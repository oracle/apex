prompt --application/deployment/install/install_plg_odata_filters_pks
begin
--   Manifest
--     INSTALL: INSTALL-plg_odata_filters_pks
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-17'
,p_default_workspace_id=>20
,p_default_application_id=>773
,p_default_id_offset=>1336332408777362883
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1365672165930114475)
,p_install_id=>wwv_flow_imp.id(1357721085222210687)
,p_name=>'plg_odata_filters_pks'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package plg_odata_filters as',
'',
'-------------------------------------------------------------------------------',
'-- Name: plg_odata_filters.pks',
'-- Copyright (c) 2012, 2022 Oracle and/or its affiliates.',
'-- Licensed under the Universal Permissive License v 1.0',
'-- as shown at https://oss.oracle.com/licenses/upl/',
'-------------------------------------------------------------------------------',
'',
'--=============================================================================',
'-- convert APEX_EXEC filters to an ODATA filter expression (string)',
'--=============================================================================',
'function odata_filter_format (',
'    p_filters               in            apex_exec.t_filters,',
'    p_local_filters         in out nocopy apex_exec.t_filters,',
'    p_external_filters      in            varchar2,',
'    --',
'    p_web_source            in            apex_plugin.t_web_source,',
'    p_profile_columns       in            apex_plugin.t_web_source_columns,',
'    --',
'    p_plugin_attributes     in            plg_odata_connector.t_plugin_attributes,',
'    --',
'    p_row_search_query      out           varchar2 )',
'    return varchar2;',
'',
'end plg_odata_filters;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
