prompt --application/deployment/install/install_plg_odata_order_bys_pks
begin
--   Manifest
--     INSTALL: INSTALL-plg_odata_order_bys_pks
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-17'
,p_default_workspace_id=>20
,p_default_application_id=>773
,p_default_id_offset=>1336332408777362883
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1365672030695112222)
,p_install_id=>wwv_flow_imp.id(1357721085222210687)
,p_name=>'plg_odata_order_bys_pks'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package plg_odata_order_bys as',
'',
'-------------------------------------------------------------------------------',
'-- Name: plg_odata_filters.pks',
'-- Copyright (c) 2012, 2022 Oracle and/or its affiliates.',
'-- Licensed under the Universal Permissive License v 1.0',
'-- as shown at https://oss.oracle.com/licenses/upl/',
'-------------------------------------------------------------------------------',
'',
'--=============================================================================',
'-- convert APEX_EXEC orderbys to an ODATA orderby expression (string)',
'--=============================================================================',
'function odata_orderby_format (',
'    p_profile_columns         in apex_plugin.t_web_source_columns,',
'    p_order_bys               in apex_exec.t_order_bys,',
'    p_external_order_bys      in varchar2 )',
'    return varchar2;',
'',
'end plg_odata_order_bys;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
