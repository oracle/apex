prompt --application/deployment/install/install_northwind_data_tbl
begin
--   Manifest
--     INSTALL: INSTALL-northwind_data_tbl
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-17'
,p_default_workspace_id=>20
,p_default_application_id=>773
,p_default_id_offset=>1336332408777362883
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1336342647974389114)
,p_install_id=>wwv_flow_imp.id(1357721085222210687)
,p_name=>'northwind_data_tbl'
,p_sequence=>5
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table NORTHWIND_DATA(',
'    "OrderID"                   NUMBER',
'   ,"CustomerID"                VARCHAR2(5)',
'   ,"EmployeeID"                NUMBER',
'   ,"OrderDate"                 TIMESTAMP WITH TIME ZONE',
'   ,"RequiredDate"              TIMESTAMP WITH TIME ZONE',
'   ,"ShippedDate"               TIMESTAMP WITH TIME ZONE',
'   ,"ShipVia"                   NUMBER',
'   ,"Freight"                   NUMBER',
'   ,"ShipName"                  VARCHAR2(40)',
'   ,"ShipAddress"               VARCHAR2(60)',
'   ,"ShipCity"                  VARCHAR2(15)',
'   ,"ShipRegion"                VARCHAR2(15)',
'   ,"ShipPostalCode"            VARCHAR2(10)',
'   ,"ShipCountry"               VARCHAR2(15)',
'   ,"COLOR"                     VARCHAR2(4000)',
'   ,"APEX$SYNC_STEP_STATIC_ID"  VARCHAR2(255)',
'   ,"APEX$ROW_SYNC_TIMESTAMP"   TIMESTAMP WITH TIME ZONE',
'   ,constraint "NORTHWIND_DATA_PK" primary key ("OrderID"))',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
