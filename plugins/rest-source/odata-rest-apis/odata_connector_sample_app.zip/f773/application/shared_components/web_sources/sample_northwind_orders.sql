prompt --application/shared_components/web_sources/sample_northwind_orders
begin
--   Manifest
--     WEB SOURCE: Sample-Northwind-Orders
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-17'
,p_default_workspace_id=>20
,p_default_application_id=>773
,p_default_id_offset=>1336332408777362883
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(1356850606266893296)
,p_name=>'Sample-Northwind-Orders'
,p_static_id=>'Sample_Northwind_Orders'
,p_web_source_type=>'PLUGIN_ODATA-CONNECTOR'
,p_data_profile_id=>wwv_flow_imp.id(1356846139689893294)
,p_remote_server_id=>wwv_flow_imp.id(1308521733375835381)
,p_url_path_prefix=>'V4/Northwind/Northwind.svc'
,p_sync_table_name=>'NORTHWIND_DATA'
,p_sync_type=>'TRUNCATE'
,p_sync_max_http_requests=>1000
,p_catalog_internal_name=>'ODATA-CATALOG-FILTER'
,p_catalog_service_name=>'Sample-Northwind-Orders'
,p_catalog_service_version=>20220713
,p_attribute_01=>'Orders'
,p_attribute_03=>'option_orderby:option_select:option_client_driven_paging'
,p_attribute_04=>'filter_lower'
,p_attribute_05=>'N'
,p_attribute_06=>'count_true_inline'
,p_attribute_07=>'filter_endswith:filter_startswith:filter_contains'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(1356850731389893296)
,p_web_src_module_id=>wwv_flow_imp.id(1356850606266893296)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_legacy_ords_fixed_page_size=>200
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
,p_caching=>'ALL_USERS'
);
wwv_flow_imp.component_end;
end;
/
