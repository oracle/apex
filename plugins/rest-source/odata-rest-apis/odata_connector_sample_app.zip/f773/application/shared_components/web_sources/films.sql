prompt --application/shared_components/web_sources/films
begin
--   Manifest
--     WEB SOURCE: Films
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-17'
,p_default_workspace_id=>20
,p_default_application_id=>773
,p_default_id_offset=>1336332408777362883
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(1356866613941899051)
,p_name=>'Films'
,p_static_id=>'Films'
,p_web_source_type=>'PLUGIN_ODATA-CONNECTOR'
,p_data_profile_id=>wwv_flow_imp.id(1356862595743899049)
,p_remote_server_id=>wwv_flow_imp.id(1333553614906578736)
,p_url_path_prefix=>'odata4.svc'
,p_attribute_01=>'SklFilms'
,p_attribute_03=>'option_orderby:option_select:option_client_driven_paging'
,p_attribute_04=>'filter_lower'
,p_attribute_05=>'N'
,p_attribute_06=>'count_true_inline'
,p_attribute_07=>'filter_startswith:filter_endswith:filter_contains'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(1356866868352899051)
,p_web_src_module_id=>wwv_flow_imp.id(1356866613941899051)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
