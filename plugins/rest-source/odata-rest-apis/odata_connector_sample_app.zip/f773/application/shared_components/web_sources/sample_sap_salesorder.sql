prompt --application/shared_components/web_sources/sample_sap_salesorder
begin
--   Manifest
--     WEB SOURCE: Sample-SAP-SalesOrder
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-17'
,p_default_workspace_id=>20
,p_default_application_id=>773
,p_default_id_offset=>1336332408777362883
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(1356858849964893300)
,p_name=>'Sample-SAP-SalesOrder'
,p_static_id=>'Sample_SAP_SalesOrder'
,p_web_source_type=>'PLUGIN_ODATA-CONNECTOR'
,p_data_profile_id=>wwv_flow_imp.id(1356851207160893298)
,p_remote_server_id=>wwv_flow_imp.id(1312718500349999059)
,p_url_path_prefix=>'/odata4/sap/ze2e001/default/sap/ze2e001_salesorder/0001'
,p_catalog_internal_name=>'ODATA-CATALOG-FILTER'
,p_catalog_service_name=>'Sample-SAP-SalesOrder'
,p_catalog_service_version=>20220713
,p_attribute_01=>'SalesOrder'
,p_attribute_03=>'option_orderby:option_select:option_client_driven_paging'
,p_attribute_04=>'none'
,p_attribute_05=>'N'
,p_attribute_06=>'count_none'
,p_attribute_07=>'filter_contains:filter_startswith:filter_endswith'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(1356859197875893300)
,p_web_src_module_id=>wwv_flow_imp.id(1356858849964893300)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
,p_caching=>'ALL_USERS'
);
wwv_flow_imp.component_end;
end;
/
