prompt --application/shared_components/web_sources/sample_trippin_airports
begin
--   Manifest
--     WEB SOURCE: Sample-Trippin-Airports
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-17'
,p_default_workspace_id=>20
,p_default_application_id=>773
,p_default_id_offset=>1336332408777362883
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(1356912303211053912)
,p_name=>'Sample-Trippin-Airports'
,p_static_id=>'Sample_Trippin_Airports'
,p_web_source_type=>'PLUGIN_ODATA-CONNECTOR'
,p_data_profile_id=>wwv_flow_imp.id(1356909620639053909)
,p_remote_server_id=>wwv_flow_imp.id(28876733146425725079)
,p_url_path_prefix=>'/TripPinServiceRW/'
,p_attribute_01=>'Airports'
,p_attribute_03=>'option_select:option_orderby:option_search:option_client_driven_paging'
,p_attribute_04=>'filter_lower'
,p_attribute_05=>'N'
,p_attribute_06=>'count_true_inline'
,p_attribute_07=>'filter_contains:filter_startswith:filter_endswith'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(1356912443532053913)
,p_web_src_module_id=>wwv_flow_imp.id(1356912303211053912)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
