prompt --application/shared_components/navigation/lists/restsourceslist
begin
--   Manifest
--     LIST: RestSourcesList
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-17'
,p_default_workspace_id=>20
,p_default_application_id=>773
,p_default_id_offset=>1336332408777362883
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1365647089474324674)
,p_name=>'RestSourcesList'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1365647237567324674)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'OData People'
,p_list_item_link_target=>'https://services.odata.org/V4//TripPinServiceRW/People'
,p_list_text_01=>'<strong>Currently not used on any pages</strong>'
,p_list_text_02=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>Supports:</strong>',
'<ul>',
'  <li>OrderBy</li>',
'  <li>Select</li>',
'  <li>Search</li>',
'  <li>Pagination (nextlink)</li>',
'  <li>Client Pagination (top & skip)</li>',
'  <li>Case sensitive</li>',
'</ul>',
'<strong>Additional Filters:</strong>',
'<ul>',
'  <li>contains</li>',
'  <li>starts with</li>',
'  <li>ends with</li>',
'</ul>'))
,p_list_text_05=>'target="_blank" rel="noreferrer"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1365647688977324674)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'OData Airports'
,p_list_item_link_target=>'https://services.odata.org/V4//TripPinServiceRW/Airports'
,p_list_text_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>Used on Pages:</strong>',
'<ul>',
'  <li>Map</li>',
'</ul>'))
,p_list_text_02=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>Supports:</strong>',
'<ul>',
'  <li>OrderBy</li>',
'  <li>Select</li>',
'  <li>Search</li>',
'  <li>Pagination (nextlink)</li>',
'  <li>Client Pagination (top & skip)</li>',
'  <li>Case sensitive</li>',
'</ul>',
'<strong>Additional Filters:</strong>',
'<ul>',
'  <li>contains</li>',
'  <li>starts with</li>',
'  <li>ends with</li>',
'</ul>'))
,p_list_text_05=>'target="_blank" rel="noreferrer"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1365648013483324674)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'DVD Rental'
,p_list_item_link_target=>'http://oiyokan.herokuapp.com/odata4.svc/SklFilms'
,p_list_text_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>Used on Pages:</strong>',
'<ul>',
'  <li>Cards</li>',
'</ul>'))
,p_list_text_02=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>Supports:</strong>',
'<ul>',
'  <li>OrderBy</li>',
'  <li>Select</li>',
'  <li>Client Pagination (top & skip)</li>',
'  <li>Case Sensitive</li>',
'</ul>',
'<strong>Additional Filters:</strong>',
'<ul>',
'  <li>contains</li>',
'  <li>starts with</li>',
'  <li>ends with</li>',
'</ul>'))
,p_list_text_05=>'target="_blank" rel="noreferrer"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1365648465981324674)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Northwind'
,p_list_item_link_target=>'https://services.odata.org/V4/Northwind/Northwind.svc'
,p_list_text_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>Used on Pages:</strong>',
'<ul>',
'  <li>Interactive Report</li>',
'  <li>Interactive Grid</li>',
'  <li>Faceted Search</li>',
'  <li>Calendar</li>',
'</ul>'))
,p_list_text_02=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>Supports:</strong>',
'<ul>',
'  <li>OrderBy</li>',
'  <li>Select</li>',
'  <li>Client Pagination (top & skip)</li>',
'  <li>Case Sensitive</li>',
'</ul>',
'<strong>Additional Filters:</strong>',
'<ul>',
'  <li>contains</li>',
'  <li>starts with</li>',
'  <li>ends with</li>',
'</ul>'))
,p_list_text_05=>'target="_blank" rel="noreferrer"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1366364955550315905)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'SAP SalesOrder'
,p_list_item_link_target=>'https://sapes5.sapdevcenter.com/sap/opu/odata4/sap/ze2e001/default/sap/ze2e001_salesorder/0001/SalesOrder'
,p_list_text_01=>'<strong>Currently not used on any pages</strong>'
,p_list_text_02=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>Supports:</strong>',
'<ul>',
'  <li>OrderBy</li>',
'  <li>Select</li>',
'  <li>Client Pagination(top & skip)</li>',
'</ul>',
'<strong>Additional Filters:</strong>',
'<ul>',
'  <li>contains</li>',
'  <li>starts with</li>',
'  <li>ends with</li>',
'</ul>',
''))
,p_list_text_05=>'target="_blank" rel="noreferrer"'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
