prompt --workspace/remote_servers/oiyokan_herokuapp_com
begin
--   Manifest
--     REMOTE SERVER: oiyokan-herokuapp-com
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-17'
,p_default_workspace_id=>20
,p_default_application_id=>773
,p_default_id_offset=>1336332408777362883
,p_default_owner=>'ORACLE'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(1333553614906578736)
,p_name=>'oiyokan-herokuapp-com'
,p_static_id=>'oiyokan_herokuapp_com'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('oiyokan_herokuapp_com'),'http://oiyokan.herokuapp.com/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('oiyokan_herokuapp_com'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('oiyokan_herokuapp_com'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('oiyokan_herokuapp_com'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('oiyokan_herokuapp_com'),'')
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
