prompt --workspace/remote_servers/services_odata_org
begin
--   Manifest
--     REMOTE SERVER: services-odata-org
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-17'
,p_default_workspace_id=>20
,p_default_application_id=>773
,p_default_id_offset=>1336332408777362883
,p_default_owner=>'ORACLE'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(1308521733375835381)
,p_name=>'services-odata-org'
,p_static_id=>'services_odata_org'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('services_odata_org'),'https://services.odata.org/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('services_odata_org'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('services_odata_org'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('services_odata_org'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('services_odata_org'),'')
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
