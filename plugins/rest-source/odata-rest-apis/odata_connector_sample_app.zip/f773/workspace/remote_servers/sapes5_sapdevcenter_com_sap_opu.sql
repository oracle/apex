prompt --workspace/remote_servers/sapes5_sapdevcenter_com_sap_opu
begin
--   Manifest
--     REMOTE SERVER: sapes5-sapdevcenter-com-sap-opu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-17'
,p_default_workspace_id=>20
,p_default_application_id=>773
,p_default_id_offset=>1336332408777362883
,p_default_owner=>'ORACLE'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(1312718500349999059)
,p_name=>'sapes5-sapdevcenter-com-sap-opu'
,p_static_id=>'sapes5_sapdevcenter_com_sap_opu'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('sapes5_sapdevcenter_com_sap_opu'),'https://sapes5.sapdevcenter.com/sap/opu/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('sapes5_sapdevcenter_com_sap_opu'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('sapes5_sapdevcenter_com_sap_opu'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('sapes5_sapdevcenter_com_sap_opu'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('sapes5_sapdevcenter_com_sap_opu'),'')
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
