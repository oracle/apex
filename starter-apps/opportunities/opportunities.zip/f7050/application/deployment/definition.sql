prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7050
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'drop table eba_sales_territory_acl       cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_tz_pref          ';
wwv_flow_imp.g_varchar2_table(2) := '   cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_deal_stages         cascade constraints;'||wwv_flow.LF||
'drop table eba';
wwv_flow_imp.g_varchar2_table(3) := '_sales_states              cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_history             cascade con';
wwv_flow_imp.g_varchar2_table(4) := 'straints;'||wwv_flow.LF||
'drop table eba_sales_terr_map            cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_lead_so';
wwv_flow_imp.g_varchar2_table(5) := 'urces        cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_svps                cascade constraints;'||wwv_flow.LF||
'drop';
wwv_flow_imp.g_varchar2_table(6) := ' table eba_sales_deal_team           cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_deal_competition    c';
wwv_flow_imp.g_varchar2_table(7) := 'ascade constraints;'||wwv_flow.LF||
'drop table eba_sales_fin_assessments     cascade constraints;'||wwv_flow.LF||
'drop table eba_sal';
wwv_flow_imp.g_varchar2_table(8) := 'es_competitors         cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_status_assessments  cascade constra';
wwv_flow_imp.g_varchar2_table(9) := 'ints;'||wwv_flow.LF||
'drop table eba_sales_risk_assessments    cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_account_sta';
wwv_flow_imp.g_varchar2_table(10) := 'nding    cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_competitor_threats  cascade constraints;'||wwv_flow.LF||
'drop tab';
wwv_flow_imp.g_varchar2_table(11) := 'le eba_sales_deal_status_codes   cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_links               casca';
wwv_flow_imp.g_varchar2_table(12) := 'de constraints;'||wwv_flow.LF||
'drop table eba_sales_files               cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_a';
wwv_flow_imp.g_varchar2_table(13) := 'ct_competition     cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_tags                cascade constraints';
wwv_flow_imp.g_varchar2_table(14) := ';'||wwv_flow.LF||
'drop table eba_sales_tags_type_sum       cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_tags_sum       ';
wwv_flow_imp.g_varchar2_table(15) := '     cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_currencies          cascade constraints;'||wwv_flow.LF||
'drop table e';
wwv_flow_imp.g_varchar2_table(16) := 'ba_sales_industries          cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_countries           cascade c';
wwv_flow_imp.g_varchar2_table(17) := 'onstraints;'||wwv_flow.LF||
'drop table eba_sales_territories         cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_custo';
wwv_flow_imp.g_varchar2_table(18) := 'mers           cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_customer_contacts   cascade constraints;'||wwv_flow.LF||
'dr';
wwv_flow_imp.g_varchar2_table(19) := 'op table eba_sales_salesreps           cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_products           ';
wwv_flow_imp.g_varchar2_table(20) := ' cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_deals               cascade constraints;'||wwv_flow.LF||
'drop table eba_s';
wwv_flow_imp.g_varchar2_table(21) := 'ales_deal_products       cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_sales_periods       cascade const';
wwv_flow_imp.g_varchar2_table(22) := 'raints;'||wwv_flow.LF||
'drop table eba_sales_customer_locations  cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_salesrep_';
wwv_flow_imp.g_varchar2_table(23) := 'roles      cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_notifications       cascade constraints;'||wwv_flow.LF||
'drop t';
wwv_flow_imp.g_varchar2_table(24) := 'able eba_sales_leads               cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_lead_status_codes   cas';
wwv_flow_imp.g_varchar2_table(25) := 'cade constraints;'||wwv_flow.LF||
'drop table eba_sales_clicks              cascade constraints;'||wwv_flow.LF||
'drop table eba_sales';
wwv_flow_imp.g_varchar2_table(26) := '_users               cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_access_levels       cascade constrain';
wwv_flow_imp.g_varchar2_table(27) := 'ts;'||wwv_flow.LF||
'drop table eba_sales_error_lookup        cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_preferences  ';
wwv_flow_imp.g_varchar2_table(28) := '       cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_errors              cascade constraints;'||wwv_flow.LF||
'drop table';
wwv_flow_imp.g_varchar2_table(29) := ' eba_sales_verifications       cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_comments            cascade';
wwv_flow_imp.g_varchar2_table(30) := ' constraints;'||wwv_flow.LF||
'drop table eba_sales_product_families    cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_ter';
wwv_flow_imp.g_varchar2_table(31) := 'ms               cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_agreement_types     cascade constraints;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(32) := 'drop table eba_sales_agreements          cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_cust_agrmnt_map  ';
wwv_flow_imp.g_varchar2_table(33) := '   cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_product_lobs        cascade constraints;'||wwv_flow.LF||
'drop table eba';
wwv_flow_imp.g_varchar2_table(34) := '_sales_support_amts        cascade constraints;'||wwv_flow.LF||
'drop table eba_sales_suprt_amt_types     cascade con';
wwv_flow_imp.g_varchar2_table(35) := 'straints;'||wwv_flow.LF||
'drop table eba_sales_cust_spt_amt_map    cascade constraints;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop view eba_sales_opp_v;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(36) := 'drop view eba_sales_opportunities_v;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop sequence eba_sales_sequence;'||wwv_flow.LF||
'drop sequence eba_sales_sequ';
wwv_flow_imp.g_varchar2_table(37) := 'ence2;'||wwv_flow.LF||
'drop sequence eba_sales_rowkey_seq;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop procedure eba_sales_tz_init;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop package eba_sale';
wwv_flow_imp.g_varchar2_table(38) := 's_data;'||wwv_flow.LF||
'drop package eba_sales_acl_api;'||wwv_flow.LF||
'drop package eba_sales_fw;';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(10512994198141527757)
,p_welcome_message=>'This application installer will guide you through the process of creating your database objects and seed data.'
,p_configuration_message=>'You can configure the following attributes of your application.'
,p_build_options_message=>'You can choose to include the following build options.'
,p_validation_message=>'The following validations will be performed to ensure your system is compatible with this application.'
,p_install_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_message=>'The application installer has detected that this application''s supporting objects were previously installed.  This wizard will guide you through the process of upgrading these supporting objects.'
,p_upgrade_confirm_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_success_message=>'Your application''s supporting objects have been installed.'
,p_upgrade_failure_message=>'Installation of database objects and seed data has failed.'
,p_get_version_sql_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select object_name',
'from user_objects',
'where object_name like ''EBA_SALES_%'''))
,p_deinstall_success_message=>'Deinstallation complete.'
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_free_kb=>3520
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE SEQUENCE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
,p_required_names_available=>'EBA_SALES_ACCESS_LEVELS:EBA_SALES_ACCOUNT_STANDING:EBA_SALES_ACL_API:EBA_SALES_ACTNOTES:EBA_SALES_ACT_COMPETITION:EBA_SALES_ACT_FILES:EBA_SALES_ACT_LINKS:EBA_SALES_COMPETITORS:EBA_SALES_COMPETITOR_THREATS:EBA_SALES_COUNTRIES:EBA_SALES_CURRENCIES:EBA_'
||'SALES_CUSTOMERS:EBA_SALES_CUSTOMER_CONTACTS:EBA_SALES_CUSTOMER_LOCATIONS:EBA_SALES_DATA:EBA_SALES_DEALS:EBA_SALES_DEAL_COMPETITION:EBA_SALES_DEAL_NOTES:EBA_SALES_DEAL_PRODUCTS:EBA_SALES_DEAL_STAGES:EBA_SALES_DEAL_STATUS_CODES:EBA_SALES_DEAL_TEAM:EBA_'
||'SALES_ERRORS:EBA_SALES_ERROR_LOOKUP:EBA_SALES_FILES:EBA_SALES_FIN_ASSESSMENTS:EBA_SALES_HISTORY:EBA_SALES_INDUSTRIES:EBA_SALES_LEADS:EBA_SALES_LEAD_SOURCES:EBA_SALES_LEAD_STATUS_CODES:EBA_SALES_LINKS:EBA_SALES_NOTIFICATIONS:EBA_SALES_OPPORTUNITIES_V:'
||'EBA_SALES_OPP_V:EBA_SALES_PREFERENCES:EBA_SALES_PRODUCTS:EBA_SALES_RISK_ASSESSMENTS:EBA_SALES_ROWKEY_SEQ:EBA_SALES_SALESREPS:EBA_SALES_SALESREP_ROLES:EBA_SALES_SALES_PERIODS:EBA_SALES_SEQUENCE:EBA_SALES_SEQUENCE2:EBA_SALES_STATES:EBA_SALES_STATUS_ASS'
||'ESSMENTS:EBA_SALES_SVPS:EBA_SALES_TAGS:EBA_SALES_TAGS_SUM:EBA_SALES_TAGS_TYPE_SUM:EBA_SALES_TERRITORIES:EBA_SALES_TERRITORY_ACL:EBA_SALES_TERR_MAP:EBA_SALES_TZ_INIT:EBA_SALES_TZ_PREF:EBA_SALES_USERS:EBA_SALES_FW:EBA_SALES_CLICKS:EBA_SALES_VERIFICATIO'
||'NS:EBA_SALES_PRODUCT_FAMILIES:EBA_SALES_TERMS:EBA_SALES_PRODUCT_LOBS:EBA_SALES_CUST_SPT_AMT_MAP:EBA_SALES_SUPPORT_AMTS:EBA_SALES_SUPRT_AMT_TYPES:EBA_SALES_AGREEMENTS:EBA_SALES_AGREEMENT_TYPES'
);
wwv_flow_imp.component_end;
end;
/
