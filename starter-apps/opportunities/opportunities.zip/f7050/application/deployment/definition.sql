prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7050
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(10495272006180774354)
,p_welcome_message=>'This application installer will guide you through the process of creating your database objects and seed data.'
,p_configuration_message=>'You can configure the following attributes of your application.'
,p_build_options_message=>'You can choose to include the following build options.'
,p_validation_message=>'The following validations will be performed to ensure your system is compatible with this application.'
,p_install_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_message=>'The application installer has detected that this application''s supporting objects were previously installed.  This wizard will guide you through the process of upgrading these supporting objects.'
,p_upgrade_confirm_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_success_message=>'Your application''s supporting objects have been installed.'
,p_upgrade_failure_message=>'Installation of database objects and seed data has failed.'
,p_get_version_sql_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select object_name',
'from user_objects',
'where object_name like ''EBA_SALES_%'''))
,p_deinstall_success_message=>'Deinstallation complete.'
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop table eba_sales_territory_acl       cascade constraints;',
'drop table eba_sales_tz_pref             cascade constraints;',
'drop table eba_sales_deal_stages         cascade constraints;',
'drop table eba_sales_states              cascade constraints;',
'drop table eba_sales_history             cascade constraints;',
'drop table eba_sales_terr_map            cascade constraints;',
'drop table eba_sales_lead_sources        cascade constraints;',
'drop table eba_sales_svps                cascade constraints;',
'drop table eba_sales_deal_team           cascade constraints;',
'drop table eba_sales_deal_competition    cascade constraints;',
'drop table eba_sales_fin_assessments     cascade constraints;',
'drop table eba_sales_competitors         cascade constraints;',
'drop table eba_sales_status_assessments  cascade constraints;',
'drop table eba_sales_risk_assessments    cascade constraints;',
'drop table eba_sales_account_standing    cascade constraints;',
'drop table eba_sales_competitor_threats  cascade constraints;',
'drop table eba_sales_deal_status_codes   cascade constraints;',
'drop table eba_sales_links               cascade constraints;',
'drop table eba_sales_files               cascade constraints;',
'drop table eba_sales_act_competition     cascade constraints;',
'drop table eba_sales_tags                cascade constraints;',
'drop table eba_sales_tags_type_sum       cascade constraints;',
'drop table eba_sales_tags_sum            cascade constraints;',
'drop table eba_sales_currencies          cascade constraints;',
'drop table eba_sales_industries          cascade constraints;',
'drop table eba_sales_countries           cascade constraints;',
'drop table eba_sales_territories         cascade constraints;',
'drop table eba_sales_customers           cascade constraints;',
'drop table eba_sales_customer_contacts   cascade constraints;',
'drop table eba_sales_salesreps           cascade constraints;',
'drop table eba_sales_products            cascade constraints;',
'drop table eba_sales_deals               cascade constraints;',
'drop table eba_sales_deal_products       cascade constraints;',
'drop table eba_sales_sales_periods       cascade constraints;',
'drop table eba_sales_customer_locations  cascade constraints;',
'drop table eba_sales_salesrep_roles      cascade constraints;',
'drop table eba_sales_notifications       cascade constraints;',
'drop table eba_sales_leads               cascade constraints;',
'drop table eba_sales_lead_status_codes   cascade constraints;',
'drop table eba_sales_clicks              cascade constraints;',
'drop table eba_sales_users               cascade constraints;',
'drop table eba_sales_access_levels       cascade constraints;',
'drop table eba_sales_error_lookup        cascade constraints;',
'drop table eba_sales_preferences         cascade constraints;',
'drop table eba_sales_errors              cascade constraints;',
'drop table eba_sales_verifications       cascade constraints;',
'drop table eba_sales_comments            cascade constraints;',
'drop table eba_sales_product_families    cascade constraints;',
'drop table eba_sales_terms               cascade constraints;',
'drop table eba_sales_agreement_types     cascade constraints;',
'drop table eba_sales_agreements          cascade constraints;',
'drop table eba_sales_cust_agrmnt_map     cascade constraints;',
'drop table eba_sales_product_lobs        cascade constraints;',
'drop table eba_sales_support_amts        cascade constraints;',
'drop table eba_sales_suprt_amt_types     cascade constraints;',
'drop table eba_sales_cust_spt_amt_map    cascade constraints;',
'',
'drop view eba_sales_opp_v;',
'drop view eba_sales_opportunities_v;',
'',
'drop sequence eba_sales_sequence;',
'drop sequence eba_sales_sequence2;',
'drop sequence eba_sales_rowkey_seq;',
'',
'drop procedure eba_sales_tz_init;',
'',
'drop package eba_sales_data;',
'drop package eba_sales_acl_api;',
'drop package eba_sales_fw;'))
,p_required_free_kb=>3520
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE SEQUENCE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
,p_required_names_available=>'EBA_SALES_ACCESS_LEVELS:EBA_SALES_ACCOUNT_STANDING:EBA_SALES_ACL_API:EBA_SALES_ACTNOTES:EBA_SALES_ACT_COMPETITION:EBA_SALES_ACT_FILES:EBA_SALES_ACT_LINKS:EBA_SALES_COMPETITORS:EBA_SALES_COMPETITOR_THREATS:EBA_SALES_COUNTRIES:EBA_SALES_CURRENCIES:EBA_'
||'SALES_CUSTOMERS:EBA_SALES_CUSTOMER_CONTACTS:EBA_SALES_CUSTOMER_LOCATIONS:EBA_SALES_DATA:EBA_SALES_DEALS:EBA_SALES_DEAL_COMPETITION:EBA_SALES_DEAL_NOTES:EBA_SALES_DEAL_PRODUCTS:EBA_SALES_DEAL_STAGES:EBA_SALES_DEAL_STATUS_CODES:EBA_SALES_DEAL_TEAM:EBA_'
||'SALES_ERRORS:EBA_SALES_ERROR_LOOKUP:EBA_SALES_FILES:EBA_SALES_FIN_ASSESSMENTS:EBA_SALES_HISTORY:EBA_SALES_INDUSTRIES:EBA_SALES_LEADS:EBA_SALES_LEAD_SOURCES:EBA_SALES_LEAD_STATUS_CODES:EBA_SALES_LINKS:EBA_SALES_NOTIFICATIONS:EBA_SALES_OPPORTUNITIES_V:'
||'EBA_SALES_OPP_V:EBA_SALES_PREFERENCES:EBA_SALES_PRODUCTS:EBA_SALES_RISK_ASSESSMENTS:EBA_SALES_ROWKEY_SEQ:EBA_SALES_SALESREPS:EBA_SALES_SALESREP_ROLES:EBA_SALES_SALES_PERIODS:EBA_SALES_SEQUENCE:EBA_SALES_SEQUENCE2:EBA_SALES_STATES:EBA_SALES_STATUS_ASS'
||'ESSMENTS:EBA_SALES_SVPS:EBA_SALES_TAGS:EBA_SALES_TAGS_SUM:EBA_SALES_TAGS_TYPE_SUM:EBA_SALES_TERRITORIES:EBA_SALES_TERRITORY_ACL:EBA_SALES_TERR_MAP:EBA_SALES_TZ_INIT:EBA_SALES_TZ_PREF:EBA_SALES_USERS:EBA_SALES_FW:EBA_SALES_CLICKS:EBA_SALES_VERIFICATIO'
||'NS:EBA_SALES_PRODUCT_FAMILIES:EBA_SALES_TERMS:EBA_SALES_PRODUCT_LOBS:EBA_SALES_CUST_SPT_AMT_MAP:EBA_SALES_SUPPORT_AMTS:EBA_SALES_SUPRT_AMT_TYPES:EBA_SALES_AGREEMENTS:EBA_SALES_AGREEMENT_TYPES'
);
wwv_flow_imp.component_end;
end;
/
