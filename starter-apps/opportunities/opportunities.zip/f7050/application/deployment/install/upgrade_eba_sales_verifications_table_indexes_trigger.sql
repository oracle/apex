prompt --application/deployment/install/upgrade_eba_sales_verifications_table_indexes_trigger
begin
--   Manifest
--     INSTALL: UPGRADE-eba_sales_verifications table, indexes, trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(7396395528907858062)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_verifications table, indexes, trigger'
,p_sequence=>40
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_SALES_VERIFICATIONS'''))
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table eba_sales_verifications',
'(',
'    id                   number primary key,',
'    cust_id              number references eba_sales_customers (id) on delete cascade,',
'    lead_id              number references eba_sales_leads (id) on delete cascade,',
'    opp_id               number,',
'    verified_by          varchar2(255) not null,',
'    verification_comment varchar2(4000),',
'    created              timestamp(6) with time zone,',
'    created_by           varchar2(255),',
'    updated              timestamp(6) with time zone,',
'    updated_by           varchar2(255)',
');',
'/',
'',
'create index eba_sales_verify_idx1 on eba_sales_verifications (cust_id);',
'create index eba_sales_verify_idx2 on eba_sales_verifications (lead_id);',
'create index eba_sales_verify_idx3 on eba_sales_verifications (opp_id);',
'    ',
'create or replace trigger eba_sales_verify_biu_fer',
'   before insert or update on eba_sales_verifications',
'   for each row',
'begin',
'   if :new.id is null then',
'     :new.id := eba_sales_sequence.nextval;',
'   end if;',
'   if inserting then',
'       :new.created := current_timestamp;',
'       :new.created_by := nvl(apex_application.g_user,user);',
'   end if;',
'   if inserting or updating then',
'       :new.updated := current_timestamp;',
'       :new.updated_by := nvl(apex_application.g_user,user);',
'   end if;',
'end;',
'/',
'',
'alter trigger eba_sales_verify_biu_fer enable;',
''))
);
wwv_flow_imp.component_end;
end;
/
