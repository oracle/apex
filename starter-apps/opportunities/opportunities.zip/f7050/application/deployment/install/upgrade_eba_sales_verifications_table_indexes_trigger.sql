prompt --application/deployment/install/upgrade_eba_sales_verifications_table_indexes_trigger
begin
--   Manifest
--     INSTALL: UPGRADE-eba_sales_verifications table, indexes, trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_sales_verifications'||wwv_flow.LF||
'('||wwv_flow.LF||
'    id                   number primary key,'||wwv_flow.LF||
'    cust_id     ';
wwv_flow_imp.g_varchar2_table(2) := '         number references eba_sales_customers (id) on delete cascade,'||wwv_flow.LF||
'    lead_id              numb';
wwv_flow_imp.g_varchar2_table(3) := 'er references eba_sales_leads (id) on delete cascade,'||wwv_flow.LF||
'    opp_id               number,'||wwv_flow.LF||
'    verified_';
wwv_flow_imp.g_varchar2_table(4) := 'by          varchar2(255) not null,'||wwv_flow.LF||
'    verification_comment varchar2(4000),'||wwv_flow.LF||
'    created            ';
wwv_flow_imp.g_varchar2_table(5) := '  timestamp(6) with time zone,'||wwv_flow.LF||
'    created_by           varchar2(255),'||wwv_flow.LF||
'    updated              time';
wwv_flow_imp.g_varchar2_table(6) := 'stamp(6) with time zone,'||wwv_flow.LF||
'    updated_by           varchar2(255)'||wwv_flow.LF||
');'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_sales_verify_';
wwv_flow_imp.g_varchar2_table(7) := 'idx1 on eba_sales_verifications (cust_id);'||wwv_flow.LF||
'create index eba_sales_verify_idx2 on eba_sales_verificat';
wwv_flow_imp.g_varchar2_table(8) := 'ions (lead_id);'||wwv_flow.LF||
'create index eba_sales_verify_idx3 on eba_sales_verifications (opp_id);'||wwv_flow.LF||
'    '||wwv_flow.LF||
'create ';
wwv_flow_imp.g_varchar2_table(9) := 'or replace trigger eba_sales_verify_biu_fer'||wwv_flow.LF||
'   before insert or update on eba_sales_verifications'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(10) := ' for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.id is null then'||wwv_flow.LF||
'     :new.id := eba_sales_sequence.nextval;'||wwv_flow.LF||
'   end if';
wwv_flow_imp.g_varchar2_table(11) := ';'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(apex_';
wwv_flow_imp.g_varchar2_table(12) := 'application.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current';
wwv_flow_imp.g_varchar2_table(13) := '_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(apex_application.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter tr';
wwv_flow_imp.g_varchar2_table(14) := 'igger eba_sales_verify_biu_fer enable;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(7396395528907858062)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_verifications table, indexes, trigger'
,p_sequence=>40
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_SALES_VERIFICATIONS'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
