prompt --application/deployment/install/install_indexes
begin
--   Manifest
--     INSTALL: INSTALL-indexes
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(6797520892266357486)
,p_install_id=>wwv_flow_api.id(10495272006180774354)
,p_name=>'indexes'
,p_sequence=>620
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE UNIQUE INDEX "EBA_SALES_ACCESS_LEVELS_UK" ON "EBA_SALES_ACCESS_LEVELS" ("ACCESS_LEVEL") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_ACT_COMPETITION_1" ON "EBA_SALES_ACT_COMPETITION" ("COMPETITOR_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_ACT_COMPETITION_2" ON "EBA_SALES_ACT_COMPETITION" ("CUSTOMER_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_ACT_COMPETITION_3" ON "EBA_SALES_ACT_COMPETITION" ("COMPETITOR_THREAT_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_CLICKS_IDX1" ON "EBA_SALES_CLICKS" ("LEAD_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_CLICKS_IDX2" ON "EBA_SALES_CLICKS" ("CUST_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_CLICKS_IDX3" ON "EBA_SALES_CLICKS" ("OPP_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_CLICKS_IDX4" ON "EBA_SALES_CLICKS" ("VIEW_TIMESTAMP") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_CLICKS_IDX5" ON "EBA_SALES_CLICKS" ("TERRITORY_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_CLICKS_IDX6" ON "EBA_SALES_CLICKS" ("CONTACT_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_CLICKS_IDX7" ON "EBA_SALES_CLICKS" ("PRODUCT_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_COMMENTS_IDX1" ON "EBA_SALES_COMMENTS" ("DEAL_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_COMMENTS_IDX2" ON "EBA_SALES_COMMENTS" ("LEAD_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_COMMENTS_IDX3" ON "EBA_SALES_COMMENTS" ("TERRITORY_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_COMMENTS_IDX4" ON "EBA_SALES_COMMENTS" ("ACCOUNT_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_COMMENTS_IDX5" ON "EBA_SALES_COMMENTS" ("CONTACT_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_COMMENTS_IDX6" ON "EBA_SALES_COMMENTS" ("PRODUCT_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_CUSTOMERS_I1" ON "EBA_SALES_CUSTOMERS" ("ROW_KEY") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_CUSTOMERS_I2" ON "EBA_SALES_CUSTOMERS" ("CUSTOMER_INDUSTRY_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_CUSTOMERS_I3" ON "EBA_SALES_CUSTOMERS" ("CUSTOMER_TERRITORY_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_CUSTOMERS_I4" ON "EBA_SALES_CUSTOMERS" ("CUSTOMER_NAME") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_CUSTOMERS_I5" ON "EBA_SALES_CUSTOMERS" ("DEFAULT_REP_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_CUSTOMER_LOC_I1" ON "EBA_SALES_CUSTOMER_LOCATIONS" ("CUSTOMER_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_DEALS_CFK" ON "EBA_SALES_DEALS" ("CUSTOMER_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_DEALS_I1" ON "EBA_SALES_DEALS" ("SALESREP_ID_01") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_DEALS_I10" ON "EBA_SALES_DEALS" ("SVP_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_DEALS_I11" ON "EBA_SALES_DEALS" ("TERRITORY_ID_OLD") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_DEALS_I12" ON "EBA_SALES_DEALS" ("EXTERNAL_OPPORTUNITY_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_DEALS_I2" ON "EBA_SALES_DEALS" ("SALESREP_ID_02") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_DEALS_I3" ON "EBA_SALES_DEALS" ("SALESREP_ID_03") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_DEALS_I4" ON "EBA_SALES_DEALS" ("SALESREP_ID_04") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_DEALS_I5" ON "EBA_SALES_DEALS" ("FINANCIAL_ASSESSMENT_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_DEALS_I6" ON "EBA_SALES_DEALS" ("STATUS_ASSESSMENT_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_DEALS_I7" ON "EBA_SALES_DEALS" ("RISK_ASSESSMENT_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_DEALS_I8" ON "EBA_SALES_DEALS" ("ACCOUNT_STANDING_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_DEALS_I9" ON "EBA_SALES_DEALS" ("VP_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_DEAL_COMPETITION_I1" ON "EBA_SALES_DEAL_COMPETITION" ("COMPETITOR_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_DEAL_COMPETITION_I2" ON "EBA_SALES_DEAL_COMPETITION" ("DEAL_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_DEAL_COMPETITION_I3" ON "EBA_SALES_DEAL_COMPETITION" ("COMPETITOR_THREAT_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_DEAL_PROD_I1" ON "EBA_SALES_DEAL_PRODUCTS" ("DEAL_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_DEAL_PROD_I2" ON "EBA_SALES_DEAL_PRODUCTS" ("PRODUCT_ID") ',
'  ;',
'',
'CREATE UNIQUE INDEX "EBA_SALES_DEAL_STATCOD_I1" ON "EBA_SALES_DEAL_STATUS_CODES" ("STATUS_CODE") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_DEAL_TEAM_I1" ON "EBA_SALES_DEAL_TEAM" ("DEAL_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_DEAL_TEAM_I2" ON "EBA_SALES_DEAL_TEAM" ("REP_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_ERRORS_I1" ON "EBA_SALES_ERRORS" ("ERR_TIME") ',
'  ;',
'',
'CREATE UNIQUE INDEX "EBA_SALES_ERROR_LOOKUP_UK" ON "EBA_SALES_ERROR_LOOKUP" ("CONSTRAINT_NAME", "LANGUAGE_CODE") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_FILES_IDX1" ON "EBA_SALES_FILES" ("DEAL_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_FILES_IDX2" ON "EBA_SALES_FILES" ("LEAD_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_FILES_IDX3" ON "EBA_SALES_FILES" ("TERRITORY_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_FILES_IDX4" ON "EBA_SALES_FILES" ("ACCOUNT_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_FILES_IDX5" ON "EBA_SALES_FILES" ("CONTACT_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_FILES_IDX6" ON "EBA_SALES_FILES" ("PRODUCT_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_HISTORY_I1" ON "EBA_SALES_HISTORY" ("DEAL_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_LEADS_I1" ON "EBA_SALES_LEADS" ("ACCOUNT_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_LEADS_I2" ON "EBA_SALES_LEADS" ("LEAD_SOURCE_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_LEADS_I3" ON "EBA_SALES_LEADS" ("LEAD_STATUS_ID") ',
'  ;',
'',
'CREATE UNIQUE INDEX "EBA_SALES_LEAD_STAT_CDI1" ON "EBA_SALES_LEAD_STATUS_CODES" ("STATUS_CODE") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_LINKS_IDX1" ON "EBA_SALES_LINKS" ("DEAL_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_LINKS_IDX2" ON "EBA_SALES_LINKS" ("LEAD_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_LINKS_IDX3" ON "EBA_SALES_LINKS" ("TERRITORY_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_LINKS_IDX4" ON "EBA_SALES_LINKS" ("ACCOUNT_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_LINKS_IDX5" ON "EBA_SALES_LINKS" ("CONTACT_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_LINKS_IDX6" ON "EBA_SALES_LINKS" ("PRODUCT_ID") ',
'  ;',
'',
'CREATE UNIQUE INDEX "EBA_SALES_PREFERENCES_UK" ON "EBA_SALES_PREFERENCES" ("PREFERENCE_NAME") ',
'  ;',
'',
'CREATE UNIQUE INDEX "EBA_SALES_PRODUCTS_I1" ON "EBA_SALES_PRODUCTS" ("PRODUCT_NAME") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_PRODUCTS_I2" ON "EBA_SALES_PRODUCTS" ("PRODUCT_SKU") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_PRODUCTS_I3" ON "EBA_SALES_PRODUCTS" ("ROW_KEY") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_SALESREPS_I1" ON "EBA_SALES_SALESREPS" ("REP_EMAIL") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_SALESREPS_I2" ON "EBA_SALES_SALESREPS" ("REP_MANAGER_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_SALESREPS_I3" ON "EBA_SALES_SALESREPS" ("REP_EBA_SALES_USERNAME") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_SALESREPS_I4" ON "EBA_SALES_SALESREPS" ("SVP_ID") ',
'  ;',
'',
'CREATE UNIQUE INDEX "EBA_SALES_SALESREP_ROLENAME" ON "EBA_SALES_SALESREP_ROLES" ("ROLE_NAME") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_SALES_PER_I1" ON "EBA_SALES_SALES_PERIODS" ("PERIOD_NAME") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_STATES_I1" ON "EBA_SALES_STATES" ("STATE") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_STATES_I2" ON "EBA_SALES_STATES" ("CODE") ',
'  ;',
'',
'CREATE UNIQUE INDEX "EBA_SALES_SVPS_I1" ON "EBA_SALES_SVPS" ("SVP_NAME") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_TERRITORY_ACL_N1" ON "EBA_SALES_TERRITORY_ACL" ("TERRITORY_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_TERR_MAP_I1" ON "EBA_SALES_TERR_MAP" ("TERRITORY_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_TERR_MAP_I3" ON "EBA_SALES_TERR_MAP" ("STATE_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_TERR_MAP_I4" ON "EBA_SALES_TERR_MAP" ("COUNTRY_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_USERS_ACC_LVL_IDX" ON "EBA_SALES_USERS" ("ACCESS_LEVEL_ID") ',
'  ;',
'',
'CREATE UNIQUE INDEX "EBA_SALES_USERS_UK" ON "EBA_SALES_USERS" ("USERNAME") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_VERIFY_IDX1" ON "EBA_SALES_VERIFICATIONS" ("CUST_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_VERIFY_IDX2" ON "EBA_SALES_VERIFICATIONS" ("LEAD_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_VERIFY_IDX3" ON "EBA_SALES_VERIFICATIONS" ("OPP_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_VERIFY_IDX4" ON "EBA_SALES_VERIFICATIONS" ("TERRITORY_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_VERIFY_IDX5" ON "EBA_SALES_VERIFICATIONS" ("CONTACT_ID") ',
'  ;',
'',
'CREATE INDEX "EBA_SALES_VERIFY_IDX6" ON "EBA_SALES_VERIFICATIONS" ("PRODUCT_ID") ',
'  ;',
'',
''))
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797521150450357489)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_ACCESS_LEVELS_UK'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797521611301357491)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_ACT_COMPETITION_1'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797521815162357491)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_ACT_COMPETITION_2'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797521958781357491)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_ACT_COMPETITION_3'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797522190964357491)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CLICKS_IDX1'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797522358411357491)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CLICKS_IDX2'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797522546514357492)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CLICKS_IDX3'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797522764586357492)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CLICKS_IDX4'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797523009085357492)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CLICKS_IDX5'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797523203470357492)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CLICKS_IDX6'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797523379852357492)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CLICKS_IDX7'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797523815783357493)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_COMMENTS_IDX1'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797523941269357493)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_COMMENTS_IDX2'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797524218280357493)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_COMMENTS_IDX3'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797524402508357493)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_COMMENTS_IDX4'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797524550680357493)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_COMMENTS_IDX5'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797524778307357493)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_COMMENTS_IDX6'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797525147238357494)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CUSTOMERS_I1'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797525348855357494)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CUSTOMERS_I2'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797525546325357494)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CUSTOMERS_I3'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797525770768357494)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CUSTOMERS_I4'
,p_last_updated_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164111','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797525968098357494)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CUSTOMERS_I5'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797526117014357495)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CUSTOMER_LOC_I1'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797526308828357495)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_CFK'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797526451081357495)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I1'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797526722208357495)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I10'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797526905310357495)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I11'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797527062053357496)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I12'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797527329597357496)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I2'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797527435156357496)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I3'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797527654281357496)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I4'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797527920014357496)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I5'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797528125574357497)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I6'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797528294653357497)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I7'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797528460736357497)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I8'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797528721957357497)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I9'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797528886678357497)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEAL_COMPETITION_I1'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797529129708357498)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEAL_COMPETITION_I2'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797529302599357498)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEAL_COMPETITION_I3'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797529659607357498)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEAL_PROD_I1'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797529892835357498)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEAL_PROD_I2'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797530109687357498)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEAL_STATCOD_I1'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797530269827357499)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEAL_TEAM_I1'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797530480128357499)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEAL_TEAM_I2'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797530675516357499)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_ERRORS_I1'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797531287981357499)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_ERROR_LOOKUP_UK'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797531483864357500)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_FILES_IDX1'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797531673644357500)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_FILES_IDX2'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797531882925357500)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_FILES_IDX3'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797532098919357500)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_FILES_IDX4'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797532291940357500)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_FILES_IDX5'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797532526568357500)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_FILES_IDX6'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797532926270357501)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_HISTORY_I1'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797533240178357501)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_LEADS_I1'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797533471101357501)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_LEADS_I2'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797533648506357501)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_LEADS_I3'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797533878002357501)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_LEAD_STAT_CDI1'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797534108331357502)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_LINKS_IDX1'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797534241687357502)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_LINKS_IDX2'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797534489590357502)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_LINKS_IDX3'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797534695446357502)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_LINKS_IDX4'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797534882183357502)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_LINKS_IDX5'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797535094409357504)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_LINKS_IDX6'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797535845822357505)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_PREFERENCES_UK'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797536067844357505)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_PRODUCTS_I1'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797536254236357505)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_PRODUCTS_I2'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797536452242357505)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_PRODUCTS_I3'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797536654815357505)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_SALESREPS_I1'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797536856372357506)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_SALESREPS_I2'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797537089490357506)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_SALESREPS_I3'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797537295961357506)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_SALESREPS_I4'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797537441816357506)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_SALESREP_ROLENAME'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797537677255357506)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_SALES_PER_I1'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797538087866357507)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_STATES_I1'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797538258248357507)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_STATES_I2'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797538652098357507)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_SVPS_I1'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797539320651357508)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_TERRITORY_ACL_N1'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797539528536357508)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_TERR_MAP_I1'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797539674734357508)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_TERR_MAP_I3'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797539921608357508)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_TERR_MAP_I4'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797540464534357509)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_USERS_ACC_LVL_IDX'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797540899036357509)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_USERS_UK'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797541128558357509)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_VERIFY_IDX1'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797541274420357509)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_VERIFY_IDX2'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797541494425357509)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_VERIFY_IDX3'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797541706501357510)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_VERIFY_IDX4'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797541878280357510)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_VERIFY_IDX5'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6797542101873357510)
,p_script_id=>wwv_flow_api.id(6797520892266357486)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_VERIFY_IDX6'
,p_last_updated_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706164112','YYYYMMDDHH24MISS')
);
wwv_flow_api.component_end;
end;
/
