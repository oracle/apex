prompt --application/deployment/install/install_indexes
begin
--   Manifest
--     INSTALL: INSTALL-indexes
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE UNIQUE INDEX "EBA_SALES_ACCESS_LEVELS_UK" ON "EBA_SALES_ACCESS_LEVELS" ("ACCESS_LEVEL") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(2) := ''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_ACT_COMPETITION_1" ON "EBA_SALES_ACT_COMPETITION" ("COMPETITOR_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'C';
wwv_flow_imp.g_varchar2_table(3) := 'REATE INDEX "EBA_SALES_ACT_COMPETITION_2" ON "EBA_SALES_ACT_COMPETITION" ("CUSTOMER_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREAT';
wwv_flow_imp.g_varchar2_table(4) := 'E INDEX "EBA_SALES_ACT_COMPETITION_3" ON "EBA_SALES_ACT_COMPETITION" ("COMPETITOR_THREAT_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(5) := 'CREATE INDEX "EBA_SALES_CLICKS_IDX1" ON "EBA_SALES_CLICKS" ("LEAD_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES';
wwv_flow_imp.g_varchar2_table(6) := '_CLICKS_IDX2" ON "EBA_SALES_CLICKS" ("CUST_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_CLICKS_IDX3" ON "EBA_S';
wwv_flow_imp.g_varchar2_table(7) := 'ALES_CLICKS" ("OPP_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_CLICKS_IDX4" ON "EBA_SALES_CLICKS" ("VIEW_TIME';
wwv_flow_imp.g_varchar2_table(8) := 'STAMP") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_CLICKS_IDX5" ON "EBA_SALES_CLICKS" ("TERRITORY_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREA';
wwv_flow_imp.g_varchar2_table(9) := 'TE INDEX "EBA_SALES_CLICKS_IDX6" ON "EBA_SALES_CLICKS" ("CONTACT_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_';
wwv_flow_imp.g_varchar2_table(10) := 'CLICKS_IDX7" ON "EBA_SALES_CLICKS" ("PRODUCT_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_COMMENTS_IDX1" ON "E';
wwv_flow_imp.g_varchar2_table(11) := 'BA_SALES_COMMENTS" ("DEAL_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_COMMENTS_IDX2" ON "EBA_SALES_COMMENTS" ';
wwv_flow_imp.g_varchar2_table(12) := '("LEAD_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_COMMENTS_IDX3" ON "EBA_SALES_COMMENTS" ("TERRITORY_ID") '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(13) := ' ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_COMMENTS_IDX4" ON "EBA_SALES_COMMENTS" ("ACCOUNT_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX';
wwv_flow_imp.g_varchar2_table(14) := ' "EBA_SALES_COMMENTS_IDX5" ON "EBA_SALES_COMMENTS" ("CONTACT_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_COMM';
wwv_flow_imp.g_varchar2_table(15) := 'ENTS_IDX6" ON "EBA_SALES_COMMENTS" ("PRODUCT_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_CUSTOMERS_I1" ON "EB';
wwv_flow_imp.g_varchar2_table(16) := 'A_SALES_CUSTOMERS" ("ROW_KEY") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_CUSTOMERS_I2" ON "EBA_SALES_CUSTOMERS" ';
wwv_flow_imp.g_varchar2_table(17) := '("CUSTOMER_INDUSTRY_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_CUSTOMERS_I3" ON "EBA_SALES_CUSTOMERS" ("CUST';
wwv_flow_imp.g_varchar2_table(18) := 'OMER_TERRITORY_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_CUSTOMERS_I4" ON "EBA_SALES_CUSTOMERS" ("CUSTOMER_';
wwv_flow_imp.g_varchar2_table(19) := 'NAME") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_CUSTOMERS_I5" ON "EBA_SALES_CUSTOMERS" ("DEFAULT_REP_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(20) := ''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_CUSTOMER_LOC_I1" ON "EBA_SALES_CUSTOMER_LOCATIONS" ("CUSTOMER_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CR';
wwv_flow_imp.g_varchar2_table(21) := 'EATE INDEX "EBA_SALES_DEALS_CFK" ON "EBA_SALES_DEALS" ("CUSTOMER_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_';
wwv_flow_imp.g_varchar2_table(22) := 'DEALS_I1" ON "EBA_SALES_DEALS" ("SALESREP_ID_01") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_DEALS_I10" ON "EBA_S';
wwv_flow_imp.g_varchar2_table(23) := 'ALES_DEALS" ("SVP_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_DEALS_I11" ON "EBA_SALES_DEALS" ("TERRITORY_ID_';
wwv_flow_imp.g_varchar2_table(24) := 'OLD") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_DEALS_I12" ON "EBA_SALES_DEALS" ("EXTERNAL_OPPORTUNITY_ID") '||wwv_flow.LF||
'  ;';
wwv_flow_imp.g_varchar2_table(25) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_DEALS_I2" ON "EBA_SALES_DEALS" ("SALESREP_ID_02") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_';
wwv_flow_imp.g_varchar2_table(26) := 'SALES_DEALS_I3" ON "EBA_SALES_DEALS" ("SALESREP_ID_03") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_DEALS_I4" ON "';
wwv_flow_imp.g_varchar2_table(27) := 'EBA_SALES_DEALS" ("SALESREP_ID_04") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_DEALS_I5" ON "EBA_SALES_DEALS" ("F';
wwv_flow_imp.g_varchar2_table(28) := 'INANCIAL_ASSESSMENT_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_DEALS_I6" ON "EBA_SALES_DEALS" ("STATUS_ASSES';
wwv_flow_imp.g_varchar2_table(29) := 'SMENT_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_DEALS_I7" ON "EBA_SALES_DEALS" ("RISK_ASSESSMENT_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(30) := ''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_DEALS_I8" ON "EBA_SALES_DEALS" ("ACCOUNT_STANDING_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "';
wwv_flow_imp.g_varchar2_table(31) := 'EBA_SALES_DEALS_I9" ON "EBA_SALES_DEALS" ("VP_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_DEAL_COMPETITION_I1';
wwv_flow_imp.g_varchar2_table(32) := '" ON "EBA_SALES_DEAL_COMPETITION" ("COMPETITOR_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_DEAL_COMPETITION_I';
wwv_flow_imp.g_varchar2_table(33) := '2" ON "EBA_SALES_DEAL_COMPETITION" ("DEAL_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_DEAL_COMPETITION_I3" ON';
wwv_flow_imp.g_varchar2_table(34) := ' "EBA_SALES_DEAL_COMPETITION" ("COMPETITOR_THREAT_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_DEAL_PROD_I1" O';
wwv_flow_imp.g_varchar2_table(35) := 'N "EBA_SALES_DEAL_PRODUCTS" ("DEAL_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_DEAL_PROD_I2" ON "EBA_SALES_DE';
wwv_flow_imp.g_varchar2_table(36) := 'AL_PRODUCTS" ("PRODUCT_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE UNIQUE INDEX "EBA_SALES_DEAL_STATCOD_I1" ON "EBA_SALES_DEAL';
wwv_flow_imp.g_varchar2_table(37) := '_STATUS_CODES" ("STATUS_CODE") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_DEAL_TEAM_I1" ON "EBA_SALES_DEAL_TEAM" ';
wwv_flow_imp.g_varchar2_table(38) := '("DEAL_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_DEAL_TEAM_I2" ON "EBA_SALES_DEAL_TEAM" ("REP_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CR';
wwv_flow_imp.g_varchar2_table(39) := 'EATE INDEX "EBA_SALES_ERRORS_I1" ON "EBA_SALES_ERRORS" ("ERR_TIME") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE UNIQUE INDEX "EBA_S';
wwv_flow_imp.g_varchar2_table(40) := 'ALES_ERROR_LOOKUP_UK" ON "EBA_SALES_ERROR_LOOKUP" ("CONSTRAINT_NAME", "LANGUAGE_CODE") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE ';
wwv_flow_imp.g_varchar2_table(41) := 'INDEX "EBA_SALES_FILES_IDX1" ON "EBA_SALES_FILES" ("DEAL_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_FILES_ID';
wwv_flow_imp.g_varchar2_table(42) := 'X2" ON "EBA_SALES_FILES" ("LEAD_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_FILES_IDX3" ON "EBA_SALES_FILES" ';
wwv_flow_imp.g_varchar2_table(43) := '("TERRITORY_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_FILES_IDX4" ON "EBA_SALES_FILES" ("ACCOUNT_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(44) := ''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_FILES_IDX5" ON "EBA_SALES_FILES" ("CONTACT_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SAL';
wwv_flow_imp.g_varchar2_table(45) := 'ES_FILES_IDX6" ON "EBA_SALES_FILES" ("PRODUCT_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_HISTORY_I1" ON "EBA';
wwv_flow_imp.g_varchar2_table(46) := '_SALES_HISTORY" ("DEAL_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_LEADS_I1" ON "EBA_SALES_LEADS" ("ACCOUNT_I';
wwv_flow_imp.g_varchar2_table(47) := 'D") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_LEADS_I2" ON "EBA_SALES_LEADS" ("LEAD_SOURCE_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE IND';
wwv_flow_imp.g_varchar2_table(48) := 'EX "EBA_SALES_LEADS_I3" ON "EBA_SALES_LEADS" ("LEAD_STATUS_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE UNIQUE INDEX "EBA_SALES';
wwv_flow_imp.g_varchar2_table(49) := '_LEAD_STAT_CDI1" ON "EBA_SALES_LEAD_STATUS_CODES" ("STATUS_CODE") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_LINK';
wwv_flow_imp.g_varchar2_table(50) := 'S_IDX1" ON "EBA_SALES_LINKS" ("DEAL_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_LINKS_IDX2" ON "EBA_SALES_LIN';
wwv_flow_imp.g_varchar2_table(51) := 'KS" ("LEAD_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_LINKS_IDX3" ON "EBA_SALES_LINKS" ("TERRITORY_ID") '||wwv_flow.LF||
'  ;';
wwv_flow_imp.g_varchar2_table(52) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_LINKS_IDX4" ON "EBA_SALES_LINKS" ("ACCOUNT_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SA';
wwv_flow_imp.g_varchar2_table(53) := 'LES_LINKS_IDX5" ON "EBA_SALES_LINKS" ("CONTACT_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_LINKS_IDX6" ON "EB';
wwv_flow_imp.g_varchar2_table(54) := 'A_SALES_LINKS" ("PRODUCT_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE UNIQUE INDEX "EBA_SALES_PREFERENCES_UK" ON "EBA_SALES_PRE';
wwv_flow_imp.g_varchar2_table(55) := 'FERENCES" ("PREFERENCE_NAME") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE UNIQUE INDEX "EBA_SALES_PRODUCTS_I1" ON "EBA_SALES_PRODUC';
wwv_flow_imp.g_varchar2_table(56) := 'TS" ("PRODUCT_NAME") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_PRODUCTS_I2" ON "EBA_SALES_PRODUCTS" ("PRODUCT_SK';
wwv_flow_imp.g_varchar2_table(57) := 'U") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_PRODUCTS_I3" ON "EBA_SALES_PRODUCTS" ("ROW_KEY") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDE';
wwv_flow_imp.g_varchar2_table(58) := 'X "EBA_SALES_SALESREPS_I1" ON "EBA_SALES_SALESREPS" ("REP_EMAIL") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_SALE';
wwv_flow_imp.g_varchar2_table(59) := 'SREPS_I2" ON "EBA_SALES_SALESREPS" ("REP_MANAGER_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_SALESREPS_I3" ON';
wwv_flow_imp.g_varchar2_table(60) := ' "EBA_SALES_SALESREPS" ("REP_EBA_SALES_USERNAME") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_SALESREPS_I4" ON "EB';
wwv_flow_imp.g_varchar2_table(61) := 'A_SALES_SALESREPS" ("SVP_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE UNIQUE INDEX "EBA_SALES_SALESREP_ROLENAME" ON "EBA_SALES_';
wwv_flow_imp.g_varchar2_table(62) := 'SALESREP_ROLES" ("ROLE_NAME") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_SALES_PER_I1" ON "EBA_SALES_SALES_PERIOD';
wwv_flow_imp.g_varchar2_table(63) := 'S" ("PERIOD_NAME") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_STATES_I1" ON "EBA_SALES_STATES" ("STATE") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CR';
wwv_flow_imp.g_varchar2_table(64) := 'EATE INDEX "EBA_SALES_STATES_I2" ON "EBA_SALES_STATES" ("CODE") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE UNIQUE INDEX "EBA_SALES';
wwv_flow_imp.g_varchar2_table(65) := '_SVPS_I1" ON "EBA_SALES_SVPS" ("SVP_NAME") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_TERRITORY_ACL_N1" ON "EBA_S';
wwv_flow_imp.g_varchar2_table(66) := 'ALES_TERRITORY_ACL" ("TERRITORY_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_TERR_MAP_I1" ON "EBA_SALES_TERR_M';
wwv_flow_imp.g_varchar2_table(67) := 'AP" ("TERRITORY_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_TERR_MAP_I3" ON "EBA_SALES_TERR_MAP" ("STATE_ID")';
wwv_flow_imp.g_varchar2_table(68) := ' '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_TERR_MAP_I4" ON "EBA_SALES_TERR_MAP" ("COUNTRY_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDE';
wwv_flow_imp.g_varchar2_table(69) := 'X "EBA_SALES_USERS_ACC_LVL_IDX" ON "EBA_SALES_USERS" ("ACCESS_LEVEL_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE UNIQUE INDEX "';
wwv_flow_imp.g_varchar2_table(70) := 'EBA_SALES_USERS_UK" ON "EBA_SALES_USERS" ("USERNAME") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_VERIFY_IDX1" ON ';
wwv_flow_imp.g_varchar2_table(71) := '"EBA_SALES_VERIFICATIONS" ("CUST_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_VERIFY_IDX2" ON "EBA_SALES_VERIF';
wwv_flow_imp.g_varchar2_table(72) := 'ICATIONS" ("LEAD_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_VERIFY_IDX3" ON "EBA_SALES_VERIFICATIONS" ("OPP_';
wwv_flow_imp.g_varchar2_table(73) := 'ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX "EBA_SALES_VERIFY_IDX4" ON "EBA_SALES_VERIFICATIONS" ("TERRITORY_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(74) := 'CREATE INDEX "EBA_SALES_VERIFY_IDX5" ON "EBA_SALES_VERIFICATIONS" ("CONTACT_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX ';
wwv_flow_imp.g_varchar2_table(75) := '"EBA_SALES_VERIFY_IDX6" ON "EBA_SALES_VERIFICATIONS" ("PRODUCT_ID") '||wwv_flow.LF||
'  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6815243084227110889)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'indexes'
,p_sequence=>620
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815243342411110892)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_ACCESS_LEVELS_UK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815243803262110894)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_ACT_COMPETITION_1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815244007123110894)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_ACT_COMPETITION_2'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815244150742110894)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_ACT_COMPETITION_3'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815244382925110894)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CLICKS_IDX1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815244550372110894)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CLICKS_IDX2'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815244738475110895)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CLICKS_IDX3'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815244956547110895)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CLICKS_IDX4'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815245201046110895)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CLICKS_IDX5'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815245395431110895)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CLICKS_IDX6'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815245571813110895)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CLICKS_IDX7'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815246007744110896)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_COMMENTS_IDX1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815246133230110896)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_COMMENTS_IDX2'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815246410241110896)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_COMMENTS_IDX3'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815246594469110896)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_COMMENTS_IDX4'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815246742641110896)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_COMMENTS_IDX5'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815246970268110896)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_COMMENTS_IDX6'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815247339199110897)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CUSTOMERS_I1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815247540816110897)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CUSTOMERS_I2'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815247738286110897)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CUSTOMERS_I3'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815247962729110897)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CUSTOMERS_I4'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815248160059110897)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CUSTOMERS_I5'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815248308975110898)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_CUSTOMER_LOC_I1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815248500789110898)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_CFK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815248643042110898)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815248914169110898)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I10'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815249097271110898)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I11'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815249254014110899)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I12'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815249521558110899)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I2'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815249627117110899)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I3'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815249846242110899)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I4'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815250111975110899)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I5'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815250317535110900)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I6'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815250486614110900)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I7'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815250652697110900)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I8'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815250913918110900)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEALS_I9'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815251078639110900)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEAL_COMPETITION_I1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815251321669110901)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEAL_COMPETITION_I2'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815251494560110901)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEAL_COMPETITION_I3'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815251851568110901)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEAL_PROD_I1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815252084796110901)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEAL_PROD_I2'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815252301648110901)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEAL_STATCOD_I1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815252461788110902)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEAL_TEAM_I1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815252672089110902)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_DEAL_TEAM_I2'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815252867477110902)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_ERRORS_I1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815253479942110902)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_ERROR_LOOKUP_UK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815253675825110903)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_FILES_IDX1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815253865605110903)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_FILES_IDX2'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815254074886110903)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_FILES_IDX3'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815254290880110903)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_FILES_IDX4'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815254483901110903)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_FILES_IDX5'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815254718529110903)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_FILES_IDX6'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815255118231110904)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_HISTORY_I1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815255432139110904)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_LEADS_I1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815255663062110904)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_LEADS_I2'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815255840467110904)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_LEADS_I3'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815256069963110904)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_LEAD_STAT_CDI1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815256300292110905)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_LINKS_IDX1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815256433648110905)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_LINKS_IDX2'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815256681551110905)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_LINKS_IDX3'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815256887407110905)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_LINKS_IDX4'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815257074144110905)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_LINKS_IDX5'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815257286370110907)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_LINKS_IDX6'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815258037783110908)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_PREFERENCES_UK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815258259805110908)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_PRODUCTS_I1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815258446197110908)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_PRODUCTS_I2'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815258644203110908)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_PRODUCTS_I3'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815258846776110908)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_SALESREPS_I1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815259048333110909)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_SALESREPS_I2'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815259281451110909)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_SALESREPS_I3'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815259487922110909)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_SALESREPS_I4'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815259633777110909)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_SALESREP_ROLENAME'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815259869216110909)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_SALES_PER_I1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815260279827110910)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_STATES_I1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815260450209110910)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_STATES_I2'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815260844059110910)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_SVPS_I1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815261512612110911)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_TERRITORY_ACL_N1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815261720497110911)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_TERR_MAP_I1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815261866695110911)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_TERR_MAP_I3'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815262113569110911)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_TERR_MAP_I4'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815262656495110912)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_USERS_ACC_LVL_IDX'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815263090997110912)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_USERS_UK'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815263320519110912)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_VERIFY_IDX1'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815263466381110912)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_VERIFY_IDX2'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815263686386110912)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_VERIFY_IDX3'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815263898462110913)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_VERIFY_IDX4'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815264070241110913)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_VERIFY_IDX5'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815264293834110913)
,p_script_id=>wwv_flow_imp.id(6815243084227110889)
,p_object_owner=>'#OWNER#'
,p_object_type=>'INDEX'
,p_object_name=>'EBA_SALES_VERIFY_IDX6'
);
wwv_flow_imp.component_end;
end;
/
