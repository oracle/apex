prompt --application/deployment/install/install_eba_sales_preferences
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_preferences
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814609050566198851)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_preferences'
,p_sequence=>55
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_PREFERENCES" ',
'   (	"ID" NUMBER NOT NULL ENABLE, ',
'	"PREFERENCE_NAME" VARCHAR2(255) NOT NULL ENABLE, ',
'	"PREFERENCE_VALUE" VARCHAR2(255) NOT NULL ENABLE, ',
'	"CREATED_BY" VARCHAR2(255) NOT NULL ENABLE, ',
'	"CREATED_ON" TIMESTAMP (6) WITH TIME ZONE, ',
'	"UPDATED_BY" VARCHAR2(255), ',
'	"UPDATED_ON" TIMESTAMP (6) WITH TIME ZONE, ',
'	 CONSTRAINT "EBA_SALES_PREFS_PREFNAME_CK" CHECK (upper(preference_name)=preference_name) ENABLE, ',
'	 CONSTRAINT "EBA_SALES_PREFERENCES_PK" PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814609137159198851)
,p_script_id=>wwv_flow_imp.id(6814609050566198851)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_PREFERENCES'
);
wwv_flow_imp.component_end;
end;
/
