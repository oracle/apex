prompt --application/deployment/install/upgrade_eba_sales_data_package_spec
begin
--   Manifest
--     INSTALL: UPGRADE-eba_sales_data package spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(7206099890842043689)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_data package spec'
,p_sequence=>200
,p_script_type=>'UPGRADE'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE OR REPLACE PACKAGE "EBA_SALES_DATA" as ',
'    procedure load_codes; ',
'    procedure load_sample; ',
'    procedure remove_sample; ',
'end;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
