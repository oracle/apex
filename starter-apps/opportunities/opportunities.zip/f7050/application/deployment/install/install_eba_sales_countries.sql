prompt --application/deployment/install/install_eba_sales_countries
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_countries
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6796791945601202843)
,p_install_id=>wwv_flow_imp.id(10495272006180774354)
,p_name=>'eba_sales_countries'
,p_sequence=>250
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_COUNTRIES" ',
'   (	"ID" NUMBER, ',
'	"ROW_VERSION_NUMBER" NUMBER, ',
'	"ROW_KEY" VARCHAR2(255), ',
'	"COUNTRY_CODE" VARCHAR2(30), ',
'	"COUNTRY_NAME" VARCHAR2(255), ',
'	"CREATED_BY" VARCHAR2(255), ',
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"UPDATED_BY" VARCHAR2(255), ',
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"INTERNAL_FLEX_FLAG_01" VARCHAR2(30), ',
'	"INTERNAL_FLEX_FLAG_02" VARCHAR2(30), ',
'	"INTERNAL_FLEX_FLAG_03" VARCHAR2(30), ',
'	"INTERNAL_FLEX_FLAG_04" VARCHAR2(30), ',
'	"INTERNAL_FLEX_01" VARCHAR2(4000), ',
'	"INTERNAL_FLEX_02" VARCHAR2(4000), ',
'	"INTERNAL_FLEX_03" VARCHAR2(4000), ',
'	"INTERNAL_FLEX_04" VARCHAR2(4000), ',
'	"FLEX_FLAG_01" VARCHAR2(30), ',
'	"FLEX_FLAG_02" VARCHAR2(30), ',
'	"FLEX_FLAG_03" VARCHAR2(30), ',
'	"FLEX_FLAG_04" VARCHAR2(30), ',
'	"FLEX_FLAG_05" VARCHAR2(30), ',
'	"FLEX_FLAG_06" VARCHAR2(30), ',
'	"FLEX_FLAG_07" VARCHAR2(30), ',
'	"FLEX_FLAG_08" VARCHAR2(30), ',
'	"FLEX_01" VARCHAR2(4000), ',
'	"FLEX_02" VARCHAR2(4000), ',
'	"FLEX_03" VARCHAR2(4000), ',
'	"FLEX_04" VARCHAR2(4000), ',
'	"FLEX_05" VARCHAR2(4000), ',
'	"FLEX_06" VARCHAR2(4000), ',
'	"FLEX_07" VARCHAR2(4000), ',
'	"FLEX_08" VARCHAR2(4000), ',
'	"FLEX_D01" TIMESTAMP (6) WITH TIME ZONE, ',
'	"FLEX_D02" TIMESTAMP (6) WITH TIME ZONE, ',
'	"FLEX_D03" TIMESTAMP (6) WITH TIME ZONE, ',
'	"FLEX_D04" TIMESTAMP (6) WITH TIME ZONE, ',
'	"FLEX_N01" NUMBER, ',
'	"FLEX_N02" NUMBER, ',
'	"FLEX_N03" NUMBER, ',
'	"FLEX_N04" NUMBER, ',
'	"FLEX_N05" NUMBER, ',
'	"FLEX_N06" NUMBER, ',
'	"FLEX_N07" NUMBER, ',
'	"FLEX_N08" NUMBER, ',
'	 PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6796792034925202843)
,p_script_id=>wwv_flow_imp.id(6796791945601202843)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_COUNTRIES'
,p_last_updated_on=>to_date('20160706132843','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706132843','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
