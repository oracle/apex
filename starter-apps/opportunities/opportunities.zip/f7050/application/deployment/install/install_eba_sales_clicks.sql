prompt --application/deployment/install/install_eba_sales_clicks
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_clicks
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_CLICKS" '||wwv_flow.LF||
'   (	"ID" NUMBER, '||wwv_flow.LF||
'	"CUST_ID" NUMBER, '||wwv_flow.LF||
'	"LEAD_ID" NUMBER, '||wwv_flow.LF||
'	"OPP_ID';
wwv_flow_imp.g_varchar2_table(2) := '" NUMBER, '||wwv_flow.LF||
'	"VIEW_TIMESTAMP" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"APP_SESSION" VARCHAR2(255), '||wwv_flow.LF||
'	"ENTITY_';
wwv_flow_imp.g_varchar2_table(3) := 'TYPE" VARCHAR2(20) NOT NULL ENABLE, '||wwv_flow.LF||
'	"TERRITORY_ID" NUMBER, '||wwv_flow.LF||
'	"CONTACT_ID" NUMBER, '||wwv_flow.LF||
'	"PRODUCT_ID" N';
wwv_flow_imp.g_varchar2_table(4) := 'UMBER, '||wwv_flow.LF||
'	"APP_USERNAME" VARCHAR2(255), '||wwv_flow.LF||
'	 PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "E';
wwv_flow_imp.g_varchar2_table(5) := 'BA_SALES_CLICKS_ENT_TYPE_CK" CHECK (entity_type in (''OPPORTUNITY'',''LEAD'',''TERRITORY'',''ACCOUNT'', ''CON';
wwv_flow_imp.g_varchar2_table(6) := 'TACT'', ''PRODUCT'')) ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SALES_CLICKS_ENT_FK_CK" CHECK ('||wwv_flow.LF||
'  entity_type = ''OPPOR';
wwv_flow_imp.g_varchar2_table(7) := 'TUNITY'' and opp_id is not null'||wwv_flow.LF||
'    or entity_type = ''LEAD'' and lead_id is not null'||wwv_flow.LF||
'    or entity_typ';
wwv_flow_imp.g_varchar2_table(8) := 'e = ''TERRITORY'' and territory_id is not null'||wwv_flow.LF||
'    or entity_type = ''ACCOUNT'' and cust_id is not null'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(9) := '    or entity_type = ''CONTACT'' and contact_id is not null'||wwv_flow.LF||
'    or entity_type = ''PRODUCT'' and product';
wwv_flow_imp.g_varchar2_table(10) := '_id is not null'||wwv_flow.LF||
') ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_CLICKS" ADD CONSTRAINT "EBA_SALES_CLICKS_CON';
wwv_flow_imp.g_varchar2_table(11) := 'TACT_FK" FOREIGN KEY ("CONTACT_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_CUSTOMER_CONTACTS" ("ID") ON DELETE CAS';
wwv_flow_imp.g_varchar2_table(12) := 'CADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_CLICKS" ADD CONSTRAINT "EBA_SALES_CLICKS_OPPS_FK" FOREIGN KEY (';
wwv_flow_imp.g_varchar2_table(13) := '"OPP_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_DEALS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_C';
wwv_flow_imp.g_varchar2_table(14) := 'LICKS" ADD CONSTRAINT "EBA_SALES_CLICKS_PRODUCT_FK" FOREIGN KEY ("PRODUCT_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SA';
wwv_flow_imp.g_varchar2_table(15) := 'LES_PRODUCTS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_CLICKS" ADD CONSTRAINT "EBA_S';
wwv_flow_imp.g_varchar2_table(16) := 'ALES_CLICKS_TERR_FK" FOREIGN KEY ("TERRITORY_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_TERRITORIES" ("ID") ON DE';
wwv_flow_imp.g_varchar2_table(17) := 'LETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_CLICKS" ADD FOREIGN KEY ("CUST_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_';
wwv_flow_imp.g_varchar2_table(18) := 'SALES_CUSTOMERS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_CLICKS" ADD FOREIGN KEY ("';
wwv_flow_imp.g_varchar2_table(19) := 'LEAD_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_LEADS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814503945072921344)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_clicks'
,p_sequence=>230
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814504059974921344)
,p_script_id=>wwv_flow_imp.id(6814503945072921344)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_CLICKS'
);
wwv_flow_imp.component_end;
end;
/
