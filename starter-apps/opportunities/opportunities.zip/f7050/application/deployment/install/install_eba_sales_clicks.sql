prompt --application/deployment/install/install_eba_sales_clicks
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_clicks
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814503945072921344)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_clicks'
,p_sequence=>230
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_CLICKS" ',
'   (	"ID" NUMBER, ',
'	"CUST_ID" NUMBER, ',
'	"LEAD_ID" NUMBER, ',
'	"OPP_ID" NUMBER, ',
'	"VIEW_TIMESTAMP" TIMESTAMP (6) WITH TIME ZONE, ',
'	"APP_SESSION" VARCHAR2(255), ',
'	"ENTITY_TYPE" VARCHAR2(20) NOT NULL ENABLE, ',
'	"TERRITORY_ID" NUMBER, ',
'	"CONTACT_ID" NUMBER, ',
'	"PRODUCT_ID" NUMBER, ',
'	"APP_USERNAME" VARCHAR2(255), ',
'	 PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE, ',
'	 CONSTRAINT "EBA_SALES_CLICKS_ENT_TYPE_CK" CHECK (entity_type in (''OPPORTUNITY'',''LEAD'',''TERRITORY'',''ACCOUNT'', ''CONTACT'', ''PRODUCT'')) ENABLE, ',
'	 CONSTRAINT "EBA_SALES_CLICKS_ENT_FK_CK" CHECK (',
'  entity_type = ''OPPORTUNITY'' and opp_id is not null',
'    or entity_type = ''LEAD'' and lead_id is not null',
'    or entity_type = ''TERRITORY'' and territory_id is not null',
'    or entity_type = ''ACCOUNT'' and cust_id is not null',
'    or entity_type = ''CONTACT'' and contact_id is not null',
'    or entity_type = ''PRODUCT'' and product_id is not null',
') ENABLE',
'   ) ;',
'',
'ALTER TABLE "EBA_SALES_CLICKS" ADD CONSTRAINT "EBA_SALES_CLICKS_CONTACT_FK" FOREIGN KEY ("CONTACT_ID")',
'	  REFERENCES "EBA_SALES_CUSTOMER_CONTACTS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_CLICKS" ADD CONSTRAINT "EBA_SALES_CLICKS_OPPS_FK" FOREIGN KEY ("OPP_ID")',
'	  REFERENCES "EBA_SALES_DEALS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_CLICKS" ADD CONSTRAINT "EBA_SALES_CLICKS_PRODUCT_FK" FOREIGN KEY ("PRODUCT_ID")',
'	  REFERENCES "EBA_SALES_PRODUCTS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_CLICKS" ADD CONSTRAINT "EBA_SALES_CLICKS_TERR_FK" FOREIGN KEY ("TERRITORY_ID")',
'	  REFERENCES "EBA_SALES_TERRITORIES" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_CLICKS" ADD FOREIGN KEY ("CUST_ID")',
'	  REFERENCES "EBA_SALES_CUSTOMERS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_CLICKS" ADD FOREIGN KEY ("LEAD_ID")',
'	  REFERENCES "EBA_SALES_LEADS" ("ID") ON DELETE CASCADE ENABLE;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814504059974921344)
,p_script_id=>wwv_flow_imp.id(6814503945072921344)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_CLICKS'
);
wwv_flow_imp.component_end;
end;
/
