prompt --application/deployment/install/install_eba_sales_products
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_products
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_PRODUCTS" '||wwv_flow.LF||
'   ("ID" NUMBER, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER, '||wwv_flow.LF||
'	"ROW_KEY" VARCH';
wwv_flow_imp.g_varchar2_table(2) := 'AR2(255), '||wwv_flow.LF||
'	"PRODUCT_NAME" VARCHAR2(255) NOT NULL ENABLE, '||wwv_flow.LF||
'	"PRODUCT_DESCRIPTION" VARCHAR2(4000) NOT';
wwv_flow_imp.g_varchar2_table(3) := ' NULL ENABLE,'||wwv_flow.LF||
'    "PRODUCT_FAMILY_ID" NUMBER,'||wwv_flow.LF||
'	"PRODUCT_SKU" VARCHAR2(255), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_01';
wwv_flow_imp.g_varchar2_table(4) := '" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_02" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_03" VARCHAR2(30), '||wwv_flow.LF||
'	"I';
wwv_flow_imp.g_varchar2_table(5) := 'NTERNAL_FLEX_FLAG_04" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_01" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_02" VARCHA';
wwv_flow_imp.g_varchar2_table(6) := 'R2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_03" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_04" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_FLAG_01"';
wwv_flow_imp.g_varchar2_table(7) := ' VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_02" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_03" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_04" VARCHA';
wwv_flow_imp.g_varchar2_table(8) := 'R2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_05" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_06" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_07" VARCHAR2(30),';
wwv_flow_imp.g_varchar2_table(9) := ' '||wwv_flow.LF||
'	"FLEX_FLAG_08" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_01" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_02" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_03" ';
wwv_flow_imp.g_varchar2_table(10) := 'VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_04" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_05" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_06" VARCHAR2(4000), ';
wwv_flow_imp.g_varchar2_table(11) := ''||wwv_flow.LF||
'	"FLEX_07" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_08" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_D01" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(12) := '	"FLEX_D02" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D03" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D04" TI';
wwv_flow_imp.g_varchar2_table(13) := 'MESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_N01" NUMBER, '||wwv_flow.LF||
'	"FLEX_N02" NUMBER, '||wwv_flow.LF||
'	"FLEX_N03" NUMBER, '||wwv_flow.LF||
'	"FLEX_N';
wwv_flow_imp.g_varchar2_table(14) := '04" NUMBER, '||wwv_flow.LF||
'	"FLEX_N05" NUMBER, '||wwv_flow.LF||
'	"FLEX_N06" NUMBER, '||wwv_flow.LF||
'	"FLEX_N07" NUMBER, '||wwv_flow.LF||
'	"FLEX_N08" NUMBER, '||wwv_flow.LF||
'	"C';
wwv_flow_imp.g_varchar2_table(15) := 'REATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"UPDATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(16) := '"UPDATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"TAGS" VARCHAR2(4000),'||wwv_flow.LF||
'    "SOLD_AS" VARCHAR2(50) CHECK (S';
wwv_flow_imp.g_varchar2_table(17) := 'OLD_AS in (''SUBSCRIPTION'',''PURCHASE'')),'||wwv_flow.LF||
'	 PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table e';
wwv_flow_imp.g_varchar2_table(18) := 'ba_sales_products add constraint eba_sales_products_families_fk foreign key (product_family_id)'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(19) := 'references eba_sales_product_families (id) on delete set null enable;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814610314514207494)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_products'
,p_sequence=>160
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814610399604207495)
,p_script_id=>wwv_flow_imp.id(6814610314514207494)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_PRODUCTS'
);
wwv_flow_imp.component_end;
end;
/
