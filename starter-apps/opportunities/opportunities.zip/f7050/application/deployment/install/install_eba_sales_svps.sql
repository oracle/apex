prompt --application/deployment/install/install_eba_sales_svps
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_svps
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6796900475920487079)
,p_install_id=>wwv_flow_imp.id(10495272006180774354)
,p_name=>'eba_sales_svps'
,p_sequence=>430
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_SVPS" ',
'   (	"ID" NUMBER, ',
'	"ROW_VERSION_NUMBER" NUMBER, ',
'	"SVP_NAME" VARCHAR2(255), ',
'	"SVP_ORG_DESCRIPTION" VARCHAR2(4000), ',
'	"CREATED_BY" VARCHAR2(255), ',
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"UPDATED_BY" VARCHAR2(255), ',
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	 PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6796900607278487079)
,p_script_id=>wwv_flow_imp.id(6796900475920487079)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_SVPS'
,p_last_updated_on=>to_date('20160706141606','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706141606','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
