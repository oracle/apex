prompt --application/deployment/install/upgrade_timestamp_fix_bugid_31352674
begin
--   Manifest
--     INSTALL: UPGRADE-TIMESTAMP Fix (BUGID: 31352674)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- This script fixes BUG 31352674, replacing all columns of type TIMESTAMP(6) WITH LOCAL TIME ZONE t';
wwv_flow_imp.g_varchar2_table(2) := 'o TIMESTAMP WITH TIME ZONE'||wwv_flow.LF||
'-- it also updates all application triggers where columns where updated w';
wwv_flow_imp.g_varchar2_table(3) := 'ith LOCALTIMESTAMP to CURRENT_TIMESTAMP'||wwv_flow.LF||
'-- '||wwv_flow.LF||
'-- This upgrade script will only run if there are tables';
wwv_flow_imp.g_varchar2_table(4) := ' that start with ''EBA_INTRACK%'' with columns of data type'||wwv_flow.LF||
'-- TIMESTAMP(6) WITH LOCAL TIME ZONE'||wwv_flow.LF||
''||wwv_flow.LF||
'-- S';
wwv_flow_imp.g_varchar2_table(5) := 'tart of Script'||wwv_flow.LF||
'-- 1. Disable All Triggers'||wwv_flow.LF||
'alter trigger "EBA_SALES_NOTE_BIU" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigge';
wwv_flow_imp.g_varchar2_table(6) := 'r "BIU_EBA_SALES_AGREEMENT_TYPES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_HISTORY" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter ';
wwv_flow_imp.g_varchar2_table(7) := 'trigger "BIU_EBA_SALES_DEAL_STAGES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_AGREEMENTS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'a';
wwv_flow_imp.g_varchar2_table(8) := 'lter trigger "EBA_SALES_PREFERENCES_BIU" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_PRODUCT_LOBS" DISAB';
wwv_flow_imp.g_varchar2_table(9) := 'LE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_DEALS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BD_EBA_SALES_DEALS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'a';
wwv_flow_imp.g_varchar2_table(10) := 'lter trigger "BIU_EBA_EBA_SALES_DEAL_COMPET" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_SALES_VERIFY_BIU_FER" DIS';
wwv_flow_imp.g_varchar2_table(11) := 'ABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_DEAL_PRODUCTS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_DEAL_STA';
wwv_flow_imp.g_varchar2_table(12) := 'T_CODES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_SALESREP_ROLES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_S';
wwv_flow_imp.g_varchar2_table(13) := 'ALES_SVPS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_CUST" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BD_EBA_SALES_CUST';
wwv_flow_imp.g_varchar2_table(14) := '" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_COMMENTS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_RISK_ASS';
wwv_flow_imp.g_varchar2_table(15) := 'ESSMENTS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_STATUS_ASSESS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_S';
wwv_flow_imp.g_varchar2_table(16) := 'ALES_COMPETITORS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BD_EBA_SALES_COMPETITORS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_';
wwv_flow_imp.g_varchar2_table(17) := 'EBA_SALES_TERRITORY_ACL" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_DEAL_TEAM" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger';
wwv_flow_imp.g_varchar2_table(18) := ' "EBA_SALES_USERS_BD" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_SALES_USERS_BIU" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_E';
wwv_flow_imp.g_varchar2_table(19) := 'BA_SALES_COUNTRIES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_INDUSTRIES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BI';
wwv_flow_imp.g_varchar2_table(20) := 'U_EBA_SALES_TERMS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BD_EBA_SALES_TERR" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SA';
wwv_flow_imp.g_varchar2_table(21) := 'LES_TERR" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_SUPPORT_AMTS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SA';
wwv_flow_imp.g_varchar2_table(22) := 'LES_CURRENCIES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_CUST_AGRMNT_MAP" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "B';
wwv_flow_imp.g_varchar2_table(23) := 'IU_EBA_SALES_SALES_PERIODS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_SALES_ERRORS_BI" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger ';
wwv_flow_imp.g_varchar2_table(24) := '"BIU_EBA_SALES_TAGS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BD_EBA_SALES_PRODUCTS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_';
wwv_flow_imp.g_varchar2_table(25) := 'EBA_SALES_PRODUCTS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_FILES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA';
wwv_flow_imp.g_varchar2_table(26) := '_SALES_CUSTOMERS_LOCS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_COMP_THREATS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigge';
wwv_flow_imp.g_varchar2_table(27) := 'r "BD_EBA_SALES_LEADS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_LEADS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "biu_';
wwv_flow_imp.g_varchar2_table(28) := 'eba_sales_product_families" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_TERR_MAP" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigg';
wwv_flow_imp.g_varchar2_table(29) := 'er "BIU_EBA_SALES_SALESREPS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_LEAD_SOURCES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter ';
wwv_flow_imp.g_varchar2_table(30) := 'trigger "BIU_EBA_SALES_FIN_ASSESSMENTS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_SALES_CLICKS_BIU" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'a';
wwv_flow_imp.g_varchar2_table(31) := 'lter trigger "BD_EBA_SALES_CUST_CONTACTS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_CUST_CONTACTS" DIS';
wwv_flow_imp.g_varchar2_table(32) := 'ABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_EBA_SALES_ACT_COMPET" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_SUPRT_A';
wwv_flow_imp.g_varchar2_table(33) := 'MT_TYPES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_TZ_PREF" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_C';
wwv_flow_imp.g_varchar2_table(34) := 'UST_SPT_AMT_MAP" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_ACCOUNT_STANDING" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger ';
wwv_flow_imp.g_varchar2_table(35) := '"BIU_EBA_SALES_LINKS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_STATES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- 2. Add temporar';
wwv_flow_imp.g_varchar2_table(36) := 'y timestamp columns'||wwv_flow.LF||
'alter table EBA_SALES_NOTIFICATIONS add (DISPLAY_FROM1 timestamp with time zone,';
wwv_flow_imp.g_varchar2_table(37) := 'DISPLAY_UNTIL1 timestamp with time zone,CREATED1 timestamp with time zone,UPDATED1 timestamp with ti';
wwv_flow_imp.g_varchar2_table(38) := 'me zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_AGREEMENT_TYPES add (CREATED1 timestamp with time zone,UPDATED1 tim';
wwv_flow_imp.g_varchar2_table(39) := 'estamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_HISTORY add (CHANGE_DATE1 timestamp with time zone)'||wwv_flow.LF||
'/';
wwv_flow_imp.g_varchar2_table(40) := ''||wwv_flow.LF||
'alter table EBA_SALES_DEAL_STAGES add (CREATED1 timestamp with time zone,UPDATED1 timestamp with ti';
wwv_flow_imp.g_varchar2_table(41) := 'me zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_AGREEMENTS add (CREATED1 timestamp with time zone,UPDATED1 timestam';
wwv_flow_imp.g_varchar2_table(42) := 'p with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_PREFERENCES add (CREATED_ON1 timestamp with time zone,UPDA';
wwv_flow_imp.g_varchar2_table(43) := 'TED_ON1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_PRODUCT_LOBS add (CREATED1 timestamp with ';
wwv_flow_imp.g_varchar2_table(44) := 'time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEALS add (DEAL_CLOSE_DATE1 tim';
wwv_flow_imp.g_varchar2_table(45) := 'estamp with time zone,DEAL_CLOSE_DATE_ALT1 timestamp with time zone,CREATED1 timestamp with time zon';
wwv_flow_imp.g_varchar2_table(46) := 'e,UPDATED1 timestamp with time zone,FLEX_D011 timestamp with time zone,FLEX_D021 timestamp with time';
wwv_flow_imp.g_varchar2_table(47) := ' zone,FLEX_D031 timestamp with time zone,FLEX_D041 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES';
wwv_flow_imp.g_varchar2_table(48) := '_DEAL_COMPETITION add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone,FLEX_D011';
wwv_flow_imp.g_varchar2_table(49) := ' timestamp with time zone,FLEX_D021 timestamp with time zone,FLEX_D031 timestamp with time zone,FLEX';
wwv_flow_imp.g_varchar2_table(50) := '_D041 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_VERIFICATIONS add (CREATED1 timestamp with t';
wwv_flow_imp.g_varchar2_table(51) := 'ime zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_PRODUCTS add (CREATED1 time';
wwv_flow_imp.g_varchar2_table(52) := 'stamp with time zone,UPDATED1 timestamp with time zone,FLEX_D011 timestamp with time zone,FLEX_D021 ';
wwv_flow_imp.g_varchar2_table(53) := 'timestamp with time zone,FLEX_D031 timestamp with time zone,FLEX_D041 timestamp with time zone,FLEX_';
wwv_flow_imp.g_varchar2_table(54) := 'D051 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_STATUS_CODES add (CREATED1 timestamp wit';
wwv_flow_imp.g_varchar2_table(55) := 'h time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_SALESREP_ROLES add (CREATED1 ';
wwv_flow_imp.g_varchar2_table(56) := 'timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_SVPS add (CREATE';
wwv_flow_imp.g_varchar2_table(57) := 'D1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUSTOMERS add';
wwv_flow_imp.g_varchar2_table(58) := ' (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone,FLEX_D011 timestamp with time ';
wwv_flow_imp.g_varchar2_table(59) := 'zone,FLEX_D021 timestamp with time zone,FLEX_D031 timestamp with time zone,FLEX_D041 timestamp with ';
wwv_flow_imp.g_varchar2_table(60) := 'time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_COMMENTS add (CREATED1 timestamp with time zone,UPDATED1 timestam';
wwv_flow_imp.g_varchar2_table(61) := 'p with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_RISK_ASSESSMENTS add (CREATED1 timestamp with time zone,UP';
wwv_flow_imp.g_varchar2_table(62) := 'DATED1 timestamp with time zone,FLEX_D011 timestamp with time zone,FLEX_D021 timestamp with time zon';
wwv_flow_imp.g_varchar2_table(63) := 'e,FLEX_D031 timestamp with time zone,FLEX_D041 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_STA';
wwv_flow_imp.g_varchar2_table(64) := 'TUS_ASSESSMENTS add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter ta';
wwv_flow_imp.g_varchar2_table(65) := 'ble EBA_SALES_COMPETITORS add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone,F';
wwv_flow_imp.g_varchar2_table(66) := 'LEX_D011 timestamp with time zone,FLEX_D021 timestamp with time zone,FLEX_D031 timestamp with time z';
wwv_flow_imp.g_varchar2_table(67) := 'one,FLEX_D041 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TERRITORY_ACL add (CREATED1 timestam';
wwv_flow_imp.g_varchar2_table(68) := 'p with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_TEAM add (CREATED1 ';
wwv_flow_imp.g_varchar2_table(69) := 'timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_USERS add (CREAT';
wwv_flow_imp.g_varchar2_table(70) := 'ED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_COUNTRIES ad';
wwv_flow_imp.g_varchar2_table(71) := 'd (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone,FLEX_D011 timestamp with time';
wwv_flow_imp.g_varchar2_table(72) := ' zone,FLEX_D021 timestamp with time zone,FLEX_D031 timestamp with time zone,FLEX_D041 timestamp with';
wwv_flow_imp.g_varchar2_table(73) := ' time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_INDUSTRIES add (CREATED1 timestamp with time zone,UPDATED1 times';
wwv_flow_imp.g_varchar2_table(74) := 'tamp with time zone,FLEX_D011 timestamp with time zone,FLEX_D021 timestamp with time zone,FLEX_D031 ';
wwv_flow_imp.g_varchar2_table(75) := 'timestamp with time zone,FLEX_D041 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TERMS add (CREA';
wwv_flow_imp.g_varchar2_table(76) := 'TED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TERRITORIES';
wwv_flow_imp.g_varchar2_table(77) := ' add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone,FLEX_D011 timestamp with t';
wwv_flow_imp.g_varchar2_table(78) := 'ime zone,FLEX_D021 timestamp with time zone,FLEX_D031 timestamp with time zone,FLEX_D041 timestamp w';
wwv_flow_imp.g_varchar2_table(79) := 'ith time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_SUPPORT_AMTS add (CREATED1 timestamp with time zone,UPDATED1 ';
wwv_flow_imp.g_varchar2_table(80) := 'timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CURRENCIES add (CREATED1 timestamp with time zone,';
wwv_flow_imp.g_varchar2_table(81) := 'UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUST_AGRMNT_MAP add (CLOSE_DATE1 timestam';
wwv_flow_imp.g_varchar2_table(82) := 'p with time zone,CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table ';
wwv_flow_imp.g_varchar2_table(83) := 'EBA_SALES_SALES_PERIODS add (FIRST_DAY1 timestamp with time zone,LAST_DAY1 timestamp with time zone)';
wwv_flow_imp.g_varchar2_table(84) := ''||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_ERRORS add (ERR_TIME1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TAG';
wwv_flow_imp.g_varchar2_table(85) := 'S add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_';
wwv_flow_imp.g_varchar2_table(86) := 'PRODUCTS add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone,FLEX_D011 timestam';
wwv_flow_imp.g_varchar2_table(87) := 'p with time zone,FLEX_D021 timestamp with time zone,FLEX_D031 timestamp with time zone,FLEX_D041 tim';
wwv_flow_imp.g_varchar2_table(88) := 'estamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_FILES add (CREATED1 timestamp with time zone,UPDATED1';
wwv_flow_imp.g_varchar2_table(89) := ' timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUSTOMER_LOCATIONS add (CREATED1 timestamp with t';
wwv_flow_imp.g_varchar2_table(90) := 'ime zone,UPDATED1 timestamp with time zone,FLEX_D011 timestamp with time zone,FLEX_D021 timestamp wi';
wwv_flow_imp.g_varchar2_table(91) := 'th time zone,FLEX_D031 timestamp with time zone,FLEX_D041 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EB';
wwv_flow_imp.g_varchar2_table(92) := 'A_SALES_COMPETITOR_THREATS add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)';
wwv_flow_imp.g_varchar2_table(93) := ''||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_LEADS add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time z';
wwv_flow_imp.g_varchar2_table(94) := 'one,FLEX_D011 timestamp with time zone,FLEX_D021 timestamp with time zone,FLEX_D031 timestamp with t';
wwv_flow_imp.g_varchar2_table(95) := 'ime zone,FLEX_D041 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_PRODUCT_FAMILIES add (CREATED1 ';
wwv_flow_imp.g_varchar2_table(96) := 'timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TERR_MAP add (CR';
wwv_flow_imp.g_varchar2_table(97) := 'EATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_SALESREPS';
wwv_flow_imp.g_varchar2_table(98) := ' add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone,FLEX_D011 timestamp with t';
wwv_flow_imp.g_varchar2_table(99) := 'ime zone,FLEX_D021 timestamp with time zone,FLEX_D031 timestamp with time zone,FLEX_D041 timestamp w';
wwv_flow_imp.g_varchar2_table(100) := 'ith time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_LEAD_SOURCES add (CREATED1 timestamp with time zone,UPDATED1 ';
wwv_flow_imp.g_varchar2_table(101) := 'timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_FIN_ASSESSMENTS add (CREATED1 timestamp with time ';
wwv_flow_imp.g_varchar2_table(102) := 'zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CLICKS add (VIEW_TIMESTAMP1 timestam';
wwv_flow_imp.g_varchar2_table(103) := 'p with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUSTOMER_CONTACTS add (CREATED1 timestamp with time zone,U';
wwv_flow_imp.g_varchar2_table(104) := 'PDATED1 timestamp with time zone,FLEX_D011 timestamp with time zone,FLEX_D021 timestamp with time zo';
wwv_flow_imp.g_varchar2_table(105) := 'ne,FLEX_D031 timestamp with time zone,FLEX_D041 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_AC';
wwv_flow_imp.g_varchar2_table(106) := 'T_COMPETITION add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter tabl';
wwv_flow_imp.g_varchar2_table(107) := 'e EBA_SALES_SUPRT_AMT_TYPES add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone';
wwv_flow_imp.g_varchar2_table(108) := ')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TZ_PREF add (CREATED1 timestamp with time zone,UPDATED1 timestamp with tim';
wwv_flow_imp.g_varchar2_table(109) := 'e zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUST_SPT_AMT_MAP add (CLOSE_DATE1 timestamp with time zone,CREATED1 ';
wwv_flow_imp.g_varchar2_table(110) := 'timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_ACCOUNT_STANDING';
wwv_flow_imp.g_varchar2_table(111) := ' add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_L';
wwv_flow_imp.g_varchar2_table(112) := 'INKS add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SAL';
wwv_flow_imp.g_varchar2_table(113) := 'ES_STATES add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone,FLEX_D011 timesta';
wwv_flow_imp.g_varchar2_table(114) := 'mp with time zone,FLEX_D021 timestamp with time zone,FLEX_D031 timestamp with time zone,FLEX_D041 ti';
wwv_flow_imp.g_varchar2_table(115) := 'mestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- 3. Copy original column values into temporary column values'||wwv_flow.LF||
'update EBA';
wwv_flow_imp.g_varchar2_table(116) := '_SALES_NOTIFICATIONS set DISPLAY_FROM1 = DISPLAY_FROM,DISPLAY_UNTIL1 = DISPLAY_UNTIL,CREATED1 = CREA';
wwv_flow_imp.g_varchar2_table(117) := 'TED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_AGREEMENT_TYPES set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(118) := 'update EBA_SALES_HISTORY set CHANGE_DATE1 = CHANGE_DATE;'||wwv_flow.LF||
'update EBA_SALES_DEAL_STAGES set CREATED1 =';
wwv_flow_imp.g_varchar2_table(119) := ' CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_AGREEMENTS set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(120) := 'update EBA_SALES_PREFERENCES set CREATED_ON1 = CREATED_ON,UPDATED_ON1 = UPDATED_ON;'||wwv_flow.LF||
'update EBA_SALES';
wwv_flow_imp.g_varchar2_table(121) := '_PRODUCT_LOBS set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_DEALS set DEAL_CLOSE_DATE1';
wwv_flow_imp.g_varchar2_table(122) := ' = DEAL_CLOSE_DATE,DEAL_CLOSE_DATE_ALT1 = DEAL_CLOSE_DATE_ALT,CREATED1 = CREATED,UPDATED1 = UPDATED,';
wwv_flow_imp.g_varchar2_table(123) := 'FLEX_D011 = FLEX_D01,FLEX_D021 = FLEX_D02,FLEX_D031 = FLEX_D03,FLEX_D041 = FLEX_D04;'||wwv_flow.LF||
'update EBA_SALE';
wwv_flow_imp.g_varchar2_table(124) := 'S_DEAL_COMPETITION set CREATED1 = CREATED,UPDATED1 = UPDATED,FLEX_D011 = FLEX_D01,FLEX_D021 = FLEX_D';
wwv_flow_imp.g_varchar2_table(125) := '02,FLEX_D031 = FLEX_D03,FLEX_D041 = FLEX_D04;'||wwv_flow.LF||
'update EBA_SALES_VERIFICATIONS set CREATED1 = CREATED,';
wwv_flow_imp.g_varchar2_table(126) := 'UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_DEAL_PRODUCTS set CREATED1 = CREATED,UPDATED1 = UPDATED,FLEX_D0';
wwv_flow_imp.g_varchar2_table(127) := '11 = FLEX_D01,FLEX_D021 = FLEX_D02,FLEX_D031 = FLEX_D03,FLEX_D041 = FLEX_D04,FLEX_D051 = FLEX_D05;'||wwv_flow.LF||
'u';
wwv_flow_imp.g_varchar2_table(128) := 'pdate EBA_SALES_DEAL_STATUS_CODES set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_SALESR';
wwv_flow_imp.g_varchar2_table(129) := 'EP_ROLES set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_SVPS set CREATED1 = CREATED,UPD';
wwv_flow_imp.g_varchar2_table(130) := 'ATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_CUSTOMERS set CREATED1 = CREATED,UPDATED1 = UPDATED,FLEX_D011 = FL';
wwv_flow_imp.g_varchar2_table(131) := 'EX_D01,FLEX_D021 = FLEX_D02,FLEX_D031 = FLEX_D03,FLEX_D041 = FLEX_D04;'||wwv_flow.LF||
'update EBA_SALES_COMMENTS set';
wwv_flow_imp.g_varchar2_table(132) := ' CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_RISK_ASSESSMENTS set CREATED1 = CREATED,UPD';
wwv_flow_imp.g_varchar2_table(133) := 'ATED1 = UPDATED,FLEX_D011 = FLEX_D01,FLEX_D021 = FLEX_D02,FLEX_D031 = FLEX_D03,FLEX_D041 = FLEX_D04;';
wwv_flow_imp.g_varchar2_table(134) := ''||wwv_flow.LF||
'update EBA_SALES_STATUS_ASSESSMENTS set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_COM';
wwv_flow_imp.g_varchar2_table(135) := 'PETITORS set CREATED1 = CREATED,UPDATED1 = UPDATED,FLEX_D011 = FLEX_D01,FLEX_D021 = FLEX_D02,FLEX_D0';
wwv_flow_imp.g_varchar2_table(136) := '31 = FLEX_D03,FLEX_D041 = FLEX_D04;'||wwv_flow.LF||
'update EBA_SALES_TERRITORY_ACL set CREATED1 = CREATED,UPDATED1 =';
wwv_flow_imp.g_varchar2_table(137) := ' UPDATED;'||wwv_flow.LF||
'update EBA_SALES_DEAL_TEAM set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_USE';
wwv_flow_imp.g_varchar2_table(138) := 'RS set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_COUNTRIES set CREATED1 = CREATED,UPDA';
wwv_flow_imp.g_varchar2_table(139) := 'TED1 = UPDATED,FLEX_D011 = FLEX_D01,FLEX_D021 = FLEX_D02,FLEX_D031 = FLEX_D03,FLEX_D041 = FLEX_D04;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(140) := 'update EBA_SALES_INDUSTRIES set CREATED1 = CREATED,UPDATED1 = UPDATED,FLEX_D011 = FLEX_D01,FLEX_D021';
wwv_flow_imp.g_varchar2_table(141) := ' = FLEX_D02,FLEX_D031 = FLEX_D03,FLEX_D041 = FLEX_D04;'||wwv_flow.LF||
'update EBA_SALES_TERMS set CREATED1 = CREATED';
wwv_flow_imp.g_varchar2_table(142) := ',UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_TERRITORIES set CREATED1 = CREATED,UPDATED1 = UPDATED,FLEX_D01';
wwv_flow_imp.g_varchar2_table(143) := '1 = FLEX_D01,FLEX_D021 = FLEX_D02,FLEX_D031 = FLEX_D03,FLEX_D041 = FLEX_D04;'||wwv_flow.LF||
'update EBA_SALES_SUPPOR';
wwv_flow_imp.g_varchar2_table(144) := 'T_AMTS set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_CURRENCIES set CREATED1 = CREATED';
wwv_flow_imp.g_varchar2_table(145) := ',UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_CUST_AGRMNT_MAP set CLOSE_DATE1 = CLOSE_DATE,CREATED1 = CREATE';
wwv_flow_imp.g_varchar2_table(146) := 'D,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_SALES_PERIODS set FIRST_DAY1 = FIRST_DAY,LAST_DAY1 = LAST_DAY';
wwv_flow_imp.g_varchar2_table(147) := ';'||wwv_flow.LF||
'update EBA_SALES_ERRORS set ERR_TIME1 = ERR_TIME;'||wwv_flow.LF||
'update EBA_SALES_TAGS set CREATED1 = CREATED,UPD';
wwv_flow_imp.g_varchar2_table(148) := 'ATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_PRODUCTS set CREATED1 = CREATED,UPDATED1 = UPDATED,FLEX_D011 = FLE';
wwv_flow_imp.g_varchar2_table(149) := 'X_D01,FLEX_D021 = FLEX_D02,FLEX_D031 = FLEX_D03,FLEX_D041 = FLEX_D04;'||wwv_flow.LF||
'update EBA_SALES_FILES set CRE';
wwv_flow_imp.g_varchar2_table(150) := 'ATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_CUSTOMER_LOCATIONS set CREATED1 = CREATED,UPDAT';
wwv_flow_imp.g_varchar2_table(151) := 'ED1 = UPDATED,FLEX_D011 = FLEX_D01,FLEX_D021 = FLEX_D02,FLEX_D031 = FLEX_D03,FLEX_D041 = FLEX_D04;'||wwv_flow.LF||
'u';
wwv_flow_imp.g_varchar2_table(152) := 'pdate EBA_SALES_COMPETITOR_THREATS set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_LEADS';
wwv_flow_imp.g_varchar2_table(153) := ' set CREATED1 = CREATED,UPDATED1 = UPDATED,FLEX_D011 = FLEX_D01,FLEX_D021 = FLEX_D02,FLEX_D031 = FLE';
wwv_flow_imp.g_varchar2_table(154) := 'X_D03,FLEX_D041 = FLEX_D04;'||wwv_flow.LF||
'update EBA_SALES_PRODUCT_FAMILIES set CREATED1 = CREATED,UPDATED1 = UPDA';
wwv_flow_imp.g_varchar2_table(155) := 'TED;'||wwv_flow.LF||
'update EBA_SALES_TERR_MAP set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_SALESREPS';
wwv_flow_imp.g_varchar2_table(156) := ' set CREATED1 = CREATED,UPDATED1 = UPDATED,FLEX_D011 = FLEX_D01,FLEX_D021 = FLEX_D02,FLEX_D031 = FLE';
wwv_flow_imp.g_varchar2_table(157) := 'X_D03,FLEX_D041 = FLEX_D04;'||wwv_flow.LF||
'update EBA_SALES_LEAD_SOURCES set CREATED1 = CREATED,UPDATED1 = UPDATED;';
wwv_flow_imp.g_varchar2_table(158) := ''||wwv_flow.LF||
'update EBA_SALES_FIN_ASSESSMENTS set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_CLICKS';
wwv_flow_imp.g_varchar2_table(159) := ' set VIEW_TIMESTAMP1 = VIEW_TIMESTAMP;'||wwv_flow.LF||
'update EBA_SALES_CUSTOMER_CONTACTS set CREATED1 = CREATED,UPD';
wwv_flow_imp.g_varchar2_table(160) := 'ATED1 = UPDATED,FLEX_D011 = FLEX_D01,FLEX_D021 = FLEX_D02,FLEX_D031 = FLEX_D03,FLEX_D041 = FLEX_D04;';
wwv_flow_imp.g_varchar2_table(161) := ''||wwv_flow.LF||
'update EBA_SALES_ACT_COMPETITION set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_SUPRT_';
wwv_flow_imp.g_varchar2_table(162) := 'AMT_TYPES set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_TZ_PREF set CREATED1 = CREATED';
wwv_flow_imp.g_varchar2_table(163) := ',UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_CUST_SPT_AMT_MAP set CLOSE_DATE1 = CLOSE_DATE,CREATED1 = CREAT';
wwv_flow_imp.g_varchar2_table(164) := 'ED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_ACCOUNT_STANDING set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(165) := 'update EBA_SALES_LINKS set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_SALES_STATES set CREATE';
wwv_flow_imp.g_varchar2_table(166) := 'D1 = CREATED,UPDATED1 = UPDATED,FLEX_D011 = FLEX_D01,FLEX_D021 = FLEX_D02,FLEX_D031 = FLEX_D03,FLEX_';
wwv_flow_imp.g_varchar2_table(167) := 'D041 = FLEX_D04;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- 4. Drop original timestamp with local time zone columns'||wwv_flow.LF||
'alter table EBA_SALES_N';
wwv_flow_imp.g_varchar2_table(168) := 'OTIFICATIONS drop (DISPLAY_FROM,DISPLAY_UNTIL,CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_AGREEMENT_TYP';
wwv_flow_imp.g_varchar2_table(169) := 'ES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_HISTORY drop (CHANGE_DATE)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES';
wwv_flow_imp.g_varchar2_table(170) := '_DEAL_STAGES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_AGREEMENTS drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alte';
wwv_flow_imp.g_varchar2_table(171) := 'r table EBA_SALES_PREFERENCES drop (CREATED_ON,UPDATED_ON)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_PRODUCT_LOBS drop';
wwv_flow_imp.g_varchar2_table(172) := ' (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEALS drop (DEAL_CLOSE_DATE,DEAL_CLOSE_DATE_ALT,CREATED,U';
wwv_flow_imp.g_varchar2_table(173) := 'PDATED,FLEX_D01,FLEX_D02,FLEX_D03,FLEX_D04)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_COMPETITION drop (CREATED,U';
wwv_flow_imp.g_varchar2_table(174) := 'PDATED,FLEX_D01,FLEX_D02,FLEX_D03,FLEX_D04)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_VERIFICATIONS drop (CREATED,UPDA';
wwv_flow_imp.g_varchar2_table(175) := 'TED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_PRODUCTS drop (CREATED,UPDATED,FLEX_D01,FLEX_D02,FLEX_D03,FLEX_D04';
wwv_flow_imp.g_varchar2_table(176) := ',FLEX_D05)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_STATUS_CODES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_';
wwv_flow_imp.g_varchar2_table(177) := 'SALESREP_ROLES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_SVPS drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter ta';
wwv_flow_imp.g_varchar2_table(178) := 'ble EBA_SALES_CUSTOMERS drop (CREATED,UPDATED,FLEX_D01,FLEX_D02,FLEX_D03,FLEX_D04)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA';
wwv_flow_imp.g_varchar2_table(179) := '_SALES_COMMENTS drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_RISK_ASSESSMENTS drop (CREATED,UPDATE';
wwv_flow_imp.g_varchar2_table(180) := 'D,FLEX_D01,FLEX_D02,FLEX_D03,FLEX_D04)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_STATUS_ASSESSMENTS drop (CREATED,UPDA';
wwv_flow_imp.g_varchar2_table(181) := 'TED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_COMPETITORS drop (CREATED,UPDATED,FLEX_D01,FLEX_D02,FLEX_D03,FLEX_D04)'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(182) := '/'||wwv_flow.LF||
'alter table EBA_SALES_TERRITORY_ACL drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_TEAM drop ';
wwv_flow_imp.g_varchar2_table(183) := '(CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_USERS drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_COUNT';
wwv_flow_imp.g_varchar2_table(184) := 'RIES drop (CREATED,UPDATED,FLEX_D01,FLEX_D02,FLEX_D03,FLEX_D04)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_INDUSTRIES d';
wwv_flow_imp.g_varchar2_table(185) := 'rop (CREATED,UPDATED,FLEX_D01,FLEX_D02,FLEX_D03,FLEX_D04)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TERMS drop (CREATE';
wwv_flow_imp.g_varchar2_table(186) := 'D,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TERRITORIES drop (CREATED,UPDATED,FLEX_D01,FLEX_D02,FLEX_D03,FLEX';
wwv_flow_imp.g_varchar2_table(187) := '_D04)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_SUPPORT_AMTS drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CURRENCIES';
wwv_flow_imp.g_varchar2_table(188) := ' drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUST_AGRMNT_MAP drop (CLOSE_DATE,CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(189) := 'alter table EBA_SALES_SALES_PERIODS drop (FIRST_DAY,LAST_DAY)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_ERRORS drop (E';
wwv_flow_imp.g_varchar2_table(190) := 'RR_TIME)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TAGS drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_PRODUCTS drop (';
wwv_flow_imp.g_varchar2_table(191) := 'CREATED,UPDATED,FLEX_D01,FLEX_D02,FLEX_D03,FLEX_D04)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_FILES drop (CREATED,UPD';
wwv_flow_imp.g_varchar2_table(192) := 'ATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUSTOMER_LOCATIONS drop (CREATED,UPDATED,FLEX_D01,FLEX_D02,FLEX_D03,FL';
wwv_flow_imp.g_varchar2_table(193) := 'EX_D04)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_COMPETITOR_THREATS drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_LE';
wwv_flow_imp.g_varchar2_table(194) := 'ADS drop (CREATED,UPDATED,FLEX_D01,FLEX_D02,FLEX_D03,FLEX_D04)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_PRODUCT_FAMIL';
wwv_flow_imp.g_varchar2_table(195) := 'IES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TERR_MAP drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA';
wwv_flow_imp.g_varchar2_table(196) := '_SALES_SALESREPS drop (CREATED,UPDATED,FLEX_D01,FLEX_D02,FLEX_D03,FLEX_D04)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_';
wwv_flow_imp.g_varchar2_table(197) := 'LEAD_SOURCES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_FIN_ASSESSMENTS drop (CREATED,UPDATED)'||wwv_flow.LF||
'/';
wwv_flow_imp.g_varchar2_table(198) := ''||wwv_flow.LF||
'alter table EBA_SALES_CLICKS drop (VIEW_TIMESTAMP)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUSTOMER_CONTACTS drop (';
wwv_flow_imp.g_varchar2_table(199) := 'CREATED,UPDATED,FLEX_D01,FLEX_D02,FLEX_D03,FLEX_D04)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_ACT_COMPETITION drop (C';
wwv_flow_imp.g_varchar2_table(200) := 'REATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_SUPRT_AMT_TYPES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SAL';
wwv_flow_imp.g_varchar2_table(201) := 'ES_TZ_PREF drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUST_SPT_AMT_MAP drop (CLOSE_DATE,CREATED,';
wwv_flow_imp.g_varchar2_table(202) := 'UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_ACCOUNT_STANDING drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_LIN';
wwv_flow_imp.g_varchar2_table(203) := 'KS drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_STATES drop (CREATED,UPDATED,FLEX_D01,FLEX_D02,FLE';
wwv_flow_imp.g_varchar2_table(204) := 'X_D03,FLEX_D04)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- 5. Rename temporary columns back to original column names'||wwv_flow.LF||
'alter table EBA_SALE';
wwv_flow_imp.g_varchar2_table(205) := 'S_NOTIFICATIONS rename column DISPLAY_FROM1 to DISPLAY_FROM'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_NOTIFICATIONS re';
wwv_flow_imp.g_varchar2_table(206) := 'name column DISPLAY_UNTIL1 to DISPLAY_UNTIL'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_NOTIFICATIONS rename column CREA';
wwv_flow_imp.g_varchar2_table(207) := 'TED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_NOTIFICATIONS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter tabl';
wwv_flow_imp.g_varchar2_table(208) := 'e EBA_SALES_AGREEMENT_TYPES rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_AGREEMENT_TYPE';
wwv_flow_imp.g_varchar2_table(209) := 'S rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_HISTORY rename column CHANGE_DATE1 to CH';
wwv_flow_imp.g_varchar2_table(210) := 'ANGE_DATE'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_STAGES rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SA';
wwv_flow_imp.g_varchar2_table(211) := 'LES_DEAL_STAGES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_AGREEMENTS rename column C';
wwv_flow_imp.g_varchar2_table(212) := 'REATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_AGREEMENTS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter tabl';
wwv_flow_imp.g_varchar2_table(213) := 'e EBA_SALES_PREFERENCES rename column CREATED_ON1 to CREATED_ON'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_PREFERENCES ';
wwv_flow_imp.g_varchar2_table(214) := 'rename column UPDATED_ON1 to UPDATED_ON'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_PRODUCT_LOBS rename column CREATED1 ';
wwv_flow_imp.g_varchar2_table(215) := 'to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_PRODUCT_LOBS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_';
wwv_flow_imp.g_varchar2_table(216) := 'SALES_DEALS rename column DEAL_CLOSE_DATE1 to DEAL_CLOSE_DATE'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEALS rename c';
wwv_flow_imp.g_varchar2_table(217) := 'olumn DEAL_CLOSE_DATE_ALT1 to DEAL_CLOSE_DATE_ALT'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEALS rename column CREATE';
wwv_flow_imp.g_varchar2_table(218) := 'D1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEALS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALE';
wwv_flow_imp.g_varchar2_table(219) := 'S_DEALS rename column FLEX_D011 to FLEX_D01'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEALS rename column FLEX_D021 to';
wwv_flow_imp.g_varchar2_table(220) := ' FLEX_D02'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEALS rename column FLEX_D031 to FLEX_D03'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_';
wwv_flow_imp.g_varchar2_table(221) := 'DEALS rename column FLEX_D041 to FLEX_D04'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_COMPETITION rename column CRE';
wwv_flow_imp.g_varchar2_table(222) := 'ATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_COMPETITION rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter ';
wwv_flow_imp.g_varchar2_table(223) := 'table EBA_SALES_DEAL_COMPETITION rename column FLEX_D011 to FLEX_D01'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_CO';
wwv_flow_imp.g_varchar2_table(224) := 'MPETITION rename column FLEX_D021 to FLEX_D02'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_COMPETITION rename column';
wwv_flow_imp.g_varchar2_table(225) := ' FLEX_D031 to FLEX_D03'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_COMPETITION rename column FLEX_D041 to FLEX_D04'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(226) := '/'||wwv_flow.LF||
'alter table EBA_SALES_VERIFICATIONS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_VERI';
wwv_flow_imp.g_varchar2_table(227) := 'FICATIONS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_PRODUCTS rename column CREA';
wwv_flow_imp.g_varchar2_table(228) := 'TED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_PRODUCTS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter tabl';
wwv_flow_imp.g_varchar2_table(229) := 'e EBA_SALES_DEAL_PRODUCTS rename column FLEX_D011 to FLEX_D01'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_PRODUCTS ';
wwv_flow_imp.g_varchar2_table(230) := 'rename column FLEX_D021 to FLEX_D02'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_PRODUCTS rename column FLEX_D031 to';
wwv_flow_imp.g_varchar2_table(231) := ' FLEX_D03'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_PRODUCTS rename column FLEX_D041 to FLEX_D04'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EB';
wwv_flow_imp.g_varchar2_table(232) := 'A_SALES_DEAL_PRODUCTS rename column FLEX_D051 to FLEX_D05'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_STATUS_CODES ';
wwv_flow_imp.g_varchar2_table(233) := 'rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_STATUS_CODES rename column UPDATED1 t';
wwv_flow_imp.g_varchar2_table(234) := 'o UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_SALESREP_ROLES rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA';
wwv_flow_imp.g_varchar2_table(235) := '_SALES_SALESREP_ROLES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_SVPS rename column C';
wwv_flow_imp.g_varchar2_table(236) := 'REATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_SVPS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_';
wwv_flow_imp.g_varchar2_table(237) := 'SALES_CUSTOMERS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUSTOMERS rename column UP';
wwv_flow_imp.g_varchar2_table(238) := 'DATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUSTOMERS rename column FLEX_D011 to FLEX_D01'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter tabl';
wwv_flow_imp.g_varchar2_table(239) := 'e EBA_SALES_CUSTOMERS rename column FLEX_D021 to FLEX_D02'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUSTOMERS rename c';
wwv_flow_imp.g_varchar2_table(240) := 'olumn FLEX_D031 to FLEX_D03'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUSTOMERS rename column FLEX_D041 to FLEX_D04'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(241) := 'alter table EBA_SALES_COMMENTS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_COMMENTS re';
wwv_flow_imp.g_varchar2_table(242) := 'name column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_RISK_ASSESSMENTS rename column CREATED1 to C';
wwv_flow_imp.g_varchar2_table(243) := 'REATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_RISK_ASSESSMENTS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_';
wwv_flow_imp.g_varchar2_table(244) := 'SALES_RISK_ASSESSMENTS rename column FLEX_D011 to FLEX_D01'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_RISK_ASSESSMENTS ';
wwv_flow_imp.g_varchar2_table(245) := 'rename column FLEX_D021 to FLEX_D02'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_RISK_ASSESSMENTS rename column FLEX_D031';
wwv_flow_imp.g_varchar2_table(246) := ' to FLEX_D03'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_RISK_ASSESSMENTS rename column FLEX_D041 to FLEX_D04'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter ta';
wwv_flow_imp.g_varchar2_table(247) := 'ble EBA_SALES_STATUS_ASSESSMENTS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_STATUS_AS';
wwv_flow_imp.g_varchar2_table(248) := 'SESSMENTS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_COMPETITORS rename column CREATE';
wwv_flow_imp.g_varchar2_table(249) := 'D1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_COMPETITORS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EB';
wwv_flow_imp.g_varchar2_table(250) := 'A_SALES_COMPETITORS rename column FLEX_D011 to FLEX_D01'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_COMPETITORS rename c';
wwv_flow_imp.g_varchar2_table(251) := 'olumn FLEX_D021 to FLEX_D02'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_COMPETITORS rename column FLEX_D031 to FLEX_D03'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(252) := '/'||wwv_flow.LF||
'alter table EBA_SALES_COMPETITORS rename column FLEX_D041 to FLEX_D04'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TERR';
wwv_flow_imp.g_varchar2_table(253) := 'ITORY_ACL rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TERRITORY_ACL rename column UPDA';
wwv_flow_imp.g_varchar2_table(254) := 'TED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_DEAL_TEAM rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EB';
wwv_flow_imp.g_varchar2_table(255) := 'A_SALES_DEAL_TEAM rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_USERS rename column CREA';
wwv_flow_imp.g_varchar2_table(256) := 'TED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_USERS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SA';
wwv_flow_imp.g_varchar2_table(257) := 'LES_COUNTRIES rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_COUNTRIES rename column UPDA';
wwv_flow_imp.g_varchar2_table(258) := 'TED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_COUNTRIES rename column FLEX_D011 to FLEX_D01'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table ';
wwv_flow_imp.g_varchar2_table(259) := 'EBA_SALES_COUNTRIES rename column FLEX_D021 to FLEX_D02'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_COUNTRIES rename col';
wwv_flow_imp.g_varchar2_table(260) := 'umn FLEX_D031 to FLEX_D03'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_COUNTRIES rename column FLEX_D041 to FLEX_D04'||wwv_flow.LF||
'/'||wwv_flow.LF||
'al';
wwv_flow_imp.g_varchar2_table(261) := 'ter table EBA_SALES_INDUSTRIES rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_INDUSTRIES ';
wwv_flow_imp.g_varchar2_table(262) := 'rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_INDUSTRIES rename column FLEX_D011 to FLEX';
wwv_flow_imp.g_varchar2_table(263) := '_D01'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_INDUSTRIES rename column FLEX_D021 to FLEX_D02'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_';
wwv_flow_imp.g_varchar2_table(264) := 'INDUSTRIES rename column FLEX_D031 to FLEX_D03'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_INDUSTRIES rename column FLEX';
wwv_flow_imp.g_varchar2_table(265) := '_D041 to FLEX_D04'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TERMS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_';
wwv_flow_imp.g_varchar2_table(266) := 'SALES_TERMS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TERRITORIES rename column CREA';
wwv_flow_imp.g_varchar2_table(267) := 'TED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TERRITORIES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table ';
wwv_flow_imp.g_varchar2_table(268) := 'EBA_SALES_TERRITORIES rename column FLEX_D011 to FLEX_D01'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TERRITORIES rename';
wwv_flow_imp.g_varchar2_table(269) := ' column FLEX_D021 to FLEX_D02'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TERRITORIES rename column FLEX_D031 to FLEX_D0';
wwv_flow_imp.g_varchar2_table(270) := '3'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TERRITORIES rename column FLEX_D041 to FLEX_D04'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_SU';
wwv_flow_imp.g_varchar2_table(271) := 'PPORT_AMTS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_SUPPORT_AMTS rename column UPDA';
wwv_flow_imp.g_varchar2_table(272) := 'TED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CURRENCIES rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table E';
wwv_flow_imp.g_varchar2_table(273) := 'BA_SALES_CURRENCIES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUST_AGRMNT_MAP rename';
wwv_flow_imp.g_varchar2_table(274) := ' column CLOSE_DATE1 to CLOSE_DATE'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUST_AGRMNT_MAP rename column CREATED1 to ';
wwv_flow_imp.g_varchar2_table(275) := 'CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUST_AGRMNT_MAP rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_';
wwv_flow_imp.g_varchar2_table(276) := 'SALES_SALES_PERIODS rename column FIRST_DAY1 to FIRST_DAY'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_SALES_PERIODS rena';
wwv_flow_imp.g_varchar2_table(277) := 'me column LAST_DAY1 to LAST_DAY'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_ERRORS rename column ERR_TIME1 to ERR_TIME'||wwv_flow.LF||
'/';
wwv_flow_imp.g_varchar2_table(278) := ''||wwv_flow.LF||
'alter table EBA_SALES_TAGS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TAGS rename co';
wwv_flow_imp.g_varchar2_table(279) := 'lumn UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_PRODUCTS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter ';
wwv_flow_imp.g_varchar2_table(280) := 'table EBA_SALES_PRODUCTS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_PRODUCTS rename c';
wwv_flow_imp.g_varchar2_table(281) := 'olumn FLEX_D011 to FLEX_D01'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_PRODUCTS rename column FLEX_D021 to FLEX_D02'||wwv_flow.LF||
'/'||wwv_flow.LF||
'a';
wwv_flow_imp.g_varchar2_table(282) := 'lter table EBA_SALES_PRODUCTS rename column FLEX_D031 to FLEX_D03'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_PRODUCTS r';
wwv_flow_imp.g_varchar2_table(283) := 'ename column FLEX_D041 to FLEX_D04'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_FILES rename column CREATED1 to CREATED'||wwv_flow.LF||
'/';
wwv_flow_imp.g_varchar2_table(284) := ''||wwv_flow.LF||
'alter table EBA_SALES_FILES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUSTOMER_LOCA';
wwv_flow_imp.g_varchar2_table(285) := 'TIONS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUSTOMER_LOCATIONS rename column UPD';
wwv_flow_imp.g_varchar2_table(286) := 'ATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUSTOMER_LOCATIONS rename column FLEX_D011 to FLEX_D01'||wwv_flow.LF||
'/'||wwv_flow.LF||
'al';
wwv_flow_imp.g_varchar2_table(287) := 'ter table EBA_SALES_CUSTOMER_LOCATIONS rename column FLEX_D021 to FLEX_D02'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_C';
wwv_flow_imp.g_varchar2_table(288) := 'USTOMER_LOCATIONS rename column FLEX_D031 to FLEX_D03'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUSTOMER_LOCATIONS ren';
wwv_flow_imp.g_varchar2_table(289) := 'ame column FLEX_D041 to FLEX_D04'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_COMPETITOR_THREATS rename column CREATED1 t';
wwv_flow_imp.g_varchar2_table(290) := 'o CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_COMPETITOR_THREATS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table';
wwv_flow_imp.g_varchar2_table(291) := ' EBA_SALES_LEADS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_LEADS rename column UPDAT';
wwv_flow_imp.g_varchar2_table(292) := 'ED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_LEADS rename column FLEX_D011 to FLEX_D01'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_S';
wwv_flow_imp.g_varchar2_table(293) := 'ALES_LEADS rename column FLEX_D021 to FLEX_D02'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_LEADS rename column FLEX_D031';
wwv_flow_imp.g_varchar2_table(294) := ' to FLEX_D03'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_LEADS rename column FLEX_D041 to FLEX_D04'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SAL';
wwv_flow_imp.g_varchar2_table(295) := 'ES_PRODUCT_FAMILIES rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_PRODUCT_FAMILIES renam';
wwv_flow_imp.g_varchar2_table(296) := 'e column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TERR_MAP rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'al';
wwv_flow_imp.g_varchar2_table(297) := 'ter table EBA_SALES_TERR_MAP rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_SALESREPS ren';
wwv_flow_imp.g_varchar2_table(298) := 'ame column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_SALESREPS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/';
wwv_flow_imp.g_varchar2_table(299) := ''||wwv_flow.LF||
'alter table EBA_SALES_SALESREPS rename column FLEX_D011 to FLEX_D01'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_SALESRE';
wwv_flow_imp.g_varchar2_table(300) := 'PS rename column FLEX_D021 to FLEX_D02'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_SALESREPS rename column FLEX_D031 to ';
wwv_flow_imp.g_varchar2_table(301) := 'FLEX_D03'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_SALESREPS rename column FLEX_D041 to FLEX_D04'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SAL';
wwv_flow_imp.g_varchar2_table(302) := 'ES_LEAD_SOURCES rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_LEAD_SOURCES rename column';
wwv_flow_imp.g_varchar2_table(303) := ' UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_FIN_ASSESSMENTS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alt';
wwv_flow_imp.g_varchar2_table(304) := 'er table EBA_SALES_FIN_ASSESSMENTS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CLICKS ';
wwv_flow_imp.g_varchar2_table(305) := 'rename column VIEW_TIMESTAMP1 to VIEW_TIMESTAMP'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUSTOMER_CONTACTS rename col';
wwv_flow_imp.g_varchar2_table(306) := 'umn CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUSTOMER_CONTACTS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(307) := '/'||wwv_flow.LF||
'alter table EBA_SALES_CUSTOMER_CONTACTS rename column FLEX_D011 to FLEX_D01'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALE';
wwv_flow_imp.g_varchar2_table(308) := 'S_CUSTOMER_CONTACTS rename column FLEX_D021 to FLEX_D02'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUSTOMER_CONTACTS re';
wwv_flow_imp.g_varchar2_table(309) := 'name column FLEX_D031 to FLEX_D03'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUSTOMER_CONTACTS rename column FLEX_D041 ';
wwv_flow_imp.g_varchar2_table(310) := 'to FLEX_D04'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_ACT_COMPETITION rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table ';
wwv_flow_imp.g_varchar2_table(311) := 'EBA_SALES_ACT_COMPETITION rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_SUPRT_AMT_TYPES ';
wwv_flow_imp.g_varchar2_table(312) := 'rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_SUPRT_AMT_TYPES rename column UPDATED1 to ';
wwv_flow_imp.g_varchar2_table(313) := 'UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TZ_PREF rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_TZ';
wwv_flow_imp.g_varchar2_table(314) := '_PREF rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUST_SPT_AMT_MAP rename column CLOSE';
wwv_flow_imp.g_varchar2_table(315) := '_DATE1 to CLOSE_DATE'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_CUST_SPT_AMT_MAP rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'al';
wwv_flow_imp.g_varchar2_table(316) := 'ter table EBA_SALES_CUST_SPT_AMT_MAP rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_ACCOU';
wwv_flow_imp.g_varchar2_table(317) := 'NT_STANDING rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_ACCOUNT_STANDING rename column';
wwv_flow_imp.g_varchar2_table(318) := ' UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_LINKS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table E';
wwv_flow_imp.g_varchar2_table(319) := 'BA_SALES_LINKS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_STATES rename column CREATE';
wwv_flow_imp.g_varchar2_table(320) := 'D1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_STATES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SAL';
wwv_flow_imp.g_varchar2_table(321) := 'ES_STATES rename column FLEX_D011 to FLEX_D01'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_STATES rename column FLEX_D021';
wwv_flow_imp.g_varchar2_table(322) := ' to FLEX_D02'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SALES_STATES rename column FLEX_D031 to FLEX_D03'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_SA';
wwv_flow_imp.g_varchar2_table(323) := 'LES_STATES rename column FLEX_D041 to FLEX_D04'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- 6. Re-create all triggers and enable them.'||wwv_flow.LF||
'crea';
wwv_flow_imp.g_varchar2_table(324) := 'te or replace TRIGGER "EBA_SALES_NOTE_BIU" '||wwv_flow.LF||
'    before insert or update on eba_sales_notifications'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(325) := '   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        select to_number(sys_guid(),';
wwv_flow_imp.g_varchar2_table(326) := '''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'          into :new.id'||wwv_flow.LF||
'          from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if i';
wwv_flow_imp.g_varchar2_table(327) := 'nserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created := current_ti';
wwv_flow_imp.g_varchar2_table(328) := 'mestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timesta';
wwv_flow_imp.g_varchar2_table(329) := 'mp;'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.row_version_';
wwv_flow_imp.g_varchar2_table(330) := 'number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(331) := '      :new.updated    := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.notification_type is null then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(332) := '      :new.notification_type := ''MANUAL'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SAL';
wwv_flow_imp.g_varchar2_table(333) := 'ES_AGREEMENT_TYPES" '||wwv_flow.LF||
'   before insert or update on EBA_SALES_AGREEMENT_TYPES'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(334) := '   if inserting then'||wwv_flow.LF||
'        if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXX';
wwv_flow_imp.g_varchar2_table(335) := 'XXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(336) := '     :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(337) := ':new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.';
wwv_flow_imp.g_varchar2_table(338) := 'row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;';
wwv_flow_imp.g_varchar2_table(339) := ''||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row';
wwv_flow_imp.g_varchar2_table(340) := '_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_HISTORY" '||wwv_flow.LF||
'    b';
wwv_flow_imp.g_varchar2_table(341) := 'efore insert or update on EBA_SALES_history'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new."ID" is null then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(342) := '     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end';
wwv_flow_imp.g_varchar2_table(343) := ' if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.change_date := current_timestamp;'||wwv_flow.LF||
'        :new.changed_by :=';
wwv_flow_imp.g_varchar2_table(344) := ' nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :n';
wwv_flow_imp.g_varchar2_table(345) := 'ew.row_version_number := :new.row_version_number + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER ';
wwv_flow_imp.g_varchar2_table(346) := '"BIU_EBA_SALES_DEAL_STAGES" '||wwv_flow.LF||
'    before insert or update on EBA_SALES_deal_stages'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'b';
wwv_flow_imp.g_varchar2_table(347) := 'egin'||wwv_flow.LF||
'    if :new."ID" is null then'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(348) := 'XXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := current_tim';
wwv_flow_imp.g_varchar2_table(349) := 'estamp;'||wwv_flow.LF||
'        :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'        :new.updated := current_timest';
wwv_flow_imp.g_varchar2_table(350) := 'amp;'||wwv_flow.LF||
'        :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(351) := ' elsif updating then'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end ';
wwv_flow_imp.g_varchar2_table(352) := 'if;'||wwv_flow.LF||
'    if inserting or updating then'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.update';
wwv_flow_imp.g_varchar2_table(353) := 'd_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_AGRE';
wwv_flow_imp.g_varchar2_table(354) := 'EMENTS" '||wwv_flow.LF||
'    before insert or update on EBA_SALES_AGREEMENTS'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting';
wwv_flow_imp.g_varchar2_table(355) := ' then'||wwv_flow.LF||
'        if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(356) := 'XXXXXXXXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.CREAT';
wwv_flow_imp.g_varchar2_table(357) := 'ED := current_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated_by';
wwv_flow_imp.g_varchar2_table(358) := ' := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_num';
wwv_flow_imp.g_varchar2_table(359) := 'ber := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.U';
wwv_flow_imp.g_varchar2_table(360) := 'PDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number';
wwv_flow_imp.g_varchar2_table(361) := ',1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "EBA_SALES_PREFERENCES_BIU" '||wwv_flow.LF||
'    before inser';
wwv_flow_imp.g_varchar2_table(362) := 't or update on eba_sales_preferences'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null the';
wwv_flow_imp.g_varchar2_table(363) := 'n'||wwv_flow.LF||
'        :new.id := eba_sales_acl_api.gen_id();'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.crea';
wwv_flow_imp.g_varchar2_table(364) := 'ted_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created_on := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if ';
wwv_flow_imp.g_varchar2_table(365) := 'updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated_on := current';
wwv_flow_imp.g_varchar2_table(366) := '_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.preference_name := upper(:new.preference_name);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or r';
wwv_flow_imp.g_varchar2_table(367) := 'eplace TRIGGER "BIU_EBA_SALES_PRODUCT_LOBS" '||wwv_flow.LF||
'    before insert or update on EBA_SALES_PRODUCT_LOBS'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(368) := '   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :NEW.ID is null then'||wwv_flow.LF||
'            select to_nu';
wwv_flow_imp.g_varchar2_table(369) := 'mber(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from du';
wwv_flow_imp.g_varchar2_table(370) := 'al;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP';
wwv_flow_imp.g_varchar2_table(371) := '_USER''),USER);'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_t';
wwv_flow_imp.g_varchar2_table(372) := 'imestamp;'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATE';
wwv_flow_imp.g_varchar2_table(373) := 'D := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version';
wwv_flow_imp.g_varchar2_table(374) := '_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EB';
wwv_flow_imp.g_varchar2_table(375) := 'A_SALES_DEALS" '||wwv_flow.LF||
'    before insert or update on EBA_SALES_DEALS'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    ov varch';
wwv_flow_imp.g_varchar2_table(376) := 'ar2(4000);'||wwv_flow.LF||
'    nv varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.tags is not null then'||wwv_flow.LF||
'        :new.tags := eba_s';
wwv_flow_imp.g_varchar2_table(377) := 'ales_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.deal_close_date is null then'||wwv_flow.LF||
'       :new.de';
wwv_flow_imp.g_varchar2_table(378) := 'al_close_date := add_months(sysdate,2);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    for c1 in (select period_name from eba_sales';
wwv_flow_imp.g_varchar2_table(379) := '_sales_periods where :new.DEAL_CLOSE_DATE between first_day and last_day) loop'||wwv_flow.LF||
'        :new.qtr := c';
wwv_flow_imp.g_varchar2_table(380) := '1.period_name;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        select to_number(sys_';
wwv_flow_imp.g_varchar2_table(381) := 'guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then';
wwv_flow_imp.g_varchar2_table(382) := ''||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(383) := '    :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :';
wwv_flow_imp.g_varchar2_table(384) := 'new.row_key := eba_sales_fw.compress_int(eba_sales_rowkey_seq.nextval);'||wwv_flow.LF||
'        :new.row_version_num';
wwv_flow_imp.g_varchar2_table(385) := 'ber := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(386) := '   :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number';
wwv_flow_imp.g_varchar2_table(387) := ',1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting and :new.DEAL_STATUS_CODE_ID is not null then'||wwv_flow.LF||
'       if :new.d';
wwv_flow_imp.g_varchar2_table(388) := 'eal_probability is null then'||wwv_flow.LF||
'          for c1 in (select corresponding_prob_pct from EBA_SALES_DEAL_';
wwv_flow_imp.g_varchar2_table(389) := 'STATUS_CODES where id=:new.DEAL_STATUS_CODE_ID) loop'||wwv_flow.LF||
'              :new.deal_probability := c1.corre';
wwv_flow_imp.g_varchar2_table(390) := 'sponding_prob_pct;'||wwv_flow.LF||
'          end loop;'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'    elsif updating and (nvl(:new.DEAL_STATUS_C';
wwv_flow_imp.g_varchar2_table(391) := 'ODE_ID,3.1) != nvl(:old.DEAL_STATUS_CODE_ID,3.1) or :new.deal_probability is null ) then'||wwv_flow.LF||
'        if ';
wwv_flow_imp.g_varchar2_table(392) := ':new.deal_probability is null then'||wwv_flow.LF||
'           for c1 in (select corresponding_prob_pct from EBA_SALE';
wwv_flow_imp.g_varchar2_table(393) := 'S_DEAL_STATUS_CODES where id=:new.DEAL_STATUS_CODE_ID) loop'||wwv_flow.LF||
'               :new.deal_probability := ';
wwv_flow_imp.g_varchar2_table(394) := 'c1.corresponding_prob_pct;'||wwv_flow.LF||
'           end loop;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(395) := '  --'||wwv_flow.LF||
'    if updating and nvl(:old.TAGS,''x0'') !=  nvl(:new.TAGS,''x0'') then'||wwv_flow.LF||
'          insert into EBA_';
wwv_flow_imp.g_varchar2_table(396) := 'SALES_HISTORY (deal_rowkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_k';
wwv_flow_imp.g_varchar2_table(397) := 'ey, :new.id, upper(''tags''),:old.TAGS,:new.TAGS);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.DEA';
wwv_flow_imp.g_varchar2_table(398) := 'L_CURRENCY,''x0'') !=  nvl(:new.DEAL_CURRENCY,''x0'') then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (deal';
wwv_flow_imp.g_varchar2_table(399) := '_rowkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(';
wwv_flow_imp.g_varchar2_table(400) := '''CURRENCY''),:old.DEAL_CURRENCY,:new.DEAL_CURRENCY);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.';
wwv_flow_imp.g_varchar2_table(401) := 'DEAL_NAME,''x0'') !=  nvl(:new.DEAL_NAME,''x0'') then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (deal_rowk';
wwv_flow_imp.g_varchar2_table(402) := 'ey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''oppo';
wwv_flow_imp.g_varchar2_table(403) := 'rtunity_name''),:old.DEAL_NAME,:new.DEAL_NAME);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.STRAT';
wwv_flow_imp.g_varchar2_table(404) := 'EGY,''x0'') !=  nvl(:new.STRATEGY,''x0'') then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (deal_rowkey, dea';
wwv_flow_imp.g_varchar2_table(405) := 'l_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''STRATEGY''),';
wwv_flow_imp.g_varchar2_table(406) := ':old.STRATEGY,:new.STRATEGY);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.DEAL_SUMMARY,''x0'') != ';
wwv_flow_imp.g_varchar2_table(407) := ' nvl(:new.DEAL_SUMMARY,''x0'') then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (deal_rowkey, deal_id, col';
wwv_flow_imp.g_varchar2_table(408) := 'umn_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''summary''),:old.DEAL_';
wwv_flow_imp.g_varchar2_table(409) := 'SUMMARY,:new.DEAL_SUMMARY);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.NATIONAL_TOP_25_YN,''x0'')';
wwv_flow_imp.g_varchar2_table(410) := ' !=  nvl(:new.NATIONAL_TOP_25_YN,''x0'') then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (deal_rowkey, de';
wwv_flow_imp.g_varchar2_table(411) := 'al_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''NATIONAL_T';
wwv_flow_imp.g_varchar2_table(412) := 'OP_25''),:old.NATIONAL_TOP_25_YN,:new.NATIONAL_TOP_25_YN);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl';
wwv_flow_imp.g_varchar2_table(413) := '(:old.PARTNER,''x0'') !=  nvl(:new.PARTNER,''x0'') then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (deal_ro';
wwv_flow_imp.g_varchar2_table(414) := 'wkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''PA';
wwv_flow_imp.g_varchar2_table(415) := 'RTNER''),:old.PARTNER,:new.PARTNER);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.QTR,''0'') !=  nvl';
wwv_flow_imp.g_varchar2_table(416) := '(:new.QTR,''0'') then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (deal_rowkey, deal_id, column_name, old_';
wwv_flow_imp.g_varchar2_table(417) := 'value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''QTR''),:old.QTR,:new.QTR);'||wwv_flow.LF||
'    end ';
wwv_flow_imp.g_varchar2_table(418) := 'if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.PRO_RE_ACTIVE,''0'') !=  nvl(:new.PRO_RE_ACTIVE,''0'') then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(419) := '      insert into EBA_SALES_HISTORY (deal_rowkey, deal_id, column_name, old_value, new_value) values';
wwv_flow_imp.g_varchar2_table(420) := ''||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''PRO_RE_ACTIVE''),:old.PRO_RE_ACTIVE,:new.PRO_RE_ACTIVE);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(421) := '  end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- date history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and to_char(:old.DEAL_CLOSE_DATE,''DD-MM-';
wwv_flow_imp.g_varchar2_table(422) := 'YYYY'') !=  to_char(:new.DEAL_CLOSE_DATE,''DD-MM-YYYY'') then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (';
wwv_flow_imp.g_varchar2_table(423) := 'deal_rowkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, up';
wwv_flow_imp.g_varchar2_table(424) := 'per(''close_date''),to_char(:old.DEAL_CLOSE_DATE,''DD-MM-YYYY''),to_char(:new.DEAL_CLOSE_DATE,''DD-MM-YYY';
wwv_flow_imp.g_varchar2_table(425) := 'Y''));'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- numeric history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.DEAL_PROBABILITY';
wwv_flow_imp.g_varchar2_table(426) := ',0) !=  nvl(:new.DEAL_PROBABILITY,0) then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (deal_rowkey, deal';
wwv_flow_imp.g_varchar2_table(427) := '_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''probability''';
wwv_flow_imp.g_varchar2_table(428) := '),:old.DEAL_PROBABILITY,:new.DEAL_PROBABILITY);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.DEAL';
wwv_flow_imp.g_varchar2_table(429) := '_AMOUNT,0) !=  nvl(:new.DEAL_AMOUNT,0) then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (deal_rowkey, de';
wwv_flow_imp.g_varchar2_table(430) := 'al_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''amount''),:';
wwv_flow_imp.g_varchar2_table(431) := 'old.DEAL_AMOUNT,:new.DEAL_AMOUNT);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.DEAL_LICENSE,0) !';
wwv_flow_imp.g_varchar2_table(432) := '=  nvl(:new.DEAL_LICENSE,0) then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (deal_rowkey, deal_id, colu';
wwv_flow_imp.g_varchar2_table(433) := 'mn_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''license''),:old.DEAL_L';
wwv_flow_imp.g_varchar2_table(434) := 'ICENSE,:new.DEAL_LICENSE);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.DEAL_SUPPORT,0) !=  nvl(:';
wwv_flow_imp.g_varchar2_table(435) := 'new.DEAL_SUPPORT,0) then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (deal_rowkey, deal_id, column_name,';
wwv_flow_imp.g_varchar2_table(436) := ' old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''support''),:old.DEAL_SUPPORT,:';
wwv_flow_imp.g_varchar2_table(437) := 'new.DEAL_SUPPORT);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.DEAL_EDUCATION,0) !=  nvl(:new.DE';
wwv_flow_imp.g_varchar2_table(438) := 'AL_EDUCATION,0) then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (deal_rowkey, deal_id, column_name, old';
wwv_flow_imp.g_varchar2_table(439) := '_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''education''),:old.DEAL_EDUCATION,:';
wwv_flow_imp.g_varchar2_table(440) := 'new.DEAL_EDUCATION);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.DEAL_CONSULTING,0) !=  nvl(:new';
wwv_flow_imp.g_varchar2_table(441) := '.DEAL_CONSULTING,0) then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (deal_rowkey, deal_id, column_name,';
wwv_flow_imp.g_varchar2_table(442) := ' old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''consulting''),:old.DEAL_CONSUL';
wwv_flow_imp.g_varchar2_table(443) := 'TING,:new.DEAL_CONSULTING);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.DEAL_STATUS_CODE_ID,0) !';
wwv_flow_imp.g_varchar2_table(444) := '= nvl(:new.DEAL_STATUS_CODE_ID,0) then'||wwv_flow.LF||
'      ov := null; nv := null;'||wwv_flow.LF||
'      for c1 in (select STATUS_';
wwv_flow_imp.g_varchar2_table(445) := 'CODE from EBA_SALES_LEAD_STATUS_CODES c where c.id = :old.DEAL_STATUS_CODE_ID) loop'||wwv_flow.LF||
'          ov := ';
wwv_flow_imp.g_varchar2_table(446) := 'c1.STATUS_CODE;'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'      for c1 in (select STATUS_CODE from EBA_SALES_LEAD_STATUS_CODES';
wwv_flow_imp.g_varchar2_table(447) := ' c where c.id = :new.DEAL_STATUS_CODE_ID) loop'||wwv_flow.LF||
'          nv := c1.STATUS_CODE;'||wwv_flow.LF||
'      end loop;   '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(448) := '    insert into EBA_SALES_HISTORY (deal_rowkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(449) := '         (:new.row_key, :new.id, upper(''status code''),ov,nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and';
wwv_flow_imp.g_varchar2_table(450) := ' nvl(:old.CUSTOMER_ID,0) != nvl(:new.CUSTOMER_ID,0) then'||wwv_flow.LF||
'      ov := null; nv := null;'||wwv_flow.LF||
'      for c1 ';
wwv_flow_imp.g_varchar2_table(451) := 'in (select CUSTOMER_NAME from EBA_SALES_CUSTOMERS c where c.id = :old.CUSTOMER_ID) loop'||wwv_flow.LF||
'          ov';
wwv_flow_imp.g_varchar2_table(452) := ' := c1.CUSTOMER_NAME;'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'      for c1 in (select CUSTOMER_NAME from EBA_SALES_CUSTOMERS';
wwv_flow_imp.g_varchar2_table(453) := ' c where c.id = :new.CUSTOMER_ID) loop'||wwv_flow.LF||
'          nv := c1.CUSTOMER_NAME;'||wwv_flow.LF||
'      end loop;   '||wwv_flow.LF||
'      in';
wwv_flow_imp.g_varchar2_table(454) := 'sert into EBA_SALES_HISTORY (deal_rowkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(455) := '   (:new.row_key, :new.id, upper(''account''),ov,nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.';
wwv_flow_imp.g_varchar2_table(456) := 'SALESREP_ID_01,0) != nvl(:new.SALESREP_ID_01,0) then'||wwv_flow.LF||
'      ov := null; nv := null;'||wwv_flow.LF||
'      for c1 in (';
wwv_flow_imp.g_varchar2_table(457) := 'select REP_EBA_SALES_USERNAME,REP_EMAIL,REP_LAST_NAME,REP_FIRST_NAME from EBA_SALES_SALESREPS c wher';
wwv_flow_imp.g_varchar2_table(458) := 'e c.id = :old.SALESREP_ID_01) loop'||wwv_flow.LF||
'          ov := nvl(nvl(c1.REP_EMAIL,c1.REP_FIRST_NAME||'' ''||c1.R';
wwv_flow_imp.g_varchar2_table(459) := 'EP_LAST_NAME),c1.REP_EBA_SALES_USERNAME);'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'      for c1 in (select REP_EBA_SALES_USER';
wwv_flow_imp.g_varchar2_table(460) := 'NAME,REP_EMAIL,REP_LAST_NAME,REP_FIRST_NAME from EBA_SALES_SALESREPS c where c.id = :new.SALESREP_ID';
wwv_flow_imp.g_varchar2_table(461) := '_01) loop'||wwv_flow.LF||
'          nv := nvl(nvl(c1.REP_EMAIL,c1.REP_FIRST_NAME||'' ''||c1.REP_LAST_NAME),c1.REP_EBA_';
wwv_flow_imp.g_varchar2_table(462) := 'SALES_USERNAME);'||wwv_flow.LF||
'      end loop;   '||wwv_flow.LF||
'      insert into EBA_SALES_HISTORY (deal_rowkey, deal_id, colum';
wwv_flow_imp.g_varchar2_table(463) := 'n_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''SALESREP_01''),ov,nv);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(464) := '    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.FINANCIAL_ASSESSMENT_ID,0) != nvl(:new.FINANCIAL_ASS';
wwv_flow_imp.g_varchar2_table(465) := 'ESSMENT_ID,0) then'||wwv_flow.LF||
'      ov := null; nv := null;'||wwv_flow.LF||
'      for c1 in (select ASSESSMENT_TEXT from EBA_SA';
wwv_flow_imp.g_varchar2_table(466) := 'LES_FIN_ASSESSMENTS c where c.id = :old.FINANCIAL_ASSESSMENT_ID) loop'||wwv_flow.LF||
'          ov := c1.ASSESSMENT_';
wwv_flow_imp.g_varchar2_table(467) := 'TEXT;'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'      for c1 in (select ASSESSMENT_TEXT from EBA_SALES_FIN_ASSESSMENTS c where';
wwv_flow_imp.g_varchar2_table(468) := ' c.id = :new.FINANCIAL_ASSESSMENT_ID) loop'||wwv_flow.LF||
'          nv := c1.ASSESSMENT_TEXT;'||wwv_flow.LF||
'      end loop;   '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(469) := '    insert into EBA_SALES_HISTORY (deal_rowkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(470) := '         (:new.row_key, :new.id, upper(''financial_assessment''),ov,nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if upd';
wwv_flow_imp.g_varchar2_table(471) := 'ating and nvl(:old.STATUS_ASSESSMENT_ID,0) != nvl(:new.STATUS_ASSESSMENT_ID,0) then'||wwv_flow.LF||
'      ov := null';
wwv_flow_imp.g_varchar2_table(472) := '; nv := null;'||wwv_flow.LF||
'      for c1 in (select ASSESSMENT_TEXT from EBA_SALES_STATUS_ASSESSMENTS c where c.id';
wwv_flow_imp.g_varchar2_table(473) := ' = :old.STATUS_ASSESSMENT_ID) loop'||wwv_flow.LF||
'          ov := c1.ASSESSMENT_TEXT;'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'      for c1 ';
wwv_flow_imp.g_varchar2_table(474) := 'in (select ASSESSMENT_TEXT from EBA_SALES_STATUS_ASSESSMENTS c where c.id = :new.STATUS_ASSESSMENT_I';
wwv_flow_imp.g_varchar2_table(475) := 'D) loop'||wwv_flow.LF||
'          nv := c1.ASSESSMENT_TEXT;'||wwv_flow.LF||
'      end loop;   '||wwv_flow.LF||
'      insert into EBA_SALES_HISTORY (';
wwv_flow_imp.g_varchar2_table(476) := 'deal_rowkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, up';
wwv_flow_imp.g_varchar2_table(477) := 'per(''status_assessment''),ov,nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.RISK_ASSESSMENT_ID,';
wwv_flow_imp.g_varchar2_table(478) := '0) != nvl(:new.RISK_ASSESSMENT_ID,0) then'||wwv_flow.LF||
'      ov := null; nv := null;'||wwv_flow.LF||
'      for c1 in (select ASSE';
wwv_flow_imp.g_varchar2_table(479) := 'SSMENT_TEXT from EBA_SALES_RISK_ASSESSMENTS c where c.id = :old.RISK_ASSESSMENT_ID) loop'||wwv_flow.LF||
'          o';
wwv_flow_imp.g_varchar2_table(480) := 'v := c1.ASSESSMENT_TEXT;'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'      for c1 in (select ASSESSMENT_TEXT from EBA_SALES_RISK';
wwv_flow_imp.g_varchar2_table(481) := '_ASSESSMENTS c where c.id = :new.RISK_ASSESSMENT_ID) loop'||wwv_flow.LF||
'          nv := c1.ASSESSMENT_TEXT;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(482) := 'end loop;   '||wwv_flow.LF||
'      insert into EBA_SALES_HISTORY (deal_rowkey, deal_id, column_name, old_value, new_';
wwv_flow_imp.g_varchar2_table(483) := 'value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''risk_assessment''),ov,nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(484) := '    if updating and nvl(:old.ACCOUNT_STANDING_ID,0) != nvl(:new.ACCOUNT_STANDING_ID,0) then'||wwv_flow.LF||
'      ov';
wwv_flow_imp.g_varchar2_table(485) := ' := null; nv := null;'||wwv_flow.LF||
'      for c1 in (select STANDING_TEXT from EBA_SALES_ACCOUNT_STANDING c where ';
wwv_flow_imp.g_varchar2_table(486) := 'c.id = :old.ACCOUNT_STANDING_ID) loop'||wwv_flow.LF||
'          ov := c1.STANDING_TEXT;'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'      for c1';
wwv_flow_imp.g_varchar2_table(487) := ' in (select STANDING_TEXT from EBA_SALES_ACCOUNT_STANDING c where c.id = :new.ACCOUNT_STANDING_ID) l';
wwv_flow_imp.g_varchar2_table(488) := 'oop'||wwv_flow.LF||
'          nv := c1.STANDING_TEXT;'||wwv_flow.LF||
'      end loop;   '||wwv_flow.LF||
'      insert into EBA_SALES_HISTORY (deal_r';
wwv_flow_imp.g_varchar2_table(489) := 'owkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''a';
wwv_flow_imp.g_varchar2_table(490) := 'ccount_standing''),ov,nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.SVP_ID,0) != nvl(:new.SVP_';
wwv_flow_imp.g_varchar2_table(491) := 'ID,0) then'||wwv_flow.LF||
'      ov := null; nv := null;'||wwv_flow.LF||
'      for c1 in (select SVP_NAME from EBA_SALES_SVPS c wher';
wwv_flow_imp.g_varchar2_table(492) := 'e c.id = :old.SVP_ID) loop'||wwv_flow.LF||
'          ov := c1.SVP_NAME;'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'      for c1 in (select SVP_';
wwv_flow_imp.g_varchar2_table(493) := 'NAME from EBA_SALES_SVPS c where c.id = :new.SVP_ID) loop'||wwv_flow.LF||
'          nv := c1.SVP_NAME;'||wwv_flow.LF||
'      end loo';
wwv_flow_imp.g_varchar2_table(494) := 'p;   '||wwv_flow.LF||
'      insert into EBA_SALES_HISTORY (deal_rowkey, deal_id, column_name, old_value, new_value) ';
wwv_flow_imp.g_varchar2_table(495) := 'values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''SVP''),ov,nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- tags'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(496) := '    eba_sales_fw.tag_sync('||wwv_flow.LF||
'        p_new_tags      => :new.tags,'||wwv_flow.LF||
'        p_old_tags      => :old.tag';
wwv_flow_imp.g_varchar2_table(497) := 's,'||wwv_flow.LF||
'        p_content_type  => ''DEAL'','||wwv_flow.LF||
'        p_content_id    => :new.id );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replac';
wwv_flow_imp.g_varchar2_table(498) := 'e TRIGGER "BD_EBA_SALES_DEALS" '||wwv_flow.LF||
'    before delete on eba_sales_deals'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    dele';
wwv_flow_imp.g_varchar2_table(499) := 'te from EBA_SALES_DEAL_products where deal_id = :new.id;'||wwv_flow.LF||
'    eba_sales_fw.tag_sync('||wwv_flow.LF||
'        p_new_ta';
wwv_flow_imp.g_varchar2_table(500) := 'gs      => null,'||wwv_flow.LF||
'        p_old_tags      => :old.tags,'||wwv_flow.LF||
'        p_content_type  => ''DEAL'','||wwv_flow.LF||
'        p_';
wwv_flow_imp.g_varchar2_table(501) := 'content_id    => :old.id );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_EBA_SALES_DEAL_COMPET" '||wwv_flow.LF||
'    b';
wwv_flow_imp.g_varchar2_table(502) := 'efore insert or update on eba_sales_deal_competition'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(503) := '      if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(504) := 'XXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.CREATED := cu';
wwv_flow_imp.g_varchar2_table(505) := 'rrent_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated_by := nvl(';
wwv_flow_imp.g_varchar2_table(506) := 'v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := 1';
wwv_flow_imp.g_varchar2_table(507) := ';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_B';
wwv_flow_imp.g_varchar2_table(508) := 'Y := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;';
wwv_flow_imp.g_varchar2_table(509) := ''||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "EBA_SALES_VERIFY_BIU_FER" '||wwv_flow.LF||
'    before insert or upda';
wwv_flow_imp.g_varchar2_table(510) := 'te on eba_sales_verifications'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        :new.id := ';
wwv_flow_imp.g_varchar2_table(511) := 'eba_sales_acl_api.gen_id();'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := current_timest';
wwv_flow_imp.g_varchar2_table(512) := 'amp;'||wwv_flow.LF||
'        :new.created_by := nvl(apex_application.g_user,user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.verified_by ';
wwv_flow_imp.g_varchar2_table(513) := ':= lower(:new.verified_by);'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(apex_a';
wwv_flow_imp.g_varchar2_table(514) := 'pplication.g_user,user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_DEAL_PRODUCTS" '||wwv_flow.LF||
'    before';
wwv_flow_imp.g_varchar2_table(515) := ' insert or update on EBA_SALES_DEAL_products'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is ';
wwv_flow_imp.g_varchar2_table(516) := 'null then'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from ';
wwv_flow_imp.g_varchar2_table(517) := 'dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    for c1 in (select period_name from eba_sales_sales_periods where :new.close_da';
wwv_flow_imp.g_varchar2_table(518) := 'te between first_day and last_day)'||wwv_flow.LF||
'    loop '||wwv_flow.LF||
'        :new.qtr := c1.period_name; '||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(519) := 'if inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created := curren';
wwv_flow_imp.g_varchar2_table(520) := 't_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_tim';
wwv_flow_imp.g_varchar2_table(521) := 'estamp;'||wwv_flow.LF||
'        :new.row_key := eba_sales_fw.compress_int(eba_sales_rowkey_seq.nextval);'||wwv_flow.LF||
'        :ne';
wwv_flow_imp.g_varchar2_table(522) := 'w.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_US';
wwv_flow_imp.g_varchar2_table(523) := 'ER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.r';
wwv_flow_imp.g_varchar2_table(524) := 'ow_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_DEAL_STAT_COD';
wwv_flow_imp.g_varchar2_table(525) := 'ES" '||wwv_flow.LF||
'    before insert or update on EBA_SALES_DEAL_status_codes'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if insert';
wwv_flow_imp.g_varchar2_table(526) := 'ing and :new.id is null then'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')';
wwv_flow_imp.g_varchar2_table(527) := ' into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USE';
wwv_flow_imp.g_varchar2_table(528) := 'R''),USER);'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),U';
wwv_flow_imp.g_varchar2_table(529) := 'SER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(530) := '   if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := curr';
wwv_flow_imp.g_varchar2_table(531) := 'ent_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'en';
wwv_flow_imp.g_varchar2_table(532) := 'd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_SALESREP_ROLES" '||wwv_flow.LF||
'    before insert or update on eba_s';
wwv_flow_imp.g_varchar2_table(533) := 'ales_salesrep_roles'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        select ';
wwv_flow_imp.g_varchar2_table(534) := 'to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if ';
wwv_flow_imp.g_varchar2_table(535) := 'inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created := current_t';
wwv_flow_imp.g_varchar2_table(536) := 'imestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timest';
wwv_flow_imp.g_varchar2_table(537) := 'amp;'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by ';
wwv_flow_imp.g_varchar2_table(538) := ':= nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_numb';
wwv_flow_imp.g_varchar2_table(539) := 'er := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.is_sales_rep is null then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(540) := ':new.is_sales_rep := ''Y'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_SVPS" '||wwv_flow.LF||
'    be';
wwv_flow_imp.g_varchar2_table(541) := 'fore insert or update on eba_sales_svps'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :NEW';
wwv_flow_imp.g_varchar2_table(542) := '.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(543) := '       into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.CREATED := current_timesta';
wwv_flow_imp.g_varchar2_table(544) := 'mp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(545) := '       :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;';
wwv_flow_imp.g_varchar2_table(546) := ''||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''A';
wwv_flow_imp.g_varchar2_table(547) := 'PP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(548) := 'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_CUST" '||wwv_flow.LF||
'    before insert or update on eba_sales_cus';
wwv_flow_imp.g_varchar2_table(549) := 'tomers'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'        if :new.id is null '||wwv_flow.LF||
'        then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(550) := '      :new.id := to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(551) := ':new.row_version_number := 1;'||wwv_flow.LF||
'        :new.row_key := eba_sales_fw.compress_int(eba_sales_rowkey_seq';
wwv_flow_imp.g_varchar2_table(552) := '.nextval);'||wwv_flow.LF||
'        :new.created_by := nvl(apex_application.g_user, user);'||wwv_flow.LF||
'        :new.created := cu';
wwv_flow_imp.g_varchar2_table(553) := 'rrent_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(apex_application.g_user, user);'||wwv_flow.LF||
'        :new.updated';
wwv_flow_imp.g_varchar2_table(554) := ' := current_timestamp;'||wwv_flow.LF||
'    elsif updating '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'        :new.updated_by := nvl(apex_application.';
wwv_flow_imp.g_varchar2_table(555) := 'g_user, user);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := nvl(:ol';
wwv_flow_imp.g_varchar2_table(556) := 'd.row_version_number, 1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.tags is not null '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'        :new.tags :';
wwv_flow_imp.g_varchar2_table(557) := '= eba_sales_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    eba_sales_fw.tag_sync('||wwv_flow.LF||
'        p_new_tags   ';
wwv_flow_imp.g_varchar2_table(558) := '  => :new.tags,'||wwv_flow.LF||
'        p_old_tags     => :old.tags,'||wwv_flow.LF||
'        p_content_type => ''ACCOUNT'','||wwv_flow.LF||
'        p_';
wwv_flow_imp.g_varchar2_table(559) := 'content_id   => :new.id'||wwv_flow.LF||
'    );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BD_EBA_SALES_CUST" '||wwv_flow.LF||
'    before del';
wwv_flow_imp.g_varchar2_table(560) := 'ete on eba_sales_customers'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba_sales_fw.tag_sync('||wwv_flow.LF||
'        p_new_tags     ';
wwv_flow_imp.g_varchar2_table(561) := '=> null,'||wwv_flow.LF||
'        p_old_tags     => :old.tags,'||wwv_flow.LF||
'        p_content_type => ''ACCOUNT'','||wwv_flow.LF||
'        p_content';
wwv_flow_imp.g_varchar2_table(562) := '_id   => :old.id'||wwv_flow.LF||
'    );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_COMMENTS" before insert or ';
wwv_flow_imp.g_varchar2_table(563) := 'update on "EBA_SALES_COMMENTS"'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(564) := '    select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end ';
wwv_flow_imp.g_varchar2_table(565) := 'if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created :';
wwv_flow_imp.g_varchar2_table(566) := '= current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := cur';
wwv_flow_imp.g_varchar2_table(567) := 'rent_timestamp;'||wwv_flow.LF||
'        :new.row_key := eba_sales_fw.compress_int(eba_sales_rowkey_seq.nextval);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(568) := '     :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v';
wwv_flow_imp.g_varchar2_table(569) := '(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := nv';
wwv_flow_imp.g_varchar2_table(570) := 'l(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_RISK_';
wwv_flow_imp.g_varchar2_table(571) := 'ASSESSMENTS" '||wwv_flow.LF||
'    before insert or update on eba_sales_risk_assessments'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(572) := 'f inserting then'||wwv_flow.LF||
'        if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(573) := 'XXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(574) := ' :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new';
wwv_flow_imp.g_varchar2_table(575) := '.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_';
wwv_flow_imp.g_varchar2_table(576) := 'version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(577) := '     :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_ver';
wwv_flow_imp.g_varchar2_table(578) := 'sion_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_STATUS_ASSESS" '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(579) := ' before insert or update on eba_sales_status_assessments'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting the';
wwv_flow_imp.g_varchar2_table(580) := 'n'||wwv_flow.LF||
'        if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(581) := 'XXXXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.CREATED :';
wwv_flow_imp.g_varchar2_table(582) := '= current_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated_by := ';
wwv_flow_imp.g_varchar2_table(583) := 'nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number ';
wwv_flow_imp.g_varchar2_table(584) := ':= 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDAT';
wwv_flow_imp.g_varchar2_table(585) := 'ED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) ';
wwv_flow_imp.g_varchar2_table(586) := '+ 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_COMPETITORS" '||wwv_flow.LF||
'    before insert or';
wwv_flow_imp.g_varchar2_table(587) := ' update on eba_sales_competitors'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'if :new.tags is not null then'||wwv_flow.LF||
'    :new.tags ';
wwv_flow_imp.g_varchar2_table(588) := ':= eba_sales_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :NEW.ID is null th';
wwv_flow_imp.g_varchar2_table(589) := 'en'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :n';
wwv_flow_imp.g_varchar2_table(590) := 'ew.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'        :N';
wwv_flow_imp.g_varchar2_table(591) := 'EW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(592) := '  :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updati';
wwv_flow_imp.g_varchar2_table(593) := 'ng then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER';
wwv_flow_imp.g_varchar2_table(594) := ');'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    eba_sales_';
wwv_flow_imp.g_varchar2_table(595) := 'fw.tag_sync('||wwv_flow.LF||
'        p_new_tags      => :new.tags,'||wwv_flow.LF||
'        p_old_tags      => :old.tags,'||wwv_flow.LF||
'        p_c';
wwv_flow_imp.g_varchar2_table(596) := 'ontent_type  => ''COMPETITOR'','||wwv_flow.LF||
'        p_content_id    => :new.id );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGE';
wwv_flow_imp.g_varchar2_table(597) := 'R "BD_EBA_SALES_COMPETITORS" '||wwv_flow.LF||
'    before delete on eba_sales_competitors'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(598) := 'eba_sales_fw.tag_sync('||wwv_flow.LF||
'        p_new_tags      => null,'||wwv_flow.LF||
'        p_old_tags      => :old.tags,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(599) := '  p_content_type  => ''COMPETITOR'','||wwv_flow.LF||
'        p_content_id    => :old.id );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace T';
wwv_flow_imp.g_varchar2_table(600) := 'RIGGER "BIU_EBA_SALES_TERRITORY_ACL" '||wwv_flow.LF||
'    before insert or update on eba_sales_territory_acl'||wwv_flow.LF||
'    for';
wwv_flow_imp.g_varchar2_table(601) := ' each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(s';
wwv_flow_imp.g_varchar2_table(602) := 'ys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(603) := '      end if;'||wwv_flow.LF||
'        :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''';
wwv_flow_imp.g_varchar2_table(604) := '),USER);'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USE';
wwv_flow_imp.g_varchar2_table(605) := 'R);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := c';
wwv_flow_imp.g_varchar2_table(606) := 'urrent_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_numbe';
wwv_flow_imp.g_varchar2_table(607) := 'r := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALE';
wwv_flow_imp.g_varchar2_table(608) := 'S_DEAL_TEAM" '||wwv_flow.LF||
'    before insert or update on eba_sales_deal_team'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inser';
wwv_flow_imp.g_varchar2_table(609) := 'ting then'||wwv_flow.LF||
'        if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(610) := 'XXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.C';
wwv_flow_imp.g_varchar2_table(611) := 'REATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.update';
wwv_flow_imp.g_varchar2_table(612) := 'd_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version';
wwv_flow_imp.g_varchar2_table(613) := '_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :N';
wwv_flow_imp.g_varchar2_table(614) := 'EW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_nu';
wwv_flow_imp.g_varchar2_table(615) := 'mber,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "EBA_SALES_USERS_BD" '||wwv_flow.LF||
'    before delete o';
wwv_flow_imp.g_varchar2_table(616) := 'n eba_sales_users'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    pragma autonomous_transaction;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- Disallow ';
wwv_flow_imp.g_varchar2_table(617) := 'deletes to a user''s own record unless last one.'||wwv_flow.LF||
'    if v(''APP_USER'') = upper(:old.username) then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(618) := '    for c1 in ('||wwv_flow.LF||
'          select count(*) cnt'||wwv_flow.LF||
'            from eba_sales_users'||wwv_flow.LF||
'           where id !';
wwv_flow_imp.g_varchar2_table(619) := '= :old.id )'||wwv_flow.LF||
'       loop'||wwv_flow.LF||
'          if c1.cnt > 0 then'||wwv_flow.LF||
'             raise_application_error(-20002, ''D';
wwv_flow_imp.g_varchar2_table(620) := 'elete disallowed, you cannot delete your own access control details.'');'||wwv_flow.LF||
'          end if;'||wwv_flow.LF||
'       end';
wwv_flow_imp.g_varchar2_table(621) := ' loop;'||wwv_flow.LF||
'    end if;    '||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "EBA_SALES_USERS_BIU" '||wwv_flow.LF||
'    before insert or';
wwv_flow_imp.g_varchar2_table(622) := ' update on eba_sales_users'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is null t';
wwv_flow_imp.g_varchar2_table(623) := 'hen'||wwv_flow.LF||
'            :new.id := eba_sales_acl_api.gen_id();'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created_by      ';
wwv_flow_imp.g_varchar2_table(624) := '   := nvl(v(''APP_USER''), USER);'||wwv_flow.LF||
'        :new.created            := current_timestamp;'||wwv_flow.LF||
'        :new.r';
wwv_flow_imp.g_varchar2_table(625) := 'ow_version        := 1;'||wwv_flow.LF||
'        if :new.account_locked is null then'||wwv_flow.LF||
'            :new.account_locked ';
wwv_flow_imp.g_varchar2_table(626) := ':= ''N'';    '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by         := nvl(';
wwv_flow_imp.g_varchar2_table(627) := 'v(''APP_USER''), USER);'||wwv_flow.LF||
'        :new.updated            := current_timestamp;'||wwv_flow.LF||
'        :new.row_version';
wwv_flow_imp.g_varchar2_table(628) := '        := nvl(:old.row_version,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- Always store username as upper case'||wwv_flow.LF||
'    :';
wwv_flow_imp.g_varchar2_table(629) := 'new.username := upper(:new.username);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_COUNTRIES" '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(630) := '   before insert or update on eba_sales_countries'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.i';
wwv_flow_imp.g_varchar2_table(631) := 'd is null then'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id ';
wwv_flow_imp.g_varchar2_table(632) := 'from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(633) := 'f updating then'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'e';
wwv_flow_imp.g_varchar2_table(634) := 'nd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_INDUSTRIES" '||wwv_flow.LF||
'    before insert or update on eba_sale';
wwv_flow_imp.g_varchar2_table(635) := 's_industries'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        select to_numb';
wwv_flow_imp.g_varchar2_table(636) := 'er(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserti';
wwv_flow_imp.g_varchar2_table(637) := 'ng then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created := current_timestam';
wwv_flow_imp.g_varchar2_table(638) := 'p;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(639) := '      :new.row_key := eba_sales_fw.compress_int(eba_sales_rowkey_seq.nextval);'||wwv_flow.LF||
'        :new.row_vers';
wwv_flow_imp.g_varchar2_table(640) := 'ion_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER)';
wwv_flow_imp.g_varchar2_table(641) := ';'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version';
wwv_flow_imp.g_varchar2_table(642) := '_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_TERMS"'||wwv_flow.LF||
'    before inser';
wwv_flow_imp.g_varchar2_table(643) := 't or update on eba_sales_terms'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(644) := '    select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end ';
wwv_flow_imp.g_varchar2_table(645) := 'if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created :';
wwv_flow_imp.g_varchar2_table(646) := '= current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := cur';
wwv_flow_imp.g_varchar2_table(647) := 'rent_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);';
wwv_flow_imp.g_varchar2_table(648) := ''||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BD_EBA_SA';
wwv_flow_imp.g_varchar2_table(649) := 'LES_TERR" '||wwv_flow.LF||
'    before delete on eba_sales_territories'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba_sales_fw.tag_sy';
wwv_flow_imp.g_varchar2_table(650) := 'nc('||wwv_flow.LF||
'        p_new_tags     => null,'||wwv_flow.LF||
'        p_old_tags     => :old.tags,'||wwv_flow.LF||
'        p_content_type => ''';
wwv_flow_imp.g_varchar2_table(651) := 'TERRITORY'','||wwv_flow.LF||
'        p_content_id   => :old.id'||wwv_flow.LF||
'    );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALE';
wwv_flow_imp.g_varchar2_table(652) := 'S_TERR" '||wwv_flow.LF||
'    before insert or update on eba_sales_territories'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if insertin';
wwv_flow_imp.g_varchar2_table(653) := 'g '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            :new.id := to_number(sys_guid(), ''XXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(654) := 'XXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'        :new.row_key';
wwv_flow_imp.g_varchar2_table(655) := ' := eba_sales_fw.compress_int(eba_sales_rowkey_seq.nextval);'||wwv_flow.LF||
'        :new.created_by := nvl(apex_app';
wwv_flow_imp.g_varchar2_table(656) := 'lication.g_user, user);'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(ap';
wwv_flow_imp.g_varchar2_table(657) := 'ex_application.g_user, user);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(658) := '     :new.updated_by := nvl(apex_application.g_user, user);'||wwv_flow.LF||
'        :new.updated := current_timestam';
wwv_flow_imp.g_varchar2_table(659) := 'p;'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number, 1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.t';
wwv_flow_imp.g_varchar2_table(660) := 'ags is not null then'||wwv_flow.LF||
'        :new.tags := eba_sales_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    eba_';
wwv_flow_imp.g_varchar2_table(661) := 'sales_fw.tag_sync('||wwv_flow.LF||
'        p_new_tags     => :new.tags,'||wwv_flow.LF||
'        p_old_tags     => :old.tags,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(662) := ' p_content_type => ''TERRITORY'','||wwv_flow.LF||
'        p_content_id   => :new.id'||wwv_flow.LF||
'    );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace T';
wwv_flow_imp.g_varchar2_table(663) := 'RIGGER "BIU_EBA_SALES_SUPPORT_AMTS" '||wwv_flow.LF||
'    before insert or update on EBA_SALES_SUPPORT_AMTS'||wwv_flow.LF||
'    for e';
wwv_flow_imp.g_varchar2_table(664) := 'ach row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys';
wwv_flow_imp.g_varchar2_table(665) := '_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(666) := '    end if;'||wwv_flow.LF||
'        :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),';
wwv_flow_imp.g_varchar2_table(667) := 'USER);'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp';
wwv_flow_imp.g_varchar2_table(668) := ';'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := cur';
wwv_flow_imp.g_varchar2_table(669) := 'rent_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number ';
wwv_flow_imp.g_varchar2_table(670) := ':= nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_';
wwv_flow_imp.g_varchar2_table(671) := 'CURRENCIES" '||wwv_flow.LF||
'    before insert or update on EBA_SALES_CURRENCIES '||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inse';
wwv_flow_imp.g_varchar2_table(672) := 'rting and :new.id is null then'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(673) := ''') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_U';
wwv_flow_imp.g_varchar2_table(674) := 'SER''),USER);'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER'')';
wwv_flow_imp.g_varchar2_table(675) := ',USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;';
wwv_flow_imp.g_varchar2_table(676) := ''||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := cu';
wwv_flow_imp.g_varchar2_table(677) := 'rrent_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(678) := '    :new.CURRENCY_CODE := upper(:new.CURRENCY_CODE);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALE';
wwv_flow_imp.g_varchar2_table(679) := 'S_CUST_AGRMNT_MAP" '||wwv_flow.LF||
'    before insert or update on EBA_SALES_CUST_AGRMNT_MAP'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(680) := '    if inserting then'||wwv_flow.LF||
'        if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXX';
wwv_flow_imp.g_varchar2_table(681) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(682) := '      :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(683) := ' :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new';
wwv_flow_imp.g_varchar2_table(684) := '.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp';
wwv_flow_imp.g_varchar2_table(685) := ';'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.ro';
wwv_flow_imp.g_varchar2_table(686) := 'w_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_SALES_PERIODS"';
wwv_flow_imp.g_varchar2_table(687) := ' '||wwv_flow.LF||
'    before insert or update on eba_sales_sales_periods'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and';
wwv_flow_imp.g_varchar2_table(688) := ' :new.id is null then'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :';
wwv_flow_imp.g_varchar2_table(689) := 'new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if';
wwv_flow_imp.g_varchar2_table(690) := ';'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    en';
wwv_flow_imp.g_varchar2_table(691) := 'd if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "EBA_SALES_ERRORS_BI" '||wwv_flow.LF||
'    before insert or update on eba_sa';
wwv_flow_imp.g_varchar2_table(692) := 'les_errors'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'       :new.id := eba_sales_acl_api.ge';
wwv_flow_imp.g_varchar2_table(693) := 'n_id();'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_TAGS" '||wwv_flow.LF||
'    before insert or upd';
wwv_flow_imp.g_varchar2_table(694) := 'ate on eba_sales_tags'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    :new.tag := upper(:new.tag);'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(695) := '        if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(696) := 'XXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.CREATED := ';
wwv_flow_imp.g_varchar2_table(697) := 'current_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :NEW.UPDATED := curre';
wwv_flow_imp.g_varchar2_table(698) := 'nt_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number :=';
wwv_flow_imp.g_varchar2_table(699) := ' 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED';
wwv_flow_imp.g_varchar2_table(700) := '_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + ';
wwv_flow_imp.g_varchar2_table(701) := '1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BD_EBA_SALES_PRODUCTS" '||wwv_flow.LF||
'    before delete on eba_s';
wwv_flow_imp.g_varchar2_table(702) := 'ales_products'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba_sales_fw.tag_sync('||wwv_flow.LF||
'        p_new_tags     => null,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(703) := '    p_old_tags     => :old.tags,'||wwv_flow.LF||
'        p_content_type => ''PRODUCT'','||wwv_flow.LF||
'        p_content_id   => :old';
wwv_flow_imp.g_varchar2_table(704) := '.id'||wwv_flow.LF||
'    );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_PRODUCTS" '||wwv_flow.LF||
'    before insert or update o';
wwv_flow_imp.g_varchar2_table(705) := 'n eba_sales_products'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'        if :new.id is null '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(706) := '       then'||wwv_flow.LF||
'        :new.id := to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        en';
wwv_flow_imp.g_varchar2_table(707) := 'd if;'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'        :new.row_key := eba_sales_fw.compress_int(eba_sa';
wwv_flow_imp.g_varchar2_table(708) := 'les_rowkey_seq.nextval);'||wwv_flow.LF||
'        :new.created_by := nvl(apex_application.g_user, user);'||wwv_flow.LF||
'        :new';
wwv_flow_imp.g_varchar2_table(709) := '.created := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(apex_application.g_user, user);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(710) := '  :new.updated := current_timestamp;'||wwv_flow.LF||
'    elsif updating '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'        :new.updated_by := nvl(ape';
wwv_flow_imp.g_varchar2_table(711) := 'x_application.g_user, user);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_num';
wwv_flow_imp.g_varchar2_table(712) := 'ber := nvl(:old.row_version_number, 1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.tags is not null '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(713) := '   :new.tags := eba_sales_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    eba_sales_fw.tag_sync('||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(714) := ' p_new_tags     => :new.tags,'||wwv_flow.LF||
'        p_old_tags     => :old.tags,'||wwv_flow.LF||
'        p_content_type => ''PRODUC';
wwv_flow_imp.g_varchar2_table(715) := 'T'','||wwv_flow.LF||
'        p_content_id   => :new.id'||wwv_flow.LF||
'    );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_FILES"';
wwv_flow_imp.g_varchar2_table(716) := ' '||wwv_flow.LF||
'    before insert or update on EBA_SALES_files'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new."ID" is null the';
wwv_flow_imp.g_varchar2_table(717) := 'n'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(718) := '  end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by :';
wwv_flow_imp.g_varchar2_table(719) := '= nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := n';
wwv_flow_imp.g_varchar2_table(720) := 'vl(wwv_flow.g_user,user);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new';
wwv_flow_imp.g_varchar2_table(721) := '.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting or updating ';
wwv_flow_imp.g_varchar2_table(722) := 'then'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(wwv_flow.g_user,user)';
wwv_flow_imp.g_varchar2_table(723) := ';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_CUSTOMERS_LOCS" '||wwv_flow.LF||
'    before insert or';
wwv_flow_imp.g_varchar2_table(724) := ' update on eba_sales_customer_locations'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null ';
wwv_flow_imp.g_varchar2_table(725) := 'then'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;';
wwv_flow_imp.g_varchar2_table(726) := ''||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.';
wwv_flow_imp.g_varchar2_table(727) := 'created := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updat';
wwv_flow_imp.g_varchar2_table(728) := 'ed := current_timestamp;'||wwv_flow.LF||
'        :new.row_key := eba_sales_fw.compress_int(eba_sales_rowkey_seq.next';
wwv_flow_imp.g_varchar2_table(729) := 'val);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by';
wwv_flow_imp.g_varchar2_table(730) := ' := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_num';
wwv_flow_imp.g_varchar2_table(731) := 'ber := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SA';
wwv_flow_imp.g_varchar2_table(732) := 'LES_COMP_THREATS" '||wwv_flow.LF||
'    before insert or update on eba_sales_competitor_threats'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begi';
wwv_flow_imp.g_varchar2_table(733) := 'n'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXX';
wwv_flow_imp.g_varchar2_table(734) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(735) := '        :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(736) := '   :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :n';
wwv_flow_imp.g_varchar2_table(737) := 'ew.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timesta';
wwv_flow_imp.g_varchar2_table(738) := 'mp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.';
wwv_flow_imp.g_varchar2_table(739) := 'row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BD_EBA_SALES_LEADS" '||wwv_flow.LF||
'    b';
wwv_flow_imp.g_varchar2_table(740) := 'efore delete on eba_sales_leads'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba_sales_fw.tag_sync('||wwv_flow.LF||
'        p_new_tags';
wwv_flow_imp.g_varchar2_table(741) := '     => null,'||wwv_flow.LF||
'        p_old_tags     => :old.tags,'||wwv_flow.LF||
'        p_content_type => ''LEAD'','||wwv_flow.LF||
'        p_conte';
wwv_flow_imp.g_varchar2_table(742) := 'nt_id   => :old.id'||wwv_flow.LF||
'    );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_LEADS" '||wwv_flow.LF||
'    before insert';
wwv_flow_imp.g_varchar2_table(743) := ' or update on eba_sales_leads'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'        if :new.id i';
wwv_flow_imp.g_varchar2_table(744) := 's null '||wwv_flow.LF||
'        then'||wwv_flow.LF||
'        :new.id := to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(745) := '       end if;'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'        :new.row_key := eba_sales_fw.compress_i';
wwv_flow_imp.g_varchar2_table(746) := 'nt(eba_sales_rowkey_seq.nextval);'||wwv_flow.LF||
'        :new.created_by := nvl(apex_application.g_user, user);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(747) := '     :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(apex_application.g_user, user';
wwv_flow_imp.g_varchar2_table(748) := ');'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'    elsif updating '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'        :new.updated_by :';
wwv_flow_imp.g_varchar2_table(749) := '= nvl(apex_application.g_user, user);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_ve';
wwv_flow_imp.g_varchar2_table(750) := 'rsion_number := nvl(:old.row_version_number, 1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.tags is not null '||wwv_flow.LF||
'    t';
wwv_flow_imp.g_varchar2_table(751) := 'hen'||wwv_flow.LF||
'        :new.tags := eba_sales_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    eba_sales_fw.tag_sync';
wwv_flow_imp.g_varchar2_table(752) := '('||wwv_flow.LF||
'        p_new_tags     => :new.tags,'||wwv_flow.LF||
'        p_old_tags     => :old.tags,'||wwv_flow.LF||
'        p_content_type =';
wwv_flow_imp.g_varchar2_table(753) := '> ''LEAD'','||wwv_flow.LF||
'        p_content_id   => :new.id'||wwv_flow.LF||
'    );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "biu_eba_sales_';
wwv_flow_imp.g_varchar2_table(754) := 'product_families" '||wwv_flow.LF||
'    before insert or update on eba_sales_product_families'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(755) := '    if :new.id is null then'||wwv_flow.LF||
'        :new.id := eba_sales_acl_api.gen_id();'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if insert';
wwv_flow_imp.g_varchar2_table(756) := 'ing then'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(apex_application.';
wwv_flow_imp.g_varchar2_table(757) := 'g_user,user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(apex_app';
wwv_flow_imp.g_varchar2_table(758) := 'lication.g_user,user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_TERR_MAP" '||wwv_flow.LF||
'    before insert';
wwv_flow_imp.g_varchar2_table(759) := ' or update on EBA_SALES_TERR_MAP'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new."ID" is null then'||wwv_flow.LF||
'        select';
wwv_flow_imp.g_varchar2_table(760) := ' to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if';
wwv_flow_imp.g_varchar2_table(761) := ' inserting then'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(wwv_flow.g';
wwv_flow_imp.g_varchar2_table(762) := '_user,user);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(wwv_flow.g_us';
wwv_flow_imp.g_varchar2_table(763) := 'er,user);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.row_version_num';
wwv_flow_imp.g_varchar2_table(764) := 'ber := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting or updating then'||wwv_flow.LF||
'        :ne';
wwv_flow_imp.g_varchar2_table(765) := 'w.updated := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'en';
wwv_flow_imp.g_varchar2_table(766) := 'd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_SALESREPS" '||wwv_flow.LF||
'    before insert or update on eba_sales_';
wwv_flow_imp.g_varchar2_table(767) := 'salesreps'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        select to_number(';
wwv_flow_imp.g_varchar2_table(768) := 'sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting ';
wwv_flow_imp.g_varchar2_table(769) := 'then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(770) := '        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(771) := '   :new.row_key := eba_sales_fw.compress_int(eba_sales_rowkey_seq.nextval);'||wwv_flow.LF||
'        :new.row_version';
wwv_flow_imp.g_varchar2_table(772) := '_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(773) := '       :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_nu';
wwv_flow_imp.g_varchar2_table(774) := 'mber,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_LEAD_SOURCES" '||wwv_flow.LF||
'    before ';
wwv_flow_imp.g_varchar2_table(775) := 'insert or update on eba_sales_lead_sources'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :';
wwv_flow_imp.g_varchar2_table(776) := 'NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(777) := '          into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.CREATED := current_time';
wwv_flow_imp.g_varchar2_table(778) := 'stamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp';
wwv_flow_imp.g_varchar2_table(779) := ';'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end ';
wwv_flow_imp.g_varchar2_table(780) := 'if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v';
wwv_flow_imp.g_varchar2_table(781) := '(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end i';
wwv_flow_imp.g_varchar2_table(782) := 'f;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_FIN_ASSESSMENTS" '||wwv_flow.LF||
'    before insert or update on';
wwv_flow_imp.g_varchar2_table(783) := ' eba_sales_fin_assessments'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :NEW.ID is null t';
wwv_flow_imp.g_varchar2_table(784) := 'hen'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :';
wwv_flow_imp.g_varchar2_table(785) := 'new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'        :';
wwv_flow_imp.g_varchar2_table(786) := 'NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(787) := '   :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updat';
wwv_flow_imp.g_varchar2_table(788) := 'ing then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USE';
wwv_flow_imp.g_varchar2_table(789) := 'R);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'creat';
wwv_flow_imp.g_varchar2_table(790) := 'e or replace TRIGGER "EBA_SALES_CLICKS_BIU" '||wwv_flow.LF||
'    before insert on eba_sales_clicks'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(791) := 'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        :new.id := eba_sales_acl_api.gen_id();'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :ne';
wwv_flow_imp.g_varchar2_table(792) := 'w.view_timestamp := current_timestamp;'||wwv_flow.LF||
'    :new.app_session := v(''APP_SESSION'');'||wwv_flow.LF||
'    :new.app_userna';
wwv_flow_imp.g_varchar2_table(793) := 'me := lower(:new.app_username);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BD_EBA_SALES_CUST_CONTACTS" '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(794) := 'before delete on eba_sales_customer_contacts'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba_sales_fw.tag_sync('||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(795) := '   p_new_tags     => null,'||wwv_flow.LF||
'        p_old_tags     => :old.tags,'||wwv_flow.LF||
'        p_content_type => ''CONTACT'',';
wwv_flow_imp.g_varchar2_table(796) := ''||wwv_flow.LF||
'        p_content_id   => :old.id'||wwv_flow.LF||
'    );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_CUST_CONT';
wwv_flow_imp.g_varchar2_table(797) := 'ACTS" '||wwv_flow.LF||
'    before insert or update on eba_sales_customer_contacts'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inse';
wwv_flow_imp.g_varchar2_table(798) := 'rting '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            :new.id := to_number(sys_guid(), ''XXXXXX';
wwv_flow_imp.g_varchar2_table(799) := 'XXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'        :new.row';
wwv_flow_imp.g_varchar2_table(800) := '_key := eba_sales_fw.compress_int(eba_sales_rowkey_seq.nextval);'||wwv_flow.LF||
'        :new.created_by := nvl(apex';
wwv_flow_imp.g_varchar2_table(801) := '_application.g_user, user);'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nv';
wwv_flow_imp.g_varchar2_table(802) := 'l(apex_application.g_user, user);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'    elsif updating then';
wwv_flow_imp.g_varchar2_table(803) := ''||wwv_flow.LF||
'        :new.updated_by := nvl(apex_application.g_user, user);'||wwv_flow.LF||
'        :new.updated := current_time';
wwv_flow_imp.g_varchar2_table(804) := 'stamp;'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number, 1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :n';
wwv_flow_imp.g_varchar2_table(805) := 'ew.tags is not null then'||wwv_flow.LF||
'        :new.tags := eba_sales_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(806) := 'eba_sales_fw.tag_sync('||wwv_flow.LF||
'        p_new_tags     => :new.tags,'||wwv_flow.LF||
'        p_old_tags     => :old.tags,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(807) := '     p_content_type => ''CONTACT'','||wwv_flow.LF||
'        p_content_id   => :new.id'||wwv_flow.LF||
'    );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace';
wwv_flow_imp.g_varchar2_table(808) := ' TRIGGER "BIU_EBA_EBA_SALES_ACT_COMPET" '||wwv_flow.LF||
'    before insert or update on eba_sales_act_competition'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(809) := '  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :NEW.ID is null then'||wwv_flow.LF||
'            select to_num';
wwv_flow_imp.g_varchar2_table(810) := 'ber(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dua';
wwv_flow_imp.g_varchar2_table(811) := 'l;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_';
wwv_flow_imp.g_varchar2_table(812) := 'USER''),USER);'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_ti';
wwv_flow_imp.g_varchar2_table(813) := 'mestamp;'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED';
wwv_flow_imp.g_varchar2_table(814) := ' := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_';
wwv_flow_imp.g_varchar2_table(815) := 'number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA';
wwv_flow_imp.g_varchar2_table(816) := '_SALES_SUPRT_AMT_TYPES" '||wwv_flow.LF||
'    before insert or update on EBA_SALES_SUPRT_AMT_TYPES'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'b';
wwv_flow_imp.g_varchar2_table(817) := 'egin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''';
wwv_flow_imp.g_varchar2_table(818) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end i';
wwv_flow_imp.g_varchar2_table(819) := 'f;'||wwv_flow.LF||
'        :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(820) := '      :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(821) := ' :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := current_time';
wwv_flow_imp.g_varchar2_table(822) := 'stamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:o';
wwv_flow_imp.g_varchar2_table(823) := 'ld.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_TZ_PREF" ';
wwv_flow_imp.g_varchar2_table(824) := ''||wwv_flow.LF||
'    before insert or update on eba_sales_tz_pref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new."ID" is null th';
wwv_flow_imp.g_varchar2_table(825) := 'en'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(826) := '   end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by ';
wwv_flow_imp.g_varchar2_table(827) := ':= nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := ';
wwv_flow_imp.g_varchar2_table(828) := 'nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :ne';
wwv_flow_imp.g_varchar2_table(829) := 'w.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting or updating';
wwv_flow_imp.g_varchar2_table(830) := ' then'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(wwv_flow.g_user,user';
wwv_flow_imp.g_varchar2_table(831) := ');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.TIMEZONE_PREFERENCE is null then'||wwv_flow.LF||
'        :new.timezone_preference := ''UTC';
wwv_flow_imp.g_varchar2_table(832) := ''';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_CUST_SPT_AMT_MAP" '||wwv_flow.LF||
'    before insert';
wwv_flow_imp.g_varchar2_table(833) := ' or update on EBA_SALES_CUST_SPT_AMT_MAP'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :NE';
wwv_flow_imp.g_varchar2_table(834) := 'W.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(835) := '        into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.CREATED := current_timest';
wwv_flow_imp.g_varchar2_table(836) := 'amp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''';
wwv_flow_imp.g_varchar2_table(837) := '),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if';
wwv_flow_imp.g_varchar2_table(838) := ';'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''';
wwv_flow_imp.g_varchar2_table(839) := 'APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;';
wwv_flow_imp.g_varchar2_table(840) := ''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_ACCOUNT_STANDING" '||wwv_flow.LF||
'    before insert or update on ';
wwv_flow_imp.g_varchar2_table(841) := 'eba_sales_account_standing'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :NEW.ID is null t';
wwv_flow_imp.g_varchar2_table(842) := 'hen'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :';
wwv_flow_imp.g_varchar2_table(843) := 'new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'        :';
wwv_flow_imp.g_varchar2_table(844) := 'NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(845) := '   :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updat';
wwv_flow_imp.g_varchar2_table(846) := 'ing then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USE';
wwv_flow_imp.g_varchar2_table(847) := 'R);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'creat';
wwv_flow_imp.g_varchar2_table(848) := 'e or replace TRIGGER "BIU_EBA_SALES_LINKS" '||wwv_flow.LF||
'    before insert or update on EBA_SALES_links'||wwv_flow.LF||
'    for e';
wwv_flow_imp.g_varchar2_table(849) := 'ach row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new."ID" is null then'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(850) := 'XXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := cu';
wwv_flow_imp.g_varchar2_table(851) := 'rrent_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'        :new.updated := curre';
wwv_flow_imp.g_varchar2_table(852) := 'nt_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'        :new.row_version_number ';
wwv_flow_imp.g_varchar2_table(853) := ':= 1;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;';
wwv_flow_imp.g_varchar2_table(854) := ''||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting or updating then'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :n';
wwv_flow_imp.g_varchar2_table(855) := 'ew.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_S';
wwv_flow_imp.g_varchar2_table(856) := 'ALES_STATES" '||wwv_flow.LF||
'   before insert or update on EBA_SALES_STATES'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new."ID" i';
wwv_flow_imp.g_varchar2_table(857) := 's null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from d';
wwv_flow_imp.g_varchar2_table(858) := 'ual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'       :new.created_b';
wwv_flow_imp.g_varchar2_table(859) := 'y := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := ';
wwv_flow_imp.g_varchar2_table(860) := 'nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.r';
wwv_flow_imp.g_varchar2_table(861) := 'ow_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then';
wwv_flow_imp.g_varchar2_table(862) := ''||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   e';
wwv_flow_imp.g_varchar2_table(863) := 'nd if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger "EBA_SALES_NOTE_BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_AGREEMENT_T';
wwv_flow_imp.g_varchar2_table(864) := 'YPES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_HISTORY" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_DEAL_ST';
wwv_flow_imp.g_varchar2_table(865) := 'AGES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_AGREEMENTS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_SALES_PREFEREN';
wwv_flow_imp.g_varchar2_table(866) := 'CES_BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_PRODUCT_LOBS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES';
wwv_flow_imp.g_varchar2_table(867) := '_DEALS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BD_EBA_SALES_DEALS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_EBA_SALES_DEAL';
wwv_flow_imp.g_varchar2_table(868) := '_COMPET" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_SALES_VERIFY_BIU_FER" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_D';
wwv_flow_imp.g_varchar2_table(869) := 'EAL_PRODUCTS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_DEAL_STAT_CODES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_E';
wwv_flow_imp.g_varchar2_table(870) := 'BA_SALES_SALESREP_ROLES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_SVPS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_E';
wwv_flow_imp.g_varchar2_table(871) := 'BA_SALES_CUST" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BD_EBA_SALES_CUST" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_CO';
wwv_flow_imp.g_varchar2_table(872) := 'MMENTS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_RISK_ASSESSMENTS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SA';
wwv_flow_imp.g_varchar2_table(873) := 'LES_STATUS_ASSESS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_COMPETITORS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BD_E';
wwv_flow_imp.g_varchar2_table(874) := 'BA_SALES_COMPETITORS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_TERRITORY_ACL" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger ';
wwv_flow_imp.g_varchar2_table(875) := '"BIU_EBA_SALES_DEAL_TEAM" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_SALES_USERS_BD" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_';
wwv_flow_imp.g_varchar2_table(876) := 'SALES_USERS_BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_COUNTRIES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_';
wwv_flow_imp.g_varchar2_table(877) := 'SALES_INDUSTRIES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_TERMS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BD_EBA_SALE';
wwv_flow_imp.g_varchar2_table(878) := 'S_TERR" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_TERR" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_SUPPORT_';
wwv_flow_imp.g_varchar2_table(879) := 'AMTS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_CURRENCIES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_CUST';
wwv_flow_imp.g_varchar2_table(880) := '_AGRMNT_MAP" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_SALES_PERIODS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_SALE';
wwv_flow_imp.g_varchar2_table(881) := 'S_ERRORS_BI" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_TAGS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BD_EBA_SALES_PROD';
wwv_flow_imp.g_varchar2_table(882) := 'UCTS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_PRODUCTS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_FILES"';
wwv_flow_imp.g_varchar2_table(883) := ' ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_CUSTOMERS_LOCS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_COMP_';
wwv_flow_imp.g_varchar2_table(884) := 'THREATS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BD_EBA_SALES_LEADS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_LEADS" ';
wwv_flow_imp.g_varchar2_table(885) := 'ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "biu_eba_sales_product_families" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_TERR';
wwv_flow_imp.g_varchar2_table(886) := '_MAP" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_SALESREPS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_LEAD_';
wwv_flow_imp.g_varchar2_table(887) := 'SOURCES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_FIN_ASSESSMENTS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_SALES_';
wwv_flow_imp.g_varchar2_table(888) := 'CLICKS_BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BD_EBA_SALES_CUST_CONTACTS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SA';
wwv_flow_imp.g_varchar2_table(889) := 'LES_CUST_CONTACTS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_EBA_SALES_ACT_COMPET" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "B';
wwv_flow_imp.g_varchar2_table(890) := 'IU_EBA_SALES_SUPRT_AMT_TYPES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_TZ_PREF" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigge';
wwv_flow_imp.g_varchar2_table(891) := 'r "BIU_EBA_SALES_CUST_SPT_AMT_MAP" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_ACCOUNT_STANDING" ENABLE;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(892) := '/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_LINKS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_SALES_STATES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- R';
wwv_flow_imp.g_varchar2_table(893) := 'ecreate views'||wwv_flow.LF||
'CREATE OR REPLACE FORCE VIEW "EBA_SALES_OPPORTUNITIES_V" ("ID", "ROW_KEY", "CUSTOMER_I';
wwv_flow_imp.g_varchar2_table(894) := 'D", "CUSTOMER_NAME", "REP_NAME", "DEAL_NAME", "DEAL_CLOSE_DATE", "DEAL_CLOSE_DATE_ALT", "DEAL_AMOUNT';
wwv_flow_imp.g_varchar2_table(895) := '", "DEAL_PROBABILITY", "STATUS_CODE", "IS_OPEN", "IS_OVERDUE", "WEIGHTED_FORECAST", "NOTES", "PRODUC';
wwv_flow_imp.g_varchar2_table(896) := 'TS", "LAST_CHANGED", "SVP", "TERRITORY_NAME", "QTR", "TAGS", "CUSTOMER_TAGS") AS '||wwv_flow.LF||
'  select d.id, '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(897) := '  d.row_key,'||wwv_flow.LF||
'    c.id customer_id,'||wwv_flow.LF||
'    c.customer_name,'||wwv_flow.LF||
'    s.rep_last_name || '', '' || s.rep_first_n';
wwv_flow_imp.g_varchar2_table(898) := 'ame as rep_name,'||wwv_flow.LF||
'    d.deal_name,'||wwv_flow.LF||
'    d.deal_close_date,'||wwv_flow.LF||
'    d.deal_close_date_alt,'||wwv_flow.LF||
'    d.deal_amoun';
wwv_flow_imp.g_varchar2_table(899) := 't,'||wwv_flow.LF||
'    d.deal_probability,'||wwv_flow.LF||
'    sc.status_code,'||wwv_flow.LF||
'    case'||wwv_flow.LF||
'      when d.deal_probability is null '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(900) := '   or d.deal_probability in (0, 100)'||wwv_flow.LF||
'      then ''No'''||wwv_flow.LF||
'      else ''Yes'''||wwv_flow.LF||
'    end is_open,'||wwv_flow.LF||
'    case '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(901) := '   when d.deal_probability in (0, 100)'||wwv_flow.LF||
'      then ''No'''||wwv_flow.LF||
'      when greatest(sysdate, d.deal_close_dat';
wwv_flow_imp.g_varchar2_table(902) := 'e) = sysdate'||wwv_flow.LF||
'      then ''Yes'''||wwv_flow.LF||
'      else ''No'''||wwv_flow.LF||
'    end is_overdue,'||wwv_flow.LF||
'    d.deal_amount * d.deal_probabi';
wwv_flow_imp.g_varchar2_table(903) := 'lity / 100 weighted_forecast,'||wwv_flow.LF||
'    ('||wwv_flow.LF||
'      select count(*) '||wwv_flow.LF||
'      from eba_sales_comments '||wwv_flow.LF||
'      wher';
wwv_flow_imp.g_varchar2_table(904) := 'e deal_id = d.id'||wwv_flow.LF||
'    ) notes,'||wwv_flow.LF||
'    ('||wwv_flow.LF||
'      select count(*) '||wwv_flow.LF||
'      from eba_sales_deal_products '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(905) := ' where deal_id = d.id'||wwv_flow.LF||
'    ) products,'||wwv_flow.LF||
'    nvl(d.updated, d.created) last_changed,'||wwv_flow.LF||
'    ('||wwv_flow.LF||
'      select';
wwv_flow_imp.g_varchar2_table(906) := ' svp_name '||wwv_flow.LF||
'      from eba_sales_svps svp '||wwv_flow.LF||
'      where svp.id = d.svp_id'||wwv_flow.LF||
'    ) svp,'||wwv_flow.LF||
'    t.territory_n';
wwv_flow_imp.g_varchar2_table(907) := 'ame,'||wwv_flow.LF||
'    d.qtr,'||wwv_flow.LF||
'    d.tags,'||wwv_flow.LF||
'    c.tags customer_tags'||wwv_flow.LF||
'  from eba_sales_deals d'||wwv_flow.LF||
'  join eba_sales_custo';
wwv_flow_imp.g_varchar2_table(908) := 'mers c'||wwv_flow.LF||
'    on c.id = d.customer_id '||wwv_flow.LF||
'  left join eba_sales_salesreps s'||wwv_flow.LF||
'    on s.id = d.salesrep_id_01';
wwv_flow_imp.g_varchar2_table(909) := ''||wwv_flow.LF||
'  left join eba_sales_deal_status_codes sc'||wwv_flow.LF||
'    on sc.id = d.deal_status_code_id'||wwv_flow.LF||
'  left join eba_sal';
wwv_flow_imp.g_varchar2_table(910) := 'es_territories t'||wwv_flow.LF||
'    on t.id = c.customer_territory_id'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE FORCE VIEW "EBA_SALES_OP';
wwv_flow_imp.g_varchar2_table(911) := 'P_V" ("CUSTOMER_ID", "DEAL_ID", "CUSTOMER_NAME", "CUSTOMER_STOCK_SYMB", "REP_FIRST_NAME", "REP_LAST_';
wwv_flow_imp.g_varchar2_table(912) := 'NAME", "REP_EMAIL", "DEAL_NAME", "DEAL_CLOSE_DATE", "DEAL_AMOUNT", "DEAL_PROBABILITY", "STATUS_CODE"';
wwv_flow_imp.g_varchar2_table(913) := ') AS '||wwv_flow.LF||
'  select c.id customer_id,'||wwv_flow.LF||
'    d.id deal_id,'||wwv_flow.LF||
'    c.customer_name,'||wwv_flow.LF||
'    c.customer_stock_symb,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(914) := '   sr.rep_first_name,'||wwv_flow.LF||
'    sr.rep_last_name,'||wwv_flow.LF||
'    sr.rep_email,'||wwv_flow.LF||
'    d.deal_name,'||wwv_flow.LF||
'    d.deal_close_date';
wwv_flow_imp.g_varchar2_table(915) := ','||wwv_flow.LF||
'    case when exists (select null'||wwv_flow.LF||
'                        from APEX_APPLICATION_BUILD_OPTIONS'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(916) := '                   where application_id = v(''APP_ID'')'||wwv_flow.LF||
'                         and BUILD_OPTION_NAME';
wwv_flow_imp.g_varchar2_table(917) := ' = ''Opportunity Amount Set at Product Level'''||wwv_flow.LF||
'                         and BUILD_OPTION_STATUS = ''Exc';
wwv_flow_imp.g_varchar2_table(918) := 'lude'') then'||wwv_flow.LF||
'        d.deal_amount'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        (select sum(nvl(quote_price, 0.00)) from EBA_SALE';
wwv_flow_imp.g_varchar2_table(919) := 'S_DEAL_PRODUCTS dp where dp.deal_id = d.id)'||wwv_flow.LF||
'    end as deal_amount,'||wwv_flow.LF||
'    d.deal_probability,'||wwv_flow.LF||
'    dsc.';
wwv_flow_imp.g_varchar2_table(920) := 'status_code '||wwv_flow.LF||
'  from  eba_sales_deals d'||wwv_flow.LF||
'  join eba_sales_deal_status_codes dsc'||wwv_flow.LF||
'    on dsc.id = d.deal';
wwv_flow_imp.g_varchar2_table(921) := '_status_code_id'||wwv_flow.LF||
'  join eba_sales_salesreps sr'||wwv_flow.LF||
'    on sr.id = d.salesrep_id_01'||wwv_flow.LF||
'  join eba_sales_custo';
wwv_flow_imp.g_varchar2_table(922) := 'mers c'||wwv_flow.LF||
'    on c.id = d.customer_id'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Tables Changed: 51'||wwv_flow.LF||
'-- Columns Changed: 166'||wwv_flow.LF||
'-- Triggers Cha';
wwv_flow_imp.g_varchar2_table(923) := 'nged: 59'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(451973872160777102)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'TIMESTAMP Fix (BUGID: 31352674)'
,p_sequence=>260
,p_script_type=>'UPGRADE'
,p_condition_type=>'EXISTS'
,p_condition=>'select null from all_tab_cols where table_name like ''EBA_SALES_%'' and data_type = ''TIMESTAMP(6) WITH LOCAL TIME ZONE'''
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
