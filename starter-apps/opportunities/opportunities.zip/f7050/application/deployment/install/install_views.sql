prompt --application/deployment/install/install_views
begin
--   Manifest
--     INSTALL: INSTALL-views
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE OR REPLACE FORCE VIEW "EBA_SALES_OPPORTUNITIES_V" ("ID", "ROW_KEY", "CUSTOMER_ID", "CUSTOMER_';
wwv_flow_imp.g_varchar2_table(2) := 'NAME", "REP_NAME", "DEAL_NAME", "DEAL_CLOSE_DATE", "DEAL_CLOSE_DATE_ALT", "DEAL_AMOUNT", "DEAL_PROBA';
wwv_flow_imp.g_varchar2_table(3) := 'BILITY", "STATUS_CODE", "IS_OPEN", "IS_OVERDUE", "WEIGHTED_FORECAST", "NOTES", "PRODUCTS", "LAST_CHA';
wwv_flow_imp.g_varchar2_table(4) := 'NGED", "SVP", "TERRITORY_NAME", "QTR", "TAGS", "CUSTOMER_TAGS") AS '||wwv_flow.LF||
'  select d.id, '||wwv_flow.LF||
'    d.row_key,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(5) := '   c.id customer_id,'||wwv_flow.LF||
'    c.customer_name,'||wwv_flow.LF||
'    s.rep_last_name || '', '' || s.rep_first_name as rep_nam';
wwv_flow_imp.g_varchar2_table(6) := 'e,'||wwv_flow.LF||
'    d.deal_name,'||wwv_flow.LF||
'    d.deal_close_date,'||wwv_flow.LF||
'    d.deal_close_date_alt,'||wwv_flow.LF||
'    d.deal_amount,'||wwv_flow.LF||
'    d.deal_';
wwv_flow_imp.g_varchar2_table(7) := 'probability,'||wwv_flow.LF||
'    sc.status_code,'||wwv_flow.LF||
'    case'||wwv_flow.LF||
'      when d.deal_probability is null '||wwv_flow.LF||
'        or d.deal_p';
wwv_flow_imp.g_varchar2_table(8) := 'robability in (0, 100)'||wwv_flow.LF||
'      then ''No'''||wwv_flow.LF||
'      else ''Yes'''||wwv_flow.LF||
'    end is_open,'||wwv_flow.LF||
'    case '||wwv_flow.LF||
'      when d.deal';
wwv_flow_imp.g_varchar2_table(9) := '_probability in (0, 100)'||wwv_flow.LF||
'      then ''No'''||wwv_flow.LF||
'      when greatest(sysdate, d.deal_close_date) = sysdate'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(10) := '     then ''Yes'''||wwv_flow.LF||
'      else ''No'''||wwv_flow.LF||
'    end is_overdue,'||wwv_flow.LF||
'    d.deal_amount * d.deal_probability / 100 wei';
wwv_flow_imp.g_varchar2_table(11) := 'ghted_forecast,'||wwv_flow.LF||
'    ('||wwv_flow.LF||
'      select count(*) '||wwv_flow.LF||
'      from eba_sales_comments '||wwv_flow.LF||
'      where deal_id = d.';
wwv_flow_imp.g_varchar2_table(12) := 'id'||wwv_flow.LF||
'    ) notes,'||wwv_flow.LF||
'    ('||wwv_flow.LF||
'      select count(*) '||wwv_flow.LF||
'      from eba_sales_deal_products '||wwv_flow.LF||
'      where deal_id';
wwv_flow_imp.g_varchar2_table(13) := ' = d.id'||wwv_flow.LF||
'    ) products,'||wwv_flow.LF||
'    nvl(d.updated, d.created) last_changed,'||wwv_flow.LF||
'    ('||wwv_flow.LF||
'      select svp_name '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(14) := '   from eba_sales_svps svp '||wwv_flow.LF||
'      where svp.id = d.svp_id'||wwv_flow.LF||
'    ) svp,'||wwv_flow.LF||
'    t.territory_name,'||wwv_flow.LF||
'    d.qtr';
wwv_flow_imp.g_varchar2_table(15) := ','||wwv_flow.LF||
'    d.tags,'||wwv_flow.LF||
'    c.tags customer_tags'||wwv_flow.LF||
'  from eba_sales_deals d'||wwv_flow.LF||
'  join eba_sales_customers c'||wwv_flow.LF||
'    on ';
wwv_flow_imp.g_varchar2_table(16) := 'c.id = d.customer_id '||wwv_flow.LF||
'  left join eba_sales_salesreps s'||wwv_flow.LF||
'    on s.id = d.salesrep_id_01'||wwv_flow.LF||
'  left join e';
wwv_flow_imp.g_varchar2_table(17) := 'ba_sales_deal_status_codes sc'||wwv_flow.LF||
'    on sc.id = d.deal_status_code_id'||wwv_flow.LF||
'  left join eba_sales_territories';
wwv_flow_imp.g_varchar2_table(18) := ' t'||wwv_flow.LF||
'    on t.id = c.customer_territory_id'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE FORCE VIEW "EBA_SALES_OPP_V" ("CUSTOME';
wwv_flow_imp.g_varchar2_table(19) := 'R_ID", "DEAL_ID", "CUSTOMER_NAME", "CUSTOMER_STOCK_SYMB", "REP_FIRST_NAME", "REP_LAST_NAME", "REP_EM';
wwv_flow_imp.g_varchar2_table(20) := 'AIL", "DEAL_NAME", "DEAL_CLOSE_DATE", "DEAL_AMOUNT", "DEAL_PROBABILITY", "STATUS_CODE") AS '||wwv_flow.LF||
'  select';
wwv_flow_imp.g_varchar2_table(21) := ' c.id customer_id,'||wwv_flow.LF||
'    d.id deal_id,'||wwv_flow.LF||
'    c.customer_name,'||wwv_flow.LF||
'    c.customer_stock_symb,'||wwv_flow.LF||
'    sr.rep_firs';
wwv_flow_imp.g_varchar2_table(22) := 't_name,'||wwv_flow.LF||
'    sr.rep_last_name,'||wwv_flow.LF||
'    sr.rep_email,'||wwv_flow.LF||
'    d.deal_name,'||wwv_flow.LF||
'    d.deal_close_date,'||wwv_flow.LF||
'    case whe';
wwv_flow_imp.g_varchar2_table(23) := 'n exists (select null'||wwv_flow.LF||
'                        from APEX_APPLICATION_BUILD_OPTIONS'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(24) := '     where application_id = v(''APP_ID'')'||wwv_flow.LF||
'                         and BUILD_OPTION_NAME = ''Opportunit';
wwv_flow_imp.g_varchar2_table(25) := 'y Amount Set at Product Level'''||wwv_flow.LF||
'                         and BUILD_OPTION_STATUS = ''Exclude'') then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(26) := '      d.deal_amount'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        (select sum(nvl(quote_price, 0.00)) from EBA_SALES_DEAL_PRODUCT';
wwv_flow_imp.g_varchar2_table(27) := 'S dp where dp.deal_id = d.id)'||wwv_flow.LF||
'    end as deal_amount,'||wwv_flow.LF||
'    d.deal_probability,'||wwv_flow.LF||
'    dsc.status_code '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(28) := ' from  eba_sales_deals d'||wwv_flow.LF||
'  join eba_sales_deal_status_codes dsc'||wwv_flow.LF||
'    on dsc.id = d.deal_status_code_i';
wwv_flow_imp.g_varchar2_table(29) := 'd'||wwv_flow.LF||
'  join eba_sales_salesreps sr'||wwv_flow.LF||
'    on sr.id = d.salesrep_id_01'||wwv_flow.LF||
'  join eba_sales_customers c'||wwv_flow.LF||
'    on ';
wwv_flow_imp.g_varchar2_table(30) := 'c.id = d.customer_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6816285806373102164)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'views'
,p_sequence=>640
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6816285907446102165)
,p_script_id=>wwv_flow_imp.id(6816285806373102164)
,p_object_owner=>'#OWNER#'
,p_object_type=>'VIEW'
,p_object_name=>'EBA_SALES_OPPORTUNITIES_V'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6816286092877102166)
,p_script_id=>wwv_flow_imp.id(6816285806373102164)
,p_object_owner=>'#OWNER#'
,p_object_type=>'VIEW'
,p_object_name=>'EBA_SALES_OPP_V'
);
wwv_flow_imp.component_end;
end;
/
