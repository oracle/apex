prompt --application/deployment/install/install_eba_sales_lead_status_codes
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_lead_status_codes
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_LEAD_STATUS_CODES" '||wwv_flow.LF||
'   (	"ID" NUMBER, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER, '||wwv_flow.LF||
'	"DISP';
wwv_flow_imp.g_varchar2_table(2) := 'LAY_ORDER" NUMBER, '||wwv_flow.LF||
'	"STATUS_CODE" VARCHAR2(30) NOT NULL ENABLE, '||wwv_flow.LF||
'	"STATUS_DESCRIPTION" VARCHAR2(400';
wwv_flow_imp.g_varchar2_table(3) := '0), '||wwv_flow.LF||
'	 PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814607238437187037)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_lead_status_codes'
,p_sequence=>200
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814607382616187037)
,p_script_id=>wwv_flow_imp.id(6814607238437187037)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_LEAD_STATUS_CODES'
);
wwv_flow_imp.component_end;
end;
/
