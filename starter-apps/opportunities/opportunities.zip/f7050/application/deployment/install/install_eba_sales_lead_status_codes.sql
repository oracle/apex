prompt --application/deployment/install/install_eba_sales_lead_status_codes
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_lead_status_codes
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814607238437187037)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_lead_status_codes'
,p_sequence=>200
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_LEAD_STATUS_CODES" ',
'   (	"ID" NUMBER, ',
'	"ROW_VERSION_NUMBER" NUMBER, ',
'	"DISPLAY_ORDER" NUMBER, ',
'	"STATUS_CODE" VARCHAR2(30) NOT NULL ENABLE, ',
'	"STATUS_DESCRIPTION" VARCHAR2(4000), ',
'	 PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814607382616187037)
,p_script_id=>wwv_flow_imp.id(6814607238437187037)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_LEAD_STATUS_CODES'
);
wwv_flow_imp.component_end;
end;
/
