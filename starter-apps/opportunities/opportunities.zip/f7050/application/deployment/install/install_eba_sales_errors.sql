prompt --application/deployment/install/install_eba_sales_errors
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_errors
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6796871059036358967)
,p_install_id=>wwv_flow_imp.id(10495272006180774354)
,p_name=>'eba_sales_errors'
,p_sequence=>330
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_ERRORS" ',
'   (	"ID" NUMBER NOT NULL ENABLE, ',
'	"ERR_TIME" TIMESTAMP (6) WITH TIME ZONE DEFAULT current_timestamp NOT NULL ENABLE, ',
'	"APP_ID" NUMBER, ',
'	"APP_PAGE_ID" NUMBER, ',
'	"APP_USER" VARCHAR2(512), ',
'	"USER_AGENT" VARCHAR2(4000), ',
'	"IP_ADDRESS" VARCHAR2(512), ',
'	"IP_ADDRESS2" VARCHAR2(512), ',
'	"MESSAGE" VARCHAR2(4000), ',
'	"PAGE_ITEM_NAME" VARCHAR2(255), ',
'	"REGION_ID" NUMBER, ',
'	"COLUMN_ALIAS" VARCHAR2(255), ',
'	"ROW_NUM" NUMBER, ',
'	"APEX_ERROR_CODE" VARCHAR2(255), ',
'	"ORA_SQLCODE" NUMBER, ',
'	"ORA_SQLERRM" VARCHAR2(4000), ',
'	"ERROR_BACKTRACE" VARCHAR2(4000), ',
'	 CONSTRAINT "EBA_SALES_ERRORS_PK" PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6796871215297358968)
,p_script_id=>wwv_flow_imp.id(6796871059036358967)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_ERRORS'
);
wwv_flow_imp.component_end;
end;
/
