prompt --application/deployment/install/install_eba_sales_errors
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_errors
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_ERRORS" '||wwv_flow.LF||
'   (	"ID" NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'	"ERR_TIME" TIMESTAMP (6) WITH T';
wwv_flow_imp.g_varchar2_table(2) := 'IME ZONE DEFAULT current_timestamp NOT NULL ENABLE, '||wwv_flow.LF||
'	"APP_ID" NUMBER, '||wwv_flow.LF||
'	"APP_PAGE_ID" NUMBER, '||wwv_flow.LF||
'	"AP';
wwv_flow_imp.g_varchar2_table(3) := 'P_USER" VARCHAR2(512), '||wwv_flow.LF||
'	"USER_AGENT" VARCHAR2(4000), '||wwv_flow.LF||
'	"IP_ADDRESS" VARCHAR2(512), '||wwv_flow.LF||
'	"IP_ADDRESS2" ';
wwv_flow_imp.g_varchar2_table(4) := 'VARCHAR2(512), '||wwv_flow.LF||
'	"MESSAGE" VARCHAR2(4000), '||wwv_flow.LF||
'	"PAGE_ITEM_NAME" VARCHAR2(255), '||wwv_flow.LF||
'	"REGION_ID" NUMBER, '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(5) := '	"COLUMN_ALIAS" VARCHAR2(255), '||wwv_flow.LF||
'	"ROW_NUM" NUMBER, '||wwv_flow.LF||
'	"APEX_ERROR_CODE" VARCHAR2(255), '||wwv_flow.LF||
'	"ORA_SQLCODE';
wwv_flow_imp.g_varchar2_table(6) := '" NUMBER, '||wwv_flow.LF||
'	"ORA_SQLERRM" VARCHAR2(4000), '||wwv_flow.LF||
'	"ERROR_BACKTRACE" VARCHAR2(4000), '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SAL';
wwv_flow_imp.g_varchar2_table(7) := 'ES_ERRORS_PK" PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814593250997112370)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_errors'
,p_sequence=>330
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814593407258112371)
,p_script_id=>wwv_flow_imp.id(6814593250997112370)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_ERRORS'
);
wwv_flow_imp.component_end;
end;
/
