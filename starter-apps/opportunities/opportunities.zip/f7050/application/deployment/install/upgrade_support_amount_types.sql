prompt --application/deployment/install/upgrade_support_amount_types
begin
--   Manifest
--     INSTALL: UPGRADE-SUPPORT AMOUNT TYPES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_SUPRT_AMT_TYPES"'||wwv_flow.LF||
'('||wwv_flow.LF||
'    "ID" NUMBER,'||wwv_flow.LF||
'    "ROW_VERSION_NUMBER" NUMBER,'||wwv_flow.LF||
'    "NA';
wwv_flow_imp.g_varchar2_table(2) := 'ME" VARCHAR2(255),'||wwv_flow.LF||
'    "DESCRIPTION" VARCHAR2(4000),'||wwv_flow.LF||
'    "CREATED_BY" VARCHAR2(255),'||wwv_flow.LF||
'    "CREATED" T';
wwv_flow_imp.g_varchar2_table(3) := 'IMESTAMP (6) WITH TIME ZONE,'||wwv_flow.LF||
'    "UPDATED_BY" VARCHAR2(255),'||wwv_flow.LF||
'    "UPDATED" TIMESTAMP (6) WITH TIME Z';
wwv_flow_imp.g_varchar2_table(4) := 'ONE,'||wwv_flow.LF||
'     PRIMARY KEY ("ID")  USING INDEX  ENABLE'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE UNIQUE INDEX "EBA_SALES_SUPRT_AMT_TYPES';
wwv_flow_imp.g_varchar2_table(5) := '_UK" ON "EBA_SALES_SUPRT_AMT_TYPES" ("NAME");'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER "BIU_EBA_SALES_SUPRT_AMT_TY';
wwv_flow_imp.g_varchar2_table(6) := 'PES" '||wwv_flow.LF||
'   before insert or update on EBA_SALES_SUPRT_AMT_TYPES'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inse';
wwv_flow_imp.g_varchar2_table(7) := 'rting then'||wwv_flow.LF||
'         if :NEW.ID is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(8) := 'XXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'           into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREA';
wwv_flow_imp.g_varchar2_table(9) := 'TED := current_timestamp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.updated';
wwv_flow_imp.g_varchar2_table(10) := '_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.updated := current_timestamp;'||wwv_flow.LF||
'         :new.row_versio';
wwv_flow_imp.g_varchar2_table(11) := 'n_number := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(12) := '     :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:old.row_ve';
wwv_flow_imp.g_varchar2_table(13) := 'rsion_number,1) + 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TRIGGER "BIU_EBA_SALES_SUPRT_AMT_TYPES" ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'in';
wwv_flow_imp.g_varchar2_table(14) := 'sert into EBA_SALES_SUPRT_AMT_TYPES (name) values (''Applications'');'||wwv_flow.LF||
'insert into EBA_SALES_SUPRT_AMT_';
wwv_flow_imp.g_varchar2_table(15) := 'TYPES (name) values (''Technology'');'||wwv_flow.LF||
'insert into EBA_SALES_SUPRT_AMT_TYPES (name) values (''Hardware'')';
wwv_flow_imp.g_varchar2_table(16) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'commit;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8473762438381176390)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'SUPPORT AMOUNT TYPES'
,p_sequence=>170
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_SALES_SUPRT_AMT_TYPES'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
