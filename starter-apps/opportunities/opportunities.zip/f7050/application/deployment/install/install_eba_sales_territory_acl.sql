prompt --application/deployment/install/install_eba_sales_territory_acl
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_territory_acl
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_TERRITORY_ACL" '||wwv_flow.LF||
'   (	"ID" NUMBER, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER, '||wwv_flow.LF||
'	"ROW_KEY"';
wwv_flow_imp.g_varchar2_table(2) := ' VARCHAR2(255), '||wwv_flow.LF||
'	"TERRITORY_ID" NUMBER, '||wwv_flow.LF||
'	"USERID" VARCHAR2(255) NOT NULL ENABLE, '||wwv_flow.LF||
'	"ACL_COMMENTS" ';
wwv_flow_imp.g_varchar2_table(3) := 'VARCHAR2(4000), '||wwv_flow.LF||
'	"CREATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"UPDATED_B';
wwv_flow_imp.g_varchar2_table(4) := 'Y" VARCHAR2(255), '||wwv_flow.LF||
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_01" VARCHAR2(255), '||wwv_flow.LF||
'	"FLEX_02" V';
wwv_flow_imp.g_varchar2_table(5) := 'ARCHAR2(255), '||wwv_flow.LF||
'	"FLEX_03" VARCHAR2(255), '||wwv_flow.LF||
'	"FLEX_04" VARCHAR2(255), '||wwv_flow.LF||
'	"FLEX_05" VARCHAR2(255), '||wwv_flow.LF||
'	"FL';
wwv_flow_imp.g_varchar2_table(6) := 'EX_06" VARCHAR2(255), '||wwv_flow.LF||
'	"FLEX_07" VARCHAR2(255), '||wwv_flow.LF||
'	"FLEX_08" VARCHAR2(255), '||wwv_flow.LF||
'	"FLEX_09" VARCHAR2(255';
wwv_flow_imp.g_varchar2_table(7) := '), '||wwv_flow.LF||
'	"FLEX_10" VARCHAR2(255), '||wwv_flow.LF||
'	 PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_S';
wwv_flow_imp.g_varchar2_table(8) := 'ALES_TERRITORY_ACL" ADD CONSTRAINT "EBA_SALES_TERR_ACL_FK" FOREIGN KEY ("TERRITORY_ID")'||wwv_flow.LF||
'	  REFERENCE';
wwv_flow_imp.g_varchar2_table(9) := 'S "EBA_SALES_TERRITORIES" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814631476319254039)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_territory_acl'
,p_sequence=>470
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814631533391254040)
,p_script_id=>wwv_flow_imp.id(6814631476319254039)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_TERRITORY_ACL'
);
wwv_flow_imp.component_end;
end;
/
