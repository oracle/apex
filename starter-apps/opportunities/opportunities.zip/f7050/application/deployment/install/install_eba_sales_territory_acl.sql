prompt --application/deployment/install/install_eba_sales_territory_acl
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_territory_acl
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814631476319254039)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_territory_acl'
,p_sequence=>470
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_TERRITORY_ACL" ',
'   (	"ID" NUMBER, ',
'	"ROW_VERSION_NUMBER" NUMBER, ',
'	"ROW_KEY" VARCHAR2(255), ',
'	"TERRITORY_ID" NUMBER, ',
'	"USERID" VARCHAR2(255) NOT NULL ENABLE, ',
'	"ACL_COMMENTS" VARCHAR2(4000), ',
'	"CREATED_BY" VARCHAR2(255), ',
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"UPDATED_BY" VARCHAR2(255), ',
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"FLEX_01" VARCHAR2(255), ',
'	"FLEX_02" VARCHAR2(255), ',
'	"FLEX_03" VARCHAR2(255), ',
'	"FLEX_04" VARCHAR2(255), ',
'	"FLEX_05" VARCHAR2(255), ',
'	"FLEX_06" VARCHAR2(255), ',
'	"FLEX_07" VARCHAR2(255), ',
'	"FLEX_08" VARCHAR2(255), ',
'	"FLEX_09" VARCHAR2(255), ',
'	"FLEX_10" VARCHAR2(255), ',
'	 PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'ALTER TABLE "EBA_SALES_TERRITORY_ACL" ADD CONSTRAINT "EBA_SALES_TERR_ACL_FK" FOREIGN KEY ("TERRITORY_ID")',
'	  REFERENCES "EBA_SALES_TERRITORIES" ("ID") ON DELETE CASCADE ENABLE;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814631533391254040)
,p_script_id=>wwv_flow_imp.id(6814631476319254039)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_TERRITORY_ACL'
);
wwv_flow_imp.component_end;
end;
/
