prompt --application/deployment/install/install_eba_sales_cust_agrmnt_map
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_cust_agrmnt_map
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_CUST_AGRMNT_MAP" '||wwv_flow.LF||
'('||wwv_flow.LF||
'    "ID" NUMBER,'||wwv_flow.LF||
'    "ROW_VERSION_NUMBER" NUMBER,'||wwv_flow.LF||
'    "N';
wwv_flow_imp.g_varchar2_table(2) := 'AME" VARCHAR2(255),'||wwv_flow.LF||
'    "CLOSE_DATE" TIMESTAMP (6) WITH TIME ZONE,'||wwv_flow.LF||
'    "TERM_ID" NUMBER references E';
wwv_flow_imp.g_varchar2_table(3) := 'BA_SALES_TERMS on delete set null,'||wwv_flow.LF||
'    "CUSTOMER_ID" NUMBER references EBA_SALES_CUSTOMERS on delete';
wwv_flow_imp.g_varchar2_table(4) := ' set null,'||wwv_flow.LF||
'    "AGREEMENT_ID" NUMBER references EBA_SALES_AGREEMENTS on delete cascade,'||wwv_flow.LF||
'    "QUOTE_P';
wwv_flow_imp.g_varchar2_table(5) := 'RICE" NUMBER,'||wwv_flow.LF||
'    "DESCRIPTION" VARCHAR2(4000),'||wwv_flow.LF||
'    "CREATED_BY" VARCHAR2(255),'||wwv_flow.LF||
'    "CREATED" TIMEST';
wwv_flow_imp.g_varchar2_table(6) := 'AMP (6) WITH TIME ZONE,'||wwv_flow.LF||
'    "UPDATED_BY" VARCHAR2(255),'||wwv_flow.LF||
'    "UPDATED" TIMESTAMP (6) WITH TIME ZONE,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(7) := '     PRIMARY KEY ("ID")  USING INDEX  ENABLE'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_CUST_AGRMN';
wwv_flow_imp.g_varchar2_table(8) := 'T_MAP" '||wwv_flow.LF||
'   before insert or update on EBA_SALES_CUST_AGRMNT_MAP'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if in';
wwv_flow_imp.g_varchar2_table(9) := 'serting then'||wwv_flow.LF||
'         if :NEW.ID is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(10) := 'XXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'           into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CR';
wwv_flow_imp.g_varchar2_table(11) := 'EATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.updat';
wwv_flow_imp.g_varchar2_table(12) := 'ed_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.updated := current_timestamp;'||wwv_flow.LF||
'         :new.row_vers';
wwv_flow_imp.g_varchar2_table(13) := 'ion_number := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(14) := '       :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:old.row_';
wwv_flow_imp.g_varchar2_table(15) := 'version_number,1) + 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TRIGGER "BIU_EBA_SALES_CUST_AGRMNT_MAP" ENABLE;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6150178853272186268)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_cust_agrmnt_map'
,p_sequence=>540
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
