prompt --application/deployment/install/install_eba_sales_account_standing
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_account_standing
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_ACCOUNT_STANDING" '||wwv_flow.LF||
'   (	"ID" NUMBER, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER, '||wwv_flow.LF||
'	"DISPL';
wwv_flow_imp.g_varchar2_table(2) := 'AY_ORDER" NUMBER, '||wwv_flow.LF||
'	"STANDING_TEXT" VARCHAR2(255) NOT NULL ENABLE, '||wwv_flow.LF||
'	"STANDING_DESCRIPTION" VARCHAR2';
wwv_flow_imp.g_varchar2_table(3) := '(4000), '||wwv_flow.LF||
'	"CREATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"UPDATED_BY" VARCH';
wwv_flow_imp.g_varchar2_table(4) := 'AR2(255), '||wwv_flow.LF||
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	 PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   )';
wwv_flow_imp.g_varchar2_table(5) := ' ;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814501735718885516)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_account_standing'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814501914775885516)
,p_script_id=>wwv_flow_imp.id(6814501735718885516)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_ACCOUNT_STANDING'
);
wwv_flow_imp.component_end;
end;
/
