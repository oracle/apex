prompt --application/deployment/install/install_eba_sales_deal_competition
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_deal_competition
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_DEAL_COMPETITION" '||wwv_flow.LF||
'   (	"ID" NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" ';
wwv_flow_imp.g_varchar2_table(2) := 'NUMBER, '||wwv_flow.LF||
'	"ROW_KEY" VARCHAR2(255), '||wwv_flow.LF||
'	"COMPETITOR_ID" NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'	"DEAL_ID" NUMBER NOT ';
wwv_flow_imp.g_varchar2_table(3) := 'NULL ENABLE, '||wwv_flow.LF||
'	"COMPETITOR_THREAT_ID" NUMBER, '||wwv_flow.LF||
'	"COMPETITION_DESC" VARCHAR2(4000), '||wwv_flow.LF||
'	"CREATED_BY" VA';
wwv_flow_imp.g_varchar2_table(4) := 'RCHAR2(255), '||wwv_flow.LF||
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"UPDATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"UPDATED" TIM';
wwv_flow_imp.g_varchar2_table(5) := 'ESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_01" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_02" VARCHAR';
wwv_flow_imp.g_varchar2_table(6) := '2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_03" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_04" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_F';
wwv_flow_imp.g_varchar2_table(7) := 'LEX_01" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_02" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_03" VARCHAR2(4000), '||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(8) := '"INTERNAL_FLEX_04" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_FLAG_01" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_02" VARCHAR2(30), '||wwv_flow.LF||
'	"';
wwv_flow_imp.g_varchar2_table(9) := 'FLEX_FLAG_03" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_04" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_05" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FL';
wwv_flow_imp.g_varchar2_table(10) := 'AG_06" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_07" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_08" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_01" VARCH';
wwv_flow_imp.g_varchar2_table(11) := 'AR2(4000), '||wwv_flow.LF||
'	"FLEX_02" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_03" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_04" VARCHAR2(4000), '||wwv_flow.LF||
'	"FL';
wwv_flow_imp.g_varchar2_table(12) := 'EX_05" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_06" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_07" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_08" VARCHAR2(';
wwv_flow_imp.g_varchar2_table(13) := '4000), '||wwv_flow.LF||
'	"FLEX_D01" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D02" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX';
wwv_flow_imp.g_varchar2_table(14) := '_D03" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D04" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_N01" NUMBER, ';
wwv_flow_imp.g_varchar2_table(15) := ''||wwv_flow.LF||
'	"FLEX_N02" NUMBER, '||wwv_flow.LF||
'	"FLEX_N03" NUMBER, '||wwv_flow.LF||
'	"FLEX_N04" NUMBER, '||wwv_flow.LF||
'	"FLEX_N05" NUMBER, '||wwv_flow.LF||
'	"FLEX_N06" NUM';
wwv_flow_imp.g_varchar2_table(16) := 'BER, '||wwv_flow.LF||
'	"FLEX_N07" NUMBER, '||wwv_flow.LF||
'	"FLEX_N08" NUMBER, '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SALES_DEAL_COMP_PK" PRIMARY KEY ("';
wwv_flow_imp.g_varchar2_table(17) := 'ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_DEAL_COMPETITION" ADD FOREIGN KEY ("COMPET';
wwv_flow_imp.g_varchar2_table(18) := 'ITOR_THREAT_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_COMPETITOR_THREATS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814581787322002056)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_deal_competition'
,p_sequence=>280
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814581915947002057)
,p_script_id=>wwv_flow_imp.id(6814581787322002056)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_DEAL_COMPETITION'
);
wwv_flow_imp.component_end;
end;
/
