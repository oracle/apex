prompt --application/deployment/install/upgrade_eba_sales_fw_spec
begin
--   Manifest
--     INSTALL: UPGRADE-eba_sales_fw spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace PACKAGE "EBA_SALES_FW" as'||wwv_flow.LF||
'    function conv_txt_html ('||wwv_flow.LF||
'        p_txt_message in va';
wwv_flow_imp.g_varchar2_table(2) := 'rchar2 )'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
'    function conv_urls_links ('||wwv_flow.LF||
'        p_string in varchar2 )'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(3) := '    return varchar2;'||wwv_flow.LF||
'    function tags_cleaner ('||wwv_flow.LF||
'        p_tags  in varchar2,'||wwv_flow.LF||
'        p_case  in var';
wwv_flow_imp.g_varchar2_table(4) := 'char2 default ''U'' )'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
'    procedure tag_sync ('||wwv_flow.LF||
'        p_new_tags          in';
wwv_flow_imp.g_varchar2_table(5) := ' varchar2,'||wwv_flow.LF||
'        p_old_tags          in varchar2,'||wwv_flow.LF||
'        p_content_type      in varchar2,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(6) := ' p_content_id        in number );'||wwv_flow.LF||
'    function selective_escape ('||wwv_flow.LF||
'        p_text  in varchar2,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(7) := '   p_tags  in varchar2 default ''<h2>,</h2>,<p>,</p>,<b>,</b>,<li>,</li>,<ul>,</ul>,<br />,<i>,</i>,<';
wwv_flow_imp.g_varchar2_table(8) := 'h3>,</h3>'' )'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
'    function get_preference_value ('||wwv_flow.LF||
'        p_preference_name ';
wwv_flow_imp.g_varchar2_table(9) := 'in varchar2 )'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
'    procedure set_preference_value ('||wwv_flow.LF||
'        p_preference_nam';
wwv_flow_imp.g_varchar2_table(10) := 'e  in varchar2, '||wwv_flow.LF||
'        p_preference_value in varchar2 );'||wwv_flow.LF||
'    function compress_int ('||wwv_flow.LF||
'        n in ';
wwv_flow_imp.g_varchar2_table(11) := 'integer )'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
'    function remove_duplicates ('||wwv_flow.LF||
'        p_csv_string in varchar2';
wwv_flow_imp.g_varchar2_table(12) := ' )'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
'end eba_sales_fw;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8473759781927119192)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_fw spec'
,p_sequence=>240
,p_script_type=>'UPGRADE'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
