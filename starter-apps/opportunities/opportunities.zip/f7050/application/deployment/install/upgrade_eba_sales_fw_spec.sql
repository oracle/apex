prompt --application/deployment/install/upgrade_eba_sales_fw_spec
begin
--   Manifest
--     INSTALL: UPGRADE-eba_sales_fw spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8473759781927119192)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_fw spec'
,p_sequence=>240
,p_script_type=>'UPGRADE'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace PACKAGE "EBA_SALES_FW" as',
'    function conv_txt_html (',
'        p_txt_message in varchar2 )',
'        return varchar2;',
'    function conv_urls_links (',
'        p_string in varchar2 )',
'        return varchar2;',
'    function tags_cleaner (',
'        p_tags  in varchar2,',
'        p_case  in varchar2 default ''U'' )',
'        return varchar2;',
'    procedure tag_sync (',
'        p_new_tags          in varchar2,',
'        p_old_tags          in varchar2,',
'        p_content_type      in varchar2,',
'        p_content_id        in number );',
'    function selective_escape (',
'        p_text  in varchar2,',
'        p_tags  in varchar2 default ''<h2>,</h2>,<p>,</p>,<b>,</b>,<li>,</li>,<ul>,</ul>,<br />,<i>,</i>,<h3>,</h3>'' )',
'        return varchar2;',
'    function get_preference_value (',
'        p_preference_name in varchar2 )',
'        return varchar2;',
'    procedure set_preference_value (',
'        p_preference_name  in varchar2, ',
'        p_preference_value in varchar2 );',
'    function compress_int (',
'        n in integer )',
'        return varchar2;',
'    function remove_duplicates (',
'        p_csv_string in varchar2 )',
'        return varchar2;',
'end eba_sales_fw;',
'/',
'show errors'))
);
wwv_flow_imp.component_end;
end;
/
