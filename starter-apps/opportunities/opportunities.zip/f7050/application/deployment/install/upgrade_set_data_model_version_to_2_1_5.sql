prompt --application/deployment/install/upgrade_set_data_model_version_to_2_1_5
begin
--   Manifest
--     INSTALL: UPGRADE-Set data model version to 2.1.5
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into eba_sales_preferences (preference_name, preference_value) values (''DATA_MODEL_VERSION'', ';
wwv_flow_imp.g_varchar2_table(2) := '''2.1.5'');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6817128408191496403)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'Set data model version to 2.1.5'
,p_sequence=>60
,p_script_type=>'UPGRADE'
,p_condition_type=>'FUNCTION_BODY'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'  l_data_model_version eba_sales_preferences.preference_value%type;',
'',
'begin',
'',
'  select preference_value',
'  into l_data_model_version',
'  from eba_sales_preferences',
'  where preference_name = ''DATA_MODEL_VERSION'';',
'',
'  return false;',
'',
'exception',
'',
'  when no_data_found',
'  then',
'    return true;',
'',
'end;'))
,p_condition2=>'PLSQL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
