prompt --application/deployment/install/upgrade_set_data_model_version_to_2_1_5
begin
--   Manifest
--     INSTALL: UPGRADE-Set data model version to 2.1.5
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6799406216230743000)
,p_install_id=>wwv_flow_imp.id(10495272006180774354)
,p_name=>'Set data model version to 2.1.5'
,p_sequence=>60
,p_script_type=>'UPGRADE'
,p_condition_type=>'FUNCTION_BODY'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'  l_data_model_version eba_sales_preferences.preference_value%type;',
'',
'begin',
'',
'  select preference_value',
'  into l_data_model_version',
'  from eba_sales_preferences',
'  where preference_name = ''DATA_MODEL_VERSION'';',
'',
'  return false;',
'',
'exception',
'',
'  when no_data_found',
'  then',
'    return true;',
'',
'end;'))
,p_condition2=>'PLSQL'
,p_script_clob=>'insert into eba_sales_preferences (preference_name, preference_value) values (''DATA_MODEL_VERSION'', ''2.1.5'');'
);
wwv_flow_imp.component_end;
end;
/
