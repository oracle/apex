prompt --application/deployment/install/install_eba_sales_deals
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_deals
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_DEALS" '||wwv_flow.LF||
'   ("ID" NUMBER, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER(*,0), '||wwv_flow.LF||
'	"ROW_KEY" VAR';
wwv_flow_imp.g_varchar2_table(2) := 'CHAR2(255), '||wwv_flow.LF||
'	"TAGS" VARCHAR2(4000), '||wwv_flow.LF||
'	"DEAL_CURRENCY" VARCHAR2(8), '||wwv_flow.LF||
'	"CUSTOMER_ID" NUMBER NOT NULL ';
wwv_flow_imp.g_varchar2_table(3) := 'ENABLE, '||wwv_flow.LF||
'	"SALESREP_ID_01" NUMBER, '||wwv_flow.LF||
'	"SALESREP_ID_02" NUMBER, '||wwv_flow.LF||
'	"SALESREP_ID_03" NUMBER, '||wwv_flow.LF||
'	"SALESREP';
wwv_flow_imp.g_varchar2_table(4) := '_ID_04" NUMBER, '||wwv_flow.LF||
'	"TEAM_MEMBERS" VARCHAR2(4000), '||wwv_flow.LF||
'	"VP_ID" NUMBER, '||wwv_flow.LF||
'	"SVP_ID" NUMBER, '||wwv_flow.LF||
'	"DEAL_NAME" ';
wwv_flow_imp.g_varchar2_table(5) := 'VARCHAR2(255), '||wwv_flow.LF||
'	"TERRITORY_ID_OLD" NUMBER, '||wwv_flow.LF||
'	"DEAL_CLOSE_DATE" TIMESTAMP (6) WITH TIME ZONE NOT NUL';
wwv_flow_imp.g_varchar2_table(6) := 'L ENABLE, '||wwv_flow.LF||
'	"DEAL_CLOSE_DATE_ALT" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"DEAL_PROBABILITY" NUMBER(*,0), '||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(7) := '"DEAL_STAGE" NUMBER, '||wwv_flow.LF||
'	"DEAL_AMOUNT" NUMBER, '||wwv_flow.LF||
'	"DEAL_LICENSE" NUMBER, '||wwv_flow.LF||
'	"DEAL_SUPPORT" NUMBER, '||wwv_flow.LF||
'	"DE';
wwv_flow_imp.g_varchar2_table(8) := 'AL_EDUCATION" NUMBER, '||wwv_flow.LF||
'	"DEAL_CONSULTING" NUMBER, '||wwv_flow.LF||
'	"DEAL_STATUS_CODE_ID" NUMBER,'||wwv_flow.LF||
'	"DEAL_CUSTOMER_LO';
wwv_flow_imp.g_varchar2_table(9) := 'CATION" VARCHAR2(4000), '||wwv_flow.LF||
'	"DEAL_CONTACTS" VARCHAR2(4000), '||wwv_flow.LF||
'	"DEAL_SUMMARY" VARCHAR2(4000), '||wwv_flow.LF||
'	"DEAL_S';
wwv_flow_imp.g_varchar2_table(10) := 'YSTEM_ID" VARCHAR2(30),'||wwv_flow.LF||
'	"DEAL_PRODUCTS" VARCHAR2(4000), '||wwv_flow.LF||
'	"DEAL_COMPETITORS" VARCHAR2(4000), '||wwv_flow.LF||
'	"STR';
wwv_flow_imp.g_varchar2_table(11) := 'ATEGY" VARCHAR2(4000), '||wwv_flow.LF||
'	"FINANCIAL_ASSESSMENT_ID" NUMBER, '||wwv_flow.LF||
'	"STATUS_ASSESSMENT_ID" NUMBER, '||wwv_flow.LF||
'	"RISK_';
wwv_flow_imp.g_varchar2_table(12) := 'ASSESSMENT_ID" NUMBER, '||wwv_flow.LF||
'	"ACCOUNT_STANDING_ID" NUMBER, '||wwv_flow.LF||
'	"PRO_RE_ACTIVE" VARCHAR2(30), '||wwv_flow.LF||
'	"NATIONAL_T';
wwv_flow_imp.g_varchar2_table(13) := 'OP_25_YN" VARCHAR2(1), '||wwv_flow.LF||
'	"PARTNER" VARCHAR2(1), '||wwv_flow.LF||
'	"CREATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"CREATED" TIMESTAMP ';
wwv_flow_imp.g_varchar2_table(14) := '(6) WITH TIME ZONE, '||wwv_flow.LF||
'	"UPDATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"QTR" ';
wwv_flow_imp.g_varchar2_table(15) := 'VARCHAR2(8),'||wwv_flow.LF||
'    "SPONSOR_CONTACT_ID" number references eba_sales_customer_contacts on delete cascad';
wwv_flow_imp.g_varchar2_table(16) := 'e,'||wwv_flow.LF||
'	"EXTERNAL_OPPORTUNITY_ID" VARCHAR2(512), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_01" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLE';
wwv_flow_imp.g_varchar2_table(17) := 'X_FLAG_02" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_03" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_04" VARCHAR2(';
wwv_flow_imp.g_varchar2_table(18) := '30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_01" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_02" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_03" ';
wwv_flow_imp.g_varchar2_table(19) := 'VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_04" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_FLAG_01" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_02"';
wwv_flow_imp.g_varchar2_table(20) := ' VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_03" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_04" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_05" VARCHA';
wwv_flow_imp.g_varchar2_table(21) := 'R2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_06" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_07" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_08" VARCHAR2(30),';
wwv_flow_imp.g_varchar2_table(22) := ' '||wwv_flow.LF||
'	"FLEX_01" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_02" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_03" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_04" VAR';
wwv_flow_imp.g_varchar2_table(23) := 'CHAR2(4000), '||wwv_flow.LF||
'	"FLEX_05" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_06" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_07" VARCHAR2(4000), '||wwv_flow.LF||
'	"';
wwv_flow_imp.g_varchar2_table(24) := 'FLEX_08" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_D01" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D02" TIMESTAMP (6) WITH ';
wwv_flow_imp.g_varchar2_table(25) := 'TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D03" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D04" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"';
wwv_flow_imp.g_varchar2_table(26) := 'FLEX_N01" NUMBER, '||wwv_flow.LF||
'	"FLEX_N02" NUMBER, '||wwv_flow.LF||
'	"FLEX_N03" NUMBER, '||wwv_flow.LF||
'	"FLEX_N04" NUMBER, '||wwv_flow.LF||
'	"FLEX_N05" NUMBER';
wwv_flow_imp.g_varchar2_table(27) := ', '||wwv_flow.LF||
'	"FLEX_N06" NUMBER, '||wwv_flow.LF||
'	"FLEX_N07" NUMBER, '||wwv_flow.LF||
'	"FLEX_N08" NUMBER, '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SALES_DEALS_PROB';
wwv_flow_imp.g_varchar2_table(28) := '_CC" CHECK (deal_probability between 0 and 100) ENABLE, '||wwv_flow.LF||
'	 PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(29) := '   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_DEALS" ADD CONSTRAINT "EBA_SALES_DEALS_TERR_FK" FOREIGN KEY ("TERRITO';
wwv_flow_imp.g_varchar2_table(30) := 'RY_ID_OLD")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_TERRITORIES" ("ID") ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_DEALS" ADD ';
wwv_flow_imp.g_varchar2_table(31) := 'FOREIGN KEY ("FINANCIAL_ASSESSMENT_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_FIN_ASSESSMENTS" ("ID") ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'AL';
wwv_flow_imp.g_varchar2_table(32) := 'TER TABLE "EBA_SALES_DEALS" ADD FOREIGN KEY ("STATUS_ASSESSMENT_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_STATUS';
wwv_flow_imp.g_varchar2_table(33) := '_ASSESSMENTS" ("ID") ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_DEALS" ADD FOREIGN KEY ("RISK_ASSESSMENT_ID")'||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(34) := '  REFERENCES "EBA_SALES_RISK_ASSESSMENTS" ("ID") ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_DEALS" ADD FOREIGN ';
wwv_flow_imp.g_varchar2_table(35) := 'KEY ("ACCOUNT_STANDING_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_ACCOUNT_STANDING" ("ID") ENABLE;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814581028547995836)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_deals'
,p_sequence=>180
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814581142001995836)
,p_script_id=>wwv_flow_imp.id(6814581028547995836)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_DEALS'
);
wwv_flow_imp.component_end;
end;
/
