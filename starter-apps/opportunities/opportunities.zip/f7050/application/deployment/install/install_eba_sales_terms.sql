prompt --application/deployment/install/install_eba_sales_terms
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_terms
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_sales_terms'||wwv_flow.LF||
'('||wwv_flow.LF||
'    id          number not null primary key,'||wwv_flow.LF||
'    name        varchar2';
wwv_flow_imp.g_varchar2_table(2) := '(255),'||wwv_flow.LF||
'    month_equiv number,'||wwv_flow.LF||
'    created_by  varchar2(255),'||wwv_flow.LF||
'    created     timestamp (6) with tim';
wwv_flow_imp.g_varchar2_table(3) := 'e zone,'||wwv_flow.LF||
'    updated_by  varchar2(255),'||wwv_flow.LF||
'    updated     timestamp (6) with time zone'||wwv_flow.LF||
');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8065088987533348962)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_terms'
,p_sequence=>510
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
