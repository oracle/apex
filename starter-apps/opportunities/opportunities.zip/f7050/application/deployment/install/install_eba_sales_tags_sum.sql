prompt --application/deployment/install/install_eba_sales_tags_sum
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_tags_sum
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_TAGS_SUM" '||wwv_flow.LF||
'   (	"TAG" VARCHAR2(255), '||wwv_flow.LF||
'	"TAG_COUNT" NUMBER, '||wwv_flow.LF||
'	 CONSTRAINT "EB';
wwv_flow_imp.g_varchar2_table(2) := 'A_SALES_TAGS_SUM_PK" PRIMARY KEY ("TAG")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814451595754728425)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_tags_sum'
,p_sequence=>450
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814451702713728426)
,p_script_id=>wwv_flow_imp.id(6814451595754728425)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_TAGS_SUM'
);
wwv_flow_imp.component_end;
end;
/
