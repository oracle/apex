prompt --application/deployment/install/install_eba_sales_competitors
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_competitors
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_COMPETITORS" '||wwv_flow.LF||
'   (	"ID" NUMBER, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER, '||wwv_flow.LF||
'	"COMPETITOR';
wwv_flow_imp.g_varchar2_table(2) := '_NAME" VARCHAR2(255) NOT NULL ENABLE, '||wwv_flow.LF||
'	"COMPETITOR_DESC" VARCHAR2(4000), '||wwv_flow.LF||
'	"URL_1" VARCHAR2(255), '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(3) := '	"URL_1_NAME" VARCHAR2(255), '||wwv_flow.LF||
'	"URL_2" VARCHAR2(255), '||wwv_flow.LF||
'	"URL_2_NAME" VARCHAR2(255), '||wwv_flow.LF||
'	"URL_3" VARCHA';
wwv_flow_imp.g_varchar2_table(4) := 'R2(255), '||wwv_flow.LF||
'	"URL_3_NAME" VARCHAR2(255), '||wwv_flow.LF||
'	"URL_4" VARCHAR2(255), '||wwv_flow.LF||
'	"URL_4_NAME" VARCHAR2(255), '||wwv_flow.LF||
'	"TAG';
wwv_flow_imp.g_varchar2_table(5) := 'S" VARCHAR2(4000), '||wwv_flow.LF||
'	"EXPERTS" VARCHAR2(4000), '||wwv_flow.LF||
'	"CREATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"CREATED" TIMESTAMP (';
wwv_flow_imp.g_varchar2_table(6) := '6) WITH TIME ZONE, '||wwv_flow.LF||
'	"UPDATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"INTERN';
wwv_flow_imp.g_varchar2_table(7) := 'AL_FLEX_FLAG_01" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_02" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_03" VAR';
wwv_flow_imp.g_varchar2_table(8) := 'CHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_04" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_01" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_';
wwv_flow_imp.g_varchar2_table(9) := 'FLEX_02" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_03" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_04" VARCHAR2(4000), '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(10) := '	"FLEX_FLAG_01" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_02" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_03" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_';
wwv_flow_imp.g_varchar2_table(11) := 'FLAG_04" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_05" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_06" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_07';
wwv_flow_imp.g_varchar2_table(12) := '" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_08" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_01" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_02" VARCHAR2(4000';
wwv_flow_imp.g_varchar2_table(13) := '), '||wwv_flow.LF||
'	"FLEX_03" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_04" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_05" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_06" V';
wwv_flow_imp.g_varchar2_table(14) := 'ARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_07" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_08" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_D01" TIMESTAMP (6) WI';
wwv_flow_imp.g_varchar2_table(15) := 'TH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D02" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D03" TIMESTAMP (6) WITH TIME ZONE, ';
wwv_flow_imp.g_varchar2_table(16) := ''||wwv_flow.LF||
'	"FLEX_D04" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_N01" NUMBER, '||wwv_flow.LF||
'	"FLEX_N02" NUMBER, '||wwv_flow.LF||
'	"FLEX_N03" NU';
wwv_flow_imp.g_varchar2_table(17) := 'MBER, '||wwv_flow.LF||
'	"FLEX_N04" NUMBER, '||wwv_flow.LF||
'	"FLEX_N05" NUMBER, '||wwv_flow.LF||
'	"FLEX_N06" NUMBER, '||wwv_flow.LF||
'	"FLEX_N07" NUMBER, '||wwv_flow.LF||
'	"FLEX_N0';
wwv_flow_imp.g_varchar2_table(18) := '8" NUMBER, '||wwv_flow.LF||
'	 PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814512822499947896)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_competitors'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814512872549947898)
,p_script_id=>wwv_flow_imp.id(6814512822499947896)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_COMPETITORS'
);
wwv_flow_imp.component_end;
end;
/
