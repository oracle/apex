prompt --application/deployment/install/install_eba_sales_deal_status_codes
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_deal_status_codes
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_DEAL_STATUS_CODES" '||wwv_flow.LF||
'   (	"ID" NUMBER, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER, '||wwv_flow.LF||
'	"DISP';
wwv_flow_imp.g_varchar2_table(2) := 'LAY_ORDER" NUMBER, '||wwv_flow.LF||
'	"CODE_TYPE" VARCHAR2(30), '||wwv_flow.LF||
'	"STATUS_CODE" VARCHAR2(255) NOT NULL ENABLE, '||wwv_flow.LF||
'	"COR';
wwv_flow_imp.g_varchar2_table(3) := 'RESPONDING_PROB_PCT" NUMBER(3,0) NOT NULL ENABLE, '||wwv_flow.LF||
'	"CODE_DESCRIPTION" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_01" V';
wwv_flow_imp.g_varchar2_table(4) := 'ARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_02" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_03" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_04" VARCHAR2(4000), '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(5) := '	"CREATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"UPDATED_BY" VARCHAR2(255),';
wwv_flow_imp.g_varchar2_table(6) := ' '||wwv_flow.LF||
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	 PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814584354145102703)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_deal_status_codes'
,p_sequence=>310
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814584428660102704)
,p_script_id=>wwv_flow_imp.id(6814584354145102703)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_DEAL_STATUS_CODES'
);
wwv_flow_imp.component_end;
end;
/
