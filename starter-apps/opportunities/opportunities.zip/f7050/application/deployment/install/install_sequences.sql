prompt --application/deployment/install/install_sequences
begin
--   Manifest
--     INSTALL: INSTALL-sequences
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := ' CREATE SEQUENCE  "EBA_SALES_ROWKEY_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT';
wwv_flow_imp.g_varchar2_table(2) := ' BY 1 START WITH 1901 CACHE 20 NOORDER  NOCYCLE ;'||wwv_flow.LF||
''||wwv_flow.LF||
' CREATE SEQUENCE  "EBA_SALES_SEQUENCE"  MINVALUE ';
wwv_flow_imp.g_varchar2_table(3) := '1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 3641 CACHE 20 NOORDER  NOCYCLE ;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(4) := ' CREATE SEQUENCE  "EBA_SALES_SEQUENCE2"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT ';
wwv_flow_imp.g_varchar2_table(5) := 'BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6815446886241355747)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'sequences'
,p_sequence=>580
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815446926857355748)
,p_script_id=>wwv_flow_imp.id(6815446886241355747)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'EBA_SALES_ROWKEY_SEQ'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815447153182355748)
,p_script_id=>wwv_flow_imp.id(6815446886241355747)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'EBA_SALES_SEQUENCE'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815447380141355748)
,p_script_id=>wwv_flow_imp.id(6815446886241355747)
,p_object_owner=>'#OWNER#'
,p_object_type=>'SEQUENCE'
,p_object_name=>'EBA_SALES_SEQUENCE2'
);
wwv_flow_imp.component_end;
end;
/
