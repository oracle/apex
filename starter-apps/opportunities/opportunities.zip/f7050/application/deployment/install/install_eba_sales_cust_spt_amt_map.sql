prompt --application/deployment/install/install_eba_sales_cust_spt_amt_map
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_cust_spt_amt_map
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_CUST_SPT_AMT_MAP" '||wwv_flow.LF||
'('||wwv_flow.LF||
'    "ID" NUMBER,'||wwv_flow.LF||
'    "ROW_VERSION_NUMBER" NUMBER,'||wwv_flow.LF||
'    "';
wwv_flow_imp.g_varchar2_table(2) := 'NAME" VARCHAR2(255),'||wwv_flow.LF||
'    "CLOSE_DATE" TIMESTAMP (6) WITH TIME ZONE,'||wwv_flow.LF||
'    "TERM_ID" NUMBER references ';
wwv_flow_imp.g_varchar2_table(3) := 'EBA_SALES_TERMS on delete set null,'||wwv_flow.LF||
'    "CUSTOMER_ID" NUMBER references EBA_SALES_CUSTOMERS on delet';
wwv_flow_imp.g_varchar2_table(4) := 'e set null,'||wwv_flow.LF||
'    "AMOUNT_ID" NUMBER references EBA_SALES_SUPPORT_AMTS on delete cascade,'||wwv_flow.LF||
'    "QUOTE_P';
wwv_flow_imp.g_varchar2_table(5) := 'RICE" NUMBER,'||wwv_flow.LF||
'    "DESCRIPTION" VARCHAR2(4000),'||wwv_flow.LF||
'    "CREATED_BY" VARCHAR2(255),'||wwv_flow.LF||
'    "CREATED" TIMEST';
wwv_flow_imp.g_varchar2_table(6) := 'AMP (6) WITH TIME ZONE,'||wwv_flow.LF||
'    "UPDATED_BY" VARCHAR2(255),'||wwv_flow.LF||
'    "UPDATED" TIMESTAMP (6) WITH TIME ZONE,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(7) := '     PRIMARY KEY ("ID")  USING INDEX  ENABLE'||wwv_flow.LF||
');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8473766046022235209)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_cust_spt_amt_map'
,p_sequence=>570
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
