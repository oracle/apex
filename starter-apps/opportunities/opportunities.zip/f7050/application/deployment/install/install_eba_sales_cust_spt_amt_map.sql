prompt --application/deployment/install/install_eba_sales_cust_spt_amt_map
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_cust_spt_amt_map
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8473766046022235209)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_cust_spt_amt_map'
,p_sequence=>570
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_CUST_SPT_AMT_MAP" ',
'(',
'    "ID" NUMBER,',
'    "ROW_VERSION_NUMBER" NUMBER,',
'    "NAME" VARCHAR2(255),',
'    "CLOSE_DATE" TIMESTAMP (6) WITH TIME ZONE,',
'    "TERM_ID" NUMBER references EBA_SALES_TERMS on delete set null,',
'    "CUSTOMER_ID" NUMBER references EBA_SALES_CUSTOMERS on delete set null,',
'    "AMOUNT_ID" NUMBER references EBA_SALES_SUPPORT_AMTS on delete cascade,',
'    "QUOTE_PRICE" NUMBER,',
'    "DESCRIPTION" VARCHAR2(4000),',
'    "CREATED_BY" VARCHAR2(255),',
'    "CREATED" TIMESTAMP (6) WITH TIME ZONE,',
'    "UPDATED_BY" VARCHAR2(255),',
'    "UPDATED" TIMESTAMP (6) WITH TIME ZONE,',
'     PRIMARY KEY ("ID")  USING INDEX  ENABLE',
');'))
);
wwv_flow_imp.component_end;
end;
/
