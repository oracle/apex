prompt --application/deployment/install/install_eba_sales_comments
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_comments
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_COMMENTS" '||wwv_flow.LF||
'   (	"ID" NUMBER, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER, '||wwv_flow.LF||
'	"ROW_KEY" VARC';
wwv_flow_imp.g_varchar2_table(2) := 'HAR2(255), '||wwv_flow.LF||
'	"DEAL_ID" NUMBER, '||wwv_flow.LF||
'	"NOTE" CLOB NOT NULL ENABLE, '||wwv_flow.LF||
'	"CREATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"CREAT';
wwv_flow_imp.g_varchar2_table(3) := 'ED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"UPDATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"UPDATED" TIMESTAMP (6) WITH TIME ';
wwv_flow_imp.g_varchar2_table(4) := 'ZONE, '||wwv_flow.LF||
'	"ENTITY_TYPE" VARCHAR2(20) NOT NULL ENABLE, '||wwv_flow.LF||
'	"LEAD_ID" NUMBER, '||wwv_flow.LF||
'	"TERRITORY_ID" NUMBER, '||wwv_flow.LF||
'	"';
wwv_flow_imp.g_varchar2_table(5) := 'ACCOUNT_ID" NUMBER, '||wwv_flow.LF||
'	"CONTACT_ID" NUMBER, '||wwv_flow.LF||
'	"PRODUCT_ID" NUMBER, '||wwv_flow.LF||
'	 PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDE';
wwv_flow_imp.g_varchar2_table(6) := 'X  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SALES_COMMENTS_ENT_TYPE_CK" CHECK (entity_type in (''OPPORTUNITY'',''LEAD';
wwv_flow_imp.g_varchar2_table(7) := ''',''TERRITORY'',''ACCOUNT'', ''CONTACT'', ''PRODUCT'')) ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SALES_COMMENTS_ENT_FK_CK"';
wwv_flow_imp.g_varchar2_table(8) := ' CHECK ('||wwv_flow.LF||
'  entity_type = ''OPPORTUNITY'' and deal_id is not null'||wwv_flow.LF||
'    or entity_type = ''LEAD'' and lead_';
wwv_flow_imp.g_varchar2_table(9) := 'id is not null'||wwv_flow.LF||
'    or entity_type = ''TERRITORY'' and territory_id is not null'||wwv_flow.LF||
'    or entity_type = ''A';
wwv_flow_imp.g_varchar2_table(10) := 'CCOUNT'' and account_id is not null'||wwv_flow.LF||
'    or entity_type = ''CONTACT'' and contact_id is not null'||wwv_flow.LF||
'    or ';
wwv_flow_imp.g_varchar2_table(11) := 'entity_type = ''PRODUCT'' and product_id is not null'||wwv_flow.LF||
') ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_COMMENTS"';
wwv_flow_imp.g_varchar2_table(12) := ' ADD CONSTRAINT "EBA_SALES_COMMENTS_ACNTS_FK" FOREIGN KEY ("ACCOUNT_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_CU';
wwv_flow_imp.g_varchar2_table(13) := 'STOMERS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_COMMENTS" ADD CONSTRAINT "EBA_SALE';
wwv_flow_imp.g_varchar2_table(14) := 'S_COMMENTS_CNTS_FK" FOREIGN KEY ("CONTACT_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_CUSTOMER_CONTACTS" ("ID") ON';
wwv_flow_imp.g_varchar2_table(15) := ' DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_COMMENTS" ADD CONSTRAINT "EBA_SALES_COMMENTS_LEADS_F';
wwv_flow_imp.g_varchar2_table(16) := 'K" FOREIGN KEY ("LEAD_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_LEADS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER T';
wwv_flow_imp.g_varchar2_table(17) := 'ABLE "EBA_SALES_COMMENTS" ADD CONSTRAINT "EBA_SALES_COMMENTS_OPPS_FK" FOREIGN KEY ("DEAL_ID")'||wwv_flow.LF||
'	  REF';
wwv_flow_imp.g_varchar2_table(18) := 'ERENCES "EBA_SALES_DEALS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_COMMENTS" ADD CON';
wwv_flow_imp.g_varchar2_table(19) := 'STRAINT "EBA_SALES_COMMENTS_PRODS_FK" FOREIGN KEY ("PRODUCT_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_PRODUCTS" ';
wwv_flow_imp.g_varchar2_table(20) := '("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_COMMENTS" ADD CONSTRAINT "EBA_SALES_COMMENT';
wwv_flow_imp.g_varchar2_table(21) := 'S_TERRS_FK" FOREIGN KEY ("TERRITORY_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_TERRITORIES" ("ID") ON DELETE CASC';
wwv_flow_imp.g_varchar2_table(22) := 'ADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814511993842942877)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_comments'
,p_sequence=>240
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814512097814942877)
,p_script_id=>wwv_flow_imp.id(6814511993842942877)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_COMMENTS'
);
wwv_flow_imp.component_end;
end;
/
