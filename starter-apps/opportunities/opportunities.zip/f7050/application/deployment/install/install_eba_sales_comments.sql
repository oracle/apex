prompt --application/deployment/install/install_eba_sales_comments
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_comments
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-13'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(6796789801882189474)
,p_install_id=>wwv_flow_api.id(10495272006180774354)
,p_name=>'eba_sales_comments'
,p_sequence=>240
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_COMMENTS" ',
'   (	"ID" NUMBER, ',
'	"ROW_VERSION_NUMBER" NUMBER, ',
'	"ROW_KEY" VARCHAR2(255), ',
'	"DEAL_ID" NUMBER, ',
'	"NOTE" CLOB NOT NULL ENABLE, ',
'	"CREATED_BY" VARCHAR2(255), ',
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"UPDATED_BY" VARCHAR2(255), ',
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"ENTITY_TYPE" VARCHAR2(20) NOT NULL ENABLE, ',
'	"LEAD_ID" NUMBER, ',
'	"TERRITORY_ID" NUMBER, ',
'	"ACCOUNT_ID" NUMBER, ',
'	"CONTACT_ID" NUMBER, ',
'	"PRODUCT_ID" NUMBER, ',
'	 PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE, ',
'	 CONSTRAINT "EBA_SALES_COMMENTS_ENT_TYPE_CK" CHECK (entity_type in (''OPPORTUNITY'',''LEAD'',''TERRITORY'',''ACCOUNT'', ''CONTACT'', ''PRODUCT'')) ENABLE, ',
'	 CONSTRAINT "EBA_SALES_COMMENTS_ENT_FK_CK" CHECK (',
'  entity_type = ''OPPORTUNITY'' and deal_id is not null',
'    or entity_type = ''LEAD'' and lead_id is not null',
'    or entity_type = ''TERRITORY'' and territory_id is not null',
'    or entity_type = ''ACCOUNT'' and account_id is not null',
'    or entity_type = ''CONTACT'' and contact_id is not null',
'    or entity_type = ''PRODUCT'' and product_id is not null',
') ENABLE',
'   ) ;',
'',
'ALTER TABLE "EBA_SALES_COMMENTS" ADD CONSTRAINT "EBA_SALES_COMMENTS_ACNTS_FK" FOREIGN KEY ("ACCOUNT_ID")',
'	  REFERENCES "EBA_SALES_CUSTOMERS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_COMMENTS" ADD CONSTRAINT "EBA_SALES_COMMENTS_CNTS_FK" FOREIGN KEY ("CONTACT_ID")',
'	  REFERENCES "EBA_SALES_CUSTOMER_CONTACTS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_COMMENTS" ADD CONSTRAINT "EBA_SALES_COMMENTS_LEADS_FK" FOREIGN KEY ("LEAD_ID")',
'	  REFERENCES "EBA_SALES_LEADS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_COMMENTS" ADD CONSTRAINT "EBA_SALES_COMMENTS_OPPS_FK" FOREIGN KEY ("DEAL_ID")',
'	  REFERENCES "EBA_SALES_DEALS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_COMMENTS" ADD CONSTRAINT "EBA_SALES_COMMENTS_PRODS_FK" FOREIGN KEY ("PRODUCT_ID")',
'	  REFERENCES "EBA_SALES_PRODUCTS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_COMMENTS" ADD CONSTRAINT "EBA_SALES_COMMENTS_TERRS_FK" FOREIGN KEY ("TERRITORY_ID")',
'	  REFERENCES "EBA_SALES_TERRITORIES" ("ID") ON DELETE CASCADE ENABLE;',
'',
''))
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6796789905854189474)
,p_script_id=>wwv_flow_api.id(6796789801882189474)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_COMMENTS'
,p_last_updated_on=>to_date('20160706132630','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706132630','YYYYMMDDHH24MISS')
);
wwv_flow_api.component_end;
end;
/
