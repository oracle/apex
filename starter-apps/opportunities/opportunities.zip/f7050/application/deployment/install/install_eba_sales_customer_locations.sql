prompt --application/deployment/install/install_eba_sales_customer_locations
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_customer_locations
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_CUSTOMER_LOCATIONS" '||wwv_flow.LF||
'   (	"ID" NUMBER, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER, '||wwv_flow.LF||
'	"ROW';
wwv_flow_imp.g_varchar2_table(2) := '_KEY" VARCHAR2(255), '||wwv_flow.LF||
'	"CUSTOMER_ADDRESS_TYPE" VARCHAR2(30), '||wwv_flow.LF||
'	"CUSTOMER_ADDRESS_DESC" VARCHAR2(4000';
wwv_flow_imp.g_varchar2_table(3) := '), '||wwv_flow.LF||
'	"CUSTOMER_ID" NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'	"CUSTOMER_LOCATION_NAME" VARCHAR2(255), '||wwv_flow.LF||
'	"CUSTOMER_ADD';
wwv_flow_imp.g_varchar2_table(4) := 'RESS1" VARCHAR2(255), '||wwv_flow.LF||
'	"CUSTOMER_ADDRESS2" VARCHAR2(255), '||wwv_flow.LF||
'	"CUSTOMER_CITY" VARCHAR2(255), '||wwv_flow.LF||
'	"CUSTO';
wwv_flow_imp.g_varchar2_table(5) := 'MER_STATE" VARCHAR2(255), '||wwv_flow.LF||
'	"CUSTOMER_COUNTRY" VARCHAR2(255), '||wwv_flow.LF||
'	"CUSTOMER_POSTAL_CODE" VARCHAR2(30),';
wwv_flow_imp.g_varchar2_table(6) := ' '||wwv_flow.LF||
'	"CUSTOMER_DESCRIPTION" VARCHAR2(4000), '||wwv_flow.LF||
'	"CUSTOMER_TERRITORY_ID" NUMBER, '||wwv_flow.LF||
'	"CREATED_BY" VARCHAR2(';
wwv_flow_imp.g_varchar2_table(7) := '255), '||wwv_flow.LF||
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"UPDATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"UPDATED" TIMESTAMP ';
wwv_flow_imp.g_varchar2_table(8) := '(6) WITH TIME ZONE, '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_01" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_02" VARCHAR2(30), ';
wwv_flow_imp.g_varchar2_table(9) := ''||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_03" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_04" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_01"';
wwv_flow_imp.g_varchar2_table(10) := ' VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_02" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_03" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERN';
wwv_flow_imp.g_varchar2_table(11) := 'AL_FLEX_04" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_FLAG_01" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_02" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FL';
wwv_flow_imp.g_varchar2_table(12) := 'AG_03" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_04" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_05" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_06" ';
wwv_flow_imp.g_varchar2_table(13) := 'VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_07" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_08" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_01" VARCHAR2(400';
wwv_flow_imp.g_varchar2_table(14) := '0), '||wwv_flow.LF||
'	"FLEX_02" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_03" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_04" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_05" ';
wwv_flow_imp.g_varchar2_table(15) := 'VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_06" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_07" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_08" VARCHAR2(4000), ';
wwv_flow_imp.g_varchar2_table(16) := ''||wwv_flow.LF||
'	"FLEX_D01" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D02" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D03" T';
wwv_flow_imp.g_varchar2_table(17) := 'IMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D04" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_N01" NUMBER, '||wwv_flow.LF||
'	"FLEX';
wwv_flow_imp.g_varchar2_table(18) := '_N02" NUMBER, '||wwv_flow.LF||
'	"FLEX_N03" NUMBER, '||wwv_flow.LF||
'	"FLEX_N04" NUMBER, '||wwv_flow.LF||
'	"FLEX_N05" NUMBER, '||wwv_flow.LF||
'	"FLEX_N06" NUMBER, '||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(19) := '"FLEX_N07" NUMBER, '||wwv_flow.LF||
'	"FLEX_N08" NUMBER, '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SALES_CUST_LOC_AT" CHECK (customer_addres';
wwv_flow_imp.g_varchar2_table(20) := 's_type in (''BILLTO'',''SHIPTO'',''OLD'',''OTHER'')) ENABLE, '||wwv_flow.LF||
'	 PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(21) := ') ;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_CUSTOMER_LOCATIONS" ADD CONSTRAINT "EBA_SALES_CUSTOMER_LOC_FK" FOREIGN K';
wwv_flow_imp.g_varchar2_table(22) := 'EY ("CUSTOMER_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_CUSTOMERS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814580470742991512)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_customer_locations'
,p_sequence=>270
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814580560347991512)
,p_script_id=>wwv_flow_imp.id(6814580470742991512)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_CUSTOMER_LOCATIONS'
);
wwv_flow_imp.component_end;
end;
/
