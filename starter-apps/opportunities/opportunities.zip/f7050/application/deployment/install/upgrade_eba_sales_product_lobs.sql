prompt --application/deployment/install/upgrade_eba_sales_product_lobs
begin
--   Manifest
--     INSTALL: UPGRADE-EBA_SALES_PRODUCT_LOBS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_PRODUCT_LOBS" '||wwv_flow.LF||
'('||wwv_flow.LF||
'    "ID" NUMBER,'||wwv_flow.LF||
'    "ROW_VERSION_NUMBER" NUMBER,'||wwv_flow.LF||
'    "NAME';
wwv_flow_imp.g_varchar2_table(2) := '" VARCHAR2(255),'||wwv_flow.LF||
'    "DESCRIPTION" VARCHAR2(4000),'||wwv_flow.LF||
'    "CREATED_BY" VARCHAR2(255),'||wwv_flow.LF||
'    "CREATED" TIM';
wwv_flow_imp.g_varchar2_table(3) := 'ESTAMP (6) WITH TIME ZONE,'||wwv_flow.LF||
'    "UPDATED_BY" VARCHAR2(255),'||wwv_flow.LF||
'    "UPDATED" TIMESTAMP (6) WITH TIME ZON';
wwv_flow_imp.g_varchar2_table(4) := 'E,'||wwv_flow.LF||
'     PRIMARY KEY ("ID")  USING INDEX ENABLE'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE UNIQUE INDEX "EBA_SALES_PRODUCT_LOBS_UK" O';
wwv_flow_imp.g_varchar2_table(5) := 'N "EBA_SALES_PRODUCT_LOBS" ("NAME");'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER "BIU_EBA_SALES_PRODUCT_LOBS" '||wwv_flow.LF||
'   be';
wwv_flow_imp.g_varchar2_table(6) := 'fore insert or update on EBA_SALES_PRODUCT_LOBS'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(7) := '      if :NEW.ID is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(8) := 'XX'')'||wwv_flow.LF||
'           into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := current';
wwv_flow_imp.g_varchar2_table(9) := '_timestamp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.updated_by := nvl(v(''';
wwv_flow_imp.g_varchar2_table(10) := 'APP_USER''),USER);'||wwv_flow.LF||
'         :new.updated := current_timestamp;'||wwv_flow.LF||
'         :new.row_version_number := 1;';
wwv_flow_imp.g_varchar2_table(11) := ''||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDA';
wwv_flow_imp.g_varchar2_table(12) := 'TED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:old.row_version_number,1';
wwv_flow_imp.g_varchar2_table(13) := ') + 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TRIGGER "BIU_EBA_SALES_PRODUCT_LOBS" ENABLE;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6432240689018929743)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'EBA_SALES_PRODUCT_LOBS'
,p_sequence=>110
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_SALES_PRODUCT_LOBS'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
