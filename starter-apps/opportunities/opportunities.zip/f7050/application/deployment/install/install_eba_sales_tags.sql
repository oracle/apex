prompt --application/deployment/install/install_eba_sales_tags
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_tags
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814448242582689734)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_tags'
,p_sequence=>440
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_TAGS" ',
'   (	"ID" NUMBER, ',
'	"ROW_VERSION_NUMBER" NUMBER, ',
'	"TAG" VARCHAR2(255) NOT NULL ENABLE, ',
'	"CONTENT_ID" NUMBER, ',
'	"CONTENT_TYPE" VARCHAR2(30), ',
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"CREATED_BY" VARCHAR2(255), ',
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"UPDATED_BY" VARCHAR2(255), ',
'	 PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE, ',
'	 CONSTRAINT "EBA_SALES_TAGS_CK" CHECK (content_type in (''ACCOUNT'',''CONTACT'',''DEAL'',''COMPETITOR'', ''TERRITORY'', ''PRODUCT'', ''LEAD'')) ENABLE',
'   ) ;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814448416702689735)
,p_script_id=>wwv_flow_imp.id(6814448242582689734)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_TAGS'
);
wwv_flow_imp.component_end;
end;
/
