prompt --application/deployment/install/install_eba_sales_links
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_links
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_LINKS" '||wwv_flow.LF||
'   (	"ID" NUMBER, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'	"';
wwv_flow_imp.g_varchar2_table(2) := 'DEAL_ID" NUMBER, '||wwv_flow.LF||
'	"LINK_TARGET" VARCHAR2(4000) NOT NULL ENABLE, '||wwv_flow.LF||
'	"LINK_TEXT" VARCHAR2(255) NOT NUL';
wwv_flow_imp.g_varchar2_table(3) := 'L ENABLE, '||wwv_flow.LF||
'	"LINK_COMMENTS" VARCHAR2(4000), '||wwv_flow.LF||
'	"TAGS" VARCHAR2(4000), '||wwv_flow.LF||
'	"CREATED" TIMESTAMP (6) WITH ';
wwv_flow_imp.g_varchar2_table(4) := 'TIME ZONE, '||wwv_flow.LF||
'	"CREATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"UPDATED_BY" VA';
wwv_flow_imp.g_varchar2_table(5) := 'RCHAR2(255), '||wwv_flow.LF||
'	"ENTITY_TYPE" VARCHAR2(20) NOT NULL ENABLE, '||wwv_flow.LF||
'	"LEAD_ID" NUMBER, '||wwv_flow.LF||
'	"TERRITORY_ID" NUMB';
wwv_flow_imp.g_varchar2_table(6) := 'ER, '||wwv_flow.LF||
'	"ACCOUNT_ID" NUMBER, '||wwv_flow.LF||
'	"CONTACT_ID" NUMBER, '||wwv_flow.LF||
'	"PRODUCT_ID" NUMBER, '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SALES_LI';
wwv_flow_imp.g_varchar2_table(7) := 'NKS_PK" PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SALES_LINKS_ENT_TYPE_CK" CHECK ';
wwv_flow_imp.g_varchar2_table(8) := '(entity_type in (''OPPORTUNITY'',''LEAD'',''TERRITORY'',''ACCOUNT'', ''CONTACT'', ''PRODUCT'')) ENABLE, '||wwv_flow.LF||
'	 CONST';
wwv_flow_imp.g_varchar2_table(9) := 'RAINT "EBA_SALES_LINKS_ENT_FK_CK" CHECK ('||wwv_flow.LF||
'  entity_type = ''OPPORTUNITY'' and deal_id is not null'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(10) := 'or entity_type = ''LEAD'' and lead_id is not null'||wwv_flow.LF||
'    or entity_type = ''TERRITORY'' and territory_id is';
wwv_flow_imp.g_varchar2_table(11) := ' not null'||wwv_flow.LF||
'    or entity_type = ''ACCOUNT'' and account_id is not null'||wwv_flow.LF||
'    or entity_type = ''CONTACT'' a';
wwv_flow_imp.g_varchar2_table(12) := 'nd contact_id is not null'||wwv_flow.LF||
'    or entity_type = ''PRODUCT'' and product_id is not null'||wwv_flow.LF||
') ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(13) := ''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_LINKS" ADD CONSTRAINT "EBA_SALES_LINKS_ACCT_FK" FOREIGN KEY ("ACCOUNT_ID")'||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(14) := '  REFERENCES "EBA_SALES_CUSTOMERS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_LINKS" A';
wwv_flow_imp.g_varchar2_table(15) := 'DD CONSTRAINT "EBA_SALES_LINKS_CONT_FK" FOREIGN KEY ("CONTACT_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_CUSTOMER';
wwv_flow_imp.g_varchar2_table(16) := '_CONTACTS" ("ID") ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_LINKS" ADD CONSTRAINT "EBA_SALES_LINKS_LEADS_FK" F';
wwv_flow_imp.g_varchar2_table(17) := 'OREIGN KEY ("LEAD_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_LEADS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE';
wwv_flow_imp.g_varchar2_table(18) := ' "EBA_SALES_LINKS" ADD CONSTRAINT "EBA_SALES_LINKS_PROD_FK" FOREIGN KEY ("PRODUCT_ID")'||wwv_flow.LF||
'	  REFERENCES';
wwv_flow_imp.g_varchar2_table(19) := ' "EBA_SALES_PRODUCTS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_LINKS" ADD CONSTRAINT';
wwv_flow_imp.g_varchar2_table(20) := ' "EBA_SALES_LINKS_TERR_FK" FOREIGN KEY ("TERRITORY_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_TERRITORIES" ("ID")';
wwv_flow_imp.g_varchar2_table(21) := ' ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_LINKS" ADD CONSTRAINT "EBA_SALES_LINK_FK" FOREIGN';
wwv_flow_imp.g_varchar2_table(22) := ' KEY ("DEAL_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_DEALS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814607877707191262)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_links'
,p_sequence=>370
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814607993945191262)
,p_script_id=>wwv_flow_imp.id(6814607877707191262)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_LINKS'
);
wwv_flow_imp.component_end;
end;
/
