prompt --application/deployment/install/install_eba_sales_links
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_links
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-13'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(6796885685746437859)
,p_install_id=>wwv_flow_api.id(10495272006180774354)
,p_name=>'eba_sales_links'
,p_sequence=>370
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_LINKS" ',
'   (	"ID" NUMBER, ',
'	"ROW_VERSION_NUMBER" NUMBER NOT NULL ENABLE, ',
'	"DEAL_ID" NUMBER, ',
'	"LINK_TARGET" VARCHAR2(4000) NOT NULL ENABLE, ',
'	"LINK_TEXT" VARCHAR2(255) NOT NULL ENABLE, ',
'	"LINK_COMMENTS" VARCHAR2(4000), ',
'	"TAGS" VARCHAR2(4000), ',
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"CREATED_BY" VARCHAR2(255), ',
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"UPDATED_BY" VARCHAR2(255), ',
'	"ENTITY_TYPE" VARCHAR2(20) NOT NULL ENABLE, ',
'	"LEAD_ID" NUMBER, ',
'	"TERRITORY_ID" NUMBER, ',
'	"ACCOUNT_ID" NUMBER, ',
'	"CONTACT_ID" NUMBER, ',
'	"PRODUCT_ID" NUMBER, ',
'	 CONSTRAINT "EBA_SALES_LINKS_PK" PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE, ',
'	 CONSTRAINT "EBA_SALES_LINKS_ENT_TYPE_CK" CHECK (entity_type in (''OPPORTUNITY'',''LEAD'',''TERRITORY'',''ACCOUNT'', ''CONTACT'', ''PRODUCT'')) ENABLE, ',
'	 CONSTRAINT "EBA_SALES_LINKS_ENT_FK_CK" CHECK (',
'  entity_type = ''OPPORTUNITY'' and deal_id is not null',
'    or entity_type = ''LEAD'' and lead_id is not null',
'    or entity_type = ''TERRITORY'' and territory_id is not null',
'    or entity_type = ''ACCOUNT'' and account_id is not null',
'    or entity_type = ''CONTACT'' and contact_id is not null',
'    or entity_type = ''PRODUCT'' and product_id is not null',
') ENABLE',
'   ) ;',
'',
'ALTER TABLE "EBA_SALES_LINKS" ADD CONSTRAINT "EBA_SALES_LINKS_ACCT_FK" FOREIGN KEY ("ACCOUNT_ID")',
'	  REFERENCES "EBA_SALES_CUSTOMERS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_LINKS" ADD CONSTRAINT "EBA_SALES_LINKS_CONT_FK" FOREIGN KEY ("CONTACT_ID")',
'	  REFERENCES "EBA_SALES_CUSTOMER_CONTACTS" ("ID") ENABLE;',
'',
'ALTER TABLE "EBA_SALES_LINKS" ADD CONSTRAINT "EBA_SALES_LINKS_LEADS_FK" FOREIGN KEY ("LEAD_ID")',
'	  REFERENCES "EBA_SALES_LEADS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_LINKS" ADD CONSTRAINT "EBA_SALES_LINKS_PROD_FK" FOREIGN KEY ("PRODUCT_ID")',
'	  REFERENCES "EBA_SALES_PRODUCTS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_LINKS" ADD CONSTRAINT "EBA_SALES_LINKS_TERR_FK" FOREIGN KEY ("TERRITORY_ID")',
'	  REFERENCES "EBA_SALES_TERRITORIES" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_LINKS" ADD CONSTRAINT "EBA_SALES_LINK_FK" FOREIGN KEY ("DEAL_ID")',
'	  REFERENCES "EBA_SALES_DEALS" ("ID") ON DELETE CASCADE ENABLE;',
'',
''))
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6796885801984437859)
,p_script_id=>wwv_flow_api.id(6796885685746437859)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_LINKS'
,p_last_updated_on=>to_date('20160706140754','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706140754','YYYYMMDDHH24MISS')
);
wwv_flow_api.component_end;
end;
/
