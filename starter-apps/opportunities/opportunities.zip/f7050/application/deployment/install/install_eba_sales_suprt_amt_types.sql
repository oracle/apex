prompt --application/deployment/install/install_eba_sales_suprt_amt_types
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_suprt_amt_types
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8473765658550225291)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_suprt_amt_types'
,p_sequence=>550
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_SUPRT_AMT_TYPES"',
'(',
'    "ID" NUMBER,',
'    "ROW_VERSION_NUMBER" NUMBER,',
'    "NAME" VARCHAR2(255),',
'    "DESCRIPTION" VARCHAR2(4000),',
'    "CREATED_BY" VARCHAR2(255),',
'    "CREATED" TIMESTAMP (6) WITH TIME ZONE,',
'    "UPDATED_BY" VARCHAR2(255),',
'    "UPDATED" TIMESTAMP (6) WITH TIME ZONE,',
'     PRIMARY KEY ("ID")  USING INDEX  ENABLE',
');',
'',
'CREATE UNIQUE INDEX "EBA_SALES_SUPRT_AMT_TYPES_UK" ON "EBA_SALES_SUPRT_AMT_TYPES" ("NAME");'))
);
wwv_flow_imp.component_end;
end;
/
