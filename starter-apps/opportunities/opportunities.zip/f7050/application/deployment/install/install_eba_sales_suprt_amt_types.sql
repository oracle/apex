prompt --application/deployment/install/install_eba_sales_suprt_amt_types
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_suprt_amt_types
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_SUPRT_AMT_TYPES"'||wwv_flow.LF||
'('||wwv_flow.LF||
'    "ID" NUMBER,'||wwv_flow.LF||
'    "ROW_VERSION_NUMBER" NUMBER,'||wwv_flow.LF||
'    "NA';
wwv_flow_imp.g_varchar2_table(2) := 'ME" VARCHAR2(255),'||wwv_flow.LF||
'    "DESCRIPTION" VARCHAR2(4000),'||wwv_flow.LF||
'    "CREATED_BY" VARCHAR2(255),'||wwv_flow.LF||
'    "CREATED" T';
wwv_flow_imp.g_varchar2_table(3) := 'IMESTAMP (6) WITH TIME ZONE,'||wwv_flow.LF||
'    "UPDATED_BY" VARCHAR2(255),'||wwv_flow.LF||
'    "UPDATED" TIMESTAMP (6) WITH TIME Z';
wwv_flow_imp.g_varchar2_table(4) := 'ONE,'||wwv_flow.LF||
'     PRIMARY KEY ("ID")  USING INDEX  ENABLE'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE UNIQUE INDEX "EBA_SALES_SUPRT_AMT_TYPES';
wwv_flow_imp.g_varchar2_table(5) := '_UK" ON "EBA_SALES_SUPRT_AMT_TYPES" ("NAME");';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8473765658550225291)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_suprt_amt_types'
,p_sequence=>550
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
