prompt --application/deployment/install/upgrade_upgrade_data_model_to_3_0_0
begin
--   Manifest
--     INSTALL: UPGRADE-Upgrade data model to 3.0.0
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- Add tags and sold_as to products'||wwv_flow.LF||
'alter table eba_sales_products'||wwv_flow.LF||
'add (tags varchar2(4000), sold_as';
wwv_flow_imp.g_varchar2_table(2) := ' varchar2(50) check (sold_as in (''SUBSCRIPTION'',''PURCHASE'')))'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Add Close date, deal type id, an';
wwv_flow_imp.g_varchar2_table(3) := 'd qtr to deal products'||wwv_flow.LF||
'alter table eba_sales_deal_products'||wwv_flow.LF||
'add (close_date timestamp (6) with time z';
wwv_flow_imp.g_varchar2_table(4) := 'one,'||wwv_flow.LF||
'     tcv number,'||wwv_flow.LF||
'     term number,'||wwv_flow.LF||
'     qtr varchar2(8));'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Add ability to do verifications';
wwv_flow_imp.g_varchar2_table(5) := ' on other entities'||wwv_flow.LF||
'alter table eba_sales_verifications'||wwv_flow.LF||
'add (entity_type varchar2(20))'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'update eba_';
wwv_flow_imp.g_varchar2_table(6) := 'sales_verifications'||wwv_flow.LF||
'set entity_type = '||wwv_flow.LF||
'  case'||wwv_flow.LF||
'    when opp_id is not null then ''OPPORTUNITY'''||wwv_flow.LF||
'    whe';
wwv_flow_imp.g_varchar2_table(7) := 'n cust_id is not null then ''ACCOUNT'''||wwv_flow.LF||
'    when lead_id is not null then ''LEAD'''||wwv_flow.LF||
'  end;'||wwv_flow.LF||
' '||wwv_flow.LF||
'alter table e';
wwv_flow_imp.g_varchar2_table(8) := 'ba_sales_verifications '||wwv_flow.LF||
'modify (entity_type varchar2(20) not null)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_verifica';
wwv_flow_imp.g_varchar2_table(9) := 'tions '||wwv_flow.LF||
'add constraint eba_sales_verif_ent_type_ck '||wwv_flow.LF||
'check (entity_type in (''OPPORTUNITY'',''LEAD'',''TERR';
wwv_flow_imp.g_varchar2_table(10) := 'ITORY'',''ACCOUNT'', ''CONTACT'', ''PRODUCT''))'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table  eba_sales_verifications '||wwv_flow.LF||
'add foreign key (o';
wwv_flow_imp.g_varchar2_table(11) := 'pp_id)'||wwv_flow.LF||
'references  eba_sales_deals (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_verifications '||wwv_flow.LF||
'ad';
wwv_flow_imp.g_varchar2_table(12) := 'd (territory_id number)'||wwv_flow.LF||
'/   '||wwv_flow.LF||
''||wwv_flow.LF||
'alter table  eba_sales_verifications '||wwv_flow.LF||
'add constraint eba_sales_verif_t';
wwv_flow_imp.g_varchar2_table(13) := 'err_fk foreign key (territory_id)'||wwv_flow.LF||
'references  eba_sales_territories (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create';
wwv_flow_imp.g_varchar2_table(14) := ' index  eba_sales_verify_idx4 on eba_sales_verifications (territory_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_ver';
wwv_flow_imp.g_varchar2_table(15) := 'ifications '||wwv_flow.LF||
'add (contact_id number)'||wwv_flow.LF||
'/   '||wwv_flow.LF||
''||wwv_flow.LF||
'alter table  eba_sales_verifications '||wwv_flow.LF||
'add constraint eba_s';
wwv_flow_imp.g_varchar2_table(16) := 'ales_verif_contact_fk foreign key (contact_id)'||wwv_flow.LF||
'references  eba_sales_customer_contacts (id) on delet';
wwv_flow_imp.g_varchar2_table(17) := 'e cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index  eba_sales_verify_idx5 on eba_sales_verifications (contact_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter ta';
wwv_flow_imp.g_varchar2_table(18) := 'ble eba_sales_verifications '||wwv_flow.LF||
'add (product_id number)'||wwv_flow.LF||
'/   '||wwv_flow.LF||
''||wwv_flow.LF||
'alter table  eba_sales_verifications '||wwv_flow.LF||
'add';
wwv_flow_imp.g_varchar2_table(19) := ' constraint eba_sales_verif_product_fk foreign key (product_id)'||wwv_flow.LF||
'references  eba_sales_products (id) ';
wwv_flow_imp.g_varchar2_table(20) := 'on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index  eba_sales_verify_idx6 on eba_sales_verifications (product_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(21) := 'alter table eba_sales_verifications '||wwv_flow.LF||
'add constraint eba_sales_verif_ent_fk_ck '||wwv_flow.LF||
'check ('||wwv_flow.LF||
'  entity_type';
wwv_flow_imp.g_varchar2_table(22) := ' = ''OPPORTUNITY'' and opp_id is not null'||wwv_flow.LF||
'    or entity_type = ''LEAD'' and lead_id is not null'||wwv_flow.LF||
'    or e';
wwv_flow_imp.g_varchar2_table(23) := 'ntity_type = ''TERRITORY'' and territory_id is not null'||wwv_flow.LF||
'    or entity_type = ''ACCOUNT'' and cust_id is ';
wwv_flow_imp.g_varchar2_table(24) := 'not null'||wwv_flow.LF||
'    or entity_type = ''CONTACT'' and contact_id is not null'||wwv_flow.LF||
'    or entity_type = ''PRODUCT'' an';
wwv_flow_imp.g_varchar2_table(25) := 'd product_id is not null'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_sales_verify_biu_fer'||wwv_flow.LF||
'   before insert or';
wwv_flow_imp.g_varchar2_table(26) := ' update on eba_sales_verifications'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.id is null then'||wwv_flow.LF||
'     :new.id := ';
wwv_flow_imp.g_varchar2_table(27) := 'eba_sales_acl_api.gen_id();'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_timestamp';
wwv_flow_imp.g_varchar2_table(28) := ';'||wwv_flow.LF||
'       :new.created_by := nvl(apex_application.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.verified_by := low';
wwv_flow_imp.g_varchar2_table(29) := 'er(:new.verified_by);'||wwv_flow.LF||
'   :new.updated := current_timestamp;'||wwv_flow.LF||
'   :new.updated_by := nvl(apex_applicati';
wwv_flow_imp.g_varchar2_table(30) := 'on.g_user,user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'-- Add ability to do views on other entities'||wwv_flow.LF||
'alter table eba_sales_clicks'||wwv_flow.LF||
'ad';
wwv_flow_imp.g_varchar2_table(31) := 'd (entity_type varchar2(20))'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'update eba_sales_clicks'||wwv_flow.LF||
'set entity_type = '||wwv_flow.LF||
'  case'||wwv_flow.LF||
'    when opp_id is';
wwv_flow_imp.g_varchar2_table(32) := ' not null then ''OPPORTUNITY'''||wwv_flow.LF||
'    when cust_id is not null then ''ACCOUNT'''||wwv_flow.LF||
'    when lead_id is not nul';
wwv_flow_imp.g_varchar2_table(33) := 'l then ''LEAD'''||wwv_flow.LF||
'  end;'||wwv_flow.LF||
' '||wwv_flow.LF||
'alter table eba_sales_clicks '||wwv_flow.LF||
'modify (entity_type varchar2(20) not null)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'a';
wwv_flow_imp.g_varchar2_table(34) := 'lter table eba_sales_clicks '||wwv_flow.LF||
'add constraint eba_sales_clicks_ent_type_ck '||wwv_flow.LF||
'check (entity_type in (''OP';
wwv_flow_imp.g_varchar2_table(35) := 'PORTUNITY'',''LEAD'',''TERRITORY'',''ACCOUNT'', ''CONTACT'', ''PRODUCT''))'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'delete from eba_sales_clicks'||wwv_flow.LF||
'wher';
wwv_flow_imp.g_varchar2_table(36) := 'e opp_id is not null'||wwv_flow.LF||
'  and opp_id not in ('||wwv_flow.LF||
'    select id'||wwv_flow.LF||
'    from eba_sales_deals'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table ';
wwv_flow_imp.g_varchar2_table(37) := 'eba_sales_clicks'||wwv_flow.LF||
'add constraint eba_sales_clicks_opps_fk foreign key (opp_id)'||wwv_flow.LF||
'references eba_sales_d';
wwv_flow_imp.g_varchar2_table(38) := 'eals (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_clicks '||wwv_flow.LF||
'add (territory_id number)'||wwv_flow.LF||
'/   '||wwv_flow.LF||
''||wwv_flow.LF||
'alter t';
wwv_flow_imp.g_varchar2_table(39) := 'able  eba_sales_clicks '||wwv_flow.LF||
'add constraint eba_sales_clicks_terr_fk foreign key (territory_id)'||wwv_flow.LF||
'reference';
wwv_flow_imp.g_varchar2_table(40) := 's  eba_sales_territories (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_sales_clicks_idx5 on eba_sales_c';
wwv_flow_imp.g_varchar2_table(41) := 'licks (territory_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_clicks '||wwv_flow.LF||
'add (contact_id number)'||wwv_flow.LF||
'/   '||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_';
wwv_flow_imp.g_varchar2_table(42) := 'sales_clicks '||wwv_flow.LF||
'add constraint eba_sales_clicks_contact_fk foreign key (contact_id)'||wwv_flow.LF||
'references  eba_sa';
wwv_flow_imp.g_varchar2_table(43) := 'les_customer_contacts (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_sales_clicks_idx6 on eba_sales_clic';
wwv_flow_imp.g_varchar2_table(44) := 'ks (contact_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_clicks '||wwv_flow.LF||
'add (product_id number)'||wwv_flow.LF||
'/   '||wwv_flow.LF||
''||wwv_flow.LF||
'alter table  eba_sale';
wwv_flow_imp.g_varchar2_table(45) := 's_clicks '||wwv_flow.LF||
'add constraint eba_sales_clicks_product_fk foreign key (product_id)'||wwv_flow.LF||
'references  eba_sales_';
wwv_flow_imp.g_varchar2_table(46) := 'products (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index  eba_sales_clicks_idx7 on eba_sales_clicks (product_';
wwv_flow_imp.g_varchar2_table(47) := 'id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_clicks '||wwv_flow.LF||
'add constraint eba_sales_clicks_ent_fk_ck '||wwv_flow.LF||
'check ('||wwv_flow.LF||
'  entity_typ';
wwv_flow_imp.g_varchar2_table(48) := 'e = ''OPPORTUNITY'' and opp_id is not null'||wwv_flow.LF||
'    or entity_type = ''LEAD'' and lead_id is not null'||wwv_flow.LF||
'    or ';
wwv_flow_imp.g_varchar2_table(49) := 'entity_type = ''TERRITORY'' and territory_id is not null'||wwv_flow.LF||
'    or entity_type = ''ACCOUNT'' and cust_id is';
wwv_flow_imp.g_varchar2_table(50) := ' not null'||wwv_flow.LF||
'    or entity_type = ''CONTACT'' and contact_id is not null'||wwv_flow.LF||
'    or entity_type = ''PRODUCT'' a';
wwv_flow_imp.g_varchar2_table(51) := 'nd product_id is not null'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_sales_clicks_biu'||wwv_flow.LF||
'    before insert on e';
wwv_flow_imp.g_varchar2_table(52) := 'ba_sales_clicks'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        :new.id := eba_sales_acl_';
wwv_flow_imp.g_varchar2_table(53) := 'api.gen_id();'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    :new.view_timestamp := current_timestamp;'||wwv_flow.LF||
'    :new.app_session := v(''';
wwv_flow_imp.g_varchar2_table(54) := 'APP_SESSION'');'||wwv_flow.LF||
'    :new.app_username := lower(:new.app_username);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Migrate "LEAD_SOURCE" t';
wwv_flow_imp.g_varchar2_table(55) := 'o "LEAD_SOURCE_ID"'||wwv_flow.LF||
'declare'||wwv_flow.LF||
''||wwv_flow.LF||
'  l_lead_source_id eba_sales_lead_sources.id%type;'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  for lead_re';
wwv_flow_imp.g_varchar2_table(56) := 'c in ('||wwv_flow.LF||
'    select distinct lead_source'||wwv_flow.LF||
'    from eba_sales_leads'||wwv_flow.LF||
'    where lead_source is not null'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(57) := ')'||wwv_flow.LF||
'  loop'||wwv_flow.LF||
'    insert into eba_sales_lead_sources ('||wwv_flow.LF||
'      lead_source'||wwv_flow.LF||
'    ) values ('||wwv_flow.LF||
'      lead_rec.le';
wwv_flow_imp.g_varchar2_table(58) := 'ad_source'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'    returning id'||wwv_flow.LF||
'    into l_lead_source_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    update eba_sales_leads'||wwv_flow.LF||
'    set lead';
wwv_flow_imp.g_varchar2_table(59) := '_source_id = l_lead_source_id'||wwv_flow.LF||
'    where lead_source = lead_rec.lead_source;'||wwv_flow.LF||
'  end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'  execute i';
wwv_flow_imp.g_varchar2_table(60) := 'mmediate ''alter table eba_sales_leads drop column lead_source'';'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Add a fk constraint fo';
wwv_flow_imp.g_varchar2_table(61) := 'r eba_sales_customers.customer_territory_id (index already exists)'||wwv_flow.LF||
'alter table  eba_sales_customers'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(62) := 'add constraint eba_sales_cust_terr_fk foreign key (customer_territory_id)'||wwv_flow.LF||
'references  eba_sales_terr';
wwv_flow_imp.g_varchar2_table(63) := 'itories (id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_sales_error_lookup ('||wwv_flow.LF||
'  constraint_name,'||wwv_flow.LF||
'  message,'||wwv_flow.LF||
'  language_code'||wwv_flow.LF||
')';
wwv_flow_imp.g_varchar2_table(64) := ' values ('||wwv_flow.LF||
'  ''EBA_SALES_CUST_TERR_FK'','||wwv_flow.LF||
'  ''There are Accounts associated with this territory'','||wwv_flow.LF||
'  ''en'''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(65) := ');'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Migrates existing references to "Unknown" source type to use null instead'||wwv_flow.LF||
'declare'||wwv_flow.LF||
''||wwv_flow.LF||
'  l_unkn';
wwv_flow_imp.g_varchar2_table(66) := 'own_exists number := 0;'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  begin'||wwv_flow.LF||
'    select 1'||wwv_flow.LF||
'    into l_unknown_exists'||wwv_flow.LF||
'    from eba_sales_le';
wwv_flow_imp.g_varchar2_table(67) := 'ad_sources'||wwv_flow.LF||
'    where id = 4'||wwv_flow.LF||
'      and lead_source = ''Unknown'';'||wwv_flow.LF||
'  exception'||wwv_flow.LF||
'    when no_data_found'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(68) := '  then'||wwv_flow.LF||
'      null;'||wwv_flow.LF||
'  end;'||wwv_flow.LF||
''||wwv_flow.LF||
'  if l_unknown_exists = 1'||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    update eba_sales_leads'||wwv_flow.LF||
'    set lead_';
wwv_flow_imp.g_varchar2_table(69) := 'source_id = null'||wwv_flow.LF||
'    where lead_source_id = 4;'||wwv_flow.LF||
''||wwv_flow.LF||
'    delete from eba_sales_lead_sources'||wwv_flow.LF||
'    where id ';
wwv_flow_imp.g_varchar2_table(70) := '= 4;'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Make eba_sales_customers.customer_is_key_account_yn not null'||wwv_flow.LF||
'update eba';
wwv_flow_imp.g_varchar2_table(71) := '_sales_customers'||wwv_flow.LF||
'set customer_is_key_account_yn = ''N'''||wwv_flow.LF||
'where customer_is_key_account_yn is null;'||wwv_flow.LF||
''||wwv_flow.LF||
'alt';
wwv_flow_imp.g_varchar2_table(72) := 'er table eba_sales_customers'||wwv_flow.LF||
'modify (customer_is_key_account_yn varchar2(1) not null);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Migrate';
wwv_flow_imp.g_varchar2_table(73) := 's eba_sales_leads.account_name to eba_sales_leads.account_id'||wwv_flow.LF||
'declare'||wwv_flow.LF||
''||wwv_flow.LF||
'  l_lead_account_id eba_sales_';
wwv_flow_imp.g_varchar2_table(74) := 'customers.id%type;'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  for lead_rec in ('||wwv_flow.LF||
'    select distinct account_name'||wwv_flow.LF||
'    from eba_sales_l';
wwv_flow_imp.g_varchar2_table(75) := 'eads'||wwv_flow.LF||
'    where account_name is not null'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  loop'||wwv_flow.LF||
'    insert into eba_sales_customers ('||wwv_flow.LF||
'      custo';
wwv_flow_imp.g_varchar2_table(76) := 'mer_name'||wwv_flow.LF||
'    ) values ('||wwv_flow.LF||
'      lead_rec.account_name'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'    returning id'||wwv_flow.LF||
'    into l_lead_account_i';
wwv_flow_imp.g_varchar2_table(77) := 'd;'||wwv_flow.LF||
''||wwv_flow.LF||
'    update eba_sales_leads'||wwv_flow.LF||
'    set account_id = l_lead_account_id'||wwv_flow.LF||
'    where account_name = lead_';
wwv_flow_imp.g_varchar2_table(78) := 'rec.account_name;'||wwv_flow.LF||
'  end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'  execute immediate ''alter table eba_sales_leads drop column account_';
wwv_flow_imp.g_varchar2_table(79) := 'name'';'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Add foreign key for EBA_SALES_CUSTOMERS.DEFAULT_REP_ID to EBA_SALES_SALESREPS.I';
wwv_flow_imp.g_varchar2_table(80) := 'D'||wwv_flow.LF||
'alter table  eba_sales_customers '||wwv_flow.LF||
'add constraint eba_sales_cust_reps_fk foreign key (default_rep_i';
wwv_flow_imp.g_varchar2_table(81) := 'd)'||wwv_flow.LF||
'references  eba_sales_salesreps (id) on delete set null'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index  eba_sales_customers_i5 o';
wwv_flow_imp.g_varchar2_table(82) := 'n eba_sales_customers (default_rep_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Change eba_sales_territories.match_words to eba_sales';
wwv_flow_imp.g_varchar2_table(83) := '_territories.tags'||wwv_flow.LF||
'alter table eba_sales_territories '||wwv_flow.LF||
'rename column match_words to tags'||wwv_flow.LF||
'/   '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Up';
wwv_flow_imp.g_varchar2_table(84) := 'date territory trigger for tag sync'||wwv_flow.LF||
'create or replace trigger biu_eba_sales_terr'||wwv_flow.LF||
'before insert or up';
wwv_flow_imp.g_varchar2_table(85) := 'date on eba_sales_territories'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(86) := '   select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end i';
wwv_flow_imp.g_varchar2_table(87) := 'f;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created :';
wwv_flow_imp.g_varchar2_table(88) := '= current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := cur';
wwv_flow_imp.g_varchar2_table(89) := 'rent_timestamp;'||wwv_flow.LF||
'        :new.row_key := eba_sales_fw.compress_int(eba_sales_rowkey_seq.nextval);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(90) := '     :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(';
wwv_flow_imp.g_varchar2_table(91) := 'v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := n';
wwv_flow_imp.g_varchar2_table(92) := 'vl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- tags'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    eba_sales_fw.tag_sync(';
wwv_flow_imp.g_varchar2_table(93) := ''||wwv_flow.LF||
'        p_new_tags      => :new.tags,'||wwv_flow.LF||
'        p_old_tags      => :old.tags,'||wwv_flow.LF||
'        p_content_type ';
wwv_flow_imp.g_varchar2_table(94) := ' => ''TERRITORY'','||wwv_flow.LF||
'        p_content_id    => :new.id );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Update tag constraint to handle ';
wwv_flow_imp.g_varchar2_table(95) := 'additional types'||wwv_flow.LF||
'alter table eba_sales_tags '||wwv_flow.LF||
'drop constraint eba_sales_tags_ck'||wwv_flow.LF||
'/   '||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba';
wwv_flow_imp.g_varchar2_table(96) := '_sales_tags '||wwv_flow.LF||
'add constraint eba_sales_tags_ck '||wwv_flow.LF||
'check (content_type in (''ACCOUNT'',''CONTACT'',''DEAL'',''C';
wwv_flow_imp.g_varchar2_table(97) := 'OMPETITOR'', ''TERRITORY'', ''PRODUCT'', ''LEAD''))'||wwv_flow.LF||
'/   '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Make eba_sales_customer_contacts.customer_id';
wwv_flow_imp.g_varchar2_table(98) := ' required'||wwv_flow.LF||
'alter table eba_sales_customer_contacts '||wwv_flow.LF||
'modify (customer_id number not null)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Upda';
wwv_flow_imp.g_varchar2_table(99) := 'te eba_sales_links to work with multiple entities'||wwv_flow.LF||
'alter table eba_sales_links '||wwv_flow.LF||
'modify (link_target v';
wwv_flow_imp.g_varchar2_table(100) := 'archar2(4000) not null)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_links '||wwv_flow.LF||
'add (entity_type varchar2(20))'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'update eba';
wwv_flow_imp.g_varchar2_table(101) := '_sales_links'||wwv_flow.LF||
'set entity_type = ''OPPORTUNITY'';'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_links '||wwv_flow.LF||
'modify (entity_type varc';
wwv_flow_imp.g_varchar2_table(102) := 'har2(20) not null)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_links '||wwv_flow.LF||
'add constraint eba_sales_links_ent_type_ck '||wwv_flow.LF||
'check';
wwv_flow_imp.g_varchar2_table(103) := ' (entity_type in (''OPPORTUNITY'',''LEAD'',''TERRITORY'',''ACCOUNT'', ''CONTACT'', ''PRODUCT''))'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter index ';
wwv_flow_imp.g_varchar2_table(104) := 'eba_sales_links_i1 rename to eba_sales_links_idx1'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_links '||wwv_flow.LF||
'add (lead_id numbe';
wwv_flow_imp.g_varchar2_table(105) := 'r)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_links'||wwv_flow.LF||
'add constraint eba_sales_links_leads_fk foreign key (lead_id)'||wwv_flow.LF||
'refe';
wwv_flow_imp.g_varchar2_table(106) := 'rences  eba_sales_leads (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_sales_links_idx2 on eba_sales_lin';
wwv_flow_imp.g_varchar2_table(107) := 'ks (lead_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_links '||wwv_flow.LF||
'add (territory_id number)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_link';
wwv_flow_imp.g_varchar2_table(108) := 's'||wwv_flow.LF||
'add constraint eba_sales_links_terr_fk foreign key (territory_id)'||wwv_flow.LF||
'references  eba_sales_territorie';
wwv_flow_imp.g_varchar2_table(109) := 's (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_sales_links_idx3 on eba_sales_links (territory_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'a';
wwv_flow_imp.g_varchar2_table(110) := 'lter table eba_sales_links '||wwv_flow.LF||
'add (account_id number)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_links'||wwv_flow.LF||
'add constraint eb';
wwv_flow_imp.g_varchar2_table(111) := 'a_sales_links_acct_fk foreign key (account_id)'||wwv_flow.LF||
'references  eba_sales_customers (id) on delete cascad';
wwv_flow_imp.g_varchar2_table(112) := 'e'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_sales_links_idx4 on eba_sales_links (account_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_link';
wwv_flow_imp.g_varchar2_table(113) := 's '||wwv_flow.LF||
'add (contact_id number)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_links'||wwv_flow.LF||
'add constraint eba_sales_links_cont_fk for';
wwv_flow_imp.g_varchar2_table(114) := 'eign key (contact_id)'||wwv_flow.LF||
'references  eba_sales_customer_contacts (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index';
wwv_flow_imp.g_varchar2_table(115) := ' eba_sales_links_idx5 on eba_sales_links (contact_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_links '||wwv_flow.LF||
'add (product_i';
wwv_flow_imp.g_varchar2_table(116) := 'd number)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_links'||wwv_flow.LF||
'add constraint eba_sales_links_prod_fk foreign key (product';
wwv_flow_imp.g_varchar2_table(117) := '_id)'||wwv_flow.LF||
'references  eba_sales_products (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_sales_links_idx6 on e';
wwv_flow_imp.g_varchar2_table(118) := 'ba_sales_links (product_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_links '||wwv_flow.LF||
'add constraint eba_sales_links_ent_fk_ck';
wwv_flow_imp.g_varchar2_table(119) := ' '||wwv_flow.LF||
'check ('||wwv_flow.LF||
'  entity_type = ''OPPORTUNITY'' and deal_id is not null'||wwv_flow.LF||
'    or entity_type = ''LEAD'' and lead';
wwv_flow_imp.g_varchar2_table(120) := '_id is not null'||wwv_flow.LF||
'    or entity_type = ''TERRITORY'' and territory_id is not null'||wwv_flow.LF||
'    or entity_type = ''';
wwv_flow_imp.g_varchar2_table(121) := 'ACCOUNT'' and account_id is not null'||wwv_flow.LF||
'    or entity_type = ''CONTACT'' and contact_id is not null'||wwv_flow.LF||
'    or';
wwv_flow_imp.g_varchar2_table(122) := ' entity_type = ''PRODUCT'' and product_id is not null'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger biu_eba_sales_links disable'||wwv_flow.LF||
'/';
wwv_flow_imp.g_varchar2_table(123) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  insert into eba_sales_links ('||wwv_flow.LF||
'    id,'||wwv_flow.LF||
'    row_version_number,'||wwv_flow.LF||
'    entity_type,'||wwv_flow.LF||
'    accoun';
wwv_flow_imp.g_varchar2_table(124) := 't_id,'||wwv_flow.LF||
'    link_target,'||wwv_flow.LF||
'    link_text,'||wwv_flow.LF||
'    link_comments,'||wwv_flow.LF||
'    tags,'||wwv_flow.LF||
'    created,'||wwv_flow.LF||
'    created_by,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(125) := 'updated,'||wwv_flow.LF||
'    updated_by'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX''),'||wwv_flow.LF||
'    r';
wwv_flow_imp.g_varchar2_table(126) := 'ow_version_number,'||wwv_flow.LF||
'    ''ACCOUNT'','||wwv_flow.LF||
'    account_id,'||wwv_flow.LF||
'    link_target,'||wwv_flow.LF||
'    link_text,'||wwv_flow.LF||
'    link_comments,';
wwv_flow_imp.g_varchar2_table(127) := ''||wwv_flow.LF||
'    tags,'||wwv_flow.LF||
'    created,'||wwv_flow.LF||
'    created_by,'||wwv_flow.LF||
'    updated,'||wwv_flow.LF||
'    updated_by'||wwv_flow.LF||
'  from eba_sales_act_links;'||wwv_flow.LF||
''||wwv_flow.LF||
'  e';
wwv_flow_imp.g_varchar2_table(128) := 'xecute immediate ''drop table eba_sales_act_links'';'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger biu_eba_sales_links enable';
wwv_flow_imp.g_varchar2_table(129) := ''||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'update eba_sales_links'||wwv_flow.LF||
'set link_text = link_target'||wwv_flow.LF||
'where link_text is null;'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sal';
wwv_flow_imp.g_varchar2_table(130) := 'es_links '||wwv_flow.LF||
'modify (link_text varchar2(255) not null)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Update eba_sales_files to work with mult';
wwv_flow_imp.g_varchar2_table(131) := 'iple entities'||wwv_flow.LF||
'alter table eba_sales_files'||wwv_flow.LF||
'add (entity_type varchar2(20))'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'update eba_sales_files'||wwv_flow.LF||
's';
wwv_flow_imp.g_varchar2_table(132) := 'et entity_type = ''OPPORTUNITY'';'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_files '||wwv_flow.LF||
'modify (entity_type varchar2(20) not n';
wwv_flow_imp.g_varchar2_table(133) := 'ull)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_files '||wwv_flow.LF||
'add constraint eba_sales_files_ent_type_ck '||wwv_flow.LF||
'check (entity_type ';
wwv_flow_imp.g_varchar2_table(134) := 'in (''OPPORTUNITY'',''LEAD'',''TERRITORY'',''ACCOUNT'', ''CONTACT'', ''PRODUCT''))'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter index eba_sales_file';
wwv_flow_imp.g_varchar2_table(135) := 's_i1 rename to eba_sales_files_idx1'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_files '||wwv_flow.LF||
'add (lead_id number)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter ta';
wwv_flow_imp.g_varchar2_table(136) := 'ble eba_sales_files'||wwv_flow.LF||
'add constraint eba_sales_files_leads_fk foreign key (lead_id)'||wwv_flow.LF||
'references  eba_sa';
wwv_flow_imp.g_varchar2_table(137) := 'les_leads (id)  on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_sales_files_idx2 on eba_sales_files (lead_id)'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(138) := '/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_files '||wwv_flow.LF||
'add (territory_id number)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_files'||wwv_flow.LF||
'add constra';
wwv_flow_imp.g_varchar2_table(139) := 'int eba_sales_files_terr_fk foreign key (territory_id)'||wwv_flow.LF||
'references  eba_sales_territories (id) on del';
wwv_flow_imp.g_varchar2_table(140) := 'ete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_sales_files_idx3 on eba_sales_files (territory_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eb';
wwv_flow_imp.g_varchar2_table(141) := 'a_sales_files '||wwv_flow.LF||
'add (account_id number)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_files'||wwv_flow.LF||
'add constraint eba_sales_files';
wwv_flow_imp.g_varchar2_table(142) := '_acct_fk foreign key (account_id)'||wwv_flow.LF||
'references  eba_sales_customers (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create i';
wwv_flow_imp.g_varchar2_table(143) := 'ndex eba_sales_files_idx4 on eba_sales_files (account_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_files '||wwv_flow.LF||
'add (conta';
wwv_flow_imp.g_varchar2_table(144) := 'ct_id number)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_files'||wwv_flow.LF||
'add constraint eba_sales_files_cont_fk foreign key (con';
wwv_flow_imp.g_varchar2_table(145) := 'tact_id)'||wwv_flow.LF||
'references  eba_sales_customer_contacts (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_sales_fi';
wwv_flow_imp.g_varchar2_table(146) := 'les_idx5 on eba_sales_files (contact_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_files '||wwv_flow.LF||
'add (product_id number)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(147) := 'alter table eba_sales_files'||wwv_flow.LF||
'add constraint eba_sales_files_prod_fk foreign key (product_id)'||wwv_flow.LF||
'referenc';
wwv_flow_imp.g_varchar2_table(148) := 'es  eba_sales_products (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_sales_files_idx6 on eba_sales_file';
wwv_flow_imp.g_varchar2_table(149) := 's (product_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_files '||wwv_flow.LF||
'add constraint eba_sales_files_ent_fk_ck '||wwv_flow.LF||
'check ('||wwv_flow.LF||
'  e';
wwv_flow_imp.g_varchar2_table(150) := 'ntity_type = ''OPPORTUNITY'' and deal_id is not null'||wwv_flow.LF||
'    or entity_type = ''LEAD'' and lead_id is not nu';
wwv_flow_imp.g_varchar2_table(151) := 'll'||wwv_flow.LF||
'    or entity_type = ''TERRITORY'' and territory_id is not null'||wwv_flow.LF||
'    or entity_type = ''ACCOUNT'' and ';
wwv_flow_imp.g_varchar2_table(152) := 'account_id is not null'||wwv_flow.LF||
'    or entity_type = ''CONTACT'' and contact_id is not null'||wwv_flow.LF||
'    or entity_type ';
wwv_flow_imp.g_varchar2_table(153) := '= ''PRODUCT'' and product_id is not null'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger biu_eba_sales_files disable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  in';
wwv_flow_imp.g_varchar2_table(154) := 'sert into eba_sales_files ('||wwv_flow.LF||
'    id,'||wwv_flow.LF||
'    row_version_number,'||wwv_flow.LF||
'    entity_type,'||wwv_flow.LF||
'    account_id,'||wwv_flow.LF||
'    fil';
wwv_flow_imp.g_varchar2_table(155) := 'ename,'||wwv_flow.LF||
'    file_mimetype,'||wwv_flow.LF||
'    file_charset,'||wwv_flow.LF||
'    file_blob,'||wwv_flow.LF||
'    file_comments,'||wwv_flow.LF||
'    tags,'||wwv_flow.LF||
'    created,';
wwv_flow_imp.g_varchar2_table(156) := ''||wwv_flow.LF||
'    created_by,'||wwv_flow.LF||
'    updated,'||wwv_flow.LF||
'    updated_by'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(157) := 'XXXXXXXXXXXX''),'||wwv_flow.LF||
'    row_version_number,'||wwv_flow.LF||
'    ''ACCOUNT'','||wwv_flow.LF||
'    account_id,'||wwv_flow.LF||
'    filename,'||wwv_flow.LF||
'    file_mimety';
wwv_flow_imp.g_varchar2_table(158) := 'pe,'||wwv_flow.LF||
'    file_charset,'||wwv_flow.LF||
'    file_blob,'||wwv_flow.LF||
'    file_comments,'||wwv_flow.LF||
'    tags,'||wwv_flow.LF||
'    created,'||wwv_flow.LF||
'    created_by,'||wwv_flow.LF||
'    u';
wwv_flow_imp.g_varchar2_table(159) := 'pdated,'||wwv_flow.LF||
'    updated_by'||wwv_flow.LF||
'  from eba_sales_act_files;'||wwv_flow.LF||
''||wwv_flow.LF||
'  execute immediate ''drop table eba_sales_act_fi';
wwv_flow_imp.g_varchar2_table(160) := 'les'';'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger biu_eba_sales_files enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Update eba_sales_deal_notes to work ';
wwv_flow_imp.g_varchar2_table(161) := 'with multiple entities'||wwv_flow.LF||
'alter table eba_sales_deal_notes'||wwv_flow.LF||
'rename to eba_sales_comments'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table ';
wwv_flow_imp.g_varchar2_table(162) := 'eba_sales_comments'||wwv_flow.LF||
'modify (deal_id number null)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_comments'||wwv_flow.LF||
'add (entity_type v';
wwv_flow_imp.g_varchar2_table(163) := 'archar2(20))'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'update eba_sales_comments'||wwv_flow.LF||
'set entity_type = ''OPPORTUNITY'';'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_co';
wwv_flow_imp.g_varchar2_table(164) := 'mments '||wwv_flow.LF||
'modify (entity_type varchar2(20) not null)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_comments '||wwv_flow.LF||
'add constraint';
wwv_flow_imp.g_varchar2_table(165) := ' eba_sales_comments_ent_type_ck '||wwv_flow.LF||
'check (entity_type in (''OPPORTUNITY'',''LEAD'',''TERRITORY'',''ACCOUNT'', ';
wwv_flow_imp.g_varchar2_table(166) := '''CONTACT'', ''PRODUCT''))'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter index eba_sales_deal_notes_i1 rename to eba_sales_comments_idx1'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'a';
wwv_flow_imp.g_varchar2_table(167) := 'lter table eba_sales_comments'||wwv_flow.LF||
'rename constraint eba_sales_deal_note_fk to eba_sales_comments_opps_fk';
wwv_flow_imp.g_varchar2_table(168) := ''||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_comments '||wwv_flow.LF||
'add (lead_id number)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_comments'||wwv_flow.LF||
'add const';
wwv_flow_imp.g_varchar2_table(169) := 'raint eba_sales_comments_leads_fk foreign key (lead_id)'||wwv_flow.LF||
'references  eba_sales_leads (id)  on delete ';
wwv_flow_imp.g_varchar2_table(170) := 'cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_sales_comments_idx2 on eba_sales_comments (lead_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_s';
wwv_flow_imp.g_varchar2_table(171) := 'ales_comments '||wwv_flow.LF||
'add (territory_id number)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_comments'||wwv_flow.LF||
'add constraint eba_sales_';
wwv_flow_imp.g_varchar2_table(172) := 'comments_terrs_fk foreign key (territory_id)'||wwv_flow.LF||
'references  eba_sales_territories (id) on delete cascad';
wwv_flow_imp.g_varchar2_table(173) := 'e'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_sales_comments_idx3 on eba_sales_comments (territory_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sa';
wwv_flow_imp.g_varchar2_table(174) := 'les_comments '||wwv_flow.LF||
'add (account_id number)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_comments'||wwv_flow.LF||
'add constraint eba_sales_com';
wwv_flow_imp.g_varchar2_table(175) := 'ments_acnts_fk foreign key (account_id)'||wwv_flow.LF||
'references  eba_sales_customers (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'cr';
wwv_flow_imp.g_varchar2_table(176) := 'eate index eba_sales_comments_idx4 on eba_sales_comments (account_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_comme';
wwv_flow_imp.g_varchar2_table(177) := 'nts '||wwv_flow.LF||
'add (contact_id number)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_comments'||wwv_flow.LF||
'add constraint eba_sales_comments_cnt';
wwv_flow_imp.g_varchar2_table(178) := 's_fk foreign key (contact_id)'||wwv_flow.LF||
'references  eba_sales_customer_contacts (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'crea';
wwv_flow_imp.g_varchar2_table(179) := 'te index eba_sales_comments_idx5 on eba_sales_comments (contact_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_comment';
wwv_flow_imp.g_varchar2_table(180) := 's '||wwv_flow.LF||
'add (product_id number)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_comments'||wwv_flow.LF||
'add constraint eba_sales_comments_prods';
wwv_flow_imp.g_varchar2_table(181) := '_fk foreign key (product_id)'||wwv_flow.LF||
'references  eba_sales_products (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index e';
wwv_flow_imp.g_varchar2_table(182) := 'ba_sales_comments_idx6 on eba_sales_comments (product_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_comments '||wwv_flow.LF||
'add con';
wwv_flow_imp.g_varchar2_table(183) := 'straint eba_sales_comments_ent_fk_ck '||wwv_flow.LF||
'check ('||wwv_flow.LF||
'  entity_type = ''OPPORTUNITY'' and deal_id is not null'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(184) := '    or entity_type = ''LEAD'' and lead_id is not null'||wwv_flow.LF||
'    or entity_type = ''TERRITORY'' and territory_i';
wwv_flow_imp.g_varchar2_table(185) := 'd is not null'||wwv_flow.LF||
'    or entity_type = ''ACCOUNT'' and account_id is not null'||wwv_flow.LF||
'    or entity_type = ''CONTAC';
wwv_flow_imp.g_varchar2_table(186) := 'T'' and contact_id is not null'||wwv_flow.LF||
'    or entity_type = ''PRODUCT'' and product_id is not null'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter t';
wwv_flow_imp.g_varchar2_table(187) := 'rigger biu_eba_sales_deal_notes'||wwv_flow.LF||
'rename to biu_eba_sales_comments'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger biu_eba_sales_comm';
wwv_flow_imp.g_varchar2_table(188) := 'ents disable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  insert into eba_sales_comments ('||wwv_flow.LF||
'    id,'||wwv_flow.LF||
'    row_version_number,'||wwv_flow.LF||
'    entity';
wwv_flow_imp.g_varchar2_table(189) := '_type,'||wwv_flow.LF||
'    account_id,'||wwv_flow.LF||
'    note,'||wwv_flow.LF||
'    created,'||wwv_flow.LF||
'    created_by,'||wwv_flow.LF||
'    updated,'||wwv_flow.LF||
'    updated_by'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  sele';
wwv_flow_imp.g_varchar2_table(190) := 'ct to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX''),'||wwv_flow.LF||
'    row_version_number,'||wwv_flow.LF||
'    ''ACCOUNT'','||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(191) := '    account_id,'||wwv_flow.LF||
'    note,'||wwv_flow.LF||
'    created,'||wwv_flow.LF||
'    created_by,'||wwv_flow.LF||
'    updated,'||wwv_flow.LF||
'    updated_by'||wwv_flow.LF||
'  from eba_sales_';
wwv_flow_imp.g_varchar2_table(192) := 'actnotes'||wwv_flow.LF||
'  where note is not null;'||wwv_flow.LF||
''||wwv_flow.LF||
'  execute immediate ''drop table eba_sales_actnotes'';'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'al';
wwv_flow_imp.g_varchar2_table(193) := 'ter trigger biu_eba_sales_comments enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Drop redundant or unused columns'||wwv_flow.LF||
'alter table eba_sa';
wwv_flow_imp.g_varchar2_table(194) := 'les_deals'||wwv_flow.LF||
'drop column territory_id'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_leads'||wwv_flow.LF||
'drop column territory_id'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter ';
wwv_flow_imp.g_varchar2_table(195) := 'table eba_sales_terr_map '||wwv_flow.LF||
'drop column account_id'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_customers'||wwv_flow.LF||
'drop column cust';
wwv_flow_imp.g_varchar2_table(196) := 'omer_address1'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_customers'||wwv_flow.LF||
'drop column customer_address2'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sa';
wwv_flow_imp.g_varchar2_table(197) := 'les_customers'||wwv_flow.LF||
'drop column customer_city'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_customers'||wwv_flow.LF||
'drop column customer_stat';
wwv_flow_imp.g_varchar2_table(198) := 'e'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_customers'||wwv_flow.LF||
'drop column customer_country'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_customers';
wwv_flow_imp.g_varchar2_table(199) := ''||wwv_flow.LF||
'drop column customer_postal_code'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_sales_customer_contacts'||wwv_flow.LF||
'drop column customer_lo';
wwv_flow_imp.g_varchar2_table(200) := 'cation_id'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Drop unused objects'||wwv_flow.LF||
'drop table eba_sales_account_activity'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table eba_sales_';
wwv_flow_imp.g_varchar2_table(201) := 'prefs'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table eba_sales_favorites'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'drop function eba_sales_id'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'drop function eba_sales_for';
wwv_flow_imp.g_varchar2_table(202) := 'mat_note'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'drop procedure eba_sales_disp_notifications'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Update eba_sales_opportunities_v to ';
wwv_flow_imp.g_varchar2_table(203) := 'match updated objects'||wwv_flow.LF||
'create or replace view eba_sales_opportunities_v'||wwv_flow.LF||
'as'||wwv_flow.LF||
'  select d.id, '||wwv_flow.LF||
'    d.row_';
wwv_flow_imp.g_varchar2_table(204) := 'key,'||wwv_flow.LF||
'    c.id customer_id,'||wwv_flow.LF||
'    c.customer_name,'||wwv_flow.LF||
'    s.rep_last_name || '', '' || s.rep_first_name as r';
wwv_flow_imp.g_varchar2_table(205) := 'ep_name,'||wwv_flow.LF||
'    d.deal_name,'||wwv_flow.LF||
'    d.deal_close_date,'||wwv_flow.LF||
'    d.deal_close_date_alt,'||wwv_flow.LF||
'    d.deal_amount,'||wwv_flow.LF||
'    d';
wwv_flow_imp.g_varchar2_table(206) := '.deal_probability,'||wwv_flow.LF||
'    sc.status_code,'||wwv_flow.LF||
'    case'||wwv_flow.LF||
'      when d.deal_probability is null '||wwv_flow.LF||
'        or d.';
wwv_flow_imp.g_varchar2_table(207) := 'deal_probability in (0, 100)'||wwv_flow.LF||
'      then ''No'''||wwv_flow.LF||
'      else ''Yes'''||wwv_flow.LF||
'    end is_open,'||wwv_flow.LF||
'    case '||wwv_flow.LF||
'      when ';
wwv_flow_imp.g_varchar2_table(208) := 'd.deal_probability in (0, 100)'||wwv_flow.LF||
'      then ''No'''||wwv_flow.LF||
'      when greatest(sysdate, d.deal_close_date) = sys';
wwv_flow_imp.g_varchar2_table(209) := 'date'||wwv_flow.LF||
'      then ''Yes'''||wwv_flow.LF||
'      else ''No'''||wwv_flow.LF||
'    end is_overdue,'||wwv_flow.LF||
'    d.deal_amount * d.deal_probability / 1';
wwv_flow_imp.g_varchar2_table(210) := '00 weighted_forecast,'||wwv_flow.LF||
'    ('||wwv_flow.LF||
'      select count(*) '||wwv_flow.LF||
'      from eba_sales_comments '||wwv_flow.LF||
'      where deal_i';
wwv_flow_imp.g_varchar2_table(211) := 'd = d.id'||wwv_flow.LF||
'    ) notes,'||wwv_flow.LF||
'    ('||wwv_flow.LF||
'      select count(*) '||wwv_flow.LF||
'      from eba_sales_deal_products '||wwv_flow.LF||
'      where d';
wwv_flow_imp.g_varchar2_table(212) := 'eal_id = d.id'||wwv_flow.LF||
'    ) products,'||wwv_flow.LF||
'    nvl(d.updated, d.created) last_changed,'||wwv_flow.LF||
'    ('||wwv_flow.LF||
'      select svp_nam';
wwv_flow_imp.g_varchar2_table(213) := 'e '||wwv_flow.LF||
'      from eba_sales_svps svp '||wwv_flow.LF||
'      where svp.id = d.svp_id'||wwv_flow.LF||
'    ) svp,'||wwv_flow.LF||
'    t.territory_name,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(214) := ' d.qtr,'||wwv_flow.LF||
'    d.tags,'||wwv_flow.LF||
'    c.tags customer_tags'||wwv_flow.LF||
'  from eba_sales_deals d'||wwv_flow.LF||
'  join eba_sales_customers c'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(215) := '   on c.id = d.customer_id '||wwv_flow.LF||
'  left join eba_sales_salesreps s'||wwv_flow.LF||
'    on s.id = d.salesrep_id_01'||wwv_flow.LF||
'  left ';
wwv_flow_imp.g_varchar2_table(216) := 'join eba_sales_deal_status_codes sc'||wwv_flow.LF||
'    on sc.id = d.deal_status_code_id'||wwv_flow.LF||
'  left join eba_sales_terri';
wwv_flow_imp.g_varchar2_table(217) := 'tories t'||wwv_flow.LF||
'    on t.id = c.customer_territory_id'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Update eba_sales_opp_v to match updated objec';
wwv_flow_imp.g_varchar2_table(218) := 'ts'||wwv_flow.LF||
'create or replace view eba_sales_opp_v'||wwv_flow.LF||
'as '||wwv_flow.LF||
'  select c.id customer_id,'||wwv_flow.LF||
'    d.id deal_id,'||wwv_flow.LF||
'    c.cus';
wwv_flow_imp.g_varchar2_table(219) := 'tomer_name,'||wwv_flow.LF||
'    c.customer_stock_symb,'||wwv_flow.LF||
'    sr.rep_first_name,'||wwv_flow.LF||
'    sr.rep_last_name,'||wwv_flow.LF||
'    sr.rep_email';
wwv_flow_imp.g_varchar2_table(220) := ','||wwv_flow.LF||
'    d.deal_name,'||wwv_flow.LF||
'    d.deal_close_date,'||wwv_flow.LF||
'    case when exists (select null'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(221) := 'from APEX_APPLICATION_BUILD_OPTIONS'||wwv_flow.LF||
'                       where application_id = v(''APP_ID'')'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(222) := '                   and BUILD_OPTION_NAME = ''Opportunity Amount Set at Product Level'''||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(223) := '          and BUILD_OPTION_STATUS = ''Exclude'') then'||wwv_flow.LF||
'        d.deal_amount'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        (select s';
wwv_flow_imp.g_varchar2_table(224) := 'um(nvl(quote_price, 0.00)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id)'||wwv_flow.LF||
'    end as deal_';
wwv_flow_imp.g_varchar2_table(225) := 'amount,'||wwv_flow.LF||
'    d.deal_probability,'||wwv_flow.LF||
'    dsc.status_code '||wwv_flow.LF||
'  from  eba_sales_deals d'||wwv_flow.LF||
'  join eba_sales_deal';
wwv_flow_imp.g_varchar2_table(226) := '_status_codes dsc'||wwv_flow.LF||
'    on dsc.id = d.deal_status_code_id'||wwv_flow.LF||
'  join eba_sales_salesreps sr'||wwv_flow.LF||
'    on sr.id =';
wwv_flow_imp.g_varchar2_table(227) := ' d.salesrep_id_01'||wwv_flow.LF||
'  join eba_sales_customers c'||wwv_flow.LF||
'    on c.id = d.customer_id'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Add tag sync to b';
wwv_flow_imp.g_varchar2_table(228) := 'iu_eba_sales_leads and bd_eba_sales_leads'||wwv_flow.LF||
'create or replace trigger biu_eba_sales_leads'||wwv_flow.LF||
'  before ins';
wwv_flow_imp.g_varchar2_table(229) := 'ert or update on eba_sales_leads'||wwv_flow.LF||
'  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  if inserting '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    if :new.id is null';
wwv_flow_imp.g_varchar2_table(230) := ' '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(231) := '    :new.row_version_number := 1;'||wwv_flow.LF||
'    :new.row_key := eba_sales_fw.compress_int(eba_sales_rowkey_seq';
wwv_flow_imp.g_varchar2_table(232) := '.nextval);'||wwv_flow.LF||
''||wwv_flow.LF||
'    :new.created_by := nvl(v(''APP_USER''), user);'||wwv_flow.LF||
'    :new.created := current_timestamp;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(233) := '    :new.updated_by := nvl(v(''APP_USER''), user);'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'  elsif upda';
wwv_flow_imp.g_varchar2_table(234) := 'ting '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''), user);'||wwv_flow.LF||
'    :new.updated := current_timestamp;';
wwv_flow_imp.g_varchar2_table(235) := ''||wwv_flow.LF||
'    :new.row_version_number := nvl(:old.row_version_number, 1) + 1;'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  if :new.tags is no';
wwv_flow_imp.g_varchar2_table(236) := 't null '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    :new.tags := eba_sales_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  eba_sales_fw.tag_';
wwv_flow_imp.g_varchar2_table(237) := 'sync('||wwv_flow.LF||
'    p_new_tags     => :new.tags,'||wwv_flow.LF||
'    p_old_tags     => :old.tags,'||wwv_flow.LF||
'    p_content_type => ''LEAD''';
wwv_flow_imp.g_varchar2_table(238) := ','||wwv_flow.LF||
'    p_content_id   => :new.id'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger bd_eba_sales_leads'||wwv_flow.LF||
'  before ';
wwv_flow_imp.g_varchar2_table(239) := 'delete on eba_sales_leads'||wwv_flow.LF||
'  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  eba_sales_fw.tag_sync('||wwv_flow.LF||
'    p_new_tags     => null,';
wwv_flow_imp.g_varchar2_table(240) := ''||wwv_flow.LF||
'    p_old_tags     => :old.tags,'||wwv_flow.LF||
'    p_content_type => ''LEAD'','||wwv_flow.LF||
'    p_content_id   => :old.id'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(241) := 'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Fix tag sync for eba_sales_terr'||wwv_flow.LF||
'create or replace trigger biu_eba_sales_terr'||wwv_flow.LF||
'  before i';
wwv_flow_imp.g_varchar2_table(242) := 'nsert or update on eba_sales_territories'||wwv_flow.LF||
'  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  if inserting '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    if :new.id';
wwv_flow_imp.g_varchar2_table(243) := ' is null '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(244) := 'nd if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    :new.row_version_number := 1;'||wwv_flow.LF||
'    :new.row_key := eba_sales_fw.compress_int(eba_sales_ro';
wwv_flow_imp.g_varchar2_table(245) := 'wkey_seq.nextval);'||wwv_flow.LF||
''||wwv_flow.LF||
'    :new.created_by := nvl(v(''APP_USER''), user);'||wwv_flow.LF||
'    :new.created := current_tim';
wwv_flow_imp.g_varchar2_table(246) := 'estamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''), user);'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'  el';
wwv_flow_imp.g_varchar2_table(247) := 'sif updating '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''), user);'||wwv_flow.LF||
'    :new.updated := current_ti';
wwv_flow_imp.g_varchar2_table(248) := 'mestamp;'||wwv_flow.LF||
'    :new.row_version_number := nvl(:old.row_version_number, 1) + 1;'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  if :new.ta';
wwv_flow_imp.g_varchar2_table(249) := 'gs is not null '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    :new.tags := eba_sales_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  eba_sales';
wwv_flow_imp.g_varchar2_table(250) := '_fw.tag_sync('||wwv_flow.LF||
'    p_new_tags     => :new.tags,'||wwv_flow.LF||
'    p_old_tags     => :old.tags,'||wwv_flow.LF||
'    p_content_type =';
wwv_flow_imp.g_varchar2_table(251) := '> ''TERRITORY'','||wwv_flow.LF||
'    p_content_id   => :new.id'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger bd_eba_sales_te';
wwv_flow_imp.g_varchar2_table(252) := 'rr'||wwv_flow.LF||
'  before delete on eba_sales_territories'||wwv_flow.LF||
'  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  eba_sales_fw.tag_sync('||wwv_flow.LF||
'    p_new';
wwv_flow_imp.g_varchar2_table(253) := '_tags     => null,'||wwv_flow.LF||
'    p_old_tags     => :old.tags,'||wwv_flow.LF||
'    p_content_type => ''TERRITORY'','||wwv_flow.LF||
'    p_content';
wwv_flow_imp.g_varchar2_table(254) := '_id   => :old.id'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Fix tag sync for eba_sales_cust'||wwv_flow.LF||
'create or replace trigger biu_eb';
wwv_flow_imp.g_varchar2_table(255) := 'a_sales_cust'||wwv_flow.LF||
'  before insert or update on eba_sales_customers'||wwv_flow.LF||
'  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  if inserting '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(256) := '  then'||wwv_flow.LF||
'    if :new.id is null '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(257) := 'XXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    :new.row_version_number := 1;'||wwv_flow.LF||
'    :new.row_key := eba_sales_fw.comp';
wwv_flow_imp.g_varchar2_table(258) := 'ress_int(eba_sales_rowkey_seq.nextval);'||wwv_flow.LF||
''||wwv_flow.LF||
'    :new.created_by := nvl(v(''APP_USER''), user);'||wwv_flow.LF||
'    :new.c';
wwv_flow_imp.g_varchar2_table(259) := 'reated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''), user);'||wwv_flow.LF||
'    :new.updated := cu';
wwv_flow_imp.g_varchar2_table(260) := 'rrent_timestamp;'||wwv_flow.LF||
'  elsif updating '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''), user);'||wwv_flow.LF||
'    :new.';
wwv_flow_imp.g_varchar2_table(261) := 'updated := current_timestamp;'||wwv_flow.LF||
'    :new.row_version_number := nvl(:old.row_version_number, 1) + 1;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(262) := 'end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  if :new.tags is not null '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    :new.tags := eba_sales_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(263) := ' end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  eba_sales_fw.tag_sync('||wwv_flow.LF||
'    p_new_tags     => :new.tags,'||wwv_flow.LF||
'    p_old_tags     => :old.tags,';
wwv_flow_imp.g_varchar2_table(264) := ''||wwv_flow.LF||
'    p_content_type => ''ACCOUNT'','||wwv_flow.LF||
'    p_content_id   => :new.id'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trig';
wwv_flow_imp.g_varchar2_table(265) := 'ger bd_eba_sales_cust'||wwv_flow.LF||
'  before delete on eba_sales_customers'||wwv_flow.LF||
'  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  eba_sales_fw.ta';
wwv_flow_imp.g_varchar2_table(266) := 'g_sync('||wwv_flow.LF||
'    p_new_tags     => null,'||wwv_flow.LF||
'    p_old_tags     => :old.tags,'||wwv_flow.LF||
'    p_content_type => ''ACCOUNT''';
wwv_flow_imp.g_varchar2_table(267) := ','||wwv_flow.LF||
'    p_content_id   => :old.id'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Fix tag sync for eba_sales_cust_contacts'||wwv_flow.LF||
'create o';
wwv_flow_imp.g_varchar2_table(268) := 'r replace trigger biu_eba_sales_cust_contacts'||wwv_flow.LF||
'  before insert or update on eba_sales_customer_contac';
wwv_flow_imp.g_varchar2_table(269) := 'ts'||wwv_flow.LF||
'  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  if inserting '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    if :new.id is null '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'      :new.id := to';
wwv_flow_imp.g_varchar2_table(270) := '_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    :new.row_version_number :=';
wwv_flow_imp.g_varchar2_table(271) := ' 1;'||wwv_flow.LF||
'    :new.row_key := eba_sales_fw.compress_int(eba_sales_rowkey_seq.nextval);'||wwv_flow.LF||
''||wwv_flow.LF||
'    :new.created_b';
wwv_flow_imp.g_varchar2_table(272) := 'y := nvl(v(''APP_USER''), user);'||wwv_flow.LF||
'    :new.created := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''';
wwv_flow_imp.g_varchar2_table(273) := 'APP_USER''), user);'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'  elsif updating '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    :new.updated_';
wwv_flow_imp.g_varchar2_table(274) := 'by := nvl(v(''APP_USER''), user);'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.row_version_number :';
wwv_flow_imp.g_varchar2_table(275) := '= nvl(:old.row_version_number, 1) + 1;'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  if :new.tags is not null '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    :new.tags :';
wwv_flow_imp.g_varchar2_table(276) := '= eba_sales_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  eba_sales_fw.tag_sync('||wwv_flow.LF||
'    p_new_tags     => :n';
wwv_flow_imp.g_varchar2_table(277) := 'ew.tags,'||wwv_flow.LF||
'    p_old_tags     => :old.tags,'||wwv_flow.LF||
'    p_content_type => ''CONTACT'','||wwv_flow.LF||
'    p_content_id   => :ne';
wwv_flow_imp.g_varchar2_table(278) := 'w.id'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger bd_eba_sales_cust_contacts'||wwv_flow.LF||
'  before delete on eba_sales';
wwv_flow_imp.g_varchar2_table(279) := '_customer_contacts'||wwv_flow.LF||
'  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  eba_sales_fw.tag_sync('||wwv_flow.LF||
'    p_new_tags     => null,'||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(280) := 'old_tags     => :old.tags,'||wwv_flow.LF||
'    p_content_type => ''CONTACT'','||wwv_flow.LF||
'    p_content_id   => :old.id'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;';
wwv_flow_imp.g_varchar2_table(281) := ''||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Fix tag sync fo eba_sales_products'||wwv_flow.LF||
'create or replace trigger biu_eba_sales_products'||wwv_flow.LF||
'  befor';
wwv_flow_imp.g_varchar2_table(282) := 'e insert or update on eba_sales_products'||wwv_flow.LF||
'  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  if inserting '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    if :new.id';
wwv_flow_imp.g_varchar2_table(283) := ' is null '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(284) := 'nd if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    :new.row_version_number := 1;'||wwv_flow.LF||
'    :new.row_key := eba_sales_fw.compress_int(eba_sales_ro';
wwv_flow_imp.g_varchar2_table(285) := 'wkey_seq.nextval);'||wwv_flow.LF||
''||wwv_flow.LF||
'    :new.created_by := nvl(v(''APP_USER''), user);'||wwv_flow.LF||
'    :new.created := current_tim';
wwv_flow_imp.g_varchar2_table(286) := 'estamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''), user);'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'  el';
wwv_flow_imp.g_varchar2_table(287) := 'sif updating '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''), user);'||wwv_flow.LF||
'    :new.updated := current_ti';
wwv_flow_imp.g_varchar2_table(288) := 'mestamp;'||wwv_flow.LF||
'    :new.row_version_number := nvl(:old.row_version_number, 1) + 1;'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  if :new.ta';
wwv_flow_imp.g_varchar2_table(289) := 'gs is not null '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    :new.tags := eba_sales_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  eba_sales';
wwv_flow_imp.g_varchar2_table(290) := '_fw.tag_sync('||wwv_flow.LF||
'    p_new_tags     => :new.tags,'||wwv_flow.LF||
'    p_old_tags     => :old.tags,'||wwv_flow.LF||
'    p_content_type =';
wwv_flow_imp.g_varchar2_table(291) := '> ''PRODUCT'','||wwv_flow.LF||
'    p_content_id   => :new.id'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger bd_eba_sales_prod';
wwv_flow_imp.g_varchar2_table(292) := 'ucts'||wwv_flow.LF||
'  before delete on eba_sales_products'||wwv_flow.LF||
'  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  eba_sales_fw.tag_sync('||wwv_flow.LF||
'    p_new_';
wwv_flow_imp.g_varchar2_table(293) := 'tags     => null,'||wwv_flow.LF||
'    p_old_tags     => :old.tags,'||wwv_flow.LF||
'    p_content_type => ''PRODUCT'','||wwv_flow.LF||
'    p_content_id';
wwv_flow_imp.g_varchar2_table(294) := '   => :old.id'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Repoplate tags tables'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  delete from eba_sales_tags;'||wwv_flow.LF||
'  delete';
wwv_flow_imp.g_varchar2_table(295) := ' from eba_sales_tags_sum;'||wwv_flow.LF||
'  delete from eba_sales_tags_type_sum;'||wwv_flow.LF||
''||wwv_flow.LF||
'  for entity_rec in ('||wwv_flow.LF||
'    select ''';
wwv_flow_imp.g_varchar2_table(296) := 'LEAD'' entity_type, id entity_id, tags from eba_sales_leads where tags is not null'||wwv_flow.LF||
'    union'||wwv_flow.LF||
'    sele';
wwv_flow_imp.g_varchar2_table(297) := 'ct ''DEAL'' entity_type, id entity_id, tags from eba_sales_deals where tags is not null'||wwv_flow.LF||
'    union'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(298) := 'select ''TERRITORY'' entity_type, id entity_id, tags from eba_sales_territories where tags is not null';
wwv_flow_imp.g_varchar2_table(299) := ''||wwv_flow.LF||
'    union'||wwv_flow.LF||
'    select ''ACCOUNT'' entity_type, id entity_id, tags from eba_sales_customers where tags ';
wwv_flow_imp.g_varchar2_table(300) := 'is not null'||wwv_flow.LF||
'    union'||wwv_flow.LF||
'    select ''CONTACT'' entity_type, id entity_id, tags from eba_sales_customer_c';
wwv_flow_imp.g_varchar2_table(301) := 'ontacts where tags is not null'||wwv_flow.LF||
'    union'||wwv_flow.LF||
'    select ''PRODUCT'' entity_type, id entity_id, tags from e';
wwv_flow_imp.g_varchar2_table(302) := 'ba_sales_products where tags is not null'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'  loop'||wwv_flow.LF||
'    entity_rec.tags := eba_sales_fw.tags_cleaner';
wwv_flow_imp.g_varchar2_table(303) := '(entity_rec.tags);'||wwv_flow.LF||
''||wwv_flow.LF||
'    eba_sales_fw.tag_sync('||wwv_flow.LF||
'      p_new_tags     => entity_rec.tags,'||wwv_flow.LF||
'      p_old_';
wwv_flow_imp.g_varchar2_table(304) := 'tags     => null,'||wwv_flow.LF||
'      p_content_type => entity_rec.entity_type,'||wwv_flow.LF||
'      p_content_id   => entity_rec';
wwv_flow_imp.g_varchar2_table(305) := '.entity_id'||wwv_flow.LF||
'    );'||wwv_flow.LF||
'  end loop;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- add eba_sales_product_families table'||wwv_flow.LF||
'create table eba_sales';
wwv_flow_imp.g_varchar2_table(306) := '_product_families( /* NAS, NAA, GBU */'||wwv_flow.LF||
'    id              number,'||wwv_flow.LF||
'    product_family  varchar2(100)';
wwv_flow_imp.g_varchar2_table(307) := ','||wwv_flow.LF||
'    description     varchar2(4000),'||wwv_flow.LF||
'    created         timestamp(6) with time zone,'||wwv_flow.LF||
'    created_b';
wwv_flow_imp.g_varchar2_table(308) := 'y      varchar2(255),'||wwv_flow.LF||
'    updated         timestamp(6) with time zone,'||wwv_flow.LF||
'    updated_by      varchar2(';
wwv_flow_imp.g_varchar2_table(309) := '255),'||wwv_flow.LF||
'    constraint eba_sales_product_families_pk primary key ( id )'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger';
wwv_flow_imp.g_varchar2_table(310) := ' "biu_eba_sales_product_families" '||wwv_flow.LF||
'   before insert or update on eba_sales_product_families'||wwv_flow.LF||
'   for e';
wwv_flow_imp.g_varchar2_table(311) := 'ach row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.id is null then'||wwv_flow.LF||
'     :new.id := eba_sales_acl_api.gen_id();'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   i';
wwv_flow_imp.g_varchar2_table(312) := 'f inserting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(apex_applic';
wwv_flow_imp.g_varchar2_table(313) := 'ation.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.updated := current_timestamp;'||wwv_flow.LF||
'   :new.updated_by := nvl(apex_';
wwv_flow_imp.g_varchar2_table(314) := 'application.g_user,user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger "biu_eba_sales_product_families" enable;'||wwv_flow.LF||
''||wwv_flow.LF||
'insert int';
wwv_flow_imp.g_varchar2_table(315) := 'o eba_sales_product_families (id, product_family, description) values (1, ''NAA'',''North America Appli';
wwv_flow_imp.g_varchar2_table(316) := 'cations (App Sales)'');'||wwv_flow.LF||
'insert into eba_sales_product_families (id, product_family, description) valu';
wwv_flow_imp.g_varchar2_table(317) := 'es (2, ''NAS'',''North America Sales (Tech & Hardware Sales)'');'||wwv_flow.LF||
'insert into eba_sales_product_families ';
wwv_flow_imp.g_varchar2_table(318) := '(id, product_family, description) values (3, ''GBU'',''Global Business Unit'');'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_sales_';
wwv_flow_imp.g_varchar2_table(319) := 'terms'||wwv_flow.LF||
'('||wwv_flow.LF||
'    id          number not null primary key,'||wwv_flow.LF||
'    name        varchar2(255),'||wwv_flow.LF||
'    month_equiv ';
wwv_flow_imp.g_varchar2_table(320) := 'number,'||wwv_flow.LF||
'    created_by  varchar2(255),'||wwv_flow.LF||
'    created     timestamp (6) with time zone,'||wwv_flow.LF||
'    updated_by ';
wwv_flow_imp.g_varchar2_table(321) := ' varchar2(255),'||wwv_flow.LF||
'    updated     timestamp (6) with time zone'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_s';
wwv_flow_imp.g_varchar2_table(322) := 'ales_terms'||wwv_flow.LF||
'before insert or update on eba_sales_terms'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :n';
wwv_flow_imp.g_varchar2_table(323) := 'ew.id is null then'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new';
wwv_flow_imp.g_varchar2_table(324) := '.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);';
wwv_flow_imp.g_varchar2_table(325) := ''||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(326) := '    :new.updated := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by := n';
wwv_flow_imp.g_varchar2_table(327) := 'vl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger';
wwv_flow_imp.g_varchar2_table(328) := ' biu_eba_sales_terms enable;'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_sales_terms (id, name, month_equiv) values (1, ''1 Mont';
wwv_flow_imp.g_varchar2_table(329) := 'h'', 1);'||wwv_flow.LF||
'insert into eba_sales_terms (id, name, month_equiv) values (2, ''1 Year'', 12);'||wwv_flow.LF||
'insert into eb';
wwv_flow_imp.g_varchar2_table(330) := 'a_sales_terms (id, name, month_equiv) values (3, ''2 Years'', 24);'||wwv_flow.LF||
'insert into eba_sales_terms (id, na';
wwv_flow_imp.g_varchar2_table(331) := 'me, month_equiv) values (4, ''3 Years'', 36);'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Set the initial Representative Title preference valu';
wwv_flow_imp.g_varchar2_table(332) := 'e'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba_sales_fw.set_preference_value(''REP_TITLE'', ''Sales Rep'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- add product_fami';
wwv_flow_imp.g_varchar2_table(333) := 'ly_id to products table'||wwv_flow.LF||
'alter table eba_sales_products add product_family_id number;'||wwv_flow.LF||
'alter table eba';
wwv_flow_imp.g_varchar2_table(334) := '_sales_products add constraint eba_sales_products_families_fk foreign key (product_family_id)'||wwv_flow.LF||
'    re';
wwv_flow_imp.g_varchar2_table(335) := 'ferences eba_sales_product_families (id) on delete set null enable;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Recreate deal_products biu t';
wwv_flow_imp.g_varchar2_table(336) := 'rigger'||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER "BIU_EBA_SALES_DEAL_PRODUCTS" '||wwv_flow.LF||
'before insert or update on EBA_SALES';
wwv_flow_imp.g_varchar2_table(337) := '_DEAL_products'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        select to_nu';
wwv_flow_imp.g_varchar2_table(338) := 'mber(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    for c1 i';
wwv_flow_imp.g_varchar2_table(339) := 'n (select period_name from eba_sales_sales_periods where :new.close_date between first_day and last_';
wwv_flow_imp.g_varchar2_table(340) := 'day)'||wwv_flow.LF||
'    loop '||wwv_flow.LF||
'        :new.qtr := c1.period_name; '||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new';
wwv_flow_imp.g_varchar2_table(341) := '.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.upda';
wwv_flow_imp.g_varchar2_table(342) := 'ted_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_key :';
wwv_flow_imp.g_varchar2_table(343) := '= eba_sales_fw.compress_int(eba_sales_rowkey_seq.nextval);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(344) := ' end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updat';
wwv_flow_imp.g_varchar2_table(345) := 'ed := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(346) := 'end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TRIGGER "BIU_EBA_SALES_DEAL_PRODUCTS" ENABLE;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6818270718358958790)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'Upgrade data model to 3.0.0'
,p_sequence=>70
,p_script_type=>'UPGRADE'
,p_condition_type=>'EXPRESSION'
,p_condition=>'eba_sales_fw.get_preference_value(''DATA_MODEL_VERSION'') = ''2.1.5'''
,p_condition2=>'PLSQL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
