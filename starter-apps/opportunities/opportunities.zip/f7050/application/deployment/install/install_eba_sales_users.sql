prompt --application/deployment/install/install_eba_sales_users
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_users
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_USERS" '||wwv_flow.LF||
'   (	"ID" NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'	"USERNAME" VARCHAR2(255) NOT NUL';
wwv_flow_imp.g_varchar2_table(2) := 'L ENABLE, '||wwv_flow.LF||
'	"ACCESS_LEVEL_ID" NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'	"ACCOUNT_LOCKED" VARCHAR2(1) NOT NULL ENABLE';
wwv_flow_imp.g_varchar2_table(3) := ', '||wwv_flow.LF||
'	"ROW_VERSION" NUMBER, '||wwv_flow.LF||
'	"CREATED_BY" VARCHAR2(255) NOT NULL ENABLE, '||wwv_flow.LF||
'	"CREATED" TIMESTAMP (6) WI';
wwv_flow_imp.g_varchar2_table(4) := 'TH TIME ZONE, '||wwv_flow.LF||
'	"UPDATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	 CONSTRAINT ';
wwv_flow_imp.g_varchar2_table(5) := '"EBA_SALES_USERS_USERNAME_CK" CHECK (upper(username)=username) ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SALES_USER';
wwv_flow_imp.g_varchar2_table(6) := 'S_ACC_LOCKED_CK" CHECK (account_locked in (''Y'',''N'')) ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SALES_USERS_PK" PRIM';
wwv_flow_imp.g_varchar2_table(7) := 'ARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_USERS" ADD CONSTRAINT "EBA_SALES';
wwv_flow_imp.g_varchar2_table(8) := '_USERS_ACC_LEVEL_FK" FOREIGN KEY ("ACCESS_LEVEL_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_ACCESS_LEVELS" ("ID") ';
wwv_flow_imp.g_varchar2_table(9) := 'ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814633335059266045)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_users'
,p_sequence=>220
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814633508274266046)
,p_script_id=>wwv_flow_imp.id(6814633335059266045)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_USERS'
);
wwv_flow_imp.component_end;
end;
/
