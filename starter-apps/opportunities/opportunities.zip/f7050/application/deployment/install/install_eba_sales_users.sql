prompt --application/deployment/install/install_eba_sales_users
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_users
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814633335059266045)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_users'
,p_sequence=>220
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_USERS" ',
'   (	"ID" NUMBER NOT NULL ENABLE, ',
'	"USERNAME" VARCHAR2(255) NOT NULL ENABLE, ',
'	"ACCESS_LEVEL_ID" NUMBER NOT NULL ENABLE, ',
'	"ACCOUNT_LOCKED" VARCHAR2(1) NOT NULL ENABLE, ',
'	"ROW_VERSION" NUMBER, ',
'	"CREATED_BY" VARCHAR2(255) NOT NULL ENABLE, ',
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"UPDATED_BY" VARCHAR2(255), ',
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	 CONSTRAINT "EBA_SALES_USERS_USERNAME_CK" CHECK (upper(username)=username) ENABLE, ',
'	 CONSTRAINT "EBA_SALES_USERS_ACC_LOCKED_CK" CHECK (account_locked in (''Y'',''N'')) ENABLE, ',
'	 CONSTRAINT "EBA_SALES_USERS_PK" PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'ALTER TABLE "EBA_SALES_USERS" ADD CONSTRAINT "EBA_SALES_USERS_ACC_LEVEL_FK" FOREIGN KEY ("ACCESS_LEVEL_ID")',
'	  REFERENCES "EBA_SALES_ACCESS_LEVELS" ("ID") ENABLE;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814633508274266046)
,p_script_id=>wwv_flow_imp.id(6814633335059266045)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_USERS'
);
wwv_flow_imp.component_end;
end;
/
