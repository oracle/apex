prompt --application/deployment/install/install_data
begin
--   Manifest
--     INSTALL: INSTALL-data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  eba_sales_fw.set_preference_value(''REP_TITLE'', ''Sales Rep'');'||wwv_flow.LF||
'  eba_sales_data.load_codes;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(2) := 'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6815454861056430633)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'data'
,p_sequence=>650
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
