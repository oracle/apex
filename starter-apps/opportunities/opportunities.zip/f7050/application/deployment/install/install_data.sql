prompt --application/deployment/install/install_data
begin
--   Manifest
--     INSTALL: INSTALL-data
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(6797732669095677230)
,p_install_id=>wwv_flow_api.id(10495272006180774354)
,p_name=>'data'
,p_sequence=>650
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'  eba_sales_fw.set_preference_value(''REP_TITLE'', ''Sales Rep'');',
'  eba_sales_data.load_codes;',
'',
'end;',
'/'))
);
wwv_flow_api.component_end;
end;
/
