prompt --application/deployment/install/install_eba_sales_deal_team
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_deal_team
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_DEAL_TEAM" '||wwv_flow.LF||
'   (	"ID" NUMBER, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER, '||wwv_flow.LF||
'	"DEAL_ID" NUM';
wwv_flow_imp.g_varchar2_table(2) := 'BER NOT NULL ENABLE, '||wwv_flow.LF||
'	"REP_ID" NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'	"CREATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"CREATED" TI';
wwv_flow_imp.g_varchar2_table(3) := 'MESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"UPDATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, ';
wwv_flow_imp.g_varchar2_table(4) := ''||wwv_flow.LF||
'	 PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_DEAL_TEAM" ADD FOREIGN KE';
wwv_flow_imp.g_varchar2_table(5) := 'Y ("DEAL_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_DEALS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SAL';
wwv_flow_imp.g_varchar2_table(6) := 'ES_DEAL_TEAM" ADD FOREIGN KEY ("REP_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_SALESREPS" ("ID") ON DELETE CASCAD';
wwv_flow_imp.g_varchar2_table(7) := 'E ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814584996151107404)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_deal_team'
,p_sequence=>320
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814585032266107405)
,p_script_id=>wwv_flow_imp.id(6814584996151107404)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_DEAL_TEAM'
);
wwv_flow_imp.component_end;
end;
/
