prompt --application/deployment/install/upgrade_set_data_model_version_to_3_0_0
begin
--   Manifest
--     INSTALL: UPGRADE-Set data model version to 3.0.0
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
'  eba_sales_fw.set_preference_value(''DATA_MODEL_VERSION'', ''3.0.0'');'||wwv_flow.LF||
'end;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6818273417463080726)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'Set data model version to 3.0.0'
,p_sequence=>230
,p_script_type=>'UPGRADE'
,p_condition_type=>'EXPRESSION'
,p_condition=>'eba_sales_fw.get_preference_value(''DATA_MODEL_VERSION'') = ''2.1.5'''
,p_condition2=>'PLSQL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
