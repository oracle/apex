prompt --application/deployment/install/install_eba_sales_product_families
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_product_families
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_sales_product_families( /* NAS, NAA, GBU */'||wwv_flow.LF||
'    id              number,'||wwv_flow.LF||
'    product';
wwv_flow_imp.g_varchar2_table(2) := '_family  varchar2(100),'||wwv_flow.LF||
'    description     varchar2(4000),'||wwv_flow.LF||
'    lob_id          NUMBER references eb';
wwv_flow_imp.g_varchar2_table(3) := 'a_sales_product_lobs,'||wwv_flow.LF||
'    created         timestamp(6) with time zone,'||wwv_flow.LF||
'    created_by      varchar2(';
wwv_flow_imp.g_varchar2_table(4) := '255),'||wwv_flow.LF||
'    updated         timestamp(6) with time zone,'||wwv_flow.LF||
'    updated_by      varchar2(255),'||wwv_flow.LF||
'    constr';
wwv_flow_imp.g_varchar2_table(5) := 'aint eba_sales_product_families_pk primary key ( id )'||wwv_flow.LF||
')'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6942125953130248389)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_product_families'
,p_sequence=>150
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
