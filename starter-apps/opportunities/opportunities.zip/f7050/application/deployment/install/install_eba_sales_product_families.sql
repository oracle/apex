prompt --application/deployment/install/install_eba_sales_product_families
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_product_families
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6942125953130248389)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_product_families'
,p_sequence=>150
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table eba_sales_product_families( /* NAS, NAA, GBU */',
'    id              number,',
'    product_family  varchar2(100),',
'    description     varchar2(4000),',
'    lob_id          NUMBER references eba_sales_product_lobs,',
'    created         timestamp(6) with time zone,',
'    created_by      varchar2(255),',
'    updated         timestamp(6) with time zone,',
'    updated_by      varchar2(255),',
'    constraint eba_sales_product_families_pk primary key ( id )',
')',
'/'))
);
wwv_flow_imp.component_end;
end;
/
