prompt --application/deployment/install/install_eba_sales_terr_map
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_terr_map
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-13'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(6796909857076505084)
,p_install_id=>wwv_flow_api.id(10495272006180774354)
,p_name=>'eba_sales_terr_map'
,p_sequence=>480
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_TERR_MAP" ',
'   (	"ID" NUMBER, ',
'	"ROW_VERSION_NUMBER" NUMBER NOT NULL ENABLE, ',
'	"TERRITORY_ID" NUMBER NOT NULL ENABLE, ',
'	"STATE_ID" NUMBER, ',
'	"COUNTRY_ID" NUMBER, ',
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"CREATED_BY" VARCHAR2(255), ',
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"UPDATED_BY" VARCHAR2(255), ',
'	 CONSTRAINT "EBA_SALES_TERR_MAP_PK" PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'ALTER TABLE "EBA_SALES_TERR_MAP" ADD CONSTRAINT "EBA_SALES_TERR_MAP_FK" FOREIGN KEY ("TERRITORY_ID")',
'	  REFERENCES "EBA_SALES_TERRITORIES" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_TERR_MAP" ADD CONSTRAINT "EBA_SALES_TERR_MAP_FK3" FOREIGN KEY ("STATE_ID")',
'	  REFERENCES "EBA_SALES_STATES" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_TERR_MAP" ADD CONSTRAINT "EBA_SALES_TERR_MAP_FK4" FOREIGN KEY ("COUNTRY_ID")',
'	  REFERENCES "EBA_SALES_COUNTRIES" ("ID") ON DELETE CASCADE ENABLE;',
'',
''))
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6796909952497505085)
,p_script_id=>wwv_flow_api.id(6796909857076505084)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_TERR_MAP'
,p_last_updated_on=>to_date('20160706141906','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706141906','YYYYMMDDHH24MISS')
);
wwv_flow_api.component_end;
end;
/
