prompt --application/deployment/install/install_eba_sales_terr_map
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_terr_map
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_TERR_MAP" '||wwv_flow.LF||
'   (	"ID" NUMBER, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER NOT NULL ENABLE, ';
wwv_flow_imp.g_varchar2_table(2) := ''||wwv_flow.LF||
'	"TERRITORY_ID" NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'	"STATE_ID" NUMBER, '||wwv_flow.LF||
'	"COUNTRY_ID" NUMBER, '||wwv_flow.LF||
'	"CREATED" TIM';
wwv_flow_imp.g_varchar2_table(3) := 'ESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"CREATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(4) := '	"UPDATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SALES_TERR_MAP_PK" PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX ';
wwv_flow_imp.g_varchar2_table(5) := ' ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_TERR_MAP" ADD CONSTRAINT "EBA_SALES_TERR_MAP_FK" FOREIGN KEY ';
wwv_flow_imp.g_varchar2_table(6) := '("TERRITORY_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_TERRITORIES" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE';
wwv_flow_imp.g_varchar2_table(7) := ' "EBA_SALES_TERR_MAP" ADD CONSTRAINT "EBA_SALES_TERR_MAP_FK3" FOREIGN KEY ("STATE_ID")'||wwv_flow.LF||
'	  REFERENCES';
wwv_flow_imp.g_varchar2_table(8) := ' "EBA_SALES_STATES" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_TERR_MAP" ADD CONSTRAIN';
wwv_flow_imp.g_varchar2_table(9) := 'T "EBA_SALES_TERR_MAP_FK4" FOREIGN KEY ("COUNTRY_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_COUNTRIES" ("ID") ON ';
wwv_flow_imp.g_varchar2_table(10) := 'DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814632049037258487)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_terr_map'
,p_sequence=>480
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814632144458258488)
,p_script_id=>wwv_flow_imp.id(6814632049037258487)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_TERR_MAP'
);
wwv_flow_imp.component_end;
end;
/
