prompt --application/deployment/install/install_eba_sales_terr_map
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_terr_map
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814632049037258487)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_terr_map'
,p_sequence=>480
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_TERR_MAP" ',
'   (	"ID" NUMBER, ',
'	"ROW_VERSION_NUMBER" NUMBER NOT NULL ENABLE, ',
'	"TERRITORY_ID" NUMBER NOT NULL ENABLE, ',
'	"STATE_ID" NUMBER, ',
'	"COUNTRY_ID" NUMBER, ',
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"CREATED_BY" VARCHAR2(255), ',
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"UPDATED_BY" VARCHAR2(255), ',
'	 CONSTRAINT "EBA_SALES_TERR_MAP_PK" PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'ALTER TABLE "EBA_SALES_TERR_MAP" ADD CONSTRAINT "EBA_SALES_TERR_MAP_FK" FOREIGN KEY ("TERRITORY_ID")',
'	  REFERENCES "EBA_SALES_TERRITORIES" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_TERR_MAP" ADD CONSTRAINT "EBA_SALES_TERR_MAP_FK3" FOREIGN KEY ("STATE_ID")',
'	  REFERENCES "EBA_SALES_STATES" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_TERR_MAP" ADD CONSTRAINT "EBA_SALES_TERR_MAP_FK4" FOREIGN KEY ("COUNTRY_ID")',
'	  REFERENCES "EBA_SALES_COUNTRIES" ("ID") ON DELETE CASCADE ENABLE;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814632144458258488)
,p_script_id=>wwv_flow_imp.id(6814632049037258487)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_TERR_MAP'
);
wwv_flow_imp.component_end;
end;
/
