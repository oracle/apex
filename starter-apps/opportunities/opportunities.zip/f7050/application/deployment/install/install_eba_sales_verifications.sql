prompt --application/deployment/install/install_eba_sales_verifications
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_verifications
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_VERIFICATIONS" '||wwv_flow.LF||
'   (	"ID" NUMBER, '||wwv_flow.LF||
'	"CUST_ID" NUMBER, '||wwv_flow.LF||
'	"LEAD_ID" NUMBER, '||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(2) := '"OPP_ID" NUMBER, '||wwv_flow.LF||
'	"VERIFICATION_COMMENT" VARCHAR2(4000), '||wwv_flow.LF||
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, ';
wwv_flow_imp.g_varchar2_table(3) := ''||wwv_flow.LF||
'	"CREATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"UPDATED_BY" VARCHAR2(255)';
wwv_flow_imp.g_varchar2_table(4) := ', '||wwv_flow.LF||
'	"TERRITORY_ID" NUMBER, '||wwv_flow.LF||
'	"ENTITY_TYPE" VARCHAR2(20) NOT NULL ENABLE, '||wwv_flow.LF||
'	"CONTACT_ID" NUMBER, '||wwv_flow.LF||
'	"P';
wwv_flow_imp.g_varchar2_table(5) := 'RODUCT_ID" NUMBER, '||wwv_flow.LF||
'	"VERIFIED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	 PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CO';
wwv_flow_imp.g_varchar2_table(6) := 'NSTRAINT "EBA_SALES_VERIF_ENT_TYPE_CK" CHECK (entity_type in (''OPPORTUNITY'',''LEAD'',''TERRITORY'',''ACCO';
wwv_flow_imp.g_varchar2_table(7) := 'UNT'', ''CONTACT'', ''PRODUCT'')) ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SALES_VERIF_ENT_FK_CK" CHECK ('||wwv_flow.LF||
'  entity_type';
wwv_flow_imp.g_varchar2_table(8) := ' = ''OPPORTUNITY'' and opp_id is not null'||wwv_flow.LF||
'    or entity_type = ''LEAD'' and lead_id is not null'||wwv_flow.LF||
'    or e';
wwv_flow_imp.g_varchar2_table(9) := 'ntity_type = ''TERRITORY'' and territory_id is not null'||wwv_flow.LF||
'    or entity_type = ''ACCOUNT'' and cust_id is ';
wwv_flow_imp.g_varchar2_table(10) := 'not null'||wwv_flow.LF||
'    or entity_type = ''CONTACT'' and contact_id is not null'||wwv_flow.LF||
'    or entity_type = ''PRODUCT'' an';
wwv_flow_imp.g_varchar2_table(11) := 'd product_id is not null'||wwv_flow.LF||
') ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_VERIFICATIONS" ADD CONSTRAINT "EBA_';
wwv_flow_imp.g_varchar2_table(12) := 'SALES_VERIF_CONTACT_FK" FOREIGN KEY ("CONTACT_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_CUSTOMER_CONTACTS" ("ID"';
wwv_flow_imp.g_varchar2_table(13) := ') ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_VERIFICATIONS" ADD CONSTRAINT "EBA_SALES_VERIF_P';
wwv_flow_imp.g_varchar2_table(14) := 'RODUCT_FK" FOREIGN KEY ("PRODUCT_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_PRODUCTS" ("ID") ON DELETE CASCADE EN';
wwv_flow_imp.g_varchar2_table(15) := 'ABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_VERIFICATIONS" ADD FOREIGN KEY ("CUST_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_CU';
wwv_flow_imp.g_varchar2_table(16) := 'STOMERS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_VERIFICATIONS" ADD FOREIGN KEY ("L';
wwv_flow_imp.g_varchar2_table(17) := 'EAD_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_LEADS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_VE';
wwv_flow_imp.g_varchar2_table(18) := 'RIFICATIONS" ADD FOREIGN KEY ("OPP_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_DEALS" ("ID") ON DELETE CASCADE ENA';
wwv_flow_imp.g_varchar2_table(19) := 'BLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_VERIFICATIONS" ADD FOREIGN KEY ("TERRITORY_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALE';
wwv_flow_imp.g_varchar2_table(20) := 'S_TERRITORIES" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814633929334268914)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_verifications'
,p_sequence=>500
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814634109475268915)
,p_script_id=>wwv_flow_imp.id(6814633929334268914)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_VERIFICATIONS'
);
wwv_flow_imp.component_end;
end;
/
