prompt --application/deployment/install/install_eba_sales_verifications
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_verifications
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6796911737373515511)
,p_install_id=>wwv_flow_imp.id(10495272006180774354)
,p_name=>'eba_sales_verifications'
,p_sequence=>500
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_VERIFICATIONS" ',
'   (	"ID" NUMBER, ',
'	"CUST_ID" NUMBER, ',
'	"LEAD_ID" NUMBER, ',
'	"OPP_ID" NUMBER, ',
'	"VERIFICATION_COMMENT" VARCHAR2(4000), ',
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"CREATED_BY" VARCHAR2(255), ',
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"UPDATED_BY" VARCHAR2(255), ',
'	"TERRITORY_ID" NUMBER, ',
'	"ENTITY_TYPE" VARCHAR2(20) NOT NULL ENABLE, ',
'	"CONTACT_ID" NUMBER, ',
'	"PRODUCT_ID" NUMBER, ',
'	"VERIFIED_BY" VARCHAR2(255), ',
'	 PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE, ',
'	 CONSTRAINT "EBA_SALES_VERIF_ENT_TYPE_CK" CHECK (entity_type in (''OPPORTUNITY'',''LEAD'',''TERRITORY'',''ACCOUNT'', ''CONTACT'', ''PRODUCT'')) ENABLE, ',
'	 CONSTRAINT "EBA_SALES_VERIF_ENT_FK_CK" CHECK (',
'  entity_type = ''OPPORTUNITY'' and opp_id is not null',
'    or entity_type = ''LEAD'' and lead_id is not null',
'    or entity_type = ''TERRITORY'' and territory_id is not null',
'    or entity_type = ''ACCOUNT'' and cust_id is not null',
'    or entity_type = ''CONTACT'' and contact_id is not null',
'    or entity_type = ''PRODUCT'' and product_id is not null',
') ENABLE',
'   ) ;',
'',
'ALTER TABLE "EBA_SALES_VERIFICATIONS" ADD CONSTRAINT "EBA_SALES_VERIF_CONTACT_FK" FOREIGN KEY ("CONTACT_ID")',
'	  REFERENCES "EBA_SALES_CUSTOMER_CONTACTS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_VERIFICATIONS" ADD CONSTRAINT "EBA_SALES_VERIF_PRODUCT_FK" FOREIGN KEY ("PRODUCT_ID")',
'	  REFERENCES "EBA_SALES_PRODUCTS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_VERIFICATIONS" ADD FOREIGN KEY ("CUST_ID")',
'	  REFERENCES "EBA_SALES_CUSTOMERS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_VERIFICATIONS" ADD FOREIGN KEY ("LEAD_ID")',
'	  REFERENCES "EBA_SALES_LEADS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_VERIFICATIONS" ADD FOREIGN KEY ("OPP_ID")',
'	  REFERENCES "EBA_SALES_DEALS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_VERIFICATIONS" ADD FOREIGN KEY ("TERRITORY_ID")',
'	  REFERENCES "EBA_SALES_TERRITORIES" ("ID") ON DELETE CASCADE ENABLE;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6796911917514515512)
,p_script_id=>wwv_flow_imp.id(6796911737373515511)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_VERIFICATIONS'
,p_last_updated_on=>to_date('20160706142050','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160706142050','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
