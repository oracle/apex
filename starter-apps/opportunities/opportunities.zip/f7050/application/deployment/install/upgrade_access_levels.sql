prompt --application/deployment/install/upgrade_access_levels
begin
--   Manifest
--     INSTALL: UPGRADE-Access Levels
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(7024820339242815680)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'Access Levels'
,p_sequence=>80
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from eba_sales_access_levels',
'where id = 0;'))
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'alter table eba_sales_access_levels drop constraint EBA_SALES_ACC_LVL_ACC_LVL_CK;',
'/',
'',
'alter table eba_sales_access_levels',
'add constraint eba_sales_access_levels_ck',
'    check (access_level in ( ''Administrator'', ''Contributor'', ''Reader'', ''Approval Pending'', ''No Access'' ));',
'/',
'',
'insert into eba_sales_access_levels (id, access_level) values (-99, ''No Access'');',
'insert into eba_sales_access_levels (id, access_level) values (0, ''Approval Pending'');'))
);
wwv_flow_imp.component_end;
end;
/
