prompt --application/deployment/install/upgrade_access_levels
begin
--   Manifest
--     INSTALL: UPGRADE-Access Levels
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'alter table eba_sales_access_levels drop constraint EBA_SALES_ACC_LVL_ACC_LVL_CK;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba';
wwv_flow_imp.g_varchar2_table(2) := '_sales_access_levels'||wwv_flow.LF||
'add constraint eba_sales_access_levels_ck'||wwv_flow.LF||
'    check (access_level in ( ''Adminis';
wwv_flow_imp.g_varchar2_table(3) := 'trator'', ''Contributor'', ''Reader'', ''Approval Pending'', ''No Access'' ));'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_sales_acces';
wwv_flow_imp.g_varchar2_table(4) := 's_levels (id, access_level) values (-99, ''No Access'');'||wwv_flow.LF||
'insert into eba_sales_access_levels (id, acce';
wwv_flow_imp.g_varchar2_table(5) := 'ss_level) values (0, ''Approval Pending'');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(7024820339242815680)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'Access Levels'
,p_sequence=>80
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from eba_sales_access_levels',
'where id = 0;'))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
