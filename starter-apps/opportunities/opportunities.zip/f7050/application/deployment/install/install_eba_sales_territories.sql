prompt --application/deployment/install/install_eba_sales_territories
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_territories
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814630897083251388)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_territories'
,p_sequence=>70
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_TERRITORIES" ',
'   (	"ID" NUMBER, ',
'	"ROW_VERSION_NUMBER" NUMBER, ',
'	"ROW_KEY" VARCHAR2(255), ',
'	"TERRITORY_NAME" VARCHAR2(255) NOT NULL ENABLE, ',
'	"TERRITORY_DESCRIPTION" VARCHAR2(4000), ',
'	"VP_ID" NUMBER, ',
'	"SVP_ID" NUMBER, ',
'	"TERRITORY_TYPE" VARCHAR2(255), ',
'	"TAGS" VARCHAR2(4000), ',
'	"CREATED_BY" VARCHAR2(255), ',
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"UPDATED_BY" VARCHAR2(255), ',
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"INTERNAL_FLEX_FLAG_01" VARCHAR2(30), ',
'	"INTERNAL_FLEX_FLAG_02" VARCHAR2(30), ',
'	"INTERNAL_FLEX_FLAG_03" VARCHAR2(30), ',
'	"INTERNAL_FLEX_FLAG_04" VARCHAR2(30), ',
'	"INTERNAL_FLEX_01" VARCHAR2(4000), ',
'	"INTERNAL_FLEX_02" VARCHAR2(4000), ',
'	"INTERNAL_FLEX_03" VARCHAR2(4000), ',
'	"INTERNAL_FLEX_04" VARCHAR2(4000), ',
'	"FLEX_FLAG_01" VARCHAR2(30), ',
'	"FLEX_FLAG_02" VARCHAR2(30), ',
'	"FLEX_FLAG_03" VARCHAR2(30), ',
'	"FLEX_FLAG_04" VARCHAR2(30), ',
'	"FLEX_FLAG_05" VARCHAR2(30), ',
'	"FLEX_FLAG_06" VARCHAR2(30), ',
'	"FLEX_FLAG_07" VARCHAR2(30), ',
'	"FLEX_FLAG_08" VARCHAR2(30), ',
'	"FLEX_01" VARCHAR2(4000), ',
'	"FLEX_02" VARCHAR2(4000), ',
'	"FLEX_03" VARCHAR2(4000), ',
'	"FLEX_04" VARCHAR2(4000), ',
'	"FLEX_05" VARCHAR2(4000), ',
'	"FLEX_06" VARCHAR2(4000), ',
'	"FLEX_07" VARCHAR2(4000), ',
'	"FLEX_08" VARCHAR2(4000), ',
'	"FLEX_D01" TIMESTAMP (6) WITH TIME ZONE, ',
'	"FLEX_D02" TIMESTAMP (6) WITH TIME ZONE, ',
'	"FLEX_D03" TIMESTAMP (6) WITH TIME ZONE, ',
'	"FLEX_D04" TIMESTAMP (6) WITH TIME ZONE, ',
'	"FLEX_N01" NUMBER, ',
'	"FLEX_N02" NUMBER, ',
'	"FLEX_N03" NUMBER, ',
'	"FLEX_N04" NUMBER, ',
'	"FLEX_N05" NUMBER, ',
'	"FLEX_N06" NUMBER, ',
'	"FLEX_N07" NUMBER, ',
'	"FLEX_N08" NUMBER, ',
'	 CONSTRAINT "EBA_SALES_TERR_TERR_CC" CHECK (territory_type in (''STATE'',''NAMED_ACCOUNT'',''KEY_ACCOUNT'',''COUNTRY'',''REGION'')) ENABLE, ',
'	 PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814630955314251388)
,p_script_id=>wwv_flow_imp.id(6814630897083251388)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_TERRITORIES'
);
wwv_flow_imp.component_end;
end;
/
