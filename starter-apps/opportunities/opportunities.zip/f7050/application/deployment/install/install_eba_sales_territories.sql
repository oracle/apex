prompt --application/deployment/install/install_eba_sales_territories
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_territories
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_TERRITORIES" '||wwv_flow.LF||
'   (	"ID" NUMBER, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER, '||wwv_flow.LF||
'	"ROW_KEY" V';
wwv_flow_imp.g_varchar2_table(2) := 'ARCHAR2(255), '||wwv_flow.LF||
'	"TERRITORY_NAME" VARCHAR2(255) NOT NULL ENABLE, '||wwv_flow.LF||
'	"TERRITORY_DESCRIPTION" VARCHAR2(4';
wwv_flow_imp.g_varchar2_table(3) := '000), '||wwv_flow.LF||
'	"VP_ID" NUMBER, '||wwv_flow.LF||
'	"SVP_ID" NUMBER, '||wwv_flow.LF||
'	"TERRITORY_TYPE" VARCHAR2(255), '||wwv_flow.LF||
'	"TAGS" VARCHAR2(4000)';
wwv_flow_imp.g_varchar2_table(4) := ', '||wwv_flow.LF||
'	"CREATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"UPDATED_BY" VARCHAR2(25';
wwv_flow_imp.g_varchar2_table(5) := '5), '||wwv_flow.LF||
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_01" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FL';
wwv_flow_imp.g_varchar2_table(6) := 'EX_FLAG_02" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_03" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_04" VARCHAR2';
wwv_flow_imp.g_varchar2_table(7) := '(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_01" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_02" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_03"';
wwv_flow_imp.g_varchar2_table(8) := ' VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_04" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_FLAG_01" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_02';
wwv_flow_imp.g_varchar2_table(9) := '" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_03" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_04" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_05" VARCH';
wwv_flow_imp.g_varchar2_table(10) := 'AR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_06" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_07" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_08" VARCHAR2(30)';
wwv_flow_imp.g_varchar2_table(11) := ', '||wwv_flow.LF||
'	"FLEX_01" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_02" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_03" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_04" VA';
wwv_flow_imp.g_varchar2_table(12) := 'RCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_05" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_06" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_07" VARCHAR2(4000), '||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(13) := '"FLEX_08" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_D01" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D02" TIMESTAMP (6) WITH';
wwv_flow_imp.g_varchar2_table(14) := ' TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D03" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D04" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(15) := '"FLEX_N01" NUMBER, '||wwv_flow.LF||
'	"FLEX_N02" NUMBER, '||wwv_flow.LF||
'	"FLEX_N03" NUMBER, '||wwv_flow.LF||
'	"FLEX_N04" NUMBER, '||wwv_flow.LF||
'	"FLEX_N05" NUMBE';
wwv_flow_imp.g_varchar2_table(16) := 'R, '||wwv_flow.LF||
'	"FLEX_N06" NUMBER, '||wwv_flow.LF||
'	"FLEX_N07" NUMBER, '||wwv_flow.LF||
'	"FLEX_N08" NUMBER, '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SALES_TERR_TERR';
wwv_flow_imp.g_varchar2_table(17) := '_CC" CHECK (territory_type in (''STATE'',''NAMED_ACCOUNT'',''KEY_ACCOUNT'',''COUNTRY'',''REGION'')) ENABLE, '||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(18) := ' PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814630897083251388)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_territories'
,p_sequence=>70
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814630955314251388)
,p_script_id=>wwv_flow_imp.id(6814630897083251388)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_TERRITORIES'
);
wwv_flow_imp.component_end;
end;
/
