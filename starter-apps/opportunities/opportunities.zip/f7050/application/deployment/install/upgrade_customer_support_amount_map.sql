prompt --application/deployment/install/upgrade_customer_support_amount_map
begin
--   Manifest
--     INSTALL: UPGRADE-Customer Support Amount Map
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8473764048765196174)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'Customer Support Amount Map'
,p_sequence=>190
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_SALES_CUST_SPT_AMT_MAP'''))
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_CUST_SPT_AMT_MAP" ',
'(',
'    "ID" NUMBER,',
'    "ROW_VERSION_NUMBER" NUMBER,',
'    "NAME" VARCHAR2(255),',
'    "CLOSE_DATE" TIMESTAMP (6) WITH TIME ZONE,',
'    "TERM_ID" NUMBER references EBA_SALES_TERMS on delete set null,',
'    "CUSTOMER_ID" NUMBER references EBA_SALES_CUSTOMERS on delete set null,',
'    "AMOUNT_ID" NUMBER references EBA_SALES_SUPPORT_AMTS on delete cascade,',
'    "QUOTE_PRICE" NUMBER,',
'    "DESCRIPTION" VARCHAR2(4000),',
'    "CREATED_BY" VARCHAR2(255),',
'    "CREATED" TIMESTAMP (6) WITH TIME ZONE,',
'    "UPDATED_BY" VARCHAR2(255),',
'    "UPDATED" TIMESTAMP (6) WITH TIME ZONE,',
'     PRIMARY KEY ("ID")  USING INDEX  ENABLE',
');',
'',
'CREATE OR REPLACE TRIGGER "BIU_EBA_SALES_CUST_SPT_AMT_MAP" ',
'   before insert or update on EBA_SALES_CUST_SPT_AMT_MAP',
'   for each row',
'   begin',
'      if inserting then',
'         if :NEW.ID is null then',
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')',
'           into :new.id',
'           from dual;',
'         end if;',
'         :NEW.CREATED := current_timestamp;',
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);',
'         :new.updated_by := nvl(v(''APP_USER''),USER);',
'         :new.updated := current_timestamp;',
'         :new.row_version_number := 1;',
'      end if;',
'      if updating then',
'         :NEW.UPDATED := current_timestamp;',
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);',
'         :new.row_version_number := nvl(:old.row_version_number,1) + 1;',
'      end if;',
'end;',
'/',
'',
'ALTER TRIGGER "BIU_EBA_SALES_CUST_SPT_AMT_MAP" ENABLE;'))
);
wwv_flow_imp.component_end;
end;
/
