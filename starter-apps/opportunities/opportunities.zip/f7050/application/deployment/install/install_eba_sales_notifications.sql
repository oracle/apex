prompt --application/deployment/install/install_eba_sales_notifications
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_notifications
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_NOTIFICATIONS" '||wwv_flow.LF||
'   (	"ID" NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUM';
wwv_flow_imp.g_varchar2_table(2) := 'BER, '||wwv_flow.LF||
'	"NOTIFICATION_NAME" VARCHAR2(255) NOT NULL ENABLE, '||wwv_flow.LF||
'	"NOTIFICATION_DESCRIPTION" VARCHAR2(4000';
wwv_flow_imp.g_varchar2_table(3) := '), '||wwv_flow.LF||
'	"NOTIFICATION_TYPE" VARCHAR2(30) NOT NULL ENABLE, '||wwv_flow.LF||
'	"DISPLAY_SEQUENCE" NUMBER, '||wwv_flow.LF||
'	"DISPLAY_FROM"';
wwv_flow_imp.g_varchar2_table(4) := ' TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"DISPLAY_UNTIL" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"CREATED_BY" VARCHA';
wwv_flow_imp.g_varchar2_table(5) := 'R2(255) NOT NULL ENABLE, '||wwv_flow.LF||
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"UPDATED_BY" VARCHAR2(255) NOT ';
wwv_flow_imp.g_varchar2_table(6) := 'NULL ENABLE, '||wwv_flow.LF||
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SALES_NOTE_TP_CC" CHECK (n';
wwv_flow_imp.g_varchar2_table(7) := 'otification_type in (''RED'',''YELLOW'')) ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SALES_NOTE_PK" PRIMARY KEY ("ID")'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(8) := ' USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814608458956194297)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_notifications'
,p_sequence=>380
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814608538914194297)
,p_script_id=>wwv_flow_imp.id(6814608458956194297)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_NOTIFICATIONS'
);
wwv_flow_imp.component_end;
end;
/
