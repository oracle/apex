prompt --application/deployment/install/install_eba_sales_notifications
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_notifications
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814608458956194297)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_notifications'
,p_sequence=>380
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_NOTIFICATIONS" ',
'   (	"ID" NUMBER NOT NULL ENABLE, ',
'	"ROW_VERSION_NUMBER" NUMBER, ',
'	"NOTIFICATION_NAME" VARCHAR2(255) NOT NULL ENABLE, ',
'	"NOTIFICATION_DESCRIPTION" VARCHAR2(4000), ',
'	"NOTIFICATION_TYPE" VARCHAR2(30) NOT NULL ENABLE, ',
'	"DISPLAY_SEQUENCE" NUMBER, ',
'	"DISPLAY_FROM" TIMESTAMP (6) WITH TIME ZONE, ',
'	"DISPLAY_UNTIL" TIMESTAMP (6) WITH TIME ZONE, ',
'	"CREATED_BY" VARCHAR2(255) NOT NULL ENABLE, ',
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"UPDATED_BY" VARCHAR2(255) NOT NULL ENABLE, ',
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	 CONSTRAINT "EBA_SALES_NOTE_TP_CC" CHECK (notification_type in (''RED'',''YELLOW'')) ENABLE, ',
'	 CONSTRAINT "EBA_SALES_NOTE_PK" PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814608538914194297)
,p_script_id=>wwv_flow_imp.id(6814608458956194297)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_NOTIFICATIONS'
);
wwv_flow_imp.component_end;
end;
/
