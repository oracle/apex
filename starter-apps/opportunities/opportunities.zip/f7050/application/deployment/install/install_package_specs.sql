prompt --application/deployment/install/install_package_specs
begin
--   Manifest
--     INSTALL: INSTALL-Package Specs
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-13'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(6957677009221431478)
,p_install_id=>wwv_flow_api.id(10495272006180774354)
,p_name=>'Package Specs'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_option=>'PACKAGE_SPEC'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE OR REPLACE PACKAGE "EBA_SALES_DATA" as ',
'    procedure load_codes; ',
'    procedure load_sample; ',
'    procedure remove_sample; ',
'end;',
'/',
'',
'CREATE OR REPLACE PACKAGE "EBA_SALES_ACL_API" is',
'    -------------------------------------------------------------------------',
'    -- Generates a unique Identifier',
'    -------------------------------------------------------------------------',
'    function gen_id return number;',
'    -------------------------------------------------------------------------',
'    -- Error handling function',
'    -------------------------------------------------------------------------',
'    function apex_error_handling (',
'        p_error in apex_error.t_error )',
'        return apex_error.t_error_result;',
'    -------------------------------------------------------------------------',
'    -- Get''s a preference value, given the name',
'    -------------------------------------------------------------------------',
'    function get_preference_value (',
'        p_preference_name   varchar2)',
'        return varchar2;',
'    -------------------------------------------------------------------------',
'    -- Set''s a preference value, given the name',
'    -------------------------------------------------------------------------',
'    procedure set_preference_value (',
'        p_preference_name   varchar2,',
'        p_preference_value  varchar2);',
'    -------------------------------------------------------------------------',
'    -- Gets the current user''s authorization level. Can depend on the following:',
'    --  * If access control is currently disabled, returns highest level of 3.',
'    --  * If access control is enabled, but user is not in list, returns 0',
'    --  * If access control is enabled and user is in list, returns their',
'    --    access level.',
'    -------------------------------------------------------------------------',
'    function get_authorization_level (',
'        p_username             varchar2)',
'        return number;',
'end eba_sales_acl_api;',
'/',
'',
'CREATE OR REPLACE PACKAGE "EBA_SALES_FW" as',
'    function conv_txt_html (',
'        p_txt_message in varchar2 )',
'        return varchar2;',
'    function conv_urls_links (',
'        p_string in varchar2 )',
'        return varchar2;',
'    function tags_cleaner (',
'        p_tags  in varchar2,',
'        p_case  in varchar2 default ''U'' )',
'        return varchar2;',
'    procedure tag_sync (',
'        p_new_tags          in varchar2,',
'        p_old_tags          in varchar2,',
'        p_content_type      in varchar2,',
'        p_content_id        in number );',
'    function selective_escape (',
'        p_text  in varchar2,',
'        p_tags  in varchar2 default ''<h2>,</h2>,<p>,</p>,<b>,</b>,<li>,</li>,<ul>,</ul>,<br />,<i>,</i>,<h3>,</h3>'' )',
'        return varchar2;',
'    function get_preference_value (',
'        p_preference_name in varchar2 )',
'        return varchar2;',
'    procedure set_preference_value (',
'        p_preference_name  in varchar2, ',
'        p_preference_value in varchar2 );',
'    function compress_int (',
'        n in integer )',
'        return varchar2;',
'end eba_sales_fw;',
'/',
'',
''))
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6957677264521431489)
,p_script_id=>wwv_flow_api.id(6957677009221431478)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_SALES_ACL_API'
,p_last_updated_on=>to_date('20160803062934','YYYYMMDDHH24MISS')
,p_created_by=>'DAVID.GALE'
,p_created_on=>to_date('20160803062934','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6957677466300431489)
,p_script_id=>wwv_flow_api.id(6957677009221431478)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_SALES_DATA'
,p_last_updated_on=>to_date('20160803062934','YYYYMMDDHH24MISS')
,p_created_by=>'DAVID.GALE'
,p_created_on=>to_date('20160803062934','YYYYMMDDHH24MISS')
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(6957677130353431487)
,p_script_id=>wwv_flow_api.id(6957677009221431478)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_SALES_FW'
,p_last_updated_on=>to_date('20160803062934','YYYYMMDDHH24MISS')
,p_created_by=>'DAVID.GALE'
,p_created_on=>to_date('20160803062934','YYYYMMDDHH24MISS')
);
wwv_flow_api.component_end;
end;
/
