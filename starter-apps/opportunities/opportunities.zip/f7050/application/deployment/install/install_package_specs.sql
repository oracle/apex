prompt --application/deployment/install/install_package_specs
begin
--   Manifest
--     INSTALL: INSTALL-Package Specs
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE OR REPLACE PACKAGE "EBA_SALES_DATA" as '||wwv_flow.LF||
'    procedure load_codes; '||wwv_flow.LF||
'    procedure load_sample;';
wwv_flow_imp.g_varchar2_table(2) := ' '||wwv_flow.LF||
'    procedure remove_sample; '||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE PACKAGE "EBA_SALES_ACL_API" is'||wwv_flow.LF||
'    -------';
wwv_flow_imp.g_varchar2_table(3) := '------------------------------------------------------------------'||wwv_flow.LF||
'    -- Generates a unique Identif';
wwv_flow_imp.g_varchar2_table(4) := 'ier'||wwv_flow.LF||
'    -------------------------------------------------------------------------'||wwv_flow.LF||
'    function gen_i';
wwv_flow_imp.g_varchar2_table(5) := 'd return number;'||wwv_flow.LF||
'    -------------------------------------------------------------------------'||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(6) := '- Error handling function'||wwv_flow.LF||
'    ----------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(7) := '---'||wwv_flow.LF||
'    function apex_error_handling ('||wwv_flow.LF||
'        p_error in apex_error.t_error )'||wwv_flow.LF||
'        return apex_e';
wwv_flow_imp.g_varchar2_table(8) := 'rror.t_error_result;'||wwv_flow.LF||
'    -------------------------------------------------------------------------'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(9) := '   -- Get''s a preference value, given the name'||wwv_flow.LF||
'    -------------------------------------------------';
wwv_flow_imp.g_varchar2_table(10) := '------------------------'||wwv_flow.LF||
'    function get_preference_value ('||wwv_flow.LF||
'        p_preference_name   varchar2)'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(11) := '       return varchar2;'||wwv_flow.LF||
'    ------------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(12) := '-'||wwv_flow.LF||
'    -- Set''s a preference value, given the name'||wwv_flow.LF||
'    ----------------------------------------------';
wwv_flow_imp.g_varchar2_table(13) := '---------------------------'||wwv_flow.LF||
'    procedure set_preference_value ('||wwv_flow.LF||
'        p_preference_name   varchar';
wwv_flow_imp.g_varchar2_table(14) := '2,'||wwv_flow.LF||
'        p_preference_value  varchar2);'||wwv_flow.LF||
'    ------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(15) := '-------------------'||wwv_flow.LF||
'    -- Gets the current user''s authorization level. Can depend on the following:';
wwv_flow_imp.g_varchar2_table(16) := ''||wwv_flow.LF||
'    --  * If access control is currently disabled, returns highest level of 3.'||wwv_flow.LF||
'    --  * If access ';
wwv_flow_imp.g_varchar2_table(17) := 'control is enabled, but user is not in list, returns 0'||wwv_flow.LF||
'    --  * If access control is enabled and us';
wwv_flow_imp.g_varchar2_table(18) := 'er is in list, returns their'||wwv_flow.LF||
'    --    access level.'||wwv_flow.LF||
'    -------------------------------------------';
wwv_flow_imp.g_varchar2_table(19) := '------------------------------'||wwv_flow.LF||
'    function get_authorization_level ('||wwv_flow.LF||
'        p_username            ';
wwv_flow_imp.g_varchar2_table(20) := ' varchar2)'||wwv_flow.LF||
'        return number;'||wwv_flow.LF||
'end eba_sales_acl_api;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE PACKAGE "EBA_SALES_FW"';
wwv_flow_imp.g_varchar2_table(21) := ' as'||wwv_flow.LF||
'    function conv_txt_html ('||wwv_flow.LF||
'        p_txt_message in varchar2 )'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
'    fu';
wwv_flow_imp.g_varchar2_table(22) := 'nction conv_urls_links ('||wwv_flow.LF||
'        p_string in varchar2 )'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
'    function tags_c';
wwv_flow_imp.g_varchar2_table(23) := 'leaner ('||wwv_flow.LF||
'        p_tags  in varchar2,'||wwv_flow.LF||
'        p_case  in varchar2 default ''U'' )'||wwv_flow.LF||
'        return varch';
wwv_flow_imp.g_varchar2_table(24) := 'ar2;'||wwv_flow.LF||
'    procedure tag_sync ('||wwv_flow.LF||
'        p_new_tags          in varchar2,'||wwv_flow.LF||
'        p_old_tags          i';
wwv_flow_imp.g_varchar2_table(25) := 'n varchar2,'||wwv_flow.LF||
'        p_content_type      in varchar2,'||wwv_flow.LF||
'        p_content_id        in number );'||wwv_flow.LF||
'    fu';
wwv_flow_imp.g_varchar2_table(26) := 'nction selective_escape ('||wwv_flow.LF||
'        p_text  in varchar2,'||wwv_flow.LF||
'        p_tags  in varchar2 default ''<h2>,</h';
wwv_flow_imp.g_varchar2_table(27) := '2>,<p>,</p>,<b>,</b>,<li>,</li>,<ul>,</ul>,<br />,<i>,</i>,<h3>,</h3>'' )'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(28) := '  function get_preference_value ('||wwv_flow.LF||
'        p_preference_name in varchar2 )'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(29) := '   procedure set_preference_value ('||wwv_flow.LF||
'        p_preference_name  in varchar2, '||wwv_flow.LF||
'        p_preference_va';
wwv_flow_imp.g_varchar2_table(30) := 'lue in varchar2 );'||wwv_flow.LF||
'    function compress_int ('||wwv_flow.LF||
'        n in integer )'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
'end e';
wwv_flow_imp.g_varchar2_table(31) := 'ba_sales_fw;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6975399201182184881)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'Package Specs'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_option=>'PACKAGE_SPEC'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6975399322314184890)
,p_script_id=>wwv_flow_imp.id(6975399201182184881)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_SALES_FW'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6975399456482184892)
,p_script_id=>wwv_flow_imp.id(6975399201182184881)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_SALES_ACL_API'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6975399658261184892)
,p_script_id=>wwv_flow_imp.id(6975399201182184881)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_SALES_DATA'
);
wwv_flow_imp.component_end;
end;
/
