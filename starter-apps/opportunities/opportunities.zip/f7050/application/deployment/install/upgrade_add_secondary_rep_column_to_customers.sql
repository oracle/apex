prompt --application/deployment/install/upgrade_add_secondary_rep_column_to_customers
begin
--   Manifest
--     INSTALL: UPGRADE-Add Secondary Rep Column to Customers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8466669989186276203)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'Add Secondary Rep Column to Customers'
,p_sequence=>140
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select column_name',
'from user_tab_columns',
'where table_name = ''EBA_SALES_CUSTOMERS''',
'    and column_name = ''SECONDARY_REP'''))
,p_script_clob=>'alter table eba_sales_customers add secondary_rep varchar2(255);'
);
wwv_flow_imp.component_end;
end;
/
