prompt --application/deployment/install/install_eba_sales_customer_contacts
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_customer_contacts
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_CUSTOMER_CONTACTS" '||wwv_flow.LF||
'   ("ID" NUMBER, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER, '||wwv_flow.LF||
'	"ROW_K';
wwv_flow_imp.g_varchar2_table(2) := 'EY" VARCHAR2(255), '||wwv_flow.LF||
'	"TAGS" VARCHAR2(4000), '||wwv_flow.LF||
'	"CUSTOMER_ID" NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'	"CONTACT_NAME"';
wwv_flow_imp.g_varchar2_table(3) := ' VARCHAR2(255),'||wwv_flow.LF||
'    "CONTACT_TITLE" varchar2(100),'||wwv_flow.LF||
'	"CONTACT_EMAIL" VARCHAR2(255), '||wwv_flow.LF||
'	"CONTACT_PHONE"';
wwv_flow_imp.g_varchar2_table(4) := ' VARCHAR2(255), '||wwv_flow.LF||
'	"CONTACT_CELL" VARCHAR2(255), '||wwv_flow.LF||
'	"CONTACT_ADDRESS" VARCHAR2(4000), '||wwv_flow.LF||
'	"CONTACT_DESCR';
wwv_flow_imp.g_varchar2_table(5) := 'IPTION" VARCHAR2(4000), '||wwv_flow.LF||
'	"CONTACT_LINKEDIN" VARCHAR2(1000), '||wwv_flow.LF||
'	"CONTACT_FACEBOOK" VARCHAR2(1000), '||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(6) := '"CONTACT_TWITTER" VARCHAR2(1000), '||wwv_flow.LF||
'	"CREATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"CREATED" TIMESTAMP (6) WITH TIME ';
wwv_flow_imp.g_varchar2_table(7) := 'ZONE, '||wwv_flow.LF||
'	"UPDATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_';
wwv_flow_imp.g_varchar2_table(8) := '01" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_02" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_03" VARCHAR2(30), '||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(9) := '"INTERNAL_FLEX_FLAG_04" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_01" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_02" VARC';
wwv_flow_imp.g_varchar2_table(10) := 'HAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_03" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_04" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_FLAG_0';
wwv_flow_imp.g_varchar2_table(11) := '1" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_02" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_03" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_04" VARC';
wwv_flow_imp.g_varchar2_table(12) := 'HAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_05" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_06" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_07" VARCHAR2(30';
wwv_flow_imp.g_varchar2_table(13) := '), '||wwv_flow.LF||
'	"FLEX_FLAG_08" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_01" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_02" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_03';
wwv_flow_imp.g_varchar2_table(14) := '" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_04" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_05" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_06" VARCHAR2(4000)';
wwv_flow_imp.g_varchar2_table(15) := ', '||wwv_flow.LF||
'	"FLEX_07" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_08" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_D01" TIMESTAMP (6) WITH TIME ZONE,';
wwv_flow_imp.g_varchar2_table(16) := ' '||wwv_flow.LF||
'	"FLEX_D02" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D03" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D04" ';
wwv_flow_imp.g_varchar2_table(17) := 'TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_N01" NUMBER, '||wwv_flow.LF||
'	"FLEX_N02" NUMBER, '||wwv_flow.LF||
'	"FLEX_N03" NUMBER, '||wwv_flow.LF||
'	"FLEX';
wwv_flow_imp.g_varchar2_table(18) := '_N04" NUMBER, '||wwv_flow.LF||
'	"FLEX_N05" NUMBER, '||wwv_flow.LF||
'	"FLEX_N06" NUMBER, '||wwv_flow.LF||
'	"FLEX_N07" NUMBER, '||wwv_flow.LF||
'	"FLEX_N08" NUMBER, '||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(19) := ' PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814578441575982090)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_customer_contacts'
,p_sequence=>170
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814578621731982091)
,p_script_id=>wwv_flow_imp.id(6814578441575982090)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_CUSTOMER_CONTACTS'
);
wwv_flow_imp.component_end;
end;
/
