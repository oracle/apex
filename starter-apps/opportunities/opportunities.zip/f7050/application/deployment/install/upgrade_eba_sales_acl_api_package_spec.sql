prompt --application/deployment/install/upgrade_eba_sales_acl_api_package_spec
begin
--   Manifest
--     INSTALL: UPGRADE-eba_sales_acl_api package spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_sales_acl_api is'||wwv_flow.LF||
'    -------------------------------------------------';
wwv_flow_imp.g_varchar2_table(2) := '------------------------'||wwv_flow.LF||
'    -- Generates a unique Identifier'||wwv_flow.LF||
'    ----------------------------------';
wwv_flow_imp.g_varchar2_table(3) := '---------------------------------------'||wwv_flow.LF||
'    function gen_id return number;'||wwv_flow.LF||
'    ---------------------';
wwv_flow_imp.g_varchar2_table(4) := '----------------------------------------------------'||wwv_flow.LF||
'    -- Error handling function'||wwv_flow.LF||
'    ------------';
wwv_flow_imp.g_varchar2_table(5) := '-------------------------------------------------------------'||wwv_flow.LF||
'    function apex_error_handling ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(6) := '     p_error in apex_error.t_error )'||wwv_flow.LF||
'        return apex_error.t_error_result;'||wwv_flow.LF||
'    -----------------';
wwv_flow_imp.g_varchar2_table(7) := '--------------------------------------------------------'||wwv_flow.LF||
'    -- Get''s a preference value, given the ';
wwv_flow_imp.g_varchar2_table(8) := 'name'||wwv_flow.LF||
'    -------------------------------------------------------------------------'||wwv_flow.LF||
'    function get_';
wwv_flow_imp.g_varchar2_table(9) := 'preference_value ('||wwv_flow.LF||
'        p_preference_name   varchar2)'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
'    --------------';
wwv_flow_imp.g_varchar2_table(10) := '-----------------------------------------------------------'||wwv_flow.LF||
'    -- Set''s a preference value, given t';
wwv_flow_imp.g_varchar2_table(11) := 'he name'||wwv_flow.LF||
'    -------------------------------------------------------------------------'||wwv_flow.LF||
'    procedure ';
wwv_flow_imp.g_varchar2_table(12) := 'set_preference_value ('||wwv_flow.LF||
'        p_preference_name   varchar2,'||wwv_flow.LF||
'        p_preference_value  varchar2);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(13) := '    -------------------------------------------------------------------------'||wwv_flow.LF||
'    -- Gets the curren';
wwv_flow_imp.g_varchar2_table(14) := 't user''s authorization level. Can depend on the following:'||wwv_flow.LF||
'    --  * If access control is currently ';
wwv_flow_imp.g_varchar2_table(15) := 'disabled, returns highest level of 3.'||wwv_flow.LF||
'    --  * If access control is enabled, but user is not in lis';
wwv_flow_imp.g_varchar2_table(16) := 't, returns 0'||wwv_flow.LF||
'    --  * If access control is enabled and user is in list, returns their'||wwv_flow.LF||
'    --    acc';
wwv_flow_imp.g_varchar2_table(17) := 'ess level.'||wwv_flow.LF||
'    -------------------------------------------------------------------------'||wwv_flow.LF||
'    functio';
wwv_flow_imp.g_varchar2_table(18) := 'n get_authorization_level ('||wwv_flow.LF||
'        p_username             varchar2)'||wwv_flow.LF||
'        return number;'||wwv_flow.LF||
'end eba_';
wwv_flow_imp.g_varchar2_table(19) := 'sales_acl_api;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(7548918094809153754)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_acl_api package spec'
,p_sequence=>10
,p_script_type=>'UPGRADE'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
