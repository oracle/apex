prompt --application/deployment/install/upgrade_eba_sales_acl_api_package_spec
begin
--   Manifest
--     INSTALL: UPGRADE-eba_sales_acl_api package spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(7548918094809153754)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_acl_api package spec'
,p_sequence=>10
,p_script_type=>'UPGRADE'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package eba_sales_acl_api is',
'    -------------------------------------------------------------------------',
'    -- Generates a unique Identifier',
'    -------------------------------------------------------------------------',
'    function gen_id return number;',
'    -------------------------------------------------------------------------',
'    -- Error handling function',
'    -------------------------------------------------------------------------',
'    function apex_error_handling (',
'        p_error in apex_error.t_error )',
'        return apex_error.t_error_result;',
'    -------------------------------------------------------------------------',
'    -- Get''s a preference value, given the name',
'    -------------------------------------------------------------------------',
'    function get_preference_value (',
'        p_preference_name   varchar2)',
'        return varchar2;',
'    -------------------------------------------------------------------------',
'    -- Set''s a preference value, given the name',
'    -------------------------------------------------------------------------',
'    procedure set_preference_value (',
'        p_preference_name   varchar2,',
'        p_preference_value  varchar2);',
'    -------------------------------------------------------------------------',
'    -- Gets the current user''s authorization level. Can depend on the following:',
'    --  * If access control is currently disabled, returns highest level of 3.',
'    --  * If access control is enabled, but user is not in list, returns 0',
'    --  * If access control is enabled and user is in list, returns their',
'    --    access level.',
'    -------------------------------------------------------------------------',
'    function get_authorization_level (',
'        p_username             varchar2)',
'        return number;',
'end eba_sales_acl_api;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
