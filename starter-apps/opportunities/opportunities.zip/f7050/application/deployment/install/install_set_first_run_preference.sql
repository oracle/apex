prompt --application/deployment/install/install_set_first_run_preference
begin
--   Manifest
--     INSTALL: INSTALL-Set First Run Preference
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
'    eba_sales_fw.set_preference_value( p_preference_name => ''FIRST_RUN'', p_preference_value =>';
wwv_flow_imp.g_varchar2_table(2) := ' ''YES'' );'||wwv_flow.LF||
'end;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6817694231768236246)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'Set First Run Preference'
,p_sequence=>660
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
