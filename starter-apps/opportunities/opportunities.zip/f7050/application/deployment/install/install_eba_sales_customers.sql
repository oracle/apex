prompt --application/deployment/install/install_eba_sales_customers
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_customers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_CUSTOMERS" '||wwv_flow.LF||
'   ("ID" NUMBER, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER, '||wwv_flow.LF||
'	"ROW_KEY" VARC';
wwv_flow_imp.g_varchar2_table(2) := 'HAR2(255), '||wwv_flow.LF||
'	"CUSTOMER_NAME" VARCHAR2(255), '||wwv_flow.LF||
'	"TAGS" VARCHAR2(4000), '||wwv_flow.LF||
'	"DEFAULT_REP_ID" NUMBER,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(3) := '"SECONDARY_REP" VARCHAR2(255), '||wwv_flow.LF||
'	"CUSTOMER_SIC" VARCHAR2(30), '||wwv_flow.LF||
'	"CUSTOMER_DUNS" VARCHAR2(30), '||wwv_flow.LF||
'	"CUS';
wwv_flow_imp.g_varchar2_table(4) := 'TOMER_WEB_SITE" VARCHAR2(512), '||wwv_flow.LF||
'	"CUSTOMER_STOCK_SYMB" VARCHAR2(30), '||wwv_flow.LF||
'	"CUSTOMER_NUMBER_OF_EMP" NUMB';
wwv_flow_imp.g_varchar2_table(5) := 'ER, '||wwv_flow.LF||
'	"CUSTOMER_IS_PUBLIC_COMP_YN" VARCHAR2(1), '||wwv_flow.LF||
'	"CUSTOMER_FACEBOOK" VARCHAR2(1000), '||wwv_flow.LF||
'	"CUSTOMER_LI';
wwv_flow_imp.g_varchar2_table(6) := 'NKEDIN" VARCHAR2(1000), '||wwv_flow.LF||
'	"CUSTOMER_TWITTER" VARCHAR2(1000), '||wwv_flow.LF||
'	"CUSTOMER_DESCRIPTION" VARCHAR2(4000)';
wwv_flow_imp.g_varchar2_table(7) := ', '||wwv_flow.LF||
'	"CUSTOMER_TERRITORY_ID" NUMBER, '||wwv_flow.LF||
'	"CUSTOMER_INDUSTRY_ID" NUMBER, '||wwv_flow.LF||
'	"CUSTOMER_IS_KEY_ACCOUNT_YN" ';
wwv_flow_imp.g_varchar2_table(8) := 'VARCHAR2(1) NOT NULL ENABLE, '||wwv_flow.LF||
'	"CREATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE,';
wwv_flow_imp.g_varchar2_table(9) := ' '||wwv_flow.LF||
'	"UPDATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_01" V';
wwv_flow_imp.g_varchar2_table(10) := 'ARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_02" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_03" VARCHAR2(30), '||wwv_flow.LF||
'	"INTE';
wwv_flow_imp.g_varchar2_table(11) := 'RNAL_FLEX_FLAG_04" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_01" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_02" VARCHAR2(';
wwv_flow_imp.g_varchar2_table(12) := '4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_03" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_04" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_FLAG_01" VA';
wwv_flow_imp.g_varchar2_table(13) := 'RCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_02" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_03" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_04" VARCHAR2(';
wwv_flow_imp.g_varchar2_table(14) := '30), '||wwv_flow.LF||
'	"FLEX_FLAG_05" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_06" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_07" VARCHAR2(30), '||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(15) := '"FLEX_FLAG_08" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_01" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_02" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_03" VAR';
wwv_flow_imp.g_varchar2_table(16) := 'CHAR2(4000), '||wwv_flow.LF||
'	"FLEX_04" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_05" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_06" VARCHAR2(4000), '||wwv_flow.LF||
'	"';
wwv_flow_imp.g_varchar2_table(17) := 'FLEX_07" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_08" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_D01" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"F';
wwv_flow_imp.g_varchar2_table(18) := 'LEX_D02" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D03" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D04" TIMES';
wwv_flow_imp.g_varchar2_table(19) := 'TAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_N01" NUMBER, '||wwv_flow.LF||
'	"FLEX_N02" NUMBER, '||wwv_flow.LF||
'	"FLEX_N03" NUMBER, '||wwv_flow.LF||
'	"FLEX_N04"';
wwv_flow_imp.g_varchar2_table(20) := ' NUMBER, '||wwv_flow.LF||
'	"FLEX_N05" NUMBER, '||wwv_flow.LF||
'	"FLEX_N06" NUMBER, '||wwv_flow.LF||
'	"FLEX_N07" NUMBER, '||wwv_flow.LF||
'	"FLEX_N08" NUMBER, '||wwv_flow.LF||
'	 CONS';
wwv_flow_imp.g_varchar2_table(21) := 'TRAINT "EBA_SALES_CUST_CK_KEY_ACCT" CHECK (customer_is_key_account_yn in (''Y'',''N'')) ENABLE, '||wwv_flow.LF||
'	 PRIMA';
wwv_flow_imp.g_varchar2_table(22) := 'RY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_CUSTOMERS" ADD CONSTRAINT "EBA_SA';
wwv_flow_imp.g_varchar2_table(23) := 'LES_CUST_REPS_FK" FOREIGN KEY ("DEFAULT_REP_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_SALESREPS" ("ID") ON DELET';
wwv_flow_imp.g_varchar2_table(24) := 'E SET NULL ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_CUSTOMERS" ADD CONSTRAINT "EBA_SALES_CUST_TERR_FK" FOREIG';
wwv_flow_imp.g_varchar2_table(25) := 'N KEY ("CUSTOMER_TERRITORY_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_TERRITORIES" ("ID") ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "E';
wwv_flow_imp.g_varchar2_table(26) := 'BA_SALES_CUSTOMERS" ADD FOREIGN KEY ("CUSTOMER_INDUSTRY_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_INDUSTRIES" ("';
wwv_flow_imp.g_varchar2_table(27) := 'ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814570880932969116)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_customers'
,p_sequence=>80
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814570964331969117)
,p_script_id=>wwv_flow_imp.id(6814570880932969116)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_CUSTOMERS'
);
wwv_flow_imp.component_end;
end;
/
