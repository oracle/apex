prompt --application/deployment/install/install_eba_sales_access_levels
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_access_levels
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6796731654836043524)
,p_install_id=>wwv_flow_imp.id(10495272006180774354)
,p_name=>'eba_sales_access_levels'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_ACCESS_LEVELS" ',
'   (	"ID" NUMBER NOT NULL ENABLE, ',
'	"ACCESS_LEVEL" VARCHAR2(30) NOT NULL ENABLE, ',
'	"ROW_VERSION" NUMBER, ',
'	 CONSTRAINT "EBA_SALES_ACCESS_LEVELS_PK" PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE, ',
'	 CONSTRAINT "EBA_SALES_ACCESS_LEVELS_CK" CHECK (access_level in ( ''Administrator'', ''Contributor'', ''Reader'', ''Approval Pending'', ''No Access'' )) ENABLE',
'   ) ;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6796731771632043525)
,p_script_id=>wwv_flow_imp.id(6796731654836043524)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_ACCESS_LEVELS'
);
wwv_flow_imp.component_end;
end;
/
