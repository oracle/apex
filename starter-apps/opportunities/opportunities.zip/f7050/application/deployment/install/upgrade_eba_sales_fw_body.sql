prompt --application/deployment/install/upgrade_eba_sales_fw_body
begin
--   Manifest
--     INSTALL: UPGRADE-eba_sales_fw body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace PACKAGE BODY "EBA_SALES_FW" as '||wwv_flow.LF||
'    function conv_txt_html ( '||wwv_flow.LF||
'        p_txt_messag';
wwv_flow_imp.g_varchar2_table(2) := 'e in varchar2 ) '||wwv_flow.LF||
'        return varchar2 '||wwv_flow.LF||
'    is '||wwv_flow.LF||
'        l_html_message   varchar2(32767) default p';
wwv_flow_imp.g_varchar2_table(3) := '_txt_message; '||wwv_flow.LF||
'        l_temp_url varchar2(32767) := null; '||wwv_flow.LF||
'        l_length number; '||wwv_flow.LF||
'    begin '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(4) := '     l_html_message := replace(l_html_message, chr(10), ''<br />''); '||wwv_flow.LF||
'        l_html_message := replac';
wwv_flow_imp.g_varchar2_table(5) := 'e(l_html_message, chr(13), null); '||wwv_flow.LF||
'        return l_html_message; '||wwv_flow.LF||
'    end conv_txt_html; '||wwv_flow.LF||
'    funct';
wwv_flow_imp.g_varchar2_table(6) := 'ion conv_urls_links ( '||wwv_flow.LF||
'        p_string in varchar2 ) '||wwv_flow.LF||
'        return varchar2 '||wwv_flow.LF||
'    is '||wwv_flow.LF||
'        l_st';
wwv_flow_imp.g_varchar2_table(7) := 'ring   varchar2(32767) default p_string; '||wwv_flow.LF||
'        l_endofUrl varchar2(4000) default chr(10) || chr(1';
wwv_flow_imp.g_varchar2_table(8) := '3) || chr(9) || '' )<>''; '||wwv_flow.LF||
'        l_url         varchar2(4000); '||wwv_flow.LF||
'        l_current_pos number := 1; '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(9) := '        n             number := 1; '||wwv_flow.LF||
'        m             number := 1; '||wwv_flow.LF||
'        p             number';
wwv_flow_imp.g_varchar2_table(10) := ' := 1; '||wwv_flow.LF||
'    begin '||wwv_flow.LF||
'        l_string := p_string || '' ''; '||wwv_flow.LF||
'        for i in 1 .. 1000 loop '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(11) := '  n := instr( lower(l_string), ''http://'', l_current_pos ); '||wwv_flow.LF||
'            m := instr( lower(l_string),';
wwv_flow_imp.g_varchar2_table(12) := ' ''https://'', l_current_pos ); '||wwv_flow.LF||
'            p := instr( lower(l_string), ''ftp://'', l_current_pos   );';
wwv_flow_imp.g_varchar2_table(13) := ' '||wwv_flow.LF||
'            -- set n to position of first link '||wwv_flow.LF||
'            if m > 0 and (n = 0 or m < n) and (p =';
wwv_flow_imp.g_varchar2_table(14) := ' 0 or m < p) then '||wwv_flow.LF||
'               n := m; '||wwv_flow.LF||
'            elsif p > 0 and (n = 0 or p < n) then '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(15) := '         n := p; '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'            exit when n = 0 or length(l_string) > 32000; '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(16) := '         for j in 0 .. length( l_string ) - n loop '||wwv_flow.LF||
'                if ( instr( l_endofUrl, substr( ';
wwv_flow_imp.g_varchar2_table(17) := 'l_string, n+j, 1 ) ) > 0 ) then '||wwv_flow.LF||
'                   l_url := rtrim( substr( l_string, n, j ), ''.''||c';
wwv_flow_imp.g_varchar2_table(18) := 'hr(32)||chr(10) ); '||wwv_flow.LF||
'                   l_url := ''<a href="'' || l_url || ''">'' || l_url || ''</a>''; '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(19) := '                 l_string := substr( l_string, 1, n-1 ) || l_url || substr( l_string, n+j ); '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(20) := '             l_current_pos := n + length(l_url); '||wwv_flow.LF||
'                   exit; '||wwv_flow.LF||
'                end if; ';
wwv_flow_imp.g_varchar2_table(21) := ''||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        end loop; '||wwv_flow.LF||
'        return l_string; '||wwv_flow.LF||
'    end conv_urls_links; '||wwv_flow.LF||
'    f';
wwv_flow_imp.g_varchar2_table(22) := 'unction tags_cleaner ( '||wwv_flow.LF||
'        p_tags  in varchar2, '||wwv_flow.LF||
'        p_case  in varchar2 default ''U'' ) '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(23) := '     return varchar2 '||wwv_flow.LF||
'    is '||wwv_flow.LF||
'        type tags is table of varchar2(255) index by varchar2(255); '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(24) := '       l_tags_a        tags; '||wwv_flow.LF||
'        l_tag           varchar2(255); '||wwv_flow.LF||
'        l_tags          apex_a';
wwv_flow_imp.g_varchar2_table(25) := 'pplication_global.vc_arr2; '||wwv_flow.LF||
'        l_tags_string   varchar2(32767); '||wwv_flow.LF||
'        i               intege';
wwv_flow_imp.g_varchar2_table(26) := 'r; '||wwv_flow.LF||
'    begin '||wwv_flow.LF||
'        l_tags := apex_util.string_to_table(p_tags,'',''); '||wwv_flow.LF||
'        for i in 1..l_tags.';
wwv_flow_imp.g_varchar2_table(27) := 'count loop '||wwv_flow.LF||
'            --remove all whitespace, including tabs, spaces, line feeds and carraige ret';
wwv_flow_imp.g_varchar2_table(28) := 'urns with a single space '||wwv_flow.LF||
'            l_tag := substr(trim(regexp_replace(l_tags(i),''[[:space:]]{1,}';
wwv_flow_imp.g_varchar2_table(29) := ''','' '')),1,255); '||wwv_flow.LF||
'            if l_tag is not null and l_tag != '' '' then '||wwv_flow.LF||
'                if p_case =';
wwv_flow_imp.g_varchar2_table(30) := ' ''U'' then '||wwv_flow.LF||
'                    l_tag := upper(l_tag); '||wwv_flow.LF||
'                elsif p_case = ''L'' then '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(31) := '                l_tag := lower(l_tag); '||wwv_flow.LF||
'                end if; '||wwv_flow.LF||
'                --add it to the ass';
wwv_flow_imp.g_varchar2_table(32) := 'ociative array, if it is a duplicate, it will just be replaced '||wwv_flow.LF||
'                l_tags_a(l_tag) := l';
wwv_flow_imp.g_varchar2_table(33) := '_tag; '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'        end loop; '||wwv_flow.LF||
'        l_tag := null; '||wwv_flow.LF||
'        l_tag := l_tags_a.fir';
wwv_flow_imp.g_varchar2_table(34) := 'st; '||wwv_flow.LF||
'        while l_tag is not null loop '||wwv_flow.LF||
'            l_tags_string := l_tags_string||l_tag; '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(35) := '       if l_tag != l_tags_a.last then '||wwv_flow.LF||
'                l_tags_string := l_tags_string || '', ''; '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(36) := '        end if; '||wwv_flow.LF||
'            l_tag := l_tags_a.next(l_tag); '||wwv_flow.LF||
'        end loop; '||wwv_flow.LF||
'        return subst';
wwv_flow_imp.g_varchar2_table(37) := 'r(l_tags_string, 1, 4000); '||wwv_flow.LF||
'    end tags_cleaner; '||wwv_flow.LF||
'    procedure tag_sync ( '||wwv_flow.LF||
'        p_new_tags     ';
wwv_flow_imp.g_varchar2_table(38) := '     in varchar2, '||wwv_flow.LF||
'        p_old_tags          in varchar2, '||wwv_flow.LF||
'        p_content_type      in varchar2';
wwv_flow_imp.g_varchar2_table(39) := ', '||wwv_flow.LF||
'        p_content_id        in number ) '||wwv_flow.LF||
'    as '||wwv_flow.LF||
'        type tags is table of varchar2(255) inde';
wwv_flow_imp.g_varchar2_table(40) := 'x by varchar2(255); '||wwv_flow.LF||
'        l_new_tags_a    tags; '||wwv_flow.LF||
'        l_old_tags_a    tags; '||wwv_flow.LF||
'        l_new_tag';
wwv_flow_imp.g_varchar2_table(41) := 's      apex_application_global.vc_arr2; '||wwv_flow.LF||
'        l_old_tags      apex_application_global.vc_arr2; '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(42) := '       l_merge_tags    apex_application_global.vc_arr2; '||wwv_flow.LF||
'        l_dummy_tag     varchar2(255); '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(43) := '     i               integer; '||wwv_flow.LF||
'    begin '||wwv_flow.LF||
'        l_old_tags := apex_util.string_to_table(p_old_tags';
wwv_flow_imp.g_varchar2_table(44) := ','', ''); '||wwv_flow.LF||
'        l_new_tags := apex_util.string_to_table(p_new_tags,'', ''); '||wwv_flow.LF||
'        if l_old_tags.co';
wwv_flow_imp.g_varchar2_table(45) := 'unt > 0 then --do inserts and deletes '||wwv_flow.LF||
'            --build the associative arrays '||wwv_flow.LF||
'            for i';
wwv_flow_imp.g_varchar2_table(46) := ' in 1..l_old_tags.count loop '||wwv_flow.LF||
'                l_old_tags_a(l_old_tags(i)) := l_old_tags(i); '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(47) := '     end loop; '||wwv_flow.LF||
'            for i in 1..l_new_tags.count loop '||wwv_flow.LF||
'                l_new_tags_a(l_new_ta';
wwv_flow_imp.g_varchar2_table(48) := 'gs(i)) := l_new_tags(i); '||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'            --do the inserts '||wwv_flow.LF||
'            for i in ';
wwv_flow_imp.g_varchar2_table(49) := '1..l_new_tags.count loop '||wwv_flow.LF||
'                begin '||wwv_flow.LF||
'                    l_dummy_tag := l_old_tags_a(l_n';
wwv_flow_imp.g_varchar2_table(50) := 'ew_tags(i)); '||wwv_flow.LF||
'                exception when no_data_found then '||wwv_flow.LF||
'                    insert into eba';
wwv_flow_imp.g_varchar2_table(51) := '_sales_tags (tag, content_id, content_type ) '||wwv_flow.LF||
'                    values (l_new_tags(i), p_content_i';
wwv_flow_imp.g_varchar2_table(52) := 'd, p_content_type ); '||wwv_flow.LF||
'                    l_merge_tags(l_merge_tags.count + 1) := l_new_tags(i); '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(53) := '              end; '||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'            --do the deletes '||wwv_flow.LF||
'            for i in 1..l_o';
wwv_flow_imp.g_varchar2_table(54) := 'ld_tags.count loop '||wwv_flow.LF||
'                begin '||wwv_flow.LF||
'                    l_dummy_tag := l_new_tags_a(l_old_tag';
wwv_flow_imp.g_varchar2_table(55) := 's(i)); '||wwv_flow.LF||
'                exception when no_data_found then '||wwv_flow.LF||
'                    delete from eba_sales';
wwv_flow_imp.g_varchar2_table(56) := '_tags where content_id = p_content_id and tag = l_old_tags(i); '||wwv_flow.LF||
'                    l_merge_tags(l_m';
wwv_flow_imp.g_varchar2_table(57) := 'erge_tags.count + 1) := l_old_tags(i); '||wwv_flow.LF||
'                end; '||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        else --';
wwv_flow_imp.g_varchar2_table(58) := 'just do inserts '||wwv_flow.LF||
'            for i in 1..l_new_tags.count loop '||wwv_flow.LF||
'                insert into eba_sale';
wwv_flow_imp.g_varchar2_table(59) := 's_tags (tag, content_id, content_type ) '||wwv_flow.LF||
'                values (l_new_tags(i), p_content_id, p_cont';
wwv_flow_imp.g_varchar2_table(60) := 'ent_type ); '||wwv_flow.LF||
'                l_merge_tags(l_merge_tags.count + 1) := l_new_tags(i); '||wwv_flow.LF||
'            end';
wwv_flow_imp.g_varchar2_table(61) := ' loop; '||wwv_flow.LF||
'        end if; '||wwv_flow.LF||
'        for i in 1..l_merge_tags.count loop '||wwv_flow.LF||
'            merge into eba_sal';
wwv_flow_imp.g_varchar2_table(62) := 'es_tags_type_sum s '||wwv_flow.LF||
'            using (select count(*) tag_count '||wwv_flow.LF||
'                     from eba_sale';
wwv_flow_imp.g_varchar2_table(63) := 's_tags '||wwv_flow.LF||
'                    where tag = l_merge_tags(i) and content_type = p_content_type ) t '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(64) := '       on (s.tag = l_merge_tags(i) and s.content_type = p_content_type ) '||wwv_flow.LF||
'            when not match';
wwv_flow_imp.g_varchar2_table(65) := 'ed then insert (tag, content_type, tag_count) '||wwv_flow.LF||
'                                  values (l_merge_tag';
wwv_flow_imp.g_varchar2_table(66) := 's(i), p_content_type, t.tag_count) '||wwv_flow.LF||
'            when matched then update set s.tag_count = t.tag_cou';
wwv_flow_imp.g_varchar2_table(67) := 'nt; '||wwv_flow.LF||
'            merge into eba_sales_tags_sum s '||wwv_flow.LF||
'            using (select sum(tag_count) tag_count';
wwv_flow_imp.g_varchar2_table(68) := ' '||wwv_flow.LF||
'                     from eba_sales_tags_type_sum '||wwv_flow.LF||
'                    where tag = l_merge_tags(i)';
wwv_flow_imp.g_varchar2_table(69) := ' ) t '||wwv_flow.LF||
'            on (s.tag = l_merge_tags(i) ) '||wwv_flow.LF||
'            when not matched then insert (tag, tag_';
wwv_flow_imp.g_varchar2_table(70) := 'count) '||wwv_flow.LF||
'                                  values (l_merge_tags(i), t.tag_count) '||wwv_flow.LF||
'            when ma';
wwv_flow_imp.g_varchar2_table(71) := 'tched then update set s.tag_count = t.tag_count; '||wwv_flow.LF||
'        end loop; '||wwv_flow.LF||
'    end tag_sync; '||wwv_flow.LF||
'    function';
wwv_flow_imp.g_varchar2_table(72) := ' selective_escape ( '||wwv_flow.LF||
'        p_text  in varchar2, '||wwv_flow.LF||
'        p_tags  in varchar2 default ''<h2>,</h2>,<';
wwv_flow_imp.g_varchar2_table(73) := 'p>,</p>,<b>,</b>,<li>,</li>,<ul>,</ul>,<br />,<i>,</i>,<h3>,</h3>'' '||wwv_flow.LF||
'        ) return varchar2 '||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(74) := 's '||wwv_flow.LF||
'        t apex_application_global.vc_arr2; '||wwv_flow.LF||
'        x varchar2(32767) := p_text; '||wwv_flow.LF||
'    begin '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(75) := '    t := apex_util.string_to_table(p_tags, '',''); '||wwv_flow.LF||
'        for i in 1..t.count loop '||wwv_flow.LF||
'            x :=';
wwv_flow_imp.g_varchar2_table(76) := ' replace(x,t(i),''Aa''||i||''aA''); '||wwv_flow.LF||
'        end loop; '||wwv_flow.LF||
'        x := apex_escape.html(x); '||wwv_flow.LF||
'        for i';
wwv_flow_imp.g_varchar2_table(77) := ' in 1..t.count loop '||wwv_flow.LF||
'            x := replace(x,''Aa''||i||''aA'',t(i)); '||wwv_flow.LF||
'        end loop; '||wwv_flow.LF||
'        ret';
wwv_flow_imp.g_varchar2_table(78) := 'urn x; '||wwv_flow.LF||
'    end selective_escape; '||wwv_flow.LF||
'    function get_preference_value ( '||wwv_flow.LF||
'        p_preference_name va';
wwv_flow_imp.g_varchar2_table(79) := 'rchar2 ) '||wwv_flow.LF||
'        return varchar2 '||wwv_flow.LF||
'    is '||wwv_flow.LF||
'        l_preference_value varchar2(255); '||wwv_flow.LF||
'    begin '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(80) := '     select preference_value '||wwv_flow.LF||
'            into l_preference_value '||wwv_flow.LF||
'        from eba_sales_preference';
wwv_flow_imp.g_varchar2_table(81) := 's '||wwv_flow.LF||
'        where preference_name = p_preference_name; '||wwv_flow.LF||
'        return l_preference_value; '||wwv_flow.LF||
'    excep';
wwv_flow_imp.g_varchar2_table(82) := 'tion '||wwv_flow.LF||
'        when no_data_found then '||wwv_flow.LF||
'            return ''Preference does not exist''; '||wwv_flow.LF||
'    end get_';
wwv_flow_imp.g_varchar2_table(83) := 'preference_value; '||wwv_flow.LF||
'    procedure set_preference_value ( '||wwv_flow.LF||
'        p_preference_name  varchar2,  '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(84) := '    p_preference_value varchar2 ) '||wwv_flow.LF||
'    is '||wwv_flow.LF||
'    begin '||wwv_flow.LF||
'        merge into eba_sales_preferences dest ';
wwv_flow_imp.g_varchar2_table(85) := ''||wwv_flow.LF||
'        using ( select upper(p_preference_name) preference_name, '||wwv_flow.LF||
'                    p_preference_';
wwv_flow_imp.g_varchar2_table(86) := 'value preference_value '||wwv_flow.LF||
'                from dual ) src '||wwv_flow.LF||
'        on ( upper(dest.preference_name) = ';
wwv_flow_imp.g_varchar2_table(87) := 'src.preference_name ) '||wwv_flow.LF||
'        when matched then '||wwv_flow.LF||
'            update set dest.preference_value = src';
wwv_flow_imp.g_varchar2_table(88) := '.preference_value '||wwv_flow.LF||
'        when not matched then '||wwv_flow.LF||
'            insert (dest.preference_name, dest.pre';
wwv_flow_imp.g_varchar2_table(89) := 'ference_value) '||wwv_flow.LF||
'            values (src.preference_name, src.preference_value); '||wwv_flow.LF||
'    end set_prefere';
wwv_flow_imp.g_varchar2_table(90) := 'nce_value; '||wwv_flow.LF||
'    function compress_int ( '||wwv_flow.LF||
'        n in integer ) '||wwv_flow.LF||
'        return varchar2 '||wwv_flow.LF||
'    as '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(91) := '      ret varchar2(30); '||wwv_flow.LF||
'        quotient integer; '||wwv_flow.LF||
'        remainder integer; '||wwv_flow.LF||
'        digit char(1';
wwv_flow_imp.g_varchar2_table(92) := '); '||wwv_flow.LF||
'    begin '||wwv_flow.LF||
'        ret := ''''; '||wwv_flow.LF||
'        quotient := n; '||wwv_flow.LF||
'        while quotient > 0 '||wwv_flow.LF||
'        loop ';
wwv_flow_imp.g_varchar2_table(93) := ''||wwv_flow.LF||
'            remainder := mod(quotient, 10 + 26); '||wwv_flow.LF||
'            quotient := floor(quotient  / (10 + 2';
wwv_flow_imp.g_varchar2_table(94) := '6)); '||wwv_flow.LF||
'            if remainder < 26 then '||wwv_flow.LF||
'                digit := chr(ascii(''A'') + remainder); '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(95) := '         else '||wwv_flow.LF||
'                digit := chr(ascii(''0'') + remainder - 26); '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(96) := '        ret := digit || ret; '||wwv_flow.LF||
'        end loop ; '||wwv_flow.LF||
'        if length(ret) < 5 then '||wwv_flow.LF||
'            ret :';
wwv_flow_imp.g_varchar2_table(97) := '= lpad(ret, 4, ''A''); '||wwv_flow.LF||
'        end if ; '||wwv_flow.LF||
'        return ret; '||wwv_flow.LF||
'    end compress_int;'||wwv_flow.LF||
'    function remo';
wwv_flow_imp.g_varchar2_table(98) := 've_duplicates'||wwv_flow.LF||
'    (p_csv_string in varchar2)'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_vc_arr2 APEX_APPLI';
wwv_flow_imp.g_varchar2_table(99) := 'CATION_GLOBAL.VC_ARR2;'||wwv_flow.LF||
'        l_retval  varchar2(32767);'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        l_vc_arr2 := APEX_UTIL.S';
wwv_flow_imp.g_varchar2_table(100) := 'TRING_TO_TABLE(p_csv_string,'','');'||wwv_flow.LF||
'        for i in 1..l_vc_arr2.count'||wwv_flow.LF||
'        loop'||wwv_flow.LF||
'            if l_';
wwv_flow_imp.g_varchar2_table(101) := 'retval is null then'||wwv_flow.LF||
'                l_retval := l_retval || l_vc_arr2(i) || '', '';'||wwv_flow.LF||
'            elsif ';
wwv_flow_imp.g_varchar2_table(102) := 'instr(l_retval,l_vc_arr2(i)) = 0 then'||wwv_flow.LF||
'                l_retval := l_retval || l_vc_arr2(i) || '', '';'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(103) := '            end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        l_retval := rtrim(l_retval, '', '');'||wwv_flow.LF||
'        return l_re';
wwv_flow_imp.g_varchar2_table(104) := 'tval;'||wwv_flow.LF||
'    end remove_duplicates;'||wwv_flow.LF||
'end eba_sales_fw; '||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8473760396641123311)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_fw body'
,p_sequence=>250
,p_script_type=>'UPGRADE'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
