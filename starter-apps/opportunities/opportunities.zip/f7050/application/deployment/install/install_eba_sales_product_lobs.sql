prompt --application/deployment/install/install_eba_sales_product_lobs
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_product_lobs
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6414521395446188035)
,p_install_id=>wwv_flow_imp.id(10495272006180774354)
,p_name=>'eba_sales_product_lobs'
,p_sequence=>140
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_PRODUCT_LOBS" ',
'(',
'    "ID" NUMBER,',
'    "ROW_VERSION_NUMBER" NUMBER,',
'    "NAME" VARCHAR2(255),',
'    "DESCRIPTION" VARCHAR2(4000),',
'    "CREATED_BY" VARCHAR2(255),',
'    "CREATED" TIMESTAMP (6) WITH TIME ZONE,',
'    "UPDATED_BY" VARCHAR2(255),',
'    "UPDATED" TIMESTAMP (6) WITH TIME ZONE,',
'     PRIMARY KEY ("ID")  USING INDEX ENABLE',
');',
'',
'CREATE UNIQUE INDEX "EBA_SALES_PRODUCT_LOBS_UK" ON "EBA_SALES_PRODUCT_LOBS" ("NAME");',
'',
'',
'CREATE OR REPLACE TRIGGER "BIU_EBA_SALES_PRODUCT_LOBS" ',
'   before insert or update on EBA_SALES_PRODUCT_LOBS',
'   for each row',
'   begin',
'      if inserting then',
'         if :NEW.ID is null then',
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')',
'           into :new.id',
'           from dual;',
'         end if;',
'         :NEW.CREATED := current_timestamp;',
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);',
'         :new.updated_by := nvl(v(''APP_USER''),USER);',
'         :new.updated := current_timestamp;',
'         :new.row_version_number := 1;',
'      end if;',
'      if updating then',
'         :NEW.UPDATED := current_timestamp;',
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);',
'         :new.row_version_number := nvl(:old.row_version_number,1) + 1;',
'      end if;',
'end;',
'/',
'',
'ALTER TRIGGER "BIU_EBA_SALES_PRODUCT_LOBS" ENABLE;'))
);
wwv_flow_imp.component_end;
end;
/
