prompt --application/deployment/install/upgrade_eba_sales_clicks_table_indexes_trigger
begin
--   Manifest
--     INSTALL: UPGRADE-eba_sales_clicks table, indexes, trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(7396097035182294135)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_clicks table, indexes, trigger'
,p_sequence=>30
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_SALES_CLICKS'''))
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table eba_sales_clicks (    ',
'    id                number primary key,',
'    cust_id           number references eba_sales_customers (id) on delete cascade,',
'    lead_id           number references eba_sales_leads (id) on delete cascade,',
'    opp_id            number,',
'    app_username      varchar2(255),',
'    view_timestamp    timestamp(6) with time zone,',
'    app_session       varchar2(255)',
');',
'/',
'',
'create index eba_sales_clicks_idx2 on eba_sales_clicks (cust_id);',
'create index eba_sales_clicks_idx1 on eba_sales_clicks (lead_id);',
'create index eba_sales_clicks_idx3 on eba_sales_clicks (opp_id);',
'create index eba_sales_clicks_idx4 on eba_sales_clicks (view_timestamp);',
'',
'create or replace trigger eba_sales_clicks_biu',
'    before insert on eba_sales_clicks',
'    for each row',
'begin',
'     if :new.id is null then',
'         :new.id := eba_sales_sequence.nextval;',
'     end if;',
'     :new.view_timestamp := current_timestamp;',
'     :new.app_username := nvl(v(''APP_USER''),user);',
'     :new.app_session := v(''APP_SESSION'');',
'end;',
'/',
'',
'alter trigger eba_sales_clicks_biu enable;',
''))
);
wwv_flow_imp.component_end;
end;
/
