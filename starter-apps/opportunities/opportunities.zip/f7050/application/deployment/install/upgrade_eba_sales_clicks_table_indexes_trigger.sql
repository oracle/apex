prompt --application/deployment/install/upgrade_eba_sales_clicks_table_indexes_trigger
begin
--   Manifest
--     INSTALL: UPGRADE-eba_sales_clicks table, indexes, trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_sales_clicks (    '||wwv_flow.LF||
'    id                number primary key,'||wwv_flow.LF||
'    cust_id           ';
wwv_flow_imp.g_varchar2_table(2) := 'number references eba_sales_customers (id) on delete cascade,'||wwv_flow.LF||
'    lead_id           number reference';
wwv_flow_imp.g_varchar2_table(3) := 's eba_sales_leads (id) on delete cascade,'||wwv_flow.LF||
'    opp_id            number,'||wwv_flow.LF||
'    app_username      varcha';
wwv_flow_imp.g_varchar2_table(4) := 'r2(255),'||wwv_flow.LF||
'    view_timestamp    timestamp(6) with time zone,'||wwv_flow.LF||
'    app_session       varchar2(255)'||wwv_flow.LF||
');'||wwv_flow.LF||
'/';
wwv_flow_imp.g_varchar2_table(5) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_sales_clicks_idx2 on eba_sales_clicks (cust_id);'||wwv_flow.LF||
'create index eba_sales_clicks_id';
wwv_flow_imp.g_varchar2_table(6) := 'x1 on eba_sales_clicks (lead_id);'||wwv_flow.LF||
'create index eba_sales_clicks_idx3 on eba_sales_clicks (opp_id);'||wwv_flow.LF||
'c';
wwv_flow_imp.g_varchar2_table(7) := 'reate index eba_sales_clicks_idx4 on eba_sales_clicks (view_timestamp);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger e';
wwv_flow_imp.g_varchar2_table(8) := 'ba_sales_clicks_biu'||wwv_flow.LF||
'    before insert on eba_sales_clicks'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'     if :new.id is ';
wwv_flow_imp.g_varchar2_table(9) := 'null then'||wwv_flow.LF||
'         :new.id := eba_sales_sequence.nextval;'||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'     :new.view_timestamp := c';
wwv_flow_imp.g_varchar2_table(10) := 'urrent_timestamp;'||wwv_flow.LF||
'     :new.app_username := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'     :new.app_session := v(''APP';
wwv_flow_imp.g_varchar2_table(11) := '_SESSION'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger eba_sales_clicks_biu enable;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(7396097035182294135)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_clicks table, indexes, trigger'
,p_sequence=>30
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_SALES_CLICKS'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
