prompt --application/deployment/install/upgrade_eba_sales_territory_acl_index
begin
--   Manifest
--     INSTALL: UPGRADE-eba_sales_territory_acl index
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(7519209052396740291)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_territory_acl index'
,p_sequence=>50
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_indexes',
'where index_name = ''EBA_SALES_TERRITORY_ACL_N1'''))
,p_script_clob=>'create index eba_sales_territory_acl_n1 on eba_sales_territory_acl( territory_id );'
);
wwv_flow_imp.component_end;
end;
/
