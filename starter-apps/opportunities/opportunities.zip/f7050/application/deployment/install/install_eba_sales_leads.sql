prompt --application/deployment/install/install_eba_sales_leads
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_leads
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_LEADS" '||wwv_flow.LF||
'   (	"ID" NUMBER, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER, '||wwv_flow.LF||
'	"ROW_KEY" VARCHAR';
wwv_flow_imp.g_varchar2_table(2) := '2(255), '||wwv_flow.LF||
'	"ACCOUNT_ID" NUMBER, '||wwv_flow.LF||
'	"LEAD_SOURCE_ID" NUMBER, '||wwv_flow.LF||
'	"LEAD_DETAILS" VARCHAR2(4000), '||wwv_flow.LF||
'	"LEAD_S';
wwv_flow_imp.g_varchar2_table(3) := 'TATUS" VARCHAR2(30), '||wwv_flow.LF||
'	"LEAD_STATUS_ID" NUMBER, '||wwv_flow.LF||
'	"OPPORTUNITY_ID" NUMBER, '||wwv_flow.LF||
'	"LEAD_EMAIL_01" VARCHAR';
wwv_flow_imp.g_varchar2_table(4) := '2(255), '||wwv_flow.LF||
'	"LEAD_EMAIL_02" VARCHAR2(255), '||wwv_flow.LF||
'	"LEAD_EMAIL_03" VARCHAR2(255), '||wwv_flow.LF||
'	"LEAD_NAME_01" VARCHAR2(';
wwv_flow_imp.g_varchar2_table(5) := '255) NOT NULL ENABLE, '||wwv_flow.LF||
'	"LEAD_NAME_02" VARCHAR2(255), '||wwv_flow.LF||
'	"LEAD_NAME_03" VARCHAR2(255), '||wwv_flow.LF||
'	"LEAD_ADDRES';
wwv_flow_imp.g_varchar2_table(6) := 'S_01" VARCHAR2(255), '||wwv_flow.LF||
'	"LEAD_ADDRESS_02" VARCHAR2(255), '||wwv_flow.LF||
'	"LEAD_ADDRESS_03" VARCHAR2(255), '||wwv_flow.LF||
'	"TAGS" ';
wwv_flow_imp.g_varchar2_table(7) := 'VARCHAR2(4000), '||wwv_flow.LF||
'	"LEAD_PRIORITY" NUMBER, '||wwv_flow.LF||
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"CREATED_BY" V';
wwv_flow_imp.g_varchar2_table(8) := 'ARCHAR2(255), '||wwv_flow.LF||
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"UPDATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"INTERNAL_FL';
wwv_flow_imp.g_varchar2_table(9) := 'EX_FLAG_01" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_02" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_03" VARCHAR2';
wwv_flow_imp.g_varchar2_table(10) := '(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_04" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_01" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_';
wwv_flow_imp.g_varchar2_table(11) := '02" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_03" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_04" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLE';
wwv_flow_imp.g_varchar2_table(12) := 'X_FLAG_01" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_02" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_03" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_';
wwv_flow_imp.g_varchar2_table(13) := '04" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_05" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_06" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_07" VAR';
wwv_flow_imp.g_varchar2_table(14) := 'CHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_08" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_01" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_02" VARCHAR2(4000), '||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(15) := '"FLEX_03" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_04" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_05" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_06" VARCHA';
wwv_flow_imp.g_varchar2_table(16) := 'R2(4000), '||wwv_flow.LF||
'	"FLEX_07" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_08" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_D01" TIMESTAMP (6) WITH TI';
wwv_flow_imp.g_varchar2_table(17) := 'ME ZONE, '||wwv_flow.LF||
'	"FLEX_D02" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D03" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FL';
wwv_flow_imp.g_varchar2_table(18) := 'EX_D04" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_N01" NUMBER, '||wwv_flow.LF||
'	"FLEX_N02" NUMBER, '||wwv_flow.LF||
'	"FLEX_N03" NUMBER,';
wwv_flow_imp.g_varchar2_table(19) := ' '||wwv_flow.LF||
'	"FLEX_N04" NUMBER, '||wwv_flow.LF||
'	"FLEX_N05" NUMBER, '||wwv_flow.LF||
'	"FLEX_N06" NUMBER, '||wwv_flow.LF||
'	"FLEX_N07" NUMBER, '||wwv_flow.LF||
'	"FLEX_N08" NU';
wwv_flow_imp.g_varchar2_table(20) := 'MBER, '||wwv_flow.LF||
'	 PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_LEADS" ADD FOREIGN ';
wwv_flow_imp.g_varchar2_table(21) := 'KEY ("LEAD_SOURCE_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_LEAD_SOURCES" ("ID") ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES';
wwv_flow_imp.g_varchar2_table(22) := '_LEADS" ADD FOREIGN KEY ("LEAD_STATUS_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_LEAD_STATUS_CODES" ("ID") ENABLE';
wwv_flow_imp.g_varchar2_table(23) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814598388173155976)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_leads'
,p_sequence=>210
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814598498214155976)
,p_script_id=>wwv_flow_imp.id(6814598388173155976)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_LEADS'
);
wwv_flow_imp.component_end;
end;
/
