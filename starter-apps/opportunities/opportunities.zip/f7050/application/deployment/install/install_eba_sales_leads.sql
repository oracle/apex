prompt --application/deployment/install/install_eba_sales_leads
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_leads
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814598388173155976)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_leads'
,p_sequence=>210
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_LEADS" ',
'   (	"ID" NUMBER, ',
'	"ROW_VERSION_NUMBER" NUMBER, ',
'	"ROW_KEY" VARCHAR2(255), ',
'	"ACCOUNT_ID" NUMBER, ',
'	"LEAD_SOURCE_ID" NUMBER, ',
'	"LEAD_DETAILS" VARCHAR2(4000), ',
'	"LEAD_STATUS" VARCHAR2(30), ',
'	"LEAD_STATUS_ID" NUMBER, ',
'	"OPPORTUNITY_ID" NUMBER, ',
'	"LEAD_EMAIL_01" VARCHAR2(255), ',
'	"LEAD_EMAIL_02" VARCHAR2(255), ',
'	"LEAD_EMAIL_03" VARCHAR2(255), ',
'	"LEAD_NAME_01" VARCHAR2(255) NOT NULL ENABLE, ',
'	"LEAD_NAME_02" VARCHAR2(255), ',
'	"LEAD_NAME_03" VARCHAR2(255), ',
'	"LEAD_ADDRESS_01" VARCHAR2(255), ',
'	"LEAD_ADDRESS_02" VARCHAR2(255), ',
'	"LEAD_ADDRESS_03" VARCHAR2(255), ',
'	"TAGS" VARCHAR2(4000), ',
'	"LEAD_PRIORITY" NUMBER, ',
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"CREATED_BY" VARCHAR2(255), ',
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"UPDATED_BY" VARCHAR2(255), ',
'	"INTERNAL_FLEX_FLAG_01" VARCHAR2(30), ',
'	"INTERNAL_FLEX_FLAG_02" VARCHAR2(30), ',
'	"INTERNAL_FLEX_FLAG_03" VARCHAR2(30), ',
'	"INTERNAL_FLEX_FLAG_04" VARCHAR2(30), ',
'	"INTERNAL_FLEX_01" VARCHAR2(4000), ',
'	"INTERNAL_FLEX_02" VARCHAR2(4000), ',
'	"INTERNAL_FLEX_03" VARCHAR2(4000), ',
'	"INTERNAL_FLEX_04" VARCHAR2(4000), ',
'	"FLEX_FLAG_01" VARCHAR2(30), ',
'	"FLEX_FLAG_02" VARCHAR2(30), ',
'	"FLEX_FLAG_03" VARCHAR2(30), ',
'	"FLEX_FLAG_04" VARCHAR2(30), ',
'	"FLEX_FLAG_05" VARCHAR2(30), ',
'	"FLEX_FLAG_06" VARCHAR2(30), ',
'	"FLEX_FLAG_07" VARCHAR2(30), ',
'	"FLEX_FLAG_08" VARCHAR2(30), ',
'	"FLEX_01" VARCHAR2(4000), ',
'	"FLEX_02" VARCHAR2(4000), ',
'	"FLEX_03" VARCHAR2(4000), ',
'	"FLEX_04" VARCHAR2(4000), ',
'	"FLEX_05" VARCHAR2(4000), ',
'	"FLEX_06" VARCHAR2(4000), ',
'	"FLEX_07" VARCHAR2(4000), ',
'	"FLEX_08" VARCHAR2(4000), ',
'	"FLEX_D01" TIMESTAMP (6) WITH TIME ZONE, ',
'	"FLEX_D02" TIMESTAMP (6) WITH TIME ZONE, ',
'	"FLEX_D03" TIMESTAMP (6) WITH TIME ZONE, ',
'	"FLEX_D04" TIMESTAMP (6) WITH TIME ZONE, ',
'	"FLEX_N01" NUMBER, ',
'	"FLEX_N02" NUMBER, ',
'	"FLEX_N03" NUMBER, ',
'	"FLEX_N04" NUMBER, ',
'	"FLEX_N05" NUMBER, ',
'	"FLEX_N06" NUMBER, ',
'	"FLEX_N07" NUMBER, ',
'	"FLEX_N08" NUMBER, ',
'	 PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'ALTER TABLE "EBA_SALES_LEADS" ADD FOREIGN KEY ("LEAD_SOURCE_ID")',
'	  REFERENCES "EBA_SALES_LEAD_SOURCES" ("ID") ENABLE;',
'',
'ALTER TABLE "EBA_SALES_LEADS" ADD FOREIGN KEY ("LEAD_STATUS_ID")',
'	  REFERENCES "EBA_SALES_LEAD_STATUS_CODES" ("ID") ENABLE;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814598498214155976)
,p_script_id=>wwv_flow_imp.id(6814598388173155976)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_LEADS'
);
wwv_flow_imp.component_end;
end;
/
