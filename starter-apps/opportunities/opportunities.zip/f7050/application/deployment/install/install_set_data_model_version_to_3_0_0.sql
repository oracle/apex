prompt --application/deployment/install/install_set_data_model_version_to_3_0_0
begin
--   Manifest
--     INSTALL: INSTALL-set data model version to 3.0.0
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6799402759988536147)
,p_install_id=>wwv_flow_imp.id(10495272006180774354)
,p_name=>'set data model version to 3.0.0'
,p_sequence=>670
,p_script_type=>'INSTALL'
,p_script_clob=>'insert into eba_sales_preferences (preference_name, preference_value) values (''DATA_MODEL_VERSION'', ''3.0.0'');'
);
wwv_flow_imp.component_end;
end;
/
