prompt --application/deployment/install/install_set_data_model_version_to_3_0_0
begin
--   Manifest
--     INSTALL: INSTALL-set data model version to 3.0.0
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6817124951949289550)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'set data model version to 3.0.0'
,p_sequence=>670
,p_script_type=>'INSTALL'
,p_script_clob=>'insert into eba_sales_preferences (preference_name, preference_value) values (''DATA_MODEL_VERSION'', ''3.0.0'');'
);
wwv_flow_imp.component_end;
end;
/
