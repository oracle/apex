prompt --application/deployment/install/install_package_bodies
begin
--   Manifest
--     INSTALL: INSTALL-Package Bodies
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE OR REPLACE PACKAGE BODY "EBA_SALES_ACL_API" as '||wwv_flow.LF||
'    -----------------------------------------';
wwv_flow_imp.g_varchar2_table(2) := '--------------------------------'||wwv_flow.LF||
'    -- Generates a unique Identifier'||wwv_flow.LF||
'    --------------------------';
wwv_flow_imp.g_varchar2_table(3) := '-----------------------------------------------'||wwv_flow.LF||
'    function gen_id'||wwv_flow.LF||
'        return number'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(4) := '     l_id  number;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        select to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX''';
wwv_flow_imp.g_varchar2_table(5) := ')'||wwv_flow.LF||
'          into l_id'||wwv_flow.LF||
'          from dual;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'        return l_id;'||wwv_flow.LF||
'    end gen_id;'||wwv_flow.LF||
'    procedure a';
wwv_flow_imp.g_varchar2_table(6) := 'dd_error_log ( '||wwv_flow.LF||
'        p_error in apex_error.t_error )'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'    pragma autonomous_transaction;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(7) := '  begin'||wwv_flow.LF||
'        -- Remove old errors'||wwv_flow.LF||
'        delete from eba_sales_errors where err_time <= current_';
wwv_flow_imp.g_varchar2_table(8) := 'timestamp - 21;'||wwv_flow.LF||
'        -- Log the error.'||wwv_flow.LF||
'        insert into eba_sales_errors ('||wwv_flow.LF||
'            app_id,';
wwv_flow_imp.g_varchar2_table(9) := ''||wwv_flow.LF||
'            app_page_id,'||wwv_flow.LF||
'            app_user,'||wwv_flow.LF||
'            user_agent,'||wwv_flow.LF||
'            ip_address,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(10) := '        ip_address2,'||wwv_flow.LF||
'            message,'||wwv_flow.LF||
'            page_item_name,'||wwv_flow.LF||
'            region_id,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(11) := '     column_alias,'||wwv_flow.LF||
'            row_num,'||wwv_flow.LF||
'            apex_error_code,'||wwv_flow.LF||
'            ora_sqlcode,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(12) := '      ora_sqlerrm,'||wwv_flow.LF||
'            error_backtrace )'||wwv_flow.LF||
'        select v(''APP_ID''),'||wwv_flow.LF||
'            v(''APP_PAGE';
wwv_flow_imp.g_varchar2_table(13) := '_ID''),'||wwv_flow.LF||
'            v(''APP_USER''),'||wwv_flow.LF||
'            owa_util.get_cgi_env(''HTTP_USER_AGENT''),'||wwv_flow.LF||
'            o';
wwv_flow_imp.g_varchar2_table(14) := 'wa_util.get_cgi_env(''REMOTE_ADDR''),'||wwv_flow.LF||
'            sys_context(''USERENV'', ''IP_ADDRESS''),'||wwv_flow.LF||
'            su';
wwv_flow_imp.g_varchar2_table(15) := 'bstr(p_error.message,0,4000),'||wwv_flow.LF||
'            p_error.page_item_name,'||wwv_flow.LF||
'            p_error.region_id,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(16) := '         p_error.column_alias,'||wwv_flow.LF||
'            p_error.row_num,'||wwv_flow.LF||
'            p_error.apex_error_code,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(17) := '         p_error.ora_sqlcode,'||wwv_flow.LF||
'            substr(p_error.ora_sqlerrm,0,4000),'||wwv_flow.LF||
'            substr(p_e';
wwv_flow_imp.g_varchar2_table(18) := 'rror.error_backtrace,0,4000)'||wwv_flow.LF||
'        from dual;'||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
'    end add_error_log;'||wwv_flow.LF||
'    ---------';
wwv_flow_imp.g_varchar2_table(19) := '----------------------------------------------------------------'||wwv_flow.LF||
'    -- Error handling function'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(20) := '-------------------------------------------------------------------------'||wwv_flow.LF||
'    function apex_error_ha';
wwv_flow_imp.g_varchar2_table(21) := 'ndling ('||wwv_flow.LF||
'        p_error in apex_error.t_error )'||wwv_flow.LF||
'        return apex_error.t_error_result'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(22) := '     l_result          apex_error.t_error_result;'||wwv_flow.LF||
'        l_constraint_name varchar2(255);'||wwv_flow.LF||
'    begin';
wwv_flow_imp.g_varchar2_table(23) := ''||wwv_flow.LF||
'        l_result := apex_error.init_error_result ('||wwv_flow.LF||
'                        p_error => p_error );'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(24) := '      -- If it''s an internal error raised by APEX, like an invalid statement or'||wwv_flow.LF||
'        -- code whic';
wwv_flow_imp.g_varchar2_table(25) := 'h can''t be executed, the error text might contain security sensitive'||wwv_flow.LF||
'        -- information. To avoi';
wwv_flow_imp.g_varchar2_table(26) := 'd this security problem we can rewrite the error to'||wwv_flow.LF||
'        -- a generic error message and log the o';
wwv_flow_imp.g_varchar2_table(27) := 'riginal error message for further'||wwv_flow.LF||
'        -- investigation by the help desk.'||wwv_flow.LF||
'        if p_error.is_i';
wwv_flow_imp.g_varchar2_table(28) := 'nternal_error then'||wwv_flow.LF||
'            -- mask all errors that are not common runtime errors (Access Denied'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(29) := '            -- errors raised by application / page authorization and all errors'||wwv_flow.LF||
'            -- regar';
wwv_flow_imp.g_varchar2_table(30) := 'ding session and session state)'||wwv_flow.LF||
'            if not p_error.is_common_runtime_error then        '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(31) := '            -- Change the message to the generic error message which doesn''t expose'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(32) := '-- any sensitive information.'||wwv_flow.LF||
'                add_error_log( p_error );'||wwv_flow.LF||
'                l_result.mes';
wwv_flow_imp.g_varchar2_table(33) := 'sage         := ''An unexpected internal application error has occurred. '';'||wwv_flow.LF||
'                l_result.';
wwv_flow_imp.g_varchar2_table(34) := 'additional_info := null;                      '||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            -- Alway';
wwv_flow_imp.g_varchar2_table(35) := 's show the error as inline error'||wwv_flow.LF||
'            -- Note: If you have created manual tabular forms (usin';
wwv_flow_imp.g_varchar2_table(36) := 'g the package'||wwv_flow.LF||
'            --       apex_item/htmldb_item in the SQL statement) you should still'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(37) := '        --       use "On error page" on that pages to avoid loosing entered data'||wwv_flow.LF||
'            l_resul';
wwv_flow_imp.g_varchar2_table(38) := 't.display_location := case'||wwv_flow.LF||
'                                           when l_result.display_location';
wwv_flow_imp.g_varchar2_table(39) := ' = apex_error.c_on_error_page then apex_error.c_inline_in_notification'||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(40) := '              else l_result.display_location'||wwv_flow.LF||
'                                         end;'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(41) := '   -- If it''s a constraint violation like'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            --   -) ORA-00001: unique const';
wwv_flow_imp.g_varchar2_table(42) := 'raint violated'||wwv_flow.LF||
'            --   -) ORA-02091: transaction rolled back (-> can hide a deferred constr';
wwv_flow_imp.g_varchar2_table(43) := 'aint)'||wwv_flow.LF||
'            --   -) ORA-02290: check constraint violated'||wwv_flow.LF||
'            --   -) ORA-02291: integr';
wwv_flow_imp.g_varchar2_table(44) := 'ity constraint violated - parent key not found'||wwv_flow.LF||
'            --   -) ORA-02292: integrity constraint v';
wwv_flow_imp.g_varchar2_table(45) := 'iolated - child record found'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            -- we try to get a friendly error message fr';
wwv_flow_imp.g_varchar2_table(46) := 'om our constraint lookup configuration.'||wwv_flow.LF||
'            -- If we don''t find the constraint in our lookup';
wwv_flow_imp.g_varchar2_table(47) := ' table we fallback to'||wwv_flow.LF||
'            -- the original ORA error message.'||wwv_flow.LF||
'            if p_error.ora_sqlc';
wwv_flow_imp.g_varchar2_table(48) := 'ode in (-1, -2091, -2290, -2291, -2292) then'||wwv_flow.LF||
'                l_constraint_name := apex_error.extract';
wwv_flow_imp.g_varchar2_table(49) := '_constraint_name ('||wwv_flow.LF||
'                                         p_error => p_error );'||wwv_flow.LF||
'                be';
wwv_flow_imp.g_varchar2_table(50) := 'gin'||wwv_flow.LF||
'                    select message'||wwv_flow.LF||
'                      into l_result.message'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(51) := '     from eba_sales_error_lookup'||wwv_flow.LF||
'                     where constraint_name = l_constraint_name;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(52) := '             exception when no_data_found then null; -- not every constraint has to be in our lookup';
wwv_flow_imp.g_varchar2_table(53) := ' table'||wwv_flow.LF||
'                end;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            -- If an ORA error has been raised, for ';
wwv_flow_imp.g_varchar2_table(54) := 'example a raise_application_error(-20xxx, ''...'')'||wwv_flow.LF||
'            -- in a table trigger or in a PL/SQL pa';
wwv_flow_imp.g_varchar2_table(55) := 'ckage called by a process and we'||wwv_flow.LF||
'            -- haven''t found the error in our lookup table, then we';
wwv_flow_imp.g_varchar2_table(56) := ' just want to see'||wwv_flow.LF||
'            -- the actual error text and not the full error stack with all the ORA';
wwv_flow_imp.g_varchar2_table(57) := ' error numbers.'||wwv_flow.LF||
'            if p_error.ora_sqlcode is not null and l_result.message = p_error.messag';
wwv_flow_imp.g_varchar2_table(58) := 'e then'||wwv_flow.LF||
'                l_result.message := apex_error.get_first_ora_error_text ('||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(59) := '                     p_error => p_error );'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            -- If no associated page ';
wwv_flow_imp.g_varchar2_table(60) := 'item/tabular form column has been set, we can use'||wwv_flow.LF||
'            -- apex_error.auto_set_associated_item';
wwv_flow_imp.g_varchar2_table(61) := ' to automatically guess the affected'||wwv_flow.LF||
'            -- error field by examine the ORA error for constra';
wwv_flow_imp.g_varchar2_table(62) := 'int names or column names.'||wwv_flow.LF||
'            if l_result.page_item_name is null and l_result.column_alias ';
wwv_flow_imp.g_varchar2_table(63) := 'is null then'||wwv_flow.LF||
'                apex_error.auto_set_associated_item ('||wwv_flow.LF||
'                    p_error      ';
wwv_flow_imp.g_varchar2_table(64) := '  => p_error,'||wwv_flow.LF||
'                    p_error_result => l_result );'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(65) := '        return l_result;'||wwv_flow.LF||
'    end apex_error_handling;'||wwv_flow.LF||
'    ------------------------------------------';
wwv_flow_imp.g_varchar2_table(66) := '-------------------------------'||wwv_flow.LF||
'    -- Get''s a preference value, given the name'||wwv_flow.LF||
'    ----------------';
wwv_flow_imp.g_varchar2_table(67) := '---------------------------------------------------------'||wwv_flow.LF||
'    function get_preference_value ('||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(68) := '  p_preference_name   varchar2)'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_preference_value varchar2(2';
wwv_flow_imp.g_varchar2_table(69) := '55);'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        select preference_value'||wwv_flow.LF||
'          into l_preference_value'||wwv_flow.LF||
'          from eba_';
wwv_flow_imp.g_varchar2_table(70) := 'sales_preferences'||wwv_flow.LF||
'         where preference_name = p_preference_name;'||wwv_flow.LF||
'        return l_preference_va';
wwv_flow_imp.g_varchar2_table(71) := 'lue;'||wwv_flow.LF||
'    exception'||wwv_flow.LF||
'        when no_data_found then'||wwv_flow.LF||
'            return ''Preference does not exist'';'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(72) := '   end get_preference_value;'||wwv_flow.LF||
'    -------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(73) := '------'||wwv_flow.LF||
'    -- Set''s a preference value, given the name'||wwv_flow.LF||
'    -----------------------------------------';
wwv_flow_imp.g_varchar2_table(74) := '--------------------------------'||wwv_flow.LF||
'    procedure set_preference_value ('||wwv_flow.LF||
'        p_preference_name   va';
wwv_flow_imp.g_varchar2_table(75) := 'rchar2,'||wwv_flow.LF||
'        p_preference_value  varchar2)'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        update eba_sales_preferences'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(76) := '           set preference_value = p_preference_value'||wwv_flow.LF||
'         where preference_name  = p_preference_';
wwv_flow_imp.g_varchar2_table(77) := 'name;'||wwv_flow.LF||
'    end set_preference_value;'||wwv_flow.LF||
'    ------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(78) := '-------------'||wwv_flow.LF||
'    -- Gets the current user''s authorization level. Depends on the following:'||wwv_flow.LF||
'    --  ';
wwv_flow_imp.g_varchar2_table(79) := '* If access control is currently disabled, returns highest level of 3.'||wwv_flow.LF||
'    --  * If access control i';
wwv_flow_imp.g_varchar2_table(80) := 's enabled, but user is not in list, returns 0'||wwv_flow.LF||
'    --  * If access control is enabled and user is in ';
wwv_flow_imp.g_varchar2_table(81) := 'list, returns their'||wwv_flow.LF||
'    --    access level.'||wwv_flow.LF||
'    ----------------------------------------------------';
wwv_flow_imp.g_varchar2_table(82) := '---------------------'||wwv_flow.LF||
'    function get_authorization_level ('||wwv_flow.LF||
'        p_username             varchar2';
wwv_flow_imp.g_varchar2_table(83) := ')'||wwv_flow.LF||
'        return number'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_access_level_id       eba_sales_users.access_level_id%type ';
wwv_flow_imp.g_varchar2_table(84) := ':= 0;  -- default to lowest privilege.'||wwv_flow.LF||
'        l_account_locked        eba_sales_users.account_locke';
wwv_flow_imp.g_varchar2_table(85) := 'd%type;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        -- If access control is disabled, default to highest privilege'||wwv_flow.LF||
'        if ';
wwv_flow_imp.g_varchar2_table(86) := 'get_preference_value(''ACCESS_CONTROL_ENABLED'') = ''N'' then'||wwv_flow.LF||
'            return 3;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(87) := '     -- Query for user''s access level, throws no_data_found if no user'||wwv_flow.LF||
'            select access_lev';
wwv_flow_imp.g_varchar2_table(88) := 'el_id,'||wwv_flow.LF||
'                   account_locked'||wwv_flow.LF||
'              into l_access_level_id,'||wwv_flow.LF||
'                   l_';
wwv_flow_imp.g_varchar2_table(89) := 'account_locked'||wwv_flow.LF||
'              from eba_sales_users'||wwv_flow.LF||
'             where username = p_username;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(90) := '    -- Check if user''s account is locked, return 0 (no privilege), otherwise stick'||wwv_flow.LF||
'            -- wi';
wwv_flow_imp.g_varchar2_table(91) := 'th their level.'||wwv_flow.LF||
'            if l_account_locked = ''Y'' then'||wwv_flow.LF||
'                return 0;'||wwv_flow.LF||
'            end';
wwv_flow_imp.g_varchar2_table(92) := ' if;'||wwv_flow.LF||
'            -- Overwrite user access level 1 with access level 2 if access control scope is PUB';
wwv_flow_imp.g_varchar2_table(93) := 'LIC_CONTRIBUTE'||wwv_flow.LF||
'            if l_access_level_id = 1 and get_preference_value(''ACCESS_CONTROL_SCOPE'')';
wwv_flow_imp.g_varchar2_table(94) := ' = ''PUBLIC_CONTRIBUTE'' then'||wwv_flow.LF||
'                return 2;'||wwv_flow.LF||
'            end if;            '||wwv_flow.LF||
'        end if';
wwv_flow_imp.g_varchar2_table(95) := ';'||wwv_flow.LF||
'        return l_access_level_id;'||wwv_flow.LF||
'    exception'||wwv_flow.LF||
'        when no_data_found then'||wwv_flow.LF||
'            -- If ';
wwv_flow_imp.g_varchar2_table(96) := 'no user exists with passed username, do a final check if reader access is set to any authenticated u';
wwv_flow_imp.g_varchar2_table(97) := 'ser'||wwv_flow.LF||
'            if get_preference_value(''ACCESS_CONTROL_SCOPE'') = ''PUBLIC_CONTRIBUTE'' then'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(98) := '       return 2;'||wwv_flow.LF||
'            elsif get_preference_value(''ACCESS_CONTROL_SCOPE'') = ''PUBLIC_READONLY'' ';
wwv_flow_imp.g_varchar2_table(99) := 'then'||wwv_flow.LF||
'                return 1;'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'                return 0;'||wwv_flow.LF||
'            end if;       ';
wwv_flow_imp.g_varchar2_table(100) := '    '||wwv_flow.LF||
'    end get_authorization_level;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'end eba_sales_acl_api;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE PACKAGE BOD';
wwv_flow_imp.g_varchar2_table(101) := 'Y "EBA_SALES_FW" as'||wwv_flow.LF||
'    function conv_txt_html ('||wwv_flow.LF||
'        p_txt_message in varchar2 )'||wwv_flow.LF||
'        return ';
wwv_flow_imp.g_varchar2_table(102) := 'varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_html_message   varchar2(32767) default p_txt_message;'||wwv_flow.LF||
'        l_temp_url v';
wwv_flow_imp.g_varchar2_table(103) := 'archar2(32767) := null;'||wwv_flow.LF||
'        l_length number;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        l_html_message := replace(l_html_';
wwv_flow_imp.g_varchar2_table(104) := 'message, chr(10), ''<br />'');'||wwv_flow.LF||
'        l_html_message := replace(l_html_message, chr(13), null);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(105) := '   return l_html_message;'||wwv_flow.LF||
'    end conv_txt_html;'||wwv_flow.LF||
'    function conv_urls_links ('||wwv_flow.LF||
'        p_string in ';
wwv_flow_imp.g_varchar2_table(106) := 'varchar2 )'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_string   varchar2(32767) default p_string;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(107) := '   l_endofUrl varchar2(4000) default chr(10) || chr(13) || chr(9) || '' )<>'';'||wwv_flow.LF||
'        l_url         v';
wwv_flow_imp.g_varchar2_table(108) := 'archar2(4000);'||wwv_flow.LF||
'        l_current_pos number := 1;'||wwv_flow.LF||
'        n             number := 1;'||wwv_flow.LF||
'        m      ';
wwv_flow_imp.g_varchar2_table(109) := '       number := 1;'||wwv_flow.LF||
'        p             number := 1;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        l_string := p_string || '' ''';
wwv_flow_imp.g_varchar2_table(110) := ';'||wwv_flow.LF||
'        for i in 1 .. 1000 loop'||wwv_flow.LF||
'            n := instr( lower(l_string), ''http://'', l_current_pos ';
wwv_flow_imp.g_varchar2_table(111) := ');'||wwv_flow.LF||
'            m := instr( lower(l_string), ''https://'', l_current_pos );'||wwv_flow.LF||
'            p := instr( low';
wwv_flow_imp.g_varchar2_table(112) := 'er(l_string), ''ftp://'', l_current_pos   );'||wwv_flow.LF||
'            -- set n to position of first link'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(113) := '  if m > 0 and (n = 0 or m < n) and (p = 0 or m < p) then'||wwv_flow.LF||
'               n := m;'||wwv_flow.LF||
'            elsif p';
wwv_flow_imp.g_varchar2_table(114) := ' > 0 and (n = 0 or p < n) then'||wwv_flow.LF||
'               n := p;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            exit when n = ';
wwv_flow_imp.g_varchar2_table(115) := '0 or length(l_string) > 32000;'||wwv_flow.LF||
'            for j in 0 .. length( l_string ) - n loop'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(116) := ' if ( instr( l_endofUrl, substr( l_string, n+j, 1 ) ) > 0 ) then'||wwv_flow.LF||
'                   l_url := rtrim( ';
wwv_flow_imp.g_varchar2_table(117) := 'substr( l_string, n, j ), ''.''||chr(32)||chr(10) );'||wwv_flow.LF||
'                   l_url := ''<a href="'' || l_url ';
wwv_flow_imp.g_varchar2_table(118) := '|| ''">'' || l_url || ''</a>'';'||wwv_flow.LF||
'                   l_string := substr( l_string, 1, n-1 ) || l_url || su';
wwv_flow_imp.g_varchar2_table(119) := 'bstr( l_string, n+j );'||wwv_flow.LF||
'                   l_current_pos := n + length(l_url);'||wwv_flow.LF||
'                   exi';
wwv_flow_imp.g_varchar2_table(120) := 't;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        return l_string;'||wwv_flow.LF||
'    end ';
wwv_flow_imp.g_varchar2_table(121) := 'conv_urls_links;'||wwv_flow.LF||
'    function tags_cleaner ('||wwv_flow.LF||
'        p_tags  in varchar2,'||wwv_flow.LF||
'        p_case  in varchar';
wwv_flow_imp.g_varchar2_table(122) := '2 default ''U'' )'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        type tags is table of varchar2(255) index by ';
wwv_flow_imp.g_varchar2_table(123) := 'varchar2(255);'||wwv_flow.LF||
'        l_tags_a        tags;'||wwv_flow.LF||
'        l_tag           varchar2(255);'||wwv_flow.LF||
'        l_tags  ';
wwv_flow_imp.g_varchar2_table(124) := '        apex_application_global.vc_arr2;'||wwv_flow.LF||
'        l_tags_string   varchar2(32767);'||wwv_flow.LF||
'        i         ';
wwv_flow_imp.g_varchar2_table(125) := '      integer;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        l_tags := apex_util.string_to_table(p_tags,'','');'||wwv_flow.LF||
'        for i in 1';
wwv_flow_imp.g_varchar2_table(126) := '..l_tags.count loop'||wwv_flow.LF||
'            --remove all whitespace, including tabs, spaces, line feeds and carr';
wwv_flow_imp.g_varchar2_table(127) := 'aige returns with a single space'||wwv_flow.LF||
'            l_tag := substr(trim(regexp_replace(l_tags(i),''[[:space';
wwv_flow_imp.g_varchar2_table(128) := ':]]{1,}'','' '')),1,255);'||wwv_flow.LF||
'            if l_tag is not null and l_tag != '' '' then'||wwv_flow.LF||
'                if p_c';
wwv_flow_imp.g_varchar2_table(129) := 'ase = ''U'' then'||wwv_flow.LF||
'                    l_tag := upper(l_tag);'||wwv_flow.LF||
'                elsif p_case = ''L'' then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(130) := '                  l_tag := lower(l_tag);'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'                --add it to the ass';
wwv_flow_imp.g_varchar2_table(131) := 'ociative array, if it is a duplicate, it will just be replaced'||wwv_flow.LF||
'                l_tags_a(l_tag) := l_';
wwv_flow_imp.g_varchar2_table(132) := 'tag;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        l_tag := null;'||wwv_flow.LF||
'        l_tag := l_tags_a.first;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(133) := '       while l_tag is not null loop'||wwv_flow.LF||
'            l_tags_string := l_tags_string||l_tag;'||wwv_flow.LF||
'            i';
wwv_flow_imp.g_varchar2_table(134) := 'f l_tag != l_tags_a.last then'||wwv_flow.LF||
'                l_tags_string := l_tags_string || '', '';'||wwv_flow.LF||
'            en';
wwv_flow_imp.g_varchar2_table(135) := 'd if;'||wwv_flow.LF||
'            l_tag := l_tags_a.next(l_tag);'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        return substr(l_tags_stri';
wwv_flow_imp.g_varchar2_table(136) := 'ng, 1, 4000);'||wwv_flow.LF||
'    end tags_cleaner;'||wwv_flow.LF||
'    procedure tag_sync ('||wwv_flow.LF||
'        p_new_tags          in varchar2';
wwv_flow_imp.g_varchar2_table(137) := ','||wwv_flow.LF||
'        p_old_tags          in varchar2,'||wwv_flow.LF||
'        p_content_type      in varchar2,'||wwv_flow.LF||
'        p_conten';
wwv_flow_imp.g_varchar2_table(138) := 't_id        in number )'||wwv_flow.LF||
'    as'||wwv_flow.LF||
'        type tags is table of varchar2(255) index by varchar2(255);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(139) := '       l_new_tags_a    tags;'||wwv_flow.LF||
'        l_old_tags_a    tags;'||wwv_flow.LF||
'        l_new_tags      apex_application_';
wwv_flow_imp.g_varchar2_table(140) := 'global.vc_arr2;'||wwv_flow.LF||
'        l_old_tags      apex_application_global.vc_arr2;'||wwv_flow.LF||
'        l_merge_tags    ape';
wwv_flow_imp.g_varchar2_table(141) := 'x_application_global.vc_arr2;'||wwv_flow.LF||
'        l_dummy_tag     varchar2(255);'||wwv_flow.LF||
'        i               integer';
wwv_flow_imp.g_varchar2_table(142) := ';'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        l_old_tags := apex_util.string_to_table(p_old_tags,'', '');'||wwv_flow.LF||
'        l_new_tags := ';
wwv_flow_imp.g_varchar2_table(143) := 'apex_util.string_to_table(p_new_tags,'', '');'||wwv_flow.LF||
'        if l_old_tags.count > 0 then --do inserts and de';
wwv_flow_imp.g_varchar2_table(144) := 'letes'||wwv_flow.LF||
'            --build the associative arrays'||wwv_flow.LF||
'            for i in 1..l_old_tags.count loop'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(145) := '           l_old_tags_a(l_old_tags(i)) := l_old_tags(i);'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'            for i in ';
wwv_flow_imp.g_varchar2_table(146) := '1..l_new_tags.count loop'||wwv_flow.LF||
'                l_new_tags_a(l_new_tags(i)) := l_new_tags(i);'||wwv_flow.LF||
'            e';
wwv_flow_imp.g_varchar2_table(147) := 'nd loop;'||wwv_flow.LF||
'            --do the inserts'||wwv_flow.LF||
'            for i in 1..l_new_tags.count loop'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(148) := 'begin'||wwv_flow.LF||
'                    l_dummy_tag := l_old_tags_a(l_new_tags(i));'||wwv_flow.LF||
'                exception when';
wwv_flow_imp.g_varchar2_table(149) := ' no_data_found then'||wwv_flow.LF||
'                    insert into eba_sales_tags (tag, content_id, content_type )'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(150) := '                    values (l_new_tags(i), p_content_id, p_content_type );'||wwv_flow.LF||
'                    l_mer';
wwv_flow_imp.g_varchar2_table(151) := 'ge_tags(l_merge_tags.count + 1) := l_new_tags(i);'||wwv_flow.LF||
'                end;'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(152) := '     --do the deletes'||wwv_flow.LF||
'            for i in 1..l_old_tags.count loop'||wwv_flow.LF||
'                begin'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(153) := '          l_dummy_tag := l_new_tags_a(l_old_tags(i));'||wwv_flow.LF||
'                exception when no_data_found t';
wwv_flow_imp.g_varchar2_table(154) := 'hen'||wwv_flow.LF||
'                    delete from eba_sales_tags where content_id = p_content_id and tag = l_old_t';
wwv_flow_imp.g_varchar2_table(155) := 'ags(i);'||wwv_flow.LF||
'                    l_merge_tags(l_merge_tags.count + 1) := l_old_tags(i);'||wwv_flow.LF||
'                e';
wwv_flow_imp.g_varchar2_table(156) := 'nd;'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'        else --just do inserts'||wwv_flow.LF||
'            for i in 1..l_new_tags.count lo';
wwv_flow_imp.g_varchar2_table(157) := 'op'||wwv_flow.LF||
'                insert into eba_sales_tags (tag, content_id, content_type )'||wwv_flow.LF||
'                value';
wwv_flow_imp.g_varchar2_table(158) := 's (l_new_tags(i), p_content_id, p_content_type );'||wwv_flow.LF||
'                l_merge_tags(l_merge_tags.count + ';
wwv_flow_imp.g_varchar2_table(159) := '1) := l_new_tags(i);'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        for i in 1..l_merge_tags.count lo';
wwv_flow_imp.g_varchar2_table(160) := 'op'||wwv_flow.LF||
'            merge into eba_sales_tags_type_sum s'||wwv_flow.LF||
'            using (select count(*) tag_count'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(161) := '                  from eba_sales_tags'||wwv_flow.LF||
'                    where tag = l_merge_tags(i) and content_ty';
wwv_flow_imp.g_varchar2_table(162) := 'pe = p_content_type ) t'||wwv_flow.LF||
'            on (s.tag = l_merge_tags(i) and s.content_type = p_content_type ';
wwv_flow_imp.g_varchar2_table(163) := ')'||wwv_flow.LF||
'            when not matched then insert (tag, content_type, tag_count)'||wwv_flow.LF||
'                          ';
wwv_flow_imp.g_varchar2_table(164) := '        values (l_merge_tags(i), p_content_type, t.tag_count)'||wwv_flow.LF||
'            when matched then update s';
wwv_flow_imp.g_varchar2_table(165) := 'et s.tag_count = t.tag_count;'||wwv_flow.LF||
'            merge into eba_sales_tags_sum s'||wwv_flow.LF||
'            using (select ';
wwv_flow_imp.g_varchar2_table(166) := 'sum(tag_count) tag_count'||wwv_flow.LF||
'                     from eba_sales_tags_type_sum'||wwv_flow.LF||
'                    where';
wwv_flow_imp.g_varchar2_table(167) := ' tag = l_merge_tags(i) ) t'||wwv_flow.LF||
'            on (s.tag = l_merge_tags(i) )'||wwv_flow.LF||
'            when not matched th';
wwv_flow_imp.g_varchar2_table(168) := 'en insert (tag, tag_count)'||wwv_flow.LF||
'                                  values (l_merge_tags(i), t.tag_count)'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(169) := '           when matched then update set s.tag_count = t.tag_count;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'    end tag_syn';
wwv_flow_imp.g_varchar2_table(170) := 'c;'||wwv_flow.LF||
'    function selective_escape ('||wwv_flow.LF||
'        p_text  in varchar2,'||wwv_flow.LF||
'        p_tags  in varchar2 default ';
wwv_flow_imp.g_varchar2_table(171) := '''<h2>,</h2>,<p>,</p>,<b>,</b>,<li>,</li>,<ul>,</ul>,<br />,<i>,</i>,<h3>,</h3>'''||wwv_flow.LF||
'        ) return var';
wwv_flow_imp.g_varchar2_table(172) := 'char2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        t apex_application_global.vc_arr2;'||wwv_flow.LF||
'        x varchar2(32767) := p_text;'||wwv_flow.LF||
'    beg';
wwv_flow_imp.g_varchar2_table(173) := 'in'||wwv_flow.LF||
'        t := apex_util.string_to_table(p_tags, '','');'||wwv_flow.LF||
'        for i in 1..t.count loop'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(174) := ' x := replace(x,t(i),''Aa''||i||''aA'');'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        x := apex_escape.html(x);'||wwv_flow.LF||
'        for';
wwv_flow_imp.g_varchar2_table(175) := ' i in 1..t.count loop'||wwv_flow.LF||
'            x := replace(x,''Aa''||i||''aA'',t(i));'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        retu';
wwv_flow_imp.g_varchar2_table(176) := 'rn x;'||wwv_flow.LF||
'    end selective_escape;'||wwv_flow.LF||
'    function get_preference_value ('||wwv_flow.LF||
'        p_preference_name varcha';
wwv_flow_imp.g_varchar2_table(177) := 'r2 )'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_preference_value varchar2(255);'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        sele';
wwv_flow_imp.g_varchar2_table(178) := 'ct preference_value'||wwv_flow.LF||
'            into l_preference_value'||wwv_flow.LF||
'        from eba_sales_preferences'||wwv_flow.LF||
'        w';
wwv_flow_imp.g_varchar2_table(179) := 'here preference_name = p_preference_name;'||wwv_flow.LF||
'        return l_preference_value;'||wwv_flow.LF||
'    exception'||wwv_flow.LF||
'        w';
wwv_flow_imp.g_varchar2_table(180) := 'hen no_data_found then'||wwv_flow.LF||
'            return ''Preference does not exist'';'||wwv_flow.LF||
'    end get_preference_value;';
wwv_flow_imp.g_varchar2_table(181) := ''||wwv_flow.LF||
'    procedure set_preference_value ('||wwv_flow.LF||
'        p_preference_name  varchar2, '||wwv_flow.LF||
'        p_preference_val';
wwv_flow_imp.g_varchar2_table(182) := 'ue varchar2 )'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        merge into eba_sales_preferences dest'||wwv_flow.LF||
'        using ( select ';
wwv_flow_imp.g_varchar2_table(183) := 'upper(p_preference_name) preference_name,'||wwv_flow.LF||
'                    p_preference_value preference_value'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(184) := '              from dual ) src'||wwv_flow.LF||
'        on ( upper(dest.preference_name) = src.preference_name )'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(185) := '   when matched then'||wwv_flow.LF||
'            update set dest.preference_value = src.preference_value'||wwv_flow.LF||
'        whe';
wwv_flow_imp.g_varchar2_table(186) := 'n not matched then'||wwv_flow.LF||
'            insert (dest.preference_name, dest.preference_value)'||wwv_flow.LF||
'            valu';
wwv_flow_imp.g_varchar2_table(187) := 'es (src.preference_name, src.preference_value);'||wwv_flow.LF||
'    end set_preference_value;'||wwv_flow.LF||
'    function compress_';
wwv_flow_imp.g_varchar2_table(188) := 'int ('||wwv_flow.LF||
'        n in integer )'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    as'||wwv_flow.LF||
'        ret varchar2(30);'||wwv_flow.LF||
'        quotie';
wwv_flow_imp.g_varchar2_table(189) := 'nt integer;'||wwv_flow.LF||
'        remainder integer;'||wwv_flow.LF||
'        digit char(1);'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        ret := '''';'||wwv_flow.LF||
'        q';
wwv_flow_imp.g_varchar2_table(190) := 'uotient := n;'||wwv_flow.LF||
'        while quotient > 0'||wwv_flow.LF||
'        loop'||wwv_flow.LF||
'            remainder := mod(quotient, 10 + 26';
wwv_flow_imp.g_varchar2_table(191) := ');'||wwv_flow.LF||
'            quotient := floor(quotient  / (10 + 26));'||wwv_flow.LF||
'            if remainder < 26 then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(192) := '        digit := chr(ascii(''A'') + remainder);'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'                digit := chr(ascii(''0';
wwv_flow_imp.g_varchar2_table(193) := ''') + remainder - 26);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            ret := digit || ret;'||wwv_flow.LF||
'        end loop ;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(194) := '  if length(ret) < 5 then'||wwv_flow.LF||
'            ret := lpad(ret, 4, ''A'');'||wwv_flow.LF||
'        end if ;'||wwv_flow.LF||
'        return ret;';
wwv_flow_imp.g_varchar2_table(195) := ''||wwv_flow.LF||
'    end compress_int;'||wwv_flow.LF||
'end eba_sales_fw;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6975400472729193560)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'Package Bodies'
,p_sequence=>590
,p_script_type=>'INSTALL'
,p_script_option=>'PACKAGE_BODY'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6975400607262193562)
,p_script_id=>wwv_flow_imp.id(6975400472729193560)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_SALES_FW'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6975400780968193563)
,p_script_id=>wwv_flow_imp.id(6975400472729193560)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_SALES_ACL_API'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6975401009166193563)
,p_script_id=>wwv_flow_imp.id(6975400472729193560)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_SALES_DATA'
);
wwv_flow_imp.component_end;
end;
/
