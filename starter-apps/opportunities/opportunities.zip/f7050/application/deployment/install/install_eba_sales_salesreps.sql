prompt --application/deployment/install/install_eba_sales_salesreps
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_salesreps
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_SALESREPS" '||wwv_flow.LF||
'   (	"ID" NUMBER, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER, '||wwv_flow.LF||
'	"ROW_KEY" VAR';
wwv_flow_imp.g_varchar2_table(2) := 'CHAR2(255), '||wwv_flow.LF||
'	"REP_LAST_NAME" VARCHAR2(100) NOT NULL ENABLE, '||wwv_flow.LF||
'	"REP_FIRST_NAME" VARCHAR2(100) NOT NU';
wwv_flow_imp.g_varchar2_table(3) := 'LL ENABLE, '||wwv_flow.LF||
'	"REP_EMAIL" VARCHAR2(100) NOT NULL ENABLE, '||wwv_flow.LF||
'	"REP_MANAGER_ID" NUMBER, '||wwv_flow.LF||
'	"REP_EBA_SALES_';
wwv_flow_imp.g_varchar2_table(4) := 'USERNAME" VARCHAR2(255), '||wwv_flow.LF||
'	"REP_ROLE" NUMBER, '||wwv_flow.LF||
'	"REP_OFFICE" VARCHAR2(255), '||wwv_flow.LF||
'	"REP_OFFICE_PHONE" VAR';
wwv_flow_imp.g_varchar2_table(5) := 'CHAR2(100), '||wwv_flow.LF||
'	"REP_CELL_PHONE" VARCHAR2(100), '||wwv_flow.LF||
'	"REP_PAGER" VARCHAR2(100), '||wwv_flow.LF||
'	"SVP_ID" NUMBER, '||wwv_flow.LF||
'	"CRE';
wwv_flow_imp.g_varchar2_table(6) := 'ATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"UPDATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"U';
wwv_flow_imp.g_varchar2_table(7) := 'PDATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_01" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_';
wwv_flow_imp.g_varchar2_table(8) := '02" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_03" VARCHAR2(30), '||wwv_flow.LF||
'	"INTERNAL_FLEX_FLAG_04" VARCHAR2(30), '||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(9) := '"INTERNAL_FLEX_01" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_02" VARCHAR2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_03" VARCHAR';
wwv_flow_imp.g_varchar2_table(10) := '2(4000), '||wwv_flow.LF||
'	"INTERNAL_FLEX_04" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_FLAG_01" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_02" VARCHA';
wwv_flow_imp.g_varchar2_table(11) := 'R2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_03" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_04" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_05" VARCHAR2(30),';
wwv_flow_imp.g_varchar2_table(12) := ' '||wwv_flow.LF||
'	"FLEX_FLAG_06" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_07" VARCHAR2(30), '||wwv_flow.LF||
'	"FLEX_FLAG_08" VARCHAR2(30), '||wwv_flow.LF||
'	"FLE';
wwv_flow_imp.g_varchar2_table(13) := 'X_01" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_02" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_03" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_04" VARCHAR2(4';
wwv_flow_imp.g_varchar2_table(14) := '000), '||wwv_flow.LF||
'	"FLEX_05" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_06" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_07" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_08';
wwv_flow_imp.g_varchar2_table(15) := '" VARCHAR2(4000), '||wwv_flow.LF||
'	"FLEX_D01" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D02" TIMESTAMP (6) WITH TIME ZO';
wwv_flow_imp.g_varchar2_table(16) := 'NE, '||wwv_flow.LF||
'	"FLEX_D03" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_D04" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FLEX_N0';
wwv_flow_imp.g_varchar2_table(17) := '1" NUMBER, '||wwv_flow.LF||
'	"FLEX_N02" NUMBER, '||wwv_flow.LF||
'	"FLEX_N03" NUMBER, '||wwv_flow.LF||
'	"FLEX_N04" NUMBER, '||wwv_flow.LF||
'	"FLEX_N05" NUMBER, '||wwv_flow.LF||
'	"FL';
wwv_flow_imp.g_varchar2_table(18) := 'EX_N06" NUMBER, '||wwv_flow.LF||
'	"FLEX_N07" NUMBER, '||wwv_flow.LF||
'	"FLEX_N08" NUMBER, '||wwv_flow.LF||
'	 PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABL';
wwv_flow_imp.g_varchar2_table(19) := 'E'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814611450594217761)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_salesreps'
,p_sequence=>50
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814611559455217762)
,p_script_id=>wwv_flow_imp.id(6814611450594217761)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_SALESREPS'
);
wwv_flow_imp.component_end;
end;
/
