prompt --application/deployment/install/install_eba_sales_error_lookup
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_error_lookup
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_ERROR_LOOKUP" '||wwv_flow.LF||
'   (	"CONSTRAINT_NAME" VARCHAR2(30) NOT NULL ENABLE, '||wwv_flow.LF||
'	"MESSA';
wwv_flow_imp.g_varchar2_table(2) := 'GE" VARCHAR2(4000) NOT NULL ENABLE, '||wwv_flow.LF||
'	"LANGUAGE_CODE" VARCHAR2(30) NOT NULL ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "E';
wwv_flow_imp.g_varchar2_table(3) := 'BA_SALES_ERROR_LOOKUP_PK" PRIMARY KEY ("CONSTRAINT_NAME")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814593897334119154)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_error_lookup'
,p_sequence=>340
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814593935193119155)
,p_script_id=>wwv_flow_imp.id(6814593897334119154)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_ERROR_LOOKUP'
);
wwv_flow_imp.component_end;
end;
/
