prompt --application/deployment/install/upgrade_eba_sales_acl_api_package_body
begin
--   Manifest
--     INSTALL: UPGRADE-eba_sales_acl_api package body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body eba_sales_acl_api as'||wwv_flow.LF||
'    --------------------------------------------';
wwv_flow_imp.g_varchar2_table(2) := '-----------------------------'||wwv_flow.LF||
'    -- Generates a unique Identifier'||wwv_flow.LF||
'    -----------------------------';
wwv_flow_imp.g_varchar2_table(3) := '--------------------------------------------'||wwv_flow.LF||
'    function gen_id'||wwv_flow.LF||
'        return number'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(4) := '  l_id  number;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        select to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(5) := '         into l_id'||wwv_flow.LF||
'          from dual;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'        return l_id;'||wwv_flow.LF||
'    end gen_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure add';
wwv_flow_imp.g_varchar2_table(6) := '_error_log ('||wwv_flow.LF||
'        p_error in apex_error.t_error )'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'    pragma autonomous_transaction;'||wwv_flow.LF||
'    b';
wwv_flow_imp.g_varchar2_table(7) := 'egin'||wwv_flow.LF||
'        -- Remove old errors'||wwv_flow.LF||
'        delete from eba_sales_errors where err_time <= current_tim';
wwv_flow_imp.g_varchar2_table(8) := 'estamp - 21;'||wwv_flow.LF||
'        -- Log the error.'||wwv_flow.LF||
'        insert into eba_sales_errors ('||wwv_flow.LF||
'            app_id,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(9) := '          app_page_id,'||wwv_flow.LF||
'            app_user,'||wwv_flow.LF||
'            user_agent,'||wwv_flow.LF||
'            ip_address,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(10) := '     ip_address2,'||wwv_flow.LF||
'            message,'||wwv_flow.LF||
'            page_item_name,'||wwv_flow.LF||
'            region_id,'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(11) := '  column_alias,'||wwv_flow.LF||
'            row_num,'||wwv_flow.LF||
'            apex_error_code,'||wwv_flow.LF||
'            ora_sqlcode,'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(12) := '   ora_sqlerrm,'||wwv_flow.LF||
'            error_backtrace )'||wwv_flow.LF||
'        select v(''APP_ID''),'||wwv_flow.LF||
'            v(''APP_PAGE_ID';
wwv_flow_imp.g_varchar2_table(13) := '''),'||wwv_flow.LF||
'            v(''APP_USER''),'||wwv_flow.LF||
'            owa_util.get_cgi_env(''HTTP_USER_AGENT''),'||wwv_flow.LF||
'            owa_';
wwv_flow_imp.g_varchar2_table(14) := 'util.get_cgi_env(''REMOTE_ADDR''),'||wwv_flow.LF||
'            sys_context(''USERENV'', ''IP_ADDRESS''),'||wwv_flow.LF||
'            subst';
wwv_flow_imp.g_varchar2_table(15) := 'r(p_error.message,0,4000),'||wwv_flow.LF||
'            p_error.page_item_name,'||wwv_flow.LF||
'            p_error.region_id,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(16) := '      p_error.column_alias,'||wwv_flow.LF||
'            p_error.row_num,'||wwv_flow.LF||
'            p_error.apex_error_code,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(17) := '      p_error.ora_sqlcode,'||wwv_flow.LF||
'            substr(p_error.ora_sqlerrm,0,4000),'||wwv_flow.LF||
'            substr(p_erro';
wwv_flow_imp.g_varchar2_table(18) := 'r.error_backtrace,0,4000)'||wwv_flow.LF||
'        from dual;'||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
'    end add_error_log;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -----------';
wwv_flow_imp.g_varchar2_table(19) := '--------------------------------------------------------------'||wwv_flow.LF||
'    -- Error handling function'||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(20) := '-----------------------------------------------------------------------'||wwv_flow.LF||
'    function apex_error_hand';
wwv_flow_imp.g_varchar2_table(21) := 'ling ('||wwv_flow.LF||
'        p_error in apex_error.t_error )'||wwv_flow.LF||
'        return apex_error.t_error_result'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(22) := '   l_result          apex_error.t_error_result;'||wwv_flow.LF||
'        l_constraint_name varchar2(255);'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(23) := '       l_result := apex_error.init_error_result ('||wwv_flow.LF||
'                        p_error => p_error );'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(24) := '    -- If it''s an internal error raised by APEX, like an invalid statement or'||wwv_flow.LF||
'        -- code which ';
wwv_flow_imp.g_varchar2_table(25) := 'can''t be executed, the error text might contain security sensitive'||wwv_flow.LF||
'        -- information. To avoid ';
wwv_flow_imp.g_varchar2_table(26) := 'this security problem we can rewrite the error to'||wwv_flow.LF||
'        -- a generic error message and log the ori';
wwv_flow_imp.g_varchar2_table(27) := 'ginal error message for further'||wwv_flow.LF||
'        -- investigation by the help desk.'||wwv_flow.LF||
'        if p_error.is_int';
wwv_flow_imp.g_varchar2_table(28) := 'ernal_error then'||wwv_flow.LF||
'            -- mask all errors that are not common runtime errors (Access Denied'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(29) := '          -- errors raised by application / page authorization and all errors'||wwv_flow.LF||
'            -- regardi';
wwv_flow_imp.g_varchar2_table(30) := 'ng session and session state)'||wwv_flow.LF||
'            if not p_error.is_common_runtime_error then'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(31) := '  -- Change the message to the generic error message which doesn''t expose'||wwv_flow.LF||
'                -- any sen';
wwv_flow_imp.g_varchar2_table(32) := 'sitive information.'||wwv_flow.LF||
''||wwv_flow.LF||
'                add_error_log( p_error );'||wwv_flow.LF||
''||wwv_flow.LF||
'                l_result.message    ';
wwv_flow_imp.g_varchar2_table(33) := '     := ''An unexpected internal application error has occurred. '';'||wwv_flow.LF||
'                l_result.addition';
wwv_flow_imp.g_varchar2_table(34) := 'al_info := null;                      '||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            -- Always show t';
wwv_flow_imp.g_varchar2_table(35) := 'he error as inline error'||wwv_flow.LF||
'            -- Note: If you have created manual tabular forms (using the pa';
wwv_flow_imp.g_varchar2_table(36) := 'ckage'||wwv_flow.LF||
'            --       apex_item/htmldb_item in the SQL statement) you should still'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(37) := '--       use "On error page" on that pages to avoid loosing entered data'||wwv_flow.LF||
'            l_result.displa';
wwv_flow_imp.g_varchar2_table(38) := 'y_location := case'||wwv_flow.LF||
'                                           when l_result.display_location = apex_';
wwv_flow_imp.g_varchar2_table(39) := 'error.c_on_error_page then apex_error.c_inline_in_notification'||wwv_flow.LF||
'                                     ';
wwv_flow_imp.g_varchar2_table(40) := '      else l_result.display_location'||wwv_flow.LF||
'                                         end;'||wwv_flow.LF||
'            -- If';
wwv_flow_imp.g_varchar2_table(41) := ' it''s a constraint violation like'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            --   -) ORA-00001: unique constraint vi';
wwv_flow_imp.g_varchar2_table(42) := 'olated'||wwv_flow.LF||
'            --   -) ORA-02091: transaction rolled back (-> can hide a deferred constraint)'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(43) := '          --   -) ORA-02290: check constraint violated'||wwv_flow.LF||
'            --   -) ORA-02291: integrity cons';
wwv_flow_imp.g_varchar2_table(44) := 'traint violated - parent key not found'||wwv_flow.LF||
'            --   -) ORA-02292: integrity constraint violated ';
wwv_flow_imp.g_varchar2_table(45) := '- child record found'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            -- we try to get a friendly error message from our c';
wwv_flow_imp.g_varchar2_table(46) := 'onstraint lookup configuration.'||wwv_flow.LF||
'            -- If we don''t find the constraint in our lookup table w';
wwv_flow_imp.g_varchar2_table(47) := 'e fallback to'||wwv_flow.LF||
'            -- the original ORA error message.'||wwv_flow.LF||
'            if p_error.ora_sqlcode in (';
wwv_flow_imp.g_varchar2_table(48) := '-1, -2091, -2290, -2291, -2292) then'||wwv_flow.LF||
'                l_constraint_name := apex_error.extract_constra';
wwv_flow_imp.g_varchar2_table(49) := 'int_name ('||wwv_flow.LF||
'                                         p_error => p_error );'||wwv_flow.LF||
'                begin'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(50) := '                select message'||wwv_flow.LF||
'                      into l_result.message'||wwv_flow.LF||
'                      fro';
wwv_flow_imp.g_varchar2_table(51) := 'm eba_sales_error_lookup'||wwv_flow.LF||
'                     where constraint_name = l_constraint_name;'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(52) := '     exception when no_data_found then null; -- not every constraint has to be in our lookup table'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(53) := '               end;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            -- If an ORA error has been raised, for example ';
wwv_flow_imp.g_varchar2_table(54) := 'a raise_application_error(-20xxx, ''...'')'||wwv_flow.LF||
'            -- in a table trigger or in a PL/SQL package ca';
wwv_flow_imp.g_varchar2_table(55) := 'lled by a process and we'||wwv_flow.LF||
'            -- haven''t found the error in our lookup table, then we just wa';
wwv_flow_imp.g_varchar2_table(56) := 'nt to see'||wwv_flow.LF||
'            -- the actual error text and not the full error stack with all the ORA error n';
wwv_flow_imp.g_varchar2_table(57) := 'umbers.'||wwv_flow.LF||
'            if p_error.ora_sqlcode is not null and l_result.message = p_error.message then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(58) := '               l_result.message := apex_error.get_first_ora_error_text ('||wwv_flow.LF||
'                           ';
wwv_flow_imp.g_varchar2_table(59) := '             p_error => p_error );'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            -- If no associated page item/tab';
wwv_flow_imp.g_varchar2_table(60) := 'ular form column has been set, we can use'||wwv_flow.LF||
'            -- apex_error.auto_set_associated_item to auto';
wwv_flow_imp.g_varchar2_table(61) := 'matically guess the affected'||wwv_flow.LF||
'            -- error field by examine the ORA error for constraint name';
wwv_flow_imp.g_varchar2_table(62) := 's or column names.'||wwv_flow.LF||
'            if l_result.page_item_name is null and l_result.column_alias is null ';
wwv_flow_imp.g_varchar2_table(63) := 'then'||wwv_flow.LF||
'                apex_error.auto_set_associated_item ('||wwv_flow.LF||
'                    p_error        => p_e';
wwv_flow_imp.g_varchar2_table(64) := 'rror,'||wwv_flow.LF||
'                    p_error_result => l_result );'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(65) := 'return l_result;'||wwv_flow.LF||
'    end apex_error_handling;'||wwv_flow.LF||
'    --------------------------------------------------';
wwv_flow_imp.g_varchar2_table(66) := '-----------------------'||wwv_flow.LF||
'    -- Get''s a preference value, given the name'||wwv_flow.LF||
'    ------------------------';
wwv_flow_imp.g_varchar2_table(67) := '-------------------------------------------------'||wwv_flow.LF||
'    function get_preference_value ('||wwv_flow.LF||
'        p_pref';
wwv_flow_imp.g_varchar2_table(68) := 'erence_name   varchar2)'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_preference_value varchar2(255);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(69) := ' begin'||wwv_flow.LF||
'        select preference_value'||wwv_flow.LF||
'          into l_preference_value'||wwv_flow.LF||
'          from eba_sales_pr';
wwv_flow_imp.g_varchar2_table(70) := 'eferences'||wwv_flow.LF||
'         where preference_name = p_preference_name;'||wwv_flow.LF||
'        return l_preference_value;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(71) := ' exception'||wwv_flow.LF||
'        when no_data_found then'||wwv_flow.LF||
'            return ''Preference does not exist'';'||wwv_flow.LF||
'    end g';
wwv_flow_imp.g_varchar2_table(72) := 'et_preference_value;'||wwv_flow.LF||
'    -------------------------------------------------------------------------'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(73) := '   -- Set''s a preference value, given the name'||wwv_flow.LF||
'    -------------------------------------------------';
wwv_flow_imp.g_varchar2_table(74) := '------------------------'||wwv_flow.LF||
'    procedure set_preference_value ('||wwv_flow.LF||
'        p_preference_name   varchar2,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(75) := '        p_preference_value  varchar2)'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        update eba_sales_preferences'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(76) := '   set preference_value = p_preference_value'||wwv_flow.LF||
'         where preference_name  = p_preference_name;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(77) := '  end set_preference_value;'||wwv_flow.LF||
'    --------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(78) := '-----'||wwv_flow.LF||
'    -- Gets the current user''s authorization level. Depends on the following:'||wwv_flow.LF||
'    --  * If acc';
wwv_flow_imp.g_varchar2_table(79) := 'ess control is currently disabled, returns highest level of 3.'||wwv_flow.LF||
'    --  * If access control is enable';
wwv_flow_imp.g_varchar2_table(80) := 'd, but user is not in list, returns 0'||wwv_flow.LF||
'    --  * If access control is enabled and user is in list, re';
wwv_flow_imp.g_varchar2_table(81) := 'turns their'||wwv_flow.LF||
'    --    access level.'||wwv_flow.LF||
'    ------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(82) := '-------------'||wwv_flow.LF||
'    function get_authorization_level ('||wwv_flow.LF||
'        p_username             varchar2)'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(83) := '  return number'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_access_level_id       eba_sales_users.access_level_id%type := 0;  -';
wwv_flow_imp.g_varchar2_table(84) := '- default to lowest privilege.'||wwv_flow.LF||
'        l_account_locked        eba_sales_users.account_locked%type;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(85) := '    begin'||wwv_flow.LF||
'        -- If access control is disabled, default to highest privilege'||wwv_flow.LF||
'        if get_pref';
wwv_flow_imp.g_varchar2_table(86) := 'erence_value(''ACCESS_CONTROL_ENABLED'') = ''N'' then'||wwv_flow.LF||
'            return 3;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            -- ';
wwv_flow_imp.g_varchar2_table(87) := 'Query for user''s access level, throws no_data_found if no user'||wwv_flow.LF||
'            select access_level_id,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(88) := '                  account_locked'||wwv_flow.LF||
'              into l_access_level_id,'||wwv_flow.LF||
'                   l_account_';
wwv_flow_imp.g_varchar2_table(89) := 'locked'||wwv_flow.LF||
'              from eba_sales_users'||wwv_flow.LF||
'             where username = p_username;'||wwv_flow.LF||
'            -- C';
wwv_flow_imp.g_varchar2_table(90) := 'heck if user''s account is locked, return 0 (no privilege), otherwise stick'||wwv_flow.LF||
'            -- with their';
wwv_flow_imp.g_varchar2_table(91) := ' level.'||wwv_flow.LF||
'            if l_account_locked = ''Y'' then'||wwv_flow.LF||
'                return 0;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(92) := '         -- Overwrite user access level 1 with access level 2 if access control scope is PUBLIC_CONT';
wwv_flow_imp.g_varchar2_table(93) := 'RIBUTE'||wwv_flow.LF||
'            if l_access_level_id = 1 and get_preference_value(''ACCESS_CONTROL_SCOPE'') = ''PUBL';
wwv_flow_imp.g_varchar2_table(94) := 'IC_CONTRIBUTE'' then'||wwv_flow.LF||
'                return 2;'||wwv_flow.LF||
'            end if;            '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(95) := '  return l_access_level_id;'||wwv_flow.LF||
'    exception'||wwv_flow.LF||
'        when no_data_found then'||wwv_flow.LF||
'            -- If no user ';
wwv_flow_imp.g_varchar2_table(96) := 'exists with passed username, do a final check if reader access is set to any authenticated user'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(97) := '        if get_preference_value(''ACCESS_CONTROL_SCOPE'') = ''PUBLIC_CONTRIBUTE'' then'||wwv_flow.LF||
'                r';
wwv_flow_imp.g_varchar2_table(98) := 'eturn 2;'||wwv_flow.LF||
'            elsif get_preference_value(''ACCESS_CONTROL_SCOPE'') = ''PUBLIC_READONLY'' then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(99) := '             return 1;'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'                return 0;'||wwv_flow.LF||
'            end if;           '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(100) := ' end get_authorization_level;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'end eba_sales_acl_api;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(7384022553721405622)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_acl_api package body'
,p_sequence=>20
,p_script_type=>'UPGRADE'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
