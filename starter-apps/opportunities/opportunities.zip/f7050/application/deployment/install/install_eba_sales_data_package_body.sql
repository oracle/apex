prompt --application/deployment/install/install_eba_sales_data_package_body
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_data package body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE OR REPLACE PACKAGE BODY "EBA_SALES_DATA" as '||wwv_flow.LF||
'    procedure load_sales_periods is '||wwv_flow.LF||
'        y  ';
wwv_flow_imp.g_varchar2_table(2) := ' pls_integer; '||wwv_flow.LF||
'        q   pls_integer; '||wwv_flow.LF||
'        yy  pls_integer; '||wwv_flow.LF||
'        d   date; '||wwv_flow.LF||
'    begin '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(3) := '     yy := to_char(sysdate-365,''RR'');'||wwv_flow.LF||
'        d := to_date(to_char(sysdate-365,''YYYY'')||''.01.01'',''YY';
wwv_flow_imp.g_varchar2_table(4) := 'YY.MM.DD'');'||wwv_flow.LF||
' '||wwv_flow.LF||
'        for y in 1..20 loop '||wwv_flow.LF||
'            for q in 1..4 loop '||wwv_flow.LF||
'                insert in';
wwv_flow_imp.g_varchar2_table(5) := 'to eba_sales_sales_periods( period_name, first_day, last_day, fiscal_year )'||wwv_flow.LF||
'                values (';
wwv_flow_imp.g_varchar2_table(6) := ' '||wwv_flow.LF||
'                    ''Q''||q||''FY''||lpad(to_char(yy-1+y),2,''0''), '||wwv_flow.LF||
'                    add_months(d,(';
wwv_flow_imp.g_varchar2_table(7) := '12*(y-1))+ ((q-1)*3)), '||wwv_flow.LF||
'                    add_months(d,(12*(y-1))+ ((q)*3))-1, '||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(8) := '  yy+y-1'||wwv_flow.LF||
'                ); '||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        end loop;  '||wwv_flow.LF||
'    end load_sales_periods; ';
wwv_flow_imp.g_varchar2_table(9) := ''||wwv_flow.LF||
' '||wwv_flow.LF||
'    procedure load_codes is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
' '||wwv_flow.LF||
'        /* sales periods */'||wwv_flow.LF||
'        load_sales_periods;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(10) := ''||wwv_flow.LF||
'        /* currencies */'||wwv_flow.LF||
'        insert into eba_sales_currencies (id, currency_code, usd_ex_rate, ';
wwv_flow_imp.g_varchar2_table(11) := 'currency_symbol, currency_description) values (1,''USD'',1,''$'',''US Dollar'');'||wwv_flow.LF||
' '||wwv_flow.LF||
'        /* countries */';
wwv_flow_imp.g_varchar2_table(12) := ''||wwv_flow.LF||
'        insert into eba_sales_countries (id,country_code,country_name) values (1,''US'',''United State';
wwv_flow_imp.g_varchar2_table(13) := 's''); '||wwv_flow.LF||
'        insert into eba_sales_countries (id,country_code,country_name) values (2,''MEX'',''Mexico';
wwv_flow_imp.g_varchar2_table(14) := '''); '||wwv_flow.LF||
'        insert into eba_sales_countries (id,country_code,country_name) values (3,''CAN'',''Canada''';
wwv_flow_imp.g_varchar2_table(15) := '); '||wwv_flow.LF||
'        insert into eba_sales_countries (id,country_code,country_name) values (4,''UK'',''United Ki';
wwv_flow_imp.g_varchar2_table(16) := 'ngdom''); '||wwv_flow.LF||
'        insert into eba_sales_countries (id,country_code,country_name) values (5,''IN'',''Ind';
wwv_flow_imp.g_varchar2_table(17) := 'ia''); '||wwv_flow.LF||
'        insert into eba_sales_countries (id,country_code,country_name) values (6,''IE'',''Irelan';
wwv_flow_imp.g_varchar2_table(18) := 'd''); '||wwv_flow.LF||
'        insert into eba_sales_countries (id,country_code,country_name) values (7,''DE'',''Germany';
wwv_flow_imp.g_varchar2_table(19) := '''); '||wwv_flow.LF||
'        insert into eba_sales_countries (id,country_code,country_name) values (8,''ES'',''Spain'');';
wwv_flow_imp.g_varchar2_table(20) := ' '||wwv_flow.LF||
'        insert into eba_sales_countries (id,country_code,country_name) values (9,''AQ'',''Antarctica''';
wwv_flow_imp.g_varchar2_table(21) := '); '||wwv_flow.LF||
'        insert into eba_sales_countries (id,country_code,country_name) values (10,''BE'',''Beljium''';
wwv_flow_imp.g_varchar2_table(22) := '); '||wwv_flow.LF||
'        insert into eba_sales_countries (id,country_code,country_name) values (11,''BM'',''Bermuda''';
wwv_flow_imp.g_varchar2_table(23) := '); '||wwv_flow.LF||
'        insert into eba_sales_countries (id,country_code,country_name) values (12,''BR'',''Brazil'')';
wwv_flow_imp.g_varchar2_table(24) := '; '||wwv_flow.LF||
'        insert into eba_sales_countries (id,country_code,country_name) values (13,''BI'',''Brundi'');';
wwv_flow_imp.g_varchar2_table(25) := ' '||wwv_flow.LF||
'        insert into eba_sales_countries (id,country_code,country_name) values (14,''JP'',''Japan''); '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(26) := '        insert into eba_sales_countries (id,country_code,country_name) values (15,''KO'',''Korea''); '||wwv_flow.LF||
' '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(27) := '        /* states */'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Alabama'', ';
wwv_flow_imp.g_varchar2_table(28) := '''AL'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Alaska''';
wwv_flow_imp.g_varchar2_table(29) := ', ''AK'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Ameri';
wwv_flow_imp.g_varchar2_table(30) := 'can Samoa'', ''AS'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) valu';
wwv_flow_imp.g_varchar2_table(31) := 'es (''Arizona'', ''AZ'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) v';
wwv_flow_imp.g_varchar2_table(32) := 'alues (''Arkansas'', ''AR'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, countr';
wwv_flow_imp.g_varchar2_table(33) := 'y) values (''California'', ''CA'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, ';
wwv_flow_imp.g_varchar2_table(34) := 'country) values (''Colorado'', ''CO'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, co';
wwv_flow_imp.g_varchar2_table(35) := 'de, country) values (''Connecticut'', ''CT'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (st';
wwv_flow_imp.g_varchar2_table(36) := 'ate, code, country) values (''Delaware'', ''DE'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states';
wwv_flow_imp.g_varchar2_table(37) := ' (state, code, country) values (''Dist. of Columbia'', ''DC'', ''United States'');'||wwv_flow.LF||
'        insert into eba';
wwv_flow_imp.g_varchar2_table(38) := '_sales_states (state, code, country) values (''Florida'', ''FL'', ''United States'');'||wwv_flow.LF||
'        insert into ';
wwv_flow_imp.g_varchar2_table(39) := 'eba_sales_states (state, code, country) values (''Georgia'', ''GA'', ''United States'');'||wwv_flow.LF||
'        insert in';
wwv_flow_imp.g_varchar2_table(40) := 'to eba_sales_states (state, code, country) values (''Guam'', ''GU'', ''United States'');'||wwv_flow.LF||
'        insert in';
wwv_flow_imp.g_varchar2_table(41) := 'to eba_sales_states (state, code, country) values (''Hawaii'', ''HI'', ''United States'');'||wwv_flow.LF||
'        insert ';
wwv_flow_imp.g_varchar2_table(42) := 'into eba_sales_states (state, code, country) values (''Idaho'', ''ID'', ''United States'');'||wwv_flow.LF||
'        insert';
wwv_flow_imp.g_varchar2_table(43) := ' into eba_sales_states (state, code, country) values (''Illinois'', ''IL'', ''United States'');'||wwv_flow.LF||
'        in';
wwv_flow_imp.g_varchar2_table(44) := 'sert into eba_sales_states (state, code, country) values (''Indiana'', ''IN'', ''United States'');'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(45) := ' insert into eba_sales_states (state, code, country) values (''Iowa'', ''IA'', ''United States'');'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(46) := ' insert into eba_sales_states (state, code, country) values (''Kansas'', ''KS'', ''United States'');'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(47) := '   insert into eba_sales_states (state, code, country) values (''Kentucky'', ''KY'', ''United States'');'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(48) := '       insert into eba_sales_states (state, code, country) values (''Louisiana'', ''LA'', ''United States';
wwv_flow_imp.g_varchar2_table(49) := ''');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Maine'', ''ME'', ''United State';
wwv_flow_imp.g_varchar2_table(50) := 's'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Maryland'', ''MD'', ''United S';
wwv_flow_imp.g_varchar2_table(51) := 'tates'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Marshall Islands'', ''MH';
wwv_flow_imp.g_varchar2_table(52) := ''', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Massachuse';
wwv_flow_imp.g_varchar2_table(53) := 'tts'', ''MA'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''M';
wwv_flow_imp.g_varchar2_table(54) := 'ichigan'', ''MI'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values';
wwv_flow_imp.g_varchar2_table(55) := ' (''Micronesia'', ''FM'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) ';
wwv_flow_imp.g_varchar2_table(56) := 'values (''Minnesota'', ''MN'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, coun';
wwv_flow_imp.g_varchar2_table(57) := 'try) values (''Mississippi'', ''MS'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, cod';
wwv_flow_imp.g_varchar2_table(58) := 'e, country) values (''Missouri'', ''MO'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state,';
wwv_flow_imp.g_varchar2_table(59) := ' code, country) values (''Montana'', ''MT'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (sta';
wwv_flow_imp.g_varchar2_table(60) := 'te, code, country) values (''Nebraska'', ''NE'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states ';
wwv_flow_imp.g_varchar2_table(61) := '(state, code, country) values (''Nevada'', ''NV'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_state';
wwv_flow_imp.g_varchar2_table(62) := 's (state, code, country) values (''New Hampshire'', ''NH'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sa';
wwv_flow_imp.g_varchar2_table(63) := 'les_states (state, code, country) values (''New Jersey'', ''NJ'', ''United States'');'||wwv_flow.LF||
'        insert into ';
wwv_flow_imp.g_varchar2_table(64) := 'eba_sales_states (state, code, country) values (''New Mexico'', ''NM'', ''United States'');'||wwv_flow.LF||
'        insert';
wwv_flow_imp.g_varchar2_table(65) := ' into eba_sales_states (state, code, country) values (''New York'', ''NY'', ''United States'');'||wwv_flow.LF||
'        in';
wwv_flow_imp.g_varchar2_table(66) := 'sert into eba_sales_states (state, code, country) values (''North Carolina'', ''NC'', ''United States'');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(67) := '        insert into eba_sales_states (state, code, country) values (''North Dakota'', ''ND'', ''United St';
wwv_flow_imp.g_varchar2_table(68) := 'ates'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Northern Marianas'', ''MP';
wwv_flow_imp.g_varchar2_table(69) := ''', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Ohio'', ''OH';
wwv_flow_imp.g_varchar2_table(70) := ''', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Oklahoma'',';
wwv_flow_imp.g_varchar2_table(71) := ' ''OK'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Oregon';
wwv_flow_imp.g_varchar2_table(72) := ''', ''OR'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Pala';
wwv_flow_imp.g_varchar2_table(73) := 'u'', ''PW'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Pen';
wwv_flow_imp.g_varchar2_table(74) := 'nsylvania'', ''PA'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) valu';
wwv_flow_imp.g_varchar2_table(75) := 'es (''Puerto Rico'', ''PR'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, countr';
wwv_flow_imp.g_varchar2_table(76) := 'y) values (''Rhode Island'', ''RI'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code';
wwv_flow_imp.g_varchar2_table(77) := ', country) values (''South Carolina'', ''SC'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_states (s';
wwv_flow_imp.g_varchar2_table(78) := 'tate, code, country) values (''South Dakota'', ''SD'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sales_s';
wwv_flow_imp.g_varchar2_table(79) := 'tates (state, code, country) values (''Tennessee'', ''TN'', ''United States'');'||wwv_flow.LF||
'        insert into eba_sa';
wwv_flow_imp.g_varchar2_table(80) := 'les_states (state, code, country) values (''Texas'', ''TX'', ''United States'');'||wwv_flow.LF||
'        insert into eba_s';
wwv_flow_imp.g_varchar2_table(81) := 'ales_states (state, code, country) values (''Utah'', ''UT'', ''United States'');'||wwv_flow.LF||
'        insert into eba_s';
wwv_flow_imp.g_varchar2_table(82) := 'ales_states (state, code, country) values (''Vermont'', ''VT'', ''United States'');'||wwv_flow.LF||
'        insert into eb';
wwv_flow_imp.g_varchar2_table(83) := 'a_sales_states (state, code, country) values (''Virginia'', ''VA'', ''United States'');'||wwv_flow.LF||
'        insert int';
wwv_flow_imp.g_varchar2_table(84) := 'o eba_sales_states (state, code, country) values (''Virgin Islands'', ''VI'', ''United States'');'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(85) := 'insert into eba_sales_states (state, code, country) values (''Washington'', ''WA'', ''United States'');'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(86) := '      insert into eba_sales_states (state, code, country) values (''West Virginia'', ''WV'', ''United Sta';
wwv_flow_imp.g_varchar2_table(87) := 'tes'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Wisconsin'', ''WI'', ''Unite';
wwv_flow_imp.g_varchar2_table(88) := 'd States'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Wyoming'', ''WY'', ''Un';
wwv_flow_imp.g_varchar2_table(89) := 'ited States'');'||wwv_flow.LF||
' '||wwv_flow.LF||
'        update eba_sales_states set state_region = ''North East'' where code in (''CT''';
wwv_flow_imp.g_varchar2_table(90) := ',''NH'',''VT'',''MA'',''NY'',''NJ'',''PN'',''ME'',''RI'',''MD'',''DC'');'||wwv_flow.LF||
'        update eba_sales_states set state_regio';
wwv_flow_imp.g_varchar2_table(91) := 'n = ''South East'' where code in (''FL'',''GA'',''SC'',''NC'',''VA'',''TN'',''MI'',''AL'');'||wwv_flow.LF||
'        update eba_sales_s';
wwv_flow_imp.g_varchar2_table(92) := 'tates set state_region = ''Western'' where code in (''CA'',''WA'',''OR'',''NM'',''UT'',''AZ'');'||wwv_flow.LF||
' '||wwv_flow.LF||
'        insert i';
wwv_flow_imp.g_varchar2_table(93) := 'nto eba_sales_states (state, code, country) values (''Alberta'',''AB'', ''Canada'');'||wwv_flow.LF||
'        insert into e';
wwv_flow_imp.g_varchar2_table(94) := 'ba_sales_states (state, code, country) values (''British Columbia'',''BC'', ''Canada'');'||wwv_flow.LF||
'        insert in';
wwv_flow_imp.g_varchar2_table(95) := 'to eba_sales_states (state, code, country) values (''Manitoba'',''MB'', ''Canada'');'||wwv_flow.LF||
'        insert into e';
wwv_flow_imp.g_varchar2_table(96) := 'ba_sales_states (state, code, country) values (''New Brunswick'',''NB'', ''Canada'');'||wwv_flow.LF||
'        insert into ';
wwv_flow_imp.g_varchar2_table(97) := 'eba_sales_states (state, code, country) values (''Newfoundland and Labrador'',''NL'', ''Canada'');'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(98) := ' insert into eba_sales_states (state, code, country) values (''Northwest Territories'',''NT'', ''Canada'')';
wwv_flow_imp.g_varchar2_table(99) := ';'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Nova Scotia'',''NS'', ''Canada'');';
wwv_flow_imp.g_varchar2_table(100) := ''||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Nunavut'',''NU'', ''Canada'');'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(101) := '    insert into eba_sales_states (state, code, country) values (''Ontario'',''ON'', ''Canada'');'||wwv_flow.LF||
'        i';
wwv_flow_imp.g_varchar2_table(102) := 'nsert into eba_sales_states (state, code, country) values (''Prince Edward Island'',''PE'', ''Canada'');'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(103) := '       insert into eba_sales_states (state, code, country) values (''Quebec'',''QC'', ''Canada'');'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(104) := ' insert into eba_sales_states (state, code, country) values (''Saskatchewan'',''SK'', ''Canada'');'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(105) := ' insert into eba_sales_states (state, code, country) values (''Yukon'',''YT'', ''Canada'');'||wwv_flow.LF||
' '||wwv_flow.LF||
'        inse';
wwv_flow_imp.g_varchar2_table(106) := 'rt into eba_sales_states (state, code, country) values (''Aguascalientes'',''AG'', ''Mexico'');'||wwv_flow.LF||
'        in';
wwv_flow_imp.g_varchar2_table(107) := 'sert into eba_sales_states (state, code, country) values (''Baja California'',''BJ'', ''Mexico'');'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(108) := ' insert into eba_sales_states (state, code, country) values (''Baja California Sur'',''BS'', ''Mexico'');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(109) := '        insert into eba_sales_states (state, code, country) values (''Campeche'',''CP'', ''Mexico'');'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(110) := '    insert into eba_sales_states (state, code, country) values (''Chiapas'',''CH'', ''Mexico'');'||wwv_flow.LF||
'        i';
wwv_flow_imp.g_varchar2_table(111) := 'nsert into eba_sales_states (state, code, country) values (''Chihuahua'',''CI'', ''Mexico'');'||wwv_flow.LF||
'        inse';
wwv_flow_imp.g_varchar2_table(112) := 'rt into eba_sales_states (state, code, country) values (''Coahuila'',''CU'', ''Mexico'');'||wwv_flow.LF||
'        insert i';
wwv_flow_imp.g_varchar2_table(113) := 'nto eba_sales_states (state, code, country) values (''Colima'',''CL'', ''Mexico'');'||wwv_flow.LF||
'        insert into eb';
wwv_flow_imp.g_varchar2_table(114) := 'a_sales_states (state, code, country) values (''Distrito Federal'',''DF'', ''Mexico'');'||wwv_flow.LF||
'        insert int';
wwv_flow_imp.g_varchar2_table(115) := 'o eba_sales_states (state, code, country) values (''MS Durango'',''DG'', ''Mexico'');'||wwv_flow.LF||
'        insert into ';
wwv_flow_imp.g_varchar2_table(116) := 'eba_sales_states (state, code, country) values (''Guanajuato'',''GJ'', ''Mexico'');'||wwv_flow.LF||
'        insert into eb';
wwv_flow_imp.g_varchar2_table(117) := 'a_sales_states (state, code, country) values (''Guerrero'',''GR'', ''Mexico'');'||wwv_flow.LF||
'        insert into eba_sa';
wwv_flow_imp.g_varchar2_table(118) := 'les_states (state, code, country) values (''Hidalgo'',''HG'', ''Mexico'');'||wwv_flow.LF||
'        insert into eba_sales_s';
wwv_flow_imp.g_varchar2_table(119) := 'tates (state, code, country) values (''Jalisco'',''JA'', ''Mexico'');'||wwv_flow.LF||
'        insert into eba_sales_states';
wwv_flow_imp.g_varchar2_table(120) := ' (state, code, country) values (''Mexico'',''EM'', ''Mexico'');'||wwv_flow.LF||
'        insert into eba_sales_states (stat';
wwv_flow_imp.g_varchar2_table(121) := 'e, code, country) values (''Michoacan'',''MH'', ''Mexico'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, ';
wwv_flow_imp.g_varchar2_table(122) := 'code, country) values (''Morelos'',''MR'', ''Mexico'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code,';
wwv_flow_imp.g_varchar2_table(123) := ' country) values (''Nayarit'',''NA'', ''Mexico'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, coun';
wwv_flow_imp.g_varchar2_table(124) := 'try) values (''Nuevo Leon'',''NL'', ''Mexico'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, countr';
wwv_flow_imp.g_varchar2_table(125) := 'y) values (''Oaxaca'',''OA'', ''Mexico'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) val';
wwv_flow_imp.g_varchar2_table(126) := 'ues (''Puebla'',''PU'', ''Mexico'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''';
wwv_flow_imp.g_varchar2_table(127) := 'Queretaro'',''QA'', ''Mexico'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Qui';
wwv_flow_imp.g_varchar2_table(128) := 'ntana Roo'',''QR'', ''Mexico'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Pot';
wwv_flow_imp.g_varchar2_table(129) := 'osi'',''SL'', ''Mexico'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Sinaloa'',';
wwv_flow_imp.g_varchar2_table(130) := '''SI'', ''Mexico'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Sonora'',''SO'', ';
wwv_flow_imp.g_varchar2_table(131) := '''Mexico'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Tabasco'',''TA'', ''Mexi';
wwv_flow_imp.g_varchar2_table(132) := 'co'');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Tamaulipas'',''TM'', ''Mexico';
wwv_flow_imp.g_varchar2_table(133) := ''');'||wwv_flow.LF||
'        insert into eba_sales_states (state, code, country) values (''Tlaxcala'',''TL'', ''Mexico'');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(134) := '        insert into eba_sales_states (state, code, country) values (''V eracruz'',''VZ'', ''Mexico'');'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(135) := '     insert into eba_sales_states (state, code, country) values (''Yucatan'',''YC'', ''Mexico'');'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(136) := 'insert into eba_sales_states (state, code, country) values (''Zacatecas'',''ZT'', ''Mexico'');'||wwv_flow.LF||
' '||wwv_flow.LF||
'        /';
wwv_flow_imp.g_varchar2_table(137) := '* deal status codes */'||wwv_flow.LF||
'        insert into eba_sales_deal_status_codes (id,display_order,status_code';
wwv_flow_imp.g_varchar2_table(138) := ',corresponding_prob_pct,code_description) values (1,1,''Product Presentation Performed'',20,''At least ';
wwv_flow_imp.g_varchar2_table(139) := 'one product presentation was performed''); '||wwv_flow.LF||
'        insert into eba_sales_deal_status_codes (id,displ';
wwv_flow_imp.g_varchar2_table(140) := 'ay_order,status_code,corresponding_prob_pct,code_description) values (2,2,''Customer Identified'',10,''';
wwv_flow_imp.g_varchar2_table(141) := 'A legitimate prospect has been identified, you have a contact''); '||wwv_flow.LF||
'        insert into eba_sales_deal';
wwv_flow_imp.g_varchar2_table(142) := '_status_codes (id,display_order,status_code,corresponding_prob_pct,code_description) values (3,3,''Pr';
wwv_flow_imp.g_varchar2_table(143) := 'oducts Identified'',30,''Customer has selected the products they are intersted in''); '||wwv_flow.LF||
'        insert i';
wwv_flow_imp.g_varchar2_table(144) := 'nto eba_sales_deal_status_codes (id,display_order,status_code,corresponding_prob_pct,code_descriptio';
wwv_flow_imp.g_varchar2_table(145) := 'n) values (4,4,''Opportunity Closed / Lost'',0,''No customer interest at this point in time''); '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(146) := ' insert into eba_sales_deal_status_codes (id,display_order,status_code,corresponding_prob_pct,code_d';
wwv_flow_imp.g_varchar2_table(147) := 'escription) values (5,5,''Payment Method Identified'',40,''A contracting vehicle or some payment method';
wwv_flow_imp.g_varchar2_table(148) := ' has been idenfieid''); '||wwv_flow.LF||
'        insert into eba_sales_deal_status_codes (id,display_order,status_cod';
wwv_flow_imp.g_varchar2_table(149) := 'e,corresponding_prob_pct,code_description) values (6,6,''Price Proposal Made'',50,''Customer has been g';
wwv_flow_imp.g_varchar2_table(150) := 'iven a price''); '||wwv_flow.LF||
'        insert into eba_sales_deal_status_codes (id,display_order,status_code,corre';
wwv_flow_imp.g_varchar2_table(151) := 'sponding_prob_pct,code_description) values (7,7,''Customer Informally Agrees to Buy'',60,''Customer has';
wwv_flow_imp.g_varchar2_table(152) := ' informally agreed to the price''); '||wwv_flow.LF||
'        insert into eba_sales_deal_status_codes (id,display_orde';
wwv_flow_imp.g_varchar2_table(153) := 'r,status_code,corresponding_prob_pct,code_description) values (8,8,''Customer Presented Terms'',70,''Cu';
wwv_flow_imp.g_varchar2_table(154) := 'stomer has been presented Terms and Conditions''); '||wwv_flow.LF||
'        insert into eba_sales_deal_status_codes (';
wwv_flow_imp.g_varchar2_table(155) := 'id,display_order,status_code,corresponding_prob_pct,code_description) values (9,9,''Legal Approval of';
wwv_flow_imp.g_varchar2_table(156) := ' Contract'',80,''Legal Departments Approve Contract''); '||wwv_flow.LF||
'        insert into eba_sales_deal_status_code';
wwv_flow_imp.g_varchar2_table(157) := 's (id,display_order,status_code,corresponding_prob_pct,code_description) values (10,10,''Customer Sig';
wwv_flow_imp.g_varchar2_table(158) := 'ns Contract'',90,''Customer Signs Contract''); '||wwv_flow.LF||
'        insert into eba_sales_deal_status_codes (id,dis';
wwv_flow_imp.g_varchar2_table(159) := 'play_order,status_code,corresponding_prob_pct,code_description) values (11,11,''Payment Received'',100';
wwv_flow_imp.g_varchar2_table(160) := ',''Payment Received''); '||wwv_flow.LF||
' '||wwv_flow.LF||
'        /* salesrep roles */'||wwv_flow.LF||
'        insert into eba_sales_salesrep_roles (';
wwv_flow_imp.g_varchar2_table(161) := 'id,role_name,is_sales_rep) values (1,''Sales Representative'',''Y''); '||wwv_flow.LF||
'        insert into eba_sales_sal';
wwv_flow_imp.g_varchar2_table(162) := 'esrep_roles (id,role_name,is_sales_rep) values (2,''Sales Consultant'',''N''); '||wwv_flow.LF||
'        insert into eba_';
wwv_flow_imp.g_varchar2_table(163) := 'sales_salesrep_roles (id,role_name,is_sales_rep) values (3,''Legal'',''N''); '||wwv_flow.LF||
'        insert into eba_sa';
wwv_flow_imp.g_varchar2_table(164) := 'les_salesrep_roles (id,role_name,is_sales_rep) values (4,''Business Development'',''N''); '||wwv_flow.LF||
'        inser';
wwv_flow_imp.g_varchar2_table(165) := 't into eba_sales_salesrep_roles (id,role_name,is_sales_rep) values (5,''Consulting Services Sales'',''N';
wwv_flow_imp.g_varchar2_table(166) := '''); '||wwv_flow.LF||
'        insert into eba_sales_salesrep_roles (id,role_name,is_sales_rep) values (6,''Education S';
wwv_flow_imp.g_varchar2_table(167) := 'ervices Sales'',''N''); '||wwv_flow.LF||
'        insert into eba_sales_salesrep_roles (id,role_name,is_sales_rep) value';
wwv_flow_imp.g_varchar2_table(168) := 's (7,''Tele-Sales'',''Y''); '||wwv_flow.LF||
'        insert into eba_sales_salesrep_roles (id,role_name,is_sales_rep) va';
wwv_flow_imp.g_varchar2_table(169) := 'lues (8,''Support'',''N''); '||wwv_flow.LF||
'        insert into eba_sales_salesrep_roles (id,role_name,is_sales_rep) va';
wwv_flow_imp.g_varchar2_table(170) := 'lues (9,''Evangelist'',''N''); '||wwv_flow.LF||
'        insert into eba_sales_salesrep_roles (id,role_name,is_sales_rep)';
wwv_flow_imp.g_varchar2_table(171) := ' values (10,''Sales Manager'',''Y''); '||wwv_flow.LF||
' '||wwv_flow.LF||
'        /* lead status codes */'||wwv_flow.LF||
'        insert into eba_sales_l';
wwv_flow_imp.g_varchar2_table(172) := 'ead_status_codes (id,display_order,status_code) values (1,4,''Dead''); '||wwv_flow.LF||
'        insert into eba_sales_';
wwv_flow_imp.g_varchar2_table(173) := 'lead_status_codes (id,display_order,status_code) values (2,3,''Hot''); '||wwv_flow.LF||
'        insert into eba_sales_';
wwv_flow_imp.g_varchar2_table(174) := 'lead_status_codes (id,display_order,status_code) values (3,2,''Qualified''); '||wwv_flow.LF||
'        insert into eba_';
wwv_flow_imp.g_varchar2_table(175) := 'sales_lead_status_codes (id,display_order,status_code) values (4,1,''Unqualified''); '||wwv_flow.LF||
'        insert i';
wwv_flow_imp.g_varchar2_table(176) := 'nto eba_sales_lead_status_codes (id,display_order,status_code) values (5,5,''Converted to Opportunity';
wwv_flow_imp.g_varchar2_table(177) := '''); '||wwv_flow.LF||
' '||wwv_flow.LF||
'        /* lead sources */'||wwv_flow.LF||
'        insert into eba_sales_lead_sources (id,lead_source) values';
wwv_flow_imp.g_varchar2_table(178) := ' (1,''Internet''); '||wwv_flow.LF||
'        insert into eba_sales_lead_sources (id,lead_source) values (2,''Direct Mail';
wwv_flow_imp.g_varchar2_table(179) := '''); '||wwv_flow.LF||
'        insert into eba_sales_lead_sources (id,lead_source) values (3,''Email''); '||wwv_flow.LF||
'        insert';
wwv_flow_imp.g_varchar2_table(180) := ' into eba_sales_lead_sources (id,lead_source) values (4,''Unknown''); '||wwv_flow.LF||
' '||wwv_flow.LF||
'        /* competitor threats';
wwv_flow_imp.g_varchar2_table(181) := ' */'||wwv_flow.LF||
'        insert into eba_sales_competitor_threats (id,display_order, competitor_threat) values (1';
wwv_flow_imp.g_varchar2_table(182) := ',1, ''Perceived Front Runner'');'||wwv_flow.LF||
'        insert into eba_sales_competitor_threats (id,display_order, c';
wwv_flow_imp.g_varchar2_table(183) := 'ompetitor_threat) values (2,2, ''Strong and worthy advisory'');'||wwv_flow.LF||
'        insert into eba_sales_competit';
wwv_flow_imp.g_varchar2_table(184) := 'or_threats (id,display_order, competitor_threat) values (3,3, ''Moderate threat'');'||wwv_flow.LF||
'        insert int';
wwv_flow_imp.g_varchar2_table(185) := 'o eba_sales_competitor_threats (id,display_order, competitor_threat) values (4,4, ''Low threat level''';
wwv_flow_imp.g_varchar2_table(186) := ');'||wwv_flow.LF||
'        insert into eba_sales_competitor_threats (id,display_order, competitor_threat) values (5,';
wwv_flow_imp.g_varchar2_table(187) := '5, ''Not a threat at this time'');'||wwv_flow.LF||
' '||wwv_flow.LF||
'        /* competitors */'||wwv_flow.LF||
'        insert into eba_sales_competito';
wwv_flow_imp.g_varchar2_table(188) := 'rs (id,competitor_name) values (1,''Competitor A'');'||wwv_flow.LF||
'        insert into eba_sales_competitors (id,com';
wwv_flow_imp.g_varchar2_table(189) := 'petitor_name) values (2,''Competitor B'');'||wwv_flow.LF||
'        insert into eba_sales_competitors (id,competitor_na';
wwv_flow_imp.g_varchar2_table(190) := 'me) values (3,''Competitor C'');'||wwv_flow.LF||
'        insert into eba_sales_competitors (id,competitor_name) values';
wwv_flow_imp.g_varchar2_table(191) := ' (4,''Competitor D'');'||wwv_flow.LF||
'        insert into eba_sales_competitors (id,competitor_name) values (5,''Compe';
wwv_flow_imp.g_varchar2_table(192) := 'titor E'');'||wwv_flow.LF||
'        insert into eba_sales_competitors (id,competitor_name) values (6,''Competitor F'');';
wwv_flow_imp.g_varchar2_table(193) := ''||wwv_flow.LF||
'        insert into eba_sales_competitors (id,competitor_name) values (7,''Competitor G'');'||wwv_flow.LF||
' '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(194) := ' /* financial assessments */'||wwv_flow.LF||
'        insert into eba_sales_fin_assessments (display_order, assessmen';
wwv_flow_imp.g_varchar2_table(195) := 't_text) values (1, ''No Dollars at Stake, Customer Education'');'||wwv_flow.LF||
'        insert into eba_sales_fin_ass';
wwv_flow_imp.g_varchar2_table(196) := 'essments (display_order, assessment_text) values (2, ''No Dollars at Stake, Defending Existing Produc';
wwv_flow_imp.g_varchar2_table(197) := 'ts'');'||wwv_flow.LF||
'        insert into eba_sales_fin_assessments (display_order, assessment_text) values (3, ''New';
wwv_flow_imp.g_varchar2_table(198) := ' Dollars, Green Field Opportunity'');'||wwv_flow.LF||
'        insert into eba_sales_fin_assessments (display_order, a';
wwv_flow_imp.g_varchar2_table(199) := 'ssessment_text) values (4, ''New Dollars, Replacement Opportunity'');'||wwv_flow.LF||
' '||wwv_flow.LF||
'        /* status assessments ';
wwv_flow_imp.g_varchar2_table(200) := '*/'||wwv_flow.LF||
'        insert into eba_sales_status_assessments (id,display_order, assessment_text) values (1,1,';
wwv_flow_imp.g_varchar2_table(201) := ' ''In Process - Looking Bad'');'||wwv_flow.LF||
'        insert into eba_sales_status_assessments (id,display_order, as';
wwv_flow_imp.g_varchar2_table(202) := 'sessment_text) values (2,2, ''In Process - Looking Good'');'||wwv_flow.LF||
'        insert into eba_sales_status_asses';
wwv_flow_imp.g_varchar2_table(203) := 'sments (id,display_order, assessment_text) values (3,3, ''In Process - Looking Neutral'');'||wwv_flow.LF||
'        ins';
wwv_flow_imp.g_varchar2_table(204) := 'ert into eba_sales_status_assessments (id,display_order, assessment_text) values (4,4, ''Lost - Decla';
wwv_flow_imp.g_varchar2_table(205) := 'red moving to competitor'');'||wwv_flow.LF||
'        insert into eba_sales_status_assessments (id,display_order, asse';
wwv_flow_imp.g_varchar2_table(206) := 'ssment_text) values (5,5, ''Lost - Staying with current vendor'');'||wwv_flow.LF||
'        insert into eba_sales_statu';
wwv_flow_imp.g_varchar2_table(207) := 's_assessments (id,display_order, assessment_text) values (6,6, ''Staying with our product - Never a T';
wwv_flow_imp.g_varchar2_table(208) := 'hreat'');'||wwv_flow.LF||
'        insert into eba_sales_status_assessments (id,display_order, assessment_text) values';
wwv_flow_imp.g_varchar2_table(209) := ' (7,7, ''Successful Defend Ongoing'');'||wwv_flow.LF||
' '||wwv_flow.LF||
'        /* risk assessments */'||wwv_flow.LF||
'        insert into eba_sales_';
wwv_flow_imp.g_varchar2_table(210) := 'risk_assessments (display_order, assessment_text) values (1, ''High'');'||wwv_flow.LF||
'        insert into eba_sales_';
wwv_flow_imp.g_varchar2_table(211) := 'risk_assessments (display_order, assessment_text) values (2, ''Moderate'');'||wwv_flow.LF||
'        insert into eba_sa';
wwv_flow_imp.g_varchar2_table(212) := 'les_risk_assessments (display_order, assessment_text) values (3, ''Low'');'||wwv_flow.LF||
'        insert into eba_sal';
wwv_flow_imp.g_varchar2_table(213) := 'es_risk_assessments (display_order, assessment_text) values (4, ''Undetermined'');'||wwv_flow.LF||
'        insert into';
wwv_flow_imp.g_varchar2_table(214) := ' eba_sales_risk_assessments (display_order, assessment_text) values (5, ''No known risk'');'||wwv_flow.LF||
' '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(215) := '/* standings */'||wwv_flow.LF||
'        insert into eba_sales_account_standing (display_order, standing_text) values';
wwv_flow_imp.g_varchar2_table(216) := ' (1, ''Exclusive to us'');'||wwv_flow.LF||
'        insert into eba_sales_account_standing (display_order, standing_tex';
wwv_flow_imp.g_varchar2_table(217) := 't) values (2, ''Mostly Us'');'||wwv_flow.LF||
'        insert into eba_sales_account_standing (display_order, standing_';
wwv_flow_imp.g_varchar2_table(218) := 'text) values (3, ''Mixed'');'||wwv_flow.LF||
'        insert into eba_sales_account_standing (display_order, standing_t';
wwv_flow_imp.g_varchar2_table(219) := 'ext) values (4, ''Primarily competitors'');'||wwv_flow.LF||
'        insert into eba_sales_account_standing (display_or';
wwv_flow_imp.g_varchar2_table(220) := 'der, standing_text) values (5, ''No account presence'');'||wwv_flow.LF||
' '||wwv_flow.LF||
'        /* industries */'||wwv_flow.LF||
'        insert int';
wwv_flow_imp.g_varchar2_table(221) := 'o eba_sales_industries (id, industry_name) values (1, ''Financial Services'');'||wwv_flow.LF||
'        insert into eba';
wwv_flow_imp.g_varchar2_table(222) := '_sales_industries (id, industry_name) values (2, ''Aerospace'');'||wwv_flow.LF||
'        insert into eba_sales_industr';
wwv_flow_imp.g_varchar2_table(223) := 'ies (id, industry_name) values (3, ''Military'');'||wwv_flow.LF||
'        insert into eba_sales_industries (id, indust';
wwv_flow_imp.g_varchar2_table(224) := 'ry_name) values (4, ''Telco'');'||wwv_flow.LF||
'        insert into eba_sales_industries (id, industry_name) values (5';
wwv_flow_imp.g_varchar2_table(225) := ', ''Power'');'||wwv_flow.LF||
'        insert into eba_sales_industries (id, industry_name) values (6, ''Retail'');'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(226) := '   commit;'||wwv_flow.LF||
' '||wwv_flow.LF||
'        /* app access levels */'||wwv_flow.LF||
'        insert into eba_sales_access_levels (id, access';
wwv_flow_imp.g_varchar2_table(227) := '_level) values (-99, ''No Access'');'||wwv_flow.LF||
'        insert into eba_sales_access_levels (id, access_level) va';
wwv_flow_imp.g_varchar2_table(228) := 'lues (0, ''Approval Pending'');'||wwv_flow.LF||
'        insert into eba_sales_access_levels (id, access_level) values ';
wwv_flow_imp.g_varchar2_table(229) := '(1, ''Reader'');'||wwv_flow.LF||
'        insert into eba_sales_access_levels (id, access_level) values (2, ''Contributo';
wwv_flow_imp.g_varchar2_table(230) := 'r'');'||wwv_flow.LF||
'        insert into eba_sales_access_levels (id, access_level) values (3, ''Administrator'');'||wwv_flow.LF||
' '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(231) := '       /* app preferences */'||wwv_flow.LF||
'        insert into eba_sales_preferences (id, preference_name, prefere';
wwv_flow_imp.g_varchar2_table(232) := 'nce_value) values (1, ''ACCESS_CONTROL_ENABLED'', ''N'');'||wwv_flow.LF||
'        insert into eba_sales_preferences (id,';
wwv_flow_imp.g_varchar2_table(233) := ' preference_name, preference_value) values (2, ''ACCESS_CONTROL_SCOPE'', ''ACL_ONLY'');'||wwv_flow.LF||
'        insert i';
wwv_flow_imp.g_varchar2_table(234) := 'nto eba_sales_preferences (id, preference_name, preference_value) values (3, ''USERNAME_FORMAT'', ''EMA';
wwv_flow_imp.g_varchar2_table(235) := 'IL'');'||wwv_flow.LF||
' '||wwv_flow.LF||
'        /* Constraint error lookups */'||wwv_flow.LF||
'        insert into eba_sales_error_lookup (constrain';
wwv_flow_imp.g_varchar2_table(236) := 't_name, message, language_code) values (''EBA_SALES_USERS_UK'', ''Username must be unique.'', ''en'');'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(237) := '     insert into eba_sales_error_lookup (constraint_name, message, language_code) values (''EBA_SALES';
wwv_flow_imp.g_varchar2_table(238) := '_CUST_TERR_FK'',''There are Accounts associated with this territory'',''en'');'||wwv_flow.LF||
' '||wwv_flow.LF||
'       /* product family';
wwv_flow_imp.g_varchar2_table(239) := ' lookups */'||wwv_flow.LF||
'       insert into eba_sales_product_families (id, product_family, description) values (';
wwv_flow_imp.g_varchar2_table(240) := '1, ''NAA'',''North America Applications (App Sales)'');'||wwv_flow.LF||
'       insert into eba_sales_product_families (i';
wwv_flow_imp.g_varchar2_table(241) := 'd, product_family, description) values (2, ''NAS'',''North America Sales (Tech & Hardware Sales)'');'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(242) := '    insert into eba_sales_product_families (id, product_family, description) values (3, ''GBU'',''Globa';
wwv_flow_imp.g_varchar2_table(243) := 'l Business Unit'');'||wwv_flow.LF||
''||wwv_flow.LF||
'       /* product LOBs lookups */'||wwv_flow.LF||
'       insert into eba_sales_product_lobs (id,';
wwv_flow_imp.g_varchar2_table(244) := ' name, description) values (1, ''NAA'',''North America Applications (App Sales)'');'||wwv_flow.LF||
'       insert into e';
wwv_flow_imp.g_varchar2_table(245) := 'ba_sales_product_lobs (id, name, description) values (2, ''NAS'',''North America Sales (Tech & Hardware';
wwv_flow_imp.g_varchar2_table(246) := ' Sales)'');'||wwv_flow.LF||
'       insert into eba_sales_product_lobs (id, name, description) values (3, ''GBU'',''Globa';
wwv_flow_imp.g_varchar2_table(247) := 'l Business Unit'');'||wwv_flow.LF||
'       insert into eba_sales_product_lobs (id, name, description) values (4, ''OTH';
wwv_flow_imp.g_varchar2_table(248) := 'ER'',''Other Business Units'');'||wwv_flow.LF||
''||wwv_flow.LF||
'       /* Agreement Types */'||wwv_flow.LF||
'       insert into EBA_SALES_AGREEMENT_TY';
wwv_flow_imp.g_varchar2_table(249) := 'PES (name, description) values (''ELA'',''End-User License Agreement'');'||wwv_flow.LF||
'       insert into EBA_SALES_AG';
wwv_flow_imp.g_varchar2_table(250) := 'REEMENT_TYPES (name, description) values (''ULA'',''Universal License Agreement'');'||wwv_flow.LF||
' '||wwv_flow.LF||
'    end load_codes';
wwv_flow_imp.g_varchar2_table(251) := '; '||wwv_flow.LF||
' '||wwv_flow.LF||
'    procedure load_sample is '||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        Insert into EBA_SALES_TERRITORIES (ID,TERRITORY';
wwv_flow_imp.g_varchar2_table(252) := '_NAME, TERRITORY_DESCRIPTION) values (1,''US Commercial East'', ''United States Commercial''); '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(253) := 'Insert into EBA_SALES_TERRITORIES (ID,TERRITORY_NAME, TERRITORY_DESCRIPTION) values (2,''US Fed'', ''Un';
wwv_flow_imp.g_varchar2_table(254) := 'ited States Federal Government''); '||wwv_flow.LF||
'        Insert into EBA_SALES_TERRITORIES (ID,TERRITORY_NAME, TER';
wwv_flow_imp.g_varchar2_table(255) := 'RITORY_DESCRIPTION) values (3,''US Commercial West'',''United States Commercial West''); '||wwv_flow.LF||
'        Insert';
wwv_flow_imp.g_varchar2_table(256) := ' into EBA_SALES_TERRITORIES (ID,TERRITORY_NAME, TERRITORY_DESCRIPTION) values (4,''US VAR'',''United St';
wwv_flow_imp.g_varchar2_table(257) := 'ates Value Added Resellers''); '||wwv_flow.LF||
'        Insert into EBA_SALES_TERRITORIES (ID,TERRITORY_NAME, TERRITO';
wwv_flow_imp.g_varchar2_table(258) := 'RY_DESCRIPTION) values (5,''EMEA Commercial'',''Europe Middle East and Africa Commercial''); '||wwv_flow.LF||
'        In';
wwv_flow_imp.g_varchar2_table(259) := 'sert into EBA_SALES_TERRITORIES (ID,TERRITORY_NAME, TERRITORY_DESCRIPTION) values (6,''EMEA Govt'',''Eu';
wwv_flow_imp.g_varchar2_table(260) := 'rope Middle East and Africa Government''); '||wwv_flow.LF||
'        Insert into EBA_SALES_TERRITORIES (ID,TERRITORY_N';
wwv_flow_imp.g_varchar2_table(261) := 'AME, TERRITORY_DESCRIPTION) values (7,''LA Commercial'',''Latin America Commercial''); '||wwv_flow.LF||
'        Insert i';
wwv_flow_imp.g_varchar2_table(262) := 'nto EBA_SALES_TERRITORIES (ID,TERRITORY_NAME, TERRITORY_DESCRIPTION) values (8,''LA Government'',''Lati';
wwv_flow_imp.g_varchar2_table(263) := 'n America Government''); '||wwv_flow.LF||
'        Insert into EBA_SALES_TERRITORIES (ID,TERRITORY_NAME, TERRITORY_DES';
wwv_flow_imp.g_varchar2_table(264) := 'CRIPTION) values (9,''APAC Commercial'',''Asia Pacific Commerical''); '||wwv_flow.LF||
'        Insert into EBA_SALES_TER';
wwv_flow_imp.g_varchar2_table(265) := 'RITORIES (ID,TERRITORY_NAME, TERRITORY_DESCRIPTION) values (10,''APAC Govt'',''Asia Pacific Government''';
wwv_flow_imp.g_varchar2_table(266) := '); '||wwv_flow.LF||
'        Insert into EBA_SALES_TERRITORIES (ID,TERRITORY_NAME, TERRITORY_DESCRIPTION) values (11,';
wwv_flow_imp.g_varchar2_table(267) := '''Mexico'',''Mexico Sales''); '||wwv_flow.LF||
'        Insert into EBA_SALES_TERRITORIES (ID,TERRITORY_NAME, TERRITORY_D';
wwv_flow_imp.g_varchar2_table(268) := 'ESCRIPTION) values (12,''Canada'',''Candada Sales''); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into eba_sales_customers';
wwv_flow_imp.g_varchar2_table(269) := ' (id, customer_name, customer_territory_id, customer_is_key_account_yn) values (1,''Lexington Exports';
wwv_flow_imp.g_varchar2_table(270) := ''',3,''Y''); '||wwv_flow.LF||
'        insert into eba_sales_customers (id, customer_name, customer_territory_id, custom';
wwv_flow_imp.g_varchar2_table(271) := 'er_is_key_account_yn) values (2,''Madison Materials'',1,''N''); '||wwv_flow.LF||
'        insert into eba_sales_customers';
wwv_flow_imp.g_varchar2_table(272) := ' (id, customer_name, customer_territory_id, customer_is_key_account_yn) values (3,''Connecticut Compo';
wwv_flow_imp.g_varchar2_table(273) := 'sites'',1,''Y''); '||wwv_flow.LF||
'        insert into eba_sales_customers (id, customer_name, customer_territory_id, c';
wwv_flow_imp.g_varchar2_table(274) := 'ustomer_is_key_account_yn) values (4,''Department of Labor'',2,''N''); '||wwv_flow.LF||
'        insert into eba_sales_cu';
wwv_flow_imp.g_varchar2_table(275) := 'stomers (id, customer_name, customer_territory_id, customer_is_key_account_yn) values (5,''Asymmetric';
wwv_flow_imp.g_varchar2_table(276) := 'al Antibiotics Inc'',3,''N''); '||wwv_flow.LF||
'        insert into eba_sales_customers (id, customer_name, customer_te';
wwv_flow_imp.g_varchar2_table(277) := 'rritory_id, customer_is_key_account_yn) values (6,''Seminal Semiconductor'',3,''Y''); '||wwv_flow.LF||
'        insert in';
wwv_flow_imp.g_varchar2_table(278) := 'to eba_sales_customers (id, customer_name, customer_territory_id, customer_is_key_account_yn) values';
wwv_flow_imp.g_varchar2_table(279) := ' (7,''Aeronautical and Space Agency'',2,''N''); '||wwv_flow.LF||
'        insert into eba_sales_customers (id, customer_n';
wwv_flow_imp.g_varchar2_table(280) := 'ame, customer_territory_id, customer_is_key_account_yn) values (8,''Army'',12,''N''); '||wwv_flow.LF||
'        insert in';
wwv_flow_imp.g_varchar2_table(281) := 'to eba_sales_customers (id, customer_name, customer_territory_id, customer_is_key_account_yn) values';
wwv_flow_imp.g_varchar2_table(282) := ' (9,''Department of Energy'',10,''N''); '||wwv_flow.LF||
'        insert into eba_sales_customers (id, customer_name, cus';
wwv_flow_imp.g_varchar2_table(283) := 'tomer_territory_id, customer_is_key_account_yn) values (10,''Department of the Interior'',2,''N''); '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(284) := '     insert into eba_sales_customers (id, customer_name, customer_territory_id, customer_is_key_acco';
wwv_flow_imp.g_varchar2_table(285) := 'unt_yn) values (11,''Integration Magic'',4,''N''); '||wwv_flow.LF||
'        insert into eba_sales_customers (id, custome';
wwv_flow_imp.g_varchar2_table(286) := 'r_name, customer_territory_id, customer_is_key_account_yn) values (12,''Acme Department of State'',1,''';
wwv_flow_imp.g_varchar2_table(287) := 'N''); '||wwv_flow.LF||
'        insert into eba_sales_customers (id, customer_name, customer_territory_id, customer_is';
wwv_flow_imp.g_varchar2_table(288) := '_key_account_yn) values (13,''Department of State'',2,''Y''); '||wwv_flow.LF||
'        insert into eba_sales_customers (';
wwv_flow_imp.g_varchar2_table(289) := 'id, customer_name, customer_territory_id, customer_is_key_account_yn) values (14,''Acme Department of';
wwv_flow_imp.g_varchar2_table(290) := ' Corrections'',1,''N''); '||wwv_flow.LF||
'        insert into eba_sales_customers (id, customer_name, customer_territor';
wwv_flow_imp.g_varchar2_table(291) := 'y_id, customer_is_key_account_yn) values (15,''Department of Natural Resources'',8,''N''); '||wwv_flow.LF||
'        inse';
wwv_flow_imp.g_varchar2_table(292) := 'rt into eba_sales_customers (id, customer_name, customer_territory_id, customer_is_key_account_yn) v';
wwv_flow_imp.g_varchar2_table(293) := 'alues (16,''State Department of Education'',3,''N''); '||wwv_flow.LF||
'        insert into eba_sales_customers (id, cust';
wwv_flow_imp.g_varchar2_table(294) := 'omer_name, customer_territory_id, customer_is_key_account_yn) values (17,''Acme Department of Transpo';
wwv_flow_imp.g_varchar2_table(295) := 'rtation'',1,''N''); '||wwv_flow.LF||
'        insert into eba_sales_customers (id, customer_name, customer_territory_id,';
wwv_flow_imp.g_varchar2_table(296) := ' customer_is_key_account_yn) values (18,''State Department of Revenue'',1,''N''); '||wwv_flow.LF||
'        insert into e';
wwv_flow_imp.g_varchar2_table(297) := 'ba_sales_customers (id, customer_name, customer_territory_id, customer_is_key_account_yn) values (19';
wwv_flow_imp.g_varchar2_table(298) := ',''Acme Department of Taxation'',6,''N''); '||wwv_flow.LF||
'        insert into eba_sales_customers (id, customer_name, ';
wwv_flow_imp.g_varchar2_table(299) := 'customer_territory_id, customer_is_key_account_yn) values (20,''Turbo Charged Migration Systems'',3,''N';
wwv_flow_imp.g_varchar2_table(300) := '''); '||wwv_flow.LF||
'        insert into eba_sales_customers (id, customer_name, customer_territory_id, customer_is_';
wwv_flow_imp.g_varchar2_table(301) := 'key_account_yn) values (21,''Malta Bold Design Studios Inc'',3,''N''); '||wwv_flow.LF||
'        insert into eba_sales_cu';
wwv_flow_imp.g_varchar2_table(302) := 'stomers (id, customer_name, customer_territory_id, customer_is_key_account_yn) values (22,''Understat';
wwv_flow_imp.g_varchar2_table(303) := 'ed Web Design of Boston'',3,''N''); '||wwv_flow.LF||
'        insert into eba_sales_customers (id, customer_name, custom';
wwv_flow_imp.g_varchar2_table(304) := 'er_territory_id, customer_is_key_account_yn) values (23,''Research and Development Council'',6,''N''); '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(305) := '        insert into eba_sales_customers (id, customer_name, customer_territory_id, customer_is_key_a';
wwv_flow_imp.g_varchar2_table(306) := 'ccount_yn) values (24,''Employment and Social Affairs'',6,''N''); '||wwv_flow.LF||
'        insert into eba_sales_custome';
wwv_flow_imp.g_varchar2_table(307) := 'rs (id, customer_name, customer_territory_id, customer_is_key_account_yn) values (25,''South East Asi';
wwv_flow_imp.g_varchar2_table(308) := 'an Economic and Development Labs'',10,''N''); '||wwv_flow.LF||
'        insert into eba_sales_customers (id, customer_na';
wwv_flow_imp.g_varchar2_table(309) := 'me, customer_territory_id, customer_is_key_account_yn) values (26,''Mt Fuji Research Systems'',9,''N'');';
wwv_flow_imp.g_varchar2_table(310) := ' '||wwv_flow.LF||
'        insert into eba_sales_customers (id, customer_name, customer_territory_id, customer_is_key';
wwv_flow_imp.g_varchar2_table(311) := '_account_yn) values (27,''National Department of Beach Preservation'',8,''N''); '||wwv_flow.LF||
'        insert into eba';
wwv_flow_imp.g_varchar2_table(312) := '_sales_customers (id, customer_name, customer_territory_id, customer_is_key_account_yn) values (28,''';
wwv_flow_imp.g_varchar2_table(313) := 'Swiss Mountain Java Solutions'',5,''Y''); '||wwv_flow.LF||
'        insert into eba_sales_customers (id, customer_name, ';
wwv_flow_imp.g_varchar2_table(314) := 'customer_territory_id, customer_is_key_account_yn) values (29,''Resource Planning and Conservation In';
wwv_flow_imp.g_varchar2_table(315) := 'c'',5,''N''); '||wwv_flow.LF||
'        insert into eba_sales_customers (id, customer_name, customer_territory_id, custo';
wwv_flow_imp.g_varchar2_table(316) := 'mer_is_key_account_yn) values (30,''Deep Cut Tier and Rim Services'',9,''N''); '||wwv_flow.LF||
'        insert into eba_';
wwv_flow_imp.g_varchar2_table(317) := 'sales_customers (id, customer_name, customer_territory_id, customer_is_key_account_yn) values (31,''G';
wwv_flow_imp.g_varchar2_table(318) := 'rand Canyon Adventure Travel Services'',3,''N''); '||wwv_flow.LF||
'        insert into eba_sales_customers (id, custome';
wwv_flow_imp.g_varchar2_table(319) := 'r_name, customer_territory_id, customer_is_key_account_yn) values (32,''ACME Guardians'',11,''N''); '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(320) := '     insert into eba_sales_customers (id, customer_name, customer_territory_id, customer_is_key_acco';
wwv_flow_imp.g_varchar2_table(321) := 'unt_yn) values (33,''J4HT Inc'',12,''Y''); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into eba_sales_SALESREPS ';
wwv_flow_imp.g_varchar2_table(322) := '(id,REP_LAST_NAME, REP_FIRST_NAME, REP_EMAIL, REP_ROLE) '||wwv_flow.LF||
'        values (1,''Davidson'',''David'',''david';
wwv_flow_imp.g_varchar2_table(323) := '.davidson@fastmail.com'',1); '||wwv_flow.LF||
'        insert into eba_sales_SALESREPS (id,REP_LAST_NAME, REP_FIRST_NA';
wwv_flow_imp.g_varchar2_table(324) := 'ME, REP_EMAIL, REP_ROLE) '||wwv_flow.LF||
'        values (2,''Robertson'',''Robert'',''robert.robertson@fastmail.com'',1);';
wwv_flow_imp.g_varchar2_table(325) := ' '||wwv_flow.LF||
'        insert into eba_sales_SALESREPS (id,REP_LAST_NAME, REP_FIRST_NAME, REP_EMAIL, REP_ROLE) '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(326) := '       values (3,''Albertson'',''Amy'',''amy.albertson@fastmail.com'',2); '||wwv_flow.LF||
'        insert into eba_sales_S';
wwv_flow_imp.g_varchar2_table(327) := 'ALESREPS (id,REP_LAST_NAME, REP_FIRST_NAME, REP_EMAIL, REP_ROLE) '||wwv_flow.LF||
'        values (4,''Summerson'',''Sam';
wwv_flow_imp.g_varchar2_table(328) := ''',''sam.sommerson@fastmail.com'',1); '||wwv_flow.LF||
'        insert into eba_sales_SALESREPS (id,REP_LAST_NAME, REP_F';
wwv_flow_imp.g_varchar2_table(329) := 'IRST_NAME, REP_EMAIL, REP_ROLE) '||wwv_flow.LF||
'        values (5,''Dewy'',''Dunbarton'',''dewy.dunbarton@fastmail.com'',';
wwv_flow_imp.g_varchar2_table(330) := '3); '||wwv_flow.LF||
'        insert into eba_sales_SALESREPS (id,REP_LAST_NAME, REP_FIRST_NAME, REP_EMAIL, REP_ROLE)';
wwv_flow_imp.g_varchar2_table(331) := ' '||wwv_flow.LF||
'        values (6,''Samantha'',''Dundealski'',''dewy.dunbarton@fastmail.com'',3); '||wwv_flow.LF||
'        insert into e';
wwv_flow_imp.g_varchar2_table(332) := 'ba_sales_SALESREPS (id,REP_LAST_NAME, REP_FIRST_NAME, REP_EMAIL, REP_ROLE) '||wwv_flow.LF||
'        values (7,''Marth';
wwv_flow_imp.g_varchar2_table(333) := 'a'',''May'',''martha.may@fastmail.com'',3); '||wwv_flow.LF||
'        insert into eba_sales_SALESREPS (id,REP_LAST_NAME, R';
wwv_flow_imp.g_varchar2_table(334) := 'EP_FIRST_NAME, REP_EMAIL, REP_ROLE) '||wwv_flow.LF||
'        values (8,''Marvin'',''Nimitz'',''marvin.nimitz@fastmail.com';
wwv_flow_imp.g_varchar2_table(335) := ''',3); '||wwv_flow.LF||
'        insert into eba_sales_SALESREPS (id,REP_LAST_NAME, REP_FIRST_NAME, REP_EMAIL, REP_ROL';
wwv_flow_imp.g_varchar2_table(336) := 'E) '||wwv_flow.LF||
'        values (9,''Raj'',''Gupta'',''raj.gupta@fastmail.com'',3); '||wwv_flow.LF||
'        insert into eba_sales_SALE';
wwv_flow_imp.g_varchar2_table(337) := 'SREPS (id,REP_LAST_NAME, REP_FIRST_NAME, REP_EMAIL, REP_ROLE) '||wwv_flow.LF||
'        values (10,''Sanjay'',''Sim'',''sa';
wwv_flow_imp.g_varchar2_table(338) := 'njay.sim@fastmail.com'',3); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into eba_sales_SALESREPS (id,REP_LAST';
wwv_flow_imp.g_varchar2_table(339) := '_NAME, REP_FIRST_NAME, REP_EMAIL, REP_ROLE) '||wwv_flow.LF||
'        values (11,''Sally'',''Simm'',''sally.simm@fastmail.';
wwv_flow_imp.g_varchar2_table(340) := 'com'',1); '||wwv_flow.LF||
'        insert into eba_sales_SALESREPS (id,REP_LAST_NAME, REP_FIRST_NAME, REP_EMAIL, REP_';
wwv_flow_imp.g_varchar2_table(341) := 'ROLE) '||wwv_flow.LF||
'        values (12,''Jing'',''Lu'',''jing.lu@fastmail.com'',1); '||wwv_flow.LF||
'        insert into eba_sales_SALE';
wwv_flow_imp.g_varchar2_table(342) := 'SREPS (id,REP_LAST_NAME, REP_FIRST_NAME, REP_EMAIL, REP_ROLE) '||wwv_flow.LF||
'        values (13,''Cynthia'',''Cheng'',';
wwv_flow_imp.g_varchar2_table(343) := '''cynthia.cheng@fastmail.com'',1); '||wwv_flow.LF||
'        insert into eba_sales_SALESREPS (id,REP_LAST_NAME, REP_FIR';
wwv_flow_imp.g_varchar2_table(344) := 'ST_NAME, REP_EMAIL, REP_ROLE) '||wwv_flow.LF||
'        values (14,''Hasan'',''Patel'',''hasan.patel@fastmail.com'',1); '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(345) := '      insert into eba_sales_SALESREPS (id,REP_LAST_NAME, REP_FIRST_NAME, REP_EMAIL, REP_ROLE) '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(346) := '   values (15,''Roger'',''Nelson'',''roger.nelson@fastmail.com'',1); '||wwv_flow.LF||
'        insert into eba_sales_SALESR';
wwv_flow_imp.g_varchar2_table(347) := 'EPS (id,REP_LAST_NAME, REP_FIRST_NAME, REP_EMAIL, REP_ROLE) '||wwv_flow.LF||
'        values (16,''Sam'',''Smith'',''sam.s';
wwv_flow_imp.g_varchar2_table(348) := 'mith@fastmail.com'',1); '||wwv_flow.LF||
'        insert into eba_sales_SALESREPS (id,REP_LAST_NAME, REP_FIRST_NAME, R';
wwv_flow_imp.g_varchar2_table(349) := 'EP_EMAIL, REP_ROLE) '||wwv_flow.LF||
'        values (17,''Peter'',''Gorski'',''peter.gorski@fastmail.com'',1); '||wwv_flow.LF||
'        in';
wwv_flow_imp.g_varchar2_table(350) := 'sert into eba_sales_SALESREPS (id,REP_LAST_NAME, REP_FIRST_NAME, REP_EMAIL, REP_ROLE) '||wwv_flow.LF||
'        value';
wwv_flow_imp.g_varchar2_table(351) := 's (18,''Larry'',''Heart'',''larry.heart@fastmail.com'',1); '||wwv_flow.LF||
'        insert into eba_sales_SALESREPS (id,RE';
wwv_flow_imp.g_varchar2_table(352) := 'P_LAST_NAME, REP_FIRST_NAME, REP_EMAIL, REP_ROLE) '||wwv_flow.LF||
'        values (19,''Chip'',''Chadworth'',''chip.chadw';
wwv_flow_imp.g_varchar2_table(353) := 'orth@fastmail.com'',1); '||wwv_flow.LF||
'        insert into eba_sales_SALESREPS (id,REP_LAST_NAME, REP_FIRST_NAME, R';
wwv_flow_imp.g_varchar2_table(354) := 'EP_EMAIL, REP_ROLE) '||wwv_flow.LF||
'        values (20,''Sharon'',''Sweed'',''sharon.sweed@fastmail.com'',1); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(355) := '        -- Products '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into eba_sales_PRODUCTS (id,product_name,product_descr';
wwv_flow_imp.g_varchar2_table(356) := 'iption) values (1,''Peregrine Enterprise Edition'',''software''); '||wwv_flow.LF||
'        insert into eba_sales_PRODUCT';
wwv_flow_imp.g_varchar2_table(357) := 'S (id,product_name,product_description) values (2,''Peregrine Standard Edition'',''software''); '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(358) := ' insert into eba_sales_PRODUCTS (id,product_name,product_description) values (3,''Osprey Enterprise E';
wwv_flow_imp.g_varchar2_table(359) := 'dition'',''software''); '||wwv_flow.LF||
'        insert into eba_sales_PRODUCTS (id,product_name,product_description) v';
wwv_flow_imp.g_varchar2_table(360) := 'alues (4,''System Sanity Check'',''consulting service''); '||wwv_flow.LF||
'        insert into eba_sales_PRODUCTS (id,pr';
wwv_flow_imp.g_varchar2_table(361) := 'oduct_name,product_description) values (5,''Symmetric 1000'',''hardware''); '||wwv_flow.LF||
'        insert into eba_sal';
wwv_flow_imp.g_varchar2_table(362) := 'es_PRODUCTS (id,product_name,product_description) values (6,''Symmetric 2000'',''hardware''); '||wwv_flow.LF||
'        i';
wwv_flow_imp.g_varchar2_table(363) := 'nsert into eba_sales_PRODUCTS (id,product_name,product_description) values (7,''Symmetric 2100'',''hard';
wwv_flow_imp.g_varchar2_table(364) := 'ware''); '||wwv_flow.LF||
'        insert into eba_sales_PRODUCTS (id,product_name,product_description) values (8,''Liq';
wwv_flow_imp.g_varchar2_table(365) := 'uid Designer'',''software''); '||wwv_flow.LF||
'        insert into eba_sales_PRODUCTS (id,product_name,product_descript';
wwv_flow_imp.g_varchar2_table(366) := 'ion) values (9,''CRUD Code Generator'',''software''); '||wwv_flow.LF||
'        insert into eba_sales_PRODUCTS (id,produc';
wwv_flow_imp.g_varchar2_table(367) := 't_name,product_description) values (10,''SQL Statement Synthesizer'',''software''); '||wwv_flow.LF||
'        insert into';
wwv_flow_imp.g_varchar2_table(368) := ' eba_sales_PRODUCTS (id,product_name,product_description) values (11,''HDRS Enterprise Edition'',''soft';
wwv_flow_imp.g_varchar2_table(369) := 'ware''); '||wwv_flow.LF||
'        insert into eba_sales_PRODUCTS (id,product_name,product_description) values (12,''JG';
wwv_flow_imp.g_varchar2_table(370) := 'FW Standard Edition'',''software''); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        -- Opportunities '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into';
wwv_flow_imp.g_varchar2_table(371) := ' EBA_SALES_DEALS (id,customer_id,salesrep_id_01,deal_name,deal_close_date,deal_amount,DEAL_PROBABILI';
wwv_flow_imp.g_varchar2_table(372) := 'TY,DEAL_STATUS_CODE_ID) '||wwv_flow.LF||
'        values (1,1,1,''Enterprise Lic Deal'',sysdate+60,12345,10,1); '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(373) := '  insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (1,1,1, 5000); '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(374) := '      insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (2,1,2, 5000);';
wwv_flow_imp.g_varchar2_table(375) := ' '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_COMPETITION (id, deal_id, COMPETITOR_THREAT_ID, competitor_id) ';
wwv_flow_imp.g_varchar2_table(376) := 'values (1,1,2,1); '||wwv_flow.LF||
'              '||wwv_flow.LF||
'        insert into EBA_SALES_DEALS (id,customer_id,salesrep_id_01';
wwv_flow_imp.g_varchar2_table(377) := ',deal_name,deal_close_date,deal_amount,DEAL_PROBABILITY,DEAL_STATUS_CODE_ID) '||wwv_flow.LF||
'        values (2,2,1,';
wwv_flow_imp.g_varchar2_table(378) := '''Marketing Dept Site Lic'',sysdate+85,100542,10,1); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,';
wwv_flow_imp.g_varchar2_table(379) := 'deal_id,product_id,QUOTE_PRICE) values (3,2,1, 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (';
wwv_flow_imp.g_varchar2_table(380) := 'id,deal_id,product_id,QUOTE_PRICE) values (4,2,2, 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_COMPETI';
wwv_flow_imp.g_varchar2_table(381) := 'TION (id, deal_id, COMPETITOR_THREAT_ID, competitor_id) values (2,2,1,1); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'         '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(382) := '   insert into EBA_SALES_DEALS (id,customer_id,salesrep_id_01,deal_name,deal_close_date,deal_amount,';
wwv_flow_imp.g_varchar2_table(383) := 'DEAL_PROBABILITY,DEAL_STATUS_CODE_ID) '||wwv_flow.LF||
'        values (3,2,1,''Upgrade'',sysdate+90,65432,10,1); '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(384) := '    insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (5,3,5, 5000); '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(385) := '        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (6,3,6, 5000';
wwv_flow_imp.g_varchar2_table(386) := '); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_COMPETITION (id, deal_id, COMPETITOR_THREAT_ID, competitor_id';
wwv_flow_imp.g_varchar2_table(387) := ') values (3,3,3,2); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into EBA_SALES_DEALS (id,customer_id,salesrep_id_01,de';
wwv_flow_imp.g_varchar2_table(388) := 'al_name,deal_close_date,deal_amount,DEAL_PROBABILITY,DEAL_STATUS_CODE_ID) '||wwv_flow.LF||
'        values (4,5,3,''Mo';
wwv_flow_imp.g_varchar2_table(389) := 'dernization Program'',sysdate+90,212890,10,1); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_';
wwv_flow_imp.g_varchar2_table(390) := 'id,product_id, QUOTE_PRICE) values (7,4,5, 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,d';
wwv_flow_imp.g_varchar2_table(391) := 'eal_id,product_id, QUOTE_PRICE) values (8,4,6, 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_COMPETITIO';
wwv_flow_imp.g_varchar2_table(392) := 'N (id, deal_id, COMPETITOR_THREAT_ID, competitor_id) values (4,4,4,4); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert int';
wwv_flow_imp.g_varchar2_table(393) := 'o EBA_SALES_DEALS (id,customer_id,salesrep_id_01,deal_name,deal_close_date,deal_amount,DEAL_PROBABIL';
wwv_flow_imp.g_varchar2_table(394) := 'ITY,DEAL_STATUS_CODE_ID) '||wwv_flow.LF||
'        values (5,5,3,''Refactoring of Application'',sysdate-5,6145,100,11);';
wwv_flow_imp.g_varchar2_table(395) := ' '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (9,5,5, 50';
wwv_flow_imp.g_varchar2_table(396) := '00); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (10,5,';
wwv_flow_imp.g_varchar2_table(397) := '6,5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_COMPETITION (id, deal_id, COMPETITOR_THREAT_ID, competi';
wwv_flow_imp.g_varchar2_table(398) := 'tor_id) values (5,5,5,5); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into EBA_SALES_DEALS (id,customer_id,salesrep_id';
wwv_flow_imp.g_varchar2_table(399) := '_01,deal_name,deal_close_date,deal_amount,DEAL_PROBABILITY,DEAL_STATUS_CODE_ID) '||wwv_flow.LF||
'        values (6,5';
wwv_flow_imp.g_varchar2_table(400) := ',1,''Special Project'',sysdate-15,15250,100,11); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal';
wwv_flow_imp.g_varchar2_table(401) := '_id,product_id, QUOTE_PRICE) values (11,6,1, 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id';
wwv_flow_imp.g_varchar2_table(402) := ',deal_id,product_id, QUOTE_PRICE) values (12,6,2, 5000); '||wwv_flow.LF||
'        --insert into EBA_SALES_DEAL_COMPE';
wwv_flow_imp.g_varchar2_table(403) := 'TITION (id, deal_id, COMPETITOR_THREAT_ID, competitor_id) values (6,6,1,1); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        inser';
wwv_flow_imp.g_varchar2_table(404) := 't into EBA_SALES_DEALS (id,customer_id,salesrep_id_01,deal_name,deal_close_date,deal_amount,DEAL_PRO';
wwv_flow_imp.g_varchar2_table(405) := 'BABILITY,DEAL_STATUS_CODE_ID) '||wwv_flow.LF||
'        values (7,2,2,''Network Installation 2'',sysdate-90,7500,100,11';
wwv_flow_imp.g_varchar2_table(406) := '); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (13,7,1,';
wwv_flow_imp.g_varchar2_table(407) := ' 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (14';
wwv_flow_imp.g_varchar2_table(408) := ',7,2, 5000); '||wwv_flow.LF||
'        --insert into EBA_SALES_DEAL_COMPETITION (id, deal_id, COMPETITOR_THREAT_ID, c';
wwv_flow_imp.g_varchar2_table(409) := 'ompetitor_id) values (7,7,2,2); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into EBA_SALES_DEALS (id,customer_id,sales';
wwv_flow_imp.g_varchar2_table(410) := 'rep_id_01,deal_name,deal_close_date,deal_amount,DEAL_PROBABILITY,DEAL_STATUS_CODE_ID) '||wwv_flow.LF||
'        value';
wwv_flow_imp.g_varchar2_table(411) := 's (8,2,2,''Network Installation 1'',sysdate-120,17500,100,11); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRO';
wwv_flow_imp.g_varchar2_table(412) := 'DUCTS (id,deal_id,product_id, QUOTE_PRICE) values (15,8,3, 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEA';
wwv_flow_imp.g_varchar2_table(413) := 'L_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (16,8,2, 5000); '||wwv_flow.LF||
'        --insert into EBA_SA';
wwv_flow_imp.g_varchar2_table(414) := 'LES_DEAL_COMPETITION (id, deal_id, COMPETITOR_THREAT_ID, competitor_id) values (8,8,3,3); '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(415) := ''||wwv_flow.LF||
'        insert into EBA_SALES_DEALS (id,customer_id,salesrep_id_01,deal_name,deal_close_date,deal_a';
wwv_flow_imp.g_varchar2_table(416) := 'mount,DEAL_PROBABILITY,DEAL_STATUS_CODE_ID) '||wwv_flow.LF||
'        values (9,2,2,''Network Installation 3'',sysdate-';
wwv_flow_imp.g_varchar2_table(417) := '10,7500,100,11); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) v';
wwv_flow_imp.g_varchar2_table(418) := 'alues (17,9,3, 5000); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into EBA_SALES_DEALS (id,customer_id,sales';
wwv_flow_imp.g_varchar2_table(419) := 'rep_id_01,deal_name,deal_close_date,deal_amount,DEAL_PROBABILITY,DEAL_STATUS_CODE_ID) '||wwv_flow.LF||
'        value';
wwv_flow_imp.g_varchar2_table(420) := 's (10,5,6,''Web HR Project'',sysdate-30,12000,100,11); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (i';
wwv_flow_imp.g_varchar2_table(421) := 'd,deal_id,product_id, QUOTE_PRICE) values (18,10,3, 50010); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PROD';
wwv_flow_imp.g_varchar2_table(422) := 'UCTS (id,deal_id,product_id, QUOTE_PRICE) values (19,10,4, 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEA';
wwv_flow_imp.g_varchar2_table(423) := 'L_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (20,10,5, 50200); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert i';
wwv_flow_imp.g_varchar2_table(424) := 'nto EBA_SALES_DEALS (id,customer_id,salesrep_id_01,deal_name,deal_close_date,deal_amount,DEAL_PROBAB';
wwv_flow_imp.g_varchar2_table(425) := 'ILITY,DEAL_STATUS_CODE_ID) '||wwv_flow.LF||
'        values (11,14,2,''Network Upgrade 1'',sysdate-200,7200,100,11); '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(426) := '       insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (21,11,6, 500';
wwv_flow_imp.g_varchar2_table(427) := '0); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (22,11,';
wwv_flow_imp.g_varchar2_table(428) := '7, 300); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (2';
wwv_flow_imp.g_varchar2_table(429) := '3,11,8, 5000); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into EBA_SALES_DEALS (id,customer_id,salesrep_id_01,deal_na';
wwv_flow_imp.g_varchar2_table(430) := 'me,deal_close_date,deal_amount,DEAL_PROBABILITY,DEAL_STATUS_CODE_ID) '||wwv_flow.LF||
'        values (12,15,3,''Netwo';
wwv_flow_imp.g_varchar2_table(431) := 'rk Upgrade 2'',sysdate-110,5500,100,11); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,pro';
wwv_flow_imp.g_varchar2_table(432) := 'duct_id, QUOTE_PRICE) values (24,12,7, 25000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal';
wwv_flow_imp.g_varchar2_table(433) := '_id,product_id, QUOTE_PRICE) values (25,12,8, 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (i';
wwv_flow_imp.g_varchar2_table(434) := 'd,deal_id,product_id, QUOTE_PRICE) values (26,12,9, 5000); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into EBA_SALES_';
wwv_flow_imp.g_varchar2_table(435) := 'DEALS (id,customer_id,salesrep_id_01,deal_name,deal_close_date,deal_amount,DEAL_PROBABILITY,DEAL_STA';
wwv_flow_imp.g_varchar2_table(436) := 'TUS_CODE_ID) '||wwv_flow.LF||
'        values (13,16,4,''Network Upgrade 3'',sysdate-10,2500,50,11); '||wwv_flow.LF||
'        insert in';
wwv_flow_imp.g_varchar2_table(437) := 'to EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (27,13,1, 5000); '||wwv_flow.LF||
'        ins';
wwv_flow_imp.g_varchar2_table(438) := 'ert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (28,13,8, 53000); '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(439) := '    insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (29,13,11, 4000)';
wwv_flow_imp.g_varchar2_table(440) := '; '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into EBA_SALES_DEALS (id,customer_id,salesrep_id_01,deal_name,deal_close';
wwv_flow_imp.g_varchar2_table(441) := '_date,deal_amount,DEAL_PROBABILITY,DEAL_STATUS_CODE_ID) '||wwv_flow.LF||
'        values (14,17,5,''Modernization Prog';
wwv_flow_imp.g_varchar2_table(442) := 'ram'',sysdate-10,25500,50,4); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QU';
wwv_flow_imp.g_varchar2_table(443) := 'OTE_PRICE) values (30,14,10, 5000); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into EBA_SALES_DEALS (id,customer_id,s';
wwv_flow_imp.g_varchar2_table(444) := 'alesrep_id_01,deal_name,deal_close_date,deal_amount,DEAL_PROBABILITY,DEAL_STATUS_CODE_ID) '||wwv_flow.LF||
'        v';
wwv_flow_imp.g_varchar2_table(445) := 'alues (15,18,6,''Legacy System Migration Program'',sysdate-4,13500,50,5); '||wwv_flow.LF||
'        insert into EBA_SAL';
wwv_flow_imp.g_varchar2_table(446) := 'ES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (31,15,10, 5000); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        in';
wwv_flow_imp.g_varchar2_table(447) := 'sert into EBA_SALES_DEALS (id,customer_id,salesrep_id_01,deal_name,deal_close_date,deal_amount,DEAL_';
wwv_flow_imp.g_varchar2_table(448) := 'PROBABILITY,DEAL_STATUS_CODE_ID) '||wwv_flow.LF||
'        values (16,19,7,''Open Systems Web Design Project'',sysdate-';
wwv_flow_imp.g_varchar2_table(449) := '5,14580,50,5); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) val';
wwv_flow_imp.g_varchar2_table(450) := 'ues (32,16,8, 5000); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into EBA_SALES_DEALS (id,customer_id,salesrep_id_01,d';
wwv_flow_imp.g_varchar2_table(451) := 'eal_name,deal_close_date,deal_amount,DEAL_PROBABILITY,DEAL_STATUS_CODE_ID) '||wwv_flow.LF||
'        values (17,20,8,';
wwv_flow_imp.g_varchar2_table(452) := '''TPS Reporting Solution'',sysdate-5,18500,50,5); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,dea';
wwv_flow_imp.g_varchar2_table(453) := 'l_id,product_id, QUOTE_PRICE) values (33,17,4, 12000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS ';
wwv_flow_imp.g_varchar2_table(454) := '(id,deal_id,product_id, QUOTE_PRICE) values (34,17,5, 12000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PR';
wwv_flow_imp.g_varchar2_table(455) := 'ODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (35,17,6, 12000); '||wwv_flow.LF||
'        insert into EBA_SALES_';
wwv_flow_imp.g_varchar2_table(456) := 'DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (36,17,7, 12000); '||wwv_flow.LF||
'        insert into EBA';
wwv_flow_imp.g_varchar2_table(457) := '_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (37,17,8, 12000); '||wwv_flow.LF||
'        insert i';
wwv_flow_imp.g_varchar2_table(458) := 'nto EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (38,17,9, 12000); '||wwv_flow.LF||
'        i';
wwv_flow_imp.g_varchar2_table(459) := 'nsert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (39,17,10, 5000); '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(460) := '           '||wwv_flow.LF||
'        insert into EBA_SALES_DEALS (id,customer_id,salesrep_id_01,deal_name,deal_close_';
wwv_flow_imp.g_varchar2_table(461) := 'date,deal_amount,DEAL_PROBABILITY,DEAL_STATUS_CODE_ID) '||wwv_flow.LF||
'        values (18,20,9,''Bianual Upgrade'',sy';
wwv_flow_imp.g_varchar2_table(462) := 'sdate-8,10000,50,5); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOTE_PRIC';
wwv_flow_imp.g_varchar2_table(463) := 'E) values (40,18,1, 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOT';
wwv_flow_imp.g_varchar2_table(464) := 'E_PRICE) values (41,18,2, 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id';
wwv_flow_imp.g_varchar2_table(465) := ', QUOTE_PRICE) values (42,18,5, 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,prod';
wwv_flow_imp.g_varchar2_table(466) := 'uct_id, QUOTE_PRICE) values (43,18,7, 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_i';
wwv_flow_imp.g_varchar2_table(467) := 'd,product_id, QUOTE_PRICE) values (44,18,8, 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,';
wwv_flow_imp.g_varchar2_table(468) := 'deal_id,product_id, QUOTE_PRICE) values (45,18,9, 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCT';
wwv_flow_imp.g_varchar2_table(469) := 'S (id,deal_id,product_id, QUOTE_PRICE) values (46,18,10, 5000); '||wwv_flow.LF||
'             '||wwv_flow.LF||
'             '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(470) := ' insert into EBA_SALES_DEALS (id,customer_id,salesrep_id_01,deal_name,deal_close_date,deal_amount,DE';
wwv_flow_imp.g_varchar2_table(471) := 'AL_PROBABILITY,DEAL_STATUS_CODE_ID) '||wwv_flow.LF||
'        values (19,20,10,''Sales team mobile modernization progr';
wwv_flow_imp.g_varchar2_table(472) := 'am'',sysdate-8,10000,50,5); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id, QUOT';
wwv_flow_imp.g_varchar2_table(473) := 'E_PRICE) values (50,19,1, 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,product_id';
wwv_flow_imp.g_varchar2_table(474) := ', QUOTE_PRICE) values (51,19,2, 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_id,prod';
wwv_flow_imp.g_varchar2_table(475) := 'uct_id, QUOTE_PRICE) values (52,19,3, 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,deal_i';
wwv_flow_imp.g_varchar2_table(476) := 'd,product_id, QUOTE_PRICE) values (53,19,7, 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCTS (id,';
wwv_flow_imp.g_varchar2_table(477) := 'deal_id,product_id, QUOTE_PRICE) values (54,19,8, 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_PRODUCT';
wwv_flow_imp.g_varchar2_table(478) := 'S (id,deal_id,product_id, QUOTE_PRICE) values (55,19,9, 5000); '||wwv_flow.LF||
'        insert into EBA_SALES_DEAL_P';
wwv_flow_imp.g_varchar2_table(479) := 'RODUCTS (id,deal_id,product_id, QUOTE_PRICE) values (56,19,10, 5000); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into';
wwv_flow_imp.g_varchar2_table(480) := ' eba_sales_users (id, username, access_level_id, account_locked) values (1, ''SAMPLE_USER'', -99, ''N'')';
wwv_flow_imp.g_varchar2_table(481) := ';'||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into eba_sales_comments (id, created_by, entity_type, deal_id, note) valu';
wwv_flow_imp.g_varchar2_table(482) := 'es  '||wwv_flow.LF||
'          (1, ''SAMPLE_USER'', ''OPPORTUNITY'', 1, ''Called customer they seem very interested, got ';
wwv_flow_imp.g_varchar2_table(483) := 'lead from a buddy whos knows someone who plays tennis with the customer.''); '||wwv_flow.LF||
'        insert into eba';
wwv_flow_imp.g_varchar2_table(484) := '_sales_comments (id, created_by, entity_type, deal_id, note) values  '||wwv_flow.LF||
'          (2, ''SAMPLE_USER'', ''';
wwv_flow_imp.g_varchar2_table(485) := 'OPPORTUNITY'', 2, ''Met someone on a flight who said they had an interest in our products.''); '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(486) := ' insert into eba_sales_comments (id, created_by, entity_type, deal_id, note) values  '||wwv_flow.LF||
'          (3, ';
wwv_flow_imp.g_varchar2_table(487) := '''SAMPLE_USER'', ''OPPORTUNITY'', 3, ''Call to main switchboard indicates that Adrian of New Haven Ct wan';
wwv_flow_imp.g_varchar2_table(488) := 'ts to buy something''); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        -- Leads '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into eba_sales_leads (i';
wwv_flow_imp.g_varchar2_table(489) := 'd,lead_name_01,account_id,lead_source_id,lead_details,lead_status_id,opportunity_id) values  '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(490) := '  (1,''Server'',5,1,''someone at dept of obfuscation wants some servers, call Jenny at 867-5309'',2,null';
wwv_flow_imp.g_varchar2_table(491) := '); '||wwv_flow.LF||
' '||wwv_flow.LF||
'        insert into eba_sales_leads (id,lead_name_01,account_id,lead_source_id,lead_details,le';
wwv_flow_imp.g_varchar2_table(492) := 'ad_status_id,opportunity_id) values  '||wwv_flow.LF||
'        (2,''Printer'',5,1,''This account needs color printers, w';
wwv_flow_imp.g_varchar2_table(493) := 'e should pay a sales call'',3,null); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into eba_sales_leads (id,lead_name_01,';
wwv_flow_imp.g_varchar2_table(494) := 'account_id,lead_source_id,lead_details,lead_status_id,opportunity_id) values  '||wwv_flow.LF||
'        (3,''Software''';
wwv_flow_imp.g_varchar2_table(495) := ',5,1,''Expressed interest in a sales tracking application, Call Bill'',4,null); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        ins';
wwv_flow_imp.g_varchar2_table(496) := 'ert into eba_sales_leads (id,lead_name_01,account_id,lead_source_id,lead_details,lead_status_id,oppo';
wwv_flow_imp.g_varchar2_table(497) := 'rtunity_id) values  '||wwv_flow.LF||
'        (4,''Software'',15,1,''Likes easy of install and cloud design, could be re';
wwv_flow_imp.g_varchar2_table(498) := 'ady to buy'',4,null); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into eba_sales_leads (id,lead_name_01,account_id,lead';
wwv_flow_imp.g_varchar2_table(499) := '_source_id,lead_details,lead_status_id,opportunity_id) values  '||wwv_flow.LF||
'        (5,''Software'',18,2,''Very muc';
wwv_flow_imp.g_varchar2_table(500) := 'h into extensibility, and our open architecture may be exactly what they are looking for'',2,null); '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(501) := '         '||wwv_flow.LF||
'        insert into eba_sales_leads (id,lead_name_01,account_id,lead_source_id,lead_detail';
wwv_flow_imp.g_varchar2_table(502) := 's,lead_status_id,opportunity_id) values  '||wwv_flow.LF||
'        (6,''Software'',16,2,''White board session at confere';
wwv_flow_imp.g_varchar2_table(503) := 'nce was very interesting, may be ready to take the leap'',3,null); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into eba';
wwv_flow_imp.g_varchar2_table(504) := '_sales_leads (id,lead_name_01,account_id,lead_source_id,lead_details,lead_status_id,opportunity_id) ';
wwv_flow_imp.g_varchar2_table(505) := 'values  '||wwv_flow.LF||
'        (7,''Software'',17,1,''Cold called, and appeared to be a great opportunity, are are ex';
wwv_flow_imp.g_varchar2_table(506) := 'actly the type of customer that likes our products'',4,null); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into eba_sale';
wwv_flow_imp.g_varchar2_table(507) := 's_leads (id,lead_name_01,account_id,lead_source_id,lead_details,lead_status_id,opportunity_id) value';
wwv_flow_imp.g_varchar2_table(508) := 's  '||wwv_flow.LF||
'        (8,''Software'',17,1,''Not sure if they have any money in their budget but would very much ';
wwv_flow_imp.g_varchar2_table(509) := 'like to see a demo'',4,null); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into eba_sales_leads (id,lead_name_01,account';
wwv_flow_imp.g_varchar2_table(510) := '_id,lead_source_id,lead_details,lead_status_id,opportunity_id) values  '||wwv_flow.LF||
'        (9,''Software'',19,2,''';
wwv_flow_imp.g_varchar2_table(511) := 'Running 20 year old COBOL system and want to modernize, need to talk to sales rep and technical cont';
wwv_flow_imp.g_varchar2_table(512) := 'act.  Highligh Java and open source.'',2,null); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into eba_sales_leads (id,le';
wwv_flow_imp.g_varchar2_table(513) := 'ad_name_01,account_id,lead_source_id,lead_details,lead_status_id,opportunity_id) values  '||wwv_flow.LF||
'        (1';
wwv_flow_imp.g_varchar2_table(514) := '0,''Software'',20,1,''Want to extend their ERP system, need interactive reporting solution for adhoc re';
wwv_flow_imp.g_varchar2_table(515) := 'port requests.'',2,null); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into eba_sales_leads (id,lead_name_01,account_id,';
wwv_flow_imp.g_varchar2_table(516) := 'lead_source_id,lead_details,lead_status_id,opportunity_id) values  '||wwv_flow.LF||
'        (11,''Software'',20,3,''Pla';
wwv_flow_imp.g_varchar2_table(517) := 'n to extend their existing CRM system using custom software, very interested in web services both RE';
wwv_flow_imp.g_varchar2_table(518) := 'ST and SOAP.'',3,null); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into eba_sales_leads (id,lead_name_01,account_id,le';
wwv_flow_imp.g_varchar2_table(519) := 'ad_source_id,lead_details,lead_status_id,opportunity_id) values  '||wwv_flow.LF||
'        (12,''Software'',21,2,''Atten';
wwv_flow_imp.g_varchar2_table(520) := 'ded our demo, didn''''t say a word but looked real interested, and took huge amount of notes.  I think';
wwv_flow_imp.g_varchar2_table(521) := ' this person is a competitor or very interested'',4,null); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into eba_sales_l';
wwv_flow_imp.g_varchar2_table(522) := 'eads (id,lead_name_01,account_id,lead_source_id,lead_details,lead_status_id,opportunity_id) values  ';
wwv_flow_imp.g_varchar2_table(523) := ''||wwv_flow.LF||
'        (13,''Software'',null,null,''Jim Southworth signed up for online web demo for our new web tool';
wwv_flow_imp.g_varchar2_table(524) := ''',4,null); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into eba_sales_leads (id,lead_name_01,account_id,lead_source_id';
wwv_flow_imp.g_varchar2_table(525) := ',lead_details,lead_status_id,opportunity_id) values  '||wwv_flow.LF||
'        (14,''Software'',null,null,''Frank Detric';
wwv_flow_imp.g_varchar2_table(526) := 'k signed up for online web demo for our new web tool'',4,null); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into eba_sa';
wwv_flow_imp.g_varchar2_table(527) := 'les_leads (id,lead_name_01,account_id,lead_source_id,lead_details,lead_status_id,opportunity_id) val';
wwv_flow_imp.g_varchar2_table(528) := 'ues  '||wwv_flow.LF||
'        (15,''Software'',null,null,''Jill Turner signed up for online web demo for our new web to';
wwv_flow_imp.g_varchar2_table(529) := 'ol'',4,null); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        insert into eba_sales_leads (id,lead_name_01,account_id,lead_source_';
wwv_flow_imp.g_varchar2_table(530) := 'id,lead_details,lead_status_id,opportunity_id) values  '||wwv_flow.LF||
'        (16,''Software'',null,null,''Naresh Nar';
wwv_flow_imp.g_varchar2_table(531) := 'a signed up for online web demo for our new web tool'', 4,null); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'    end load_sample; '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(532) := '  '||wwv_flow.LF||
'    procedure remove_sample is '||wwv_flow.LF||
'    begin '||wwv_flow.LF||
'        delete from eba_sales_comments where id <= 20;';
wwv_flow_imp.g_varchar2_table(533) := ' '||wwv_flow.LF||
'        delete from eba_sales_deal_products where id <= 100; '||wwv_flow.LF||
'        delete from eba_sales_deal_c';
wwv_flow_imp.g_varchar2_table(534) := 'ompetition where id < 100; '||wwv_flow.LF||
'        delete from eba_sales_deals where id < 100; '||wwv_flow.LF||
'        delete from';
wwv_flow_imp.g_varchar2_table(535) := ' eba_sales_products where id < 100; '||wwv_flow.LF||
'        delete from eba_sales_salesreps where id < 100; '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(536) := '  delete from eba_sales_customers where id < 100; '||wwv_flow.LF||
'        delete from eba_sales_leads where id < 10';
wwv_flow_imp.g_varchar2_table(537) := '0; '||wwv_flow.LF||
'        delete from eba_sales_users where id = 1;'||wwv_flow.LF||
'        delete from eba_sales_territories wher';
wwv_flow_imp.g_varchar2_table(538) := 'e id < 20;'||wwv_flow.LF||
'    end remove_sample; '||wwv_flow.LF||
' '||wwv_flow.LF||
'end eba_sales_data;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(7206105073768149418)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_data package body'
,p_sequence=>600
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
