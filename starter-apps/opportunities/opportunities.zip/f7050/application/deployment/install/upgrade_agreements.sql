prompt --application/deployment/install/upgrade_agreements
begin
--   Manifest
--     INSTALL: UPGRADE-AGREEMENTS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_AGREEMENTS" '||wwv_flow.LF||
'('||wwv_flow.LF||
'    "ID" NUMBER,'||wwv_flow.LF||
'    "ROW_VERSION_NUMBER" NUMBER,'||wwv_flow.LF||
'    "NAME" ';
wwv_flow_imp.g_varchar2_table(2) := 'VARCHAR2(255),'||wwv_flow.LF||
'    "AGREEMENT_TYPE_ID" NUMBER references EBA_SALES_AGREEMENT_TYPES on delete cascade';
wwv_flow_imp.g_varchar2_table(3) := ','||wwv_flow.LF||
'    "DESCRIPTION" VARCHAR2(4000),'||wwv_flow.LF||
'    "CREATED_BY" VARCHAR2(255),'||wwv_flow.LF||
'    "CREATED" TIMESTAMP (6) WITH';
wwv_flow_imp.g_varchar2_table(4) := ' TIME ZONE,'||wwv_flow.LF||
'    "UPDATED_BY" VARCHAR2(255),'||wwv_flow.LF||
'    "UPDATED" TIMESTAMP (6) WITH TIME ZONE,'||wwv_flow.LF||
'     PRIMARY';
wwv_flow_imp.g_varchar2_table(5) := ' KEY ("ID")  USING INDEX  ENABLE'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE UNIQUE INDEX "EBA_SALES_AGREEMENTS_UK" ON "EBA_SALES_AGR';
wwv_flow_imp.g_varchar2_table(6) := 'EEMENTS" ("NAME");'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER "BIU_EBA_SALES_AGREEMENTS" '||wwv_flow.LF||
'   before insert or update';
wwv_flow_imp.g_varchar2_table(7) := ' on EBA_SALES_AGREEMENTS'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         if :NEW.ID is nul';
wwv_flow_imp.g_varchar2_table(8) := 'l then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'           into :n';
wwv_flow_imp.g_varchar2_table(9) := 'ew.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'         :N';
wwv_flow_imp.g_varchar2_table(10) := 'EW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(11) := '    :new.updated := current_timestamp;'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      if';
wwv_flow_imp.g_varchar2_table(12) := ' updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_US';
wwv_flow_imp.g_varchar2_table(13) := 'ER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'en';
wwv_flow_imp.g_varchar2_table(14) := 'd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TRIGGER "BIU_EBA_SALES_AGREEMENTS" ENABLE;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8466667434427006111)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'AGREEMENTS'
,p_sequence=>100
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_SALES_AGREEMENTS'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
