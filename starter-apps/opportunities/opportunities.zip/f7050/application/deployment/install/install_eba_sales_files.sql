prompt --application/deployment/install/install_eba_sales_files
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_files
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814595202239132741)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_files'
,p_sequence=>350
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_FILES" ',
'   (	"ID" NUMBER, ',
'	"ROW_VERSION_NUMBER" NUMBER, ',
'	"DEAL_ID" NUMBER, ',
'	"FILENAME" VARCHAR2(4000), ',
'	"FILE_MIMETYPE" VARCHAR2(512), ',
'	"FILE_CHARSET" VARCHAR2(512), ',
'	"FILE_BLOB" BLOB, ',
'	"FILE_COMMENTS" VARCHAR2(4000), ',
'	"TAGS" VARCHAR2(4000), ',
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"CREATED_BY" VARCHAR2(255), ',
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"UPDATED_BY" VARCHAR2(255), ',
'	"ENTITY_TYPE" VARCHAR2(20) NOT NULL ENABLE, ',
'	"LEAD_ID" NUMBER, ',
'	"TERRITORY_ID" NUMBER, ',
'	"ACCOUNT_ID" NUMBER, ',
'	"CONTACT_ID" NUMBER, ',
'	"PRODUCT_ID" NUMBER, ',
'	 CONSTRAINT "EBA_SALES_FILES_PK" PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE, ',
'	 CONSTRAINT "EBA_SALES_FILES_ENT_TYPE_CK" CHECK (entity_type in (''OPPORTUNITY'',''LEAD'',''TERRITORY'',''ACCOUNT'', ''CONTACT'', ''PRODUCT'')) ENABLE, ',
'	 CONSTRAINT "EBA_SALES_FILES_ENT_FK_CK" CHECK (',
'  entity_type = ''OPPORTUNITY'' and deal_id is not null',
'    or entity_type = ''LEAD'' and lead_id is not null',
'    or entity_type = ''TERRITORY'' and territory_id is not null',
'    or entity_type = ''ACCOUNT'' and account_id is not null',
'    or entity_type = ''CONTACT'' and contact_id is not null',
'    or entity_type = ''PRODUCT'' and product_id is not null',
') ENABLE',
'   ) ;',
'',
'ALTER TABLE "EBA_SALES_FILES" ADD CONSTRAINT "EBA_SALES_FILES_ACCT_FK" FOREIGN KEY ("ACCOUNT_ID")',
'	  REFERENCES "EBA_SALES_CUSTOMERS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_FILES" ADD CONSTRAINT "EBA_SALES_FILES_CONT_FK" FOREIGN KEY ("CONTACT_ID")',
'	  REFERENCES "EBA_SALES_CUSTOMER_CONTACTS" ("ID") ENABLE;',
'',
'ALTER TABLE "EBA_SALES_FILES" ADD CONSTRAINT "EBA_SALES_FILES_FK" FOREIGN KEY ("DEAL_ID")',
'	  REFERENCES "EBA_SALES_DEALS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_FILES" ADD CONSTRAINT "EBA_SALES_FILES_LEADS_FK" FOREIGN KEY ("LEAD_ID")',
'	  REFERENCES "EBA_SALES_LEADS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_FILES" ADD CONSTRAINT "EBA_SALES_FILES_PROD_FK" FOREIGN KEY ("PRODUCT_ID")',
'	  REFERENCES "EBA_SALES_PRODUCTS" ("ID") ENABLE;',
'',
'ALTER TABLE "EBA_SALES_FILES" ADD CONSTRAINT "EBA_SALES_FILES_TERR_FK" FOREIGN KEY ("TERRITORY_ID")',
'	  REFERENCES "EBA_SALES_TERRITORIES" ("ID") ENABLE;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814595305321132741)
,p_script_id=>wwv_flow_imp.id(6814595202239132741)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_FILES'
);
wwv_flow_imp.component_end;
end;
/
