prompt --application/deployment/install/install_eba_sales_files
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_files
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_FILES" '||wwv_flow.LF||
'   (	"ID" NUMBER, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER, '||wwv_flow.LF||
'	"DEAL_ID" NUMBER,';
wwv_flow_imp.g_varchar2_table(2) := ' '||wwv_flow.LF||
'	"FILENAME" VARCHAR2(4000), '||wwv_flow.LF||
'	"FILE_MIMETYPE" VARCHAR2(512), '||wwv_flow.LF||
'	"FILE_CHARSET" VARCHAR2(512), '||wwv_flow.LF||
'	"FI';
wwv_flow_imp.g_varchar2_table(3) := 'LE_BLOB" BLOB, '||wwv_flow.LF||
'	"FILE_COMMENTS" VARCHAR2(4000), '||wwv_flow.LF||
'	"TAGS" VARCHAR2(4000), '||wwv_flow.LF||
'	"CREATED" TIMESTAMP (6) ';
wwv_flow_imp.g_varchar2_table(4) := 'WITH TIME ZONE, '||wwv_flow.LF||
'	"CREATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"UPDATED_B';
wwv_flow_imp.g_varchar2_table(5) := 'Y" VARCHAR2(255), '||wwv_flow.LF||
'	"ENTITY_TYPE" VARCHAR2(20) NOT NULL ENABLE, '||wwv_flow.LF||
'	"LEAD_ID" NUMBER, '||wwv_flow.LF||
'	"TERRITORY_ID"';
wwv_flow_imp.g_varchar2_table(6) := ' NUMBER, '||wwv_flow.LF||
'	"ACCOUNT_ID" NUMBER, '||wwv_flow.LF||
'	"CONTACT_ID" NUMBER, '||wwv_flow.LF||
'	"PRODUCT_ID" NUMBER, '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SAL';
wwv_flow_imp.g_varchar2_table(7) := 'ES_FILES_PK" PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SALES_FILES_ENT_TYPE_CK" C';
wwv_flow_imp.g_varchar2_table(8) := 'HECK (entity_type in (''OPPORTUNITY'',''LEAD'',''TERRITORY'',''ACCOUNT'', ''CONTACT'', ''PRODUCT'')) ENABLE, '||wwv_flow.LF||
'	 ';
wwv_flow_imp.g_varchar2_table(9) := 'CONSTRAINT "EBA_SALES_FILES_ENT_FK_CK" CHECK ('||wwv_flow.LF||
'  entity_type = ''OPPORTUNITY'' and deal_id is not null';
wwv_flow_imp.g_varchar2_table(10) := ''||wwv_flow.LF||
'    or entity_type = ''LEAD'' and lead_id is not null'||wwv_flow.LF||
'    or entity_type = ''TERRITORY'' and territory_';
wwv_flow_imp.g_varchar2_table(11) := 'id is not null'||wwv_flow.LF||
'    or entity_type = ''ACCOUNT'' and account_id is not null'||wwv_flow.LF||
'    or entity_type = ''CONTA';
wwv_flow_imp.g_varchar2_table(12) := 'CT'' and contact_id is not null'||wwv_flow.LF||
'    or entity_type = ''PRODUCT'' and product_id is not null'||wwv_flow.LF||
') ENABLE'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(13) := ' ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_FILES" ADD CONSTRAINT "EBA_SALES_FILES_ACCT_FK" FOREIGN KEY ("ACCOUNT_I';
wwv_flow_imp.g_varchar2_table(14) := 'D")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_CUSTOMERS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_FIL';
wwv_flow_imp.g_varchar2_table(15) := 'ES" ADD CONSTRAINT "EBA_SALES_FILES_CONT_FK" FOREIGN KEY ("CONTACT_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_CUS';
wwv_flow_imp.g_varchar2_table(16) := 'TOMER_CONTACTS" ("ID") ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_FILES" ADD CONSTRAINT "EBA_SALES_FILES_FK" FO';
wwv_flow_imp.g_varchar2_table(17) := 'REIGN KEY ("DEAL_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_DEALS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE ';
wwv_flow_imp.g_varchar2_table(18) := '"EBA_SALES_FILES" ADD CONSTRAINT "EBA_SALES_FILES_LEADS_FK" FOREIGN KEY ("LEAD_ID")'||wwv_flow.LF||
'	  REFERENCES "E';
wwv_flow_imp.g_varchar2_table(19) := 'BA_SALES_LEADS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_FILES" ADD CONSTRAINT "EBA_';
wwv_flow_imp.g_varchar2_table(20) := 'SALES_FILES_PROD_FK" FOREIGN KEY ("PRODUCT_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_PRODUCTS" ("ID") ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'A';
wwv_flow_imp.g_varchar2_table(21) := 'LTER TABLE "EBA_SALES_FILES" ADD CONSTRAINT "EBA_SALES_FILES_TERR_FK" FOREIGN KEY ("TERRITORY_ID")'||wwv_flow.LF||
'	';
wwv_flow_imp.g_varchar2_table(22) := '  REFERENCES "EBA_SALES_TERRITORIES" ("ID") ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814595202239132741)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_files'
,p_sequence=>350
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814595305321132741)
,p_script_id=>wwv_flow_imp.id(6814595202239132741)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_FILES'
);
wwv_flow_imp.component_end;
end;
/
