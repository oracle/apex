prompt --application/deployment/install/upgrade_add_lob_id_to_product_families
begin
--   Manifest
--     INSTALL: UPGRADE-Add lob_id to product families
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6414528776085272062)
,p_install_id=>wwv_flow_imp.id(10495272006180774354)
,p_name=>'Add lob_id to product families'
,p_sequence=>120
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select column_name',
'from user_tab_columns',
'where table_name = ''EBA_SALES_PRODUCT_FAMILIES''',
'    and column_name = ''LOB_ID'''))
,p_script_clob=>'alter table eba_sales_product_families add lob_id NUMBER references eba_sales_product_lobs;'
);
wwv_flow_imp.component_end;
end;
/
