prompt --application/deployment/install/upgrade_add_lob_id_to_product_families
begin
--   Manifest
--     INSTALL: UPGRADE-Add lob_id to product families
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'alter table eba_sales_product_families add lob_id NUMBER references eba_sales_product_lobs;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6432250968046025465)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'Add lob_id to product families'
,p_sequence=>120
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select column_name',
'from user_tab_columns',
'where table_name = ''EBA_SALES_PRODUCT_FAMILIES''',
'    and column_name = ''LOB_ID'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
