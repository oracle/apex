prompt --application/deployment/install/upgrade_add_lob_id_to_product_families
begin
--   Manifest
--     INSTALL: UPGRADE-Add lob_id to product families
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(6414528776085272062)
,p_install_id=>wwv_flow_api.id(10495272006180774354)
,p_name=>'Add lob_id to product families'
,p_sequence=>120
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select column_name',
'from user_tab_columns',
'where table_name = ''EBA_SALES_PRODUCT_FAMILIES''',
'    and column_name = ''LOB_ID'''))
,p_script_clob=>'alter table eba_sales_product_families add lob_id NUMBER references eba_sales_product_lobs;'
);
wwv_flow_api.component_end;
end;
/
