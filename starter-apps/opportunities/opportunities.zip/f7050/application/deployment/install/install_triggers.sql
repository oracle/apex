prompt --application/deployment/install/install_triggers
begin
--   Manifest
--     INSTALL: INSTALL-triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace TRIGGER "BD_EBA_SALES_COMPETITORS" '||wwv_flow.LF||
'    before delete on eba_sales_competitors'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(2) := ' for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba_sales_fw.tag_sync('||wwv_flow.LF||
'        p_new_tags      => null,'||wwv_flow.LF||
'        p_old_tags  ';
wwv_flow_imp.g_varchar2_table(3) := '    => :old.tags,'||wwv_flow.LF||
'        p_content_type  => ''COMPETITOR'','||wwv_flow.LF||
'        p_content_id    => :old.id );'||wwv_flow.LF||
'end';
wwv_flow_imp.g_varchar2_table(4) := ';'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BD_EBA_SALES_CUST" '||wwv_flow.LF||
'  before delete on eba_sales_customers'||wwv_flow.LF||
'  for each';
wwv_flow_imp.g_varchar2_table(5) := ' row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  eba_sales_fw.tag_sync('||wwv_flow.LF||
'    p_new_tags     => null,'||wwv_flow.LF||
'    p_old_tags     => :old.tags,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(6) := '  p_content_type => ''ACCOUNT'','||wwv_flow.LF||
'    p_content_id   => :old.id'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER ';
wwv_flow_imp.g_varchar2_table(7) := '"BD_EBA_SALES_CUST_CONTACTS" '||wwv_flow.LF||
'  before delete on eba_sales_customer_contacts'||wwv_flow.LF||
'  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(8) := ' eba_sales_fw.tag_sync('||wwv_flow.LF||
'    p_new_tags     => null,'||wwv_flow.LF||
'    p_old_tags     => :old.tags,'||wwv_flow.LF||
'    p_content_t';
wwv_flow_imp.g_varchar2_table(9) := 'ype => ''CONTACT'','||wwv_flow.LF||
'    p_content_id   => :old.id'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BD_EBA_SALES';
wwv_flow_imp.g_varchar2_table(10) := '_DEALS" '||wwv_flow.LF||
'    before delete on eba_sales_deals'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    delete from EBA_SALES_DEAL_';
wwv_flow_imp.g_varchar2_table(11) := 'products where deal_id = :new.id;'||wwv_flow.LF||
'    eba_sales_fw.tag_sync('||wwv_flow.LF||
'        p_new_tags      => null,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(12) := '  p_old_tags      => :old.tags,'||wwv_flow.LF||
'        p_content_type  => ''DEAL'','||wwv_flow.LF||
'        p_content_id    => :old.i';
wwv_flow_imp.g_varchar2_table(13) := 'd );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BD_EBA_SALES_LEADS" '||wwv_flow.LF||
'  before delete on eba_sales_leads'||wwv_flow.LF||
'  for';
wwv_flow_imp.g_varchar2_table(14) := ' each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  eba_sales_fw.tag_sync('||wwv_flow.LF||
'    p_new_tags     => null,'||wwv_flow.LF||
'    p_old_tags     => :old.tag';
wwv_flow_imp.g_varchar2_table(15) := 's,'||wwv_flow.LF||
'    p_content_type => ''LEAD'','||wwv_flow.LF||
'    p_content_id   => :old.id'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGE';
wwv_flow_imp.g_varchar2_table(16) := 'R "BD_EBA_SALES_PRODUCTS" '||wwv_flow.LF||
'  before delete on eba_sales_products'||wwv_flow.LF||
'  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  eba_sales_f';
wwv_flow_imp.g_varchar2_table(17) := 'w.tag_sync('||wwv_flow.LF||
'    p_new_tags     => null,'||wwv_flow.LF||
'    p_old_tags     => :old.tags,'||wwv_flow.LF||
'    p_content_type => ''PROD';
wwv_flow_imp.g_varchar2_table(18) := 'UCT'','||wwv_flow.LF||
'    p_content_id   => :old.id'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BD_EBA_SALES_TERR" '||wwv_flow.LF||
'  be';
wwv_flow_imp.g_varchar2_table(19) := 'fore delete on eba_sales_territories'||wwv_flow.LF||
'  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  eba_sales_fw.tag_sync('||wwv_flow.LF||
'    p_new_tags  ';
wwv_flow_imp.g_varchar2_table(20) := '   => null,'||wwv_flow.LF||
'    p_old_tags     => :old.tags,'||wwv_flow.LF||
'    p_content_type => ''TERRITORY'','||wwv_flow.LF||
'    p_content_id   =';
wwv_flow_imp.g_varchar2_table(21) := '> :old.id'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_EBA_SALES_ACT_COMPET" '||wwv_flow.LF||
'   before insert or';
wwv_flow_imp.g_varchar2_table(22) := ' update on eba_sales_act_competition'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         if :N';
wwv_flow_imp.g_varchar2_table(23) := 'EW.ID is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(24) := '     into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_timestamp;';
wwv_flow_imp.g_varchar2_table(25) := ''||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.updated_by := nvl(v(''APP_USER''),';
wwv_flow_imp.g_varchar2_table(26) := 'USER);'||wwv_flow.LF||
'         :new.updated := current_timestamp;'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'      end ';
wwv_flow_imp.g_varchar2_table(27) := 'if;'||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := n';
wwv_flow_imp.g_varchar2_table(28) := 'vl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(29) := '  end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_EBA_SALES_DEAL_COMPET" '||wwv_flow.LF||
'   before insert or upda';
wwv_flow_imp.g_varchar2_table(30) := 'te on eba_sales_deal_competition'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         if :NEW.I';
wwv_flow_imp.g_varchar2_table(31) := 'D is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(32) := ' into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(33) := '      :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.updated_by := nvl(v(''APP_USER''),USER';
wwv_flow_imp.g_varchar2_table(34) := ');'||wwv_flow.LF||
'         :new.updated := current_timestamp;'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(35) := '      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v';
wwv_flow_imp.g_varchar2_table(36) := '(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'      en';
wwv_flow_imp.g_varchar2_table(37) := 'd if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_ACCOUNT_STANDING" '||wwv_flow.LF||
'   before insert or update ';
wwv_flow_imp.g_varchar2_table(38) := 'on eba_sales_account_standing'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         if :NEW.ID i';
wwv_flow_imp.g_varchar2_table(39) := 's null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'           in';
wwv_flow_imp.g_varchar2_table(40) := 'to :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(41) := '   :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(42) := '         :new.updated := current_timestamp;'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(43) := '   if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''A';
wwv_flow_imp.g_varchar2_table(44) := 'PP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'      end i';
wwv_flow_imp.g_varchar2_table(45) := 'f;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_COMMENTS" before insert or update on "EBA_SALES_C';
wwv_flow_imp.g_varchar2_table(46) := 'OMMENTS"'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        select to_number(s';
wwv_flow_imp.g_varchar2_table(47) := 'ys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting t';
wwv_flow_imp.g_varchar2_table(48) := 'hen'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(49) := '       :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(50) := '  :new.row_key := eba_sales_fw.compress_int(eba_sales_rowkey_seq.nextval);'||wwv_flow.LF||
'        :new.row_version_';
wwv_flow_imp.g_varchar2_table(51) := 'number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(52) := '      :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_num';
wwv_flow_imp.g_varchar2_table(53) := 'ber,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_COMPETITORS" '||wwv_flow.LF||
'   before inse';
wwv_flow_imp.g_varchar2_table(54) := 'rt or update on eba_sales_competitors'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'    if :new.tags is not null then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(55) := '     :new.tags := eba_sales_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(56) := ' if :NEW.ID is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(57) := '           into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_time';
wwv_flow_imp.g_varchar2_table(58) := 'stamp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.updated_by := nvl(v(''APP_U';
wwv_flow_imp.g_varchar2_table(59) := 'SER''),USER);'||wwv_flow.LF||
'         :new.updated := current_timestamp;'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(60) := '  end if;'||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_B';
wwv_flow_imp.g_varchar2_table(61) := 'Y := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:old.row_version_number,1) + 1';
wwv_flow_imp.g_varchar2_table(62) := ';'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'    eba_sales_fw.tag_sync('||wwv_flow.LF||
'        p_new_tags      => :new.tags,'||wwv_flow.LF||
'        p_old_tags ';
wwv_flow_imp.g_varchar2_table(63) := '     => :old.tags,'||wwv_flow.LF||
'        p_content_type  => ''COMPETITOR'','||wwv_flow.LF||
'        p_content_id    => :new.id );'||wwv_flow.LF||
'en';
wwv_flow_imp.g_varchar2_table(64) := 'd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_COMP_THREATS" '||wwv_flow.LF||
'   before insert or update on eba_sales';
wwv_flow_imp.g_varchar2_table(65) := '_competitor_threats'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         if :NEW.ID is null the';
wwv_flow_imp.g_varchar2_table(66) := 'n'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'           into :new.id';
wwv_flow_imp.g_varchar2_table(67) := ''||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.CR';
wwv_flow_imp.g_varchar2_table(68) := 'EATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :';
wwv_flow_imp.g_varchar2_table(69) := 'new.updated := current_timestamp;'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      if upda';
wwv_flow_imp.g_varchar2_table(70) := 'ting then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),';
wwv_flow_imp.g_varchar2_table(71) := 'USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(72) := 'create or replace TRIGGER "BIU_EBA_SALES_COUNTRIES" '||wwv_flow.LF||
'before insert or update on eba_sales_countries'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(73) := '    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        select to_number(sys_guid()';
wwv_flow_imp.g_varchar2_table(74) := ',''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(75) := '   :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.row_version_number :=';
wwv_flow_imp.g_varchar2_table(76) := ' nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_CUR';
wwv_flow_imp.g_varchar2_table(77) := 'RENCIES" '||wwv_flow.LF||
'before insert or update on EBA_SALES_CURRENCIES '||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting a';
wwv_flow_imp.g_varchar2_table(78) := 'nd :new.id is null then'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into';
wwv_flow_imp.g_varchar2_table(79) := ' :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),U';
wwv_flow_imp.g_varchar2_table(80) := 'SER);'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);';
wwv_flow_imp.g_varchar2_table(81) := ''||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if';
wwv_flow_imp.g_varchar2_table(82) := ' updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_t';
wwv_flow_imp.g_varchar2_table(83) := 'imestamp;'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :ne';
wwv_flow_imp.g_varchar2_table(84) := 'w.CURRENCY_CODE := upper(:new.CURRENCY_CODE);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_CUST" ';
wwv_flow_imp.g_varchar2_table(85) := ''||wwv_flow.LF||
'  before insert or update on eba_sales_customers'||wwv_flow.LF||
'  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  if inserting '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(86) := 'f :new.id is null '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(87) := ''');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    :new.row_version_number := 1;'||wwv_flow.LF||
'    :new.row_key := eba_sales_fw.compress_int(eba';
wwv_flow_imp.g_varchar2_table(88) := '_sales_rowkey_seq.nextval);'||wwv_flow.LF||
''||wwv_flow.LF||
'    :new.created_by := nvl(apex_application.g_user, user);'||wwv_flow.LF||
'    :new.cre';
wwv_flow_imp.g_varchar2_table(89) := 'ated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(apex_application.g_user, user);'||wwv_flow.LF||
'    :new.updat';
wwv_flow_imp.g_varchar2_table(90) := 'ed := current_timestamp;'||wwv_flow.LF||
'  elsif updating '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    :new.updated_by := nvl(apex_application.g_user';
wwv_flow_imp.g_varchar2_table(91) := ', user);'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.row_version_number := nvl(:old.row_version_';
wwv_flow_imp.g_varchar2_table(92) := 'number, 1) + 1;'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  if :new.tags is not null '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    :new.tags := eba_sales_fw.tags_cle';
wwv_flow_imp.g_varchar2_table(93) := 'aner(:new.tags);'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  eba_sales_fw.tag_sync('||wwv_flow.LF||
'    p_new_tags     => :new.tags,'||wwv_flow.LF||
'    p_old_tags';
wwv_flow_imp.g_varchar2_table(94) := '     => :old.tags,'||wwv_flow.LF||
'    p_content_type => ''ACCOUNT'','||wwv_flow.LF||
'    p_content_id   => :new.id'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'creat';
wwv_flow_imp.g_varchar2_table(95) := 'e or replace TRIGGER "BIU_EBA_SALES_CUSTOMERS_LOCS" '||wwv_flow.LF||
'before insert or update on eba_sales_customer_l';
wwv_flow_imp.g_varchar2_table(96) := 'ocations'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        select to_number(s';
wwv_flow_imp.g_varchar2_table(97) := 'ys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting t';
wwv_flow_imp.g_varchar2_table(98) := 'hen'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(99) := '       :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(100) := '  :new.row_key := eba_sales_fw.compress_int(eba_sales_rowkey_seq.nextval);'||wwv_flow.LF||
'        :new.row_version_';
wwv_flow_imp.g_varchar2_table(101) := 'number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(102) := '      :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_num';
wwv_flow_imp.g_varchar2_table(103) := 'ber,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_CUST_CONTACTS" '||wwv_flow.LF||
'  before ins';
wwv_flow_imp.g_varchar2_table(104) := 'ert or update on eba_sales_customer_contacts'||wwv_flow.LF||
'  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  if inserting '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    if :ne';
wwv_flow_imp.g_varchar2_table(105) := 'w.id is null '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(106) := '   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    :new.row_version_number := 1;'||wwv_flow.LF||
'    :new.row_key := eba_sales_fw.compress_int(eba_sale';
wwv_flow_imp.g_varchar2_table(107) := 's_rowkey_seq.nextval);'||wwv_flow.LF||
''||wwv_flow.LF||
'    :new.created_by := nvl(apex_application.g_user, user);'||wwv_flow.LF||
'    :new.created ';
wwv_flow_imp.g_varchar2_table(108) := ':= current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(apex_application.g_user, user);'||wwv_flow.LF||
'    :new.updated :=';
wwv_flow_imp.g_varchar2_table(109) := ' current_timestamp;'||wwv_flow.LF||
'  elsif updating '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    :new.updated_by := nvl(apex_application.g_user, use';
wwv_flow_imp.g_varchar2_table(110) := 'r);'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.row_version_number := nvl(:old.row_version_numbe';
wwv_flow_imp.g_varchar2_table(111) := 'r, 1) + 1;'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  if :new.tags is not null '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    :new.tags := eba_sales_fw.tags_cleaner(';
wwv_flow_imp.g_varchar2_table(112) := ':new.tags);'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  eba_sales_fw.tag_sync('||wwv_flow.LF||
'    p_new_tags     => :new.tags,'||wwv_flow.LF||
'    p_old_tags     ';
wwv_flow_imp.g_varchar2_table(113) := '=> :old.tags,'||wwv_flow.LF||
'    p_content_type => ''CONTACT'','||wwv_flow.LF||
'    p_content_id   => :new.id'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or ';
wwv_flow_imp.g_varchar2_table(114) := 'replace TRIGGER "BIU_EBA_SALES_DEALS" '||wwv_flow.LF||
'before insert or update on EBA_SALES_DEALS'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'd';
wwv_flow_imp.g_varchar2_table(115) := 'eclare'||wwv_flow.LF||
'    ov varchar2(4000);'||wwv_flow.LF||
'    nv varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.tags is not null then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(116) := ' :new.tags := eba_sales_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.deal_close_date is null ';
wwv_flow_imp.g_varchar2_table(117) := 'then'||wwv_flow.LF||
'       :new.deal_close_date := add_months(sysdate,2);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    for c1 in (select period_';
wwv_flow_imp.g_varchar2_table(118) := 'name from eba_sales_sales_periods where :new.DEAL_CLOSE_DATE between first_day and last_day) loop'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(119) := '      :new.qtr := c1.period_name;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        se';
wwv_flow_imp.g_varchar2_table(120) := 'lect to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(121) := '  if inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created := curr';
wwv_flow_imp.g_varchar2_table(122) := 'ent_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_t';
wwv_flow_imp.g_varchar2_table(123) := 'imestamp;'||wwv_flow.LF||
'        :new.row_key := eba_sales_fw.compress_int(eba_sales_rowkey_seq.nextval);'||wwv_flow.LF||
'        :';
wwv_flow_imp.g_varchar2_table(124) := 'new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_';
wwv_flow_imp.g_varchar2_table(125) := 'USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old';
wwv_flow_imp.g_varchar2_table(126) := '.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting and :new.DEAL_STATUS_CODE_ID is not null th';
wwv_flow_imp.g_varchar2_table(127) := 'en'||wwv_flow.LF||
'       if :new.deal_probability is null then'||wwv_flow.LF||
'          for c1 in (select corresponding_prob_pct f';
wwv_flow_imp.g_varchar2_table(128) := 'rom EBA_SALES_DEAL_STATUS_CODES where id=:new.DEAL_STATUS_CODE_ID) loop'||wwv_flow.LF||
'              :new.deal_prob';
wwv_flow_imp.g_varchar2_table(129) := 'ability := c1.corresponding_prob_pct;'||wwv_flow.LF||
'          end loop;'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'    elsif updating and (nvl';
wwv_flow_imp.g_varchar2_table(130) := '(:new.DEAL_STATUS_CODE_ID,3.1) != nvl(:old.DEAL_STATUS_CODE_ID,3.1) or :new.deal_probability is null';
wwv_flow_imp.g_varchar2_table(131) := ' ) then'||wwv_flow.LF||
'        if :new.deal_probability is null then'||wwv_flow.LF||
'           for c1 in (select corresponding_pro';
wwv_flow_imp.g_varchar2_table(132) := 'b_pct from EBA_SALES_DEAL_STATUS_CODES where id=:new.DEAL_STATUS_CODE_ID) loop'||wwv_flow.LF||
'               :new.d';
wwv_flow_imp.g_varchar2_table(133) := 'eal_probability := c1.corresponding_prob_pct;'||wwv_flow.LF||
'           end loop;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(134) := '-'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.TAGS,''x0'') !=  nvl(:new.TAGS,''x0'') then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(135) := '   insert into EBA_SALES_HISTORY (deal_rowkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(136) := '        (:new.row_key, :new.id, upper(''tags''),:old.TAGS,:new.TAGS);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updati';
wwv_flow_imp.g_varchar2_table(137) := 'ng and nvl(:old.DEAL_CURRENCY,''x0'') !=  nvl(:new.DEAL_CURRENCY,''x0'') then'||wwv_flow.LF||
'          insert into EBA_';
wwv_flow_imp.g_varchar2_table(138) := 'SALES_HISTORY (deal_rowkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_k';
wwv_flow_imp.g_varchar2_table(139) := 'ey, :new.id, upper(''CURRENCY''),:old.DEAL_CURRENCY,:new.DEAL_CURRENCY);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if upd';
wwv_flow_imp.g_varchar2_table(140) := 'ating and nvl(:old.DEAL_NAME,''x0'') !=  nvl(:new.DEAL_NAME,''x0'') then'||wwv_flow.LF||
'          insert into EBA_SALES';
wwv_flow_imp.g_varchar2_table(141) := '_HISTORY (deal_rowkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :';
wwv_flow_imp.g_varchar2_table(142) := 'new.id, upper(''opportunity_name''),:old.DEAL_NAME,:new.DEAL_NAME);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating';
wwv_flow_imp.g_varchar2_table(143) := ' and nvl(:old.STRATEGY,''x0'') !=  nvl(:new.STRATEGY,''x0'') then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTOR';
wwv_flow_imp.g_varchar2_table(144) := 'Y (deal_rowkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id,';
wwv_flow_imp.g_varchar2_table(145) := ' upper(''STRATEGY''),:old.STRATEGY,:new.STRATEGY);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.DEA';
wwv_flow_imp.g_varchar2_table(146) := 'L_SUMMARY,''x0'') !=  nvl(:new.DEAL_SUMMARY,''x0'') then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (deal_r';
wwv_flow_imp.g_varchar2_table(147) := 'owkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''s';
wwv_flow_imp.g_varchar2_table(148) := 'ummary''),:old.DEAL_SUMMARY,:new.DEAL_SUMMARY);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.NATIO';
wwv_flow_imp.g_varchar2_table(149) := 'NAL_TOP_25_YN,''x0'') !=  nvl(:new.NATIONAL_TOP_25_YN,''x0'') then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTO';
wwv_flow_imp.g_varchar2_table(150) := 'RY (deal_rowkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id';
wwv_flow_imp.g_varchar2_table(151) := ', upper(''NATIONAL_TOP_25''),:old.NATIONAL_TOP_25_YN,:new.NATIONAL_TOP_25_YN);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(152) := 'if updating and nvl(:old.PARTNER,''x0'') !=  nvl(:new.PARTNER,''x0'') then'||wwv_flow.LF||
'          insert into EBA_SAL';
wwv_flow_imp.g_varchar2_table(153) := 'ES_HISTORY (deal_rowkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key,';
wwv_flow_imp.g_varchar2_table(154) := ' :new.id, upper(''PARTNER''),:old.PARTNER,:new.PARTNER);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:o';
wwv_flow_imp.g_varchar2_table(155) := 'ld.QTR,''0'') !=  nvl(:new.QTR,''0'') then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (deal_rowkey, deal_id';
wwv_flow_imp.g_varchar2_table(156) := ', column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''QTR''),:old.QTR,';
wwv_flow_imp.g_varchar2_table(157) := ':new.QTR);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.PRO_RE_ACTIVE,''0'') !=  nvl(:new.PRO_RE_AC';
wwv_flow_imp.g_varchar2_table(158) := 'TIVE,''0'') then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (deal_rowkey, deal_id, column_name, old_value';
wwv_flow_imp.g_varchar2_table(159) := ', new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''PRO_RE_ACTIVE''),:old.PRO_RE_ACTIVE,:new';
wwv_flow_imp.g_varchar2_table(160) := '.PRO_RE_ACTIVE);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- date history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and to_char(:old.DEAL';
wwv_flow_imp.g_varchar2_table(161) := '_CLOSE_DATE,''DD-MM-YYYY'') !=  to_char(:new.DEAL_CLOSE_DATE,''DD-MM-YYYY'') then'||wwv_flow.LF||
'          insert into ';
wwv_flow_imp.g_varchar2_table(162) := 'EBA_SALES_HISTORY (deal_rowkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.r';
wwv_flow_imp.g_varchar2_table(163) := 'ow_key, :new.id, upper(''close_date''),to_char(:old.DEAL_CLOSE_DATE,''DD-MM-YYYY''),to_char(:new.DEAL_CL';
wwv_flow_imp.g_varchar2_table(164) := 'OSE_DATE,''DD-MM-YYYY''));'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- numeric history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:o';
wwv_flow_imp.g_varchar2_table(165) := 'ld.DEAL_PROBABILITY,0) !=  nvl(:new.DEAL_PROBABILITY,0) then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY';
wwv_flow_imp.g_varchar2_table(166) := ' (deal_rowkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, ';
wwv_flow_imp.g_varchar2_table(167) := 'upper(''probability''),:old.DEAL_PROBABILITY,:new.DEAL_PROBABILITY);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updatin';
wwv_flow_imp.g_varchar2_table(168) := 'g and nvl(:old.DEAL_AMOUNT,0) !=  nvl(:new.DEAL_AMOUNT,0) then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTO';
wwv_flow_imp.g_varchar2_table(169) := 'RY (deal_rowkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id';
wwv_flow_imp.g_varchar2_table(170) := ', upper(''amount''),:old.DEAL_AMOUNT,:new.DEAL_AMOUNT);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:ol';
wwv_flow_imp.g_varchar2_table(171) := 'd.DEAL_LICENSE,0) !=  nvl(:new.DEAL_LICENSE,0) then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (deal_ro';
wwv_flow_imp.g_varchar2_table(172) := 'wkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''li';
wwv_flow_imp.g_varchar2_table(173) := 'cense''),:old.DEAL_LICENSE,:new.DEAL_LICENSE);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.DEAL_S';
wwv_flow_imp.g_varchar2_table(174) := 'UPPORT,0) !=  nvl(:new.DEAL_SUPPORT,0) then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (deal_rowkey, de';
wwv_flow_imp.g_varchar2_table(175) := 'al_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''support''),';
wwv_flow_imp.g_varchar2_table(176) := ':old.DEAL_SUPPORT,:new.DEAL_SUPPORT);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.DEAL_EDUCATION';
wwv_flow_imp.g_varchar2_table(177) := ',0) !=  nvl(:new.DEAL_EDUCATION,0) then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (deal_rowkey, deal_i';
wwv_flow_imp.g_varchar2_table(178) := 'd, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''education''),:o';
wwv_flow_imp.g_varchar2_table(179) := 'ld.DEAL_EDUCATION,:new.DEAL_EDUCATION);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.DEAL_CONSULT';
wwv_flow_imp.g_varchar2_table(180) := 'ING,0) !=  nvl(:new.DEAL_CONSULTING,0) then'||wwv_flow.LF||
'          insert into EBA_SALES_HISTORY (deal_rowkey, de';
wwv_flow_imp.g_varchar2_table(181) := 'al_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''consulting';
wwv_flow_imp.g_varchar2_table(182) := '''),:old.DEAL_CONSULTING,:new.DEAL_CONSULTING);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.DEAL_';
wwv_flow_imp.g_varchar2_table(183) := 'STATUS_CODE_ID,0) != nvl(:new.DEAL_STATUS_CODE_ID,0) then'||wwv_flow.LF||
'      ov := null; nv := null;'||wwv_flow.LF||
'      for c1';
wwv_flow_imp.g_varchar2_table(184) := ' in (select STATUS_CODE from EBA_SALES_LEAD_STATUS_CODES c where c.id = :old.DEAL_STATUS_CODE_ID) lo';
wwv_flow_imp.g_varchar2_table(185) := 'op'||wwv_flow.LF||
'          ov := c1.STATUS_CODE;'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'      for c1 in (select STATUS_CODE from EBA_SALE';
wwv_flow_imp.g_varchar2_table(186) := 'S_LEAD_STATUS_CODES c where c.id = :new.DEAL_STATUS_CODE_ID) loop'||wwv_flow.LF||
'          nv := c1.STATUS_CODE;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(187) := '    end loop;   '||wwv_flow.LF||
'      insert into EBA_SALES_HISTORY (deal_rowkey, deal_id, column_name, old_value, ';
wwv_flow_imp.g_varchar2_table(188) := 'new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''status code''),ov,nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(189) := '    if updating and nvl(:old.CUSTOMER_ID,0) != nvl(:new.CUSTOMER_ID,0) then'||wwv_flow.LF||
'      ov := null; nv := ';
wwv_flow_imp.g_varchar2_table(190) := 'null;'||wwv_flow.LF||
'      for c1 in (select CUSTOMER_NAME from EBA_SALES_CUSTOMERS c where c.id = :old.CUSTOMER_ID';
wwv_flow_imp.g_varchar2_table(191) := ') loop'||wwv_flow.LF||
'          ov := c1.CUSTOMER_NAME;'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'      for c1 in (select CUSTOMER_NAME from ';
wwv_flow_imp.g_varchar2_table(192) := 'EBA_SALES_CUSTOMERS c where c.id = :new.CUSTOMER_ID) loop'||wwv_flow.LF||
'          nv := c1.CUSTOMER_NAME;'||wwv_flow.LF||
'      en';
wwv_flow_imp.g_varchar2_table(193) := 'd loop;   '||wwv_flow.LF||
'      insert into EBA_SALES_HISTORY (deal_rowkey, deal_id, column_name, old_value, new_va';
wwv_flow_imp.g_varchar2_table(194) := 'lue) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''account''),ov,nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if upd';
wwv_flow_imp.g_varchar2_table(195) := 'ating and nvl(:old.SALESREP_ID_01,0) != nvl(:new.SALESREP_ID_01,0) then'||wwv_flow.LF||
'      ov := null; nv := null';
wwv_flow_imp.g_varchar2_table(196) := ';'||wwv_flow.LF||
'      for c1 in (select REP_EBA_SALES_USERNAME,REP_EMAIL,REP_LAST_NAME,REP_FIRST_NAME from EBA_SAL';
wwv_flow_imp.g_varchar2_table(197) := 'ES_SALESREPS c where c.id = :old.SALESREP_ID_01) loop'||wwv_flow.LF||
'          ov := nvl(nvl(c1.REP_EMAIL,c1.REP_FI';
wwv_flow_imp.g_varchar2_table(198) := 'RST_NAME||'' ''||c1.REP_LAST_NAME),c1.REP_EBA_SALES_USERNAME);'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'      for c1 in (select';
wwv_flow_imp.g_varchar2_table(199) := ' REP_EBA_SALES_USERNAME,REP_EMAIL,REP_LAST_NAME,REP_FIRST_NAME from EBA_SALES_SALESREPS c where c.id';
wwv_flow_imp.g_varchar2_table(200) := ' = :new.SALESREP_ID_01) loop'||wwv_flow.LF||
'          nv := nvl(nvl(c1.REP_EMAIL,c1.REP_FIRST_NAME||'' ''||c1.REP_LAS';
wwv_flow_imp.g_varchar2_table(201) := 'T_NAME),c1.REP_EBA_SALES_USERNAME);'||wwv_flow.LF||
'      end loop;   '||wwv_flow.LF||
'      insert into EBA_SALES_HISTORY (deal_row';
wwv_flow_imp.g_varchar2_table(202) := 'key, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''SAL';
wwv_flow_imp.g_varchar2_table(203) := 'ESREP_01''),ov,nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.FINANCIAL_ASSESSMENT_ID,0) != nvl';
wwv_flow_imp.g_varchar2_table(204) := '(:new.FINANCIAL_ASSESSMENT_ID,0) then'||wwv_flow.LF||
'      ov := null; nv := null;'||wwv_flow.LF||
'      for c1 in (select ASSESSME';
wwv_flow_imp.g_varchar2_table(205) := 'NT_TEXT from EBA_SALES_FIN_ASSESSMENTS c where c.id = :old.FINANCIAL_ASSESSMENT_ID) loop'||wwv_flow.LF||
'          o';
wwv_flow_imp.g_varchar2_table(206) := 'v := c1.ASSESSMENT_TEXT;'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'      for c1 in (select ASSESSMENT_TEXT from EBA_SALES_FIN_';
wwv_flow_imp.g_varchar2_table(207) := 'ASSESSMENTS c where c.id = :new.FINANCIAL_ASSESSMENT_ID) loop'||wwv_flow.LF||
'          nv := c1.ASSESSMENT_TEXT;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(208) := '    end loop;   '||wwv_flow.LF||
'      insert into EBA_SALES_HISTORY (deal_rowkey, deal_id, column_name, old_value, ';
wwv_flow_imp.g_varchar2_table(209) := 'new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''financial_assessment''),ov,nv);'||wwv_flow.LF||
'    end if';
wwv_flow_imp.g_varchar2_table(210) := ';'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.STATUS_ASSESSMENT_ID,0) != nvl(:new.STATUS_ASSESSMENT_ID,0) th';
wwv_flow_imp.g_varchar2_table(211) := 'en'||wwv_flow.LF||
'      ov := null; nv := null;'||wwv_flow.LF||
'      for c1 in (select ASSESSMENT_TEXT from EBA_SALES_STATUS_ASSES';
wwv_flow_imp.g_varchar2_table(212) := 'SMENTS c where c.id = :old.STATUS_ASSESSMENT_ID) loop'||wwv_flow.LF||
'          ov := c1.ASSESSMENT_TEXT;'||wwv_flow.LF||
'      end ';
wwv_flow_imp.g_varchar2_table(213) := 'loop;'||wwv_flow.LF||
'      for c1 in (select ASSESSMENT_TEXT from EBA_SALES_STATUS_ASSESSMENTS c where c.id = :new.';
wwv_flow_imp.g_varchar2_table(214) := 'STATUS_ASSESSMENT_ID) loop'||wwv_flow.LF||
'          nv := c1.ASSESSMENT_TEXT;'||wwv_flow.LF||
'      end loop;   '||wwv_flow.LF||
'      insert into ';
wwv_flow_imp.g_varchar2_table(215) := 'EBA_SALES_HISTORY (deal_rowkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.r';
wwv_flow_imp.g_varchar2_table(216) := 'ow_key, :new.id, upper(''status_assessment''),ov,nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.';
wwv_flow_imp.g_varchar2_table(217) := 'RISK_ASSESSMENT_ID,0) != nvl(:new.RISK_ASSESSMENT_ID,0) then'||wwv_flow.LF||
'      ov := null; nv := null;'||wwv_flow.LF||
'      for';
wwv_flow_imp.g_varchar2_table(218) := ' c1 in (select ASSESSMENT_TEXT from EBA_SALES_RISK_ASSESSMENTS c where c.id = :old.RISK_ASSESSMENT_I';
wwv_flow_imp.g_varchar2_table(219) := 'D) loop'||wwv_flow.LF||
'          ov := c1.ASSESSMENT_TEXT;'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'      for c1 in (select ASSESSMENT_TEXT ';
wwv_flow_imp.g_varchar2_table(220) := 'from EBA_SALES_RISK_ASSESSMENTS c where c.id = :new.RISK_ASSESSMENT_ID) loop'||wwv_flow.LF||
'          nv := c1.ASSE';
wwv_flow_imp.g_varchar2_table(221) := 'SSMENT_TEXT;'||wwv_flow.LF||
'      end loop;   '||wwv_flow.LF||
'      insert into EBA_SALES_HISTORY (deal_rowkey, deal_id, column_na';
wwv_flow_imp.g_varchar2_table(222) := 'me, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''risk_assessment''),ov,nv);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(223) := '    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.ACCOUNT_STANDING_ID,0) != nvl(:new.ACCOUNT_STANDING_';
wwv_flow_imp.g_varchar2_table(224) := 'ID,0) then'||wwv_flow.LF||
'      ov := null; nv := null;'||wwv_flow.LF||
'      for c1 in (select STANDING_TEXT from EBA_SALES_ACCOUN';
wwv_flow_imp.g_varchar2_table(225) := 'T_STANDING c where c.id = :old.ACCOUNT_STANDING_ID) loop'||wwv_flow.LF||
'          ov := c1.STANDING_TEXT;'||wwv_flow.LF||
'      end';
wwv_flow_imp.g_varchar2_table(226) := ' loop;'||wwv_flow.LF||
'      for c1 in (select STANDING_TEXT from EBA_SALES_ACCOUNT_STANDING c where c.id = :new.ACC';
wwv_flow_imp.g_varchar2_table(227) := 'OUNT_STANDING_ID) loop'||wwv_flow.LF||
'          nv := c1.STANDING_TEXT;'||wwv_flow.LF||
'      end loop;   '||wwv_flow.LF||
'      insert into EBA_SA';
wwv_flow_imp.g_varchar2_table(228) := 'LES_HISTORY (deal_rowkey, deal_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key';
wwv_flow_imp.g_varchar2_table(229) := ', :new.id, upper(''account_standing''),ov,nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating and nvl(:old.SVP_ID,';
wwv_flow_imp.g_varchar2_table(230) := '0) != nvl(:new.SVP_ID,0) then'||wwv_flow.LF||
'      ov := null; nv := null;'||wwv_flow.LF||
'      for c1 in (select SVP_NAME from EB';
wwv_flow_imp.g_varchar2_table(231) := 'A_SALES_SVPS c where c.id = :old.SVP_ID) loop'||wwv_flow.LF||
'          ov := c1.SVP_NAME;'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'      for';
wwv_flow_imp.g_varchar2_table(232) := ' c1 in (select SVP_NAME from EBA_SALES_SVPS c where c.id = :new.SVP_ID) loop'||wwv_flow.LF||
'          nv := c1.SVP_';
wwv_flow_imp.g_varchar2_table(233) := 'NAME;'||wwv_flow.LF||
'      end loop;   '||wwv_flow.LF||
'      insert into EBA_SALES_HISTORY (deal_rowkey, deal_id, column_name, old';
wwv_flow_imp.g_varchar2_table(234) := '_value, new_value) values'||wwv_flow.LF||
'          (:new.row_key, :new.id, upper(''SVP''),ov,nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(235) := '    -- tags'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    eba_sales_fw.tag_sync('||wwv_flow.LF||
'        p_new_tags      => :new.tags,'||wwv_flow.LF||
'        p_old_ta';
wwv_flow_imp.g_varchar2_table(236) := 'gs      => :old.tags,'||wwv_flow.LF||
'        p_content_type  => ''DEAL'','||wwv_flow.LF||
'        p_content_id    => :new.id );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(237) := '/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_DEAL_PRODUCTS" '||wwv_flow.LF||
'before insert or update on EBA_SALES_DEAL';
wwv_flow_imp.g_varchar2_table(238) := '_products'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        select to_number(';
wwv_flow_imp.g_varchar2_table(239) := 'sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    for c1 in (se';
wwv_flow_imp.g_varchar2_table(240) := 'lect period_name from eba_sales_sales_periods where :new.close_date between first_day and last_day)'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(241) := '    loop '||wwv_flow.LF||
'        :new.qtr := c1.period_name; '||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.crea';
wwv_flow_imp.g_varchar2_table(242) := 'ted_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.updated_b';
wwv_flow_imp.g_varchar2_table(243) := 'y := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_key := eba';
wwv_flow_imp.g_varchar2_table(244) := '_sales_fw.compress_int(eba_sales_rowkey_seq.nextval);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end ';
wwv_flow_imp.g_varchar2_table(245) := 'if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated :=';
wwv_flow_imp.g_varchar2_table(246) := ' current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end i';
wwv_flow_imp.g_varchar2_table(247) := 'f;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_DEAL_STAGES" '||wwv_flow.LF||
'   before insert or update on EBA_S';
wwv_flow_imp.g_varchar2_table(248) := 'ALES_deal_stages'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid()';
wwv_flow_imp.g_varchar2_table(249) := ',''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(250) := ':new.created := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.';
wwv_flow_imp.g_varchar2_table(251) := 'updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_v';
wwv_flow_imp.g_varchar2_table(252) := 'ersion_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_nu';
wwv_flow_imp.g_varchar2_table(253) := 'mber,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(254) := '      :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU';
wwv_flow_imp.g_varchar2_table(255) := '_EBA_SALES_DEAL_STAT_CODES" '||wwv_flow.LF||
'before insert or update on EBA_SALES_DEAL_status_codes'||wwv_flow.LF||
'    for each row';
wwv_flow_imp.g_varchar2_table(256) := ''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(257) := 'XXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_';
wwv_flow_imp.g_varchar2_table(258) := 'by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by :=';
wwv_flow_imp.g_varchar2_table(259) := ' nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number';
wwv_flow_imp.g_varchar2_table(260) := ' := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(261) := ':new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1)';
wwv_flow_imp.g_varchar2_table(262) := ' + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_DEAL_TEAM" '||wwv_flow.LF||
'   before insert or up';
wwv_flow_imp.g_varchar2_table(263) := 'date on eba_sales_deal_team'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         if :NEW.ID is ';
wwv_flow_imp.g_varchar2_table(264) := 'null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'           into';
wwv_flow_imp.g_varchar2_table(265) := ' :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(266) := ' :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(267) := '       :new.updated := current_timestamp;'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(268) := ' if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP';
wwv_flow_imp.g_varchar2_table(269) := '_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'      end if;';
wwv_flow_imp.g_varchar2_table(270) := ''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_FILES" '||wwv_flow.LF||
'   before insert or update on EBA_SALES_fil';
wwv_flow_imp.g_varchar2_table(271) := 'es'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(272) := 'XXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created :';
wwv_flow_imp.g_varchar2_table(273) := '= current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := cur';
wwv_flow_imp.g_varchar2_table(274) := 'rent_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number ';
wwv_flow_imp.g_varchar2_table(275) := ':= 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(276) := '  end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.upd';
wwv_flow_imp.g_varchar2_table(277) := 'ated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_FIN';
wwv_flow_imp.g_varchar2_table(278) := '_ASSESSMENTS" '||wwv_flow.LF||
'   before insert or update on eba_sales_fin_assessments'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(279) := '  if inserting then'||wwv_flow.LF||
'         if :NEW.ID is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXX';
wwv_flow_imp.g_varchar2_table(280) := 'XXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'           into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(281) := ':NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :ne';
wwv_flow_imp.g_varchar2_table(282) := 'w.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.updated := current_timestamp;'||wwv_flow.LF||
'         :new.r';
wwv_flow_imp.g_varchar2_table(283) := 'ow_version_number := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timest';
wwv_flow_imp.g_varchar2_table(284) := 'amp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:o';
wwv_flow_imp.g_varchar2_table(285) := 'ld.row_version_number,1) + 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_HISTORY"';
wwv_flow_imp.g_varchar2_table(286) := ' '||wwv_flow.LF||
'   before insert or update on EBA_SALES_history'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new."ID" is null then';
wwv_flow_imp.g_varchar2_table(287) := ''||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end';
wwv_flow_imp.g_varchar2_table(288) := ' if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.change_date := current_timestamp;'||wwv_flow.LF||
'       :new.changed_by := nv';
wwv_flow_imp.g_varchar2_table(289) := 'l(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row';
wwv_flow_imp.g_varchar2_table(290) := '_version_number := :new.row_version_number + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA';
wwv_flow_imp.g_varchar2_table(291) := '_SALES_INDUSTRIES" '||wwv_flow.LF||
'before insert or update on eba_sales_industries'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if in';
wwv_flow_imp.g_varchar2_table(292) := 'serting and :new.id is null then'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(293) := 'XX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP';
wwv_flow_imp.g_varchar2_table(294) := '_USER''),USER);'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER';
wwv_flow_imp.g_varchar2_table(295) := '''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_key := eba_sales_fw.compress_i';
wwv_flow_imp.g_varchar2_table(296) := 'nt(eba_sales_rowkey_seq.nextval);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating ';
wwv_flow_imp.g_varchar2_table(297) := 'then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(298) := '        :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or ';
wwv_flow_imp.g_varchar2_table(299) := 'replace TRIGGER "BIU_EBA_SALES_LEADS" '||wwv_flow.LF||
'  before insert or update on eba_sales_leads'||wwv_flow.LF||
'  for each row'||wwv_flow.LF||
'b';
wwv_flow_imp.g_varchar2_table(300) := 'egin'||wwv_flow.LF||
''||wwv_flow.LF||
'  if inserting '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    if :new.id is null '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(),';
wwv_flow_imp.g_varchar2_table(301) := ' ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    :new.row_version_number := 1;'||wwv_flow.LF||
'    :new.row_ke';
wwv_flow_imp.g_varchar2_table(302) := 'y := eba_sales_fw.compress_int(eba_sales_rowkey_seq.nextval);'||wwv_flow.LF||
''||wwv_flow.LF||
'    :new.created_by := nvl(apex_appli';
wwv_flow_imp.g_varchar2_table(303) := 'cation.g_user, user);'||wwv_flow.LF||
'    :new.created := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(apex_applica';
wwv_flow_imp.g_varchar2_table(304) := 'tion.g_user, user);'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'  elsif updating '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    :new.updated';
wwv_flow_imp.g_varchar2_table(305) := '_by := nvl(apex_application.g_user, user);'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.row_versi';
wwv_flow_imp.g_varchar2_table(306) := 'on_number := nvl(:old.row_version_number, 1) + 1;'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  if :new.tags is not null '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(307) := ':new.tags := eba_sales_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  eba_sales_fw.tag_sync('||wwv_flow.LF||
'    p_new_tag';
wwv_flow_imp.g_varchar2_table(308) := 's     => :new.tags,'||wwv_flow.LF||
'    p_old_tags     => :old.tags,'||wwv_flow.LF||
'    p_content_type => ''LEAD'','||wwv_flow.LF||
'    p_content_id ';
wwv_flow_imp.g_varchar2_table(309) := '  => :new.id'||wwv_flow.LF||
'  );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_LEAD_SOURCES" '||wwv_flow.LF||
'   before insert o';
wwv_flow_imp.g_varchar2_table(310) := 'r update on eba_sales_lead_sources'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         if :NEW';
wwv_flow_imp.g_varchar2_table(311) := '.ID is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(312) := '   into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(313) := '        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(314) := '     :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'      end if';
wwv_flow_imp.g_varchar2_table(315) := ';'||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl';
wwv_flow_imp.g_varchar2_table(316) := '(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(317) := 'end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_LEAD_ST_CDS" '||wwv_flow.LF||
'before insert or update on eba';
wwv_flow_imp.g_varchar2_table(318) := '_sales_lead_status_codes'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        se';
wwv_flow_imp.g_varchar2_table(319) := 'lect to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(320) := '  if inserting then'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :';
wwv_flow_imp.g_varchar2_table(321) := 'new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace T';
wwv_flow_imp.g_varchar2_table(322) := 'RIGGER "BIU_EBA_SALES_LINKS" '||wwv_flow.LF||
'   before insert or update on EBA_SALES_links'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(323) := ' if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into';
wwv_flow_imp.g_varchar2_table(324) := ' :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(325) := ' :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new';
wwv_flow_imp.g_varchar2_table(326) := '.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating the';
wwv_flow_imp.g_varchar2_table(327) := 'n'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting o';
wwv_flow_imp.g_varchar2_table(328) := 'r updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_u';
wwv_flow_imp.g_varchar2_table(329) := 'ser,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_PRODUCTS" '||wwv_flow.LF||
'  before insert or ';
wwv_flow_imp.g_varchar2_table(330) := 'update on eba_sales_products'||wwv_flow.LF||
'  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  if inserting '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    if :new.id is null '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(331) := '  then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(332) := ':new.row_version_number := 1;'||wwv_flow.LF||
'    :new.row_key := eba_sales_fw.compress_int(eba_sales_rowkey_seq.nex';
wwv_flow_imp.g_varchar2_table(333) := 'tval);'||wwv_flow.LF||
''||wwv_flow.LF||
'    :new.created_by := nvl(apex_application.g_user, user);'||wwv_flow.LF||
'    :new.created := current_times';
wwv_flow_imp.g_varchar2_table(334) := 'tamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(apex_application.g_user, user);'||wwv_flow.LF||
'    :new.updated := current_timesta';
wwv_flow_imp.g_varchar2_table(335) := 'mp;'||wwv_flow.LF||
'  elsif updating '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    :new.updated_by := nvl(apex_application.g_user, user);'||wwv_flow.LF||
'    :new.upd';
wwv_flow_imp.g_varchar2_table(336) := 'ated := current_timestamp;'||wwv_flow.LF||
'    :new.row_version_number := nvl(:old.row_version_number, 1) + 1;'||wwv_flow.LF||
'  end';
wwv_flow_imp.g_varchar2_table(337) := ' if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  if :new.tags is not null '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    :new.tags := eba_sales_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'  en';
wwv_flow_imp.g_varchar2_table(338) := 'd if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  eba_sales_fw.tag_sync('||wwv_flow.LF||
'    p_new_tags     => :new.tags,'||wwv_flow.LF||
'    p_old_tags     => :old.tags,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(339) := '  p_content_type => ''PRODUCT'','||wwv_flow.LF||
'    p_content_id   => :new.id'||wwv_flow.LF||
'  );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "';
wwv_flow_imp.g_varchar2_table(340) := 'BIU_EBA_SALES_RISK_ASSESSMENTS" '||wwv_flow.LF||
'   before insert or update on eba_sales_risk_assessments'||wwv_flow.LF||
'   for eac';
wwv_flow_imp.g_varchar2_table(341) := 'h row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         if :NEW.ID is null then'||wwv_flow.LF||
'           select to_number(';
wwv_flow_imp.g_varchar2_table(342) := 'sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'           into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(343) := '  end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),';
wwv_flow_imp.g_varchar2_table(344) := 'USER);'||wwv_flow.LF||
'         :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.updated := current_timesta';
wwv_flow_imp.g_varchar2_table(345) := 'mp;'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATE';
wwv_flow_imp.g_varchar2_table(346) := 'D := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_versi';
wwv_flow_imp.g_varchar2_table(347) := 'on_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU';
wwv_flow_imp.g_varchar2_table(348) := '_EBA_SALES_SALESREPS" '||wwv_flow.LF||
'before insert or update on eba_sales_salesreps'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if ';
wwv_flow_imp.g_varchar2_table(349) := 'inserting and :new.id is null then'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(350) := 'XXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''A';
wwv_flow_imp.g_varchar2_table(351) := 'PP_USER''),USER);'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_US';
wwv_flow_imp.g_varchar2_table(352) := 'ER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_key := eba_sales_fw.compress';
wwv_flow_imp.g_varchar2_table(353) := '_int(eba_sales_rowkey_seq.nextval);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updatin';
wwv_flow_imp.g_varchar2_table(354) := 'g then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp';
wwv_flow_imp.g_varchar2_table(355) := ';'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create o';
wwv_flow_imp.g_varchar2_table(356) := 'r replace TRIGGER "BIU_EBA_SALES_SALESREP_ROLES" '||wwv_flow.LF||
'before insert or update on eba_sales_salesrep_role';
wwv_flow_imp.g_varchar2_table(357) := 's'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        select to_number(sys_guid';
wwv_flow_imp.g_varchar2_table(358) := '(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(359) := '     :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(360) := ':new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.';
wwv_flow_imp.g_varchar2_table(361) := 'row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER';
wwv_flow_imp.g_varchar2_table(362) := '''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row';
wwv_flow_imp.g_varchar2_table(363) := '_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.is_sales_rep is null then'||wwv_flow.LF||
'        :new.is_sales_rep ';
wwv_flow_imp.g_varchar2_table(364) := ':= ''Y'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_SALES_PERIODS" '||wwv_flow.LF||
'before insert or';
wwv_flow_imp.g_varchar2_table(365) := ' update on eba_sales_sales_periods'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(366) := '        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(367) := 'end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then';
wwv_flow_imp.g_varchar2_table(368) := ''||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or';
wwv_flow_imp.g_varchar2_table(369) := ' replace TRIGGER "BIU_EBA_SALES_STATES" '||wwv_flow.LF||
'   before insert or update on EBA_SALES_STATES'||wwv_flow.LF||
'   for each ';
wwv_flow_imp.g_varchar2_table(370) := 'row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(371) := 'XXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_times';
wwv_flow_imp.g_varchar2_table(372) := 'tamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;';
wwv_flow_imp.g_varchar2_table(373) := ''||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif ';
wwv_flow_imp.g_varchar2_table(374) := 'updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if';
wwv_flow_imp.g_varchar2_table(375) := ' inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(';
wwv_flow_imp.g_varchar2_table(376) := 'wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_STATUS_ASSESS" '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(377) := ' before insert or update on eba_sales_status_assessments'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting';
wwv_flow_imp.g_varchar2_table(378) := ' then'||wwv_flow.LF||
'         if :NEW.ID is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(379) := 'XXXXXXXXXXX'')'||wwv_flow.LF||
'           into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED :';
wwv_flow_imp.g_varchar2_table(380) := '= current_timestamp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.updated_by :';
wwv_flow_imp.g_varchar2_table(381) := '= nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.updated := current_timestamp;'||wwv_flow.LF||
'         :new.row_version_num';
wwv_flow_imp.g_varchar2_table(382) := 'ber := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(383) := ':NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:old.row_version';
wwv_flow_imp.g_varchar2_table(384) := '_number,1) + 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_SVPS" '||wwv_flow.LF||
'   before inser';
wwv_flow_imp.g_varchar2_table(385) := 't or update on eba_sales_svps'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         if :NEW.ID i';
wwv_flow_imp.g_varchar2_table(386) := 's null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'           in';
wwv_flow_imp.g_varchar2_table(387) := 'to :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(388) := '   :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(389) := ':NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(390) := '   if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''A';
wwv_flow_imp.g_varchar2_table(391) := 'PP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'      end i';
wwv_flow_imp.g_varchar2_table(392) := 'f;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_TAGS" '||wwv_flow.LF||
'   before insert or update on eba_sales_ta';
wwv_flow_imp.g_varchar2_table(393) := 'gs'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'        :new.tag := upper(:new.tag);'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         if';
wwv_flow_imp.g_varchar2_table(394) := ' :NEW.ID is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(395) := '        into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_timesta';
wwv_flow_imp.g_varchar2_table(396) := 'mp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;';
wwv_flow_imp.g_varchar2_table(397) := ''||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'      e';
wwv_flow_imp.g_varchar2_table(398) := 'nd if;'||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY :';
wwv_flow_imp.g_varchar2_table(399) := '= nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(400) := '     end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_TERR" '||wwv_flow.LF||
'  before insert or update on eba';
wwv_flow_imp.g_varchar2_table(401) := '_sales_territories'||wwv_flow.LF||
'  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'  if inserting '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    if :new.id is null '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(402) := '   :new.id := to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    :new.row_v';
wwv_flow_imp.g_varchar2_table(403) := 'ersion_number := 1;'||wwv_flow.LF||
'    :new.row_key := eba_sales_fw.compress_int(eba_sales_rowkey_seq.nextval);'||wwv_flow.LF||
''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(404) := '  :new.created_by := nvl(apex_application.g_user, user);'||wwv_flow.LF||
'    :new.created := current_timestamp;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(405) := ':new.updated_by := nvl(apex_application.g_user, user);'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'  elsi';
wwv_flow_imp.g_varchar2_table(406) := 'f updating '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    :new.updated_by := nvl(apex_application.g_user, user);'||wwv_flow.LF||
'    :new.updated := cu';
wwv_flow_imp.g_varchar2_table(407) := 'rrent_timestamp;'||wwv_flow.LF||
'    :new.row_version_number := nvl(:old.row_version_number, 1) + 1;'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  if';
wwv_flow_imp.g_varchar2_table(408) := ' :new.tags is not null '||wwv_flow.LF||
'  then'||wwv_flow.LF||
'    :new.tags := eba_sales_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  e';
wwv_flow_imp.g_varchar2_table(409) := 'ba_sales_fw.tag_sync('||wwv_flow.LF||
'    p_new_tags     => :new.tags,'||wwv_flow.LF||
'    p_old_tags     => :old.tags,'||wwv_flow.LF||
'    p_conten';
wwv_flow_imp.g_varchar2_table(410) := 't_type => ''TERRITORY'','||wwv_flow.LF||
'    p_content_id   => :new.id'||wwv_flow.LF||
'  );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_';
wwv_flow_imp.g_varchar2_table(411) := 'SALES_TERRITORY_ACL" '||wwv_flow.LF||
'   before insert or update on eba_sales_territory_acl'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin';
wwv_flow_imp.g_varchar2_table(412) := ''||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         if :NEW.ID is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XX';
wwv_flow_imp.g_varchar2_table(413) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'           into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(414) := '     :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(415) := '  :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :';
wwv_flow_imp.g_varchar2_table(416) := 'new.row_version_number := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_t';
wwv_flow_imp.g_varchar2_table(417) := 'imestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := n';
wwv_flow_imp.g_varchar2_table(418) := 'vl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_TER';
wwv_flow_imp.g_varchar2_table(419) := 'R_MAP" '||wwv_flow.LF||
'   before insert or update on EBA_SALES_TERR_MAP'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new."ID" is nu';
wwv_flow_imp.g_varchar2_table(420) := 'll then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;';
wwv_flow_imp.g_varchar2_table(421) := ''||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'       :new.created_by :=';
wwv_flow_imp.g_varchar2_table(422) := ' nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(';
wwv_flow_imp.g_varchar2_table(423) := 'wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_v';
wwv_flow_imp.g_varchar2_table(424) := 'ersion_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(425) := '    :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end i';
wwv_flow_imp.g_varchar2_table(426) := 'f;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_SALES_TZ_PREF" '||wwv_flow.LF||
'   before insert or update on eba_sales';
wwv_flow_imp.g_varchar2_table(427) := '_tz_pref'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXX';
wwv_flow_imp.g_varchar2_table(428) := 'XXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.cre';
wwv_flow_imp.g_varchar2_table(429) := 'ated := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated ';
wwv_flow_imp.g_varchar2_table(430) := ':= current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_n';
wwv_flow_imp.g_varchar2_table(431) := 'umber := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) ';
wwv_flow_imp.g_varchar2_table(432) := '+ 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :n';
wwv_flow_imp.g_varchar2_table(433) := 'ew.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if :new.TIMEZONE_PREFERENCE is null then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(434) := '      :new.timezone_preference := ''UTC'';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "EBA_SALES_CLIC';
wwv_flow_imp.g_varchar2_table(435) := 'KS_BIU" '||wwv_flow.LF||
'    before insert on eba_sales_clicks'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(436) := '      :new.id := eba_sales_acl_api.gen_id();'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    :new.view_timestamp := current_timesta';
wwv_flow_imp.g_varchar2_table(437) := 'mp;'||wwv_flow.LF||
'    :new.app_session := v(''APP_SESSION'');'||wwv_flow.LF||
'    :new.app_username := lower(:new.app_username);'||wwv_flow.LF||
'end';
wwv_flow_imp.g_varchar2_table(438) := ';'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "EBA_SALES_ERRORS_BI" '||wwv_flow.LF||
'    before insert or update on eba_sales_errors';
wwv_flow_imp.g_varchar2_table(439) := ''||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'       :new.id := eba_sales_acl_api.gen_id();'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(440) := '  end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "EBA_SALES_NOTE_BIU" '||wwv_flow.LF||
'before insert or update on eba_sale';
wwv_flow_imp.g_varchar2_table(441) := 's_notifications'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        select to_n';
wwv_flow_imp.g_varchar2_table(442) := 'umber(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'        into :new.id'||wwv_flow.LF||
'        from dual;'||wwv_flow.LF||
'    end';
wwv_flow_imp.g_varchar2_table(443) := ' if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created ';
wwv_flow_imp.g_varchar2_table(444) := ':= current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := cu';
wwv_flow_imp.g_varchar2_table(445) := 'rrent_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new';
wwv_flow_imp.g_varchar2_table(446) := '.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USE';
wwv_flow_imp.g_varchar2_table(447) := 'R''),USER);'||wwv_flow.LF||
'        :new.updated    := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.notification_type i';
wwv_flow_imp.g_varchar2_table(448) := 's null then'||wwv_flow.LF||
'       :new.notification_type := ''MANUAL'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER ';
wwv_flow_imp.g_varchar2_table(449) := '"EBA_SALES_PREFERENCES_BIU" '||wwv_flow.LF||
'before insert or update on eba_sales_preferences'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin';
wwv_flow_imp.g_varchar2_table(450) := ''||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        :new.id := eba_sales_acl_api.gen_id();'||wwv_flow.LF||
'    end if';
wwv_flow_imp.g_varchar2_table(451) := ';'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created_on ';
wwv_flow_imp.g_varchar2_table(452) := ':= current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),';
wwv_flow_imp.g_varchar2_table(453) := 'USER);'||wwv_flow.LF||
'        :new.updated_on := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.preference_name := upper(:';
wwv_flow_imp.g_varchar2_table(454) := 'new.preference_name);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "EBA_SALES_USERS_BD" '||wwv_flow.LF||
'    before delete on eb';
wwv_flow_imp.g_varchar2_table(455) := 'a_sales_users'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    pragma autonomous_transaction;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- Disallow dele';
wwv_flow_imp.g_varchar2_table(456) := 'tes to a user''s own record unless last one.'||wwv_flow.LF||
'    if v(''APP_USER'') = upper(:old.username) then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(457) := 'for c1 in ('||wwv_flow.LF||
'          select count(*) cnt'||wwv_flow.LF||
'            from eba_sales_users'||wwv_flow.LF||
'           where id != :o';
wwv_flow_imp.g_varchar2_table(458) := 'ld.id )'||wwv_flow.LF||
'       loop'||wwv_flow.LF||
'          if c1.cnt > 0 then'||wwv_flow.LF||
'             raise_application_error(-20002, ''Delet';
wwv_flow_imp.g_varchar2_table(459) := 'e disallowed, you cannot delete your own access control details.'');'||wwv_flow.LF||
'          end if;'||wwv_flow.LF||
'       end loo';
wwv_flow_imp.g_varchar2_table(460) := 'p;'||wwv_flow.LF||
'    end if;    '||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "EBA_SALES_USERS_BIU" '||wwv_flow.LF||
'    before insert or upda';
wwv_flow_imp.g_varchar2_table(461) := 'te on eba_sales_users'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(462) := '           :new.id := eba_sales_acl_api.gen_id();'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created_by         :=';
wwv_flow_imp.g_varchar2_table(463) := ' nvl(v(''APP_USER''), USER);'||wwv_flow.LF||
'        :new.created            := current_timestamp;'||wwv_flow.LF||
'        :new.row_ve';
wwv_flow_imp.g_varchar2_table(464) := 'rsion        := 1;'||wwv_flow.LF||
'        if :new.account_locked is null then'||wwv_flow.LF||
'            :new.account_locked := ''N';
wwv_flow_imp.g_varchar2_table(465) := ''';    '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by         := nvl(v(''AP';
wwv_flow_imp.g_varchar2_table(466) := 'P_USER''), USER);'||wwv_flow.LF||
'        :new.updated            := current_timestamp;'||wwv_flow.LF||
'        :new.row_version     ';
wwv_flow_imp.g_varchar2_table(467) := '   := nvl(:old.row_version,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- Always store username as upper case'||wwv_flow.LF||
'    :new.u';
wwv_flow_imp.g_varchar2_table(468) := 'sername := upper(:new.username);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "EBA_SALES_VERIFY_BIU_FER" '||wwv_flow.LF||
'   bef';
wwv_flow_imp.g_varchar2_table(469) := 'ore insert or update on eba_sales_verifications'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.id is null then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(470) := '  :new.id := eba_sales_acl_api.gen_id();'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := curr';
wwv_flow_imp.g_varchar2_table(471) := 'ent_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(apex_application.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.verif';
wwv_flow_imp.g_varchar2_table(472) := 'ied_by := lower(:new.verified_by);'||wwv_flow.LF||
'   :new.updated := current_timestamp;'||wwv_flow.LF||
'   :new.updated_by := nvl(a';
wwv_flow_imp.g_varchar2_table(473) := 'pex_application.g_user,user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace TRIGGER "biu_eba_sales_product_families" '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(474) := 'before insert or update on eba_sales_product_families'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.id is null th';
wwv_flow_imp.g_varchar2_table(475) := 'en'||wwv_flow.LF||
'     :new.id := eba_sales_acl_api.gen_id();'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created :';
wwv_flow_imp.g_varchar2_table(476) := '= current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(apex_application.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new';
wwv_flow_imp.g_varchar2_table(477) := '.updated := current_timestamp;'||wwv_flow.LF||
'   :new.updated_by := nvl(apex_application.g_user,user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/ ';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6815264954706116977)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'triggers'
,p_sequence=>630
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815265065508116978)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BD_EBA_SALES_COMPETITORS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815265293160116978)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BD_EBA_SALES_CUST'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815265519837116979)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BD_EBA_SALES_CUST_CONTACTS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815265647271116979)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BD_EBA_SALES_DEALS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815265892470116979)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BD_EBA_SALES_LEADS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815266066483116979)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BD_EBA_SALES_PRODUCTS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815266278284116979)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BD_EBA_SALES_TERR'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815266452016116979)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_EBA_SALES_ACT_COMPET'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815266705703116980)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_EBA_SALES_DEAL_COMPET'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815266829105116980)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_ACCOUNT_STANDING'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815267231129116980)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_COMMENTS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815267479936116980)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_COMPETITORS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815267702488116980)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_COMP_THREATS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815267837581116981)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_COUNTRIES'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815268105611116981)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_CURRENCIES'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815268264912116981)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_CUST'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815268484001116981)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_CUSTOMERS_LOCS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815268650524116981)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_CUST_CONTACTS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815268902619116981)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_DEALS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815269042414116982)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_DEAL_PRODUCTS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815269304710116982)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_DEAL_STAGES'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815269432328116982)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_DEAL_STAT_CODES'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815269661090116982)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_DEAL_TEAM'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815270107190116982)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_FILES'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815270308688116983)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_FIN_ASSESSMENTS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815270439607116983)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_HISTORY'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815270680163116983)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_INDUSTRIES'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815270916041116983)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_LEADS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815271099084116983)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_LEAD_SOURCES'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815271274527116983)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_LEAD_ST_CDS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815271461210116984)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_LINKS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815271833734116984)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_PRODUCTS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815272034462116984)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_RISK_ASSESSMENTS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815272276926116984)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_SALESREPS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815272522285116984)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_SALESREP_ROLES'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815272712006116985)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_SALES_PERIODS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815272868817116985)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_STATES'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815273098725116985)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_STATUS_ASSESS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815273276665116985)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_SVPS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815273478720116985)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_TAGS'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815273700970116985)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_TERR'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815273879973116986)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_TERRITORY_ACL'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815274032171116986)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_TERR_MAP'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815274293684116986)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'BIU_EBA_SALES_TZ_PREF'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815274473343116986)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'EBA_SALES_CLICKS_BIU'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815274663749116986)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'EBA_SALES_ERRORS_BI'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815274845806116986)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'EBA_SALES_NOTE_BIU'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815275120423116987)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'EBA_SALES_PREFERENCES_BIU'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815275278766116987)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'EBA_SALES_USERS_BD'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815275452098116987)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'EBA_SALES_USERS_BIU'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6815275655506116987)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'EBA_SALES_VERIFY_BIU_FER'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6942502012309407072)
,p_script_id=>wwv_flow_imp.id(6815264954706116977)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'biu_eba_sales_product_families'
);
wwv_flow_imp.component_end;
end;
/
