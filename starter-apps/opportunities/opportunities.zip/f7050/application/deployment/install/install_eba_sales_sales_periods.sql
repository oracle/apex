prompt --application/deployment/install/install_eba_sales_sales_periods
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_sales_periods
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6796898203505473825)
,p_install_id=>wwv_flow_imp.id(10495272006180774354)
,p_name=>'eba_sales_sales_periods'
,p_sequence=>410
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_SALES_PERIODS" ',
'   (	"ID" NUMBER, ',
'	"ROW_VERSION_NUMBER" NUMBER, ',
'	"PERIOD_NAME" VARCHAR2(255) NOT NULL ENABLE, ',
'	"FIRST_DAY" TIMESTAMP (6) WITH TIME ZONE, ',
'	"LAST_DAY" TIMESTAMP (6) WITH TIME ZONE, ',
'	"FISCAL_YEAR" NUMBER(2,0), ',
'	 PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6796898281870473825)
,p_script_id=>wwv_flow_imp.id(6796898203505473825)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_SALES_PERIODS'
);
wwv_flow_imp.component_end;
end;
/
