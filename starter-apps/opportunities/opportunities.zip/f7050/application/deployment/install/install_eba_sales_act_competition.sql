prompt --application/deployment/install/install_eba_sales_act_competition
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_act_competition
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_ACT_COMPETITION" '||wwv_flow.LF||
'   (	"ID" NUMBER, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER, '||wwv_flow.LF||
'	"COMPET';
wwv_flow_imp.g_varchar2_table(2) := 'ITOR_ID" NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'	"CUSTOMER_ID" NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'	"COMPETITOR_THREAT_ID" NU';
wwv_flow_imp.g_varchar2_table(3) := 'MBER, '||wwv_flow.LF||
'	"COMPETITION_DESC" VARCHAR2(4000), '||wwv_flow.LF||
'	"CREATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"CREATED" TIMESTAMP (6) W';
wwv_flow_imp.g_varchar2_table(4) := 'ITH TIME ZONE, '||wwv_flow.LF||
'	"UPDATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	 PRIMARY KE';
wwv_flow_imp.g_varchar2_table(5) := 'Y ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_ACT_COMPETITION" ADD CONSTRAINT "EBA_S';
wwv_flow_imp.g_varchar2_table(6) := 'ALES_ACT_COMP_FK" FOREIGN KEY ("COMPETITOR_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_COMPETITORS" ("ID") ON DELE';
wwv_flow_imp.g_varchar2_table(7) := 'TE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TABLE "EBA_SALES_ACT_COMPETITION" ADD CONSTRAINT "EBA_SALES_ACT_COMP_FK2" ';
wwv_flow_imp.g_varchar2_table(8) := 'FOREIGN KEY ("CUSTOMER_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_CUSTOMERS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'AL';
wwv_flow_imp.g_varchar2_table(9) := 'TER TABLE "EBA_SALES_ACT_COMPETITION" ADD CONSTRAINT "EBA_SALES_ACT_COMP_FK3" FOREIGN KEY ("COMPETIT';
wwv_flow_imp.g_varchar2_table(10) := 'OR_THREAT_ID")'||wwv_flow.LF||
'	  REFERENCES "EBA_SALES_COMPETITOR_THREATS" ("ID") ON DELETE CASCADE ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814503062851905367)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_act_competition'
,p_sequence=>100
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814503173896905367)
,p_script_id=>wwv_flow_imp.id(6814503062851905367)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_ACT_COMPETITION'
);
wwv_flow_imp.component_end;
end;
/
