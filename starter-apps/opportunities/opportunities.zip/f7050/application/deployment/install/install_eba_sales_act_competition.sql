prompt --application/deployment/install/install_eba_sales_act_competition
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_act_competition
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6796780870891151964)
,p_install_id=>wwv_flow_imp.id(10495272006180774354)
,p_name=>'eba_sales_act_competition'
,p_sequence=>100
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_ACT_COMPETITION" ',
'   (	"ID" NUMBER, ',
'	"ROW_VERSION_NUMBER" NUMBER, ',
'	"COMPETITOR_ID" NUMBER NOT NULL ENABLE, ',
'	"CUSTOMER_ID" NUMBER NOT NULL ENABLE, ',
'	"COMPETITOR_THREAT_ID" NUMBER, ',
'	"COMPETITION_DESC" VARCHAR2(4000), ',
'	"CREATED_BY" VARCHAR2(255), ',
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"UPDATED_BY" VARCHAR2(255), ',
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	 PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'ALTER TABLE "EBA_SALES_ACT_COMPETITION" ADD CONSTRAINT "EBA_SALES_ACT_COMP_FK" FOREIGN KEY ("COMPETITOR_ID")',
'	  REFERENCES "EBA_SALES_COMPETITORS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_ACT_COMPETITION" ADD CONSTRAINT "EBA_SALES_ACT_COMP_FK2" FOREIGN KEY ("CUSTOMER_ID")',
'	  REFERENCES "EBA_SALES_CUSTOMERS" ("ID") ON DELETE CASCADE ENABLE;',
'',
'ALTER TABLE "EBA_SALES_ACT_COMPETITION" ADD CONSTRAINT "EBA_SALES_ACT_COMP_FK3" FOREIGN KEY ("COMPETITOR_THREAT_ID")',
'	  REFERENCES "EBA_SALES_COMPETITOR_THREATS" ("ID") ON DELETE CASCADE ENABLE;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6796780981936151964)
,p_script_id=>wwv_flow_imp.id(6796780870891151964)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_ACT_COMPETITION'
);
wwv_flow_imp.component_end;
end;
/
