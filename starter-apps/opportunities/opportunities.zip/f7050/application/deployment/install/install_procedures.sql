prompt --application/deployment/install/install_procedures
begin
--   Manifest
--     INSTALL: INSTALL-procedures
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6798482136284631941)
,p_install_id=>wwv_flow_imp.id(10495272006180774354)
,p_name=>'procedures'
,p_sequence=>610
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE OR REPLACE PROCEDURE "EBA_SALES_TZ_INIT" ',
'as',
'  c integer := 0;',
'  l_app_user varchar2(255);',
'begin',
'l_app_user := nvl(v(''APP_USER''),user);',
'for c1 in (',
'   select TIMEZONE_PREFERENCE',
'   from   eba_sales_tz_pref',
'   where  USERID = l_app_user) loop',
'   --',
'   if c1.TIMEZONE_PREFERENCE is not null then',
'       c := c + 1;',
'       APEX_UTIL.SET_SESSION_TIME_ZONE (P_TIME_ZONE => c1.TIMEZONE_PREFERENCE ); ',
'   end if;',
'   exit;',
'end loop;',
'if c = 0 then',
'    if apex_util.get_session_time_zone is null then',
'        APEX_UTIL.SET_SESSION_TIME_ZONE (P_TIME_ZONE => ''US/Pacific''); ',
'    end if;',
'end if;',
'end;',
'/',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6798482310729631943)
,p_script_id=>wwv_flow_imp.id(6798482136284631941)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PROCEDURE'
,p_object_name=>'EBA_SALES_TZ_INIT'
,p_last_updated_on=>to_date('20160707072024','YYYYMMDDHH24MISS')
,p_created_by=>'DAN'
,p_created_on=>to_date('20160707072024','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
