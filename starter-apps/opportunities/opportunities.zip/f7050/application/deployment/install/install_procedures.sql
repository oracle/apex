prompt --application/deployment/install/install_procedures
begin
--   Manifest
--     INSTALL: INSTALL-procedures
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE OR REPLACE PROCEDURE "EBA_SALES_TZ_INIT" '||wwv_flow.LF||
'as'||wwv_flow.LF||
'  c integer := 0;'||wwv_flow.LF||
'  l_app_user varchar2(255);'||wwv_flow.LF||
'be';
wwv_flow_imp.g_varchar2_table(2) := 'gin'||wwv_flow.LF||
'l_app_user := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'for c1 in ('||wwv_flow.LF||
'   select TIMEZONE_PREFERENCE'||wwv_flow.LF||
'   from   eba_s';
wwv_flow_imp.g_varchar2_table(3) := 'ales_tz_pref'||wwv_flow.LF||
'   where  USERID = l_app_user) loop'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   if c1.TIMEZONE_PREFERENCE is not null then';
wwv_flow_imp.g_varchar2_table(4) := ''||wwv_flow.LF||
'       c := c + 1;'||wwv_flow.LF||
'       APEX_UTIL.SET_SESSION_TIME_ZONE (P_TIME_ZONE => c1.TIMEZONE_PREFERENCE );';
wwv_flow_imp.g_varchar2_table(5) := ' '||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   exit;'||wwv_flow.LF||
'end loop;'||wwv_flow.LF||
'if c = 0 then'||wwv_flow.LF||
'    if apex_util.get_session_time_zone is null then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(6) := '      APEX_UTIL.SET_SESSION_TIME_ZONE (P_TIME_ZONE => ''US/Pacific''); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6816204328245385344)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'procedures'
,p_sequence=>610
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6816204502690385346)
,p_script_id=>wwv_flow_imp.id(6816204328245385344)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PROCEDURE'
,p_object_name=>'EBA_SALES_TZ_INIT'
);
wwv_flow_imp.component_end;
end;
/
