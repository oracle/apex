prompt --application/deployment/install/install_eba_sales_salesrep_roles
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_salesrep_roles
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814612074077221897)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_salesrep_roles'
,p_sequence=>400
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_SALES_SALESREP_ROLES" ',
'   (	"ID" NUMBER, ',
'	"ROW_VERSION_NUMBER" NUMBER, ',
'	"ROLE_NAME" VARCHAR2(255) NOT NULL ENABLE, ',
'	"IS_SALES_REP" VARCHAR2(1), ',
'	"CREATED_BY" VARCHAR2(255), ',
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	"UPDATED_BY" VARCHAR2(255), ',
'	"UPDATED" TIMESTAMP (6) WITH TIME ZONE, ',
'	 PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814612168307221897)
,p_script_id=>wwv_flow_imp.id(6814612074077221897)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_SALESREP_ROLES'
);
wwv_flow_imp.component_end;
end;
/
