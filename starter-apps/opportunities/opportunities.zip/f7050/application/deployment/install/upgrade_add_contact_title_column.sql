prompt --application/deployment/install/upgrade_add_contact_title_column
begin
--   Manifest
--     INSTALL: UPGRADE-Add Contact Title Column
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8473761692663157988)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'Add Contact Title Column'
,p_sequence=>160
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select column_name',
'from user_tab_columns',
'where table_name = ''EBA_SALES_CUSTOMER_CONTACTS''',
'    and column_name = ''CONTACT_TITLE'''))
,p_script_clob=>'alter table eba_sales_customer_contacts add contact_title varchar2(100);'
);
wwv_flow_imp.component_end;
end;
/
