prompt --application/create_application
begin
--   Manifest
--     FLOW: 7050
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-13'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_flow(
 p_id=>wwv_flow.g_flow_id
,p_owner=>nvl(wwv_flow_application_install.get_schema,'ORACLE')
,p_name=>nvl(wwv_flow_application_install.get_application_name,'Opportunities')
,p_alias=>nvl(wwv_flow_application_install.get_application_alias,'OPPORTUNITIES')
,p_application_group=>wwv_flow_api.id(162622091734521428)
,p_application_group_name=>'21.1 Starter Apps'
,p_page_view_logging=>'YES'
,p_page_protection_enabled_y_n=>'Y'
,p_checksum_salt=>'5BCC77279D9609B433F5B565C984041B033408BC7963CB6DFCCAF42FF445EF74'
,p_checksum_salt_last_reset=>'20150102071703'
,p_bookmark_checksum_function=>'SH1'
,p_max_session_length_sec=>28800
,p_compatibility_mode=>'19.2'
,p_flow_language=>'en-us'
,p_flow_language_derived_from=>'FLOW_PRIMARY_LANGUAGE'
,p_allow_feedback_yn=>'Y'
,p_direction_right_to_left=>'N'
,p_flow_image_prefix => nvl(wwv_flow_application_install.get_image_prefix,'')
,p_documentation_banner=>wwv_flow_string.join(wwv_flow_t_varchar2(
'0.9.25 -> 0.9.26: Fixed code in eba_sales_acl_api.apex_error_handling() procedure to allow the correct error message to be displayed when a page item''s "Restricted characters" security setting has been violated.',
'0.9.26 -> 0.9.27: Implemented redesigned administrative ACL controls',
'0.9.27 -> 0.9.28: Added Usage Metrics region plugin to pages 80 (Opportunity), 94 (Account) and 133 (Lead)',
'0.9.28 -> 1.1.26: Updated version level to match APEX metadata'))
,p_authentication=>'PLUGIN'
,p_authentication_id=>wwv_flow_api.id(10495269307775772421)
,p_application_tab_set=>1
,p_logo_type=>'T'
,p_logo_text=>'&APPLICATION_TITLE.'
,p_favicons=>'<link rel="shortcut icon" href="#IMAGE_PREFIX#apex_ui/img/favicons/app-opportunity-tracker.ico"><link rel="icon" sizes="16x16" href="#IMAGE_PREFIX#apex_ui/img/favicons/app-opportunity-tracker-16x16.png"><link rel="icon" sizes="32x32" href="#IMAGE_PRE'
||'FIX#apex_ui/img/favicons/app-opportunity-tracker-32x32.png"><link rel="apple-touch-icon" sizes="180x180" href="#IMAGE_PREFIX#apex_ui/img/favicons/app-opportunity-tracker.png">'
,p_public_user=>'APEX_PUBLIC_USER'
,p_proxy_server=>nvl(wwv_flow_application_install.get_proxy,'')
,p_no_proxy_domains=>nvl(wwv_flow_application_install.get_no_proxy_domains,'')
,p_flow_version=>'3.2.1'
,p_flow_status=>'AVAILABLE_W_EDIT_LINK'
,p_flow_unavailable_text=>'This application is currently unavailable at this time.'
,p_exact_substitutions_only=>'Y'
,p_browser_cache=>'N'
,p_browser_frame=>'S'
,p_deep_linking=>'Y'
,p_runtime_api_usage=>'T'
,p_security_scheme=>wwv_flow_api.id(9042570838363542978)
,p_rejoin_existing_sessions=>'P'
,p_csv_encoding=>'N'
,p_auto_time_zone=>'N'
,p_error_handling_function=>'eba_sales_acl_api.apex_error_handling'
,p_substitution_string_01=>'APP_DATE_FORMAT'
,p_substitution_value_01=>'DD-MON-YYYY'
,p_substitution_string_02=>'GETTING_STARTED_URL'
,p_substitution_value_02=>'http://www.oracle.com/technetwork/developer-tools/apex/index.html'
,p_substitution_string_03=>'APP_NAME'
,p_substitution_value_03=>'Opportunities'
,p_substitution_string_04=>'APP_DATE_TIME_FMT'
,p_substitution_value_04=>'DD-MON-YYYY HH:MI PM'
,p_last_updated_by=>'CBCHO'
,p_last_upd_yyyymmddhh24miss=>'20210413141650'
,p_file_prefix => nvl(wwv_flow_application_install.get_static_app_file_prefix,'')
,p_ui_type_name => null
,p_print_server_type=>'INSTANCE'
);
wwv_flow_api.component_end;
end;
/
