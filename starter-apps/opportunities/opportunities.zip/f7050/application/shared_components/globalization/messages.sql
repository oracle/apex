prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 7050
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7248803954533533610)
,p_name=>'ABOUT_TO_CREATE'
,p_message_text=>'Please confirm adding the following %0 <strong>%1</strong> user(s) to your access control list.'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7293396633192798304)
,p_name=>'ABOUT_TO_CREATE_WITH_INVALIDS'
,p_message_text=>'Please confirm adding the following %0 <strong>%1</strong> user(s) to your access control list. Note that %2 string(s) were invalid usernames.'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(9060307854306387742)
,p_name=>'ACCESS_CONTROL_INFO'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>When Access Control is enabled, Administrators have the ability to restrict access to certain application features, for authenticated users. Opportunities supports the following 3 access levels; Reader, Contributor and Administrator.',
'  <b>Readers</b> have read-only access and can also view reports.',
'  <b>Contributors</b> can create, edit, delete and view reports.',
'  <b>Administrators</b>, in addition to Contributor''s capability, can also perform Opportunities administration, including configuration of access control, managing application look-up data and installing or uninstalling sample data.</p> ',
''))
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7524528345066169297)
,p_name=>'ACCESS_CONTROL_IS_DISABLED'
,p_message_text=>'Access control for this application is currently disabled.  All users are currently Administrators. Navigate to <a href="%0">application administration</a> to enable access control.'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7393234555616093907)
,p_name=>'ACL_DISABLED'
,p_message_text=>'<p>All users are currently <strong>Administrators</strong>. Please enable Access Control to restrict user access to this application.</p>'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7393234328024091479)
,p_name=>'ACL_ENABLED'
,p_message_text=>'<p>Only users defined in the Access Control List have access to this application.</p>'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7393234132337089540)
,p_name=>'ACL_PUBLIC_CONTRIBUTE'
,p_message_text=>'<p>All authenticated users have <strong>Reader</strong> and <strong>Contributor</strong> access.</p><p>Administrators are restricted by the Access Control List.</p>'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7393233936219087681)
,p_name=>'ACL_PUBLIC_READONLY'
,p_message_text=>'<p>All authenticated users have <strong>Reader</strong> access.</p><p>Contributors and Administrators are restricted by the Access Control List.</p>'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(9060308027772389569)
,p_name=>'AC_CONFIGURATION_INFO'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><b>Enabling Access Control</b> means that access to the application and its features are controlled by the current <b>Access Control List</b>, as defined by the application administrator. Opportunities has 3 access levels available that can be gra'
||'nted to a user; Administrator, Contributor and Reader. Please see the Manage Access Control List page for further details on what each level provides.</p>',
'<p>In addition, if you don''t want to have to define every ''Reader'' of your application, you can select <b>Any Authenticated User</b> from the <b>Reader Access</b> configuration option. This opens read-only access to any user who can authenticate into'
||' your application.</p>',
'<br />',
'<p><b>Disabling Access Control</b> means that access to the application and all of its features including Administration are open to any user who can authenticate to the application.</p>',
'<br />',
'<p><em>Note: Whether Access Control is enabled or disabled, a user still has to authenticate successfully into the application.</em></p>'))
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(8664166055200467367)
,p_name=>'ADMINISTRATION'
,p_message_text=>'Administration'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7248804448064536601)
,p_name=>'ALREADY_IN_ACL'
,p_message_text=>'User is already in Access Control List'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7393233740748085605)
,p_name=>'ANY_AUTHENTICATED_USER'
,p_message_text=>'Any Authenticated User'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7393682849876341455)
,p_name=>'AUTHENTICATION_REQUIRED_PAGES'
,p_message_text=>'Login Required Pages'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7248805734046543129)
,p_name=>'BAU_EMAIL_INSTRUCTIONS'
,p_message_text=>'Enter or copy and paste email addresses separated by commas, semicolons, or new lines. Note that if you copy and paste email addresses from email messages, extraneous text will be filtered out. All email users provided will be added as the selected r'
||'ole. Existing or duplicate email addresses will be ignored.'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7248805930164544906)
,p_name=>'BAU_STRING_INSTRUCTIONS'
,p_message_text=>'Enter or copy and paste usernames separated by commas, semicolons, or whitespace. All usernames provided will be added as the selected role. Existing or duplicate usernames will be ignored.'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7248804745260537944)
,p_name=>'DUPLICATE_USER'
,p_message_text=>'Duplicate user in list'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7374077348240736929)
,p_name=>'EMAIL_USERNAME_FORMAT_MSG'
,p_message_text=>'This application is currently using an <strong>email address</strong> username format (e.g. xyz@xyz.com). <a href="f?p=%0:%1:%2:">Change Username Format</a>'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(8664145945849464640)
,p_name=>'HELP'
,p_message_text=>'Help'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7297638350524589811)
,p_name=>'HELP_ABOUT'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="aboutApp">',
'<h2>About this Application</h2>',
'<p>',
'	Manage opportunities, track leads, manage accounts and contacts. Opportunities are organized by territory and account. For each opportunity you can track products, competition, team members, and add hypertext links and file attachments. Use interact'
||'ive reports to slice and dice your sales pipeline. You can upload leads from spreadsheets and convert leads to opportunities.',
'</p>',
'</div>'))
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7297638734780597139)
,p_name=>'HELP_FEATURES'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="textRegion">',
'<h2>Features</h2>',
'<ul>',
'	<li>Track Sales Opportunities</li>',
'	<li>View opportunities by product, territory, sales person</li>',
'	<li>Track and manage leads</li>',
'	<li>Link, Note, and File Attachments</li>',
'	<li>Mobile Interface</li>',
'	<li>Flexible Access Control (reader, contributor, administrator model)</li>',
'	<li>Timezone Support</li>',
'</ul>',
'</div>'))
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7297638543623593074)
,p_name=>'HELP_GETTING_STARTED'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="textRegion">',
'<h2>Getting Started</h2>',
'<p>',
'	1. Create your Team Members',
'</p>',
'<ul>',
'	<li>Click the administration icon (gear icon)</li>',
'	<li>Click Team Members</li>',
'	<li>Add your &REP_TITLE.s</li>',
'</ul>',
'<p>',
'	2. Define your products:',
'</p>',
'<ul>',
'	<li>Click the administration icon (gear icon)</li>',
'	<li>Click Products</li>',
'	<li>Add your products</li>',
'</ul>',
'<p>',
'	2. Define your territories:',
'</p>',
'<ul>',
'	<li>Click the administration icon (gear icon)</li>',
'	<li>Click Territories</li>',
'	<li>Add Territories</li>',
'</ul>',
'<p>',
'	2. Enter your opportunities:',
'</p>',
'<ul>',
'	<li>Navigate to the home page</li>',
'	<li>Click (+) icon in open opportunities region</li>',
'	<li>Follow the wizard to add an opportunity</li>',
'</ul>',
'</div>'))
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7297637927676585250)
,p_name=>'HELP_SIDEBAR'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h1 class="appNameHeader">',
'    <img src="%0f_spacer.gif" class="appIcon %1" alt="" />',
'    %2',
'</h1>',
'<ul class="vapList">',
'    <li>',
'        <span class="vLabel">App Version</span>',
'        <span class="vValue">%3</span>',
'    </li>',
'    <li>',
'        <span class="vLabel">Pages</span>',
'        <span class="vValue">%4</span>',
'    </li>',
'    <li>',
'        <span class="vLabel">Vendor</span>',
'        <span class="vValue">%5 </span>',
'    </li>',
'</ul>'))
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7297638158287586284)
,p_name=>'HELP_SUPPORT'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="textRegion">',
'<h2>Additional Information</h2>',
'<p>If you have questions, ask them on the <a href="%0" target="_blank">%1</a>.',
'</p>',
'</div>'))
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7234588152860347085)
,p_name=>'INFO_TEXT_ADMIN_PRODUCTS'
,p_message_text=>'Products are associated with an opportunities. Define the domain of products available to opportunities here.'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7234578644271305503)
,p_name=>'INFO_TEXT_ADMIN_PRODUCTS_FORM'
,p_message_text=>'Products are associated with an opportunities.  Use this page to identify each product that can be associated with an opportunity.  Products are associated by numeric ID and not by name, so changing a product name will be immediately reflected on all'
||' opportunities, past and present.'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7248804151083535241)
,p_name=>'INVALID_USERS_NOT_CREATED'
,p_message_text=>'Note that %0 string(s) were invalid usernames.'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(8664161952083466461)
,p_name=>'LOGIN'
,p_message_text=>'Login'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(8664150047927465261)
,p_name=>'LOGOUT'
,p_message_text=>'Logout'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7248805339437540589)
,p_name=>'MISSING_AT_SIGN'
,p_message_text=>'Missing @ sign'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7248805537065541695)
,p_name=>'MISSING_DOT'
,p_message_text=>'Missing dot'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(9074840659204990803)
,p_name=>'MOBILE'
,p_message_text=>'Mobile'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7101345156648836547)
,p_name=>'N_DAY'
,p_message_text=>'%0 day'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7101345355138837201)
,p_name=>'N_DAYS'
,p_message_text=>'%0 days'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7101344729487833916)
,p_name=>'N_HOUR'
,p_message_text=>'%0 hour'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7101344927977834621)
,p_name=>'N_HOURS'
,p_message_text=>'%0 hours'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7101344532075832765)
,p_name=>'N_MINUTES'
,p_message_text=>'%0 minutes'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7101345552766838350)
,p_name=>'N_WEEK'
,p_message_text=>'%0 week'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7101345751040839166)
,p_name=>'N_WEEKS'
,p_message_text=>'%0 weeks'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7393682455268338924)
,p_name=>'PAGES_WITH_CUSTOM_AUTH'
,p_message_text=>'Authorization Protected'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7393682652680340135)
,p_name=>'PUBLIC_PAGES'
,p_message_text=>'Public Pages'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(9036081447048910065)
,p_name=>'SEARCH_TERM_BLURB'
,p_message_text=>'Enter a search term and press enter to search accounts, customers and opportunities.'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7384020250555280406)
,p_name=>'STATE.RESTRICTED_CHAR.WEB_SAFE'
,p_message_text=>'%0 contains <, > or " which are invalid characters.'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7374077544358738696)
,p_name=>'STRING_USERNAME_FORMAT_MSG'
,p_message_text=>'This application is currently using a <strong>non-email address</strong> username format (e.g. JOHNDOE). <a href="f?p=%0:%1:%2:">Change Username Format</a>'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7248805142241539266)
,p_name=>'USERNAME_TOO_LONG'
,p_message_text=>'Username too long'
,p_version_scn=>37166093793182
);
wwv_flow_imp.component_end;
end;
/
