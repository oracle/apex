prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 7050
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7231081762572780207)
,p_name=>'ABOUT_TO_CREATE'
,p_message_text=>'Please confirm adding the following %0 <strong>%1</strong> user(s) to your access control list.'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7275674441232044901)
,p_name=>'ABOUT_TO_CREATE_WITH_INVALIDS'
,p_message_text=>'Please confirm adding the following %0 <strong>%1</strong> user(s) to your access control list. Note that %2 string(s) were invalid usernames.'
,p_version_scn=>37166093793182
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(9042585662345634339)
,p_name=>'ACCESS_CONTROL_INFO'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>When Access Control is enabled, Administrators have the ability to restrict access to certain application features, for authenticated users. Opportunities supports the following 3 access levels; Reader, Contributor and Administrator.',
'  <b>Readers</b> have read-only access and can also view reports.',
'  <b>Contributors</b> can create, edit, delete and view reports.',
'  <b>Administrators</b>, in addition to Contributor''s capability, can also perform Opportunities administration, including configuration of access control, managing application look-up data and installing or uninstalling sample data.</p> ',
''))
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7506806153105415894)
,p_name=>'ACCESS_CONTROL_IS_DISABLED'
,p_message_text=>'Access control for this application is currently disabled.  All users are currently Administrators. Navigate to <a href="%0">application administration</a> to enable access control.'
,p_version_scn=>37166093793182
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7375512363655340504)
,p_name=>'ACL_DISABLED'
,p_message_text=>'<p>All users are currently <strong>Administrators</strong>. Please enable Access Control to restrict user access to this application.</p>'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7375512136063338076)
,p_name=>'ACL_ENABLED'
,p_message_text=>'<p>Only users defined in the Access Control List have access to this application.</p>'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7375511940376336137)
,p_name=>'ACL_PUBLIC_CONTRIBUTE'
,p_message_text=>'<p>All authenticated users have <strong>Reader</strong> and <strong>Contributor</strong> access.</p><p>Administrators are restricted by the Access Control List.</p>'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7375511744258334278)
,p_name=>'ACL_PUBLIC_READONLY'
,p_message_text=>'<p>All authenticated users have <strong>Reader</strong> access.</p><p>Contributors and Administrators are restricted by the Access Control List.</p>'
,p_version_scn=>37166093793182
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(9042585835811636166)
,p_name=>'AC_CONFIGURATION_INFO'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><b>Enabling Access Control</b> means that access to the application and its features are controlled by the current <b>Access Control List</b>, as defined by the application administrator. Opportunities has 3 access levels available that can be gra'
||'nted to a user; Administrator, Contributor and Reader. Please see the Manage Access Control List page for further details on what each level provides.</p>',
'<p>In addition, if you don''t want to have to define every ''Reader'' of your application, you can select <b>Any Authenticated User</b> from the <b>Reader Access</b> configuration option. This opens read-only access to any user who can authenticate into'
||' your application.</p>',
'<br />',
'<p><b>Disabling Access Control</b> means that access to the application and all of its features including Administration are open to any user who can authenticate to the application.</p>',
'<br />',
'<p><em>Note: Whether Access Control is enabled or disabled, a user still has to authenticate successfully into the application.</em></p>'))
,p_version_scn=>37166093793182
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(8646443863239713964)
,p_name=>'ADMINISTRATION'
,p_message_text=>'Administration'
,p_version_scn=>37166093793182
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7231082256103783198)
,p_name=>'ALREADY_IN_ACL'
,p_message_text=>'User is already in Access Control List'
,p_version_scn=>37166093793182
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7375511548787332202)
,p_name=>'ANY_AUTHENTICATED_USER'
,p_message_text=>'Any Authenticated User'
,p_version_scn=>37166093793182
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7375960657915588052)
,p_name=>'AUTHENTICATION_REQUIRED_PAGES'
,p_message_text=>'Login Required Pages'
,p_version_scn=>37166093793182
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7231083542085789726)
,p_name=>'BAU_EMAIL_INSTRUCTIONS'
,p_message_text=>'Enter or copy and paste email addresses separated by commas, semicolons, or new lines. Note that if you copy and paste email addresses from email messages, extraneous text will be filtered out. All email users provided will be added as the selected r'
||'ole. Existing or duplicate email addresses will be ignored.'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7231083738203791503)
,p_name=>'BAU_STRING_INSTRUCTIONS'
,p_message_text=>'Enter or copy and paste usernames separated by commas, semicolons, or whitespace. All usernames provided will be added as the selected role. Existing or duplicate usernames will be ignored.'
,p_version_scn=>37166093793182
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7231082553299784541)
,p_name=>'DUPLICATE_USER'
,p_message_text=>'Duplicate user in list'
,p_version_scn=>37166093793182
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7356355156279983526)
,p_name=>'EMAIL_USERNAME_FORMAT_MSG'
,p_message_text=>'This application is currently using an <strong>email address</strong> username format (e.g. xyz@xyz.com). <a href="f?p=%0:%1:%2:">Change Username Format</a>'
,p_version_scn=>37166093793182
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(8646423753888711237)
,p_name=>'HELP'
,p_message_text=>'Help'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7279916158563836408)
,p_name=>'HELP_ABOUT'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="aboutApp">',
'<h2>About this Application</h2>',
'<p>',
'	Manage opportunities, track leads, manage accounts and contacts. Opportunities are organized by territory and account. For each opportunity you can track products, competition, team members, and add hypertext links and file attachments. Use interact'
||'ive reports to slice and dice your sales pipeline. You can upload leads from spreadsheets and convert leads to opportunities.',
'</p>',
'</div>'))
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7279916542819843736)
,p_name=>'HELP_FEATURES'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="textRegion">',
'<h2>Features</h2>',
'<ul>',
'	<li>Track Sales Opportunities</li>',
'	<li>View opportunities by product, territory, sales person</li>',
'	<li>Track and manage leads</li>',
'	<li>Link, Note, and File Attachments</li>',
'	<li>Mobile Interface</li>',
'	<li>Flexible Access Control (reader, contributor, administrator model)</li>',
'	<li>Timezone Support</li>',
'</ul>',
'</div>'))
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7279916351662839671)
,p_name=>'HELP_GETTING_STARTED'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="textRegion">',
'<h2>Getting Started</h2>',
'<p>',
'	1. Create your Team Members',
'</p>',
'<ul>',
'	<li>Click the administration icon (gear icon)</li>',
'	<li>Click Team Members</li>',
'	<li>Add your &REP_TITLE.s</li>',
'</ul>',
'<p>',
'	2. Define your products:',
'</p>',
'<ul>',
'	<li>Click the administration icon (gear icon)</li>',
'	<li>Click Products</li>',
'	<li>Add your products</li>',
'</ul>',
'<p>',
'	2. Define your territories:',
'</p>',
'<ul>',
'	<li>Click the administration icon (gear icon)</li>',
'	<li>Click Territories</li>',
'	<li>Add Territories</li>',
'</ul>',
'<p>',
'	2. Enter your opportunities:',
'</p>',
'<ul>',
'	<li>Navigate to the home page</li>',
'	<li>Click (+) icon in open opportunities region</li>',
'	<li>Follow the wizard to add an opportunity</li>',
'</ul>',
'</div>'))
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7279915735715831847)
,p_name=>'HELP_SIDEBAR'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h1 class="appNameHeader">',
'    <img src="%0f_spacer.gif" class="appIcon %1" alt="" />',
'    %2',
'</h1>',
'<ul class="vapList">',
'    <li>',
'        <span class="vLabel">App Version</span>',
'        <span class="vValue">%3</span>',
'    </li>',
'    <li>',
'        <span class="vLabel">Pages</span>',
'        <span class="vValue">%4</span>',
'    </li>',
'    <li>',
'        <span class="vLabel">Vendor</span>',
'        <span class="vValue">%5 </span>',
'    </li>',
'</ul>'))
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7279915966326832881)
,p_name=>'HELP_SUPPORT'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="textRegion">',
'<h2>Additional Information</h2>',
'<p>If you have questions, ask them on the <a href="%0" target="_blank">%1</a>.',
'</p>',
'</div>'))
,p_version_scn=>37166093793182
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7216865960899593682)
,p_name=>'INFO_TEXT_ADMIN_PRODUCTS'
,p_message_text=>'Products are associated with an opportunities. Define the domain of products available to opportunities here.'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7216856452310552100)
,p_name=>'INFO_TEXT_ADMIN_PRODUCTS_FORM'
,p_message_text=>'Products are associated with an opportunities.  Use this page to identify each product that can be associated with an opportunity.  Products are associated by numeric ID and not by name, so changing a product name will be immediately reflected on all'
||' opportunities, past and present.'
,p_version_scn=>37166093793182
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7231081959122781838)
,p_name=>'INVALID_USERS_NOT_CREATED'
,p_message_text=>'Note that %0 string(s) were invalid usernames.'
,p_version_scn=>37166093793182
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(8646439760122713058)
,p_name=>'LOGIN'
,p_message_text=>'Login'
,p_version_scn=>37166093793182
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(8646427855966711858)
,p_name=>'LOGOUT'
,p_message_text=>'Logout'
,p_version_scn=>37166093793182
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7231083147476787186)
,p_name=>'MISSING_AT_SIGN'
,p_message_text=>'Missing @ sign'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7231083345104788292)
,p_name=>'MISSING_DOT'
,p_message_text=>'Missing dot'
,p_version_scn=>37166093793182
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(9057118467244237400)
,p_name=>'MOBILE'
,p_message_text=>'Mobile'
,p_version_scn=>37166093793182
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7083622964688083144)
,p_name=>'N_DAY'
,p_message_text=>'%0 day'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7083623163178083798)
,p_name=>'N_DAYS'
,p_message_text=>'%0 days'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7083622537527080513)
,p_name=>'N_HOUR'
,p_message_text=>'%0 hour'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7083622736017081218)
,p_name=>'N_HOURS'
,p_message_text=>'%0 hours'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7083622340115079362)
,p_name=>'N_MINUTES'
,p_message_text=>'%0 minutes'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7083623360806084947)
,p_name=>'N_WEEK'
,p_message_text=>'%0 week'
,p_version_scn=>37166093793182
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7083623559080085763)
,p_name=>'N_WEEKS'
,p_message_text=>'%0 weeks'
,p_version_scn=>37166093793182
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7375960263307585521)
,p_name=>'PAGES_WITH_CUSTOM_AUTH'
,p_message_text=>'Authorization Protected'
,p_version_scn=>37166093793182
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7375960460719586732)
,p_name=>'PUBLIC_PAGES'
,p_message_text=>'Public Pages'
,p_version_scn=>37166093793182
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(9018359255088156662)
,p_name=>'SEARCH_TERM_BLURB'
,p_message_text=>'Enter a search term and press enter to search accounts, customers and opportunities.'
,p_version_scn=>37166093793182
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7366298058594527003)
,p_name=>'STATE.RESTRICTED_CHAR.WEB_SAFE'
,p_message_text=>'%0 contains <, > or " which are invalid characters.'
,p_version_scn=>37166093793182
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7356355352397985293)
,p_name=>'STRING_USERNAME_FORMAT_MSG'
,p_message_text=>'This application is currently using a <strong>non-email address</strong> username format (e.g. JOHNDOE). <a href="f?p=%0:%1:%2:">Change Username Format</a>'
,p_version_scn=>37166093793182
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(7231082950280785863)
,p_name=>'USERNAME_TOO_LONG'
,p_message_text=>'Username too long'
,p_version_scn=>37166093793182
);
null;
wwv_flow_imp.component_end;
end;
/
