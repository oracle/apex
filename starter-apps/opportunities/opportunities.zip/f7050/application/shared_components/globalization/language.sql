prompt --application/shared_components/globalization/language
begin
--   Manifest
--     LANGUAGE MAP: 7050
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
null;
wwv_flow_imp.component_end;
end;
/
