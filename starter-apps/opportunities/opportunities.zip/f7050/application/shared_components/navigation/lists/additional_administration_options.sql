prompt --application/shared_components/navigation/lists/additional_administration_options
begin
--   Manifest
--     LIST: Additional Administration Options
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(10266216968140663885)
,p_name=>'Additional Administration Options'
,p_static_id=>'additional-administration-options'
,p_version_scn=>'1089051157'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7699498197562536160)
,p_list_item_display_sequence=>450
,p_list_item_link_text=>'Application Appearance'
,p_static_id=>'application-appearance'
,p_list_item_link_target=>'f?p=&APP_ID.:141:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-desktop'
,p_list_text_01=>'Change user interface color scheme for all users.'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7276980547082635493)
,p_list_item_display_sequence=>435
,p_list_item_link_text=>'Application Error Log'
,p_static_id=>'application-error-log'
,p_list_item_link_target=>'f?p=&APP_ID.:175:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-alert'
,p_list_text_01=>'Report of all internal errors encountered within the application.'
,p_list_text_02=>'reportIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(9019269353576777367)
,p_list_item_display_sequence=>420
,p_list_item_link_text=>'Closed Opportunities'
,p_static_id=>'closed-opportunities'
,p_list_item_link_target=>'f?p=&APP_ID.:81:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Opportunities that are won or lost (0 or 100% probability) cannot be edited. Set the status to something other then 0 or 100% to reenable edit capabilities.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10266218038159663892)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>'Fiscal Quarters'
,p_static_id=>'fiscal-quarters'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar'
,p_list_text_01=>'Manage the fiscal quarters used for reporting.  Companies have different quarter start and end dates, click here to manage those dates.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'12'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7373852235760403181)
,p_list_item_display_sequence=>432
,p_list_item_link_text=>'Rename Application'
,p_static_id=>'rename-application'
,p_list_item_link_target=>'f?p=&APP_ID.:45:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Change the application name, displayed on the top left of each page, to one of your choosing.  By default, the application name is "&APP_NAME.".'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10266218667310663893)
,p_list_item_display_sequence=>400
,p_list_item_link_text=>'Sample Data'
,p_static_id=>'sample-data'
,p_list_item_link_target=>'f?p=&APP_ID.:142:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database'
,p_list_text_01=>'Manage sample data for Accounts, &REP_TITLE.s, Products, Opportunities, Notes and Leads.  Options to remove, install, or re-install.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10268886162502050136)
,p_list_item_display_sequence=>410
,p_list_item_link_text=>'SVPs'
,p_static_id=>'svps'
,p_list_item_link_target=>'f?p=&APP_ID.:66:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-user'
,p_list_text_01=>'Opportunities can be tracked by Senior Vice President (SVP).  Use these pages to define the domain of SVP''s for use within this application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'66'
);
wwv_flow_imp.component_end;
end;
/
