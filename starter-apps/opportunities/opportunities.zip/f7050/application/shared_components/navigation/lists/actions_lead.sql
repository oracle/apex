prompt --application/shared_components/navigation/lists/actions_lead
begin
--   Manifest
--     LIST: Actions - Lead
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(6629035122780983304)
,p_name=>'Actions - Lead'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089051157
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6629035406986990788)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Add Link'
,p_list_item_link_target=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:114:P114_ENTITY_TYPE,P114_ENTITY_ID:LEAD,&P133_ID.:'
,p_list_item_icon=>'fa-link'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6636434141683445370)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Add Attachment'
,p_list_item_link_target=>'f?p=&APP_ID.:99:&SESSION.::&DEBUG.:99:P99_ENTITY_TYPE,P99_ENTITY_ID:LEAD,&P133_ID.:'
,p_list_item_icon=>'fa-paperclip'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6646877873724282700)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Add Comment'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:22:P22_ENTITY_TYPE,P22_ENTITY_ID:LEAD,&P133_ID.:'
,p_list_item_icon=>'fa-comment-o'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
