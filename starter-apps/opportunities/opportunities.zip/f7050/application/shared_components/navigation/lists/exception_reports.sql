prompt --application/shared_components/navigation/lists/exception_reports
begin
--   Manifest
--     LIST: Exception Reports
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(10268871462127822998)
,p_name=>'Exception Reports'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089051157
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10268871666150822998)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Opportunities with No Products'
,p_list_item_link_target=>'f?p=&APP_ID.:129:&SESSION.::&DEBUG.:129,RIR:::'
,p_list_item_icon=>'fa-file-text'
,p_list_text_01=>'Interactive report identifying opportunities that do not specify any products.'
,p_required_patch=>wwv_flow_imp.id(10514207977421756031)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7375490757545388051)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Opportunities Past Due'
,p_list_item_link_target=>'f?p=&APP_ID.:131:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-file-text'
,p_list_text_01=>'Interactive report of all opportunities open but with a close date in the past.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7375498954692450201)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Accounts with No Territory'
,p_list_item_link_target=>'f?p=&APP_ID.:132:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-file-text'
,p_list_text_01=>'Interactive report of all accounts with no territory specified.'
,p_required_patch=>wwv_flow_imp.id(10513861890095974398)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
