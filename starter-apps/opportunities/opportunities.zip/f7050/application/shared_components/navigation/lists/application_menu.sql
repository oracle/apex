prompt --application/shared_components/navigation/lists/application_menu
begin
--   Manifest
--     LIST: Application Menu
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-13'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(7343993389165094905)
,p_name=>'Application Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7343993527276094908)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'43,100,128,148'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7343994208122094910)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Leads [&LEADS.]'
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-crosshairs'
,p_required_patch=>wwv_flow_api.id(7401034857403255410)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'29,133,138,19'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7343993801526094910)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Opportunities [&DEALS.]'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-briefcase'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'1,80,85,86,87'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(8235758514674817653)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'By &REP_TITLE_RAW.'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:RP:::'
,p_parent_list_item_id=>wwv_flow_api.id(7343993801526094910)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(6569671411461416684)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'By Competitor'
,p_list_item_link_target=>'f?p=&APP_ID.:134:&SESSION.::&DEBUG.:RP:::'
,p_parent_list_item_id=>wwv_flow_api.id(7343993801526094910)
,p_required_patch=>wwv_flow_api.id(7401040659522300015)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(8235761594504838257)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'By Product'
,p_list_item_link_target=>'f?p=&APP_ID.:135:&SESSION.::&DEBUG.:RP:::'
,p_parent_list_item_id=>wwv_flow_api.id(7343993801526094910)
,p_required_patch=>wwv_flow_api.id(10496485785461002628)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(8236259597392447136)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'By Territory'
,p_list_item_link_target=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:RP:::'
,p_parent_list_item_id=>wwv_flow_api.id(7343993801526094910)
,p_required_patch=>wwv_flow_api.id(10496139698135220995)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7343993566158094910)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Territories [&TERRITORIES.]'
,p_list_item_link_target=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-globe'
,p_required_patch=>wwv_flow_api.id(10496139698135220995)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'50,93,123,125'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7343993671575094910)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Accounts [&CUSTOMERS.]'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-users'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2,94,98,105,107,127,130'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7343993842889094910)
,p_list_item_display_sequence=>55
,p_list_item_link_text=>'Contacts [&CONTACTS.]'
,p_list_item_link_target=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user'
,p_required_patch=>wwv_flow_api.id(10496478296281986809)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'23,24'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7343993938213094910)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Products [&PRODUCTS.]'
,p_list_item_link_target=>'f?p=&APP_ID.:68:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-archive'
,p_required_patch=>wwv_flow_api.id(10496485785461002628)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'68,61'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7343994292460094910)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Reports'
,p_list_item_link_target=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'14,20,39,46,47,48,49,62,90,91,121,129,131,132,139'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7344679678379593715)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Administration'
,p_list_item_link_target=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-gear'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10,13,12,18,17,26,25,33,11,44,43,37,38,8,9,6,7,4,5,33,54,53,56,55,57,60,59,65,64,67,66,70,69,51,77,78,81,96,83,104,109,110,112,111,116,113,115,119,82,210,211,212,213,43,128,44,109,104,110,175,175,15,153,154,45,141,142,28,35,40,35,36,58,84,103,118,136'
||',144'
);
wwv_flow_api.component_end;
end;
/
