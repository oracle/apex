prompt --application/shared_components/navigation/lists/application_menu
begin
--   Manifest
--     LIST: Application Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(7361715581125848308)
,p_name=>'Application Menu'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089051157
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7361715719236848311)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'43,100,128,148'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7361716400082848313)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Leads [&LEADS.]'
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-crosshairs'
,p_required_patch=>wwv_flow_imp.id(7418757049364008813)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'29,133,138,19'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7361715993486848313)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Opportunities [&DEALS.]'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-briefcase'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'1,80,85,86,87'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8253480706635571056)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'By &REP_TITLE_RAW.'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:RP:::'
,p_parent_list_item_id=>wwv_flow_imp.id(7361715993486848313)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6587393603422170087)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'By Competitor'
,p_list_item_link_target=>'f?p=&APP_ID.:134:&SESSION.::&DEBUG.:RP:::'
,p_parent_list_item_id=>wwv_flow_imp.id(7361715993486848313)
,p_required_patch=>wwv_flow_imp.id(7418762851483053418)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8253483786465591660)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'By Product'
,p_list_item_link_target=>'f?p=&APP_ID.:135:&SESSION.::&DEBUG.:RP:::'
,p_parent_list_item_id=>wwv_flow_imp.id(7361715993486848313)
,p_required_patch=>wwv_flow_imp.id(10514207977421756031)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8253981789353200539)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'By Territory'
,p_list_item_link_target=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:RP:::'
,p_parent_list_item_id=>wwv_flow_imp.id(7361715993486848313)
,p_required_patch=>wwv_flow_imp.id(10513861890095974398)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7361715758118848313)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Territories [&TERRITORIES.]'
,p_list_item_link_target=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-globe'
,p_required_patch=>wwv_flow_imp.id(10513861890095974398)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'50,93,123,125'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7361715863535848313)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Accounts [&CUSTOMERS.]'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-users'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2,94,98,105,107,127,130'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7361716034849848313)
,p_list_item_display_sequence=>55
,p_list_item_link_text=>'Contacts [&CONTACTS.]'
,p_list_item_link_target=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user'
,p_required_patch=>wwv_flow_imp.id(10514200488242740212)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'23,24'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7361716130173848313)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Products [&PRODUCTS.]'
,p_list_item_link_target=>'f?p=&APP_ID.:68:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-archive'
,p_required_patch=>wwv_flow_imp.id(10514207977421756031)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'68,61'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7361716484420848313)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Reports'
,p_list_item_link_target=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'14,20,39,46,47,48,49,62,90,91,121,129,131,132,139'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7362401870340347118)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Administration'
,p_list_item_link_target=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-gear'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10,13,12,18,17,26,25,33,11,44,43,37,38,8,9,6,7,4,5,33,54,53,56,55,57,60,59,65,64,67,66,70,69,51,77,78,81,96,83,104,109,110,112,111,116,113,115,119,82,210,211,212,213,43,128,44,109,104,110,175,175,15,153,154,45,141,142,28,35,40,35,36,58,84,103,118,136'
||',144'
);
wwv_flow_imp.component_end;
end;
/
