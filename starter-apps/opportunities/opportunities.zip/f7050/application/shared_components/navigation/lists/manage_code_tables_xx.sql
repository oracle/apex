prompt --application/shared_components/navigation/lists/manage_code_tables_xx
begin
--   Manifest
--     LIST: Manage Code Tables XX
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(10206213948860369430)
,p_name=>'Manage Code Tables XX'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089051157
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6121798909113642754)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Agreements'
,p_list_item_link_target=>'f?p=&APP_ID.:84:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-handshake-o'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select null from eba_sales_agreement_types;'
,p_list_text_01=>'Manage the agreements that will be used throughout the application.'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_required_patch=>wwv_flow_imp.id(6116102906450391758)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6119092896097230794)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Agreement Types'
,p_list_item_link_target=>'f?p=&APP_ID.:58:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-handshake-o'
,p_list_text_01=>'Manage the various agreement types that will be used throughout the application.'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_required_patch=>wwv_flow_imp.id(6116102906450391758)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10265837653438723019)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Competitor Threats'
,p_list_item_link_target=>'f?p=&APP_ID.:59:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Competitor Threats that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_required_patch=>wwv_flow_imp.id(7418762851483053418)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10268842941687391336)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Countries'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Countries that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(9030612152063410837)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Currencies'
,p_list_item_link_target=>'f?p=&APP_ID.:111:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Currencies that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10265831444995711109)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Financial Assessments'
,p_list_item_link_target=>'f?p=&APP_ID.:57:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Financial Assessments that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10268842661857378215)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Industries'
,p_list_item_link_target=>'f?p=&APP_ID.:64:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Industries that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10269192938625544728)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Lead Sources'
,p_list_item_link_target=>'f?p=&APP_ID.:69:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Lead Sources that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10206393666399140842)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Lead Status Codes'
,p_list_item_link_target=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Lead Status Codes that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10268845845412411326)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Opportunity Stages'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Opportunity Stages that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10265818739885690723)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Risk Assessments'
,p_list_item_link_target=>'f?p=&APP_ID.:53:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Risk Assessments that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10266222659923718345)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Team Roles'
,p_list_item_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Team Roles that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(9023256039414493927)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'States'
,p_list_item_link_target=>'f?p=&APP_ID.:83:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of States that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10265825043133701182)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Status Assessments'
,p_list_item_link_target=>'f?p=&APP_ID.:55:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Status Assessments that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8468901491529541239)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Support Amount Types'
,p_list_item_link_target=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-money'
,p_list_text_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Manage the support amount types that will be used throughout the application.',
''))
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_required_patch=>wwv_flow_imp.id(8468901833586544711)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8468926035556143633)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Support Amounts'
,p_list_item_link_target=>'f?p=&APP_ID.:118:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-money'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select null from eba_sales_suprt_amt_types;'
,p_list_text_01=>'Manage the support amounts that will be used throughout the application.'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_required_patch=>wwv_flow_imp.id(8468901833586544711)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
