prompt --application/shared_components/navigation/lists/manage_code_tables_xx
begin
--   Manifest
--     LIST: Manage Code Tables XX
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(10188491756899616027)
,p_name=>'Manage Code Tables XX'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(6104076717152889351)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Agreements'
,p_list_item_link_target=>'f?p=&APP_ID.:84:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-handshake-o'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select null from eba_sales_agreement_types;'
,p_list_text_01=>'Manage the agreements that will be used throughout the application.'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_required_patch=>wwv_flow_api.id(6098380714489638355)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(6101370704136477391)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Agreement Types'
,p_list_item_link_target=>'f?p=&APP_ID.:58:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-handshake-o'
,p_list_text_01=>'Manage the various agreement types that will be used throughout the application.'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_required_patch=>wwv_flow_api.id(6098380714489638355)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10248115461477969616)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Competitor Threats'
,p_list_item_link_target=>'f?p=&APP_ID.:59:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Competitor Threats that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_required_patch=>wwv_flow_api.id(7401040659522300015)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10251120749726637933)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Countries'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Countries that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(9012889960102657434)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Currencies'
,p_list_item_link_target=>'f?p=&APP_ID.:111:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Currencies that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10248109253034957706)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Financial Assessments'
,p_list_item_link_target=>'f?p=&APP_ID.:57:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Financial Assessments that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10251120469896624812)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Industries'
,p_list_item_link_target=>'f?p=&APP_ID.:64:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Industries that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10251470746664791325)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Lead Sources'
,p_list_item_link_target=>'f?p=&APP_ID.:69:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Lead Sources that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10188671474438387439)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Lead Status Codes'
,p_list_item_link_target=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Lead Status Codes that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10251123653451657923)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Opportunity Stages'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Opportunity Stages that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10248096547924937320)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Risk Assessments'
,p_list_item_link_target=>'f?p=&APP_ID.:53:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Risk Assessments that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10248500467962964942)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Team Roles'
,p_list_item_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Team Roles that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(9005533847453740524)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'States'
,p_list_item_link_target=>'f?p=&APP_ID.:83:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of States that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10248102851172947779)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Status Assessments'
,p_list_item_link_target=>'f?p=&APP_ID.:55:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-pencil'
,p_list_text_01=>'Manage the list of Status Assessments that will be available to end-users for selection in the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(8451179299568787836)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Support Amount Types'
,p_list_item_link_target=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-money'
,p_list_text_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Manage the support amount types that will be used throughout the application.',
''))
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_required_patch=>wwv_flow_api.id(8451179641625791308)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(8451203843595390230)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Support Amounts'
,p_list_item_link_target=>'f?p=&APP_ID.:118:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-money'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>'select null from eba_sales_suprt_amt_types;'
,p_list_text_01=>'Manage the support amounts that will be used throughout the application.'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_required_patch=>wwv_flow_api.id(8451179641625791308)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
