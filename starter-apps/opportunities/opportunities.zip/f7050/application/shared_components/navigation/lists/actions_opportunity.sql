prompt --application/shared_components/navigation/lists/actions_opportunity
begin
--   Manifest
--     LIST: Actions - Opportunity
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(6581178665957427082)
,p_name=>'Actions - Opportunity'
,p_static_id=>'actions-opportunity'
,p_version_scn=>'1089051157'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6581185796415499887)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Add Attachment'
,p_static_id=>'add-attachment'
,p_list_item_link_target=>'f?p=&APP_ID.:99:&SESSION.::&DEBUG.:99:P99_ENTITY_TYPE,P99_ENTITY_ID:OPPORTUNITY,&P80_ID.:'
,p_list_item_icon=>'fa-paperclip'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6581180096157427085)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Add Comment'
,p_static_id=>'add-comment'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:22:P22_ENTITY_TYPE,P22_ENTITY_ID:OPPORTUNITY,&P80_ID.:'
,p_list_item_icon=>'fa-comment-o'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6581179273457427084)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Add Competition'
,p_static_id=>'add-competition'
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:27:P27_DEAL_ID:&P80_ID.:'
,p_list_item_icon=>'fa-user-plus'
,p_required_patch=>wwv_flow_imp.id(7418762851483053418)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6581180472184427085)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Add Link'
,p_static_id=>'add-link'
,p_list_item_link_target=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:114:P114_ENTITY_TYPE,P114_ENTITY_ID:OPPORTUNITY,&P80_ID.:'
,p_list_item_icon=>'fa-link'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6581178879314427083)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Add Product'
,p_static_id=>'add-product'
,p_list_item_link_target=>'f?p=&APP_ID.:108:&SESSION.::&DEBUG.:108:P108_DEAL_ID:&P80_ID.:'
,p_list_item_icon=>'fa-archive'
,p_required_patch=>wwv_flow_imp.id(10514207977421756031)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6581179655726427084)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Add Team Member'
,p_static_id=>'add-team-member'
,p_list_item_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:30:P30_DEAL_ID:&P80_ID.:'
,p_list_item_icon=>'fa-user-plus'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
