prompt --application/shared_components/navigation/lists/upload_data
begin
--   Manifest
--     LIST: upload data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(10251124265488680377)
,p_name=>'upload data'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(9046600165054961947)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Opportunities'
,p_list_item_link_target=>'f?p=&APP_ID.:210:&SESSION.::&DEBUG.:210,211,212,213:::'
,p_list_item_icon=>'fa-upload'
,p_list_text_01=>'Upload opportunities from a spreadsheet'
,p_security_scheme=>wwv_flow_imp.id(9042570640734542978)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8466862002128252273)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Accounts'
,p_list_item_link_target=>'f?p=&APP_ID.:136:&SESSION.::&DEBUG.:136,137,140,143:::'
,p_list_item_icon=>'fa-upload'
,p_list_text_01=>'Upload accounts from a spreadsheet'
,p_security_scheme=>wwv_flow_imp.id(9042570640734542978)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
