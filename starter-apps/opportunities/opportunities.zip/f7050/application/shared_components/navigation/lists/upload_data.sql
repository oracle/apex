prompt --application/shared_components/navigation/lists/upload_data
begin
--   Manifest
--     LIST: upload data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(10268846457449433780)
,p_name=>'upload data'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089051157
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(9064322357015715350)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Opportunities'
,p_list_item_link_target=>'f?p=&APP_ID.:210:&SESSION.::&DEBUG.:210,211,212,213:::'
,p_list_item_icon=>'fa-upload'
,p_list_text_01=>'Upload opportunities from a spreadsheet'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8484584194089005676)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Accounts'
,p_list_item_link_target=>'f?p=&APP_ID.:136:&SESSION.::&DEBUG.:136,137,140,143:::'
,p_list_item_icon=>'fa-upload'
,p_list_text_01=>'Upload accounts from a spreadsheet'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
