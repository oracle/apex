prompt --application/shared_components/navigation/lists/actions_territory
begin
--   Manifest
--     LIST: Actions - Territory
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(6426278390041808138)
,p_name=>'Actions - Territory'
,p_static_id=>'actions-territory'
,p_version_scn=>'1089051157'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6654177089330296011)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Add Attachment'
,p_static_id=>'add-attachment'
,p_list_item_link_target=>'f?p=&APP_ID.:99:&SESSION.::&DEBUG.:99:P99_ENTITY_TYPE,P99_ENTITY_ID:TERRITORY,&P93_ID.:'
,p_list_item_icon=>'fa-paperclip'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6668274656011628487)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Add Comment'
,p_static_id=>'add-comment'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:22:P22_ENTITY_TYPE,P22_ENTITY_ID:TERRITORY,&P93_ID.:'
,p_list_item_icon=>'fa-comment-o'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6426278953735808142)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Add Country'
,p_static_id=>'add-country'
,p_list_item_link_target=>'f?p=&APP_ID.:124:&SESSION.::&DEBUG.:124:P124_TERRITORY_ID:&P93_ID.:'
,p_list_item_icon=>'fa-map-pin'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6646735081285545115)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Add Link'
,p_static_id=>'add-link'
,p_list_item_link_target=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:114:P114_ENTITY_TYPE,P114_ENTITY_ID:TERRITORY,&P93_ID.:'
,p_list_item_icon=>'fa-link'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6426279329094808142)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Add State'
,p_static_id=>'add-state'
,p_list_item_link_target=>'f?p=&APP_ID.:126:&SESSION.::&DEBUG.:126:P126_TERRITORY_ID:&P93_ID.:'
,p_list_item_icon=>'fa-map-pin'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
