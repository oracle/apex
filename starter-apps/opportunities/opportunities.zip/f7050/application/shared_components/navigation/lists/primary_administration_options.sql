prompt --application/shared_components/navigation/lists/primary_administration_options
begin
--   Manifest
--     LIST: Primary Administration Options
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(10235697054632910247)
,p_name=>'Primary Administration Options'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10235697850131910248)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'&REP_TITLE.s'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user'
,p_list_text_01=>'Manage all &REP_TITLE.s.  Identify name, email, and role.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'7'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(6442423001685110184)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Lines of Business'
,p_list_item_link_target=>'f?p=&APP_ID.:144:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-building-o'
,p_list_text_01=>'Manage the lines of businesses that can be assigned to product families.'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_required_patch=>wwv_flow_api.id(10496485785461002628)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(6978426343894749939)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Product Families'
,p_list_item_link_target=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-object-group'
,p_list_text_01=>'Manage the domain of product families available within this application. Opportunities can identify one or more products, each potentially belonging to a product family. This facilitates opportunity tracking by product and product family.'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_required_patch=>wwv_flow_api.id(10496485785461002628)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10235698460707910248)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Products'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-archive'
,p_list_text_01=>'Manage the domain of products available within this application.  Opportunities can identify one or more products.  This facilitates opportunity tracking by product.'
,p_list_text_02=>'formIcon'
,p_list_text_03=>'Manage'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_required_patch=>wwv_flow_api.id(10496485785461002628)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10235699064048910249)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Territories'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-globe'
,p_list_text_01=>'Accounts are organized into territories.  Each account must be in one and only one territory.  Territory''s facilitate reporting and organization of opportunities.'
,p_list_text_02=>'formIcon'
,p_list_text_03=>'Manage'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_required_patch=>wwv_flow_api.id(10496139698135220995)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10248501355888989826)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Competitors'
,p_list_item_link_target=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-bullseye'
,p_list_text_01=>'Manage a list of competitors.  Manage the domain of competitors available to be identified by opportunities.'
,p_list_text_02=>'formIcon'
,p_list_text_03=>'Manage'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_required_patch=>wwv_flow_api.id(7401040659522300015)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(6995028219706729818)
,p_list_item_display_sequence=>51
,p_list_item_link_text=>'Contract Terms'
,p_list_item_link_target=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-clock-o'
,p_list_text_01=>'Manage the various contract terms that are used throughout the application. This facilitates opportunity tracking by contract term.'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(8793937265054001907)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Notifications'
,p_list_item_link_target=>'f?p=&APP_ID.:77:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-comment-o'
,p_list_text_01=>'Manage notifications which are displayed on this applications home page.  Use notifications to communicate important information to users of this application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7219544147618447862)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Build Options'
,p_list_item_link_target=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-bell-o'
,p_list_text_01=>'Enable and disable various features and functionality within the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7523089979646055172)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Application Preferences'
,p_list_item_link_target=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.:35:::'
,p_list_item_icon=>'fa-heart-o'
,p_list_text_01=>'Manage your application''s preferences. Set the title text used to describe representatives in your line of business.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
