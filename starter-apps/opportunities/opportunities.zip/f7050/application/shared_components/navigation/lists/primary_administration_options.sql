prompt --application/shared_components/navigation/lists/primary_administration_options
begin
--   Manifest
--     LIST: Primary Administration Options
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(10253419246593663650)
,p_name=>'Primary Administration Options'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089051157
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10253420042092663651)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'&REP_TITLE.s'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user'
,p_list_text_01=>'Manage all &REP_TITLE.s.  Identify name, email, and role.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'7'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6460145193645863587)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Lines of Business'
,p_list_item_link_target=>'f?p=&APP_ID.:144:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-building-o'
,p_list_text_01=>'Manage the lines of businesses that can be assigned to product families.'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_required_patch=>wwv_flow_imp.id(10514207977421756031)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6996148535855503342)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Product Families'
,p_list_item_link_target=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-object-group'
,p_list_text_01=>'Manage the domain of product families available within this application. Opportunities can identify one or more products, each potentially belonging to a product family. This facilitates opportunity tracking by product and product family.'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_required_patch=>wwv_flow_imp.id(10514207977421756031)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10253420652668663651)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Products'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-archive'
,p_list_text_01=>'Manage the domain of products available within this application.  Opportunities can identify one or more products.  This facilitates opportunity tracking by product.'
,p_list_text_02=>'formIcon'
,p_list_text_03=>'Manage'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_required_patch=>wwv_flow_imp.id(10514207977421756031)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10253421256009663652)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Territories'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-globe'
,p_list_text_01=>'Accounts are organized into territories.  Each account must be in one and only one territory.  Territory''s facilitate reporting and organization of opportunities.'
,p_list_text_02=>'formIcon'
,p_list_text_03=>'Manage'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_required_patch=>wwv_flow_imp.id(10513861890095974398)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10266223547849743229)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Competitors'
,p_list_item_link_target=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-bullseye'
,p_list_text_01=>'Manage a list of competitors.  Manage the domain of competitors available to be identified by opportunities.'
,p_list_text_02=>'formIcon'
,p_list_text_03=>'Manage'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_required_patch=>wwv_flow_imp.id(7418762851483053418)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7012750411667483221)
,p_list_item_display_sequence=>51
,p_list_item_link_text=>'Contract Terms'
,p_list_item_link_target=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-clock-o'
,p_list_text_01=>'Manage the various contract terms that are used throughout the application. This facilitates opportunity tracking by contract term.'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8811659457014755310)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Notifications'
,p_list_item_link_target=>'f?p=&APP_ID.:77:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-comment-o'
,p_list_text_01=>'Manage notifications which are displayed on this applications home page.  Use notifications to communicate important information to users of this application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7237266339579201265)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Build Options'
,p_list_item_link_target=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-bell-o'
,p_list_text_01=>'Enable and disable various features and functionality within the application.'
,p_list_text_02=>'formIcon'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7540812171606808575)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Application Preferences'
,p_list_item_link_target=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.:35:::'
,p_list_item_icon=>'fa-heart-o'
,p_list_text_01=>'Manage your application''s preferences. Set the title text used to describe representatives in your line of business.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
