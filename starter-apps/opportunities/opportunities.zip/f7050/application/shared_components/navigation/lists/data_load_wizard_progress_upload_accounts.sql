prompt --application/shared_components/navigation/lists/data_load_wizard_progress_upload_accounts
begin
--   Manifest
--     LIST: Data Load Wizard Progress - Upload Accounts
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(8484490553780979431)
,p_name=>'Data Load Wizard Progress - Upload Accounts'
,p_static_id=>'data-load-wizard-progress-upload-accounts'
,p_version_scn=>'1089051157'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8484492192739979433)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Data Load Results'
,p_static_id=>'data-load-results'
,p_list_item_link_target=>'f?p=&APP_ID.:143:&SESSION.::&DEBUG.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8484490989390979431)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Data Load Source'
,p_static_id=>'data-load-source'
,p_list_item_link_target=>'f?p=&APP_ID.:136:&SESSION.::&DEBUG.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8484491382762979433)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Data / Table Mapping'
,p_static_id=>'data-table-mapping'
,p_list_item_link_target=>'f?p=&APP_ID.:137:&SESSION.::&DEBUG.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8484491756596979433)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Data Validation'
,p_static_id=>'data-validation'
,p_list_item_link_target=>'f?p=&APP_ID.:140:&SESSION.::&DEBUG.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
