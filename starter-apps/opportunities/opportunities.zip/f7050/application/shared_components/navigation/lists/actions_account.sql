prompt --application/shared_components/navigation/lists/actions_account
begin
--   Manifest
--     LIST: Actions - Account
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(6563970729300657572)
,p_name=>'Actions - Account'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(6563970903409657574)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Add Contact'
,p_list_item_link_target=>'f?p=&APP_ID.:106:&SESSION.::&DEBUG.:106:P106_CUSTOMER_ID,P106_SHOW_ACCOUNT:&P94_ID.,N:'
,p_list_item_icon=>'fa-phone'
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
,p_required_patch=>wwv_flow_api.id(10496478296281986809)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(6563971708297657575)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Add Competition'
,p_list_item_link_target=>'f?p=&APP_ID.:145:&SESSION.::&DEBUG.:145:P145_CUSTOMER_ID:&P94_ID.:'
,p_list_item_icon=>'fa-user-plus'
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
,p_required_patch=>wwv_flow_api.id(7401040659522300015)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(6563972131033657576)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Add Location'
,p_list_item_link_target=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:32:P32_CUSTOMER_ID:&P94_ID.:'
,p_list_item_icon=>'fa-map-marker'
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
,p_required_patch=>wwv_flow_api.id(8456035888906321075)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(6118264431737337403)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Add Agreement'
,p_list_item_link_target=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:102:P102_CUSTOMER_ID:&P94_ID.:'
,p_list_item_icon=>'fa-handshake-o'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from apex_application_build_options bo',
'where application_id = :APP_ID',
'  and build_option_name = ''Agreements''',
'  and build_option_status = ''Include''',
'  and (select count(*) from EBA_SALES_AGREEMENTS) > 0'))
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
,p_required_patch=>wwv_flow_api.id(6098380714489638355)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(8451257118848648004)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Add Support Amount'
,p_list_item_link_target=>'f?p=&APP_ID.:122:&SESSION.::&DEBUG.:122:P122_CUSTOMER_ID:&P94_ID.:'
,p_list_item_icon=>'fa-money'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from apex_application_build_options bo',
'where application_id = :APP_ID',
'  and build_option_name = ''Support Amounts''',
'  and build_option_status = ''Include''',
'  and (select count(*) from EBA_SALES_SUPPORT_AMTS) > 0'))
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
,p_required_patch=>wwv_flow_api.id(8451179641625791308)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(6563972467992657576)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Add Link'
,p_list_item_link_target=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:114:P114_ENTITY_TYPE,P114_ENTITY_ID:ACCOUNT,&P94_ID.:'
,p_list_item_icon=>'fa-link'
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(6563972889913657576)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Add Attachment'
,p_list_item_link_target=>'f?p=&APP_ID.:99:&SESSION.::&DEBUG.:99:P99_ENTITY_TYPE,P99_ENTITY_ID:ACCOUNT,&P94_ID.:'
,p_list_item_icon=>'fa-paperclip'
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(6563971253249657575)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Add Comment'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:22:P22_ENTITY_TYPE,P22_ENTITY_ID:ACCOUNT,&P94_ID.:'
,p_list_item_icon=>'fa-comment-o'
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
