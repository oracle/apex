prompt --application/shared_components/navigation/lists/actions_account
begin
--   Manifest
--     LIST: Actions - Account
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(6581692921261410975)
,p_name=>'Actions - Account'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089051157
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6581693095370410977)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Add Contact'
,p_list_item_link_target=>'f?p=&APP_ID.:106:&SESSION.::&DEBUG.:106:P106_CUSTOMER_ID,P106_SHOW_ACCOUNT:&P94_ID.,N:'
,p_list_item_icon=>'fa-phone'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
,p_required_patch=>wwv_flow_imp.id(10514200488242740212)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6581693900258410978)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Add Competition'
,p_list_item_link_target=>'f?p=&APP_ID.:145:&SESSION.::&DEBUG.:145:P145_CUSTOMER_ID:&P94_ID.:'
,p_list_item_icon=>'fa-user-plus'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
,p_required_patch=>wwv_flow_imp.id(7418762851483053418)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6581694322994410979)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Add Location'
,p_list_item_link_target=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:32:P32_CUSTOMER_ID:&P94_ID.:'
,p_list_item_icon=>'fa-map-marker'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
,p_required_patch=>wwv_flow_imp.id(8473758080867074478)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6135986623698090806)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Add Agreement'
,p_list_item_link_target=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:102:P102_CUSTOMER_ID:&P94_ID.:'
,p_list_item_icon=>'fa-handshake-o'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from apex_application_build_options bo',
'where application_id = :APP_ID',
'  and build_option_name = ''Agreements''',
'  and build_option_status = ''Include''',
'  and (select count(*) from EBA_SALES_AGREEMENTS) > 0'))
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
,p_required_patch=>wwv_flow_imp.id(6116102906450391758)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8468979310809401407)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Add Support Amount'
,p_list_item_link_target=>'f?p=&APP_ID.:122:&SESSION.::&DEBUG.:122:P122_CUSTOMER_ID:&P94_ID.:'
,p_list_item_icon=>'fa-money'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from apex_application_build_options bo',
'where application_id = :APP_ID',
'  and build_option_name = ''Support Amounts''',
'  and build_option_status = ''Include''',
'  and (select count(*) from EBA_SALES_SUPPORT_AMTS) > 0'))
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
,p_required_patch=>wwv_flow_imp.id(8468901833586544711)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6581694659953410979)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Add Link'
,p_list_item_link_target=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:114:P114_ENTITY_TYPE,P114_ENTITY_ID:ACCOUNT,&P94_ID.:'
,p_list_item_icon=>'fa-link'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6581695081874410979)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Add Attachment'
,p_list_item_link_target=>'f?p=&APP_ID.:99:&SESSION.::&DEBUG.:99:P99_ENTITY_TYPE,P99_ENTITY_ID:ACCOUNT,&P94_ID.:'
,p_list_item_icon=>'fa-paperclip'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6581693445210410978)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Add Comment'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:22:P22_ENTITY_TYPE,P22_ENTITY_ID:ACCOUNT,&P94_ID.:'
,p_list_item_icon=>'fa-comment-o'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
