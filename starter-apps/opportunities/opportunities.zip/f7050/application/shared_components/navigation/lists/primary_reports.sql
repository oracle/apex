prompt --application/shared_components/navigation/lists/primary_reports
begin
--   Manifest
--     LIST: Primary Reports
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(10253189465668546191)
,p_name=>'Primary Reports'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089051157
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10265850136655831755)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Opportunity Pipeline'
,p_list_item_link_target=>'f?p=&APP_ID.:62:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-text'
,p_list_text_01=>'Opportunity analysis by sales stage.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10253190265034546196)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Opportunities About to Close'
,p_list_item_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-dollar'
,p_list_text_01=>'Identifies opportunities that are past due, or about to become past due.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10253190538815546199)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Revenue by Quarter'
,p_list_item_link_target=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar'
,p_list_text_01=>'Vertical bar chart showing sales forcast by quarter for a user definable reporting period.  '
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6587391026445113933)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Competitor Analysis'
,p_list_item_link_target=>'f?p=&APP_ID.:49:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bullseye'
,p_list_text_01=>'View opportunity counts organized by Competitor, Quarter, and Status.'
,p_required_patch=>wwv_flow_imp.id(7418762851483053418)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
