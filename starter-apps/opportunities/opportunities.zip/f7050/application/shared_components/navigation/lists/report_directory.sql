prompt --application/shared_components/navigation/lists/report_directory
begin
--   Manifest
--     LIST: report directory
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-13'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(10188768170545105315)
,p_name=>'report directory'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10176933868968419313)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Revenue by &REP_TITLE.'
,p_list_item_link_target=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-area-chart'
,p_list_text_01=>'Chart showing revenue by &REP_TITLE..'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(7357611056864633036)
,p_list_item_display_sequence=>41
,p_list_item_link_text=>'Potential Revenue by &REP_TITLE.'
,p_list_item_link_target=>'f?p=&APP_ID.:121:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-area-chart'
,p_list_text_01=>'Chart showing potential revenue by &REP_TITLE..'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10176934275548421182)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Projected Close Dates'
,p_list_item_link_target=>'f?p=&APP_ID.:47:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar'
,p_list_text_01=>'Calendar of projected opportunity close dates.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(10236006058642743703)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Tags'
,p_list_item_link_target=>'f?p=&APP_ID.:48:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-tag'
,p_list_text_01=>'Tags with click through to tag references.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_api.component_end;
end;
/
