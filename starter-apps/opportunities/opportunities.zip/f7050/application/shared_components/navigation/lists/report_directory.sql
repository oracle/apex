prompt --application/shared_components/navigation/lists/report_directory
begin
--   Manifest
--     LIST: report directory
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(10206490362505858718)
,p_name=>'report directory'
,p_static_id=>'report-directory'
,p_version_scn=>'1089051157'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(7375333248825386439)
,p_list_item_display_sequence=>41
,p_list_item_link_text=>'Potential Revenue by &REP_TITLE.'
,p_static_id=>'potential-revenue-by-rep-title'
,p_list_item_link_target=>'f?p=&APP_ID.:121:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-area-chart'
,p_list_text_01=>'Chart showing potential revenue by &REP_TITLE..'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10194656467509174585)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Projected Close Dates'
,p_static_id=>'projected-close-dates'
,p_list_item_link_target=>'f?p=&APP_ID.:47:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar'
,p_list_text_01=>'Calendar of projected opportunity close dates.'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10194656060929172716)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Revenue by &REP_TITLE.'
,p_static_id=>'revenue-by-rep-title'
,p_list_item_link_target=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-area-chart'
,p_list_text_01=>'Chart showing revenue by &REP_TITLE..'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10253728250603497106)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Tags'
,p_static_id=>'tags'
,p_list_item_link_target=>'f?p=&APP_ID.:48:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-tag'
,p_list_text_01=>'Tags with click through to tag references.'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp.component_end;
end;
/
