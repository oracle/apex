prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 7050
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(6098380714489638355)
,p_build_option_name=>'Agreements'
,p_build_option_status=>'EXCLUDE'
,p_default_on_export=>'EXCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'This option allows for the ability to assign license agreements to accounts.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(6628607810862680350)
,p_build_option_name=>'Usage Metrics'
,p_build_option_status=>'INCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Adds a usage metics widget to the detail pages of leads, opportunities, territories, accounts, contacts, and products. The widget is used to show how many times and how many people have viewed the item in the last 90 days.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(7186832953398887873)
,p_build_option_name=>'Opportunity Amount Set at Product Level'
,p_build_option_status=>'EXCLUDE'
,p_default_on_export=>'EXCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'When this option is enabled, an opportunity''s amount is derived from the sum of its associated product''s quote prices. When it is disabled, an opportunity''s amount is the amount that is manually entered at the opportunity level.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(7381617337298872120)
,p_build_option_name=>'Validations'
,p_build_option_status=>'INCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Adds a validation widget to the detail pages of leads, opportunities, territories, accounts, contacts, and products. The widget is used to occasionally validate that the data has been reviewed and is accurate.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(7401034857403255410)
,p_build_option_name=>'Leads'
,p_build_option_status=>'INCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Adds ability to track leads which can be converted to opportunities.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(7401040659522300015)
,p_build_option_name=>'Competitors'
,p_build_option_status=>'INCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Adds ability to track opportunity competitors.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(7478708532380272297)
,p_build_option_name=>'Product Level Close Dates'
,p_build_option_status=>'EXCLUDE'
,p_default_on_export=>'EXCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Enabling this option will capture and report on close dates for each product associated with an opportunity. Disabling this option will exclude per product close date tracking.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(8021848672523215596)
,p_build_option_name=>'Show "Opportunity Pipeline" on Home Page'
,p_build_option_status=>'INCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'When included, causes the "Opportunity Pipeline" funnel chart to be displayed on the home page.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(8021849483284249129)
,p_build_option_name=>'Show "Top Open Opportunities" on Home Page'
,p_build_option_status=>'INCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'When included, causes the "Top Open Opportunities" bar chart to be displayed on the home page.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(8451179641625791308)
,p_build_option_name=>'Support Amounts'
,p_build_option_status=>'EXCLUDE'
,p_default_on_export=>'EXCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'This option allows for the ability to assign support amounts to accounts.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(8456035888906321075)
,p_build_option_name=>'Account Locations'
,p_build_option_status=>'INCLUDE'
,p_default_on_export=>'INCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'This option allows end-users the ability to add locations to an account (if an account has multiple locations that need to be tracked).'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(10496139698135220995)
,p_build_option_name=>'Territories'
,p_build_option_status=>'INCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Adds ability to manage application by territories. Territories are assigned to accounts, which are linked to leads and opportunities.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(10496478296281986809)
,p_build_option_name=>'Contacts'
,p_build_option_status=>'INCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Adds ability to track contacts that are associated with accounts.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(10496485785461002628)
,p_build_option_name=>'Products'
,p_build_option_status=>'INCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Adds ability to maintain products and link them with opportunities.'
);
wwv_flow_imp.component_end;
end;
/
