prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 7050
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(6116102906450391758)
,p_build_option_name=>'Agreements'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>37166093793182
,p_default_on_export=>'EXCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'This option allows for the ability to assign license agreements to accounts.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(6646330002823433753)
,p_build_option_name=>'Usage Metrics'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>37166093793182
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Adds a usage metics widget to the detail pages of leads, opportunities, territories, accounts, contacts, and products. The widget is used to show how many times and how many people have viewed the item in the last 90 days.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(7204555145359641276)
,p_build_option_name=>'Opportunity Amount Set at Product Level'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>37166093793182
,p_default_on_export=>'EXCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'When this option is enabled, an opportunity''s amount is derived from the sum of its associated product''s quote prices. When it is disabled, an opportunity''s amount is the amount that is manually entered at the opportunity level.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(7399339529259625523)
,p_build_option_name=>'Validations'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>37166093793182
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Adds a validation widget to the detail pages of leads, opportunities, territories, accounts, contacts, and products. The widget is used to occasionally validate that the data has been reviewed and is accurate.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(7418757049364008813)
,p_build_option_name=>'Leads'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>37166093793182
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Adds ability to track leads which can be converted to opportunities.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(7418762851483053418)
,p_build_option_name=>'Competitors'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>37166093793182
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Adds ability to track opportunity competitors.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(7496430724341025700)
,p_build_option_name=>'Product Level Close Dates'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>37166093793182
,p_default_on_export=>'EXCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Enabling this option will capture and report on close dates for each product associated with an opportunity. Disabling this option will exclude per product close date tracking.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(8039570864483968999)
,p_build_option_name=>'Show "Opportunity Pipeline" on Home Page'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>37166093793182
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'When included, causes the "Opportunity Pipeline" funnel chart to be displayed on the home page.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(8039571675245002532)
,p_build_option_name=>'Show "Top Open Opportunities" on Home Page'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>37166093793182
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'When included, causes the "Top Open Opportunities" bar chart to be displayed on the home page.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(8468901833586544711)
,p_build_option_name=>'Support Amounts'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>37166093793182
,p_default_on_export=>'EXCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'This option allows for the ability to assign support amounts to accounts.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(8473758080867074478)
,p_build_option_name=>'Account Locations'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>37166093793182
,p_default_on_export=>'INCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'This option allows end-users the ability to add locations to an account (if an account has multiple locations that need to be tracked).'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(10513861890095974398)
,p_build_option_name=>'Territories'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>37166093793182
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Adds ability to manage application by territories. Territories are assigned to accounts, which are linked to leads and opportunities.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(10514200488242740212)
,p_build_option_name=>'Contacts'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>37166093793182
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Adds ability to track contacts that are associated with accounts.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(10514207977421756031)
,p_build_option_name=>'Products'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>37166093793182
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Adds ability to maintain products and link them with opportunities.'
);
wwv_flow_imp.component_end;
end;
/
