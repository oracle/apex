prompt --application/shared_components/logic/application_computations/opp_set_prod_lev_bo_002
begin
--   Manifest
--     APPLICATION COMPUTATION: OPP_SET_PROD_LEV_BO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(6132418900003960084)
,p_computation_sequence=>10
,p_computation_item=>'OPP_SET_PROD_LEV_BO'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'Exclude'
,p_required_patch=>-wwv_flow_imp.id(7186832953398887873)
,p_version_scn=>37166093793166
);
wwv_flow_imp.component_end;
end;
/
