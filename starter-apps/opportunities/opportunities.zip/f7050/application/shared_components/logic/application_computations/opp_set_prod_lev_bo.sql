prompt --application/shared_components/logic/application_computations/opp_set_prod_lev_bo
begin
--   Manifest
--     APPLICATION COMPUTATION: OPP_SET_PROD_LEV_BO
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_flow_computation(
 p_id=>wwv_flow_api.id(6132418707756957693)
,p_computation_sequence=>10
,p_computation_item=>'OPP_SET_PROD_LEV_BO'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'Include'
,p_required_patch=>wwv_flow_api.id(7186832953398887873)
);
wwv_flow_api.component_end;
end;
/
