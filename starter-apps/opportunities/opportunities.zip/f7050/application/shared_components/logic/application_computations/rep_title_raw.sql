prompt --application/shared_components/logic/application_computations/rep_title_raw
begin
--   Manifest
--     APPLICATION COMPUTATION: REP_TITLE_RAW
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(234350636960170834)
,p_computation_sequence=>10
,p_computation_item=>'REP_TITLE_RAW'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'return eba_sales_fw.get_preference_value(''REP_TITLE'');'
,p_version_scn=>37166093793166
);
wwv_flow_imp.component_end;
end;
/
