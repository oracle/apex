prompt --application/shared_components/logic/application_computations/opp_set_prod_lev_bo_name
begin
--   Manifest
--     APPLICATION COMPUTATION: OPP_SET_PROD_LEV_BO_NAME
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_flow_computation(
 p_id=>wwv_flow_api.id(6132418480387951596)
,p_computation_sequence=>10
,p_computation_item=>'OPP_SET_PROD_LEV_BO_NAME'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'Opportunity Amount Set at Product Level'
);
wwv_flow_api.component_end;
end;
/
