prompt --application/shared_components/logic/application_computations/opp_set_prod_lev_bo_name
begin
--   Manifest
--     APPLICATION COMPUTATION: OPP_SET_PROD_LEV_BO_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(6150140672348704999)
,p_computation_sequence=>10
,p_computation_item=>'OPP_SET_PROD_LEV_BO_NAME'
,p_static_id=>'opp-set-prod-lev-bo-name'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'Opportunity Amount Set at Product Level'
,p_version_scn=>'37166093793166'
);
wwv_flow_imp.component_end;
end;
/
