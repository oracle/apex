prompt --application/shared_components/logic/application_processes/breadcrumb_for_opportunity
begin
--   Manifest
--     APPLICATION PROCESS: Breadcrumb for Opportunity
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(6563107490663803312)
,p_process_sequence=>1
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Breadcrumb for Opportunity'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'  l_id number;',
'',
'begin',
'',
'  l_id := ',
'    case :APP_PAGE_ID',
'      when ''80'' then nv(''P80_ID'')',
'      when ''85'' then nv(''P85_ID'')',
'    end;',
'',
'  select apex_escape.html(deal_name)',
'  into :BREADCRUMB_DISPLAY',
'  from eba_sales_deals',
'  where id = l_id;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'80,85'
,p_process_when_type=>'CURRENT_PAGE_IN_CONDITION'
,p_version_scn=>37166093793166
);
wwv_flow_imp.component_end;
end;
/
