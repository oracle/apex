prompt --application/shared_components/logic/application_processes/breadcrumb_for_contact
begin
--   Manifest
--     APPLICATION PROCESS: Breadcrumb for Contact
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(6645415071820596724)
,p_process_sequence=>1
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Breadcrumb for Contact'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'  l_id number;',
'',
'begin',
'',
'  l_id := ',
'    case :APP_PAGE_ID',
'      when ''24'' then nv(''P24_ID'')',
'    end;',
'',
'  select apex_escape.html(contact_name)',
'  into :BREADCRUMB_DISPLAY',
'  from eba_sales_customer_contacts',
'  where id = l_id;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'24'
,p_process_when_type=>'CURRENT_PAGE_IN_CONDITION'
,p_version_scn=>37166093793166
);
wwv_flow_imp.component_end;
end;
/
