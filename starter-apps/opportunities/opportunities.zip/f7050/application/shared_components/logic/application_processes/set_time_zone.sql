prompt --application/shared_components/logic/application_processes/set_time_zone
begin
--   Manifest
--     APPLICATION PROCESS: set Time Zone
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(9070158658710670222)
,p_process_sequence=>2
,p_process_point=>'AFTER_LOGIN'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set Time Zone'
,p_process_sql_clob=>'eba_sales_tz_init;'
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Unable to set timezone'
,p_version_scn=>37166093793166
);
wwv_flow_imp.component_end;
end;
/
