prompt --application/shared_components/logic/application_processes/breadcrumb_for_account
begin
--   Manifest
--     APPLICATION PROCESS: Breadcrumb for Account
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(6629003826521689846)
,p_process_sequence=>1
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Breadcrumb for Account'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'  l_id number;',
'',
'begin',
'',
'  l_id := ',
'    case :APP_PAGE_ID',
'      when ''94'' then nv(''P94_ID'')',
'    end;',
'',
'  select apex_escape.html(customer_name)',
'  into :BREADCRUMB_DISPLAY',
'  from eba_sales_customers',
'  where id = l_id;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'94'
,p_process_when_type=>'CURRENT_PAGE_IN_CONDITION'
,p_version_scn=>37166093793166
);
wwv_flow_imp.component_end;
end;
/
