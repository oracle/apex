prompt --application/shared_components/logic/application_processes/set_counts
begin
--   Manifest
--     APPLICATION PROCESS: set counts
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(7351573981081232690)
,p_process_sequence=>3
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set counts'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trim(to_char(count(*),''999G999G999G990''))',
'into :PRODUCTS',
'from eba_sales_products;',
'',
'select trim(to_char(count(*),''999G999G999G990''))',
'into :CUSTOMERS',
'from eba_sales_customers;',
'',
'select trim(to_char(count(*),''999G999G999G990''))',
'into :DEALS',
'from eba_sales_deals;',
'',
'select trim(to_char(count(*),''999G999G999G990''))',
'into :TERRITORIES',
'from eba_sales_territories;',
'',
'select trim(to_char(count(*),''999G999G999G990''))',
'into :LEADS',
'from eba_sales_leads;',
'',
'select trim(to_char(count(*),''999G999G999G990''))',
'into :CONTACTS',
'from eba_sales_customer_contacts;',
'',
'select trim(to_char(count(*),''999G999G999G990''))',
'into :COMPETITION',
'from eba_sales_deal_competition;'))
,p_process_clob_language=>'PLSQL'
,p_version_scn=>37166093793166
);
wwv_flow_imp.component_end;
end;
/
