prompt --application/shared_components/logic/application_items/rep_title
begin
--   Manifest
--     APPLICATION ITEM: REP_TITLE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(7501991887197708497)
,p_name=>'REP_TITLE'
,p_protection_level=>'I'
,p_version_scn=>37166093793166
);
wwv_flow_imp.component_end;
end;
/
