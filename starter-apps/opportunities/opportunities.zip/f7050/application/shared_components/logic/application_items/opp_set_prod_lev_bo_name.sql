prompt --application/shared_components/logic/application_items/opp_set_prod_lev_bo_name
begin
--   Manifest
--     APPLICATION ITEM: OPP_SET_PROD_LEV_BO_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(6150139933109686236)
,p_name=>'OPP_SET_PROD_LEV_BO_NAME'
,p_protection_level=>'I'
,p_version_scn=>'37166093793166'
);
wwv_flow_imp.component_end;
end;
/
