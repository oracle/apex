prompt --application/shared_components/legacy_data_loads/eba_sales_deals
begin
--   Manifest
--     EBA_SALES_DEALS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_load_table(
 p_id=>wwv_flow_imp.id(8399244600077225003)
,p_name=>'aaa'
,p_static_id=>'aaa'
,p_owner=>'#OWNER#'
,p_table_name=>'EBA_SALES_DEALS'
,p_unique_column_1=>'ROW_KEY'
,p_is_uk1_case_sensitive=>'N'
,p_skip_validation=>'N'
);
wwv_flow_imp.component_end;
end;
/
