prompt --application/shared_components/legacy_data_loads/eba_sales_customers
begin
--   Manifest
--     EBA_SALES_CUSTOMERS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_load_table(
 p_id=>wwv_flow_api.id(8466766994939225996)
,p_name=>'Upload Accounts'
,p_owner=>'#OWNER#'
,p_table_name=>'EBA_SALES_CUSTOMERS'
,p_unique_column_1=>'ID'
,p_is_uk1_case_sensitive=>'N'
,p_is_uk2_case_sensitive=>'N'
,p_is_uk3_case_sensitive=>'N'
,p_skip_validation=>'N'
);
wwv_flow_api.create_load_table_lookup(
 p_id=>wwv_flow_api.id(8466767295404226001)
,p_load_table_id=>wwv_flow_api.id(8466766994939225996)
,p_load_column_name=>'CUSTOMER_INDUSTRY_ID'
,p_lookup_owner=>'#OWNER#'
,p_lookup_table_name=>'EBA_SALES_INDUSTRIES'
,p_key_column=>'ID'
,p_display_column=>'INDUSTRY_NAME'
,p_insert_new_value=>'N'
);
wwv_flow_api.create_load_table_lookup(
 p_id=>wwv_flow_api.id(8466767686183226026)
,p_load_table_id=>wwv_flow_api.id(8466766994939225996)
,p_load_column_name=>'CUSTOMER_TERRITORY_ID'
,p_lookup_owner=>'#OWNER#'
,p_lookup_table_name=>'EBA_SALES_TERRITORIES'
,p_key_column=>'ID'
,p_display_column=>'TERRITORY_NAME'
,p_insert_new_value=>'N'
);
wwv_flow_api.create_load_table_lookup(
 p_id=>wwv_flow_api.id(8466768122496226026)
,p_load_table_id=>wwv_flow_api.id(8466766994939225996)
,p_load_column_name=>'DEFAULT_REP_ID'
,p_lookup_owner=>'#OWNER#'
,p_lookup_table_name=>'EBA_SALES_SALESREPS'
,p_key_column=>'ID'
,p_display_column=>'REP_EBA_SALES_USERNAME'
,p_insert_new_value=>'N'
);
wwv_flow_api.component_end;
end;
/
