prompt --application/shared_components/legacy_data_loads/eba_sales_customers
begin
--   Manifest
--     EBA_SALES_CUSTOMERS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_load_table(
 p_id=>wwv_flow_imp.id(8484489186899979399)
,p_name=>'Upload Accounts'
,p_owner=>'#OWNER#'
,p_table_name=>'EBA_SALES_CUSTOMERS'
,p_unique_column_1=>'ID'
,p_is_uk1_case_sensitive=>'N'
,p_is_uk2_case_sensitive=>'N'
,p_is_uk3_case_sensitive=>'N'
,p_skip_validation=>'N'
);
wwv_flow_imp_shared.create_load_table_lookup(
 p_id=>wwv_flow_imp.id(8484489487364979404)
,p_load_table_id=>wwv_flow_imp.id(8484489186899979399)
,p_load_column_name=>'CUSTOMER_INDUSTRY_ID'
,p_lookup_owner=>'#OWNER#'
,p_lookup_table_name=>'EBA_SALES_INDUSTRIES'
,p_key_column=>'ID'
,p_display_column=>'INDUSTRY_NAME'
,p_insert_new_value=>'N'
);
wwv_flow_imp_shared.create_load_table_lookup(
 p_id=>wwv_flow_imp.id(8484489878143979429)
,p_load_table_id=>wwv_flow_imp.id(8484489186899979399)
,p_load_column_name=>'CUSTOMER_TERRITORY_ID'
,p_lookup_owner=>'#OWNER#'
,p_lookup_table_name=>'EBA_SALES_TERRITORIES'
,p_key_column=>'ID'
,p_display_column=>'TERRITORY_NAME'
,p_insert_new_value=>'N'
);
wwv_flow_imp_shared.create_load_table_lookup(
 p_id=>wwv_flow_imp.id(8484490314456979429)
,p_load_table_id=>wwv_flow_imp.id(8484489186899979399)
,p_load_column_name=>'DEFAULT_REP_ID'
,p_lookup_owner=>'#OWNER#'
,p_lookup_table_name=>'EBA_SALES_SALESREPS'
,p_key_column=>'ID'
,p_display_column=>'REP_EBA_SALES_USERNAME'
,p_insert_new_value=>'N'
);
wwv_flow_imp.component_end;
end;
/
