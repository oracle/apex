prompt --application/shared_components/user_interface/lovs/fiscal_years_product_close_dates
begin
--   Manifest
--     FISCAL YEARS - PRODUCT CLOSE DATES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(7593714213552545365)
,p_lov_name=>'FISCAL YEARS - PRODUCT CLOSE DATES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct sp.fiscal_year + 2000 as dv, sp.fiscal_year as rv',
'  from eba_sales_sales_periods sp,',
'       eba_sales_deal_products dp',
' where sp.fiscal_year = substr(dp.qtr, -2)',
' order by 2 asc'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
);
wwv_flow_imp.component_end;
end;
/
