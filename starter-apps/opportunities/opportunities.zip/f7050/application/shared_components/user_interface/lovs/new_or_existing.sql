prompt --application/shared_components/user_interface/lovs/new_or_existing
begin
--   Manifest
--     NEW_OR_EXISTING
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(9066605934501140924)
,p_lov_name=>'NEW_OR_EXISTING'
,p_static_id=>'new-or-existing'
,p_lov_query=>'.'||wwv_flow_imp.id(9066605934501140924)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089051157'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9066606247002140927)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Existing Account'
,p_lov_return_value=>'EXISTING'
,p_static_id=>'existing-account'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9066606440483140931)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'New Account'
,p_lov_return_value=>'NEW'
,p_static_id=>'new-account'
);
wwv_flow_imp.component_end;
end;
/
