prompt --application/shared_components/user_interface/lovs/lov_dataload_upload_opportunities
begin
--   Manifest
--     LOV_DATALOAD_UPLOAD OPPORTUNITIES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(8376394121355562199)
,p_lov_name=>'LOV_DATALOAD_UPLOAD OPPORTUNITIES'
,p_lov_query=>'.'||wwv_flow_imp.id(8376394121355562199)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8376420903674562230)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Row Key'
,p_lov_return_value=>'ROW_KEY'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8376395831778562210)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Account'
,p_lov_return_value=>'CUSTOMER_ID'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8376398989668562211)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Location'
,p_lov_return_value=>'DEAL_CUSTOMER_LOCATION'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8376400198681562213)
,p_lov_disp_sequence=>40
,p_lov_disp_value=>'Opportunity Name'
,p_lov_return_value=>'DEAL_NAME'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8376396598822562210)
,p_lov_disp_sequence=>50
,p_lov_disp_value=>'Close Date'
,p_lov_return_value=>'DEAL_CLOSE_DATE'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8376396137784562210)
,p_lov_disp_sequence=>60
,p_lov_disp_value=>'Deal Amount'
,p_lov_return_value=>'DEAL_AMOUNT'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8376401379788562214)
,p_lov_disp_sequence=>70
,p_lov_disp_value=>'Stage'
,p_lov_return_value=>'DEAL_STAGE'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8376401793557562214)
,p_lov_disp_sequence=>90
,p_lov_disp_value=>'Risk'
,p_lov_return_value=>'RISK_ASSESSMENT_ID'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8376400615058562214)
,p_lov_disp_sequence=>100
,p_lov_disp_value=>'Probability'
,p_lov_return_value=>'DEAL_PROBABILITY'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8376425329832562233)
,p_lov_disp_sequence=>110
,p_lov_disp_value=>'Territory'
,p_lov_return_value=>'TERRITORY_ID'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8376394602930562205)
,p_lov_disp_sequence=>130
,p_lov_disp_value=>'Account Standing'
,p_lov_return_value=>'ACCOUNT_STANDING_ID'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8376419693163562229)
,p_lov_disp_sequence=>140
,p_lov_disp_value=>'Pro / Re-Active'
,p_lov_return_value=>'PRO_RE_ACTIVE'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8376424466767562232)
,p_lov_disp_sequence=>150
,p_lov_disp_value=>'Tags'
,p_lov_return_value=>'TAGS'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8376402178575562215)
,p_lov_disp_sequence=>160
,p_lov_disp_value=>'Summary'
,p_lov_return_value=>'DEAL_SUMMARY'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8376395026193562209)
,p_lov_disp_sequence=>200
,p_lov_disp_value=>'Created'
,p_lov_return_value=>'CREATED'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8376395429856562209)
,p_lov_disp_sequence=>210
,p_lov_disp_value=>'Created By'
,p_lov_return_value=>'CREATED_BY'
);
wwv_flow_imp.component_end;
end;
/
