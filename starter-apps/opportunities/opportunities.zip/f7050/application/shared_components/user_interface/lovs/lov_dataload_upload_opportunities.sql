prompt --application/shared_components/user_interface/lovs/lov_dataload_upload_opportunities
begin
--   Manifest
--     LOV_DATALOAD_UPLOAD OPPORTUNITIES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(8394116313316315602)
,p_lov_name=>'LOV_DATALOAD_UPLOAD OPPORTUNITIES'
,p_lov_query=>'.'||wwv_flow_imp.id(8394116313316315602)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089051157
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8394143095635315633)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Row Key'
,p_lov_return_value=>'ROW_KEY'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8394118023739315613)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Account'
,p_lov_return_value=>'CUSTOMER_ID'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8394121181629315614)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Location'
,p_lov_return_value=>'DEAL_CUSTOMER_LOCATION'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8394122390642315616)
,p_lov_disp_sequence=>40
,p_lov_disp_value=>'Opportunity Name'
,p_lov_return_value=>'DEAL_NAME'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8394118790783315613)
,p_lov_disp_sequence=>50
,p_lov_disp_value=>'Close Date'
,p_lov_return_value=>'DEAL_CLOSE_DATE'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8394118329745315613)
,p_lov_disp_sequence=>60
,p_lov_disp_value=>'Deal Amount'
,p_lov_return_value=>'DEAL_AMOUNT'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8394123571749315617)
,p_lov_disp_sequence=>70
,p_lov_disp_value=>'Stage'
,p_lov_return_value=>'DEAL_STAGE'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8394123985518315617)
,p_lov_disp_sequence=>90
,p_lov_disp_value=>'Risk'
,p_lov_return_value=>'RISK_ASSESSMENT_ID'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8394122807019315617)
,p_lov_disp_sequence=>100
,p_lov_disp_value=>'Probability'
,p_lov_return_value=>'DEAL_PROBABILITY'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8394147521793315636)
,p_lov_disp_sequence=>110
,p_lov_disp_value=>'Territory'
,p_lov_return_value=>'TERRITORY_ID'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8394116794891315608)
,p_lov_disp_sequence=>130
,p_lov_disp_value=>'Account Standing'
,p_lov_return_value=>'ACCOUNT_STANDING_ID'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8394141885124315632)
,p_lov_disp_sequence=>140
,p_lov_disp_value=>'Pro / Re-Active'
,p_lov_return_value=>'PRO_RE_ACTIVE'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8394146658728315635)
,p_lov_disp_sequence=>150
,p_lov_disp_value=>'Tags'
,p_lov_return_value=>'TAGS'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8394124370536315618)
,p_lov_disp_sequence=>160
,p_lov_disp_value=>'Summary'
,p_lov_return_value=>'DEAL_SUMMARY'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8394117218154315612)
,p_lov_disp_sequence=>200
,p_lov_disp_value=>'Created'
,p_lov_return_value=>'CREATED'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8394117621817315612)
,p_lov_disp_sequence=>210
,p_lov_disp_value=>'Created By'
,p_lov_return_value=>'CREATED_BY'
);
wwv_flow_imp.component_end;
end;
/
