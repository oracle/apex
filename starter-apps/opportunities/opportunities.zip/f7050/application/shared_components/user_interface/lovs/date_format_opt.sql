prompt --application/shared_components/user_interface/lovs/date_format_opt
begin
--   Manifest
--     DATE_FORMAT_OPT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(8484502873321979533)
,p_lov_name=>'DATE_FORMAT_OPT'
,p_static_id=>'date-format-opt'
,p_lov_query=>'.'||wwv_flow_imp.id(8484502873321979533)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089051157'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8484503654469979534)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Provide custom formats for uploaded columns'
,p_lov_return_value=>'N'
,p_static_id=>'provide-custom-formats-for-uploaded-columns'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8484503283683979533)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Use application standard format masks'
,p_lov_return_value=>'Y'
,p_static_id=>'use-application-standard-format-masks'
);
wwv_flow_imp.component_end;
end;
/
