prompt --application/shared_components/user_interface/lovs/primary_sales_rep
begin
--   Manifest
--     PRIMARY_SALES_REP
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(9057132946127657168)
,p_lov_name=>'PRIMARY_SALES_REP'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.rep_email||'' - ''||r2.role_name display_value, ',
'         r.ID return_value ',
'from eba_sales_SALESREPS r, ',
'        eba_sales_salesrep_roles r2',
'where r.rep_role = r2.id(+) and r2.is_sales_rep = ''Y''',
'order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
);
wwv_flow_imp.component_end;
end;
/
