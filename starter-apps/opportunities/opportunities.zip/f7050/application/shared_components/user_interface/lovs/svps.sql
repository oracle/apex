prompt --application/shared_components/user_interface/lovs/svps
begin
--   Manifest
--     SVPS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(8472245818551375151)
,p_lov_name=>'SVPS'
,p_lov_query=>'select svp_name, id from eba_sales_svps order by upper(svp_name)'
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1089051157
);
wwv_flow_imp.component_end;
end;
/
