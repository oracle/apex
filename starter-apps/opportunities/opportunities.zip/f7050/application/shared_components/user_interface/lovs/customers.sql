prompt --application/shared_components/user_interface/lovs/customers
begin
--   Manifest
--     CUSTOMERS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(8867799149541577989)
,p_lov_name=>'CUSTOMERS'
,p_static_id=>'customers'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CUSTOMER_NAME as display_value, ID as return_value ',
'  from EBA_SALES_CUSTOMERS',
' order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>'1089051157'
);
wwv_flow_imp.component_end;
end;
/
