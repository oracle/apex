prompt --application/shared_components/user_interface/lovs/pill_display_as
begin
--   Manifest
--     PILL_DISPLAY_AS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(7368395106126867077)
,p_lov_name=>'PILL_DISPLAY_AS'
,p_static_id=>'pill-display-as'
,p_lov_query=>'.'||wwv_flow_imp.id(7368395106126867077)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089051157'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(7368395358679867088)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Cards View'
,p_lov_return_value=>'CARDS'
,p_static_id=>'cards-view'
,p_lov_template=>'<span class="t-Icon fa fa-cards" title="#DISPLAY_VALUE#"></span><span class="u-VisuallyHidden">#DISPLAY_VALUE#</span>'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(7368396170894867089)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Customizable Grid'
,p_lov_return_value=>'GRID'
,p_static_id=>'customizable-grid'
,p_lov_template=>'<span class="t-Icon fa fa-table" title="#DISPLAY_VALUE#"></span><span class="u-VisuallyHidden">#DISPLAY_VALUE#</span>'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(7368395816342867089)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Report View'
,p_lov_return_value=>'REPORT'
,p_static_id=>'report-view'
,p_lov_template=>'<span class="t-Icon fa fa-reorder" title="#DISPLAY_VALUE#"></span><span class="u-VisuallyHidden">#DISPLAY_VALUE#</span>'
);
wwv_flow_imp.component_end;
end;
/
