prompt --application/shared_components/user_interface/lovs/search_page_include_options
begin
--   Manifest
--     SEARCH PAGE, INCLUDE OPTIONS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(9036136457951925676)
,p_lov_name=>'SEARCH PAGE, INCLUDE OPTIONS'
,p_lov_query=>'.'||wwv_flow_imp.id(9036136457951925676)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089051157
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(6587282797195650846)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'Leads'
,p_lov_return_value=>'LEADS'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9036136658782925678)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Opportunities'
,p_lov_return_value=>'OPPORTUNITIES'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9036137051401925678)
,p_lov_disp_sequence=>15
,p_lov_disp_value=>'Territories'
,p_lov_return_value=>'TERRITORIES'
,p_required_patch=>wwv_flow_imp.id(10513861890095974398)
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9036136846265925678)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Accounts'
,p_lov_return_value=>'ACCOUNTS'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(6587365708465943004)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Contacts'
,p_lov_return_value=>'CONTACTS'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(6587365933785944185)
,p_lov_disp_sequence=>40
,p_lov_disp_value=>'Products'
,p_lov_return_value=>'PRODUCTS'
);
wwv_flow_imp.component_end;
end;
/
