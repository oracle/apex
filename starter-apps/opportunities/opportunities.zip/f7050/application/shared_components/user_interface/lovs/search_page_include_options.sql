prompt --application/shared_components/user_interface/lovs/search_page_include_options
begin
--   Manifest
--     SEARCH PAGE, INCLUDE OPTIONS
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(9018414265991172273)
,p_lov_name=>'SEARCH PAGE, INCLUDE OPTIONS'
,p_lov_query=>'.'||wwv_flow_api.id(9018414265991172273)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(6569560605234897443)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'Leads'
,p_lov_return_value=>'LEADS'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(9018414466822172275)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Opportunities'
,p_lov_return_value=>'OPPORTUNITIES'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(9018414859441172275)
,p_lov_disp_sequence=>15
,p_lov_disp_value=>'Territories'
,p_lov_return_value=>'TERRITORIES'
,p_required_patch=>wwv_flow_api.id(10496139698135220995)
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(9018414654305172275)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Accounts'
,p_lov_return_value=>'ACCOUNTS'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(6569643516505189601)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Contacts'
,p_lov_return_value=>'CONTACTS'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(6569643741825190782)
,p_lov_disp_sequence=>40
,p_lov_disp_value=>'Products'
,p_lov_return_value=>'PRODUCTS'
);
wwv_flow_api.component_end;
end;
/
