prompt --application/shared_components/user_interface/lovs/deal_status_all_open_closed
begin
--   Manifest
--     DEAL STATUS ALL OPEN CLOSED
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(7362612288577452019)
,p_lov_name=>'DEAL STATUS ALL OPEN CLOSED'
,p_lov_query=>'.'||wwv_flow_imp.id(7362612288577452019)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089051157
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(7362612490067452023)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'All'
,p_lov_return_value=>'ALL'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(7362612767608452028)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Open'
,p_lov_return_value=>'OPEN'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(7362613058593452028)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Closed'
,p_lov_return_value=>'CLOSED'
);
wwv_flow_imp.component_end;
end;
/
