prompt --application/shared_components/user_interface/lovs/deal_status_all_open_closed
begin
--   Manifest
--     DEAL STATUS ALL OPEN CLOSED
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(7344890096616698616)
,p_lov_name=>'DEAL STATUS ALL OPEN CLOSED'
,p_lov_query=>'.'||wwv_flow_imp.id(7344890096616698616)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(7344890298106698620)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'All'
,p_lov_return_value=>'ALL'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(7344890575647698625)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Open'
,p_lov_return_value=>'OPEN'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(7344890866632698625)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Closed'
,p_lov_return_value=>'CLOSED'
);
wwv_flow_imp.component_end;
end;
/
