prompt --application/shared_components/user_interface/lovs/quarter_end
begin
--   Manifest
--     QUARTER END
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(10202939568910657860)
,p_lov_name=>'QUARTER END'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PERIOD_NAME ||',
'       case when sysdate between first_day and last_day then '' *'' end d,',
'       to_char(last_day,''YYYYMMDD'') r ',
'  from EBA_SALES_SALES_PERIODS',
' where sysdate >= first_day',
' order by first_day'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1089051157
);
wwv_flow_imp.component_end;
end;
/
