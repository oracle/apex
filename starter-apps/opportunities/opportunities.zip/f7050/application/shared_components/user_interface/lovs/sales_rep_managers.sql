prompt --application/shared_components/user_interface/lovs/sales_rep_managers
begin
--   Manifest
--     SALES REP MANAGERS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(8472251827295537964)
,p_lov_name=>'SALES REP MANAGERS'
,p_static_id=>'sales-rep-managers'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select initcap(rep_first_name) || '' ''|| initcap(rep_last_name) display_value, ID return_value ',
'from eba_sales_salesreps',
'where rep_manager_id is null',
'union',
'select initcap(rep_first_name) || '' ''|| initcap(rep_last_name) display_value, ID return_value ',
'from eba_sales_salesreps',
'where id in (select distinct rep_manager_id from eba_sales_salesreps)',
'order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>'1089051157'
);
wwv_flow_imp.component_end;
end;
/
