prompt --application/shared_components/user_interface/lovs/sales_rep_managers
begin
--   Manifest
--     SALES REP MANAGERS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(8454529635334784561)
,p_lov_name=>'SALES REP MANAGERS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select initcap(rep_first_name) || '' ''|| initcap(rep_last_name) display_value, ID return_value ',
'from eba_sales_salesreps',
'where rep_manager_id is null',
'union',
'select initcap(rep_first_name) || '' ''|| initcap(rep_last_name) display_value, ID return_value ',
'from eba_sales_salesreps',
'where id in (select distinct rep_manager_id from eba_sales_salesreps)',
'order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
);
wwv_flow_imp.component_end;
end;
/
