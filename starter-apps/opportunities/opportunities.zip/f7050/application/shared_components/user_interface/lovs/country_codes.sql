prompt --application/shared_components/user_interface/lovs/country_codes
begin
--   Manifest
--     COUNTRY CODES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(10497471608719813682)
,p_lov_name=>'COUNTRY CODES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select COUNTRY_NAME display_value, COUNTRY_CODE return_value ',
'from eba_sales_COUNTRIES',
'order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1089051157
);
wwv_flow_imp.component_end;
end;
/
