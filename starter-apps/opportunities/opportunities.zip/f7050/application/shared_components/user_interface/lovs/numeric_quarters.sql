prompt --application/shared_components/user_interface/lovs/numeric_quarters
begin
--   Manifest
--     NUMERIC_QUARTERS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(3310246017204933924)
,p_lov_name=>'NUMERIC_QUARTERS'
,p_lov_query=>'.'||wwv_flow_imp.id(3310246017204933924)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089051157
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(3310246335267933927)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'First Quarter'
,p_lov_return_value=>'Q1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(3310246759559933928)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Second Quarter'
,p_lov_return_value=>'Q2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(3310247132835933928)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Third Quarter'
,p_lov_return_value=>'Q3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(3310247466352933928)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Fourth Quarter'
,p_lov_return_value=>'Q4'
);
wwv_flow_imp.component_end;
end;
/
