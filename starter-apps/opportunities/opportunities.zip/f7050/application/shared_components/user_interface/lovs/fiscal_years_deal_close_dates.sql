prompt --application/shared_components/user_interface/lovs/fiscal_years_deal_close_dates
begin
--   Manifest
--     FISCAL YEARS - DEAL CLOSE DATES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(7611440599834376761)
,p_lov_name=>'FISCAL YEARS - DEAL CLOSE DATES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct sp.fiscal_year + 2000 as dv, sp.fiscal_year as rv',
'  from eba_sales_sales_periods sp,',
'       eba_sales_deals d',
' where sp.fiscal_year = substr(d.qtr, -2)',
' order by 2 asc'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1089051157
);
wwv_flow_imp.component_end;
end;
/
