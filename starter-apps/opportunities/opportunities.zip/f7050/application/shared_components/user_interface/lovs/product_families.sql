prompt --application/shared_components/user_interface/lovs/product_families
begin
--   Manifest
--     PRODUCT FAMILIES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(6996144581841418999)
,p_lov_name=>'PRODUCT FAMILIES'
,p_static_id=>'product-families'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select product_family as d,',
'       id as r',
'  from eba_sales_product_families',
' order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>'1089051157'
);
wwv_flow_imp.component_end;
end;
/
