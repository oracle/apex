prompt --application/shared_components/user_interface/lovs/territory_types
begin
--   Manifest
--     TERRITORY TYPES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(9065776939080665918)
,p_lov_name=>'TERRITORY TYPES'
,p_lov_query=>'.'||wwv_flow_imp.id(9065776939080665918)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089051157
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9065777239461665919)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'State'
,p_lov_return_value=>'STATE'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9065777453416665920)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Named Account'
,p_lov_return_value=>'NAMED_ACCOUNT'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9065777848742665920)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Country'
,p_lov_return_value=>'COUNTRY'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9065778050364665920)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'Region'
,p_lov_return_value=>'REGION'
);
wwv_flow_imp.component_end;
end;
/
