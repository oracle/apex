prompt --application/shared_components/user_interface/lovs/territory_types
begin
--   Manifest
--     TERRITORY TYPES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(9048054747119912515)
,p_lov_name=>'TERRITORY TYPES'
,p_lov_query=>'.'||wwv_flow_imp.id(9048054747119912515)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089051157
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9048055047500912516)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'State'
,p_lov_return_value=>'STATE'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9048055261455912517)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Named Account'
,p_lov_return_value=>'NAMED_ACCOUNT'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9048055656781912517)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Country'
,p_lov_return_value=>'COUNTRY'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9048055858403912517)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'Region'
,p_lov_return_value=>'REGION'
);
wwv_flow_imp.component_end;
end;
/
