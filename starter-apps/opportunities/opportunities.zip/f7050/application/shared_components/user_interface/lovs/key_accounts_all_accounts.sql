prompt --application/shared_components/user_interface/lovs/key_accounts_all_accounts
begin
--   Manifest
--     KEY ACCOUNTS ALL ACCOUNTS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(8261827700633505498)
,p_lov_name=>'KEY ACCOUNTS ALL ACCOUNTS'
,p_lov_query=>'.'||wwv_flow_imp.id(8261827700633505498)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089051157
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8261828265700505506)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'All Accounts'
,p_lov_return_value=>'ALL'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8261827853056505503)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Key Accounts'
,p_lov_return_value=>'KEY'
);
wwv_flow_imp.component_end;
end;
/
