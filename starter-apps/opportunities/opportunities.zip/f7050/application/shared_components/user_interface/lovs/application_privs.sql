prompt --application/shared_components/user_interface/lovs/application_privs
begin
--   Manifest
--     APPLICATION PRIVS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(10516191905054853275)
,p_lov_name=>'APPLICATION PRIVS'
,p_lov_query=>'.'||wwv_flow_imp.id(10516191905054853275)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089051157
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(10516192099850853276)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Read Write'
,p_lov_return_value=>'RW'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(10516192302543853281)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Read Only'
,p_lov_return_value=>'RO'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(10516192503517853281)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Administrator'
,p_lov_return_value=>'A'
);
wwv_flow_imp.component_end;
end;
/
