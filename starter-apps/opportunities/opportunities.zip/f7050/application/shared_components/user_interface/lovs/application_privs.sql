prompt --application/shared_components/user_interface/lovs/application_privs
begin
--   Manifest
--     APPLICATION PRIVS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(10498469713094099872)
,p_lov_name=>'APPLICATION PRIVS'
,p_lov_query=>'.'||wwv_flow_imp.id(10498469713094099872)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(10498469907890099873)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Read Write'
,p_lov_return_value=>'RW'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(10498470110583099878)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Read Only'
,p_lov_return_value=>'RO'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(10498470311557099878)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Administrator'
,p_lov_return_value=>'A'
);
wwv_flow_imp.component_end;
end;
/
