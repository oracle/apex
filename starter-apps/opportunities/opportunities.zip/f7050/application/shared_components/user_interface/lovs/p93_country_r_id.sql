prompt --application/shared_components/user_interface/lovs/p93_country_r_id
begin
--   Manifest
--     P93_COUNTRY_R_ID
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(9066276836123251631)
,p_lov_name=>'P93_COUNTRY_R_ID'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select COUNTRY_NAME display_value, id return_value ',
'from eba_sales_COUNTRIES',
'where id not in (select country_id',
'                 from eba_sales_terr_map',
'                 where territory_id = :P93_ID',
'                 and country_id is not null)',
'order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1089051157
);
wwv_flow_imp.component_end;
end;
/
