prompt --application/shared_components/user_interface/lovs/purchase_or_subscription
begin
--   Manifest
--     PURCHASE OR SUBSCRIPTION
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(7188321921794914038)
,p_lov_name=>'PURCHASE OR SUBSCRIPTION'
,p_lov_query=>'.'||wwv_flow_api.id(7188321921794914038)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(7188322462831914059)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Cloud Subscription'
,p_lov_return_value=>'SUBSCRIPTION'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(7188322123864914055)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'On-Premise Purchase'
,p_lov_return_value=>'PURCHASE'
);
wwv_flow_api.component_end;
end;
/
