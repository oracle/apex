prompt --application/shared_components/user_interface/lovs/purchase_or_subscription
begin
--   Manifest
--     PURCHASE OR SUBSCRIPTION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(7206044113755667441)
,p_lov_name=>'PURCHASE OR SUBSCRIPTION'
,p_lov_query=>'.'||wwv_flow_imp.id(7206044113755667441)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089051157
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(7206044654792667462)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Cloud Subscription'
,p_lov_return_value=>'SUBSCRIPTION'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(7206044315825667458)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'On-Premise Purchase'
,p_lov_return_value=>'PURCHASE'
);
wwv_flow_imp.component_end;
end;
/
