prompt --application/shared_components/user_interface/lovs/card_ir_chart
begin
--   Manifest
--     CARD, IR, CHART
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(8241953892527743680)
,p_lov_name=>'CARD, IR, CHART'
,p_lov_query=>'.'||wwv_flow_imp.id(8241953892527743680)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8241954157652743691)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Cards'
,p_lov_return_value=>'CARDS'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8241954492975743697)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Interactive Report'
,p_lov_return_value=>'REPORT'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8241956044669747484)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Bar Chart'
,p_lov_return_value=>'BAR'
);
wwv_flow_imp.component_end;
end;
/
