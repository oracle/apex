prompt --application/shared_components/user_interface/lovs/card_ir_chart
begin
--   Manifest
--     CARD, IR, CHART
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(8259676084488497083)
,p_lov_name=>'CARD, IR, CHART'
,p_lov_query=>'.'||wwv_flow_imp.id(8259676084488497083)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089051157
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8259676349613497094)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Cards'
,p_lov_return_value=>'CARDS'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8259676684936497100)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Interactive Report'
,p_lov_return_value=>'REPORT'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8259678236630500887)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Bar Chart'
,p_lov_return_value=>'BAR'
);
wwv_flow_imp.component_end;
end;
/
