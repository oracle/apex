prompt --application/shared_components/user_interface/lovs/team_member
begin
--   Manifest
--     TEAM MEMBER
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(10516155781234751701)
,p_lov_name=>'TEAM MEMBER'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.rep_email||'' - ''||r2.role_name display_value, ',
'         r.ID return_value ',
'from eba_sales_SALESREPS r, ',
'        eba_sales_salesrep_roles r2',
'where r.rep_role = r2.id(+)',
'order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1089051157
);
wwv_flow_imp.component_end;
end;
/
