prompt --application/shared_components/user_interface/lovs/quarter_Begin
begin
--   Manifest
--     QUARTER BEGIN
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(10220660652559408825)
,p_lov_name=>'QUARTER BEGIN'
,p_static_id=>'quarter-begin'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PERIOD_NAME ||',
'       case when sysdate between first_day and last_day then '' *'' end d,',
'       to_char(first_day,''YYYYMMDD'') r ',
'  from EBA_SALES_SALES_PERIODS',
' where sysdate >= first_day',
'order by first_day'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>'1089051157'
);
wwv_flow_imp.component_end;
end;
/
