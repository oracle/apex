prompt --application/pages/page_00105
begin
--   Manifest
--     PAGE: 00105
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>105
,p_name=>'Contacts'
,p_alias=>'CONTACTS'
,p_page_mode=>'MODAL'
,p_step_title=>'Contacts'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(7357625541266796352)
,p_inline_css=>'.t-Dialog-body {padding: 0; overflow: hidden;}'
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_required_patch=>wwv_flow_imp.id(10496478296281986809)
,p_dialog_css_classes=>'view-contacts-dialog'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_upd_yyyymmddhh24miss=>'20220823161415'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8900251653510987894)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(7343855860694915257)
,p_plug_display_sequence=>10
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8900252238504987896)
,p_plug_name=>'Contacts'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343865001510915269)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'  contact_name,',
'  contact_email,',
'  contact_phone,',
'  contact_cell,',
'  contact_address,',
'  contact_description,',
'  contact_linkedin,',
'  contact_facebook,',
'  created,',
'  updated,',
'  lower(created_by) created_by,',
'  lower(updated_by) updated_by',
'from eba_sales_customer_contacts',
'where customer_id = :P105_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(8900252461867987896)
,p_name=>'Competitors'
,p_max_row_count=>'100000'
,p_max_row_count_message=>'This query returns more than #MAX_ROW_COUNT# rows, please filter your data to ensure complete results.'
,p_no_data_found_message=>'No contacts found.'
,p_allow_save_rpt_public=>'Y'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:106:&SESSION.::&DEBUG.:RP,106:P106_ID,P106_SHOW_ACCOUNT:#ID#,N'
,p_detail_link_text=>'<span class="fa fa-edit" aria-hidden="true"></span>'
,p_detail_link_attr=>'title="Edit #CONTACT_NAME#"'
,p_owner=>'MIKE'
,p_internal_uid=>2389888027257460489
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8900368554854002680)
,p_db_column_name=>'CONTACT_ADDRESS'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Address'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8900368757756002681)
,p_db_column_name=>'CONTACT_DESCRIPTION'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7291016665873435237)
,p_db_column_name=>'CONTACT_LINKEDIN'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'LinkedIn'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7291016753535435240)
,p_db_column_name=>'CONTACT_FACEBOOK'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Facebook'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6597149578697006780)
,p_db_column_name=>'CONTACT_NAME'
,p_display_order=>27
,p_column_identifier=>'T'
,p_column_label=>'Contact'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6597149684831006781)
,p_db_column_name=>'CONTACT_EMAIL'
,p_display_order=>37
,p_column_identifier=>'U'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6597149807138006782)
,p_db_column_name=>'CONTACT_PHONE'
,p_display_order=>47
,p_column_identifier=>'V'
,p_column_label=>'Phone'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6597149869248006783)
,p_db_column_name=>'CONTACT_CELL'
,p_display_order=>57
,p_column_identifier=>'W'
,p_column_label=>'Cell'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8900252865667987898)
,p_db_column_name=>'CREATED'
,p_display_order=>67
,p_column_identifier=>'D'
,p_column_label=>'Added'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8900252942591987898)
,p_db_column_name=>'UPDATED'
,p_display_order=>77
,p_column_identifier=>'E'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8900253037936987898)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>87
,p_column_identifier=>'F'
,p_column_label=>'Added By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8900253145549987898)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>97
,p_column_identifier=>'G'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6597150031498006784)
,p_db_column_name=>'ID'
,p_display_order=>107
,p_column_identifier=>'X'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(8900253266088987899)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'23898889'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'CONTACT_NAME:CONTACT_EMAIL:CONTACT_PHONE:CONTACT_CELL:CREATED_BY:CREATED:'
,p_sort_column_1=>'UPDATED'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'COMPETITOR'
,p_sort_direction_2=>'ASC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8901397057851268301)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8900252238504987896)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886016830915316)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:105:&SESSION.::&DEBUG.:RP,RIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8901431450364275586)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(8900252238504987896)
,p_button_name=>'ADD_CONTACT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7343886609855915317)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Contact'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:106:&SESSION.::&DEBUG.:RP,106:P106_CUSTOMER_ID,P106_SHOW_ACCOUNT:&P105_ID.,N'
,p_security_scheme=>wwv_flow_imp.id(9042571137027542978)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8900251859321987895)
,p_name=>'P105_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8900251653510987894)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(8901288535426242927)
,p_computation_sequence=>10
,p_computation_item=>'LAST_PAGE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'105'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6563907746835118945)
,p_name=>'Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6563908230218118952)
,p_event_id=>wwv_flow_imp.id(6563907746835118945)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8900252238504987896)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6563908701109118953)
,p_event_id=>wwv_flow_imp.id(6563907746835118945)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''Action Processed.'');'
);
wwv_flow_imp.component_end;
end;
/
