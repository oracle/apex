prompt --application/pages/page_00046
begin
--   Manifest
--     PAGE: 00046
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>46
,p_name=>'Revenue by &REP_TITLE.'
,p_alias=>'REVENUE-BY-REP-TITLE'
,p_step_title=>'Revenue by &REP_TITLE_RAW.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(7375353650393743976)
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This page shows a donut pie chart depicting revenue by &REP_TITLE.. Change the "Quarter" and/or "Territory" filter values to vary the pie chart''s results.',
''))
,p_page_component_map=>'04'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10194614868193035168)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(10512992898526525834)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10194612840649035167)
,p_plug_name=>'Button Bar'
,p_static_id=>'button-bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>2127905476394690047
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8057533067080568994)
,p_plug_name=>'Revenue by &REP_TITLE.'
,p_static_id=>'revenue-by-rep-title'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_ajax_items_to_submit=>'P46_QUARTER,P46_TERRITORY'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(6609503715357685266)
,p_region_id=>wwv_flow_imp.id(8057533067080568994)
,p_chart_type=>'donut'
,p_height=>'300'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_format_scaling=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6609503794635685267)
,p_chart_id=>wwv_flow_imp.id(6609503715357685266)
,p_static_id=>'series'
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sr.REP_LAST_NAME||'', ''|| sr.REP_FIRST_NAME||'' - ''||(select territory_name from eba_sales_territories t where t.id = c.customer_territory_id) label,',
'       case when apex_util.get_build_option_status(',
'                     p_application_id    => :APP_ID,',
'                     p_build_option_name => ''Opportunity Amount Set at Product Level''',
'                 ) = ''EXCLUDE'' then',
'           sum(d.deal_amount)',
'       else',
'           sum(nvl((select sum(nvl(dp.quote_price, 0.00)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id), 0))',
'       end as value,',
'       sr.id sales_rep_id',
'  from EBA_SALES_SALESREPS sr,',
'       EBA_SALES_DEALS d,',
'       EBA_SALES_CUSTOMERS c',
' where d.SALESREP_ID_01 = sr.ID (+)',
'   and d.customer_id = c.id ',
'   and (nvl(:P46_QUARTER,''0'') = ''0'' or d.qtr = :P46_QUARTER)',
'   and (nvl(:P46_TERRITORY,''0'') = ''0'' or c.customer_territory_id = :P46_TERRITORY)',
'   and DEAL_PROBABILITY = 100',
'group by sr.REP_LAST_NAME||'', ''|| sr.REP_FIRST_NAME, sr.id, c.customer_territory_id',
'order by 3 desc'))
,p_series_type=>'donut'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7372648843836299856)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10194614868193035168)
,p_button_name=>'RESET_CHART'
,p_static_id=>'reset-chart'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.:RP,46::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10194618262913035172)
,p_name=>'P46_QUARTER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10194612840649035167)
,p_prompt=>'Quarter'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PERIOD_NAME from eba_sales_sales_periods',
' where sysdate between first_day and last_day'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'QUARTER - PAST AND CURRENT'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_lov_null_value=>'0'
,p_cHeight=>1
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7375325044445206204)
,p_name=>'P46_TERRITORY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10194612840649035167)
,p_item_default=>'0'
,p_prompt=>'Territory'
,p_source=>'0'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TERRITORY'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_lov_null_value=>'0'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_required_patch=>wwv_flow_imp.id(10513861890095974398)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10194619556436035173)
,p_computation_sequence=>10
,p_computation_item=>'LAST_PAGE'
,p_static_id=>'last-page'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'46'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6609504075455685270)
,p_name=>'P46_QUARTER or P46_TERRITORY changed'
,p_static_id=>'p46-quarter-or-p46-territory-changed'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P46_QUARTER,P46_TERRITORY'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6609504140985685271)
,p_event_id=>wwv_flow_imp.id(6609504075455685270)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8057533067080568994)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
