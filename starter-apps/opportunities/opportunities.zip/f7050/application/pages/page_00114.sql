prompt --application/pages/page_00114
begin
--   Manifest
--     PAGE: 00114
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>114
,p_name=>'Link Details'
,p_alias=>'LINK-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Link Details'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(9060293328988296381)
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6560181034138791589)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9031775239449600490)
,p_plug_name=>'Opportunity Link'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9031775555113600493)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(6560181034138791589)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CREATE'
,p_button_condition=>'P114_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9031775448570600493)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(6560181034138791589)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Link'
,p_button_position=>'CREATE'
,p_button_condition=>'P114_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9031775828991600493)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6560181034138791589)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'EDIT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9031775636855600493)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(6560181034138791589)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--danger'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Delete'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P114_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6645391255864558884)
,p_name=>'P114_ENTITY_TYPE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(9031775239449600490)
,p_use_cache_before_default=>'NO'
,p_source=>'ENTITY_TYPE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6645391400979558885)
,p_name=>'P114_LEAD_ID'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(9031775239449600490)
,p_use_cache_before_default=>'NO'
,p_source=>'LEAD_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6645391449624558886)
,p_name=>'P114_TERRITORY_ID'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(9031775239449600490)
,p_use_cache_before_default=>'NO'
,p_source=>'TERRITORY_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6645391608350558887)
,p_name=>'P114_ACCOUNT_ID'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(9031775239449600490)
,p_use_cache_before_default=>'NO'
,p_source=>'ACCOUNT_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6645391710680558888)
,p_name=>'P114_CONTACT_ID'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(9031775239449600490)
,p_use_cache_before_default=>'NO'
,p_source=>'CONTACT_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6645391752986558889)
,p_name=>'P114_PRODUCT_ID'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(9031775239449600490)
,p_use_cache_before_default=>'NO'
,p_source=>'PRODUCT_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6653904402968702591)
,p_name=>'P114_ENTITY_ID'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(9031775239449600490)
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when_type=>'NEVER'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9031776644172600500)
,p_name=>'P114_ID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(9031775239449600490)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9031776837073600508)
,p_name=>'P114_OPPORTUNITY_ID'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(9031775239449600490)
,p_use_cache_before_default=>'NO'
,p_source=>'DEAL_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9031777028312600510)
,p_name=>'P114_LINK_TARGET'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9031775239449600490)
,p_use_cache_before_default=>'NO'
,p_item_default=>'http://'
,p_prompt=>'URL'
,p_source=>'LINK_TARGET'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9031777229304600510)
,p_name=>'P114_LINK_TEXT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(9031775239449600490)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Name'
,p_source=>'LINK_TEXT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9031777440864600510)
,p_name=>'P114_LINK_COMMENTS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(9031775239449600490)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Description'
,p_source=>'LINK_COMMENTS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>64
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'N',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9031777633282600510)
,p_name=>'P114_TAGS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(9031775239449600490)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Tags'
,p_source=>'TAGS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(9033291251448360950)
,p_computation_sequence=>10
,p_computation_item=>'P114_LINK_TEXT'
,p_computation_type=>'ITEM_VALUE'
,p_computation=>'P114_LINK_TARGET'
,p_compute_when=>'P114_LINK_TEXT'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(7393357231409557848)
,p_validation_name=>'P114_LINK_TARGET valid URL'
,p_validation_sequence=>10
,p_validation=>'P114_LINK_TARGET'
,p_validation2=>'^http[s]?://[-a-zA-Z0-9_.:]+[-a-zA-Z0-9_:@&?=+,.!/~*''%$]*$'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>'Invalid URL'
,p_associated_item=>wwv_flow_imp.id(9031777028312600510)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(7393488831744532881)
,p_validation_name=>'P114 link not duplicated'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from eba_sales_links',
'where (:P114_ID is null or id != :P114_ID)',
'  and (',
'    (:P114_ENTITY_TYPE = ''OPPORTUNITY'' and deal_id = :P114_OPPORTUNITY_ID)',
'      or (:P114_ENTITY_TYPE = ''LEAD'' and lead_id = :P114_LEAD_ID)',
'      or (:P114_ENTITY_TYPE = ''TERRITORY'' and territory_id = :P114_TERRITORY_ID)',
'      or (:P114_ENTITY_TYPE = ''ACCOUNT'' and account_id = :P114_ACCOUNT_ID)',
'      or (:P114_ENTITY_TYPE = ''CONTACT'' and contact_id = :P114_CONTACT_ID)',
'      or (:P114_ENTITY_TYPE = ''PRODUCT'' and product_id = :P114_PRODUCT_ID)',
'  )',
'  and upper(link_target) = upper(:P114_LINK_TARGET)'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Provided link already exists.'
,p_associated_item=>wwv_flow_imp.id(9031777028312600510)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6560181146058791590)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(9031775828991600493)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6560181276206791591)
,p_event_id=>wwv_flow_imp.id(6560181146058791590)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6645391899941558890)
,p_name=>'Page loaded'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6645391972881558891)
,p_event_id=>wwv_flow_imp.id(6645391899941558890)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var targetElmt = document.getElementById(''P114_LINK_TARGET'');',
'',
'$(targetElmt).focus();',
'',
'// Focus the cursor at the end of the input for the link target',
'targetElmt.selectionStart = targetElmt.selectionEnd = targetElmt.value.length;'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9031778539651600513)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from EBA_SALES_LINKS'
,p_attribute_02=>'EBA_SALES_LINKS'
,p_attribute_03=>'P114_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_internal_uid=>9014056347690847110
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9031778733030600514)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of EBA_SALES_LINKS'
,p_attribute_02=>'EBA_SALES_LINKS'
,p_attribute_03=>'P114_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>9014056541069847111
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9031778943683600514)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9031775636855600493)
,p_internal_uid=>9014056751722847111
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6560180936041791588)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_01=>'REQUEST'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>6542458744081038185
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6654603299771068606)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Proxy P114_ENTITY_ID on create'
,p_process_sql_clob=>'apex_util.set_session_state(''P114_'' || :P114_ENTITY_TYPE || ''_ID'', :P114_ENTITY_ID);'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(9031775448570600493)
,p_internal_uid=>6636881107810315203
,p_process_comment=>'This needs to go before validations and processing to allow them to work correctly.'
);
wwv_flow_imp.component_end;
end;
/
