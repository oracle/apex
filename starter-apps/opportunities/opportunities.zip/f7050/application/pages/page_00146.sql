prompt --application/pages/page_00146
begin
--   Manifest
--     PAGE: 00146
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>146
,p_name=>'Validation Details'
,p_alias=>'VALIDATION-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Validation Details'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(7357625541266796352)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(9042571137027542978)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6407138207233009677)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343855860694915257)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6429138300591355842)
,p_plug_name=>'Validation Details'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(7343855668783915255)
,p_plug_display_sequence=>20
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6429138826543355857)
,p_plug_name=>'form items'
,p_parent_plug_id=>wwv_flow_imp.id(6429138300591355842)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343855668783915255)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6429142573088355873)
,p_plug_name=>'Introduction text'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343855668783915255)
,p_plug_display_sequence=>1
,p_plug_source=>'<p>If you feel information associated with this &P146_ENTITY_TYPE_LOWER. is correct and accurate, please validate it. Enter any comments (optional), check the validation checkbox, and then click the Validate button below.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6429143899531355876)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(6407138207233009677)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886609855915317)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Validate'
,p_button_position=>'CREATE'
,p_icon_css_classes=>'fa-check'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6429143438794355874)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6407138207233009677)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7343886609855915317)
,p_button_image_alt=>'Cancel'
,p_button_position=>'EDIT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(586950775292840927)
,p_name=>'P146_ENTITY_ID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(6429138826543355857)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(586951097556840930)
,p_name=>'P146_ENTITY_TYPE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(6429138826543355857)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6429139605011355864)
,p_name=>'P146_VERIFICATION_COMMENT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(6429138826543355857)
,p_prompt=>'Comment'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(7466594599226885491)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6429139997831355865)
,p_name=>'P146_I_VALIDATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(6429138826543355857)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Check to validate'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC2:I validate this info is accurate;VALIDATED'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(7343885535981915309)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6637010356198819682)
,p_name=>'P146_ENTITY_TYPE_LOWER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(6429138826543355857)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(6407138251169009678)
,p_validation_name=>'P146_I_VALIDATE is not null'
,p_validation_sequence=>10
,p_validation=>'P146_I_VALIDATE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Please check to validate.'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6407138472053009680)
,p_name=>'Cancel clicked'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(6429143438794355874)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6407138623875009681)
,p_event_id=>wwv_flow_imp.id(6407138472053009680)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6429145205132355900)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create validation'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'  l_verification_rec eba_sales_verifications%rowtype;',
'',
'begin',
'',
'  l_verification_rec.verification_comment := :P146_VERIFICATION_COMMENT;',
'  l_verification_rec.entity_type := :P146_ENTITY_TYPE;',
'  l_verification_rec.verified_by := lower(:APP_USER);',
'',
'  case :P146_ENTITY_TYPE',
'    when ''LEAD''',
'    then',
'      l_verification_rec.lead_id := :P146_ENTITY_ID;',
'    when ''OPPORTUNITY''',
'    then',
'      l_verification_rec.opp_id := :P146_ENTITY_ID;',
'    when ''ACCOUNT''',
'    then',
'      l_verification_rec.cust_id := :P146_ENTITY_ID;',
'    when ''TERRITORY''',
'    then',
'      l_verification_rec.territory_id := :P146_ENTITY_ID;',
'    when ''CONTACT''',
'    then',
'      l_verification_rec.contact_id := :P146_ENTITY_ID;',
'    when ''PRODUCT''',
'    then',
'      l_verification_rec.product_id := :P146_ENTITY_ID;',
'  end case;',
'  ',
'  ',
'  insert into eba_sales_verifications values l_verification_rec;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Unable to save validation.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(6429143899531355876)
,p_process_success_message=>'Validation saved.'
,p_internal_uid=>6429145205132355900
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6407138390542009679)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'close dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(6429143899531355876)
,p_internal_uid=>6407138390542009679
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6637010483017819683)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Init page'
,p_process_sql_clob=>':P146_ENTITY_TYPE_LOWER := lower(:P146_ENTITY_TYPE);'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>6637010483017819683
);
wwv_flow_imp.component_end;
end;
/
