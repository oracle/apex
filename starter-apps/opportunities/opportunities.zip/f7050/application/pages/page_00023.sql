prompt --application/pages/page_00023
begin
--   Manifest
--     PAGE: 00023
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>23
,p_user_interface_id=>wwv_flow_api.id(6988712858842356549)
,p_name=>'Contacts'
,p_alias=>'CONTACTS2'
,p_step_title=>'Contacts'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_api.id(7357641247631157813)
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// standard, cacheable elements',
'var timeout = 0; // used for debounce on search',
'var CONTAINER_SEL = ''.t-Form-fieldContainer'';',
'var pagePrefix = ''P'' + $(''#pFlowStepId'').val();',
'var displayAsId = pagePrefix + ''_DISPLAY_AS'';',
'var $displayAs = $(''#'' + displayAsId);',
'var $body = $(''.t-PageBody'');',
'var $search = $(''#'' + pagePrefix + ''_SEARCH'');',
'var $sort = $(''#'' + pagePrefix + ''_SORT'');',
'var $reset = $(''#reset_button'');',
'var $cardsReg = $(''#cards_region'');',
'var $reportReg = $(''#report_region'');',
'var $gridReg = $(''#grid_region'');',
'',
'// custom items (will vary by page)',
'var $territory = $(''#'' + pagePrefix + ''_TERRITORY_ID'');',
'var $account = $(''#'' + pagePrefix + ''_ACCOUNT_ID'');',
'',
'function showLeftColumn() {',
'  $body',
'    .removeClass(''t-PageBody--hideLeft'')',
'    .addClass(''t-PageBody--showLeft'');',
'    ',
'  // Takes 200ms to hide column',
'  setTimeout(function() {',
'    // Ensure column headers align correctly',
'    $(window).trigger(''apexwindowresized'');',
'  }, 250);',
'}',
'',
'function hideLeftColumn() {',
'  $body',
'    .removeClass(''t-PageBody--showLeft'')',
'    .addClass(''t-PageBody--hideLeft'');',
'    ',
'  // Takes 200ms to hide column',
'  setTimeout(function() {',
'    // Ensure column headers align correctly',
'    $(window).trigger(''apexwindowresized'');',
'  }, 250);',
'}',
'  ',
'// applyFilters triggers the refresh event on the correct region',
'function applyFilters() {',
'  var display = $v(displayAsId);',
'  ',
'  if (display === ''CARDS'') {',
'    $cardsReg.trigger(''apexrefresh'');',
'  } else if (display === ''REPORT'') {',
'    $reportReg.trigger(''apexrefresh'');',
'  } else if (display === ''GRID'') {',
'    $gridReg.trigger(''apexrefresh'');',
'  }',
'}',
'',
'// toggleRegionDisplay is similar to applyFilters except that it also',
'// takes into account what regions or items need to be displayed or hidden',
'function toggleRegionDisplay(refresh) {',
'  var display = $v(displayAsId);',
'  ',
'  refresh = (refresh === false) ? false : true;',
'  ',
'  if (display === ''CARDS'') {',
'    $reportReg.hide();',
'    $gridReg.hide();',
'',
'    showLeftColumn();',
'',
'    $sort.closest(CONTAINER_SEL).show();',
'',
'    if (refresh) {',
'      $cardsReg.trigger(''apexrefresh'');',
'    }',
'    ',
'    $cardsReg.show();',
'  } else if (display === ''REPORT'') {',
'    $sort.closest(CONTAINER_SEL).hide();',
'    $cardsReg.hide();',
'    $gridReg.hide();',
'',
'    showLeftColumn();',
'',
'    if (refresh) {',
'      $reportReg.trigger(''apexrefresh'');',
'    }',
'',
'    $reportReg.show();',
'  } else if (display === ''GRID'') {',
'    $sort.closest(CONTAINER_SEL).hide();',
'    $cardsReg.hide();',
'    $reportReg.hide();',
'',
'    hideLeftColumn();',
'',
'    if (refresh) {',
'      $gridReg.trigger(''apexrefresh'');',
'    }',
'',
'    $gridReg.show();',
'  }',
'}',
'  ',
'function debounceSearch(e) {',
'    /*',
'     * Prevent search for following keys:',
'     * TAB:     9',
'     * SHIFT:   16',
'     * LEFT:    37',
'     * RIGHT:   39',
'     */',
'    if ( e.which === 9 || e.which === 16 || e.which === 37 || e.which === 39 ) {',
'        return false;',
'    }',
'    clearTimeout(timeout);',
'    timeout = setTimeout(applyFilters, 250);',
'}',
'  ',
'function preventSubmitOnEnter(e) {',
'  if (e.which === 13) {',
'    return false;',
'  }',
'}',
'',
'function resetFilters() {',
'  $search.val(null);',
'  $territory.val(null);',
'  $account.val(null);',
'  ',
'  $sort.val(''NAME'');',
'',
'  applyFilters();',
'}',
'',
'// standard search event bindings',
'$search.keydown(preventSubmitOnEnter);',
'$search.keyup(debounceSearch);',
'',
'// dynamic event bindings (will vary by filter page)',
'$territory.change(applyFilters);',
'$account.change(applyFilters);',
'',
'// standard display, sort, reset event bindings',
'$displayAs.change(toggleRegionDisplay);',
'$sort.change(applyFilters);',
'$reset.click(resetFilters);',
'  ',
'toggleRegionDisplay(false);'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Card-initials {',
'  font-size: 14px;',
'}'))
,p_step_template=>wwv_flow_api.id(7343828740328915198)
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_api.id(10496478296281986809)
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'Use the filters on the left to show different results in the region on the right. The right region can be displayed in one of three ways (Cards View, Report View, and Customizable Grid) by using the display-mode buttons located just to the left of th'
||'e <strong>Create Contact</strong> button. Filters are not displayed in the Customizable Grid view.',
''))
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20210301101414'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(6574209451821083465)
,p_name=>'Contacts Report'
,p_region_name=>'report_region'
,p_template=>wwv_flow_api.id(7343866444940915275)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline'
,p_region_attributes=>'style="display:none"'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select cc.id, ',
'  cc.row_key,',
'  cc.contact_name,',
'  cc.contact_email,',
'  cc.customer_id,',
'  c.customer_name account,',
'  cc.updated,',
'  t.territory_name,',
'  t.id territory_id',
'from eba_sales_customer_contacts cc',
'join eba_sales_customers c',
'  on c.id = cc.customer_id',
'join eba_sales_territories t',
'  on t.id = c.customer_territory_id',
'where :P23_DISPLAY_AS = ''REPORT''',
'  and (',
'    :P23_TERRITORY_ID is null ',
'      or t.id = :P23_TERRITORY_ID',
'  )',
'  and (',
'    :P23_ACCOUNT_ID is null ',
'      or cc.customer_id = :P23_ACCOUNT_ID',
'  )',
'  and (',
'    :P23_SEARCH is null',
'      or instr(upper(cc.contact_name), upper(:P23_SEARCH)) > 0',
'      or instr(upper(cc.row_key), upper(:P23_SEARCH)) > 0',
'      or instr(upper(cc.contact_email), upper(:P23_SEARCH)) > 0',
'      or instr(upper(c.customer_name), upper(:P23_SEARCH)) > 0',
'      or instr(upper(t.territory_name), upper(:P23_SEARCH)) > 0',
'      or instr(upper(apex_util.get_since(cc.updated)), upper(:P23_SEARCH)) > 0',
'  )'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P23_SEARCH,P23_TERRITORY_ID,P23_ACCOUNT_ID,P23_DISPLAY_AS,P23_SORT'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(7343873253436915289)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'No contacts found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6574209628446083466)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6574209686177083467)
,p_query_column_id=>2
,p_column_alias=>'ROW_KEY'
,p_column_display_sequence=>3
,p_column_heading=>'Key'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6574209770969083468)
,p_query_column_id=>3
,p_column_alias=>'CONTACT_NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Contact'
,p_column_link=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:RP,24:P24_ID:#ID#'
,p_column_linktext=>'#CONTACT_NAME#'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6574209917849083469)
,p_query_column_id=>4
,p_column_alias=>'CONTACT_EMAIL'
,p_column_display_sequence=>7
,p_column_heading=>'Email'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6574209945552083470)
,p_query_column_id=>5
,p_column_alias=>'CUSTOMER_ID'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6574210123923083471)
,p_query_column_id=>6
,p_column_alias=>'ACCOUNT'
,p_column_display_sequence=>5
,p_column_heading=>'Account'
,p_column_link=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP,94:P94_ID:#CUSTOMER_ID#'
,p_column_linktext=>'#ACCOUNT#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6574210280219083473)
,p_query_column_id=>7
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>8
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6592772193414034152)
,p_query_column_id=>8
,p_column_alias=>'TERRITORY_NAME'
,p_column_display_sequence=>6
,p_column_heading=>'Account Territory'
,p_column_link=>'f?p=&APP_ID.:93:&SESSION.::&DEBUG.:RP,93:P93_ID:#TERRITORY_ID#'
,p_column_linktext=>'#TERRITORY_NAME#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Territories''',
') = ''INCLUDE'''))
,p_display_when_condition2=>'PLSQL'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6592774324776034173)
,p_query_column_id=>9
,p_column_alias=>'TERRITORY_ID'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6574210170041083472)
,p_plug_name=>'Filters'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_api.id(7343866444940915275)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(6574210410480083474)
,p_name=>'Contacts Cards'
,p_region_name=>'cards_region'
,p_template=>wwv_flow_api.id(7343855668783915255)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--basic:t-Cards--3cols:t-Cards--animColorFill'
,p_region_attributes=>'style="display:none"'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with base_contacts as (',
'  select cc.id, ',
'    cc.row_key,',
'    cc.contact_name,',
'    cc.contact_email,',
'    cc.contact_phone,',
'    cc.customer_id account_id,',
'    c.customer_name account_name,',
'    cc.updated',
'  from eba_sales_customer_contacts cc',
'  join eba_sales_customers c',
'    on c.id = cc.customer_id',
'  join eba_sales_territories t',
'    on t.id = c.customer_territory_id',
'  where :P23_DISPLAY_AS = ''CARDS''',
'    and (:P23_TERRITORY_ID is null or t.id = :P23_TERRITORY_ID)',
'    and (:P23_ACCOUNT_ID is null or cc.customer_id = :P23_ACCOUNT_ID)',
'),',
'card_details as (',
'  select contact_name card_title,',
'    null card_icon,',
'    row_key card_initials,',
'    null card_text,',
'    ''Account: '' || account_name card_text_p1,',
'    ''Email: '' || contact_email card_text_p2,',
'    ''Phone: '' || contact_phone card_text_p3,',
'    apex_util.prepare_url(',
'      ''f?p='' ||',
'      :APP_ID ||',
'      '':24:'' ||',
'      :APP_SESSION ||',
'      '':::24,RP:P24_ID:'' ||',
'      id',
'    ) card_link,',
'    id,',
'    updated card_subtext,',
'    updated,',
'    contact_name,',
'    account_name',
'  from base_contacts',
')',
'select *',
'from card_details',
'where (',
'  :P23_SEARCH is null',
'    or instr(upper(card_title), upper(:P23_SEARCH)) > 0',
'    or instr(upper(card_text_p1), upper(:P23_SEARCH)) > 0',
'    or instr(upper(card_text_p2), upper(:P23_SEARCH)) > 0',
'    or instr(upper(card_text_p3), upper(:P23_SEARCH)) > 0',
'    or instr(upper(card_initials), upper(:P23_SEARCH)) > 0',
'    or instr(upper(''Updated: '' || apex_util.get_since(card_subtext)), upper(:P23_SEARCH)) > 0',
')',
'order by',
'  case :P23_SORT',
'    when ''NAME'' then contact_name',
'  end,',
'  case :P23_SORT',
'    when ''ACCOUNT'' then account_name',
'  end desc,',
'  case :P23_SORT',
'    when ''UPDATED'' then updated',
'  end desc'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P23_SEARCH,P23_TERRITORY_ID,P23_ACCOUNT_ID,P23_DISPLAY_AS,P23_SORT'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(7400884047268179746)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'No contacts found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6574210448761083475)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>1
,p_column_heading=>'Card title'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6574210597828083476)
,p_query_column_id=>2
,p_column_alias=>'CARD_ICON'
,p_column_display_sequence=>2
,p_column_heading=>'Card icon'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6574211212901083482)
,p_query_column_id=>3
,p_column_alias=>'CARD_INITIALS'
,p_column_display_sequence=>7
,p_column_heading=>'Card initials'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6574210700461083477)
,p_query_column_id=>4
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>3
,p_column_heading=>'Card text'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#CARD_TEXT_P1#<br >',
'<small>',
'#CARD_TEXT_P2#<br />',
'#CARD_TEXT_P3#<br />',
'</small>',
''))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6574210751670083478)
,p_query_column_id=>5
,p_column_alias=>'CARD_TEXT_P1'
,p_column_display_sequence=>4
,p_column_heading=>'Card text p1'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6574210892084083479)
,p_query_column_id=>6
,p_column_alias=>'CARD_TEXT_P2'
,p_column_display_sequence=>5
,p_column_heading=>'Card text p2'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6557186173732338375)
,p_query_column_id=>7
,p_column_alias=>'CARD_TEXT_P3'
,p_column_display_sequence=>13
,p_column_heading=>'Card text p3'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6574211086324083481)
,p_query_column_id=>8
,p_column_alias=>'CARD_LINK'
,p_column_display_sequence=>6
,p_column_heading=>'Card link'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6574211292633083483)
,p_query_column_id=>9
,p_column_alias=>'ID'
,p_column_display_sequence=>8
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6574211394837083484)
,p_query_column_id=>10
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>9
,p_column_heading=>'Card subtext'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_column_html_expression=>'Updated: #CARD_SUBTEXT#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6574211713453083487)
,p_query_column_id=>11
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>10
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6574211852459083489)
,p_query_column_id=>12
,p_column_alias=>'CONTACT_NAME'
,p_column_display_sequence=>11
,p_column_heading=>'Contact name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6574212037819083491)
,p_query_column_id=>13
,p_column_alias=>'ACCOUNT_NAME'
,p_column_display_sequence=>12
,p_column_heading=>'Account name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6592772328374034153)
,p_plug_name=>'Contacts Grid'
,p_region_name=>'grid_region'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7343865001510915269)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select cc.id, ',
'  cc.row_key,',
'  cc.contact_title,',
'  cc.contact_name,',
'  cc.contact_email,',
'  cc.contact_phone,',
'  cc.contact_cell,',
'  cc.contact_address,',
'  cc.contact_description,',
'  cc.contact_linkedin,',
'  cc.contact_facebook,',
'  cc.contact_twitter,',
'  cc.customer_id,',
'  c.customer_name account,',
'  cc.tags,',
'  (',
'    select count(*)',
'    from eba_sales_links',
'    where contact_id = cc.id',
'  ) links,',
'  (',
'    select count(*)',
'    from eba_sales_files',
'    where contact_id = cc.id',
'  ) attachments,',
'  (',
'    select count(*)',
'    from eba_sales_comments',
'    where contact_id = cc.id',
'  ) comments,',
'  (',
'    select count(*)',
'    from eba_sales_verifications',
'    where contact_id = cc.id',
'  ) validations,',
'  (',
'    select max(created)',
'    from eba_sales_verifications',
'    where contact_id = cc.id',
'  ) last_validation,',
'  (',
'    select count(*)',
'    from eba_sales_clicks',
'    where contact_id = cc.id',
'      and view_timestamp >= sysdate - 90',
'  ) views_90_days,',
'    (   select count(distinct(app_username))',
'        from eba_sales_clicks',
'        where contact_id = cc.id',
'            and view_timestamp >= sysdate - 90',
'  ) users_90_days,',
'  cc.created,',
'  cc.created_by,',
'  cc.updated,',
'  cc.updated_by,',
'  t.territory_name,',
'  t.id territory_id',
'from eba_sales_customer_contacts cc',
'join eba_sales_customers c',
'  on c.id = cc.customer_id',
'left join eba_sales_territories t',
'  on t.id = c.customer_territory_id',
'where :P23_DISPLAY_AS = ''GRID'''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P23_DISPLAY_AS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(6592772374690034154)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:EMAIL:XLSX:PDF:RTF'
,p_owner=>'DAN'
,p_internal_uid=>721909340236468407
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6592772510138034155)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6592772633103034156)
,p_db_column_name=>'ROW_KEY'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Key'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6592772672955034157)
,p_db_column_name=>'CONTACT_NAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Contact'
,p_column_link=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:RP,24:P24_ID:#ID#'
,p_column_linktext=>'#CONTACT_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6592772834237034158)
,p_db_column_name=>'CONTACT_EMAIL'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6592773025354034160)
,p_db_column_name=>'ACCOUNT'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Account'
,p_column_link=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP,94:P94_ID:#CUSTOMER_ID#'
,p_column_linktext=>'#ACCOUNT#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6592773208220034162)
,p_db_column_name=>'TERRITORY_NAME'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Account Territory'
,p_column_link=>'f?p=&APP_ID.:93:&SESSION.::&DEBUG.:RP,93:P93_ID:#TERRITORY_ID#'
,p_column_linktext=>'#TERRITORY_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Territories''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6592773598901034166)
,p_db_column_name=>'CONTACT_PHONE'
,p_display_order=>90
,p_column_identifier=>'L'
,p_column_label=>'Phone'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6592773665039034167)
,p_db_column_name=>'CONTACT_CELL'
,p_display_order=>100
,p_column_identifier=>'M'
,p_column_label=>'Cell'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6592773751295034168)
,p_db_column_name=>'CONTACT_ADDRESS'
,p_display_order=>110
,p_column_identifier=>'N'
,p_column_label=>'Address'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6592773924001034169)
,p_db_column_name=>'CONTACT_DESCRIPTION'
,p_display_order=>120
,p_column_identifier=>'O'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6592773961601034170)
,p_db_column_name=>'CONTACT_LINKEDIN'
,p_display_order=>130
,p_column_identifier=>'P'
,p_column_label=>'LinkedIn'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6592774070490034171)
,p_db_column_name=>'CONTACT_FACEBOOK'
,p_display_order=>140
,p_column_identifier=>'Q'
,p_column_label=>'Facebook'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6592774228247034172)
,p_db_column_name=>'CONTACT_TWITTER'
,p_display_order=>150
,p_column_identifier=>'R'
,p_column_label=>'Twitter'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6592773040940034161)
,p_db_column_name=>'UPDATED'
,p_display_order=>160
,p_column_identifier=>'G'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_TIME_FMT.'
,p_tz_dependent=>'Y'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6592773282623034163)
,p_db_column_name=>'CREATED'
,p_display_order=>170
,p_column_identifier=>'I'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_TIME_FMT.'
,p_tz_dependent=>'Y'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6592773341452034164)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>180
,p_column_identifier=>'J'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6592773464818034165)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>190
,p_column_identifier=>'K'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6592772837965034159)
,p_db_column_name=>'CUSTOMER_ID'
,p_display_order=>200
,p_column_identifier=>'E'
,p_column_label=>'Customer id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6592774361190034174)
,p_db_column_name=>'TERRITORY_ID'
,p_display_order=>210
,p_column_identifier=>'S'
,p_column_label=>'Territory id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6661032165759044686)
,p_db_column_name=>'TAGS'
,p_display_order=>220
,p_column_identifier=>'T'
,p_column_label=>'Tags'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6661032322522044687)
,p_db_column_name=>'LINKS'
,p_display_order=>230
,p_column_identifier=>'U'
,p_column_label=>'Links'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6661032391322044688)
,p_db_column_name=>'ATTACHMENTS'
,p_display_order=>240
,p_column_identifier=>'V'
,p_column_label=>'Attachments'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6661032480205044689)
,p_db_column_name=>'COMMENTS'
,p_display_order=>250
,p_column_identifier=>'W'
,p_column_label=>'Comments'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6661032571138044690)
,p_db_column_name=>'VALIDATIONS'
,p_display_order=>260
,p_column_identifier=>'X'
,p_column_label=>'Validations'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Validations''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6661032699962044691)
,p_db_column_name=>'LAST_VALIDATION'
,p_display_order=>270
,p_column_identifier=>'Y'
,p_column_label=>'Last Validation'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Validations''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6661032737833044692)
,p_db_column_name=>'VIEWS_90_DAYS'
,p_display_order=>280
,p_column_identifier=>'Z'
,p_column_label=>'90 Day Views'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Usage Metrics''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6802490168587595754)
,p_db_column_name=>'USERS_90_DAYS'
,p_display_order=>290
,p_column_identifier=>'AA'
,p_column_label=>'90 Day Users'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Usage Metrics''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5837785989143087284)
,p_db_column_name=>'CONTACT_TITLE'
,p_display_order=>300
,p_column_identifier=>'AB'
,p_column_label=>'Title'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(6592829693094188771)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'7219667'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CONTACT_NAME:CONTACT_TITLE:ROW_KEY:ACCOUNT:CONTACT_EMAIL:CONTACT_PHONE:CONTACT_CELL:'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(10495960299417590175)
,p_plug_name=>'Contacts'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_plug_template=>wwv_flow_api.id(7343861764153915263)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6592772111086034151)
,p_plug_name=>'Page Settings'
,p_parent_plug_id=>wwv_flow_api.id(10495960299417590175)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7343855668783915255)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6584510596086968865)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(6574210170041083472)
,p_button_name=>'RESET'
,p_button_static_id=>'reset_button'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(7343886016830915316)
,p_button_image_alt=>'Reset'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(10248073166204687161)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(10495960299417590175)
,p_button_name=>'CREATE_CONTACT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_api.id(7343886609855915317)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Contact'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:106:&SESSION.::&DEBUG.:RP,106:P106_SHOW_ACCOUNT:Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6800888992382182252)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(6592772328374034153)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(7343886016830915316)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&SESSION.::&DEBUG.:RIR,CIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6584499110414523882)
,p_name=>'P23_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(6574210170041083472)
,p_prompt=>'Search'
,p_placeholder=>'Search Contacts'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_api.id(7343885535981915309)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6584507761358935456)
,p_name=>'P23_ACCOUNT_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(6574210170041083472)
,p_prompt=>'Account'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'ACCOUNTS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CUSTOMER_NAME display_value, ID return_value ',
'from eba_sales_CUSTOMERS',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7466594599226885491)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6584508126529940511)
,p_name=>'P23_DISPLAY_AS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(6592772111086034151)
,p_item_default=>'CARDS'
,p_prompt=>'Display'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'PILL_DISPLAY_AS'
,p_lov=>'.'||wwv_flow_api.id(7350672914166113674)||'.'
,p_field_template=>wwv_flow_api.id(7343885535981915309)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:t-Form-fieldContainer--radioButtonGroup'
,p_is_persistent=>'U'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_attribute_01=>'4'
,p_attribute_02=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6584508370016942047)
,p_name=>'P23_SORT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(6574210170041083472)
,p_item_default=>'NAME'
,p_prompt=>'Sort'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Contact;NAME,Account;ACCOUNT,Updated;UPDATED'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7466594599226885491)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'U'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(6592809636446118309)
,p_name=>'P23_TERRITORY_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(6574210170041083472)
,p_prompt=>'Account Territory'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TERRITORY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TERRITORY_NAME display_value, ID return_value ',
'from eba_sales_TERRITORIES',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(7466594599226885491)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_required_patch=>wwv_flow_api.id(10496139698135220995)
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(10172038473096266019)
,p_computation_sequence=>10
,p_computation_item=>'LAST_PAGE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'23'
,p_compute_when_type=>'%null%'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6557307305518941532)
,p_name=>'Create Contact dialog closed'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(10248073166204687161)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6557307681868941536)
,p_event_id=>wwv_flow_api.id(6557307305518941532)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var display = $v(''P23_DISPLAY_AS'');',
'',
'if (display === ''CARDS'') {',
'  $(''#cards_region'').trigger(''apexrefresh'');',
'} else if (display === ''REPORT'') {',
'  $(''#report_region'').trigger(''apexrefresh'');',
'} else if (display === ''GRID'') {',
'  $(''#grid_region'').trigger(''apexrefresh'');',
'}',
'',
'apex.message.showPageSuccess(''Action Processed.'');'))
);
wwv_flow_api.component_end;
end;
/
