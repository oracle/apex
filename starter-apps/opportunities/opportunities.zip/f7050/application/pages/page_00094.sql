prompt --application/pages/page_00094
begin
--   Manifest
--     PAGE: 00094
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>94
,p_user_interface_id=>wwv_flow_api.id(6988712858842356549)
,p_name=>'Account'
,p_alias=>'ACCOUNT'
,p_step_title=>'Account'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(7357625541266796352)
,p_step_template=>wwv_flow_api.id(7343838829035915213)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'Manage an account''s contact information, competitors, locations, links, attachments, and/or comments. You can also validate the account.'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20210301101414'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(6047328493597045894)
,p_name=>'Agreements'
,p_template=>wwv_flow_api.id(7343866444940915275)
,p_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'js-dynamicHideShowRegion'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    id,',
'    name,',
'    close_date,',
'    term_id,',
'    agreement_id,',
'    quote_price,',
'    created_by,',
'    created,',
'    updated_by,',
'    updated',
'from',
'    EBA_SALES_CUST_AGRMNT_MAP',
'where',
'    customer_id = :P94_ID;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P94_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(7343873253436915289)
,p_query_num_rows=>5000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_required_patch=>wwv_flow_api.id(6098380714489638355)
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6047326686537045876)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6047328391670045893)
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Account Agreement'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from EBA_SALES_CUST_AGRMNT_MAP m',
' where m.name not in (select distinct name from eba_sales_agreements where id = m.agreement_id)',
'  and m.customer_id = :P94_ID'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6047328209252045892)
,p_query_column_id=>3
,p_column_alias=>'CLOSE_DATE'
,p_column_display_sequence=>4
,p_column_heading=>'Close Date'
,p_use_as_row_header=>'N'
,p_column_format=>'DD-MON-YYYY'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6047328110078045891)
,p_query_column_id=>4
,p_column_alias=>'TERM_ID'
,p_column_display_sequence=>5
,p_column_heading=>'Term'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(6104196949703947859)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6047328024254045890)
,p_query_column_id=>5
,p_column_alias=>'AGREEMENT_ID'
,p_column_display_sequence=>3
,p_column_heading=>'Agreement'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(6118273411059368482)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6047327943795045889)
,p_query_column_id=>6
,p_column_alias=>'QUOTE_PRICE'
,p_column_display_sequence=>6
,p_column_heading=>'Quote Price'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G999'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6047327901305045888)
,p_query_column_id=>7
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6047327725021045887)
,p_query_column_id=>8
,p_column_alias=>'CREATED'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6047327684878045886)
,p_query_column_id=>9
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>9
,p_column_heading=>'Updated by'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6047327582610045885)
,p_query_column_id=>10
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>10
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7349603971468212649)
,p_plug_name=>'RDS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7343855668783915255)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7378676440719153066)
,p_plug_name=>'Validations'
,p_region_css_classes=>'js-validateRegion'
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--hiddenOverflow'
,p_plug_template=>wwv_flow_api.id(7343866444940915275)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.verified_by,',
'  v.created',
'from eba_sales_verifications v',
'where cust_id = :P94_ID',
'order by v.created desc'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.VALIDATOR'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_required_patch=>wwv_flow_api.id(7381617337298872120)
,p_attribute_01=>'f?p=&APP_ID.:146:&SESSION.::&DEBUG.:146:P146_ENTITY_TYPE,P146_ENTITY_ID:ACCOUNT,&P94_ID.'
,p_attribute_02=>'f?p=&APP_ID.:147:&SESSION.::&DEBUG.:RP,147:P147_ENTITY_TYPE,P147_ENTITY_ID:ACCOUNT,&P94_ID.'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8168639033480536337)
,p_plug_name=>'Usage Metrics - 90 days'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(7343866444940915275)
,p_plug_display_sequence=>100
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select count(*) c,',
'  ''Views'' l,',
'  1 disp',
'from eba_sales_clicks',
'where cust_id = :P94_ID ',
'  and view_timestamp > sysdate - 90',
'union all',
'select count(distinct(app_username)) c,',
'    ''Users'' l,',
'    2 disp',
'from eba_sales_clicks',
'where cust_id = :P94_ID ',
'  and view_timestamp > sysdate - 90',
'order by disp'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_required_patch=>wwv_flow_api.id(6628607810862680350)
,p_attribute_01=>'L'
,p_attribute_02=>'C'
,p_attribute_04=>'f?p=&APP_ID.:138:&SESSION.::&DEBUG.:138:P138_ENTITY_TYPE,P138_ENTITY_ID:ACCOUNT,&P94_ID.'
,p_attribute_05=>'2'
,p_attribute_06=>'L'
,p_attribute_07=>'DOT'
,p_attribute_08=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(8433002053482354597)
,p_name=>'Support Amounts'
,p_template=>wwv_flow_api.id(7343866444940915275)
,p_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'js-dynamicHideShowRegion'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    id,',
'    name,',
'    close_date,',
'    term_id,',
'    amount_id,',
'    quote_price,',
'    created_by,',
'    created,',
'    updated_by,',
'    updated',
'from',
'    EBA_SALES_CUST_SPT_AMT_MAP',
'where',
'    customer_id = :P94_ID;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P94_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(7343873253436915289)
,p_query_num_rows=>5000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_required_patch=>wwv_flow_api.id(8451179641625791308)
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8451263567189738248)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8451263680798738249)
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Account Support Amount'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from EBA_SALES_CUST_SPT_AMT_MAP m',
' where m.name not in (select distinct name from EBA_SALES_SUPPORT_AMTS where id = m.amount_id)',
'  and m.customer_id = :P94_ID'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8451263773660738250)
,p_query_column_id=>3
,p_column_alias=>'CLOSE_DATE'
,p_column_display_sequence=>4
,p_column_heading=>'Close Date'
,p_use_as_row_header=>'N'
,p_column_format=>'DD-MON-YYYY'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8451263839239738251)
,p_query_column_id=>4
,p_column_alias=>'TERM_ID'
,p_column_display_sequence=>5
,p_column_heading=>'Term'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(6104196949703947859)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8451264609302738258)
,p_query_column_id=>5
,p_column_alias=>'AMOUNT_ID'
,p_column_display_sequence=>3
,p_column_heading=>'Support Amount'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(8451253329091624985)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8451264047574738253)
,p_query_column_id=>6
,p_column_alias=>'QUOTE_PRICE'
,p_column_display_sequence=>6
,p_column_heading=>'Quote Price'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G999'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8451264200926738254)
,p_query_column_id=>7
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8451264307212738255)
,p_query_column_id=>8
,p_column_alias=>'CREATED'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8451264416438738256)
,p_query_column_id=>9
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>9
,p_column_heading=>'Updated by'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8451264481592738257)
,p_query_column_id=>10
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>10
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8880073845567293615)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7343869008886915277)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(10495270706565772431)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(7343886820987915318)
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(8880637059204696860)
,p_name=>'Account'
,p_template=>wwv_flow_api.id(7343855668783915255)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_display_point=>'REGION_POSITION_02'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c.id,',
'  c.row_key,',
'    case customer_is_key_account_yn',
'      when ''Y'' then ''Yes''',
'      when ''N'' then ''No''',
'    end key_account,',
'  c.customer_stock_symb,',
'  c.customer_duns,',
'  c.secondary_rep,',
'  c.customer_sic,',
'  c.customer_industry_id as industry,',
'  c.customer_web_site,',
'  c.customer_facebook,',
'  c.customer_linkedin,',
'  c.customer_twitter,',
'  c.customer_description,',
'  c.tags,',
'  c.created,',
'  lower(c.created_by) created_by,',
'  c.updated,',
'  lower(c.updated_by) updated_by,',
'  t.id territory_id,',
'  t.territory_name,',
'  case',
'    when c.default_rep_id is not null',
'    then (',
'      select rep_first_name || '' '' || rep_last_name',
'      from eba_sales_salesreps sr',
'      where sr.id = c.default_rep_id',
'    )',
'  end default_rep',
'from eba_sales_customers c',
'left join eba_sales_territories t',
'  on t.id = c.customer_territory_id',
'where c.id = :P94_ID'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(7343875181010915291)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'0'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8880637362347696869)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8880637455039696870)
,p_query_column_id=>2
,p_column_alias=>'ROW_KEY'
,p_column_display_sequence=>2
,p_column_heading=>'Key'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8880638242996696870)
,p_query_column_id=>3
,p_column_alias=>'KEY_ACCOUNT'
,p_column_display_sequence=>6
,p_column_heading=>'Key Account'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customers',
' where id = :P94_ID',
'   and customer_is_key_account_yn is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6597149195021006776)
,p_query_column_id=>4
,p_column_alias=>'CUSTOMER_STOCK_SYMB'
,p_column_display_sequence=>10
,p_column_heading=>'Stock Symbol'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customers',
' where id = :P94_ID',
'   and CUSTOMER_STOCK_SYMB is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6597149270829006777)
,p_query_column_id=>5
,p_column_alias=>'CUSTOMER_DUNS'
,p_column_display_sequence=>11
,p_column_heading=>'DUNS'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customers',
' where id = :P94_ID',
'   and CUSTOMER_DUNS is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8433001484934354591)
,p_query_column_id=>6
,p_column_alias=>'SECONDARY_REP'
,p_column_display_sequence=>5
,p_column_heading=>'Default &SALES_LDR_TITLE.'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customers',
' where id = :P94_ID',
'   and SECONDARY_REP is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6597149398339006778)
,p_query_column_id=>7
,p_column_alias=>'CUSTOMER_SIC'
,p_column_display_sequence=>12
,p_column_heading=>'SIC'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customers',
' where id = :P94_ID',
'   and CUSTOMER_SIC is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(5837785745256087281)
,p_query_column_id=>8
,p_column_alias=>'INDUSTRY'
,p_column_display_sequence=>21
,p_column_heading=>'Industry'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customers',
' where id = :P94_ID',
'   and CUSTOMER_INDUSTRY_ID is not null'))
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_api.id(5870909235935719754)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8880637956204696870)
,p_query_column_id=>9
,p_column_alias=>'CUSTOMER_WEB_SITE'
,p_column_display_sequence=>13
,p_column_heading=>'Web Site'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customers',
' where id = :P94_ID',
'   and CUSTOMER_WEB_SITE is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6597148823449006772)
,p_query_column_id=>10
,p_column_alias=>'CUSTOMER_FACEBOOK'
,p_column_display_sequence=>15
,p_column_heading=>'Facebook'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customers',
' where id = :P94_ID',
'   and CUSTOMER_FACEBOOK is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6597148932118006773)
,p_query_column_id=>11
,p_column_alias=>'CUSTOMER_LINKEDIN'
,p_column_display_sequence=>14
,p_column_heading=>'LinkedIn'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customers',
' where id = :P94_ID',
'   and CUSTOMER_LINKEDIN is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6597149032979006774)
,p_query_column_id=>12
,p_column_alias=>'CUSTOMER_TWITTER'
,p_column_display_sequence=>16
,p_column_heading=>'Twitter'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customers',
' where id = :P94_ID',
'   and CUSTOMER_TWITTER is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6597149092050006775)
,p_query_column_id=>13
,p_column_alias=>'CUSTOMER_DESCRIPTION'
,p_column_display_sequence=>8
,p_column_heading=>'Description'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customers',
' where id = :P94_ID',
'   and CUSTOMER_DESCRIPTION is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8880639137640696870)
,p_query_column_id=>14
,p_column_alias=>'TAGS'
,p_column_display_sequence=>9
,p_column_heading=>'Tags'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customers',
' where id = :P94_ID',
'   and tags is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636178161072949148)
,p_query_column_id=>15
,p_column_alias=>'CREATED'
,p_column_display_sequence=>17
,p_column_heading=>'Created'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_column_html_expression=>'#CREATED# by #CREATED_BY#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636178249082949149)
,p_query_column_id=>16
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>18
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636178376747949150)
,p_query_column_id=>17
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>19
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_column_html_expression=>'#UPDATED# by #UPDATED_BY#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636178493825949151)
,p_query_column_id=>18
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8880638349622696870)
,p_query_column_id=>19
,p_column_alias=>'TERRITORY_ID'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8880638165839696870)
,p_query_column_id=>20
,p_column_alias=>'TERRITORY_NAME'
,p_column_display_sequence=>3
,p_column_heading=>'Territory'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Territories''',
') = ''INCLUDE'''))
,p_display_when_condition2=>'PLSQL'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8880639063862696870)
,p_query_column_id=>21
,p_column_alias=>'DEFAULT_REP'
,p_column_display_sequence=>7
,p_column_heading=>'Default &REP_TITLE.'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customers',
' where id = :P94_ID',
'   and default_rep_id is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(8881427957427018050)
,p_plug_name=>'Account Actions'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-LinksList--actions:t-LinksList--showIcons'
,p_plug_template=>wwv_flow_api.id(7343855668783915255)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_list_id=>wwv_flow_api.id(6563970729300657572)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7343880741600915298)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(8881473151670025827)
,p_name=>'Open Opportunities'
,p_template=>wwv_flow_api.id(7343866444940915275)
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'js-dynamicHideShowRegion'
,p_region_template_options=>'t-Region--noPadding:#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'t-Report--stretch:#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select	 ',
'   d.id,',
'   (select sr."REP_LAST_NAME"||'', ''|| ',
'	     sr."REP_FIRST_NAME" x',
'	    from "EBA_SALES_SALESREPS" sr',
'	    where sr.id = d.salesrep_id_01) REP_NAME,',
'   d."DEAL_NAME",',
'   d."DEAL_CLOSE_DATE",',
'   (select sc."STATUS_CODE" ',
'    from "EBA_SALES_DEAL_STATUS_CODES" sc ',
'    where sc.id = d.DEAL_STATUS_CODE_ID) STATUS_CODE,',
'   decode(d."DEAL_PROBABILITY",0,''No'',100,''No'',',
'              decode(greatest(sysdate,d."DEAL_CLOSE_DATE"),',
'              sysdate,''Yes'',''No'')) overdue,',
'    d.qtr as quarter',
'from	 ',
'    "EBA_SALES_DEALS" d',
'where   ',
'     d.CUSTOMER_ID = :P94_ID and',
'     d."DEAL_PROBABILITY" > 0 and ',
'     d."DEAL_PROBABILITY" < 100'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(7343873253436915289)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No open opportunities found for this account'
,p_query_num_rows_type=>'0'
,p_query_row_count_max=>50
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_report_total_text_format=>'&nbsp;'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8881473340953025829)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'Id'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8881473440583025829)
,p_query_column_id=>2
,p_column_alias=>'REP_NAME'
,p_column_display_sequence=>3
,p_column_heading=>'&REP_TITLE.'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_lov_show_nulls=>'YES'
,p_derived_column=>'N'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8881473559353025829)
,p_query_column_id=>3
,p_column_alias=>'DEAL_NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Opportunity'
,p_column_link=>'f?p=&APP_ID.:80:&SESSION.::&DEBUG.:80:P80_ID:#ID#'
,p_column_linktext=>'#DEAL_NAME#'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8881473637956025830)
,p_query_column_id=>4
,p_column_alias=>'DEAL_CLOSE_DATE'
,p_column_display_sequence=>4
,p_column_heading=>'Close Date'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8881473938948025835)
,p_query_column_id=>5
,p_column_alias=>'STATUS_CODE'
,p_column_display_sequence=>5
,p_column_heading=>'Stage'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8881474052601025835)
,p_query_column_id=>6
,p_column_alias=>'OVERDUE'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8881474240032025835)
,p_query_column_id=>7
,p_column_alias=>'QUARTER'
,p_column_display_sequence=>7
,p_column_heading=>'Quarter'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(8889440742813584550)
,p_name=>'Competition'
,p_template=>wwv_flow_api.id(7343866444940915275)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'js-dynamicHideShowRegion'
,p_region_template_options=>'t-Region--noPadding:#DEFAULT#:t-Region--scrollBody:t-Form--labelsAbove'
,p_component_template_options=>'t-Report--stretch:#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'   (select COMPETITOR_NAME from EBA_SALES_COMPETITORS x where x.id = c.COMPETITOR_ID) competitor, ',
'   (select COMPETITOR_THREAT  from EBA_SALES_COMPETITOR_THREATS x where x.id = c.COMPETITOR_THREAT_ID) threat, ',
'   COMPETITION_DESC,',
'   created AS "COMPETITION_CREATED",',
'   lower(created_by) created_by',
'from EBA_SALES_ACT_COMPETITION c',
'where    CUSTOMER_ID = :P94_ID',
''))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(7343873253436915289)
,p_query_num_rows=>20
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No competitors identified, click "+" icon to add a competitor'
,p_query_num_rows_type=>'0'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
,p_required_patch=>wwv_flow_api.id(7401040659522300015)
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8890181458442667773)
,p_query_column_id=>1
,p_column_alias=>'COMPETITOR'
,p_column_display_sequence=>1
,p_column_heading=>'Competitor'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.component_end;
end;
/
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8890181545056667774)
,p_query_column_id=>2
,p_column_alias=>'THREAT'
,p_column_display_sequence=>2
,p_column_heading=>'Threat'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8890181648989667774)
,p_query_column_id=>3
,p_column_alias=>'COMPETITION_DESC'
,p_column_display_sequence=>3
,p_column_heading=>'Description'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(630460813054465302)
,p_query_column_id=>4
,p_column_alias=>'COMPETITION_CREATED'
,p_column_display_sequence=>4
,p_column_heading=>'Added'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_column_html_expression=>'#COMPETITION_CREATED# by #CREATED_BY#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6708496686238619280)
,p_query_column_id=>5
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(8899968835650959057)
,p_name=>'Contacts'
,p_template=>wwv_flow_api.id(7343866444940915275)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'js-dynamicHideShowRegion'
,p_region_template_options=>'t-Region--noPadding:#DEFAULT#:t-Region--scrollBody:t-Form--noPadding'
,p_component_template_options=>'t-Report--stretch:#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'	 "CONTACT_NAME" as "CONTACT",',
'	 "CONTACT_EMAIL" as "EMAIL",',
'	 "CONTACT_PHONE" as "PHONE",',
'	 "CONTACT_CELL" as "CELL",',
'	 "CONTACT_ADDRESS" as "CONTACT_ADDRESS",',
'         created as "CONTACT_CREATED",',
'         lower(created_by) created_by',
' from	 "EBA_SALES_CUSTOMER_CONTACTS" c',
'where customer_id = :P94_ID'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(7343873253436915289)
,p_query_num_rows=>500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'No contacts identified, click "+" icon to add a contact'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
,p_required_patch=>wwv_flow_api.id(10496478296281986809)
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8899969165400959064)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'Id'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8899969241131959064)
,p_query_column_id=>2
,p_column_alias=>'CONTACT'
,p_column_display_sequence=>2
,p_column_heading=>'Contact'
,p_column_link=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:RP,24:P24_ID:#ID#'
,p_column_linktext=>'#CONTACT#'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8899969357331959064)
,p_query_column_id=>3
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>3
,p_column_heading=>'Email'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8899969441522959064)
,p_query_column_id=>4
,p_column_alias=>'PHONE'
,p_column_display_sequence=>4
,p_column_heading=>'Phone'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8899969535030959064)
,p_query_column_id=>5
,p_column_alias=>'CELL'
,p_column_display_sequence=>5
,p_column_heading=>'Cell'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8899969658877959064)
,p_query_column_id=>6
,p_column_alias=>'CONTACT_ADDRESS'
,p_column_display_sequence=>6
,p_column_heading=>'Address'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(630460782723465301)
,p_query_column_id=>7
,p_column_alias=>'CONTACT_CREATED'
,p_column_display_sequence=>7
,p_column_heading=>'Added'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_column_html_expression=>'#CONTACT_CREATED# by #CREATED_BY#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6708496576494619279)
,p_query_column_id=>8
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(8901954767258375085)
,p_name=>'Locations'
,p_template=>wwv_flow_api.id(7343866444940915275)
,p_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'js-dynamicHideShowRegion'
,p_region_template_options=>'t-Region--noPadding:#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'t-Report--stretch:#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'	CUSTOMER_LOCATION_NAME location,',
'	CUSTOMER_ADDRESS1||',
'        decode(CUSTOMER_ADDRESS2,null,null,'' ''|| CUSTOMER_ADDRESS2) address,',
'        CUSTOMER_CITY city,',
'        CUSTOMER_STATE state,',
'	CUSTOMER_COUNTRY country,',
'        CUSTOMER_POSTAL_CODE,',
'        CUSTOMER_DESCRIPTION',
'        CUSTOMER_TERRITORY_ID,',
'        created as location_created,',
'        lower(created_by) created_by',
' from	 "EBA_SALES_CUSTOMER_LOCATIONS"',
'where customer_id = :P94_ID'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(7343873253436915289)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No locations identified, click "+" icon to add a customer location'
,p_query_num_rows_type=>'0'
,p_query_row_count_max=>50
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
,p_required_patch=>wwv_flow_api.id(8456035888906321075)
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8901954952990375087)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'Id'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8901967453667390095)
,p_query_column_id=>2
,p_column_alias=>'LOCATION'
,p_column_display_sequence=>2
,p_column_heading=>'Location'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8901967553409390095)
,p_query_column_id=>3
,p_column_alias=>'ADDRESS'
,p_column_display_sequence=>3
,p_column_heading=>'Address'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8901967652770390095)
,p_query_column_id=>4
,p_column_alias=>'CITY'
,p_column_display_sequence=>4
,p_column_heading=>'City'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8901967755027390095)
,p_query_column_id=>5
,p_column_alias=>'STATE'
,p_column_display_sequence=>5
,p_column_heading=>'State'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8901967865391390096)
,p_query_column_id=>6
,p_column_alias=>'COUNTRY'
,p_column_display_sequence=>6
,p_column_heading=>'Country'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8901967966997390096)
,p_query_column_id=>7
,p_column_alias=>'CUSTOMER_POSTAL_CODE'
,p_column_display_sequence=>7
,p_column_heading=>'Postal Code'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(8901968064485390096)
,p_query_column_id=>8
,p_column_alias=>'CUSTOMER_TERRITORY_ID'
,p_column_display_sequence=>8
,p_column_heading=>'Territory'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(247683924940047215)
,p_query_column_id=>9
,p_column_alias=>'LOCATION_CREATED'
,p_column_display_sequence=>9
,p_column_heading=>'Added'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_column_html_expression=>'#LOCATION_CREATED# by #CREATED_BY#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6708496756630619281)
,p_query_column_id=>10
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8880888256658762383)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(8880073845567293615)
,p_button_name=>'EDIT_ACCOUNT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7343886609855915317)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Edit Account'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:3:P3_ID:&P94_ID.'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6636753781277593288)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(10373553642022828503)
,p_button_name=>'POPATTACHMENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'Add Attachment'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:99:&SESSION.::&DEBUG.:RP,99:P99_ENTITY_TYPE,P99_ENTITY_ID:ACCOUNT,&P94_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8451265009389738262)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(8433002053482354597)
,p_button_name=>'ADD_SUPPORT_AMOUNT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'Add Support Amount'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:122:&SESSION.::&DEBUG.:122:P122_CUSTOMER_ID:&P94_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
,p_required_patch=>wwv_flow_api.id(8451179641625791308)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8451265051425738263)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(6047328493597045894)
,p_button_name=>'ADD_AGREEMENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'Add Agreement'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:102:P102_CUSTOMER_ID:&P94_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_api.id(9042570640734542978)
,p_required_patch=>wwv_flow_api.id(6098380714489638355)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6636754224081593289)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(10373553642022828503)
,p_button_name=>'VIEW_ATTACHMENTS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'View Attachments'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:92:&SESSION.::&DEBUG.:RP,92:P92_ENTITY_TYPE,P92_ENTITY_ID:ACCOUNT,&P94_ID.'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8455897059405641471)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(6047328493597045894)
,p_button_name=>'VIEW_AGREEMENTS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'View Agreements'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:130:&SESSION.::&DEBUG.:RP,130:P130_ID:&P94_ID.'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8455898162834641482)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(8433002053482354597)
,p_button_name=>'VIEW_AMOUNTS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'View Support Amounts'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:127:&SESSION.::&DEBUG.:RP,127:P127_ID:&P94_ID.'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8900816941856083885)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_api.id(8899968835650959057)
,p_button_name=>'ADD_CONTACT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'Add Contact'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:106:&SESSION.::&DEBUG.:RP,106:P106_CUSTOMER_ID:&P94_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8900174252534982834)
,p_button_sequence=>150
,p_button_plug_id=>wwv_flow_api.id(8899968835650959057)
,p_button_name=>'VIEW_contacts'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'View Contacts'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:105:&SESSION.::::P105_ID:&P94_ID.'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8889442046491584555)
,p_button_sequence=>230
,p_button_plug_id=>wwv_flow_api.id(8889440742813584550)
,p_button_name=>'POP_ADD_COMP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'Add Competition'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:145:&SESSION.::&DEBUG.:RP,145:P145_CUSTOMER_ID:&P94_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6628974766460120568)
,p_button_sequence=>240
,p_button_plug_id=>wwv_flow_api.id(12639994297061764443)
,p_button_name=>'POP_LINK'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'Add Link'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:RP,114:P114_ENTITY_TYPE,P114_ENTITY_ID:ACCOUNT,&P94_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8889442253999584556)
,p_button_sequence=>240
,p_button_plug_id=>wwv_flow_api.id(8889440742813584550)
,p_button_name=>'VIEW_COMP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'View Competitors'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:98:&SESSION.::&DEBUG.:RP,98:P98_ID:&P94_ID.'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6628975194493120568)
,p_button_sequence=>250
,p_button_plug_id=>wwv_flow_api.id(12639994297061764443)
,p_button_name=>'VIEW_LINKS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'View Links'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:89:&SESSION.::&DEBUG.:RP,89:P89_ENTITY_TYPE,P89_ENTITY_ID:ACCOUNT,&P94_ID.'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8901955965644375087)
,p_button_sequence=>270
,p_button_plug_id=>wwv_flow_api.id(8901954767258375085)
,p_button_name=>'POP_ADD_LOCATION'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'Add Location'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:RP,32:P32_CUSTOMER_ID:&P94_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8901955748779375087)
,p_button_sequence=>280
,p_button_plug_id=>wwv_flow_api.id(8901954767258375085)
,p_button_name=>'VIEW_LOCATIONS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'View Locations'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:107:&SESSION.::&DEBUG.:RP,107:P107_ID:&P94_ID.'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(8881474338633025835)
,p_button_sequence=>330
,p_button_plug_id=>wwv_flow_api.id(8881473151670025827)
,p_button_name=>'VIEW_OPEN_OPPORTUNITIES'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'View Open Opportunities'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:RP,1,RIR:IR_OPEN,IR_ACCOUNT_ID,P1_DISPLAY_AS:Yes,&P94_ID.,GRID'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6650556329500950960)
,p_button_sequence=>350
,p_button_plug_id=>wwv_flow_api.id(9607804126252773209)
,p_button_name=>'POPCOMMENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'Add Comment'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:RP,22:P22_ENTITY_TYPE,P22_ENTITY_ID:ACCOUNT,&P94_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6650556607146951787)
,p_button_sequence=>360
,p_button_plug_id=>wwv_flow_api.id(9607804126252773209)
,p_button_name=>'VIEW_COMMENTS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'View Comments'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:88:&SESSION.::&DEBUG.:RP,88:P88_ENTITY_TYPE,P88_ENTITY_ID:ACCOUNT,&P94_ID.'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7066727252415106357)
,p_name=>'P94_ROW_KEY'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(8880637059204696860)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select row_key',
'from eba_sales_customers',
'where id = :P94_ID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8881130039830842652)
,p_name=>'P94_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(8880637059204696860)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(8884500056068594883)
,p_name=>'P94_TERRITORY_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(8880637059204696860)
,p_use_cache_before_default=>'NO'
,p_source=>'select customer_territory_id from EBA_SALES_CUSTOMERS where id = :P94_ID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6563082045246594990)
,p_name=>'Refresh Account Details'
,p_event_sequence=>5
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 3'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6563082224526594991)
,p_event_id=>wwv_flow_api.id(6563082045246594990)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(8880637059204696860)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6563481697649904210)
,p_name=>'Refresh Contacts'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 106'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6563482551655904217)
,p_event_id=>wwv_flow_api.id(6563481697649904210)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(8899968835650959057)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6563551853258338816)
,p_name=>'Refresh Locations'
,p_event_sequence=>20
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 32'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6563552314726338817)
,p_event_id=>wwv_flow_api.id(6563551853258338816)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(8901954767258375085)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6563537999865252856)
,p_name=>'Link Details dialog closed'
,p_event_sequence=>30
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 114'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6563080843829594978)
,p_name=>'Refresh Notes'
,p_event_sequence=>50
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 21'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6563081563239594985)
,p_name=>'Refresh Competitors'
,p_event_sequence=>60
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 145'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6563081712813594986)
,p_event_id=>wwv_flow_api.id(6563081563239594985)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(8889440742813584550)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6563082807690594997)
,p_name=>'Refresh Validations'
,p_event_sequence=>70
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 146'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6567060657497423548)
,p_event_id=>wwv_flow_api.id(6563082807690594997)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(7378676440719153066)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6047325568582045865)
,p_name=>'Refresh Agreements'
,p_event_sequence=>90
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 102'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6047325442516045864)
,p_event_id=>wwv_flow_api.id(6047325568582045865)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(6047328493597045894)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(8451264715247738259)
,p_name=>'Refresh Support Amounts'
,p_event_sequence=>100
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 122'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8455895254135641453)
,p_event_id=>wwv_flow_api.id(8451264715247738259)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(8433002053482354597)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(8456012202136603300)
,p_name=>'Contacts IRR dialog closed'
,p_event_sequence=>110
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.view-contacts-dialog'
,p_bind_type=>'live'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'dialogclose'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8455898912987641489)
,p_event_id=>wwv_flow_api.id(8456012202136603300)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(8899968835650959057)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(8455898988130641490)
,p_name=>'Locations IRR dialog closed'
,p_event_sequence=>120
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.view-locations-dialog'
,p_bind_type=>'live'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'dialogclose'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8455899054536641491)
,p_event_id=>wwv_flow_api.id(8455898988130641490)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(8901954767258375085)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(8455899157518641492)
,p_name=>'Competitors IRR dialog closed'
,p_event_sequence=>130
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.view-competition-dialog'
,p_bind_type=>'live'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'dialogclose'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8455899318907641493)
,p_event_id=>wwv_flow_api.id(8455899157518641492)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(8889440742813584550)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(8455899348492641494)
,p_name=>'Agreements IRR dialog closed'
,p_event_sequence=>140
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.view-agreements-dialog'
,p_bind_type=>'live'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'dialogclose'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8455899449221641495)
,p_event_id=>wwv_flow_api.id(8455899348492641494)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(6047328493597045894)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(8455899629096641496)
,p_name=>'Support Amounts IRR dialog closed'
,p_event_sequence=>150
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.view-supportamounts-dialog'
,p_bind_type=>'live'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'dialogclose'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(8455899641413641497)
,p_event_id=>wwv_flow_api.id(8455899629096641496)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(8433002053482354597)
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7378376165609613420)
,p_process_sequence=>70
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Init page'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into eba_sales_clicks (',
'  entity_type,',
'  cust_id,',
'    app_username',
') values (',
'  ''ACCOUNT'',',
'  :P94_ID,',
'    lower(:APP_USER)',
');',
'',
'delete from eba_sales_clicks ',
'where view_timestamp < (sysdate - 90) ',
'  and cust_id = :P94_ID;'))
,p_process_clob_language=>'PLSQL'
);
wwv_flow_api.component_end;
end;
/
