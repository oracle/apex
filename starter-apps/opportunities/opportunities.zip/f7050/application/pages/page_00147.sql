prompt --application/pages/page_00147
begin
--   Manifest
--     PAGE: 00147
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>147
,p_name=>'Previous Validations'
,p_alias=>'PREVIOUS-VALIDATIONS'
,p_page_mode=>'MODAL'
,p_step_title=>'Previous Validations'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>'.t-Dialog-body {padding: 0; overflow: hidden;}'
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6654732881443573088)
,p_plug_name=>'Previous Validations'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select lower(v.created_by) as validated_by,',
'  v.created validated,',
'  v.verification_comment ',
'from eba_sales_verifications v',
'where (',
'  (:P147_ENTITY_TYPE = ''OPPORTUNITY'' and v.opp_id = :P147_ENTITY_ID)',
'    or (:P147_ENTITY_TYPE = ''TERRITORY'' and v.territory_id = :P147_ENTITY_ID)',
'    or (:P147_ENTITY_TYPE = ''LEAD'' and v.lead_id = :P147_ENTITY_ID)',
'    or (:P147_ENTITY_TYPE = ''ACCOUNT'' and v.cust_id = :P147_ENTITY_ID)',
'    or (:P147_ENTITY_TYPE = ''CONTACT'' and v.contact_id = :P147_ENTITY_ID)',
'    or (:P147_ENTITY_TYPE = ''PRODUCT'' and v.product_id = :P147_ENTITY_ID)',
')'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(6654732958037573089)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DAN'
,p_internal_uid=>766147731623253939
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6654733058995573090)
,p_db_column_name=>'VALIDATED_BY'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Validated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6654733216515573091)
,p_db_column_name=>'VALIDATED'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Validated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6654733239553573092)
,p_db_column_name=>'VERIFICATION_COMMENT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Comment'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(6672250193285134060)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'7836650'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'VALIDATED:VALIDATED_BY:VERIFICATION_COMMENT:'
,p_sort_column_1=>'VALIDATED'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(604673011039594331)
,p_name=>'P147_ENTITY_TYPE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6654732881443573088)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(604673148762594332)
,p_name=>'P147_ENTITY_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(6654732881443573088)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
