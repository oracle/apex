prompt --application/pages/page_00100
begin
--   Manifest
--     PAGE: 00100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>100
,p_name=>'Opportunities'
,p_alias=>'HOME'
,p_step_title=>'Opportunities'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(7418988128250509952)
,p_step_template=>4072355960268175073
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h2>About this Application</h2>',
'<p>',
'	Manage opportunities, track leads, manage accounts and contacts. Opportunities are organized by territory and account. For each opportunity you can track products, competition, team members, and add hypertext links and file attachments. Use interact'
||'ive reports to slice and dice your pipeline. You can upload leads from spreadsheets and convert leads to opportunities.',
'</p>'))
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6538649947034050181)
,p_plug_name=>'Total Leads by Source'
,p_region_css_classes=>'i-h400'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>120
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_required_patch=>wwv_flow_imp.id(7418757049364008813)
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(6538650038810050182)
,p_region_id=>wwv_flow_imp.id(6538649947034050181)
,p_chart_type=>'bar'
,p_height=>'330'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_spark_chart=>'N'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>true
,p_show_value=>false
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6538650165941050183)
,p_chart_id=>wwv_flow_imp.id(6538650038810050182)
,p_seq=>10
,p_name=>'Leads by source'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(sls.lead_source, ''Unidentified'') lead_source,',
'  count(*) cnt',
'from eba_sales_leads sl',
'left join eba_sales_lead_sources sls',
'  on sl.lead_source_id = sls.id',
'where instr('':'' || :P100_LEAD_STATUSES || '':'', '':'' || sl.lead_status_id || '':'') > 0',
'group by sls.lead_source',
'order by cnt desc'))
,p_ajax_items_to_submit=>'P100_LEAD_STATUSES'
,p_items_value_column_name=>'CNT'
,p_items_label_column_name=>'LEAD_SOURCE'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(6506043746956540863)
,p_chart_id=>wwv_flow_imp.id(6538650038810050182)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(6506043676512540862)
,p_chart_id=>wwv_flow_imp.id(6538650038810050182)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6538651093032050192)
,p_plug_name=>'Select Lead Statuses to Include'
,p_region_name=>'select_lead_statuses'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size480x320'
,p_plug_template=>2672673746673652531
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_04'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6538651791210050199)
,p_plug_name=>'Opportunity Pipeline'
,p_region_css_classes=>'i-h400'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>130
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_required_patch=>wwv_flow_imp.id(8039570864483968999)
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(6539768546306514351)
,p_region_id=>wwv_flow_imp.id(6538651791210050199)
,p_chart_type=>'funnel'
,p_height=>'330'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_value_format_type=>'decimal'
,p_value_format_scaling=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6539768643339514352)
,p_chart_id=>wwv_flow_imp.id(6539768546306514351)
,p_seq=>10
,p_name=>'Opportunity Pipeline'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sdsc.status_code,',
'  sdsc.corresponding_prob_pct,',
'  count(*) cnt',
'from eba_sales_deals sd',
'join eba_sales_deal_status_codes sdsc',
'  on sd.deal_status_code_id = sdsc.id',
'where sdsc.corresponding_prob_pct != 0',
'group by sdsc.status_code,',
'  sdsc.corresponding_prob_pct',
'order by sdsc.corresponding_prob_pct'))
,p_items_value_column_name=>'CNT'
,p_items_label_column_name=>'STATUS_CODE'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6539768758248514353)
,p_plug_name=>'Open Leads by Status'
,p_region_css_classes=>'i-h400'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>110
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_required_patch=>wwv_flow_imp.id(7418757049364008813)
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(6539768865072514354)
,p_region_id=>wwv_flow_imp.id(6539768758248514353)
,p_chart_type=>'bar'
,p_height=>'330'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_spark_chart=>'N'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>true
,p_show_value=>false
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6539769003993514355)
,p_chart_id=>wwv_flow_imp.id(6539768865072514354)
,p_seq=>10
,p_name=>'Leads by status'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select slsc.status_code,',
'  slsc.display_order,',
'  count(*) cnt',
'from eba_sales_leads sl',
'join eba_sales_lead_status_codes slsc',
'  on sl.lead_status_id = slsc.id',
'where sl.lead_status_id not in (1, 5)',
'group by slsc.status_code,',
'  slsc.display_order',
'order by slsc.display_order'))
,p_items_value_column_name=>'CNT'
,p_items_label_column_name=>'STATUS_CODE'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(6539769187428514357)
,p_chart_id=>wwv_flow_imp.id(6539768865072514354)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(6539769099037514356)
,p_chart_id=>wwv_flow_imp.id(6539768865072514354)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(7082006552981920571)
,p_name=>'Notifications'
,p_template=>4501440665235496320
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'decode(lower(NOTIFICATION_TYPE),''yellow'',''warning'',''red'',''danger'',lower(NOTIFICATION_TYPE)) as ALERT_TYPE,',
'    NOTIFICATION_NAME as ALERT_TITLE,',
'    NOTIFICATION_DESCRIPTION as ALERT_DESC,',
'    '''' alert_action',
'  from EBA_SALES_NOTIFICATIONS',
' where (DISPLAY_FROM is null or DISPLAY_FROM <= current_date) and',
'       (DISPLAY_UNTIL is null or DISPLAY_UNTIL >= current_date)',
' order by nvl(DISPLAY_SEQUENCE,0),NOTIFICATION_NAME'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from EBA_SALES_NOTIFICATIONS',
' where (DISPLAY_FROM is null or DISPLAY_FROM <= current_date) and',
'       (DISPLAY_UNTIL is null or DISPLAY_UNTIL >= current_date)'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>2882902941739462796
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'0'
,p_query_num_rows_type=>'0'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7082006838436920572)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7683086745911098782)
,p_query_column_id=>2
,p_column_alias=>'ALERT_TYPE'
,p_column_display_sequence=>2
,p_column_heading=>'Alert type'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7683086915297098783)
,p_query_column_id=>3
,p_column_alias=>'ALERT_TITLE'
,p_column_display_sequence=>3
,p_column_heading=>'Alert title'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7683086989173098784)
,p_query_column_id=>4
,p_column_alias=>'ALERT_DESC'
,p_column_display_sequence=>4
,p_column_heading=>'Alert desc'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7683087108046098785)
,p_query_column_id=>5
,p_column_alias=>'ALERT_ACTION'
,p_column_display_sequence=>5
,p_column_heading=>'Alert action'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7362488305822896410)
,p_plug_name=>'Opportunities'
,p_icon_css_classes=>'app-opportunity-tracker'
,p_region_template_options=>'#DEFAULT#:#DEFAULT#'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in ( select preference_value',
'            from eba_sales_preferences',
'            where preference_name = ''APPLICATION_SUBTITLE''',
'            union all',
'            select ''Manage Opportunities''',
'            from dual',
'            where not exists ( select null',
'                               from eba_sales_preferences',
'                               where preference_name = ''APPLICATION_SUBTITLE'')',
'          ) loop',
'    sys.htp.p(''<p>''||apex_escape.html(c1.preference_value)||''</p>'');',
'end loop;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7364746135918100974)
,p_plug_name=>'Top Open Opportunities'
,p_region_css_classes=>'i-h400'
,p_region_template_options=>'t-Region--noPadding:#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>140
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sd.id,',
'  sd.deal_name || '' - ''  || c.customer_name as deal_name,',
'  case when apex_util.get_build_option_status(',
'                p_application_id    => :APP_ID,',
'                p_build_option_name => ''Opportunity Amount Set at Product Level''',
'            ) = ''EXCLUDE'' then',
'      nvl(sd.deal_amount,0)',
'  else',
'      nvl((select sum(nvl(dp.quote_price, 0)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = sd.id and (nvl(:P100_FY_PCD, 0) = 0 or :P100_FY_PCD = substr(dp.qtr, -2))),0)',
'  end as deal_amount',
'from eba_sales_deals sd',
'join eba_sales_customers c',
'  on sd.customer_id = c.id',
'join eba_sales_deal_status_codes sdsc',
'  on sd.deal_status_code_id = sdsc.id',
'where sdsc.corresponding_prob_pct not in (0, 100)',
'  and (',
'          (apex_util.get_build_option_status(',
'                    p_application_id    => :APP_ID,',
'                    p_build_option_name => ''Opportunity Amount Set at Product Level''',
'                ) = ''EXCLUDE''',
'           and ',
'           (nvl(:P100_FY_OCD, 0) = 0 or :P100_FY_OCD = substr(sd.qtr, -2))',
'          )',
'          or ',
'          apex_util.get_build_option_status(',
'                p_application_id    => :APP_ID,',
'                p_build_option_name => ''Opportunity Amount Set at Product Level''',
'          ) = ''INCLUDE''',
'      )',
'order by case when apex_util.get_build_option_status(',
'             p_application_id    => :APP_ID,',
'             p_build_option_name => ''Opportunity Amount Set at Product Level''',
'         ) = ''EXCLUDE'' then',
'      nvl(sd.deal_amount,0)',
'  else',
'      nvl((select sum(nvl(dp.quote_price, 0)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = sd.id and (nvl(:P100_FY_PCD, 0) = 0 or :P100_FY_PCD = substr(dp.qtr, -2))),0)',
'  end desc',
''))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HTML5_BAR_CHART'
,p_required_patch=>wwv_flow_imp.id(8039571675245002532)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'INITIALS',
  'attribute_02', 'DEAL_NAME',
  'attribute_03', 'f?p=&APP_ID.:80:&SESSION.::&DEBUG.:RP,80:P80_ID:&ID.',
  'attribute_04', 'DEAL_AMOUNT',
  'attribute_11', 'VALUE',
  'attribute_14', '50',
  'attribute_15', 'TEXT',
  'attribute_16', 'ABSOLUTE',
  'attribute_17', 'DEFAULT',
  'attribute_18', 'ABOVE',
  'attribute_20', 'No data found.',
  'attribute_21', '999G999G999G999G999G990')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7475668736433567498)
,p_plug_name=>'Revenue By Product Family'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_required_patch=>wwv_flow_imp.id(7204555145359641276)
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(7475668847180567499)
,p_region_id=>wwv_flow_imp.id(7475668736433567498)
,p_chart_type=>'pie'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_value_format_scaling=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(7475668962765567500)
,p_chart_id=>wwv_flow_imp.id(7475668847180567499)
,p_seq=>10
,p_name=>'Revenue By Product Family'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'       sum(case ',
'           when :OPP_SET_PROD_LEV_BO = ''Include'' then',
'               case when dp.term is null then nvl(dp.quote_price, 0) else nvl(dp.quote_price, 0) * dp.term/12 end',
'       else',
'               d.deal_amount',
'       end) as revenue,',
'       pf.product_family',
'  from eba_sales_deal_products dp,',
'       eba_sales_products p,',
'       eba_sales_product_families pf,',
'       eba_sales_deals d',
' where dp.product_id = p.id',
'   and dp.deal_id = d.id',
'   and p.product_family_id = pf.id',
'   and (',
'           nvl(:P100_FY_PCD, 0) = 0',
'           or',
'           instr(dp.qtr, :P100_FY_PCD) > 0',
'       )',
'   and (',
'           :P100_QUARTER is null',
'           or',
'           instr(:P100_QUARTER, substr(dp.qtr,1,2)) > 0',
'       )',
'   and (',
'           nvl(:P100_SALES_MGR_ID, 0) = 0',
'           or exists',
'           (select null from EBA_SALES_SALESREPS r where r.id = d.salesrep_id_01 and r.rep_manager_id = :P100_SALES_MGR_ID)',
'           or exists',
'           (select null from EBA_SALES_SALESREPS r where r.id = d.salesrep_id_02 and r.rep_manager_id = :P100_SALES_MGR_ID)',
'           or exists',
'           (select null from EBA_SALES_SALESREPS r where r.id = d.salesrep_id_03 and r.rep_manager_id = :P100_SALES_MGR_ID)',
'           or exists',
'           (select null from EBA_SALES_SALESREPS r where r.id = d.salesrep_id_04 and r.rep_manager_id = :P100_SALES_MGR_ID)',
'       )',
'   and (',
'           :P100_TERRITORY_ID is null',
'           or exists',
'           (select null from eba_sales_customers a, eba_sales_territories t where d.customer_id = a.id and dp.deal_id = d.id and dp.product_id = p.id and p.product_family_id = pf.id and a.customer_territory_id = :P100_TERRITORY_ID)',
'       )',
' group by pf.product_family'))
,p_items_value_column_name=>'REVENUE'
,p_items_label_column_name=>'PRODUCT_FAMILY'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_link_target=>'f?p=&APP_ID.:135:&SESSION.::&DEBUG.:RP,135,RIR:IR_PRODUCT_FAMILY_ID,IR_PFYO,IR_SALES_MGR,IR_TERRITORY_NAME,IRIN_PQO:&PRODUCT_FAMILY.,&P100_FY_PCD.,\&P100_SALES_MGR_NAME.\,&P100_TERRITORY_NAME.,\&P100_QTR_NAME.\'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7591081993969339653)
,p_plug_name=>'Revenue By Territories'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_required_patch=>wwv_flow_imp.id(7204555145359641276)
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(7591082111359339654)
,p_region_id=>wwv_flow_imp.id(7591081993969339653)
,p_chart_type=>'bar'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(7591082133877339655)
,p_chart_id=>wwv_flow_imp.id(7591082111359339654)
,p_seq=>10
,p_name=>'Revenue By Territories'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sum(case ',
'           when :OPP_SET_PROD_LEV_BO = ''Include'' then',
'               case when dp.term is null then nvl(dp.quote_price, 0) else nvl(dp.quote_price, 0) * dp.term/12 end',
'       else',
'               d.deal_amount',
'       end) as revenue,',
'       t.territory_name as territory',
'  from eba_sales_deals d,',
'       eba_sales_deal_products dp,',
'       eba_sales_territories t',
' where d.customer_id in (select id from eba_sales_customers c where c.customer_territory_id = t.id)',
'   and dp.deal_id = d.id',
'   and (',
'           nvl(:P100_FY_PCD, 0) = 0',
'           or',
'           instr(dp.qtr, :P100_FY_PCD) > 0',
'       )',
'   and (',
'           :P100_QUARTER is null',
'           or',
'           instr(:P100_QUARTER, substr(dp.qtr,1,2)) > 0',
'       )',
'   and (',
'           nvl(:P100_SALES_MGR_ID, 0) = 0',
'           or exists',
'           (select null from EBA_SALES_SALESREPS r where r.id = d.salesrep_id_01 and r.rep_manager_id = :P100_SALES_MGR_ID)',
'           or exists',
'           (select null from EBA_SALES_SALESREPS r where r.id = d.salesrep_id_02 and r.rep_manager_id = :P100_SALES_MGR_ID)',
'           or exists',
'           (select null from EBA_SALES_SALESREPS r where r.id = d.salesrep_id_03 and r.rep_manager_id = :P100_SALES_MGR_ID)',
'           or exists',
'           (select null from EBA_SALES_SALESREPS r where r.id = d.salesrep_id_04 and r.rep_manager_id = :P100_SALES_MGR_ID)',
'       )',
'   and (',
'           :P100_TERRITORY_ID is null',
'           or',
'           t.id = :P100_TERRITORY_ID',
'       )',
' group by t.territory_name'))
,p_items_value_column_name=>'REVENUE'
,p_items_label_column_name=>'TERRITORY'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_link_target=>'f?p=&APP_ID.:135:&SESSION.::&DEBUG.:RP,1,RIR:IR_TERRITORY_NAME,P1_DISPLAY_AS,IR_SALES_MGR,IRIN_PQO,IR_PFYO:&TERRITORY.,GRID,&P100_SALES_MGR_NAME.,\&P100_QTR_NAME.\,&P100_FY_PCD.'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(7591082386234339657)
,p_chart_id=>wwv_flow_imp.id(7591082111359339654)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(6065047047117799261)
,p_chart_id=>wwv_flow_imp.id(7591082111359339654)
,p_axis=>'y2'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_split_dual_y=>'auto'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(7591082263777339656)
,p_chart_id=>wwv_flow_imp.id(7591082111359339654)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7591082458259339658)
,p_plug_name=>'Revenue By Product Type'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_required_patch=>wwv_flow_imp.id(7204555145359641276)
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(7591082527991339659)
,p_region_id=>wwv_flow_imp.id(7591082458259339658)
,p_chart_type=>'pie'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_value_format_scaling=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(7591082647516339660)
,p_chart_id=>wwv_flow_imp.id(7591082527991339659)
,p_seq=>10
,p_name=>'Revenue By Product Type'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'       sum(case ',
'           when :OPP_SET_PROD_LEV_BO = ''Include'' then',
'               case when dp.term is null then nvl(dp.quote_price, 0) else nvl(dp.quote_price, 0) * dp.term/12 end',
'       else',
'               d.deal_amount',
'       end) as revenue,',
'       decode(p.sold_as, ''SUBSCRIPTION'', ''Cloud Subscription'', ''PURCHASE'', ''On-Premise Purchase'', p.sold_as) as product_type',
'  from eba_sales_deal_products dp,',
'       eba_sales_products p,',
'       eba_sales_deals d',
' where dp.product_id = p.id',
'   and dp.deal_id = d.id',
'   and (',
'           nvl(:P100_FY_PCD, 0) = 0',
'           or',
'           instr(dp.qtr, :P100_FY_PCD) > 0',
'       )',
'   and (',
'           :P100_QUARTER is null',
'           or',
'           instr(:P100_QUARTER, substr(dp.qtr,1,2)) > 0',
'       )',
'   and (',
'           nvl(:P100_SALES_MGR_ID, 0) = 0',
'           or exists',
'           (select null from EBA_SALES_SALESREPS r where r.id = d.salesrep_id_01 and r.rep_manager_id = :P100_SALES_MGR_ID)',
'           or exists',
'           (select null from EBA_SALES_SALESREPS r where r.id = d.salesrep_id_02 and r.rep_manager_id = :P100_SALES_MGR_ID)',
'           or exists',
'           (select null from EBA_SALES_SALESREPS r where r.id = d.salesrep_id_03 and r.rep_manager_id = :P100_SALES_MGR_ID)',
'           or exists',
'           (select null from EBA_SALES_SALESREPS r where r.id = d.salesrep_id_04 and r.rep_manager_id = :P100_SALES_MGR_ID)',
'       )',
'   and (',
'           :P100_TERRITORY_ID is null',
'           or exists',
'           (select null from eba_sales_customers a, eba_sales_territories t where d.customer_id = a.id and dp.deal_id = d.id and dp.product_id = p.id and a.customer_territory_id = :P100_TERRITORY_ID)',
'       )',
' group by decode(p.sold_as, ''SUBSCRIPTION'', ''Cloud Subscription'', ''PURCHASE'', ''On-Premise Purchase'', p.sold_as)'))
,p_items_value_column_name=>'REVENUE'
,p_items_label_column_name=>'PRODUCT_TYPE'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_link_target=>'f?p=&APP_ID.:135:&SESSION.::&DEBUG.:RP,135,RIR:IR_PRODUCT_TYPE,IR_PFYO,IR_SALES_MGR,IR_TERRITORY_NAME,IRIN_PQO:&PRODUCT_TYPE.,&P100_FY_PCD.,\&P100_SALES_MGR_NAME.\,&P100_TERRITORY_NAME.,\&P100_QTR_NAME.\'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7591083494633339668)
,p_plug_name=>'Revenue By Quarter'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_required_patch=>wwv_flow_imp.id(7204555145359641276)
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(7591083579626339669)
,p_region_id=>wwv_flow_imp.id(7591083494633339668)
,p_chart_type=>'bar'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(7591083655885339670)
,p_chart_id=>wwv_flow_imp.id(7591083579626339669)
,p_seq=>10
,p_name=>'Revenue By Quarter'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with qtrs as (',
'    select level q',
'    from dual',
'    connect by level <= 4',
'), data as (',
'    select sum(case ',
'            when :OPP_SET_PROD_LEV_BO = ''Include'' then',
'                case when dp.term is null then nvl(dp.quote_price, 0) else nvl(dp.quote_price, 0) * dp.term/12 end',
'            else d.deal_amount',
'            end) as revenue,',
'        dp.qtr as fiscal_quarter,',
'        pf.product_family',
'    from eba_sales_deals d',
'        join eba_sales_customers c on c.id = d.customer_id',
'        join eba_sales_deal_products dp on dp.deal_id = d.id',
'        join eba_sales_products p on p.id = dp.product_id',
'        join eba_sales_product_families pf on pf.id = p.product_family_id',
'        left join eba_sales_territories t on t.id = c.customer_territory_id',
'    where dp.qtr is not null',
'        and ( nvl(:P100_FY_PCD, 0) = 0',
'            or instr(dp.qtr, :P100_FY_PCD) > 0',
'        )',
'/*      -- This doesn''t work.',
'        and ( nvl(:P100_QUARTER, 0) = 0',
'            or substr(dp.qtr,1,2) = :P100_QUARTER',
'        )*/',
'/*      -- This works, but I think we can do better.',
'        and ( :P100_QUARTER is null',
'           or instr(:P100_QUARTER, substr(dp.qtr,1,2)) > 0',
'        )*/',
'        and ( nvl(:P100_SALES_MGR_ID, 0) = 0',
'            or exists ( select null',
'                        from EBA_SALES_SALESREPS r',
'                        where r.id = d.salesrep_id_01',
'                            and r.rep_manager_id = :P100_SALES_MGR_ID )',
'        )',
'        and ( nvl(:P100_TERRITORY_ID, 0) = 0',
'            or t.id = :P100_TERRITORY_ID',
'        )',
'    group by dp.qtr, pf.product_family',
'), yrrng as (',
'    select min(substr(data.fiscal_quarter,-2)) start_year, max(substr(data.fiscal_quarter,-2)) end_year',
'    from data',
'), yrs as (',
'    select yrrng.start_year + (level - 1) y',
'    from yrrng',
'    connect by level <= 1 + (yrrng.end_year - yrrng.start_year)',
'), fyqtr as (',
'    select ''Q''||qtrs.q||''FY''||yrs.y qt, yrs.y, qtrs.q',
'    from qtrs, yrs',
'), pf as (',
'    select distinct product_family',
'    from data',
')',
'select nvl(data.revenue,0) revenue,',
'    fyqtr.qt fiscal_quarter,',
'    pf.product_family',
'from fyqtr, pf, data',
'where data.fiscal_quarter(+) = fyqtr.qt',
'    and data.product_family(+) = pf.product_family',
'    -- This works, and only displays the selected quarter(s).',
'    and (:P100_QUARTER is null or '':''||:P100_QUARTER||'':'' like ''%:Q''||fyqtr.q||'':%'')',
'order by fyqtr.y, fyqtr.q'))
,p_series_name_column_name=>'PRODUCT_FAMILY'
,p_items_value_column_name=>'REVENUE'
,p_items_label_column_name=>'FISCAL_QUARTER'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
,p_link_target=>'f?p=&APP_ID.:135:&SESSION.::&DEBUG.:RP,135,RIR:IR_PRODUCT_FAMILY_ID,IRIN_PQO,IR_PFYO,IR_TERRITORY_NAME,IR_SALES_MGR,IR_PRODUCT_QTR:&PRODUCT_FAMILY.,\&P100_QTR_NAME.\,&P100_FY_PCD.,&P100_TERRITORY_NAME.,&P100_SALES_MGR_NAME.,&FISCAL_QUARTER.'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(7591083741169339671)
,p_chart_id=>wwv_flow_imp.id(7591083579626339669)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(7591083897548339672)
,p_chart_id=>wwv_flow_imp.id(7591083579626339669)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7591084963382339683)
,p_plug_name=>'Filters'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody:t-Form--stretchInputs'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_02'
,p_required_patch=>wwv_flow_imp.id(7204555145359641276)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7599239931232634876)
,p_plug_name=>'ACL Warning'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.ACL_WARNING'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'EBA_sales_fw.get_preference_value(''ACCESS_CONTROL_ENABLED'') = ''N'''
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'f?p=&APP_ID.:SETTINGS:&SESSION.::&DEBUG.:RP::')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9070159135817710934)
,p_plug_name=>'Time Zone'
,p_region_template_options=>'#DEFAULT#:#DEFAULT#'
,p_region_attributes=>'style="clear: left; "'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>150
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Dates and Times are displayed in the ',
'<a href="&P100_TIMEZONE_URL.">&P100_TIMEZONE.</a> timezone.</p>'))
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10200247451443424988)
,p_plug_name=>'Home'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10512992898526525834)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3310080704275823154)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(7591084963382339683)
,p_button_name=>'RESET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Reset Filters'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&SESSION.::&DEBUG.:RP,&APP_PAGE_ID.::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6539769318522514358)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6538649947034050181)
,p_button_name=>'EDIT_STATUSES'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Select Lead Statuses'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-wrench'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10268827742640093862)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(7364746135918100974)
,p_button_name=>'Create_ACCT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Create Account'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:3::'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10252044849778306228)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(7364746135918100974)
,p_button_name=>'VIEW_ACCOUNTS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'View Accounts'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(6032420359135459252)
,p_branch_name=>'Go To Page 1000'
,p_branch_action=>'f?p=&APP_ID.:1000:&SESSION.::&DEBUG.:RP,1000::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>'eba_sales_fw.get_preference_value(''FIRST_RUN'') = ''YES'''
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3148704172495786181)
,p_name=>'P100_SALES_MGR_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(7591084963382339683)
,p_prompt=>'&REP_TITLE. Manager'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rep_last_name||'', ''||rep_first_name display_value, ID return_value ',
'from eba_sales_salesreps',
'where rep_manager_id is null',
'union',
'select rep_last_name||'', ''||rep_first_name display_value, ID return_value ',
'from eba_sales_salesreps',
'where id in (select distinct rep_manager_id from eba_sales_salesreps)',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_cHeight=>1
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3148704280361786182)
,p_name=>'P100_TERRITORY_ID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(7591084963382339683)
,p_prompt=>'Territory'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TERRITORY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TERRITORY_NAME display_value, ID return_value ',
'from eba_sales_TERRITORIES',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_cHeight=>1
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3148704933140786188)
,p_name=>'P100_SALES_MGR_NAME'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(7591084963382339683)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3310079823342823145)
,p_name=>'P100_TERRITORY_NAME'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(7591084963382339683)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3310080204144823149)
,p_name=>'P100_QUARTER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(7591084963382339683)
,p_prompt=>'Quarter'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'NUMERIC_QUARTERS'
,p_lov=>'.'||wwv_flow_imp.id(3310246017204933924)||'.'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_help_text=>'Select the quarters you want to include in your results. The current calendar year is used if you haven''t selected a specific fiscal year in the "Fiscal Year" select list filter (above).'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3310080337733823150)
,p_name=>'P100_QTR_NAME'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(7591084963382339683)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6538650509435050186)
,p_name=>'P100_LEAD_STATUSES'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6538651093032050192)
,p_item_default=>'2:3:4'
,p_prompt=>'Statuses included'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select status_code,',
'  id',
'from eba_sales_lead_status_codes',
'order by display_order'))
,p_field_template=>2040785906935475274
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6538651630591050198)
,p_name=>'P100_LEAD_STATUSES_DISPLAY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(6538649947034050181)
,p_prompt=>'Lead Statuses'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>3
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#::'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7113277453655255941)
,p_name=>'P100_TIMEZONE_URL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9070159135817710934)
,p_source=>'apex_util.prepare_url(''f?p=''||:APP_ID||'':43:''||:APP_SESSION)'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7113277648910258142)
,p_name=>'P100_TIMEZONE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(9070159135817710934)
,p_use_cache_before_default=>'NO'
,p_source=>'nvl(apex_util.get_session_time_zone(),''unknown'')'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7591085153727339685)
,p_name=>'P100_FY_PCD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(7591084963382339683)
,p_item_default=>'null'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fiscal Year'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'FISCAL YEARS - PRODUCT CLOSE DATES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct sp.fiscal_year + 2000 as dv, sp.fiscal_year as rv',
'  from eba_sales_sales_periods sp,',
'       eba_sales_deal_products dp',
' where sp.fiscal_year = substr(dp.qtr, -2)',
' order by 2 asc'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_cHeight=>1
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_deal_products',
' where qtr is not null'))
,p_display_when_type=>'EXISTS'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_required_patch=>wwv_flow_imp.id(7496430724341025700)
,p_help_text=>'Filter the results displayed on this page by selecting a specific Fiscal Year from this list. This filter only affects the results in the "Revenue By Product Family", "Revenue By Product Type", "Revenue By Territories", "Revenue By Quarter", and "Top'
||' Open Opportunities" regions.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7591085306751339686)
,p_name=>'P100_FY_OCD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(7591084963382339683)
,p_item_default=>'null'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fiscal Year'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'FISCAL YEARS - DEAL CLOSE DATES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct sp.fiscal_year + 2000 as dv, sp.fiscal_year as rv',
'  from eba_sales_sales_periods sp,',
'       eba_sales_deals d',
' where sp.fiscal_year = substr(d.qtr, -2)',
' order by 2 asc'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_cHeight=>1
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_deals',
' where qtr is not null'))
,p_display_when_type=>'EXISTS'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_required_patch=>-wwv_flow_imp.id(7496430724341025700)
,p_help_text=>'Filter the results displayed on this page by selecting a specific Fiscal Year from this list. This filter only affects the results in the "Revenue By Territories", "Revenue By Quarter", and "Top Open Opportunities" regions.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10189755953713997217)
,p_computation_sequence=>20
,p_computation_item=>'LAST_PAGE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'100'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3148705312179786192)
,p_name=>'Set Sales Manager Name'
,p_event_sequence=>2
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_SALES_MGR_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3148705368983786193)
,p_event_id=>wwv_flow_imp.id(3148705312179786192)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P100_SALES_MGR_NAME'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select initcap(rep_first_name) || '' '' || initcap(rep_last_name)',
'from EBA_SALES_SALESREPS',
'where id = :P100_SALES_MGR_ID'))
,p_attribute_07=>'P100_SALES_MGR_ID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3148705462962786194)
,p_event_id=>wwv_flow_imp.id(3148705312179786192)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P100_SALES_MGR_ID is null then',
'    :P100_SALES_MGR_NAME := null;',
'end if;'))
,p_attribute_02=>'P100_SALES_MGR_NAME'
,p_attribute_03=>'P100_SALES_MGR_NAME'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1875842437322138392)
,p_event_id=>wwv_flow_imp.id(3148705312179786192)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P100_SALES_MGR_NAME'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3310079934555823146)
,p_name=>'Set Territory Name'
,p_event_sequence=>5
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_TERRITORY_ID'
,p_condition_element=>'P100_TERRITORY_ID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3310080033015823147)
,p_event_id=>wwv_flow_imp.id(3310079934555823146)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P100_TERRITORY_NAME'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select TERRITORY_NAME from EBA_SALES_TERRITORIES where id = :P100_TERRITORY_ID'
,p_attribute_07=>'P100_TERRITORY_ID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3310080153002823148)
,p_event_id=>wwv_flow_imp.id(3310079934555823146)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P100_TERRITORY_NAME'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6538650728859050189)
,p_name=>'Lead Status changed'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_LEAD_STATUSES'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6538651230041050194)
,p_event_id=>wwv_flow_imp.id(6538650728859050189)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var $leadStatuses = $(''#P100_LEAD_STATUSES''),',
'  statuses = '''';',
'',
'$leadStatuses.find('':checked'').each(function(idx) {',
'  if (idx > 0) {',
'    statuses += '', '';',
'  }',
'',
'  statuses  += $leadStatuses.find(''label[for="'' + this.id + ''"]'').text();',
'});',
'',
'$s(''P100_LEAD_STATUSES_DISPLAY'', statuses || ''None'', null, true);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6538650848394050190)
,p_event_id=>wwv_flow_imp.id(6538650728859050189)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6538649947034050181)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6538651479362050196)
,p_name=>'Edit lead statuses clicked'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(6539769318522514358)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6538651580064050197)
,p_event_id=>wwv_flow_imp.id(6538651479362050196)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal(''select_lead_statuses'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7591085339494339687)
,p_name=>'Refresh Regions'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_FY_PCD,P100_SALES_MGR_ID,P100_TERRITORY_ID,P100_QUARTER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_required_patch=>wwv_flow_imp.id(7496430724341025700)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7591085600339339689)
,p_event_id=>wwv_flow_imp.id(7591085339494339687)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P100_FY_PCD,P100_SALES_MGR_ID,P100_TERRITORY_ID,P100_QUARTER'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7591085509484339688)
,p_event_id=>wwv_flow_imp.id(7591085339494339687)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7475668736433567498)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7591085636424339690)
,p_event_id=>wwv_flow_imp.id(7591085339494339687)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7591082458259339658)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7591085961984339693)
,p_event_id=>wwv_flow_imp.id(7591085339494339687)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7591081993969339653)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7591086113013339694)
,p_event_id=>wwv_flow_imp.id(7591085339494339687)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7591083494633339668)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3321273495902144346)
,p_event_id=>wwv_flow_imp.id(7591085339494339687)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7364746135918100974)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7591086256489339696)
,p_name=>'Refresh Opportunity-Based Regions'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_FY_OCD'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7591086343559339697)
,p_event_id=>wwv_flow_imp.id(7591086256489339696)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P100_FY_OCD'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7591086631681339700)
,p_event_id=>wwv_flow_imp.id(7591086256489339696)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7364746135918100974)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3310080383514823151)
,p_name=>'Set Quarter Name'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_QUARTER,P100_FY_PCD'
,p_condition_element=>'P100_QUARTER'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3310080464494823152)
,p_event_id=>wwv_flow_imp.id(3310080383514823151)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P100_QTR_NAME'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_vc_arr2    apex_application_global.vc_arr2;',
'    l_retval     varchar2(200);',
'begin',
'    l_vc_arr2 := apex_util.string_to_table(:P100_QUARTER);',
'    for i in 1..l_vc_arr2.count',
'    loop',
'        l_retval := l_retval || l_vc_arr2(i) || '','';',
'    end loop;',
'    l_retval := rtrim(l_retval, '','');',
'    return l_retval;',
'end;'))
,p_attribute_07=>'P100_QUARTER,P100_FY_PCD'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3310080635289823153)
,p_event_id=>wwv_flow_imp.id(3310080383514823151)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P100_QTR_NAME'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
