prompt --application/pages/page_00133
begin
--   Manifest
--     PAGE: 00133
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-13'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>133
,p_user_interface_id=>wwv_flow_api.id(6988712858842356549)
,p_name=>'Lead'
,p_alias=>'LEAD'
,p_step_title=>'Lead'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(7216871863962621378)
,p_step_template=>wwv_flow_api.id(7343838829035915213)
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_api.id(7401034857403255410)
,p_protection_level=>'C'
,p_help_text=>'Manage a lead''s details, links, attachments, and/or comments. You can also covert a lead to an opportunity and/or validate the lead.'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20210301101414'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6584911588647136067)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7343855668783915255)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6627670531376805495)
,p_plug_name=>'Lead Actions'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-LinksList--actions:t-LinksList--showTopIcons'
,p_plug_template=>wwv_flow_api.id(7343855668783915255)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_list_id=>wwv_flow_api.id(6629035122780983304)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(7343880741600915298)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7360326864636258423)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7343869008886915277)
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(10495270706565772431)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(7343886820987915318)
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(7360330045193300090)
,p_name=>'Lead Details'
,p_template=>wwv_flow_api.id(7343855668783915255)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_display_point=>'REGION_POSITION_02'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select l.id, ',
'  l.row_key,',
'  l.lead_priority,',
'  l.lead_name_01 lead,',
'  l.lead_details,',
'  l.lead_email_01,',
'  l.opportunity_id,',
'  case',
'    when opportunity_id is null',
'    then ''<a href="'' || apex_util.prepare_url(''f?p='' || :APP_ID || '':63:'' || :APP_SESSION || '':::63:P63_LEAD_ID:''||l.id) || ''" class="simpleButton">Convert</a>''',
'    else ''<a href="'' || apex_util.prepare_url(''f?p='' || :APP_ID || '':80:'' || :APP_SESSION || '':::80:P80_ID:'' || l.OPPORTUNITY_ID) || ''" class="simpleButton">Opportunity</a>''',
'  end action,',
'  l.tags,',
'  l.created,',
'  lower(l.created_by) created_by,',
'  l.updated,',
'  lower(l.updated_by) updated_by,',
'  t.id territory_id,',
'  t.territory_name,',
'  c.id account_id,',
'  c.customer_name account_name,',
'  slsc.status_code lead_status,',
'  ls.lead_source',
'from eba_sales_leads l',
'left join eba_sales_customers c',
'  on c.id = l.account_id',
'left join eba_sales_territories t',
'  on t.id = c.customer_territory_id ',
'left join eba_sales_lead_status_codes slsc',
'  on slsc.id = l.lead_status_id',
'left join eba_sales_lead_sources ls',
'  on ls.id = l.lead_source_id',
'where l.id = :P133_ID'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(7343875181010915291)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(7360330243415300092)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(7360330348562300095)
,p_query_column_id=>2
,p_column_alias=>'ROW_KEY'
,p_column_display_sequence=>2
,p_column_heading=>'Key'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(7360332967073314567)
,p_query_column_id=>3
,p_column_alias=>'LEAD_PRIORITY'
,p_column_display_sequence=>5
,p_column_heading=>'Priority'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6592774829180034178)
,p_query_column_id=>4
,p_column_alias=>'LEAD'
,p_column_display_sequence=>16
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6592774901798034179)
,p_query_column_id=>5
,p_column_alias=>'LEAD_DETAILS'
,p_column_display_sequence=>9
,p_column_heading=>'Details'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6592774972198034180)
,p_query_column_id=>6
,p_column_alias=>'LEAD_EMAIL_01'
,p_column_display_sequence=>10
,p_column_heading=>'Email'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6592775116725034181)
,p_query_column_id=>7
,p_column_alias=>'OPPORTUNITY_ID'
,p_column_display_sequence=>17
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(7360333044073314567)
,p_query_column_id=>8
,p_column_alias=>'ACTION'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(7360331151450300095)
,p_query_column_id=>9
,p_column_alias=>'TAGS'
,p_column_display_sequence=>11
,p_column_heading=>'Tags'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(7360333540055314567)
,p_query_column_id=>10
,p_column_alias=>'CREATED'
,p_column_display_sequence=>12
,p_column_heading=>'Created'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_column_html_expression=>'#CREATED# by #CREATED_BY#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(7360333937619314567)
,p_query_column_id=>11
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>13
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6592775136281034182)
,p_query_column_id=>12
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>14
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_column_html_expression=>'#UPDATED# by #UPDATED_BY#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6592775247531034183)
,p_query_column_id=>13
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>15
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6592775396122034184)
,p_query_column_id=>14
,p_column_alias=>'TERRITORY_ID'
,p_column_display_sequence=>18
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(7360330755556300095)
,p_query_column_id=>15
,p_column_alias=>'TERRITORY_NAME'
,p_column_display_sequence=>4
,p_column_heading=>'Account Territory'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Territories''',
') = ''INCLUDE'''))
,p_display_when_condition2=>'PLSQL'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6592775474559034185)
,p_query_column_id=>16
,p_column_alias=>'ACCOUNT_ID'
,p_column_display_sequence=>19
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(7360333156049314567)
,p_query_column_id=>17
,p_column_alias=>'ACCOUNT_NAME'
,p_column_display_sequence=>3
,p_column_heading=>'Account'
,p_column_link=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP,94:P94_ID:#ACCOUNT_ID#'
,p_column_linktext=>'#ACCOUNT_NAME#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(7360333341366314567)
,p_query_column_id=>18
,p_column_alias=>'LEAD_STATUS'
,p_column_display_sequence=>7
,p_column_heading=>'Status'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(7360333466129314567)
,p_query_column_id=>19
,p_column_alias=>'LEAD_SOURCE'
,p_column_display_sequence=>8
,p_column_heading=>'Source'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7378380366180679765)
,p_plug_name=>'Usage Metrics - 90 days'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(7343866444940915275)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select count(*) c,',
'  ''Views'' l,',
'  1 disp',
'from eba_sales_clicks',
'where lead_id = :P133_ID ',
'  and view_timestamp > sysdate - 90',
'union all',
'select count(distinct(app_username)) c,',
'    ''Users'' l,',
'    2 disp',
'from eba_sales_clicks',
'where lead_id = :P133_ID ',
'    and view_timestamp > sysdate - 90',
'order by disp'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_required_patch=>wwv_flow_api.id(6628607810862680350)
,p_attribute_01=>'L'
,p_attribute_02=>'C'
,p_attribute_04=>'f?p=&APP_ID.:138:&SESSION.::&DEBUG.:138:P138_ENTITY_TYPE,P138_ENTITY_ID:LEAD,&P133_ID.'
,p_attribute_05=>'2'
,p_attribute_06=>'L'
,p_attribute_07=>'DOT'
,p_attribute_08=>'N'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7378743446332810571)
,p_plug_name=>'Validations'
,p_region_css_classes=>'js-validateRegion'
,p_region_template_options=>'#DEFAULT#:t-Region--hiddenOverflow'
,p_plug_template=>wwv_flow_api.id(7343866444940915275)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.verified_by,',
'  v.created',
'from eba_sales_verifications v',
'where lead_id = :P133_ID',
'order by v.created desc'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.VALIDATOR'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_required_patch=>wwv_flow_api.id(7381617337298872120)
,p_attribute_01=>'f?p=&APP_ID.:146:&SESSION.::&DEBUG.:146:P146_ENTITY_TYPE,P146_ENTITY_ID:LEAD,&P133_ID.'
,p_attribute_02=>'f?p=&APP_ID.:147:&SESSION.::&DEBUG.:RP,147:P147_ENTITY_TYPE,P147_ENTITY_ID:LEAD,&P133_ID.'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7360338455807369320)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(7360326864636258423)
,p_button_name=>'CONVERT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7343886609855915317)
,p_button_image_alt=>'Convert Lead'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:63:&SESSION.::&DEBUG.:RP,63:P63_LEAD_ID:&P133_ID.'
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7360335041777327406)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(7360326864636258423)
,p_button_name=>'EDIT_LEAD'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(7343886609855915317)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Edit Lead'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:RP,29:P29_ID:&P133_ID.'
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6636844250727037773)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(10373553642022828503)
,p_button_name=>'POPATTACHMENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'Add Attachment'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:99:&SESSION.::&DEBUG.:RP,99:P99_ENTITY_TYPE,P99_ENTITY_ID:LEAD,&P133_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6636844656655037773)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(10373553642022828503)
,p_button_name=>'VIEW_ATTACHMENTS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'View Attachments'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:92:&SESSION.::&DEBUG.:RP,92:P92_ENTITY_TYPE,P92_ENTITY_ID:LEAD,&P133_ID.'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6629040735536012951)
,p_button_sequence=>240
,p_button_plug_id=>wwv_flow_api.id(12639994297061764443)
,p_button_name=>'POP_LINK'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'Add Link'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:RP,114:P114_ENTITY_TYPE,P114_ENTITY_ID:LEAD,&P133_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6629041141117012951)
,p_button_sequence=>250
,p_button_plug_id=>wwv_flow_api.id(12639994297061764443)
,p_button_name=>'VIEW_LINKS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'View Links'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:89:&SESSION.::&DEBUG.:RP,89:P89_ENTITY_TYPE,P89_ENTITY_ID:LEAD,&P133_ID.'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6646877074037267505)
,p_button_sequence=>260
,p_button_plug_id=>wwv_flow_api.id(9607804126252773209)
,p_button_name=>'POPCOMMENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'Add Comment'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:RP,22:P22_ENTITY_TYPE,P22_ENTITY_ID:LEAD,&P133_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_api.id(9042571137027542978)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(6646877411099268572)
,p_button_sequence=>270
,p_button_plug_id=>wwv_flow_api.id(9607804126252773209)
,p_button_name=>'VIEW_COMMENTS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_api.id(7343885855926915314)
,p_button_image_alt=>'View Comments'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:88:&SESSION.::&DEBUG.:RP,88:P88_ENTITY_TYPE,P88_ENTITY_ID:LEAD,&P133_ID.'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7360332246813308709)
,p_name=>'P133_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7360330045193300090)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6557242556895719081)
,p_name=>'Edit Lead dialog closed'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 29'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6557243489197719088)
,p_event_id=>wwv_flow_api.id(6557242556895719081)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(7360330045193300090)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6557242934964719084)
,p_event_id=>wwv_flow_api.id(6557242556895719081)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.t-Breadcrumb-item.is-active > span'').text(this.data.P29_LEAD_NAME_01);',
'apex.message.showPageSuccess(''Action Processed.'');'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6569635774983916354)
,p_name=>'Refresh Validations'
,p_event_sequence=>20
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId ===130'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6569636173221916360)
,p_event_id=>wwv_flow_api.id(6569635774983916354)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(7378743446332810571)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6629050796073039915)
,p_name=>'Link Details dialog closed'
,p_event_sequence=>50
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 114'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(7378375536519605013)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Init page'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into eba_sales_clicks (',
'  entity_type,',
'  lead_id,',
'    app_username',
') values (',
'  ''LEAD'',',
'  :P133_ID,',
'    lower(:APP_USER)',
');',
'',
'delete from eba_sales_clicks ',
'where view_timestamp < (sysdate - 90) ',
'  and lead_id = :P133_ID;',
''))
,p_process_clob_language=>'PLSQL'
);
wwv_flow_api.component_end;
end;
/
