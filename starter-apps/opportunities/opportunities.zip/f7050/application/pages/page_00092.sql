prompt --application/pages/page_00092
begin
--   Manifest
--     PAGE: 00092
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>92
,p_name=>'Attachments'
,p_alias=>'ATTACHMENTS'
,p_page_mode=>'MODAL'
,p_step_title=>'Attachments'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>'.t-Dialog-body {padding: 0; overflow: hidden;}'
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_dialog_css_classes=>'view-attachments-dialog'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_upd_yyyymmddhh24miss=>'20220823161416'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8896848040546938571)
,p_plug_name=>'Attachments'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders'
,p_plug_template=>wwv_flow_imp.id(7343865001510915269)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'  filename,',
'  apex_util.get_blob_file_src(''P99_FILE_BLOB'', id) attachment_link,',
'  file_comments,',
'  tags,',
'  apex_util.filesize_mask(dbms_lob.getlength(file_blob)) file_size,',
'  created, ',
'  lower(created_by) created_by,',
'  updated, ',
'  lower(updated_by) updated_by,',
'  null delete_attachment',
'from eba_sales_files',
'where (',
'  (:P92_ENTITY_TYPE = ''OPPORTUNITY'' and deal_id = :P92_ENTITY_ID)',
'    or (:P92_ENTITY_TYPE = ''TERRITORY'' and territory_id = :P92_ENTITY_ID)',
'    or (:P92_ENTITY_TYPE = ''LEAD'' and lead_id = :P92_ENTITY_ID)',
'    or (:P92_ENTITY_TYPE = ''ACCOUNT'' and account_id = :P92_ENTITY_ID)',
'    or (:P92_ENTITY_TYPE = ''CONTACT'' and contact_id = :P92_ENTITY_ID)',
'    or (:P92_ENTITY_TYPE = ''PRODUCT'' and product_id = :P92_ENTITY_ID)',
')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(8896848137989938919)
,p_name=>'Files'
,p_max_row_count=>'100000'
,p_max_row_count_message=>'This query returns more than #MAX_ROW_COUNT# rows, please filter your data to ensure complete results.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:99:&SESSION.::&DEBUG.:99:P99_ID:#ID#'
,p_detail_link_text=>'<span class="fa fa-edit" aria-hidden="true"></span>'
,p_detail_link_attr=>'title="Edit #FILENAME#"'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(9042571137027542978)
,p_owner=>'CBCHO'
,p_internal_uid=>2386483703379411512
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8896848444504938931)
,p_db_column_name=>'ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8896848556967938931)
,p_db_column_name=>'FILENAME'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Attachment'
,p_column_link=>'#ATTACHMENT_LINK#'
,p_column_linktext=>'#FILENAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_rpt_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select filename',
'from eba_sales_files',
'where deal_id = :P92_ENTITY_ID',
'order by 1'))
,p_rpt_show_filter_lov=>'C'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8896848654833938931)
,p_db_column_name=>'FILE_COMMENTS'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6603324820275329472)
,p_db_column_name=>'FILE_SIZE'
,p_display_order=>14
,p_column_identifier=>'Q'
,p_column_label=>'File size'
,p_column_type=>'STRING'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8896848753510938931)
,p_db_column_name=>'TAGS'
,p_display_order=>24
,p_column_identifier=>'E'
,p_column_label=>'Tags'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8896849051297938932)
,p_db_column_name=>'CREATED'
,p_display_order=>34
,p_column_identifier=>'H'
,p_column_label=>'Added'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8896849161111938932)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>44
,p_column_identifier=>'I'
,p_column_label=>'Added By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8896849255889938932)
,p_db_column_name=>'UPDATED'
,p_display_order=>54
,p_column_identifier=>'J'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8896849351088938932)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>64
,p_column_identifier=>'K'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6603324574754329470)
,p_db_column_name=>'DELETE_ATTACHMENT'
,p_display_order=>74
,p_column_identifier=>'O'
,p_column_label=>'Delete'
,p_column_link=>'javascript:void(0);'
,p_column_linktext=>'<span aria-hidden="true" class="t-Icon fa fa-trash-o"></span>'
,p_column_link_attr=>'data-attachment-id="#ID#" title="Delete Attachment" class="t-Button t-Button--small t-Button--danger t-Button--simple delete-attachment"'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6603324655423329471)
,p_db_column_name=>'ATTACHMENT_LINK'
,p_display_order=>84
,p_column_identifier=>'P'
,p_column_label=>'Attachment link'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(8896856842970939271)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'23864925'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'FILENAME:FILE_COMMENTS:FILE_SIZE:CREATED:CREATED_BY:DELETE_ATTACHMENT:'
,p_sort_column_1=>'CREATED'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8898485362851380322)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8896848040546938571)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886016830915316)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:92:&SESSION.::&DEBUG.:RP,RIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8898534966098390668)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(8896848040546938571)
,p_button_name=>'ATTACH_FILE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7343886609855915317)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Attachment'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:99:&SESSION.::&DEBUG.:99:P99_ENTITY_TYPE,P99_ENTITY_ID:&P92_ENTITY_TYPE.,&P92_ENTITY_ID.'
,p_security_scheme=>wwv_flow_imp.id(9042571137027542978)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6636180078755949167)
,p_name=>'P92_ENTITY_TYPE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8896848040546938571)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6636180697654949173)
,p_name=>'P92_DELETE_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(8896848040546938571)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8861640661654135620)
,p_name=>'P92_ENTITY_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(8896848040546938571)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6563090353551612818)
,p_name=>'Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6563090770172612851)
,p_event_id=>wwv_flow_imp.id(6563090353551612818)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8896848040546938571)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6563091219873612851)
,p_event_id=>wwv_flow_imp.id(6563090353551612818)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (this.data.REQUEST === ''CREATE'') {',
'  apex.message.showPageSuccess(''Attachment Added.'');',
'} if (this.data.REQUEST === ''SAVE'') {',
'  apex.message.showPageSuccess(''Attachment Updated.'');',
'} if (this.data.REQUEST === ''DELETE'') {',
'  apex.message.showPageSuccess(''Attachment Deleted.'');',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6636180395712949170)
,p_name=>'Delete Attachment clicked'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.delete-attachment'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6636180510125949171)
,p_event_id=>wwv_flow_imp.id(6636180395712949170)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Are you sure you want to delete this attachment?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6636180547379949172)
,p_event_id=>wwv_flow_imp.id(6636180395712949170)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var attachmentId = $(this.triggeringElement).data(''attachment-id'');',
'',
'$s(''P92_DELETE_ID'', attachmentId);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6636180833170949174)
,p_event_id=>wwv_flow_imp.id(6636180395712949170)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from eba_sales_files',
'where id = :P92_DELETE_ID;',
'',
':P92_DELETE_ID := null;'))
,p_attribute_02=>'P92_DELETE_ID'
,p_attribute_03=>'P92_DELETE_ID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6636180874702949175)
,p_event_id=>wwv_flow_imp.id(6636180395712949170)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8896848040546938571)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6636180989113949176)
,p_event_id=>wwv_flow_imp.id(6636180395712949170)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''Attachment Deleted.'');'
);
wwv_flow_imp.component_end;
end;
/
