prompt --application/pages/page_00125
begin
--   Manifest
--     PAGE: 00125
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>125
,p_name=>'Territory States'
,p_alias=>'TERRITORY-STATES'
,p_step_title=>'States'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(7216874050933627053)
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(10496139698135220995)
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    To edit a state assignment, click the <strong>Edit</strong> icon (pencil) next to the country assignment. Click the <strong>Add State</strong> button to assign a new state to the territory. Click the <strong>Reset</strong> button to reset the int'
||'eractive report. Click the <strong>Actions</strong> button to define the number of rows displayed per page, filter, format, download, and/or save the interactive report.',
'</p>'))
,p_page_component_map=>'18'
,p_last_upd_yyyymmddhh24miss=>'20230110134706'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9048749542090044219)
,p_plug_name=>'Territory States'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343865001510915269)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select s.id,',
'  m.state_id, ',
'  s.state,',
'  s.code,',
'  m.created date_added, ',
'  lower(m.created_by) added_by,',
'  null remove_button ',
'from eba_sales_states s, eba_sales_terr_map m',
'where s.id = m.state_id',
'and m.territory_id = :P125_TERRITORY_ID',
'order by 1',
''))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(9048749757427044220)
,p_name=>'Territory Countries'
,p_max_row_count=>'100000'
,p_max_row_count_message=>'This query returns more than #MAX_ROW_COUNT# rows, please filter your data to ensure complete results.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'Y'
,p_owner=>'CBCHO'
,p_internal_uid=>2538385322816516813
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9048749963368044222)
,p_db_column_name=>'DATE_ADDED'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Added'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9048750055793044222)
,p_db_column_name=>'ADDED_BY'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Added By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9048752338921049273)
,p_db_column_name=>'STATE'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'State'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9048752543076050493)
,p_db_column_name=>'STATE_ID'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'State Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6407136752175009663)
,p_db_column_name=>'REMOVE_BUTTON'
,p_display_order=>16
,p_column_identifier=>'G'
,p_column_label=>'Remove'
,p_column_link=>'javascript:void(0);'
,p_column_linktext=>'<span class="t-Icon fa fa-trash-o"></span>'
,p_column_link_attr=>'class="t-Button t-Button--small t-Button--noUI t-Button--danger js-removeTerritoryState" data-territory-state-id="#ID#"'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6407136859295009664)
,p_db_column_name=>'ID'
,p_display_order=>26
,p_column_identifier=>'H'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6708497773720619291)
,p_db_column_name=>'CODE'
,p_display_order=>36
,p_column_identifier=>'I'
,p_column_label=>'Code'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(9048750334687044224)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'25383860'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'STATE:CODE:DATE_ADDED:ADDED_BY:REMOVE_BUTTON:'
,p_sort_column_1=>'DATE_ADDED'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9048751537099044228)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343869008886915277)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10495270706565772431)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(7343886820987915318)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9048750958530044227)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9048751537099044228)
,p_button_name=>'ADD_STATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7343886609855915317)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add State'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:126:&SESSION.::&DEBUG.:126:P126_TERRITORY_ID:&P125_TERRITORY_ID.'
,p_security_scheme=>wwv_flow_imp.id(9042571137027542978)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9048750763549044224)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9048749542090044219)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886016830915316)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:125:&SESSION.::&DEBUG.:RP,RIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9048751137345044227)
,p_name=>'P125_TERRITORY_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(9048749542090044219)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9048751345265044228)
,p_name=>'P125_TERRITORY_STATE_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9048749542090044219)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(9048820059100111947)
,p_computation_sequence=>10
,p_computation_item=>'P93_ID'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'ITEM_VALUE'
,p_computation=>'P125_TERRITORY_ID'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6407978012187861506)
,p_name=>'Remove territory state button clicked'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.js-removeTerritoryState'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6407979844266861514)
,p_event_id=>wwv_flow_imp.id(6407978012187861506)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Are you sure you want to remove this state from the territory?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6407978389438861510)
,p_event_id=>wwv_flow_imp.id(6407978012187861506)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var id = $(this.triggeringElement).data(''territory-state-id'');',
'',
'$s(''P125_TERRITORY_STATE_ID'', id);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6407978930369861511)
,p_event_id=>wwv_flow_imp.id(6407978012187861506)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from eba_sales_terr_map',
'where state_id = :P125_TERRITORY_STATE_ID;'))
,p_attribute_02=>'P125_TERRITORY_STATE_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6407979422923861514)
,p_event_id=>wwv_flow_imp.id(6407978012187861506)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9048749542090044219)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6407980394351861515)
,p_event_id=>wwv_flow_imp.id(6407978012187861506)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''State Removed'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6407136956303009665)
,p_name=>'Add State dialog closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(9048750958530044227)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6407137047324009666)
,p_event_id=>wwv_flow_imp.id(6407136956303009665)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9048749542090044219)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6407137828441009673)
,p_event_id=>wwv_flow_imp.id(6407136956303009665)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''State Added'');'
);
wwv_flow_imp.component_end;
end;
/
