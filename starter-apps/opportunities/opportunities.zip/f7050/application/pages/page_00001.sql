prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_imp.id(6988712858842356549)
,p_name=>'Opportunities'
,p_alias=>'OPPORTUNITIES'
,p_step_title=>'Opportunities'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(7216871762230620860)
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// standard, cacheable elements',
'var timeout = 0; // used for debounce on search',
'var CONTAINER_SEL = ''.t-Form-fieldContainer'';',
'var pagePrefix = ''P'' + $(''#pFlowStepId'').val();',
'var displayAsId = pagePrefix + ''_DISPLAY_AS'';',
'var $displayAs = $(''#'' + displayAsId);',
'var $body = $(''.t-PageBody'');',
'var $search = $(''#'' + pagePrefix + ''_SEARCH'');',
'var $sort = $(''#'' + pagePrefix + ''_SORT'');',
'var $reset = $(''#reset_button'');',
'var $cardsReg = $(''#cards_region'');',
'var $reportReg = $(''#report_region'');',
'var $gridReg = $(''#grid_region'');',
'',
'// custom items (will vary by page)',
'var $territory = $(''#'' + pagePrefix + ''_TERRITORY_ID'');',
'var $account = $(''#'' + pagePrefix + ''_ACCOUNT_ID'');',
'var $show = $(''#'' + pagePrefix + ''_SHOW'');',
'var $quarter = $(''#'' + pagePrefix + ''_QUARTER'');',
'',
'function showLeftColumn() {',
'  $body',
'    .removeClass(''t-PageBody--hideLeft'')',
'    .addClass(''t-PageBody--showLeft'');',
'    ',
'  // Takes 200ms to hide column',
'  setTimeout(function() {',
'    // Ensure column headers align correctly',
'    $(window).trigger(''apexwindowresized'');',
'  }, 250);',
'}',
'',
'function hideLeftColumn() {',
'  $body',
'    .removeClass(''t-PageBody--showLeft'')',
'    .addClass(''t-PageBody--hideLeft'');',
'    ',
'  // Takes 200ms to hide column',
'  setTimeout(function() {',
'    // Ensure column headers align correctly',
'    $(window).trigger(''apexwindowresized'');',
'  }, 250);',
'}',
'  ',
'// applyFilters triggers the refresh event on the correct region',
'function applyFilters() {',
'  var display = $v(displayAsId);',
'  ',
'  if (display === ''CARDS'') {',
'    $cardsReg.trigger(''apexrefresh'');',
'  } else if (display === ''REPORT'') {',
'    $reportReg.trigger(''apexrefresh'');',
'  } else if (display === ''GRID'') {',
'    $gridReg.trigger(''apexrefresh'');',
'  }',
'}',
'',
'// toggleRegionDisplay is similar to applyFilters except that it also',
'// takes into account what regions or items need to be displayed or hidden',
'function toggleRegionDisplay(refresh) {',
'  var display = $v(displayAsId);',
'  ',
'  refresh = (refresh === false) ? false : true;',
'  ',
'  if (display === ''CARDS'') {',
'    $reportReg.hide();',
'    $gridReg.hide();',
'',
'    showLeftColumn();',
'',
'    $sort.closest(CONTAINER_SEL).show();',
'',
'    if (refresh) {',
'      $cardsReg.trigger(''apexrefresh'');',
'    }',
'    ',
'    $cardsReg.show();',
'  } else if (display === ''REPORT'') {',
'    $sort.closest(CONTAINER_SEL).hide();',
'    $cardsReg.hide();',
'    $gridReg.hide();',
'',
'    showLeftColumn();',
'',
'    if (refresh) {',
'      $reportReg.trigger(''apexrefresh'');',
'    }',
'',
'    $reportReg.show();',
'  } else if (display === ''GRID'') {',
'    $sort.closest(CONTAINER_SEL).hide();',
'    $cardsReg.hide();',
'    $reportReg.hide();',
'',
'    hideLeftColumn();',
'',
'    if (refresh) {',
'      $gridReg.trigger(''apexrefresh'');',
'    }',
'',
'    $gridReg.show();',
'  }',
'}',
'  ',
'function debounceSearch(e) {',
'    /*',
'     * Prevent search for following keys:',
'     * TAB:     9',
'     * SHIFT:   16',
'     * LEFT:    37',
'     * RIGHT:   39',
'     */',
'    if ( e.which === 9 || e.which === 16 || e.which === 37 || e.which === 39 ) {',
'        return false;',
'    }',
'    clearTimeout(timeout);',
'    timeout = setTimeout(applyFilters, 250);',
'}',
'',
'function preventSubmitOnEnter(e) {',
'  if (e.which === 13) {',
'    return false;',
'  }',
'}',
'',
'function resetFilters() {',
'  $search.val(null);',
'  $territory.val(null);',
'  $account.val(null);',
'  $show.val(null);',
'  $quarter.val(null);',
'  ',
'  $sort.val(''NAME'');',
'  ',
'  applyFilters();',
'}',
'',
'// standard search event bindings',
'$search.keydown(preventSubmitOnEnter);',
'$search.keyup(debounceSearch);',
'',
'// dynamic event bindings (will vary by filter page)',
'$territory.change(applyFilters);',
'$account.change(applyFilters);',
'$show.change(applyFilters);',
'$quarter.change(applyFilters);',
'',
'// standard display, sort, reset event bindings',
'$displayAs.change(toggleRegionDisplay);',
'$sort.change(applyFilters);',
'$reset.click(resetFilters);',
'  ',
'toggleRegionDisplay(false);'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Card-initials {',
'  font-size: 14px;',
'}'))
,p_step_template=>wwv_flow_imp.id(7343828740328915198)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Use the filters on the left to show different results in the region on the right. The right region can be displayed in one of three ways (Cards View, Report View, and Customizable Grid) by using the display-mode buttons (located to the left of the <s'
||'trong>Create Opportunity</strong> button). Filters are not displayed in the Customizable Grid view.',
''))
,p_page_component_map=>'18'
,p_last_updated_by=>'PAIGE'
,p_last_upd_yyyymmddhh24miss=>'20220404112154'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(6574212288912083493)
,p_name=>'Opportunities Report'
,p_region_name=>'report_region'
,p_template=>wwv_flow_imp.id(7343866444940915275)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline'
,p_region_attributes=>'style="display:none"'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d.id,',
'  d.row_key,',
'  d.deal_name,',
'  t.id territory_id,',
'  t.territory_name,',
'  c.id account_id,',
'  c.customer_name account,',
'  d.qtr,',
'  (select max(dp.qtr) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id) as calculated_qtr,',
'  dsc.status_code,',
'  nvl((select sum(nvl(dp.quote_price, 0)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id), 0) as calculated_amount,',
'  d.deal_amount,',
'  d.updated',
'from eba_sales_deals d',
'join eba_sales_customers c',
'  on c.id = d.customer_id',
'left join eba_sales_deal_status_codes dsc',
'  on dsc.id = d.deal_status_code_id',
'left join eba_sales_territories t',
'  on t.id = c.customer_territory_id',
'where :P1_DISPLAY_AS = ''REPORT''',
'  and (',
'    :P1_SHOW is null',
'      or (:P1_SHOW = ''OPEN'' and d.deal_probability between 1 and 99)',
'      or (:P1_SHOW = ''CLOSED'' and d.deal_probability in (0,100))',
'  )',
'  and (',
'    :P1_TERRITORY_ID is null ',
'      or c.customer_territory_id = :P1_TERRITORY_ID',
'  )',
'  and (',
'    :P1_ACCOUNT_ID is null ',
'      or c.id = :P1_ACCOUNT_ID',
'  )',
'  and (',
'    :P1_QUARTER is null ',
'      or d.qtr = :P1_QUARTER',
'  )',
'  and (',
'    :P1_SEARCH is null',
'      or instr(upper(d.deal_name), upper(:P1_SEARCH)) > 0',
'      or instr(upper(d.row_key), upper(:P1_SEARCH)) > 0',
'      or instr(upper(d.qtr), upper(:P1_SEARCH)) > 0',
'      or instr(upper(apex_util.get_since(d.updated)), upper(:P1_SEARCH)) > 0',
'      or instr(upper(d.tags), upper(:P1_SEARCH)) > 0',
'      or instr(upper(d.deal_summary), upper(:P1_SEARCH)) > 0',
'      or instr(upper(t.territory_name), upper(:P1_SEARCH)) > 0',
'      or instr(upper(c.customer_name), upper(:P1_SEARCH)) > 0',
'      or instr(upper(dsc.status_code), upper(:P1_SEARCH)) > 0',
'  )'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P1_SEARCH,P1_SHOW,P1_TERRITORY_ID,P1_ACCOUNT_ID,P1_QUARTER,P1_DISPLAY_AS'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(7343873253436915289)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'No opportunities found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6574212347588083494)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6574212479700083495)
,p_query_column_id=>2
,p_column_alias=>'ROW_KEY'
,p_column_display_sequence=>3
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6574212620342083496)
,p_query_column_id=>3
,p_column_alias=>'DEAL_NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Opportunity'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:80:&SESSION.::&DEBUG.:RP,80:P80_ID:#ID#'
,p_column_linktext=>'#DEAL_NAME#'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6574212724219083497)
,p_query_column_id=>4
,p_column_alias=>'TERRITORY_ID'
,p_column_display_sequence=>8
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6585008288957530548)
,p_query_column_id=>5
,p_column_alias=>'TERRITORY_NAME'
,p_column_display_sequence=>9
,p_column_heading=>'Account Territory'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6585008395487530549)
,p_query_column_id=>6
,p_column_alias=>'ACCOUNT_ID'
,p_column_display_sequence=>6
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6585008445802530550)
,p_query_column_id=>7
,p_column_alias=>'ACCOUNT'
,p_column_display_sequence=>7
,p_column_heading=>'Account'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6585008536387530551)
,p_query_column_id=>8
,p_column_alias=>'QTR'
,p_column_display_sequence=>11
,p_column_heading=>'Quarter'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>-wwv_flow_imp.id(7478708532380272297)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7573360812216586260)
,p_query_column_id=>9
,p_column_alias=>'CALCULATED_QTR'
,p_column_display_sequence=>10
,p_column_heading=>'Quarter'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>wwv_flow_imp.id(7478708532380272297)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6585008698183530552)
,p_query_column_id=>10
,p_column_alias=>'STATUS_CODE'
,p_column_display_sequence=>12
,p_column_heading=>'Stage'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7457943167092814061)
,p_query_column_id=>11
,p_column_alias=>'CALCULATED_AMOUNT'
,p_column_display_sequence=>4
,p_column_heading=>'Amount'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7457943254555814062)
,p_query_column_id=>12
,p_column_alias=>'DEAL_AMOUNT'
,p_column_display_sequence=>5
,p_column_heading=>'Amount'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>-wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6585008818824530553)
,p_query_column_id=>13
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>13
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6592170463481718854)
,p_plug_name=>'Opportunities Grid'
,p_region_name=>'grid_region'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343865001510915269)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d.id,',
'  d.row_key,',
'  d.deal_name,',
'  t.id territory_id,',
'  (select count(*) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id) as product_cnt,',
'  (select',
'    listagg(p.product_name,'', '') within group (order by p.product_name asc)',
'  from EBA_SALES_DEAL_PRODUCTS dp,',
'       EBA_SALES_PRODUCTS p,',
'       EBA_SALES_PRODUCT_FAMILIES f',
' where dp.deal_id = d.id',
'   and dp.product_id = p.id',
'   and p.product_family_id = f.id (+)) as products,',
'  (select',
'    distinct RTRIM(',
'         REGEXP_REPLACE(',
'           (listagg(f.product_family,'', '') within group (order by f.product_family asc) OVER ()), ',
'           ''([^, ]*)(, \1)+($|, )'', ',
'           ''\1\3''),',
'         '', '')',
'  from EBA_SALES_DEAL_PRODUCTS dp,',
'       EBA_SALES_PRODUCTS p,',
'       EBA_SALES_PRODUCT_FAMILIES f',
' where dp.deal_id = d.id',
'   and dp.product_id = p.id',
'   and p.product_family_id = f.id) as product_families,',
'  (select',
'    distinct RTRIM(',
'         REGEXP_REPLACE(',
'           (listagg(lob.name,'', '') within group (order by lob.name asc) OVER ()), ',
'           ''([^, ]*)(, \1)+($|, )'', ',
'           ''\1\3''),',
'         '', '')',
'  from EBA_SALES_DEAL_PRODUCTS dp,',
'       EBA_SALES_PRODUCTS p,',
'       EBA_SALES_PRODUCT_FAMILIES f,',
'       EBA_SALES_PRODUCT_LOBS lob',
' where dp.deal_id = d.id',
'   and dp.product_id = p.id',
'   and p.product_family_id = f.id',
'   and f.lob_id = lob.id) as lobs,',
'  t.territory_name,',
'  c.id account_id,',
'  c.customer_name account,',
'  d.deal_amount,',
'  nvl((select sum(nvl(dp.quote_price, 0)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id and dp.term is not null), 0) as calculated_amount,',
'  nvl((select sum(nvl(dp.quote_price, 0)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id and dp.term is null), 0) as calculated_opp,',
'  nvl((select sum(nvl(dp.tcv, 0)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id and dp.term is not null), 0) as calculated_tcv,',
'  nvl((select sum(nvl(dp.quote_price, 0)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id and dp.term is null), 0) + nvl((select sum(nvl(dp.quote_price, 0)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id and dp.term is not null), 0) '
||'as revenue,',
'  d.deal_probability,',
'  case',
'    when deal_probability > 0 and deal_probability < 100',
'    then ''Yes''',
'    else ''No''',
'  end open,',
'  deal_close_date,',
'  case',
'    when deal_close_date < sysdate and deal_probability != 0 and deal_probability != 100',
'    then ''Yes''',
'    else ''No''',
'  end past_due,',
'  d.qtr,',
'  (select listagg(dp.qtr,'', '') within group (order by dp.qtr asc) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id) as calculated_qtr,',
'  dsc.status_code,',
'  d.tags,',
'  (',
'    select count(*)',
'    from eba_sales_links',
'    where deal_id = d.id',
'  ) links,',
'  (',
'    select count(*)',
'    from eba_sales_files',
'    where deal_id = d.id',
'  ) attachments,',
'  (',
'    select count(*)',
'    from eba_sales_comments',
'    where deal_id = d.id',
'  ) comments,',
'  (',
'    select count(*)',
'    from eba_sales_verifications',
'    where opp_id = d.id',
'  ) validations,',
'  (',
'    select max(created)',
'    from eba_sales_verifications',
'    where opp_id = d.id',
'  ) last_validation,',
'  (',
'    select count(*)',
'    from eba_sales_clicks',
'    where opp_id = d.id',
'      and view_timestamp >= sysdate - 90',
'  ) views_90_days,',
'      ( select count(distinct(app_username))',
'        from eba_sales_clicks',
'        where opp_id = d.id',
'            and view_timestamp >= sysdate - 90',
'  ) users_90_days,',
'  d.svp_id,',
'  c.SECONDARY_REP,',
'  d.updated,',
'  d.updated_by,',
'  d.created,',
'  d.created_by,',
'  sr.rep_first_name || '' '' || sr.rep_last_name as sales_rep_name,',
'  sr.REP_MANAGER_ID as sales_mgr',
'from eba_sales_deals d',
'join eba_sales_customers c',
'  on c.id = d.customer_id',
'left join eba_sales_deal_status_codes dsc',
'  on dsc.id = d.deal_status_code_id',
'left join eba_sales_territories t',
'  on t.id = c.customer_territory_id',
'left join eba_sales_salesreps sr',
'  on sr.id = d.salesrep_id_01',
'where :P1_DISPLAY_AS = ''GRID'''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P1_DISPLAY_AS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(6592170596638718855)
,p_max_row_count=>'1000000'
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_imp.id(9042570640734542978)
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_icon_view_columns_per_row=>1
,p_owner=>'DAN'
,p_internal_uid=>721307562185153108
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592170699805718856)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592170796673718857)
,p_db_column_name=>'ROW_KEY'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Key'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592170894019718858)
,p_db_column_name=>'DEAL_NAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Opportunity'
,p_column_link=>'f?p=&APP_ID.:80:&SESSION.::&DEBUG.:RP,80:P80_ID:#ID#'
,p_column_linktext=>'#DEAL_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592171030720718859)
,p_db_column_name=>'TERRITORY_ID'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Territory id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592171097915718860)
,p_db_column_name=>'TERRITORY_NAME'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Account Territory'
,p_column_link=>'f?p=&APP_ID.:93:&SESSION.::&DEBUG.:RP,93:P93_ID:#TERRITORY_ID#'
,p_column_linktext=>'#TERRITORY_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Territories''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592171212373718861)
,p_db_column_name=>'ACCOUNT_ID'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Selected Account'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592171263080718862)
,p_db_column_name=>'ACCOUNT'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Account'
,p_column_link=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP,94:P94_ID:#ACCOUNT_ID#'
,p_column_linktext=>'#ACCOUNT#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592171374471718863)
,p_db_column_name=>'QTR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Quarter'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_required_patch=>-wwv_flow_imp.id(7478708532380272297)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592171492243718864)
,p_db_column_name=>'STATUS_CODE'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Stage'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592171537740718865)
,p_db_column_name=>'UPDATED'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_TIME_FMT.'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592171794587718867)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592171924120718868)
,p_db_column_name=>'CREATED'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_TIME_FMT.'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592172018792718869)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592774460275034175)
,p_db_column_name=>'DEAL_PROBABILITY'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Probability'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592774566153034176)
,p_db_column_name=>'OPEN'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Open'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592774700092034177)
,p_db_column_name=>'PAST_DUE'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Past Due'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592776728252034197)
,p_db_column_name=>'DEAL_AMOUNT'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'&AMT_HDR.'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
,p_required_patch=>-wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7026387461831438385)
,p_db_column_name=>'CALCULATED_AMOUNT'
,p_display_order=>180
,p_column_identifier=>'AC'
,p_column_label=>'&AMT_HDR.'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999G999G999'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8023075159534039166)
,p_db_column_name=>'CALCULATED_TCV'
,p_display_order=>190
,p_column_identifier=>'AE'
,p_column_label=>'Total Contract Value'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6597146428833006748)
,p_db_column_name=>'SALES_REP_NAME'
,p_display_order=>200
,p_column_identifier=>'R'
,p_column_label=>'&REP_TITLE.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6661029757979044662)
,p_db_column_name=>'TAGS'
,p_display_order=>210
,p_column_identifier=>'S'
,p_column_label=>'Tags'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6661029929383044663)
,p_db_column_name=>'LINKS'
,p_display_order=>220
,p_column_identifier=>'T'
,p_column_label=>'Links'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6661029987514044664)
,p_db_column_name=>'ATTACHMENTS'
,p_display_order=>230
,p_column_identifier=>'U'
,p_column_label=>'Attachments'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6661030087002044665)
,p_db_column_name=>'COMMENTS'
,p_display_order=>240
,p_column_identifier=>'V'
,p_column_label=>'Comments'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6661030170139044666)
,p_db_column_name=>'VALIDATIONS'
,p_display_order=>250
,p_column_identifier=>'W'
,p_column_label=>'Validations'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Validations''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6661030281792044667)
,p_db_column_name=>'LAST_VALIDATION'
,p_display_order=>260
,p_column_identifier=>'X'
,p_column_label=>'Last Validation'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Validations''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6661030421244044668)
,p_db_column_name=>'VIEWS_90_DAYS'
,p_display_order=>270
,p_column_identifier=>'Y'
,p_column_label=>'90 Day Views'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Usage Metrics''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6802489836552595751)
,p_db_column_name=>'USERS_90_DAYS'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'90 Day Users'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Usage Metrics''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6591780684081931855)
,p_db_column_name=>'DEAL_CLOSE_DATE'
,p_display_order=>290
,p_column_identifier=>'AA'
,p_column_label=>'Close Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_FORMAT.'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7573360834750586261)
,p_db_column_name=>'CALCULATED_QTR'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Quarter'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6047325237328045862)
,p_db_column_name=>'CALCULATED_OPP'
,p_display_order=>310
,p_column_identifier=>'AF'
,p_column_label=>'On-Premise Purchase Value'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6047325188808045861)
,p_db_column_name=>'REVENUE'
,p_display_order=>320
,p_column_identifier=>'AG'
,p_column_label=>'Total Revenue'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8451266027941738272)
,p_db_column_name=>'SVP_ID'
,p_display_order=>330
,p_column_identifier=>'AH'
,p_column_label=>'SVP'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(8454523626590621748)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8451266075000738273)
,p_db_column_name=>'SECONDARY_REP'
,p_display_order=>340
,p_column_identifier=>'AI'
,p_column_label=>'&SALES_LDR_TITLE.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8451266162744738274)
,p_db_column_name=>'SALES_MGR'
,p_display_order=>350
,p_column_identifier=>'AJ'
,p_column_label=>'&REP_TITLE. Manager'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(8454529635334784561)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8451266274415738275)
,p_db_column_name=>'PRODUCTS'
,p_display_order=>360
,p_column_identifier=>'AK'
,p_column_label=>'Products'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(10496485785461002628)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8451266402721738276)
,p_db_column_name=>'PRODUCT_CNT'
,p_display_order=>370
,p_column_identifier=>'AL'
,p_column_label=>'Product Count'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(10496485785461002628)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3464265335459172995)
,p_db_column_name=>'PRODUCT_FAMILIES'
,p_display_order=>380
,p_column_identifier=>'AM'
,p_column_label=>'Product Families'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(10496485785461002628)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6403327415553096176)
,p_db_column_name=>'LOBS'
,p_display_order=>390
,p_column_identifier=>'AN'
,p_column_label=>'Lines of Business'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(6592737328478352540)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'7218743'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DEAL_NAME:ACCOUNT:TERRITORY_NAME:SALES_REP_NAME:SALES_MGR:SVP_ID:SECONDARY_REP:CALCULATED_QTR:STATUS_CODE:DEAL_PROBABILITY:OPEN:PAST_DUE:PRODUCT_CNT:LOBS:PRODUCT_FAMILIES:PRODUCTS:CALCULATED_TCV:CALCULATED_AMOUNT:CALCULATED_OPP:REVENUE:'
,p_sort_column_1=>'REVENUE'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'CALCULATED_AMOUNT'
,p_sort_direction_2=>'DESC'
,p_sum_columns_on_break=>'REVENUE'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(3297939856691375480)
,p_report_id=>wwv_flow_imp.id(6592737328478352540)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'STATUS_CODE'
,p_operator=>'!='
,p_expr=>'Opportunity Closed / Lost'
,p_condition_sql=>'"STATUS_CODE" != #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# != ''Opportunity Closed / Lost''  '
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(8122476714431474968)
,p_name=>'Opportunities Cards'
,p_region_name=>'cards_region'
,p_template=>wwv_flow_imp.id(7343855668783915255)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--basic:t-Cards--3cols:t-Cards--animColorFill'
,p_region_attributes=>'style="display:none"'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with base_opps as (',
'  select d.id,',
'    d.row_key,',
'    d.deal_name,',
'    t.id territory_id,',
'    c.id account_id,',
'    c.customer_name account_name,',
'    d.qtr,',
'    dsc.status_code,',
'    case when apex_util.get_build_option_status(',
'                  p_application_id    => :APP_ID,',
'                  p_build_option_name => ''Opportunity Amount Set at Product Level''',
'              ) = ''INCLUDE'' then',
'        (select to_char(sum(quote_price),''999G999G999G999G999G999G990'') from eba_sales_deal_products dp where dp.deal_id = d.id)',
'    else',
'        to_char(nvl(d.deal_amount, 0), ''999G999G999G999G999G999G990'')',
'    end amount,',
'    d.updated,',
'    d.deal_summary,',
'    d.tags',
'  from eba_sales_deals d',
'  join eba_sales_customers c',
'    on c.id = d.customer_id',
'  left join eba_sales_deal_status_codes dsc',
'    on dsc.id = d.deal_status_code_id',
'  left join eba_sales_territories t',
'    on t.id = c.customer_territory_id',
'  where :P1_DISPLAY_AS = ''CARDS''',
'    and (',
'      :P1_SHOW is null',
'        or (:P1_SHOW = ''OPEN'' and d.deal_probability between 1 and 99)',
'        or (:P1_SHOW = ''CLOSED'' and d.deal_probability in (0,100))',
'    )',
'    and (',
'      :P1_TERRITORY_ID is null ',
'        or c.customer_territory_id = :P1_TERRITORY_ID',
'    )',
'    and (',
'      :P1_ACCOUNT_ID is null ',
'        or c.id = :P1_ACCOUNT_ID',
'    )',
'    and (',
'      :P1_QUARTER is null ',
'        or d.qtr = :P1_QUARTER',
'    )',
'),',
'card_details as (',
'  select deal_name card_title,',
'    null card_icon,',
'    row_key card_initials,',
'    null card_text,',
'    ''Account: '' || account_name card_text_acct,',
'    ''Quarter: '' || qtr card_text_qtr,',
'    ''Stage: '' || status_code card_text_stg,',
'    ''Amount: '' || amount card_text_amt,',
'    apex_util.prepare_url(',
'      ''f?p='' ||',
'      :APP_ID ||',
'      '':80:'' ||',
'      :APP_SESSION ||',
'      '':::80,RP:P80_ID:'' ||',
'      id',
'    ) card_link,',
'    updated card_subtext,',
'    id,',
'    account_name,',
'    updated,',
'    amount,',
'    tags,',
'    deal_summary',
'  from base_opps',
')',
'select *',
'from card_details',
'where (',
'    :P1_SEARCH is null',
'      or instr(upper(card_title), upper(:P1_SEARCH)) > 0',
'      or instr(upper(card_initials), upper(:P1_SEARCH)) > 0',
'      or instr(upper(card_text_acct), upper(:P1_SEARCH)) > 0',
'      or instr(upper(card_text_qtr), upper(:P1_SEARCH)) > 0',
'      or instr(upper(card_text_stg), upper(:P1_SEARCH)) > 0',
'      or instr(upper(''Updated: '' || apex_util.get_since(updated)), upper(:P1_SEARCH)) > 0',
'      or instr(upper(tags), upper(:P1_SEARCH)) > 0',
'      or instr(upper(deal_summary), upper(:P1_SEARCH)) > 0',
'  )',
'order by',
'  case :P1_SORT',
'    when ''NAME'' then card_title',
'  end,',
'  case :P1_SORT',
'    when ''ACCOUNT'' then account_name',
'  end,',
'  case :P1_SORT',
'    when ''AMOUNT'' then amount',
'  end,',
'  case :P1_SORT',
'    when ''UPDATED'' then updated',
'  end desc'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P1_SEARCH,P1_SHOW,P1_TERRITORY_ID,P1_ACCOUNT_ID,P1_QUARTER,P1_DISPLAY_AS,P1_SORT'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(7400884047268179746)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'No opportunities found'
,p_query_more_data=>'This query returns more than #MAX_ROW_COUNT# rows, please filter your data to ensure complete results.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8122476770798474969)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>1
,p_column_heading=>'Card title'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6585008876641530554)
,p_query_column_id=>2
,p_column_alias=>'CARD_ICON'
,p_column_display_sequence=>6
,p_column_heading=>'Card icon'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8122477208314474973)
,p_query_column_id=>3
,p_column_alias=>'CARD_INITIALS'
,p_column_display_sequence=>5
,p_column_heading=>'Card initials'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8122476965902474971)
,p_query_column_id=>4
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>3
,p_column_heading=>'Card text'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#CARD_TEXT_ACCT#<br >',
'<small>',
'#CARD_TEXT_AMT#<br />',
'#CARD_TEXT_QTR#<br />',
'#CARD_TEXT_STG#<br />',
'</small>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7457942613954814055)
,p_query_column_id=>5
,p_column_alias=>'CARD_TEXT_ACCT'
,p_column_display_sequence=>12
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7457942639066814056)
,p_query_column_id=>6
,p_column_alias=>'CARD_TEXT_QTR'
,p_column_display_sequence=>13
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7457942792064814057)
,p_query_column_id=>7
,p_column_alias=>'CARD_TEXT_STG'
,p_column_display_sequence=>14
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7457942860948814058)
,p_query_column_id=>8
,p_column_alias=>'CARD_TEXT_AMT'
,p_column_display_sequence=>15
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8122476836050474970)
,p_query_column_id=>9
,p_column_alias=>'CARD_LINK'
,p_column_display_sequence=>2
,p_column_heading=>'Card link'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8122477088023474972)
,p_query_column_id=>10
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>4
,p_column_heading=>'Card subtext'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_column_html_expression=>'Updated: #CARD_SUBTEXT#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6585009305559530558)
,p_query_column_id=>11
,p_column_alias=>'ID'
,p_column_display_sequence=>7
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6585009348195530559)
,p_query_column_id=>12
,p_column_alias=>'ACCOUNT_NAME'
,p_column_display_sequence=>8
,p_column_heading=>'Account name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6585009478193530560)
,p_query_column_id=>13
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>9
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7457942979932814059)
,p_query_column_id=>14
,p_column_alias=>'AMOUNT'
,p_column_display_sequence=>16
,p_column_heading=>'Amount'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6585009609501530561)
,p_query_column_id=>15
,p_column_alias=>'TAGS'
,p_column_display_sequence=>10
,p_column_heading=>'Tags'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6585009733439530562)
,p_query_column_id=>16
,p_column_alias=>'DEAL_SUMMARY'
,p_column_display_sequence=>11
,p_column_heading=>'Deal summary'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10249209061614155139)
,p_plug_name=>'Filters'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(7343866444940915275)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10495271188055772439)
,p_plug_name=>'Opportunities'
,p_icon_css_classes=>'fa-eye'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_plug_template=>wwv_flow_imp.id(7343861764153915263)
,p_plug_display_sequence=>60
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6592171645305718866)
,p_plug_name=>'Page Settings'
,p_parent_plug_id=>wwv_flow_imp.id(10495271188055772439)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343855668783915255)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10251143250933950474)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10249209061614155139)
,p_button_name=>'RESET_REPORT'
,p_button_static_id=>'reset_button'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886016830915316)
,p_button_image_alt=>'Reset'
,p_button_position=>'CLOSE'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8379051148895652267)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_imp.id(10495271188055772439)
,p_button_name=>'UPLOAD'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886016830915316)
,p_button_image_alt=>'Upload Data'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:210:&SESSION.::&DEBUG.:210::'
,p_icon_css_classes=>'fa-upload'
,p_security_scheme=>wwv_flow_imp.id(9042570640734542978)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10495566103827897725)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_imp.id(10495271188055772439)
,p_button_name=>'CREATE_DEAL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--padLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886609855915317)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Opportunity'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:71:&SESSION.::&DEBUG.:71,72,73,74::'
,p_security_scheme=>wwv_flow_imp.id(9042571137027542978)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6800886138330164816)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_imp.id(6592170463481718854)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886016830915316)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&SESSION.::&DEBUG.:RIR:IRNE_STATUS_CODE:\Opportunity Closed / Lost\'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6585288503145431243)
,p_name=>'P1_ACCOUNT_ID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(10249209061614155139)
,p_prompt=>'Account'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'ACCOUNTS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CUSTOMER_NAME display_value, ID return_value ',
'from eba_sales_CUSTOMERS',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(7466594599226885491)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6587770161263558794)
,p_name=>'P1_SORT'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(10249209061614155139)
,p_item_default=>'NAME'
,p_prompt=>'Sort'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Opportunity;NAME,Account;ACCOUNT,Amount;AMOUNT,Updated;UPDATED'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(7466594599226885491)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'U'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7344874194479620746)
,p_name=>'P1_DISPLAY_AS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6592171645305718866)
,p_item_default=>'CARDS'
,p_prompt=>'Display'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'PILL_DISPLAY_AS'
,p_lov=>'.'||wwv_flow_imp.id(7350672914166113674)||'.'
,p_field_template=>wwv_flow_imp.id(7343885535981915309)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:t-Form-fieldContainer--radioButtonGroup'
,p_is_persistent=>'U'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'4'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7344889958092696995)
,p_name=>'P1_SHOW'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(10249209061614155139)
,p_prompt=>'Show'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Open;OPEN,Closed;CLOSED'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(7466594599226885491)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7351564785355150505)
,p_name=>'P1_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10249209061614155139)
,p_prompt=>'Search'
,p_placeholder=>'Search Opportunities'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(7343885535981915309)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10249209266411155201)
,p_name=>'P1_TERRITORY_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(10249209061614155139)
,p_prompt=>'Account Territory'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TERRITORY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TERRITORY_NAME display_value, ID return_value ',
'from eba_sales_TERRITORIES',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(7466594599226885491)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_required_patch=>wwv_flow_imp.id(10496139698135220995)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10249210357721172901)
,p_name=>'P1_QUARTER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(10249209061614155139)
,p_prompt=>'Quarter'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select	 distinct d.qtr d, d.qtr r',
' from	 "EBA_SALES_DEALS" d',
'where d.qtr is not null',
'order by substr(d.qtr,3), substr(d.qtr,1,2)'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(7466594599226885491)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_required_patch=>-wwv_flow_imp.id(7478708532380272297)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10172025359282214775)
,p_computation_sequence=>20
,p_computation_item=>'LAST_PAGE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'1'
,p_compute_when_type=>'%null%'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7957990572224602396)
,p_name=>'Refresh on add'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10495566103827897725)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7957990722569602397)
,p_event_id=>wwv_flow_imp.id(7957990572224602396)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8122476714431474968)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8021896960779963448)
,p_event_id=>wwv_flow_imp.id(7957990572224602396)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6574212288912083493)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8021897062215963449)
,p_event_id=>wwv_flow_imp.id(7957990572224602396)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6592170463481718854)
);
wwv_flow_imp.component_end;
end;
/
