prompt --application/pages/page_00014
begin
--   Manifest
--     PAGE: 00014
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>14
,p_name=>'Revenue by Quarter'
,p_alias=>'REVENUE-BY-QUARTER'
,p_step_title=>'Revenue by Quarter'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(7375353650393743976)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'Vertical bar chart showing sales forcast by quarter for a user definable reporting period. Change the "Beginning" and "Ending" filters to vary the bar graph''s results.'
,p_page_component_map=>'04'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10220625859500284395)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10512992898526525834)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10220626264248284397)
,p_plug_name=>'Revenue by Quarter'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--hiddenOverflow'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_display_condition_type=>'NOT_DISPLAYING_INLINE_VALIDATION_ERRORS'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(6679190341602994290)
,p_region_id=>wwv_flow_imp.id(10220626264248284397)
,p_chart_type=>'bar'
,p_height=>'300'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_spark_chart=>'N'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(6679190494329994291)
,p_chart_id=>wwv_flow_imp.id(6679190341602994290)
,p_seq=>10
,p_name=>'Revenue by Quarter'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select label,',
' null series,',
' sum(deal_amount) value',
'from (',
'  select d.qtr label,',
'    case when apex_util.get_build_option_status(',
'                  p_application_id    => :APP_ID,',
'                  p_build_option_name => ''Opportunity Amount Set at Product Level''',
'              ) = ''EXCLUDE'' then',
'        d.deal_amount',
'    else',
'        nvl((select sum(nvl(dp.quote_price, 0)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id), 0)',
'    end as deal_amount,',
'    q.first_day ob',
'  from eba_sales_deals d,',
'    eba_sales_sales_periods q',
'  where d.qtr = q.period_name',
'    and d.deal_probability = 100',
'    and d.deal_close_date >= to_date(:P14_BEGIN_QTR,''YYYYMMDD'')',
'    and d.deal_close_date <= to_date(:P14_END_QTR,''YYYYMMDD'')',
'  union all',
'  select period_name label,',
'    0 deal_amount,',
'    first_day ob',
'  from eba_sales_sales_periods',
'  where first_day >= to_date(:P14_BEGIN_QTR,''YYYYMMDD'')',
'    and last_day  <= to_date(:P14_END_QTR,''YYYYMMDD'')',
')',
'group by label, ob',
'order by ob '))
,p_ajax_items_to_submit=>'P14_BEGIN_QTR,P14_END_QTR'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(6679190568663994292)
,p_chart_id=>wwv_flow_imp.id(6679190341602994290)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(6679190653216994293)
,p_chart_id=>wwv_flow_imp.id(6679190341602994290)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10220648367572346978)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10220645044023340155)
,p_name=>'P14_BEGIN_QTR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10220648367572346978)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'select first_day ',
'  from eba_sales_sales_periods',
' where sysdate between first_day and last_day',
')',
'loop',
'return c1.first_day;',
'end loop;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Beginning'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'QUARTER BEGIN'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PERIOD_NAME ||',
'       case when sysdate between first_day and last_day then '' *'' end d,',
'       to_char(first_day,''YYYYMMDD'') r ',
'  from EBA_SALES_SALES_PERIODS',
' where sysdate >= first_day',
'order by first_day'))
,p_cHeight=>1
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10220646151642342303)
,p_name=>'P14_END_QTR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10220648367572346978)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'select last_day ',
'  from eba_sales_sales_periods',
' where sysdate between first_day and last_day',
')',
'loop',
'return c1.last_day;',
'end loop;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Ending'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'QUARTER END'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PERIOD_NAME ||',
'       case when sysdate between first_day and last_day then '' *'' end d,',
'       to_char(last_day,''YYYYMMDD'') r ',
'  from EBA_SALES_SALES_PERIODS',
' where sysdate >= first_day',
' order by first_day'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(10220771764977134333)
,p_validation_name=>'End >= Begin'
,p_validation_sequence=>10
,p_validation=>'to_date(:P14_END_QTR,''YYYYMMDD'') >= to_date(:P14_BEGIN_QTR,''YYYYMMDD'')'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Ending Quarter must be greater than or equal to Beginning Quarter.'
,p_associated_item=>wwv_flow_imp.id(10220645044023340155)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6679190081109994287)
,p_name=>'P14_BEGIN_QTR or P14_END_QTR changed'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P14_BEGIN_QTR,P14_END_QTR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6679190299030994289)
,p_event_id=>wwv_flow_imp.id(6679190081109994287)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10220626264248284397)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10220767759867113864)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Initial Begin and End'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  for c1 in (',
'  select first_day',
'    from eba_sales_sales_periods',
'   where sysdate-270 between first_day and last_day',
'  )',
'  loop',
'     :P14_BEGIN_QTR := to_char(c1.first_day,''YYYYMMDD'');',
'  end loop;',
'',
'  for c2 in (',
'  select last_day',
'    from eba_sales_sales_periods',
'   where sysdate between first_day and last_day',
'  )',
'  loop',
'     :P14_END_QTR := to_char(c2.last_day,''YYYYMMDD'');',
'  end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P14_BEGIN_QTR'
,p_process_when_type=>'ITEM_IS_NULL'
,p_internal_uid=>10203045567906360461
);
wwv_flow_imp.component_end;
end;
/
