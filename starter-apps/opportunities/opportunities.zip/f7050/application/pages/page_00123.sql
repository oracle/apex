prompt --application/pages/page_00123
begin
--   Manifest
--     PAGE: 00123
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>123
,p_name=>'Territory Countries'
,p_alias=>'TERRITORY-COUNTRIES'
,p_step_title=>'Countries'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(7216874050933627053)
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(10496139698135220995)
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    To edit a country assignment, click the <strong>Edit</strong> icon (pencil) next to the country assignment. Click the <strong>Add Country</strong> button to assign a new country to the territory. Click the <strong>Reset</strong> button to reset t'
||'he interactive report. Click the <strong>Actions</strong> button to define the number of rows displayed per page, filter, format, download, and/or save the interactive report.',
'</p>'))
,p_page_component_map=>'18'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20231002163752'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9048740242929942254)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343869008886915277)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10495270706565772431)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(7343886820987915318)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9048740660976942255)
,p_plug_name=>'Countries'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343865001510915269)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select m.id,',
'  m.country_id, ',
'  c.country_name,',
'  c.country_code,',
'  m.created date_added, ',
'  lower(m.created_by) added_by,',
'  null remove_button',
'from eba_sales_countries c',
'join eba_sales_terr_map m',
'  on c.id = m.country_id',
'where m.territory_id = :P123_TERRITORY_ID'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(9048740759153942255)
,p_name=>'Territory Countries'
,p_max_row_count=>'100000'
,p_max_row_count_message=>'This query returns more than #MAX_ROW_COUNT# rows, please filter your data to ensure complete results.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'Y'
,p_owner=>'CBCHO'
,p_internal_uid=>2538376324543414848
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9048740958239942261)
,p_db_column_name=>'COUNTRY_NAME'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Country'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9048741056362942263)
,p_db_column_name=>'DATE_ADDED'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Added'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9048741166627942263)
,p_db_column_name=>'ADDED_BY'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Added By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9048744366185000464)
,p_db_column_name=>'COUNTRY_ID'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Country Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6407136184708009657)
,p_db_column_name=>'REMOVE_BUTTON'
,p_display_order=>25
,p_column_identifier=>'H'
,p_column_label=>'Remove'
,p_column_link=>'javascript:void(0);'
,p_column_linktext=>'<span class="t-Icon fa fa-trash-o"></span>'
,p_column_link_attr=>'class="t-Button t-Button--small t-Button--noUI t-Button--danger js-removeTerritoryCountry" data-territory-country-id="#ID#"'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6407136095528009656)
,p_db_column_name=>'ID'
,p_display_order=>35
,p_column_identifier=>'G'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6400532954195872479)
,p_db_column_name=>'COUNTRY_CODE'
,p_display_order=>45
,p_column_identifier=>'I'
,p_column_label=>'Code'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(9048743056095969081)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'25383787'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'COUNTRY_NAME:COUNTRY_CODE:DATE_ADDED:ADDED_BY:REMOVE_BUTTON:'
,p_sort_column_1=>'DATE_ADDED'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9048741967261953409)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9048740242929942254)
,p_button_name=>'ADD_COUNTRY'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7343886609855915317)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Country'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:124:&SESSION.::&DEBUG.:124:P124_TERRITORY_ID:&P123_TERRITORY_ID.'
,p_security_scheme=>wwv_flow_imp.id(9042571137027542978)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9048741751331948852)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9048740660976942255)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886016830915316)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:123:&SESSION.::&DEBUG.:RP,RIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9048742352154958510)
,p_name=>'P123_TERRITORY_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(9048740660976942255)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9048742748476966934)
,p_name=>'P123_TERRITORY_COUNTRY_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9048740660976942255)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6407135544964009651)
,p_name=>'Add Country'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(9048741967261953409)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6407135647676009652)
,p_event_id=>wwv_flow_imp.id(6407135544964009651)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9048740660976942255)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6407137643253009672)
,p_event_id=>wwv_flow_imp.id(6407135544964009651)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''Country Added'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6407163045453185254)
,p_name=>'Remove territory country button clicked'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.js-removeTerritoryCountry'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6407164837471185387)
,p_event_id=>wwv_flow_imp.id(6407163045453185254)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Are you sure you want to remove this country from the territory?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6407163461556185383)
,p_event_id=>wwv_flow_imp.id(6407163045453185254)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var id = $(this.triggeringElement).data(''territory-country-id'');',
'',
'$s(''P123_TERRITORY_COUNTRY_ID'', id);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6407163870067185384)
,p_event_id=>wwv_flow_imp.id(6407163045453185254)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from eba_sales_terr_map',
'where id = :P123_TERRITORY_COUNTRY_ID;'))
,p_attribute_02=>'P123_TERRITORY_COUNTRY_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6407164396986185387)
,p_event_id=>wwv_flow_imp.id(6407163045453185254)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9048740660976942255)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6407165375315185388)
,p_event_id=>wwv_flow_imp.id(6407163045453185254)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''Country Removed'');'
);
wwv_flow_imp.component_end;
end;
/
