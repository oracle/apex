prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-13'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>0
,p_user_interface_id=>wwv_flow_api.id(6988712858842356549)
,p_name=>'0'
,p_alias=>'0'
,p_step_title=>'0'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_nav_list_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20210301101414'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(9607804126252773209)
,p_name=>'Comments'
,p_template=>wwv_flow_api.id(7343866444940915275)
,p_display_sequence=>1200
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'js-dynamicHideShowRegion js-commentsRegion'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Comments--chat'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select '''' comment_modifiers, ',
'  ''u-color-'' || ora_hash(created_by, 29) || '' u-color-'' || ora_hash(created_by, 29) || ''-bd'' icon_modifier,',
'  replace(apex_escape.html(dbms_lob.substr(note,2000,1)), chr(10), ''<br />'') comment_text,',
'  '''' attribute_1,',
'  '''' attribute_2,',
'  '''' attribute_3,',
'  '''' attribute_4,',
'  lower(created_by) user_name,',
'  upper(',
'    case',
'      when instr(replace(created_by,''.'','' ''),'' '') = 0',
'      then substr(created_by,1,2)',
'      else substr(created_by,1,1)||substr(created_by,instr(replace(created_by,''.'','' ''),'' '')+1,1)',
'    end',
'  ) user_icon,',
'  case',
'    when eba_sales_acl_api.get_authorization_level(:APP_USER) = 3',
'    then ''<a href="'' || apex_page.get_url(p_page => 22, p_items => ''P22_ID'', p_values => id) || ',
'      ''" class="t-Button t-Button--small t-Button--simple">Edit</a>''',
'  end actions,',
'  id update_id,',
'  case',
'    when to_char(created, ''YYYMMDDHH24MISS'') = to_char(updated, ''YYYMMDDHH24MISS'')',
'    then apex_util.get_since(created) ',
'    else apex_util.get_since(created) || '' (Updated '' || apex_util.get_since(updated) || '')'' ',
'  end comment_date',
'from eba_sales_comments ',
'where (',
'  (:APP_PAGE_ID = ''80'' and deal_id = :P80_ID)',
'    or (:APP_PAGE_ID = ''93'' and territory_id = :P93_ID)',
'    or (:APP_PAGE_ID = ''133'' and lead_id = :P133_ID)',
'    or (:APP_PAGE_ID = ''94'' and account_id = :P94_ID)',
'    or (:APP_PAGE_ID = ''24'' and contact_id = :P24_ID)',
'    or (:APP_PAGE_ID = ''61'' and product_id = :P61_ID)',
')',
'order by created desc'))
,p_display_when_condition=>'80,94,133,93,24,61'
,p_display_condition_type=>'CURRENT_PAGE_IN_CONDITION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(7343872900632915285)
,p_query_headings_type=>'QUERY_COLUMNS'
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No updates or status logged, click "+" icon to add a note'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6637172164821804009)
,p_query_column_id=>1
,p_column_alias=>'COMMENT_MODIFIERS'
,p_column_display_sequence=>5
,p_column_heading=>'Comment Modifiers'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6637175345530804014)
,p_query_column_id=>2
,p_column_alias=>'ICON_MODIFIER'
,p_column_display_sequence=>9
,p_column_heading=>'Icon Modifier'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6637172616890804011)
,p_query_column_id=>3
,p_column_alias=>'COMMENT_TEXT'
,p_column_display_sequence=>6
,p_column_heading=>'Comment Text'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6637172959494804012)
,p_query_column_id=>4
,p_column_alias=>'ATTRIBUTE_1'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6637173425787804012)
,p_query_column_id=>5
,p_column_alias=>'ATTRIBUTE_2'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6637173786792804013)
,p_query_column_id=>6
,p_column_alias=>'ATTRIBUTE_3'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6637174149398804013)
,p_query_column_id=>7
,p_column_alias=>'ATTRIBUTE_4'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6637174536786804013)
,p_query_column_id=>8
,p_column_alias=>'USER_NAME'
,p_column_display_sequence=>7
,p_column_heading=>'User Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6637175799051804015)
,p_query_column_id=>9
,p_column_alias=>'USER_ICON'
,p_column_display_sequence=>10
,p_column_heading=>'User Icon'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6637176221346804015)
,p_query_column_id=>10
,p_column_alias=>'ACTIONS'
,p_column_display_sequence=>11
,p_column_heading=>'Actions'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6637176560240804015)
,p_query_column_id=>11
,p_column_alias=>'UPDATE_ID'
,p_column_display_sequence=>12
,p_column_heading=>'Update Id'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6637174948840804014)
,p_query_column_id=>12
,p_column_alias=>'COMMENT_DATE'
,p_column_display_sequence=>8
,p_column_heading=>'Comment Date'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(10373553642022828503)
,p_name=>'Attachments'
,p_template=>wwv_flow_api.id(7343866444940915275)
,p_display_sequence=>1100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'js-dynamicHideShowRegion js-attachmentsRegion'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--noBorders'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'  filename,',
'  apex_util.get_blob_file_src(''P99_FILE_BLOB'', id) edit_url,',
'  file_mimetype,',
'  file_charset,',
'  apex_util.filesize_mask(dbms_lob.getlength(file_blob)) f_len,',
'  file_comments,',
'  case ',
'    when instr(upper(filename),''.PPT'') > 0 ',
'      or instr(upper(filename),''.PPTX'') > 0 ',
'    then ''fa fa-file-powerpoint-o''',
'    when instr(upper(filename),''.XLS'') > 0 ',
'      or instr(upper(filename),''.XLSX'') > 0 ',
'    then ''fa fa-file-excel-o''',
'    when instr(upper(filename),''.DOC'') > 0 ',
'      or instr(upper(filename),''.DOCX'') > 0 ',
'    then ''fa fa-file-word-o''',
'    when instr(upper(filename),''.PDF'') > 0 ',
'    then ''fa fa-file-pdf-o''',
'    when instr(upper(filename),''.GIF'') > 0 ',
'      or instr(upper(filename),''.PNG'') > 0 ',
'      or instr(upper(filename),''.TIFF'') > 0 ',
'      or instr(upper(filename),''.JPG'') > 0 ',
'    then ''fa fa-file-image-o''',
'    else ''fa fa-file-o''',
'  end file_type,',
'  case ',
'    when instr(upper(filename),''.PPT'') > 0',
'      or instr(upper(filename),''.PPTX'') > 0 ',
'    then ''MS Powerpoint File''',
'    when instr(upper(filename),''.XLS'') > 0 ',
'      or instr(upper(filename),''.XLSX'') > 0 ',
'    then ''MS Excel File''',
'    when instr(upper(filename),''.DOC'') > 0 ',
'      or instr(upper(filename),''.DOCX'') > 0 ',
'    then ''MS Word File''',
'    when instr(upper(filename),''.PDF'') > 0 ',
'    then ''Adobe PDF File''',
'    when instr(upper(filename),''.GIF'') > 0 ',
'      or instr(upper(filename),''.PNG'') > 0 ',
'      or instr(upper(filename),''.TIFF'') > 0 ',
'      or instr(upper(filename),''.JPG'') > 0 ',
'    then ''Image File''',
'    else ''Text File''',
'  end file_type_title,',
'  created,',
'  lower(created_by) created_by,',
'  null edit',
'from eba_sales_files f',
'where (',
'  (:APP_PAGE_ID = ''80'' and deal_id = :P80_ID)',
'    or (:APP_PAGE_ID = ''93'' and territory_id = :P93_ID)',
'    or (:APP_PAGE_ID = ''133'' and lead_id = :P133_ID)',
'    or (:APP_PAGE_ID = ''94'' and account_id = :P94_ID)',
'    or (:APP_PAGE_ID = ''24'' and contact_id = :P24_ID)',
'    or (:APP_PAGE_ID = ''61'' and product_id = :P61_ID)',
')'))
,p_display_when_condition=>'80,94,133,93,24,61'
,p_display_condition_type=>'CURRENT_PAGE_IN_CONDITION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(7343873253436915289)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'No attachments identified, click "+" icon to add a file attachment'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
,p_comment=>'Used with marquee page attachments'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636944688376387282)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636945116660387283)
,p_query_column_id=>2
,p_column_alias=>'FILENAME'
,p_column_display_sequence=>5
,p_column_heading=>'Attachment'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<a class="u-bold" href="#EDIT_URL#">#FILENAME#</a><br />#FILE_COMMENTS#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636943852417387281)
,p_query_column_id=>3
,p_column_alias=>'EDIT_URL'
,p_column_display_sequence=>12
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636945470868387283)
,p_query_column_id=>4
,p_column_alias=>'FILE_MIMETYPE'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636945862188387284)
,p_query_column_id=>5
,p_column_alias=>'FILE_CHARSET'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636946313747387285)
,p_query_column_id=>6
,p_column_alias=>'F_LEN'
,p_column_display_sequence=>8
,p_column_heading=>'Size'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636946691140387286)
,p_query_column_id=>7
,p_column_alias=>'FILE_COMMENTS'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636947104785387286)
,p_query_column_id=>8
,p_column_alias=>'FILE_TYPE'
,p_column_display_sequence=>4
,p_column_heading=>'<span class="u-VisuallyHidden">Type</span>'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span class="u-file-icon #FILE_TYPE#" title="#FILE_TYPE_TITLE#"></span>'
,p_column_alignment=>'CENTER'
,p_report_column_width=>24
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636947496417387286)
,p_query_column_id=>9
,p_column_alias=>'FILE_TYPE_TITLE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636947911778387287)
,p_query_column_id=>10
,p_column_alias=>'CREATED'
,p_column_display_sequence=>9
,p_column_heading=>'Added'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_column_html_expression=>'<span class="u-nowrap">#CREATED# by #CREATED_BY#</span>'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_default_sort_dir=>'desc'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636948274385387287)
,p_query_column_id=>11
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>11
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636944304008387282)
,p_query_column_id=>12
,p_column_alias=>'EDIT'
,p_column_display_sequence=>1
,p_column_heading=>'<span class="u-VisuallyHidden">Edit</span>'
,p_column_link=>'f?p=&APP_ID.:99:&SESSION.::&DEBUG.:RP:P99_ID:#ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_column_alignment=>'CENTER'
,p_report_column_width=>24
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(12639994297061764443)
,p_name=>'Links'
,p_template=>wwv_flow_api.id(7343866444940915275)
,p_display_sequence=>1000
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'js-dynamicHideShowRegion js-linksRegion'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--horizontalBorders'
,p_region_attributes=>'style="display:none"'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id, ',
'  link_text, ',
'  link_target, ',
'  lower(created_by) created_by, ',
'  created, ',
'  link_comments,',
'  null edit',
'from eba_sales_links ',
'where (',
'  (:APP_PAGE_ID = ''80'' and deal_id = :P80_ID)',
'    or (:APP_PAGE_ID = ''93'' and territory_id = :P93_ID)',
'    or (:APP_PAGE_ID = ''133'' and lead_id = :P133_ID)',
'    or (:APP_PAGE_ID = ''94'' and account_id = :P94_ID)',
'    or (:APP_PAGE_ID = ''24'' and contact_id = :P24_ID)',
'    or (:APP_PAGE_ID = ''61'' and product_id = :P61_ID)',
')'))
,p_display_when_condition=>'80,94,133,93,24,61'
,p_display_condition_type=>'CURRENT_PAGE_IN_CONDITION'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(7343873253436915289)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'No links provided, click "+" icon to add a URL link'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636992509392698335)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636992920065698335)
,p_query_column_id=>2
,p_column_alias=>'LINK_TEXT'
,p_column_display_sequence=>3
,p_column_heading=>'Link'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<a href="#LINK_TARGET#" target="_blank" class="u-bold">#LINK_TEXT#</a><br />#LINK_COMMENTS#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636993275826698335)
,p_query_column_id=>3
,p_column_alias=>'LINK_TARGET'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636993654975698336)
,p_query_column_id=>4
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636991258776698334)
,p_query_column_id=>5
,p_column_alias=>'CREATED'
,p_column_display_sequence=>6
,p_column_heading=>'Added'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_column_html_expression=>'<span class="u-nowrap">#CREATED# by #CREATED_BY#</span>'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_default_sort_dir=>'desc'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636991728032698334)
,p_query_column_id=>6
,p_column_alias=>'LINK_COMMENTS'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(6636992047956698334)
,p_query_column_id=>7
,p_column_alias=>'EDIT'
,p_column_display_sequence=>1
,p_column_heading=>'<span class="u-VisuallyHidden">Edit</span>'
,p_column_link=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:RP,114:P114_ID:#ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_heading_alignment=>'LEFT'
,p_report_column_width=>24
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6636667264297366811)
,p_name=>'Marquee Pages - Handle No Data Found Regions'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
,p_display_when_type=>'CURRENT_PAGE_IN_CONDITION'
,p_display_when_cond=>'80,94,133,93,24,61'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6636667651153366813)
,p_event_id=>wwv_flow_api.id(6636667264297366811)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(function() {',
'    ',
'function toggleRegion() {',
'  var $region = $(this),',
'      noDataFound = $region.find(''.nodatafound'').length === 1;',
'',
'    //triggering after hide/show because that what the RDS response to',
'    if (noDataFound) {',
'      $region.hide();',
'      $region.trigger(''apexafterhide'');',
'    } else {',
'      $region.show();',
'      $region.trigger(''apexaftershow'');',
'    }',
'}',
'',
'function initHideShowRegions() {',
'  var $regions = $(''.js-dynamicHideShowRegion'');',
'      $rds = $(''.apex-rds'');',
'',
'  $regions',
'    .each(toggleRegion)',
'    .on(''apexafterrefresh'', toggleRegion);',
'',
'  //using visiblity over display to avoid DOM movement issues',
'  $rds.css(''visibility'', ''visible'');',
'} ',
'',
'//using load because document.ready here goes before the RDS has added its listeners',
'$(window).on(''theme42ready'', initHideShowRegions);',
' ',
'}())'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6636182711739949193)
,p_name=>'Marquee Pages - Links dialog closed'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.view-links-dialog'
,p_bind_type=>'live'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'dialogclose'
,p_display_when_type=>'CURRENT_PAGE_IN_CONDITION'
,p_display_when_cond=>'80,94,133,93,24,61'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6636182790821949194)
,p_event_id=>wwv_flow_api.id(6636182711739949193)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''.js-linksRegion'').trigger(''apexrefresh'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6636734832237534129)
,p_name=>'Marquee Pages - Attachments dialog closed'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.view-attachments-dialog'
,p_bind_type=>'live'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'dialogclose'
,p_display_when_type=>'CURRENT_PAGE_IN_CONDITION'
,p_display_when_cond=>'80,94,133,93,24,61'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6636735161285534133)
,p_event_id=>wwv_flow_api.id(6636734832237534129)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''.js-attachmentsRegion'').trigger(''apexrefresh'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6637008887276819667)
,p_name=>'Marquee Pages - Comments dialog closed'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.view-comments-dialog'
,p_bind_type=>'live'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'dialogclose'
,p_display_when_type=>'CURRENT_PAGE_IN_CONDITION'
,p_display_when_cond=>'80,94,133,93,24,61'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6637009010255819668)
,p_event_id=>wwv_flow_api.id(6637008887276819667)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''.js-commentsRegion'').trigger(''apexrefresh'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6636182518406949191)
,p_name=>'Marquee Pages - Link Details dialog closed'
,p_event_sequence=>50
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 114'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
,p_display_when_type=>'CURRENT_PAGE_IN_CONDITION'
,p_display_when_cond=>'80,94,133,93,24,61'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6636182571978949192)
,p_event_id=>wwv_flow_api.id(6636182518406949191)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.js-linksRegion'').trigger(''apexrefresh'');',
'',
'if (this.data.REQUEST === ''CREATE'') {',
'  apex.message.showPageSuccess(''Link Added.'');',
'} if (this.data.REQUEST === ''SAVE'') {',
'  apex.message.showPageSuccess(''Link Updated.'');',
'} if (this.data.REQUEST === ''DELETE'') {',
'  apex.message.showPageSuccess(''Link Deleted.'');',
'}'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6636739529132570444)
,p_name=>'Marquee Pages - Attachment Details dialog closed'
,p_event_sequence=>60
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 99'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
,p_display_when_type=>'CURRENT_PAGE_IN_CONDITION'
,p_display_when_cond=>'80,94,133,93,24,61'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6636739892399570445)
,p_event_id=>wwv_flow_api.id(6636739529132570444)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.js-attachmentsRegion'').trigger(''apexrefresh'');',
'',
'if (this.data.REQUEST === ''CREATE'') {',
'  apex.message.showPageSuccess(''Attachment Added.'');',
'} if (this.data.REQUEST === ''SAVE'') {',
'  apex.message.showPageSuccess(''Attachment Updated.'');',
'} if (this.data.REQUEST === ''DELETE'') {',
'  apex.message.showPageSuccess(''Attachment Deleted.'');',
'}'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6637008637856819665)
,p_name=>'Marquee Pages - Comment Details dialog closed'
,p_event_sequence=>70
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 22'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
,p_display_when_type=>'CURRENT_PAGE_IN_CONDITION'
,p_display_when_cond=>'80,94,133,93,24,61'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6637008808434819666)
,p_event_id=>wwv_flow_api.id(6637008637856819665)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.js-commentsRegion'').trigger(''apexrefresh'');',
'',
'if (this.data.REQUEST === ''CREATE'') {',
'  apex.message.showPageSuccess(''Comment Added.'');',
'} if (this.data.REQUEST === ''SAVE'') {',
'  apex.message.showPageSuccess(''Comment Updated.'');',
'} if (this.data.REQUEST === ''DELETE'') {',
'  apex.message.showPageSuccess(''Comment Deleted.'');',
'}'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(6651033792838039763)
,p_name=>'Marquee Pages - Validate dialog closed'
,p_event_sequence=>80
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 146'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
,p_display_when_type=>'CURRENT_PAGE_IN_CONDITION'
,p_display_when_cond=>'80,94,133,93,24,61'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(6651034142882039771)
,p_event_id=>wwv_flow_api.id(6651033792838039763)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''.js-validateRegion'').trigger(''apexrefresh'');'
);
wwv_flow_api.component_end;
end;
/
