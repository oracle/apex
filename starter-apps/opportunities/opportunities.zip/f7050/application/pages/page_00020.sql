prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>20
,p_name=>'Past Due Opportunities'
,p_alias=>'PAST-DUE-OPPORTUNITIES'
,p_step_title=>'Past Due Opportunities'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(7357631458432990573)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'This page identifies opportunities that are past due, or about to become past due. Change the "Closing Timeframe" filter value to vary the report''s results. Click the <strong>Reset</strong> button to reset the interactive report. Click the <strong>Ac'
||'tions</strong> button to define the number of rows displayed per page, filter, format, download, and/or save the interactive report.'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9003920959199799125)
,p_plug_name=>'Filters'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343855668783915255)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_translate_title=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10235705057099971668)
,p_plug_name=>'Past Due Opportunities'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343865001510915269)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_3'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select deal_id as id, ',
'  customer_name,',
'  customer_stock_symb,',
'  customer_id account_id,',
'  rep_first_name || '' '' || rep_last_name as rep,',
'  rep_email,',
'  deal_name,',
'  deal_close_date,',
'  deal_amount,',
'  deal_probability,',
'  status_code ',
'from eba_sales_opp_v v',
'where deal_close_date < trunc(sysdate) + :P20_CLOSING_TIMEFRAME ',
'  and nvl(deal_probability, 0) < 100'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P20_CLOSING_TIMEFRAME'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(10235705153784971668)
,p_name=>'Past Due Opportunities'
,p_max_row_count=>'10000'
,p_max_row_count_message=>'This query returns more than #MAX_ROW_COUNT# rows, please filter your data to ensure complete results.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:PDF'
,p_download_filename=>'past_due.csv'
,p_enable_mail_download=>'Y'
,p_owner=>'MIKE'
,p_internal_uid=>3725340719174444261
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10235705747899971681)
,p_db_column_name=>'REP'
,p_display_order=>1
,p_column_identifier=>'E'
,p_column_label=>'Rep'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10235705371440971674)
,p_db_column_name=>'CUSTOMER_NAME'
,p_display_order=>2
,p_column_identifier=>'A'
,p_column_label=>'Account'
,p_column_link=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP,94:P94_ID:#ACCOUNT_ID#'
,p_column_linktext=>'#CUSTOMER_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10235705676472971681)
,p_db_column_name=>'CUSTOMER_STOCK_SYMB'
,p_display_order=>5
,p_column_identifier=>'D'
,p_column_label=>'Stock'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10235705857297971682)
,p_db_column_name=>'REP_EMAIL'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10235705969271971682)
,p_db_column_name=>'DEAL_NAME'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Opportunity'
,p_column_link=>'f?p=&APP_ID.:80:&SESSION.::&DEBUG.:RP,80:P80_ID:#ID#'
,p_column_linktext=>'#DEAL_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10235706169700971683)
,p_db_column_name=>'DEAL_AMOUNT'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'&AMT_HDR.'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10235706363386971683)
,p_db_column_name=>'STATUS_CODE'
,p_display_order=>10
,p_column_identifier=>'K'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10235706270094971683)
,p_db_column_name=>'DEAL_PROBABILITY'
,p_display_order=>11
,p_column_identifier=>'J'
,p_column_label=>'Probability'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9014767243531975459)
,p_db_column_name=>'DEAL_CLOSE_DATE'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Close Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6591780790802931856)
,p_db_column_name=>'ID'
,p_display_order=>22
,p_column_identifier=>'M'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6591780911959931857)
,p_db_column_name=>'ACCOUNT_ID'
,p_display_order=>32
,p_column_identifier=>'N'
,p_column_label=>'Account id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(10235707276196973311)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8977878'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'DEAL_NAME:CUSTOMER_NAME:REP:REP_EMAIL:DEAL_AMOUNT:STATUS_CODE:DEAL_PROBABILITY:DEAL_CLOSE_DATE::ID:ACCOUNT_ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10495867081717433784)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343869008886915277)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10495270706565772431)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(7343886820987915318)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8320386073941963851)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10235705057099971668)
,p_button_name=>'RESET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886016830915316)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&SESSION.::&DEBUG.:RP,&APP_PAGE_ID.,RIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9003951955867807682)
,p_name=>'P20_CLOSING_TIMEFRAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(9003920959199799125)
,p_item_default=>'7'
,p_prompt=>'Closing Timeframe'
,p_source=>'7'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Within 7 days;7,Within 30 days ;30,Within 90 days;90,Within 180 days;180,Past Due;0'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(7343885725551915311)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10172064768435378204)
,p_computation_sequence=>10
,p_computation_item=>'LAST_PAGE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'20'
,p_compute_when_type=>'%null%'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6591781001385931858)
,p_name=>'P20_CLOSING_TIMEFRAME changed'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P20_CLOSING_TIMEFRAME'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6591781045798931859)
,p_event_id=>wwv_flow_imp.id(6591781001385931858)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10235705057099971668)
);
wwv_flow_imp.component_end;
end;
/
