prompt --application/pages/page_00031
begin
--   Manifest
--     PAGE: 00031
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>31
,p_name=>'Opportunities by &REP_TITLE.'
,p_alias=>'OPPORTUNITIES-BY-REP-TITLE'
,p_step_title=>'Opportunities by &REP_TITLE_RAW.'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(7357631458432990573)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'This is an interactive report of all opportunities listed by &REP_TITLE.. Click the <strong>Reset</strong> button to reset the interactive report. Click the <strong>Actions</strong> button to define the number of rows displayed per page, filter, form'
||'at, download, and/or save the interactive report.'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10234372552471386125)
,p_plug_name=>'Opportunities by Rep'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343865001510915269)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select	 ',
'	 "EBA_SALES_OPP_V"."REP_FIRST_NAME" ||'' ''||',
'	 "EBA_SALES_OPP_V"."REP_LAST_NAME" as "REP",',
'	 "EBA_SALES_OPP_V"."REP_EMAIL" as "REP_EMAIL",',
'         count(*) deal_count,',
'	 sum("EBA_SALES_OPP_V"."DEAL_AMOUNT") total_amount,',
'         sum("EBA_SALES_OPP_V"."DEAL_PROBABILITY"*.01',
'            *"EBA_SALES_OPP_V"."DEAL_AMOUNT") weighted,',
'         min("EBA_SALES_OPP_V"."DEAL_PROBABILITY") minimum_probability,',
'         max("EBA_SALES_OPP_V"."DEAL_PROBABILITY") maximum_probability',
' from	 "EBA_SALES_OPP_V" "EBA_SALES_OPP_V"',
'--where DEAL_PROBABILITY > 0 and deal_probability < 100',
'group by "EBA_SALES_OPP_V"."REP_FIRST_NAME" ||'' ''||',
'	 "EBA_SALES_OPP_V"."REP_LAST_NAME","EBA_SALES_OPP_V"."REP_EMAIL"'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(10234372658371386125)
,p_name=>'Opportunities by Rep'
,p_max_row_count=>'10000'
,p_max_row_count_message=>'This query returns more than #MAX_ROW_COUNT# rows, please filter your data to ensure complete results.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:PDF'
,p_download_filename=>'opportunities_by_rep.csv'
,p_enable_mail_download=>'Y'
,p_owner=>'MIKE'
,p_internal_uid=>3724008223760858718
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10234372868743386135)
,p_db_column_name=>'REP'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'&REP_TITLE.'
,p_column_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:RP,1,RIR,CIR:IREQ_SALES_REP_NAME,P1_DISPLAY_AS:#REP#,GRID'
,p_column_linktext=>'#REP#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10234372967377386142)
,p_db_column_name=>'REP_EMAIL'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10234373072485386142)
,p_db_column_name=>'DEAL_COUNT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Opportunity Count'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10234373156907386142)
,p_db_column_name=>'TOTAL_AMOUNT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Total &AMT_HDR.'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999G999G999'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10234373247878386143)
,p_db_column_name=>'WEIGHTED'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Weighted &AMT_HDR.'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999G999G999'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7357623745550759832)
,p_db_column_name=>'MINIMUM_PROBABILITY'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Minimum Probability'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7357623859558759832)
,p_db_column_name=>'MAXIMUM_PROBABILITY'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Maximum Probability'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(10234373973133388956)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8964545'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'REP:REP_EMAIL:DEAL_COUNT:TOTAL_AMOUNT:WEIGHTED:MINIMUM_PROBABILITY:MAXIMUM_PROBABILITY'
,p_sort_column_1=>'WEIGHTED'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'REP'
,p_sort_direction_2=>'ASC'
,p_sum_columns_on_break=>'TOTAL_AMOUNT:WEIGHTED:DEAL_COUNT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10497464312664780854)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343869008886915277)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10495270706565772431)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(7343886820987915318)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10251153566236134715)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10234372552471386125)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886016830915316)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:31,RIR,CIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp.component_end;
end;
/
