prompt --application/pages/page_00049
begin
--   Manifest
--     PAGE: 00049
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>49
,p_name=>'Competitor Analysis'
,p_alias=>'COMPETITOR-ANALYSIS'
,p_step_title=>'Competitor Analysis'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(7418975233025255820)
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(7418762851483053418)
,p_protection_level=>'C'
,p_help_text=>'<p>View opportunity counts organized by Competitor, Quarter, and Status. Click the <strong>Reset</strong> button to reset the interactive report. Click the <strong>Actions</strong> button to define the number of rows displayed per page, filter, forma'
||'t, download, and/or save the interactive report.</p>'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10265130559744089986)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(10512992898526525834)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10268887167629126206)
,p_plug_name=>'Competitor Analysis'
,p_static_id=>'competitor-analysis'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2102002977963900996
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select	 decode(DEAL_PROBABILITY,0,''Lost'',100,''Won'',''Open'') status,',
'         c.COMPETITOR_NAME,',
'         o.qtr quarter,',
'         count(*) opportunity_count,',
'         count(distinct o.customer_id) accounts,',
'         case when apex_util.get_build_option_status(',
'                       p_application_id    => :APP_ID,',
'                       p_build_option_name => ''Opportunity Amount Set at Product Level''',
'                   ) = ''EXCLUDE'' then',
'             sum(o.deal_amount)',
'         else',
'             sum(nvl((select sum(nvl(dp.quote_price, 0.00)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = o.id), 0))',
'         end as total_amount,',
'         case when apex_util.get_build_option_status(',
'                       p_application_id    => :APP_ID,',
'                       p_build_option_name => ''Opportunity Amount Set at Product Level''',
'                   ) = ''EXCLUDE'' then',
'             sum(o.deal_probability * .01 * o.deal_amount)',
'         else',
'             sum(o.deal_probability * .01 * nvl((select sum(nvl(dp.quote_price, 0.00)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = o.id), 0))',
'         end as weighted,',
'         min(o."DEAL_PROBABILITY") minimum_probability,',
'         max(o."DEAL_PROBABILITY") maximum_probability',
'from	 ',
'   EBA_SALES_OPPORTUNITIES_V o,',
'   EBA_SALES_DEAL_COMPETITION dc,',
'   EBA_SALES_COMPETITORS c',
'where ',
'   dc.deal_id = o.ID and',
'   dc.competitor_id = c.id',
'group by decode(DEAL_PROBABILITY,0,''Lost'',100,''Won'',''Open''),',
'         c.COMPETITOR_NAME,',
'         o.qtr'))
,p_plug_source_type=>'NATIVE_IR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(10268887253663126206)
,p_max_row_count=>'10000'
,p_max_row_count_message=>'This query returns more than #MAX_ROW_COUNT# rows, please filter your data to ensure complete results.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'Y'
,p_internal_uid=>3740800627091845396
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10268888249614141088)
,p_db_column_name=>'ACCOUNTS'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Accounts'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10268887463028126209)
,p_db_column_name=>'COMPETITOR_NAME'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Competitor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7378251638384699712)
,p_db_column_name=>'MAXIMUM_PROBABILITY'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Maximum Probability'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7378251547389699712)
,p_db_column_name=>'MINIMUM_PROBABILITY'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Minimum Probability'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7378251258200699712)
,p_db_column_name=>'OPPORTUNITY_COUNT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Opportunity Count'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7378251158507699711)
,p_db_column_name=>'QUARTER'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Quarter'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7378250952150699711)
,p_db_column_name=>'STATUS'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7378251346783699712)
,p_db_column_name=>'TOTAL_AMOUNT'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Total &AMT_HDR.'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999G999'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7378251440959699712)
,p_db_column_name=>'WEIGHTED'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Weighted &AMT_HDR.'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999G999'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(10268887767706127315)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'9132461'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100
,p_report_columns=>'COMPETITOR_NAME:QUARTER:STATUS:ACCOUNTS:OPPORTUNITY_COUNT:TOTAL_AMOUNT:WEIGHTED'
,p_sort_column_1=>'TOTAL_AMOUNT'
,p_sort_direction_1=>'DESC'
,p_sum_columns_on_break=>'TOTAL_AMOUNT:WEIGHTED'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7378251739555703540)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10268887167629126206)
,p_button_name=>'RESET_REPORT'
,p_static_id=>'reset-report'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:49:&SESSION.::&DEBUG.:RP,49,RIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp.component_end;
end;
/
