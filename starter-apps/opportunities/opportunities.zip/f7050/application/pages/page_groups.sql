prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7050
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7338841254361942699)
,p_group_name=>'ACL'
,p_group_desc=>'Access Control List'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7375347733227549755)
,p_group_name=>'Accounts'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(9061991741235658343)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7418975233025255820)
,p_group_name=>'Competition'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7375363439591911216)
,p_group_name=>'Contacts'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7418978053980299781)
,p_group_name=>'Help'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7418988128250509952)
,p_group_name=>'Home'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7234594055923374781)
,p_group_name=>'Leads'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7234593954191374263)
,p_group_name=>'Opportunities'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7418981228878330390)
,p_group_name=>'Products'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7375353650393743976)
,p_group_name=>'Reports'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7234596242894380456)
,p_group_name=>'Territories'
);
wwv_flow_imp.component_end;
end;
/
