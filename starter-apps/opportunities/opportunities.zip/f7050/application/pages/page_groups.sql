prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7050
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7321119062401189296)
,p_group_name=>'ACL'
,p_group_desc=>'Access Control List'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7357625541266796352)
,p_group_name=>'Accounts'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(9044269549274904940)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7401253041064502417)
,p_group_name=>'Competition'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7357641247631157813)
,p_group_name=>'Contacts'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7401255862019546378)
,p_group_name=>'Help'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7401265936289756549)
,p_group_name=>'Home'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7216871863962621378)
,p_group_name=>'Leads'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7216871762230620860)
,p_group_name=>'Opportunities'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7401259036917576987)
,p_group_name=>'Products'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7357631458432990573)
,p_group_name=>'Reports'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(7216874050933627053)
,p_group_name=>'Territories'
);
wwv_flow_imp.component_end;
end;
/
