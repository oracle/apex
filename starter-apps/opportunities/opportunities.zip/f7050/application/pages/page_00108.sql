prompt --application/pages/page_00108
begin
--   Manifest
--     PAGE: 00108
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>108
,p_name=>'Product Details'
,p_alias=>'PRODUCT-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Product Details'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(7216871762230620860)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(9042571137027542978)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'02'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20230511225325'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6542457506678038172)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343855860694915257)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8904504835975722376)
,p_plug_name=>'Product Details'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343855668783915255)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8904505148265722377)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(6542457506678038172)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886609855915317)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CREATE'
,p_button_condition=>'P108_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8904505051021722377)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(6542457506678038172)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886609855915317)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Product'
,p_button_position=>'CREATE'
,p_button_condition=>'P108_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8904505450286722377)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6542457506678038172)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7343886609855915317)
,p_button_image_alt=>'Cancel'
,p_button_position=>'EDIT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8904505257019722377)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(6542457506678038172)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--danger'
,p_button_template_id=>wwv_flow_imp.id(7343886609855915317)
,p_button_image_alt=>'Delete'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P108_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6708419630151880786)
,p_name=>'P108_CLOSE_DATE'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(8904504835975722376)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Close Date'
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'CLOSE_DATE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(7343885759644915312)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Enter the contract end date (in DD-MON-YYYY format) or use the date picker controls to navigate to and select the contract''s end date.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7016413169172537685)
,p_name=>'P108_QUOTE_PRICE'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(8904504835975722376)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Annual Recurring Revenue'
,p_placeholder=>'$0'
,p_format_mask=>'FML999G999G999G999G999'
,p_source=>'QUOTE_PRICE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(7343885759644915312)
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
,p_help_text=>'Enter the quoted Annual Recurring Revenue price for the product. If this is a subscription product and it costs $100 per month, the value entered in this field would be $1,200.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7016413331996537686)
,p_name=>'P108_PRODUCT_SOLD_AS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(8904504835975722376)
,p_prompt=>'Sold As'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(7343885725551915311)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8021898861644963467)
,p_name=>'P108_CONTRACT_TERM'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(8904504835975722376)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Contract Term'
,p_source=>'TERM'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TERMS - NUM_MONTHS RETURN VALUE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select name as d,',
'       month_equiv as r',
'  from eba_sales_terms',
' order by 2'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select -'
,p_cHeight=>1
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(7343885759644915312)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
,p_help_text=>'Select the contract term that matches the term of this opportunity''s subscription.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8021899192012963470)
,p_name=>'P108_TCV'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(8904504835975722376)
,p_prompt=>'Total Contract Value'
,p_format_mask=>'FML999G999G999G999G999'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(7343885725551915311)
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8023074250571039157)
,p_name=>'P108_TCV_RETURN'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(8904504835975722376)
,p_use_cache_before_default=>'NO'
,p_source=>'TCV'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8904506261200722382)
,p_name=>'P108_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(8904504835975722376)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8904506439615722390)
,p_name=>'P108_DEAL_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(8904504835975722376)
,p_use_cache_before_default=>'NO'
,p_source=>'DEAL_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8904506644854722391)
,p_name=>'P108_PRODUCT_ID'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(8904504835975722376)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Product'
,p_source=>'PRODUCT_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'PRODUCTS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PRODUCT_NAME display_value, ID return_value ',
'from eba_sales_PRODUCTS',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Product -'
,p_cHeight=>1
,p_colspan=>8
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(7343885759644915312)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8904507042935722392)
,p_name=>'P108_DEAL_PROD_DESCRIPTION'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(8904504835975722376)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Description'
,p_source=>'DEAL_PROD_DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>74
,p_cMaxlength=>4000
,p_cHeight=>4
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(7343885725551915311)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_help_text=>'Enter any other additional information you may have about this product contract'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'NONE'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(8021900758555963486)
,p_computation_sequence=>10
,p_computation_item=>'P108_QUOTE_PRICE'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'replace(replace(:P108_QUOTE_PRICE,''$'',null),'','',null);'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(8021901573501963494)
,p_computation_sequence=>20
,p_computation_item=>'P108_TCV_RETURN'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'replace(replace(nvl(:P108_TCV,:P108_QUOTE_PRICE),''$'',null),'','',null);'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(8021901225436963490)
,p_computation_sequence=>10
,p_computation_item=>'P108_PRODUCT_SOLD_AS'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case',
'           when sold_as = ''SUBSCRIPTION'' then',
'               ''Cloud '' || initcap(sold_as)',
'           when sold_as = ''PURCHASE'' then',
'               ''On-Premise '' || initcap(sold_as)',
'       end sold_as',
'  from eba_sales_products',
' where id = :P108_PRODUCT_ID;'))
,p_compute_when=>'P108_PRODUCT_ID'
,p_compute_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(7375713237355583085)
,p_validation_name=>'P108_PRODUCT_ID not duplicated'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_deal_products',
' where deal_id = :P108_DEAL_ID',
'   and product_id = :P108_PRODUCT_ID',
'   and (:P108_ID is null or id != :P108_ID)'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Product is already associated with this deal.'
,p_associated_item=>wwv_flow_imp.id(8904506644854722391)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
,p_required_patch=>-wwv_flow_imp.id(7478708532380272297)
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(7457946509505814094)
,p_validation_name=>'P108_PRODUCT_ID & P108_CLOSE_DATE not duplicated'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_deal_products',
' where deal_id = :P108_DEAL_ID',
'   and product_id = :P108_PRODUCT_ID',
'   and close_date = :P108_CLOSE_DATE',
'   and (:P108_ID is null or id != :P108_ID)'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Product is already associated with this deal.'
,p_associated_item=>wwv_flow_imp.id(8904506644854722391)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
,p_required_patch=>wwv_flow_imp.id(7478708532380272297)
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8021900858710963487)
,p_validation_name=>'P108_QUOTE_PRICE is numeric'
,p_validation_sequence=>30
,p_validation=>'P108_QUOTE_PRICE'
,p_validation_type=>'ITEM_IS_NUMERIC'
,p_error_message=>'#LABEL# must contain a numeric value (other than commas and a dollar sign).'
,p_validation_condition=>'P108_QUOTE_PRICE'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_imp.id(7016413169172537685)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8021901667841963495)
,p_validation_name=>'P108_TCV is numeric'
,p_validation_sequence=>40
,p_validation=>'P108_TCV'
,p_validation_type=>'ITEM_IS_NUMERIC'
,p_error_message=>'#LABEL# must contain a numeric value (other than commas and a dollar sign).'
,p_validation_condition=>'P108_TCV'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_imp.id(8021899192012963470)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6542457582484038173)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8904505450286722377)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6542457704592038174)
,p_event_id=>wwv_flow_imp.id(6542457582484038173)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8021898534479963464)
,p_name=>'Refresh Sold As'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_PRODUCT_ID'
,p_condition_element=>'P108_PRODUCT_ID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8021898787065963466)
,p_event_id=>wwv_flow_imp.id(8021898534479963464)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_PRODUCT_SOLD_AS'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case',
'           when sold_as = ''SUBSCRIPTION'' then',
'               ''Cloud '' || initcap(sold_as)',
'           when sold_as = ''PURCHASE'' then',
'               ''On-Premise '' || initcap(sold_as)',
'       end sold_as',
'  from eba_sales_products',
' where id = :P108_PRODUCT_ID;'))
,p_attribute_07=>'P108_PRODUCT_ID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8021899505500963473)
,p_event_id=>wwv_flow_imp.id(8021898534479963464)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_CONTRACT_TERM,P108_TCV,P108_PRODUCT_SOLD_AS,P108_QUOTE_PRICE'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8021899679307963475)
,p_event_id=>wwv_flow_imp.id(8021898534479963464)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_PRODUCT_SOLD_AS'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8021898700165963465)
,p_event_id=>wwv_flow_imp.id(8021898534479963464)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_PRODUCT_SOLD_AS'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8021899748940963476)
,p_name=>'Show/Hide Term & TCV'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_PRODUCT_SOLD_AS'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$(''#P108_PRODUCT_SOLD_AS'').html().toLowerCase().indexOf(''subscription'') > 0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8021899912305963477)
,p_event_id=>wwv_flow_imp.id(8021899748940963476)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_CONTRACT_TERM,P108_QUOTE_PRICE'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8021900010861963478)
,p_event_id=>wwv_flow_imp.id(8021899748940963476)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_CONTRACT_TERM,P108_TCV'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8021900690775963485)
,p_event_id=>wwv_flow_imp.id(8021899748940963476)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''label[for="P108_QUOTE_PRICE"]'').html(''Amount'');'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8021901797304963496)
,p_event_id=>wwv_flow_imp.id(8021899748940963476)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''label[for="P108_QUOTE_PRICE"]'').html(''Annual Recurring Revenue'');'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8021900595494963484)
,p_event_id=>wwv_flow_imp.id(8021899748940963476)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_QUOTE_PRICE'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8021900070879963479)
,p_name=>'Set TCV'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_CONTRACT_TERM,P108_QUOTE_PRICE'
,p_condition_element=>'P108_QUOTE_PRICE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8021900188310963480)
,p_event_id=>wwv_flow_imp.id(8021900070879963479)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_TCV'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P108_CONTRACT_TERM < 12 then',
'    :P108_TCV := replace(replace(:P108_QUOTE_PRICE,'','',null),''$'',null) / ((:P108_CONTRACT_TERM * 12) / :P108_CONTRACT_TERM);',
'elsif :P108_CONTRACT_TERM = 12 then',
'    :P108_TCV := replace(replace(:P108_QUOTE_PRICE,'','',null),''$'',null);',
'elsif :P108_CONTRACT_TERM > 12 then',
'    :P108_TCV := replace(replace(:P108_QUOTE_PRICE,'','',null),''$'',null) * (:P108_CONTRACT_TERM / 12);',
'end if;',
'',
':P108_TCV := to_char(:P108_TCV,''FML999G999G999G999G999'');',
'',
'return :P108_TCV;'))
,p_attribute_07=>'P108_CONTRACT_TERM,P108_QUOTE_PRICE'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8021901904098963497)
,p_event_id=>wwv_flow_imp.id(8021900070879963479)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_TCV'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3464264944193172991)
,p_name=>'Set TCV_1'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_QUOTE_PRICE'
,p_condition_element=>'P108_QUOTE_PRICE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'focusout'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3464265042505172992)
,p_event_id=>wwv_flow_imp.id(3464264944193172991)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_TCV'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P108_CONTRACT_TERM < 12 then',
'    :P108_TCV := replace(replace(:P108_QUOTE_PRICE,'','',null),''$'',null) / ((:P108_CONTRACT_TERM * 12) / :P108_CONTRACT_TERM);',
'elsif :P108_CONTRACT_TERM = 12 then',
'    :P108_TCV := replace(replace(:P108_QUOTE_PRICE,'','',null),''$'',null);',
'elsif :P108_CONTRACT_TERM > 12 then',
'    :P108_TCV := replace(replace(:P108_QUOTE_PRICE,'','',null),''$'',null) * (:P108_CONTRACT_TERM / 12);',
'end if;',
'',
':P108_TCV := to_char(:P108_TCV,''FML999G999G999G999G999'');',
'',
'return :P108_TCV;'))
,p_attribute_07=>'P108_CONTRACT_TERM,P108_QUOTE_PRICE'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3464265097713172993)
,p_event_id=>wwv_flow_imp.id(3464264944193172991)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_TCV'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8023073899564039153)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Automatic Row Processing of EBA_SALES_DEAL_PRODUCTS'
,p_attribute_02=>'EBA_SALES_DEAL_PRODUCTS'
,p_attribute_03=>'P108_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8023073899564039153
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8904508239223722395)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(8904505257019722377)
,p_internal_uid=>8904508239223722395
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6542457752707038175)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>6542457752707038175
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8023073958169039154)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from EBA_SALES_DEAL_PRODUCTS'
,p_attribute_02=>'EBA_SALES_DEAL_PRODUCTS'
,p_attribute_03=>'P108_ID'
,p_attribute_04=>'ID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8023073958169039154
);
wwv_flow_imp.component_end;
end;
/
