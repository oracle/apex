prompt --application/pages/page_00108
begin
--   Manifest
--     PAGE: 00108
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>108
,p_name=>'Product Details'
,p_alias=>'PRODUCT-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Product Details'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(7234593954191374263)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_step_template=>2101883943284197310
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(9060293328988296381)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6560179698638791575)
,p_plug_name=>'Buttons'
,p_static_id=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2127905476394690047
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8922227027936475779)
,p_plug_name=>'Product Details'
,p_static_id=>'product-details'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8922227642247475780)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6560179698638791575)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8922227242982475780)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(6560179698638791575)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Product'
,p_button_position=>'CREATE'
,p_button_condition=>'P108_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8922227448980475780)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(6560179698638791575)
,p_button_name=>'DELETE'
,p_static_id=>'delete'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--danger'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Delete'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P108_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8922227340226475780)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(6560179698638791575)
,p_button_name=>'SAVE'
,p_static_id=>'save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CREATE'
,p_button_condition=>'P108_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6726141822112634189)
,p_name=>'P108_CLOSE_DATE'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(8922227027936475779)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Close Date'
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'CLOSE_DATE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_grid_label_column_span=>3
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Enter the contract end date (in DD-MON-YYYY format) or use the date picker controls to navigate to and select the contract''s end date.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8039621053605716870)
,p_name=>'P108_CONTRACT_TERM'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(8922227027936475779)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Contract Term'
,p_source=>'TERM'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TERMS - NUM_MONTHS RETURN VALUE'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select -'
,p_cHeight=>1
,p_grid_label_column_span=>3
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_required_patch=>wwv_flow_imp.id(7204555145359641276)
,p_help_text=>'Select the contract term that matches the term of this opportunity''s subscription.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8922228631576475793)
,p_name=>'P108_DEAL_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(8922227027936475779)
,p_use_cache_before_default=>'NO'
,p_source=>'DEAL_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8922229234896475795)
,p_name=>'P108_DEAL_PROD_DESCRIPTION'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(8922227027936475779)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Description'
,p_source=>'DEAL_PROD_DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>74
,p_cMaxlength=>4000
,p_cHeight=>4
,p_grid_label_column_span=>3
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_help_text=>'Enter any other additional information you may have about this product contract'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'N',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8922228453161475785)
,p_name=>'P108_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(8922227027936475779)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8922228836815475794)
,p_name=>'P108_PRODUCT_ID'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(8922227027936475779)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Product'
,p_source=>'PRODUCT_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'PRODUCTS'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Product -'
,p_cHeight=>1
,p_colspan=>8
,p_grid_label_column_span=>3
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7034135523957291089)
,p_name=>'P108_PRODUCT_SOLD_AS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(8922227027936475779)
,p_prompt=>'Sold As'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_required_patch=>wwv_flow_imp.id(7204555145359641276)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7034135361133291088)
,p_name=>'P108_QUOTE_PRICE'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(8922227027936475779)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Annual Recurring Revenue'
,p_placeholder=>'$0'
,p_format_mask=>'FML999G999G999G999G999'
,p_source=>'QUOTE_PRICE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>3
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(7204555145359641276)
,p_help_text=>'Enter the quoted Annual Recurring Revenue price for the product. If this is a subscription product and it costs $100 per month, the value entered in this field would be $1,200.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8039621383973716873)
,p_name=>'P108_TCV'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(8922227027936475779)
,p_prompt=>'Total Contract Value'
,p_format_mask=>'FML999G999G999G999G999'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_grid_label_column_span=>3
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(7204555145359641276)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8040796442531792560)
,p_name=>'P108_TCV_RETURN'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(8922227027936475779)
,p_use_cache_before_default=>'NO'
,p_source=>'TCV'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_required_patch=>wwv_flow_imp.id(7204555145359641276)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(8039623417397716893)
,p_computation_sequence=>10
,p_computation_item=>'P108_PRODUCT_SOLD_AS'
,p_static_id=>'p108-product-sold-as'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case',
'           when sold_as = ''SUBSCRIPTION'' then',
'               ''Cloud '' || initcap(sold_as)',
'           when sold_as = ''PURCHASE'' then',
'               ''On-Premise '' || initcap(sold_as)',
'       end sold_as',
'  from eba_sales_products',
' where id = :P108_PRODUCT_ID;'))
,p_compute_when=>'P108_PRODUCT_ID'
,p_compute_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(8039622950516716889)
,p_computation_sequence=>10
,p_computation_item=>'P108_QUOTE_PRICE'
,p_static_id=>'p108-quote-price'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'replace(replace(:P108_QUOTE_PRICE,''$'',null),'','',null);'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(8039623765462716897)
,p_computation_sequence=>20
,p_computation_item=>'P108_TCV_RETURN'
,p_static_id=>'p108-tcv-return'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'replace(replace(nvl(:P108_TCV,:P108_QUOTE_PRICE),''$'',null),'','',null);'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(7393435429316336488)
,p_validation_name=>'P108_PRODUCT_ID not duplicated'
,p_static_id=>'p108-product-id-not-duplicated'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_deal_products',
' where deal_id = :P108_DEAL_ID',
'   and product_id = :P108_PRODUCT_ID',
'   and (:P108_ID is null or id != :P108_ID)'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Product is already associated with this deal.'
,p_associated_item=>wwv_flow_imp.id(8922228836815475794)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
,p_required_patch=>-wwv_flow_imp.id(7496430724341025700)
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(7475668701466567497)
,p_validation_name=>'P108_PRODUCT_ID & P108_CLOSE_DATE not duplicated'
,p_static_id=>'p108-product-id-p108-close-date-not-duplicated'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_deal_products',
' where deal_id = :P108_DEAL_ID',
'   and product_id = :P108_PRODUCT_ID',
'   and close_date = :P108_CLOSE_DATE',
'   and (:P108_ID is null or id != :P108_ID)'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Product is already associated with this deal.'
,p_associated_item=>wwv_flow_imp.id(8922228836815475794)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
,p_required_patch=>wwv_flow_imp.id(7496430724341025700)
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8039623050671716890)
,p_validation_name=>'P108_QUOTE_PRICE is numeric'
,p_static_id=>'p108-quote-price-is-numeric'
,p_validation_sequence=>30
,p_validation=>'P108_QUOTE_PRICE'
,p_validation_type=>'ITEM_IS_NUMERIC'
,p_error_message=>'#LABEL# must contain a numeric value (other than commas and a dollar sign).'
,p_validation_condition=>'P108_QUOTE_PRICE'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_imp.id(7034135361133291088)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8039623859802716898)
,p_validation_name=>'P108_TCV is numeric'
,p_static_id=>'p108-tcv-is-numeric'
,p_validation_sequence=>40
,p_validation=>'P108_TCV'
,p_validation_type=>'ITEM_IS_NUMERIC'
,p_error_message=>'#LABEL# must contain a numeric value (other than commas and a dollar sign).'
,p_validation_condition=>'P108_TCV'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_imp.id(8039621383973716873)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6560179774444791576)
,p_name=>'Cancel Dialog'
,p_static_id=>'cancel-dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8922227642247475780)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6560179896552791577)
,p_event_id=>wwv_flow_imp.id(6560179774444791576)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-dialog-cancel'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8039620726440716867)
,p_name=>'Refresh Sold As'
,p_static_id=>'refresh-sold-as'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_PRODUCT_ID'
,p_condition_element=>'P108_PRODUCT_ID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8039621697461716876)
,p_event_id=>wwv_flow_imp.id(8039620726440716867)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_CONTRACT_TERM,P108_TCV,P108_PRODUCT_SOLD_AS,P108_QUOTE_PRICE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8039620892126716868)
,p_event_id=>wwv_flow_imp.id(8039620726440716867)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_PRODUCT_SOLD_AS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8039620979026716869)
,p_event_id=>wwv_flow_imp.id(8039620726440716867)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-set-value'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_PRODUCT_SOLD_AS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'escape_special_characters', 'Y',
  'items_to_submit', 'P108_PRODUCT_ID',
  'sql_query', wwv_flow_string.join(wwv_flow_t_varchar2(
    'select case',
    '           when sold_as = ''SUBSCRIPTION'' then',
    '               ''Cloud '' || initcap(sold_as)',
    '           when sold_as = ''PURCHASE'' then',
    '               ''On-Premise '' || initcap(sold_as)',
    '       end sold_as',
    '  from eba_sales_products',
    ' where id = :P108_PRODUCT_ID;')),
  'suppress_change_event', 'N',
  'type', 'SQL_STATEMENT')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8039621871268716878)
,p_event_id=>wwv_flow_imp.id(8039620726440716867)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_PRODUCT_SOLD_AS'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8039622262840716882)
,p_name=>'Set TCV'
,p_static_id=>'set-tcv'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_CONTRACT_TERM,P108_QUOTE_PRICE'
,p_condition_element=>'P108_QUOTE_PRICE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8039622380271716883)
,p_event_id=>wwv_flow_imp.id(8039622262840716882)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-set-value'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_TCV'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'escape_special_characters', 'Y',
  'items_to_submit', 'P108_CONTRACT_TERM,P108_QUOTE_PRICE',
  'plsql_function_body', wwv_flow_string.join(wwv_flow_t_varchar2(
    'if :P108_CONTRACT_TERM < 12 then',
    '    :P108_TCV := replace(replace(:P108_QUOTE_PRICE,'','',null),''$'',null) / ((:P108_CONTRACT_TERM * 12) / :P108_CONTRACT_TERM);',
    'elsif :P108_CONTRACT_TERM = 12 then',
    '    :P108_TCV := replace(replace(:P108_QUOTE_PRICE,'','',null),''$'',null);',
    'elsif :P108_CONTRACT_TERM > 12 then',
    '    :P108_TCV := replace(replace(:P108_QUOTE_PRICE,'','',null),''$'',null) * (:P108_CONTRACT_TERM / 12);',
    'end if;',
    '',
    ':P108_TCV := to_char(:P108_TCV,''FML999G999G999G999G999'');',
    '',
    'return :P108_TCV;')),
  'suppress_change_event', 'N',
  'type', 'FUNCTION_BODY')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8039624096059716900)
,p_event_id=>wwv_flow_imp.id(8039622262840716882)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_TCV'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3481987136153926394)
,p_name=>'Set TCV_1'
,p_static_id=>'set-tcv-2'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_QUOTE_PRICE'
,p_condition_element=>'P108_QUOTE_PRICE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'focusout'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3481987234465926395)
,p_event_id=>wwv_flow_imp.id(3481987136153926394)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-set-value'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_TCV'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'escape_special_characters', 'Y',
  'items_to_submit', 'P108_CONTRACT_TERM,P108_QUOTE_PRICE',
  'plsql_function_body', wwv_flow_string.join(wwv_flow_t_varchar2(
    'if :P108_CONTRACT_TERM < 12 then',
    '    :P108_TCV := replace(replace(:P108_QUOTE_PRICE,'','',null),''$'',null) / ((:P108_CONTRACT_TERM * 12) / :P108_CONTRACT_TERM);',
    'elsif :P108_CONTRACT_TERM = 12 then',
    '    :P108_TCV := replace(replace(:P108_QUOTE_PRICE,'','',null),''$'',null);',
    'elsif :P108_CONTRACT_TERM > 12 then',
    '    :P108_TCV := replace(replace(:P108_QUOTE_PRICE,'','',null),''$'',null) * (:P108_CONTRACT_TERM / 12);',
    'end if;',
    '',
    ':P108_TCV := to_char(:P108_TCV,''FML999G999G999G999G999'');',
    '',
    'return :P108_TCV;')),
  'suppress_change_event', 'N',
  'type', 'FUNCTION_BODY')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3481987289673926396)
,p_event_id=>wwv_flow_imp.id(3481987136153926394)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_TCV'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8039621940901716879)
,p_name=>'Show/Hide Term & TCV'
,p_static_id=>'show-hide-term-tcv'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P108_PRODUCT_SOLD_AS'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$(''#P108_PRODUCT_SOLD_AS'').html().toLowerCase().indexOf(''subscription'') > 0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8039622202822716881)
,p_event_id=>wwv_flow_imp.id(8039621940901716879)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_CONTRACT_TERM,P108_TCV'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8039622882736716888)
,p_event_id=>wwv_flow_imp.id(8039621940901716879)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', '$(''label[for="P108_QUOTE_PRICE"]'').html(''Amount'');')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8039623989265716899)
,p_event_id=>wwv_flow_imp.id(8039621940901716879)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code-2'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', '$(''label[for="P108_QUOTE_PRICE"]'').html(''Annual Recurring Revenue'');')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8039622104266716880)
,p_event_id=>wwv_flow_imp.id(8039621940901716879)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_CONTRACT_TERM,P108_QUOTE_PRICE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8039622787455716887)
,p_event_id=>wwv_flow_imp.id(8039621940901716879)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show-2'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P108_QUOTE_PRICE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8040796091524792556)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Automatic Row Processing of EBA_SALES_DEAL_PRODUCTS'
,p_static_id=>'automatic-row-processing-of-eba-sales-deal-products'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'lock_row', 'Y',
  'primary_key_column', 'ID',
  'primary_key_item', 'P108_ID',
  'supported_operations', 'I:U:D',
  'table_name', 'EBA_SALES_DEAL_PRODUCTS')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8023073899564039153
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6560179944667791578)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_static_id=>'close-dialog'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_success_messages', 'N')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>6542457752707038175
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8040796150129792557)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from EBA_SALES_DEAL_PRODUCTS'
,p_static_id=>'fetch-row-from-eba-sales-deal-products'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'primary_key_column', 'ID',
  'primary_key_item', 'P108_ID',
  'table_name', 'EBA_SALES_DEAL_PRODUCTS')).to_clob
,p_internal_uid=>8023073958169039154
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8922230431184475798)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_static_id=>'reset-page'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'type', 'CLEAR_CACHE_CURRENT_PAGE')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(8922227448980475780)
,p_internal_uid=>8904508239223722395
);
wwv_flow_imp.component_end;
end;
/
