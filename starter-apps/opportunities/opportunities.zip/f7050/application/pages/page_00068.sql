prompt --application/pages/page_00068
begin
--   Manifest
--     PAGE: 00068
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>68
,p_name=>'Products'
,p_alias=>'PRODUCTS'
,p_step_title=>'Products'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(7418981228878330390)
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// standard, cacheable elements',
'var timeout = 0; // used for debounce on search',
'var CONTAINER_SEL = ''.t-Form-fieldContainer'';',
'var pagePrefix = ''P'' + $(''#pFlowStepId'').val();',
'var displayAsId = pagePrefix + ''_DISPLAY_AS'';',
'var $displayAs = $(''#'' + displayAsId);',
'var $body = $(''.t-PageBody'');',
'var $search = $(''#'' + pagePrefix + ''_SEARCH'');',
'var $sort = $(''#'' + pagePrefix + ''_SORT'');',
'var $reset = $(''#reset_button'');',
'var $cardsReg = $(''#cards_region'');',
'var $reportReg = $(''#report_region'');',
'var $gridReg = $(''#grid_region'');',
'',
'// custom items (will vary by page)',
'var $territory = $(''#'' + pagePrefix + ''_TERRITORY_ID'');',
'var $account = $(''#'' + pagePrefix + ''_ACCOUNT_ID'');',
'var $quarter = $(''#'' + pagePrefix + ''_QUARTER'');',
'',
'function showLeftColumn() {',
'  $body',
'    .removeClass(''t-PageBody--hideLeft'')',
'    .addClass(''t-PageBody--showLeft'');',
'    ',
'  // Takes 200ms to hide column',
'  setTimeout(function() {',
'    // Ensure column headers align correctly',
'    $(window).trigger(''apexwindowresized'');',
'  }, 250);',
'}',
'',
'function hideLeftColumn() {',
'  $body',
'    .removeClass(''t-PageBody--showLeft'')',
'    .addClass(''t-PageBody--hideLeft'');',
'    ',
'  // Takes 200ms to hide column',
'  setTimeout(function() {',
'    // Ensure column headers align correctly',
'    $(window).trigger(''apexwindowresized'');',
'  }, 250);',
'}',
'  ',
'// applyFilters triggers the refresh event on the correct region',
'function applyFilters() {',
'  var display = $v(displayAsId);',
'  ',
'  if (display === ''CARDS'') {',
'    $cardsReg.trigger(''apexrefresh'');',
'  } else if (display === ''REPORT'') {',
'    $reportReg.trigger(''apexrefresh'');',
'  } else if (display === ''GRID'') {',
'    $gridReg.trigger(''apexrefresh'');',
'  }',
'}',
'',
'// toggleRegionDisplay is similar to applyFilters except that it also',
'// takes into account what regions or items need to be displayed or hidden',
'function toggleRegionDisplay(refresh) {',
'  var display = $v(displayAsId);',
'  ',
'  refresh = (refresh === false) ? false : true;',
'  ',
'  if (display === ''CARDS'') {',
'    $reportReg.hide();',
'    $gridReg.hide();',
'',
'    showLeftColumn();',
'',
'    $sort.closest(CONTAINER_SEL).show();',
'',
'    if (refresh) {',
'      $cardsReg.trigger(''apexrefresh'');',
'    }',
'    ',
'    $cardsReg.show();',
'  } else if (display === ''REPORT'') {',
'    $sort.closest(CONTAINER_SEL).hide();',
'    $cardsReg.hide();',
'    $gridReg.hide();',
'',
'    showLeftColumn();',
'',
'    if (refresh) {',
'      $reportReg.trigger(''apexrefresh'');',
'    }',
'',
'    $reportReg.show();',
'  } else if (display === ''GRID'') {',
'    $sort.closest(CONTAINER_SEL).hide();',
'    $cardsReg.hide();',
'    $reportReg.hide();',
'',
'    hideLeftColumn();',
'',
'    if (refresh) {',
'      $gridReg.trigger(''apexrefresh'');',
'    }',
'',
'    $gridReg.show();',
'  }',
'}',
'  ',
'function debounceSearch(e) {',
'    /*',
'     * Prevent search for following keys:',
'     * TAB:     9',
'     * SHIFT:   16',
'     * LEFT:    37',
'     * RIGHT:   39',
'     */',
'    if ( e.which === 9 || e.which === 16 || e.which === 37 || e.which === 39 ) {',
'        return false;',
'    }',
'    clearTimeout(timeout);',
'    timeout = setTimeout(applyFilters, 250);',
'}',
'  ',
'function preventSubmitOnEnter(e) {',
'  if (e.which === 13) {',
'    return false;',
'  }',
'}',
'',
'function resetFilters() {',
'  $search.val(null);',
'  $territory.val(null);',
'  $account.val(null);',
'  $quarter.val(null);',
'  ',
'  $sort.val(''NAME'');',
'',
'  applyFilters();',
'}',
'',
'// standard search event bindings',
'$search.keydown(preventSubmitOnEnter);',
'$search.keyup(debounceSearch);',
'',
'// dynamic event bindings (will vary by filter page)',
'$territory.change(applyFilters);',
'$account.change(applyFilters);',
'$quarter.change(applyFilters);',
'',
'// standard display, sort, reset event bindings',
'$displayAs.change(toggleRegionDisplay);',
'$sort.change(applyFilters);',
'$reset.click(resetFilters);',
'  ',
'toggleRegionDisplay(false);'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Card-initials {',
'  font-size: 14px;',
'}'))
,p_step_template=>2528119710305719084
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(10514207977421756031)
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'Use the filters on the left to show different results in the region on the right. The right region can be displayed in one of three ways (Cards View, Report View, and Customizable Grid) by using the display-mode buttons located just to the left of th'
||'e <strong>Manage Products</strong> button. Filters are not displayed in the Customizable Grid view.'))
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10269194544286530286)
,p_plug_name=>'Filters'
,p_static_id=>'filters'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody:t-Form--stretchInputs'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_translate_title=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6602633840677889471)
,p_plug_name=>'Page Settings'
,p_static_id=>'page-settings'
,p_parent_plug_id=>wwv_flow_imp.id(10269178648003350175)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(7362622160984645165)
,p_name=>'Product Cards'
,p_static_id=>'product-cards'
,p_region_name=>'cards_region'
,p_template=>4502917002193490937
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--basic:t-Cards--3cols:t-Cards--desc-3ln:t-Cards--animColorFill'
,p_region_attributes=>'style="display:none"'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with base_products as (',
'  select p.id,',
'    p.product_name,',
'    p.product_description,',
'    p.row_key, ',
'    p.product_sku,',
'    f.product_family,',
'    p.updated,',
'    (',
'      select count(*)',
'      from eba_sales_deals',
'      where id in (',
'        select deal_id',
'        from eba_sales_deal_products',
'        where product_id = p.id',
'      )',
'    ) opportunities,',
'    (',
'      select count(*)',
'      from eba_sales_customers',
'      where id in (',
'        select customer_id',
'        from eba_sales_deals',
'        where id in (',
'          select deal_id',
'          from eba_sales_deal_products',
'          where product_id = p.id',
'        )',
'      )',
'    ) customers',
'  from eba_sales_products p,',
'       eba_sales_product_families f',
'  where p.product_family_id = f.id (+)',
'    and :P68_DISPLAY_AS = ''CARDS''',
'    and (',
'      :P68_ACCOUNT_ID is null ',
'        or p.id in (',
'          select product_id',
'          from eba_sales_deal_products dp',
'          where deal_id in (',
'            select id',
'            from eba_sales_deals',
'            where customer_id = :P68_ACCOUNT_ID',
'          )',
'        )',
'    )',
'    and (',
'      :P68_QUARTER is null ',
'        or p.id in (',
'          select product_id',
'          from eba_sales_deal_products dp',
'          where deal_id in (',
'            select id',
'            from eba_sales_deals',
'            where qtr = :P68_QUARTER',
'          )',
'        )   ',
'    )',
'),',
'card_details as (',
'  select product_name card_title,',
'    null card_icon,',
'    row_key card_initials,',
'    null card_text,',
'    case when product_family is not null and product_description is not null then',
'            product_family || '', ''  || product_description',
'        when product_family is not null and product_description is null then',
'            product_family',
'        when product_family is null and product_description is not null then',
'            product_description',
'        else',
'            null',
'    end as card_text_p1,',
'    ''SKU: '' || product_sku card_text_p2,',
'    to_char(opportunities,''999G999G999G990'') ||',
'      '' opportunities, '' ||',
'      to_char(customers,''999G999G999G990'') ||',
'      '' accounts'' card_text_p3,',
'    apex_util.prepare_url(',
'      ''f?p='' ||',
'      :APP_ID ||',
'      '':61:'' ||',
'      :APP_SESSION ||',
'      '':::61,RP:P61_ID:'' ||',
'      id',
'    ) card_link,',
'    id,',
'    updated card_subtext,',
'    opportunities,',
'    customers,',
'    updated,',
'    product_name,',
'    product_family',
'  from base_products',
')',
'select *',
'from card_details',
'where (',
'  :P68_SEARCH is null',
'    or instr(upper(card_title), upper(:P68_SEARCH)) > 0',
'    or instr(upper(card_initials), upper(:P68_SEARCH)) > 0',
'    or instr(upper(card_text_p1), upper(:P68_SEARCH)) > 0',
'    or instr(upper(card_text_p2), upper(:P68_SEARCH)) > 0',
'    or instr(upper(card_text_p3), upper(:P68_SEARCH)) > 0',
'    or instr(upper(''Updated: '' || apex_util.get_since(card_subtext)), upper(:P68_SEARCH)) > 0',
')',
'order by',
'  case :P68_SORT',
'    when ''NAME'' then product_name',
'  end,',
'  case :P68_SORT',
'    when ''OPPORTUNITIES'' then opportunities',
'  end desc,',
'  case :P68_SORT',
'    when ''CUSTOMERS'' then customers',
'  end desc,',
'  case :P68_SORT',
'    when ''UPDATED'' then updated',
'  end desc'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P68_SEARCH,P68_ACCOUNT_ID,P68_QUARTER,P68_DISPLAY_AS,P68_SORT'
,p_lazy_loading=>false
,p_query_row_template=>2976458789255810118
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'No products found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6587344298489490261)
,p_query_column_id=>2
,p_column_alias=>'CARD_ICON'
,p_column_display_sequence=>4
,p_column_heading=>'Card icon'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6587344590866490264)
,p_query_column_id=>3
,p_column_alias=>'CARD_INITIALS'
,p_column_display_sequence=>6
,p_column_heading=>'Card initials'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6587344392097490262)
,p_query_column_id=>8
,p_column_alias=>'CARD_LINK'
,p_column_display_sequence=>5
,p_column_heading=>'Card link'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6477935401976156293)
,p_query_column_id=>10
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>2
,p_column_heading=>'Card subtext'
,p_column_format=>'SINCE'
,p_column_html_expression=>'Updated: #CARD_SUBTEXT#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6477935455956156294)
,p_query_column_id=>4
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>3
,p_column_heading=>'Card text'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#CARD_TEXT_P1#<br >',
'<small>',
'#CARD_TEXT_P2#<br >',
'#CARD_TEXT_P3#',
'</small>',
''))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6587344842302490267)
,p_query_column_id=>5
,p_column_alias=>'CARD_TEXT_P1'
,p_column_display_sequence=>7
,p_column_heading=>'Card text p1'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6587344942929490268)
,p_query_column_id=>6
,p_column_alias=>'CARD_TEXT_P2'
,p_column_display_sequence=>8
,p_column_heading=>'Card text p2'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6587345050370490269)
,p_query_column_id=>7
,p_column_alias=>'CARD_TEXT_P3'
,p_column_display_sequence=>9
,p_column_heading=>'Card text p3'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6477935241237156292)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>1
,p_column_heading=>'Card title'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6587345295562490271)
,p_query_column_id=>12
,p_column_alias=>'CUSTOMERS'
,p_column_display_sequence=>11
,p_column_heading=>'Customers'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6587345595081490274)
,p_query_column_id=>9
,p_column_alias=>'ID'
,p_column_display_sequence=>14
,p_column_heading=>'Id'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6587345172067490270)
,p_query_column_id=>11
,p_column_alias=>'OPPORTUNITIES'
,p_column_display_sequence=>10
,p_column_heading=>'Opportunities'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7475664244940567453)
,p_query_column_id=>15
,p_column_alias=>'PRODUCT_FAMILY'
,p_column_display_sequence=>15
,p_column_heading=>'Product family'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6587345441393490273)
,p_query_column_id=>14
,p_column_alias=>'PRODUCT_NAME'
,p_column_display_sequence=>13
,p_column_heading=>'Product name'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6587345372821490272)
,p_query_column_id=>13
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>12
,p_column_heading=>'Updated'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10269178648003350175)
,p_plug_name=>'Products'
,p_static_id=>'products'
,p_icon_css_classes=>'fa-archive'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6574908467212091779)
,p_plug_name=>'Products Grid'
,p_static_id=>'products-grid'
,p_region_name=>'grid_region'
,p_region_template_options=>'#DEFAULT#'
,p_region_attributes=>'style="display:none"'
,p_plug_template=>2102002977963900996
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.id,',
'  p.product_name,',
'  p.row_key, ',
'  p.product_sku,',
'  p.product_family_id,',
'  p.product_description,',
'  p.tags,',
'  (',
'    select count(*)',
'    from eba_sales_links',
'    where product_id = p.id',
'  ) links,',
'  (',
'    select count(*)',
'    from eba_sales_files',
'    where product_id = p.id',
'  ) attachments,',
'  (',
'    select count(*)',
'    from eba_sales_comments',
'    where product_id = p.id',
'  ) comments,',
'  (',
'    select count(*)',
'    from eba_sales_verifications',
'    where product_id = p.id',
'  ) validations,',
'  (',
'    select max(created)',
'    from eba_sales_verifications',
'    where product_id = p.id',
'  ) last_validation,',
'  (',
'    select count(*)',
'    from eba_sales_clicks',
'    where product_id = p.id',
'      and view_timestamp >= sysdate - 90',
'  ) views_90_days,',
'    (   select count(distinct(app_username))',
'        from eba_sales_clicks',
'        where product_id = p.id',
'            and view_timestamp >= sysdate - 90',
'    ) users_90_days,',
'  p.created,',
'  p.created_by,',
'  p.updated,',
'  p.updated_by,',
'  (',
'    select count(*)',
'    from eba_sales_deals',
'    where id in (',
'      select deal_id',
'      from eba_sales_deal_products',
'      where product_id = p.id',
'    )',
'  ) opportunities,',
'  (',
'    select count(*)',
'    from eba_sales_customers',
'    where id in (',
'      select customer_id',
'      from eba_sales_deals',
'      where id in (',
'        select deal_id',
'        from eba_sales_deal_products',
'        where product_id = p.id',
'      )',
'    )',
'  ) customers',
'from eba_sales_products p'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P68_DISPLAY_AS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(6574909747575091792)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_internal_uid=>686324521160772642
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6678755335141798099)
,p_db_column_name=>'ATTACHMENTS'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Attachments'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6678755476383798100)
,p_db_column_name=>'COMMENTS'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Comments'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6574910420028091798)
,p_db_column_name=>'CREATED'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_TIME_FMT.'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6574910501616091799)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6609502355334685253)
,p_db_column_name=>'CUSTOMERS'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Accounts'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6574909925392091793)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6679186563740994252)
,p_db_column_name=>'LAST_VALIDATION'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Last Validation'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Validations''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6678755290526798098)
,p_db_column_name=>'LINKS'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Links'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6609502271889685252)
,p_db_column_name=>'OPPORTUNITIES'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Opportunities'
,p_column_link=>'f?p=&APP_ID.:135:&SESSION.::&DEBUG.:RP,RIR,CIR:IR_PRODUCT_ID:#ID#'
,p_column_linktext=>'#OPPORTUNITIES#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6574910302689091797)
,p_db_column_name=>'PRODUCT_DESCRIPTION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7475664619738567456)
,p_db_column_name=>'PRODUCT_FAMILY_ID'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Family'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(6996144581841418999)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6574909996661091794)
,p_db_column_name=>'PRODUCT_NAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Product'
,p_column_link=>'f?p=&APP_ID.:61:&SESSION.::&DEBUG.:RP,61:P61_ID:#ID#'
,p_column_linktext=>'#PRODUCT_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6574910192445091796)
,p_db_column_name=>'PRODUCT_SKU'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'SKU'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6574910049294091795)
,p_db_column_name=>'ROW_KEY'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Key'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6678755169125798097)
,p_db_column_name=>'TAGS'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Tags'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6574910576829091800)
,p_db_column_name=>'UPDATED'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_TIME_FMT.'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6609502137050685251)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6820212603803349159)
,p_db_column_name=>'USERS_90_DAYS'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'90 Day Users'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Usage Metrics''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6679186494246994251)
,p_db_column_name=>'VALIDATIONS'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Validations'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Validations''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6679186693700994253)
,p_db_column_name=>'VIEWS_90_DAYS'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'90 Day Views'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Usage Metrics''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(6609515943207685723)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'7209308'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PRODUCT_NAME:ROW_KEY:PRODUCT_FAMILY_ID:PRODUCT_SKU:PRODUCT_DESCRIPTION:OPPORTUNITIES:CUSTOMERS'
,p_sort_column_1=>'PRODUCT_NAME'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(6587345640172490275)
,p_name=>'Products Report'
,p_static_id=>'products-report'
,p_region_name=>'report_region'
,p_template=>4073835273271169698
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline'
,p_region_attributes=>'style="display:none"'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with base_products as (',
'  select p.id,',
'    p.product_name,',
'    p.row_key, ',
'    p.product_sku,',
'    p.product_family_id,',
'    p.updated,',
'    (',
'      select count(*)',
'      from eba_sales_deals',
'      where id in (',
'        select deal_id',
'        from eba_sales_deal_products',
'        where product_id = p.id',
'      )',
'    ) opportunities,',
'    (',
'      select count(*)',
'      from eba_sales_customers',
'      where id in (',
'        select customer_id',
'        from eba_sales_deals',
'        where id in (',
'          select deal_id',
'          from eba_sales_deal_products',
'          where product_id = p.id',
'        )',
'      )',
'    ) customers',
'  from eba_sales_products p',
')',
'select *',
'from base_products',
'where :P68_DISPLAY_AS = ''REPORT''',
'  and (',
'    :P68_ACCOUNT_ID is null ',
'      or id in (',
'        select product_id',
'        from eba_sales_deal_products dp',
'        where deal_id in (',
'          select id',
'          from eba_sales_deals',
'          where customer_id = :P68_ACCOUNT_ID',
'        )',
'      )',
'  )',
'  and (',
'    :P68_QUARTER is null ',
'      or id in (',
'        select product_id',
'        from eba_sales_deal_products dp',
'        where deal_id in (',
'          select id',
'          from eba_sales_deals',
'          where qtr = :P68_QUARTER',
'        )',
'      )   ',
'  )',
'  and (',
'    :P68_SEARCH is null',
'      or instr(upper(product_name), upper(:P68_SEARCH)) > 0',
'      or instr(upper(row_key), upper(:P68_SEARCH)) > 0',
'      or instr(upper(product_sku), upper(:P68_SEARCH)) > 0',
'      or instr(opportunities, upper(:P68_SEARCH)) > 0',
'      or instr(customers, upper(:P68_SEARCH)) > 0',
'      or instr(upper(apex_util.get_since(updated)), upper(:P68_SEARCH)) > 0',
'  )'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P68_SEARCH,P68_ACCOUNT_ID,P68_QUARTER,P68_DISPLAY_AS,P68_SORT'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6587346396332490282)
,p_query_column_id=>8
,p_column_alias=>'CUSTOMERS'
,p_column_display_sequence=>7
,p_column_heading=>'Accounts'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6587345759201490276)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6587346283562490281)
,p_query_column_id=>7
,p_column_alias=>'OPPORTUNITIES'
,p_column_display_sequence=>6
,p_column_heading=>'Opportunities'
,p_column_link=>'f?p=&APP_ID.:135:&SESSION.::&DEBUG.:RP,RIR,CIR:IR_PRODUCT_ID:#ID#'
,p_column_linktext=>'#OPPORTUNITIES#'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7475664492790567455)
,p_query_column_id=>5
,p_column_alias=>'PRODUCT_FAMILY_ID'
,p_column_display_sequence=>4
,p_column_heading=>'Family'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(6996144581841418999)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6587345871741490277)
,p_query_column_id=>2
,p_column_alias=>'PRODUCT_NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Product'
,p_column_link=>'f?p=&APP_ID.:61:&SESSION.::&DEBUG.:RP,61:P61_ID:#ID#'
,p_column_linktext=>'#PRODUCT_NAME#'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6587346073960490279)
,p_query_column_id=>4
,p_column_alias=>'PRODUCT_SKU'
,p_column_display_sequence=>5
,p_column_heading=>'SKU'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6587346003792490278)
,p_query_column_id=>3
,p_column_alias=>'ROW_KEY'
,p_column_display_sequence=>3
,p_column_heading=>'Key'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6587346196449490280)
,p_query_column_id=>6
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>8
,p_column_heading=>'Updated'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6813262986010862943)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10269178648003350175)
,p_button_name=>'MANAGE_PRODUCTS'
,p_static_id=>'manage-products'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Manage Products'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP,4::'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8261561508743257347)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10269194544286530286)
,p_button_name=>'RESET'
,p_static_id=>'reset'
,p_button_static_id=>'reset_button'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Reset'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6818614021854944573)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(6574908467212091779)
,p_button_name=>'RESET_REPORT'
,p_static_id=>'reset-report'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&SESSION.::&DEBUG.:RIR,CIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6610668597827030972)
,p_name=>'P68_ACCOUNT_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(10269194544286530286)
,p_prompt=>'Account'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'ACCOUNTS'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_cHeight=>1
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7362617803662533761)
,p_name=>'P68_DISPLAY_AS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6602633840677889471)
,p_item_default=>'CARDS'
,p_prompt=>'Display'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'PILL_DISPLAY_AS'
,p_field_template=>2042262243893469891
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:t-Form-fieldContainer--radioButtonGroup'
,p_is_persistent=>'U'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '4',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10269195344769530293)
,p_name=>'P68_QUARTER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(10269194544286530286)
,p_prompt=>'Quarter'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select	 distinct d.qtr d, d.qtr r',
' from	 "EBA_SALES_DEALS" d',
'where d.qtr is not null',
'order by substr(d.qtr,3), substr(d.qtr,1,2)'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_cHeight=>1
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6588092416159248658)
,p_name=>'P68_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10269194544286530286)
,p_prompt=>'Search'
,p_placeholder=>'Search Products'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>2042262243893469891
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6591711621464318938)
,p_name=>'P68_SORT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(10269194544286530286)
,p_item_default=>'NAME'
,p_prompt=>'Sort'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Product;NAME,Opportunities;OPPORTUNITIES,Customers;CUSTOMERS,Updated;UPDATED'
,p_cHeight=>1
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'U'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp.component_end;
end;
/
