prompt --application/pages/page_00135
begin
--   Manifest
--     PAGE: 00135
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>135
,p_user_interface_id=>wwv_flow_api.id(6988712858842356549)
,p_name=>'Opportunities by Product'
,p_alias=>'OPPORTUNITIES-BY-PRODUCT'
,p_step_title=>'Opportunities by Product'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(7357631458432990573)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'This is an interactive report of all opportunities listed by product. Click the <strong>Reset</strong> button to reset the interactive report. Click the <strong>Actions</strong> button to define the number of rows displayed per page, filter, format, '
||'download, and/or save the interactive report.'
,p_last_upd_yyyymmddhh24miss=>'20210812003731'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7360537034872037871)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7343869008886915277)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(10495270706565772431)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(7343886820987915318)
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7457847953530455573)
,p_plug_name=>'Hidden Items'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7343855668783915255)
,p_plug_display_sequence=>1210
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7464719972960775597)
,p_plug_name=>'Opportunities by Product'
,p_region_name=>'grid_region'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7343865001510915269)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d.id,',
'  d.row_key,',
'  d.deal_name,',
'  dp.close_date,',
'  p.product_family_id,',
'  pf.lob_id as lob,',
'  t.id territory_id,',
'  t.territory_name,',
'  c.id account_id,',
'  c.customer_name account,',
'  d.deal_amount,',
'  d.deal_probability,',
'  case',
'    when deal_probability > 0 and deal_probability < 100',
'    then ''Yes''',
'    else ''No''',
'  end open,',
'  deal_close_date,',
'  case',
'    when deal_close_date < sysdate and deal_probability != 0 and deal_probability != 100',
'    then ''Yes''',
'    else ''No''',
'  end past_due,',
'  d.qtr,',
'  dp.qtr as product_qtr,',
'  substr(dp.qtr,1,2) as pqo,',
'  substr(dp.qtr,-2) as pfyo,',
'  dsc.status_code,',
'  d.updated,',
'  d.updated_by,',
'  d.created,',
'  d.created_by,',
'  sr.rep_first_name || '' '' || sr.rep_last_name as sales_rep_name,',
'  p.product_name,',
'  p.product_sku,',
'  p.id product_id,',
'  d.svp_id,',
'  c.secondary_rep,',
'  sr.REP_MANAGER_ID as sales_mgr,',
'  case ',
'      when :OPP_SET_PROD_LEV_BO = ''Include'' then',
'          case when dp.term is null then nvl(dp.quote_price, 0) else nvl(dp.quote_price, 0) * dp.term/12 end',
'  else',
'          d.deal_amount',
'  end as revenue,',
'  decode(p.sold_as, ''SUBSCRIPTION'', ''Cloud Subscription'', ''PURCHASE'', ''On-Premise Purchase'', p.sold_as) as product_type,',
'  case when dp.term is not null then nvl(dp.quote_price, 0) else 0 end calculated_deal_amount,',
'  case when dp.term is null then nvl(dp.quote_price, 0) else 0 end calculated_opp_amount,',
'  nvl(dp.tcv, 0) as calculated_tcv',
'from eba_sales_deals d',
'join eba_sales_customers c',
'  on c.id = d.customer_id',
'join eba_sales_deal_products dp',
'  on dp.deal_id = d.id',
'join eba_sales_products p',
'  on p.id = dp.product_id',
'join eba_sales_product_families pf',
'  on pf.id = p.product_family_id',
'left join eba_sales_deal_status_codes dsc',
'  on dsc.id = d.deal_status_code_id',
'left join eba_sales_territories t',
'  on t.id = c.customer_territory_id',
'left join eba_sales_salesreps sr',
'  on sr.id = d.salesrep_id_01'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7464720106117775598)
,p_max_row_count=>'1000000'
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_api.id(9042570640734542978)
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DAN'
,p_internal_uid=>1593857071664209851
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743413296207622491)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743413712286622492)
,p_db_column_name=>'ROW_KEY'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Key'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743414088728622492)
,p_db_column_name=>'DEAL_NAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Opportunity'
,p_column_link=>'f?p=&APP_ID.:80:&SESSION.::&DEBUG.:RP,80:P80_ID:#ID#'
,p_column_linktext=>'#DEAL_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743414459765622493)
,p_db_column_name=>'TERRITORY_ID'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Territory id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743414876543622493)
,p_db_column_name=>'TERRITORY_NAME'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Account Territory'
,p_column_link=>'f?p=&APP_ID.:93:&SESSION.::&DEBUG.:RP,93:P93_ID:#TERRITORY_ID#'
,p_column_linktext=>'#TERRITORY_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Territories''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743415330906622494)
,p_db_column_name=>'ACCOUNT_ID'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Selected Account'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743415667179622494)
,p_db_column_name=>'ACCOUNT'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Account'
,p_column_link=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP,94:P94_ID:#ID#'
,p_column_linktext=>'#ACCOUNT#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6708420121818880791)
,p_db_column_name=>'PRODUCT_QTR'
,p_display_order=>80
,p_column_identifier=>'AF'
,p_column_label=>'Quarter'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_required_patch=>wwv_flow_api.id(7478708532380272297)
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743416043466622495)
,p_db_column_name=>'QTR'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Opportunity Quarter'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_required_patch=>-wwv_flow_api.id(7478708532380272297)
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743416455650622495)
,p_db_column_name=>'STATUS_CODE'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Stage'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743416875450622495)
,p_db_column_name=>'UPDATED'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_TIME_FMT.'
,p_tz_dependent=>'Y'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743417262293622496)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743417695548622496)
,p_db_column_name=>'CREATED'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_TIME_FMT.'
,p_tz_dependent=>'Y'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743418070017622497)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743418467135622497)
,p_db_column_name=>'DEAL_PROBABILITY'
,p_display_order=>150
,p_column_identifier=>'N'
,p_column_label=>'Probability'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743418912048622497)
,p_db_column_name=>'OPEN'
,p_display_order=>160
,p_column_identifier=>'O'
,p_column_label=>'Open'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743419333511622498)
,p_db_column_name=>'PAST_DUE'
,p_display_order=>170
,p_column_identifier=>'P'
,p_column_label=>'Past Due'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743419647807622498)
,p_db_column_name=>'DEAL_AMOUNT'
,p_display_order=>180
,p_column_identifier=>'Q'
,p_column_label=>'Amount'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_required_patch=>-wwv_flow_api.id(7186832953398887873)
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743420055958622498)
,p_db_column_name=>'SALES_REP_NAME'
,p_display_order=>200
,p_column_identifier=>'R'
,p_column_label=>'&REP_TITLE.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743412917901622491)
,p_db_column_name=>'DEAL_CLOSE_DATE'
,p_display_order=>210
,p_column_identifier=>'AA'
,p_column_label=>'Opportunity Close Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_FORMAT.'
,p_tz_dependent=>'Y'
,p_required_patch=>-wwv_flow_api.id(7478708532380272297)
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743262499328799951)
,p_db_column_name=>'PRODUCT_NAME'
,p_display_order=>220
,p_column_identifier=>'AB'
,p_column_label=>'Product'
,p_column_link=>'f?p=&APP_ID.:85:&SESSION.::&DEBUG.:RP,85:P85_ID,IR_PRODUCT:#ID#,#PRODUCT_NAME#'
,p_column_linktext=>'#PRODUCT_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743262580476799952)
,p_db_column_name=>'PRODUCT_SKU'
,p_display_order=>230
,p_column_identifier=>'AC'
,p_column_label=>'Product SKU'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743262690000799953)
,p_db_column_name=>'PRODUCT_ID'
,p_display_order=>240
,p_column_identifier=>'AD'
,p_column_label=>'Selected Product'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6708420287618880793)
,p_db_column_name=>'CALCULATED_DEAL_AMOUNT'
,p_display_order=>260
,p_column_identifier=>'AH'
,p_column_label=>'&AMT_HDR.'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_required_patch=>wwv_flow_api.id(7186832953398887873)
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6708420402654880794)
,p_db_column_name=>'CLOSE_DATE'
,p_display_order=>270
,p_column_identifier=>'AI'
,p_column_label=>'Product Close Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'CENTER'
,p_format_mask=>'&APP_DATE_FORMAT.'
,p_tz_dependent=>'Y'
,p_required_patch=>wwv_flow_api.id(7478708532380272297)
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6708420460560880795)
,p_db_column_name=>'PRODUCT_FAMILY_ID'
,p_display_order=>280
,p_column_identifier=>'AJ'
,p_column_label=>'Product Family'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(6978422389880665596)
,p_rpt_show_filter_lov=>'1'
,p_required_patch=>wwv_flow_api.id(7186832953398887873)
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7573360536540586258)
,p_db_column_name=>'PRODUCT_TYPE'
,p_display_order=>290
,p_column_identifier=>'AK'
,p_column_label=>'Product Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_required_patch=>wwv_flow_api.id(7186832953398887873)
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8023075346704039168)
,p_db_column_name=>'CALCULATED_TCV'
,p_display_order=>300
,p_column_identifier=>'AL'
,p_column_label=>'Total Contract Value'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_required_patch=>wwv_flow_api.id(7186832953398887873)
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6047324642278045856)
,p_db_column_name=>'CALCULATED_OPP_AMOUNT'
,p_display_order=>310
,p_column_identifier=>'AM'
,p_column_label=>'On-Premise Purchase Amount'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_required_patch=>wwv_flow_api.id(7186832953398887873)
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6047324524593045855)
,p_db_column_name=>'REVENUE'
,p_display_order=>320
,p_column_identifier=>'AN'
,p_column_label=>'Total Revenue'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8451267193466738284)
,p_db_column_name=>'SVP_ID'
,p_display_order=>330
,p_column_identifier=>'AO'
,p_column_label=>'SVP'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(8454523626590621748)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8451267281154738285)
,p_db_column_name=>'SECONDARY_REP'
,p_display_order=>340
,p_column_identifier=>'AP'
,p_column_label=>'&SALES_LDR_TITLE.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(8451267340608738286)
,p_db_column_name=>'SALES_MGR'
,p_display_order=>350
,p_column_identifier=>'AQ'
,p_column_label=>'&REP_TITLE. Manager'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(8454529635334784561)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6403327342113096175)
,p_db_column_name=>'LOB'
,p_display_order=>360
,p_column_identifier=>'AR'
,p_column_label=>'Line of Business'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_api.id(6414531050722291092)
,p_rpt_show_filter_lov=>'1'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3292358598395069752)
,p_db_column_name=>'PQO'
,p_display_order=>370
,p_column_identifier=>'AS'
,p_column_label=>'Product Quarter Only'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(3292358680788069753)
,p_db_column_name=>'PFYO'
,p_display_order=>380
,p_column_identifier=>'AT'
,p_column_label=>'Product Fiscal Year Only'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7465286837957409283)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8725606'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DEAL_NAME:PRODUCT_NAME:LOB:PRODUCT_FAMILY_ID:PRODUCT_TYPE:ACCOUNT:TERRITORY_NAME:PRODUCT_QTR:DEAL_PROBABILITY:OPEN:PAST_DUE:SALES_REP_NAME:SALES_MGR:SVP_ID:SECONDARY_REP:CALCULATED_TCV:CALCULATED_DEAL_AMOUNT:CALCULATED_OPP_AMOUNT:REVENUE:'
,p_sort_column_1=>'PRODUCT_NAME'
,p_sort_direction_1=>'ASC'
,p_break_on=>'0:0:0:0:0'
,p_break_enabled_on=>'0:0:0:0:0'
,p_sum_columns_on_break=>'REVENUE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7360536247609037867)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7464719972960775597)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(7343886016830915316)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:135:&SESSION.::&DEBUG.:135,RIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_api.create_page_branch(
 p_id=>wwv_flow_api.id(7360537654943037873)
,p_branch_name=>'Go To Page 135'
,p_branch_action=>'f?p=&FLOW_ID.:135:&SESSION.'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(7457848121847455574)
,p_name=>'P135_HELP'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(7457847953530455573)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(7360537466121037873)
,p_computation_sequence=>10
,p_computation_item=>'LAST_PAGE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'135'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(7457848177746455575)
,p_computation_sequence=>20
,p_computation_item=>'P135_HELP'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'This is help text'
);
wwv_flow_api.component_end;
end;
/
