prompt --application/pages/page_00062
begin
--   Manifest
--     PAGE: 00062
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>62
,p_name=>'Pipeline'
,p_alias=>'PIPELINE'
,p_step_title=>'Pipeline'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(7357631458432990573)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'.tbl-main .rounded-corner-region .rc-body-r { height: 170px !important; }',
'</style>'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'View horizontal bar graphs depicting Weighted Pipeline data (by Opportunity and by Territory). Change the "Territory" filter or enter an account name into the search bar and click the <strong>Go</strong> button to vary the bar graph results.'
,p_page_component_map=>'17'
,p_last_upd_yyyymmddhh24miss=>'20220823161416'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7581517536258881471)
,p_plug_name=>'Weighted Pipeline by Opportunity'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hiddenOverflow'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(7343866444940915275)
,p_plug_display_sequence=>30
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select	 ',
'     d.qtr||'': ''||cust."CUSTOMER_NAME" as label,',
'     case when apex_util.get_build_option_status(',
'                   p_application_id    => :APP_ID,',
'                   p_build_option_name => ''Opportunity Amount Set at Product Level''',
'               ) = ''EXCLUDE'' then',
'         round(nvl(d.deal_amount,0) * nvl(d."DEAL_PROBABILITY",10) / 100)',
'     else',
'         round(nvl((select sum(nvl(dp.quote_price, 0.00)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id),0) * nvl(d."DEAL_PROBABILITY",10) / 100) ',
'     end as value,',
'     case when apex_util.get_build_option_status(',
'                   p_application_id    => :APP_ID,',
'                   p_build_option_name => ''Opportunity Amount Set at Product Level''',
'               ) = ''EXCLUDE'' then',
'         to_char(round(d.deal_amount * d.deal_probability / 100),''FML999G999G999G999G999'')',
'     else',
'         to_char(round(nvl((select sum(nvl(dp.quote_price, 0.00)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id),0) * d.deal_probability / 100),''FML999G999G999G999G999'')',
'     end as display_value,',
'     d.id,',
'    ''f?p=''||:APP_ID||'':80:''||:APP_SESSION',
'        ||''::''||:DEBUG||'':RP,80:P80_ID:''||d.id the_link',
'from	 ',
'    "EBA_SALES_SALESREPS" r,',
'    "EBA_SALES_DEAL_STATUS_CODES" c,',
'    "EBA_SALES_CUSTOMERS" cust,',
'    "EBA_SALES_DEALS" d,',
'    eba_sales_territories t',
'where   ',
' cust.customer_territory_id = t.id(+) ',
' and     d."CUSTOMER_ID"=cust."ID"(+)',
' and	 d."DEAL_STATUS_CODE_ID"=c."ID"(+)',
' and	 d."SALESREP_ID_01"=r."ID"(+)',
' and     (nvl(:P62_TERRITORY,0) = 0 or t.id= :P62_TERRITORY)',
' and     (:P62_SEARCH is null or',
'          instr(upper(cust."CUSTOMER_NAME"),upper(:P62_SEARCH)) > 0',
'         )',
'order by 2 desc'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HTML5_BAR_CHART'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'INITIALS'
,p_attribute_02=>'LABEL'
,p_attribute_03=>'&THE_LINK.'
,p_attribute_04=>'VALUE'
,p_attribute_11=>'VALUE'
,p_attribute_14=>'50'
,p_attribute_15=>'TEXT'
,p_attribute_16=>'ABSOLUTE'
,p_attribute_17=>'MODERN'
,p_attribute_18=>'AROUND'
,p_attribute_20=>'<p>No data found.</p>'
,p_attribute_21=>'FML999G999G999G999G999G999'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7581517710179881472)
,p_plug_name=>'Weighted Pipeline by Territory'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hiddenOverflow'
,p_plug_template=>wwv_flow_imp.id(7343866444940915275)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select	 ',
'     t.territory_name label,',
'     case when apex_util.get_build_option_status(',
'                   p_application_id    => :APP_ID,',
'                   p_build_option_name => ''Opportunity Amount Set at Product Level''',
'               ) = ''EXCLUDE'' then',
'         round(sum(nvl(d.deal_amount,0) * nvl(d."DEAL_PROBABILITY",0) / 100))',
'     else',
'         round(sum(nvl((select sum(nvl(dp.quote_price, 0.00)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id),0) * nvl(d."DEAL_PROBABILITY",0) / 100))',
'     end as value,',
'     t.id,',
'    ''f?p=''||:APP_ID||'':93:''||:APP_SESSION||''::''||:DEBUG||'':RP,93:P93_ID:''||t.id the_link',
'from	 ',
'    "EBA_SALES_SALESREPS" r,',
'    "EBA_SALES_DEAL_STATUS_CODES" c,',
'    "EBA_SALES_CUSTOMERS" cust,',
'    "EBA_SALES_DEALS" d,',
'    eba_sales_territories t',
'where cust.customer_territory_id = t.id',
'  and d."CUSTOMER_ID" = cust."ID"(+)',
'  and d."DEAL_STATUS_CODE_ID" = c."ID"(+)',
'  and d."SALESREP_ID_01" = r."ID"(+)',
'  and (nvl(:P62_TERRITORY,0) = 0 or t.id = :P62_TERRITORY)',
'group by t.territory_name, t.id',
'order by 2 desc'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HTML5_BAR_CHART'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_required_patch=>wwv_flow_imp.id(10496139698135220995)
,p_attribute_01=>'INITIALS'
,p_attribute_02=>'LABEL'
,p_attribute_03=>'&THE_LINK.'
,p_attribute_04=>'VALUE'
,p_attribute_11=>'VALUE'
,p_attribute_14=>'50'
,p_attribute_15=>'TEXT'
,p_attribute_16=>'ABSOLUTE'
,p_attribute_17=>'MODERN'
,p_attribute_18=>'AROUND'
,p_attribute_20=>'<p>No data found.</p>'
,p_attribute_21=>'FML999G999G999G999G999G999'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10248127152039070993)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343869008886915277)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10495270706565772431)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(7343886820987915318)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10248128371707086162)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(7343855860694915257)
,p_plug_display_sequence=>10
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10248128963265086166)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(10248128371707086162)
,p_button_name=>'P62_GO'
,p_button_static_id=>'P62_GO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--small'
,p_button_template_id=>wwv_flow_imp.id(7343886609855915317)
,p_button_image_alt=>'Go'
,p_button_cattributes=>'style="margin-top:8px;"'
,p_request_source=>'Go'
,p_request_source_type=>'STATIC'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7357621947490722488)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10248127152039070993)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886016830915316)
,p_button_image_alt=>'Reset'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:62:&SESSION.::&DEBUG.:RP,62::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10248128572621086163)
,p_name=>'P62_TERRITORY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10248128371707086162)
,p_prompt=>'Territory'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TERRITORY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TERRITORY_NAME display_value, ID return_value ',
'from eba_sales_TERRITORIES',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(7343885725551915311)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_required_patch=>wwv_flow_imp.id(10496139698135220995)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'REDIRECT_SET_VALUE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10248128752272086165)
,p_name=>'P62_SEARCH'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10248128371707086162)
,p_prompt=>'Search'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select customer_name',
'from EBA_SALES_CUSTOMERS'))
,p_cSize=>64
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(7343885725551915311)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'Y'
,p_attribute_06=>'N'
,p_attribute_07=>'N'
,p_attribute_08=>'N'
);
wwv_flow_imp.component_end;
end;
/
