prompt --application/pages/page_00062
begin
--   Manifest
--     PAGE: 00062
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>62
,p_name=>'Pipeline'
,p_alias=>'PIPELINE'
,p_step_title=>'Pipeline'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(7375353650393743976)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'.tbl-main .rounded-corner-region .rc-body-r { height: 170px !important; }',
'</style>'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'View horizontal bar graphs depicting Weighted Pipeline data (by Opportunity and by Territory). Change the "Territory" filter or enter an account name into the search bar and click the <strong>Go</strong> button to vary the bar graph results.'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7599239728219634874)
,p_plug_name=>'Weighted Pipeline by Opportunity'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hiddenOverflow'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select	 ',
'     d.qtr||'': ''||cust."CUSTOMER_NAME" as label,',
'     case when apex_util.get_build_option_status(',
'                   p_application_id    => :APP_ID,',
'                   p_build_option_name => ''Opportunity Amount Set at Product Level''',
'               ) = ''EXCLUDE'' then',
'         round(nvl(d.deal_amount,0) * nvl(d."DEAL_PROBABILITY",10) / 100)',
'     else',
'         round(nvl((select sum(nvl(dp.quote_price, 0.00)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id),0) * nvl(d."DEAL_PROBABILITY",10) / 100) ',
'     end as value,',
'     case when apex_util.get_build_option_status(',
'                   p_application_id    => :APP_ID,',
'                   p_build_option_name => ''Opportunity Amount Set at Product Level''',
'               ) = ''EXCLUDE'' then',
'         to_char(round(d.deal_amount * d.deal_probability / 100),''FML999G999G999G999G999'')',
'     else',
'         to_char(round(nvl((select sum(nvl(dp.quote_price, 0.00)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id),0) * d.deal_probability / 100),''FML999G999G999G999G999'')',
'     end as display_value,',
'     d.id,',
'    apex_util.prepare_url( ''f?p=''||:APP_ID||'':80:''||:APP_SESSION',
'        ||''::''||:DEBUG||'':RP,80:P80_ID:''||d.id ) the_link',
'from	 ',
'    "EBA_SALES_SALESREPS" r,',
'    "EBA_SALES_DEAL_STATUS_CODES" c,',
'    "EBA_SALES_CUSTOMERS" cust,',
'    "EBA_SALES_DEALS" d,',
'    eba_sales_territories t',
'where   ',
' cust.customer_territory_id = t.id(+) ',
' and     d."CUSTOMER_ID"=cust."ID"(+)',
' and	 d."DEAL_STATUS_CODE_ID"=c."ID"(+)',
' and	 d."SALESREP_ID_01"=r."ID"(+)',
' and     (nvl(:P62_TERRITORY,0) = 0 or t.id= :P62_TERRITORY)',
' and     (:P62_SEARCH is null or',
'          instr(upper(cust."CUSTOMER_NAME"),upper(:P62_SEARCH)) > 0',
'         )',
'order by 2 desc'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HTML5_BAR_CHART'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_02', 'LABEL',
  'attribute_03', '&THE_LINK.',
  'attribute_04', 'VALUE',
  'attribute_11', 'VALUE',
  'attribute_14', '50',
  'attribute_15', 'TEXT',
  'attribute_16', 'ABSOLUTE',
  'attribute_17', 'MODERN',
  'attribute_18', 'AROUND',
  'attribute_20', '<p>No data found.</p>',
  'attribute_21', 'FML999G999G999G999G999G999')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7599239902140634875)
,p_plug_name=>'Weighted Pipeline by Territory'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hiddenOverflow'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select	 ',
'     t.territory_name label,',
'     case when apex_util.get_build_option_status(',
'                   p_application_id    => :APP_ID,',
'                   p_build_option_name => ''Opportunity Amount Set at Product Level''',
'               ) = ''EXCLUDE'' then',
'         round(sum(nvl(d.deal_amount,0) * nvl(d."DEAL_PROBABILITY",0) / 100))',
'     else',
'         round(sum(nvl((select sum(nvl(dp.quote_price, 0.00)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id),0) * nvl(d."DEAL_PROBABILITY",0) / 100))',
'     end as value,',
'     t.id,',
'    apex_util.prepare_url(''f?p=''||:APP_ID||'':93:''||:APP_SESSION||''::''||:DEBUG||'':RP,93:P93_ID:''||t.id) the_link',
'from	 ',
'    "EBA_SALES_SALESREPS" r,',
'    "EBA_SALES_DEAL_STATUS_CODES" c,',
'    "EBA_SALES_CUSTOMERS" cust,',
'    "EBA_SALES_DEALS" d,',
'    eba_sales_territories t',
'where cust.customer_territory_id = t.id',
'  and d."CUSTOMER_ID" = cust."ID"(+)',
'  and d."DEAL_STATUS_CODE_ID" = c."ID"(+)',
'  and d."SALESREP_ID_01" = r."ID"(+)',
'  and (nvl(:P62_TERRITORY,0) = 0 or t.id = :P62_TERRITORY)',
'group by t.territory_name, t.id',
'order by 2 desc'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.HTML5_BAR_CHART'
,p_required_patch=>wwv_flow_imp.id(10513861890095974398)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_02', 'LABEL',
  'attribute_03', '&THE_LINK.',
  'attribute_04', 'VALUE',
  'attribute_11', 'VALUE',
  'attribute_14', '50',
  'attribute_15', 'TEXT',
  'attribute_16', 'ABSOLUTE',
  'attribute_17', 'MODERN',
  'attribute_18', 'AROUND',
  'attribute_20', '<p>No data found.</p>',
  'attribute_21', 'FML999G999G999G999G999G999')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10265849343999824396)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10512992898526525834)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10265850563667839565)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10265851155225839569)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(10265850563667839565)
,p_button_name=>'P62_GO'
,p_button_static_id=>'P62_GO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--small'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Go'
,p_button_cattributes=>'style="margin-top:8px;"'
,p_request_source=>'Go'
,p_request_source_type=>'STATIC'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7375344139451475891)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10265849343999824396)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Reset'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:62:&SESSION.::&DEBUG.:RP,62::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10265850764581839566)
,p_name=>'P62_TERRITORY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10265850563667839565)
,p_prompt=>'Territory'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TERRITORY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TERRITORY_NAME display_value, ID return_value ',
'from eba_sales_TERRITORIES',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_cHeight=>1
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_required_patch=>wwv_flow_imp.id(10513861890095974398)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'REDIRECT_SET_VALUE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10265850944232839568)
,p_name=>'P62_SEARCH'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10265850563667839565)
,p_prompt=>'Search'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select customer_name',
'from EBA_SALES_CUSTOMERS'))
,p_cSize=>64
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'fetch_on_type', 'Y',
  'match_type', 'CONTAINS_IGNORE',
  'use_cache', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
