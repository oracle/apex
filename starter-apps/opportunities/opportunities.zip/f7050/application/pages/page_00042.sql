prompt --application/pages/page_00042
begin
--   Manifest
--     PAGE: 00042
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>42
,p_name=>'Opportunities by Territory'
,p_alias=>'OPPORTUNITIES-BY-TERRITORY'
,p_step_title=>'Opportunities by Territory'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(7357631458432990573)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'This is an interactive report of all opportunities listed by territory. Weighted values are derived from multiplying the opportunity''s value by its chance of coming to fruition and dividing the result by 100. Click the <strong>Reset</strong> button t'
||'o reset the interactive report. Click the <strong>Actions</strong> button to define the number of rows displayed per page, filter, format, download, and/or save the interactive report.'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8456020066809937748)
,p_plug_name=>'Opportunities by Territory and Quarter'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343865001510915269)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    v1.territory_name,',
'    v1.qtr,',
'    v1.product_qtr,',
'    v1.customers,',
'    v1.deal_amount,',
'    v1.calculated_amount,',
'    v1.calculated_tcv,',
'    v1.deal_revenues as revenues,',
'    v1.calculated_opp,',
'    v1.weighted_forecast,',
'    v1.calculated_weighted_forecast',
'from',
'(',
'    select',
'        t.territory_name,',
'        o.qtr,',
'        sum(o.deal_amount) as deal_revenues,',
'        listagg(dp.qtr,'', '') within group (order by substr(dp.qtr, -2) asc, substr(dp.qtr, 2) asc) as product_qtr,',
'        count(distinct c.id) customers,',
'        sum(o.deal_amount) as deal_amount,',
'        nvl(sum(nvl(dp.quote_price, 0)), 0) as calculated_amount,',
'        nvl(sum(nvl(dp.tcv, 0)), 0) as calculated_tcv,',
'        sum(nvl((select sum(nvl(dx.quote_price, 0)) from EBA_SALES_DEAL_PRODUCTS dx where dx.deal_id = dp.id and dx.term is null), 0)) as calculated_opp,',
'        sum(o.deal_amount * o.deal_probability / 100) weighted_forecast,',
'        nvl(sum(nvl(dp.quote_price, 0) * o.deal_probability / 100), 0) calculated_weighted_forecast',
'    from eba_sales_territories t',
'    left join eba_sales_customers c',
'      on c.customer_territory_id = t.id',
'    left join eba_sales_deals o',
'      on o.customer_id = c.id',
'    left join eba_sales_deal_products dp',
'      on dp.deal_id = o.id',
'    where o.qtr is not null',
'       or (select max(dps.qtr) from eba_sales_deal_products dps where dps.deal_id = o.id) is not null',
'    group by  t.territory_name, o.qtr',
') v1'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_required_patch=>-wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(8456020261746937750)
,p_max_row_count=>'10000'
,p_max_row_count_message=>'This query returns more than #MAX_ROW_COUNT# rows, please filter your data to ensure complete results.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:PDF'
,p_download_filename=>'opportunities_by_territory.csv'
,p_enable_mail_download=>'Y'
,p_owner=>'ALLAN'
,p_internal_uid=>2585157227293372003
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8456020433026937751)
,p_db_column_name=>'TERRITORY_NAME'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Territory'
,p_column_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:RP,1,RIR:P1_DISPLAY_AS,IR_TERRITORY_NAME:GRID,#TERRITORY_NAME#'
,p_column_linktext=>'#TERRITORY_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8456020491100937752)
,p_db_column_name=>'QTR'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Quarter'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_required_patch=>-wwv_flow_imp.id(7478708532380272297)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8456020626914937753)
,p_db_column_name=>'CUSTOMERS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Accounts'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8456020705071937754)
,p_db_column_name=>'WEIGHTED_FORECAST'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Weighted Forecast'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
,p_required_patch=>-wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8456020756736937755)
,p_db_column_name=>'CALCULATED_WEIGHTED_FORECAST'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Weighted Forecast'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8456020881325937756)
,p_db_column_name=>'PRODUCT_QTR'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Quarter(s)'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(7478708532380272297)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8456020996596937757)
,p_db_column_name=>'DEAL_AMOUNT'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Actual Amount'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
,p_required_patch=>-wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8456021117154937758)
,p_db_column_name=>'CALCULATED_AMOUNT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'&AMT_HDR.'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8456021192464937759)
,p_db_column_name=>'CALCULATED_TCV'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Actual Total Contract Value'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8456021267159937760)
,p_db_column_name=>'CALCULATED_OPP'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'On-Premise Purchase Amount'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8456021346720937761)
,p_db_column_name=>'REVENUES'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Revenues'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(8456032013579120506)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'25851690'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TERRITORY_NAME:QTR:CUSTOMERS:WEIGHTED_FORECAST:CALCULATED_WEIGHTED_FORECAST:PRODUCT_QTR:DEAL_AMOUNT:CALCULATED_AMOUNT:CALCULATED_TCV:CALCULATED_OPP:REVENUES'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10167203677118023635)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343869008886915277)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10495270706565772431)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(7343886820987915318)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10235709073680994361)
,p_plug_name=>'Opportunities by Territory and Quarter'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343865001510915269)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    v1.territory_name,',
'    eba_sales_fw.remove_duplicates(v1.product_qtr) as product_qtr,',
'    v1.customers,',
'    v1.deal_amount,',
'    v1.calculated_amount,',
'    v1.calculated_tcv,',
'    v1.calculated_amount + v1.calculated_opp as revenues,',
'    v1.calculated_opp,',
'    v1.weighted_forecast,',
'    v1.calculated_weighted_forecast',
'from',
'(',
'    select',
'        t.territory_name,',
'        sum(o.deal_amount) as deal_revenues,',
'        listagg(dp.qtr,'', '') within group (order by substr(dp.qtr, -2) asc, substr(dp.qtr, 2) asc) as product_qtr,',
'        count(distinct c.id) customers,',
'        sum(o.deal_amount) as deal_amount,',
'        nvl(sum(nvl(dp.quote_price, 0)), 0) as calculated_amount,',
'        nvl(sum(nvl(dp.tcv, 0)), 0) as calculated_tcv,',
'        sum(nvl((select sum(nvl(dx.quote_price, 0)) from EBA_SALES_DEAL_PRODUCTS dx where dx.deal_id = dp.id and dx.term is null), 0)) as calculated_opp,',
'        sum(o.deal_amount * o.deal_probability / 100) weighted_forecast,',
'        nvl(sum(nvl(dp.quote_price, 0) * o.deal_probability / 100), 0) calculated_weighted_forecast',
'    from eba_sales_territories t',
'    left join eba_sales_customers c',
'      on c.customer_territory_id = t.id',
'    left join eba_sales_deals o',
'      on o.customer_id = c.id',
'    left join eba_sales_deal_products dp',
'      on dp.deal_id = o.id',
'    where o.qtr is not null',
'       or (select max(dps.qtr) from eba_sales_deal_products dps where dps.deal_id = o.id) is not null',
'    group by  t.territory_name',
') v1'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(10235709159560994361)
,p_name=>'Opportunities by Territory and Quarter'
,p_max_row_count=>'10000'
,p_max_row_count_message=>'This query returns more than #MAX_ROW_COUNT# rows, please filter your data to ensure complete results.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:PDF'
,p_download_filename=>'opportunities_by_territory.csv'
,p_enable_mail_download=>'Y'
,p_owner=>'MIKE'
,p_internal_uid=>3725344724950466954
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10235709354235994370)
,p_db_column_name=>'TERRITORY_NAME'
,p_display_order=>2
,p_column_identifier=>'A'
,p_column_label=>'Territory'
,p_column_link=>'f?p=&APP_ID.:1:&SESSION.:IR_25333932:&DEBUG.:RP,1,RIR:P1_DISPLAY_AS,IR_TERRITORY_NAME:GRID,#TERRITORY_NAME#'
,p_column_linktext=>'#TERRITORY_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10235709544455994371)
,p_db_column_name=>'CUSTOMERS'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Accounts'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10235709662899994371)
,p_db_column_name=>'WEIGHTED_FORECAST'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Weighted Forecast'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
,p_required_patch=>-wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7026387192455438382)
,p_db_column_name=>'CALCULATED_WEIGHTED_FORECAST'
,p_display_order=>14
,p_column_identifier=>'E'
,p_column_label=>'Weighted Forecast'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7573361157298586264)
,p_db_column_name=>'PRODUCT_QTR'
,p_display_order=>24
,p_column_identifier=>'F'
,p_column_label=>'Quarter(s)'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(7478708532380272297)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7573363548473586288)
,p_db_column_name=>'DEAL_AMOUNT'
,p_display_order=>34
,p_column_identifier=>'G'
,p_column_label=>'Actual Amount'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
,p_required_patch=>-wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7573363714747586289)
,p_db_column_name=>'CALCULATED_AMOUNT'
,p_display_order=>44
,p_column_identifier=>'H'
,p_column_label=>'&AMT_HDR.'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8023075459861039169)
,p_db_column_name=>'CALCULATED_TCV'
,p_display_order=>54
,p_column_identifier=>'I'
,p_column_label=>'Actual Total Contract Value'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6047325013949045860)
,p_db_column_name=>'CALCULATED_OPP'
,p_display_order=>64
,p_column_identifier=>'J'
,p_column_label=>'On-Premise Purchase Amount'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6047324745405045857)
,p_db_column_name=>'REVENUES'
,p_display_order=>74
,p_column_identifier=>'K'
,p_column_label=>'Revenues'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(10235709954426995384)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8977905'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TERRITORY_NAME:CUSTOMERS:PRODUCT_QTR:CALCULATED_WEIGHTED_FORECAST:CALCULATED_AMOUNT:CALCULATED_OPP:REVENUES'
,p_sort_column_1=>'TERRITORY_NAME'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'QTR'
,p_sort_direction_2=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10251155246375195140)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343855668783915255)
,p_plug_display_sequence=>10
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8456020208616937749)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8456020066809937748)
,p_button_name=>'RESET_REPORT_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886016830915316)
,p_button_image_alt=>'Reset'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:42,RIR,CIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10251155065983191397)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10235709073680994361)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886016830915316)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:42,RIR,CIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp.component_end;
end;
/
