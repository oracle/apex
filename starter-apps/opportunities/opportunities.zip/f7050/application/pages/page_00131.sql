prompt --application/pages/page_00131
begin
--   Manifest
--     PAGE: 00131
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>131
,p_name=>'Opportunities Past Due'
,p_alias=>'OPPORTUNITIES-PAST-DUE'
,p_step_title=>'Opportunities Past Due'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(7375353650393743976)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'This is an interactive report of all opportunities open but with a close date in the past. Click the <strong>Reset</strong> button to reset the interactive report. Click the <strong>Actions</strong> button to define the number of rows displayed per p'
||'age, filter, format, download, and/or save the interactive report.'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7375490032663385915)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10512992898526525834)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8247917566306947328)
,p_plug_name=>'Opportunities Past Due'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d.id,',
'  d.row_key,',
'  d.deal_name,',
'  t.id territory_id,',
'  t.territory_name,',
'  c.id account_id,',
'  c.customer_name account,',
'  d.deal_amount,',
'  d.deal_probability,',
'  deal_close_date,',
'  d.qtr,',
'  dsc.status_code,',
'  d.tags,',
'  d.updated,',
'  lower(d.updated_by) updated_by,',
'  d.created,',
'  lower(d.created_by) created_by,',
'  sr.rep_first_name || '' '' || sr.rep_last_name as sales_rep_name,',
'  nvl((select sum(nvl(dp.quote_price, 0.00)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id), 0) as calculated_amount',
'from eba_sales_deals d',
'join eba_sales_customers c',
'  on c.id = d.customer_id',
'left join eba_sales_deal_status_codes dsc',
'  on dsc.id = d.deal_status_code_id',
'left join eba_sales_territories t',
'  on t.id = c.customer_territory_id',
'left join eba_sales_salesreps sr',
'  on sr.id = d.salesrep_id_01',
'where (deal_close_date < sysdate and deal_probability != 0 and deal_probability != 100)'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(8247917768449947330)
,p_name=>'Opportunities with No Account'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'Y'
,p_owner=>'MIKE'
,p_internal_uid=>2359332542035628180
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6761031643266942114)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6761032043697942115)
,p_db_column_name=>'ACCOUNT_ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Specified Account'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6761032497405942115)
,p_db_column_name=>'ROW_KEY'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Key'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6761032913623942116)
,p_db_column_name=>'DEAL_NAME'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Opportunity'
,p_column_link=>'f?p=&APP_ID.:80:&SESSION.::&DEBUG.:RP,80:P80_ID:#ID#'
,p_column_linktext=>'#DEAL_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6761033252331942116)
,p_db_column_name=>'DEAL_CLOSE_DATE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Close Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-YYYY'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6761033715837942116)
,p_db_column_name=>'DEAL_AMOUNT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Amount'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_required_patch=>-wwv_flow_imp.id(7204555145359641276)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7044109471417191786)
,p_db_column_name=>'CALCULATED_AMOUNT'
,p_display_order=>18
,p_column_identifier=>'AE'
,p_column_label=>'Amount'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(7204555145359641276)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6761034124056942117)
,p_db_column_name=>'DEAL_PROBABILITY'
,p_display_order=>28
,p_column_identifier=>'I'
,p_column_label=>'Probability'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6761034465244942117)
,p_db_column_name=>'STATUS_CODE'
,p_display_order=>38
,p_column_identifier=>'J'
,p_column_label=>'Stage'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6761034862976942118)
,p_db_column_name=>'TERRITORY_NAME'
,p_display_order=>48
,p_column_identifier=>'R'
,p_column_label=>'Acount Territory'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Territories''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6761035266310942118)
,p_db_column_name=>'TERRITORY_ID'
,p_display_order=>58
,p_column_identifier=>'S'
,p_column_label=>'Territory ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6761035701733942119)
,p_db_column_name=>'QTR'
,p_display_order=>68
,p_column_identifier=>'T'
,p_column_label=>'Quarter'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6761036123689942119)
,p_db_column_name=>'TAGS'
,p_display_order=>78
,p_column_identifier=>'U'
,p_column_label=>'Tags'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6761028450863942108)
,p_db_column_name=>'ACCOUNT'
,p_display_order=>88
,p_column_identifier=>'W'
,p_column_label=>'Account'
,p_column_link=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP,94:P94_ID:#ACCOUNT_ID#'
,p_column_linktext=>'#ACCOUNT#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6761029631929942110)
,p_db_column_name=>'UPDATED'
,p_display_order=>98
,p_column_identifier=>'Z'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_TIME_FMT.'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6761030037694942113)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>108
,p_column_identifier=>'AA'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6761030489791942113)
,p_db_column_name=>'CREATED'
,p_display_order=>118
,p_column_identifier=>'AB'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_TIME_FMT.'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6761030842074942114)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>128
,p_column_identifier=>'AC'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6761031284587942114)
,p_db_column_name=>'SALES_REP_NAME'
,p_display_order=>138
,p_column_identifier=>'AD'
,p_column_label=>'&REP_TITLE.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(8247920070183947384)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8724512'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'DEAL_NAME:ROW_KEY:QTR:STATUS_CODE:ACCOUNT:CALCULATED_AMOUNT:DEAL_PROBABILITY:'
,p_sort_column_1=>'DEAL_NAME'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'ROW_KEY'
,p_sort_direction_2=>'ASC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6761036921149942126)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8247917566306947328)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:131:&SESSION.::&DEBUG.:131,RIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp.component_end;
end;
/
