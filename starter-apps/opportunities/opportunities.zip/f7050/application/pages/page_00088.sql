prompt --application/pages/page_00088
begin
--   Manifest
--     PAGE: 00088
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>88
,p_name=>'Comments'
,p_alias=>'COMMENTS'
,p_page_mode=>'MODAL'
,p_step_title=>'Comments'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>'.t-Dialog-body {padding: 0; overflow: hidden;}'
,p_step_template=>2101883943284197310
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_dialog_css_classes=>'view-comments-dialog'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7375358139629863869)
,p_plug_name=>'Comments'
,p_static_id=>'comments'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders'
,p_plug_template=>2102002977963900996
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'  ''<a href="'' || apex_page.get_url(p_page => 22, p_items => ''P22_ID'', p_values => id) || ',
'      ''" title="Edit Comment"><span class="fa fa-edit" aria-hidden="true"></span></a>'' edit_comment,',
'  ''<a href="javascript:void(0)" data-comment-id="'' || id ||  ',
'      ''" title="Delete Comment" class="t-Button t-Button--small t-Button--danger t-Button--simple delete-comment">'' || ',
'      ''<span aria-hidden="true" class="t-Icon fa fa-trash-o"></span></a>'' delete_comment,',
'  replace(apex_escape.html(dbms_lob.substr(note,32767,1)),chr(10),''<br />'') note_text,',
'  lower(created_by) created_by,',
'  created',
'from eba_sales_comments',
'where (',
'  (:P88_ENTITY_TYPE = ''OPPORTUNITY'' and deal_id = :P88_ENTITY_ID)',
'    or (:P88_ENTITY_TYPE = ''TERRITORY'' and territory_id = :P88_ENTITY_ID)',
'    or (:P88_ENTITY_TYPE = ''LEAD'' and lead_id = :P88_ENTITY_ID)',
'    or (:P88_ENTITY_TYPE = ''ACCOUNT'' and account_id = :P88_ENTITY_ID)',
'    or (:P88_ENTITY_TYPE = ''CONTACT'' and contact_id = :P88_ENTITY_ID)',
'    or (:P88_ENTITY_TYPE = ''PRODUCT'' and product_id = :P88_ENTITY_ID)',
')'))
,p_plug_source_type=>'NATIVE_IR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(7375358235071863869)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'Y'
,p_internal_uid=>847271608500583059
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7375359443434863897)
,p_db_column_name=>'CREATED'
,p_display_order=>10
,p_column_identifier=>'K'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7375359140790863897)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6654731578594573075)
,p_db_column_name=>'DELETE_COMMENT'
,p_display_order=>31
,p_column_identifier=>'P'
,p_column_label=>'Delete'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'eba_sales_acl_api.get_authorization_level(:APP_USER) = 3'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6654731453036573074)
,p_db_column_name=>'EDIT_COMMENT'
,p_display_order=>21
,p_column_identifier=>'O'
,p_column_label=>'Edit'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'eba_sales_acl_api.get_authorization_level(:APP_USER) = 3'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7375362133105895192)
,p_db_column_name=>'ID'
,p_display_order=>11
,p_column_identifier=>'L'
,p_column_label=>'Selected Note'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7375358648773863896)
,p_db_column_name=>'NOTE_TEXT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Comment'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(7375359741707864483)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8472732'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'EDIT_COMMENT:NOTE_TEXT:CREATED_BY:CREATED:DELETE_COMMENT'
,p_sort_column_1=>'CREATED'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6580800359462348354)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(7375358139629863869)
,p_button_name=>'ADD_COMMENT'
,p_static_id=>'add-comment'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Comment'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:22:P22_ENTITY_TYPE,P22_ENTITY_ID:&P88_ENTITY_TYPE.,&P88_ENTITY_ID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8301180118038101580)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(7375358139629863869)
,p_button_name=>'RESET'
,p_static_id=>'reset'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&SESSION.::&DEBUG.:RP,&APP_PAGE_ID.,RIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6654729958838573059)
,p_name=>'P88_DELETE_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(7375358139629863869)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6654729875627573058)
,p_name=>'P88_ENTITY_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(7375358139629863869)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6654729730453573057)
,p_name=>'P88_ENTITY_TYPE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(7375358139629863869)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6654731800320573077)
,p_name=>'Delete Comment clicked'
,p_static_id=>'delete-comment-clicked'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.delete-comment'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_security_scheme=>wwv_flow_imp.id(9060292832695296381)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6654731904281573078)
,p_event_id=>wwv_flow_imp.id(6654731800320573077)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-confirm'
,p_action=>'NATIVE_CONFIRM'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'message', 'Are you sure you want to delete this comment?')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6654732052397573080)
,p_event_id=>wwv_flow_imp.id(6654731800320573077)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_static_id=>'native-execute-plsql-code'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'items_to_return', 'P88_DELETE_ID',
  'items_to_submit', 'P88_DELETE_ID',
  'language', 'PLSQL',
  'plsql_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'delete from eba_sales_comments',
    'where id = :P88_DELETE_ID;',
    '  ',
    ':P88_DELETE_ID := null;')),
  'show_processing', 'Y',
  'suppress_change_event', 'N')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6654732015160573079)
,p_event_id=>wwv_flow_imp.id(6654731800320573077)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'var commentId = $(this.triggeringElement).data(''comment-id'');',
    '',
    '$s(''P88_DELETE_ID'', commentId);')))).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6654732229884573082)
,p_event_id=>wwv_flow_imp.id(6654731800320573077)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code-2'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', 'apex.message.showPageSuccess(''Comment Deleted.'');')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6654732197974573081)
,p_event_id=>wwv_flow_imp.id(6654731800320573077)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7375358139629863869)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6581111868656245844)
,p_name=>'Dialog Closed'
,p_static_id=>'dialog-closed'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6581112784968245849)
,p_event_id=>wwv_flow_imp.id(6581111868656245844)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'if (this.data.REQUEST === ''CREATE'') {',
    '  apex.message.showPageSuccess(''Comment Added.'');',
    '} if (this.data.REQUEST === ''SAVE'') {',
    '  apex.message.showPageSuccess(''Comment Updated.'');',
    '} if (this.data.REQUEST === ''DELETE'') {',
    '  apex.message.showPageSuccess(''Comment Deleted.'');',
    '}')))).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6581112290610245848)
,p_event_id=>wwv_flow_imp.id(6581111868656245844)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7375358139629863869)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
