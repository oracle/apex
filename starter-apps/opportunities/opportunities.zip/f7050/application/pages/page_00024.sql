prompt --application/pages/page_00024
begin
--   Manifest
--     PAGE: 00024
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>24
,p_name=>'Contact'
,p_alias=>'CONTACT'
,p_step_title=>'Contact'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>1998361449248688088
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'Manage a contact''s details, links, attachments, and/or comments. You can also validate the contact.'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6614872701755760192)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10512992898526525834)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(6614872734240760193)
,p_name=>'Contact Details'
,p_template=>4501440665235496320
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_display_point=>'REGION_POSITION_02'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select cc.id,',
'  cc.row_key,',
'  cc.contact_name,',
'  cc.contact_title,',
'  cc.contact_email,',
'  cc.contact_phone,',
'  cc.contact_cell,',
'  cc.contact_address,',
'  cc.contact_description,',
'  cc.contact_linkedin,',
'  cc.contact_facebook,',
'  cc.tags,',
'  cc.created,',
'  cc.updated,',
'  lower(cc.created_by) created_by,',
'  lower(cc.updated_by) updated_by,',
'  c.id account_id,',
'  c.customer_name account_name',
'from eba_sales_customer_contacts cc',
'join eba_sales_customers c',
'  on c.id = cc.customer_id',
'where cc.id = :P24_ID'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2100515439059797523
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'no data found'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6614872870157760194)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6760984979414553357)
,p_query_column_id=>2
,p_column_alias=>'ROW_KEY'
,p_column_display_sequence=>2
,p_column_heading=>'Key'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6614872989132760195)
,p_query_column_id=>3
,p_column_alias=>'CONTACT_NAME'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8468987983652491673)
,p_query_column_id=>4
,p_column_alias=>'CONTACT_TITLE'
,p_column_display_sequence=>5
,p_column_heading=>'Title'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customer_contacts cc',
'  join eba_sales_customers c',
'    on c.id = cc.customer_id',
' where cc.id = :P24_ID',
'   and cc.contact_title is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6614873077192760196)
,p_query_column_id=>5
,p_column_alias=>'CONTACT_EMAIL'
,p_column_display_sequence=>6
,p_column_heading=>'Email'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customer_contacts cc',
'  join eba_sales_customers c',
'    on c.id = cc.customer_id',
' where cc.id = :P24_ID',
'   and cc.contact_email is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6614873188942760197)
,p_query_column_id=>6
,p_column_alias=>'CONTACT_PHONE'
,p_column_display_sequence=>7
,p_column_heading=>'Phone'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customer_contacts cc',
'  join eba_sales_customers c',
'    on c.id = cc.customer_id',
' where cc.id = :P24_ID',
'   and cc.contact_phone is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6614873300773760198)
,p_query_column_id=>7
,p_column_alias=>'CONTACT_CELL'
,p_column_display_sequence=>8
,p_column_heading=>'Cell'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customer_contacts cc',
'  join eba_sales_customers c',
'    on c.id = cc.customer_id',
' where cc.id = :P24_ID',
'   and cc.contact_cell is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6614873359404760199)
,p_query_column_id=>8
,p_column_alias=>'CONTACT_ADDRESS'
,p_column_display_sequence=>11
,p_column_heading=>'Address'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customer_contacts cc',
'  join eba_sales_customers c',
'    on c.id = cc.customer_id',
' where cc.id = :P24_ID',
'   and cc.contact_address is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6614873441973760200)
,p_query_column_id=>9
,p_column_alias=>'CONTACT_DESCRIPTION'
,p_column_display_sequence=>12
,p_column_heading=>'Description'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customer_contacts cc',
'  join eba_sales_customers c',
'    on c.id = cc.customer_id',
' where cc.id = :P24_ID',
'   and cc.contact_description is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6645387946810558851)
,p_query_column_id=>10
,p_column_alias=>'CONTACT_LINKEDIN'
,p_column_display_sequence=>9
,p_column_heading=>'LinkedIn'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customer_contacts cc',
'  join eba_sales_customers c',
'    on c.id = cc.customer_id',
' where cc.id = :P24_ID',
'   and cc.contact_linkedin is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6645388046446558852)
,p_query_column_id=>11
,p_column_alias=>'CONTACT_FACEBOOK'
,p_column_display_sequence=>10
,p_column_heading=>'Facebook'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customer_contacts cc',
'  join eba_sales_customers c',
'    on c.id = cc.customer_id',
' where cc.id = :P24_ID',
'   and cc.contact_facebook is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6645388861527558860)
,p_query_column_id=>12
,p_column_alias=>'TAGS'
,p_column_display_sequence=>13
,p_column_heading=>'Tags'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_sales_customer_contacts cc',
'  join eba_sales_customers c',
'    on c.id = cc.customer_id',
' where cc.id = :P24_ID',
'   and cc.tags is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6645388190534558853)
,p_query_column_id=>13
,p_column_alias=>'CREATED'
,p_column_display_sequence=>14
,p_column_heading=>'Created'
,p_column_format=>'SINCE'
,p_column_html_expression=>'#CREATED# by #CREATED_BY#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6645388290741558854)
,p_query_column_id=>14
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>15
,p_column_heading=>'Updated'
,p_column_format=>'SINCE'
,p_column_html_expression=>'#UPDATED# by #UPDATED_BY#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6645388381182558855)
,p_query_column_id=>15
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>16
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6645388434086558856)
,p_query_column_id=>16
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>17
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6645388948332558861)
,p_query_column_id=>17
,p_column_alias=>'ACCOUNT_ID'
,p_column_display_sequence=>18
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6645389064492558862)
,p_query_column_id=>18
,p_column_alias=>'ACCOUNT_NAME'
,p_column_display_sequence=>4
,p_column_heading=>'Account'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6645392357922558895)
,p_plug_name=>'Contact Actions'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-LinksList--actions:t-LinksList--showTopIcons'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_list_id=>wwv_flow_imp.id(6646667217846717928)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>4072361143931175087
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6645392863865558900)
,p_plug_name=>'RDS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8180070903200771885)
,p_plug_name=>'Validations'
,p_region_css_classes=>'js-validateRegion'
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--hiddenOverflow'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.verified_by,',
'  v.created',
'from eba_sales_verifications v',
'where contact_id = :P24_ID',
'order by v.created desc'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.VALIDATOR'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_required_patch=>wwv_flow_imp.id(7399339529259625523)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'f?p=&APP_ID.:146:&SESSION.::&DEBUG.:146:P146_ENTITY_TYPE,P146_ENTITY_ID:CONTACT,&P24_ID.',
  'attribute_02', 'f?p=&APP_ID.:147:&SESSION.::&DEBUG.:RP,147:P147_ENTITY_TYPE,P147_ENTITY_ID:CONTACT,&P24_ID.')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8186376302406397296)
,p_plug_name=>'Usage Metrics - 90 days'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select count(*) c,',
'  ''Views'' l,',
'  1 disp',
'from eba_sales_clicks',
'where contact_id = :P24_ID ',
'  and view_timestamp > sysdate - 90',
'union all',
'select count(distinct(app_username)) c,',
'  ''Users'' l,',
'  2 disp',
'from eba_sales_clicks',
'where contact_id = :P24_ID ',
'  and view_timestamp > sysdate - 90',
'order by disp'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_required_patch=>wwv_flow_imp.id(6646330002823433753)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'L',
  'attribute_02', 'C',
  'attribute_04', 'f?p=&APP_ID.:138:&SESSION.::&DEBUG.:138:P138_ENTITY_TYPE,P138_ENTITY_ID:CONTACT,&P24_ID.',
  'attribute_05', '2',
  'attribute_06', 'L',
  'attribute_07', 'DOT',
  'attribute_08', 'N')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6645388779084558859)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6614872701755760192)
,p_button_name=>'EDIT_CONTACT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Edit Contact'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:106:&SESSION.::&DEBUG.:RP,106:P106_ID,P106_SHOW_ACCOUNT,P106_DELETE_BRANCH_PAGE_ID:&P24_ID.,Y,23'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6654585054796913098)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10391275833983581906)
,p_button_name=>'POPATTACHMENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Add Attachment'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:99:&SESSION.::&DEBUG.:RP,99:P99_ENTITY_TYPE,P99_ENTITY_ID:CONTACT,&P24_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6654585499727913099)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10391275833983581906)
,p_button_name=>'VIEW_ATTACHMENTS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'View Attachments'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:92:&SESSION.::&DEBUG.:RP,92:P92_ENTITY_TYPE,P92_ENTITY_ID:CONTACT,&P24_ID.'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6646671680430732916)
,p_button_sequence=>240
,p_button_plug_id=>wwv_flow_imp.id(12657716489022517846)
,p_button_name=>'POP_LINK'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Add Link'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:RP,114:P114_ENTITY_TYPE,P114_ENTITY_ID:CONTACT,&P24_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6646672035591732917)
,p_button_sequence=>250
,p_button_plug_id=>wwv_flow_imp.id(12657716489022517846)
,p_button_name=>'VIEW_LINKS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'View Links'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:89:&SESSION.::&DEBUG.:RP,89:P89_ENTITY_TYPE,P89_ENTITY_ID:CONTACT,&P24_ID.'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6668280178633722716)
,p_button_sequence=>260
,p_button_plug_id=>wwv_flow_imp.id(9625526318213526612)
,p_button_name=>'POPCOMMENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Add Comment'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:RP,22:P22_ENTITY_TYPE,P22_ENTITY_ID:CONTACT,&P24_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6668280505068723451)
,p_button_sequence=>270
,p_button_plug_id=>wwv_flow_imp.id(9625526318213526612)
,p_button_name=>'VIEW_COMMENTS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'View Comments'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:88:&SESSION.::&DEBUG.:RP,88:P88_ENTITY_TYPE,P88_ENTITY_ID:CONTACT,&P24_ID.'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6645388593079558857)
,p_name=>'P24_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6614872734240760193)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6645389333355558865)
,p_name=>'Edit Contact dialog closed'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(6645388779084558859)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6645389467199558866)
,p_event_id=>wwv_flow_imp.id(6645389333355558865)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6614872734240760193)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6645389534135558867)
,p_event_id=>wwv_flow_imp.id(6645389333355558865)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.t-Breadcrumb-item.is-active > span'').text(this.data.P106_CONTACT_NAME);',
'',
'apex.message.showPageSuccess(''Action Processed.'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6646672555672737109)
,p_name=>'Handle No Data Found Regions'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6646672938834737112)
,p_event_id=>wwv_flow_imp.id(6646672555672737109)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(function() {',
'    ',
'  function toggleRegion() {',
'    var $region = $(this),',
'        noDataFound = $region.find(''.nodatafound'').length === 1;',
'      ',
'      //triggering after hide/show because that what the RDS response to',
'      if (noDataFound) {',
'        $region.hide();',
'        $region.trigger(''apexafterhide'');',
'      } else {',
'        $region.show();',
'        $region.trigger(''apexaftershow'');',
'      }',
'  }',
'  ',
'  function initHideShowRegions() {',
'    var $regions = $(''.js-dynamicHideShowRegion'');',
'        $rds = $(''.apex-rds'');',
'',
'    $regions',
'      .each(toggleRegion)',
'      .on(''apexafterrefresh'', toggleRegion);',
'',
'      //using visiblity over display to avoid DOM movement issues',
'      $rds.css(''visibility'', ''visibile'');',
'  } ',
'',
'  //using load because document.ready here goes before the RDS has added its listeners',
'  $(window).on(''theme42ready'',initHideShowRegions);',
' ',
'}())'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6646673337861738819)
,p_name=>'Page loaded and/or report refreshed'
,p_event_sequence=>30
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6646673800838738820)
,p_event_id=>wwv_flow_imp.id(6646673337861738819)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.t-Report-pagination--bottom'').each(function(){',
'  var $self = $(this);',
'  var links = $self.find(''a'');',
'  ',
'  if (links.length === 0) {',
'    $self.hide();',
'  } else {',
'    $self.show();',
'  }',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6646674210954740013)
,p_name=>'Link Details dialog closed'
,p_event_sequence=>40
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 114'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6678751108558798056)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Init page'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into eba_sales_clicks (',
'  entity_type,',
'  contact_id,',
'    app_username',
') values (',
'  ''CONTACT'',',
'  :P24_ID,',
'    lower(:APP_USER)',
');',
'',
'delete from eba_sales_clicks ',
'where view_timestamp < (sysdate - 90) ',
'  and contact_id = :P24_ID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>6661028916598044653
);
wwv_flow_imp.component_end;
end;
/
