prompt --application/pages/page_00035
begin
--   Manifest
--     PAGE: 00035
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>35
,p_name=>'Application Preferences'
,p_alias=>'APPLICATION-PREFERENCES'
,p_page_mode=>'MODAL'
,p_step_title=>'Application Preferences'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(9061991741235658343)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'Manage your application''s preferences. Set the title text used to describe representatives in your line of business.'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7540729528051545233)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7540730417092547151)
,p_plug_name=>'Preferences'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>1210
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7540730606009547153)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(7540729528051545233)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'CREATE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7540730683398547154)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(7540729528051545233)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(7540730897973547156)
,p_branch_name=>'Go to Administration'
,p_branch_action=>'f?p=&APP_ID.:settings:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7540730521755547152)
,p_name=>'P35_REP_TITLE'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(7540730417092547151)
,p_prompt=>'Representative Title'
,p_source=>'return eba_sales_fw.get_preference_value(''REP_TITLE'');'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'By default, the term "Sales Rep" is used in many places of this application but this title may not be appropriate for some lines of business. Use this preference to change this title to something more appropriate to your line of business (e.g. Accoun'
||'t Manager, Key Account Director, Global Consultant Advisor, etc...).'
,p_inline_help_text=>'The administrator changing this value will see the change immediately. Other users, however, will need to logout and log back in to see the change.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8450723444235107992)
,p_name=>'P35_SALES_LDR_TITLE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(7540730417092547151)
,p_item_default=>'Sales Leader'
,p_prompt=>'Sales Leader Title'
,p_source=>'return replace(eba_sales_fw.get_preference_value(''SALES_LDR_TITLE''),''Preference does not exist'',''Sales Leader'');'
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'By default, the term "Sales Leader" is used in many places of this application but this title may not be appropriate for some lines of business. Use this preference to change this title to something more appropriate to your line of business (e.g. Acc'
||'ount Manager, Key Account Director, Global Consultant Advisor, etc...).'
,p_inline_help_text=>'The administrator changing this value will see the change immediately. Other users, however, will need to logout and log back in to see the change.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(342662012576593093)
,p_name=>'CNX'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(7540730606009547153)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(342662090102593094)
,p_event_id=>wwv_flow_imp.id(342662012576593093)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7540730807131547155)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save Preference Values'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'eba_sales_fw.set_preference_value(''REP_TITLE'', :P35_REP_TITLE);',
'',
':REP_TITLE := apex_escape.html(eba_sales_fw.get_preference_value(''REP_TITLE''));',
'',
'eba_sales_fw.set_preference_value(''REP_TITLE_RAW'', :P35_REP_TITLE);',
'',
':REP_TITLE_RAW := eba_sales_fw.get_preference_value(''REP_TITLE_RAW'');',
'',
'eba_sales_fw.set_preference_value(''SALES_LDR_TITLE'', :P35_SALES_LDR_TITLE);',
'',
':SALES_LDR_TITLE := apex_escape.html(eba_sales_fw.get_preference_value(''SALES_LDR_TITLE''));'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Application preferences updated.'
,p_internal_uid=>7523008615170793752
);
wwv_flow_imp.component_end;
end;
/
