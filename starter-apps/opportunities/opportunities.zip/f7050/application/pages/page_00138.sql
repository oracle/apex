prompt --application/pages/page_00138
begin
--   Manifest
--     PAGE: 00138
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>138
,p_name=>'Usage Metrics'
,p_alias=>'USAGE-METRICS'
,p_page_mode=>'MODAL'
,p_step_title=>'Usage Metrics'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Dialog-body {padding: 0; overflow: hidden;}',
'.fc-month-button {display: none !important;}'))
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_required_patch=>wwv_flow_imp.id(6628607810862680350)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'18'
,p_last_upd_yyyymmddhh24miss=>'20220823161415'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6637011368373819692)
,p_plug_name=>'Report'
,p_region_name=>'report_region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343865001510915269)
,p_plug_display_sequence=>1210
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c.view_timestamp timestamp,',
'  c.view_timestamp viewed,',
'  lower(c.app_username) app_username',
'from eba_sales_clicks c',
'where (',
'  (:P138_ENTITY_TYPE = ''OPPORTUNITY'' and opp_id = :P138_ENTITY_ID)',
'    or (:P138_ENTITY_TYPE = ''TERRITORY'' and territory_id = :P138_ENTITY_ID)',
'    or (:P138_ENTITY_TYPE = ''LEAD'' and lead_id = :P138_ENTITY_ID)',
'    or (:P138_ENTITY_TYPE = ''ACCOUNT'' and cust_id = :P138_ENTITY_ID)',
'    or (:P138_ENTITY_TYPE = ''CONTACT'' and contact_id = :P138_ENTITY_ID)',
'    or (:P138_ENTITY_TYPE = ''PRODUCT'' and product_id = :P138_ENTITY_ID)',
')',
'  and c.view_timestamp > sysdate - 90',
'  and :P138_DISPLAY_AS = ''REPORT'''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P138_DISPLAY_AS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(6637011811866819696)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DAN'
,p_internal_uid=>766148777413253949
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6802489800925595750)
,p_db_column_name=>'APP_USERNAME'
,p_display_order=>10
,p_column_identifier=>'E'
,p_column_label=>'User'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6661028494156044649)
,p_db_column_name=>'TIMESTAMP'
,p_display_order=>20
,p_column_identifier=>'C'
,p_column_label=>'Timestamp'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6661028583809044650)
,p_db_column_name=>'VIEWED'
,p_display_order=>30
,p_column_identifier=>'D'
,p_column_label=>'Viewed'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(6661035353675045044)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'7901724'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'APP_USERNAME:VIEWED:TIMESTAMP:'
,p_sort_column_1=>'TIMESTAMP'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6661464769546240853)
,p_plug_name=>'Calendar'
,p_region_name=>'calendar_region'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(7343866444940915275)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null id,',
'    view_timestamp,',
'  trim(to_char(views,''999G999G999G990'')) || ',
'    case views',
'      when 1 then '' view''',
'      else '' views''',
'    end || ',
'    '' - '' ||',
'    trim(to_char(users,''999G999G999G990'')) || ',
'    case users',
'      when 1 then '' user''',
'      else '' users''',
'    end d',
'from (',
'  select trunc(view_timestamp) view_timestamp,',
'    count(*) views,',
'    count(distinct app_username) users',
'  from eba_sales_clicks',
'  where (',
'    (:P138_ENTITY_TYPE = ''OPPORTUNITY'' and opp_id = :P138_ENTITY_ID)',
'      or (:P138_ENTITY_TYPE = ''TERRITORY'' and territory_id = :P138_ENTITY_ID)',
'      or (:P138_ENTITY_TYPE = ''LEAD'' and lead_id = :P138_ENTITY_ID)',
'      or (:P138_ENTITY_TYPE = ''ACCOUNT'' and cust_id = :P138_ENTITY_ID)',
'      or (:P138_ENTITY_TYPE = ''CONTACT'' and contact_id = :P138_ENTITY_ID)',
'      or (:P138_ENTITY_TYPE = ''PRODUCT'' and product_id = :P138_ENTITY_ID)',
'  )',
'    and view_timestamp > sysdate - 90',
'    and :P138_DISPLAY_AS = ''CALENDAR''',
'  group by trunc(view_timestamp) ',
')'))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_ajax_items_to_submit=>'P138_DISPLAY_AS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'VIEW_TIMESTAMP'
,p_attribute_02=>'VIEW_TIMESTAMP'
,p_attribute_03=>'D'
,p_attribute_09=>'navigation'
,p_attribute_13=>'N'
,p_attribute_17=>'Y'
,p_attribute_19=>'Y'
,p_attribute_21=>'10'
,p_attribute_22=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6661464901357240854)
,p_plug_name=>'Region toggle'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--slimPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(7343855860694915257)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(586951119520840931)
,p_name=>'P138_ENTITY_TYPE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(6661464901357240854)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(586951232870840932)
,p_name=>'P138_ENTITY_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(6661464901357240854)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6661465027351240855)
,p_name=>'P138_DISPLAY_AS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6661464901357240854)
,p_item_default=>'CALENDAR'
,p_prompt=>'Display as'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:<span class="t-Icon fa fa-reorder" title="Report View"></span><span class="u-VisuallyHidden">Report</span>;REPORT'
,p_field_template=>wwv_flow_imp.id(7343885535981915309)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'3'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6661465265257240858)
,p_name=>'Display As changed'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P138_DISPLAY_AS'
,p_condition_element=>'P138_DISPLAY_AS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'CALENDAR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6661465625134240861)
,p_event_id=>wwv_flow_imp.id(6661465265257240858)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6637011368373819692)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6661465780985240863)
,p_event_id=>wwv_flow_imp.id(6661465265257240858)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6661464769546240853)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6661465370577240859)
,p_event_id=>wwv_flow_imp.id(6661465265257240858)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6661464769546240853)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6661465909484240864)
,p_event_id=>wwv_flow_imp.id(6661465265257240858)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6637011368373819692)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6661465711854240862)
,p_event_id=>wwv_flow_imp.id(6661465265257240858)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#calendar_region'').trigger(''apexrefresh'');'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6661465947883240865)
,p_event_id=>wwv_flow_imp.id(6661465265257240858)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#report_region'').trigger(''apexrefresh'');'
);
wwv_flow_imp.component_end;
end;
/
