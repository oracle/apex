prompt --application/pages/page_00129
begin
--   Manifest
--     PAGE: 00129
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_page(
 p_id=>129
,p_user_interface_id=>wwv_flow_api.id(6988712858842356549)
,p_name=>'Opportunities with No Assigned Products'
,p_alias=>'OPPORTUNITIES-WITH-NO-ASSIGNED-PRODUCTS'
,p_step_title=>'Opportunities with No Assigned Products'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_api.id(7357631458432990573)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'This is an interactive report identifying opportunities that do not specify any products. Click the <strong>Reset</strong> button to reset the interactive report. Click the <strong>Actions</strong> button to define the number of rows displayed per pa'
||'ge, filter, format, download, and/or save the interactive report.'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20210210140129'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7357752440326570980)
,p_plug_name=>'Opportunities with No Assigned Products'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7343865001510915269)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d.id,',
'  d.row_key,',
'  d.deal_name,',
'  t.id territory_id,',
'  t.territory_name,',
'  c.id account_id,',
'  c.customer_name account,',
'  case when apex_util.get_build_option_status(',
'                p_application_id    => :APP_ID,',
'                p_build_option_name => ''Opportunity Amount Set at Product Level''',
'            ) = ''EXCLUDE'' then',
'      d.deal_amount',
'  else',
'      nvl((select sum(nvl(dp.quote_price, 0.00)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id), 0)',
'  end as deal_amount,',
'  d.deal_probability,',
'  case',
'    when deal_probability > 0 and deal_probability < 100',
'    then ''Yes''',
'    else ''No''',
'  end open,',
'  deal_close_date,',
'  case',
'    when deal_close_date < sysdate and deal_probability != 0 and deal_probability != 100',
'    then ''Yes''',
'    else ''No''',
'  end past_due,',
'  d.qtr,',
'  dsc.status_code,',
'  d.tags,',
'  d.updated,',
'  lower(d.updated_by) updated_by,',
'  d.created,',
'  lower(d.created_by) created_by,',
'  sr.rep_first_name || '' '' || sr.rep_last_name as sales_rep_name',
'from eba_sales_deals d',
'join eba_sales_customers c',
'  on c.id = d.customer_id',
'left join eba_sales_deal_status_codes dsc',
'  on dsc.id = d.deal_status_code_id',
'left join eba_sales_territories t',
'  on t.id = c.customer_territory_id',
'left join eba_sales_salesreps sr',
'  on sr.id = d.salesrep_id_01',
'where d.id not in (',
'  select deal_id',
'  from eba_sales_deal_products',
')'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(7357752642469570982)
,p_name=>'Opportunities with No Account'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL'
,p_owner=>'MIKE'
,p_internal_uid=>847388207859043575
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7357752738755571027)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7357752852547571028)
,p_db_column_name=>'ACCOUNT_ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Specified Account'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7357752941944571031)
,p_db_column_name=>'ROW_KEY'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Key'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7357753263186571031)
,p_db_column_name=>'DEAL_NAME'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Opportunity'
,p_column_link=>'f?p=&APP_ID.:80:&SESSION.::&DEBUG.:RP,80:P80_ID:#ID#'
,p_column_linktext=>'#DEAL_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7357753336406571031)
,p_db_column_name=>'DEAL_CLOSE_DATE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Close Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-YYYY'
,p_tz_dependent=>'Y'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7357753448871571031)
,p_db_column_name=>'DEAL_AMOUNT'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Amount'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G990'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7357753536588571031)
,p_db_column_name=>'DEAL_PROBABILITY'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Probability'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7357753666427571032)
,p_db_column_name=>'STATUS_CODE'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Stage'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7357754462677571033)
,p_db_column_name=>'TERRITORY_NAME'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Account Territory'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Territories''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7357754542923571033)
,p_db_column_name=>'TERRITORY_ID'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Territory ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7357754639660571033)
,p_db_column_name=>'QTR'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Quarter'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(7357754745459571033)
,p_db_column_name=>'TAGS'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Tags'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6708497867022619292)
,p_db_column_name=>'ACCOUNT'
,p_display_order=>31
,p_column_identifier=>'W'
,p_column_label=>'Account'
,p_column_link=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP,94:P94_ID:#ACCOUNT_ID#'
,p_column_linktext=>'#ACCOUNT#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6708497989888619293)
,p_db_column_name=>'OPEN'
,p_display_order=>41
,p_column_identifier=>'X'
,p_column_label=>'Open'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6708498071525619294)
,p_db_column_name=>'PAST_DUE'
,p_display_order=>51
,p_column_identifier=>'Y'
,p_column_label=>'Past Due'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6708498215545619295)
,p_db_column_name=>'UPDATED'
,p_display_order=>61
,p_column_identifier=>'Z'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_TIME_FMT.'
,p_tz_dependent=>'Y'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6708498243798619296)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>71
,p_column_identifier=>'AA'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6708498367952619297)
,p_db_column_name=>'CREATED'
,p_display_order=>81
,p_column_identifier=>'AB'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_TIME_FMT.'
,p_tz_dependent=>'Y'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743262164843799948)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>91
,p_column_identifier=>'AC'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(6743262282287799949)
,p_db_column_name=>'SALES_REP_NAME'
,p_display_order=>101
,p_column_identifier=>'AD'
,p_column_label=>'&REP_TITLE.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(7357754944203571036)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8473906'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'DEAL_NAME:ROW_KEY:QTR:STATUS_CODE:ACCOUNT:DEAL_AMOUNT:DEAL_PROBABILITY:OPEN:PAST_DUE:'
,p_sort_column_1=>'DEAL_NAME'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'ROW_KEY'
,p_sort_direction_2=>'ASC'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(7357755364485571057)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(7343869008886915277)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(10495270706565772431)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(7343886820987915318)
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(7357771945307689987)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(7357752440326570980)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(7343886016830915316)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:129:&SESSION.::&DEBUG.:129,RIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_api.component_end;
end;
/
