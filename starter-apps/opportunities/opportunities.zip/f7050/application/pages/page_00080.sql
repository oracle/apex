prompt --application/pages/page_00080
begin
--   Manifest
--     PAGE: 00080
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>80
,p_name=>'Opportunity'
,p_alias=>'OPPORTUNITY'
,p_step_title=>'Opportunity'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(7234593954191374263)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_step_template=>1998361449248688088
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'Manage an opportunity''s details, products, competitors, team members, links, attachments, and/or comments. You can also validate the opportunity.'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6870117037811262773)
,p_plug_name=>'History'
,p_icon_css_classes=>'fa-clock-o'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info:t-Alert--accessibleHeading'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>1500
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_history varchar2(4000);',
'begin',
'    for c1 in',
'    (',
'        select',
'            ''<p class="audit-info">Last updated <strong>''||apex_util.get_since(updated)',
'                ||''</strong> by <strong>'' ||',
'                apex_escape.html(lower(updated_by))||''</strong>.',
'             <br />Created ''||apex_util.get_since(created) ||'' by ''||apex_escape.html(lower(created_by))',
'                ||''.</span>'' as history',
'          from eba_sales_deals',
'         where id = :P80_ID',
'    )',
'    loop',
'        l_history := c1.history;',
'    end loop;',
'    sys.htp.p( l_history );',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7367291337727761493)
,p_plug_name=>'Region Display Selector'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7396456035504411773)
,p_plug_name=>'Validations'
,p_region_css_classes=>'js-validateRegion'
,p_region_template_options=>'#DEFAULT#:t-Region--hiddenOverflow'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.verified_by,',
'  v.created',
'from eba_sales_verifications v',
'where opp_id = :P80_ID',
'order by v.created desc'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.VALIDATOR'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_required_patch=>wwv_flow_imp.id(7399339529259625523)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'f?p=&APP_ID.:146:&SESSION.::&DEBUG.:RP,146:P146_ENTITY_TYPE,P146_ENTITY_ID:OPPORTUNITY,&P80_ID.',
  'attribute_02', 'f?p=&APP_ID.:147:&SESSION.::&DEBUG.:RP,147:P147_ENTITY_TYPE,P147_ENTITY_ID:OPPORTUNITY,&P80_ID.')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8186285723196043713)
,p_plug_name=>'Usage Metrics - 90 days'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>60
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select count(*) c,',
'  ''Views'' l,',
'  1 disp',
'from eba_sales_clicks',
'where opp_id = :P80_ID ',
'  and view_timestamp > sysdate - 90',
'union all',
'select count(distinct(app_username)) c,',
'  ''Users'' l,',
'  2 disp',
'from eba_sales_clicks',
'where opp_id = :P80_ID ',
'  and view_timestamp > sysdate - 90',
'order by disp'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_required_patch=>wwv_flow_imp.id(6646330002823433753)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'L',
  'attribute_02', 'C',
  'attribute_04', 'f?p=&APP_ID.:138:&SESSION.::&DEBUG.:138:P138_ENTITY_TYPE,P138_ENTITY_ID:OPPORTUNITY,&P80_ID.',
  'attribute_05', '2',
  'attribute_06', 'L',
  'attribute_07', 'DOT',
  'attribute_08', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8859217044627288354)
,p_plug_name=>'Opportunity Actions'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-LinksList--actions:t-LinksList--showTopIcons'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_list_id=>wwv_flow_imp.id(6581178665957427082)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>4072361143931175087
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(8859225529092288361)
,p_name=>'Opportunity Details'
,p_template=>4501440665235496320
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_display_point=>'REGION_POSITION_02'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d.id,',
'  d.row_key,',
'  d.svp_id,',
'  t.id territory_id,',
'  t.territory_name,',
'  c.id account_id,',
'  c.customer_name account,',
'  d.deal_probability || ''%'' deal_probability,',
'  case',
'    when deal_probability > 0 and deal_probability < 100',
'    then ''Yes''',
'    else ''No''',
'  end open,',
'  case',
'    when deal_close_date < sysdate and deal_probability != 0 and deal_probability != 100',
'    then ''Yes''',
'    else ''No''',
'  end past_due,',
'  d.deal_amount,',
'  d.qtr || '' '' || ',
'    to_char(deal_close_date,''Day DD-MON-YYYY'') || ',
'    '' ('' || apex_util.get_since(deal_close_date) || '')'' deal_close_date,',
'  dsc.status_code,',
'  d.updated,',
'  lower(d.updated_by) updated_by,',
'  d.created,',
'  lower(d.created_by) created_by,',
'  sr.rep_first_name || '' '' || sr.rep_last_name as sales_rep_name,',
'  (select listagg(decode(inv.sold_as, ''SUBSCRIPTION'', ''Cloud Subscription ARR'', ''PURCHASE'', ''On-Premise Purchase'', ''TCV'', ''Cloud Subscription TCV'', inv.sold_as)',
'        || '': '' || to_char(inv.value, ''FML999G999G999G999G990''), chr(10))',
'        within group (order by inv.sold_as desc, inv.value)',
'from (  select p.sold_as, nvl(sum(dp.quote_price),0) value',
'        from eba_sales_deal_products dp, eba_sales_products p',
'        where dp.deal_id = :P80_ID',
'            and dp.product_id = p.id',
'        group by p.sold_as',
'        union all',
'        select ''TCV'', nvl(sum(dp.tcv),0) value',
'        from eba_sales_deal_products dp, eba_sales_products p',
'        where dp.deal_id = :P80_ID',
'            and dp.product_id = p.id',
'            and p.sold_as = ''SUBSCRIPTION''',
'    ) inv) as calculated_amount',
'from eba_sales_deals d',
'join eba_sales_customers c',
'  on c.id = d.customer_id',
'left join eba_sales_deal_status_codes dsc',
'  on dsc.id = d.deal_status_code_id',
'left join eba_sales_territories t',
'  on t.id = c.customer_territory_id',
'left join eba_sales_salesreps sr',
'  on sr.id = d.salesrep_id_01',
'where d.id = :P80_ID;'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>2100515439059797523
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'0'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8859692438012391958)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>12
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8859692530506391958)
,p_query_column_id=>2
,p_column_alias=>'ROW_KEY'
,p_column_display_sequence=>1
,p_column_heading=>'Key'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8468988093663491674)
,p_query_column_id=>3
,p_column_alias=>'SVP_ID'
,p_column_display_sequence=>19
,p_column_heading=>'SVP'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>'select null from eba_sales_deals where id = :P80_ID and svp_id is not null'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>'select svp_name, id from eba_sales_svps order by upper(svp_name)'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6610497897623787590)
,p_query_column_id=>4
,p_column_alias=>'TERRITORY_ID'
,p_column_display_sequence=>13
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8859693453854391958)
,p_query_column_id=>5
,p_column_alias=>'TERRITORY_NAME'
,p_column_display_sequence=>3
,p_column_heading=>'Account Territory'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXPRESSION'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Territories''',
') = ''INCLUDE'''))
,p_display_when_condition2=>'PLSQL'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6610498012185787591)
,p_query_column_id=>6
,p_column_alias=>'ACCOUNT_ID'
,p_column_display_sequence=>14
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6610498040371787592)
,p_query_column_id=>7
,p_column_alias=>'ACCOUNT'
,p_column_display_sequence=>2
,p_column_heading=>'Account'
,p_column_link=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP,94:P94_ID:#ACCOUNT_ID#'
,p_column_linktext=>'#ACCOUNT#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8859370050763312834)
,p_query_column_id=>8
,p_column_alias=>'DEAL_PROBABILITY'
,p_column_display_sequence=>8
,p_column_heading=>'Probability'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6610498189594787593)
,p_query_column_id=>9
,p_column_alias=>'OPEN'
,p_column_display_sequence=>10
,p_column_heading=>'Open'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6610498230067787594)
,p_query_column_id=>10
,p_column_alias=>'PAST_DUE'
,p_column_display_sequence=>4
,p_column_heading=>'Past Due'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8859369939686312834)
,p_query_column_id=>11
,p_column_alias=>'DEAL_AMOUNT'
,p_column_display_sequence=>6
,p_column_heading=>'Opportunity Amount'
,p_column_format=>'FML999G999G999G999G999G990'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>-wwv_flow_imp.id(7204555145359641276)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8859369833095312834)
,p_query_column_id=>12
,p_column_alias=>'DEAL_CLOSE_DATE'
,p_column_display_sequence=>5
,p_column_heading=>'Close Date'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8859370151062312834)
,p_query_column_id=>13
,p_column_alias=>'STATUS_CODE'
,p_column_display_sequence=>11
,p_column_heading=>'Stage'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6610498494204787596)
,p_query_column_id=>14
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>16
,p_column_heading=>'Updated'
,p_column_format=>'SINCE'
,p_column_html_expression=>'#UPDATED# by #UPDATED_BY#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6610498555674787597)
,p_query_column_id=>15
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>17
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6610498627354787598)
,p_query_column_id=>16
,p_column_alias=>'CREATED'
,p_column_display_sequence=>15
,p_column_heading=>'Created'
,p_column_format=>'SINCE'
,p_column_html_expression=>'#CREATED# by #CREATED_BY#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6610498816421787599)
,p_query_column_id=>17
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>18
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6614868721574760152)
,p_query_column_id=>18
,p_column_alias=>'SALES_REP_NAME'
,p_column_display_sequence=>9
,p_column_heading=>'&REP_TITLE.'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7044109039814191782)
,p_query_column_id=>19
,p_column_alias=>'CALCULATED_AMOUNT'
,p_column_display_sequence=>7
,p_column_heading=>'Amount by "Sold As"'
,p_column_format=>'FML999G999G999G999G990'
,p_column_html_expression=>'<div style="white-space:pre;">#CALCULATED_AMOUNT#</div>'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    null',
'  from EBA_SALES_DEAL_PRODUCTS dp,',
'       EBA_SALES_PRODUCTS p,',
'       EBA_SALES_PRODUCT_FAMILIES f',
' where dp.deal_id = :P80_ID ',
'   and dp.product_id = p.id',
'   and p.product_family_id = f.id (+)',
'   and dp.quote_price > 0'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>wwv_flow_imp.id(7204555145359641276)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8859227357681288362)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--showBreadcrumb:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10512992898526525834)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(8863952932789863499)
,p_name=>'Products'
,p_template=>4072358936313175081
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'js-dynamicHideShowRegion'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'t-Report--stretch:#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    dp.id,',
'    p.id as product_id,',
'    dp.deal_id,',
'    dp.tcv,',
'    dp.term,',
'    dp.close_date,',
'    dp.qtr,',
'    decode(p.sold_as, ''SUBSCRIPTION'', ''Cloud Subscription'', ''PURCHASE'', ''On-Premise Purchase'', p.sold_as) sold_as,',
'    p.product_name product,',
'    --p.product_description,',
'    dp.quote_price,',
'    dp.DEAL_PROD_DESCRIPTION description,',
'    --dp.DEAL_PROD_PROBABILITY product_probablity,',
'    dp.created,',
'    lower(dp.created_by) created_by,',
'    p.product_family_id',
'  from EBA_SALES_DEAL_PRODUCTS dp,',
'       EBA_SALES_PRODUCTS p,',
'       EBA_SALES_PRODUCT_FAMILIES f',
' where dp.deal_id = :P80_ID ',
'   and dp.product_id = p.id',
'   and p.product_family_id = f.id (+)',
' order by dp.updated desc'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'No products associated with this opportunity, click "+" icon to associate products'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
,p_required_patch=>wwv_flow_imp.id(10514207977421756031)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7044107307356191764)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7044108175222191773)
,p_query_column_id=>2
,p_column_alias=>'PRODUCT_ID'
,p_column_display_sequence=>14
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7044107334849191765)
,p_query_column_id=>3
,p_column_alias=>'DEAL_ID'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8040795955822792555)
,p_query_column_id=>4
,p_column_alias=>'TCV'
,p_column_display_sequence=>10
,p_column_heading=>'Total Contract Value'
,p_column_format=>'FML999G999G999G999G999'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>wwv_flow_imp.id(7204555145359641276)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8040796295129792558)
,p_query_column_id=>5
,p_column_alias=>'TERM'
,p_column_display_sequence=>9
,p_column_heading=>'Term'
,p_heading_alignment=>'LEFT'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(7038693393934140377)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>wwv_flow_imp.id(7204555145359641276)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6726141907330634190)
,p_query_column_id=>6
,p_column_alias=>'CLOSE_DATE'
,p_column_display_sequence=>12
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_required_patch=>wwv_flow_imp.id(7496430724341025700)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6726141973715634191)
,p_query_column_id=>7
,p_column_alias=>'QTR'
,p_column_display_sequence=>11
,p_column_heading=>'Quarter'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>wwv_flow_imp.id(7496430724341025700)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8040796886522792564)
,p_query_column_id=>8
,p_column_alias=>'SOLD_AS'
,p_column_display_sequence=>7
,p_column_heading=>'Sold As'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>wwv_flow_imp.id(7204555145359641276)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8863973151966878533)
,p_query_column_id=>9
,p_column_alias=>'PRODUCT'
,p_column_display_sequence=>3
,p_column_heading=>'Product'
,p_column_link=>'f?p=&APP_ID.:108:&SESSION.::&DEBUG.:RP,108:P108_ID:#ID#'
,p_column_linktext=>'#PRODUCT#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7044106969313191761)
,p_query_column_id=>10
,p_column_alias=>'QUOTE_PRICE'
,p_column_display_sequence=>8
,p_column_heading=>'Amount/ARR'
,p_column_format=>'FML999G999G999G999G999'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>wwv_flow_imp.id(7204555145359641276)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9029485835114207253)
,p_query_column_id=>11
,p_column_alias=>'DESCRIPTION'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8864314739640960072)
,p_query_column_id=>12
,p_column_alias=>'CREATED'
,p_column_display_sequence=>13
,p_column_heading=>'Added'
,p_column_format=>'SINCE'
,p_column_html_expression=>'#CREATED# by #CREATED_BY#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9029485043856190829)
,p_query_column_id=>13
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7475664097479567451)
,p_query_column_id=>14
,p_column_alias=>'PRODUCT_FAMILY_ID'
,p_column_display_sequence=>4
,p_column_heading=>'Family'
,p_heading_alignment=>'LEFT'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(6996144581841418999)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(8864397848775972200)
,p_name=>'Competition'
,p_template=>4072358936313175081
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'js-dynamicHideShowRegion'
,p_region_template_options=>'t-Region--noPadding:#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'t-Report--stretch:#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c.competitor_name competitor,',
'  dc.competition_desc,',
'  dc.competitor_threat_id,',
'  (',
'    select competitor_threat ',
'    from eba_sales_competitor_threats x ',
'    where x.id = dc.competitor_threat_id',
'  ) threat,',
'  dc.created,',
'  lower(dc.created_by) created_by',
'from eba_sales_deal_competition dc',
'join eba_sales_competitors c',
'  on c.id = dc.competitor_id',
'where dc.deal_id = :P80_ID'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'No competition identified, click "+" icon to add a competitor'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
,p_required_patch=>wwv_flow_imp.id(7418762851483053418)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8864417427219984876)
,p_query_column_id=>1
,p_column_alias=>'COMPETITOR'
,p_column_display_sequence=>1
,p_column_heading=>'Competitor'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8864417529593984876)
,p_query_column_id=>2
,p_column_alias=>'COMPETITION_DESC'
,p_column_display_sequence=>3
,p_column_heading=>'Description'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8864417643456984876)
,p_query_column_id=>3
,p_column_alias=>'COMPETITOR_THREAT_ID'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6726217809541372672)
,p_query_column_id=>4
,p_column_alias=>'THREAT'
,p_column_display_sequence=>2
,p_column_heading=>'Threat'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8864398337638972200)
,p_query_column_id=>5
,p_column_alias=>'CREATED'
,p_column_display_sequence=>5
,p_column_heading=>'Added'
,p_column_format=>'SINCE'
,p_column_html_expression=>'#CREATED# by #CREATED_BY#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6726217677226372671)
,p_query_column_id=>6
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(8864688229392042336)
,p_name=>'Team Members'
,p_template=>4072358936313175081
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'js-dynamicHideShowRegion'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.rep_first_name || '' '' || r.rep_last_name team_member,',
'  lower(r.rep_email) email,',
'  r2.role_name role,',
'  t.created,',
'  lower(t.created_by) created_by',
'from eba_sales_deal_team t',
'join eba_sales_salesreps r',
'  on r.id = t.rep_id',
'join eba_sales_salesrep_roles r2',
'  on r2.id = r.rep_role',
'where t.deal_id = :P80_ID'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'No team members assigned, click "+" icon to add a assign team members'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8864726957227059793)
,p_query_column_id=>1
,p_column_alias=>'TEAM_MEMBER'
,p_column_display_sequence=>1
,p_column_heading=>'Team Member'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6609503406090685263)
,p_query_column_id=>2
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>3
,p_column_heading=>'Email'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8864727031904059794)
,p_query_column_id=>3
,p_column_alias=>'ROLE'
,p_column_display_sequence=>2
,p_column_heading=>'Role'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6609503525064685264)
,p_query_column_id=>4
,p_column_alias=>'CREATED'
,p_column_display_sequence=>4
,p_column_heading=>'Added'
,p_column_format=>'SINCE'
,p_column_html_expression=>'#CREATED# by #CREATED_BY#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6609503538790685265)
,p_query_column_id=>5
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8859215647910288352)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(8859227357681288362)
,p_button_name=>'SIDE_MAKE_DECISION'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Close Won / Lost'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:79:&SESSION.::&DEBUG.:79:P79_ID:&P80_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from EBA_SALES_OPPORTUNITIES_V',
'where id = :P80_ID and DEAL_PROBABILITY > 0 and DEAL_PROBABILITY < 100'))
,p_button_condition_type=>'EXISTS'
,p_button_css_classes=>'uButtonAlt'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8859215431536288351)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(8859227357681288362)
,p_button_name=>'SIDE_EDIT_OPP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Edit Opportunity'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:RP,16:P16_ID:&P80_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from EBA_SALES_OPPORTUNITIES_V',
'where (id = :P80_ID and DEAL_PROBABILITY > 0 and DEAL_PROBABILITY < 100)',
'or',
'eba_sales_acl_api.get_authorization_level(:APP_USER) = 3;'))
,p_button_condition_type=>'EXISTS'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8859220247039288357)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10391275833983581906)
,p_button_name=>'POPATTACHMENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Add Attachment'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:99:&SESSION.::&DEBUG.:RP,99:P99_ENTITY_TYPE,P99_ENTITY_ID:OPPORTUNITY,&P80_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8859220426731288358)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10391275833983581906)
,p_button_name=>'VIEW_ATTACHMENTS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'View Attachments'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:92:&SESSION.::&DEBUG.:RP,92:P92_ENTITY_TYPE,P92_ENTITY_ID:OPPORTUNITY,&P80_ID.'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8863953851935863502)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(8863952932789863499)
,p_button_name=>'POP_PRODUCT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Add Product'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:108:&SESSION.::&DEBUG.:RP,108:P108_DEAL_ID:&P80_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8863953635699863502)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(8863952932789863499)
,p_button_name=>'VIEW_OPP_PRODUCTS'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'View Products'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:85:&SESSION.:::9,85:P85_ID:&P80_ID.'
,p_icon_css_classes=>'fa-chevron-right'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8864398654721972201)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(8864397848775972200)
,p_button_name=>'POP_COMP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Add Competition'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:RP:P27_DEAL_ID:&P80_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8864398436655972200)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(8864397848775972200)
,p_button_name=>'VIEW_COMP'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'View Competition'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:86:&SESSION.:::86:P86_ID:&P80_ID.'
,p_icon_css_classes=>'fa-chevron-right'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8864689026956042337)
,p_button_sequence=>160
,p_button_plug_id=>wwv_flow_imp.id(8864688229392042336)
,p_button_name=>'POP_TEAM'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Add Team Member'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:RP:P30_DEAL_ID:&P80_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8864688833279042336)
,p_button_sequence=>170
,p_button_plug_id=>wwv_flow_imp.id(8864688229392042336)
,p_button_name=>'VIEW_TEAM_MEMBERS'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'View Team'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:87:&SESSION.:::87:P87_ID:&P80_ID.'
,p_icon_css_classes=>'fa-chevron-right'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8859218932808288356)
,p_button_sequence=>200
,p_button_plug_id=>wwv_flow_imp.id(9625526318213526612)
,p_button_name=>'POPCOMMENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Add Comment'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:RP,22:P22_ENTITY_TYPE,P22_ENTITY_ID:OPPORTUNITY,&P80_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8859218734721288356)
,p_button_sequence=>210
,p_button_plug_id=>wwv_flow_imp.id(9625526318213526612)
,p_button_name=>'VIEW_COMMENTS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'View Comments'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:88:&SESSION.::&DEBUG.:RP,88:P88_ENTITY_TYPE,P88_ENTITY_ID:OPPORTUNITY,&P80_ID.'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8859221559009288358)
,p_button_sequence=>240
,p_button_plug_id=>wwv_flow_imp.id(12657716489022517846)
,p_button_name=>'POP_LINK'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Add Link'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:RP,114:P114_ENTITY_TYPE,P114_ENTITY_ID:OPPORTUNITY,&P80_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8859221330469288358)
,p_button_sequence=>250
,p_button_plug_id=>wwv_flow_imp.id(12657716489022517846)
,p_button_name=>'VIEW_LINKS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'View Links'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:89:&SESSION.::&DEBUG.:RP:P89_ENTITY_TYPE,P89_ENTITY_ID:OPPORTUNITY,&P80_ID.'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8859228931762288370)
,p_branch_action=>'f?p=&APP_ID.:80:&SESSION.::&DEBUG.::P80_ID:&P80_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_comment=>'Created 11-JAN-2012 16:02 by MIKE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8859216848554288353)
,p_name=>'P80_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8859225529092288361)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(8866605126788353823)
,p_computation_sequence=>10
,p_computation_item=>'P16_ID'
,p_computation_point=>'AFTER_FOOTER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'&P80_ID.'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(8859228158246288366)
,p_computation_sequence=>20
,p_computation_item=>'LAST_PAGE'
,p_computation_point=>'AFTER_FOOTER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'80'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6578960043077489359)
,p_name=>'Edit Opportunity dialog closed'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 16'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6578960951897489359)
,p_event_id=>wwv_flow_imp.id(6578960043077489359)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8859225529092288361)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6578960469218489359)
,p_event_id=>wwv_flow_imp.id(6578960043077489359)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.t-Breadcrumb-item.is-active > span'').text(this.data.P16_DEAL_NAME);',
'apex.message.showPageSuccess(''Action Processed.'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6506045038728540876)
,p_name=>'Refresh Products'
,p_event_sequence=>40
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 108'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6506045146880540877)
,p_event_id=>wwv_flow_imp.id(6506045038728540876)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8863952932789863499)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3481986788602926391)
,p_event_id=>wwv_flow_imp.id(6506045038728540876)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8859225529092288361)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6560181331374791592)
,p_name=>'Refresh Competition'
,p_event_sequence=>50
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 27'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6560181461116791593)
,p_event_id=>wwv_flow_imp.id(6560181331374791592)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8864397848775972200)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3481986937824926392)
,p_event_id=>wwv_flow_imp.id(6560181331374791592)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8859225529092288361)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6560181623793791594)
,p_name=>'Refresh Team'
,p_event_sequence=>60
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 30'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6560181633723791595)
,p_event_id=>wwv_flow_imp.id(6560181623793791594)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8864688229392042336)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3481986998246926393)
,p_event_id=>wwv_flow_imp.id(6560181623793791594)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8859225529092288361)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6580801118480348361)
,p_name=>'Refresh Updates'
,p_event_sequence=>90
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 22'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6580801327200348364)
,p_name=>'Refresh Validations'
,p_event_sequence=>100
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId ===127'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6580801509911348365)
,p_event_id=>wwv_flow_imp.id(6580801327200348364)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7396456035504411773)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7044109781394191789)
,p_name=>'Refresh Reports after Edit'
,p_event_sequence=>110
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(8863952932789863499)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7044109886760191790)
,p_event_id=>wwv_flow_imp.id(7044109781394191789)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8863952932789863499)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7044110018299191791)
,p_event_id=>wwv_flow_imp.id(7044109781394191789)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8859225529092288361)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7044110086658191792)
,p_name=>'Refresh Reports after add'
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8863953851935863502)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7044110147323191793)
,p_event_id=>wwv_flow_imp.id(7044110086658191792)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8863952932789863499)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7044110260619191794)
,p_event_id=>wwv_flow_imp.id(7044110086658191792)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8859225529092288361)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7396098145103363144)
,p_process_sequence=>70
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Init page'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into eba_sales_clicks (',
'    entity_type,',
'    opp_id,',
'    app_username  ',
') values (',
'    ''OPPORTUNITY'',',
'    :P80_ID,',
'    lower(:APP_USER)',
');',
'',
'delete from eba_sales_clicks ',
'where view_timestamp < (sysdate - 90) ',
'  and opp_id = :P80_ID;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>7378375953142609741
);
wwv_flow_imp.component_end;
end;
/
