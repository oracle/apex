prompt --application/pages/page_00019
begin
--   Manifest
--     PAGE: 00019
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>19
,p_name=>'Leads'
,p_alias=>'LEADS'
,p_step_title=>'Leads'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(7216871863962621378)
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// standard, cacheable elements',
'var timeout = 0; // used for debounce on search',
'var CONTAINER_SEL = ''.t-Form-fieldContainer'';',
'var pagePrefix = ''P'' + $(''#pFlowStepId'').val();',
'var displayAsId = pagePrefix + ''_DISPLAY_AS'';',
'var $displayAs = $(''#'' + displayAsId);',
'var $body = $(''.t-PageBody'');',
'var $search = $(''#'' + pagePrefix + ''_SEARCH'');',
'var $sort = $(''#'' + pagePrefix + ''_SORT'');',
'var $reset = $(''#reset_button'');',
'var $cardsReg = $(''#cards_region'');',
'var $reportReg = $(''#report_region'');',
'var $gridReg = $(''#grid_region'');',
'',
'// custom items (will vary by page)',
'var $territory = $(''#'' + pagePrefix + ''_TERRITORY_ID'');',
'var $account = $(''#'' + pagePrefix + ''_ACCOUNT_ID'');',
'var $source = $(''#'' + pagePrefix + ''_SOURCE_ID'');',
'var $status = $(''#'' + pagePrefix + ''_STATUS_ID'');',
'',
'function showLeftColumn() {',
'  $body',
'    .removeClass(''t-PageBody--hideLeft'')',
'    .addClass(''t-PageBody--showLeft'');',
'    ',
'  // Takes 200ms to hide column',
'  setTimeout(function() {',
'    // Ensure column headers align correctly',
'    $(window).trigger(''apexwindowresized'');',
'  }, 250);',
'}',
'',
'function hideLeftColumn() {',
'  $body',
'    .removeClass(''t-PageBody--showLeft'')',
'    .addClass(''t-PageBody--hideLeft'');',
'    ',
'  // Takes 200ms to hide column',
'  setTimeout(function() {',
'    // Ensure column headers align correctly',
'    $(window).trigger(''apexwindowresized'');',
'  }, 250);',
'}',
'  ',
'// applyFilters triggers the refresh event on the correct region',
'function applyFilters() {',
'  var display = $v(displayAsId);',
'  ',
'  if (display === ''CARDS'') {',
'    $cardsReg.trigger(''apexrefresh'');',
'  } else if (display === ''REPORT'') {',
'    $reportReg.trigger(''apexrefresh'');',
'  } else if (display === ''GRID'') {',
'    $gridReg.trigger(''apexrefresh'');',
'  }',
'}',
'',
'// toggleRegionDisplay is similar to applyFilters except that it also',
'// takes into account what regions or items need to be displayed or hidden',
'function toggleRegionDisplay(refresh) {',
'  var display = $v(displayAsId);',
'  ',
'  refresh = (refresh === false) ? false : true;',
'  ',
'  if (display === ''CARDS'') {',
'    $reportReg.hide();',
'    $gridReg.hide();',
'',
'    showLeftColumn();',
'',
'    $sort.closest(CONTAINER_SEL).show();',
'',
'    if (refresh) {',
'      $cardsReg.trigger(''apexrefresh'');',
'    }',
'    ',
'    $cardsReg.show();',
'  } else if (display === ''REPORT'') {',
'    $sort.closest(CONTAINER_SEL).hide();',
'    $cardsReg.hide();',
'    $gridReg.hide();',
'',
'    showLeftColumn();',
'',
'    if (refresh) {',
'      $reportReg.trigger(''apexrefresh'');',
'    }',
'',
'    $reportReg.show();',
'  } else if (display === ''GRID'') {',
'    $sort.closest(CONTAINER_SEL).hide();',
'    $cardsReg.hide();',
'    $reportReg.hide();',
'',
'    hideLeftColumn();',
'',
'    if (refresh) {',
'      $gridReg.trigger(''apexrefresh'');',
'    }',
'',
'    $gridReg.show();',
'  }',
'}',
'  ',
'function debounceSearch(e) {',
'    /*',
'     * Prevent search for following keys:',
'     * TAB:     9',
'     * SHIFT:   16',
'     * LEFT:    37',
'     * RIGHT:   39',
'     */',
'    if ( e.which === 9 || e.which === 16 || e.which === 37 || e.which === 39 ) {',
'        return false;',
'    }',
'    clearTimeout(timeout);',
'    timeout = setTimeout(applyFilters, 250);',
'}',
'  ',
'function preventSubmitOnEnter(e) {',
'  if (e.which === 13) {',
'    return false;',
'  }',
'}',
'',
'function resetFilters() {',
'  $search.val(null);',
'  $territory.val(null);',
'  $account.val(null);',
'  $source.val(null);',
'  $status.val(null);',
'  ',
'  $sort.val(''NAME'');',
'',
'  applyFilters();',
'}',
'',
'// standard search event bindings',
'$search.keydown(preventSubmitOnEnter);',
'$search.keyup(debounceSearch);',
'',
'// dynamic event bindings (will vary by filter page)',
'$territory.change(applyFilters);',
'$account.change(applyFilters);',
'$source.change(applyFilters);',
'$status.change(applyFilters);',
'',
'// standard display, sort, reset event bindings',
'$displayAs.change(toggleRegionDisplay);',
'$sort.change(applyFilters);',
'$reset.click(resetFilters);',
'  ',
'toggleRegionDisplay(false);'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Card-initials {',
'  font-size: 14px;',
'}'))
,p_step_template=>wwv_flow_imp.id(7343828740328915198)
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(7401034857403255410)
,p_protection_level=>'C'
,p_help_text=>'Use the filters on the left to show different results in the region on the right. The right region can be displayed in one of three ways (Cards View, Report View, and Customizable Grid) by using the display-mode buttons located just to the left of th'
||'e <strong>Create Lead</strong> button. Filters are not displayed in the Customizable Grid view.'
,p_page_component_map=>'18'
,p_last_upd_yyyymmddhh24miss=>'20220823161415'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(712146672081237601)
,p_plug_name=>'Hidden'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343855668783915255)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<br />'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6460176100937277949)
,p_plug_name=>'Filters'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(7343866444940915275)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(6460176151288277950)
,p_name=>'Leads Report'
,p_region_name=>'report_region'
,p_template=>wwv_flow_imp.id(7343866444940915275)
,p_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_region_attributes=>'style="display: none"'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select l.id, ',
'  l.row_key,',
'  nvl(l.lead_priority, 5) lead_priority,',
'  opportunity_id,',
'  case ',
'    when opportunity_id is null',
'    then ''<a href="'' || apex_util.prepare_url(''f?p=&APP_ID.:63:&APP_SESSION.:::63:P63_LEAD_ID:'' || l.id) || ''" class="t-Button t-Button--small t-Button--hot t-Button--simple t-Button--stretch">Convert</a>''',
'    else ''<a href="'' || apex_util.prepare_url(''f?p=&APP_ID.:80:&APP_SESSION.:::80:P80_ID:'' || l.opportunity_id) ||''" class="t-Button t-Button--small t-Button--hot t-Button--simple t-Button--stretch">Opportunity</a>''',
'  end action,',
'  c.customer_name account_name,',
'  slsc.status_code lead_status,',
'  ls.lead_source,',
'  l.updated,',
'  t.territory_name,',
'  case',
'    when length(l.lead_details) <= 50',
'    then l.lead_details',
'    else substr(l.lead_details, 1, 50) || ''...''',
'  end lead_details,',
'  l.lead_name_01 name',
'from eba_sales_leads l',
'left join eba_sales_customers c',
'  on c.id = l.account_id',
'left join eba_sales_territories t',
'  on t.id = c.customer_territory_id ',
'left join eba_sales_lead_status_codes slsc',
'  on slsc.id = l.lead_status_id',
'left join eba_sales_lead_sources ls',
'  on ls.id = l.lead_source_id',
'where :P19_DISPLAY_AS = ''REPORT''',
'  and (',
'    :P19_SEARCH is null',
'      or instr(lower(l.lead_name_01), lower(:P19_SEARCH)) > 0',
'      or instr(lower(l.row_key), lower(:P19_SEARCH)) > 0',
'      or instr(lower(l.lead_details), lower(:P19_SEARCH)) > 0',
'      or instr(lower(c.customer_name), lower(:P19_SEARCH)) > 0',
'      or instr(lower(t.territory_name), lower(:P19_SEARCH)) > 0',
'      or instr(lower(l.lead_priority), lower(:P19_SEARCH)) > 0',
'      or instr(lower(slsc.status_code), lower(:P19_SEARCH)) > 0',
'      or instr(upper(apex_util.get_since(l.updated)), upper(:P19_SEARCH)) > 0',
'  )',
'  and (:P19_TERRITORY_ID is null or t.id = :P19_TERRITORY_ID)',
'  and (:P19_ACCOUNT_ID is null or c.id = :P19_ACCOUNT_ID)',
'  and (:P19_SOURCE_ID is null or ls.id = :P19_SOURCE_ID)',
'  and (:P19_STATUS_ID is null or slsc.id = :P19_STATUS_ID)'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P19_SEARCH,P19_TERRITORY_ID,P19_ACCOUNT_ID,P19_SOURCE_ID,P19_STATUS_ID,P19_DISPLAY_AS'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(7343873253436915289)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'No leads found'
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6520925711627296757)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6520925804546296758)
,p_query_column_id=>2
,p_column_alias=>'ROW_KEY'
,p_column_display_sequence=>3
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6520925905880296759)
,p_query_column_id=>3
,p_column_alias=>'LEAD_PRIORITY'
,p_column_display_sequence=>7
,p_column_heading=>'Priority'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6520925955940296760)
,p_query_column_id=>4
,p_column_alias=>'OPPORTUNITY_ID'
,p_column_display_sequence=>12
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6520926095869296761)
,p_query_column_id=>5
,p_column_alias=>'ACTION'
,p_column_display_sequence=>9
,p_column_heading=>'Action'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_report_column_required_role=>wwv_flow_imp.id(9042571137027542978)
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6520926251065296763)
,p_query_column_id=>6
,p_column_alias=>'ACCOUNT_NAME'
,p_column_display_sequence=>5
,p_column_heading=>'Account'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6520926439624296765)
,p_query_column_id=>7
,p_column_alias=>'LEAD_STATUS'
,p_column_display_sequence=>8
,p_column_heading=>'Status'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6520926600636296766)
,p_query_column_id=>8
,p_column_alias=>'LEAD_SOURCE'
,p_column_display_sequence=>11
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6520927318373296773)
,p_query_column_id=>9
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>10
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_default_sort_dir=>'desc'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6520926819922296768)
,p_query_column_id=>10
,p_column_alias=>'TERRITORY_NAME'
,p_column_display_sequence=>6
,p_column_heading=>'Account Territory'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6520926856558296769)
,p_query_column_id=>11
,p_column_alias=>'LEAD_DETAILS'
,p_column_display_sequence=>4
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6520927085367296771)
,p_query_column_id=>12
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Lead'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:133:&SESSION.::&DEBUG.:RP,133:P133_ID:#ID#'
,p_column_linktext=>'#NAME#'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(6460177837571277967)
,p_name=>'Leads Cards'
,p_region_name=>'cards_region'
,p_template=>wwv_flow_imp.id(7343855668783915255)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--basic:t-Cards--displayInitials:t-Cards--3cols:t-Cards--animColorFill'
,p_region_attributes=>'style="display: none"'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with base_leads as (',
'  select l.id,',
'    l.row_key,',
'    l.lead_name_01 lead_name,',
'    l.lead_details,',
'    c.id account_id,',
'    c.customer_name account_name,',
'    ls.lead_source,',
'    lsc.status_code,',
'    l.updated,',
'    l.tags',
'  from eba_sales_leads l',
'  left join eba_sales_customers c',
'    on c.id = l.account_id',
'  left join eba_sales_territories t',
'    on t.id = c.customer_territory_id ',
'  left join eba_sales_lead_sources ls',
'    on ls.id = l.lead_source_id',
'  left join eba_sales_lead_status_codes lsc',
'    on lsc.id = l.lead_status_id',
'  where :P19_DISPLAY_AS = ''CARDS''',
'    and (',
'      :P19_TERRITORY_ID is null ',
'        or c.customer_territory_id = :P19_TERRITORY_ID',
'    )',
'    and (',
'      :P19_ACCOUNT_ID is null ',
'        or c.id = :P19_ACCOUNT_ID',
'    )',
'    and (',
'      :P19_SOURCE_ID is null ',
'        or ls.id = :P19_SOURCE_ID',
'    )',
'    and (',
'      :P19_STATUS_ID is null ',
'        or lsc.id = :P19_STATUS_ID',
'    )',
'),',
'card_details as (',
'  select lead_name card_title,',
'    null card_icon,',
'    row_key card_initials,',
'    null card_text,',
'    case ',
'      when length(lead_details) < 50',
'      then lead_details',
'      else substr(lead_details, 1, 50) || ''...''',
'    end card_text_p1,',
'    ''Source: '' || lead_source card_text_p2,',
'    ''Status: '' || status_code card_text_p3,',
'    apex_util.prepare_url(',
'      ''f?p='' ||',
'      :APP_ID ||',
'      '':133:'' ||',
'      :APP_SESSION ||',
'      '':::133,RP:P133_ID:'' ||',
'      id',
'    ) card_link,',
'    updated card_subtext,',
'    account_name,',
'    updated,',
'    tags,',
'    lead_details',
'  from base_leads',
')',
'select *',
'from card_details',
'where (',
'    :P19_SEARCH is null',
'      or instr(upper(card_title), upper(:P19_SEARCH)) > 0',
'      or instr(upper(card_initials), upper(:P19_SEARCH)) > 0',
'      or instr(upper(card_text_p2), upper(:P19_SEARCH)) > 0',
'      or instr(upper(card_text_p3), upper(:P19_SEARCH)) > 0',
'      or instr(upper(''Updated: '' || apex_util.get_since(updated)), upper(:P19_SEARCH)) > 0',
'      or instr(upper(tags), upper(:P19_SEARCH)) > 0',
'      or instr(upper(lead_details), upper(:P19_SEARCH)) > 0',
'  )',
'order by',
'  case :P19_SORT',
'    when ''NAME'' then card_title',
'  end,',
'  case :P19_SORT',
'    when ''UPDATED'' then updated',
'  end desc'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P19_SEARCH,P19_TERRITORY_ID,P19_ACCOUNT_ID,P19_SOURCE_ID,P19_STATUS_ID,P19_DISPLAY_AS'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(7400884047268179746)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'No leads found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6460178010116277968)
,p_query_column_id=>1
,p_column_alias=>'CARD_TITLE'
,p_column_display_sequence=>1
,p_column_heading=>'Card title'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6460178231027277970)
,p_query_column_id=>2
,p_column_alias=>'CARD_ICON'
,p_column_display_sequence=>2
,p_column_heading=>'Card icon'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6460178488486277973)
,p_query_column_id=>3
,p_column_alias=>'CARD_INITIALS'
,p_column_display_sequence=>5
,p_column_heading=>'Card initials'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6460178308864277971)
,p_query_column_id=>4
,p_column_alias=>'CARD_TEXT'
,p_column_display_sequence=>3
,p_column_heading=>'Card text'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#CARD_TEXT_P1#<br >',
'<small>',
'#CARD_TEXT_P2#<br />',
'#CARD_TEXT_P3#<br />',
'</small>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6588354927810951812)
,p_query_column_id=>5
,p_column_alias=>'CARD_TEXT_P1'
,p_column_display_sequence=>7
,p_column_heading=>'Card Text P1'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6588355254691951812)
,p_query_column_id=>6
,p_column_alias=>'CARD_TEXT_P2'
,p_column_display_sequence=>8
,p_column_heading=>'Card Text P2'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6588355726777951813)
,p_query_column_id=>7
,p_column_alias=>'CARD_TEXT_P3'
,p_column_display_sequence=>9
,p_column_heading=>'Card Text P3'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6407139402265009689)
,p_query_column_id=>8
,p_column_alias=>'CARD_LINK'
,p_column_display_sequence=>6
,p_column_heading=>'Card link'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6460178354871277972)
,p_query_column_id=>9
,p_column_alias=>'CARD_SUBTEXT'
,p_column_display_sequence=>4
,p_column_heading=>'Card subtext'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_column_html_expression=>'Updated: #CARD_SUBTEXT#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6588356125628951813)
,p_query_column_id=>10
,p_column_alias=>'ACCOUNT_NAME'
,p_column_display_sequence=>10
,p_column_heading=>'Account Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6588356475546951813)
,p_query_column_id=>11
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>11
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6588356877440951814)
,p_query_column_id=>12
,p_column_alias=>'TAGS'
,p_column_display_sequence=>12
,p_column_heading=>'Tags'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6588357243044951814)
,p_query_column_id=>13
,p_column_alias=>'LEAD_DETAILS'
,p_column_display_sequence=>13
,p_column_heading=>'Lead Details'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6585011611398530581)
,p_plug_name=>'Leads Grid'
,p_region_name=>'grid_region'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343865001510915269)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select l.id, ',
'  l.row_key,',
'  l.lead_priority,',
'  l.lead_name_01 lead,',
'  l.opportunity_id,',
'  case ',
'    when opportunity_id is null',
'    then ''<a href="'' || apex_util.prepare_url(''f?p=&APP_ID.:63:&APP_SESSION.:::63:P63_LEAD_ID:'' || l.id) || ''" class="t-Button t-Button--small t-Button--hot t-Button--simple t-Button--stretch">Convert</a>''',
'    else ''<a href="'' || apex_util.prepare_url(''f?p=&APP_ID.:80:&APP_SESSION.:::80:P80_ID:'' || l.opportunity_id) ||''" class="t-Button t-Button--small t-Button--hot t-Button--simple t-Button--stretch">Opportunity</a>''',
'  end action,',
'  l.tags,',
'  (',
'    select count(*)',
'    from eba_sales_links',
'    where lead_id = l.id',
'  ) links,',
'  (',
'    select count(*)',
'    from eba_sales_files',
'    where lead_id = l.id',
'  ) attachments,',
'  (',
'    select count(*)',
'    from eba_sales_comments',
'    where lead_id = l.id',
'  ) comments,',
'  (',
'    select count(*)',
'    from eba_sales_verifications',
'    where lead_id = l.id',
'  ) validations,',
'  (',
'    select max(created)',
'    from eba_sales_verifications',
'    where lead_id = l.id',
'  ) last_validation,',
'  (',
'    select count(*)',
'    from eba_sales_clicks',
'    where lead_id = l.id',
'      and view_timestamp >= sysdate - 90',
'  ) views_90_day,',
'    (   select count(distinct(app_username))',
'        from eba_sales_clicks',
'        where lead_id = l.id',
'            and view_timestamp >= sysdate - 90',
'  ) users_90_day,',
'  l.created,',
'  l.created_by,',
'  l.updated,',
'  l.updated_by,',
'  l.lead_details,',
'  sr.rep_first_name || '' '' || sr.rep_last_name account_default_rep,',
'  t.id territory_id,',
'  t.territory_name territory_name,',
'  c.id account_id,',
'  c.customer_name account_name,',
'  slsc.status_code lead_status,',
'  ls.lead_source',
'from eba_sales_leads l',
'left join eba_sales_customers c',
'  on c.id = l.account_id',
'left join eba_sales_salesreps sr',
'  on sr.id = c.default_rep_id',
'left join eba_sales_territories t',
'  on t.id = c.customer_territory_id ',
'left join eba_sales_lead_status_codes slsc',
'  on slsc.id = l.lead_status_id',
'left join eba_sales_lead_sources ls',
'  on ls.id = l.lead_source_id',
'where :P19_DISPLAY_AS = ''GRID'''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P19_DISPLAY_AS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(6585011679861530582)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'No leads found'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DAN'
,p_internal_uid=>714148645407964835
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6585013104334530596)
,p_db_column_name=>'LEAD'
,p_display_order=>20
,p_column_identifier=>'N'
,p_column_label=>'Lead'
,p_column_link=>'f?p=&APP_ID.:133:&SESSION.::&DEBUG.:RP,133:P133_ID:#ID#'
,p_column_linktext=>'#LEAD#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6585011884027530584)
,p_db_column_name=>'ROW_KEY'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Key'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6585011997240530585)
,p_db_column_name=>'LEAD_PRIORITY'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Priority'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6585012210949530587)
,p_db_column_name=>'ACTION'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Action'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6585012596529530591)
,p_db_column_name=>'LEAD_SOURCE'
,p_display_order=>70
,p_column_identifier=>'I'
,p_column_label=>'Source'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6585012524463530590)
,p_db_column_name=>'LEAD_STATUS'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6585012757370530593)
,p_db_column_name=>'TERRITORY_NAME'
,p_display_order=>90
,p_column_identifier=>'K'
,p_column_label=>'Account Territory'
,p_column_link=>'f?p=&APP_ID.:93:&SESSION.::&DEBUG.:RP,93:P93_ID:#TERRITORY_ID#'
,p_column_linktext=>'#TERRITORY_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Territories''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6585012317214530588)
,p_db_column_name=>'ACCOUNT_NAME'
,p_display_order=>100
,p_column_identifier=>'F'
,p_column_label=>'Account'
,p_column_link=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP,94:P94_ID:#ACCOUNT_ID#'
,p_column_linktext=>'#ACCOUNT_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6585012875958530594)
,p_db_column_name=>'LEAD_DETAILS'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Details'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6585013163188530597)
,p_db_column_name=>'CREATED'
,p_display_order=>130
,p_column_identifier=>'O'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_TIME_FMT.'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592169876584718848)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>140
,p_column_identifier=>'P'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6585012672936530592)
,p_db_column_name=>'UPDATED'
,p_display_order=>150
,p_column_identifier=>'J'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_TIME_FMT.'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592169997312718849)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>160
,p_column_identifier=>'Q'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6585011752229530583)
,p_db_column_name=>'ID'
,p_display_order=>170
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6585012061195530586)
,p_db_column_name=>'OPPORTUNITY_ID'
,p_display_order=>180
,p_column_identifier=>'D'
,p_column_label=>'Opportunity id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592170095809718850)
,p_db_column_name=>'TAGS'
,p_display_order=>190
,p_column_identifier=>'R'
,p_column_label=>'Tags'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592170165990718851)
,p_db_column_name=>'ACCOUNT_DEFAULT_REP'
,p_display_order=>200
,p_column_identifier=>'S'
,p_column_label=>'Account Default Rep'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592170247463718852)
,p_db_column_name=>'TERRITORY_ID'
,p_display_order=>210
,p_column_identifier=>'T'
,p_column_label=>'Territory id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6592170354601718853)
,p_db_column_name=>'ACCOUNT_ID'
,p_display_order=>220
,p_column_identifier=>'U'
,p_column_label=>'Selected Account'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6661029071215044655)
,p_db_column_name=>'LINKS'
,p_display_order=>230
,p_column_identifier=>'V'
,p_column_label=>'Links'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6661029217129044656)
,p_db_column_name=>'ATTACHMENTS'
,p_display_order=>240
,p_column_identifier=>'W'
,p_column_label=>'Attachments'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6661029242641044657)
,p_db_column_name=>'COMMENTS'
,p_display_order=>250
,p_column_identifier=>'X'
,p_column_label=>'Comments'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6661029417493044658)
,p_db_column_name=>'VALIDATIONS'
,p_display_order=>260
,p_column_identifier=>'Y'
,p_column_label=>'Validations'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Validations''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6661029513375044659)
,p_db_column_name=>'LAST_VALIDATION'
,p_display_order=>270
,p_column_identifier=>'Z'
,p_column_label=>'Last Validation'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Validations''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6661029561126044660)
,p_db_column_name=>'VIEWS_90_DAY'
,p_display_order=>280
,p_column_identifier=>'AA'
,p_column_label=>'90 Day Views'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Usage Metrics''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6802490063947595753)
,p_db_column_name=>'USERS_90_DAY'
,p_display_order=>290
,p_column_identifier=>'AB'
,p_column_label=>'90 Day Users'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Usage Metrics''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(6592158141875671851)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'7212952'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LEAD:ACCOUNT_NAME:ROW_KEY:LEAD_PRIORITY:LEAD_SOURCE:LEAD_STATUS:ACTION:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10188646758882119770)
,p_plug_name=>'Leads'
,p_icon_css_classes=>'fa-comment-o'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_plug_template=>wwv_flow_imp.id(7343861764153915263)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6585011522158530580)
,p_plug_name=>'Page Settings'
,p_parent_plug_id=>wwv_flow_imp.id(10188646758882119770)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343855668783915255)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6481509892862463219)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(6460176100937277949)
,p_button_name=>'Reset'
,p_button_static_id=>'reset_button'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886016830915316)
,p_button_image_alt=>'Reset'
,p_button_position=>'CLOSE'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10188646683133119770)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10188646758882119770)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886609855915317)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Lead'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:29::'
,p_security_scheme=>wwv_flow_imp.id(9042571137027542978)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6800886939930171680)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(6585011611398530581)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886016830915316)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&SESSION.::&DEBUG.:RIR,CIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6481503327008427222)
,p_name=>'P19_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6460176100937277949)
,p_prompt=>'Search'
,p_placeholder=>'Search Leads'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(7343885535981915309)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6481505043907432025)
,p_name=>'P19_DISPLAY_AS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6585011522158530580)
,p_item_default=>'CARDS'
,p_prompt=>'Display as'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'PILL_DISPLAY_AS'
,p_lov=>'.'||wwv_flow_imp.id(7350672914166113674)||'.'
,p_field_template=>wwv_flow_imp.id(7343885535981915309)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:t-Form-fieldContainer--radioButtonGroup'
,p_is_persistent=>'U'
,p_lov_display_extra=>'NO'
,p_escape_on_http_output=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'4'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6585009880811530564)
,p_name=>'P19_SOURCE_ID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(6460176100937277949)
,p_prompt=>'Source'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select lead_source display,',
'  id return',
'from eba_sales_lead_sources',
'order by display'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(7466594599226885491)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6585010009753530565)
,p_name=>'P19_STATUS_ID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(6460176100937277949)
,p_prompt=>'Status'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select status_code display,',
'  id return',
'from eba_sales_lead_status_codes',
'order by display_order'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(7466594599226885491)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6592152903555618431)
,p_name=>'P19_SORT'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(6460176100937277949)
,p_item_default=>'NAME'
,p_prompt=>'Sort'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Product;NAME,Updated;UPDATED'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(7466594599226885491)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'U'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10167007080212819498)
,p_name=>'P19_ACCOUNT_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(6460176100937277949)
,p_prompt=>'Account'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'ACCOUNTS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CUSTOMER_NAME display_value, ID return_value ',
'from eba_sales_CUSTOMERS',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(7466594599226885491)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10167033164806852836)
,p_name=>'P19_TERRITORY_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(6460176100937277949)
,p_prompt=>'Account Territory'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TERRITORY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TERRITORY_NAME display_value, ID return_value ',
'from eba_sales_TERRITORIES',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(7466594599226885491)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_required_patch=>wwv_flow_imp.id(10496139698135220995)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10172040255912270567)
,p_computation_sequence=>10
,p_computation_item=>'LAST_PAGE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'19'
,p_compute_when_type=>'%null%'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6597147634005006760)
,p_name=>'Create Lead dialog closed'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10188646683133119770)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6597147728408006761)
,p_event_id=>wwv_flow_imp.id(6597147634005006760)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var display = $v(''P19_DISPLAY_AS'');',
'',
'if (display === ''CARDS'') {',
'  $(''#cards_region'').trigger(''apexrefresh'');',
'} else if (display === ''REPORT'') {',
'  $(''#report_region'').trigger(''apexrefresh'');',
'} else if (display === ''GRID'') {',
'  $(''#grid_region'').trigger(''apexrefresh'');',
'}',
'',
'apex.message.showPageSuccess(''Lead Created.'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6661468965791240895)
,p_name=>'Convert Lead dialog closed'
,p_event_sequence=>20
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 63'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6661469086092240896)
,p_event_id=>wwv_flow_imp.id(6661468965791240895)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var display = $v(''P19_DISPLAY_AS'');',
'',
'if (display === ''CARDS'') {',
'  $(''#cards_region'').trigger(''apexrefresh'');',
'} else if (display === ''REPORT'') {',
'  $(''#report_region'').trigger(''apexrefresh'');',
'} else if (display === ''GRID'') {',
'  $(''#grid_region'').trigger(''apexrefresh'');',
'}',
'',
'',
'apex.message.showPageSuccess(''Lead Converted.'');'))
);
wwv_flow_imp.component_end;
end;
/
