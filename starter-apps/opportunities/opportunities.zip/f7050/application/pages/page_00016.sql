prompt --application/pages/page_00016
begin
--   Manifest
--     PAGE: 00016
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>16
,p_name=>'Opportunity Details'
,p_alias=>'OPPORTUNITY-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Opportunity Details'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(7234593954191374263)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script language="JavaScript" type="text/javascript">',
'<!--',
'',
' htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'//-->',
'</script>',
'<style>',
'.shuttle select {width: 350px}',
'</style>'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(9060293328988296381)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6560179129832791570)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10513282799235644189)
,p_plug_name=>'Opportunity'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_column_width=>'valign=top'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10513283089038644191)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(6560179129832791570)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CREATE'
,p_button_condition=>'P16_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10513282979923644191)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(6560179129832791570)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Opportunity'
,p_button_position=>'CREATE'
,p_button_condition=>'P16_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10513283282794644191)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(6560179129832791570)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'EDIT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10513283177238644191)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(6560179129832791570)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--danger'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Delete'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P16_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(6614870758697760173)
,p_branch_name=>'Branch to Opportunities on delete'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(10513283177238644191)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5964640294096071159)
,p_name=>'P16_SPONSOR_CONTACT_ID'
,p_item_sequence=>175
,p_item_plug_id=>wwv_flow_imp.id(10513282799235644189)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Client Sponsor'
,p_source=>'SPONSOR_CONTACT_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'CONTACTS WITH TITLES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CONTACT_NAME || case when contact_title is not null then '' ('' || CONTACT_TITLE || '')'' else null end as display_value, ID as return_value ',
'  from EBA_SALES_CUSTOMER_CONTACTS',
' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select -'
,p_cHeight=>1
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_help_text=>'Select a client sponsor from the list provided. If you do not see the client sponsor you want in the list, click the "Contacts" tab and add a new contact that represents the client sponsor you want to add to this opportunity. Once you''ve created the '
||'contact, you can come back to this page and assign the newly added contact as this opportunity''s client sponsor.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10252876837273277361)
,p_name=>'P16_TAGS'
,p_item_sequence=>195
,p_item_plug_id=>wwv_flow_imp.id(10513282799235644189)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Tags'
,p_source=>'TAGS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tag',
'from eba_sales_tags_type_sum',
'where content_type = ''DEAL'''))
,p_lov_display_null=>'YES'
,p_cSize=>80
,p_cMaxlength=>255
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'initial_fetch', 'FIRST_ROWSET')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10266923064114722378)
,p_name=>'P16_FINANCIAL_ASSESSMENT_ID'
,p_item_sequence=>135
,p_item_plug_id=>wwv_flow_imp.id(10513282799235644189)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Financial Assessment'
,p_source=>'FINANCIAL_ASSESSMENT_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select display_order||''. ''||assessment_text d, id from eba_sales_fin_assessments order by display_order'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_label_column_span=>2
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10266923248315727254)
,p_name=>'P16_STATUS_ASSESSMENT_ID'
,p_item_sequence=>125
,p_item_plug_id=>wwv_flow_imp.id(10513282799235644189)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Status Assessment'
,p_source=>'STATUS_ASSESSMENT_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select display_order||''. ''||assessment_text d, id ',
'from EBA_SALES_STATUS_ASSESSMENTS ',
'order by display_order'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10266923744637735637)
,p_name=>'P16_RISK_ASSESSMENT_ID'
,p_item_sequence=>145
,p_item_plug_id=>wwv_flow_imp.id(10513282799235644189)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Risk Assessment'
,p_source=>'RISK_ASSESSMENT_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select display_order||''. ''||assessment_text d, id from eba_sales_risk_assessments order by display_order'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10266924358620749142)
,p_name=>'P16_ACCOUNT_STANDING_ID'
,p_item_sequence=>155
,p_item_plug_id=>wwv_flow_imp.id(10513282799235644189)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Account Standing'
,p_source=>'ACCOUNT_STANDING_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select display_order||''. ''||standing_text d, id from eba_sales_account_standing order by display_order'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_grid_label_column_span=>2
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10266924944684764029)
,p_name=>'P16_PRO_RE_ACTIVE'
,p_item_sequence=>165
,p_item_plug_id=>wwv_flow_imp.id(10513282799235644189)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Pro Re Active'
,p_source=>'PRO_RE_ACTIVE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Proactive;Proactive,Reactive;Reactive'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10268885351504028102)
,p_name=>'P16_SVP'
,p_item_sequence=>105
,p_item_plug_id=>wwv_flow_imp.id(10513282799235644189)
,p_use_cache_before_default=>'NO'
,p_prompt=>'SVP'
,p_source=>'SVP_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select svp_name, id from eba_sales_svps order by upper(svp_name)'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select -'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'select null from eba_sales_svps'
,p_display_when_type=>'EXISTS'
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10513284103074644199)
,p_name=>'P16_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10513282799235644189)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10513284283929644200)
,p_name=>'P16_DEAL_NAME'
,p_is_required=>true
,p_item_sequence=>35
,p_item_plug_id=>wwv_flow_imp.id(10513282799235644189)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Opportunity'
,p_source=>'DEAL_NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10513284497411644200)
,p_name=>'P16_DEAL_CLOSE_DATE'
,p_is_required=>true
,p_item_sequence=>75
,p_item_plug_id=>wwv_flow_imp.id(10513282799235644189)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Close'
,p_format_mask=>'&APP_DATE_FORMAT.'
,p_source=>'DEAL_CLOSE_DATE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10513284688769644201)
,p_name=>'P16_DEAL_PROBABILITY'
,p_item_sequence=>115
,p_item_plug_id=>wwv_flow_imp.id(10513282799235644189)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Probability'
,p_post_element_text=>'%'
,p_source=>'DEAL_PROBABILITY'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_grid_label_column_span=>2
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--postTextBlock'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'max_value', '100',
  'min_value', '0',
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10513284879768644201)
,p_name=>'P16_DEAL_AMOUNT'
,p_item_sequence=>65
,p_item_plug_id=>wwv_flow_imp.id(10513282799235644189)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Amount'
,p_placeholder=>'$0'
,p_source=>'DEAL_AMOUNT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_required_patch=>-wwv_flow_imp.id(7204555145359641276)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10513285288141644202)
,p_name=>'P16_DEAL_STATUS_CODE_ID'
,p_item_sequence=>95
,p_item_plug_id=>wwv_flow_imp.id(10513282799235644189)
,p_use_cache_before_default=>'NO'
,p_item_default=>'2'
,p_prompt=>'Stage'
,p_source=>'DEAL_STATUS_CODE_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'STEPS TO CLOSE (STATUS CODE)'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CORRESPONDING_PROB_PCT/10 ||''. ''||status_code d,id',
'from EBA_SALES_DEAL_STATUS_CODES',
'order by CORRESPONDING_PROB_PCT/10 '))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select a Status -'
,p_cHeight=>1
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10513285477752644203)
,p_name=>'P16_DEAL_CUSTOMER_LOCATION_ID'
,p_item_sequence=>55
,p_item_plug_id=>wwv_flow_imp.id(10513282799235644189)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Location'
,p_source=>'DEAL_CUSTOMER_LOCATION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CUSTOMER_LOCATION_NAME display_value, ID return_value ',
'from eba_sales_CUSTOMER_LOCATIONS',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Location -'
,p_cHeight=>1
,p_display_when_type=>'NEVER'
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10513285696705644203)
,p_name=>'P16_DEAL_SUMMARY'
,p_item_sequence=>185
,p_item_plug_id=>wwv_flow_imp.id(10513282799235644189)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Summary'
,p_source=>'DEAL_SUMMARY'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'N',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10513401173857786729)
,p_name=>'P16_CUSTOMER_ID'
,p_is_required=>true
,p_item_sequence=>45
,p_item_plug_id=>wwv_flow_imp.id(10513282799235644189)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Account'
,p_source=>'CUSTOMER_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'ACCOUNTS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CUSTOMER_NAME display_value, ID return_value ',
'from eba_sales_CUSTOMERS',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- No Account Specified -'
,p_cHeight=>1
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10514075404416262375)
,p_name=>'P16_SALESREP_ID_01'
,p_is_required=>true
,p_item_sequence=>85
,p_item_plug_id=>wwv_flow_imp.id(10513282799235644189)
,p_use_cache_before_default=>'NO'
,p_prompt=>'&REP_TITLE.'
,p_source=>'SALESREP_ID_01'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'PRIMARY_SALES_REP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.rep_email||'' - ''||r2.role_name display_value, ',
'         r.ID return_value ',
'from eba_sales_SALESREPS r, ',
'        eba_sales_salesrep_roles r2',
'where r.rep_role = r2.id(+) and r2.is_sales_rep = ''Y''',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select -'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>2
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(8860009536243438720)
,p_computation_sequence=>10
,p_computation_item=>'P80_ID'
,p_computation_point=>'AFTER_FOOTER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'&P16_ID.'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(6726217202512372666)
,p_validation_name=>'P16_DEAL_STATUS_CODE_ID not in (4, 11)'
,p_validation_sequence=>10
,p_validation=>':P16_DEAL_STATUS_CODE_ID in (''4'', ''11'')'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Use the Close Won/Lost button to set #LABEL# to a "closed" value.'
,p_validation_condition=>'sysdate > to_date(:P16_DEAL_CLOSE_DATE,''DD-MON-YYYY'')'
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(10513283089038644191)
,p_associated_item=>wwv_flow_imp.id(10513285288141644202)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(6726217090790372665)
,p_validation_name=>'P16_DEAL_PROBABILITY is not 0 or 100'
,p_validation_sequence=>20
,p_validation=>':P16_DEAL_PROBABILITY in (''0'', ''100'')'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Use the Close Won/Lost button to set #LABEL# to 0 or 100.'
,p_validation_condition=>'sysdate > to_date(:P16_DEAL_CLOSE_DATE,''DD-MON-YYYY'')'
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(10513283089038644191)
,p_associated_item=>wwv_flow_imp.id(10513284688769644201)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(7044109602250191787)
,p_validation_name=>'P16_DEAL_AMOUNT Not Null'
,p_validation_sequence=>30
,p_validation=>'P16_DEAL_AMOUNT'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have some value.'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
,p_required_patch=>-wwv_flow_imp.id(7204555145359641276)
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(291554140115863887)
,p_validation_name=>'Valid Tag Characters'
,p_validation_sequence=>40
,p_validation=>'not regexp_like( :P16_TAGS, ''[:;#\/\\\?\&]'' )'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Tags may not contain the following characters: : ; \ / ? &'
,p_validation_condition=>'SAVE,CREATE'
,p_validation_condition_type=>'REQUEST_IN_CONDITION'
,p_associated_item=>wwv_flow_imp.id(10252876837273277361)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6560179300551791571)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10513283282794644191)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6560179334458791572)
,p_event_id=>wwv_flow_imp.id(6560179300551791571)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10513285885423644204)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from EBA_SALES_DEALS'
,p_attribute_02=>'EBA_SALES_DEALS'
,p_attribute_03=>'P16_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_process_error_message=>'Unable to fetch row.'
,p_internal_uid=>10495563693462890801
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10513286103628644207)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of EBA_SALES_DEALS'
,p_attribute_02=>'EBA_SALES_DEALS'
,p_attribute_03=>'P16_ID'
,p_attribute_04=>'ID'
,p_attribute_09=>'P16_ID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_process_error_message=>'Unable to process row of table EBA_SALES_DEALS.'
,p_process_success_message=>'Action Processed.'
,p_return_key_into_item1=>'P16_ID'
,p_internal_uid=>10495563911667890804
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10513286275671644208)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_process_when_button_id=>wwv_flow_imp.id(10513283177238644191)
,p_internal_uid=>10495564083710890805
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6560179465800791573)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_01=>'P16_DEAL_NAME'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DELETE'
,p_process_when_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_internal_uid=>6542457273840038170
);
wwv_flow_imp.component_end;
end;
/
