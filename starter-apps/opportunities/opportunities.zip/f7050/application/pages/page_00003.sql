prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Account Details'
,p_alias=>'ACCOUNT-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Account Details'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(7357625541266796352)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script language="JavaScript" type="text/javascript">',
'<!--',
'',
' htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'//-->',
'</script>'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(9042571137027542978)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'02'
,p_last_upd_yyyymmddhh24miss=>'20220823161416'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6563081791269594987)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343855860694915257)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9060092662163188141)
,p_plug_name=>'Classification'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(7343862276731915264)
,p_plug_display_sequence=>20
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10495474481611633810)
,p_plug_name=>'Account'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343855668783915255)
,p_plug_display_sequence=>10
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10495474785427633814)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(6563081791269594987)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886609855915317)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CREATE'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10495474704686633814)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(6563081791269594987)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886609855915317)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Account'
,p_button_position=>'CREATE'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10495475008308633817)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6563081791269594987)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7343886609855915317)
,p_button_image_alt=>'Cancel'
,p_button_position=>'EDIT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10495474913452633815)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(6563081791269594987)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--danger'
,p_button_template_id=>wwv_flow_imp.id(7343886609855915317)
,p_button_image_alt=>'Delete'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8881919753467206116)
,p_branch_name=>'Branch to Accounts on delete'
,p_branch_action=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:2::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(10495474913452633815)
,p_branch_sequence=>40
,p_branch_comment=>'Created 17-JAN-2012 10:41 by MIKE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5837785658792087280)
,p_name=>'P3_INDUSTRY_ID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(10495474481611633810)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Industry'
,p_source=>'CUSTOMER_INDUSTRY_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'INDUSTRIES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select industry_name as d,',
'       id as r',
'  from eba_sales_industries',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(7343885725551915311)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_help_text=>'Select the industry that best matches this account''s industry.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7357736253453442773)
,p_name=>'P3_CUSTOMER_TERRITORY_ID'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(10495474481611633810)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Territory'
,p_source=>'CUSTOMER_TERRITORY_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TERRITORY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TERRITORY_NAME display_value, ID return_value ',
'from eba_sales_TERRITORIES',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select a Territory -'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(7343885759644915312)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_restricted_characters=>'WEB_SAFE'
,p_required_patch=>wwv_flow_imp.id(10496139698135220995)
,p_help_text=>'Select the account''s territory.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8433001400217354590)
,p_name=>'P3_SALES_LEADER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(10495474481611633810)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Default &SALES_LDR_TITLE.'
,p_source=>'SECONDARY_REP'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>69
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(7343885725551915311)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Enter the name and/or email address of the account''s sales leader.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9060089966964161071)
,p_name=>'P3_CUSTOMER_LINKEDIN'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(9060092662163188141)
,p_use_cache_before_default=>'NO'
,p_prompt=>'LinkedIn'
,p_placeholder=>'https://www.linkedin.com/company/account-name'
,p_source=>'CUSTOMER_LINKEDIN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(7343885725551915311)
,p_item_icon_css_classes=>'fa-linkedin-square'
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Enter the account''s unique LinkedIn URL here.'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'URL'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9060090158091168008)
,p_name=>'P3_CUSTOMER_FACEBOOK'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(9060092662163188141)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Facebook'
,p_placeholder=>'https://www.facebook.com/account-name'
,p_source=>'CUSTOMER_FACEBOOK'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(7343885725551915311)
,p_item_icon_css_classes=>'fa-facebook-square'
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Enter the account''s unique Facebook URL here.'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'URL'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9060090739868172176)
,p_name=>'P3_CUSTOMER_TWITTER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(9060092662163188141)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Twitter'
,p_placeholder=>'https://twitter.com/account-name'
,p_source=>'CUSTOMER_TWITTER'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(7343885725551915311)
,p_item_icon_css_classes=>'fa-twitter-square'
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Enter the account''s unique Twitter URL here.'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'URL'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10235154153838516895)
,p_name=>'P3_TAGS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(10495474481611633810)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Tags'
,p_source=>'TAGS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tag',
'  from eba_sales_tags_type_sum',
' where content_type = ''ACCOUNT'''))
,p_lov_display_null=>'YES'
,p_cSize=>80
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(7343885725551915311)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'YES'
,p_restricted_characters=>'WEB_SAFE'
,p_help_text=>'Enter a comma-separated list of words that will help flag this account in the future.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'Y'
,p_attribute_04=>'Y'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_attribute_11=>','
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10251498973328199142)
,p_name=>'P3_CUSTOMER_IS_KEY_ACCOUNT_YN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(10495474481611633810)
,p_use_cache_before_default=>'NO'
,p_item_default=>'N'
,p_prompt=>'Key Account'
,p_source=>'CUSTOMER_IS_KEY_ACCOUNT_YN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Yes;Y,No;N'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(7343885725551915311)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_restricted_characters=>'WEB_SAFE'
,p_help_text=>'Choose whether this account is a key account or not.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10251503744575465278)
,p_name=>'P3_DEFAULT_REP_ID'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(10495474481611633810)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Default &REP_TITLE.'
,p_source=>'DEFAULT_REP_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select REP_LAST_NAME||'', ''|| REP_FIRST_NAME n, id r',
'from EBA_SALES_SALESREPS',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Rep -'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(7343885725551915311)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_restricted_characters=>'WEB_SAFE'
,p_help_text=>'Click the <strong>^</strong> button to pop up a window of &REP_TITLE.s and then select a &REP_TITLE. from the list to populate this field.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10495476088084633836)
,p_name=>'P3_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10495474481611633810)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10495476283852633859)
,p_name=>'P3_CUSTOMER_NAME'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10495474481611633810)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Name'
,p_source=>'CUSTOMER_NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(7343885759644915312)
,p_item_template_options=>'#DEFAULT#'
,p_restricted_characters=>'WEB_SAFE'
,p_help_text=>'Enter the account''s name.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10495477483295633863)
,p_name=>'P3_CUSTOMER_SIC'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(9060092662163188141)
,p_use_cache_before_default=>'NO'
,p_prompt=>'SIC'
,p_source=>'CUSTOMER_SIC'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>64
,p_cMaxlength=>4
,p_field_template=>wwv_flow_imp.id(7343885725551915311)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Enter the 4 digit Standard Industrial Classification code that represents this account. <a href="https://www.osha.gov/pls/imis/sicsearch.html" target="_blank">Search SIC Codes</a>'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10495477707095633865)
,p_name=>'P3_CUSTOMER_DUNS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(9060092662163188141)
,p_use_cache_before_default=>'NO'
,p_prompt=>'DUNS#'
,p_source=>'CUSTOMER_DUNS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>64
,p_cMaxlength=>9
,p_field_template=>wwv_flow_imp.id(7343885725551915311)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'If this account has a Dun & Bradstreet number, enter the 9 digit number here. <a href="https://fedgov.dnb.com/webform/pages/CCRSearch.jsp" target="_blank">Search Dun & Bradstreet Codes</a>'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10495477905643633866)
,p_name=>'P3_CUSTOMER_WEB_SITE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(9060092662163188141)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Web Site'
,p_placeholder=>'http://account-name.com'
,p_source=>'CUSTOMER_WEB_SITE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(7343885725551915311)
,p_item_icon_css_classes=>'fa-link'
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Enter the URL to this account''s public-facing website here.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'URL'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10495478097469633866)
,p_name=>'P3_CUSTOMER_STOCK_SYMB'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(9060092662163188141)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Stock Symbol'
,p_source=>'CUSTOMER_STOCK_SYMB'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(7343885725551915311)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'If this account has stock that is publicly traded, enter their stock symbol here.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10495478311051633867)
,p_name=>'P3_CUSTOMER_DESCRIPTION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(10495474481611633810)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Description'
,p_source=>'CUSTOMER_DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>3
,p_field_template=>wwv_flow_imp.id(7343885725551915311)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_restricted_characters=>'WEB_SAFE'
,p_help_text=>'Enter a description of this account.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(7375799250782102693)
,p_validation_name=>'P3_CUSTOMER_NAME not duplicated'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from eba_sales_customers',
'where (:P3_ID is null or :P3_ID != id)',
'    and upper(customer_name) = upper(:P3_CUSTOMER_NAME)'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'An account with that name already exists.'
,p_validation_condition=>'SAVE,CREATE'
,p_validation_condition_type=>'REQUEST_IN_CONDITION'
,p_associated_item=>wwv_flow_imp.id(10495476283852633859)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(663118251827931027)
,p_validation_name=>'Valid Tag Characters'
,p_validation_sequence=>20
,p_validation=>'not regexp_like( :P3_TAGS, ''[:;#\/\\\?\&]'' )'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Tags may not contain the following characters: : ; \ / ? &'
,p_validation_condition=>'CREATE,SAVE'
,p_validation_condition_type=>'REQUEST_IN_CONDITION'
,p_associated_item=>wwv_flow_imp.id(10235154153838516895)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(465063209223632218)
,p_validation_name=>'Website must start with http'
,p_validation_sequence=>30
,p_validation=>'substr(:P3_CUSTOMER_WEB_SITE, 1, 4) = ''http'''
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Please provide a URL that begins with, "http".'
,p_validation_condition=>'P3_CUSTOMER_WEB_SITE'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_imp.id(10495477905643633866)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(465063335514632219)
,p_validation_name=>'LinkedIn must start with http'
,p_validation_sequence=>40
,p_validation=>'substr(:P3_CUSTOMER_LINKEDIN, 1, 4) = ''http'''
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Please provide a URL that begins with, "http".'
,p_validation_condition=>'P3_CUSTOMER_LINKEDIN'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_imp.id(9060089966964161071)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(465063423833632220)
,p_validation_name=>'FB must start with http'
,p_validation_sequence=>50
,p_validation=>'substr(:P3_CUSTOMER_FACEBOOK, 1, 4) = ''http'''
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Please provide a URL that begins with, "http".'
,p_validation_condition=>'P3_CUSTOMER_FACEBOOK'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_imp.id(9060090158091168008)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(465063522384632221)
,p_validation_name=>'Twitter must start with http'
,p_validation_sequence=>60
,p_validation=>'substr(:P3_CUSTOMER_TWITTER, 1, 4) = ''http'''
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Please provide a URL that begins with, "http".'
,p_validation_condition=>'P3_CUSTOMER_TWITTER'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_imp.id(9060090739868172176)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6563081884897594988)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10495475008308633817)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6563081978153594989)
,p_event_id=>wwv_flow_imp.id(6563081884897594988)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10495479489471633872)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from eba_sales_CUSTOMERS'
,p_attribute_02=>'EBA_SALES_CUSTOMERS'
,p_attribute_03=>'P3_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_process_error_message=>'Unable to fetch row.'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10495479709305633880)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of eba_sales_CUSTOMERS'
,p_attribute_02=>'EBA_SALES_CUSTOMERS'
,p_attribute_03=>'P3_ID'
,p_attribute_04=>'ID'
,p_attribute_09=>'P3_ID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_process_error_message=>'Unable to process row of table eba_sales_CUSTOMERS.'
,p_process_success_message=>'Action Processed.'
,p_security_scheme=>wwv_flow_imp.id(9042571137027542978)
,p_return_key_into_item1=>'P3_ID'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6563082311880594992)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_imp.component_end;
end;
/
