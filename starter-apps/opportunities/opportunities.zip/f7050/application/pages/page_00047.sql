prompt --application/pages/page_00047
begin
--   Manifest
--     PAGE: 00047
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>47
,p_name=>'Projected Close Dates'
,p_alias=>'PROJECTED-CLOSE-DATES'
,p_step_title=>'Projected Close Dates'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(7375353650393743976)
,p_step_template=>4072355960268175073
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'This page displays a calendar of projected opportunity close dates. Click an opportunity to edit its details.'
,p_page_component_map=>'08'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10194643769493118390)
,p_plug_name=>'Projected Close Dates (displays &REP_TITLE. and Deal Amount)'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--hiddenOverflow'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d.ID,',
'       d.CUSTOMER_ID,',
'       c.CUSTOMER_NAME,',
'       d.SALESREP_ID_01,',
'       case when apex_util.get_build_option_status(',
'                     p_application_id    => :APP_ID,',
'                     p_build_option_name => ''Opportunity Amount Set at Product Level''',
'                 ) = ''EXCLUDE'' then',
'           sr.REP_LAST_NAME ||'', ''|| sr.REP_FIRST_NAME || '' ('' || ltrim(to_char(d.DEAL_AMOUNT,''9G999G999G999''),'' '') || '')''',
'       else',
'           sr.REP_LAST_NAME ||'', ''|| sr.REP_FIRST_NAME || '' ('' || ltrim(to_char(nvl((select sum(nvl(dp.quote_price, 0)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id), 0),''FML999G999G999G999G999''),'' '') || '')''',
'       end as rep_name,',
'       d.DEAL_NAME,',
'       d.DEAL_CLOSE_DATE',
'  from EBA_SALES_DEALS d,',
'       EBA_SALES_CUSTOMERS c,',
'       EBA_SALES_SALESREPS sr',
' where d.CUSTOMER_ID = c.ID',
'   and d.SALESREP_ID_01 = sr.ID'))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'additional_calendar_views', 'list:navigation',
  'display_column', 'REP_NAME',
  'end_date_column', 'DEAL_CLOSE_DATE',
  'maximum_events_day', '10',
  'multiple_line_event', 'Y',
  'show_time', 'N',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'DEAL_CLOSE_DATE',
  'view_edit_link', 'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:RP:P16_ID:&ID.')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10194647570344118396)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>1
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10512992898526525834)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10194653969456165689)
,p_computation_sequence=>30
,p_computation_item=>'LAST_PAGE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'47'
);
wwv_flow_imp.component_end;
end;
/
