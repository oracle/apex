prompt --application/pages/page_00134
begin
--   Manifest
--     PAGE: 00134
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>134
,p_name=>'Opportunities by Competitor'
,p_alias=>'OPPORTUNITIES-BY-COMPETITOR'
,p_step_title=>'Opportunities by Competitor'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(7357631458432990573)
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(7401040659522300015)
,p_protection_level=>'C'
,p_help_text=>'This is an interactive report of all opportunities listed by competitor. Click the <strong>Reset</strong> button to reset the interactive report. Click the <strong>Actions</strong> button to define the number of rows displayed per page, filter, forma'
||'t, download, and/or save the interactive report.'
,p_page_component_map=>'18'
,p_last_upd_yyyymmddhh24miss=>'20210812003731'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7360408145991631035)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343869008886915277)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10495270706565772431)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(7343886820987915318)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7464695805217719275)
,p_plug_name=>'Opportunities by Competitor'
,p_region_name=>'grid_region'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343865001510915269)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d.id,',
'  d.row_key,',
'  d.deal_name,',
'  t.id territory_id,',
'  t.territory_name,',
'  c.id account_id,',
'  c.customer_name account,',
'  d.deal_amount,',
'  d.deal_probability,',
'  case',
'    when deal_probability > 0 and deal_probability < 100',
'    then ''Yes''',
'    else ''No''',
'  end open,',
'  d.deal_close_date,',
'  dp.close_date as product_close_date,',
'  (select max(dp.qtr) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id) as calculated_qtr,',
'  case',
'    when deal_close_date < sysdate and deal_probability != 0 and deal_probability != 100',
'    then ''Yes''',
'    else ''No''',
'  end past_due,',
'  d.qtr,',
'  dsc.status_code,',
'  d.updated,',
'  d.updated_by,',
'  d.created,',
'  d.created_by,',
'  sr.rep_first_name || '' '' || sr.rep_last_name as sales_rep_name,',
'  cmp.competitor_name,',
'  d.svp_id,',
'  c.secondary_rep,',
'  nvl((select sum(nvl(dp.quote_price, 0)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id), 0) as calculated_amount,',
'  nvl((select sum(nvl(dp.quote_price, 0)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id and dp.term is null), 0) as calculated_opp,',
'  nvl((select sum(nvl(dp.tcv, 0)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id), 0) as calculated_tcv,',
'  nvl((select sum(nvl(dp.quote_price, 0)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id and dp.term is null), 0) + nvl((select sum(nvl(dp.quote_price, 0)) from EBA_SALES_DEAL_PRODUCTS dp where dp.deal_id = d.id and dp.term is not null), 0) '
||'as revenue,',
'  (select',
'    listagg(p.product_name,'', '') within group (order by p.product_name asc)',
'  from EBA_SALES_DEAL_PRODUCTS dp,',
'       EBA_SALES_PRODUCTS p,',
'       EBA_SALES_PRODUCT_FAMILIES f',
' where dp.deal_id = d.id',
'   and dp.product_id = p.id',
'   and p.product_family_id = f.id (+)) as products,',
'   sr.REP_MANAGER_ID as sales_mgr',
'from eba_sales_deals d',
'join eba_sales_customers c',
'  on c.id = d.customer_id',
'join eba_sales_deal_competition dc',
'  on dc.deal_id = d.id',
'join eba_sales_deal_products dp',
'  on dp.deal_id = d.id',
'join eba_sales_competitors cmp',
'  on cmp.id = dc.competitor_id',
'left join eba_sales_deal_status_codes dsc',
'  on dsc.id = d.deal_status_code_id',
'left join eba_sales_territories t',
'  on t.id = c.customer_territory_id',
'left join eba_sales_salesreps sr',
'  on sr.id = d.salesrep_id_01'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>8.5
,p_prn_height=>11
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(7464695938374719276)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DAN'
,p_internal_uid=>1593832903921153529
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6743389119528566169)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6743389486115566170)
,p_db_column_name=>'ROW_KEY'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Key'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6743389836229566170)
,p_db_column_name=>'DEAL_NAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Opportunity'
,p_column_link=>'f?p=&APP_ID.:80:&SESSION.::&DEBUG.:RP,80:P80_ID:#ID#'
,p_column_linktext=>'#DEAL_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6743390281235566170)
,p_db_column_name=>'TERRITORY_ID'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Territory id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6743390697515566171)
,p_db_column_name=>'TERRITORY_NAME'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Account Territory'
,p_column_link=>'f?p=&APP_ID.:93:&SESSION.::&DEBUG.:RP,93:P93_ID:#TERRITORY_ID#'
,p_column_linktext=>'#TERRITORY_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Territories''',
') = ''INCLUDE'''))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6743391048001566171)
,p_db_column_name=>'ACCOUNT_ID'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Selected Account'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6743391468917566172)
,p_db_column_name=>'ACCOUNT'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Account'
,p_column_link=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP,94:P94_ID:#ID#'
,p_column_linktext=>'#ACCOUNT#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7573361026195586262)
,p_db_column_name=>'CALCULATED_QTR'
,p_display_order=>80
,p_column_identifier=>'AD'
,p_column_label=>'Quarter'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(7478708532380272297)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6743391861955566172)
,p_db_column_name=>'QTR'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Quarter'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_required_patch=>-wwv_flow_imp.id(7478708532380272297)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6743392266081566172)
,p_db_column_name=>'STATUS_CODE'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Stage'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6743392651297566173)
,p_db_column_name=>'UPDATED'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_TIME_FMT.'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6743393038203566173)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6743393492981566173)
,p_db_column_name=>'CREATED'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_TIME_FMT.'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6743393896210566174)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6743394288130566174)
,p_db_column_name=>'DEAL_PROBABILITY'
,p_display_order=>150
,p_column_identifier=>'N'
,p_column_label=>'Probability'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6743394711025566174)
,p_db_column_name=>'OPEN'
,p_display_order=>160
,p_column_identifier=>'O'
,p_column_label=>'Open'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6743395059038566175)
,p_db_column_name=>'PAST_DUE'
,p_display_order=>170
,p_column_identifier=>'P'
,p_column_label=>'Past Due'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6743395470245566175)
,p_db_column_name=>'DEAL_AMOUNT'
,p_display_order=>180
,p_column_identifier=>'Q'
,p_column_label=>'Amount'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_required_patch=>-wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6743395875442566175)
,p_db_column_name=>'SALES_REP_NAME'
,p_display_order=>200
,p_column_identifier=>'R'
,p_column_label=>'&REP_TITLE.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7026387006089438380)
,p_db_column_name=>'CALCULATED_AMOUNT'
,p_display_order=>210
,p_column_identifier=>'AC'
,p_column_label=>'&AMT_HDR.'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8023075285501039167)
,p_db_column_name=>'CALCULATED_TCV'
,p_display_order=>220
,p_column_identifier=>'AF'
,p_column_label=>'Total Contract Value'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7573361117174586263)
,p_db_column_name=>'PRODUCT_CLOSE_DATE'
,p_display_order=>230
,p_column_identifier=>'AE'
,p_column_label=>'Close Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_FORMAT.'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(7478708532380272297)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6743388716684566169)
,p_db_column_name=>'DEAL_CLOSE_DATE'
,p_display_order=>240
,p_column_identifier=>'AA'
,p_column_label=>'Close Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_FORMAT.'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
,p_required_patch=>-wwv_flow_imp.id(7478708532380272297)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6743262426961799950)
,p_db_column_name=>'COMPETITOR_NAME'
,p_display_order=>250
,p_column_identifier=>'AB'
,p_column_label=>'Competitor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8451266539154738278)
,p_db_column_name=>'SVP_ID'
,p_display_order=>260
,p_column_identifier=>'AG'
,p_column_label=>'SVP'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(8454523626590621748)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8451266656945738279)
,p_db_column_name=>'SECONDARY_REP'
,p_display_order=>270
,p_column_identifier=>'AH'
,p_column_label=>'&SALES_LDR_TITLE.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8451266738978738280)
,p_db_column_name=>'CALCULATED_OPP'
,p_display_order=>280
,p_column_identifier=>'AI'
,p_column_label=>'On-Premise Purchase Value'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8451266852102738281)
,p_db_column_name=>'REVENUE'
,p_display_order=>290
,p_column_identifier=>'AJ'
,p_column_label=>'Total Revenue'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G999'
,p_use_as_row_header=>'N'
,p_required_patch=>wwv_flow_imp.id(7186832953398887873)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8451267013072738282)
,p_db_column_name=>'PRODUCTS'
,p_display_order=>300
,p_column_identifier=>'AK'
,p_column_label=>'Products'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8451267119858738283)
,p_db_column_name=>'SALES_MGR'
,p_display_order=>310
,p_column_identifier=>'AL'
,p_column_label=>'&REP_TITLE. Manager'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(8454529635334784561)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(7465262670214352961)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8725364'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DEAL_NAME:PRODUCT_CLOSE_DATE:COMPETITOR_NAME:ACCOUNT:CALCULATED_AMOUNT:DEAL_PROBABILITY:OPEN:PAST_DUE::SVP_ID:SECONDARY_REP:CALCULATED_OPP:REVENUE:PRODUCTS:SALES_MGR'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7360407362190631019)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(7464695805217719275)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886016830915316)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:134:&SESSION.::&DEBUG.:134,RIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(7360408539010631036)
,p_branch_name=>'Go To Page 134'
,p_branch_action=>'f?p=&FLOW_ID.:134:&SESSION.'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(7360532653658025316)
,p_computation_sequence=>10
,p_computation_item=>'LAST_PAGE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'134'
);
wwv_flow_imp.component_end;
end;
/
