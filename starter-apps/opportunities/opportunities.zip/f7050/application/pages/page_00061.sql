prompt --application/pages/page_00061
begin
--   Manifest
--     PAGE: 00061
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>61
,p_name=>'Product'
,p_alias=>'PRODUCT'
,p_step_title=>'Product'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(7418981228878330390)
,p_step_template=>1998361449248688088
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(10514207977421756031)
,p_protection_level=>'C'
,p_help_text=>'Manage an product''s details, links, attachments, and/or comments. You can also validate the product.'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(6591930422659836855)
,p_name=>'Product'
,p_template=>4501440665235496320
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_display_point=>'REGION_POSITION_02'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.id,',
'  p.product_name,',
'  p.product_family_id,',
'  p.row_key, ',
'  p.product_sku,',
'  p.product_description,',
'  p.created,',
'  lower(p.created_by) created_by,',
'  p.updated,',
'  lower(p.updated_by) updated_by',
'from eba_sales_products p',
'where p.id = :P61_ID'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2100515439059797523
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6591930439829836856)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6591930567000836857)
,p_query_column_id=>2
,p_column_alias=>'PRODUCT_NAME'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7475664357542567454)
,p_query_column_id=>3
,p_column_alias=>'PRODUCT_FAMILY_ID'
,p_column_display_sequence=>4
,p_column_heading=>'Family'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from eba_sales_products p',
'where p.id = :P61_ID',
'and p.product_family_id is not null'))
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(6996144581841418999)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6591930653319836858)
,p_query_column_id=>4
,p_column_alias=>'ROW_KEY'
,p_column_display_sequence=>3
,p_column_heading=>'Key'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6591930809746836859)
,p_query_column_id=>5
,p_column_alias=>'PRODUCT_SKU'
,p_column_display_sequence=>5
,p_column_heading=>'SKU'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from eba_sales_products p',
'where p.id = :P61_ID',
'and p.product_sku is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7475664672049567457)
,p_query_column_id=>6
,p_column_alias=>'PRODUCT_DESCRIPTION'
,p_column_display_sequence=>6
,p_column_heading=>'Description'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from eba_sales_products p',
'where p.id = :P61_ID',
'and p.product_description is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6591930858059836860)
,p_query_column_id=>7
,p_column_alias=>'CREATED'
,p_column_display_sequence=>7
,p_column_heading=>'Created'
,p_column_format=>'SINCE'
,p_column_html_expression=>'#CREATED# by #CREATED_BY#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6653900759791702555)
,p_query_column_id=>8
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6591930956178836861)
,p_query_column_id=>9
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>8
,p_column_heading=>'Updated'
,p_column_format=>'SINCE'
,p_column_html_expression=>'#UPDATED# by #UPDATED_BY#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6653900879055702556)
,p_query_column_id=>10
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6591931225458836863)
,p_plug_name=>'RDS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6601488137911398320)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10512992898526525834)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6645392082982558892)
,p_plug_name=>'Product Actions'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-LinksList--actions:t-LinksList--showTopIcons'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_list_id=>wwv_flow_imp.id(6646563795924690693)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>4072361143931175087
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8186396491482537622)
,p_plug_name=>'Usage Metrics - 90 days'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select count(*) c,',
'  ''Views'' l,',
'  1 disp',
'from eba_sales_clicks',
'where product_id = :P61_ID ',
'  and view_timestamp > sysdate - 90',
'union all',
'select count(distinct(app_username)) c,',
'    ''Users'' l,',
'    2 disp',
'from eba_sales_clicks',
'where product_id = :P61_ID ',
'    and view_timestamp > sysdate - 90',
'order by disp'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_required_patch=>wwv_flow_imp.id(6646330002823433753)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'L',
  'attribute_02', 'C',
  'attribute_04', 'f?p=&APP_ID.:138:&SESSION.::&DEBUG.:138:P138_ENTITY_TYPE,P138_ENTITY_ID:PRODUCT,&P61_ID.',
  'attribute_05', '2',
  'attribute_06', 'L',
  'attribute_07', 'DOT',
  'attribute_08', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8963744391274722003)
,p_plug_name=>'Validations'
,p_region_css_classes=>'js-validateRegion'
,p_region_template_options=>'#DEFAULT#:t-Region--stacked:t-Region--hiddenOverflow'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.verified_by,',
'  v.created',
'from eba_sales_verifications v',
'where product_id = :P61_ID',
'order by v.created desc'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.VALIDATOR'
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_required_patch=>wwv_flow_imp.id(7399339529259625523)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'f?p=&APP_ID.:146:&SESSION.::&DEBUG.:146:P146_ENTITY_TYPE,P146_ENTITY_ID:PRODUCT,&P61_ID.',
  'attribute_02', 'f?p=&APP_ID.:147:&SESSION.::&DEBUG.:RP,147:P147_ENTITY_TYPE,P147_ENTITY_ID:PRODUCT,&P61_ID.')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9606914048704640877)
,p_plug_name=>'Summary'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:::::t-Region--scrollBody:::::'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d, ',
'  c',
'from (',
'  select ''Accounts'' d, ',
'    count(*) c, ',
'    1 s',
'  from eba_sales_customers',
'  where id in (',
'    select customer_id',
'    from eba_sales_deals',
'    where id in (',
'      select deal_id',
'      from eba_sales_deal_products',
'      where product_id = :P61_ID',
'    )',
'  )',
'  union all',
'  select ''Opportunities'' d, count(*) c, 2 s',
'  from eba_sales_deals',
'  where id in (',
'    select deal_id',
'    from eba_sales_deal_products',
'    where product_id = :P61_ID',
'  )',
'  union all',
'  select ''Open Opportunities'' d, count(*) c, 3 s',
'  from eba_sales_deals',
'  where deal_probability != 0 and deal_probability != 100',
'    and id in (',
'      select deal_id',
'      from eba_sales_deal_products',
'      where product_id = :P61_ID',
'    )',
')',
'order by s'))
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.BADGE_LIST'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'D',
  'attribute_02', 'C',
  'attribute_05', '0',
  'attribute_07', 'BOX',
  'attribute_08', 'N')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6654596137242968441)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10391275833983581906)
,p_button_name=>'POPATTACHMENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Add Attachment'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:99:&SESSION.::&DEBUG.:RP,99:P99_ENTITY_TYPE,P99_ENTITY_ID:PRODUCT,&P61_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6654596538615968441)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10391275833983581906)
,p_button_name=>'VIEW_ATTACHMENTS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'View Attachments'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:92:&SESSION.::&DEBUG.:RP,92:P92_ENTITY_TYPE,P92_ENTITY_ID:PRODUCT,&P61_ID.'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6646589491247000310)
,p_button_sequence=>240
,p_button_plug_id=>wwv_flow_imp.id(12657716489022517846)
,p_button_name=>'POP_LINK'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Add Link'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:RP,114:P114_ENTITY_TYPE,P114_ENTITY_ID:PRODUCT,&P61_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6646589855936000312)
,p_button_sequence=>250
,p_button_plug_id=>wwv_flow_imp.id(12657716489022517846)
,p_button_name=>'VIEW_LINKS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'View Links'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:89:&SESSION.::&DEBUG.:RP,89:P89_ENTITY_TYPE,P89_ENTITY_ID:PRODUCT,&P61_ID.'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6668281674455740212)
,p_button_sequence=>260
,p_button_plug_id=>wwv_flow_imp.id(9625526318213526612)
,p_button_name=>'POPCOMMENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Add Comment'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:RP,22:P22_ENTITY_TYPE,P22_ENTITY_ID:PRODUCT,&P61_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(9060293328988296381)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6668281968071740944)
,p_button_sequence=>270
,p_button_plug_id=>wwv_flow_imp.id(9625526318213526612)
,p_button_name=>'VIEW_COMMENTS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'View Comments'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:88:&SESSION.::&DEBUG.:RP,88:P88_ENTITY_TYPE,P88_ENTITY_ID:PRODUCT,&P61_ID.'
,p_icon_css_classes=>'fa-external-link-square'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6591931090690836862)
,p_name=>'P61_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6591930422659836855)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6645392149665558893)
,p_name=>'Link Details dialog closed'
,p_event_sequence=>30
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data && this.data.dialogPageId === 114'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6678751134616798057)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Init page'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into eba_sales_clicks (',
'  entity_type,',
'  product_id,',
'    app_username',
') values (',
'  ''PRODUCT'',',
'  :P61_ID,',
'    lower(:APP_USER)',
');',
'',
'delete from eba_sales_clicks ',
'where view_timestamp < (sysdate - 90) ',
'  and product_id = :P61_ID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>6661028942656044654
);
wwv_flow_imp.component_end;
end;
/
