prompt --application/pages/page_00071
begin
--   Manifest
--     PAGE: 00071
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>71
,p_name=>'Create Opportunity'
,p_alias=>'CREATE-OPPORTUNITY'
,p_page_mode=>'MODAL'
,p_step_title=>'Create Opportunity'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(7234593954191374263)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'',
'a.simpleButton{display:inline-block;padding:0 8px;font:normal 11px/20px Arial,sans-serif;color:#666;background-color:#F0F0F0;border:1px solid #CCC;text-align:center;-moz-border-radius:4px;-webkit-border-radius:4px;border-radius:8px; text-decoration: '
||'none !important}',
'a.simpleButton:hover {background-color: #FFF}',
'</style>'))
,p_step_template=>2121795032473542284
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(9060293328988296381)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6726216110656372655)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7805528377581492000)
,p_plug_name=>'Opportunity Information'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7975712129866355793)
,p_plug_name=>'Other Opportunity Attributes'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>1210
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9066602927874110634)
,p_plug_name=>'New Account'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10269207446002713543)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(6726216110656372655)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'EDIT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10269207768827713543)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6726216110656372655)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Opportunity'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8039580368550512416)
,p_name=>'P71_SALESREP'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(7975712129866355793)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   x number := null;',
'begin',
'   for c1 in (select DEFAULT_REP_ID',
'                 from EBA_SALES_CUSTOMERS',
'                 where id = :P71_ACCOUNT) loop',
'       x := c1.DEFAULT_REP_ID;',
'   end loop;',
'   return x;',
'end;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'&REP_TITLE.'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'PRIMARY_SALES_REP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.rep_email||'' - ''||r2.role_name display_value, ',
'         r.ID return_value ',
'from eba_sales_SALESREPS r, ',
'        eba_sales_salesrep_roles r2',
'where r.rep_role = r2.id(+) and r2.is_sales_rep = ''Y''',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select -'
,p_cHeight=>1
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_help_text=>'Only sales representatives that have been assigned the role of "Sales Representative", "Sales Manager", or "Tele Sales" will appear in this list. Contact your application administrator if you''re not seeing someone expected to be in this list and ask '
||'them to change that person''s role to one of the three roles mentioned above.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8039581976843520938)
,p_name=>'P71_AMOUNT'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(7975712129866355793)
,p_item_default=>'0'
,p_prompt=>'Amount'
,p_placeholder=>'$0'
,p_format_mask=>'FML999G999G999G999G999'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>50
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_required_patch=>-wwv_flow_imp.id(7204555145359641276)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'max_value', '10000000000',
  'min_value', '1',
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8039582314782523694)
,p_name=>'P71_STATUS'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(7975712129866355793)
,p_item_default=>'2'
,p_prompt=>'Stage'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'STEPS TO CLOSE (STATUS CODE)'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CORRESPONDING_PROB_PCT/10 ||''. ''||status_code d,id',
'from EBA_SALES_DEAL_STATUS_CODES',
'order by CORRESPONDING_PROB_PCT/10 '))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select a Status -'
,p_cHeight=>1
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8039582808519525691)
,p_name=>'P71_CLOSE_DATE'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(7975712129866355793)
,p_item_default=>'return to_char((sysdate + 90),''&APP_DATE_FORMAT.'');'
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Close Date'
,p_format_mask=>'&APP_DATE_FORMAT.'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_required_patch=>-wwv_flow_imp.id(7496430724341025700)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8039626336194763427)
,p_name=>'P71_OPP_ID'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(7975712129866355793)
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when_type=>'NEVER'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8468987831544491672)
,p_name=>'P71_SPONSOR_CONTACT_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(7975712129866355793)
,p_prompt=>'Client Sponsor'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'CONTACTS WITH TITLES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CONTACT_NAME || case when contact_title is not null then '' ('' || CONTACT_TITLE || '')'' else null end as display_value, ID as return_value ',
'  from EBA_SALES_CUSTOMER_CONTACTS',
' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select -'
,p_cHeight=>1
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_help_text=>'Select a client sponsor from the list provided. If you do not see the client sponsor you want in the list, click the "Contacts" tab and add a new contact that represents the client sponsor you want to add to this opportunity. Once you''ve created the '
||'contact, you can come back to this page and assign the newly added contact as this opportunity''s client sponsor.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8469036565529970142)
,p_name=>'P71_SVP'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(7975712129866355793)
,p_use_cache_before_default=>'NO'
,p_prompt=>'SVP'
,p_source=>'SVP_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select svp_name, id from eba_sales_svps order by upper(svp_name)'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select -'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'select null from eba_sales_svps'
,p_display_when_type=>'EXISTS'
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8469037263771974023)
,p_name=>'P71_DEAL_SUMMARY'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(7975712129866355793)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Summary'
,p_source=>'DEAL_SUMMARY'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'N',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8469038695168985064)
,p_name=>'P71_OPP_TAGS'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(7975712129866355793)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Tags'
,p_source=>'TAGS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tag',
'from eba_sales_tags_type_sum',
'where content_type = ''DEAL'''))
,p_lov_display_null=>'YES'
,p_cSize=>80
,p_cMaxlength=>255
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'initial_fetch', 'FIRST_ROWSET')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9066603146811110638)
,p_name=>'P71_TAGS'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(9066602927874110634)
,p_prompt=>'Tags'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tag',
'  from eba_sales_tags_type_sum',
' where content_type = ''ACCOUNT'''))
,p_lov_display_null=>'YES'
,p_cSize=>80
,p_cMaxlength=>255
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'initial_fetch', 'FIRST_ROWSET')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9066603329166110640)
,p_name=>'P71_CUSTOMER_IS_KEY_ACCOUNT_YN'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(9066602927874110634)
,p_item_default=>'N'
,p_prompt=>'Key Account'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Yes;Y,No;N'
,p_cHeight=>1
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9066603556654110640)
,p_name=>'P71_DEFAULT_REP_ID'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(9066602927874110634)
,p_prompt=>'Default &REP_TITLE.'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select REP_LAST_NAME||'', ''|| REP_FIRST_NAME n, id r',
'from EBA_SALES_SALESREPS',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Rep -'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'DIALOG',
  'initial_fetch', 'FIRST_ROWSET')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9066603942061110641)
,p_name=>'P71_CUSTOMER_NAME'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(9066602927874110634)
,p_prompt=>'Account Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9066604157895110641)
,p_name=>'P71_CUSTOMER_SIC'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(9066602927874110634)
,p_prompt=>'SIC'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9066604354114110641)
,p_name=>'P71_CUSTOMER_DUNS'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(9066602927874110634)
,p_prompt=>'DUNS#'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9066604529793110641)
,p_name=>'P71_CUSTOMER_WEB_SITE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(9066602927874110634)
,p_prompt=>'Web Site'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_cMaxlength=>255
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9066604742970110641)
,p_name=>'P71_CUSTOMER_STOCK_SYMB'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(9066602927874110634)
,p_prompt=>'Stock Symbol'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9066604954703110642)
,p_name=>'P71_CUSTOMER_DESCRIPTION'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(9066602927874110634)
,p_prompt=>'Description'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>3
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'N',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9066605749607135786)
,p_name=>'P71_NEW_OR_EXISTING'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(7805528377581492000)
,p_item_default=>'EXISTING'
,p_prompt=>'Use'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'NEW_OR_EXISTING'
,p_lov=>'.'||wwv_flow_imp.id(9066605934501140924)||'.'
,p_cHeight=>1
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10269207245749713542)
,p_name=>'P71_TERRITORY_ID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(9066602927874110634)
,p_prompt=>'Territory'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TERRITORY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TERRITORY_NAME display_value, ID return_value ',
'from eba_sales_TERRITORIES',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Territory -'
,p_cHeight=>1
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10269216654142769634)
,p_name=>'P71_ACCOUNT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(7805528377581492000)
,p_prompt=>'Account'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'ACCOUNTS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CUSTOMER_NAME display_value, ID return_value ',
'from eba_sales_CUSTOMERS',
'order by 1'))
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'DIALOG',
  'initial_fetch', 'FIRST_ROWSET')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10269216958689799309)
,p_name=>'P71_OPPORTUNITY_NAME'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(7805528377581492000)
,p_prompt=>'Opportunity'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(9071248346147059356)
,p_validation_name=>'P71_ACCOUNT not null when existing'
,p_validation_sequence=>10
,p_validation=>'P71_ACCOUNT'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have some value.'
,p_validation_condition=>'P71_NEW_OR_EXISTING'
,p_validation_condition2=>'EXISTING'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(10269207768827713543)
,p_associated_item=>wwv_flow_imp.id(10269216654142769634)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(9071248627577063451)
,p_validation_name=>'P71_CUSTOMER_NAME not null when new'
,p_validation_sequence=>20
,p_validation=>'P71_CUSTOMER_NAME'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have some value.'
,p_validation_condition=>'P71_NEW_OR_EXISTING'
,p_validation_condition2=>'NEW'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(10269207768827713543)
,p_associated_item=>wwv_flow_imp.id(9066603942061110641)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(7393523759108878893)
,p_validation_name=>'P71_OPPORTUNITY_NAME not duplicated'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from eba_sales_deals',
'where upper(deal_name) = upper(:P71_OPPORTUNITY_NAME)'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'An opportunity with that name already exists.'
,p_associated_item=>wwv_flow_imp.id(10269216958689799309)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(7393523949619883252)
,p_validation_name=>'P71_CUSTOMER_NAME not duplicated'
,p_validation_sequence=>40
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from eba_sales_customers',
'where upper(customer_name) = upper(:P71_CUSTOMER_NAME)'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'An account with that name already exists.'
,p_validation_condition=>'P71_NEW_OR_EXISTING'
,p_validation_condition2=>'NEW'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_associated_item=>wwv_flow_imp.id(9066603942061110641)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(6539773511665514400)
,p_validation_name=>'P71_TERRITORY_ID not null'
,p_validation_sequence=>50
,p_validation=>'P71_TERRITORY_ID'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have some value.'
,p_validation_condition=>'P71_NEW_OR_EXISTING'
,p_validation_condition2=>'NEW'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_associated_item=>wwv_flow_imp.id(10269207245749713542)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(291555392336875214)
,p_validation_name=>'Valid Tag Characters'
,p_validation_sequence=>60
,p_validation=>'not regexp_like( :P71_TAGS, ''[:;#\/\\\?\&]'' )'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Tags may not contain the following characters: : ; \ / ? &'
,p_when_button_pressed=>wwv_flow_imp.id(10269207768827713543)
,p_associated_item=>wwv_flow_imp.id(9066603146811110638)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(291543086478683505)
,p_validation_name=>'Valid Tag Characters Opportunity'
,p_validation_sequence=>70
,p_validation=>'not regexp_like( :P71_OPP_TAGS, ''[:;#\/\\\?\&]'' )'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Tags may not contain the following characters: : ; \ / ? &'
,p_when_button_pressed=>wwv_flow_imp.id(10269207768827713543)
,p_associated_item=>wwv_flow_imp.id(8469038695168985064)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(9070958633951382455)
,p_name=>'show hide new account region'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P71_NEW_OR_EXISTING'
,p_condition_element=>'P71_NEW_OR_EXISTING'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'NEW'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9070958931184382458)
,p_event_id=>wwv_flow_imp.id(9070958633951382455)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9066602927874110634)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9070959144260382459)
,p_event_id=>wwv_flow_imp.id(9070958633951382455)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9066602927874110634)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7975712290654355794)
,p_event_id=>wwv_flow_imp.id(9070958633951382455)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_FOCUS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P71_CUSTOMER_NAME'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(9070961741841479365)
,p_name=>'show hide existing account item'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P71_NEW_OR_EXISTING'
,p_condition_element=>'P71_NEW_OR_EXISTING'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'EXISTING'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9070962051586479365)
,p_event_id=>wwv_flow_imp.id(9070961741841479365)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P71_ACCOUNT'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9070962241197479366)
,p_event_id=>wwv_flow_imp.id(9070961741841479365)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P71_ACCOUNT'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7975712390735355795)
,p_event_id=>wwv_flow_imp.id(9070961741841479365)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_FOCUS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P71_ACCOUNT'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6726216437991372659)
,p_name=>'Cancel clicked'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10269207446002713543)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6726216593226372660)
,p_event_id=>wwv_flow_imp.id(6726216437991372659)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8039613878123651599)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'create opportunity'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_account_id   number;',
'    l_opp_id       number;',
'    ',
'    la_product     apex_application_global.vc_arr2;',
'    la_team        apex_application_global.vc_arr2;',
'    la_competition apex_application_global.vc_arr2;',
'begin',
'    if :P71_NEW_OR_EXISTING = ''NEW'' then',
'        insert into eba_sales_customers (',
'        customer_name,',
'        customer_territory_id,',
'        customer_web_site,',
'        customer_duns,',
'        customer_sic,',
'        customer_stock_symb,',
'        customer_is_key_account_yn,',
'        default_rep_id,',
'        customer_description,',
'        tags              ',
'        )',
'        values (',
'        :P71_CUSTOMER_NAME,',
'        :P71_TERRITORY_ID,',
'        :P71_CUSTOMER_WEB_SITE,',
'        :P71_CUSTOMER_DUNS,',
'        :P71_CUSTOMER_SIC,',
'        :P71_CUSTOMER_STOCK_SYMB,',
'        :P71_CUSTOMER_IS_KEY_ACCOUNT_YN,',
'        :P71_DEFAULT_REP_ID,',
'        :P71_CUSTOMER_DESCRIPTION,',
'        :P71_TAGS',
'        ) returning id into l_account_id;',
'    else',
'        l_account_id := :P71_ACCOUNT;',
'    end if;',
'    ',
'    insert into EBA_SALES_DEALS (',
'    DEAL_NAME,',
'    CUSTOMER_ID,',
'    SALESREP_ID_01,',
'    DEAL_AMOUNT,',
'    DEAL_CLOSE_DATE,',
'    DEAL_STATUS_CODE_ID,',
'    SPONSOR_CONTACT_ID,',
'    VP_ID,',
'    DEAL_SUMMARY,',
'    TAGS,',
'    SVP_ID',
'    )',
'    values (',
'    :P71_OPPORTUNITY_NAME,',
'    l_account_id,',
'    :P71_SALESREP,',
'    :P71_AMOUNT,',
'    :P71_CLOSE_DATE,',
'    :P71_STATUS,',
'    :P71_SPONSOR_CONTACT_ID,',
'    :P71_SVP,',
'    :P71_DEAL_SUMMARY,',
'    :P71_OPP_TAGS,',
'    :P71_SVP',
'    )',
'    returning id into l_opp_id;',
'    ',
'    :P71_OPP_ID := l_opp_id; -- used to branch later',
'    ',
'-- The code below is remarked out because this functionality was removed from the wizard',
'-- Allan 21-NOV-2016',
'/*',
'    -- add products',
'    if :P73_PRODUCTS is not null then',
'        la_product := apex_util.string_to_table(:P73_PRODUCTS);',
'        for i in 1..la_product.count',
'        loop',
'            insert into eba_sales_deal_products (deal_id, product_id) values (l_opp_id, la_product(i));',
'        end loop;',
'    end if;',
'  ',
'    -- team',
'    if :P72_TEAM is not null then',
'        la_team := apex_util.string_to_table(:P72_TEAM);',
'        for i in 1..la_team.count',
'        loop',
'            insert into eba_sales_deal_team (deal_id, REP_ID) values (l_opp_id, la_team(i));',
'        end loop;',
'    end if;',
'',
'    -- competition',
'    if :P72_COMPETITION is not null then',
'        la_competition := apex_util.string_to_table(:P72_COMPETITION);',
'        for i in 1..la_competition.count',
'        loop',
'            insert into eba_sales_deal_competition (deal_id, competitor_id) values (l_opp_id, la_competition(i));',
'        end loop;',
'    end if;',
'*/',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Unable to create opportunity'
,p_process_when_button_id=>wwv_flow_imp.id(10269207768827713543)
,p_process_success_message=>'Opportunity Created'
,p_internal_uid=>8021891686162898196
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7975712612718355797)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Session Data'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(10269207768827713543)
,p_internal_uid=>7957990420757602394
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7975712698218355798)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(10269207768827713543)
,p_internal_uid=>7957990506257602395
);
wwv_flow_imp.component_end;
end;
/
