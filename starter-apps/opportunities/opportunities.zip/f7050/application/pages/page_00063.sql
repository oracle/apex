prompt --application/pages/page_00063
begin
--   Manifest
--     PAGE: 00063
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>63
,p_name=>'Convert to Opportunity'
,p_alias=>'CONVERT-TO-OPPORTUNITY'
,p_page_mode=>'MODAL'
,p_step_title=>'Convert to Opportunity'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(7216871863962621378)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(9042571137027542978)
,p_required_patch=>wwv_flow_imp.id(7401034857403255410)
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_upd_yyyymmddhh24miss=>'20220823161416'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6520927359440296774)
,p_plug_name=>'Button bar'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343855860694915257)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9017469658513487198)
,p_plug_name=>'Convert'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(7343855668783915255)
,p_plug_display_sequence=>10
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9017470665166495253)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6520927359440296774)
,p_button_name=>'Convert_to_opportunity'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_imp.id(7343886609855915317)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Convert to Opportunity'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9017470453450495253)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(6520927359440296774)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(7343886609855915317)
,p_button_image_alt=>'Cancel'
,p_button_position=>'EDIT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9017469938212490801)
,p_name=>'P63_LEAD_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(9017469658513487198)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9017476355236599826)
,p_name=>'P63_OPPORTUNITY'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9017469658513487198)
,p_prompt=>'Opportunity'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(7343885759644915312)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9017476660908610961)
,p_name=>'P63_ACCOUNT'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(9017469658513487198)
,p_prompt=>'Account'
,p_source=>'select account_id from EBA_SALES_LEADS where id = :P63_LEAD_ID'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'ACCOUNTS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CUSTOMER_NAME display_value, ID return_value ',
'from eba_sales_CUSTOMERS',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Account -'
,p_cHeight=>1
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(7343885759644915312)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9017477237191641920)
,p_name=>'P63_SALES_REP'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(9017469658513487198)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   x number := null;',
'begin',
'   for c1 in (select DEFAULT_REP_ID',
'                 from EBA_SALES_CUSTOMERS',
'                 where id = :P71_ACCOUNT) loop',
'       x := c1.DEFAULT_REP_ID;',
'   end loop;',
'   return x;',
'end;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Primary &REP_TITLE.'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.rep_email || '' - '' || rr.role_name display_value, ',
'  r.id return_value ',
'from eba_sales_salesreps r',
'join eba_sales_salesrep_roles rr',
'  on rr.id = r.rep_role',
'where rr.is_sales_rep = ''Y''',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select -'
,p_cHeight=>1
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(7343885759644915312)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9017477554853647092)
,p_name=>'P63_AMOUNT'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(9017469658513487198)
,p_item_default=>'0'
,p_prompt=>'Amount'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>15
,p_cMaxlength=>2000
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(7343885759644915312)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'1'
,p_attribute_02=>'10000000000'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9017477761432648963)
,p_name=>'P63_CLOSE_DATE'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(9017469658513487198)
,p_use_cache_before_default=>'NO'
,p_item_default=>'return to_char((sysdate + 90),''&APP_DATE_FORMAT.'');'
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Close Date'
,p_format_mask=>'&APP_DATE_FORMAT.'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>15
,p_cMaxlength=>255
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(7343885759644915312)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9017477938015651641)
,p_name=>'P63_STATUS'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(9017469658513487198)
,p_item_default=>'2'
,p_prompt=>'Status'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'STEPS TO CLOSE (STATUS CODE)'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CORRESPONDING_PROB_PCT/10 ||''. ''||status_code d,id',
'from EBA_SALES_DEAL_STATUS_CODES',
'order by CORRESPONDING_PROB_PCT/10 '))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select a Status -'
,p_cHeight=>1
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(7343885759644915312)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6520927506355296775)
,p_name=>'Cancel clicked'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(9017470453450495253)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6520927556560296776)
,p_event_id=>wwv_flow_imp.id(6520927506355296775)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9017478038061680032)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'convert lead to opportunity'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'  l_id             number;',
'  l_sales_lead_rec eba_sales_leads%rowtype;',
'  l_message        varchar2(4000);',
'',
'begin',
'',
'  insert into eba_sales_deals (',
'    deal_name,',
'    customer_id,',
'    salesrep_id_01,',
'    deal_amount,',
'    deal_close_date,',
'    deal_status_code_id',
'  ) values (',
'    :P63_OPPORTUNITY,',
'    :P63_ACCOUNT,',
'    :P63_SALES_REP,',
'    :P63_AMOUNT,',
'    to_date(:P63_CLOSE_DATE,''DD-MON-YYYY''),',
'    :P63_STATUS',
'  )',
'  returning id ',
'  into l_id;',
'',
'  update eba_sales_leads ',
'  set opportunity_id = l_id, ',
'    lead_status_id = 5 ',
'  where id = :P63_LEAD_ID;',
'/*',
'  select *',
'  into l_sales_lead_rec',
'  from eba_sales_leads ',
'  where id = :P63_LEAD_ID;',
'',
'  l_message := ''converted from lead '' || l_sales_lead_rec.row_key;',
'',
'  insert into eba_sales_deal_notes(',
'    deal_id,',
'    note',
'  ) values (',
'    l_id,',
'    l_message',
'  );',
' */',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6520927654010296777)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Lead converted.'
);
wwv_flow_imp.component_end;
end;
/
