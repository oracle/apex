prompt --application/pages/page_00116
begin
--   Manifest
--     PAGE: 00116
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>116
,p_name=>'Search Results'
,p_alias=>'SEARCH-RESULTS'
,p_step_title=>'Search Results'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(7418988128250509952)
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'ul.sSearchResultsReport span.title span.highlight {',
'  background-color: #FFEA87;',
'  text-decoration: underline',
'  }',
'ul.sSearchResultsReport span.highlight {',
'  background-color: #FFEA87;',
'  }',
'</style>'))
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(function() {',
' ',
'// search items',
'var $search = $(''#P116_SEARCH'');',
'var $include = $(''#P116_INCLUDE'');',
'var $searchBtn = $(''#search_btn'');',
'var $resetBtn = $(''#reset_btn'');',
'  ',
'// regions',
'var $searchResultsReg = $(''#search_results_reg'');',
'  ',
'var timeout = 0; // used for debounce on search',
'  ',
'function applyFilters() {',
'  $searchResultsReg.trigger(''apexrefresh'');',
'}',
'  ',
'function debounceSearch(e) {',
'    /*',
'     * Prevent search for following keys:',
'     * TAB:     9',
'     * SHIFT:   16',
'     * LEFT:    37',
'     * RIGHT:   39',
'     */',
'    if ( e.which === 9 || e.which === 16 || e.which === 37 || e.which === 39 ) {',
'        return false;',
'    }',
'    clearTimeout(timeout);',
'    timeout = setTimeout(applyFilters, 250);',
'}',
'  ',
'function preventSubmitOnEnter(e) {',
'  if (e.which === 13) {',
'    return false;',
'  }',
'}',
'  ',
'function resetFilters() {',
'  $search.val(null);',
'  $include.find(''input'').prop(''checked'', true);',
'  ',
'  $searchResultsReg.trigger(''apexrefresh'');',
'}',
'',
'$search.keydown(preventSubmitOnEnter);',
'$search.keyup(debounceSearch);',
'$include.change(applyFilters);',
'$searchBtn.click(applyFilters);',
'$resetBtn.click(resetFilters);',
'  ',
'})();'))
,p_step_template=>2526643373347724467
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'This page displays all of the opportunities that match the search term(s) entered in the app''s search page.'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(6574906334470091758)
,p_name=>'Search Results'
,p_region_name=>'search_results_reg'
,p_template=>4072358936313175081
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select search_link,',
'  substr(search_title,1,200) search_title,',
'  search_desc,',
'  ''Source'' label_01,',
'  source value_01,',
'  ''Key'' label_02,',
'  row_key value_02,',
'  ''Last Modified'' label_03,',
'  apex_util.get_since(updated) value_03,',
'  secondary_link',
'from (',
'  select ''Lead'' source,',
'    1 sort_order,',
'    l.lead_name_01 search_title,',
'    nvl(l.lead_details, ''*** no details provided ***'') search_desc,',
'    l.updated,',
'    apex_util.prepare_url(''f?p='' || :APP_ID || '':133:'' || :APP_SESSION || '':::RP,133:P133_ID:'' || l.id) search_link,',
'    '''' secondary_link,',
'    l.row_key',
'  from eba_sales_leads l',
'  where (',
'      instr(:P116_INCLUDE,''LEADS'') > 0 ',
'        and (',
'          instr(upper(l.lead_name_01), upper(:P116_SEARCH)) > 0',
'            or instr(upper(l.row_key), upper(:P116_SEARCH)) > 0',
'            or instr(upper(l.lead_details), upper(:P116_SEARCH)) > 0',
'            or instr(upper(l.tags), upper(:P116_SEARCH)) > 0',
'        )',
'    )',
'  union',
'  select ''Opportunity'' source,',
'    2 sort_order,',
'    o.deal_name search_title,',
'    nvl(o.deal_summary, ''*** no summary provided ***'') search_desc,',
'    o.updated,',
'    apex_util.prepare_url(''f?p='' || :APP_ID || '':80:'' || :APP_SESSION || '':::RP,80:P80_ID:'' || o.id) search_link,',
'    '''' secondary_link,',
'    o.row_key',
'  from eba_sales_deals o',
'  where (',
'      instr(:P116_INCLUDE,''OPPORTUNITIES'') > 0 ',
'        and (',
'          instr(upper(o.deal_name), upper(:P116_SEARCH)) > 0',
'            or instr(upper(o.row_key), upper(:P116_SEARCH)) > 0',
'            or instr(upper(o.deal_summary), upper(:P116_SEARCH)) > 0',
'            or instr(upper(o.tags), upper(:P116_SEARCH)) > 0',
'        )',
'    )',
'  union',
'  select ''Territory'' source,',
'    3 sort_order,',
'    t.territory_name search_title,',
'    nvl(t.territory_description, ''*** no description provided ***'') search_desc,',
'    t.updated,',
'    apex_util.prepare_url(''f?p='' || :APP_ID || '':93:'' || :APP_SESSION || '':::RP,93:P93_ID:'' || t.id) search_link,',
'    '''' secondary_link,',
'    t.row_key',
'  from eba_sales_territories t',
'  where (',
'      instr(:P116_INCLUDE,''TERRITORIES'') > 0 ',
'        and (',
'          instr(upper(t.territory_name), upper(:P116_SEARCH)) > 0',
'            or instr(upper(t.row_key), upper(:P116_SEARCH)) > 0',
'            or instr(upper(t.territory_description), upper(:P116_SEARCH)) > 0',
'            or instr(upper(t.tags), upper(:P116_SEARCH)) > 0',
'        )',
'    )',
'  union',
'  select ''Account'' source,',
'    4 sort_order,',
'    c.customer_name search_title,',
'    nvl(c.customer_description, ''*** no description provided ***'') search_desc,',
'    c.updated,',
'    apex_util.prepare_url(''f?p='' || :APP_ID || '':94:'' || :APP_SESSION || '':::RP,94:P94_ID:'' || c.id) search_link,',
'    '''' secondary_link,',
'    c.row_key',
'  from eba_sales_customers c',
'  where (',
'      instr(:P116_INCLUDE,''ACCOUNTS'') > 0 ',
'        and (',
'          instr(upper(c.customer_name), upper(:P116_SEARCH)) > 0',
'            or instr(upper(c.row_key), upper(:P116_SEARCH)) > 0',
'            or instr(upper(c.customer_description), upper(:P116_SEARCH)) > 0',
'            or instr(upper(c.tags), upper(:P116_SEARCH)) > 0',
'        )',
'    )',
'  union',
'  select ''Contact'' source,',
'    5 sort_order,',
'    c.contact_name search_title,',
'    nvl(c.contact_description, ''*** no description provided ***'') search_desc,',
'    c.updated,',
'    apex_util.prepare_url(''f?p='' || :APP_ID || '':94:'' || :APP_SESSION || '':::RP,94:P94_ID:'' || c.id) search_link,',
'    '''' secondary_link,',
'    c.row_key',
'  from eba_sales_customer_contacts c',
'  where (',
'      instr(:P116_INCLUDE,''CONTACTS'') > 0 ',
'        and (',
'          instr(upper(c.contact_name), upper(:P116_SEARCH)) > 0',
'            or instr(upper(c.contact_description), upper(:P116_SEARCH)) > 0',
'            or instr(upper(c.tags), upper(:P116_SEARCH)) > 0',
'            or instr(upper(c.contact_email), upper(:P116_SEARCH)) > 0',
'            or instr(upper(c.contact_phone), upper(:P116_SEARCH)) > 0',
'            or instr(upper(c.contact_cell), upper(:P116_SEARCH)) > 0',
'            or instr(upper(c.contact_address), upper(:P116_SEARCH)) > 0',
'            or instr(upper(c.contact_linkedin), upper(:P116_SEARCH)) > 0',
'            or instr(upper(c.contact_facebook), upper(:P116_SEARCH)) > 0',
'            or instr(upper(c.contact_twitter), upper(:P116_SEARCH)) > 0',
'        )',
'    )',
'  union',
'  select ''Product'' source,',
'    6 sort_order,',
'    p.product_name search_title,',
'    nvl(p.product_description, ''*** no description provided ***'') search_desc,',
'    p.updated,',
'    apex_util.prepare_url(''f?p='' || :APP_ID || '':94:'' || :APP_SESSION || '':::RP,94:P94_ID:'' || p.id) search_link,',
'    '''' secondary_link,',
'    p.row_key',
'  from eba_sales_products p',
'  where (',
'      instr(:P116_INCLUDE,''PRODUCTS'') > 0 ',
'        and (',
'          instr(upper(p.product_name), upper(:P116_SEARCH)) > 0',
'            or instr(upper(p.row_key), upper(:P116_SEARCH)) > 0',
'            or instr(upper(p.product_description), upper(:P116_SEARCH)) > 0',
'            or instr(upper(p.tags), upper(:P116_SEARCH)) > 0',
'        )',
'    )',
')',
'order by sort_order'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P116_SEARCH,P116_INCLUDE'
,p_lazy_loading=>false
,p_query_row_template=>4072360234311175085
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'No match found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6574906538371091760)
,p_query_column_id=>1
,p_column_alias=>'SEARCH_LINK'
,p_column_display_sequence=>1
,p_column_heading=>'Search link'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6574906718771091761)
,p_query_column_id=>2
,p_column_alias=>'SEARCH_TITLE'
,p_column_display_sequence=>2
,p_column_heading=>'Search title'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6574906821677091762)
,p_query_column_id=>3
,p_column_alias=>'SEARCH_DESC'
,p_column_display_sequence=>3
,p_column_heading=>'Search desc'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6574906827751091763)
,p_query_column_id=>4
,p_column_alias=>'LABEL_01'
,p_column_display_sequence=>4
,p_column_heading=>'Label 01'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6574906997361091764)
,p_query_column_id=>5
,p_column_alias=>'VALUE_01'
,p_column_display_sequence=>5
,p_column_heading=>'Value 01'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6574907078054091765)
,p_query_column_id=>6
,p_column_alias=>'LABEL_02'
,p_column_display_sequence=>6
,p_column_heading=>'Label 02'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6574907143211091766)
,p_query_column_id=>7
,p_column_alias=>'VALUE_02'
,p_column_display_sequence=>7
,p_column_heading=>'Value 02'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6574907266335091767)
,p_query_column_id=>8
,p_column_alias=>'LABEL_03'
,p_column_display_sequence=>8
,p_column_heading=>'Label 03'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6574907374146091768)
,p_query_column_id=>9
,p_column_alias=>'VALUE_03'
,p_column_display_sequence=>9
,p_column_heading=>'Value 03'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6574907430597091769)
,p_query_column_id=>10
,p_column_alias=>'SECONDARY_LINK'
,p_column_display_sequence=>10
,p_column_heading=>'Secondary link'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9036084146725929279)
,p_plug_name=>'Filters'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody:t-Form--stretchInputs'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_02'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9036085731725929285)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--showBreadcrumb:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(10512992898526525834)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
,p_translate_title=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9036084346309929280)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9036084146725929279)
,p_button_name=>'SEARCH'
,p_button_static_id=>'search_btn'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Search'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9036084530430929281)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(9036084146725929279)
,p_button_name=>'RESET_REPORT'
,p_button_static_id=>'reset_btn'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Reset'
,p_button_position=>'CLOSE'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(9036086334418929295)
,p_branch_action=>'f?p=&APP_ID.:116:&SESSION.::&DEBUG.:::'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_comment=>'Created 14-DEC-2011 09:16 by SHAKEEB'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6587351582090639646)
,p_name=>'P116_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(9036084146725929279)
,p_prompt=>'Search'
,p_placeholder=>'Search'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>2040785906935475274
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9036084938258929282)
,p_name=>'P116_INCLUDE'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9036084146725929279)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if apex_util.get_build_option_status(',
'  p_application_id    => :APP_ID,',
'  p_build_option_name => ''Territories''',
') = ''INCLUDE''',
'then',
'  return ''LEADS:OPPORTUNITIES:TERRITORIES:ACCOUNTS:CONTACTS:PRODUCTS'';',
'else',
'  return ''LEADS:OPPORTUNITIES:ACCOUNTS:CONTACTS:PRODUCTS'';',
'end if;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Include'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'SEARCH PAGE, INCLUDE OPTIONS'
,p_lov=>'.'||wwv_flow_imp.id(9036136457951925676)||'.'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_restricted_characters=>'WEB_SAFE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
);
wwv_flow_imp.component_end;
end;
/
