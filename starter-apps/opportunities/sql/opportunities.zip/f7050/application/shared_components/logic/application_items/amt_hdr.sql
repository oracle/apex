prompt --application/shared_components/logic/application_items/amt_hdr
begin
--   Manifest
--     APPLICATION ITEM: AMT_HDR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(8088148343576399566)
,p_name=>'AMT_HDR'
,p_protection_level=>'I'
,p_version_scn=>'37166093793166'
);
wwv_flow_imp.component_end;
end;
/
