prompt --application/deployment/install/install_eba_sales_tz_pref
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_tz_pref
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_TZ_PREF" '||wwv_flow.LF||
'   (	"ID" NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER(*,';
wwv_flow_imp.g_varchar2_table(2) := '0), '||wwv_flow.LF||
'	"USERID" VARCHAR2(255) NOT NULL ENABLE, '||wwv_flow.LF||
'	"TIMEZONE_PREFERENCE" VARCHAR2(255) NOT NULL ENABLE,';
wwv_flow_imp.g_varchar2_table(3) := ' '||wwv_flow.LF||
'	"CREATED" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"CREATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	"UPDATED" TIMESTAMP (6) W';
wwv_flow_imp.g_varchar2_table(4) := 'ITH TIME ZONE, '||wwv_flow.LF||
'	"UPDATED_BY" VARCHAR2(255), '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SALES_TZ_PREF_PK" PRIMARY KEY ("ID")';
wwv_flow_imp.g_varchar2_table(5) := ''||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814632647996262388)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_tz_pref'
,p_sequence=>490
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814632778285262389)
,p_script_id=>wwv_flow_imp.id(6814632647996262388)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_TZ_PREF'
);
wwv_flow_imp.component_end;
end;
/
