prompt --application/deployment/install/install_eba_sales_access_levels
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_access_levels
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_ACCESS_LEVELS" '||wwv_flow.LF||
'   (	"ID" NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'	"ACCESS_LEVEL" VARCHAR2(';
wwv_flow_imp.g_varchar2_table(2) := '30) NOT NULL ENABLE, '||wwv_flow.LF||
'	"ROW_VERSION" NUMBER, '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SALES_ACCESS_LEVELS_PK" PRIMARY KEY ';
wwv_flow_imp.g_varchar2_table(3) := '("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE, '||wwv_flow.LF||
'	 CONSTRAINT "EBA_SALES_ACCESS_LEVELS_CK" CHECK (access_level in ( ''A';
wwv_flow_imp.g_varchar2_table(4) := 'dministrator'', ''Contributor'', ''Reader'', ''Approval Pending'', ''No Access'' )) ENABLE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814453846796796927)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_access_levels'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814453963592796928)
,p_script_id=>wwv_flow_imp.id(6814453846796796927)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_ACCESS_LEVELS'
);
wwv_flow_imp.component_end;
end;
/
