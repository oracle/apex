prompt --application/deployment/install/install_eba_sales_sales_periods
begin
--   Manifest
--     INSTALL: INSTALL-eba_sales_sales_periods
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_SALES_PERIODS" '||wwv_flow.LF||
'   (	"ID" NUMBER, '||wwv_flow.LF||
'	"ROW_VERSION_NUMBER" NUMBER, '||wwv_flow.LF||
'	"PERIOD_N';
wwv_flow_imp.g_varchar2_table(2) := 'AME" VARCHAR2(255) NOT NULL ENABLE, '||wwv_flow.LF||
'	"FIRST_DAY" TIMESTAMP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"LAST_DAY" TIMESTA';
wwv_flow_imp.g_varchar2_table(3) := 'MP (6) WITH TIME ZONE, '||wwv_flow.LF||
'	"FISCAL_YEAR" NUMBER(2,0), '||wwv_flow.LF||
'	 PRIMARY KEY ("ID")'||wwv_flow.LF||
'  USING INDEX  ENABLE'||wwv_flow.LF||
'   )';
wwv_flow_imp.g_varchar2_table(4) := ' ;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6814620395466227228)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'eba_sales_sales_periods'
,p_sequence=>410
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(6814620473831227228)
,p_script_id=>wwv_flow_imp.id(6814620395466227228)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_SALES_SALES_PERIODS'
);
wwv_flow_imp.component_end;
end;
/
