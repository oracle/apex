prompt --application/deployment/install/upgrade_customer_support_amount_map
begin
--   Manifest
--     INSTALL: UPGRADE-Customer Support Amount Map
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_SALES_CUST_SPT_AMT_MAP" '||wwv_flow.LF||
'('||wwv_flow.LF||
'    "ID" NUMBER,'||wwv_flow.LF||
'    "ROW_VERSION_NUMBER" NUMBER,'||wwv_flow.LF||
'    "';
wwv_flow_imp.g_varchar2_table(2) := 'NAME" VARCHAR2(255),'||wwv_flow.LF||
'    "CLOSE_DATE" TIMESTAMP (6) WITH TIME ZONE,'||wwv_flow.LF||
'    "TERM_ID" NUMBER references ';
wwv_flow_imp.g_varchar2_table(3) := 'EBA_SALES_TERMS on delete set null,'||wwv_flow.LF||
'    "CUSTOMER_ID" NUMBER references EBA_SALES_CUSTOMERS on delet';
wwv_flow_imp.g_varchar2_table(4) := 'e set null,'||wwv_flow.LF||
'    "AMOUNT_ID" NUMBER references EBA_SALES_SUPPORT_AMTS on delete cascade,'||wwv_flow.LF||
'    "QUOTE_P';
wwv_flow_imp.g_varchar2_table(5) := 'RICE" NUMBER,'||wwv_flow.LF||
'    "DESCRIPTION" VARCHAR2(4000),'||wwv_flow.LF||
'    "CREATED_BY" VARCHAR2(255),'||wwv_flow.LF||
'    "CREATED" TIMEST';
wwv_flow_imp.g_varchar2_table(6) := 'AMP (6) WITH TIME ZONE,'||wwv_flow.LF||
'    "UPDATED_BY" VARCHAR2(255),'||wwv_flow.LF||
'    "UPDATED" TIMESTAMP (6) WITH TIME ZONE,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(7) := '     PRIMARY KEY ("ID")  USING INDEX  ENABLE'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER "BIU_EBA_SALES_CUST_SPT_A';
wwv_flow_imp.g_varchar2_table(8) := 'MT_MAP" '||wwv_flow.LF||
'   before insert or update on EBA_SALES_CUST_SPT_AMT_MAP'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if ';
wwv_flow_imp.g_varchar2_table(9) := 'inserting then'||wwv_flow.LF||
'         if :NEW.ID is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(10) := 'XXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'           into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.';
wwv_flow_imp.g_varchar2_table(11) := 'CREATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.upd';
wwv_flow_imp.g_varchar2_table(12) := 'ated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.updated := current_timestamp;'||wwv_flow.LF||
'         :new.row_ve';
wwv_flow_imp.g_varchar2_table(13) := 'rsion_number := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(14) := '         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:old.ro';
wwv_flow_imp.g_varchar2_table(15) := 'w_version_number,1) + 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TRIGGER "BIU_EBA_SALES_CUST_SPT_AMT_MAP" ENABLE';
wwv_flow_imp.g_varchar2_table(16) := ';';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8473764048765196174)
,p_install_id=>wwv_flow_imp.id(10512994198141527757)
,p_name=>'Customer Support Amount Map'
,p_sequence=>190
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_SALES_CUST_SPT_AMT_MAP'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
