prompt --application/create_application
begin
--   Manifest
--     FLOW: 7050
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_imp_workspace.create_flow(
 p_id=>wwv_flow.g_flow_id
,p_owner=>nvl(wwv_flow_application_install.get_schema,'ORACLE')
,p_name=>nvl(wwv_flow_application_install.get_application_name,'Opportunities')
,p_alias=>nvl(wwv_flow_application_install.get_application_alias,'OPPORTUNITIES')
,p_application_group=>wwv_flow_imp.id(178129388996107318)
,p_application_group_name=>'Starter Apps'
,p_application_group_static_id=>'starter-apps'
,p_page_view_logging=>'YES'
,p_page_protection_enabled_y_n=>'Y'
,p_checksum_salt=>'40468B10AECAD957E04758D38A5A131344A0F095B504A0F77A07286C45405C0B'
,p_checksum_salt_last_reset_dt=>to_date('19990804000000','YYYYMMDDHH24MISS')
,p_bookmark_checksum_function=>'SH512'
,p_max_session_length_sec=>28800
,p_compatibility_mode=>'26.1'
,p_flow_language=>'en-us'
,p_flow_language_derived_from=>'FLOW_PRIMARY_LANGUAGE'
,p_direction_right_to_left=>'N'
,p_flow_image_prefix=>nvl(wwv_flow_application_install.get_image_prefix,'')
,p_documentation_banner=>wwv_flow_string.join(wwv_flow_t_varchar2(
'0.9.25 -> 0.9.26: Fixed code in eba_sales_acl_api.apex_error_handling() procedure to allow the correct error message to be displayed when a page item''s "Restricted characters" security setting has been violated.',
'0.9.26 -> 0.9.27: Implemented redesigned administrative ACL controls',
'0.9.27 -> 0.9.28: Added Usage Metrics region plugin to pages 80 (Opportunity), 94 (Account) and 133 (Lead)',
'0.9.28 -> 1.1.26: Updated version level to match APEX metadata'))
,p_authentication_id=>wwv_flow_imp.id(10512991499736525824)
,p_application_tab_set=>0
,p_logo_type=>'T'
,p_logo_text=>'&APPLICATION_TITLE.'
,p_public_user=>'APEX_PUBLIC_USER'
,p_proxy_server=>nvl(wwv_flow_application_install.get_proxy,'')
,p_no_proxy_domains=>nvl(wwv_flow_application_install.get_no_proxy_domains,'')
,p_flow_version=>'26.1.0'
,p_flow_status=>'AVAILABLE_W_EDIT_LINK'
,p_browser_cache=>'N'
,p_browser_frame=>'S'
,p_deep_linking=>'Y'
,p_runtime_api_usage=>'T'
,p_pass_ecid=>'N'
,p_security_scheme=>wwv_flow_imp.id(9060293030324296381)
,p_rejoin_existing_sessions=>'P'
,p_csv_encoding=>'N'
,p_error_handling_function=>'eba_sales_acl_api.apex_error_handling'
,p_tokenize_row_search=>'N'
,p_modernization_available=>'Y'
,p_substitution_string_01=>'APP_DATE_FORMAT'
,p_substitution_value_01=>'DD-MON-YYYY'
,p_substitution_string_02=>'APP_DATE_TIME_FMT'
,p_substitution_value_02=>'DD-MON-YYYY HH:MI PM'
,p_substitution_string_03=>'APP_NAME'
,p_substitution_value_03=>'Opportunities'
,p_file_prefix=>nvl(wwv_flow_application_install.get_static_app_file_prefix,'')
,p_files_version=>4
,p_version_scn=>'123508552'
,p_print_server_type=>'INSTANCE'
,p_file_storage=>'DB'
,p_is_pwa=>'N'
,p_copyright_banner=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Name: #APP_NAME#',
'Copyright (c) 2012, #YEAR# Oracle and/or its affiliates.',
'Licensed under the Universal Permissive License v 1.0',
'as shown at https://oss.oracle.com/licenses/upl/'))
,p_theme_id=>42
,p_home_url=>'f?p=&APP_ID.:100:&SESSION.'
,p_theme_style_by_user_pref=>true
,p_global_page_id=>0
,p_navigation_list_id=>wwv_flow_imp.id(7361715581125848308)
,p_navigation_list_position=>'SIDE'
,p_navigation_list_template_id=>2469215554099805162
,p_nav_list_template_options=>'#DEFAULT#:js-defaultCollapsed:js-navCollapsed--hidden:t-TreeNav--styleA'
,p_css_file_urls=>'#IMAGE_PREFIX#pkgapp_ui/css/5.0#MIN#.css'
,p_include_legacy_javascript=>'PRE18:18'
,p_nav_bar_type=>'LIST'
,p_nav_bar_list_id=>wwv_flow_imp.id(7082413943185847681)
,p_nav_bar_list_template_id=>2849019392706229583
);
wwv_flow_imp.component_end;
end;
/
