prompt --application/pages/page_00149
begin
--   Manifest
--     PAGE: 00149
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7050
,p_default_id_offset=>17722191960753403
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>149
,p_name=>'Search Opportunities'
,p_alias=>'SEARCH-OPPORTUNITY-TRACKER'
,p_page_mode=>'MODAL'
,p_step_title=>'Search Opportunities'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Button.search-button {padding: 12px 16px;}',
''))
,p_step_template=>2125222674922027330
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'480'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6539773091371514396)
,p_plug_name=>'Search'
,p_static_id=>'search'
,p_region_css_classes=>'search-dialog'
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--xlarge:t-Form--stretchInputs'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6539773298880514398)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(6539773091371514396)
,p_button_name=>'Search'
,p_static_id=>'search'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--stretch'
,p_button_template_id=>4075790603270660137
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Search'
,p_button_css_classes=>'search-button'
,p_grid_column_css_classes=>'col-xxs-3'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>3
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(6539773352475514399)
,p_branch_name=>'Go to search'
,p_branch_action=>'f?p=&APP_ID.:116:&SESSION.::&DEBUG.:RP,116:P116_SEARCH:&P149_SEARCH.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6539773182097514397)
,p_name=>'P149_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6539773091371514396)
,p_prompt=>'Search'
,p_placeholder=>'Search Leads, Opportunities, and more...'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>0
,p_grid_column_css_classes=>'col-xxs-9'
,p_field_template=>2322028657308407345
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'Y',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp.component_end;
end;
/
