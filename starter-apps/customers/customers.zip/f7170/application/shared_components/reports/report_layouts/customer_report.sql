prompt --application/shared_components/reports/report_layouts/customer_report
begin
--   Manifest
--     REPORT LAYOUT: Customer_Report
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_report_layout(
 p_id=>wwv_flow_imp.id(17826631158865513414)
,p_report_layout_name=>'Customer_Report'
,p_static_id=>'CUSTOMER_REPORT'
,p_report_layout_type=>'RTF_FILE'
,p_page_template => wwv_flow_string.join_clob(wwv_flow_t_varchar2(
'{\rtf1\ansi\ansicpg1252\uc1 \deff0\deflang1033\deflangfe1033{\fonttbl{\f0\froman\fcharset0\fprq2{\*\',
'panose 02020603050405020304}Times New Roman;}{\f31\froman\fcharset238\fprq2 Times New Roman CE;}{\f3',
'2\froman\fcharset204\fprq2 Times New Roman Cyr;}'||wwv_flow.LF||
'{\f34\froman\fcharset161\fprq2 Times New Roman Gree',
'k;}{\f35\froman\fcharset162\fprq2 Times New Roman Tur;}{\f36\froman\fcharset177\fprq2 Times New Roma',
'n (Hebrew);}{\f37\froman\fcharset178\fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\f38\froman\fcharset186\fprq2',
' Times New Roman Baltic;}}{\colortbl;\red0\green0\blue0;\red0\green0\blue255;\red0\green255\blue255;',
'\red0\green255\blue0;\red255\green0\blue255;\red255\green0\blue0;\red255\green255\blue0;\red255\gree',
'n255\blue255;'||wwv_flow.LF||
'\red0\green0\blue128;\red0\green128\blue128;\red0\green128\blue0;\red128\green0\blue12',
'8;\red128\green0\blue0;\red128\green128\blue0;\red128\green128\blue128;\red192\green192\blue192;\red',
'231\green243\blue253;\red0\green51\blue0;}{\stylesheet{'||wwv_flow.LF||
'\ql \li0\ri0\widctlpar\aspalpha\aspnum\faaut',
'o\adjustright\rin0\lin0\itap0 \fs24\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 \snext0 Normal',
';}{\*\cs10 \additive Default Paragraph Font;}}{\info{\title USER_NAME}{\author user}{\operator user}',
''||wwv_flow.LF||
'{\creatim\yr2007\mo6\dy4\hr12\min11}{\revtim\yr2007\mo6\dy4\hr12\min11}{\version2}{\edmins0}{\nofpa',
'ges1}{\nofwords0}{\nofchars0}{\nofcharsws0}{\vern8203}}'||wwv_flow.LF||
'\widowctrl\ftnbj\aenddoc\noxlattoyen\expshrt',
'n\noultrlspc\dntblnsbdb\nospaceforul\hyphcaps0\formshade\horzdoc\dgmargin\dghspace180\dgvspace180\dg',
'horigin1800\dgvorigin1440\dghshow1\dgvshow1'||wwv_flow.LF||
'\jexpand\viewkind1\viewscale100\pgbrdrhead\pgbrdrfoot\sp',
'lytwnine\ftnlytwnine\htmautsp\nolnhtadjtbl\useltbaln\alntblind\lytcalctblwd\lyttblrtgr\lnbrkrule \fe',
't0\sectd \linex0\endnhere\sectlinegrid360\sectdefaultcl {\*\pnseclvl1'||wwv_flow.LF||
'\pnucrm\pnstart1\pnindent720\p',
'nhang{\pntxta .}}{\*\pnseclvl2\pnucltr\pnstart1\pnindent720\pnhang{\pntxta .}}{\*\pnseclvl3\pndec\pn',
'start1\pnindent720\pnhang{\pntxta .}}{\*\pnseclvl4\pnlcltr\pnstart1\pnindent720\pnhang{\pntxta )}}{\',
'*\pnseclvl5'||wwv_flow.LF||
'\pndec\pnstart1\pnindent720\pnhang{\pntxtb (}{\pntxta )}}{\*\pnseclvl6\pnlcltr\pnstart1\',
'pnindent720\pnhang{\pntxtb (}{\pntxta )}}{\*\pnseclvl7\pnlcrm\pnstart1\pnindent720\pnhang{\pntxtb (}',
'{\pntxta )}}{\*\pnseclvl8\pnlcltr\pnstart1\pnindent720\pnhang'||wwv_flow.LF||
'{\pntxtb (}{\pntxta )}}{\*\pnseclvl9\p',
'nlcrm\pnstart1\pnindent720\pnhang{\pntxtb (}{\pntxta )}}\pard\plain \ql \li0\ri0\widctlpar\aspalpha\',
'aspnum\faauto\adjustright\rin0\lin0\itap0 \fs24\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 {\',
'*\bkmkstart Text1'||wwv_flow.LF||
'}{\field\flddirty{\*\fldinst { FORMTEXT }{{\*\datafield 80010000000000000554657874',
'310009555345525f4e414d4500000000000d3c3f555345525f4e414d453f3e0000000000}{\*\formfield{\fftype0\ffow',
'nhelp\ffownstat\fftypetxt0{\*\ffname Text1}{\*\ffdeftext USER_NAME}'||wwv_flow.LF||
'{\*\ffstattext <?USER_NAME?>}}}}',
'}{\fldrslt {\lang1024\langfe1024\noproof USER_NAME}}}{{\*\bkmkend Text1}'||wwv_flow.LF||
'\par {\*\bkmkstart Text2}}{',
'\field\flddirty{\*\fldinst { FORMTEXT }{{\*\datafield 8001000000000000055465787432001050325f43555354',
'4f4d45525f4e414d450000000000143c3f50325f435553544f4d45525f4e414d453f3e0000000000}'||wwv_flow.LF||
'{\*\formfield{\fft',
'ype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text2}{\*\ffdeftext P2_CUSTOMER_NAME}{\*\ffstattext <?',
'P2_CUSTOMER_NAME?>}}}}}{\fldrslt {\lang1024\langfe1024\noproof P2_CUSTOMER_NAME}}}{{\*\bkmkend Text2',
'}'||wwv_flow.LF||
'\par '||wwv_flow.LF||
'\par {\*\bkmkstart Text3}}{\field\flddirty{\*\fldinst {\cf9  FORMTEXT }{\cf9 {\*\datafield '||wwv_flow.LF||
'',
'80010000000000000554657874330001470000000000473c3f666f722d656163682d67726f75703a524f573b2e2f4e414d45',
'3f3e3c3f736f72743a4e414d453b27617363656e64696e67273b646174612d747970653d2774657874273f3e0000000000}{',
'\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0'||wwv_flow.LF||
'{\*\ffname Text3}{\*\ffdeftext G}{\*\ffstattext',
' <?for-each-group:ROW\''3b./NAME?><?sort:NAME\''3b''ascending''\''3bdata-type=''text''?>}}}}}{\fldrslt {\cf',
'9\lang1024\langfe1024\noproof G}}}{{\*\bkmkend Text3}'||wwv_flow.LF||
'\par {\*\bkmkstart Text4}}{\field\flddirty{\*\',
'fldinst { FORMTEXT }{{\*\datafield 800100000000000005546578743400044e414d450000000000083c3f4e414d453',
'f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text4}{\*\ffdeftext NA',
'ME}'||wwv_flow.LF||
'{\*\ffstattext <?NAME?>}}}}}{\fldrslt {\lang1024\langfe1024\noproof NAME}}}{{\*\bkmkend Text4}'||wwv_flow.LF||
'\',
'par }\trowd \trgaph108\trleft-108\trhdr\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\',
'brdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 \trftsWidth1\trautofit1',
'\trpaddl108\trpaddr108\trpaddfl3\trpaddfr3 \clvertalt'||wwv_flow.LF||
'\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 ',
'\clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth1265 \cellx109',
'7\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw',
'10 '||wwv_flow.LF||
'\clcbpat17\cltxlrtb\clftsWidth3\clwWidth1265 \cellx2324\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl',
'\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidt',
'h1265 \cellx3545\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clb',
'rdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth1265 \cellx4962\clvertalt\clbrdrt\brdrs\b',
'rdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\clcbpat17\cltxlrtb\clf',
'tsWidth3\clwWidth1265 \cellx6152\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brd',
'rs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth1265 \cellx7371\clvertalt\',
'clbrdrt\brdrs\brdrw10 \clbrdrl'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat',
'17\cltxlrtb\clftsWidth3\clwWidth1266 \cellx8748\pard \ql \li0\ri0\widctlpar\intbl\aspalpha\aspnum\fa',
'auto\adjustright\rin0\lin0 {\b Title}{\cell }{\b Phone}{\cell }{\b Email}{\cell }{\b '||wwv_flow.LF||
'Company}{\cell',
' }{\b City}{\cell }{\b State}{\cell }{\b Country}{\cell }\pard \ql \li0\ri0\widctlpar\intbl\aspalpha',
'\aspnum\faauto\adjustright\rin0\lin0 {\trowd \trgaph108\trleft-108\trhdr\trbrdrt\brdrs\brdrw10 \trbr',
'drl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 '||wwv_flow.LF||
'\trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brd',
'rs\brdrw10 \trftsWidth1\trautofit1\trpaddl108\trpaddr108\trpaddfl3\trpaddfr3 \clvertalt\clbrdrt\brdr',
's\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\clcbpat17\cltxlrtb\',
'clftsWidth3\clwWidth1265 \cellx1097\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\',
'brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth1265 \cellx2324\clverta',
'lt\clbrdrt\brdrs\brdrw10 \clbrdrl'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcb',
'pat17\cltxlrtb\clftsWidth3\clwWidth1265 \cellx3545\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\br',
'drw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\clcbpat17\cltxlrtb\clftsWidth3\clwWidth1265 \c',
'ellx4962\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdr',
's\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidth1265 \cellx6152\clvertalt\clbrdrt\brdrs\brdrw10 \c',
'lbrdrl'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\',
'clwWidth1265 \cellx7371\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw1',
'0 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\clcbpat17\cltxlrtb\clftsWidth3\clwWidth1266 \cellx8748\row }\trowd \trgap',
'h108\trleft-108\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\b',
'rdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trautofit1\trpaddl108\trpaddr108\',
'trpaddfl3\trpaddfr3 \clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \',
'clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth1265 \cellx1097\clvertalt\clbrdrt\brdrs\brdrw10 ',
'\clbrdrl'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth',
'1265 \cellx2324\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrd',
'rr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth1265 \cellx3545'||wwv_flow.LF||
'\clvertalt\clbrdrt\brdrs\brdrw10 \clb',
'rdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth1265 ',
'\cellx4962\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\br',
'drs\brdrw10 '||wwv_flow.LF||
'\cltxlrtb\clftsWidth3\clwWidth1265 \cellx6152\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\',
'brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth1265 \cell',
'x7371\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 '||wwv_flow.LF||
'\clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\',
'brdrw10 \cltxlrtb\clftsWidth3\clwWidth1266 \cellx8748\pard \ql \li0\ri0\widctlpar\intbl\aspalpha\asp',
'num\faauto\adjustright\rin0\lin0 {\*\bkmkstart Text5}{\field\flddirty{\*\fldinst {\cf18  FORMTEXT }{',
'\cf18 '||wwv_flow.LF||
'{\*\datafield 800100000000000005546578743500014600000000001c3c3f666f722d656163683a63757272656',
'e742d67726f757028293f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Te',
'xt5}{\*\ffdeftext F}{\*\ffstattext '||wwv_flow.LF||
'<?for-each:current-group()?>}}}}}{\fldrslt {\cf18\lang1024\langf',
'e1024\noproof F}}}{\cf18 {\*\bkmkend Text5} {\*\bkmkstart Text6}}{\field\flddirty{\*\fldinst { FORMT',
'EXT }{{\*\datafield '||wwv_flow.LF||
'800100000000000005546578743600055449544c450000000000093c3f5449544c453f3e0000000',
'000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text6}{\*\ffdeftext TITLE}{\*\ff',
'stattext <?TITLE?>}}}}}{\fldrslt {\lang1024\langfe1024\noproof TITLE}}}{'||wwv_flow.LF||
'{\*\bkmkend Text6}\cell {\*',
'\bkmkstart Text7}}{\field\flddirty{\*\fldinst { FORMTEXT }{{\*\datafield 800100000000000005546578743',
'7000550484f4e450000000000093c3f50484f4e453f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\f',
'ftypetxt0{\*\ffname Text7}'||wwv_flow.LF||
'{\*\ffdeftext PHONE}{\*\ffstattext <?PHONE?>}}}}}{\fldrslt {\lang1024\lan',
'gfe1024\noproof PHONE}}}{{\*\bkmkend Text7}\cell {\*\bkmkstart Text8}}{\field\flddirty{\*\fldinst { ',
'FORMTEXT }{{\*\datafield '||wwv_flow.LF||
'80010000000000000554657874380005454d41494c0000000000093c3f454d41494c3f3e00',
'00000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text8}{\*\ffdeftext EMAIL}{',
'\*\ffstattext <?EMAIL?>}}}}}{\fldrslt {\lang1024\langfe1024\noproof EMAIL}}}{'||wwv_flow.LF||
'{\*\bkmkend Text8}\cel',
'l {\*\bkmkstart Text9}}{\field\flddirty{\*\fldinst { FORMTEXT }{{\*\datafield 8001000000000000055465',
'7874390007434f4d50414e5900000000000b3c3f434f4d50414e593f3e0000000000}{\*\formfield{\fftype0\ffownhel',
'p\ffownstat\fftypetxt0{\*\ffname '||wwv_flow.LF||
'Text9}{\*\ffdeftext COMPANY}{\*\ffstattext <?COMPANY?>}}}}}{\fldrs',
'lt {\lang1024\langfe1024\noproof COMPANY}}}{{\*\bkmkend Text9}\cell {\*\bkmkstart Text10}}{\field\fl',
'ddirty{\*\fldinst { FORMTEXT }{{\*\datafield '||wwv_flow.LF||
'800100000000000006546578743130000443495459000000000008',
'3c3f434954593f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text10}{\',
'*\ffdeftext CITY}{\*\ffstattext <?CITY?>}}}}}{\fldrslt {\lang1024\langfe1024\noproof CITY}}}{'||wwv_flow.LF||
'{\*\bk',
'mkend Text10}\cell {\*\bkmkstart Text11}}{\field\flddirty{\*\fldinst { FORMTEXT }{{\*\datafield 8001',
'00000000000006546578743131000553544154450000000000093c3f53544154453f3e0000000000}{\*\formfield{\ffty',
'pe0\ffownhelp\ffownstat\fftypetxt0{\*\ffname '||wwv_flow.LF||
'Text11}{\*\ffdeftext STATE}{\*\ffstattext <?STATE?>}}}',
'}}{\fldrslt {\lang1024\langfe1024\noproof STATE}}}{{\*\bkmkend Text11}\cell {\*\bkmkstart Text12}}{\',
'field\flddirty{\*\fldinst { FORMTEXT }{{\*\datafield '||wwv_flow.LF||
'8001000000000000065465787431320007434f554e5452',
'5900000000000b3c3f434f554e5452593f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0',
'{\*\ffname Text12}{\*\ffdeftext COUNTRY}{\*\ffstattext <?COUNTRY?>}}}}}{\fldrslt {'||wwv_flow.LF||
'\lang1024\langfe1',
'024\noproof COUNTRY}}}{{\*\bkmkend Text12}  {\*\bkmkstart Text13}}{\field\flddirty{\*\fldinst {\cf18',
'  FORMTEXT }{\cf18 {\*\datafield 8001000000000000065465787431330001450000000000103c3f656e6420666f722',
'd656163683f3e0000000000}'||wwv_flow.LF||
'{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text13}{\*\',
'ffdeftext E}{\*\ffstattext <?end for-each?>}}}}}{\fldrslt {\cf18\lang1024\langfe1024\noproof E}}}{{\',
'*\bkmkend Text13}\cell }\pard '||wwv_flow.LF||
'\ql \li0\ri0\widctlpar\intbl\aspalpha\aspnum\faauto\adjustright\rin0\',
'lin0 {\trowd \trgaph108\trleft-108\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw',
'10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trautofit1\trp',
'addl108\trpaddr108\trpaddfl3\trpaddfr3 \clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbr',
'drb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth1265 \cellx1097\clvertalt\clb',
'rdrt\brdrs\brdrw10 \clbrdrl'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\c',
'lftsWidth3\clwWidth1265 \cellx2324\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\b',
'rdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth1265 \cellx3545'||wwv_flow.LF||
'\clvertalt\clbrdrt',
'\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsW',
'idth3\clwWidth1265 \cellx4962\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\',
'brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\cltxlrtb\clftsWidth3\clwWidth1265 \cellx6152\clvertalt\clbrdrt\brdr',
's\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3',
'\clwWidth1265 \cellx7371\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 '||wwv_flow.LF||
'\clbrdrb\brdrs\brdr',
'w10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth1266 \cellx8748\row }\pard \ql \li0\ri0\wid',
'ctlpar\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 {'||wwv_flow.LF||
'\par  {\*\bkmkstart Text14}}{\field\fldd',
'irty{\*\fldinst {\cf9  FORMTEXT }{\cf9 {\*\datafield 80010000000000000654657874313400014500000000001',
'63c3f656e6420666f722d656163682d67726f75703f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\f',
'ftypetxt0{\*\ffname '||wwv_flow.LF||
'Text14}{\*\ffdeftext E}{\*\ffstattext <?end for-each-group?>}}}}}{\fldrslt {\cf',
'9\lang1024\langfe1024\noproof E}}}{{\*\bkmkend Text14}'||wwv_flow.LF||
'\par }}'
))
,p_version_scn=>37166093824750
);
wwv_flow_imp.component_end;
end;
/
