prompt --application/shared_components/navigation/lists/data_load_process_train_customers_1816502813937938617
begin
--   Manifest
--     LIST: Data Load Process Train - Customers-1816502813937938617
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(18180535436640972069)
,p_name=>'Data Load Process Train - Customers-1816502813937938617'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089051550
);
wwv_flow_imp.component_end;
end;
/
