prompt --application/shared_components/logic/application_items/customer_use_case_help
begin
--   Manifest
--     APPLICATION ITEM: CUSTOMER_USE_CASE_HELP
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-13'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_flow_item(
 p_id=>wwv_flow_api.id(17125133671584839641)
,p_name=>'CUSTOMER_USE_CASE_HELP'
,p_protection_level=>'I'
,p_escape_on_http_output=>'N'
);
wwv_flow_api.component_end;
end;
/
