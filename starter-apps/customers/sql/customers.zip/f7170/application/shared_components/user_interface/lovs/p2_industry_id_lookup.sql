prompt --application/shared_components/user_interface/lovs/p2_industry_id_lookup
begin
--   Manifest
--     P2_INDUSTRY_ID LOOKUP
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(14837847793689754411)
,p_lov_name=>'P2_INDUSTRY_ID LOOKUP'
,p_static_id=>'p2-industry-id-lookup'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select INDUSTRY_NAME display_value, ID return_value ',
'from EBA_CUST_INDUSTRIES',
'order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>'1089051550'
);
wwv_flow_imp.component_end;
end;
/
