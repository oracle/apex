prompt --application/shared_components/user_interface/lovs/show_customer_views_checkbox
begin
--   Manifest
--     SHOW CUSTOMER VIEWS CHECKBOX
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(17963726352365952178)
,p_lov_name=>'SHOW CUSTOMER VIEWS CHECKBOX'
,p_static_id=>'show-customer-views-checkbox'
,p_lov_query=>'.'||wwv_flow_imp.id(17963726352365952178)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089051550'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(17963726761784952182)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Show Customer Views'
,p_lov_return_value=>'Y'
,p_static_id=>'show-customer-views'
);
wwv_flow_imp.component_end;
end;
/
