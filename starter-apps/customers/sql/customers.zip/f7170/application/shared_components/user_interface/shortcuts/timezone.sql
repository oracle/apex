prompt --application/shared_components/user_interface/shortcuts/timezone
begin
--   Manifest
--     SHORTCUT: TIMEZONE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_shortcut(
 p_id=>wwv_flow_imp.id(16625382694803855520)
,p_shortcut_name=>'TIMEZONE'
,p_shortcut_type=>'FUNCTION_BODY'
,p_shortcut_language=>'PLSQL'
,p_version_scn=>'32872768'
,p_shortcut=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_url varchar2(1000);',
'  l_tz  varchar2(1000);',
'begin',
'  l_url := apex_util.prepare_url( ''f?p='' || :APP_ID || '':76:'' || :APP_SESSION );',
'  l_tz  := nvl( apex_escape.html( apex_util.get_session_time_zone ),''unknown'' );',
'',
'  return ''<p>''||''Dates and Times are displayed in the ''||',
'         ''<a href="'' || l_url || ''">'' || l_tz || ''</a> timezone.</p>'';',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
