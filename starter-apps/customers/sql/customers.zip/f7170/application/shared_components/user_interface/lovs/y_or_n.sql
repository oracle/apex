prompt --application/shared_components/user_interface/lovs/y_or_n
begin
--   Manifest
--     Y_OR_N
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(17816434694596815039)
,p_lov_name=>'Y_OR_N'
,p_static_id=>'y-or-n'
,p_lov_query=>'.'||wwv_flow_imp.id(17816434694596815039)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089051550'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(17816435112982815058)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'No'
,p_lov_return_value=>'N'
,p_static_id=>'no'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(17816434902780815049)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Yes'
,p_lov_return_value=>'Y'
,p_static_id=>'yes'
);
wwv_flow_imp.component_end;
end;
/
