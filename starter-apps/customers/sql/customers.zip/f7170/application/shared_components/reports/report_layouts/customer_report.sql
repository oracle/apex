prompt --application/shared_components/reports/report_layouts/customer_report
begin
--   Manifest
--     REPORT LAYOUT: Customer_Report
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '{\rtf1\ansi\ansicpg1252\uc1 \deff0\deflang1033\deflangfe1033{\fonttbl{\f0\froman\fcharset0\fprq2{\*\';
wwv_flow_imp.g_varchar2_table(2) := ''||wwv_flow.LF||
'panose 02020603050405020304}Times New Roman;}{\f31\froman\fcharset238\fprq2 Times New Roman CE;}{\f';
wwv_flow_imp.g_varchar2_table(3) := '3'||wwv_flow.LF||
'2\froman\fcharset204\fprq2 Times New Roman Cyr;}'||wwv_flow.LF||
'{\f34\froman\fcharset161\fprq2 Times New Roman Gr';
wwv_flow_imp.g_varchar2_table(4) := 'ee'||wwv_flow.LF||
'k;}{\f35\froman\fcharset162\fprq2 Times New Roman Tur;}{\f36\froman\fcharset177\fprq2 Times New R';
wwv_flow_imp.g_varchar2_table(5) := 'oma'||wwv_flow.LF||
'n (Hebrew);}{\f37\froman\fcharset178\fprq2 Times New Roman (Arabic);}'||wwv_flow.LF||
'{\f38\froman\fcharset186\f';
wwv_flow_imp.g_varchar2_table(6) := 'prq2'||wwv_flow.LF||
' Times New Roman Baltic;}}{\colortbl;\red0\green0\blue0;\red0\green0\blue255;\red0\green255\blu';
wwv_flow_imp.g_varchar2_table(7) := 'e255;'||wwv_flow.LF||
'\red0\green255\blue0;\red255\green0\blue255;\red255\green0\blue0;\red255\green255\blue0;\red25';
wwv_flow_imp.g_varchar2_table(8) := '5\gree'||wwv_flow.LF||
'n255\blue255;'||wwv_flow.LF||
'\red0\green0\blue128;\red0\green128\blue128;\red0\green128\blue0;\red128\green0';
wwv_flow_imp.g_varchar2_table(9) := '\blue12'||wwv_flow.LF||
'8;\red128\green0\blue0;\red128\green128\blue0;\red128\green128\blue128;\red192\green192\blue';
wwv_flow_imp.g_varchar2_table(10) := '192;\red'||wwv_flow.LF||
'231\green243\blue253;\red0\green51\blue0;}{\stylesheet{'||wwv_flow.LF||
'\ql \li0\ri0\widctlpar\aspalpha\asp';
wwv_flow_imp.g_varchar2_table(11) := 'num\faaut'||wwv_flow.LF||
'o\adjustright\rin0\lin0\itap0 \fs24\lang1033\langfe1033\cgrid\langnp1033\langfenp1033 \sne';
wwv_flow_imp.g_varchar2_table(12) := 'xt0 Normal'||wwv_flow.LF||
';}{\*\cs10 \additive Default Paragraph Font;}}{\info{\title USER_NAME}{\author user}{\ope';
wwv_flow_imp.g_varchar2_table(13) := 'rator user}'||wwv_flow.LF||
''||wwv_flow.LF||
'{\creatim\yr2007\mo6\dy4\hr12\min11}{\revtim\yr2007\mo6\dy4\hr12\min11}{\version2}{\edm';
wwv_flow_imp.g_varchar2_table(14) := 'ins0}{\nofpa'||wwv_flow.LF||
'ges1}{\nofwords0}{\nofchars0}{\nofcharsws0}{\vern8203}}'||wwv_flow.LF||
'\widowctrl\ftnbj\aenddoc\noxlat';
wwv_flow_imp.g_varchar2_table(15) := 'toyen\expshrt'||wwv_flow.LF||
'n\noultrlspc\dntblnsbdb\nospaceforul\hyphcaps0\formshade\horzdoc\dgmargin\dghspace180\';
wwv_flow_imp.g_varchar2_table(16) := 'dgvspace180\dg'||wwv_flow.LF||
'horigin1800\dgvorigin1440\dghshow1\dgvshow1'||wwv_flow.LF||
'\jexpand\viewkind1\viewscale100\pgbrdrhea';
wwv_flow_imp.g_varchar2_table(17) := 'd\pgbrdrfoot\sp'||wwv_flow.LF||
'lytwnine\ftnlytwnine\htmautsp\nolnhtadjtbl\useltbaln\alntblind\lytcalctblwd\lyttblrt';
wwv_flow_imp.g_varchar2_table(18) := 'gr\lnbrkrule \fe'||wwv_flow.LF||
't0\sectd \linex0\endnhere\sectlinegrid360\sectdefaultcl {\*\pnseclvl1'||wwv_flow.LF||
'\pnucrm\pnsta';
wwv_flow_imp.g_varchar2_table(19) := 'rt1\pnindent720\p'||wwv_flow.LF||
'nhang{\pntxta .}}{\*\pnseclvl2\pnucltr\pnstart1\pnindent720\pnhang{\pntxta .}}{\*\';
wwv_flow_imp.g_varchar2_table(20) := 'pnseclvl3\pndec\pn'||wwv_flow.LF||
'start1\pnindent720\pnhang{\pntxta .}}{\*\pnseclvl4\pnlcltr\pnstart1\pnindent720\p';
wwv_flow_imp.g_varchar2_table(21) := 'nhang{\pntxta )}}{\'||wwv_flow.LF||
'*\pnseclvl5'||wwv_flow.LF||
'\pndec\pnstart1\pnindent720\pnhang{\pntxtb (}{\pntxta )}}{\*\pnseclv';
wwv_flow_imp.g_varchar2_table(22) := 'l6\pnlcltr\pnstart1\'||wwv_flow.LF||
'pnindent720\pnhang{\pntxtb (}{\pntxta )}}{\*\pnseclvl7\pnlcrm\pnstart1\pnindent';
wwv_flow_imp.g_varchar2_table(23) := '720\pnhang{\pntxtb (}'||wwv_flow.LF||
'{\pntxta )}}{\*\pnseclvl8\pnlcltr\pnstart1\pnindent720\pnhang'||wwv_flow.LF||
'{\pntxtb (}{\pnt';
wwv_flow_imp.g_varchar2_table(24) := 'xta )}}{\*\pnseclvl9\p'||wwv_flow.LF||
'nlcrm\pnstart1\pnindent720\pnhang{\pntxtb (}{\pntxta )}}\pard\plain \ql \li0\';
wwv_flow_imp.g_varchar2_table(25) := 'ri0\widctlpar\aspalpha\'||wwv_flow.LF||
'aspnum\faauto\adjustright\rin0\lin0\itap0 \fs24\lang1033\langfe1033\cgrid\la';
wwv_flow_imp.g_varchar2_table(26) := 'ngnp1033\langfenp1033 {\'||wwv_flow.LF||
'*\bkmkstart Text1'||wwv_flow.LF||
'}{\field\flddirty{\*\fldinst { FORMTEXT }{{\*\datafield 8';
wwv_flow_imp.g_varchar2_table(27) := '0010000000000000554657874'||wwv_flow.LF||
'310009555345525f4e414d4500000000000d3c3f555345525f4e414d453f3e0000000000}{';
wwv_flow_imp.g_varchar2_table(28) := '\*\formfield{\fftype0\ffow'||wwv_flow.LF||
'nhelp\ffownstat\fftypetxt0{\*\ffname Text1}{\*\ffdeftext USER_NAME}'||wwv_flow.LF||
'{\*\f';
wwv_flow_imp.g_varchar2_table(29) := 'fstattext <?USER_NAME?>}}}}'||wwv_flow.LF||
'}{\fldrslt {\lang1024\langfe1024\noproof USER_NAME}}}{{\*\bkmkend Text1}';
wwv_flow_imp.g_varchar2_table(30) := ''||wwv_flow.LF||
'\par {\*\bkmkstart Text2}}{'||wwv_flow.LF||
'\field\flddirty{\*\fldinst { FORMTEXT }{{\*\datafield 80010000000000000';
wwv_flow_imp.g_varchar2_table(31) := '55465787432001050325f43555354'||wwv_flow.LF||
'4f4d45525f4e414d450000000000143c3f50325f435553544f4d45525f4e414d453f3e';
wwv_flow_imp.g_varchar2_table(32) := '0000000000}'||wwv_flow.LF||
'{\*\formfield{\fft'||wwv_flow.LF||
'ype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text2}{\*\ffdeftext P2_';
wwv_flow_imp.g_varchar2_table(33) := 'CUSTOMER_NAME}{\*\ffstattext <?'||wwv_flow.LF||
'P2_CUSTOMER_NAME?>}}}}}{\fldrslt {\lang1024\langfe1024\noproof P2_CU';
wwv_flow_imp.g_varchar2_table(34) := 'STOMER_NAME}}}{{\*\bkmkend Text2'||wwv_flow.LF||
'}'||wwv_flow.LF||
'\par '||wwv_flow.LF||
'\par {\*\bkmkstart Text3}}{\field\flddirty{\*\fldinst {\cf9';
wwv_flow_imp.g_varchar2_table(35) := '  FORMTEXT }{\cf9 {\*\datafield '||wwv_flow.LF||
''||wwv_flow.LF||
'80010000000000000554657874330001470000000000473c3f666f722d65616368';
wwv_flow_imp.g_varchar2_table(36) := '2d67726f75703a524f573b2e2f4e414d45'||wwv_flow.LF||
'3f3e3c3f736f72743a4e414d453b27617363656e64696e67273b646174612d747';
wwv_flow_imp.g_varchar2_table(37) := '970653d2774657874273f3e0000000000}{'||wwv_flow.LF||
'\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0'||wwv_flow.LF||
'{\*\ffname ';
wwv_flow_imp.g_varchar2_table(38) := 'Text3}{\*\ffdeftext G}{\*\ffstattext'||wwv_flow.LF||
' <?for-each-group:ROW\''3b./NAME?><?sort:NAME\''3b''ascending''\''3b';
wwv_flow_imp.g_varchar2_table(39) := 'data-type=''text''?>}}}}}{\fldrslt {\cf'||wwv_flow.LF||
'9\lang1024\langfe1024\noproof G}}}{{\*\bkmkend Text3}'||wwv_flow.LF||
'\par {\*';
wwv_flow_imp.g_varchar2_table(40) := '\bkmkstart Text4}}{\field\flddirty{\*\'||wwv_flow.LF||
'fldinst { FORMTEXT }{{\*\datafield 80010000000000000554657874';
wwv_flow_imp.g_varchar2_table(41) := '3400044e414d450000000000083c3f4e414d453'||wwv_flow.LF||
'f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fft';
wwv_flow_imp.g_varchar2_table(42) := 'ypetxt0{\*\ffname Text4}{\*\ffdeftext NA'||wwv_flow.LF||
'ME}'||wwv_flow.LF||
'{\*\ffstattext <?NAME?>}}}}}{\fldrslt {\lang1024\langfe';
wwv_flow_imp.g_varchar2_table(43) := '1024\noproof NAME}}}{{\*\bkmkend Text4}'||wwv_flow.LF||
'\'||wwv_flow.LF||
'par }\trowd \trgaph108\trleft-108\trhdr\trbrdrt\brdrs\brdr';
wwv_flow_imp.g_varchar2_table(44) := 'w10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\'||wwv_flow.LF||
'brdrw10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \tr';
wwv_flow_imp.g_varchar2_table(45) := 'brdrv\brdrs\brdrw10 \trftsWidth1\trautofit1'||wwv_flow.LF||
'\trpaddl108\trpaddr108\trpaddfl3\trpaddfr3 \clvertalt'||wwv_flow.LF||
'\c';
wwv_flow_imp.g_varchar2_table(46) := 'lbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 '||wwv_flow.LF||
'\clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat1';
wwv_flow_imp.g_varchar2_table(47) := '7\cltxlrtb\clftsWidth3\clwWidth1265 \cellx109'||wwv_flow.LF||
'7\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw';
wwv_flow_imp.g_varchar2_table(48) := '10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw'||wwv_flow.LF||
'10 '||wwv_flow.LF||
'\clcbpat17\cltxlrtb\clftsWidth3\clwWidth1265 \cel';
wwv_flow_imp.g_varchar2_table(49) := 'lx2324\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs';
wwv_flow_imp.g_varchar2_table(50) := '\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\clwWidt'||wwv_flow.LF||
'h1265 \cellx3545\clvertalt\clbrdrt\brdrs\brdrw10 \c';
wwv_flow_imp.g_varchar2_table(51) := 'lbrdrl'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clb'||wwv_flow.LF||
'rdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3';
wwv_flow_imp.g_varchar2_table(52) := '\clwWidth1265 \cellx4962\clvertalt\clbrdrt\brdrs\b'||wwv_flow.LF||
'rdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdr';
wwv_flow_imp.g_varchar2_table(53) := 'w10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\clcbpat17\cltxlrtb\clf'||wwv_flow.LF||
'tsWidth3\clwWidth1265 \cellx6152\clvertalt\clbrd';
wwv_flow_imp.g_varchar2_table(54) := 'rt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brd'||wwv_flow.LF||
'rs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cl';
wwv_flow_imp.g_varchar2_table(55) := 'txlrtb\clftsWidth3\clwWidth1265 \cellx7371\clvertalt\'||wwv_flow.LF||
'clbrdrt\brdrs\brdrw10 \clbrdrl'||wwv_flow.LF||
'\brdrs\brdrw10 ';
wwv_flow_imp.g_varchar2_table(56) := '\clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat'||wwv_flow.LF||
'17\cltxlrtb\clftsWidth3\clwWidth1266 \cellx87';
wwv_flow_imp.g_varchar2_table(57) := '48\pard \ql \li0\ri0\widctlpar\intbl\aspalpha\aspnum\fa'||wwv_flow.LF||
'auto\adjustright\rin0\lin0 {\b Title}{\cell ';
wwv_flow_imp.g_varchar2_table(58) := '}{\b Phone}{\cell }{\b Email}{\cell }{\b '||wwv_flow.LF||
'Company}{\cell'||wwv_flow.LF||
' }{\b City}{\cell }{\b State}{\cell }{\b Co';
wwv_flow_imp.g_varchar2_table(59) := 'untry}{\cell }\pard \ql \li0\ri0\widctlpar\intbl\aspalpha'||wwv_flow.LF||
'\aspnum\faauto\adjustright\rin0\lin0 {\tro';
wwv_flow_imp.g_varchar2_table(60) := 'wd \trgaph108\trleft-108\trhdr\trbrdrt\brdrs\brdrw10 \trbr'||wwv_flow.LF||
'drl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 ';
wwv_flow_imp.g_varchar2_table(61) := ''||wwv_flow.LF||
'\trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brd'||wwv_flow.LF||
'rs\brdrw10 \trftsWidth1\trautofit1\trpad';
wwv_flow_imp.g_varchar2_table(62) := 'dl108\trpaddr108\trpaddfl3\trpaddfr3 \clvertalt\clbrdrt\brdr'||wwv_flow.LF||
's\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrd';
wwv_flow_imp.g_varchar2_table(63) := 'rb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\clcbpat17\cltxlrtb\'||wwv_flow.LF||
'clftsWidth3\clwWidth1265 \cellx1097\cl';
wwv_flow_imp.g_varchar2_table(64) := 'vertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\'||wwv_flow.LF||
'brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 ';
wwv_flow_imp.g_varchar2_table(65) := '\clcbpat17\cltxlrtb\clftsWidth3\clwWidth1265 \cellx2324\clverta'||wwv_flow.LF||
'lt\clbrdrt\brdrs\brdrw10 \clbrdrl'||wwv_flow.LF||
'\b';
wwv_flow_imp.g_varchar2_table(66) := 'rdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcb'||wwv_flow.LF||
'pat17\cltxlrtb\clftsWidth3\clwWidth';
wwv_flow_imp.g_varchar2_table(67) := '1265 \cellx3545\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\br'||wwv_flow.LF||
'drw10 \clbrdrb\brdrs\brdrw10 \clbr';
wwv_flow_imp.g_varchar2_table(68) := 'drr\brdrs\brdrw10 '||wwv_flow.LF||
'\clcbpat17\cltxlrtb\clftsWidth3\clwWidth1265 \c'||wwv_flow.LF||
'ellx4962\clvertalt\clbrdrt\brdrs\';
wwv_flow_imp.g_varchar2_table(69) := 'brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdr'||wwv_flow.LF||
's\brdrw10 \clcbpat17\cltxlrtb\cl';
wwv_flow_imp.g_varchar2_table(70) := 'ftsWidth3\clwWidth1265 \cellx6152\clvertalt\clbrdrt\brdrs\brdrw10 \c'||wwv_flow.LF||
'lbrdrl'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrb\';
wwv_flow_imp.g_varchar2_table(71) := 'brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \clcbpat17\cltxlrtb\clftsWidth3\'||wwv_flow.LF||
'clwWidth1265 \cellx7371\clvert';
wwv_flow_imp.g_varchar2_table(72) := 'alt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw1'||wwv_flow.LF||
'0 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\cl';
wwv_flow_imp.g_varchar2_table(73) := 'cbpat17\cltxlrtb\clftsWidth3\clwWidth1266 \cellx8748\row }\trowd \trgap'||wwv_flow.LF||
'h108\trleft-108\trbrdrt\brdr';
wwv_flow_imp.g_varchar2_table(74) := 's\brdrw10 \trbrdrl\brdrs\brdrw10 \trbrdrb\brdrs\brdrw10 \trbrdrr\brdrs\b'||wwv_flow.LF||
'rdrw10 \trbrdrh\brdrs\brdrw';
wwv_flow_imp.g_varchar2_table(75) := '10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsWidth1\trautofit1\trpaddl108\trpaddr108\'||wwv_flow.LF||
'trpaddfl3\trpaddfr3 \clver';
wwv_flow_imp.g_varchar2_table(76) := 'talt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \'||wwv_flow.LF||
'clbrdrr\brdrs\brdrw10 \cl';
wwv_flow_imp.g_varchar2_table(77) := 'txlrtb\clftsWidth3\clwWidth1265 \cellx1097\clvertalt\clbrdrt\brdrs\brdrw10 '||wwv_flow.LF||
'\clbrdrl'||wwv_flow.LF||
'\brdrs\brdrw10 ';
wwv_flow_imp.g_varchar2_table(78) := '\clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth'||wwv_flow.LF||
'1265 \cellx2324\clverta';
wwv_flow_imp.g_varchar2_table(79) := 'lt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrd'||wwv_flow.LF||
'rr\brdrs\brdrw10 \cltx';
wwv_flow_imp.g_varchar2_table(80) := 'lrtb\clftsWidth3\clwWidth1265 \cellx3545'||wwv_flow.LF||
'\clvertalt\clbrdrt\brdrs\brdrw10 \clb'||wwv_flow.LF||
'rdrl\brdrs\brdrw10 \c';
wwv_flow_imp.g_varchar2_table(81) := 'lbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth1265 '||wwv_flow.LF||
'\cellx4962\clvertalt';
wwv_flow_imp.g_varchar2_table(82) := '\clbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\br'||wwv_flow.LF||
'drs\brdrw10 '||wwv_flow.LF||
'\cltxl';
wwv_flow_imp.g_varchar2_table(83) := 'rtb\clftsWidth3\clwWidth1265 \cellx6152\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\'||wwv_flow.LF||
'brdrs\brdrw10 \clb';
wwv_flow_imp.g_varchar2_table(84) := 'rdrb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth1265 \cell'||wwv_flow.LF||
'x7371\clvertalt\c';
wwv_flow_imp.g_varchar2_table(85) := 'lbrdrt\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 '||wwv_flow.LF||
'\clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\'||wwv_flow.LF||
'brdrw10 \cltxlrt';
wwv_flow_imp.g_varchar2_table(86) := 'b\clftsWidth3\clwWidth1266 \cellx8748\pard \ql \li0\ri0\widctlpar\intbl\aspalpha\asp'||wwv_flow.LF||
'num\faauto\adju';
wwv_flow_imp.g_varchar2_table(87) := 'stright\rin0\lin0 {\*\bkmkstart Text5}{\field\flddirty{\*\fldinst {\cf18  FORMTEXT }{'||wwv_flow.LF||
'\cf18 '||wwv_flow.LF||
'{\*\dat';
wwv_flow_imp.g_varchar2_table(88) := 'afield 800100000000000005546578743500014600000000001c3c3f666f722d656163683a63757272656'||wwv_flow.LF||
'e742d67726f75';
wwv_flow_imp.g_varchar2_table(89) := '7028293f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Te'||wwv_flow.LF||
'xt5}{\*\ffde';
wwv_flow_imp.g_varchar2_table(90) := 'ftext F}{\*\ffstattext '||wwv_flow.LF||
'<?for-each:current-group()?>}}}}}{\fldrslt {\cf18\lang1024\langf'||wwv_flow.LF||
'e1024\nopro';
wwv_flow_imp.g_varchar2_table(91) := 'of F}}}{\cf18 {\*\bkmkend Text5} {\*\bkmkstart Text6}}{\field\flddirty{\*\fldinst { FORMT'||wwv_flow.LF||
'EXT }{{\*\';
wwv_flow_imp.g_varchar2_table(92) := 'datafield '||wwv_flow.LF||
'800100000000000005546578743600055449544c450000000000093c3f5449544c453f3e0000000'||wwv_flow.LF||
'000}{\*\f';
wwv_flow_imp.g_varchar2_table(93) := 'ormfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text6}{\*\ffdeftext TITLE}{\*\ff'||wwv_flow.LF||
'stattext';
wwv_flow_imp.g_varchar2_table(94) := ' <?TITLE?>}}}}}{\fldrslt {\lang1024\langfe1024\noproof TITLE}}}{'||wwv_flow.LF||
'{\*\bkmkend Text6}\cell {\*'||wwv_flow.LF||
'\bkmkst';
wwv_flow_imp.g_varchar2_table(95) := 'art Text7}}{\field\flddirty{\*\fldinst { FORMTEXT }{{\*\datafield 800100000000000005546578743'||wwv_flow.LF||
'700055';
wwv_flow_imp.g_varchar2_table(96) := '0484f4e450000000000093c3f50484f4e453f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\f'||wwv_flow.LF||
'ftype';
wwv_flow_imp.g_varchar2_table(97) := 'txt0{\*\ffname Text7}'||wwv_flow.LF||
'{\*\ffdeftext PHONE}{\*\ffstattext <?PHONE?>}}}}}{\fldrslt {\lang1024\lan'||wwv_flow.LF||
'gfe1';
wwv_flow_imp.g_varchar2_table(98) := '024\noproof PHONE}}}{{\*\bkmkend Text7}\cell {\*\bkmkstart Text8}}{\field\flddirty{\*\fldinst { '||wwv_flow.LF||
'FOR';
wwv_flow_imp.g_varchar2_table(99) := 'MTEXT }{{\*\datafield '||wwv_flow.LF||
'80010000000000000554657874380005454d41494c0000000000093c3f454d41494c3f3e00'||wwv_flow.LF||
'00';
wwv_flow_imp.g_varchar2_table(100) := '000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text8}{\*\ffdeftext EMAIL}{'||wwv_flow.LF||
'\';
wwv_flow_imp.g_varchar2_table(101) := '*\ffstattext <?EMAIL?>}}}}}{\fldrslt {\lang1024\langfe1024\noproof EMAIL}}}{'||wwv_flow.LF||
'{\*\bkmkend Text8}\cel'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(102) := 'l {\*\bkmkstart Text9}}{\field\flddirty{\*\fldinst { FORMTEXT }{{\*\datafield 8001000000000000055465';
wwv_flow_imp.g_varchar2_table(103) := ''||wwv_flow.LF||
'7874390007434f4d50414e5900000000000b3c3f434f4d50414e593f3e0000000000}{\*\formfield{\fftype0\ffownhe';
wwv_flow_imp.g_varchar2_table(104) := 'l'||wwv_flow.LF||
'p\ffownstat\fftypetxt0{\*\ffname '||wwv_flow.LF||
'Text9}{\*\ffdeftext COMPANY}{\*\ffstattext <?COMPANY?>}}}}}{\fld';
wwv_flow_imp.g_varchar2_table(105) := 'rs'||wwv_flow.LF||
'lt {\lang1024\langfe1024\noproof COMPANY}}}{{\*\bkmkend Text9}\cell {\*\bkmkstart Text10}}{\field';
wwv_flow_imp.g_varchar2_table(106) := '\fl'||wwv_flow.LF||
'ddirty{\*\fldinst { FORMTEXT }{{\*\datafield '||wwv_flow.LF||
'80010000000000000654657874313000044349545900000000';
wwv_flow_imp.g_varchar2_table(107) := '0008'||wwv_flow.LF||
'3c3f434954593f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ffname Text';
wwv_flow_imp.g_varchar2_table(108) := '10}{\'||wwv_flow.LF||
'*\ffdeftext CITY}{\*\ffstattext <?CITY?>}}}}}{\fldrslt {\lang1024\langfe1024\noproof CITY}}}{'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(109) := '{\*\bk'||wwv_flow.LF||
'mkend Text10}\cell {\*\bkmkstart Text11}}{\field\flddirty{\*\fldinst { FORMTEXT }{{\*\datafie';
wwv_flow_imp.g_varchar2_table(110) := 'ld 8001'||wwv_flow.LF||
'00000000000006546578743131000553544154450000000000093c3f53544154453f3e0000000000}{\*\formfie';
wwv_flow_imp.g_varchar2_table(111) := 'ld{\ffty'||wwv_flow.LF||
'pe0\ffownhelp\ffownstat\fftypetxt0{\*\ffname '||wwv_flow.LF||
'Text11}{\*\ffdeftext STATE}{\*\ffstattext <?S';
wwv_flow_imp.g_varchar2_table(112) := 'TATE?>}}}'||wwv_flow.LF||
'}}{\fldrslt {\lang1024\langfe1024\noproof STATE}}}{{\*\bkmkend Text11}\cell {\*\bkmkstart ';
wwv_flow_imp.g_varchar2_table(113) := 'Text12}}{\'||wwv_flow.LF||
'field\flddirty{\*\fldinst { FORMTEXT }{{\*\datafield '||wwv_flow.LF||
'80010000000000000654657874313200074';
wwv_flow_imp.g_varchar2_table(114) := '34f554e5452'||wwv_flow.LF||
'5900000000000b3c3f434f554e5452593f3e0000000000}{\*\formfield{\fftype0\ffownhelp\ffownsta';
wwv_flow_imp.g_varchar2_table(115) := 't\fftypetxt0'||wwv_flow.LF||
'{\*\ffname Text12}{\*\ffdeftext COUNTRY}{\*\ffstattext <?COUNTRY?>}}}}}{\fldrslt {'||wwv_flow.LF||
'\lan';
wwv_flow_imp.g_varchar2_table(116) := 'g1024\langfe1'||wwv_flow.LF||
'024\noproof COUNTRY}}}{{\*\bkmkend Text12}  {\*\bkmkstart Text13}}{\field\flddirty{\*\';
wwv_flow_imp.g_varchar2_table(117) := 'fldinst {\cf18'||wwv_flow.LF||
'  FORMTEXT }{\cf18 {\*\datafield 8001000000000000065465787431330001450000000000103c3f';
wwv_flow_imp.g_varchar2_table(118) := '656e6420666f722'||wwv_flow.LF||
'd656163683f3e0000000000}'||wwv_flow.LF||
'{\*\formfield{\fftype0\ffownhelp\ffownstat\fftypetxt0{\*\ff';
wwv_flow_imp.g_varchar2_table(119) := 'name Text13}{\*\'||wwv_flow.LF||
'ffdeftext E}{\*\ffstattext <?end for-each?>}}}}}{\fldrslt {\cf18\lang1024\langfe102';
wwv_flow_imp.g_varchar2_table(120) := '4\noproof E}}}{{\'||wwv_flow.LF||
'*\bkmkend Text13}\cell }\pard '||wwv_flow.LF||
'\ql \li0\ri0\widctlpar\intbl\aspalpha\aspnum\faauto';
wwv_flow_imp.g_varchar2_table(121) := '\adjustright\rin0\'||wwv_flow.LF||
'lin0 {\trowd \trgaph108\trleft-108\trbrdrt\brdrs\brdrw10 \trbrdrl\brdrs\brdrw10 \';
wwv_flow_imp.g_varchar2_table(122) := 'trbrdrb\brdrs\brdrw'||wwv_flow.LF||
'10 \trbrdrr\brdrs\brdrw10 \trbrdrh\brdrs\brdrw10 \trbrdrv\brdrs\brdrw10 '||wwv_flow.LF||
'\trftsW';
wwv_flow_imp.g_varchar2_table(123) := 'idth1\trautofit1\trp'||wwv_flow.LF||
'addl108\trpaddr108\trpaddfl3\trpaddfr3 \clvertalt\clbrdrt\brdrs\brdrw10 \clbrdr';
wwv_flow_imp.g_varchar2_table(124) := 'l\brdrs\brdrw10 \clbr'||wwv_flow.LF||
'drb\brdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth1265 \c';
wwv_flow_imp.g_varchar2_table(125) := 'ellx1097\clvertalt\clb'||wwv_flow.LF||
'rdrt\brdrs\brdrw10 \clbrdrl'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\br';
wwv_flow_imp.g_varchar2_table(126) := 'drs\brdrw10 \cltxlrtb\c'||wwv_flow.LF||
'lftsWidth3\clwWidth1265 \cellx2324\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\';
wwv_flow_imp.g_varchar2_table(127) := 'brdrs\brdrw10 \clbrdrb\b'||wwv_flow.LF||
'rdrs\brdrw10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth1265 \cel';
wwv_flow_imp.g_varchar2_table(128) := 'lx3545'||wwv_flow.LF||
'\clvertalt\clbrdrt'||wwv_flow.LF||
'\brdrs\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdr';
wwv_flow_imp.g_varchar2_table(129) := 's\brdrw10 \cltxlrtb\clftsW'||wwv_flow.LF||
'idth3\clwWidth1265 \cellx4962\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\br';
wwv_flow_imp.g_varchar2_table(130) := 'drs\brdrw10 \clbrdrb\brdrs\'||wwv_flow.LF||
'brdrw10 \clbrdrr\brdrs\brdrw10 '||wwv_flow.LF||
'\cltxlrtb\clftsWidth3\clwWidth1265 \cell';
wwv_flow_imp.g_varchar2_table(131) := 'x6152\clvertalt\clbrdrt\brdr'||wwv_flow.LF||
's\brdrw10 \clbrdrl\brdrs\brdrw10 \clbrdrb\brdrs\brdrw10 \clbrdrr\brdrs\';
wwv_flow_imp.g_varchar2_table(132) := 'brdrw10 \cltxlrtb\clftsWidth3'||wwv_flow.LF||
'\clwWidth1265 \cellx7371\clvertalt\clbrdrt\brdrs\brdrw10 \clbrdrl\brdr';
wwv_flow_imp.g_varchar2_table(133) := 's\brdrw10 '||wwv_flow.LF||
'\clbrdrb\brdrs\brdr'||wwv_flow.LF||
'w10 \clbrdrr\brdrs\brdrw10 \cltxlrtb\clftsWidth3\clwWidth1266 \cellx8';
wwv_flow_imp.g_varchar2_table(134) := '748\row }\pard \ql \li0\ri0\wid'||wwv_flow.LF||
'ctlpar\aspalpha\aspnum\faauto\adjustright\rin0\lin0\itap0 {'||wwv_flow.LF||
'\par  {\';
wwv_flow_imp.g_varchar2_table(135) := '*\bkmkstart Text14}}{\field\fldd'||wwv_flow.LF||
'irty{\*\fldinst {\cf9  FORMTEXT }{\cf9 {\*\datafield 80010000000000';
wwv_flow_imp.g_varchar2_table(136) := '000654657874313400014500000000001'||wwv_flow.LF||
'63c3f656e6420666f722d656163682d67726f75703f3e0000000000}{\*\formfi';
wwv_flow_imp.g_varchar2_table(137) := 'eld{\fftype0\ffownhelp\ffownstat\f'||wwv_flow.LF||
'ftypetxt0{\*\ffname '||wwv_flow.LF||
'Text14}{\*\ffdeftext E}{\*\ffstattext <?end ';
wwv_flow_imp.g_varchar2_table(138) := 'for-each-group?>}}}}}{\fldrslt {\cf'||wwv_flow.LF||
'9\lang1024\langfe1024\noproof E}}}{{\*\bkmkend Text14}'||wwv_flow.LF||
'\par }}';
wwv_flow_imp_shared.create_report_layout(
 p_id=>wwv_flow_imp.id(17842138456127099304)
,p_report_layout_name=>'Customer_Report'
,p_static_id=>'CUSTOMER_REPORT'
,p_report_layout_type=>'RTF_FILE'
,p_page_template=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_version_scn=>'37166093824750'
);
wwv_flow_imp.component_end;
end;
/
