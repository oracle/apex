prompt --application/shared_components/navigation/lists/activity_actions
begin
--   Manifest
--     LIST: Activity Actions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(18188121800916915330)
,p_name=>'Activity Actions'
,p_static_id=>'activity-actions'
,p_version_scn=>'1089051550'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(18188124769178915339)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Add Attachment'
,p_static_id=>'add-attachment'
,p_list_item_link_target=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:114:P114_ACTIVITY_ID:&P145_ID.:'
,p_list_item_icon=>'fa-paperclip'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
