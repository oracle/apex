prompt --application/shared_components/navigation/lists/data_load_process_train_customers_002
begin
--   Manifest
--     LIST: Data Load Process Train - Customers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(18148992223752361467)
,p_name=>'Data Load Process Train - Customers'
,p_static_id=>'data-load-process-train-customers-3'
,p_version_scn=>'1089051550'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(18148993824790361472)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Data Load Results'
,p_static_id=>'data-load-results'
,p_list_item_link_target=>'f?p=&APP_ID.:128:&SESSION.::&DEBUG.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(18148992569599361469)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Data Load Source'
,p_static_id=>'data-load-source'
,p_list_item_link_target=>'f?p=&APP_ID.:125:&SESSION.::&DEBUG.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(18148992963987361471)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Data / Table Mapping'
,p_static_id=>'data-table-mapping'
,p_list_item_link_target=>'f?p=&APP_ID.:126:&SESSION.::&DEBUG.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(18148993431149361472)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Data Validation'
,p_static_id=>'data-validation'
,p_list_item_link_target=>'f?p=&APP_ID.:127:&SESSION.::&DEBUG.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
