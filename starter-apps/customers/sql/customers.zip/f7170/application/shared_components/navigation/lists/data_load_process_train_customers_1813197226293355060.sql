prompt --application/shared_components/navigation/lists/data_load_process_train_customers_1813197226293355060
begin
--   Manifest
--     LIST: Data Load Process Train - customers-1813197226293355060
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(18147479560195136492)
,p_name=>'Data Load Process Train - customers-1813197226293355060'
,p_static_id=>'data-load-process-train-customers-2'
,p_version_scn=>'1089051550'
);
wwv_flow_imp.component_end;
end;
/
