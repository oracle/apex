prompt --application/shared_components/navigation/lists/mobile_menu
begin
--   Manifest
--     LIST: + Mobile Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(16657030493057030763)
,p_name=>'+ Mobile Menu'
,p_static_id=>'mobile-menu'
,p_version_scn=>'1089051550'
);
wwv_flow_imp.component_end;
end;
/
