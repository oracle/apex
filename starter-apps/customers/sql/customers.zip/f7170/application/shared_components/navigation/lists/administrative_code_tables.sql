prompt --application/shared_components/navigation/lists/administrative_code_tables
begin
--   Manifest
--     LIST: Administrative Code Tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(15858084707331374837)
,p_name=>'Administrative Code Tables'
,p_static_id=>'administrative-code-tables'
,p_version_scn=>'1089051550'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(18153708502819329291)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Activity Types'
,p_static_id=>'activity-types'
,p_list_item_link_target=>'f?p=&APP_ID.:53:&SESSION.::&DEBUG.:RP,RIR,53:::'
,p_list_item_icon=>'fa-newspaper-o'
,p_list_text_01=>'Manage the types of activities tracked by the system.'
,p_security_scheme=>wwv_flow_imp.id(15689730986492315427)
,p_required_patch=>wwv_flow_imp.id(18152936214703210671)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15858085662130374838)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Categories'
,p_static_id=>'categories'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-bullseye'
,p_list_text_01=>'Manage the categories used to bucket customers.'
,p_list_text_02=>'formIcon'
,p_list_text_03=>'&CNT_02.'
,p_security_scheme=>wwv_flow_imp.id(15689730986492315427)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'3'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15858086440727374839)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Contact Types'
,p_static_id=>'contact-types'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-crosshairs'
,p_list_text_01=>'Manage domain of customer contact types.'
,p_list_text_02=>'formIcon'
,p_list_text_03=>'&CNT_04.'
,p_security_scheme=>wwv_flow_imp.id(15689730986492315427)
,p_required_patch=>wwv_flow_imp.id(14970180175172343869)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'8'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(16944559811435821521)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Countries'
,p_static_id=>'countries'
,p_list_item_link_target=>'f?p=&APP_ID.:98:&SESSION.::&DEBUG.:98,RIR:::'
,p_list_item_icon=>'fa-globe'
,p_list_text_01=>'Manage the list of countries used to organize customers.'
,p_security_scheme=>wwv_flow_imp.id(15689730986492315427)
,p_required_patch=>wwv_flow_imp.id(16941764922785525601)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(17015883459647896141)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Customer Statuses'
,p_static_id=>'customer-statuses'
,p_list_item_link_target=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-edit'
,p_list_text_01=>'Manage domain of customer statuses.'
,p_list_text_02=>'formIcon'
,p_list_text_03=>'&CNT_03.'
,p_security_scheme=>wwv_flow_imp.id(15689730986492315427)
,p_required_patch=>wwv_flow_imp.id(17153508560085275962)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'5'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15858086093513374838)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Customer Types'
,p_static_id=>'customer-types'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-edit'
,p_list_text_01=>'Manage domain of customer types.'
,p_list_text_02=>'formIcon'
,p_list_text_03=>'&CNT_03.'
,p_security_scheme=>wwv_flow_imp.id(15689730986492315427)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'5'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(17141433526095593538)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Customer Use Cases'
,p_static_id=>'customer-use-cases'
,p_list_item_link_target=>'f?p=&APP_ID.:104:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-check'
,p_list_text_01=>'Manage domain of customer use cases.'
,p_security_scheme=>wwv_flow_imp.id(15689730986492315427)
,p_required_patch=>wwv_flow_imp.id(17131707154069197740)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15858087651760374839)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Geographies'
,p_static_id=>'geographies'
,p_list_item_link_target=>'f?p=&APP_ID.:48:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-globe'
,p_list_text_01=>'Manage the list of geographies used to organize customers.'
,p_list_text_02=>'formIcon'
,p_list_text_03=>'&CNT_06.'
,p_security_scheme=>wwv_flow_imp.id(15689730986492315427)
,p_required_patch=>wwv_flow_imp.id(14970149602821011981)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'48'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15858088119555374839)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Industries'
,p_static_id=>'industries'
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-building-o'
,p_list_text_01=>'Manage the domain of industries a customer can be assigned to'
,p_list_text_02=>'formIcon'
,p_list_text_03=>'&CNT_09.'
,p_security_scheme=>wwv_flow_imp.id(15689730986492315427)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(2580553735871582239)
,p_list_item_display_sequence=>95
,p_list_item_link_text=>'Issue Statuses'
,p_static_id=>'issue-statuses'
,p_list_item_link_target=>'f?p=&APP_ID.:132:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-alert'
,p_list_text_01=>'Manage the domain of statuses a customer issue can be assigned to'
,p_security_scheme=>wwv_flow_imp.id(15689730986492315427)
,p_required_patch=>wwv_flow_imp.id(2580201656498442703)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(17776766825666703200)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Product Families'
,p_static_id=>'product-families'
,p_list_item_link_target=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:RP,RIR,112:::'
,p_list_item_icon=>'fa-tags'
,p_list_text_01=>'Manage the list of available product families that a product can belong to.'
,p_security_scheme=>wwv_flow_imp.id(15689730986492315427)
,p_required_patch=>wwv_flow_imp.id(14970172887299277418)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'112'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15858087322374374839)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Products'
,p_static_id=>'products'
,p_list_item_link_target=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-tag'
,p_list_text_01=>'Manage the list of available products that can be associated with a customer.'
,p_list_text_02=>'formIcon'
,p_list_text_03=>'&CNT_05.'
,p_security_scheme=>wwv_flow_imp.id(15689730986492315427)
,p_required_patch=>wwv_flow_imp.id(14970172887299277418)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'42'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15858126311354403955)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Reference Phases'
,p_static_id=>'reference-phases'
,p_list_item_link_target=>'f?p=&APP_ID.:87:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-moon-o'
,p_list_text_01=>'Manage reference life cycle using phases.'
,p_security_scheme=>wwv_flow_imp.id(15689730986492315427)
,p_required_patch=>wwv_flow_imp.id(14302332505635866896)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14295041228674054140)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Reference Statuses'
,p_static_id=>'reference-statuses'
,p_list_item_link_target=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-tags'
,p_list_text_01=>'Manage the reference statuses for customer product assignments.'
,p_security_scheme=>wwv_flow_imp.id(15689730986492315427)
,p_required_patch=>wwv_flow_imp.id(14302390922364941048)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15858086845753374839)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Reference Types'
,p_static_id=>'reference-types'
,p_list_item_link_target=>'f?p=&APP_ID.:78:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-group'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'APEX_UTIL.GET_BUILD_OPTION_STATUS(',
'    P_APPLICATION_ID => :APP_ID,',
'    P_BUILD_OPTION_NAME => ''Customer Referencability'') = ''INCLUDE''',
'or',
'APEX_UTIL.GET_BUILD_OPTION_STATUS(',
'    P_APPLICATION_ID => :APP_ID,',
'    P_BUILD_OPTION_NAME => ''Product Referencability'') = ''INCLUDE'''))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_text_01=>'Manage domain of customer reference types.'
,p_security_scheme=>wwv_flow_imp.id(15689730986492315427)
,p_required_patch=>wwv_flow_imp.id(14302390922364941048)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'78'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15858141878495494583)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Sales Channels'
,p_static_id=>'sales-channels'
,p_list_item_link_target=>'f?p=&APP_ID.:89:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-exchange'
,p_list_text_01=>'Manage domain of available sales channels'
,p_security_scheme=>wwv_flow_imp.id(15689730986492315427)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
