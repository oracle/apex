prompt --application/shared_components/logic/application_items/category_help
begin
--   Manifest
--     APPLICATION ITEM: CATEGORY_HELP
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(17849791343232996002)
,p_name=>'CATEGORY_HELP'
,p_protection_level=>'S'
,p_escape_on_http_output=>'N'
,p_version_scn=>'37166093824741'
);
wwv_flow_imp.component_end;
end;
/
