prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 7170
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(18152936214703210671)
,p_build_option_name=>'Activities'
,p_static_id=>'activities'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>'37166093824750'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'This feature allows the tracking of contacts who have attended various events.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(1177222556504584862)
,p_build_option_name=>'Annual Recurring Revenue (ARR)'
,p_static_id=>'annual-recurring-revenue-arr'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>'37166093824750'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'A status of include will expose an Annual Recurring Revenue attribute of customers.  A status of exclude will hide the attribute.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(1350858776229335487)
,p_build_option_name=>'Competitors'
,p_static_id=>'competitors'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>'37166093824750'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'This feature allows the tracking of competitors, and which customers they are competing against you on.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(14970180175172343869)
,p_build_option_name=>'Contacts'
,p_static_id=>'contacts'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>'37166093824750'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Use this build option to enable or disable tracking of customer contacts.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(14950782698391970796)
,p_build_option_name=>'Content Completeness Widget'
,p_static_id=>'content-completeness-widget'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>'37166093824750'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'This build option controls whether the "Content Completeness" plugin region is displayed on the Customer details page or not.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(16941764922785525601)
,p_build_option_name=>'Countries'
,p_static_id=>'countries'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>'37166093824750'
,p_default_on_export=>'EXCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Including will allow reporting and management of countries by customer. Excluding will not show the country attribute for customers.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(14970324699199122084)
,p_build_option_name=>'Customer Data Loading'
,p_static_id=>'customer-data-loading'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>'37166093824750'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Allow application contributors to load customer data from CSV files or cut and paste via a data loading wizard.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(14302332505635866896)
,p_build_option_name=>'Customer Referencability'
,p_static_id=>'customer-referencability'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>'37166093824750'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Support reference attributes at the customer level.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(17153508560085275962)
,p_build_option_name=>'Customer Status'
,p_static_id=>'customer-status'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>'37166093824750'
,p_default_on_export=>'INCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Support a status attribute at the customer level.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(17131707154069197740)
,p_build_option_name=>'Customer Use Case'
,p_static_id=>'customer-use-case'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>'37166093824750'
,p_default_on_export=>'EXCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Support a use case status attribute at the customer level (development, test/stage, production, etc...).'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(1177221148924551993)
,p_build_option_name=>'Discount Percentage'
,p_static_id=>'discount-percentage'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>'37166093824750'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Include a customer attribute that tracks discount percentage at the customer level.  Including the discount will allow this value to be displayed and edited within the application.  Excluding this attribute will hide this feature from the application'
||'.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(1177138972730478351)
,p_build_option_name=>'Display Row Key'
,p_static_id=>'display-row-key'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>'37166093824750'
,p_default_on_export=>'EXCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Row Keys are alphanumeric unique identifiers that can be used to easily identify a specific customer.  If you wish to see these unique identifiers in the application set to Include; if you do not wish to see these unique identifiers in the applicatio'
||'n set to exclude.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(18745318799724164339)
,p_build_option_name=>'Feedback'
,p_static_id=>'feedback'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>'37166093824750'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'This feature allows end-users to submit feedback about the application that can be emailed and viewed by application administrators.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(14970149602821011981)
,p_build_option_name=>'Geography'
,p_static_id=>'geography'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>'37166093824750'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Including will allow reporting and management of geography by customer.  Excluding will not show the geography attribute for customers.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(2580201656498442703)
,p_build_option_name=>'Issues'
,p_static_id=>'issues'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>'37166093824750'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'This feature allows end-users to capture and record customer issues.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(14889473570610436663)
,p_build_option_name=>'Number_of_users'
,p_static_id=>'number-of-users'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>'37166093824750'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Expose the number of users attribute'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(1354010364133360169)
,p_build_option_name=>'Partners'
,p_static_id=>'partners'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>'37166093824750'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'This feature allows the tracking of partners, and which customers they are working with you on.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(14302390922364941048)
,p_build_option_name=>'Product Referencability'
,p_static_id=>'product-referencability'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>'37166093824750'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Support reference attributes at the customer product level.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(14970172887299277418)
,p_build_option_name=>'Products and Services'
,p_static_id=>'products-and-services'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>'37166093824750'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Use this build option to enable or disable products and services application functionality.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(14970246879369402325)
,p_build_option_name=>'Reports'
,p_static_id=>'reports'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>'37166093824750'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Enable or disable the application reporting tab that provides summary reporting of application data.  Disable this option to keep the application more terse and focused, enable this option to enable additional reporting functionality.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(16902400265700863507)
,p_build_option_name=>'Strategic Customer Program'
,p_static_id=>'strategic-customer-program'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>'37166093824750'
,p_default_on_export=>'EXCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Support tracking whether a customer is a "Strategic Customer Program" customer or not.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(1177221432481558104)
,p_build_option_name=>'Total Contract Value (TCV)'
,p_static_id=>'total-contract-value-tcv'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>'37166093824750'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'A status of include will expose an Total Contract Value (TCV) attribute of customers.  A status of exclude will hide the attribute.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(14950782891705973913)
,p_build_option_name=>'Validations Widget'
,p_static_id=>'validations-widget'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>'37166093824750'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'This build option controls whether the "Validations" plugin region is displayed on the Customer details page or not.'
);
wwv_flow_imp.component_end;
end;
/
