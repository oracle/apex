prompt --application/deployment/install/install_eba_cust_body
begin
--   Manifest
--     INSTALL: INSTALL-eba_cust body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body eba_cust as'||wwv_flow.LF||
'   '||wwv_flow.LF||
'    -------------------------------------------------';
wwv_flow_imp.g_varchar2_table(2) := '------------------------'||wwv_flow.LF||
'    -- Generates a unique Identifier'||wwv_flow.LF||
'    ----------------------------------';
wwv_flow_imp.g_varchar2_table(3) := '---------------------------------------'||wwv_flow.LF||
'    function gen_id'||wwv_flow.LF||
'        return number'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_i';
wwv_flow_imp.g_varchar2_table(4) := 'd  number;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        select to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(5) := '    into l_id'||wwv_flow.LF||
'          from dual;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'        return l_id;'||wwv_flow.LF||
'    end gen_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ------------------';
wwv_flow_imp.g_varchar2_table(6) := '-------------------------------------------------------'||wwv_flow.LF||
'    -- Gets the current user''s authorization';
wwv_flow_imp.g_varchar2_table(7) := ' level. Depends on the following:'||wwv_flow.LF||
'    --  * If access control is currently disabled, returns highest';
wwv_flow_imp.g_varchar2_table(8) := ' level of 3.'||wwv_flow.LF||
'    --  * If access control is enabled, but user is not in list, returns 0'||wwv_flow.LF||
'    --  * If';
wwv_flow_imp.g_varchar2_table(9) := ' access control is enabled and user is in list, returns their'||wwv_flow.LF||
'    --    access level.'||wwv_flow.LF||
'    ----------';
wwv_flow_imp.g_varchar2_table(10) := '---------------------------------------------------------------'||wwv_flow.LF||
'    function get_authorization_level';
wwv_flow_imp.g_varchar2_table(11) := ' ('||wwv_flow.LF||
'        p_username             varchar2)'||wwv_flow.LF||
'        return number'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_access_level_id  ';
wwv_flow_imp.g_varchar2_table(12) := '     eba_cust_users.access_level_id%type := 0;  -- default to lowest privilege.'||wwv_flow.LF||
'        l_account_lo';
wwv_flow_imp.g_varchar2_table(13) := 'cked        eba_cust_users.account_locked%type;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        -- If access control is disabled, ';
wwv_flow_imp.g_varchar2_table(14) := 'default to highest privilege'||wwv_flow.LF||
'        if eba_cust_fw.get_preference_value(''ACCESS_CONTROL_ENABLED'') =';
wwv_flow_imp.g_varchar2_table(15) := ' ''N'' then'||wwv_flow.LF||
'            return 3;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            -- Query for user''s access level, throws no';
wwv_flow_imp.g_varchar2_table(16) := '_data_found if no user'||wwv_flow.LF||
'            select access_level_id,'||wwv_flow.LF||
'                   account_locked'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(17) := '       into l_access_level_id,'||wwv_flow.LF||
'                   l_account_locked'||wwv_flow.LF||
'              from eba_cust_users';
wwv_flow_imp.g_varchar2_table(18) := ''||wwv_flow.LF||
'             where username = p_username;'||wwv_flow.LF||
'            -- Check if user''s account is locked, return ';
wwv_flow_imp.g_varchar2_table(19) := '0 (no privilege), otherwise stick'||wwv_flow.LF||
'            -- with their level.'||wwv_flow.LF||
'            if l_account_locked =';
wwv_flow_imp.g_varchar2_table(20) := ' ''Y'' then'||wwv_flow.LF||
'                return 0;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            -- Overwrite user access level 1';
wwv_flow_imp.g_varchar2_table(21) := ' with access level 2 if access control scope is PUBLIC_CONTRIBUTE'||wwv_flow.LF||
'            if l_access_level_id =';
wwv_flow_imp.g_varchar2_table(22) := ' 1 and eba_cust_fw.get_preference_value(''ACCESS_CONTROL_SCOPE'') = ''PUBLIC_CONTRIBUTE'' then'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(23) := '       return 2;'||wwv_flow.LF||
'            end if;            '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        return l_access_level_id;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(24) := '   exception'||wwv_flow.LF||
'        when no_data_found then'||wwv_flow.LF||
'            -- If no user exists with passed username, ';
wwv_flow_imp.g_varchar2_table(25) := 'do a final check if reader access is set to any authenticated user'||wwv_flow.LF||
'            if eba_cust_fw.get_pr';
wwv_flow_imp.g_varchar2_table(26) := 'eference_value(''ACCESS_CONTROL_SCOPE'') = ''PUBLIC_CONTRIBUTE'' then'||wwv_flow.LF||
'                return 2;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(27) := '    elsif eba_cust_fw.get_preference_value(''ACCESS_CONTROL_SCOPE'') = ''PUBLIC_READONLY'' then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(28) := '        return 1;'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'                return 0;'||wwv_flow.LF||
'            end if;           '||wwv_flow.LF||
'    end ';
wwv_flow_imp.g_varchar2_table(29) := 'get_authorization_level;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ----------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(30) := '---'||wwv_flow.LF||
'    -- Gets the current user''s feature level. '||wwv_flow.LF||
'    --   Based on combination of the ACL Feature''';
wwv_flow_imp.g_varchar2_table(31) := 's access level and user''s access level (if access control enabled) '||wwv_flow.LF||
'    ----------------------------';
wwv_flow_imp.g_varchar2_table(32) := '---------------------------------------------'||wwv_flow.LF||
'    function get_feature_level ('||wwv_flow.LF||
'        p_username   ';
wwv_flow_imp.g_varchar2_table(33) := '          varchar2,'||wwv_flow.LF||
'        p_authorization_name   varchar2)'||wwv_flow.LF||
'        return boolean'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l';
wwv_flow_imp.g_varchar2_table(34) := '_feature_level_id    eba_cust_acl_features.access_level_id%type := 1;  -- default to lowest privileg';
wwv_flow_imp.g_varchar2_table(35) := 'e required'||wwv_flow.LF||
'        l_user_level_id       eba_cust_users.access_level_id%type := 0;  -- default to lo';
wwv_flow_imp.g_varchar2_table(36) := 'west privilege.'||wwv_flow.LF||
'        l_account_locked      eba_cust_users.account_locked%type;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(37) := '-- If access control is disabled, default to highest privilege'||wwv_flow.LF||
'        if eba_cust_fw.get_preference';
wwv_flow_imp.g_varchar2_table(38) := '_value(''ACCESS_CONTROL_ENABLED'') = ''N'' then'||wwv_flow.LF||
'            return true;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- Det';
wwv_flow_imp.g_varchar2_table(39) := 'ermine the Feature level from ACL Features'||wwv_flow.LF||
'        for c1 in (select access_level_id'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(40) := '    from eba_cust_acl_features'||wwv_flow.LF||
'                   where authorization_name = p_authorization_name'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(41) := '                ) loop'||wwv_flow.LF||
'            l_feature_level_id := c1.access_level_id;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(42) := '    -- Query for user''s access level, throws no_data_found if no user'||wwv_flow.LF||
'        begin'||wwv_flow.LF||
'            sele';
wwv_flow_imp.g_varchar2_table(43) := 'ct access_level_id,'||wwv_flow.LF||
'                   account_locked'||wwv_flow.LF||
'              into l_user_level_id,'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(44) := '         l_account_locked'||wwv_flow.LF||
'              from eba_cust_users'||wwv_flow.LF||
'             where username = p_username';
wwv_flow_imp.g_varchar2_table(45) := ';'||wwv_flow.LF||
'            -- Check if user''s account is locked, return false (no privilege), otherwise stick wit';
wwv_flow_imp.g_varchar2_table(46) := 'h their level.'||wwv_flow.LF||
'            if l_account_locked = ''Y'' then'||wwv_flow.LF||
'                return false;'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(47) := 'end if;'||wwv_flow.LF||
'            -- Overwrite user access level 1 with access level 2 if access control scope is ';
wwv_flow_imp.g_varchar2_table(48) := 'PUBLIC_CONTRIBUTE'||wwv_flow.LF||
'            if l_user_level_id = 1 and eba_cust_fw.get_preference_value(''ACCESS_CO';
wwv_flow_imp.g_varchar2_table(49) := 'NTROL_SCOPE'') = ''PUBLIC_CONTRIBUTE'' then'||wwv_flow.LF||
'                l_user_level_id := 2;'||wwv_flow.LF||
'            end if;  ';
wwv_flow_imp.g_varchar2_table(50) := '          '||wwv_flow.LF||
'        exception'||wwv_flow.LF||
'            when no_data_found then'||wwv_flow.LF||
'            -- If no user exists wi';
wwv_flow_imp.g_varchar2_table(51) := 'th passed username, do a final check if reader access is set to any authenticated user'||wwv_flow.LF||
'            i';
wwv_flow_imp.g_varchar2_table(52) := 'f eba_cust_fw.get_preference_value(''ACCESS_CONTROL_SCOPE'') = ''PUBLIC_CONTRIBUTE'' then'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(53) := '  l_user_level_id := 2;'||wwv_flow.LF||
'            elsif eba_cust_fw.get_preference_value(''ACCESS_CONTROL_SCOPE'') =';
wwv_flow_imp.g_varchar2_table(54) := ' ''PUBLIC_READONLY'' then'||wwv_flow.LF||
'                l_user_level_id := 1;'||wwv_flow.LF||
'            end if;           '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(55) := ' end;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- Compare the Feature level to the User level'||wwv_flow.LF||
'        -- If the User level is at lea';
wwv_flow_imp.g_varchar2_table(56) := 'st as high as the Feature level then the user can perform the given function.'||wwv_flow.LF||
'        if l_feature_l';
wwv_flow_imp.g_varchar2_table(57) := 'evel_id <= l_user_level_id then'||wwv_flow.LF||
'          return true;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'          return false;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(58) := 'end if;'||wwv_flow.LF||
'    end get_feature_level;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure eba_cust_add_views_log(p_view_type varchar2,p_id';
wwv_flow_imp.g_varchar2_table(59) := ' number) as'||wwv_flow.LF||
'       l_count number;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'         select count(*)'||wwv_flow.LF||
'           into l_count'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(60) := '     from eba_cust_views_log'||wwv_flow.LF||
'          where table_primary_id = p_id'||wwv_flow.LF||
'            and view_type = p_v';
wwv_flow_imp.g_varchar2_table(61) := 'iew_type;'||wwv_flow.LF||
'         if l_count >= 1 then'||wwv_flow.LF||
'               update eba_cust_views_log'||wwv_flow.LF||
'                  s';
wwv_flow_imp.g_varchar2_table(62) := 'et view_count = view_count + 1'||wwv_flow.LF||
'                where table_primary_id = p_id'||wwv_flow.LF||
'                 and vi';
wwv_flow_imp.g_varchar2_table(63) := 'ew_type = p_view_type ;'||wwv_flow.LF||
'         else'||wwv_flow.LF||
'               insert into eba_cust_views_log( view_type, tabl';
wwv_flow_imp.g_varchar2_table(64) := 'e_primary_id )'||wwv_flow.LF||
'               values (p_view_type, p_id);         '||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'    end;'||wwv_flow.LF||
''||wwv_flow.LF||
'end eb';
wwv_flow_imp.g_varchar2_table(65) := 'a_cust;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(15939588282843415287)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'eba_cust body'
,p_sequence=>430
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
