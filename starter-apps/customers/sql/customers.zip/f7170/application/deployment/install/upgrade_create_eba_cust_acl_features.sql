prompt --application/deployment/install/upgrade_create_eba_cust_acl_features
begin
--   Manifest
--     INSTALL: UPGRADE-create eba_cust_acl_features
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_acl_features ('||wwv_flow.LF||
'    id                      number              not null'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(2) := '                                          constraint eba_cust_acl_features_pk'||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(3) := '                          primary key,'||wwv_flow.LF||
'    authorization_name      varchar2(255)       not null,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(4) := ' access_level_id         number              not null'||wwv_flow.LF||
'                                              ';
wwv_flow_imp.g_varchar2_table(5) := '  constraint eba_cust_acl_features_fk'||wwv_flow.LF||
'                                                references eba';
wwv_flow_imp.g_varchar2_table(6) := '_cust_access_levels,'||wwv_flow.LF||
'    feature                 varchar2(255)       not null,'||wwv_flow.LF||
'    row_version      ';
wwv_flow_imp.g_varchar2_table(7) := '       number,'||wwv_flow.LF||
'    created_by              varchar2(255)       not null,'||wwv_flow.LF||
'    created                ';
wwv_flow_imp.g_varchar2_table(8) := ' timestamp with time zone,'||wwv_flow.LF||
'    updated_by              varchar2(255),'||wwv_flow.LF||
'    updated                 ti';
wwv_flow_imp.g_varchar2_table(9) := 'mestamp with time zone )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust_acl_features_uk on eba_cust_acl_features (au';
wwv_flow_imp.g_varchar2_table(10) := 'thorization_name);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_cust_acl_features_biu'||wwv_flow.LF||
'    before insert or update ';
wwv_flow_imp.g_varchar2_table(11) := 'on eba_cust_acl_features'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  -- Always store authorization_name as upper case'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(12) := ' :new.authorization_name := upper(:new.authorization_name);'||wwv_flow.LF||
''||wwv_flow.LF||
'  if inserting then'||wwv_flow.LF||
'    if :new.id is n';
wwv_flow_imp.g_varchar2_table(13) := 'ull then'||wwv_flow.LF||
'      :new.id := eba_cust.gen_id();'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.created_by         := nvl(v(''APP_U';
wwv_flow_imp.g_varchar2_table(14) := 'SER''), USER);'||wwv_flow.LF||
'    :new.created            := current_timestamp;'||wwv_flow.LF||
'    :new.row_version        := 1;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(15) := 'elsif updating then'||wwv_flow.LF||
'    :new.row_version        := nvl(:old.row_version,1) + 1;                     ';
wwv_flow_imp.g_varchar2_table(16) := '           '||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
'  :new.updated_by         := nvl(v(''APP_USER''), USER);'||wwv_flow.LF||
'  :new.updated         ';
wwv_flow_imp.g_varchar2_table(17) := '   := current_timestamp;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1374530106979158301)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'create eba_cust_acl_features'
,p_sequence=>430
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_CUST_ACL_FEATURES'';'))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
