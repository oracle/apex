prompt --application/deployment/install/install_lookup
begin
--   Manifest
--     INSTALL: INSTALL-lookup
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_error_lookup ('||wwv_flow.LF||
'    constraint_name         varchar2(30)        not null'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(2) := '                                          constraint eba_cust_error_lookup_pk'||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(3) := '                          primary key,'||wwv_flow.LF||
'    message                 varchar2(4000)      not null,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(4) := ' language_code           varchar2(30)        not null'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust_error_lookup_';
wwv_flow_imp.g_varchar2_table(5) := 'uk on eba_cust_error_lookup (constraint_name,language_code);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16674619404019401111)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'lookup'
,p_sequence=>120
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
