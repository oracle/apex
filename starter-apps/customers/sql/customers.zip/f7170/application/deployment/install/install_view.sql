prompt --application/deployment/install/install_view
begin
--   Manifest
--     INSTALL: INSTALL-view
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace view eba_cust_customers_v as'||wwv_flow.LF||
'select '||wwv_flow.LF||
'   a.row_key, '||wwv_flow.LF||
'   a.id,'||wwv_flow.LF||
'   customer_name,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(2) := 'status,'||wwv_flow.LF||
'   a.status_id,'||wwv_flow.LF||
'   category,'||wwv_flow.LF||
'   geography_name,'||wwv_flow.LF||
'   referencable,'||wwv_flow.LF||
'   number_of_users,'||wwv_flow.LF||
'   summ';
wwv_flow_imp.g_varchar2_table(3) := 'ary,'||wwv_flow.LF||
'   web_site,'||wwv_flow.LF||
'   (select listagg(p.product_name, '', '') within group (order by p.product_name) pr';
wwv_flow_imp.g_varchar2_table(4) := 'oduct_uses'||wwv_flow.LF||
'    from eba_cust_customers c, eba_cust_product_uses u, eba_cust_products p'||wwv_flow.LF||
'    where c.i';
wwv_flow_imp.g_varchar2_table(5) := 'd = u.customer_id'||wwv_flow.LF||
'    and u.product_id = p.id'||wwv_flow.LF||
'    and c.id = a.id'||wwv_flow.LF||
'    group by c.customer_name'||wwv_flow.LF||
'   ) ';
wwv_flow_imp.g_varchar2_table(6) := 'product_uses,'||wwv_flow.LF||
'   nvl((select industry_name from eba_cust_industries i where i.id = a.industry_id),''N';
wwv_flow_imp.g_varchar2_table(7) := 'ot Defined'') industry,'||wwv_flow.LF||
'   tags,'||wwv_flow.LF||
'   a.created,'||wwv_flow.LF||
'   a.created_by,'||wwv_flow.LF||
'   a.updated,'||wwv_flow.LF||
'   a.updated_by'||wwv_flow.LF||
'from   ';
wwv_flow_imp.g_varchar2_table(8) := ''||wwv_flow.LF||
'   eba_cust_customers a, '||wwv_flow.LF||
'   eba_cust_categories b, '||wwv_flow.LF||
'   eba_cust_status c, '||wwv_flow.LF||
'   eba_cust_geographies';
wwv_flow_imp.g_varchar2_table(9) := ' d'||wwv_flow.LF||
'where '||wwv_flow.LF||
'   a.category_id = b.id (+) and '||wwv_flow.LF||
'   a.status_id = c.id (+) and '||wwv_flow.LF||
'   a.geography_id = d.id (';
wwv_flow_imp.g_varchar2_table(10) := '+)'||wwv_flow.LF||
';'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16615212576121798026)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'view'
,p_sequence=>480
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
