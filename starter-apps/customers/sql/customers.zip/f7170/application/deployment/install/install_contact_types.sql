prompt --application/deployment/install/install_contact_types
begin
--   Manifest
--     INSTALL: INSTALL-contact types
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_contact_types ('||wwv_flow.LF||
'   id                      number       not null,'||wwv_flow.LF||
'   row_versi';
wwv_flow_imp.g_varchar2_table(2) := 'on_number      number,'||wwv_flow.LF||
'   contact_type            varchar2(60) not null,'||wwv_flow.LF||
'   is_active               ';
wwv_flow_imp.g_varchar2_table(3) := 'varchar2(1)  default ''Y'','||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   created               timestamp with time zone not null,'||wwv_flow.LF||
'   creat';
wwv_flow_imp.g_varchar2_table(4) := 'ed_by            varchar2(255) not null,'||wwv_flow.LF||
'   updated               timestamp with time zone,'||wwv_flow.LF||
'   updat';
wwv_flow_imp.g_varchar2_table(5) := 'ed_by            varchar2(255)'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_contact_types'||wwv_flow.LF||
'   add constraint eba_cust_c';
wwv_flow_imp.g_varchar2_table(6) := 'ontact_types_pk'||wwv_flow.LF||
'       primary key (id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust_contact_types_uk on eba_cust_';
wwv_flow_imp.g_varchar2_table(7) := 'contact_types(contact_type)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_contact_types'||wwv_flow.LF||
'   add constraint eba_cust_contact_';
wwv_flow_imp.g_varchar2_table(8) := 'types_uk'||wwv_flow.LF||
'       unique (contact_type)'||wwv_flow.LF||
'       using index eba_cust_contact_types_uk'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16674621188135424920)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'contact types'
,p_sequence=>230
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
