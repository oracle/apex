prompt --application/deployment/install/install_timezone
begin
--   Manifest
--     INSTALL: INSTALL-timezone
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_tz_pref ('||wwv_flow.LF||
'  id                        number not null'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(2) := '    constraint eba_cust_tz_pref_pk'||wwv_flow.LF||
'                            primary key,'||wwv_flow.LF||
'  row_version_number    ';
wwv_flow_imp.g_varchar2_table(3) := '    integer,'||wwv_flow.LF||
'  userid                    varchar2(255) not null,'||wwv_flow.LF||
'  TIMEZONE_PREFERENCE       varchar';
wwv_flow_imp.g_varchar2_table(4) := '2(255) not null,'||wwv_flow.LF||
'  created                   timestamp with time zone,'||wwv_flow.LF||
'  created_by                v';
wwv_flow_imp.g_varchar2_table(5) := 'archar2(255),'||wwv_flow.LF||
'  updated                   timestamp with time zone,'||wwv_flow.LF||
'  updated_by                varc';
wwv_flow_imp.g_varchar2_table(6) := 'har2(255)'||wwv_flow.LF||
'  );'||wwv_flow.LF||
'  '||wwv_flow.LF||
'create or replace trigger biu_eba_cust_tz_pref'||wwv_flow.LF||
'   before insert or update on eba_c';
wwv_flow_imp.g_varchar2_table(7) := 'ust_tz_pref'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXX';
wwv_flow_imp.g_varchar2_table(8) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.';
wwv_flow_imp.g_varchar2_table(9) := 'created := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updat';
wwv_flow_imp.g_varchar2_table(10) := 'ed := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_versio';
wwv_flow_imp.g_varchar2_table(11) := 'n_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,';
wwv_flow_imp.g_varchar2_table(12) := '1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(13) := ' :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if :new.TIMEZONE_PREFERENCE is null the';
wwv_flow_imp.g_varchar2_table(14) := 'n'||wwv_flow.LF||
'       :new.timezone_preference := ''UTC'';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger biu_eba_cust_tz_pref ena';
wwv_flow_imp.g_varchar2_table(15) := 'ble;    '||wwv_flow.LF||
'    '||wwv_flow.LF||
'create or replace procedure eba_cust_tz_init'||wwv_flow.LF||
'as'||wwv_flow.LF||
'  c integer := 0;'||wwv_flow.LF||
'  l_app_user varchar';
wwv_flow_imp.g_varchar2_table(16) := '2(255);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'l_app_user := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'for c1 in ('||wwv_flow.LF||
'   select TIMEZONE_PREFERENCE'||wwv_flow.LF||
'   fr';
wwv_flow_imp.g_varchar2_table(17) := 'om   eba_cust_tz_pref'||wwv_flow.LF||
'   where  USERID = l_app_user) loop'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   if c1.TIMEZONE_PREFERENCE is not ';
wwv_flow_imp.g_varchar2_table(18) := 'null then'||wwv_flow.LF||
'       c := c + 1;'||wwv_flow.LF||
'       APEX_UTIL.SET_SESSION_TIME_ZONE (P_TIME_ZONE => c1.TIMEZONE_PREF';
wwv_flow_imp.g_varchar2_table(19) := 'ERENCE ); '||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   exit;'||wwv_flow.LF||
'end loop;'||wwv_flow.LF||
'if c = 0 then'||wwv_flow.LF||
'    if apex_util.get_session_time_zone is nul';
wwv_flow_imp.g_varchar2_table(20) := 'l then'||wwv_flow.LF||
'        APEX_UTIL.SET_SESSION_TIME_ZONE (P_TIME_ZONE => ''US/Pacific''); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end if;'||wwv_flow.LF||
'e';
wwv_flow_imp.g_varchar2_table(21) := 'nd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16625382074932840262)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'timezone'
,p_sequence=>50
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
