prompt --application/deployment/install/install_product_uses
begin
--   Manifest
--     INSTALL: INSTALL-product uses
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_product_uses ('||wwv_flow.LF||
'    id                      number         not NULL,'||wwv_flow.LF||
'    row_ve';
wwv_flow_imp.g_varchar2_table(2) := 'rsion_number      number         not null,'||wwv_flow.LF||
'    customer_id             number         not NULL,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(3) := 'product_id              number         not NULL,'||wwv_flow.LF||
'    reference_type_ids      varchar2(4000),'||wwv_flow.LF||
'    int';
wwv_flow_imp.g_varchar2_table(4) := 'ernal_contact        varchar2(255),'||wwv_flow.LF||
'    customer_contact_id     number,'||wwv_flow.LF||
'    reference_status_id     ';
wwv_flow_imp.g_varchar2_table(5) := 'number,'||wwv_flow.LF||
'    valid_from              timestamp with time zone,'||wwv_flow.LF||
'    valid_to                timestamp ';
wwv_flow_imp.g_varchar2_table(6) := 'with time zone,'||wwv_flow.LF||
'    comments                varchar2(4000),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created               timesta';
wwv_flow_imp.g_varchar2_table(7) := 'mp with time zone not null,'||wwv_flow.LF||
'    created_by            varchar2(255) not null,'||wwv_flow.LF||
'    updated           ';
wwv_flow_imp.g_varchar2_table(8) := '    timestamp with time zone,'||wwv_flow.LF||
'    updated_by            varchar2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_pr';
wwv_flow_imp.g_varchar2_table(9) := 'oduct_uses'||wwv_flow.LF||
'   add constraint eba_cust_product_uses_pk'||wwv_flow.LF||
'       primary key (id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust';
wwv_flow_imp.g_varchar2_table(10) := '_product_uses'||wwv_flow.LF||
'   add constraint eba_cust_product_uses_cust_fk'||wwv_flow.LF||
'       foreign key (customer_id)'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(11) := '  references eba_cust_customers (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_product_uses'||wwv_flow.LF||
'   add co';
wwv_flow_imp.g_varchar2_table(12) := 'nstraint eba_cust_product_uses_prod_fk'||wwv_flow.LF||
'       foreign key (product_id)'||wwv_flow.LF||
'       references eba_cust_pr';
wwv_flow_imp.g_varchar2_table(13) := 'oducts (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_product_uses'||wwv_flow.LF||
'   add constraint eba_cust_prod_us';
wwv_flow_imp.g_varchar2_table(14) := 'es_contact_fk'||wwv_flow.LF||
'       foreign key (customer_contact_id)'||wwv_flow.LF||
'       references eba_cust_contacts (id) on d';
wwv_flow_imp.g_varchar2_table(15) := 'elete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_cust_product_uses_01 on eba_cust_product_uses (customer_id);'||wwv_flow.LF||
'creat';
wwv_flow_imp.g_varchar2_table(16) := 'e index eba_cust_product_uses_02 on eba_cust_product_uses (product_id);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16674620980517422720)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'product uses'
,p_sequence=>250
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
