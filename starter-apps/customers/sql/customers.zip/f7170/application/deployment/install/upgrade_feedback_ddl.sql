prompt --application/deployment/install/upgrade_feedback_ddl
begin
--   Manifest
--     INSTALL: UPGRADE-Feedback DDL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_feedback'||wwv_flow.LF||
'('||wwv_flow.LF||
'    id             number constraint eba_cust_feedback_pk not null ';
wwv_flow_imp.g_varchar2_table(2) := 'primary key,'||wwv_flow.LF||
'    application_id number not null,'||wwv_flow.LF||
'    page_id        number not null,'||wwv_flow.LF||
'    feedback   ';
wwv_flow_imp.g_varchar2_table(3) := '    varchar2(4000),'||wwv_flow.LF||
'    response       varchar2(4000),'||wwv_flow.LF||
'    type_id        number,'||wwv_flow.LF||
'    status        ';
wwv_flow_imp.g_varchar2_table(4) := ' varchar2(30),'||wwv_flow.LF||
'    created        timestamp with time zone,'||wwv_flow.LF||
'    created_by     varchar2(255),'||wwv_flow.LF||
'    up';
wwv_flow_imp.g_varchar2_table(5) := 'dated        timestamp with time zone,'||wwv_flow.LF||
'    updated_by     varchar2(255),'||wwv_flow.LF||
'    constraint eba_cust_fee';
wwv_flow_imp.g_varchar2_table(6) := 'dback_type_fk foreign key (type_id) references eba_cust_feedback_types (id)'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_cus';
wwv_flow_imp.g_varchar2_table(7) := 't_feedback_type_idx on eba_cust_feedback (type_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_cust_feedback_biu';
wwv_flow_imp.g_varchar2_table(8) := ''||wwv_flow.LF||
'    before insert or update '||wwv_flow.LF||
'    on eba_cust_feedback'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null';
wwv_flow_imp.g_varchar2_table(9) := ' then'||wwv_flow.LF||
'        :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(10) := 'f inserting then'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := NVL(V(''APP_US';
wwv_flow_imp.g_varchar2_table(11) := 'ER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := NVL(V(''APP_USE';
wwv_flow_imp.g_varchar2_table(12) := 'R''),user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger eba_cust_feedback_biu enable'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(18744673058150962049)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Feedback DDL'
,p_sequence=>380
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_CUST_FEEDBACK'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
