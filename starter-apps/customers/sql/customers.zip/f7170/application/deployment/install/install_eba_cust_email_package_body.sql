prompt --application/deployment/install/install_eba_cust_email_package_body
begin
--   Manifest
--     INSTALL: INSTALL-eba_cust_email package body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body eba_cust_email as'||wwv_flow.LF||
''||wwv_flow.LF||
'    c_fb_subject constant varchar2(500) := eba_cus';
wwv_flow_imp.g_varchar2_table(2) := 't_fw.get_preference_value(''APPLICATION_TITLE'') || '': Feedback Submission'';'||wwv_flow.LF||
'    c_base_url   constant';
wwv_flow_imp.g_varchar2_table(3) := ' varchar2(500) := eba_cust_fw.get_preference_value(''HOST_URL'');'||wwv_flow.LF||
'    c_top_tmpl   constant clob := ''<';
wwv_flow_imp.g_varchar2_table(4) := '!DOCTYPE HTML>'||wwv_flow.LF||
'<html>'||wwv_flow.LF||
'<head>'||wwv_flow.LF||
'<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">'||wwv_flow.LF||
'<me';
wwv_flow_imp.g_varchar2_table(5) := 'ta name="viewport" content="width=device-width">'||wwv_flow.LF||
'<title>#APP_NAME#</title>'||wwv_flow.LF||
'<style>'||wwv_flow.LF||
'    body { backgr';
wwv_flow_imp.g_varchar2_table(6) := 'ound-color: #ffffff; color: #707070; margin: 0; padding: 0; min-width: 100%; -webkit-text-size-adjus';
wwv_flow_imp.g_varchar2_table(7) := 't: none; -ms-text-size-adjust: none; text-size-adjust: none; font-family: Helvetica, Arial, sans-ser';
wwv_flow_imp.g_varchar2_table(8) := 'if; mso-line-height-rule: exactly; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: gra';
wwv_flow_imp.g_varchar2_table(9) := 'yscale; }'||wwv_flow.LF||
'    table { border: 0; border-spacing: 0; border-collapse: collapse; mso-table-lspace: 0pt';
wwv_flow_imp.g_varchar2_table(10) := '; mso-table-rspace: 0pt; }'||wwv_flow.LF||
'    table td { padding: 0; vertical-align: top; border-collapse: collapse';
wwv_flow_imp.g_varchar2_table(11) := '; }'||wwv_flow.LF||
'    p { margin: 0 0 16px 0; }'||wwv_flow.LF||
'    table.container { margin-right: auto; margin-left: auto; width';
wwv_flow_imp.g_varchar2_table(12) := ': 580px; }'||wwv_flow.LF||
'    a { color: #2C7ABF; }'||wwv_flow.LF||
'    body, th, td { line-height: 1.5; }'||wwv_flow.LF||
'    @media only screen a';
wwv_flow_imp.g_varchar2_table(13) := 'nd (max-width: 580px) {'||wwv_flow.LF||
'      .mobile-hide { display: none !important; }'||wwv_flow.LF||
'      .stack { display: blo';
wwv_flow_imp.g_varchar2_table(14) := 'ck !important; width: 100% !important; }'||wwv_flow.LF||
'      table.container { width: 100% !important; }'||wwv_flow.LF||
'      .he';
wwv_flow_imp.g_varchar2_table(15) := 'ader { height: auto !important; }'||wwv_flow.LF||
'      .category-content td,'||wwv_flow.LF||
'      .sub-category-title,'||wwv_flow.LF||
'      .cate';
wwv_flow_imp.g_varchar2_table(16) := 'gory-title { padding-left: 10px !important; padding-right: 10px !important; }'||wwv_flow.LF||
'    }'||wwv_flow.LF||
'</style>'||wwv_flow.LF||
'</head>';
wwv_flow_imp.g_varchar2_table(17) := ''||wwv_flow.LF||
'<body bgcolor="#ffffff" style="font-family: Helvetica, Arial, sans-serif; background-color: #ffffff';
wwv_flow_imp.g_varchar2_table(18) := '; color: #707070; margin: 0; padding: 0;">'||wwv_flow.LF||
'<table class="body" border="0" width="100%" style="font-f';
wwv_flow_imp.g_varchar2_table(19) := 'amily: Helvetica, Arial, sans-serif">'||wwv_flow.LF||
'<tr>'||wwv_flow.LF||
'<td align="center" valign="top" style="background-color: ';
wwv_flow_imp.g_varchar2_table(20) := '#ffffff; color: #707070;">'||wwv_flow.LF||
'<center>'||wwv_flow.LF||
''||wwv_flow.LF||
'<!-- Header Wrapper -->'||wwv_flow.LF||
'<table width="100%" border="0" bgcolor=';
wwv_flow_imp.g_varchar2_table(21) := '"#fd2a1b" style="background-color: #fd2a1b; color: #ffffff;">'||wwv_flow.LF||
'<tr>'||wwv_flow.LF||
'<td>'||wwv_flow.LF||
''||wwv_flow.LF||
'<table align="center" borde';
wwv_flow_imp.g_varchar2_table(22) := 'r="0" class="container" width="600">'||wwv_flow.LF||
'<tr>'||wwv_flow.LF||
'<td class="header" style="font-size: 14px; line-height: 1.';
wwv_flow_imp.g_varchar2_table(23) := '3; text-align: left; padding: 10px; height: 140px; vertical-align: middle; color: #ffffff;" valign="';
wwv_flow_imp.g_varchar2_table(24) := 'middle" align="left">'||wwv_flow.LF||
'<font style="font-size: 28px;">#SUBJECT#</font>#RECIPIENT_EMAIL#'||wwv_flow.LF||
'</td>'||wwv_flow.LF||
'</tr>'||wwv_flow.LF||
'<';
wwv_flow_imp.g_varchar2_table(25) := '/table>'||wwv_flow.LF||
''||wwv_flow.LF||
'</td>'||wwv_flow.LF||
'</tr>'||wwv_flow.LF||
'</table>'||wwv_flow.LF||
'<!-- // Header Wrapper -->'||wwv_flow.LF||
'<br>'||wwv_flow.LF||
''||wwv_flow.LF||
'<!-- Content Wrapper -->'||wwv_flow.LF||
'<table align';
wwv_flow_imp.g_varchar2_table(26) := '="center" border="0" class="container" width="600">'||wwv_flow.LF||
'<tr>'||wwv_flow.LF||
'<td class="container-inner" style="text-ali';
wwv_flow_imp.g_varchar2_table(27) := 'gn: left; padding-left: 10px; padding-right: 10px;" align="left">'||wwv_flow.LF||
'''; -- Email Top'||wwv_flow.LF||
''||wwv_flow.LF||
'    c_btm_tmpl   ';
wwv_flow_imp.g_varchar2_table(28) := 'constant clob := '''||wwv_flow.LF||
'</td>'||wwv_flow.LF||
'</tr>'||wwv_flow.LF||
'</table>'||wwv_flow.LF||
'<!-- // Content Wrapper -->'||wwv_flow.LF||
'<br>'||wwv_flow.LF||
'''; -- Email Bottom'||wwv_flow.LF||
''||wwv_flow.LF||
'    pro';
wwv_flow_imp.g_varchar2_table(29) := 'cedure set_apex_session( p_app_id in number ) is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        for c1 in ( select workspace_id'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(30) := '                   from apex_applications'||wwv_flow.LF||
'                    where application_id = p_app_id ) loop';
wwv_flow_imp.g_varchar2_table(31) := ''||wwv_flow.LF||
'            apex_util.set_security_group_id('||wwv_flow.LF||
'                p_security_group_id => c1.workspace_id';
wwv_flow_imp.g_varchar2_table(32) := ');'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'    end set_apex_session;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure log_sent_email'||wwv_flow.LF||
'    ('||wwv_flow.LF||
'        p_email_t';
wwv_flow_imp.g_varchar2_table(33) := 'o    in varchar2,'||wwv_flow.LF||
'        p_email_from  in varchar2,'||wwv_flow.LF||
'        p_body_size   in number,'||wwv_flow.LF||
'        p_type';
wwv_flow_imp.g_varchar2_table(34) := '        in varchar2,'||wwv_flow.LF||
'        p_customer_id in number    default null'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(35) := 'insert into eba_cust_email_log'||wwv_flow.LF||
'        (email_first_to, email_to, email_from, body_size, created_by,';
wwv_flow_imp.g_varchar2_table(36) := ''||wwv_flow.LF||
'         created, email_type, customer_id)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'        (p_email_to, p_email_to, p_email_';
wwv_flow_imp.g_varchar2_table(37) := 'from, p_body_size, nvl( nvl( wwv_flow.g_user, v(''APP_USER'') ), user),'||wwv_flow.LF||
'         current_timestamp, p_';
wwv_flow_imp.g_varchar2_table(38) := 'type, p_customer_id);'||wwv_flow.LF||
'    end log_sent_email;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function get_build_option_status'||wwv_flow.LF||
'    ('||wwv_flow.LF||
'        p_';
wwv_flow_imp.g_varchar2_table(39) := 'app_id  in number,'||wwv_flow.LF||
'        p_bo_name in varchar2'||wwv_flow.LF||
'    ) return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_retval varch';
wwv_flow_imp.g_varchar2_table(40) := 'ar2(10) := ''EXCLUDE'';'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        for c1 in'||wwv_flow.LF||
'        ('||wwv_flow.LF||
'            select upper(build_option_st';
wwv_flow_imp.g_varchar2_table(41) := 'atus) as bo_value'||wwv_flow.LF||
'              from apex_application_build_options'||wwv_flow.LF||
'             where upper(build_o';
wwv_flow_imp.g_varchar2_table(42) := 'ption_name) = upper(p_bo_name)'||wwv_flow.LF||
'               and application_id = p_app_id'||wwv_flow.LF||
'        )'||wwv_flow.LF||
'        loop'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(43) := '           l_retval := c1.bo_value;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        return l_retval;'||wwv_flow.LF||
'    end get_build_opt';
wwv_flow_imp.g_varchar2_table(44) := 'ion_status;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function get_feedback_email_body ('||wwv_flow.LF||
'        p_app_id        in number,'||wwv_flow.LF||
'        p_pag';
wwv_flow_imp.g_varchar2_table(45) := 'e_id       in number,'||wwv_flow.LF||
'        p_submitter     in varchar2,'||wwv_flow.LF||
'        p_feedback_type in varchar2,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(46) := '    p_feedback      in varchar2,'||wwv_flow.LF||
'        p_fb_rpt_page   in number'||wwv_flow.LF||
'    ) return clob'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'       l';
wwv_flow_imp.g_varchar2_table(47) := '_clob clob;'||wwv_flow.LF||
'       l_body clob;'||wwv_flow.LF||
'       m      clob;'||wwv_flow.LF||
'       '||wwv_flow.LF||
'       l_submitter        varchar2(32000';
wwv_flow_imp.g_varchar2_table(48) := ')    :=    apex_escape.html(p_submitter);'||wwv_flow.LF||
'       l_feedback_type    varchar2(32000)    :=    apex_es';
wwv_flow_imp.g_varchar2_table(49) := 'cape.html(p_feedback_type);'||wwv_flow.LF||
'       l_feedback        varchar2(32000)     :=    apex_escape.html(p_fe';
wwv_flow_imp.g_varchar2_table(50) := 'edback);'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        l_clob := m;'||wwv_flow.LF||
'        m := m || replace(replace(replace(c_top_tmpl, ''#APP_';
wwv_flow_imp.g_varchar2_table(51) := 'NAME#'', eba_cust_fw.get_preference_value(''APPLICATION_TITLE'')), ''#SUBJECT#'', c_fb_subject), ''#RECIPI';
wwv_flow_imp.g_varchar2_table(52) := 'ENT_EMAIL#'', null);'||wwv_flow.LF||
'        l_clob := l_clob || m;'||wwv_flow.LF||
'        m := null;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- Construct html bod';
wwv_flow_imp.g_varchar2_table(53) := 'y'||wwv_flow.LF||
'        l_body := ''<p>'' || l_submitter || '' has submitted the following <strong><a href="'' || c_ba';
wwv_flow_imp.g_varchar2_table(54) := 'se_url || apex_util.prepare_url('||wwv_flow.LF||
'                  ''f?p='' || p_app_id || '':'' || p_fb_rpt_page || '':0';
wwv_flow_imp.g_varchar2_table(55) := ':::'' || p_fb_rpt_page || '',RIR:IREQ_PAGE_ID,IREQ_TYPE_ID,IREQ_CREATED_BY:'' || p_page_id || '','' ||'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(56) := '                l_feedback_type || '','' || upper(l_submitter)) || ''">'' || l_feedback_type || ''</a></s';
wwv_flow_imp.g_varchar2_table(57) := 'trong> from page '' || p_page_id || '':</p>'' ||'||wwv_flow.LF||
'                  ''<p>'' || l_feedback || ''</p>'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(58) := '    -- Add body to current clob'||wwv_flow.LF||
'        l_clob := l_clob || l_body;'||wwv_flow.LF||
''||wwv_flow.LF||
'        m := m || c_btm_tmpl ||';
wwv_flow_imp.g_varchar2_table(59) := ' c_btm_tmpl;'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_clob := l_clob || m;'||wwv_flow.LF||
''||wwv_flow.LF||
'        return l_clob;'||wwv_flow.LF||
'    end get_feedback_email_body';
wwv_flow_imp.g_varchar2_table(60) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure send_feedback_email'||wwv_flow.LF||
'    ('||wwv_flow.LF||
'        p_app_id        in number,'||wwv_flow.LF||
'        p_page_id     ';
wwv_flow_imp.g_varchar2_table(61) := '  in number,'||wwv_flow.LF||
'        p_submitter     in varchar2,'||wwv_flow.LF||
'        p_feedback_type in varchar2,'||wwv_flow.LF||
'        p_fee';
wwv_flow_imp.g_varchar2_table(62) := 'dback      in varchar2'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_subject       varchar2(500) := c_fb_subject;'||wwv_flow.LF||
'        l';
wwv_flow_imp.g_varchar2_table(63) := '_body          clob := '' '';'||wwv_flow.LF||
'        l_body_html     clob;'||wwv_flow.LF||
'        l_email_type    varchar2(30) := ''F';
wwv_flow_imp.g_varchar2_table(64) := 'EEDBACK_SUBMISSION'';'||wwv_flow.LF||
'        l_from          varchar2(255);'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        if eba_cust_fw.get_pre';
wwv_flow_imp.g_varchar2_table(65) := 'ference_value(p_preference_name  => ''FEEDBACK_RECIPIENTS'') = ''Preference does not exist'' or'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(66) := '   get_build_option_status(p_app_id => p_app_id, p_bo_name => ''Feedback'') = ''EXCLUDE'' then'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(67) := '   return; -- No Feedback Recipients Defined or the Feedback build option has been disabled so exit'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(68) := '        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        set_apex_session( p_app_id );'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- Determine Sender'||wwv_flow.LF||
'        if instr';
wwv_flow_imp.g_varchar2_table(69) := '(p_submitter,''@'') > 0 then'||wwv_flow.LF||
'            l_from := lower(p_submitter);'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            for c1';
wwv_flow_imp.g_varchar2_table(70) := ' in (select username from eba_cust_users where upper(username) = upper(p_submitter) and username is ';
wwv_flow_imp.g_varchar2_table(71) := 'not null and instr(username,''@'') > 0)'||wwv_flow.LF||
'            loop'||wwv_flow.LF||
'                l_from := lower(c1.username);';
wwv_flow_imp.g_varchar2_table(72) := ''||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if l_from is null then'||wwv_flow.LF||
'            if instr(eba_cust_';
wwv_flow_imp.g_varchar2_table(73) := 'fw.get_preference_value(p_preference_name  => ''FEEDBACK_RECIPIENTS''),'','') > 0 then'||wwv_flow.LF||
'                l';
wwv_flow_imp.g_varchar2_table(74) := '_from := lower( substr( eba_cust_fw.get_preference_value(p_preference_name  => ''FEEDBACK_RECIPIENTS''';
wwv_flow_imp.g_varchar2_table(75) := '), 1, instr(eba_cust_fw.get_preference_value(p_preference_name  => ''FEEDBACK_RECIPIENTS''),'','') - 1) ';
wwv_flow_imp.g_varchar2_table(76) := ');'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'                l_from := lower( eba_cust_fw.get_preference_value(p_preference_n';
wwv_flow_imp.g_varchar2_table(77) := 'ame  => ''FEEDBACK_RECIPIENTS'') );'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- Assign local varia';
wwv_flow_imp.g_varchar2_table(78) := 'bles'||wwv_flow.LF||
'        l_body_html     := get_feedback_email_body ('||wwv_flow.LF||
'                               p_app_id   ';
wwv_flow_imp.g_varchar2_table(79) := '     => p_app_id,'||wwv_flow.LF||
'                               p_page_id       => p_page_id,'||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(80) := '          p_submitter     => p_submitter,'||wwv_flow.LF||
'                               p_feedback_type => p_feedba';
wwv_flow_imp.g_varchar2_table(81) := 'ck_type,'||wwv_flow.LF||
'                               p_feedback      => p_feedback,'||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(82) := '  p_fb_rpt_page   => 119'||wwv_flow.LF||
'                           );'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- Send email'||wwv_flow.LF||
'        apex_mail.send';
wwv_flow_imp.g_varchar2_table(83) := '('||wwv_flow.LF||
'            p_to        => eba_cust_fw.get_preference_value(p_preference_name  => ''FEEDBACK_RECIPI';
wwv_flow_imp.g_varchar2_table(84) := 'ENTS''),'||wwv_flow.LF||
'            p_from      => l_from,'||wwv_flow.LF||
'            p_body      => l_body,'||wwv_flow.LF||
'            p_body_htm';
wwv_flow_imp.g_varchar2_table(85) := 'l => ''<html><body>'' || l_body_html || ''</body></html>'','||wwv_flow.LF||
'            p_subj      => l_subject,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(86) := '      p_cc        => null,'||wwv_flow.LF||
'            p_bcc       => null,'||wwv_flow.LF||
'            p_replyto   => null);'||wwv_flow.LF||
''||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(87) := '   -- Log sent email'||wwv_flow.LF||
'        log_sent_email('||wwv_flow.LF||
'            p_email_to => eba_cust_fw.get_preference_va';
wwv_flow_imp.g_varchar2_table(88) := 'lue(p_preference_name  => ''FEEDBACK_RECIPIENTS''),'||wwv_flow.LF||
''||wwv_flow.LF||
'            p_email_from => l_from,'||wwv_flow.LF||
'            p';
wwv_flow_imp.g_varchar2_table(89) := '_body_size => 26 + length(l_body_html),'||wwv_flow.LF||
'            p_type => l_email_type);'||wwv_flow.LF||
''||wwv_flow.LF||
'        apex_mail.push';
wwv_flow_imp.g_varchar2_table(90) := '_queue;'||wwv_flow.LF||
'    end send_feedback_email;'||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_cust_email;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(18749215752058061124)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'eba_cust_email package body'
,p_sequence=>550
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
