prompt --application/deployment/install/install_countries
begin
--   Manifest
--     INSTALL: INSTALL-countries
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_countries ('||wwv_flow.LF||
'   id                        number primary key,'||wwv_flow.LF||
'   country_code  ';
wwv_flow_imp.g_varchar2_table(2) := '            varchar2(30)  not null,'||wwv_flow.LF||
'   country_name              varchar2(255) not null,'||wwv_flow.LF||
'   region_i';
wwv_flow_imp.g_varchar2_table(3) := 'd                 number,'||wwv_flow.LF||
'   display_yn                varchar2(1)'||wwv_flow.LF||
'                             cons';
wwv_flow_imp.g_varchar2_table(4) := 'traint eba_cust_countries_disp_cc'||wwv_flow.LF||
'                             check (display_yn in (''Y'',''N'')),'||wwv_flow.LF||
'   r';
wwv_flow_imp.g_varchar2_table(5) := 'ow_version_number        number,'||wwv_flow.LF||
'   created                   timestamp with time zone,'||wwv_flow.LF||
'   created_b';
wwv_flow_imp.g_varchar2_table(6) := 'y                varchar2(255),'||wwv_flow.LF||
'   updated                   timestamp with time zone,'||wwv_flow.LF||
'   updated_by';
wwv_flow_imp.g_varchar2_table(7) := '                varchar2(255)'||wwv_flow.LF||
');'||wwv_flow.LF||
'create unique index eba_cust_countries_i1 on eba_cust_countries(cou';
wwv_flow_imp.g_varchar2_table(8) := 'ntry_code);'||wwv_flow.LF||
'create unique index eba_cust_countries_i2 on eba_cust_countries(country_name);'||wwv_flow.LF||
''||wwv_flow.LF||
'alter ta';
wwv_flow_imp.g_varchar2_table(9) := 'ble eba_cust_countries'||wwv_flow.LF||
'   add constraint eba_countries_region_fk'||wwv_flow.LF||
'       foreign key (region_id)'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(10) := '   references eba_cust_geographies (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cust_';
wwv_flow_imp.g_varchar2_table(11) := 'countries'||wwv_flow.LF||
'   before insert or update on eba_cust_countries'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is nu';
wwv_flow_imp.g_varchar2_table(12) := 'll then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;';
wwv_flow_imp.g_varchar2_table(13) := ''||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'       :new.created_by :=';
wwv_flow_imp.g_varchar2_table(14) := ' nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(';
wwv_flow_imp.g_varchar2_table(15) := 'wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_v';
wwv_flow_imp.g_varchar2_table(16) := 'ersion_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(17) := '    :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end i';
wwv_flow_imp.g_varchar2_table(18) := 'f;'||wwv_flow.LF||
'   if :new.display_yn is null then '||wwv_flow.LF||
'      :new.display_yn := ''Y'';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger';
wwv_flow_imp.g_varchar2_table(19) := ' biu_eba_cust_countries enable;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16608957773846933099)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'countries'
,p_sequence=>90
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
