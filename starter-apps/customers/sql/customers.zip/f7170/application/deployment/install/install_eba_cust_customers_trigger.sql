prompt --application/deployment/install/install_eba_cust_customers_trigger
begin
--   Manifest
--     INSTALL: INSTALL-eba_cust_customers trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger biu_eba_cust_customers'||wwv_flow.LF||
'   before insert or update on eba_cust_customers'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(2) := ' for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'    nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new';
wwv_flow_imp.g_varchar2_table(3) := '.tags is not null then'||wwv_flow.LF||
'         :new.tags := eba_cust_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if i';
wwv_flow_imp.g_varchar2_table(4) := 'nserting then'||wwv_flow.LF||
'      if :NEW.ID is null then'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(5) := 'XXXXXXXXXXXXX'')'||wwv_flow.LF||
'        into :new.id'||wwv_flow.LF||
'        from dual;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      :NEW.CREATED := current_';
wwv_flow_imp.g_varchar2_table(6) := 'timestamp;'||wwv_flow.LF||
'      :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'      :NEW.UPDATED := current_timestamp';
wwv_flow_imp.g_varchar2_table(7) := ';'||wwv_flow.LF||
'      :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'      :new.row_version_number := 1;'||wwv_flow.LF||
'      :new.c';
wwv_flow_imp.g_varchar2_table(8) := 'ustomer_name_upper := trim(upper(:new.customer_name));'||wwv_flow.LF||
'      eba_cust_fw.tag_sync('||wwv_flow.LF||
'         p_new_ta';
wwv_flow_imp.g_varchar2_table(9) := 'gs      => :new.tags,'||wwv_flow.LF||
'         p_old_tags      => null,'||wwv_flow.LF||
'         p_content_type  => ''CUSTOMER'','||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(10) := '     p_content_id    => :new.id );'||wwv_flow.LF||
'      -- Add new column values into history table'||wwv_flow.LF||
'      -- CUSTOM';
wwv_flow_imp.g_varchar2_table(11) := 'ER_NAME (default)'||wwv_flow.LF||
'      if nvl(:old.customer_name, ''0'') != nvl(:new.customer_name,''0'') then '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(12) := ' insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, n';
wwv_flow_imp.g_varchar2_table(13) := 'ew_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''CUSTOMER_NAME'', null, substr(:ne';
wwv_flow_imp.g_varchar2_table(14) := 'w.customer_name,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- CUSTOMER_NAME_UPPER (default)'||wwv_flow.LF||
'      if nvl(:old.c';
wwv_flow_imp.g_varchar2_table(15) := 'ustomer_name_upper, ''0'') != nvl(:new.customer_name_upper,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_his';
wwv_flow_imp.g_varchar2_table(16) := 'tory (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(17) := '     (''CUSTOMERS'', :new.row_key, :new.id, ''CUSTOMER_NAME_UPPER'', null, substr(:new.customer_name_upp';
wwv_flow_imp.g_varchar2_table(18) := 'er,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- INDUSTRY_ID (foreign key)'||wwv_flow.LF||
'      if nvl(:old.industry_id,-999) ';
wwv_flow_imp.g_varchar2_table(19) := '!= nvl(:new.industry_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select industr';
wwv_flow_imp.g_varchar2_table(20) := 'y_name val from eba_cust_industries t where t.id = :new.industry_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(21) := '        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, ';
wwv_flow_imp.g_varchar2_table(22) := 'column_name, old_value, new_value) values'||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''INDUSTRY';
wwv_flow_imp.g_varchar2_table(23) := '_ID'', ov, nv);'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- CATEGORY_ID (foreign key)'||wwv_flow.LF||
'      if nvl(:old.category_id,-999) ';
wwv_flow_imp.g_varchar2_table(24) := '!= nvl(:new.category_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select categor';
wwv_flow_imp.g_varchar2_table(25) := 'y val from eba_cust_categories t where t.id = :new.category_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(26) := '   end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, colum';
wwv_flow_imp.g_varchar2_table(27) := 'n_name, old_value, new_value) values'||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''CATEGORY_ID'',';
wwv_flow_imp.g_varchar2_table(28) := ' ov, nv);'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- STATUS_ID (foreign key)'||wwv_flow.LF||
'      if nvl(:old.status_id,-999) != nvl(:n';
wwv_flow_imp.g_varchar2_table(29) := 'ew.status_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select status val from eb';
wwv_flow_imp.g_varchar2_table(30) := 'a_cust_status t where t.id = :new.status_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(31) := '  insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, ';
wwv_flow_imp.g_varchar2_table(32) := 'new_value) values'||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''STATUS_ID'', ov, nv);'||wwv_flow.LF||
'      end i';
wwv_flow_imp.g_varchar2_table(33) := 'f;'||wwv_flow.LF||
'      -- GEOGRAPHY_ID (foreign key)'||wwv_flow.LF||
'      if nvl(:old.geography_id,-999) != nvl(:new.geography_id';
wwv_flow_imp.g_varchar2_table(34) := ',-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select geography_name val from eba_cu';
wwv_flow_imp.g_varchar2_table(35) := 'st_geographies t where t.id = :new.geography_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(36) := '      insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_val';
wwv_flow_imp.g_varchar2_table(37) := 'ue, new_value) values'||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''GEOGRAPHY_ID'', ov, nv);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(38) := '  end if;'||wwv_flow.LF||
'      -- REFERENCABLE (default)'||wwv_flow.LF||
'      if nvl(:old.referencable, ''0'') != nvl(:new.referenca';
wwv_flow_imp.g_varchar2_table(39) := 'ble,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, col';
wwv_flow_imp.g_varchar2_table(40) := 'umn_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''REFERENCAB';
wwv_flow_imp.g_varchar2_table(41) := 'LE'', null, substr(:new.referencable,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- MARQUEE_CUSTOMER_YN (default)';
wwv_flow_imp.g_varchar2_table(42) := ''||wwv_flow.LF||
'      if nvl(:old.marquee_customer_yn, ''0'') != nvl(:new.marquee_customer_yn,''0'') then '||wwv_flow.LF||
'        inse';
wwv_flow_imp.g_varchar2_table(43) := 'rt into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_va';
wwv_flow_imp.g_varchar2_table(44) := 'lue) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''MARQUEE_CUSTOMER'', null, substr(:new.';
wwv_flow_imp.g_varchar2_table(45) := 'marquee_customer_yn,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- TAGS (default)'||wwv_flow.LF||
'      if nvl(:old.tags, ''0'') !';
wwv_flow_imp.g_varchar2_table(46) := '= nvl(:new.tags,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, compo';
wwv_flow_imp.g_varchar2_table(47) := 'nent_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id,';
wwv_flow_imp.g_varchar2_table(48) := ' ''TAGS'', null, substr(:new.tags,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- CUSTOMER_PRODUCTS (default)'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(49) := ' if nvl(:old.customer_products, ''0'') != nvl(:new.customer_products,''0'') then '||wwv_flow.LF||
'        insert into eb';
wwv_flow_imp.g_varchar2_table(50) := 'a_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) value';
wwv_flow_imp.g_varchar2_table(51) := 's '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''CUSTOMER_PRODUCTS'', null, substr(:new.customer_';
wwv_flow_imp.g_varchar2_table(52) := 'products,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- NUMBER_OF_USERS (default)'||wwv_flow.LF||
'      if nvl(:old.number_of_us';
wwv_flow_imp.g_varchar2_table(53) := 'ers, ''0'') != nvl(:new.number_of_users,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, c';
wwv_flow_imp.g_varchar2_table(54) := 'omponent_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', ';
wwv_flow_imp.g_varchar2_table(55) := ':new.row_key, :new.id, ''NUMBER_OF_USERS'', null, substr(:new.number_of_users,0,4000) ); '||wwv_flow.LF||
'      end if';
wwv_flow_imp.g_varchar2_table(56) := ';'||wwv_flow.LF||
'      -- SUMMARY (default)'||wwv_flow.LF||
'      if nvl(:old.summary, ''0'') != nvl(:new.summary,''0'') then '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(57) := 'insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, ne';
wwv_flow_imp.g_varchar2_table(58) := 'w_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''SUMMARY'', null, substr(:new.summa';
wwv_flow_imp.g_varchar2_table(59) := 'ry,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- CUSTOMER_PROFILE (default)'||wwv_flow.LF||
'      if nvl(:old.customer_profile,';
wwv_flow_imp.g_varchar2_table(60) := ' ''0'') != nvl(:new.customer_profile,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, comp';
wwv_flow_imp.g_varchar2_table(61) := 'onent_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :ne';
wwv_flow_imp.g_varchar2_table(62) := 'w.row_key, :new.id, ''CUSTOMER_PROFILE'', null, substr(:new.customer_profile,0,4000) ); '||wwv_flow.LF||
'      end if;';
wwv_flow_imp.g_varchar2_table(63) := ''||wwv_flow.LF||
'      -- APPLICATIONS (default)'||wwv_flow.LF||
'      if nvl(:old.applications, ''0'') != nvl(:new.applications,''0'') ';
wwv_flow_imp.g_varchar2_table(64) := 'then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_name,';
wwv_flow_imp.g_varchar2_table(65) := ' old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''APPLICATIONS'', null';
wwv_flow_imp.g_varchar2_table(66) := ', substr(:new.applications,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- WEB_SITE (default)'||wwv_flow.LF||
'      if nvl(:old.w';
wwv_flow_imp.g_varchar2_table(67) := 'eb_site, ''0'') != nvl(:new.web_site,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, comp';
wwv_flow_imp.g_varchar2_table(68) := 'onent_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :ne';
wwv_flow_imp.g_varchar2_table(69) := 'w.row_key, :new.id, ''WEB_SITE'', null, substr(:new.web_site,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- LINKED';
wwv_flow_imp.g_varchar2_table(70) := 'IN (default)'||wwv_flow.LF||
'      if nvl(:old.linkedin, ''0'') != nvl(:new.linkedin,''0'') then '||wwv_flow.LF||
'        insert into eb';
wwv_flow_imp.g_varchar2_table(71) := 'a_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) value';
wwv_flow_imp.g_varchar2_table(72) := 's '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''LINKEDIN'', null, substr(:new.linkedin,0,4000) )';
wwv_flow_imp.g_varchar2_table(73) := '; '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- FACEBOOK (default)'||wwv_flow.LF||
'      if nvl(:old.facebook, ''0'') != nvl(:new.facebook,''';
wwv_flow_imp.g_varchar2_table(74) := '0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_n';
wwv_flow_imp.g_varchar2_table(75) := 'ame, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''FACEBOOK'', null';
wwv_flow_imp.g_varchar2_table(76) := ', substr(:new.facebook,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- TWITTER (default)'||wwv_flow.LF||
'      if nvl(:old.twitte';
wwv_flow_imp.g_varchar2_table(77) := 'r, ''0'') != nvl(:new.twitter,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_r';
wwv_flow_imp.g_varchar2_table(78) := 'owkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_k';
wwv_flow_imp.g_varchar2_table(79) := 'ey, :new.id, ''TWITTER'', null, substr(:new.twitter,0,4000) ); '||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'      -- STOCK_SYMBOL (de';
wwv_flow_imp.g_varchar2_table(80) := 'fault)'||wwv_flow.LF||
'      if nvl(:old.stock_symbol, ''0'') != nvl(:new.stock_symbol,''0'') then '||wwv_flow.LF||
'        insert into ';
wwv_flow_imp.g_varchar2_table(81) := 'eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) val';
wwv_flow_imp.g_varchar2_table(82) := 'ues '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''STOCK_SYMBOL'', null, substr(:new.stock_symbol';
wwv_flow_imp.g_varchar2_table(83) := ',0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- SIC (default)'||wwv_flow.LF||
'      if nvl(:old.sic, ''0'') != nvl(:new.sic,''0'') t';
wwv_flow_imp.g_varchar2_table(84) := 'hen '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, ';
wwv_flow_imp.g_varchar2_table(85) := 'old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''SIC'', null, substr(:';
wwv_flow_imp.g_varchar2_table(86) := 'new.sic,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- DUNS (default)'||wwv_flow.LF||
'      if nvl(:old.duns, ''0'') != nvl(:new.d';
wwv_flow_imp.g_varchar2_table(87) := 'uns,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, col';
wwv_flow_imp.g_varchar2_table(88) := 'umn_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''DUNS'', nul';
wwv_flow_imp.g_varchar2_table(89) := 'l, substr(:new.duns,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if :new.row_key is null then'||wwv_flow.LF||
'      selec';
wwv_flow_imp.g_varchar2_table(90) := 't eba_cust_fw.compress_int(eba_cust_seq.nextval) into :new.row_key from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if updat';
wwv_flow_imp.g_varchar2_table(91) := 'ing then'||wwv_flow.LF||
'      :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'      :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(92) := '      :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'      :new.customer_name_upper ';
wwv_flow_imp.g_varchar2_table(93) := ':= trim(upper(:new.customer_name));'||wwv_flow.LF||
'     eba_cust_fw.tag_sync('||wwv_flow.LF||
'         p_new_tags      => :new.tags';
wwv_flow_imp.g_varchar2_table(94) := ','||wwv_flow.LF||
'         p_old_tags      => :old.tags,'||wwv_flow.LF||
'         p_content_type  => ''CUSTOMER'','||wwv_flow.LF||
'         p_content_';
wwv_flow_imp.g_varchar2_table(95) := 'id    => :new.id );'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16613334278196685931)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'eba_cust_customers trigger'
,p_sequence=>380
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
