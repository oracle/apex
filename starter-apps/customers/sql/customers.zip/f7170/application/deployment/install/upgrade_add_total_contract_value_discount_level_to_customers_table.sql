prompt --application/deployment/install/upgrade_add_total_contract_value_discount_level_to_customers_table
begin
--   Manifest
--     INSTALL: UPGRADE-Add total_contract_value & discount_level to Customers table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'alter table eba_cust_customers add (total_contract_value number, discount_level number);'||wwv_flow.LF||
''||wwv_flow.LF||
'alter tabl';
wwv_flow_imp.g_varchar2_table(2) := 'e eba_cust_customers add  annual_recurring_revenue      number;'||wwv_flow.LF||
'alter table eba_cust_customers add  ';
wwv_flow_imp.g_varchar2_table(3) := 'currency                      varchar2(20);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1168438206045504656)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Add total_contract_value & discount_level to Customers table'
,p_sequence=>420
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tab_columns',
'where table_name = ''EBA_CUST_CUSTOMERS''',
'    and column_name in (''TOTAL_CONTRACT_VALUE'', ''DISCOUNT_LEVEL'')'))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
