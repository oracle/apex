prompt --application/deployment/install/upgrade_activities
begin
--   Manifest
--     INSTALL: UPGRADE-Activities
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- Activity Types'||wwv_flow.LF||
'create table eba_cust_activity_types ('||wwv_flow.LF||
'    id                 number not null,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(2) := ' row_version_number number not null,'||wwv_flow.LF||
'    name               varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created       ';
wwv_flow_imp.g_varchar2_table(3) := '     timestamp with time zone not null,'||wwv_flow.LF||
'    created_by         varchar2(255) not null,'||wwv_flow.LF||
'    updated  ';
wwv_flow_imp.g_varchar2_table(4) := '          timestamp with time zone,'||wwv_flow.LF||
'    updated_by         varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    constraint eba_';
wwv_flow_imp.g_varchar2_table(5) := 'cust_activity_types_pk primary key ( id ) using index'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust_activity_type';
wwv_flow_imp.g_varchar2_table(6) := 's_uk on eba_cust_activity_types( name );'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cust_activity_types'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(7) := '  before insert or update on eba_cust_activity_types'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(8) := '      if :new.id is null then'||wwv_flow.LF||
'            :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(9) := 'XXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl';
wwv_flow_imp.g_varchar2_table(10) := '(v(''APP_USER''),user);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        :new.row_version_number';
wwv_flow_imp.g_varchar2_table(11) := ' := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.';
wwv_flow_imp.g_varchar2_table(12) := 'updated_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end biu_eba_cust_activity_types;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger biu_eba_cust';
wwv_flow_imp.g_varchar2_table(13) := '_activity_types enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Activities'||wwv_flow.LF||
'create table eba_cust_activities ('||wwv_flow.LF||
'    id                 n';
wwv_flow_imp.g_varchar2_table(14) := 'umber not null,'||wwv_flow.LF||
'    row_version_number number not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    type_id            number not nul';
wwv_flow_imp.g_varchar2_table(15) := 'l,'||wwv_flow.LF||
'    name               varchar2(255),'||wwv_flow.LF||
'    description        varchar2(4000),'||wwv_flow.LF||
'    activity_date   ';
wwv_flow_imp.g_varchar2_table(16) := '   date,'||wwv_flow.LF||
'    owner              varchar2(255),'||wwv_flow.LF||
'    location           varchar2(4000),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    cre';
wwv_flow_imp.g_varchar2_table(17) := 'ated            timestamp with time zone not null,'||wwv_flow.LF||
'    created_by         varchar2(255) not null,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(18) := '  updated            timestamp with time zone,'||wwv_flow.LF||
'    updated_by         varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    cons';
wwv_flow_imp.g_varchar2_table(19) := 'traint eba_cust_activities_pk primary key ( id ) using index,'||wwv_flow.LF||
'    constraint eba_cust_activities_fk ';
wwv_flow_imp.g_varchar2_table(20) := 'foreign key ( type_id )'||wwv_flow.LF||
'        references eba_cust_activity_types( id )'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create index eba_cust_a';
wwv_flow_imp.g_varchar2_table(21) := 'ctivities_idx1 on eba_cust_activities( type_id )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger biu_eba_cust_activities';
wwv_flow_imp.g_varchar2_table(22) := ''||wwv_flow.LF||
'    before insert or update on eba_cust_activities'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(23) := '     if :new.id is null then'||wwv_flow.LF||
'            :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(24) := 'XXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(';
wwv_flow_imp.g_varchar2_table(25) := 'v(''APP_USER''),user);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        :new.row_version_number ';
wwv_flow_imp.g_varchar2_table(26) := ':= nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.u';
wwv_flow_imp.g_varchar2_table(27) := 'pdated_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end biu_eba_cust_activities;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger biu_eba_cust_acti';
wwv_flow_imp.g_varchar2_table(28) := 'vities enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger au_eba_cust_activities'||wwv_flow.LF||
'    after update on eba_cust_acti';
wwv_flow_imp.g_varchar2_table(29) := 'vities'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    pragma autonomous_transaction;'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(30) := '  nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- TYPE_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:old.type_id,-999) != nvl';
wwv_flow_imp.g_varchar2_table(31) := '(:new.type_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select name val from eba';
wwv_flow_imp.g_varchar2_table(32) := '_cust_activity_types t where t.id = :old.type_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(33) := '       for c1 in (select name val from eba_cust_activity_types t where t.id = :new.type_id) loop'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(34) := '         nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component';
wwv_flow_imp.g_varchar2_table(35) := '_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            (''ACTIVITIES'', null, :n';
wwv_flow_imp.g_varchar2_table(36) := 'ew.id, ''TYPE_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- NAME (default)'||wwv_flow.LF||
'    if nvl(:old.name, ''0'') != nvl(:new.';
wwv_flow_imp.g_varchar2_table(37) := 'name,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, co';
wwv_flow_imp.g_varchar2_table(38) := 'lumn_name, old_value, new_value) values '||wwv_flow.LF||
'            (''ACTIVITIES'', null, :new.id, ''NAME'', substr(:o';
wwv_flow_imp.g_varchar2_table(39) := 'ld.name,0,4000), substr(:new.name,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- DESCRIPTION (default)'||wwv_flow.LF||
'    if nvl(:o';
wwv_flow_imp.g_varchar2_table(40) := 'ld.description, ''0'') != nvl(:new.description,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_';
wwv_flow_imp.g_varchar2_table(41) := 'name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''ACTIV';
wwv_flow_imp.g_varchar2_table(42) := 'ITIES'', null, :new.id, ''DESCRIPTION'', substr(:old.description,0,4000), substr(:new.description,0,400';
wwv_flow_imp.g_varchar2_table(43) := '0) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- ACTIVITY_DATE (date/timestamp)'||wwv_flow.LF||
'    if (:old.activity_date is null and :new';
wwv_flow_imp.g_varchar2_table(44) := '.activity_date is not null) or '||wwv_flow.LF||
'        (:old.activity_date is not null and :new.activity_date is nu';
wwv_flow_imp.g_varchar2_table(45) := 'll) or '||wwv_flow.LF||
'        (:old.activity_date != :new.activity_date) then '||wwv_flow.LF||
'        insert into eba_cust_histor';
wwv_flow_imp.g_varchar2_table(46) := 'y (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(47) := '  (''ACTIVITIES'', null, :new.id, ''ACTIVITY_DATE'', to_char(:old.activity_date, ''DD-MON-YYYY''), to_char';
wwv_flow_imp.g_varchar2_table(48) := '(:new.activity_date, ''DD-MON-YYYY'') );'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- OWNER (default)'||wwv_flow.LF||
'    if nvl(:old.owner, ''0''';
wwv_flow_imp.g_varchar2_table(49) := ') != nvl(:new.owner,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, c';
wwv_flow_imp.g_varchar2_table(50) := 'omponent_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''ACTIVITIES'', null, :new.id, ''O';
wwv_flow_imp.g_varchar2_table(51) := 'WNER'', substr(:old.owner,0,4000), substr(:new.owner,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- LOCATION (default';
wwv_flow_imp.g_varchar2_table(52) := ')'||wwv_flow.LF||
'    if nvl(:old.location, ''0'') != nvl(:new.location,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_histor';
wwv_flow_imp.g_varchar2_table(53) := 'y (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(54) := '  (''ACTIVITIES'', null, :new.id, ''LOCATION'', substr(:old.location,0,4000), substr(:new.location,0,400';
wwv_flow_imp.g_varchar2_table(55) := '0) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end au_eba_cust_activities;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger au_eba_cust_activities en';
wwv_flow_imp.g_varchar2_table(56) := 'able;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Activity Files'||wwv_flow.LF||
'create table eba_cust_activity_files ('||wwv_flow.LF||
'    id                 number not ';
wwv_flow_imp.g_varchar2_table(57) := 'null,'||wwv_flow.LF||
'    row_version_number number not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    activity_id        number not null,'||wwv_flow.LF||
'    fil';
wwv_flow_imp.g_varchar2_table(58) := 'e_name          varchar2(512),'||wwv_flow.LF||
'    file_mimetype      varchar2(512),'||wwv_flow.LF||
'    file_charset       varchar2';
wwv_flow_imp.g_varchar2_table(59) := '(512),'||wwv_flow.LF||
'    file_last_update   date,'||wwv_flow.LF||
'    file_blob          blob,'||wwv_flow.LF||
'    file_comments      varchar2(400';
wwv_flow_imp.g_varchar2_table(60) := '0),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created            timestamp (6) with time zone not null,'||wwv_flow.LF||
'    created_by         varc';
wwv_flow_imp.g_varchar2_table(61) := 'har2(255) not null,'||wwv_flow.LF||
'    updated            timestamp (6) with time zone,'||wwv_flow.LF||
'    updated_by         varc';
wwv_flow_imp.g_varchar2_table(62) := 'har2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    constraint eba_cust_activity_files_pk primary key ( id ) using index,'||wwv_flow.LF||
'    cons';
wwv_flow_imp.g_varchar2_table(63) := 'traint eba_cust_activity_files_fk foreign key ( activity_id )'||wwv_flow.LF||
'        references eba_cust_activities';
wwv_flow_imp.g_varchar2_table(64) := ' ( id ) on delete cascade'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create index eba_cust_activity_files_idx1 on eba_cust_activity_files( ';
wwv_flow_imp.g_varchar2_table(65) := 'activity_id )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger biu_eba_cust_activity_files'||wwv_flow.LF||
'    before insert or update on';
wwv_flow_imp.g_varchar2_table(66) := ' eba_cust_activity_files'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is null the';
wwv_flow_imp.g_varchar2_table(67) := 'n'||wwv_flow.LF||
'            :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(68) := '       :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(69) := '  :new.row_version_number := 1;'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        :new.row_version_number := nvl(:new.row_version_num';
wwv_flow_imp.g_varchar2_table(70) := 'ber,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USE';
wwv_flow_imp.g_varchar2_table(71) := 'R''),user);'||wwv_flow.LF||
'end biu_eba_cust_activity_files;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger biu_eba_cust_activity_files enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-';
wwv_flow_imp.g_varchar2_table(72) := '- Activity References'||wwv_flow.LF||
'create table eba_cust_activity_ref ('||wwv_flow.LF||
'    id            number not null,'||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(73) := ''||wwv_flow.LF||
'    activity_id   number not null,'||wwv_flow.LF||
'    customer_id   number not null,'||wwv_flow.LF||
'    contact_id    number,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(74) := ' activity_date date,'||wwv_flow.LF||
'    owner         varchar2(255),'||wwv_flow.LF||
'    location      varchar2(4000),'||wwv_flow.LF||
'    notes   ';
wwv_flow_imp.g_varchar2_table(75) := '      varchar2(4000),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    row_version_number number default 1 not null,'||wwv_flow.LF||
'    created          ';
wwv_flow_imp.g_varchar2_table(76) := '  timestamp (6) with time zone not null,'||wwv_flow.LF||
'    created_by         varchar2(255) not null,'||wwv_flow.LF||
'    updated ';
wwv_flow_imp.g_varchar2_table(77) := '           timestamp (6) with time zone,'||wwv_flow.LF||
'    updated_by         varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    constraint';
wwv_flow_imp.g_varchar2_table(78) := ' eba_cust_activity_ref_pk primary key ( id ) using index,'||wwv_flow.LF||
'    constraint eba_cust_activity_ref_fk1 f';
wwv_flow_imp.g_varchar2_table(79) := 'oreign key ( activity_id )'||wwv_flow.LF||
'        references eba_cust_activities ( id ) on delete cascade,'||wwv_flow.LF||
'    cons';
wwv_flow_imp.g_varchar2_table(80) := 'traint eba_cust_activity_ref_fk2 foreign key ( customer_id )'||wwv_flow.LF||
'        references eba_cust_customers (';
wwv_flow_imp.g_varchar2_table(81) := ' id ) on delete cascade,'||wwv_flow.LF||
'    constraint eba_cust_activity_ref_fk3 foreign key ( contact_id )'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(82) := ' references eba_cust_contacts ( id ) on delete set null'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create index eba_cust_activity_ref_idx1 ';
wwv_flow_imp.g_varchar2_table(83) := 'on eba_cust_activity_ref ( activity_id )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create index eba_cust_activity_ref_idx2 on eba_cust_activ';
wwv_flow_imp.g_varchar2_table(84) := 'ity_ref ( customer_id )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create index eba_cust_activity_ref_idx3 on eba_cust_activity_ref ( contact';
wwv_flow_imp.g_varchar2_table(85) := '_id )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger biu_eba_cust_activity_ref'||wwv_flow.LF||
'    before insert or update on eba_cust_';
wwv_flow_imp.g_varchar2_table(86) := 'activity_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(87) := '  :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.';
wwv_flow_imp.g_varchar2_table(88) := 'created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'        :new.row_v';
wwv_flow_imp.g_varchar2_table(89) := 'ersion_number := 1; '||wwv_flow.LF||
'    else '||wwv_flow.LF||
'        :new.row_version_number := nvl(:new.row_version_number,0) + 1';
wwv_flow_imp.g_varchar2_table(90) := '; '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''),user)';
wwv_flow_imp.g_varchar2_table(91) := ';'||wwv_flow.LF||
'end biu_eba_cust_activity_ref;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger biu_eba_cust_activity_ref enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or repl';
wwv_flow_imp.g_varchar2_table(92) := 'ace trigger au_eba_cust_activity_ref'||wwv_flow.LF||
'    after update on eba_cust_activity_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'decl';
wwv_flow_imp.g_varchar2_table(93) := 'are'||wwv_flow.LF||
'    pragma autonomous_transaction;'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'    nv varchar2(4000) := null;';
wwv_flow_imp.g_varchar2_table(94) := ''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- ACTIVITY_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:old.activity_id,-999) != nvl(:new.activity_id,-9';
wwv_flow_imp.g_varchar2_table(95) := '99) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select name val from eba_cust_activities';
wwv_flow_imp.g_varchar2_table(96) := ' t where t.id = :old.activity_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in';
wwv_flow_imp.g_varchar2_table(97) := ' (select name val from eba_cust_activities t where t.id = :new.activity_id) loop'||wwv_flow.LF||
'            nv := c';
wwv_flow_imp.g_varchar2_table(98) := '1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, compone';
wwv_flow_imp.g_varchar2_table(99) := 'nt_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            (''ACTIVITY_REF'', null, :new.id, ''ACTIVI';
wwv_flow_imp.g_varchar2_table(100) := 'TY_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CUSTOMER_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:old.customer_id,-999) != n';
wwv_flow_imp.g_varchar2_table(101) := 'vl(:new.customer_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select row_key val';
wwv_flow_imp.g_varchar2_table(102) := ' from eba_cust_customers t where t.id = :old.customer_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        end';
wwv_flow_imp.g_varchar2_table(103) := ' loop;'||wwv_flow.LF||
'        for c1 in (select row_key val from eba_cust_customers t where t.id = :new.customer_id';
wwv_flow_imp.g_varchar2_table(104) := ') loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name,';
wwv_flow_imp.g_varchar2_table(105) := ' component_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            (''ACTIVITY_RE';
wwv_flow_imp.g_varchar2_table(106) := 'F'', null, :new.id, ''CUSTOMER_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CONTACT_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:o';
wwv_flow_imp.g_varchar2_table(107) := 'ld.contact_id,-999) != nvl(:new.contact_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1';
wwv_flow_imp.g_varchar2_table(108) := ' in (select name val from eba_cust_contacts t where t.id = :old.contact_id) loop'||wwv_flow.LF||
'            ov := c';
wwv_flow_imp.g_varchar2_table(109) := '1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in (select name val from eba_cust_contacts t where t.id = :n';
wwv_flow_imp.g_varchar2_table(110) := 'ew.contact_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history';
wwv_flow_imp.g_varchar2_table(111) := ' (table_name, component_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(112) := '(''ACTIVITY_REF'', null, :new.id, ''CONTACT_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- ACTIVITY_DATE (date/timest';
wwv_flow_imp.g_varchar2_table(113) := 'amp)'||wwv_flow.LF||
'    if (:old.activity_date is null and :new.activity_date is not null) or '||wwv_flow.LF||
'        (:old.activi';
wwv_flow_imp.g_varchar2_table(114) := 'ty_date is not null and :new.activity_date is null) or '||wwv_flow.LF||
'        (:old.activity_date != :new.activity';
wwv_flow_imp.g_varchar2_table(115) := '_date) then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, colum';
wwv_flow_imp.g_varchar2_table(116) := 'n_name, old_value, new_value) values '||wwv_flow.LF||
'            (''ACTIVITY_REF'', null, :new.id, ''ACTIVITY_DATE'', t';
wwv_flow_imp.g_varchar2_table(117) := 'o_char(:old.activity_date, ''DD-MON-YYYY''), to_char(:new.activity_date, ''DD-MON-YYYY'') );'||wwv_flow.LF||
'    end if;';
wwv_flow_imp.g_varchar2_table(118) := ''||wwv_flow.LF||
'    -- OWNER (default)'||wwv_flow.LF||
'    if nvl(:old.owner, ''0'') != nvl(:new.owner,''0'') then '||wwv_flow.LF||
'        insert into';
wwv_flow_imp.g_varchar2_table(119) := ' eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) va';
wwv_flow_imp.g_varchar2_table(120) := 'lues '||wwv_flow.LF||
'            (''ACTIVITY_REF'', null, :new.id, ''OWNER'', substr(:old.owner,0,4000), substr(:new.ow';
wwv_flow_imp.g_varchar2_table(121) := 'ner,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- LOCATION (default)'||wwv_flow.LF||
'    if nvl(:old.location, ''0'') != nvl(:new.loc';
wwv_flow_imp.g_varchar2_table(122) := 'ation,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, c';
wwv_flow_imp.g_varchar2_table(123) := 'olumn_name, old_value, new_value) values '||wwv_flow.LF||
'            (''ACTIVITY_REF'', null, :new.id, ''LOCATION'', su';
wwv_flow_imp.g_varchar2_table(124) := 'bstr(:old.location,0,4000), substr(:new.location,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- NOTES (default)'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(125) := 'if nvl(:old.notes, ''0'') != nvl(:new.notes,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_nam';
wwv_flow_imp.g_varchar2_table(126) := 'e, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''ACTIVITY';
wwv_flow_imp.g_varchar2_table(127) := '_REF'', null, :new.id, ''NOTES'', substr(:old.notes,0,4000), substr(:new.notes,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(128) := '    commit;'||wwv_flow.LF||
'end au_eba_cust_activity_ref;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger au_eba_cust_activity_ref enable'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(18149818232565524002)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Activities'
,p_sequence=>70
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_CUST_ACTIVITIES'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
