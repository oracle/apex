prompt --application/deployment/install/upgrade_email_log_ddl
begin
--   Manifest
--     INSTALL: UPGRADE-Email Log DDL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_email_log ('||wwv_flow.LF||
'    id                 number,'||wwv_flow.LF||
'    row_version_number number,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(2) := 'email_first_to     varchar2(255),'||wwv_flow.LF||
'    email_to           varchar2(4000),'||wwv_flow.LF||
'    email_from         varc';
wwv_flow_imp.g_varchar2_table(3) := 'har2(255),'||wwv_flow.LF||
'    body_size          number,'||wwv_flow.LF||
'    customer_id        number,'||wwv_flow.LF||
'    email_type         varc';
wwv_flow_imp.g_varchar2_table(4) := 'har2(30),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created            timestamp (6) with time zone,'||wwv_flow.LF||
'    created_by         varchar';
wwv_flow_imp.g_varchar2_table(5) := '2(255),'||wwv_flow.LF||
'    updated            timestamp (6) with time zone,'||wwv_flow.LF||
'    updated_by         varchar2(255),'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(6) := '   primary key (id) using index enable'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_cust_email_log_n1 on eba_cust_email_log';
wwv_flow_imp.g_varchar2_table(7) := ' (email_first_to)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_cust_email_log_n2 on eba_cust_email_log (email_from)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create';
wwv_flow_imp.g_varchar2_table(8) := ' or replace trigger  biu_eba_cust_email_log'||wwv_flow.LF||
'    before insert or update on eba_cust_email_log'||wwv_flow.LF||
'    fo';
wwv_flow_imp.g_varchar2_table(9) := 'r each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(10) := 'XXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(11) := '       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    elsif';
wwv_flow_imp.g_varchar2_table(12) := ' updating then'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(13) := '   :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'    :new.ema';
wwv_flow_imp.g_varchar2_table(14) := 'il_first_to := lower(:new.email_first_to);'||wwv_flow.LF||
'    :new.email_from := lower(:new.email_from);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'al';
wwv_flow_imp.g_varchar2_table(15) := 'ter trigger  biu_eba_cust_email_log enable'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(18748954810599987409)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Email Log DDL'
,p_sequence=>390
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_CUST_EMAIL_LOG'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
