prompt --application/deployment/install/upgrade_history_triggers
begin
--   Manifest
--     INSTALL: UPGRADE-History Triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger au_eba_cust_product_uses'||wwv_flow.LF||
'    after update on eba_cust_product_uses'||wwv_flow.LF||
'    for';
wwv_flow_imp.g_varchar2_table(2) := ' each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'    nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- PRODUCT';
wwv_flow_imp.g_varchar2_table(3) := '_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:old.product_id,-999) != nvl(:new.product_id,-999) then'||wwv_flow.LF||
'        ov := n';
wwv_flow_imp.g_varchar2_table(4) := 'ull; nv := null;'||wwv_flow.LF||
'        for c1 in (select product_name val from eba_cust_products t where t.id = :o';
wwv_flow_imp.g_varchar2_table(5) := 'ld.product_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in (select product_na';
wwv_flow_imp.g_varchar2_table(6) := 'me val from eba_cust_products t where t.id = :new.product_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(7) := ' end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_';
wwv_flow_imp.g_varchar2_table(8) := 'name, old_value, new_value) values'||wwv_flow.LF||
'            (''PRODUCT_USES'', null, :new.customer_id, ''PRODUCT_ID''';
wwv_flow_imp.g_varchar2_table(9) := ', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end au_eba_cust_product_uses;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger au_eba_cust_product_uses enable';
wwv_flow_imp.g_varchar2_table(10) := ''||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger au_eba_cust_customers'||wwv_flow.LF||
'    after update on eba_cust_customers'||wwv_flow.LF||
'    for e';
wwv_flow_imp.g_varchar2_table(11) := 'ach row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'    nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- CUSTOMER_';
wwv_flow_imp.g_varchar2_table(12) := 'NAME (default)'||wwv_flow.LF||
'    if nvl(:old.customer_name, ''0'') != nvl(:new.customer_name,''0'') then '||wwv_flow.LF||
'        inse';
wwv_flow_imp.g_varchar2_table(13) := 'rt into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_va';
wwv_flow_imp.g_varchar2_table(14) := 'lue) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''CUSTOMER_NAME'', substr(:old.customer_';
wwv_flow_imp.g_varchar2_table(15) := 'name,0,4000), substr(:new.customer_name,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CUSTOMER_NAME_UPPER (default)';
wwv_flow_imp.g_varchar2_table(16) := ''||wwv_flow.LF||
'    if nvl(:old.customer_name_upper, ''0'') != nvl(:new.customer_name_upper,''0'') then '||wwv_flow.LF||
'        insert';
wwv_flow_imp.g_varchar2_table(17) := ' into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_valu';
wwv_flow_imp.g_varchar2_table(18) := 'e) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''CUSTOMER_NAME_UPPER'', substr(:old.custo';
wwv_flow_imp.g_varchar2_table(19) := 'mer_name_upper,0,4000), substr(:new.customer_name_upper,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- INDUSTRY_ID (';
wwv_flow_imp.g_varchar2_table(20) := 'foreign key)'||wwv_flow.LF||
'    if nvl(:old.industry_id,-999) != nvl(:new.industry_id,-999) then'||wwv_flow.LF||
'        ov := null';
wwv_flow_imp.g_varchar2_table(21) := '; nv := null;'||wwv_flow.LF||
'        for c1 in (select industry_name val from eba_cust_industries t where t.id = :o';
wwv_flow_imp.g_varchar2_table(22) := 'ld.industry_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in (select industry_';
wwv_flow_imp.g_varchar2_table(23) := 'name val from eba_cust_industries t where t.id = :new.industry_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(24) := '      end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, co';
wwv_flow_imp.g_varchar2_table(25) := 'lumn_name, old_value, new_value) values'||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''INDUSTRY_I';
wwv_flow_imp.g_varchar2_table(26) := 'D'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CATEGORY_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:old.category_id,-999) != nvl(:';
wwv_flow_imp.g_varchar2_table(27) := 'new.category_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select category val fr';
wwv_flow_imp.g_varchar2_table(28) := 'om eba_cust_categories t where t.id = :old.category_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        end l';
wwv_flow_imp.g_varchar2_table(29) := 'oop;'||wwv_flow.LF||
'        for c1 in (select category val from eba_cust_categories t where t.id = :new.category_id';
wwv_flow_imp.g_varchar2_table(30) := ') loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name,';
wwv_flow_imp.g_varchar2_table(31) := ' component_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            (''CUSTOMERS'',';
wwv_flow_imp.g_varchar2_table(32) := ' :new.row_key, :new.id, ''CATEGORY_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- STATUS_ID (foreign key)'||wwv_flow.LF||
'    if nv';
wwv_flow_imp.g_varchar2_table(33) := 'l(:old.status_id,-999) != nvl(:new.status_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for ';
wwv_flow_imp.g_varchar2_table(34) := 'c1 in (select status val from eba_cust_status t where t.id = :old.status_id) loop'||wwv_flow.LF||
'            ov := ';
wwv_flow_imp.g_varchar2_table(35) := 'c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in (select status val from eba_cust_status t where t.id = :';
wwv_flow_imp.g_varchar2_table(36) := 'new.status_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history';
wwv_flow_imp.g_varchar2_table(37) := ' (table_name, component_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(38) := '(''CUSTOMERS'', :new.row_key, :new.id, ''STATUS_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- GEOGRAPHY_ID (foreign ';
wwv_flow_imp.g_varchar2_table(39) := 'key)'||wwv_flow.LF||
'    if nvl(:old.geography_id,-999) != nvl(:new.geography_id,-999) then'||wwv_flow.LF||
'        ov := null; nv :';
wwv_flow_imp.g_varchar2_table(40) := '= null;'||wwv_flow.LF||
'        for c1 in (select geography_name val from eba_cust_geographies t where t.id = :old.g';
wwv_flow_imp.g_varchar2_table(41) := 'eography_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in (select geography_na';
wwv_flow_imp.g_varchar2_table(42) := 'me val from eba_cust_geographies t where t.id = :new.geography_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(43) := '      end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, co';
wwv_flow_imp.g_varchar2_table(44) := 'lumn_name, old_value, new_value) values'||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''GEOGRAPHY_';
wwv_flow_imp.g_varchar2_table(45) := 'ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- REFERENCABLE (default)'||wwv_flow.LF||
'    if nvl(:old.referencable, ''0'') != nvl(:n';
wwv_flow_imp.g_varchar2_table(46) := 'ew.referencable,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, compo';
wwv_flow_imp.g_varchar2_table(47) := 'nent_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id,';
wwv_flow_imp.g_varchar2_table(48) := ' ''REFERENCABLE'', substr(:old.referencable,0,4000), substr(:new.referencable,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(49) := '    -- MARQUEE_CUSTOMER_YN (default)'||wwv_flow.LF||
'    if nvl(:old.marquee_customer_yn, ''0'') != nvl(:new.marquee_c';
wwv_flow_imp.g_varchar2_table(50) := 'ustomer_yn,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_';
wwv_flow_imp.g_varchar2_table(51) := 'id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''MAR';
wwv_flow_imp.g_varchar2_table(52) := 'QUEE_CUSTOMER'', substr(:old.marquee_customer_yn,0,4000), substr(:new.marquee_customer_yn,0,4000) ); ';
wwv_flow_imp.g_varchar2_table(53) := ''||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- TAGS (default)'||wwv_flow.LF||
'    if nvl(:old.tags, ''0'') != nvl(:new.tags,''0'') then '||wwv_flow.LF||
'        in';
wwv_flow_imp.g_varchar2_table(54) := 'sert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_';
wwv_flow_imp.g_varchar2_table(55) := 'value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''TAGS'', substr(:old.tags,0,4000), su';
wwv_flow_imp.g_varchar2_table(56) := 'bstr(:new.tags,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CUSTOMER_PRODUCTS (default)'||wwv_flow.LF||
'    if nvl(:old.customer_p';
wwv_flow_imp.g_varchar2_table(57) := 'roducts, ''0'') != nvl(:new.customer_products,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_n';
wwv_flow_imp.g_varchar2_table(58) := 'ame, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOM';
wwv_flow_imp.g_varchar2_table(59) := 'ERS'', :new.row_key, :new.id, ''CUSTOMER_PRODUCTS'', substr(:old.customer_products,0,4000), substr(:new';
wwv_flow_imp.g_varchar2_table(60) := '.customer_products,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- NUMBER_OF_USERS (default)'||wwv_flow.LF||
'    if nvl(:old.number_o';
wwv_flow_imp.g_varchar2_table(61) := 'f_users, ''0'') != nvl(:new.number_of_users,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_nam';
wwv_flow_imp.g_varchar2_table(62) := 'e, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMER';
wwv_flow_imp.g_varchar2_table(63) := 'S'', :new.row_key, :new.id, ''NUMBER_OF_USERS'', substr(:old.number_of_users,0,4000), substr(:new.numbe';
wwv_flow_imp.g_varchar2_table(64) := 'r_of_users,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- SUMMARY (default)'||wwv_flow.LF||
'    if nvl(:old.summary, ''0'') != nvl(:ne';
wwv_flow_imp.g_varchar2_table(65) := 'w.summary,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_i';
wwv_flow_imp.g_varchar2_table(66) := 'd, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''SUMM';
wwv_flow_imp.g_varchar2_table(67) := 'ARY'', substr(:old.summary,0,4000), substr(:new.summary,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CUSTOMER_PROFI';
wwv_flow_imp.g_varchar2_table(68) := 'LE (default)'||wwv_flow.LF||
'    if nvl(:old.customer_profile, ''0'') != nvl(:new.customer_profile,''0'') then '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(69) := 'insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, ne';
wwv_flow_imp.g_varchar2_table(70) := 'w_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''CUSTOMER_PROFILE'', substr(:old.cu';
wwv_flow_imp.g_varchar2_table(71) := 'stomer_profile,0,4000), substr(:new.customer_profile,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- APPLICATIONS (de';
wwv_flow_imp.g_varchar2_table(72) := 'fault)'||wwv_flow.LF||
'    if nvl(:old.applications, ''0'') != nvl(:new.applications,''0'') then '||wwv_flow.LF||
'        insert into eb';
wwv_flow_imp.g_varchar2_table(73) := 'a_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) value';
wwv_flow_imp.g_varchar2_table(74) := 's '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''APPLICATIONS'', substr(:old.applications,0,4000)';
wwv_flow_imp.g_varchar2_table(75) := ', substr(:new.applications,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- WEB_SITE (default)'||wwv_flow.LF||
'    if nvl(:old.web_sit';
wwv_flow_imp.g_varchar2_table(76) := 'e, ''0'') != nvl(:new.web_site,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_';
wwv_flow_imp.g_varchar2_table(77) := 'rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_';
wwv_flow_imp.g_varchar2_table(78) := 'key, :new.id, ''WEB_SITE'', substr(:old.web_site,0,4000), substr(:new.web_site,0,4000) ); '||wwv_flow.LF||
'    end if;';
wwv_flow_imp.g_varchar2_table(79) := ''||wwv_flow.LF||
'    -- LINKEDIN (default)'||wwv_flow.LF||
'    if nvl(:old.linkedin, ''0'') != nvl(:new.linkedin,''0'') then '||wwv_flow.LF||
'        in';
wwv_flow_imp.g_varchar2_table(80) := 'sert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_';
wwv_flow_imp.g_varchar2_table(81) := 'value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''LINKEDIN'', substr(:old.linkedin,0,4';
wwv_flow_imp.g_varchar2_table(82) := '000), substr(:new.linkedin,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- FACEBOOK (default)'||wwv_flow.LF||
'    if nvl(:old.faceboo';
wwv_flow_imp.g_varchar2_table(83) := 'k, ''0'') != nvl(:new.facebook,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_';
wwv_flow_imp.g_varchar2_table(84) := 'rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_';
wwv_flow_imp.g_varchar2_table(85) := 'key, :new.id, ''FACEBOOK'', substr(:old.facebook,0,4000), substr(:new.facebook,0,4000) ); '||wwv_flow.LF||
'    end if;';
wwv_flow_imp.g_varchar2_table(86) := ''||wwv_flow.LF||
'    -- TWITTER (default)'||wwv_flow.LF||
'    if nvl(:old.twitter, ''0'') != nvl(:new.twitter,''0'') then '||wwv_flow.LF||
'        inser';
wwv_flow_imp.g_varchar2_table(87) := 't into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_val';
wwv_flow_imp.g_varchar2_table(88) := 'ue) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''TWITTER'', substr(:old.twitter,0,4000),';
wwv_flow_imp.g_varchar2_table(89) := ' substr(:new.twitter,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- STOCK_SYMBOL (default)'||wwv_flow.LF||
'    if nvl(:old.stock_sym';
wwv_flow_imp.g_varchar2_table(90) := 'bol, ''0'') != nvl(:new.stock_symbol,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, comp';
wwv_flow_imp.g_varchar2_table(91) := 'onent_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :ne';
wwv_flow_imp.g_varchar2_table(92) := 'w.row_key, :new.id, ''STOCK_SYMBOL'', substr(:old.stock_symbol,0,4000), substr(:new.stock_symbol,0,400';
wwv_flow_imp.g_varchar2_table(93) := '0) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- SIC (default)'||wwv_flow.LF||
'    if nvl(:old.sic, ''0'') != nvl(:new.sic,''0'') then '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(94) := ' insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, n';
wwv_flow_imp.g_varchar2_table(95) := 'ew_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''SIC'', substr(:old.sic,0,4000), s';
wwv_flow_imp.g_varchar2_table(96) := 'ubstr(:new.sic,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- DUNS (default)'||wwv_flow.LF||
'    if nvl(:old.duns, ''0'') != nvl(:new.';
wwv_flow_imp.g_varchar2_table(97) := 'duns,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, co';
wwv_flow_imp.g_varchar2_table(98) := 'lumn_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''DUNS'', su';
wwv_flow_imp.g_varchar2_table(99) := 'bstr(:old.duns,0,4000), substr(:new.duns,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end au_eba_cust_customers;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter ';
wwv_flow_imp.g_varchar2_table(100) := 'trigger au_eba_cust_customers enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger au_eba_cust_contacts'||wwv_flow.LF||
'    after upd';
wwv_flow_imp.g_varchar2_table(101) := 'ate on eba_cust_contacts'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'    nv varchar2(400';
wwv_flow_imp.g_varchar2_table(102) := '0) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- CUSTOMER_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:old.customer_id,-999) != nvl(:new.cus';
wwv_flow_imp.g_varchar2_table(103) := 'tomer_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select customer_name val from';
wwv_flow_imp.g_varchar2_table(104) := ' eba_cust_customers t where t.id = :old.customer_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        end loop';
wwv_flow_imp.g_varchar2_table(105) := ';'||wwv_flow.LF||
'        for c1 in (select customer_name val from eba_cust_customers t where t.id = :new.customer_i';
wwv_flow_imp.g_varchar2_table(106) := 'd) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name';
wwv_flow_imp.g_varchar2_table(107) := ', component_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            (''CONTACTS'',';
wwv_flow_imp.g_varchar2_table(108) := ' null, :new.id, ''CUSTOMER_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- NAME (default)'||wwv_flow.LF||
'    if nvl(:old.name, ''0'')';
wwv_flow_imp.g_varchar2_table(109) := ' != nvl(:new.name,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, com';
wwv_flow_imp.g_varchar2_table(110) := 'ponent_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''NAME''';
wwv_flow_imp.g_varchar2_table(111) := ', substr(:old.name,0,4000), substr(:new.name,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- TITLE (default)'||wwv_flow.LF||
'    if n';
wwv_flow_imp.g_varchar2_table(112) := 'vl(:old.title, ''0'') != nvl(:new.title,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, c';
wwv_flow_imp.g_varchar2_table(113) := 'omponent_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', n';
wwv_flow_imp.g_varchar2_table(114) := 'ull, :new.id, ''TITLE'', substr(:old.title,0,4000), substr(:new.title,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- C';
wwv_flow_imp.g_varchar2_table(115) := 'OMPANY (default)'||wwv_flow.LF||
'    if nvl(:old.company, ''0'') != nvl(:new.company,''0'') then '||wwv_flow.LF||
'        insert into eb';
wwv_flow_imp.g_varchar2_table(116) := 'a_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) value';
wwv_flow_imp.g_varchar2_table(117) := 's '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''COMPANY'', substr(:old.company,0,4000), substr(:new.compa';
wwv_flow_imp.g_varchar2_table(118) := 'ny,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- ADDRESS_LINE1 (default)'||wwv_flow.LF||
'    if nvl(:old.address_line1, ''0'') != nvl';
wwv_flow_imp.g_varchar2_table(119) := '(:new.address_line1,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, c';
wwv_flow_imp.g_varchar2_table(120) := 'omponent_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''ADD';
wwv_flow_imp.g_varchar2_table(121) := 'RESS_LINE1'', substr(:old.address_line1,0,4000), substr(:new.address_line1,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(122) := '  -- ADDRESS_LINE2 (default)'||wwv_flow.LF||
'    if nvl(:old.address_line2, ''0'') != nvl(:new.address_line2,''0'') then';
wwv_flow_imp.g_varchar2_table(123) := ' '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old';
wwv_flow_imp.g_varchar2_table(124) := '_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''ADDRESS_LINE2'', substr(:old.addr';
wwv_flow_imp.g_varchar2_table(125) := 'ess_line2,0,4000), substr(:new.address_line2,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CITY (default)'||wwv_flow.LF||
'    if nv';
wwv_flow_imp.g_varchar2_table(126) := 'l(:old.city, ''0'') != nvl(:new.city,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, comp';
wwv_flow_imp.g_varchar2_table(127) := 'onent_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null';
wwv_flow_imp.g_varchar2_table(128) := ', :new.id, ''CITY'', substr(:old.city,0,4000), substr(:new.city,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- STATE (';
wwv_flow_imp.g_varchar2_table(129) := 'default)'||wwv_flow.LF||
'    if nvl(:old.state, ''0'') != nvl(:new.state,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_histo';
wwv_flow_imp.g_varchar2_table(130) := 'ry (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(131) := '   (''CONTACTS'', null, :new.id, ''STATE'', substr(:old.state,0,4000), substr(:new.state,0,4000) ); '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(132) := ' end if;'||wwv_flow.LF||
'    -- COUNTRY (default)'||wwv_flow.LF||
'    if nvl(:old.country, ''0'') != nvl(:new.country,''0'') then '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(133) := '   insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value,';
wwv_flow_imp.g_varchar2_table(134) := ' new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''COUNTRY'', substr(:old.country,0,4000), ';
wwv_flow_imp.g_varchar2_table(135) := 'substr(:new.country,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- ZIP (default)'||wwv_flow.LF||
'    if nvl(:old.zip, ''0'') != nvl(:n';
wwv_flow_imp.g_varchar2_table(136) := 'ew.zip,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, ';
wwv_flow_imp.g_varchar2_table(137) := 'column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''ZIP'', substr(:ol';
wwv_flow_imp.g_varchar2_table(138) := 'd.zip,0,4000), substr(:new.zip,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- EMAIL (default)'||wwv_flow.LF||
'    if nvl(:old.email,';
wwv_flow_imp.g_varchar2_table(139) := ' ''0'') != nvl(:new.email,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowke';
wwv_flow_imp.g_varchar2_table(140) := 'y, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ';
wwv_flow_imp.g_varchar2_table(141) := '''EMAIL'', substr(:old.email,0,4000), substr(:new.email,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- PHONE (default)';
wwv_flow_imp.g_varchar2_table(142) := ''||wwv_flow.LF||
'    if nvl(:old.phone, ''0'') != nvl(:new.phone,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (tabl';
wwv_flow_imp.g_varchar2_table(143) := 'e_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CON';
wwv_flow_imp.g_varchar2_table(144) := 'TACTS'', null, :new.id, ''PHONE'', substr(:old.phone,0,4000), substr(:new.phone,0,4000) ); '||wwv_flow.LF||
'    end if;';
wwv_flow_imp.g_varchar2_table(145) := ''||wwv_flow.LF||
'    -- CELL_PHONE (default)'||wwv_flow.LF||
'    if nvl(:old.cell_phone, ''0'') != nvl(:new.cell_phone,''0'') then '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(146) := '    insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value';
wwv_flow_imp.g_varchar2_table(147) := ', new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''CELL_PHONE'', substr(:old.cell_phone,0,';
wwv_flow_imp.g_varchar2_table(148) := '4000), substr(:new.cell_phone,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- FAX (default)'||wwv_flow.LF||
'    if nvl(:old.fax, ''0'')';
wwv_flow_imp.g_varchar2_table(149) := ' != nvl(:new.fax,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, comp';
wwv_flow_imp.g_varchar2_table(150) := 'onent_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''FAX'', ';
wwv_flow_imp.g_varchar2_table(151) := 'substr(:old.fax,0,4000), substr(:new.fax,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CONTACT_TYPE_ID (foreign key';
wwv_flow_imp.g_varchar2_table(152) := ')'||wwv_flow.LF||
'    if nvl(:old.contact_type_id,-999) != nvl(:new.contact_type_id,-999) then'||wwv_flow.LF||
'        ov := null; n';
wwv_flow_imp.g_varchar2_table(153) := 'v := null;'||wwv_flow.LF||
'        for c1 in (select contact_type val from eba_cust_contact_types t where t.id = :ol';
wwv_flow_imp.g_varchar2_table(154) := 'd.contact_type_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in (select contac';
wwv_flow_imp.g_varchar2_table(155) := 't_type val from eba_cust_contact_types t where t.id = :new.contact_type_id) loop'||wwv_flow.LF||
'            nv := c';
wwv_flow_imp.g_varchar2_table(156) := '1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, compone';
wwv_flow_imp.g_varchar2_table(157) := 'nt_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''CONTACT_TY';
wwv_flow_imp.g_varchar2_table(158) := 'PE_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- NOTES (default)'||wwv_flow.LF||
'    if nvl(:old.notes, ''0'') != nvl(:new.notes,''0';
wwv_flow_imp.g_varchar2_table(159) := ''') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_na';
wwv_flow_imp.g_varchar2_table(160) := 'me, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''NOTES'', substr(:old.notes';
wwv_flow_imp.g_varchar2_table(161) := ',0,4000), substr(:new.notes,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- TAGS (default)'||wwv_flow.LF||
'    if nvl(:old.tags, ''0'')';
wwv_flow_imp.g_varchar2_table(162) := ' != nvl(:new.tags,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, com';
wwv_flow_imp.g_varchar2_table(163) := 'ponent_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''TAGS''';
wwv_flow_imp.g_varchar2_table(164) := ', substr(:old.tags,0,4000), substr(:new.tags,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end au_eba_cust_contacts;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alt';
wwv_flow_imp.g_varchar2_table(165) := 'er trigger au_eba_cust_contacts enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
'?'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(14923828887379629251)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'History Triggers'
,p_sequence=>120
,p_script_type=>'UPGRADE'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
