prompt --application/deployment/install/upgrade_reference_types
begin
--   Manifest
--     INSTALL: UPGRADE-Reference Types
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_reference_types ('||wwv_flow.LF||
'    id                    number       not null,'||wwv_flow.LF||
'    row_ver';
wwv_flow_imp.g_varchar2_table(2) := 'sion_number    number,'||wwv_flow.LF||
'    reference_type        varchar2(60) not null,'||wwv_flow.LF||
'    is_active             va';
wwv_flow_imp.g_varchar2_table(3) := 'rchar2(1)  default ''Y'','||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created               timestamp with time zone not null,'||wwv_flow.LF||
'    crea';
wwv_flow_imp.g_varchar2_table(4) := 'ted_by            varchar2(255) not null,'||wwv_flow.LF||
'    updated               timestamp with time zone,'||wwv_flow.LF||
'    up';
wwv_flow_imp.g_varchar2_table(5) := 'dated_by            varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    constraint eba_cust_reference_types_pk primary key (id';
wwv_flow_imp.g_varchar2_table(6) := ')'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust_reference_types_uk on eba_cust_reference_types(reference_type)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(7) := 'alter table eba_cust_reference_types'||wwv_flow.LF||
'    add constraint eba_cust_reference_types_uk'||wwv_flow.LF||
'        unique (';
wwv_flow_imp.g_varchar2_table(8) := 'reference_type)'||wwv_flow.LF||
'        using index eba_cust_reference_types_uk'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_cust_customer_re';
wwv_flow_imp.g_varchar2_table(9) := 'ftype_ref ('||wwv_flow.LF||
'    id                 number not null,'||wwv_flow.LF||
'    customer_id        number not null,'||wwv_flow.LF||
'    refe';
wwv_flow_imp.g_varchar2_table(10) := 'rence_type_id  number not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created               timestamp with time zone not null,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(11) := '    created_by            varchar2(255) not null,'||wwv_flow.LF||
'    updated               timestamp with time zone';
wwv_flow_imp.g_varchar2_table(12) := ','||wwv_flow.LF||
'    updated_by            varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    constraint eba_cust_customer_reftype_pk primar';
wwv_flow_imp.g_varchar2_table(13) := 'y key (id),'||wwv_flow.LF||
'    constraint eba_cust_customer_reftype_fk1'||wwv_flow.LF||
'        foreign key ( customer_id ) referen';
wwv_flow_imp.g_varchar2_table(14) := 'ces eba_cust_customers(id) on delete cascade,'||wwv_flow.LF||
'    constraint eba_cust_customer_reftype_fk2'||wwv_flow.LF||
'        f';
wwv_flow_imp.g_varchar2_table(15) := 'oreign key ( reference_type_id ) references eba_cust_reference_types(id) on delete cascade'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'creat';
wwv_flow_imp.g_varchar2_table(16) := 'e unique index eba_cust_customer_reftype_uk on eba_cust_customer_reftype_ref(customer_id,reference_t';
wwv_flow_imp.g_varchar2_table(17) := 'ype_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_customer_reftype_ref'||wwv_flow.LF||
'   add constraint eba_cust_customer_reftype_uk'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(18) := '      unique (customer_id,reference_type_id)'||wwv_flow.LF||
'       using index eba_cust_customer_reftype_uk'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- T';
wwv_flow_imp.g_varchar2_table(19) := 'riggers'||wwv_flow.LF||
'create or replace trigger biu_eba_cust_reference_types'||wwv_flow.LF||
'    before insert or update on eba_cu';
wwv_flow_imp.g_varchar2_table(20) := 'st_reference_types'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(21) := '        :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(22) := ' :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'        :new';
wwv_flow_imp.g_varchar2_table(23) := '.row_version_number := 1;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.row_version_number := nvl(:new.row_ve';
wwv_flow_imp.g_varchar2_table(24) := 'rsion_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := ';
wwv_flow_imp.g_varchar2_table(25) := 'nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cust_cust_reftype_ref'||wwv_flow.LF||
'    before ';
wwv_flow_imp.g_varchar2_table(26) := 'insert or update on eba_cust_customer_reftype_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(27) := '   if :new.id is null then'||wwv_flow.LF||
'            :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(28) := 'XXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(';
wwv_flow_imp.g_varchar2_table(29) := '''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nv';
wwv_flow_imp.g_varchar2_table(30) := 'l(v(''APP_USER''),user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger au_eba_cust_customer_reftype_r'||wwv_flow.LF||
'    after in';
wwv_flow_imp.g_varchar2_table(31) := 'sert or update or delete on eba_cust_customer_reftype_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    pragma autono';
wwv_flow_imp.g_varchar2_table(32) := 'mous_transaction;'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'    nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    ov := null';
wwv_flow_imp.g_varchar2_table(33) := '; nv := null;'||wwv_flow.LF||
'    for c1 in (select reference_type val from eba_cust_reference_types t where t.id = ';
wwv_flow_imp.g_varchar2_table(34) := ':old.reference_type_id) loop'||wwv_flow.LF||
'        ov := c1.val;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    for c1 in (select reference_typ';
wwv_flow_imp.g_varchar2_table(35) := 'e val from eba_cust_reference_types t where t.id = :new.reference_type_id) loop'||wwv_flow.LF||
'        nv := c1.val';
wwv_flow_imp.g_varchar2_table(36) := ';'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    insert into eba_cust_history (table_name, component_rowkey, component_id, column';
wwv_flow_imp.g_varchar2_table(37) := '_name, old_value, new_value) values'||wwv_flow.LF||
'        (''CUSTOMERS'', null, nvl(:new.customer_id,:old.customer_i';
wwv_flow_imp.g_varchar2_table(38) := 'd), ''REFERENCE_TYPE_ID'', ov, nv);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end au_eba_cust_customer_reftype_r;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger au';
wwv_flow_imp.g_varchar2_table(39) := '_eba_cust_customer_reftype_r enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- Load in the default reference types.'||wwv_flow.LF||
'    insert ';
wwv_flow_imp.g_varchar2_table(40) := 'into eba_cust_reference_types (id, reference_type, is_active) values (1, ''Analyst Interview'', ''Y'');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(41) := '    insert into eba_cust_reference_types (id, reference_type, is_active) values (2, ''Available for C';
wwv_flow_imp.g_varchar2_table(42) := 'alls'', ''Y'');'||wwv_flow.LF||
'    insert into eba_cust_reference_types (id, reference_type, is_active) values (3, ''Lo';
wwv_flow_imp.g_varchar2_table(43) := 'go'', ''Y'');'||wwv_flow.LF||
'    insert into eba_cust_reference_types (id, reference_type, is_active) values (4, ''Succ';
wwv_flow_imp.g_varchar2_table(44) := 'ess Story'', ''Y'');'||wwv_flow.LF||
'    insert into eba_cust_reference_types (id, reference_type, is_active) values (5';
wwv_flow_imp.g_varchar2_table(45) := ', ''Quote'', ''Y'');'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(15625375353582322949)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Reference Types'
,p_sequence=>160
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_CUST_REFERENCE_TYPES'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
