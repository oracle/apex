prompt --application/deployment/install/install_history
begin
--   Manifest
--     INSTALL: INSTALL-history
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_CUST_HISTORY" '||wwv_flow.LF||
'   (   '||wwv_flow.LF||
'    "ID"                  NUMBER constraint eba_cust_histor';
wwv_flow_imp.g_varchar2_table(2) := 'y_pk primary key, '||wwv_flow.LF||
'    "ROW_VERSION_NUMBER"  NUMBER, '||wwv_flow.LF||
'    "TABLE_NAME"          varchar2(255),'||wwv_flow.LF||
'    "';
wwv_flow_imp.g_varchar2_table(3) := 'COMPONENT_ID"        NUMBER, '||wwv_flow.LF||
'    "COMPONENT_ROWKEY"    VARCHAR2(30 BYTE), '||wwv_flow.LF||
'    "COLUMN_NAME"       ';
wwv_flow_imp.g_varchar2_table(4) := '  VARCHAR2(60 BYTE) not null, '||wwv_flow.LF||
'    "OLD_VALUE"           VARCHAR2(4000 BYTE), '||wwv_flow.LF||
'    "NEW_VALUE"      ';
wwv_flow_imp.g_varchar2_table(5) := '     VARCHAR2(4000 BYTE), '||wwv_flow.LF||
'    "CHANGE_DATE"         TIMESTAMP WITH TIME ZONE, '||wwv_flow.LF||
'    "CHANGED_BY"    ';
wwv_flow_imp.g_varchar2_table(6) := '      VARCHAR2(255 BYTE)'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_cust_history_i1 on EBA_CUST_HISTORY(component_id);';
wwv_flow_imp.g_varchar2_table(7) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER BIU_EBA_CUST_HISTORY'||wwv_flow.LF||
'   before insert or update on EBA_CUST_HISTORY'||wwv_flow.LF||
'   f';
wwv_flow_imp.g_varchar2_table(8) := 'or each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(9) := 'XXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.change_date := c';
wwv_flow_imp.g_varchar2_table(10) := 'urrent_timestamp;'||wwv_flow.LF||
'       :new.changed_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_numbe';
wwv_flow_imp.g_varchar2_table(11) := 'r := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := :new.row_version_number + 1;'||wwv_flow.LF||
'   end';
wwv_flow_imp.g_varchar2_table(12) := ' if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TRIGGER BIU_EBA_CUST_HISTORY ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16613318395353454349)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'history'
,p_sequence=>100
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
