prompt --application/deployment/install/upgrade_implementation_partners_competitors
begin
--   Manifest
--     INSTALL: UPGRADE-Implementation Partners/Competitors
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_impl_partners ('||wwv_flow.LF||
'    id                  number       not null,'||wwv_flow.LF||
'    row_version';
wwv_flow_imp.g_varchar2_table(2) := '_number  number,'||wwv_flow.LF||
'    name                varchar2(60) not null,'||wwv_flow.LF||
'    description         varchar2(400';
wwv_flow_imp.g_varchar2_table(3) := '0) ,'||wwv_flow.LF||
'    website             varchar2(512),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created             timestamp with time zone ';
wwv_flow_imp.g_varchar2_table(4) := 'not null,'||wwv_flow.LF||
'    created_by          varchar2(255) not null,'||wwv_flow.LF||
'    updated             timestamp with tim';
wwv_flow_imp.g_varchar2_table(5) := 'e zone,'||wwv_flow.LF||
'    updated_by          varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    constraint eba_cust_impl_partners_pk prima';
wwv_flow_imp.g_varchar2_table(6) := 'ry key (id)'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust_impl_partners_uk on eba_cust_impl_partners(name)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'cre';
wwv_flow_imp.g_varchar2_table(7) := 'ate or replace trigger biu_eba_cust_impl_partners'||wwv_flow.LF||
'    before insert or update on eba_cust_impl_partn';
wwv_flow_imp.g_varchar2_table(8) := 'ers'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            :new.id';
wwv_flow_imp.g_varchar2_table(9) := ' := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created :';
wwv_flow_imp.g_varchar2_table(10) := '= current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'        :new.row_version_nu';
wwv_flow_imp.g_varchar2_table(11) := 'mber := 1;'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    end i';
wwv_flow_imp.g_varchar2_table(12) := 'f;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end biu_eb';
wwv_flow_imp.g_varchar2_table(13) := 'a_cust_impl_partners;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger biu_eba_cust_impl_partners enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_cust_cu';
wwv_flow_imp.g_varchar2_table(14) := 'st_partner_ref ('||wwv_flow.LF||
'    id          number not null,'||wwv_flow.LF||
'    customer_id number not null,'||wwv_flow.LF||
'    partner_id  n';
wwv_flow_imp.g_varchar2_table(15) := 'umber not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created     timestamp with time zone not null,'||wwv_flow.LF||
'    created_by  varchar2(2';
wwv_flow_imp.g_varchar2_table(16) := '55) not null,'||wwv_flow.LF||
'    updated     timestamp with time zone,'||wwv_flow.LF||
'    updated_by  varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    co';
wwv_flow_imp.g_varchar2_table(17) := 'nstraint eba_cust_cust_part_pk  primary key (id),'||wwv_flow.LF||
'    constraint eba_cust_cust_part_fk  foreign key ';
wwv_flow_imp.g_varchar2_table(18) := '(customer_id) references eba_cust_customers(id) on delete cascade,'||wwv_flow.LF||
'    constraint eba_cust_cust_part';
wwv_flow_imp.g_varchar2_table(19) := '_fk2 foreign key (partner_id) references eba_cust_impl_partners(id) on delete cascade'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create uni';
wwv_flow_imp.g_varchar2_table(20) := 'que index eba_cust_cust_partner_ref_u1 on eba_cust_cust_partner_ref( customer_id, partner_id )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'cr';
wwv_flow_imp.g_varchar2_table(21) := 'eate or replace trigger biu_eba_cust_cust_partner_ref'||wwv_flow.LF||
'    before insert or update on eba_cust_cust_p';
wwv_flow_imp.g_varchar2_table(22) := 'artner_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(23) := ':new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.cr';
wwv_flow_imp.g_varchar2_table(24) := 'eated := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new';
wwv_flow_imp.g_varchar2_table(25) := '.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end biu_eba_cust_cust';
wwv_flow_imp.g_varchar2_table(26) := '_partner_ref;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger biu_eba_cust_cust_partner_ref enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger au_';
wwv_flow_imp.g_varchar2_table(27) := 'eba_cust_cust_partner_ref'||wwv_flow.LF||
'    after insert or update or delete on eba_cust_cust_partner_ref'||wwv_flow.LF||
'    for ';
wwv_flow_imp.g_varchar2_table(28) := 'each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    pragma autonomous_transaction;'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'    nv varchar2(4';
wwv_flow_imp.g_varchar2_table(29) := '000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    ov := null; nv := null;'||wwv_flow.LF||
'    for c1 in (select name val from eba_cust_impl_pa';
wwv_flow_imp.g_varchar2_table(30) := 'rtners t where t.id = :old.partner_id) loop'||wwv_flow.LF||
'        ov := c1.val;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    for c1 in (selec';
wwv_flow_imp.g_varchar2_table(31) := 't name val from eba_cust_impl_partners t where t.id = :new.partner_id) loop'||wwv_flow.LF||
'        nv := c1.val;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(32) := '  end loop;'||wwv_flow.LF||
'    insert into eba_cust_history (table_name, component_rowkey, component_id, column_nam';
wwv_flow_imp.g_varchar2_table(33) := 'e, old_value, new_value) values'||wwv_flow.LF||
'        (''CUSTOMERS'', null, nvl(:new.customer_id,:old.customer_id), ';
wwv_flow_imp.g_varchar2_table(34) := '''PARTNER_ID'', ov, nv);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end au_eba_cust_cust_partner_ref;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger au_eba_cust_cus';
wwv_flow_imp.g_varchar2_table(35) := 't_partner_ref enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Competitors'||wwv_flow.LF||
'create table eba_cust_competitors ('||wwv_flow.LF||
'    id                  n';
wwv_flow_imp.g_varchar2_table(36) := 'umber       not null,'||wwv_flow.LF||
'    row_version_number  number,'||wwv_flow.LF||
'    name                varchar2(60) not null,';
wwv_flow_imp.g_varchar2_table(37) := ''||wwv_flow.LF||
'    description         varchar2(4000) ,'||wwv_flow.LF||
'    website             varchar2(512),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created ';
wwv_flow_imp.g_varchar2_table(38) := '            timestamp with time zone not null,'||wwv_flow.LF||
'    created_by          varchar2(255) not null,'||wwv_flow.LF||
'    u';
wwv_flow_imp.g_varchar2_table(39) := 'pdated             timestamp with time zone,'||wwv_flow.LF||
'    updated_by          varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    const';
wwv_flow_imp.g_varchar2_table(40) := 'raint eba_cust_competitors_pk primary key (id)'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust_competitors_uk on eb';
wwv_flow_imp.g_varchar2_table(41) := 'a_cust_competitors(name)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cust_competitors'||wwv_flow.LF||
'    before insert or ';
wwv_flow_imp.g_varchar2_table(42) := 'update on eba_cust_competitors'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is nu';
wwv_flow_imp.g_varchar2_table(43) := 'll then'||wwv_flow.LF||
'            :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end';
wwv_flow_imp.g_varchar2_table(44) := ' if;'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(45) := '        :new.row_version_number := 1;'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        :new.row_version_number := nvl(:new.row_versi';
wwv_flow_imp.g_varchar2_table(46) := 'on_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''A';
wwv_flow_imp.g_varchar2_table(47) := 'PP_USER''),user);'||wwv_flow.LF||
'end biu_eba_cust_competitors;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger biu_eba_cust_competitors enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'c';
wwv_flow_imp.g_varchar2_table(48) := 'reate table eba_cust_cust_competitor_ref ('||wwv_flow.LF||
'    id            number not null,'||wwv_flow.LF||
'    customer_id   numb';
wwv_flow_imp.g_varchar2_table(49) := 'er not null,'||wwv_flow.LF||
'    competitor_id number not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created     timestamp with time zone not ';
wwv_flow_imp.g_varchar2_table(50) := 'null,'||wwv_flow.LF||
'    created_by  varchar2(255) not null,'||wwv_flow.LF||
'    updated     timestamp with time zone,'||wwv_flow.LF||
'    updated_';
wwv_flow_imp.g_varchar2_table(51) := 'by  varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    constraint eba_cust_cust_competitor_pk  primary key (id),'||wwv_flow.LF||
'    constrai';
wwv_flow_imp.g_varchar2_table(52) := 'nt eba_cust_cust_competitor_fk  foreign key (customer_id) references eba_cust_customers(id) on delet';
wwv_flow_imp.g_varchar2_table(53) := 'e cascade,'||wwv_flow.LF||
'    constraint eba_cust_cust_competitor_fk2 foreign key (competitor_id) references eba_cu';
wwv_flow_imp.g_varchar2_table(54) := 'st_competitors(id) on delete cascade'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust_cust_compe_ref_u1 on eba_cust_';
wwv_flow_imp.g_varchar2_table(55) := 'cust_competitor_ref( customer_id, competitor_id )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cust_cust_com';
wwv_flow_imp.g_varchar2_table(56) := 'p_ref'||wwv_flow.LF||
'    before insert or update on eba_cust_cust_competitor_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inse';
wwv_flow_imp.g_varchar2_table(57) := 'rting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            :new.id := to_number(sys_guid(),''XXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(58) := 'XXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.crea';
wwv_flow_imp.g_varchar2_table(59) := 'ted_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updat';
wwv_flow_imp.g_varchar2_table(60) := 'ed_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end biu_eba_cust_cust_comp_ref;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger biu_eba_cust_cust_';
wwv_flow_imp.g_varchar2_table(61) := 'comp_ref enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger au_eba_cust_cust_competitor_re'||wwv_flow.LF||
'    after insert or upd';
wwv_flow_imp.g_varchar2_table(62) := 'ate or delete on eba_cust_cust_competitor_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    pragma autonomous_transac';
wwv_flow_imp.g_varchar2_table(63) := 'tion;'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'    nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    ov := null; nv := null';
wwv_flow_imp.g_varchar2_table(64) := ';'||wwv_flow.LF||
'    for c1 in (select name val from eba_cust_competitors t where t.id = :old.competitor_id) loop'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(65) := '       ov := c1.val;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    for c1 in (select name val from eba_cust_competitors t where ';
wwv_flow_imp.g_varchar2_table(66) := 't.id = :new.competitor_id) loop'||wwv_flow.LF||
'        nv := c1.val;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    insert into eba_cust_history';
wwv_flow_imp.g_varchar2_table(67) := ' (table_name, component_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'        (''CU';
wwv_flow_imp.g_varchar2_table(68) := 'STOMERS'', null, nvl(:new.customer_id,:old.customer_id), ''COMPETITOR_ID'', ov, nv);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end au';
wwv_flow_imp.g_varchar2_table(69) := '_eba_cust_cust_competitor_re;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger au_eba_cust_cust_competitor_re enable'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(17727461063266363073)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Implementation Partners/Competitors'
,p_sequence=>60
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_CUST_IMPL_PARTNERS'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
