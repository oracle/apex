prompt --application/deployment/install/install_geographies
begin
--   Manifest
--     INSTALL: INSTALL-geographies
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_geographies ('||wwv_flow.LF||
'    id                      number not null,'||wwv_flow.LF||
'    row_version_num';
wwv_flow_imp.g_varchar2_table(2) := 'ber      number not null,'||wwv_flow.LF||
'    geography_name          varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created             ';
wwv_flow_imp.g_varchar2_table(3) := '  timestamp with time zone not null,'||wwv_flow.LF||
'    created_by            varchar2(255) not null,'||wwv_flow.LF||
'    updated  ';
wwv_flow_imp.g_varchar2_table(4) := '             timestamp with time zone,'||wwv_flow.LF||
'    updated_by            varchar2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eb';
wwv_flow_imp.g_varchar2_table(5) := 'a_cust_geographies'||wwv_flow.LF||
'   add constraint eba_cust_geographies_pk'||wwv_flow.LF||
'       primary key (id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique';
wwv_flow_imp.g_varchar2_table(6) := ' index eba_cust_geographies_uk on eba_cust_geographies(geography_name)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_geogra';
wwv_flow_imp.g_varchar2_table(7) := 'phies'||wwv_flow.LF||
'   add constraint eba_cust_geographies_uk'||wwv_flow.LF||
'       unique (geography_name)'||wwv_flow.LF||
'       using index eb';
wwv_flow_imp.g_varchar2_table(8) := 'a_cust_geographies_uk'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16674619997224408584)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'geographies'
,p_sequence=>80
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
