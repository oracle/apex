prompt --application/deployment/install/upgrade_new_product_uses_columns
begin
--   Manifest
--     INSTALL: UPGRADE-New Product Uses Columns
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'alter table eba_cust_product_uses add ('||wwv_flow.LF||
'    reference_type_ids varchar2(4000),'||wwv_flow.LF||
'    internal_contact ';
wwv_flow_imp.g_varchar2_table(2) := 'varchar2(255),'||wwv_flow.LF||
'    customer_contact_id number,'||wwv_flow.LF||
'    reference_status_id number,'||wwv_flow.LF||
'    valid_from timest';
wwv_flow_imp.g_varchar2_table(3) := 'amp with time zone,'||wwv_flow.LF||
'    valid_to timestamp with time zone,'||wwv_flow.LF||
'    comments varchar2(4000)'||wwv_flow.LF||
');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(14257442750293533397)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'New Product Uses Columns'
,p_sequence=>220
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tab_cols',
'where table_name = ''EBA_CUST_PRODUCT_USES''',
'    and column_name = ''REFERENCE_TYPE_IDS'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
