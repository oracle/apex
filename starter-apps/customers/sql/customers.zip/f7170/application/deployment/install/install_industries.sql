prompt --application/deployment/install/install_industries
begin
--   Manifest
--     INSTALL: INSTALL-industries
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_industries ('||wwv_flow.LF||
'    id                    number not null,'||wwv_flow.LF||
'    row_version_number';
wwv_flow_imp.g_varchar2_table(2) := '    number,'||wwv_flow.LF||
'    industry_name         varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created               timestamp with';
wwv_flow_imp.g_varchar2_table(3) := ' time zone not null,'||wwv_flow.LF||
'    created_by            varchar2(255) not null,'||wwv_flow.LF||
'    updated               tim';
wwv_flow_imp.g_varchar2_table(4) := 'estamp with time zone,'||wwv_flow.LF||
'    updated_by            varchar2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_industrie';
wwv_flow_imp.g_varchar2_table(5) := 's'||wwv_flow.LF||
'   add constraint eba_cust_industries_pk'||wwv_flow.LF||
'       primary key (id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust_in';
wwv_flow_imp.g_varchar2_table(6) := 'dustries_uk on eba_cust_industries(industry_name)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_industries'||wwv_flow.LF||
'   add constrain';
wwv_flow_imp.g_varchar2_table(7) := 't eba_cust_industries_uk'||wwv_flow.LF||
'       unique (industry_name)'||wwv_flow.LF||
'       using index eba_cust_industries_uk'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(8) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16674619789259406305)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'industries'
,p_sequence=>140
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
