prompt --application/deployment/install/install_product_statuses
begin
--   Manifest
--     INSTALL: INSTALL-product statuses
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_product_statuses ('||wwv_flow.LF||
'    id            number         not NULL,'||wwv_flow.LF||
'    status      ';
wwv_flow_imp.g_varchar2_table(2) := '  varchar2(255),'||wwv_flow.LF||
'    description   varchar2(512),'||wwv_flow.LF||
'    is_current_yn varchar2(1),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created ';
wwv_flow_imp.g_varchar2_table(3) := '    timestamp with time zone not null,'||wwv_flow.LF||
'    created_by  varchar2(255) not null,'||wwv_flow.LF||
'    updated     times';
wwv_flow_imp.g_varchar2_table(4) := 'tamp with time zone,'||wwv_flow.LF||
'    updated_by  varchar2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_product_statuses'||wwv_flow.LF||
'   a';
wwv_flow_imp.g_varchar2_table(5) := 'dd constraint eba_cust_product_statuses_pk'||wwv_flow.LF||
'       primary key (id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(14294309896235847005)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'product statuses'
,p_sequence=>260
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
