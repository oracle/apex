prompt --application/deployment/install/install_eba_cust_email_package_spec
begin
--   Manifest
--     INSTALL: INSTALL-eba_cust_email package spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_cust_email as'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure send_feedback_email'||wwv_flow.LF||
'    ('||wwv_flow.LF||
'        p_app_i';
wwv_flow_imp.g_varchar2_table(2) := 'd        in number,'||wwv_flow.LF||
'        p_page_id       in number,'||wwv_flow.LF||
'        p_submitter     in varchar2,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(3) := 'p_feedback_type in varchar2,'||wwv_flow.LF||
'        p_feedback      in varchar2'||wwv_flow.LF||
'    );'||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_cust_email;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show ';
wwv_flow_imp.g_varchar2_table(4) := 'errors';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(18749128641969044511)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'eba_cust_email package spec'
,p_sequence=>540
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
