prompt --application/deployment/install/upgrade_add_eba_cust_prod_uses_contact_fk
begin
--   Manifest
--     INSTALL: UPGRADE-add eba_cust_prod_uses_contact_fk
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'alter table eba_cust_product_uses'||wwv_flow.LF||
'   add constraint eba_cust_prod_uses_contact_fk'||wwv_flow.LF||
'       foreign key';
wwv_flow_imp.g_varchar2_table(2) := ' (customer_contact_id)'||wwv_flow.LF||
'       references eba_cust_contacts (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(14301014284562280331)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'add eba_cust_prod_uses_contact_fk'
,p_sequence=>250
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_constraints',
'where constraint_name = ''EBA_CUST_PROD_USES_CONTACT_FK'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
