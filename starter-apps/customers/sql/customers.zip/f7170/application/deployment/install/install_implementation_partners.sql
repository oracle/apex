prompt --application/deployment/install/install_implementation_partners
begin
--   Manifest
--     INSTALL: INSTALL-Implementation Partners
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_impl_partners ('||wwv_flow.LF||
'    id                  number       not null,'||wwv_flow.LF||
'    row_version';
wwv_flow_imp.g_varchar2_table(2) := '_number  number,'||wwv_flow.LF||
'    name                varchar2(250) not null,'||wwv_flow.LF||
'    description         varchar2(40';
wwv_flow_imp.g_varchar2_table(3) := '00) ,'||wwv_flow.LF||
'    website             varchar2(512),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created             timestamp with time zone';
wwv_flow_imp.g_varchar2_table(4) := ' not null,'||wwv_flow.LF||
'    created_by          varchar2(255) not null,'||wwv_flow.LF||
'    updated             timestamp with ti';
wwv_flow_imp.g_varchar2_table(5) := 'me zone,'||wwv_flow.LF||
'    updated_by          varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    constraint eba_cust_impl_partners_pk prim';
wwv_flow_imp.g_varchar2_table(6) := 'ary key (id)'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust_impl_partners_uk on eba_cust_impl_partners(name)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'cr';
wwv_flow_imp.g_varchar2_table(7) := 'eate or replace trigger biu_eba_cust_impl_partners'||wwv_flow.LF||
'    before insert or update on eba_cust_impl_part';
wwv_flow_imp.g_varchar2_table(8) := 'ners'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            :new.i';
wwv_flow_imp.g_varchar2_table(9) := 'd := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created ';
wwv_flow_imp.g_varchar2_table(10) := ':= current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'        :new.row_version_n';
wwv_flow_imp.g_varchar2_table(11) := 'umber := 1;'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    end ';
wwv_flow_imp.g_varchar2_table(12) := 'if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end biu_e';
wwv_flow_imp.g_varchar2_table(13) := 'ba_cust_impl_partners;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger biu_eba_cust_impl_partners enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_cust_c';
wwv_flow_imp.g_varchar2_table(14) := 'ust_partner_ref ('||wwv_flow.LF||
'    id          number not null,'||wwv_flow.LF||
'    customer_id number not null,'||wwv_flow.LF||
'    partner_id  ';
wwv_flow_imp.g_varchar2_table(15) := 'number not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created     timestamp with time zone not null,'||wwv_flow.LF||
'    created_by  varchar2(';
wwv_flow_imp.g_varchar2_table(16) := '255) not null,'||wwv_flow.LF||
'    updated     timestamp with time zone,'||wwv_flow.LF||
'    updated_by  varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    c';
wwv_flow_imp.g_varchar2_table(17) := 'onstraint eba_cust_cust_part_pk  primary key (id),'||wwv_flow.LF||
'    constraint eba_cust_cust_part_fk  foreign key';
wwv_flow_imp.g_varchar2_table(18) := ' (customer_id) references eba_cust_customers(id) on delete cascade,'||wwv_flow.LF||
'    constraint eba_cust_cust_par';
wwv_flow_imp.g_varchar2_table(19) := 't_fk2 foreign key (partner_id) references eba_cust_impl_partners(id) on delete cascade'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create un';
wwv_flow_imp.g_varchar2_table(20) := 'ique index eba_cust_cust_partner_ref_u1 on eba_cust_cust_partner_ref( customer_id, partner_id )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'c';
wwv_flow_imp.g_varchar2_table(21) := 'reate or replace trigger biu_eba_cust_cust_partner_ref'||wwv_flow.LF||
'    before insert or update on eba_cust_cust_';
wwv_flow_imp.g_varchar2_table(22) := 'partner_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(23) := ' :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.c';
wwv_flow_imp.g_varchar2_table(24) := 'reated := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :ne';
wwv_flow_imp.g_varchar2_table(25) := 'w.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end biu_eba_cust_cus';
wwv_flow_imp.g_varchar2_table(26) := 't_partner_ref;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger biu_eba_cust_cust_partner_ref enable;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(17727449674106304416)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Implementation Partners'
,p_sequence=>340
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
