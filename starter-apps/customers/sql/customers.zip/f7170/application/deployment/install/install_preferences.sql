prompt --application/deployment/install/install_preferences
begin
--   Manifest
--     INSTALL: INSTALL-preferences
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_preferences ('||wwv_flow.LF||
'    id                      number              not null'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(2) := '                                         constraint eba_cust_preferences_pk'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(3) := '                        primary key,'||wwv_flow.LF||
'    preference_name         varchar2(255)       not null'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(4) := '                                          constraint eba_cust_prefs_prefname_ck'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(5) := '                            check (upper(preference_name)=preference_name),'||wwv_flow.LF||
'    preference_value    ';
wwv_flow_imp.g_varchar2_table(6) := '    varchar2(255),'||wwv_flow.LF||
'    created_by              varchar2(255)       not null,'||wwv_flow.LF||
'    created_on         ';
wwv_flow_imp.g_varchar2_table(7) := '     timestamp with time zone,'||wwv_flow.LF||
'    updated_by              varchar2(255),'||wwv_flow.LF||
'    updated_on            ';
wwv_flow_imp.g_varchar2_table(8) := '  timestamp with time zone )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust_preferences_uk on eba_cust_preferences (';
wwv_flow_imp.g_varchar2_table(9) := 'preference_name)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16674619579908403577)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'preferences'
,p_sequence=>130
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
