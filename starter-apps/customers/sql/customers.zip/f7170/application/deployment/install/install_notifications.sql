prompt --application/deployment/install/install_notifications
begin
--   Manifest
--     INSTALL: INSTALL-notifications
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_notifications ('||wwv_flow.LF||
'    id                        number            not null'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(2) := '                                           constraint eba_cust_notif_pk'||wwv_flow.LF||
'                            ';
wwv_flow_imp.g_varchar2_table(3) := '                    primary key,'||wwv_flow.LF||
'    row_version_number        number,'||wwv_flow.LF||
'    notification_name        ';
wwv_flow_imp.g_varchar2_table(4) := ' varchar2(255)     not null,'||wwv_flow.LF||
'    notification_description  varchar2(4000)    null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    notifi';
wwv_flow_imp.g_varchar2_table(5) := 'cation_type         varchar2(30)      not null'||wwv_flow.LF||
'                                                const';
wwv_flow_imp.g_varchar2_table(6) := 'raint eba_cust_notif_tp_cc'||wwv_flow.LF||
'                                                check (notification_type ';
wwv_flow_imp.g_varchar2_table(7) := 'in (''RED'',''YELLOW'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    display_sequence          number,'||wwv_flow.LF||
'    display_from              tim';
wwv_flow_imp.g_varchar2_table(8) := 'estamp with time zone,'||wwv_flow.LF||
'    display_until             timestamp with time zone,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created_by';
wwv_flow_imp.g_varchar2_table(9) := '                varchar2(255)       not null,'||wwv_flow.LF||
'    created                   timestamp with time zone';
wwv_flow_imp.g_varchar2_table(10) := ','||wwv_flow.LF||
'    updated_by                varchar2(255)       not null,'||wwv_flow.LF||
'    updated                   timestam';
wwv_flow_imp.g_varchar2_table(11) := 'p with time zone);'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index eba_cust_notif_uk on eba_cust_notifications (notification_na';
wwv_flow_imp.g_varchar2_table(12) := 'me);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_cust_notif_biu'||wwv_flow.LF||
'before insert or update on eba_cust_notifications';
wwv_flow_imp.g_varchar2_table(13) := ''||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        select to_number(sys_guid(';
wwv_flow_imp.g_varchar2_table(14) := '),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'        into :new.id'||wwv_flow.LF||
'        from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if ins';
wwv_flow_imp.g_varchar2_table(15) := 'erting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created := current_time';
wwv_flow_imp.g_varchar2_table(16) := 'stamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp';
wwv_flow_imp.g_varchar2_table(17) := ';'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.row_version_nu';
wwv_flow_imp.g_varchar2_table(18) := 'mber := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(19) := '    :new.updated    := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.notification_type is null then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(20) := '    :new.notification_type := ''MANUAL'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger eba_cust_notif';
wwv_flow_imp.g_varchar2_table(21) := '_biu enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16302072274432803473)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'notifications'
,p_sequence=>440
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
