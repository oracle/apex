prompt --application/deployment/install/upgrade_use_case_id_into_customers_table
begin
--   Manifest
--     INSTALL: UPGRADE-use_case_id into customers table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'alter table eba_cust_customers add use_case_id number'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_customers'||wwv_flow.LF||
'   add constr';
wwv_flow_imp.g_varchar2_table(2) := 'aint eba_customers_use_case_fk'||wwv_flow.LF||
'       foreign key (use_case_id)'||wwv_flow.LF||
'       references eba_cust_use_case ';
wwv_flow_imp.g_varchar2_table(3) := '(id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create index eba_cust_customers_06 on eba_cust_customers (use_case_id)'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(17131625981136167439)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'use_case_id into customers table'
,p_sequence=>330
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tab_cols',
'where table_name = ''EBA_CUST_CUSTOMERS''',
'    and column_name = ''USE_CASE_ID'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
