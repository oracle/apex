prompt --application/deployment/install/install_customer_view_log
begin
--   Manifest
--     INSTALL: INSTALL-customer view log
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_views_log ('||wwv_flow.LF||
'   id                 number          not null,'||wwv_flow.LF||
'   row_version_num';
wwv_flow_imp.g_varchar2_table(2) := 'ber NUMBER,'||wwv_flow.LF||
'   table_primary_id   number,'||wwv_flow.LF||
'   view_type          varchar2(10),'||wwv_flow.LF||
'   view_count         ';
wwv_flow_imp.g_varchar2_table(3) := 'NUMBER default 1,'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   created               timestamp with time zone not null,'||wwv_flow.LF||
'   created_by   ';
wwv_flow_imp.g_varchar2_table(4) := '         varchar2(255) not null,'||wwv_flow.LF||
'   updated               timestamp with time zone,'||wwv_flow.LF||
'   updated_by   ';
wwv_flow_imp.g_varchar2_table(5) := '         varchar2(255)'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_views_log'||wwv_flow.LF||
'   add constraint eba_cust_views_log_pk'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(6) := '       primary key (id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger bi_eba_cust_views_log'||wwv_flow.LF||
'   before insert on eba_c';
wwv_flow_imp.g_varchar2_table(7) := 'ust_views_log'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         if :NEW.ID is null then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(8) := '        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(9) := '             from dual;'||wwv_flow.LF||
'         End if;'||wwv_flow.LF||
'         :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.C';
wwv_flow_imp.g_varchar2_table(10) := 'REATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDA';
wwv_flow_imp.g_varchar2_table(11) := 'TED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   '||wwv_flow.LF||
'      if';
wwv_flow_imp.g_varchar2_table(12) := ' updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_US';
wwv_flow_imp.g_varchar2_table(13) := 'ER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(14) := ' end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16674621984457433252)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'customer view log'
,p_sequence=>300
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
