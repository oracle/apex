prompt --application/deployment/install/install_load_acl_data
begin
--   Manifest
--     INSTALL: INSTALL-load acl data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '/* Checklist access levels */'||wwv_flow.LF||
'insert into eba_cust_access_levels (id, access_level) values (1, ''Read';
wwv_flow_imp.g_varchar2_table(2) := 'er'');'||wwv_flow.LF||
'insert into eba_cust_access_levels (id, access_level) values (2, ''Contributor'');'||wwv_flow.LF||
'insert into e';
wwv_flow_imp.g_varchar2_table(3) := 'ba_cust_access_levels (id, access_level) values (3, ''Administrator'');'||wwv_flow.LF||
''||wwv_flow.LF||
'/* Checklist preferences */'||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(4) := 'nsert into eba_cust_preferences (id, preference_name, preference_value) values (1, ''ACCESS_CONTROL_E';
wwv_flow_imp.g_varchar2_table(5) := 'NABLED'', ''N'');'||wwv_flow.LF||
'insert into eba_cust_preferences (id, preference_name, preference_value) values (2, ''';
wwv_flow_imp.g_varchar2_table(6) := 'ACCESS_CONTROL_SCOPE'', ''ACL_ONLY'');'||wwv_flow.LF||
'insert into eba_cust_preferences (id, preference_name, preferenc';
wwv_flow_imp.g_varchar2_table(7) := 'e_value) values (3, ''USERNAME_FORMAT'', ''EMAIL'');'||wwv_flow.LF||
''||wwv_flow.LF||
'/* Constraint error lookups */'||wwv_flow.LF||
'insert into eba_cus';
wwv_flow_imp.g_varchar2_table(8) := 't_error_lookup (constraint_name, message, language_code) values (''EBA_CUST_USERS_UK'', ''Username must';
wwv_flow_imp.g_varchar2_table(9) := ' be unique.'', ''en'');'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'commit;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(15940697374868687448)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'load acl data'
,p_sequence=>410
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
