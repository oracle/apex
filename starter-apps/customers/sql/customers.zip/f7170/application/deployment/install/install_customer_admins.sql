prompt --application/deployment/install/install_customer_admins
begin
--   Manifest
--     INSTALL: INSTALL-customer admins
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_administrators ('||wwv_flow.LF||
'    id                      number        not null,'||wwv_flow.LF||
'    row_v';
wwv_flow_imp.g_varchar2_table(2) := 'ersion_number      number,'||wwv_flow.LF||
'    app_user                varchar2(255) not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created   ';
wwv_flow_imp.g_varchar2_table(3) := '            timestamp with time zone not null,'||wwv_flow.LF||
'    created_by            varchar2(255) not null,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(4) := ' updated               timestamp with time zone,'||wwv_flow.LF||
'    updated_by            varchar2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alte';
wwv_flow_imp.g_varchar2_table(5) := 'r table eba_cust_administrators'||wwv_flow.LF||
'   add constraint eba_cust_administrators_pk'||wwv_flow.LF||
'       primary key (id)';
wwv_flow_imp.g_varchar2_table(6) := ''||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust_administrators_uk on eba_cust_administrators(app_user)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table';
wwv_flow_imp.g_varchar2_table(7) := ' eba_cust_administrators'||wwv_flow.LF||
'   add constraint eba_cust_administrators_uk'||wwv_flow.LF||
'       unique (app_user)'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(8) := '  using index eba_cust_administrators_uk'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16674622191729435430)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'customer admins'
,p_sequence=>310
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
