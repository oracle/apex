prompt --application/deployment/install/upgrade_update_countries_region_ids
begin
--   Manifest
--     INSTALL: UPGRADE-Update countries region_ids
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'update eba_cust_countries set region_id = 30 where country_code = ''AF'' and region_id is null;'||wwv_flow.LF||
'update';
wwv_flow_imp.g_varchar2_table(2) := ' eba_cust_countries set region_id = 30 where country_code = ''AL'' and region_id is null;'||wwv_flow.LF||
'update eba_c';
wwv_flow_imp.g_varchar2_table(3) := 'ust_countries set region_id = 30 where country_code = ''DZ'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_co';
wwv_flow_imp.g_varchar2_table(4) := 'untries set region_id = 50 where country_code = ''AS'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countrie';
wwv_flow_imp.g_varchar2_table(5) := 's set region_id = 30 where country_code = ''AD'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set ';
wwv_flow_imp.g_varchar2_table(6) := 'region_id = 30 where country_code = ''AO'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region';
wwv_flow_imp.g_varchar2_table(7) := '_id = 10 where country_code = ''AG'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = ';
wwv_flow_imp.g_varchar2_table(8) := '20 where country_code = ''AR'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 whe';
wwv_flow_imp.g_varchar2_table(9) := 're country_code = ''AM'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 10 where cou';
wwv_flow_imp.g_varchar2_table(10) := 'ntry_code = ''AW'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50 where country_c';
wwv_flow_imp.g_varchar2_table(11) := 'ode = ''AU'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ';
wwv_flow_imp.g_varchar2_table(12) := '''AT'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''AZ'' a';
wwv_flow_imp.g_varchar2_table(13) := 'nd region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 10 where country_code = ''BS'' and reg';
wwv_flow_imp.g_varchar2_table(14) := 'ion_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''BH'' and region_id';
wwv_flow_imp.g_varchar2_table(15) := ' is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50 where country_code = ''BD'' and region_id is nu';
wwv_flow_imp.g_varchar2_table(16) := 'll;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 10 where country_code = ''BB'' and region_id is null;'||wwv_flow.LF||
'up';
wwv_flow_imp.g_varchar2_table(17) := 'date eba_cust_countries set region_id = 30 where country_code = ''BY'' and region_id is null;'||wwv_flow.LF||
'update e';
wwv_flow_imp.g_varchar2_table(18) := 'ba_cust_countries set region_id = 30 where country_code = ''BE'' and region_id is null;'||wwv_flow.LF||
'update eba_cus';
wwv_flow_imp.g_varchar2_table(19) := 't_countries set region_id = 10 where country_code = ''BZ'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_coun';
wwv_flow_imp.g_varchar2_table(20) := 'tries set region_id = 30 where country_code = ''BJ'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries ';
wwv_flow_imp.g_varchar2_table(21) := 'set region_id = 10 where country_code = ''BM'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set re';
wwv_flow_imp.g_varchar2_table(22) := 'gion_id = 50 where country_code = ''BT'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_i';
wwv_flow_imp.g_varchar2_table(23) := 'd = 20 where country_code = ''BO'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30';
wwv_flow_imp.g_varchar2_table(24) := ' where country_code = ''BA'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where';
wwv_flow_imp.g_varchar2_table(25) := ' country_code = ''BW'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 20 where count';
wwv_flow_imp.g_varchar2_table(26) := 'ry_code = ''BR'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50 where country_cod';
wwv_flow_imp.g_varchar2_table(27) := 'e = ''BN'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''B';
wwv_flow_imp.g_varchar2_table(28) := 'G'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''BF'' and';
wwv_flow_imp.g_varchar2_table(29) := ' region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''BI'' and regio';
wwv_flow_imp.g_varchar2_table(30) := 'n_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50 where country_code = ''KH'' and region_id i';
wwv_flow_imp.g_varchar2_table(31) := 's null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''CM'' and region_id is null';
wwv_flow_imp.g_varchar2_table(32) := ';'||wwv_flow.LF||
'update eba_cust_countries set region_id = 10 where country_code = ''CA'' and region_id is null;'||wwv_flow.LF||
'upda';
wwv_flow_imp.g_varchar2_table(33) := 'te eba_cust_countries set region_id = 30 where country_code = ''IC'' and region_id is null;'||wwv_flow.LF||
'update eba';
wwv_flow_imp.g_varchar2_table(34) := '_cust_countries set region_id = 10 where country_code = ''CV'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_';
wwv_flow_imp.g_varchar2_table(35) := 'countries set region_id = 30 where country_code = ''KY'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countr';
wwv_flow_imp.g_varchar2_table(36) := 'ies set region_id = 30 where country_code = ''CF'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries se';
wwv_flow_imp.g_varchar2_table(37) := 't region_id = 30 where country_code = ''TD'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set regi';
wwv_flow_imp.g_varchar2_table(38) := 'on_id = 20 where country_code = ''CL'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id ';
wwv_flow_imp.g_varchar2_table(39) := '= 50 where country_code = ''CN'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 20 w';
wwv_flow_imp.g_varchar2_table(40) := 'here country_code = ''CO'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where c';
wwv_flow_imp.g_varchar2_table(41) := 'ountry_code = ''KM'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country';
wwv_flow_imp.g_varchar2_table(42) := '_code = ''CG'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 20 where country_code ';
wwv_flow_imp.g_varchar2_table(43) := '= ''CR'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''HR''';
wwv_flow_imp.g_varchar2_table(44) := ' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''CY'' and r';
wwv_flow_imp.g_varchar2_table(45) := 'egion_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''CZ'' and region_';
wwv_flow_imp.g_varchar2_table(46) := 'id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''CD'' and region_id is ';
wwv_flow_imp.g_varchar2_table(47) := 'null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''DK'' and region_id is null;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(48) := 'update eba_cust_countries set region_id = 30 where country_code = ''DJ'' and region_id is null;'||wwv_flow.LF||
'update';
wwv_flow_imp.g_varchar2_table(49) := ' eba_cust_countries set region_id = 10 where country_code = ''DM'' and region_id is null;'||wwv_flow.LF||
'update eba_c';
wwv_flow_imp.g_varchar2_table(50) := 'ust_countries set region_id = 20 where country_code = ''DO'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_co';
wwv_flow_imp.g_varchar2_table(51) := 'untries set region_id = 20 where country_code = ''EC'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countrie';
wwv_flow_imp.g_varchar2_table(52) := 's set region_id = 30 where country_code = ''EG'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set ';
wwv_flow_imp.g_varchar2_table(53) := 'region_id = 10 where country_code = ''SV'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region';
wwv_flow_imp.g_varchar2_table(54) := '_id = 30 where country_code = ''GQ'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = ';
wwv_flow_imp.g_varchar2_table(55) := '30 where country_code = ''EE'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 whe';
wwv_flow_imp.g_varchar2_table(56) := 're country_code = ''ET'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where cou';
wwv_flow_imp.g_varchar2_table(57) := 'ntry_code = ''FO'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50 where country_c';
wwv_flow_imp.g_varchar2_table(58) := 'ode = ''FJ'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ';
wwv_flow_imp.g_varchar2_table(59) := '''FI'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''FR'' a';
wwv_flow_imp.g_varchar2_table(60) := 'nd region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 20 where country_code = ''GF'' and reg';
wwv_flow_imp.g_varchar2_table(61) := 'ion_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50 where country_code = ''PF'' and region_id';
wwv_flow_imp.g_varchar2_table(62) := ' is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''GA'' and region_id is nu';
wwv_flow_imp.g_varchar2_table(63) := 'll;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''GM'' and region_id is null;'||wwv_flow.LF||
'up';
wwv_flow_imp.g_varchar2_table(64) := 'date eba_cust_countries set region_id = 30 where country_code = ''GE'' and region_id is null;'||wwv_flow.LF||
'update e';
wwv_flow_imp.g_varchar2_table(65) := 'ba_cust_countries set region_id = 30 where country_code = ''DE'' and region_id is null;'||wwv_flow.LF||
'update eba_cus';
wwv_flow_imp.g_varchar2_table(66) := 't_countries set region_id = 30 where country_code = ''GH'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_coun';
wwv_flow_imp.g_varchar2_table(67) := 'tries set region_id = 30 where country_code = ''GI'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries ';
wwv_flow_imp.g_varchar2_table(68) := 'set region_id = 30 where country_code = ''GR'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set re';
wwv_flow_imp.g_varchar2_table(69) := 'gion_id = 30 where country_code = ''GL'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_i';
wwv_flow_imp.g_varchar2_table(70) := 'd = 10 where country_code = ''GD'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 10';
wwv_flow_imp.g_varchar2_table(71) := ' where country_code = ''GP'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 10 where';
wwv_flow_imp.g_varchar2_table(72) := ' country_code = ''GT'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where count';
wwv_flow_imp.g_varchar2_table(73) := 'ry_code = ''GG'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_cod';
wwv_flow_imp.g_varchar2_table(74) := 'e = ''GN'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''G';
wwv_flow_imp.g_varchar2_table(75) := 'W'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 20 where country_code = ''GY'' and';
wwv_flow_imp.g_varchar2_table(76) := ' region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 10 where country_code = ''HT'' and regio';
wwv_flow_imp.g_varchar2_table(77) := 'n_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 10 where country_code = ''HN'' and region_id i';
wwv_flow_imp.g_varchar2_table(78) := 's null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50 where country_code = ''HK'' and region_id is null';
wwv_flow_imp.g_varchar2_table(79) := ';'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''HU'' and region_id is null;'||wwv_flow.LF||
'upda';
wwv_flow_imp.g_varchar2_table(80) := 'te eba_cust_countries set region_id = 30 where country_code = ''IS'' and region_id is null;'||wwv_flow.LF||
'update eba';
wwv_flow_imp.g_varchar2_table(81) := '_cust_countries set region_id = 50 where country_code = ''IN'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_';
wwv_flow_imp.g_varchar2_table(82) := 'countries set region_id = 50 where country_code = ''ID'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countr';
wwv_flow_imp.g_varchar2_table(83) := 'ies set region_id = 30 where country_code = ''IQ'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries se';
wwv_flow_imp.g_varchar2_table(84) := 't region_id = 30 where country_code = ''IE'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set regi';
wwv_flow_imp.g_varchar2_table(85) := 'on_id = 30 where country_code = ''IM'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id ';
wwv_flow_imp.g_varchar2_table(86) := '= 30 where country_code = ''IL'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 w';
wwv_flow_imp.g_varchar2_table(87) := 'here country_code = ''IT'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where c';
wwv_flow_imp.g_varchar2_table(88) := 'ountry_code = ''CI'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 10 where country';
wwv_flow_imp.g_varchar2_table(89) := '_code = ''JM'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 40 where country_code ';
wwv_flow_imp.g_varchar2_table(90) := '= ''JP'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''JE''';
wwv_flow_imp.g_varchar2_table(91) := ' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''JO'' and r';
wwv_flow_imp.g_varchar2_table(92) := 'egion_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''KZ'' and region_';
wwv_flow_imp.g_varchar2_table(93) := 'id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''KE'' and region_id is ';
wwv_flow_imp.g_varchar2_table(94) := 'null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50 where country_code = ''KR'' and region_id is null;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(95) := 'update eba_cust_countries set region_id = 30 where country_code = ''KW'' and region_id is null;'||wwv_flow.LF||
'update';
wwv_flow_imp.g_varchar2_table(96) := ' eba_cust_countries set region_id = 30 where country_code = ''KG'' and region_id is null;'||wwv_flow.LF||
'update eba_c';
wwv_flow_imp.g_varchar2_table(97) := 'ust_countries set region_id = 50 where country_code = ''LA'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_co';
wwv_flow_imp.g_varchar2_table(98) := 'untries set region_id = 30 where country_code = ''LV'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countrie';
wwv_flow_imp.g_varchar2_table(99) := 's set region_id = 30 where country_code = ''LB'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set ';
wwv_flow_imp.g_varchar2_table(100) := 'region_id = 30 where country_code = ''LS'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region';
wwv_flow_imp.g_varchar2_table(101) := '_id = 30 where country_code = ''LR'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = ';
wwv_flow_imp.g_varchar2_table(102) := '30 where country_code = ''LY'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 whe';
wwv_flow_imp.g_varchar2_table(103) := 're country_code = ''LI'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where cou';
wwv_flow_imp.g_varchar2_table(104) := 'ntry_code = ''LT'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_c';
wwv_flow_imp.g_varchar2_table(105) := 'ode = ''LU'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50 where country_code = ';
wwv_flow_imp.g_varchar2_table(106) := '''MO'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''MK'' a';
wwv_flow_imp.g_varchar2_table(107) := 'nd region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''MG'' and reg';
wwv_flow_imp.g_varchar2_table(108) := 'ion_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''MW'' and region_id';
wwv_flow_imp.g_varchar2_table(109) := ' is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50 where country_code = ''MY'' and region_id is nu';
wwv_flow_imp.g_varchar2_table(110) := 'll;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50 where country_code = ''MV'' and region_id is null;'||wwv_flow.LF||
'up';
wwv_flow_imp.g_varchar2_table(111) := 'date eba_cust_countries set region_id = 30 where country_code = ''ML'' and region_id is null;'||wwv_flow.LF||
'update e';
wwv_flow_imp.g_varchar2_table(112) := 'ba_cust_countries set region_id = 30 where country_code = ''MT'' and region_id is null;'||wwv_flow.LF||
'update eba_cus';
wwv_flow_imp.g_varchar2_table(113) := 't_countries set region_id = 10 where country_code = ''MQ'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_coun';
wwv_flow_imp.g_varchar2_table(114) := 'tries set region_id = 30 where country_code = ''MR'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries ';
wwv_flow_imp.g_varchar2_table(115) := 'set region_id = 30 where country_code = ''MU'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set re';
wwv_flow_imp.g_varchar2_table(116) := 'gion_id = 10 where country_code = ''MX'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_i';
wwv_flow_imp.g_varchar2_table(117) := 'd = 30 where country_code = ''MC'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50';
wwv_flow_imp.g_varchar2_table(118) := ' where country_code = ''MN'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where';
wwv_flow_imp.g_varchar2_table(119) := ' country_code = ''ME'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where count';
wwv_flow_imp.g_varchar2_table(120) := 'ry_code = ''MA'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_cod';
wwv_flow_imp.g_varchar2_table(121) := 'e = ''MZ'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50 where country_code = ''M';
wwv_flow_imp.g_varchar2_table(122) := 'M'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''NA'' and';
wwv_flow_imp.g_varchar2_table(123) := ' region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50 where country_code = ''NP'' and regio';
wwv_flow_imp.g_varchar2_table(124) := 'n_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''NL'' and region_id i';
wwv_flow_imp.g_varchar2_table(125) := 's null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 10 where country_code = ''AN'' and region_id is null';
wwv_flow_imp.g_varchar2_table(126) := ';'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50 where country_code = ''NC'' and region_id is null;'||wwv_flow.LF||
'upda';
wwv_flow_imp.g_varchar2_table(127) := 'te eba_cust_countries set region_id = 50 where country_code = ''NZ'' and region_id is null;'||wwv_flow.LF||
'update eba';
wwv_flow_imp.g_varchar2_table(128) := '_cust_countries set region_id = 10 where country_code = ''NI'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_';
wwv_flow_imp.g_varchar2_table(129) := 'countries set region_id = 30 where country_code = ''NE'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countr';
wwv_flow_imp.g_varchar2_table(130) := 'ies set region_id = 30 where country_code = ''NG'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries se';
wwv_flow_imp.g_varchar2_table(131) := 't region_id = 50 where country_code = ''KP'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set regi';
wwv_flow_imp.g_varchar2_table(132) := 'on_id = 30 where country_code = ''NO'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id ';
wwv_flow_imp.g_varchar2_table(133) := '= 30 where country_code = ''OM'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50 w';
wwv_flow_imp.g_varchar2_table(134) := 'here country_code = ''PK'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where c';
wwv_flow_imp.g_varchar2_table(135) := 'ountry_code = ''PS'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 10 where country';
wwv_flow_imp.g_varchar2_table(136) := '_code = ''PA'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50 where country_code ';
wwv_flow_imp.g_varchar2_table(137) := '= ''PG'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 20 where country_code = ''PY''';
wwv_flow_imp.g_varchar2_table(138) := ' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 20 where country_code = ''PE'' and r';
wwv_flow_imp.g_varchar2_table(139) := 'egion_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50 where country_code = ''PH'' and region_';
wwv_flow_imp.g_varchar2_table(140) := 'id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''PL'' and region_id is ';
wwv_flow_imp.g_varchar2_table(141) := 'null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''PT'' and region_id is null;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(142) := 'update eba_cust_countries set region_id = 10 where country_code = ''PR'' and region_id is null;'||wwv_flow.LF||
'update';
wwv_flow_imp.g_varchar2_table(143) := ' eba_cust_countries set region_id = 30 where country_code = ''QA'' and region_id is null;'||wwv_flow.LF||
'update eba_c';
wwv_flow_imp.g_varchar2_table(144) := 'ust_countries set region_id = 30 where country_code = ''RO'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_co';
wwv_flow_imp.g_varchar2_table(145) := 'untries set region_id = 30 where country_code = ''RU'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countrie';
wwv_flow_imp.g_varchar2_table(146) := 's set region_id = 30 where country_code = ''RW'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set ';
wwv_flow_imp.g_varchar2_table(147) := 'region_id = 30 where country_code = ''RE'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region';
wwv_flow_imp.g_varchar2_table(148) := '_id = 30 where country_code = ''ST'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = ';
wwv_flow_imp.g_varchar2_table(149) := '30 where country_code = ''SA'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 whe';
wwv_flow_imp.g_varchar2_table(150) := 're country_code = ''SN'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where cou';
wwv_flow_imp.g_varchar2_table(151) := 'ntry_code = ''RS'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_c';
wwv_flow_imp.g_varchar2_table(152) := 'ode = ''SC'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ';
wwv_flow_imp.g_varchar2_table(153) := '''SL'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50 where country_code = ''SG'' a';
wwv_flow_imp.g_varchar2_table(154) := 'nd region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''SK'' and reg';
wwv_flow_imp.g_varchar2_table(155) := 'ion_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''SI'' and region_id';
wwv_flow_imp.g_varchar2_table(156) := ' is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''SO'' and region_id is nu';
wwv_flow_imp.g_varchar2_table(157) := 'll;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''ZA'' and region_id is null;'||wwv_flow.LF||
'up';
wwv_flow_imp.g_varchar2_table(158) := 'date eba_cust_countries set region_id = 30 where country_code = ''ES'' and region_id is null;'||wwv_flow.LF||
'update e';
wwv_flow_imp.g_varchar2_table(159) := 'ba_cust_countries set region_id = 50 where country_code = ''LK'' and region_id is null;'||wwv_flow.LF||
'update eba_cus';
wwv_flow_imp.g_varchar2_table(160) := 't_countries set region_id = 20 where country_code = ''SR'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_coun';
wwv_flow_imp.g_varchar2_table(161) := 'tries set region_id = 30 where country_code = ''SZ'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries ';
wwv_flow_imp.g_varchar2_table(162) := 'set region_id = 30 where country_code = ''SE'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set re';
wwv_flow_imp.g_varchar2_table(163) := 'gion_id = 30 where country_code = ''CH'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_i';
wwv_flow_imp.g_varchar2_table(164) := 'd = 50 where country_code = ''TW'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30';
wwv_flow_imp.g_varchar2_table(165) := ' where country_code = ''TJ'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where';
wwv_flow_imp.g_varchar2_table(166) := ' country_code = ''TZ'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50 where count';
wwv_flow_imp.g_varchar2_table(167) := 'ry_code = ''TH'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 50 where country_cod';
wwv_flow_imp.g_varchar2_table(168) := 'e = ''TL'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''T';
wwv_flow_imp.g_varchar2_table(169) := 'G'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 10 where country_code = ''TT'' and';
wwv_flow_imp.g_varchar2_table(170) := ' region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''TN'' and regio';
wwv_flow_imp.g_varchar2_table(171) := 'n_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''TR'' and region_id i';
wwv_flow_imp.g_varchar2_table(172) := 's null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''UG'' and region_id is null';
wwv_flow_imp.g_varchar2_table(173) := ';'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''UA'' and region_id is null;'||wwv_flow.LF||
'upda';
wwv_flow_imp.g_varchar2_table(174) := 'te eba_cust_countries set region_id = 30 where country_code = ''AE'' and region_id is null;'||wwv_flow.LF||
'update eba';
wwv_flow_imp.g_varchar2_table(175) := '_cust_countries set region_id = 30 where country_code = ''GB'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_';
wwv_flow_imp.g_varchar2_table(176) := 'countries set region_id = 10 where country_code = ''US'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countr';
wwv_flow_imp.g_varchar2_table(177) := 'ies set region_id = 20 where country_code = ''UY'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries se';
wwv_flow_imp.g_varchar2_table(178) := 't region_id = 30 where country_code = ''UZ'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set regi';
wwv_flow_imp.g_varchar2_table(179) := 'on_id = 20 where country_code = ''VE'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id ';
wwv_flow_imp.g_varchar2_table(180) := '= 50 where country_code = ''VN'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 10 w';
wwv_flow_imp.g_varchar2_table(181) := 'here country_code = ''VG'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 10 where c';
wwv_flow_imp.g_varchar2_table(182) := 'ountry_code = ''VI'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country';
wwv_flow_imp.g_varchar2_table(183) := '_code = ''EH'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code ';
wwv_flow_imp.g_varchar2_table(184) := '= ''YE'' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''ZR''';
wwv_flow_imp.g_varchar2_table(185) := ' and region_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''ZM'' and r';
wwv_flow_imp.g_varchar2_table(186) := 'egion_id is null;'||wwv_flow.LF||
'update eba_cust_countries set region_id = 30 where country_code = ''ZW'' and region_';
wwv_flow_imp.g_varchar2_table(187) := 'id is null;'||wwv_flow.LF||
'commit;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(839516688765034828)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Update countries region_ids'
,p_sequence=>510
,p_script_type=>'UPGRADE'
,p_condition_type=>'EXISTS'
,p_condition=>'select null from eba_cust_countries where region_id is null'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
