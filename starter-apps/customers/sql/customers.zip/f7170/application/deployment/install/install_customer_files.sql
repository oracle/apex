prompt --application/deployment/install/install_customer_files
begin
--   Manifest
--     INSTALL: INSTALL-customer files
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_files ('||wwv_flow.LF||
'    id                      number         not null,'||wwv_flow.LF||
'    row_version_n';
wwv_flow_imp.g_varchar2_table(2) := 'umber      number         not null,'||wwv_flow.LF||
'    customer_id             number         not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(3) := 'file_name               varchar2(512),'||wwv_flow.LF||
'    file_mimetype           varchar2(512),'||wwv_flow.LF||
'    file_charset  ';
wwv_flow_imp.g_varchar2_table(4) := '          varchar2(512),'||wwv_flow.LF||
'    file_lastupd            date,'||wwv_flow.LF||
'    file_blob               blob,'||wwv_flow.LF||
'    fil';
wwv_flow_imp.g_varchar2_table(5) := 'e_comments           varchar2(4000),'||wwv_flow.LF||
'    tags                    varchar2(4000),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created ';
wwv_flow_imp.g_varchar2_table(6) := '              timestamp with time zone not null,'||wwv_flow.LF||
'    created_by            varchar2(255) not null,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(7) := '   updated               timestamp with time zone,'||wwv_flow.LF||
'    updated_by            varchar2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'al';
wwv_flow_imp.g_varchar2_table(8) := 'ter table eba_cust_files'||wwv_flow.LF||
'   add constraint eba_cust_files_pk'||wwv_flow.LF||
'       primary key (id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table e';
wwv_flow_imp.g_varchar2_table(9) := 'ba_cust_files'||wwv_flow.LF||
'   add constraint eba_cust_files_fk'||wwv_flow.LF||
'       foreign key (customer_id)'||wwv_flow.LF||
'       references';
wwv_flow_imp.g_varchar2_table(10) := ' eba_cust_customers (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_cust_files_01 on eba_cust_files (cust';
wwv_flow_imp.g_varchar2_table(11) := 'omer_id);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16674621601988428926)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'customer files'
,p_sequence=>280
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
