prompt --application/deployment/install/install_customer_after_delete_trigger
begin
--   Manifest
--     INSTALL: INSTALL-customer after delete trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger ad_eba_cust_customers'||wwv_flow.LF||
'    after delete on eba_cust_customers'||wwv_flow.LF||
'    for each ';
wwv_flow_imp.g_varchar2_table(2) := 'row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into eba_cust_history (table_name, component_rowkey, component_id, column_name,';
wwv_flow_imp.g_varchar2_table(3) := ' old_value, new_value)'||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (''CUSTOMERS'', :old.row_key, :old.id, ''CUSTOMER_REMOVED'', subs';
wwv_flow_imp.g_varchar2_table(4) := 'tr(:old.customer_name,0,4000), null ); '||wwv_flow.LF||
'end ad_eba_cust_customers;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger ad_eba_cust_custo';
wwv_flow_imp.g_varchar2_table(5) := 'mers enable'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(4028496655643651063)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'customer after delete trigger'
,p_sequence=>580
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
