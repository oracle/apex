prompt --application/deployment/install/install_contacts
begin
--   Manifest
--     INSTALL: INSTALL-contacts
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_contacts ('||wwv_flow.LF||
'   id                      number         not null,'||wwv_flow.LF||
'   row_version_';
wwv_flow_imp.g_varchar2_table(2) := 'number      number,'||wwv_flow.LF||
'   customer_id             number         not NULL,'||wwv_flow.LF||
'   name                    v';
wwv_flow_imp.g_varchar2_table(3) := 'archar2(255)  not null,'||wwv_flow.LF||
'   title                   varchar2(100),'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   company                 v';
wwv_flow_imp.g_varchar2_table(4) := 'archar2(100),'||wwv_flow.LF||
'   address_line1           varchar2(255),'||wwv_flow.LF||
'   address_line2           varchar2(255),'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(5) := ' city                    varchar2(100),'||wwv_flow.LF||
'   state                   varchar2(100),'||wwv_flow.LF||
'   country        ';
wwv_flow_imp.g_varchar2_table(6) := '         varchar2(100),'||wwv_flow.LF||
'   zip                     varchar2(30),'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   email                   va';
wwv_flow_imp.g_varchar2_table(7) := 'rchar2(250),'||wwv_flow.LF||
'   phone                   varchar2(100),'||wwv_flow.LF||
'   cell_phone              varchar2(100),'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(8) := 'fax                     varchar2(100),'||wwv_flow.LF||
'   contact_type_id         number,'||wwv_flow.LF||
'   notes                  ';
wwv_flow_imp.g_varchar2_table(9) := ' varchar2(4000),'||wwv_flow.LF||
'   facebook                varchar2(4000),'||wwv_flow.LF||
'   linkedin                varchar2(4000';
wwv_flow_imp.g_varchar2_table(10) := '),'||wwv_flow.LF||
'   twitter                 varchar2(4000),'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   tags                    varchar2(4000),'||wwv_flow.LF||
'   --';
wwv_flow_imp.g_varchar2_table(11) := ''||wwv_flow.LF||
'   created                 timestamp with time zone not null,'||wwv_flow.LF||
'   created_by              varchar2(2';
wwv_flow_imp.g_varchar2_table(12) := '55) not null,'||wwv_flow.LF||
'   updated                 timestamp with time zone,'||wwv_flow.LF||
'   updated_by              varcha';
wwv_flow_imp.g_varchar2_table(13) := 'r2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_contacts'||wwv_flow.LF||
'   add constraint eba_cust_contacts_pk'||wwv_flow.LF||
'       primary k';
wwv_flow_imp.g_varchar2_table(14) := 'ey (id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_contacts'||wwv_flow.LF||
'   add constraint eba_cust_contact_customers_fk'||wwv_flow.LF||
'       forei';
wwv_flow_imp.g_varchar2_table(15) := 'gn key (customer_id)'||wwv_flow.LF||
'       references eba_cust_customers (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_c';
wwv_flow_imp.g_varchar2_table(16) := 'ust_contacts'||wwv_flow.LF||
'   add constraint eba_cust_contact_type_fk'||wwv_flow.LF||
'       foreign key (contact_type_id)'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(17) := 'references eba_cust_contact_types (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create index eba_cust_contacts_01 on eba_';
wwv_flow_imp.g_varchar2_table(18) := 'cust_contacts (customer_id);'||wwv_flow.LF||
'create index eba_cust_contacts_02 on eba_cust_contacts (contact_type_id';
wwv_flow_imp.g_varchar2_table(19) := ');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16674621395408426941)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'contacts'
,p_sequence=>240
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
