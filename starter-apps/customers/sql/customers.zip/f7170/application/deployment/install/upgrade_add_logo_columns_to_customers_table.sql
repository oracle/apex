prompt --application/deployment/install/upgrade_add_logo_columns_to_customers_table
begin
--   Manifest
--     INSTALL: UPGRADE-add logo columns to customers table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'alter table eba_cust_customers add ('||wwv_flow.LF||
'    logo_blob     blob,'||wwv_flow.LF||
'    logo_name     varchar2(512),'||wwv_flow.LF||
'    lo';
wwv_flow_imp.g_varchar2_table(2) := 'go_mimetype varchar2(512),'||wwv_flow.LF||
'    logo_charset  varchar2(512),'||wwv_flow.LF||
'    logo_lastupd  date'||wwv_flow.LF||
');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(14480370400517643427)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'add logo columns to customers table'
,p_sequence=>270
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tab_cols',
'where table_name = ''EBA_CUST_CUSTOMERS''',
'    and column_name = ''LOGO_BLOB'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
