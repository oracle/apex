prompt --application/deployment/install/upgrade_region_id_in_countries
begin
--   Manifest
--     INSTALL: UPGRADE-region_id in countries
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'alter table eba_cust_countries add region_id number'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_countries'||wwv_flow.LF||
'   add constrai';
wwv_flow_imp.g_varchar2_table(2) := 'nt eba_countries_region_fk'||wwv_flow.LF||
'       foreign key (region_id)'||wwv_flow.LF||
'       references eba_cust_geographies (id';
wwv_flow_imp.g_varchar2_table(3) := ') on delete cascade'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(17181972879526745380)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'region_id in countries'
,p_sequence=>350
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tab_cols',
'where table_name = ''EBA_CUST_COUNTRIES''',
'    and column_name = ''REGION_ID'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
