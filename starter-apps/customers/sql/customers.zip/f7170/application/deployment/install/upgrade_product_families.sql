prompt --application/deployment/install/upgrade_product_families
begin
--   Manifest
--     INSTALL: UPGRADE-Product Families
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_product_families ('||wwv_flow.LF||
'    id                  number       not null,'||wwv_flow.LF||
'    row_vers';
wwv_flow_imp.g_varchar2_table(2) := 'ion_number  number,'||wwv_flow.LF||
'    name                varchar2(60) not null,'||wwv_flow.LF||
'    description         varchar2(';
wwv_flow_imp.g_varchar2_table(3) := '4000),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created             timestamp with time zone not null,'||wwv_flow.LF||
'    created_by          var';
wwv_flow_imp.g_varchar2_table(4) := 'char2(255) not null,'||wwv_flow.LF||
'    updated             timestamp with time zone,'||wwv_flow.LF||
'    updated_by          varch';
wwv_flow_imp.g_varchar2_table(5) := 'ar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    constraint eba_cust_prod_families_pk primary key (id)'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index e';
wwv_flow_imp.g_varchar2_table(6) := 'ba_cust_prod_families_uk on eba_cust_product_families(name)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cus';
wwv_flow_imp.g_varchar2_table(7) := 't_product_families'||wwv_flow.LF||
'    before insert or update on eba_cust_product_families'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(8) := '   if inserting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            :new.id := to_number(sys_guid(),''XX';
wwv_flow_imp.g_varchar2_table(9) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(10) := ' :new.created_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(11) := ':new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := curre';
wwv_flow_imp.g_varchar2_table(12) := 'nt_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end biu_eba_cust_product_families;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'a';
wwv_flow_imp.g_varchar2_table(13) := 'lter trigger biu_eba_cust_product_families enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_cust_products'||wwv_flow.LF||
'add ('||wwv_flow.LF||
'    produc';
wwv_flow_imp.g_varchar2_table(14) := 't_family_id number,'||wwv_flow.LF||
'    constraint eba_cust_prod_fam_fk foreign key (product_family_id) references e';
wwv_flow_imp.g_varchar2_table(15) := 'ba_cust_product_families(id) on delete cascade'||wwv_flow.LF||
');'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(17770023136137420167)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Product Families'
,p_sequence=>100
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_CUST_PRODUCT_FAMILIES'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
