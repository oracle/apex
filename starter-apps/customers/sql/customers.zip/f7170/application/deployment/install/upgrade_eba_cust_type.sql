prompt --application/deployment/install/upgrade_eba_cust_type
begin
--   Manifest
--     INSTALL: UPGRADE-eba_cust_type
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_type ('||wwv_flow.LF||
'   id                      number       not null,'||wwv_flow.LF||
'   row_version_number';
wwv_flow_imp.g_varchar2_table(2) := '      number,'||wwv_flow.LF||
'   type                  varchar2(60) not null,'||wwv_flow.LF||
'   description             varchar2(40';
wwv_flow_imp.g_varchar2_table(3) := '00) ,'||wwv_flow.LF||
'   is_active               varchar2(1)  default ''Y'','||wwv_flow.LF||
''||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   created               timestamp';
wwv_flow_imp.g_varchar2_table(4) := ' with time zone not null,'||wwv_flow.LF||
'   created_by            varchar2(255) not null,'||wwv_flow.LF||
'   updated               ';
wwv_flow_imp.g_varchar2_table(5) := 'timestamp with time zone,'||wwv_flow.LF||
'   updated_by            varchar2(255)'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_type'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(6) := 'add constraint eba_cust_type_pk'||wwv_flow.LF||
'       primary key (id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust_type_uk on eb';
wwv_flow_imp.g_varchar2_table(7) := 'a_cust_type(type)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_type'||wwv_flow.LF||
'   add constraint eba_cust_type_uk'||wwv_flow.LF||
'       unique (type';
wwv_flow_imp.g_varchar2_table(8) := ')'||wwv_flow.LF||
'       using index eba_cust_type_uk'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cust_type'||wwv_flow.LF||
'   before inse';
wwv_flow_imp.g_varchar2_table(9) := 'rt or update on eba_cust_type'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         if :NEW.ID i';
wwv_flow_imp.g_varchar2_table(10) := 's null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(11) := 'into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(12) := '     :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(13) := '  :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(14) := '      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v';
wwv_flow_imp.g_varchar2_table(15) := '(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'      en';
wwv_flow_imp.g_varchar2_table(16) := 'd if;'||wwv_flow.LF||
'   end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_cust_type (id, type, Description ) values (1,''Productio';
wwv_flow_imp.g_varchar2_table(17) := 'n / Closed'', ''Production / Closed'');'||wwv_flow.LF||
'insert into eba_cust_type (id, type, Description ) values (2,''E';
wwv_flow_imp.g_varchar2_table(18) := 'valuation / Testing'', ''Evaluation / Testing'');'||wwv_flow.LF||
'insert into eba_cust_type (id, type, Description ) va';
wwv_flow_imp.g_varchar2_table(19) := 'lues (3,''Proof of Concept (PoC)'', ''Proof of Concept (PoC)'');'||wwv_flow.LF||
'insert into eba_cust_type (id, type, De';
wwv_flow_imp.g_varchar2_table(20) := 'scription ) values (4,''Planning / Prospecting'', ''Planning / Prospecting'');'||wwv_flow.LF||
'commit;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(17015555049343746182)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'eba_cust_type'
,p_sequence=>300
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_CUST_TYPE'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
