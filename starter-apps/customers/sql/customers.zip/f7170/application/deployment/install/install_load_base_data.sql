prompt --application/deployment/install/install_load_base_data
begin
--   Manifest
--     INSTALL: INSTALL-Load base data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '       insert into eba_cust_categories (id, Category, Description ) values (1, ''Consumer'', ''General ';
wwv_flow_imp.g_varchar2_table(2) := 'Consumer'') ;'||wwv_flow.LF||
'       insert into eba_cust_categories (id, Category, Description ) values (2, ''Corpora';
wwv_flow_imp.g_varchar2_table(3) := 'te'', ''Small, Medium and Big Companies'') ;'||wwv_flow.LF||
'       insert into eba_cust_categories (id, Category, Desc';
wwv_flow_imp.g_varchar2_table(4) := 'ription ) values (3, ''Nonprofit'', ''Nonprofit Organizations'') ;'||wwv_flow.LF||
'       '||wwv_flow.LF||
'       insert into eba_cust_i';
wwv_flow_imp.g_varchar2_table(5) := 'ndustries (id, industry_name) values (1, ''Aerospace & Defense'');'||wwv_flow.LF||
'       insert into eba_cust_industr';
wwv_flow_imp.g_varchar2_table(6) := 'ies (id, industry_name) values (2, ''Automotive'');'||wwv_flow.LF||
'       insert into eba_cust_industries (id, indust';
wwv_flow_imp.g_varchar2_table(7) := 'ry_name) values (3, ''Chemicals'');'||wwv_flow.LF||
'       insert into eba_cust_industries (id, industry_name) values ';
wwv_flow_imp.g_varchar2_table(8) := '(4, ''Communications'');'||wwv_flow.LF||
'       insert into eba_cust_industries (id, industry_name) values (5, ''Consum';
wwv_flow_imp.g_varchar2_table(9) := 'er Goods'');'||wwv_flow.LF||
'       insert into eba_cust_industries (id, industry_name) values (6, ''Education & Resea';
wwv_flow_imp.g_varchar2_table(10) := 'rch'');'||wwv_flow.LF||
'       insert into eba_cust_industries (id, industry_name) values (7, ''Engineering & Construc';
wwv_flow_imp.g_varchar2_table(11) := 'tion'');'||wwv_flow.LF||
'       insert into eba_cust_industries (id, industry_name) values (8, ''Financial Services'');';
wwv_flow_imp.g_varchar2_table(12) := ''||wwv_flow.LF||
'       insert into eba_cust_industries (id, industry_name) values (9, ''Insurance'');'||wwv_flow.LF||
'       insert i';
wwv_flow_imp.g_varchar2_table(13) := 'nto eba_cust_industries (id, industry_name) values (10, ''Healthcare'');'||wwv_flow.LF||
'       insert into eba_cust_i';
wwv_flow_imp.g_varchar2_table(14) := 'ndustries (id, industry_name) values (11, ''High Technology'');'||wwv_flow.LF||
'       insert into eba_cust_industries';
wwv_flow_imp.g_varchar2_table(15) := ' (id, industry_name) values (12, ''Industrial Manufacturing'');'||wwv_flow.LF||
'       insert into eba_cust_industries';
wwv_flow_imp.g_varchar2_table(16) := ' (id, industry_name) values (13, ''Life Sciences'');'||wwv_flow.LF||
'       insert into eba_cust_industries (id, indus';
wwv_flow_imp.g_varchar2_table(17) := 'try_name) values (14, ''Media & Entertainment'');'||wwv_flow.LF||
'       insert into eba_cust_industries (id, industry';
wwv_flow_imp.g_varchar2_table(18) := '_name) values (15, ''Natural Resources'');'||wwv_flow.LF||
'       insert into eba_cust_industries (id, industry_name) ';
wwv_flow_imp.g_varchar2_table(19) := 'values (16, ''Oil & Gas'');'||wwv_flow.LF||
'       insert into eba_cust_industries (id, industry_name) values (17, ''Pr';
wwv_flow_imp.g_varchar2_table(20) := 'ofessional Services'');'||wwv_flow.LF||
'       insert into eba_cust_industries (id, industry_name) values (18, ''Publi';
wwv_flow_imp.g_varchar2_table(21) := 'c Sector'');'||wwv_flow.LF||
'       insert into eba_cust_industries (id, industry_name) values (19, ''Travel & Transpo';
wwv_flow_imp.g_varchar2_table(22) := 'rtation'');'||wwv_flow.LF||
'       insert into eba_cust_industries (id, industry_name) values (20, ''Unclassified'');'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(23) := '      insert into eba_cust_industries (id, industry_name) values (21, ''Utilities'');'||wwv_flow.LF||
'       insert in';
wwv_flow_imp.g_varchar2_table(24) := 'to eba_cust_industries (id, industry_name) values (22, ''Wholesale Distribution'');'||wwv_flow.LF||
''||wwv_flow.LF||
'       insert int';
wwv_flow_imp.g_varchar2_table(25) := 'o eba_cust_geographies (id, geography_name) values (10, ''North America'');'||wwv_flow.LF||
'       insert into eba_cus';
wwv_flow_imp.g_varchar2_table(26) := 't_geographies (id, geography_name) values (20, ''South America'');'||wwv_flow.LF||
'       insert into eba_cust_geograp';
wwv_flow_imp.g_varchar2_table(27) := 'hies (id, geography_name) values (30, ''EMEA'');'||wwv_flow.LF||
'       insert into eba_cust_geographies (id, geograph';
wwv_flow_imp.g_varchar2_table(28) := 'y_name) values (40, ''Japan'');'||wwv_flow.LF||
'       insert into eba_cust_geographies (id, geography_name) values (5';
wwv_flow_imp.g_varchar2_table(29) := '0, ''Asia Pacific'');'||wwv_flow.LF||
'       '||wwv_flow.LF||
'       insert into eba_cust_status (id, Status, Description ) values (1,';
wwv_flow_imp.g_varchar2_table(30) := '''Unknown'', ''Unknown'');'||wwv_flow.LF||
'       insert into eba_cust_status (id, Status, Description ) values (2,''Cust';
wwv_flow_imp.g_varchar2_table(31) := 'omer'', ''Current Customer'');'||wwv_flow.LF||
'       insert into eba_cust_status (id, Status, Description ) values (3,';
wwv_flow_imp.g_varchar2_table(32) := '''Prospect'', ''A company we are working to secure'');'||wwv_flow.LF||
'       insert into eba_cust_status (id, Status, D';
wwv_flow_imp.g_varchar2_table(33) := 'escription ) values (4,''Partner'', ''A company we are working with'');'||wwv_flow.LF||
'       insert into eba_cust_stat';
wwv_flow_imp.g_varchar2_table(34) := 'us (id, Status, Description ) values (5,''Internal'', ''A group within our company'');'||wwv_flow.LF||
'       '||wwv_flow.LF||
'       in';
wwv_flow_imp.g_varchar2_table(35) := 'sert into eba_cust_type (id, type, Description ) values (1,''Production'', ''Production'');'||wwv_flow.LF||
'       inser';
wwv_flow_imp.g_varchar2_table(36) := 't into eba_cust_type (id, type, Description ) values (2,''Evaluation / Testing'', ''Evaluation / Testin';
wwv_flow_imp.g_varchar2_table(37) := 'g'');'||wwv_flow.LF||
'       insert into eba_cust_type (id, type, Description ) values (3,''Proof of Concept (PoC)'', ''';
wwv_flow_imp.g_varchar2_table(38) := 'Proof of Concept (PoC)'');'||wwv_flow.LF||
'       insert into eba_cust_type (id, type, Description ) values (4,''Plann';
wwv_flow_imp.g_varchar2_table(39) := 'ing / Prospecting'', ''Planning / Prospecting'');'||wwv_flow.LF||
'       insert into eba_cust_type (id, type, Descripti';
wwv_flow_imp.g_varchar2_table(40) := 'on ) values (5,''Closed'', ''Closed'');'||wwv_flow.LF||
''||wwv_flow.LF||
'       insert into eba_cust_use_case (id, use_case, description';
wwv_flow_imp.g_varchar2_table(41) := ' ) values (1,''Development'', ''Development'');'||wwv_flow.LF||
'       insert into eba_cust_use_case (id, use_case, desc';
wwv_flow_imp.g_varchar2_table(42) := 'ription ) values (2,''Test / Stage'', ''Test / Stage'');'||wwv_flow.LF||
'       insert into eba_cust_use_case (id, use_c';
wwv_flow_imp.g_varchar2_table(43) := 'ase, description ) values (3,''Production'', ''Production'');'||wwv_flow.LF||
''||wwv_flow.LF||
'       insert into eba_cust_contact_types';
wwv_flow_imp.g_varchar2_table(44) := ' (id, Contact_Type ) values (1, ''Other'') ;'||wwv_flow.LF||
'       insert into eba_cust_contact_types (id, Contact_Ty';
wwv_flow_imp.g_varchar2_table(45) := 'pe ) values (2, ''Customer'') ;'||wwv_flow.LF||
'       insert into eba_cust_contact_types (id, Contact_Type ) values (';
wwv_flow_imp.g_varchar2_table(46) := '3, ''Sales Consultant'') ;'||wwv_flow.LF||
'       insert into eba_cust_contact_types (id, Contact_Type ) values (4, ''P';
wwv_flow_imp.g_varchar2_table(47) := 'roduct Manager'') ;'||wwv_flow.LF||
''||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) valu';
wwv_flow_imp.g_varchar2_table(48) := 'es (''AF'',''Afghanistan'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_';
wwv_flow_imp.g_varchar2_table(49) := 'id) values (''AL'',''Albania'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,reg';
wwv_flow_imp.g_varchar2_table(50) := 'ion_id) values (''DZ'',''Algeria'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name';
wwv_flow_imp.g_varchar2_table(51) := ',region_id) values (''AS'',''American Samoa'',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,c';
wwv_flow_imp.g_varchar2_table(52) := 'ountry_name,region_id) values (''AD'',''Andorra'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_co';
wwv_flow_imp.g_varchar2_table(53) := 'de,country_name,region_id) values (''AO'',''Angola'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country';
wwv_flow_imp.g_varchar2_table(54) := '_code,country_name,region_id) values (''AG'',''Antigua and Barbuda'',10);'||wwv_flow.LF||
'       insert into eba_cust_co';
wwv_flow_imp.g_varchar2_table(55) := 'untries (country_code,country_name,region_id) values (''AR'',''Argentina'',20);'||wwv_flow.LF||
'       insert into eba_c';
wwv_flow_imp.g_varchar2_table(56) := 'ust_countries (country_code,country_name,region_id) values (''AM'',''Armenia'',30);'||wwv_flow.LF||
'       insert into e';
wwv_flow_imp.g_varchar2_table(57) := 'ba_cust_countries (country_code,country_name,region_id) values (''AW'',''Aruba'',10);'||wwv_flow.LF||
'       insert into';
wwv_flow_imp.g_varchar2_table(58) := ' eba_cust_countries (country_code,country_name,region_id) values (''AU'',''Australia'',50);'||wwv_flow.LF||
'       inser';
wwv_flow_imp.g_varchar2_table(59) := 't into eba_cust_countries (country_code,country_name,region_id) values (''AT'',''Austria'',30);'||wwv_flow.LF||
'       i';
wwv_flow_imp.g_varchar2_table(60) := 'nsert into eba_cust_countries (country_code,country_name,region_id) values (''AZ'',''Azerbaijan'',30);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(61) := '      insert into eba_cust_countries (country_code,country_name,region_id) values (''BS'',''Bahamas'',10';
wwv_flow_imp.g_varchar2_table(62) := ');'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''BH'',''Bahrain';
wwv_flow_imp.g_varchar2_table(63) := ''',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''BD'',''Ban';
wwv_flow_imp.g_varchar2_table(64) := 'gladesh'',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''B';
wwv_flow_imp.g_varchar2_table(65) := 'B'',''Barbados'',10);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) value';
wwv_flow_imp.g_varchar2_table(66) := 's (''BY'',''Belarus'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) v';
wwv_flow_imp.g_varchar2_table(67) := 'alues (''BE'',''Belgium'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_i';
wwv_flow_imp.g_varchar2_table(68) := 'd) values (''BZ'',''Belize'',10);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,regio';
wwv_flow_imp.g_varchar2_table(69) := 'n_id) values (''BJ'',''Benin'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,reg';
wwv_flow_imp.g_varchar2_table(70) := 'ion_id) values (''BM'',''Bermuda'',10);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name';
wwv_flow_imp.g_varchar2_table(71) := ',region_id) values (''BT'',''Bhutan'',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_n';
wwv_flow_imp.g_varchar2_table(72) := 'ame,region_id) values (''BO'',''Bolivia'',20);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,count';
wwv_flow_imp.g_varchar2_table(73) := 'ry_name,region_id) values (''BA'',''Bosnia and Herzegovina'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries ';
wwv_flow_imp.g_varchar2_table(74) := '(country_code,country_name,region_id) values (''BW'',''Botswana'',30);'||wwv_flow.LF||
'       insert into eba_cust_count';
wwv_flow_imp.g_varchar2_table(75) := 'ries (country_code,country_name,region_id) values (''BR'',''Brazil'',20);'||wwv_flow.LF||
'       insert into eba_cust_co';
wwv_flow_imp.g_varchar2_table(76) := 'untries (country_code,country_name,region_id) values (''BN'',''Brunei Darussalam'',50);'||wwv_flow.LF||
'       insert in';
wwv_flow_imp.g_varchar2_table(77) := 'to eba_cust_countries (country_code,country_name,region_id) values (''BG'',''Bulgaria'',30);'||wwv_flow.LF||
'       inse';
wwv_flow_imp.g_varchar2_table(78) := 'rt into eba_cust_countries (country_code,country_name,region_id) values (''BF'',''Burkina Faso'',30);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(79) := '     insert into eba_cust_countries (country_code,country_name,region_id) values (''BI'',''Burundi'',30)';
wwv_flow_imp.g_varchar2_table(80) := ';'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''KH'',''Cambodia';
wwv_flow_imp.g_varchar2_table(81) := ''',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''CM'',''Cam';
wwv_flow_imp.g_varchar2_table(82) := 'eroon'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''CA''';
wwv_flow_imp.g_varchar2_table(83) := ',''Canada'',10);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''';
wwv_flow_imp.g_varchar2_table(84) := 'IC'',''Canary Islands'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id';
wwv_flow_imp.g_varchar2_table(85) := ') values (''CV'',''Cape Verde'',10);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,re';
wwv_flow_imp.g_varchar2_table(86) := 'gion_id) values (''KY'',''Cayman Islands'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,coun';
wwv_flow_imp.g_varchar2_table(87) := 'try_name,region_id) values (''CF'',''Central African Republic'',30);'||wwv_flow.LF||
'       insert into eba_cust_countri';
wwv_flow_imp.g_varchar2_table(88) := 'es (country_code,country_name,region_id) values (''TD'',''Chad'',30);'||wwv_flow.LF||
'       insert into eba_cust_countr';
wwv_flow_imp.g_varchar2_table(89) := 'ies (country_code,country_name,region_id) values (''CL'',''Chile'',20);'||wwv_flow.LF||
'       insert into eba_cust_coun';
wwv_flow_imp.g_varchar2_table(90) := 'tries (country_code,country_name,region_id) values (''CN'',''China'',50);'||wwv_flow.LF||
'       insert into eba_cust_co';
wwv_flow_imp.g_varchar2_table(91) := 'untries (country_code,country_name,region_id) values (''CO'',''Colombia'',20);'||wwv_flow.LF||
'       insert into eba_cu';
wwv_flow_imp.g_varchar2_table(92) := 'st_countries (country_code,country_name,region_id) values (''KM'',''Comoros'',30);'||wwv_flow.LF||
'       insert into eb';
wwv_flow_imp.g_varchar2_table(93) := 'a_cust_countries (country_code,country_name,region_id) values (''CG'',''Congo'',30);'||wwv_flow.LF||
'       insert into ';
wwv_flow_imp.g_varchar2_table(94) := 'eba_cust_countries (country_code,country_name,region_id) values (''CR'',''Costa Rica'',20);'||wwv_flow.LF||
'       inser';
wwv_flow_imp.g_varchar2_table(95) := 't into eba_cust_countries (country_code,country_name,region_id) values (''HR'',''Croatia'',30);'||wwv_flow.LF||
'       i';
wwv_flow_imp.g_varchar2_table(96) := 'nsert into eba_cust_countries (country_code,country_name,region_id) values (''CY'',''Cyprus'',30);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(97) := '  insert into eba_cust_countries (country_code,country_name,region_id) values (''CZ'',''Czech Republic''';
wwv_flow_imp.g_varchar2_table(98) := ',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''CD'',''Demo';
wwv_flow_imp.g_varchar2_table(99) := 'cratic Republic of the Congo'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,';
wwv_flow_imp.g_varchar2_table(100) := 'region_id) values (''DK'',''Denmark'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_n';
wwv_flow_imp.g_varchar2_table(101) := 'ame,region_id) values (''DJ'',''Djibouti'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,coun';
wwv_flow_imp.g_varchar2_table(102) := 'try_name,region_id) values (''DM'',''Dominica'',10);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code';
wwv_flow_imp.g_varchar2_table(103) := ',country_name,region_id) values (''DO'',''Dominican Republic'',20);'||wwv_flow.LF||
'       insert into eba_cust_countrie';
wwv_flow_imp.g_varchar2_table(104) := 's (country_code,country_name,region_id) values (''EC'',''Ecuador'',20);'||wwv_flow.LF||
'       insert into eba_cust_coun';
wwv_flow_imp.g_varchar2_table(105) := 'tries (country_code,country_name,region_id) values (''EG'',''Egypt'',30);'||wwv_flow.LF||
'       insert into eba_cust_co';
wwv_flow_imp.g_varchar2_table(106) := 'untries (country_code,country_name,region_id) values (''SV'',''El Salvador'',10);'||wwv_flow.LF||
'       insert into eba';
wwv_flow_imp.g_varchar2_table(107) := '_cust_countries (country_code,country_name,region_id) values (''GQ'',''Equatorial Guinea'',30);'||wwv_flow.LF||
'       i';
wwv_flow_imp.g_varchar2_table(108) := 'nsert into eba_cust_countries (country_code,country_name,region_id) values (''EE'',''Estonia'',30);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(109) := '   insert into eba_cust_countries (country_code,country_name,region_id) values (''ET'',''Ethiopia'',30);';
wwv_flow_imp.g_varchar2_table(110) := ''||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''FO'',''Faroe Isl';
wwv_flow_imp.g_varchar2_table(111) := 'ands'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''FJ'',';
wwv_flow_imp.g_varchar2_table(112) := '''Fiji'',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''FI''';
wwv_flow_imp.g_varchar2_table(113) := ',''Finland'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (';
wwv_flow_imp.g_varchar2_table(114) := '''FR'',''France'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) value';
wwv_flow_imp.g_varchar2_table(115) := 's (''GF'',''French Guiana'',20);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region';
wwv_flow_imp.g_varchar2_table(116) := '_id) values (''PF'',''French Polynesia'',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,countr';
wwv_flow_imp.g_varchar2_table(117) := 'y_name,region_id) values (''GA'',''Gabon'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,coun';
wwv_flow_imp.g_varchar2_table(118) := 'try_name,region_id) values (''GM'',''Gambia'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,c';
wwv_flow_imp.g_varchar2_table(119) := 'ountry_name,region_id) values (''GE'',''Georgia'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_co';
wwv_flow_imp.g_varchar2_table(120) := 'de,country_name,region_id) values (''DE'',''Germany'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (countr';
wwv_flow_imp.g_varchar2_table(121) := 'y_code,country_name,region_id) values (''GH'',''Ghana'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (coun';
wwv_flow_imp.g_varchar2_table(122) := 'try_code,country_name,region_id) values (''GI'',''Gibraltar'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries';
wwv_flow_imp.g_varchar2_table(123) := ' (country_code,country_name,region_id) values (''GR'',''Greece'',30);'||wwv_flow.LF||
'       insert into eba_cust_countr';
wwv_flow_imp.g_varchar2_table(124) := 'ies (country_code,country_name,region_id) values (''GL'',''Greenland'',30);'||wwv_flow.LF||
'       insert into eba_cust_';
wwv_flow_imp.g_varchar2_table(125) := 'countries (country_code,country_name,region_id) values (''GD'',''Grenada'',10);'||wwv_flow.LF||
'       insert into eba_c';
wwv_flow_imp.g_varchar2_table(126) := 'ust_countries (country_code,country_name,region_id) values (''GP'',''Guadeloupe'',10);'||wwv_flow.LF||
'       insert int';
wwv_flow_imp.g_varchar2_table(127) := 'o eba_cust_countries (country_code,country_name,region_id) values (''GT'',''Guatemala'',10);'||wwv_flow.LF||
'       inse';
wwv_flow_imp.g_varchar2_table(128) := 'rt into eba_cust_countries (country_code,country_name,region_id) values (''GG'',''Guernsey'',30);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(129) := ' insert into eba_cust_countries (country_code,country_name,region_id) values (''GN'',''Guinea'',30);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(130) := '    insert into eba_cust_countries (country_code,country_name,region_id) values (''GW'',''Guinea Bissau';
wwv_flow_imp.g_varchar2_table(131) := ''',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''GY'',''Guy';
wwv_flow_imp.g_varchar2_table(132) := 'ana'',20);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''HT'',''';
wwv_flow_imp.g_varchar2_table(133) := 'Haiti'',10);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''HN''';
wwv_flow_imp.g_varchar2_table(134) := ',''Honduras'',10);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values ';
wwv_flow_imp.g_varchar2_table(135) := '(''HK'',''Hong Kong'',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) v';
wwv_flow_imp.g_varchar2_table(136) := 'alues (''HU'',''Hungary'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_i';
wwv_flow_imp.g_varchar2_table(137) := 'd) values (''IS'',''Iceland'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,regi';
wwv_flow_imp.g_varchar2_table(138) := 'on_id) values (''IN'',''India'',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,re';
wwv_flow_imp.g_varchar2_table(139) := 'gion_id) values (''ID'',''Indonesia'',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_n';
wwv_flow_imp.g_varchar2_table(140) := 'ame,region_id) values (''IQ'',''Iraq'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_';
wwv_flow_imp.g_varchar2_table(141) := 'name,region_id) values (''IE'',''Ireland'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,coun';
wwv_flow_imp.g_varchar2_table(142) := 'try_name,region_id) values (''IM'',''Isle of Man'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_c';
wwv_flow_imp.g_varchar2_table(143) := 'ode,country_name,region_id) values (''IL'',''Israel'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (countr';
wwv_flow_imp.g_varchar2_table(144) := 'y_code,country_name,region_id) values (''IT'',''Italy'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (coun';
wwv_flow_imp.g_varchar2_table(145) := 'try_code,country_name,region_id) values (''CI'',''Ivory Coast'',30);'||wwv_flow.LF||
'       insert into eba_cust_countri';
wwv_flow_imp.g_varchar2_table(146) := 'es (country_code,country_name,region_id) values (''JM'',''Jamaica'',10);'||wwv_flow.LF||
'       insert into eba_cust_cou';
wwv_flow_imp.g_varchar2_table(147) := 'ntries (country_code,country_name,region_id) values (''JP'',''Japan'',40);'||wwv_flow.LF||
'       insert into eba_cust_c';
wwv_flow_imp.g_varchar2_table(148) := 'ountries (country_code,country_name,region_id) values (''JE'',''Jersey'',30);'||wwv_flow.LF||
'       insert into eba_cus';
wwv_flow_imp.g_varchar2_table(149) := 't_countries (country_code,country_name,region_id) values (''JO'',''Jordan'',30);'||wwv_flow.LF||
'       insert into eba_';
wwv_flow_imp.g_varchar2_table(150) := 'cust_countries (country_code,country_name,region_id) values (''KZ'',''Kazakhstan'',30);'||wwv_flow.LF||
'       insert in';
wwv_flow_imp.g_varchar2_table(151) := 'to eba_cust_countries (country_code,country_name,region_id) values (''KE'',''Kenya'',30);'||wwv_flow.LF||
'       insert ';
wwv_flow_imp.g_varchar2_table(152) := 'into eba_cust_countries (country_code,country_name,region_id) values (''KR'',''Korea'',50);'||wwv_flow.LF||
'       inser';
wwv_flow_imp.g_varchar2_table(153) := 't into eba_cust_countries (country_code,country_name,region_id) values (''KW'',''Kuwait'',30);'||wwv_flow.LF||
'       in';
wwv_flow_imp.g_varchar2_table(154) := 'sert into eba_cust_countries (country_code,country_name,region_id) values (''KG'',''Kyrgyzstan'',30);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(155) := '     insert into eba_cust_countries (country_code,country_name,region_id) values (''LA'',''Laos'',50);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(156) := '      insert into eba_cust_countries (country_code,country_name,region_id) values (''LV'',''Latvia'',30)';
wwv_flow_imp.g_varchar2_table(157) := ';'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''LB'',''Lebanon''';
wwv_flow_imp.g_varchar2_table(158) := ',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''LS'',''Leso';
wwv_flow_imp.g_varchar2_table(159) := 'tho'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''LR'',''';
wwv_flow_imp.g_varchar2_table(160) := 'Liberia'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''L';
wwv_flow_imp.g_varchar2_table(161) := 'Y'',''Libyan Arab Jamahiriya'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,re';
wwv_flow_imp.g_varchar2_table(162) := 'gion_id) values (''LI'',''Liechtenstein'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,count';
wwv_flow_imp.g_varchar2_table(163) := 'ry_name,region_id) values (''LT'',''Lithuania'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code';
wwv_flow_imp.g_varchar2_table(164) := ',country_name,region_id) values (''LU'',''Luxembourg'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (count';
wwv_flow_imp.g_varchar2_table(165) := 'ry_code,country_name,region_id) values (''MO'',''Macau'',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (cou';
wwv_flow_imp.g_varchar2_table(166) := 'ntry_code,country_name,region_id) values (''MK'',''Macedonia'',30);'||wwv_flow.LF||
'       insert into eba_cust_countrie';
wwv_flow_imp.g_varchar2_table(167) := 's (country_code,country_name,region_id) values (''MG'',''Madagascar'',30);'||wwv_flow.LF||
'       insert into eba_cust_c';
wwv_flow_imp.g_varchar2_table(168) := 'ountries (country_code,country_name,region_id) values (''MW'',''Malawi'',30);'||wwv_flow.LF||
'       insert into eba_cus';
wwv_flow_imp.g_varchar2_table(169) := 't_countries (country_code,country_name,region_id) values (''MY'',''Malaysia'',50);'||wwv_flow.LF||
'       insert into eb';
wwv_flow_imp.g_varchar2_table(170) := 'a_cust_countries (country_code,country_name,region_id) values (''MV'',''Maldives'',50);'||wwv_flow.LF||
'       insert in';
wwv_flow_imp.g_varchar2_table(171) := 'to eba_cust_countries (country_code,country_name,region_id) values (''ML'',''Mali'',30);'||wwv_flow.LF||
'       insert i';
wwv_flow_imp.g_varchar2_table(172) := 'nto eba_cust_countries (country_code,country_name,region_id) values (''MT'',''Malta'',30);'||wwv_flow.LF||
'       insert';
wwv_flow_imp.g_varchar2_table(173) := ' into eba_cust_countries (country_code,country_name,region_id) values (''MQ'',''Martinique'',10);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(174) := ' insert into eba_cust_countries (country_code,country_name,region_id) values (''MR'',''Mauritania'',30);';
wwv_flow_imp.g_varchar2_table(175) := ''||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''MU'',''Mauritius';
wwv_flow_imp.g_varchar2_table(176) := ''',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''MX'',''Mex';
wwv_flow_imp.g_varchar2_table(177) := 'ico'',10);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''MC'',''';
wwv_flow_imp.g_varchar2_table(178) := 'Monaco'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''MN';
wwv_flow_imp.g_varchar2_table(179) := ''',''Mongolia'',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values';
wwv_flow_imp.g_varchar2_table(180) := ' (''ME'',''Montenegro'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id)';
wwv_flow_imp.g_varchar2_table(181) := ' values (''MA'',''Morocco'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region';
wwv_flow_imp.g_varchar2_table(182) := '_id) values (''MZ'',''Mozambique'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name';
wwv_flow_imp.g_varchar2_table(183) := ',region_id) values (''MM'',''Myanmar'',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_';
wwv_flow_imp.g_varchar2_table(184) := 'name,region_id) values (''NA'',''Namibia'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,coun';
wwv_flow_imp.g_varchar2_table(185) := 'try_name,region_id) values (''NP'',''Nepal'',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,co';
wwv_flow_imp.g_varchar2_table(186) := 'untry_name,region_id) values (''NL'',''Netherlands'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country';
wwv_flow_imp.g_varchar2_table(187) := '_code,country_name,region_id) values (''AN'',''Netherlands Antilles'',10);'||wwv_flow.LF||
'       insert into eba_cust_c';
wwv_flow_imp.g_varchar2_table(188) := 'ountries (country_code,country_name,region_id) values (''NC'',''New Caledonia'',50);'||wwv_flow.LF||
'       insert into ';
wwv_flow_imp.g_varchar2_table(189) := 'eba_cust_countries (country_code,country_name,region_id) values (''NZ'',''New Zealand'',50);'||wwv_flow.LF||
'       inse';
wwv_flow_imp.g_varchar2_table(190) := 'rt into eba_cust_countries (country_code,country_name,region_id) values (''NI'',''Nicaragua'',10);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(191) := '  insert into eba_cust_countries (country_code,country_name,region_id) values (''NE'',''Niger'',30);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(192) := '    insert into eba_cust_countries (country_code,country_name,region_id) values (''NG'',''Nigeria'',30);';
wwv_flow_imp.g_varchar2_table(193) := ''||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''KP'',''North Kor';
wwv_flow_imp.g_varchar2_table(194) := 'ea'',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''NO'',''N';
wwv_flow_imp.g_varchar2_table(195) := 'orway'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''OM''';
wwv_flow_imp.g_varchar2_table(196) := ',''Oman'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''PK';
wwv_flow_imp.g_varchar2_table(197) := ''',''Pakistan'',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values';
wwv_flow_imp.g_varchar2_table(198) := ' (''PS'',''Palestine'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) ';
wwv_flow_imp.g_varchar2_table(199) := 'values (''PA'',''Panama'',10);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_i';
wwv_flow_imp.g_varchar2_table(200) := 'd) values (''PG'',''Papua New Guinea'',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_';
wwv_flow_imp.g_varchar2_table(201) := 'name,region_id) values (''PY'',''Paraguay'',20);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,cou';
wwv_flow_imp.g_varchar2_table(202) := 'ntry_name,region_id) values (''PE'',''Peru'',20);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,co';
wwv_flow_imp.g_varchar2_table(203) := 'untry_name,region_id) values (''PH'',''Philippines'',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (country';
wwv_flow_imp.g_varchar2_table(204) := '_code,country_name,region_id) values (''PL'',''Poland'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (coun';
wwv_flow_imp.g_varchar2_table(205) := 'try_code,country_name,region_id) values (''PT'',''Portugal'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries ';
wwv_flow_imp.g_varchar2_table(206) := '(country_code,country_name,region_id) values (''PR'',''Puerto Rico'',10);'||wwv_flow.LF||
'       insert into eba_cust_co';
wwv_flow_imp.g_varchar2_table(207) := 'untries (country_code,country_name,region_id) values (''QA'',''Qatar'',30);'||wwv_flow.LF||
'       insert into eba_cust_';
wwv_flow_imp.g_varchar2_table(208) := 'countries (country_code,country_name,region_id) values (''RO'',''Romania'',30);'||wwv_flow.LF||
'       insert into eba_c';
wwv_flow_imp.g_varchar2_table(209) := 'ust_countries (country_code,country_name,region_id) values (''RU'',''Russia'',30);'||wwv_flow.LF||
'       insert into eb';
wwv_flow_imp.g_varchar2_table(210) := 'a_cust_countries (country_code,country_name,region_id) values (''RW'',''Rwanda'',30);'||wwv_flow.LF||
'       insert into';
wwv_flow_imp.g_varchar2_table(211) := ' eba_cust_countries (country_code,country_name,region_id) values (''RE'',''Reunion'',30);'||wwv_flow.LF||
'       insert ';
wwv_flow_imp.g_varchar2_table(212) := 'into eba_cust_countries (country_code,country_name,region_id) values (''ST'',''Sao Tome and Principe'',3';
wwv_flow_imp.g_varchar2_table(213) := '0);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''SA'',''Saudi ';
wwv_flow_imp.g_varchar2_table(214) := 'Arabia'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''SN';
wwv_flow_imp.g_varchar2_table(215) := ''',''Senegal'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values ';
wwv_flow_imp.g_varchar2_table(216) := '(''RS'',''Serbia'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) valu';
wwv_flow_imp.g_varchar2_table(217) := 'es (''SC'',''Seychelles'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_i';
wwv_flow_imp.g_varchar2_table(218) := 'd) values (''SL'',''Sierra Leone'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name';
wwv_flow_imp.g_varchar2_table(219) := ',region_id) values (''SG'',''Singapore'',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,countr';
wwv_flow_imp.g_varchar2_table(220) := 'y_name,region_id) values (''SK'',''Slovakia'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,c';
wwv_flow_imp.g_varchar2_table(221) := 'ountry_name,region_id) values (''SI'',''Slovenia'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_c';
wwv_flow_imp.g_varchar2_table(222) := 'ode,country_name,region_id) values (''SO'',''Somalia'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (count';
wwv_flow_imp.g_varchar2_table(223) := 'ry_code,country_name,region_id) values (''ZA'',''South Africa'',30);'||wwv_flow.LF||
'       insert into eba_cust_countri';
wwv_flow_imp.g_varchar2_table(224) := 'es (country_code,country_name,region_id) values (''ES'',''Spain'',30);'||wwv_flow.LF||
'       insert into eba_cust_count';
wwv_flow_imp.g_varchar2_table(225) := 'ries (country_code,country_name,region_id) values (''LK'',''Sri Lanka'',50);'||wwv_flow.LF||
'       insert into eba_cust';
wwv_flow_imp.g_varchar2_table(226) := '_countries (country_code,country_name,region_id) values (''SR'',''Suriname'',20);'||wwv_flow.LF||
'       insert into eba';
wwv_flow_imp.g_varchar2_table(227) := '_cust_countries (country_code,country_name,region_id) values (''SZ'',''Swaziland'',30);'||wwv_flow.LF||
'       insert in';
wwv_flow_imp.g_varchar2_table(228) := 'to eba_cust_countries (country_code,country_name,region_id) values (''SE'',''Sweden'',30);'||wwv_flow.LF||
'       insert';
wwv_flow_imp.g_varchar2_table(229) := ' into eba_cust_countries (country_code,country_name,region_id) values (''CH'',''Switzerland'',30);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(230) := '  insert into eba_cust_countries (country_code,country_name,region_id) values (''TW'',''Taiwan'',50);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(231) := '     insert into eba_cust_countries (country_code,country_name,region_id) values (''TJ'',''Tajikistan'',';
wwv_flow_imp.g_varchar2_table(232) := '30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''TZ'',''Tanza';
wwv_flow_imp.g_varchar2_table(233) := 'nia'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''TH'',''';
wwv_flow_imp.g_varchar2_table(234) := 'Thailand'',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''';
wwv_flow_imp.g_varchar2_table(235) := 'TL'',''Timor Leste'',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) v';
wwv_flow_imp.g_varchar2_table(236) := 'alues (''TG'',''Togo'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) ';
wwv_flow_imp.g_varchar2_table(237) := 'values (''TT'',''Trinidad and Tobago'',10);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_';
wwv_flow_imp.g_varchar2_table(238) := 'name,region_id) values (''TN'',''Tunisia'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,coun';
wwv_flow_imp.g_varchar2_table(239) := 'try_name,region_id) values (''TR'',''Turkey'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,c';
wwv_flow_imp.g_varchar2_table(240) := 'ountry_name,region_id) values (''UG'',''Uganda'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_cod';
wwv_flow_imp.g_varchar2_table(241) := 'e,country_name,region_id) values (''UA'',''Ukraine'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country';
wwv_flow_imp.g_varchar2_table(242) := '_code,country_name,region_id) values (''AE'',''United Arab Emirates'',30);'||wwv_flow.LF||
'       insert into eba_cust_c';
wwv_flow_imp.g_varchar2_table(243) := 'ountries (country_code,country_name,region_id) values (''GB'',''United Kingdom'',30);'||wwv_flow.LF||
'       insert into';
wwv_flow_imp.g_varchar2_table(244) := ' eba_cust_countries (id,country_code,country_name,region_id) values (1, ''US'',''United States'',10);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(245) := '     insert into eba_cust_countries (country_code,country_name,region_id) values (''UY'',''Uruguay'',20)';
wwv_flow_imp.g_varchar2_table(246) := ';'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''UZ'',''Uzbekist';
wwv_flow_imp.g_varchar2_table(247) := 'an'',30);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''VE'',''V';
wwv_flow_imp.g_varchar2_table(248) := 'enezuela'',20);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) values (''';
wwv_flow_imp.g_varchar2_table(249) := 'VN'',''Vietnam'',50);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_name,region_id) value';
wwv_flow_imp.g_varchar2_table(250) := 's (''VG'',''Virgin Islands, British'',10);'||wwv_flow.LF||
'       insert into eba_cust_countries (country_code,country_n';
wwv_flow_imp.g_varchar2_table(251) := 'ame,region_id) values (''VI'',''Virgin Islands, U.S.'',10);'||wwv_flow.LF||
'       insert into eba_cust_countries (count';
wwv_flow_imp.g_varchar2_table(252) := 'ry_code,country_name,region_id) values (''EH'',''Western Sahara'',30);'||wwv_flow.LF||
'       insert into eba_cust_count';
wwv_flow_imp.g_varchar2_table(253) := 'ries (country_code,country_name,region_id) values (''YE'',''Yemen'',30);'||wwv_flow.LF||
'       insert into eba_cust_cou';
wwv_flow_imp.g_varchar2_table(254) := 'ntries (country_code,country_name,region_id) values (''ZR'',''Zaire'',30);'||wwv_flow.LF||
'       insert into eba_cust_c';
wwv_flow_imp.g_varchar2_table(255) := 'ountries (country_code,country_name,region_id) values (''ZM'',''Zambia'',30);'||wwv_flow.LF||
'       insert into eba_cus';
wwv_flow_imp.g_varchar2_table(256) := 't_countries (country_code,country_name,region_id) values (''ZW'',''Zimbabwe'',30);'||wwv_flow.LF||
'       '||wwv_flow.LF||
'       insert';
wwv_flow_imp.g_varchar2_table(257) := ' into eba_cust_product_statuses (status, description, is_current_yn) values (''Phase 1'', ''Candidates ';
wwv_flow_imp.g_varchar2_table(258) := 'and Discovery'', ''N'');'||wwv_flow.LF||
'       insert into eba_cust_product_statuses (status, description, is_current_';
wwv_flow_imp.g_varchar2_table(259) := 'yn) values (''Phase 2'', ''Active Discussions'', ''N'');'||wwv_flow.LF||
'       insert into eba_cust_product_statuses (sta';
wwv_flow_imp.g_varchar2_table(260) := 'tus, description, is_current_yn) values (''Phase 3'', ''Engaged With Customer'', ''N'');'||wwv_flow.LF||
'       insert int';
wwv_flow_imp.g_varchar2_table(261) := 'o eba_cust_product_statuses (status, description, is_current_yn) values (''Phase 4'', ''Reference Avail';
wwv_flow_imp.g_varchar2_table(262) := 'able and Published'', ''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16626438787448498193)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Load base data'
,p_sequence=>400
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
