prompt --application/deployment/install/install_customer_types
begin
--   Manifest
--     INSTALL: INSTALL-Customer Types
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_type ('||wwv_flow.LF||
'   id                      number       not null,'||wwv_flow.LF||
'   row_version_number';
wwv_flow_imp.g_varchar2_table(2) := '      number,'||wwv_flow.LF||
'   type                    varchar2(60) not null,'||wwv_flow.LF||
'   description             varchar2(';
wwv_flow_imp.g_varchar2_table(3) := '4000) ,'||wwv_flow.LF||
'   is_active               varchar2(1)  default ''Y'','||wwv_flow.LF||
''||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   created               timesta';
wwv_flow_imp.g_varchar2_table(4) := 'mp with time zone not null,'||wwv_flow.LF||
'   created_by            varchar2(255) not null,'||wwv_flow.LF||
'   updated             ';
wwv_flow_imp.g_varchar2_table(5) := '  timestamp with time zone,'||wwv_flow.LF||
'   updated_by            varchar2(255)'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_type'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(6) := '  add constraint eba_cust_type_pk'||wwv_flow.LF||
'       primary key (id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust_type_uk on ';
wwv_flow_imp.g_varchar2_table(7) := 'eba_cust_type(type)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_type'||wwv_flow.LF||
'   add constraint eba_cust_type_uk'||wwv_flow.LF||
'       unique (ty';
wwv_flow_imp.g_varchar2_table(8) := 'pe)'||wwv_flow.LF||
'       using index eba_cust_type_uk'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(17128887952728118721)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Customer Types'
,p_sequence=>170
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
