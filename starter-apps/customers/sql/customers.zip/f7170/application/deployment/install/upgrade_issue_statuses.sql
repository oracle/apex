prompt --application/deployment/install/upgrade_issue_statuses
begin
--   Manifest
--     INSTALL: UPGRADE-Issue Statuses
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE "EBA_CUST_ISSUE_STATUSES" '||wwv_flow.LF||
'   ("ID" NUMBER,'||wwv_flow.LF||
'    "NAME" VARCHAR2(255) NOT NULL ENABLE,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(2) := '   "DETAILS" VARCHAR2(4000),'||wwv_flow.LF||
'    "OPEN_YN" VARCHAR2(1),'||wwv_flow.LF||
'    "CREATED" TIMESTAMP (6) WITH TIME ZONE,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(3) := '    "CREATED_BY" VARCHAR2(255),'||wwv_flow.LF||
'    "UPDATED" TIMESTAMP (6) WITH TIME ZONE,'||wwv_flow.LF||
'    "UPDATED_BY" VARCHAR';
wwv_flow_imp.g_varchar2_table(4) := '2(255),'||wwv_flow.LF||
'     PRIMARY KEY ("ID") USING INDEX  ENABLE,'||wwv_flow.LF||
'     constraint check_open_yn check (open_yn in';
wwv_flow_imp.g_varchar2_table(5) := ' (''Y'',''N''))'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER  "BIU_EBA_CUST_ISSUE_STATUSES" '||wwv_flow.LF||
'    before insert or u';
wwv_flow_imp.g_varchar2_table(6) := 'pdate '||wwv_flow.LF||
'    on eba_cust_issue_statuses'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        :ne';
wwv_flow_imp.g_varchar2_table(7) := 'w.id := to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then';
wwv_flow_imp.g_varchar2_table(8) := ''||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(9) := 'end if;'||wwv_flow.LF||
'    if inserting or updating then'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.up';
wwv_flow_imp.g_varchar2_table(10) := 'dated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TRIGGER "BIU_EBA_CUST_ISSUE_STATUSES"';
wwv_flow_imp.g_varchar2_table(11) := ' ENABLE'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_CUST_ISSUE_STATUSES'||wwv_flow.LF||
'(name, open_yn, details)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'(''Open'',''Y'',''The issu';
wwv_flow_imp.g_varchar2_table(12) := 'e has not been resolved yet.'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_CUST_ISSUE_STATUSES'||wwv_flow.LF||
'(name, open_yn, details)'||wwv_flow.LF||
'values';
wwv_flow_imp.g_varchar2_table(13) := ''||wwv_flow.LF||
'(''Closed'',''N'',''The issue has been resolved.'');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2580578305250005577)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Issue Statuses'
,p_sequence=>470
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_CUST_ISSUE_STATUSES'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
