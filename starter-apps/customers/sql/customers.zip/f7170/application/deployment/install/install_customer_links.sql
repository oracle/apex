prompt --application/deployment/install/install_customer_links
begin
--   Manifest
--     INSTALL: INSTALL-customer links
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_links ('||wwv_flow.LF||
'   id                      number          not null,'||wwv_flow.LF||
'   row_version_nu';
wwv_flow_imp.g_varchar2_table(2) := 'mber      number,'||wwv_flow.LF||
'   customer_id             number          not null,'||wwv_flow.LF||
'   contact_id              nu';
wwv_flow_imp.g_varchar2_table(3) := 'mber,'||wwv_flow.LF||
'   link                    varchar2(4000)  not null,'||wwv_flow.LF||
'   link_desc               varchar2(255),';
wwv_flow_imp.g_varchar2_table(4) := ''||wwv_flow.LF||
'   link_type               varchar2(10),'||wwv_flow.LF||
'   LINK_COMMENTS           varchar2(4000),'||wwv_flow.LF||
'   tags        ';
wwv_flow_imp.g_varchar2_table(5) := '            varchar2(4000),'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   created               timestamp with time zone not null,'||wwv_flow.LF||
'   cre';
wwv_flow_imp.g_varchar2_table(6) := 'ated_by            varchar2(255) not null,'||wwv_flow.LF||
'   updated               timestamp with time zone,'||wwv_flow.LF||
'   upd';
wwv_flow_imp.g_varchar2_table(7) := 'ated_by            varchar2(255)'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_links'||wwv_flow.LF||
'   add constraint eba_cust_links_p';
wwv_flow_imp.g_varchar2_table(8) := 'k'||wwv_flow.LF||
'       primary key (id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_links'||wwv_flow.LF||
'   add constraint eba_cust_links_cust_fk'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(9) := '   foreign key (customer_id)'||wwv_flow.LF||
'       references eba_cust_customers (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter tab';
wwv_flow_imp.g_varchar2_table(10) := 'le eba_cust_links'||wwv_flow.LF||
'   add constraint eba_cust_links_contact_fk'||wwv_flow.LF||
'       foreign key (contact_id)'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(11) := ' references eba_cust_contacts (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_cust_links_01 on eba_cust_l';
wwv_flow_imp.g_varchar2_table(12) := 'inks (customer_id);'||wwv_flow.LF||
'create index eba_cust_links_02 on eba_cust_links (contact_id);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16674621776146430929)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'customer links'
,p_sequence=>290
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
