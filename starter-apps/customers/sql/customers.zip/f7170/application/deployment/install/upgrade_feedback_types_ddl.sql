prompt --application/deployment/install/upgrade_feedback_types_ddl
begin
--   Manifest
--     INSTALL: UPGRADE-Feedback Types DDL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_feedback_types'||wwv_flow.LF||
'('||wwv_flow.LF||
'    id             number constraint eba_cust_feedback_types_';
wwv_flow_imp.g_varchar2_table(2) := 'pk not null primary key,'||wwv_flow.LF||
'    type           varchar2(30),'||wwv_flow.LF||
'    created        timestamp with time zon';
wwv_flow_imp.g_varchar2_table(3) := 'e,'||wwv_flow.LF||
'    created_by     varchar2(255),'||wwv_flow.LF||
'    updated        timestamp with time zone,'||wwv_flow.LF||
'    updated_by    ';
wwv_flow_imp.g_varchar2_table(4) := ' varchar2(255)'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_cust_feedback_types_biu'||wwv_flow.LF||
'    before insert or update';
wwv_flow_imp.g_varchar2_table(5) := ' '||wwv_flow.LF||
'    on eba_cust_feedback_types'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        :new.id ';
wwv_flow_imp.g_varchar2_table(6) := ':= to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(7) := '   :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := NVL(V(''APP_USER''),user);'||wwv_flow.LF||
'    end if';
wwv_flow_imp.g_varchar2_table(8) := ';'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := NVL(V(''APP_USER''),user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alt';
wwv_flow_imp.g_varchar2_table(9) := 'er trigger eba_cust_feedback_types_biu enable'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(18744483546682966248)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Feedback Types DDL'
,p_sequence=>360
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_CUST_FEEDBACK_TYPES'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
