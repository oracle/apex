prompt --application/deployment/install/upgrade_timestamp_fix_bugid_31352674
begin
--   Manifest
--     INSTALL: UPGRADE-TIMESTAMP Fix (BUGID: 31352674) 
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- This script fixes BUG 31352674, replacing all columns of type TIMESTAMP(6) WITH LOCAL TIME ZONE t';
wwv_flow_imp.g_varchar2_table(2) := 'o TIMESTAMP WITH TIME ZONE'||wwv_flow.LF||
'-- it also updates all application triggers where columns where updated w';
wwv_flow_imp.g_varchar2_table(3) := 'ith LOCALTIMESTAMP to CURRENT_TIMESTAMP'||wwv_flow.LF||
'-- '||wwv_flow.LF||
'-- This upgrade script will only run if there are tables';
wwv_flow_imp.g_varchar2_table(4) := ' that start with ''EBA_INTRACK%'' with columns of data type'||wwv_flow.LF||
'-- TIMESTAMP(6) WITH LOCAL TIME ZONE'||wwv_flow.LF||
''||wwv_flow.LF||
'-- S';
wwv_flow_imp.g_varchar2_table(5) := 'tart of Script'||wwv_flow.LF||
'-- 1. Disable All Triggers'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_TYPE" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger';
wwv_flow_imp.g_varchar2_table(6) := ' "EBA_CUST_FEEDBACK_TYPES_BIU" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_SALES_CHANNEL" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alte';
wwv_flow_imp.g_varchar2_table(7) := 'r trigger "BIU_EBA_CUST_FILES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BD_EBA_CUST_FILES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger';
wwv_flow_imp.g_varchar2_table(8) := ' "AU_EBA_CUST_PRODUCT_USES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_PRODUCT_USES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter tr';
wwv_flow_imp.g_varchar2_table(9) := 'igger "BIU_EBA_CUST_CATEGORIES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "AU_EBA_CUST_ACTIVITIES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter t';
wwv_flow_imp.g_varchar2_table(10) := 'rigger "BIU_EBA_CUST_ACTIVITIES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_ACTIVITY_FILES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'a';
wwv_flow_imp.g_varchar2_table(11) := 'lter trigger "BIU_EBA_CUST_CUST_REFTYPE_REF" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "AU_EBA_CUST_CUSTOMER_REFTYPE_';
wwv_flow_imp.g_varchar2_table(12) := 'R" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CUST_USERS_BD" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CUST_USERS_BIU" DISABL';
wwv_flow_imp.g_varchar2_table(13) := 'E;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_REFERENCE_TYPES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_ACTIVITY_RE';
wwv_flow_imp.g_varchar2_table(14) := 'F" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "AU_EBA_CUST_ACTIVITY_REF" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_STATUS';
wwv_flow_imp.g_varchar2_table(15) := '" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_USE_CASE" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CUST_PRODUCT_STATUS';
wwv_flow_imp.g_varchar2_table(16) := 'ES_BIU" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_PRODUCT_FAMILIES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_C';
wwv_flow_imp.g_varchar2_table(17) := 'UST_TZ_PREF" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CUST_PREFERENCES_BIU" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_C';
wwv_flow_imp.g_varchar2_table(18) := 'UST_IMPL_PARTNERS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_EMAIL_LOG" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_E';
wwv_flow_imp.g_varchar2_table(19) := 'BA_CUST_ACTIVITY_TYPES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_CUST_PARTNER_REF" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter tr';
wwv_flow_imp.g_varchar2_table(20) := 'igger "AU_EBA_CUST_CUST_PARTNER_REF" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_ISSUES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter';
wwv_flow_imp.g_varchar2_table(21) := ' trigger "BIU_EBA_CUST_ADMINISTRATORS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CUST_VERIFY_BIU_FER" DISABLE;'||wwv_flow.LF||
'/';
wwv_flow_imp.g_varchar2_table(22) := ''||wwv_flow.LF||
'alter trigger "BD_EBA_CUST_CONTACTS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_CONTACTS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'al';
wwv_flow_imp.g_varchar2_table(23) := 'ter trigger "AU_EBA_CUST_CONTACTS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CUST_NOTIF_BIU" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter tr';
wwv_flow_imp.g_varchar2_table(24) := 'igger "BIU_EBA_CUST_ISSUE_STATUSES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CUST_ACL_FEATURES_BIU" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(25) := 'alter trigger "EBA_CUST_CLICKS_BIU" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CUST_FEEDBACK_BIU" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alte';
wwv_flow_imp.g_varchar2_table(26) := 'r trigger "BI_EBA_CUST_VIEWS_LOG" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_LINKS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter tri';
wwv_flow_imp.g_varchar2_table(27) := 'gger "BIU_EBA_CUST_GEOGRAPHIES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_REF_PHASE" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter t';
wwv_flow_imp.g_varchar2_table(28) := 'rigger "BIU_EBA_CUST_INDUSTRIES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CUST_TAGS_BIU" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigg';
wwv_flow_imp.g_varchar2_table(29) := 'er "BIU_EBA_CUST_COMPETITORS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "AU_EBA_CUST_COMPETITORS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter tr';
wwv_flow_imp.g_varchar2_table(30) := 'igger "AU_EBA_CUST_CUSTOMERS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "AD_EBA_CUST_CUSTOMERS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trig';
wwv_flow_imp.g_varchar2_table(31) := 'ger "BIU_EBA_CUST_CUSTOMERS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_NOTES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger ';
wwv_flow_imp.g_varchar2_table(32) := '"BIU_EBA_CUST_COUNTRIES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_CONTACT_TYPES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trig';
wwv_flow_imp.g_varchar2_table(33) := 'ger "BIU_EBA_CUST_HISTORY" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BI_EBA_CUST_ERRORS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "A';
wwv_flow_imp.g_varchar2_table(34) := 'U_EBA_CUST_CUST_COMPETITOR_RE" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_CUST_COMP_REF" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alte';
wwv_flow_imp.g_varchar2_table(35) := 'r trigger "BIU_EBA_CUST_PRODUCTS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BD_EBA_CUST_PRODUCTS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'-- Drop';
wwv_flow_imp.g_varchar2_table(36) := ' views:'||wwv_flow.LF||
'drop view eba_cust_customers_v;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- 2. Add temporary timestamp columns'||wwv_flow.LF||
'alter table EBA_CUST_';
wwv_flow_imp.g_varchar2_table(37) := 'TYPE add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUS';
wwv_flow_imp.g_varchar2_table(38) := 'T_FEEDBACK_TYPES add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter t';
wwv_flow_imp.g_varchar2_table(39) := 'able EBA_CUST_SALES_CHANNEL add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone';
wwv_flow_imp.g_varchar2_table(40) := ')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_FILES add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time z';
wwv_flow_imp.g_varchar2_table(41) := 'one)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_PRODUCT_USES add (VALID_FROM1 timestamp with time zone,VALID_TO1 timesta';
wwv_flow_imp.g_varchar2_table(42) := 'mp with time zone,CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table';
wwv_flow_imp.g_varchar2_table(43) := ' EBA_CUST_CATEGORIES add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alt';
wwv_flow_imp.g_varchar2_table(44) := 'er table EBA_CUST_ACTIVITIES add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zon';
wwv_flow_imp.g_varchar2_table(45) := 'e)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ACTIVITY_FILES add (CREATED1 timestamp with time zone,UPDATED1 timestamp w';
wwv_flow_imp.g_varchar2_table(46) := 'ith time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CUSTOMER_REFTYPE_REF add (CREATED1 timestamp with time zone,UP';
wwv_flow_imp.g_varchar2_table(47) := 'DATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_USERS add (CREATED1 timestamp with time zone';
wwv_flow_imp.g_varchar2_table(48) := ',UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_REFERENCE_TYPES add (CREATED1 timestamp w';
wwv_flow_imp.g_varchar2_table(49) := 'ith time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ACTIVITY_REF add (CREATED1 t';
wwv_flow_imp.g_varchar2_table(50) := 'imestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_STATUS add (CREATE';
wwv_flow_imp.g_varchar2_table(51) := 'D1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_USE_CASE add (';
wwv_flow_imp.g_varchar2_table(52) := 'CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_PRODUCT_';
wwv_flow_imp.g_varchar2_table(53) := 'STATUSES add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA';
wwv_flow_imp.g_varchar2_table(54) := '_CUST_PRODUCT_FAMILIES add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'a';
wwv_flow_imp.g_varchar2_table(55) := 'lter table EBA_CUST_TZ_PREF add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone';
wwv_flow_imp.g_varchar2_table(56) := ')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_PREFERENCES add (CREATED_ON1 timestamp with time zone,UPDATED_ON1 timestamp';
wwv_flow_imp.g_varchar2_table(57) := ' with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_IMPL_PARTNERS add (CREATED1 timestamp with time zone,UPDATED';
wwv_flow_imp.g_varchar2_table(58) := '1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_EMAIL_LOG add (CREATED1 timestamp with time zone,';
wwv_flow_imp.g_varchar2_table(59) := 'UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ACTIVITY_TYPES add (CREATED1 timestamp wit';
wwv_flow_imp.g_varchar2_table(60) := 'h time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CUST_PARTNER_REF add (CREATED1';
wwv_flow_imp.g_varchar2_table(61) := ' timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ISSUES add (CREA';
wwv_flow_imp.g_varchar2_table(62) := 'TED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ADMINISTRATO';
wwv_flow_imp.g_varchar2_table(63) := 'RS add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_';
wwv_flow_imp.g_varchar2_table(64) := 'VERIFICATIONS add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter tabl';
wwv_flow_imp.g_varchar2_table(65) := 'e EBA_CUST_CONTACTS add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alte';
wwv_flow_imp.g_varchar2_table(66) := 'r table EBA_CUST_NOTIFICATIONS add (DISPLAY_FROM1 timestamp with time zone,DISPLAY_UNTIL1 timestamp ';
wwv_flow_imp.g_varchar2_table(67) := 'with time zone,CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EB';
wwv_flow_imp.g_varchar2_table(68) := 'A_CUST_ISSUE_STATUSES add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'al';
wwv_flow_imp.g_varchar2_table(69) := 'ter table EBA_CUST_ACL_FEATURES add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time ';
wwv_flow_imp.g_varchar2_table(70) := 'zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CLICKS add (VIEW_TIMESTAMP1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA';
wwv_flow_imp.g_varchar2_table(71) := '_CUST_FEEDBACK add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter tab';
wwv_flow_imp.g_varchar2_table(72) := 'le EBA_CUST_VIEWS_LOG add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'al';
wwv_flow_imp.g_varchar2_table(73) := 'ter table EBA_CUST_LINKS add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/';
wwv_flow_imp.g_varchar2_table(74) := ''||wwv_flow.LF||
'alter table EBA_CUST_GEOGRAPHIES add (CREATED1 timestamp with time zone,UPDATED1 timestamp with tim';
wwv_flow_imp.g_varchar2_table(75) := 'e zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_REF_PHASE add (CREATED1 timestamp with time zone,UPDATED1 timestamp w';
wwv_flow_imp.g_varchar2_table(76) := 'ith time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_INDUSTRIES add (CREATED1 timestamp with time zone,UPDATED1 tim';
wwv_flow_imp.g_varchar2_table(77) := 'estamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_TAGS add (CREATED1 timestamp with time zone,UPDATED1 t';
wwv_flow_imp.g_varchar2_table(78) := 'imestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_COMPETITORS add (CREATED1 timestamp with time zone,U';
wwv_flow_imp.g_varchar2_table(79) := 'PDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CUSTOMERS add (CREATED1 timestamp with time';
wwv_flow_imp.g_varchar2_table(80) := ' zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_NOTES add (CREATED1 timestamp with t';
wwv_flow_imp.g_varchar2_table(81) := 'ime zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_COUNTRIES add (CREATED1 timestamp';
wwv_flow_imp.g_varchar2_table(82) := ' with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CONTACT_TYPES add (CREATED';
wwv_flow_imp.g_varchar2_table(83) := '1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_HISTORY add (CH';
wwv_flow_imp.g_varchar2_table(84) := 'ANGE_DATE1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ERRORS add (ERR_TIME1 timestamp with tim';
wwv_flow_imp.g_varchar2_table(85) := 'e zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CUST_COMPETITOR_REF add (CREATED1 timestamp with time zone,UPDATED1 t';
wwv_flow_imp.g_varchar2_table(86) := 'imestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_PRODUCTS add (CREATED1 timestamp with time zone,UPDA';
wwv_flow_imp.g_varchar2_table(87) := 'TED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- 3. Copy original column values into temporary column values'||wwv_flow.LF||
'upd';
wwv_flow_imp.g_varchar2_table(88) := 'ate EBA_CUST_TYPE set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_FEEDBACK_TYPES set CREA';
wwv_flow_imp.g_varchar2_table(89) := 'TED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_SALES_CHANNEL set CREATED1 = CREATED,UPDATED1 = U';
wwv_flow_imp.g_varchar2_table(90) := 'PDATED;'||wwv_flow.LF||
'update EBA_CUST_FILES set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_PRODUCT_USE';
wwv_flow_imp.g_varchar2_table(91) := 'S set VALID_FROM1 = VALID_FROM,VALID_TO1 = VALID_TO,CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EB';
wwv_flow_imp.g_varchar2_table(92) := 'A_CUST_CATEGORIES set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_ACTIVITIES set CREATED1';
wwv_flow_imp.g_varchar2_table(93) := ' = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_ACTIVITY_FILES set CREATED1 = CREATED,UPDATED1 = UPDA';
wwv_flow_imp.g_varchar2_table(94) := 'TED;'||wwv_flow.LF||
'update EBA_CUST_CUSTOMER_REFTYPE_REF set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST';
wwv_flow_imp.g_varchar2_table(95) := '_USERS set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_REFERENCE_TYPES set CREATED1 = CRE';
wwv_flow_imp.g_varchar2_table(96) := 'ATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_ACTIVITY_REF set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'upd';
wwv_flow_imp.g_varchar2_table(97) := 'ate EBA_CUST_STATUS set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_USE_CASE set CREATED1';
wwv_flow_imp.g_varchar2_table(98) := ' = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_PRODUCT_STATUSES set CREATED1 = CREATED,UPDATED1 = UP';
wwv_flow_imp.g_varchar2_table(99) := 'DATED;'||wwv_flow.LF||
'update EBA_CUST_PRODUCT_FAMILIES set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_T';
wwv_flow_imp.g_varchar2_table(100) := 'Z_PREF set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_PREFERENCES set CREATED_ON1 = CREA';
wwv_flow_imp.g_varchar2_table(101) := 'TED_ON,UPDATED_ON1 = UPDATED_ON;'||wwv_flow.LF||
'update EBA_CUST_IMPL_PARTNERS set CREATED1 = CREATED,UPDATED1 = UPD';
wwv_flow_imp.g_varchar2_table(102) := 'ATED;'||wwv_flow.LF||
'update EBA_CUST_EMAIL_LOG set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_ACTIVITY_';
wwv_flow_imp.g_varchar2_table(103) := 'TYPES set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_CUST_PARTNER_REF set CREATED1 = CRE';
wwv_flow_imp.g_varchar2_table(104) := 'ATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_ISSUES set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EB';
wwv_flow_imp.g_varchar2_table(105) := 'A_CUST_ADMINISTRATORS set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_VERIFICATIONS set C';
wwv_flow_imp.g_varchar2_table(106) := 'REATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_CONTACTS set CREATED1 = CREATED,UPDATED1 = UPD';
wwv_flow_imp.g_varchar2_table(107) := 'ATED;'||wwv_flow.LF||
'update EBA_CUST_NOTIFICATIONS set DISPLAY_FROM1 = DISPLAY_FROM,DISPLAY_UNTIL1 = DISPLAY_UNTIL,';
wwv_flow_imp.g_varchar2_table(108) := 'CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_ISSUE_STATUSES set CREATED1 = CREATED,UPDATED';
wwv_flow_imp.g_varchar2_table(109) := '1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_ACL_FEATURES set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST';
wwv_flow_imp.g_varchar2_table(110) := '_CLICKS set VIEW_TIMESTAMP1 = VIEW_TIMESTAMP;'||wwv_flow.LF||
'update EBA_CUST_FEEDBACK set CREATED1 = CREATED,UPDATE';
wwv_flow_imp.g_varchar2_table(111) := 'D1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_VIEWS_LOG set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_L';
wwv_flow_imp.g_varchar2_table(112) := 'INKS set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_GEOGRAPHIES set CREATED1 = CREATED,U';
wwv_flow_imp.g_varchar2_table(113) := 'PDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_REF_PHASE set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_C';
wwv_flow_imp.g_varchar2_table(114) := 'UST_INDUSTRIES set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_TAGS set CREATED1 = CREATE';
wwv_flow_imp.g_varchar2_table(115) := 'D,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_COMPETITORS set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update ';
wwv_flow_imp.g_varchar2_table(116) := 'EBA_CUST_CUSTOMERS set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_NOTES set CREATED1 = C';
wwv_flow_imp.g_varchar2_table(117) := 'REATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_COUNTRIES set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'upda';
wwv_flow_imp.g_varchar2_table(118) := 'te EBA_CUST_CONTACT_TYPES set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_HISTORY set CHA';
wwv_flow_imp.g_varchar2_table(119) := 'NGE_DATE1 = CHANGE_DATE;'||wwv_flow.LF||
'update EBA_CUST_ERRORS set ERR_TIME1 = ERR_TIME;'||wwv_flow.LF||
'update EBA_CUST_CUST_COMPE';
wwv_flow_imp.g_varchar2_table(120) := 'TITOR_REF set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CUST_PRODUCTS set CREATED1 = CREATED';
wwv_flow_imp.g_varchar2_table(121) := ',UPDATED1 = UPDATED;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- 4. Drop original timestamp with local time zone columns'||wwv_flow.LF||
'alter table EBA_CUS';
wwv_flow_imp.g_varchar2_table(122) := 'T_TYPE drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_FEEDBACK_TYPES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter t';
wwv_flow_imp.g_varchar2_table(123) := 'able EBA_CUST_SALES_CHANNEL drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_FILES drop (CREATED,UPDATE';
wwv_flow_imp.g_varchar2_table(124) := 'D)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_PRODUCT_USES drop (VALID_FROM,VALID_TO,CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_';
wwv_flow_imp.g_varchar2_table(125) := 'CUST_CATEGORIES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ACTIVITIES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'al';
wwv_flow_imp.g_varchar2_table(126) := 'ter table EBA_CUST_ACTIVITY_FILES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CUSTOMER_REFTYPE_REF';
wwv_flow_imp.g_varchar2_table(127) := ' drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_USERS drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_R';
wwv_flow_imp.g_varchar2_table(128) := 'EFERENCE_TYPES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ACTIVITY_REF drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'a';
wwv_flow_imp.g_varchar2_table(129) := 'lter table EBA_CUST_STATUS drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_USE_CASE drop (CREATED,UPDA';
wwv_flow_imp.g_varchar2_table(130) := 'TED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_PRODUCT_STATUSES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_PRODUCT_F';
wwv_flow_imp.g_varchar2_table(131) := 'AMILIES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_TZ_PREF drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table E';
wwv_flow_imp.g_varchar2_table(132) := 'BA_CUST_PREFERENCES drop (CREATED_ON,UPDATED_ON)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_IMPL_PARTNERS drop (CREATED,';
wwv_flow_imp.g_varchar2_table(133) := 'UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_EMAIL_LOG drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ACTIVITY_TYP';
wwv_flow_imp.g_varchar2_table(134) := 'ES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CUST_PARTNER_REF drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter tab';
wwv_flow_imp.g_varchar2_table(135) := 'le EBA_CUST_ISSUES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ADMINISTRATORS drop (CREATED,UPDATE';
wwv_flow_imp.g_varchar2_table(136) := 'D)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_VERIFICATIONS drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CONTACTS drop ';
wwv_flow_imp.g_varchar2_table(137) := '(CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_NOTIFICATIONS drop (DISPLAY_FROM,DISPLAY_UNTIL,CREATED,UPDA';
wwv_flow_imp.g_varchar2_table(138) := 'TED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ISSUE_STATUSES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ACL_FEATURE';
wwv_flow_imp.g_varchar2_table(139) := 'S drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CLICKS drop (VIEW_TIMESTAMP)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_';
wwv_flow_imp.g_varchar2_table(140) := 'FEEDBACK drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_VIEWS_LOG drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter tabl';
wwv_flow_imp.g_varchar2_table(141) := 'e EBA_CUST_LINKS drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_GEOGRAPHIES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(142) := 'alter table EBA_CUST_REF_PHASE drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_INDUSTRIES drop (CREATE';
wwv_flow_imp.g_varchar2_table(143) := 'D,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_TAGS drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_COMPETITORS dro';
wwv_flow_imp.g_varchar2_table(144) := 'p (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CUSTOMERS drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_N';
wwv_flow_imp.g_varchar2_table(145) := 'OTES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_COUNTRIES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EB';
wwv_flow_imp.g_varchar2_table(146) := 'A_CUST_CONTACT_TYPES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_HISTORY drop (CHANGE_DATE)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alte';
wwv_flow_imp.g_varchar2_table(147) := 'r table EBA_CUST_ERRORS drop (ERR_TIME)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CUST_COMPETITOR_REF drop (CREATED,UPD';
wwv_flow_imp.g_varchar2_table(148) := 'ATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_PRODUCTS drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- 5. Rename temporary columns back ';
wwv_flow_imp.g_varchar2_table(149) := 'to original column names'||wwv_flow.LF||
'alter table EBA_CUST_TYPE rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table E';
wwv_flow_imp.g_varchar2_table(150) := 'BA_CUST_TYPE rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_FEEDBACK_TYPES rename column C';
wwv_flow_imp.g_varchar2_table(151) := 'REATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_FEEDBACK_TYPES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter t';
wwv_flow_imp.g_varchar2_table(152) := 'able EBA_CUST_SALES_CHANNEL rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_SALES_CHANNEL r';
wwv_flow_imp.g_varchar2_table(153) := 'ename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_FILES rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'al';
wwv_flow_imp.g_varchar2_table(154) := 'ter table EBA_CUST_FILES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_PRODUCT_USES renam';
wwv_flow_imp.g_varchar2_table(155) := 'e column VALID_FROM1 to VALID_FROM'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_PRODUCT_USES rename column VALID_TO1 to VA';
wwv_flow_imp.g_varchar2_table(156) := 'LID_TO'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_PRODUCT_USES rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_';
wwv_flow_imp.g_varchar2_table(157) := 'PRODUCT_USES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CATEGORIES rename column CREAT';
wwv_flow_imp.g_varchar2_table(158) := 'ED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CATEGORIES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA';
wwv_flow_imp.g_varchar2_table(159) := '_CUST_ACTIVITIES rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ACTIVITIES rename column U';
wwv_flow_imp.g_varchar2_table(160) := 'PDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ACTIVITY_FILES rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter t';
wwv_flow_imp.g_varchar2_table(161) := 'able EBA_CUST_ACTIVITY_FILES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CUSTOMER_REFTY';
wwv_flow_imp.g_varchar2_table(162) := 'PE_REF rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CUSTOMER_REFTYPE_REF rename column U';
wwv_flow_imp.g_varchar2_table(163) := 'PDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_USERS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_';
wwv_flow_imp.g_varchar2_table(164) := 'CUST_USERS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_REFERENCE_TYPES rename column CR';
wwv_flow_imp.g_varchar2_table(165) := 'EATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_REFERENCE_TYPES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter t';
wwv_flow_imp.g_varchar2_table(166) := 'able EBA_CUST_ACTIVITY_REF rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ACTIVITY_REF ren';
wwv_flow_imp.g_varchar2_table(167) := 'ame column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_STATUS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alt';
wwv_flow_imp.g_varchar2_table(168) := 'er table EBA_CUST_STATUS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_USE_CASE rename co';
wwv_flow_imp.g_varchar2_table(169) := 'lumn CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_USE_CASE rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter t';
wwv_flow_imp.g_varchar2_table(170) := 'able EBA_CUST_PRODUCT_STATUSES rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_PRODUCT_STAT';
wwv_flow_imp.g_varchar2_table(171) := 'USES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_PRODUCT_FAMILIES rename column CREATED';
wwv_flow_imp.g_varchar2_table(172) := '1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_PRODUCT_FAMILIES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table';
wwv_flow_imp.g_varchar2_table(173) := ' EBA_CUST_TZ_PREF rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_TZ_PREF rename column UPD';
wwv_flow_imp.g_varchar2_table(174) := 'ATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_PREFERENCES rename column CREATED_ON1 to CREATED_ON'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter ';
wwv_flow_imp.g_varchar2_table(175) := 'table EBA_CUST_PREFERENCES rename column UPDATED_ON1 to UPDATED_ON'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_IMPL_PARTN';
wwv_flow_imp.g_varchar2_table(176) := 'ERS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_IMPL_PARTNERS rename column UPDATED1 to';
wwv_flow_imp.g_varchar2_table(177) := ' UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_EMAIL_LOG rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_E';
wwv_flow_imp.g_varchar2_table(178) := 'MAIL_LOG rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ACTIVITY_TYPES rename column CREAT';
wwv_flow_imp.g_varchar2_table(179) := 'ED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ACTIVITY_TYPES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table';
wwv_flow_imp.g_varchar2_table(180) := ' EBA_CUST_CUST_PARTNER_REF rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CUST_PARTNER_REF';
wwv_flow_imp.g_varchar2_table(181) := ' rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ISSUES rename column CREATED1 to CREATED'||wwv_flow.LF||
'/';
wwv_flow_imp.g_varchar2_table(182) := ''||wwv_flow.LF||
'alter table EBA_CUST_ISSUES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ADMINISTRATORS';
wwv_flow_imp.g_varchar2_table(183) := ' rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ADMINISTRATORS rename column UPDATED1 to U';
wwv_flow_imp.g_varchar2_table(184) := 'PDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_VERIFICATIONS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST';
wwv_flow_imp.g_varchar2_table(185) := '_VERIFICATIONS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CONTACTS rename column CREAT';
wwv_flow_imp.g_varchar2_table(186) := 'ED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CONTACTS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_C';
wwv_flow_imp.g_varchar2_table(187) := 'UST_NOTIFICATIONS rename column DISPLAY_FROM1 to DISPLAY_FROM'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_NOTIFICATIONS r';
wwv_flow_imp.g_varchar2_table(188) := 'ename column DISPLAY_UNTIL1 to DISPLAY_UNTIL'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_NOTIFICATIONS rename column CREA';
wwv_flow_imp.g_varchar2_table(189) := 'TED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_NOTIFICATIONS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table';
wwv_flow_imp.g_varchar2_table(190) := ' EBA_CUST_ISSUE_STATUSES rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ISSUE_STATUSES ren';
wwv_flow_imp.g_varchar2_table(191) := 'ame column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ACL_FEATURES rename column CREATED1 to CREATED';
wwv_flow_imp.g_varchar2_table(192) := ''||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ACL_FEATURES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CLICKS';
wwv_flow_imp.g_varchar2_table(193) := ' rename column VIEW_TIMESTAMP1 to VIEW_TIMESTAMP'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_FEEDBACK rename column CREAT';
wwv_flow_imp.g_varchar2_table(194) := 'ED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_FEEDBACK rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_C';
wwv_flow_imp.g_varchar2_table(195) := 'UST_VIEWS_LOG rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_VIEWS_LOG rename column UPDAT';
wwv_flow_imp.g_varchar2_table(196) := 'ED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_LINKS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST';
wwv_flow_imp.g_varchar2_table(197) := '_LINKS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_GEOGRAPHIES rename column CREATED1 t';
wwv_flow_imp.g_varchar2_table(198) := 'o CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_GEOGRAPHIES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUS';
wwv_flow_imp.g_varchar2_table(199) := 'T_REF_PHASE rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_REF_PHASE rename column UPDATED';
wwv_flow_imp.g_varchar2_table(200) := '1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_INDUSTRIES rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_C';
wwv_flow_imp.g_varchar2_table(201) := 'UST_INDUSTRIES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_TAGS rename column CREATED1 ';
wwv_flow_imp.g_varchar2_table(202) := 'to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_TAGS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_COMP';
wwv_flow_imp.g_varchar2_table(203) := 'ETITORS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_COMPETITORS rename column UPDATED1 ';
wwv_flow_imp.g_varchar2_table(204) := 'to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CUSTOMERS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST';
wwv_flow_imp.g_varchar2_table(205) := '_CUSTOMERS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_NOTES rename column CREATED1 to ';
wwv_flow_imp.g_varchar2_table(206) := 'CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_NOTES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_COUNTR';
wwv_flow_imp.g_varchar2_table(207) := 'IES rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_COUNTRIES rename column UPDATED1 to UPD';
wwv_flow_imp.g_varchar2_table(208) := 'ATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CONTACT_TYPES rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_C';
wwv_flow_imp.g_varchar2_table(209) := 'ONTACT_TYPES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_HISTORY rename column CHANGE_D';
wwv_flow_imp.g_varchar2_table(210) := 'ATE1 to CHANGE_DATE'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_ERRORS rename column ERR_TIME1 to ERR_TIME'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table ';
wwv_flow_imp.g_varchar2_table(211) := 'EBA_CUST_CUST_COMPETITOR_REF rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_CUST_COMPETITO';
wwv_flow_imp.g_varchar2_table(212) := 'R_REF rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_PRODUCTS rename column CREATED1 to CR';
wwv_flow_imp.g_varchar2_table(213) := 'EATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CUST_PRODUCTS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- 6. Re-create all trigg';
wwv_flow_imp.g_varchar2_table(214) := 'ers and enable them.'||wwv_flow.LF||
'create or replace TRIGGER biu_eba_cust_type'||wwv_flow.LF||
'    before insert or update on eba_';
wwv_flow_imp.g_varchar2_table(215) := 'cust_type'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :NEW.ID is null then'||wwv_flow.LF||
'            s';
wwv_flow_imp.g_varchar2_table(216) := 'elect to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(217) := '    from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY :=';
wwv_flow_imp.g_varchar2_table(218) := ' nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(';
wwv_flow_imp.g_varchar2_table(219) := 'v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(220) := ':NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.';
wwv_flow_imp.g_varchar2_table(221) := 'row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIG';
wwv_flow_imp.g_varchar2_table(222) := 'GER eba_cust_feedback_types_biu'||wwv_flow.LF||
'    before insert or update '||wwv_flow.LF||
'    on eba_cust_feedback_types'||wwv_flow.LF||
'    for ';
wwv_flow_imp.g_varchar2_table(223) := 'each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(224) := 'XXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(225) := '     :new.created_by := NVL(V(''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(226) := '    :new.updated_by := NVL(V(''APP_USER''),user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER biu_eba_cust_sales';
wwv_flow_imp.g_varchar2_table(227) := '_channel'||wwv_flow.LF||
'   before insert or update on eba_cust_sales_channel'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if inserting ';
wwv_flow_imp.g_varchar2_table(228) := 'then'||wwv_flow.LF||
'      if :NEW.ID is null then'||wwv_flow.LF||
'        :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(229) := 'XXXXXXXX'');'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'      :NEW.CREATED_BY := nvl(v(''A';
wwv_flow_imp.g_varchar2_table(230) := 'PP_USER''),USER);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'   :NEW.UPDATED_BY := nvl(v(''APP_U';
wwv_flow_imp.g_varchar2_table(231) := 'SER''),USER);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER biu_eba_cust_files'||wwv_flow.LF||
'  before insert or update on eba_c';
wwv_flow_imp.g_varchar2_table(232) := 'ust_files'||wwv_flow.LF||
'  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  if (inserting or updating) and nvl(dbms_lob.getlength(:new.file_blo';
wwv_flow_imp.g_varchar2_table(233) := 'b),0) > 15728640 then'||wwv_flow.LF||
'    raise_application_error(-20000, ''The size of the uploaded file was over 15';
wwv_flow_imp.g_varchar2_table(234) := 'MB. Please upload a smaller file.'');'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
'  if inserting then'||wwv_flow.LF||
'    if :NEW.ID is null then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(235) := ' select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'        into :new.id'||wwv_flow.LF||
'        from d';
wwv_flow_imp.g_varchar2_table(236) := 'ual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'    :NEW.CREATED_BY := nvl(v(''APP_USER''),USE';
wwv_flow_imp.g_varchar2_table(237) := 'R);'||wwv_flow.LF||
'    :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'    :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'    :new.';
wwv_flow_imp.g_varchar2_table(238) := 'row_version_number := 1;'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
'  if updating then'||wwv_flow.LF||
'    :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'    :NE';
wwv_flow_imp.g_varchar2_table(239) := 'W.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'    :new.row_version_number := nvl(:new.row_version_number,';
wwv_flow_imp.g_varchar2_table(240) := '0) + 1;'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
'  eba_cust_fw.tag_sync('||wwv_flow.LF||
'    p_new_tags      => :new.tags,'||wwv_flow.LF||
'    p_old_tags      => :';
wwv_flow_imp.g_varchar2_table(241) := 'old.tags,'||wwv_flow.LF||
'    p_content_type  => ''FILE'','||wwv_flow.LF||
'    p_content_id    => :new.id );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace';
wwv_flow_imp.g_varchar2_table(242) := ' TRIGGER bd_eba_cust_files'||wwv_flow.LF||
'    before delete on eba_cust_files'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba_cust_f';
wwv_flow_imp.g_varchar2_table(243) := 'w.tag_sync('||wwv_flow.LF||
'        p_new_tags      => null,'||wwv_flow.LF||
'        p_old_tags      => :old.tags,'||wwv_flow.LF||
'        p_content';
wwv_flow_imp.g_varchar2_table(244) := '_type  => ''FILE'','||wwv_flow.LF||
'        p_content_id    => :old.id );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER au_eba_cus';
wwv_flow_imp.g_varchar2_table(245) := 't_product_uses'||wwv_flow.LF||
'    after update on eba_cust_product_uses'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    ov varchar2(40';
wwv_flow_imp.g_varchar2_table(246) := '00) := null;'||wwv_flow.LF||
'    nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- PRODUCT_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:old.pr';
wwv_flow_imp.g_varchar2_table(247) := 'oduct_id,-999) != nvl(:new.product_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (';
wwv_flow_imp.g_varchar2_table(248) := 'select product_name val from eba_cust_products t where t.id = :old.product_id) loop'||wwv_flow.LF||
'            ov :';
wwv_flow_imp.g_varchar2_table(249) := '= c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in (select product_name val from eba_cust_products t wher';
wwv_flow_imp.g_varchar2_table(250) := 'e t.id = :new.product_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_c';
wwv_flow_imp.g_varchar2_table(251) := 'ust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(252) := '           (''PRODUCT_USES'', null, :new.customer_id, ''PRODUCT_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end au_eba_cu';
wwv_flow_imp.g_varchar2_table(253) := 'st_product_uses;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER biu_eba_cust_product_uses'||wwv_flow.LF||
'    before insert or update ';
wwv_flow_imp.g_varchar2_table(254) := 'on eba_cust_product_uses'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :NEW.ID is null the';
wwv_flow_imp.g_varchar2_table(255) := 'n'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :ne';
wwv_flow_imp.g_varchar2_table(256) := 'w.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'        :NE';
wwv_flow_imp.g_varchar2_table(257) := 'W.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPD';
wwv_flow_imp.g_varchar2_table(258) := 'ATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updatin';
wwv_flow_imp.g_varchar2_table(259) := 'g then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER)';
wwv_flow_imp.g_varchar2_table(260) := ';'||wwv_flow.LF||
'        :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create ';
wwv_flow_imp.g_varchar2_table(261) := 'or replace TRIGGER biu_eba_cust_categories'||wwv_flow.LF||
'    before insert or update on eba_cust_categories'||wwv_flow.LF||
'    fo';
wwv_flow_imp.g_varchar2_table(262) := 'r each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(';
wwv_flow_imp.g_varchar2_table(263) := 'sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(264) := '       end if;'||wwv_flow.LF||
'        :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER';
wwv_flow_imp.g_varchar2_table(265) := '''),USER);'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),US';
wwv_flow_imp.g_varchar2_table(266) := 'ER);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := ';
wwv_flow_imp.g_varchar2_table(267) := 'current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_numb';
wwv_flow_imp.g_varchar2_table(268) := 'er := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER au_eba_cust_';
wwv_flow_imp.g_varchar2_table(269) := 'activities'||wwv_flow.LF||
'    after update on eba_cust_activities'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    pragma autonomous_tr';
wwv_flow_imp.g_varchar2_table(270) := 'ansaction;'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'    nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- TYPE_ID (forei';
wwv_flow_imp.g_varchar2_table(271) := 'gn key)'||wwv_flow.LF||
'    if nvl(:old.type_id,-999) != nvl(:new.type_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;';
wwv_flow_imp.g_varchar2_table(272) := ''||wwv_flow.LF||
'        for c1 in (select name val from eba_cust_activity_types t where t.id = :old.type_id) loop'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(273) := '           ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in (select name val from eba_cust_activity';
wwv_flow_imp.g_varchar2_table(274) := '_types t where t.id = :new.type_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert ';
wwv_flow_imp.g_varchar2_table(275) := 'into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value';
wwv_flow_imp.g_varchar2_table(276) := ') values'||wwv_flow.LF||
'            (''ACTIVITIES'', null, :new.id, ''TYPE_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- NAME (defa';
wwv_flow_imp.g_varchar2_table(277) := 'ult)'||wwv_flow.LF||
'    if nvl(:old.name, ''0'') != nvl(:new.name,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (ta';
wwv_flow_imp.g_varchar2_table(278) := 'ble_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''A';
wwv_flow_imp.g_varchar2_table(279) := 'CTIVITIES'', null, :new.id, ''NAME'', substr(:old.name,0,4000), substr(:new.name,0,4000) ); '||wwv_flow.LF||
'    end if';
wwv_flow_imp.g_varchar2_table(280) := ';'||wwv_flow.LF||
'    -- DESCRIPTION (default)'||wwv_flow.LF||
'    if nvl(:old.description, ''0'') != nvl(:new.description,''0'') then '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(281) := '        insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_v';
wwv_flow_imp.g_varchar2_table(282) := 'alue, new_value) values '||wwv_flow.LF||
'            (''ACTIVITIES'', null, :new.id, ''DESCRIPTION'', substr(:old.descri';
wwv_flow_imp.g_varchar2_table(283) := 'ption,0,4000), substr(:new.description,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- ACTIVITY_DATE (date/timestamp)';
wwv_flow_imp.g_varchar2_table(284) := ''||wwv_flow.LF||
'    if (:old.activity_date is null and :new.activity_date is not null) or '||wwv_flow.LF||
'        (:old.activity_d';
wwv_flow_imp.g_varchar2_table(285) := 'ate is not null and :new.activity_date is null) or '||wwv_flow.LF||
'        (:old.activity_date != :new.activity_dat';
wwv_flow_imp.g_varchar2_table(286) := 'e) then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_na';
wwv_flow_imp.g_varchar2_table(287) := 'me, old_value, new_value) values '||wwv_flow.LF||
'            (''ACTIVITIES'', null, :new.id, ''ACTIVITY_DATE'', to_char';
wwv_flow_imp.g_varchar2_table(288) := '(:old.activity_date, ''DD-MON-YYYY''), to_char(:new.activity_date, ''DD-MON-YYYY'') );'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(289) := '- OWNER (default)'||wwv_flow.LF||
'    if nvl(:old.owner, ''0'') != nvl(:new.owner,''0'') then '||wwv_flow.LF||
'        insert into eba_c';
wwv_flow_imp.g_varchar2_table(290) := 'ust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(291) := '            (''ACTIVITIES'', null, :new.id, ''OWNER'', substr(:old.owner,0,4000), substr(:new.owner,0,40';
wwv_flow_imp.g_varchar2_table(292) := '00) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- LOCATION (default)'||wwv_flow.LF||
'    if nvl(:old.location, ''0'') != nvl(:new.location,''0';
wwv_flow_imp.g_varchar2_table(293) := ''') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_na';
wwv_flow_imp.g_varchar2_table(294) := 'me, old_value, new_value) values '||wwv_flow.LF||
'            (''ACTIVITIES'', null, :new.id, ''LOCATION'', substr(:old.';
wwv_flow_imp.g_varchar2_table(295) := 'location,0,4000), substr(:new.location,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end au_eba_cust_activitie';
wwv_flow_imp.g_varchar2_table(296) := 's;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER biu_eba_cust_activities'||wwv_flow.LF||
'    before insert or update on eba_cust_acti';
wwv_flow_imp.g_varchar2_table(297) := 'vities'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            :new';
wwv_flow_imp.g_varchar2_table(298) := '.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.create';
wwv_flow_imp.g_varchar2_table(299) := 'd := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'        :new.row_version';
wwv_flow_imp.g_varchar2_table(300) := '_number := 1;'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    en';
wwv_flow_imp.g_varchar2_table(301) := 'd if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end biu';
wwv_flow_imp.g_varchar2_table(302) := '_eba_cust_activities;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER biu_eba_cust_cust_reftype_ref'||wwv_flow.LF||
'    before insert o';
wwv_flow_imp.g_varchar2_table(303) := 'r update on eba_cust_customer_reftype_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :n';
wwv_flow_imp.g_varchar2_table(304) := 'ew.id is null then'||wwv_flow.LF||
'            :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(305) := '        end if;'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USE';
wwv_flow_imp.g_varchar2_table(306) := 'R''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP';
wwv_flow_imp.g_varchar2_table(307) := '_USER''),user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER au_eba_cust_customer_reftype_r'||wwv_flow.LF||
'    after insert or ';
wwv_flow_imp.g_varchar2_table(308) := 'update or delete on eba_cust_customer_reftype_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    pragma autonomous_tra';
wwv_flow_imp.g_varchar2_table(309) := 'nsaction;'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'    nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    ov := null; nv := ';
wwv_flow_imp.g_varchar2_table(310) := 'null;'||wwv_flow.LF||
'    for c1 in (select reference_type val from eba_cust_reference_types t where t.id = :old.ref';
wwv_flow_imp.g_varchar2_table(311) := 'erence_type_id) loop'||wwv_flow.LF||
'        ov := c1.val;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    for c1 in (select reference_type val fr';
wwv_flow_imp.g_varchar2_table(312) := 'om eba_cust_reference_types t where t.id = :new.reference_type_id) loop'||wwv_flow.LF||
'        nv := c1.val;'||wwv_flow.LF||
'    en';
wwv_flow_imp.g_varchar2_table(313) := 'd loop;'||wwv_flow.LF||
'    insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, o';
wwv_flow_imp.g_varchar2_table(314) := 'ld_value, new_value) values'||wwv_flow.LF||
'        (''CUSTOMERS'', null, nvl(:new.customer_id,:old.customer_id), ''REF';
wwv_flow_imp.g_varchar2_table(315) := 'ERENCE_TYPE_ID'', ov, nv);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end au_eba_cust_customer_reftype_r;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGG';
wwv_flow_imp.g_varchar2_table(316) := 'ER eba_cust_users_bd'||wwv_flow.LF||
'    before delete on eba_cust_users'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- Disallow dele';
wwv_flow_imp.g_varchar2_table(317) := 'tes to a user''s own record.'||wwv_flow.LF||
'    if v(''APP_USER'') = upper(:old.username) then'||wwv_flow.LF||
'        raise_applicati';
wwv_flow_imp.g_varchar2_table(318) := 'on_error(-20002, ''Delete disallowed, you cannot delete your own access control details.'');'||wwv_flow.LF||
'    end i';
wwv_flow_imp.g_varchar2_table(319) := 'f;    '||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER eba_cust_users_biu'||wwv_flow.LF||
'    before insert or update on eba_cust_';
wwv_flow_imp.g_varchar2_table(320) := 'users'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            :new.';
wwv_flow_imp.g_varchar2_table(321) := 'id := eba_cust.gen_id();'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created_by         := nvl(v(''APP_USER''), USER)';
wwv_flow_imp.g_varchar2_table(322) := ';'||wwv_flow.LF||
'        :new.created            := current_timestamp;'||wwv_flow.LF||
'        :new.row_version        := 1;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(323) := '  if :new.account_locked is null then'||wwv_flow.LF||
'            :new.account_locked := ''N'';    '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(324) := '  end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'            :new.updated_by         := nvl(v(''APP_USER''), USER);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(325) := '        :new.updated            := current_timestamp;'||wwv_flow.LF||
'            :new.row_version        := nvl(:ol';
wwv_flow_imp.g_varchar2_table(326) := 'd.row_version,1) + 1;                                '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- Always store username as up';
wwv_flow_imp.g_varchar2_table(327) := 'per case'||wwv_flow.LF||
'    :new.username := upper(:new.username);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER biu_eba_cust_r';
wwv_flow_imp.g_varchar2_table(328) := 'eference_types'||wwv_flow.LF||
'    before insert or update on eba_cust_reference_types'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if';
wwv_flow_imp.g_varchar2_table(329) := ' inserting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            :new.id := to_number(sys_guid(),''XXXXXXX';
wwv_flow_imp.g_varchar2_table(330) := 'XXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new';
wwv_flow_imp.g_varchar2_table(331) := '.created_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    elsif updating the';
wwv_flow_imp.g_varchar2_table(332) := 'n'||wwv_flow.LF||
'        :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    :new.u';
wwv_flow_imp.g_varchar2_table(333) := 'pdated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or repla';
wwv_flow_imp.g_varchar2_table(334) := 'ce TRIGGER biu_eba_cust_activity_ref'||wwv_flow.LF||
'    before insert or update on eba_cust_activity_ref'||wwv_flow.LF||
'    for ea';
wwv_flow_imp.g_varchar2_table(335) := 'ch row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            :new.id := to_number(';
wwv_flow_imp.g_varchar2_table(336) := 'sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created := current_time';
wwv_flow_imp.g_varchar2_table(337) := 'stamp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'        :new.row_version_number := 1; '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(338) := '  else '||wwv_flow.LF||
'        :new.row_version_number := nvl(:new.row_version_number,0) + 1; '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new';
wwv_flow_imp.g_varchar2_table(339) := '.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end biu_eba_cust_acti';
wwv_flow_imp.g_varchar2_table(340) := 'vity_ref;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER au_eba_cust_activity_ref'||wwv_flow.LF||
'    after update on eba_cust_activit';
wwv_flow_imp.g_varchar2_table(341) := 'y_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    pragma autonomous_transaction;'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(342) := ' nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- ACTIVITY_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:old.activity_id,-999)';
wwv_flow_imp.g_varchar2_table(343) := ' != nvl(:new.activity_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select name v';
wwv_flow_imp.g_varchar2_table(344) := 'al from eba_cust_activities t where t.id = :old.activity_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(345) := 'end loop;'||wwv_flow.LF||
'        for c1 in (select name val from eba_cust_activities t where t.id = :new.activity_i';
wwv_flow_imp.g_varchar2_table(346) := 'd) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name';
wwv_flow_imp.g_varchar2_table(347) := ', component_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            (''ACTIVITY_R';
wwv_flow_imp.g_varchar2_table(348) := 'EF'', null, :new.id, ''ACTIVITY_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CUSTOMER_ID (foreign key)'||wwv_flow.LF||
'    if nvl(';
wwv_flow_imp.g_varchar2_table(349) := ':old.customer_id,-999) != nvl(:new.customer_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        fo';
wwv_flow_imp.g_varchar2_table(350) := 'r c1 in (select row_key val from eba_cust_customers t where t.id = :old.customer_id) loop'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(351) := '  ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in (select row_key val from eba_cust_customers t wh';
wwv_flow_imp.g_varchar2_table(352) := 'ere t.id = :new.customer_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eb';
wwv_flow_imp.g_varchar2_table(353) := 'a_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) value';
wwv_flow_imp.g_varchar2_table(354) := 's'||wwv_flow.LF||
'            (''ACTIVITY_REF'', null, :new.id, ''CUSTOMER_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CONTACT_ID ';
wwv_flow_imp.g_varchar2_table(355) := '(foreign key)'||wwv_flow.LF||
'    if nvl(:old.contact_id,-999) != nvl(:new.contact_id,-999) then'||wwv_flow.LF||
'        ov := null;';
wwv_flow_imp.g_varchar2_table(356) := ' nv := null;'||wwv_flow.LF||
'        for c1 in (select name val from eba_cust_contacts t where t.id = :old.contact_i';
wwv_flow_imp.g_varchar2_table(357) := 'd) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in (select name val from eba_cust';
wwv_flow_imp.g_varchar2_table(358) := '_contacts t where t.id = :new.contact_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        i';
wwv_flow_imp.g_varchar2_table(359) := 'nsert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new';
wwv_flow_imp.g_varchar2_table(360) := '_value) values'||wwv_flow.LF||
'            (''ACTIVITY_REF'', null, :new.id, ''CONTACT_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(361) := ' ACTIVITY_DATE (date/timestamp)'||wwv_flow.LF||
'    if (:old.activity_date is null and :new.activity_date is not nul';
wwv_flow_imp.g_varchar2_table(362) := 'l) or '||wwv_flow.LF||
'        (:old.activity_date is not null and :new.activity_date is null) or '||wwv_flow.LF||
'        (:old.act';
wwv_flow_imp.g_varchar2_table(363) := 'ivity_date != :new.activity_date) then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_';
wwv_flow_imp.g_varchar2_table(364) := 'rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''ACTIVITY_REF'', null, ';
wwv_flow_imp.g_varchar2_table(365) := ':new.id, ''ACTIVITY_DATE'', to_char(:old.activity_date, ''DD-MON-YYYY''), to_char(:new.activity_date, ''D';
wwv_flow_imp.g_varchar2_table(366) := 'D-MON-YYYY'') );'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- OWNER (default)'||wwv_flow.LF||
'    if nvl(:old.owner, ''0'') != nvl(:new.owner,''0''';
wwv_flow_imp.g_varchar2_table(367) := ') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_nam';
wwv_flow_imp.g_varchar2_table(368) := 'e, old_value, new_value) values '||wwv_flow.LF||
'            (''ACTIVITY_REF'', null, :new.id, ''OWNER'', substr(:old.ow';
wwv_flow_imp.g_varchar2_table(369) := 'ner,0,4000), substr(:new.owner,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- LOCATION (default)'||wwv_flow.LF||
'    if nvl(:old.loc';
wwv_flow_imp.g_varchar2_table(370) := 'ation, ''0'') != nvl(:new.location,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, compon';
wwv_flow_imp.g_varchar2_table(371) := 'ent_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''ACTIVITY_REF'', nu';
wwv_flow_imp.g_varchar2_table(372) := 'll, :new.id, ''LOCATION'', substr(:old.location,0,4000), substr(:new.location,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(373) := '    -- NOTES (default)'||wwv_flow.LF||
'    if nvl(:old.notes, ''0'') != nvl(:new.notes,''0'') then '||wwv_flow.LF||
'        insert into ';
wwv_flow_imp.g_varchar2_table(374) := 'eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) val';
wwv_flow_imp.g_varchar2_table(375) := 'ues '||wwv_flow.LF||
'            (''ACTIVITY_REF'', null, :new.id, ''NOTES'', substr(:old.notes,0,4000), substr(:new.not';
wwv_flow_imp.g_varchar2_table(376) := 'es,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end au_eba_cust_activity_ref;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER bi';
wwv_flow_imp.g_varchar2_table(377) := 'u_eba_cust_status'||wwv_flow.LF||
'    before insert or update on eba_cust_status'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inser';
wwv_flow_imp.g_varchar2_table(378) := 'ting then'||wwv_flow.LF||
'        if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(379) := 'XXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.C';
wwv_flow_imp.g_varchar2_table(380) := 'REATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :NEW.UPDATE';
wwv_flow_imp.g_varchar2_table(381) := 'D := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version';
wwv_flow_imp.g_varchar2_table(382) := '_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :N';
wwv_flow_imp.g_varchar2_table(383) := 'EW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:new.row_version_nu';
wwv_flow_imp.g_varchar2_table(384) := 'mber,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER biu_eba_cust_use_case'||wwv_flow.LF||
'    before insert o';
wwv_flow_imp.g_varchar2_table(385) := 'r update on eba_cust_use_case'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :NEW.ID is nul';
wwv_flow_imp.g_varchar2_table(386) := 'l then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              int';
wwv_flow_imp.g_varchar2_table(387) := 'o :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(388) := '  :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NE';
wwv_flow_imp.g_varchar2_table(389) := 'W.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if up';
wwv_flow_imp.g_varchar2_table(390) := 'dating then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),';
wwv_flow_imp.g_varchar2_table(391) := 'USER);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'cr';
wwv_flow_imp.g_varchar2_table(392) := 'eate or replace TRIGGER eba_cust_product_statuses_biu'||wwv_flow.LF||
'    before insert or update on eba_cust_produc';
wwv_flow_imp.g_varchar2_table(393) := 't_statuses'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :NEW.ID is null then'||wwv_flow.LF||
'        select to_number(sys_guid(),''X';
wwv_flow_imp.g_varchar2_table(394) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'          into :new.id'||wwv_flow.LF||
'          from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if ins';
wwv_flow_imp.g_varchar2_table(395) := 'erting then'||wwv_flow.LF||
'       :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'       :NEW.CREATED_BY := nvl(v(''APP_USER''),US';
wwv_flow_imp.g_varchar2_table(396) := 'ER);'||wwv_flow.LF||
'       :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'       :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(397) := '  end if;'||wwv_flow.LF||
'  '||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'       :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'       :NEW.UPDATED_BY :';
wwv_flow_imp.g_varchar2_table(398) := '= nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER biu_eba_cust_product_famili';
wwv_flow_imp.g_varchar2_table(399) := 'es'||wwv_flow.LF||
'    before insert or update on eba_cust_product_families'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting ';
wwv_flow_imp.g_varchar2_table(400) := 'then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(401) := 'XXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by';
wwv_flow_imp.g_varchar2_table(402) := ' := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        :new.row_version';
wwv_flow_imp.g_varchar2_table(403) := '_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(404) := '  :new.updated_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end biu_eba_cust_product_families;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replac';
wwv_flow_imp.g_varchar2_table(405) := 'e TRIGGER biu_eba_cust_tz_pref'||wwv_flow.LF||
'    before insert or update on eba_cust_tz_pref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begi';
wwv_flow_imp.g_varchar2_table(406) := 'n'||wwv_flow.LF||
'   if :new."ID" is null then'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(407) := ''') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_timestamp;';
wwv_flow_imp.g_varchar2_table(408) := ''||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(409) := '   :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updat';
wwv_flow_imp.g_varchar2_table(410) := 'ing then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inse';
wwv_flow_imp.g_varchar2_table(411) := 'rting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_f';
wwv_flow_imp.g_varchar2_table(412) := 'low.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if :new.TIMEZONE_PREFERENCE is null then'||wwv_flow.LF||
'       :new.timezone_prefer';
wwv_flow_imp.g_varchar2_table(413) := 'ence := ''UTC'';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER eba_cust_preferences_biu'||wwv_flow.LF||
'    before inse';
wwv_flow_imp.g_varchar2_table(414) := 'rt or update on eba_cust_preferences'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null the';
wwv_flow_imp.g_varchar2_table(415) := 'n'||wwv_flow.LF||
'        :new.id := eba_cust.gen_id();'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_by :=';
wwv_flow_imp.g_varchar2_table(416) := ' nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created_on := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating ';
wwv_flow_imp.g_varchar2_table(417) := 'then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated_on := current_timestam';
wwv_flow_imp.g_varchar2_table(418) := 'p;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.preference_name := upper(:new.preference_name);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TR';
wwv_flow_imp.g_varchar2_table(419) := 'IGGER biu_eba_cust_impl_partners'||wwv_flow.LF||
'    before insert or update on eba_cust_impl_partners'||wwv_flow.LF||
'    for each ';
wwv_flow_imp.g_varchar2_table(420) := 'row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            :new.id := to_number(sys';
wwv_flow_imp.g_varchar2_table(421) := '_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created := current_timesta';
wwv_flow_imp.g_varchar2_table(422) := 'mp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    el';
wwv_flow_imp.g_varchar2_table(423) := 'se'||wwv_flow.LF||
'        :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updat';
wwv_flow_imp.g_varchar2_table(424) := 'ed := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end biu_eba_cust_impl_partn';
wwv_flow_imp.g_varchar2_table(425) := 'ers;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER biu_eba_cust_email_log'||wwv_flow.LF||
'    before insert or update on eba_cust_ema';
wwv_flow_imp.g_varchar2_table(426) := 'il_log'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        :new.id := to_number(sys_guid(),''X';
wwv_flow_imp.g_varchar2_table(427) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := current';
wwv_flow_imp.g_varchar2_table(428) := '_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'        :new.row_version_number :=';
wwv_flow_imp.g_varchar2_table(429) := ' 1;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(430) := '   end if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(431) := '    :new.email_first_to := lower(:new.email_first_to);'||wwv_flow.LF||
'    :new.email_from := lower(:new.email_from)';
wwv_flow_imp.g_varchar2_table(432) := ';'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER biu_eba_cust_activity_types'||wwv_flow.LF||
'    before insert or update on eba_c';
wwv_flow_imp.g_varchar2_table(433) := 'ust_activity_types'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(434) := '        :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(435) := ' :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'        :new';
wwv_flow_imp.g_varchar2_table(436) := '.row_version_number := 1;'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        :new.row_version_number := nvl(:new.row_version_number,0)';
wwv_flow_imp.g_varchar2_table(437) := ' + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''),us';
wwv_flow_imp.g_varchar2_table(438) := 'er);'||wwv_flow.LF||
'end biu_eba_cust_activity_types;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER biu_eba_cust_cust_partner_ref'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(439) := ' before insert or update on eba_cust_cust_partner_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(440) := '       if :new.id is null then'||wwv_flow.LF||
'            :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(441) := 'XXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nv';
wwv_flow_imp.g_varchar2_table(442) := 'l(v(''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl';
wwv_flow_imp.g_varchar2_table(443) := '(v(''APP_USER''),user);'||wwv_flow.LF||
'end biu_eba_cust_cust_partner_ref;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER au_eba_cust_cu';
wwv_flow_imp.g_varchar2_table(444) := 'st_partner_ref'||wwv_flow.LF||
'    after insert or update or delete on eba_cust_cust_partner_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'de';
wwv_flow_imp.g_varchar2_table(445) := 'clare'||wwv_flow.LF||
'    pragma autonomous_transaction;'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'    nv varchar2(4000) := nul';
wwv_flow_imp.g_varchar2_table(446) := 'l;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    ov := null; nv := null;'||wwv_flow.LF||
'    for c1 in (select name val from eba_cust_impl_partners t wh';
wwv_flow_imp.g_varchar2_table(447) := 'ere t.id = :old.partner_id) loop'||wwv_flow.LF||
'        ov := c1.val;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    for c1 in (select name val ';
wwv_flow_imp.g_varchar2_table(448) := 'from eba_cust_impl_partners t where t.id = :new.partner_id) loop'||wwv_flow.LF||
'        nv := c1.val;'||wwv_flow.LF||
'    end loop;';
wwv_flow_imp.g_varchar2_table(449) := ''||wwv_flow.LF||
'    insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_valu';
wwv_flow_imp.g_varchar2_table(450) := 'e, new_value) values'||wwv_flow.LF||
'        (''CUSTOMERS'', null, nvl(:new.customer_id,:old.customer_id), ''PARTNER_ID';
wwv_flow_imp.g_varchar2_table(451) := ''', ov, nv);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end au_eba_cust_cust_partner_ref;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER "BIU_EBA_CUST';
wwv_flow_imp.g_varchar2_table(452) := '_ISSUES" '||wwv_flow.LF||
'    before insert or update '||wwv_flow.LF||
'    on eba_cust_issues'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id ';
wwv_flow_imp.g_varchar2_table(453) := 'is null then'||wwv_flow.LF||
'        :new.id := to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end i';
wwv_flow_imp.g_varchar2_table(454) := 'f;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(v';
wwv_flow_imp.g_varchar2_table(455) := '(''APP_USER''),USER);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting or updating then'||wwv_flow.LF||
'        :new.updated := current_ti';
wwv_flow_imp.g_varchar2_table(456) := 'mestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace T';
wwv_flow_imp.g_varchar2_table(457) := 'RIGGER biu_eba_cust_administrators'||wwv_flow.LF||
'    before insert or update on eba_cust_administrators'||wwv_flow.LF||
'    for ea';
wwv_flow_imp.g_varchar2_table(458) := 'ch row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_';
wwv_flow_imp.g_varchar2_table(459) := 'guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(460) := '   end if;'||wwv_flow.LF||
'        :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),U';
wwv_flow_imp.g_varchar2_table(461) := 'SER);'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);';
wwv_flow_imp.g_varchar2_table(462) := ''||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := cur';
wwv_flow_imp.g_varchar2_table(463) := 'rent_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number ';
wwv_flow_imp.g_varchar2_table(464) := ':= nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER eba_cust_verify';
wwv_flow_imp.g_varchar2_table(465) := '_biu_fer'||wwv_flow.LF||
'    before insert or update on eba_cust_verifications'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.id ';
wwv_flow_imp.g_varchar2_table(466) := 'is null then'||wwv_flow.LF||
'        :new.id := eba_cust_seq.nextval;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.cr';
wwv_flow_imp.g_varchar2_table(467) := 'eated := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(apex_application.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(468) := '   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by :=';
wwv_flow_imp.g_varchar2_table(469) := ' nvl(apex_application.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER bd_eba_cust_contact';
wwv_flow_imp.g_varchar2_table(470) := 's'||wwv_flow.LF||
'    before delete on eba_cust_contacts'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba_cust_fw.tag_sync('||wwv_flow.LF||
'        p_';
wwv_flow_imp.g_varchar2_table(471) := 'new_tags      => null,'||wwv_flow.LF||
'        p_old_tags      => :old.tags,'||wwv_flow.LF||
'        p_content_type  => ''CONTACT'','||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(472) := '       p_content_id    => :old.id );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER biu_eba_cust_contacts'||wwv_flow.LF||
'    bef';
wwv_flow_imp.g_varchar2_table(473) := 'ore insert or update on eba_cust_contacts'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.tags is not null then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(474) := '       :new.tags := eba_cust_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        i';
wwv_flow_imp.g_varchar2_table(475) := 'f :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(476) := '             into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.CREATED := current_t';
wwv_flow_imp.g_varchar2_table(477) := 'imestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :NEW.UPDATED := current_timest';
wwv_flow_imp.g_varchar2_table(478) := 'amp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(479) := 'ba_cust_fw.tag_sync('||wwv_flow.LF||
'        p_new_tags      => :new.tags,'||wwv_flow.LF||
'        p_old_tags      => null,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(480) := 'p_content_type  => ''CONTACT'','||wwv_flow.LF||
'        p_content_id    => :new.id );'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then';
wwv_flow_imp.g_varchar2_table(481) := ''||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(482) := '    :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    eba_cust_fw.tag_sync('||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(483) := ' p_new_tags      => :new.tags,'||wwv_flow.LF||
'        p_old_tags      => :old.tags,'||wwv_flow.LF||
'        p_content_type  => ''CON';
wwv_flow_imp.g_varchar2_table(484) := 'TACT'','||wwv_flow.LF||
'        p_content_id    => :new.id );'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER au_eba_cu';
wwv_flow_imp.g_varchar2_table(485) := 'st_contacts'||wwv_flow.LF||
'    after update on eba_cust_contacts'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    ov varchar2(4000) := ';
wwv_flow_imp.g_varchar2_table(486) := 'null;'||wwv_flow.LF||
'    nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- CUSTOMER_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:old.customer';
wwv_flow_imp.g_varchar2_table(487) := '_id,-999) != nvl(:new.customer_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (sele';
wwv_flow_imp.g_varchar2_table(488) := 'ct customer_name val from eba_cust_customers t where t.id = :old.customer_id) loop'||wwv_flow.LF||
'            ov :=';
wwv_flow_imp.g_varchar2_table(489) := ' c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in (select customer_name val from eba_cust_customers t whe';
wwv_flow_imp.g_varchar2_table(490) := 're t.id = :new.customer_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba';
wwv_flow_imp.g_varchar2_table(491) := '_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values';
wwv_flow_imp.g_varchar2_table(492) := ''||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''CUSTOMER_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- NAME (default)'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(493) := '   if nvl(:old.name, ''0'') != nvl(:new.name,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_na';
wwv_flow_imp.g_varchar2_table(494) := 'me, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACT';
wwv_flow_imp.g_varchar2_table(495) := 'S'', null, :new.id, ''NAME'', substr(:old.name,0,4000), substr(:new.name,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(496) := ' TITLE (default)'||wwv_flow.LF||
'    if nvl(:old.title, ''0'') != nvl(:new.title,''0'') then '||wwv_flow.LF||
'        insert into eba_cu';
wwv_flow_imp.g_varchar2_table(497) := 'st_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(498) := '           (''CONTACTS'', null, :new.id, ''TITLE'', substr(:old.title,0,4000), substr(:new.title,0,4000)';
wwv_flow_imp.g_varchar2_table(499) := ' ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- COMPANY (default)'||wwv_flow.LF||
'    if nvl(:old.company, ''0'') != nvl(:new.company,''0'') the';
wwv_flow_imp.g_varchar2_table(500) := 'n '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, ol';
wwv_flow_imp.g_varchar2_table(501) := 'd_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''COMPANY'', substr(:old.company,0';
wwv_flow_imp.g_varchar2_table(502) := ',4000), substr(:new.company,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- ADDRESS_LINE1 (default)'||wwv_flow.LF||
'    if nvl(:old.a';
wwv_flow_imp.g_varchar2_table(503) := 'ddress_line1, ''0'') != nvl(:new.address_line1,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_';
wwv_flow_imp.g_varchar2_table(504) := 'name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTA';
wwv_flow_imp.g_varchar2_table(505) := 'CTS'', null, :new.id, ''ADDRESS_LINE1'', substr(:old.address_line1,0,4000), substr(:new.address_line1,0';
wwv_flow_imp.g_varchar2_table(506) := ',4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- ADDRESS_LINE2 (default)'||wwv_flow.LF||
'    if nvl(:old.address_line2, ''0'') != nvl(:ne';
wwv_flow_imp.g_varchar2_table(507) := 'w.address_line2,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, compo';
wwv_flow_imp.g_varchar2_table(508) := 'nent_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''ADDRESS';
wwv_flow_imp.g_varchar2_table(509) := '_LINE2'', substr(:old.address_line2,0,4000), substr(:new.address_line2,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(510) := ' CITY (default)'||wwv_flow.LF||
'    if nvl(:old.city, ''0'') != nvl(:new.city,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_';
wwv_flow_imp.g_varchar2_table(511) := 'history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(512) := '        (''CONTACTS'', null, :new.id, ''CITY'', substr(:old.city,0,4000), substr(:new.city,0,4000) ); '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(513) := '   end if;'||wwv_flow.LF||
'    -- STATE (default)'||wwv_flow.LF||
'    if nvl(:old.state, ''0'') != nvl(:new.state,''0'') then '||wwv_flow.LF||
'        i';
wwv_flow_imp.g_varchar2_table(514) := 'nsert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new';
wwv_flow_imp.g_varchar2_table(515) := '_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''STATE'', substr(:old.state,0,4000), substr(:';
wwv_flow_imp.g_varchar2_table(516) := 'new.state,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- COUNTRY (default)'||wwv_flow.LF||
'    if nvl(:old.country, ''0'') != nvl(:new';
wwv_flow_imp.g_varchar2_table(517) := '.country,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id';
wwv_flow_imp.g_varchar2_table(518) := ', column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''COUNTRY'', subs';
wwv_flow_imp.g_varchar2_table(519) := 'tr(:old.country,0,4000), substr(:new.country,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- ZIP (default)'||wwv_flow.LF||
'    if nvl';
wwv_flow_imp.g_varchar2_table(520) := '(:old.zip, ''0'') != nvl(:new.zip,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, compone';
wwv_flow_imp.g_varchar2_table(521) := 'nt_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :';
wwv_flow_imp.g_varchar2_table(522) := 'new.id, ''ZIP'', substr(:old.zip,0,4000), substr(:new.zip,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- EMAIL (defaul';
wwv_flow_imp.g_varchar2_table(523) := 't)'||wwv_flow.LF||
'    if nvl(:old.email, ''0'') != nvl(:new.email,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (ta';
wwv_flow_imp.g_varchar2_table(524) := 'ble_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''C';
wwv_flow_imp.g_varchar2_table(525) := 'ONTACTS'', null, :new.id, ''EMAIL'', substr(:old.email,0,4000), substr(:new.email,0,4000) ); '||wwv_flow.LF||
'    end i';
wwv_flow_imp.g_varchar2_table(526) := 'f;'||wwv_flow.LF||
'    -- PHONE (default)'||wwv_flow.LF||
'    if nvl(:old.phone, ''0'') != nvl(:new.phone,''0'') then '||wwv_flow.LF||
'        insert in';
wwv_flow_imp.g_varchar2_table(527) := 'to eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) ';
wwv_flow_imp.g_varchar2_table(528) := 'values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''PHONE'', substr(:old.phone,0,4000), substr(:new.phon';
wwv_flow_imp.g_varchar2_table(529) := 'e,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CELL_PHONE (default)'||wwv_flow.LF||
'    if nvl(:old.cell_phone, ''0'') != nvl(:new.c';
wwv_flow_imp.g_varchar2_table(530) := 'ell_phone,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_i';
wwv_flow_imp.g_varchar2_table(531) := 'd, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''CELL_PHONE'', ';
wwv_flow_imp.g_varchar2_table(532) := 'substr(:old.cell_phone,0,4000), substr(:new.cell_phone,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- FAX (default)'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(533) := '    if nvl(:old.fax, ''0'') != nvl(:new.fax,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_nam';
wwv_flow_imp.g_varchar2_table(534) := 'e, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS';
wwv_flow_imp.g_varchar2_table(535) := ''', null, :new.id, ''FAX'', substr(:old.fax,0,4000), substr(:new.fax,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CON';
wwv_flow_imp.g_varchar2_table(536) := 'TACT_TYPE_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:old.contact_type_id,-999) != nvl(:new.contact_type_id,-999) t';
wwv_flow_imp.g_varchar2_table(537) := 'hen'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select contact_type val from eba_cust_contact';
wwv_flow_imp.g_varchar2_table(538) := '_types t where t.id = :old.contact_type_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(539) := ' for c1 in (select contact_type val from eba_cust_contact_types t where t.id = :new.contact_type_id)';
wwv_flow_imp.g_varchar2_table(540) := ' loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name, ';
wwv_flow_imp.g_varchar2_table(541) := 'component_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            (''CONTACTS'', n';
wwv_flow_imp.g_varchar2_table(542) := 'ull, :new.id, ''CONTACT_TYPE_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- NOTES (default)'||wwv_flow.LF||
'    if nvl(:old.notes, ';
wwv_flow_imp.g_varchar2_table(543) := '''0'') != nvl(:new.notes,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey';
wwv_flow_imp.g_varchar2_table(544) := ', component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''';
wwv_flow_imp.g_varchar2_table(545) := 'NOTES'', substr(:old.notes,0,4000), substr(:new.notes,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- TAGS (default)'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(546) := '   if nvl(:old.tags, ''0'') != nvl(:new.tags,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_na';
wwv_flow_imp.g_varchar2_table(547) := 'me, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACT';
wwv_flow_imp.g_varchar2_table(548) := 'S'', null, :new.id, ''TAGS'', substr(:old.tags,0,4000), substr(:new.tags,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end au';
wwv_flow_imp.g_varchar2_table(549) := '_eba_cust_contacts;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER eba_cust_notif_biu'||wwv_flow.LF||
'before insert or update on eba_c';
wwv_flow_imp.g_varchar2_table(550) := 'ust_notifications'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        select to';
wwv_flow_imp.g_varchar2_table(551) := '_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'          into :new.id'||wwv_flow.LF||
'          from dual;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(552) := '   end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.cr';
wwv_flow_imp.g_varchar2_table(553) := 'eated := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated';
wwv_flow_imp.g_varchar2_table(554) := ' := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(555) := '  :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''A';
wwv_flow_imp.g_varchar2_table(556) := 'PP_USER''),USER);'||wwv_flow.LF||
'        :new.updated    := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.notification_';
wwv_flow_imp.g_varchar2_table(557) := 'type is null then'||wwv_flow.LF||
'       :new.notification_type := ''MANUAL'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace T';
wwv_flow_imp.g_varchar2_table(558) := 'RIGGER "BIU_EBA_CUST_ISSUE_STATUSES" '||wwv_flow.LF||
'    before insert or update '||wwv_flow.LF||
'    on eba_cust_issue_statuses'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(559) := '  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        :new.id := to_number(sys_guid(), ''XXXXXXXXX';
wwv_flow_imp.g_varchar2_table(560) := 'XXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := current_timesta';
wwv_flow_imp.g_varchar2_table(561) := 'mp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting or updating the';
wwv_flow_imp.g_varchar2_table(562) := 'n'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(563) := ' end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER eba_cust_acl_features_biu'||wwv_flow.LF||
'    before insert or update on ';
wwv_flow_imp.g_varchar2_table(564) := 'eba_cust_acl_features'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  -- Always store authorization_name as upper case'||wwv_flow.LF||
'  :n';
wwv_flow_imp.g_varchar2_table(565) := 'ew.authorization_name := upper(:new.authorization_name);'||wwv_flow.LF||
'  if inserting then'||wwv_flow.LF||
'    if :new.id is null ';
wwv_flow_imp.g_varchar2_table(566) := 'then'||wwv_flow.LF||
'      :new.id := eba_cust.gen_id();'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.created_by         := nvl(v(''APP_USER''';
wwv_flow_imp.g_varchar2_table(567) := '), USER);'||wwv_flow.LF||
'    :new.created            := current_timestamp;'||wwv_flow.LF||
'    :new.row_version        := 1;'||wwv_flow.LF||
'  elsi';
wwv_flow_imp.g_varchar2_table(568) := 'f updating then'||wwv_flow.LF||
'    :new.row_version        := nvl(:old.row_version,1) + 1;                         ';
wwv_flow_imp.g_varchar2_table(569) := '       '||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
'  :new.updated_by         := nvl(v(''APP_USER''), USER);'||wwv_flow.LF||
'  :new.updated            :';
wwv_flow_imp.g_varchar2_table(570) := '= current_timestamp;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER eba_cust_clicks_biu'||wwv_flow.LF||
'    before insert on eba_';
wwv_flow_imp.g_varchar2_table(571) := 'cust_clicks'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'     if :new.id is null then'||wwv_flow.LF||
'         :new.id := eba_cust_seq.nex';
wwv_flow_imp.g_varchar2_table(572) := 'tval;'||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'     :new.view_timestamp := current_timestamp;'||wwv_flow.LF||
'     :new.app_username := nvl(v(''A';
wwv_flow_imp.g_varchar2_table(573) := 'PP_USER''),user);'||wwv_flow.LF||
'     :new.app_session := v(''APP_SESSION'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER eba_cu';
wwv_flow_imp.g_varchar2_table(574) := 'st_feedback_biu'||wwv_flow.LF||
'    before insert or update '||wwv_flow.LF||
'    on eba_cust_feedback'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if ';
wwv_flow_imp.g_varchar2_table(575) := ':new.id is null then'||wwv_flow.LF||
'        :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(576) := '  end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by :';
wwv_flow_imp.g_varchar2_table(577) := '= NVL(V(''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by :=';
wwv_flow_imp.g_varchar2_table(578) := ' NVL(V(''APP_USER''),user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER bi_eba_cust_views_log'||wwv_flow.LF||
'    before insert ';
wwv_flow_imp.g_varchar2_table(579) := 'on eba_cust_views_log'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :NEW.ID is null then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(580) := '           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :new.i';
wwv_flow_imp.g_varchar2_table(581) := 'd'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        End if;'||wwv_flow.LF||
'        :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.C';
wwv_flow_imp.g_varchar2_table(582) := 'REATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATE';
wwv_flow_imp.g_varchar2_table(583) := 'D_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if updating ';
wwv_flow_imp.g_varchar2_table(584) := 'then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(585) := '        :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or';
wwv_flow_imp.g_varchar2_table(586) := ' replace TRIGGER biu_eba_cust_links'||wwv_flow.LF||
'    before insert or update on eba_cust_links'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'b';
wwv_flow_imp.g_varchar2_table(587) := 'egin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''';
wwv_flow_imp.g_varchar2_table(588) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end i';
wwv_flow_imp.g_varchar2_table(589) := 'f;'||wwv_flow.LF||
'        :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(590) := '      :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(591) := ' :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := current_time';
wwv_flow_imp.g_varchar2_table(592) := 'stamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:n';
wwv_flow_imp.g_varchar2_table(593) := 'ew.row_version_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER biu_eba_cust_geographies';
wwv_flow_imp.g_varchar2_table(594) := ''||wwv_flow.LF||
'    before insert or update on eba_cust_geographies'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(595) := '      if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(596) := 'XXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.CREATED := cu';
wwv_flow_imp.g_varchar2_table(597) := 'rrent_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :NEW.UPDATED := current';
wwv_flow_imp.g_varchar2_table(598) := '_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := 1';
wwv_flow_imp.g_varchar2_table(599) := ';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_B';
wwv_flow_imp.g_varchar2_table(600) := 'Y := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:new.row_version_number,0) + 1;';
wwv_flow_imp.g_varchar2_table(601) := ''||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER biu_eba_cust_ref_phase'||wwv_flow.LF||
'    before insert or update on';
wwv_flow_imp.g_varchar2_table(602) := ' eba_cust_ref_phase'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'      if :NEW.ID is null then'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(603) := '  select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'          into :new.id'||wwv_flow.LF||
'          f';
wwv_flow_imp.g_varchar2_table(604) := 'rom dual;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'      :NEW.CREATED_BY := nvl(v(''APP';
wwv_flow_imp.g_varchar2_table(605) := '_USER''),USER);'||wwv_flow.LF||
'      :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'      :NEW.UPDATED_BY := nvl(v(''APP_USER''),U';
wwv_flow_imp.g_varchar2_table(606) := 'SER);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if updating then'||wwv_flow.LF||
'      :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'      :NEW.UPDATED_BY ';
wwv_flow_imp.g_varchar2_table(607) := ':= nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER biu_eba_cust_industries'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(608) := ' before insert or update on eba_cust_industries'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(609) := ' if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')';
wwv_flow_imp.g_varchar2_table(610) := ''||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.CREATED := current';
wwv_flow_imp.g_varchar2_table(611) := '_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :NEW.UPDATED := current_time';
wwv_flow_imp.g_varchar2_table(612) := 'stamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(613) := ' end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := ';
wwv_flow_imp.g_varchar2_table(614) := 'nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(615) := 'end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER eba_cust_tags_biu'||wwv_flow.LF||
'    before insert or update on eba_cust_';
wwv_flow_imp.g_varchar2_table(616) := 'tags'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    :new.tag := upper(:new.tag);'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'       if :NEW.TA';
wwv_flow_imp.g_varchar2_table(617) := 'G_ID is null then'||wwv_flow.LF||
'          select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(618) := '    into :new.tag_id'||wwv_flow.LF||
'            from dual;'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       :NEW.CREATED := current_timestamp;';
wwv_flow_imp.g_varchar2_table(619) := ''||wwv_flow.LF||
'       :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'       :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(620) := ' :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'  '||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'       :NEW.UPDATED';
wwv_flow_imp.g_varchar2_table(621) := ' := current_timestamp;'||wwv_flow.LF||
'       :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create';
wwv_flow_imp.g_varchar2_table(622) := ' or replace TRIGGER biu_eba_cust_competitors'||wwv_flow.LF||
'    before insert or update on eba_cust_competitors'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(623) := ' for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            :new.id := to_';
wwv_flow_imp.g_varchar2_table(624) := 'number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created := curre';
wwv_flow_imp.g_varchar2_table(625) := 'nt_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'        :new.row_version_number :=';
wwv_flow_imp.g_varchar2_table(626) := ' 1;'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(627) := ':new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end biu_eba_cust_';
wwv_flow_imp.g_varchar2_table(628) := 'competitors;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER au_eba_cust_competitors'||wwv_flow.LF||
'    after update on eba_cust_compe';
wwv_flow_imp.g_varchar2_table(629) := 'titors'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    pragma autonomous_transaction;'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(630) := '  nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- NAME (default)'||wwv_flow.LF||
'    if nvl(:old.name, ''0'') != nvl(:new.name';
wwv_flow_imp.g_varchar2_table(631) := ',''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column';
wwv_flow_imp.g_varchar2_table(632) := '_name, old_value, new_value) values '||wwv_flow.LF||
'            (''COMPETITORS'', null, :new.id, ''NAME'', substr(:old.';
wwv_flow_imp.g_varchar2_table(633) := 'name,0,4000), substr(:new.name,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- DESCRIPTION (default)'||wwv_flow.LF||
'    if nvl(:old.';
wwv_flow_imp.g_varchar2_table(634) := 'description, ''0'') != nvl(:new.description,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_nam';
wwv_flow_imp.g_varchar2_table(635) := 'e, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''COMPETIT';
wwv_flow_imp.g_varchar2_table(636) := 'ORS'', null, :new.id, ''DESCRIPTION'', substr(:old.description,0,4000), substr(:new.description,0,4000)';
wwv_flow_imp.g_varchar2_table(637) := ' ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- WEBSITE (default)'||wwv_flow.LF||
'    if nvl(:old.website, ''0'') != nvl(:new.website,''0'') the';
wwv_flow_imp.g_varchar2_table(638) := 'n '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, ol';
wwv_flow_imp.g_varchar2_table(639) := 'd_value, new_value) values '||wwv_flow.LF||
'            (''COMPETITORS'', null, :new.id, ''WEBSITE'', substr(:old.websit';
wwv_flow_imp.g_varchar2_table(640) := 'e,0,4000), substr(:new.website,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end au_eba_cust_competitors;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'c';
wwv_flow_imp.g_varchar2_table(641) := 'reate or replace TRIGGER au_eba_cust_customers'||wwv_flow.LF||
'    after update on eba_cust_customers'||wwv_flow.LF||
'    for each r';
wwv_flow_imp.g_varchar2_table(642) := 'ow'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'    nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- CUSTOMER_NAME ';
wwv_flow_imp.g_varchar2_table(643) := '(default)'||wwv_flow.LF||
'    if nvl(:old.customer_name, ''0'') != nvl(:new.customer_name,''0'') then '||wwv_flow.LF||
'        insert in';
wwv_flow_imp.g_varchar2_table(644) := 'to eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) ';
wwv_flow_imp.g_varchar2_table(645) := 'values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''CUSTOMER_NAME'', substr(:old.customer_name,';
wwv_flow_imp.g_varchar2_table(646) := '0,4000), substr(:new.customer_name,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CUSTOMER_NAME_UPPER (default)'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(647) := 'if nvl(:old.customer_name_upper, ''0'') != nvl(:new.customer_name_upper,''0'') then '||wwv_flow.LF||
'        insert into';
wwv_flow_imp.g_varchar2_table(648) := ' eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) va';
wwv_flow_imp.g_varchar2_table(649) := 'lues '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''CUSTOMER_NAME_UPPER'', substr(:old.customer_n';
wwv_flow_imp.g_varchar2_table(650) := 'ame_upper,0,4000), substr(:new.customer_name_upper,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- INDUSTRY_ID (forei';
wwv_flow_imp.g_varchar2_table(651) := 'gn key)'||wwv_flow.LF||
'    if nvl(:old.industry_id,-999) != nvl(:new.industry_id,-999) then'||wwv_flow.LF||
'        ov := null; nv ';
wwv_flow_imp.g_varchar2_table(652) := ':= null;'||wwv_flow.LF||
'        for c1 in (select industry_name val from eba_cust_industries t where t.id = :old.in';
wwv_flow_imp.g_varchar2_table(653) := 'dustry_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in (select industry_name ';
wwv_flow_imp.g_varchar2_table(654) := 'val from eba_cust_industries t where t.id = :new.industry_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(655) := ' end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_';
wwv_flow_imp.g_varchar2_table(656) := 'name, old_value, new_value) values'||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''INDUSTRY_ID'', o';
wwv_flow_imp.g_varchar2_table(657) := 'v, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CATEGORY_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:old.category_id,-999) != nvl(:new.c';
wwv_flow_imp.g_varchar2_table(658) := 'ategory_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select category val from eb';
wwv_flow_imp.g_varchar2_table(659) := 'a_cust_categories t where t.id = :old.category_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(660) := '        for c1 in (select category val from eba_cust_categories t where t.id = :new.category_id) loo';
wwv_flow_imp.g_varchar2_table(661) := 'p'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name, comp';
wwv_flow_imp.g_varchar2_table(662) := 'onent_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            (''CUSTOMERS'', :new';
wwv_flow_imp.g_varchar2_table(663) := '.row_key, :new.id, ''CATEGORY_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- STATUS_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:ol';
wwv_flow_imp.g_varchar2_table(664) := 'd.status_id,-999) != nvl(:new.status_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in';
wwv_flow_imp.g_varchar2_table(665) := ' (select status val from eba_cust_status t where t.id = :old.status_id) loop'||wwv_flow.LF||
'            ov := c1.va';
wwv_flow_imp.g_varchar2_table(666) := 'l;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in (select status val from eba_cust_status t where t.id = :new.s';
wwv_flow_imp.g_varchar2_table(667) := 'tatus_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (tab';
wwv_flow_imp.g_varchar2_table(668) := 'le_name, component_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            (''CUS';
wwv_flow_imp.g_varchar2_table(669) := 'TOMERS'', :new.row_key, :new.id, ''STATUS_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- GEOGRAPHY_ID (foreign key)'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(670) := '    if nvl(:old.geography_id,-999) != nvl(:new.geography_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := nul';
wwv_flow_imp.g_varchar2_table(671) := 'l;'||wwv_flow.LF||
'        for c1 in (select geography_name val from eba_cust_geographies t where t.id = :old.geogra';
wwv_flow_imp.g_varchar2_table(672) := 'phy_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in (select geography_name va';
wwv_flow_imp.g_varchar2_table(673) := 'l from eba_cust_geographies t where t.id = :new.geography_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(674) := ' end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_';
wwv_flow_imp.g_varchar2_table(675) := 'name, old_value, new_value) values'||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''GEOGRAPHY_ID'', ';
wwv_flow_imp.g_varchar2_table(676) := 'ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- REFERENCABLE (default)'||wwv_flow.LF||
'    if nvl(:old.referencable, ''0'') != nvl(:new.re';
wwv_flow_imp.g_varchar2_table(677) := 'ferencable,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_';
wwv_flow_imp.g_varchar2_table(678) := 'id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''REF';
wwv_flow_imp.g_varchar2_table(679) := 'ERENCABLE'', substr(:old.referencable,0,4000), substr(:new.referencable,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(680) := '- MARQUEE_CUSTOMER_YN (default)'||wwv_flow.LF||
'    if nvl(:old.marquee_customer_yn, ''0'') != nvl(:new.marquee_custom';
wwv_flow_imp.g_varchar2_table(681) := 'er_yn,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, c';
wwv_flow_imp.g_varchar2_table(682) := 'olumn_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''MARQUEE_';
wwv_flow_imp.g_varchar2_table(683) := 'CUSTOMER'', substr(:old.marquee_customer_yn,0,4000), substr(:new.marquee_customer_yn,0,4000) ); '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(684) := 'end if;'||wwv_flow.LF||
'    -- TAGS (default)'||wwv_flow.LF||
'    if nvl(:old.tags, ''0'') != nvl(:new.tags,''0'') then '||wwv_flow.LF||
'        insert ';
wwv_flow_imp.g_varchar2_table(685) := 'into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value';
wwv_flow_imp.g_varchar2_table(686) := ') values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''TAGS'', substr(:old.tags,0,4000), substr(';
wwv_flow_imp.g_varchar2_table(687) := ':new.tags,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CUSTOMER_PRODUCTS (default)'||wwv_flow.LF||
'    if nvl(:old.customer_produc';
wwv_flow_imp.g_varchar2_table(688) := 'ts, ''0'') != nvl(:new.customer_products,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, ';
wwv_flow_imp.g_varchar2_table(689) := 'component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'',';
wwv_flow_imp.g_varchar2_table(690) := ' :new.row_key, :new.id, ''CUSTOMER_PRODUCTS'', substr(:old.customer_products,0,4000), substr(:new.cust';
wwv_flow_imp.g_varchar2_table(691) := 'omer_products,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- NUMBER_OF_USERS (default)'||wwv_flow.LF||
'    if nvl(:old.number_of_use';
wwv_flow_imp.g_varchar2_table(692) := 'rs, ''0'') != nvl(:new.number_of_users,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, co';
wwv_flow_imp.g_varchar2_table(693) := 'mponent_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :';
wwv_flow_imp.g_varchar2_table(694) := 'new.row_key, :new.id, ''NUMBER_OF_USERS'', substr(:old.number_of_users,0,4000), substr(:new.number_of_';
wwv_flow_imp.g_varchar2_table(695) := 'users,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- SUMMARY (default)'||wwv_flow.LF||
'    if nvl(:old.summary, ''0'') != nvl(:new.sum';
wwv_flow_imp.g_varchar2_table(696) := 'mary,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, co';
wwv_flow_imp.g_varchar2_table(697) := 'lumn_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''SUMMARY'',';
wwv_flow_imp.g_varchar2_table(698) := ' substr(:old.summary,0,4000), substr(:new.summary,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CUSTOMER_PROFILE (d';
wwv_flow_imp.g_varchar2_table(699) := 'efault)'||wwv_flow.LF||
'    if nvl(:old.customer_profile, ''0'') != nvl(:new.customer_profile,''0'') then '||wwv_flow.LF||
'        inser';
wwv_flow_imp.g_varchar2_table(700) := 't into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_val';
wwv_flow_imp.g_varchar2_table(701) := 'ue) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''CUSTOMER_PROFILE'', substr(:old.custome';
wwv_flow_imp.g_varchar2_table(702) := 'r_profile,0,4000), substr(:new.customer_profile,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- APPLICATIONS (default';
wwv_flow_imp.g_varchar2_table(703) := ')'||wwv_flow.LF||
'    if nvl(:old.applications, ''0'') != nvl(:new.applications,''0'') then '||wwv_flow.LF||
'        insert into eba_cus';
wwv_flow_imp.g_varchar2_table(704) := 't_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(705) := '          (''CUSTOMERS'', :new.row_key, :new.id, ''APPLICATIONS'', substr(:old.applications,0,4000), sub';
wwv_flow_imp.g_varchar2_table(706) := 'str(:new.applications,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- WEB_SITE (default)'||wwv_flow.LF||
'    if nvl(:old.web_site, ''0';
wwv_flow_imp.g_varchar2_table(707) := ''') != nvl(:new.web_site,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowke';
wwv_flow_imp.g_varchar2_table(708) := 'y, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, ';
wwv_flow_imp.g_varchar2_table(709) := ':new.id, ''WEB_SITE'', substr(:old.web_site,0,4000), substr(:new.web_site,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(710) := '-- LINKEDIN (default)'||wwv_flow.LF||
'    if nvl(:old.linkedin, ''0'') != nvl(:new.linkedin,''0'') then '||wwv_flow.LF||
'        insert ';
wwv_flow_imp.g_varchar2_table(711) := 'into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value';
wwv_flow_imp.g_varchar2_table(712) := ') values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''LINKEDIN'', substr(:old.linkedin,0,4000),';
wwv_flow_imp.g_varchar2_table(713) := ' substr(:new.linkedin,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- FACEBOOK (default)'||wwv_flow.LF||
'    if nvl(:old.facebook, ''0';
wwv_flow_imp.g_varchar2_table(714) := ''') != nvl(:new.facebook,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowke';
wwv_flow_imp.g_varchar2_table(715) := 'y, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, ';
wwv_flow_imp.g_varchar2_table(716) := ':new.id, ''FACEBOOK'', substr(:old.facebook,0,4000), substr(:new.facebook,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(717) := '-- TWITTER (default)'||wwv_flow.LF||
'    if nvl(:old.twitter, ''0'') != nvl(:new.twitter,''0'') then '||wwv_flow.LF||
'        insert int';
wwv_flow_imp.g_varchar2_table(718) := 'o eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) v';
wwv_flow_imp.g_varchar2_table(719) := 'alues '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''TWITTER'', substr(:old.twitter,0,4000), subs';
wwv_flow_imp.g_varchar2_table(720) := 'tr(:new.twitter,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- STOCK_SYMBOL (default)'||wwv_flow.LF||
'    if nvl(:old.stock_symbol, ';
wwv_flow_imp.g_varchar2_table(721) := '''0'') != nvl(:new.stock_symbol,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component';
wwv_flow_imp.g_varchar2_table(722) := '_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row';
wwv_flow_imp.g_varchar2_table(723) := '_key, :new.id, ''STOCK_SYMBOL'', substr(:old.stock_symbol,0,4000), substr(:new.stock_symbol,0,4000) );';
wwv_flow_imp.g_varchar2_table(724) := ' '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- SIC (default)'||wwv_flow.LF||
'    if nvl(:old.sic, ''0'') != nvl(:new.sic,''0'') then '||wwv_flow.LF||
'        inse';
wwv_flow_imp.g_varchar2_table(725) := 'rt into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_va';
wwv_flow_imp.g_varchar2_table(726) := 'lue) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''SIC'', substr(:old.sic,0,4000), substr';
wwv_flow_imp.g_varchar2_table(727) := '(:new.sic,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- DUNS (default)'||wwv_flow.LF||
'    if nvl(:old.duns, ''0'') != nvl(:new.duns,';
wwv_flow_imp.g_varchar2_table(728) := '''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_';
wwv_flow_imp.g_varchar2_table(729) := 'name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''DUNS'', substr(';
wwv_flow_imp.g_varchar2_table(730) := ':old.duns,0,4000), substr(:new.duns,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end au_eba_cust_customers;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or ';
wwv_flow_imp.g_varchar2_table(731) := 'replace TRIGGER ad_eba_cust_customers'||wwv_flow.LF||
'    after delete on eba_cust_customers'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(732) := '    insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value';
wwv_flow_imp.g_varchar2_table(733) := ', new_value)'||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (''CUSTOMERS'', :old.row_key, :old.id, ''CUSTOMER_REMOVED'', substr(:old.cu';
wwv_flow_imp.g_varchar2_table(734) := 'stomer_name,0,4000), null ); '||wwv_flow.LF||
'end ad_eba_cust_customers;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER biu_eba_cust_c';
wwv_flow_imp.g_varchar2_table(735) := 'ustomers'||wwv_flow.LF||
'   before insert or update on eba_cust_customers'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    ov varchar2(40';
wwv_flow_imp.g_varchar2_table(736) := '00) := null;'||wwv_flow.LF||
'    nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.tags is not null then'||wwv_flow.LF||
'         :new.tag';
wwv_flow_imp.g_varchar2_table(737) := 's := eba_cust_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'      if :NEW.ID is null t';
wwv_flow_imp.g_varchar2_table(738) := 'hen'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'        into :new.id'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(739) := '     from dual;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'      :NEW.CREATED_BY := nvl(';
wwv_flow_imp.g_varchar2_table(740) := 'v(''APP_USER''),USER);'||wwv_flow.LF||
'      :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'      :NEW.UPDATED_BY := nvl(v(''APP_US';
wwv_flow_imp.g_varchar2_table(741) := 'ER''),USER);'||wwv_flow.LF||
'      :new.row_version_number := 1;'||wwv_flow.LF||
'      :new.customer_name_upper := trim(upper(:new.cu';
wwv_flow_imp.g_varchar2_table(742) := 'stomer_name));'||wwv_flow.LF||
'      eba_cust_fw.tag_sync('||wwv_flow.LF||
'         p_new_tags      => :new.tags,'||wwv_flow.LF||
'         p_old_tag';
wwv_flow_imp.g_varchar2_table(743) := 's      => null,'||wwv_flow.LF||
'         p_content_type  => ''CUSTOMER'','||wwv_flow.LF||
'         p_content_id    => :new.id );'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(744) := ' -- Add new column values into history table'||wwv_flow.LF||
'      -- CUSTOMER_NAME (default)'||wwv_flow.LF||
'      if nvl(:old.cust';
wwv_flow_imp.g_varchar2_table(745) := 'omer_name, ''0'') != nvl(:new.customer_name,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_nam';
wwv_flow_imp.g_varchar2_table(746) := 'e, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMER';
wwv_flow_imp.g_varchar2_table(747) := 'S'', :new.row_key, :new.id, ''CUSTOMER_NAME'', null, substr(:new.customer_name,0,4000) ); '||wwv_flow.LF||
'      end if';
wwv_flow_imp.g_varchar2_table(748) := ';'||wwv_flow.LF||
'      -- CUSTOMER_NAME_UPPER (default)'||wwv_flow.LF||
'      if nvl(:old.customer_name_upper, ''0'') != nvl(:new.cus';
wwv_flow_imp.g_varchar2_table(749) := 'tomer_name_upper,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, comp';
wwv_flow_imp.g_varchar2_table(750) := 'onent_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id';
wwv_flow_imp.g_varchar2_table(751) := ', ''CUSTOMER_NAME_UPPER'', null, substr(:new.customer_name_upper,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- IN';
wwv_flow_imp.g_varchar2_table(752) := 'DUSTRY_ID (foreign key)'||wwv_flow.LF||
'      if nvl(:old.industry_id,-999) != nvl(:new.industry_id,-999) then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(753) := '   ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select industry_name val from eba_cust_industries t wh';
wwv_flow_imp.g_varchar2_table(754) := 'ere t.id = :new.industry_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eb';
wwv_flow_imp.g_varchar2_table(755) := 'a_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) value';
wwv_flow_imp.g_varchar2_table(756) := 's'||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''INDUSTRY_ID'', ov, nv);'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- CA';
wwv_flow_imp.g_varchar2_table(757) := 'TEGORY_ID (foreign key)'||wwv_flow.LF||
'      if nvl(:old.category_id,-999) != nvl(:new.category_id,-999) then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(758) := '   ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select category val from eba_cust_categories t where t';
wwv_flow_imp.g_varchar2_table(759) := '.id = :new.category_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cus';
wwv_flow_imp.g_varchar2_table(760) := 't_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(761) := '         (''CUSTOMERS'', :new.row_key, :new.id, ''CATEGORY_ID'', ov, nv);'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- STATUS_';
wwv_flow_imp.g_varchar2_table(762) := 'ID (foreign key)'||wwv_flow.LF||
'      if nvl(:old.status_id,-999) != nvl(:new.status_id,-999) then'||wwv_flow.LF||
'        ov := nu';
wwv_flow_imp.g_varchar2_table(763) := 'll; nv := null;'||wwv_flow.LF||
'        for c1 in (select status val from eba_cust_status t where t.id = :new.status';
wwv_flow_imp.g_varchar2_table(764) := '_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_na';
wwv_flow_imp.g_varchar2_table(765) := 'me, component_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            (''CUSTOMER';
wwv_flow_imp.g_varchar2_table(766) := 'S'', :new.row_key, :new.id, ''STATUS_ID'', ov, nv);'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- GEOGRAPHY_ID (foreign key)'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(767) := '     if nvl(:old.geography_id,-999) != nvl(:new.geography_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := nu';
wwv_flow_imp.g_varchar2_table(768) := 'll;'||wwv_flow.LF||
'        for c1 in (select geography_name val from eba_cust_geographies t where t.id = :new.geogr';
wwv_flow_imp.g_varchar2_table(769) := 'aphy_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (tabl';
wwv_flow_imp.g_varchar2_table(770) := 'e_name, component_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            (''CUST';
wwv_flow_imp.g_varchar2_table(771) := 'OMERS'', :new.row_key, :new.id, ''GEOGRAPHY_ID'', ov, nv);'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- REFERENCABLE (default';
wwv_flow_imp.g_varchar2_table(772) := ')'||wwv_flow.LF||
'      if nvl(:old.referencable, ''0'') != nvl(:new.referencable,''0'') then '||wwv_flow.LF||
'        insert into eba_c';
wwv_flow_imp.g_varchar2_table(773) := 'ust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(774) := '            (''CUSTOMERS'', :new.row_key, :new.id, ''REFERENCABLE'', null, substr(:new.referencable,0,40';
wwv_flow_imp.g_varchar2_table(775) := '00) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- MARQUEE_CUSTOMER_YN (default)'||wwv_flow.LF||
'      if nvl(:old.marquee_customer_yn, ';
wwv_flow_imp.g_varchar2_table(776) := '''0'') != nvl(:new.marquee_customer_yn,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, co';
wwv_flow_imp.g_varchar2_table(777) := 'mponent_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :';
wwv_flow_imp.g_varchar2_table(778) := 'new.row_key, :new.id, ''MARQUEE_CUSTOMER'', null, substr(:new.marquee_customer_yn,0,4000) ); '||wwv_flow.LF||
'      en';
wwv_flow_imp.g_varchar2_table(779) := 'd if;'||wwv_flow.LF||
'      -- TAGS (default)'||wwv_flow.LF||
'      if nvl(:old.tags, ''0'') != nvl(:new.tags,''0'') then '||wwv_flow.LF||
'        inser';
wwv_flow_imp.g_varchar2_table(780) := 't into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_val';
wwv_flow_imp.g_varchar2_table(781) := 'ue) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''TAGS'', null, substr(:new.tags,0,4000) ';
wwv_flow_imp.g_varchar2_table(782) := '); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- CUSTOMER_PRODUCTS (default)'||wwv_flow.LF||
'      if nvl(:old.customer_products, ''0'') != ';
wwv_flow_imp.g_varchar2_table(783) := 'nvl(:new.customer_products,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_ro';
wwv_flow_imp.g_varchar2_table(784) := 'wkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_ke';
wwv_flow_imp.g_varchar2_table(785) := 'y, :new.id, ''CUSTOMER_PRODUCTS'', null, substr(:new.customer_products,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(786) := ' -- NUMBER_OF_USERS (default)'||wwv_flow.LF||
'      if nvl(:old.number_of_users, ''0'') != nvl(:new.number_of_users,''0';
wwv_flow_imp.g_varchar2_table(787) := ''') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_na';
wwv_flow_imp.g_varchar2_table(788) := 'me, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''NUMBER_OF_USERS''';
wwv_flow_imp.g_varchar2_table(789) := ', null, substr(:new.number_of_users,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- SUMMARY (default)'||wwv_flow.LF||
'      if nv';
wwv_flow_imp.g_varchar2_table(790) := 'l(:old.summary, ''0'') != nvl(:new.summary,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name';
wwv_flow_imp.g_varchar2_table(791) := ', component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS';
wwv_flow_imp.g_varchar2_table(792) := ''', :new.row_key, :new.id, ''SUMMARY'', null, substr(:new.summary,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- CU';
wwv_flow_imp.g_varchar2_table(793) := 'STOMER_PROFILE (default)'||wwv_flow.LF||
'      if nvl(:old.customer_profile, ''0'') != nvl(:new.customer_profile,''0'') ';
wwv_flow_imp.g_varchar2_table(794) := 'then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_name,';
wwv_flow_imp.g_varchar2_table(795) := ' old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''CUSTOMER_PROFILE'', ';
wwv_flow_imp.g_varchar2_table(796) := 'null, substr(:new.customer_profile,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- APPLICATIONS (default)'||wwv_flow.LF||
'      i';
wwv_flow_imp.g_varchar2_table(797) := 'f nvl(:old.applications, ''0'') != nvl(:new.applications,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_histo';
wwv_flow_imp.g_varchar2_table(798) := 'ry (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(799) := '   (''CUSTOMERS'', :new.row_key, :new.id, ''APPLICATIONS'', null, substr(:new.applications,0,4000) ); '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(800) := '     end if;'||wwv_flow.LF||
'      -- WEB_SITE (default)'||wwv_flow.LF||
'      if nvl(:old.web_site, ''0'') != nvl(:new.web_site,''0'') ';
wwv_flow_imp.g_varchar2_table(801) := 'then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_name,';
wwv_flow_imp.g_varchar2_table(802) := ' old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''WEB_SITE'', null, su';
wwv_flow_imp.g_varchar2_table(803) := 'bstr(:new.web_site,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- LINKEDIN (default)'||wwv_flow.LF||
'      if nvl(:old.linkedin,';
wwv_flow_imp.g_varchar2_table(804) := ' ''0'') != nvl(:new.linkedin,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_ro';
wwv_flow_imp.g_varchar2_table(805) := 'wkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_ke';
wwv_flow_imp.g_varchar2_table(806) := 'y, :new.id, ''LINKEDIN'', null, substr(:new.linkedin,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- FACEBOOK (defa';
wwv_flow_imp.g_varchar2_table(807) := 'ult)'||wwv_flow.LF||
'      if nvl(:old.facebook, ''0'') != nvl(:new.facebook,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_h';
wwv_flow_imp.g_varchar2_table(808) := 'istory (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(809) := '       (''CUSTOMERS'', :new.row_key, :new.id, ''FACEBOOK'', null, substr(:new.facebook,0,4000) ); '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(810) := ' end if;'||wwv_flow.LF||
'      -- TWITTER (default)'||wwv_flow.LF||
'      if nvl(:old.twitter, ''0'') != nvl(:new.twitter,''0'') then '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(811) := '       insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_va';
wwv_flow_imp.g_varchar2_table(812) := 'lue, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''TWITTER'', null, substr(:ne';
wwv_flow_imp.g_varchar2_table(813) := 'w.twitter,0,4000) ); '||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'      -- STOCK_SYMBOL (default)'||wwv_flow.LF||
'      if nvl(:old.stock_symbol, ''';
wwv_flow_imp.g_varchar2_table(814) := '0'') != nvl(:new.stock_symbol,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_';
wwv_flow_imp.g_varchar2_table(815) := 'rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_';
wwv_flow_imp.g_varchar2_table(816) := 'key, :new.id, ''STOCK_SYMBOL'', null, substr(:new.stock_symbol,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      -- SIC ';
wwv_flow_imp.g_varchar2_table(817) := '(default)'||wwv_flow.LF||
'      if nvl(:old.sic, ''0'') != nvl(:new.sic,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_histor';
wwv_flow_imp.g_varchar2_table(818) := 'y (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(819) := '  (''CUSTOMERS'', :new.row_key, :new.id, ''SIC'', null, substr(:new.sic,0,4000) ); '||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(820) := '-- DUNS (default)'||wwv_flow.LF||
'      if nvl(:old.duns, ''0'') != nvl(:new.duns,''0'') then '||wwv_flow.LF||
'        insert into eba_c';
wwv_flow_imp.g_varchar2_table(821) := 'ust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(822) := '            (''CUSTOMERS'', :new.row_key, :new.id, ''DUNS'', null, substr(:new.duns,0,4000) ); '||wwv_flow.LF||
'      en';
wwv_flow_imp.g_varchar2_table(823) := 'd if;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if :new.row_key is null then'||wwv_flow.LF||
'      select eba_cust_fw.compress_int(eba_cust_seq.';
wwv_flow_imp.g_varchar2_table(824) := 'nextval) into :new.row_key from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if updating then'||wwv_flow.LF||
'      :NEW.UPDATED := current_t';
wwv_flow_imp.g_varchar2_table(825) := 'imestamp;'||wwv_flow.LF||
'      :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'      :new.row_version_number := nvl(:ne';
wwv_flow_imp.g_varchar2_table(826) := 'w.row_version_number,0) + 1;'||wwv_flow.LF||
'      :new.customer_name_upper := trim(upper(:new.customer_name));'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(827) := ' eba_cust_fw.tag_sync('||wwv_flow.LF||
'         p_new_tags      => :new.tags,'||wwv_flow.LF||
'         p_old_tags      => :old.tags,';
wwv_flow_imp.g_varchar2_table(828) := ''||wwv_flow.LF||
'         p_content_type  => ''CUSTOMER'','||wwv_flow.LF||
'         p_content_id    => :new.id );'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'c';
wwv_flow_imp.g_varchar2_table(829) := 'reate or replace TRIGGER BIU_EBA_CUST_NOTES '||wwv_flow.LF||
'    before insert or update on EBA_CUST_NOTES'||wwv_flow.LF||
'    for e';
wwv_flow_imp.g_varchar2_table(830) := 'ach row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(831) := 'XXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_t';
wwv_flow_imp.g_varchar2_table(832) := 'imestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_timest';
wwv_flow_imp.g_varchar2_table(833) := 'amp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   el';
wwv_flow_imp.g_varchar2_table(834) := 'sif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(835) := '  if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := ';
wwv_flow_imp.g_varchar2_table(836) := 'nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER biu_eba_cust_countries'||wwv_flow.LF||
'    b';
wwv_flow_imp.g_varchar2_table(837) := 'efore insert or update on eba_cust_countries'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is null then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(838) := 'select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(839) := '  if inserting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow';
wwv_flow_imp.g_varchar2_table(840) := '.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_us';
wwv_flow_imp.g_varchar2_table(841) := 'er,user);'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number';
wwv_flow_imp.g_varchar2_table(842) := ' := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.upda';
wwv_flow_imp.g_varchar2_table(843) := 'ted := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if :new';
wwv_flow_imp.g_varchar2_table(844) := '.display_yn is null then '||wwv_flow.LF||
'      :new.display_yn := ''Y'';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER';
wwv_flow_imp.g_varchar2_table(845) := ' biu_eba_cust_contact_types'||wwv_flow.LF||
'    before insert or update on eba_cust_contact_types'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'b';
wwv_flow_imp.g_varchar2_table(846) := 'egin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''';
wwv_flow_imp.g_varchar2_table(847) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end i';
wwv_flow_imp.g_varchar2_table(848) := 'f;'||wwv_flow.LF||
'        :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(849) := '      :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(850) := ' :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :NEW.UPDATED := current_time';
wwv_flow_imp.g_varchar2_table(851) := 'stamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := nvl(:n';
wwv_flow_imp.g_varchar2_table(852) := 'ew.row_version_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER BIU_EBA_CUST_HISTORY'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(853) := 'before insert or update on EBA_CUST_HISTORY'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new."ID" is null then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(854) := 'select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(855) := '  if inserting then'||wwv_flow.LF||
'       :new.change_date := current_timestamp;'||wwv_flow.LF||
'       :new.changed_by := nvl(wwv_';
wwv_flow_imp.g_varchar2_table(856) := 'flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_versi';
wwv_flow_imp.g_varchar2_table(857) := 'on_number := :new.row_version_number + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER bi_eba_cust_e';
wwv_flow_imp.g_varchar2_table(858) := 'rrors'||wwv_flow.LF||
'    before insert or update on eba_cust_errors'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null t';
wwv_flow_imp.g_varchar2_table(859) := 'hen'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(860) := '    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER au_eba_cust_cust_competitor_re'||wwv_flow.LF||
'    after insert or upd';
wwv_flow_imp.g_varchar2_table(861) := 'ate or delete on eba_cust_cust_competitor_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    pragma autonomous_transac';
wwv_flow_imp.g_varchar2_table(862) := 'tion;'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'    nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    ov := null; nv := null';
wwv_flow_imp.g_varchar2_table(863) := ';'||wwv_flow.LF||
'    for c1 in (select name val from eba_cust_competitors t where t.id = :old.competitor_id) loop'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(864) := '       ov := c1.val;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    for c1 in (select name val from eba_cust_competitors t where ';
wwv_flow_imp.g_varchar2_table(865) := 't.id = :new.competitor_id) loop'||wwv_flow.LF||
'        nv := c1.val;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    insert into eba_cust_history';
wwv_flow_imp.g_varchar2_table(866) := ' (table_name, component_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'        (''CU';
wwv_flow_imp.g_varchar2_table(867) := 'STOMERS'', null, nvl(:new.customer_id,:old.customer_id), ''COMPETITOR_ID'', ov, nv);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end au';
wwv_flow_imp.g_varchar2_table(868) := '_eba_cust_cust_competitor_re;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER biu_eba_cust_cust_comp_ref'||wwv_flow.LF||
'    before ins';
wwv_flow_imp.g_varchar2_table(869) := 'ert or update on eba_cust_cust_competitor_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        i';
wwv_flow_imp.g_varchar2_table(870) := 'f :new.id is null then'||wwv_flow.LF||
'            :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(871) := ''');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP';
wwv_flow_imp.g_varchar2_table(872) := '_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_';
wwv_flow_imp.g_varchar2_table(873) := 'USER''),user);'||wwv_flow.LF||
'end biu_eba_cust_cust_comp_ref;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER biu_eba_cust_products'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(874) := ' before insert or update on eba_cust_products'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.tags is not null th';
wwv_flow_imp.g_varchar2_table(875) := 'en'||wwv_flow.LF||
'        :new.tags := eba_cust_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(876) := '   if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(877) := ''')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              from dual;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :NEW.CREATED := curre';
wwv_flow_imp.g_varchar2_table(878) := 'nt_timestamp;'||wwv_flow.LF||
'        :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :NEW.UPDATED := current_ti';
wwv_flow_imp.g_varchar2_table(879) := 'mestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(880) := '   eba_cust_fw.tag_sync('||wwv_flow.LF||
'        p_new_tags      => :new.tags,'||wwv_flow.LF||
'        p_old_tags      => null,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(881) := '    p_content_type  => ''PRODUCT'','||wwv_flow.LF||
'        p_content_id    => :new.id );'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating ';
wwv_flow_imp.g_varchar2_table(882) := 'then'||wwv_flow.LF||
'        :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(883) := '        :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    eba_cust_fw.tag_sync('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(884) := '     p_new_tags      => :new.tags,'||wwv_flow.LF||
'        p_old_tags      => :old.tags,'||wwv_flow.LF||
'        p_content_type  => ';
wwv_flow_imp.g_varchar2_table(885) := '''PRODUCT'','||wwv_flow.LF||
'        p_content_id    => :new.id );'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER bd_eb';
wwv_flow_imp.g_varchar2_table(886) := 'a_cust_products'||wwv_flow.LF||
'    before delete on eba_cust_products'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba_cust_fw.tag_sy';
wwv_flow_imp.g_varchar2_table(887) := 'nc('||wwv_flow.LF||
'        p_new_tags      => null,'||wwv_flow.LF||
'        p_old_tags      => :old.tags,'||wwv_flow.LF||
'        p_content_type  =';
wwv_flow_imp.g_varchar2_table(888) := '> ''PRODUCT'','||wwv_flow.LF||
'        p_content_id    => :old.id );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_TYPE" ENABLE;';
wwv_flow_imp.g_varchar2_table(889) := ''||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CUST_FEEDBACK_TYPES_BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_SALES_CHANNEL" ';
wwv_flow_imp.g_varchar2_table(890) := 'ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_FILES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BD_EBA_CUST_FILES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'a';
wwv_flow_imp.g_varchar2_table(891) := 'lter trigger "AU_EBA_CUST_PRODUCT_USES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_PRODUCT_USES" ENABLE;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(892) := '/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_CATEGORIES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "AU_EBA_CUST_ACTIVITIES" ENABLE;'||wwv_flow.LF||
'/';
wwv_flow_imp.g_varchar2_table(893) := ''||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_ACTIVITIES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_ACTIVITY_FILES" ENABL';
wwv_flow_imp.g_varchar2_table(894) := 'E;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_CUST_REFTYPE_REF" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "AU_EBA_CUST_CUSTOMER_REF';
wwv_flow_imp.g_varchar2_table(895) := 'TYPE_R" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CUST_USERS_BD" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CUST_USERS_BIU" ENA';
wwv_flow_imp.g_varchar2_table(896) := 'BLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_REFERENCE_TYPES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_ACTIVITY_R';
wwv_flow_imp.g_varchar2_table(897) := 'EF" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "AU_EBA_CUST_ACTIVITY_REF" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_STATUS"';
wwv_flow_imp.g_varchar2_table(898) := ' ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_USE_CASE" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CUST_PRODUCT_STATUSES_';
wwv_flow_imp.g_varchar2_table(899) := 'BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_PRODUCT_FAMILIES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_T';
wwv_flow_imp.g_varchar2_table(900) := 'Z_PREF" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CUST_PREFERENCES_BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_IMP';
wwv_flow_imp.g_varchar2_table(901) := 'L_PARTNERS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_EMAIL_LOG" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_A';
wwv_flow_imp.g_varchar2_table(902) := 'CTIVITY_TYPES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_CUST_PARTNER_REF" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "AU_E';
wwv_flow_imp.g_varchar2_table(903) := 'BA_CUST_CUST_PARTNER_REF" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_ISSUES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU';
wwv_flow_imp.g_varchar2_table(904) := '_EBA_CUST_ADMINISTRATORS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CUST_VERIFY_BIU_FER" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger ';
wwv_flow_imp.g_varchar2_table(905) := '"BD_EBA_CUST_CONTACTS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_CONTACTS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "AU_E';
wwv_flow_imp.g_varchar2_table(906) := 'BA_CUST_CONTACTS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CUST_NOTIF_BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST';
wwv_flow_imp.g_varchar2_table(907) := '_ISSUE_STATUSES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CUST_ACL_FEATURES_BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CU';
wwv_flow_imp.g_varchar2_table(908) := 'ST_CLICKS_BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CUST_FEEDBACK_BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BI_EBA_CUST_';
wwv_flow_imp.g_varchar2_table(909) := 'VIEWS_LOG" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_LINKS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_GEOGRA';
wwv_flow_imp.g_varchar2_table(910) := 'PHIES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_REF_PHASE" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_INDUST';
wwv_flow_imp.g_varchar2_table(911) := 'RIES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CUST_TAGS_BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_COMPETITORS"';
wwv_flow_imp.g_varchar2_table(912) := ' ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "AU_EBA_CUST_COMPETITORS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "AU_EBA_CUST_CUSTOMERS" E';
wwv_flow_imp.g_varchar2_table(913) := 'NABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "AD_EBA_CUST_CUSTOMERS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_CUSTOMERS" ENAB';
wwv_flow_imp.g_varchar2_table(914) := 'LE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_NOTES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_COUNTRIES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(915) := 'alter trigger "BIU_EBA_CUST_CONTACT_TYPES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_HISTORY" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(916) := 'alter trigger "BI_EBA_CUST_ERRORS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "AU_EBA_CUST_CUST_COMPETITOR_RE" ENABLE;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(917) := '/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_CUST_COMP_REF" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CUST_PRODUCTS" ENABLE;';
wwv_flow_imp.g_varchar2_table(918) := ''||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BD_EBA_CUST_PRODUCTS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Re-create views:'||wwv_flow.LF||
'create or replace view eba_cu';
wwv_flow_imp.g_varchar2_table(919) := 'st_customers_v as'||wwv_flow.LF||
'select '||wwv_flow.LF||
'   a.row_key, '||wwv_flow.LF||
'   a.id,'||wwv_flow.LF||
'   customer_name,'||wwv_flow.LF||
'   status,'||wwv_flow.LF||
'   a.status_id,'||wwv_flow.LF||
'   ca';
wwv_flow_imp.g_varchar2_table(920) := 'tegory,'||wwv_flow.LF||
'   geography_name,'||wwv_flow.LF||
'   referencable,'||wwv_flow.LF||
'   number_of_users,'||wwv_flow.LF||
'   summary,'||wwv_flow.LF||
'   web_site,'||wwv_flow.LF||
'   (select ';
wwv_flow_imp.g_varchar2_table(921) := 'listagg(p.product_name, '', '') within group (order by p.product_name) product_uses'||wwv_flow.LF||
'    from eba_cust_';
wwv_flow_imp.g_varchar2_table(922) := 'customers c, eba_cust_product_uses u, eba_cust_products p'||wwv_flow.LF||
'    where c.id = u.customer_id'||wwv_flow.LF||
'    and u.p';
wwv_flow_imp.g_varchar2_table(923) := 'roduct_id = p.id'||wwv_flow.LF||
'    and c.id = a.id'||wwv_flow.LF||
'    group by c.customer_name'||wwv_flow.LF||
'   ) product_uses,'||wwv_flow.LF||
'   nvl((select ';
wwv_flow_imp.g_varchar2_table(924) := 'industry_name from eba_cust_industries i where i.id = a.industry_id),''Not Defined'') industry,'||wwv_flow.LF||
'   tag';
wwv_flow_imp.g_varchar2_table(925) := 's,'||wwv_flow.LF||
'   a.created,'||wwv_flow.LF||
'   a.created_by,'||wwv_flow.LF||
'   a.updated,'||wwv_flow.LF||
'   a.updated_by'||wwv_flow.LF||
'from   '||wwv_flow.LF||
'   eba_cust_customers a, '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(926) := ' eba_cust_categories b, '||wwv_flow.LF||
'   eba_cust_status c, '||wwv_flow.LF||
'   eba_cust_geographies d'||wwv_flow.LF||
'where '||wwv_flow.LF||
'   a.category_id = ';
wwv_flow_imp.g_varchar2_table(927) := 'b.id (+) and '||wwv_flow.LF||
'   a.status_id = c.id (+) and '||wwv_flow.LF||
'   a.geography_id = d.id (+)'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Tables Changed: 49'||wwv_flow.LF||
'-';
wwv_flow_imp.g_varchar2_table(928) := '- Columns Changed: 111'||wwv_flow.LF||
'-- Triggers Changed: 63';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(425891577841886362)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'TIMESTAMP Fix (BUGID: 31352674) '
,p_sequence=>500
,p_script_type=>'UPGRADE'
,p_condition_type=>'EXISTS'
,p_condition=>'select null from all_tab_cols where table_name like ''EBA_CUST_%'' and data_type = ''TIMESTAMP(6) WITH LOCAL TIME ZONE'''
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
