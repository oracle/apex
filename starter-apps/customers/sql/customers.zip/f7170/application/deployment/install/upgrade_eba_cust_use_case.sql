prompt --application/deployment/install/upgrade_eba_cust_use_case
begin
--   Manifest
--     INSTALL: UPGRADE-eba_cust_use_case
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_use_case ('||wwv_flow.LF||
'   id                      number       not null,'||wwv_flow.LF||
'   row_version_nu';
wwv_flow_imp.g_varchar2_table(2) := 'mber      number,'||wwv_flow.LF||
'   use_case                varchar2(60) not null,'||wwv_flow.LF||
'   description             varch';
wwv_flow_imp.g_varchar2_table(3) := 'ar2(4000) ,'||wwv_flow.LF||
'   is_active               varchar2(1)  default ''Y'','||wwv_flow.LF||
''||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   created               tim';
wwv_flow_imp.g_varchar2_table(4) := 'estamp with time zone not null,'||wwv_flow.LF||
'   created_by            varchar2(255) not null,'||wwv_flow.LF||
'   updated         ';
wwv_flow_imp.g_varchar2_table(5) := '      timestamp with time zone,'||wwv_flow.LF||
'   updated_by            varchar2(255)'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_us';
wwv_flow_imp.g_varchar2_table(6) := 'e_case'||wwv_flow.LF||
'   add constraint eba_cust_use_case_pk'||wwv_flow.LF||
'       primary key (id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust';
wwv_flow_imp.g_varchar2_table(7) := '_use_case_uk on eba_cust_use_case(use_case)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_use_case'||wwv_flow.LF||
'   add constraint eba_cu';
wwv_flow_imp.g_varchar2_table(8) := 'st_use_case_uk'||wwv_flow.LF||
'       unique (use_case)'||wwv_flow.LF||
'       using index eba_cust_use_case_uk'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace';
wwv_flow_imp.g_varchar2_table(9) := ' trigger biu_eba_cust_use_case'||wwv_flow.LF||
'   before insert or update on eba_cust_use_case'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   be';
wwv_flow_imp.g_varchar2_table(10) := 'gin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid()';
wwv_flow_imp.g_varchar2_table(11) := ',''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'            into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;';
wwv_flow_imp.g_varchar2_table(12) := ''||wwv_flow.LF||
'         :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(13) := '       :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(14) := '    :new.row_version_number := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := cur';
wwv_flow_imp.g_varchar2_table(15) := 'rent_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_numbe';
wwv_flow_imp.g_varchar2_table(16) := 'r := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_cust_u';
wwv_flow_imp.g_varchar2_table(17) := 'se_case (id, use_case, description ) values (1,''Development'', ''Development'');'||wwv_flow.LF||
'insert into eba_cust_u';
wwv_flow_imp.g_varchar2_table(18) := 'se_case (id, use_case, description ) values (2,''Test / Stage'', ''Test / Stage'');'||wwv_flow.LF||
'insert into eba_cust';
wwv_flow_imp.g_varchar2_table(19) := '_use_case (id, use_case, description ) values (3,''Production'', ''Production'');'||wwv_flow.LF||
'commit;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(17131615259584211194)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'eba_cust_use_case'
,p_sequence=>320
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_CUST_USE_CASE'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
