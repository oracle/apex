prompt --application/deployment/install/upgrade_populate_eba_cust_acl_features
begin
--   Manifest
--     INSTALL: UPGRADE-populate eba_cust_acl_features
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into eba_cust_acl_features (authorization_name, feature, access_level_id)'||wwv_flow.LF||
'  values (''EDIT_COM';
wwv_flow_imp.g_varchar2_table(2) := 'PETITORS'',''Specify what access level is required to maintain competitors.'',2);'||wwv_flow.LF||
'insert into eba_cust_';
wwv_flow_imp.g_varchar2_table(3) := 'acl_features (authorization_name, feature, access_level_id)'||wwv_flow.LF||
'  values (''VIEW_COMPETITORS'',''Specify wh';
wwv_flow_imp.g_varchar2_table(4) := 'at level can view competiors, and add them to customers.'',2);'||wwv_flow.LF||
'commit;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1374575187008248752)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'populate eba_cust_acl_features'
,p_sequence=>450
,p_script_type=>'UPGRADE'
,p_condition_type=>'FUNCTION_BODY'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_cnt    pls_integer;',
'    l_retval boolean := true;',
'begin',
'    select count(*)',
'      into l_cnt',
'      from eba_cust_acl_features',
'     where authorization_name in (''EDIT_COMPETITORS'', ''VIEW_COMPETITORS'');',
'',
'    if l_cnt > 0 then',
'        l_retval := false;',
'    end if;',
'',
'    return l_retval;',
'end;'))
,p_condition2=>'PLSQL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
