prompt --application/deployment/install/install_competitors
begin
--   Manifest
--     INSTALL: INSTALL-Competitors
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_competitors ('||wwv_flow.LF||
'    id                  number       not null,'||wwv_flow.LF||
'    row_version_n';
wwv_flow_imp.g_varchar2_table(2) := 'umber  number,'||wwv_flow.LF||
'    name                varchar2(250) not null,'||wwv_flow.LF||
'    description         varchar2(4000';
wwv_flow_imp.g_varchar2_table(3) := ') ,'||wwv_flow.LF||
'    website             varchar2(512),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created             timestamp with time zone n';
wwv_flow_imp.g_varchar2_table(4) := 'ot null,'||wwv_flow.LF||
'    created_by          varchar2(255) not null,'||wwv_flow.LF||
'    updated             timestamp with time';
wwv_flow_imp.g_varchar2_table(5) := ' zone,'||wwv_flow.LF||
'    updated_by          varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    constraint eba_cust_competitors_pk primary ';
wwv_flow_imp.g_varchar2_table(6) := 'key (id)'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust_competitors_uk on eba_cust_competitors(name)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or ';
wwv_flow_imp.g_varchar2_table(7) := 'replace trigger biu_eba_cust_competitors'||wwv_flow.LF||
'    before insert or update on eba_cust_competitors'||wwv_flow.LF||
'    for';
wwv_flow_imp.g_varchar2_table(8) := ' each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            :new.id := to_numb';
wwv_flow_imp.g_varchar2_table(9) := 'er(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created := current_t';
wwv_flow_imp.g_varchar2_table(10) := 'imestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(11) := '    else'||wwv_flow.LF||
'        :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new';
wwv_flow_imp.g_varchar2_table(12) := '.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end biu_eba_cust_comp';
wwv_flow_imp.g_varchar2_table(13) := 'etitors;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger biu_eba_cust_competitors enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_cust_cust_competitor_r';
wwv_flow_imp.g_varchar2_table(14) := 'ef ('||wwv_flow.LF||
'    id            number not null,'||wwv_flow.LF||
'    customer_id   number not null,'||wwv_flow.LF||
'    competitor_id number ';
wwv_flow_imp.g_varchar2_table(15) := 'not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created     timestamp with time zone not null,'||wwv_flow.LF||
'    created_by  varchar2(255) no';
wwv_flow_imp.g_varchar2_table(16) := 't null,'||wwv_flow.LF||
'    updated     timestamp with time zone,'||wwv_flow.LF||
'    updated_by  varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    constrai';
wwv_flow_imp.g_varchar2_table(17) := 'nt eba_cust_cust_competitor_pk  primary key (id),'||wwv_flow.LF||
'    constraint eba_cust_cust_competitor_fk  foreig';
wwv_flow_imp.g_varchar2_table(18) := 'n key (customer_id) references eba_cust_customers(id) on delete cascade,'||wwv_flow.LF||
'    constraint eba_cust_cus';
wwv_flow_imp.g_varchar2_table(19) := 't_competitor_fk2 foreign key (competitor_id) references eba_cust_competitors(id) on delete cascade'||wwv_flow.LF||
')';
wwv_flow_imp.g_varchar2_table(20) := ''||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust_cust_compe_ref_u1 on eba_cust_cust_competitor_ref( customer_id, comp';
wwv_flow_imp.g_varchar2_table(21) := 'etitor_id )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cust_cust_comp_ref'||wwv_flow.LF||
'    before insert or update on e';
wwv_flow_imp.g_varchar2_table(22) := 'ba_cust_cust_competitor_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is null ';
wwv_flow_imp.g_varchar2_table(23) := 'then'||wwv_flow.LF||
'            :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if';
wwv_flow_imp.g_varchar2_table(24) := ';'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(25) := ' end if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end ';
wwv_flow_imp.g_varchar2_table(26) := 'biu_eba_cust_cust_comp_ref;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger biu_eba_cust_cust_comp_ref enable;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(17727445141753358565)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Competitors'
,p_sequence=>350
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
