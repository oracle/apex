prompt --application/deployment/install/upgrade_click_counting_table
begin
--   Manifest
--     INSTALL: UPGRADE-Click Counting Table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_clicks (    '||wwv_flow.LF||
'    id                number primary key,'||wwv_flow.LF||
'    cust_id           n';
wwv_flow_imp.g_varchar2_table(2) := 'umber,'||wwv_flow.LF||
'    app_username      varchar2(255),'||wwv_flow.LF||
'    view_timestamp    timestamp(6) with time zone,'||wwv_flow.LF||
'    a';
wwv_flow_imp.g_varchar2_table(3) := 'pp_session       varchar2(255)'||wwv_flow.LF||
');'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_cust_clicks_idx1 on eba_cust_clicks (cust_id)';
wwv_flow_imp.g_varchar2_table(4) := ';'||wwv_flow.LF||
'create index eba_cust_clicks_idx2 on eba_cust_clicks (view_timestamp);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger ';
wwv_flow_imp.g_varchar2_table(5) := 'eba_cust_clicks_biu'||wwv_flow.LF||
'    before insert on eba_cust_clicks'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'     if :new.id is n';
wwv_flow_imp.g_varchar2_table(6) := 'ull then'||wwv_flow.LF||
'         :new.id := eba_cust_seq.nextval;'||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'     :new.view_timestamp := current_';
wwv_flow_imp.g_varchar2_table(7) := 'timestamp;'||wwv_flow.LF||
'     :new.app_username := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'     :new.app_session := v(''APP_SESSIO';
wwv_flow_imp.g_varchar2_table(8) := 'N'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger eba_cust_clicks_biu enable;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(14947522174529787656)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Click Counting Table'
,p_sequence=>130
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_CUST_CLICKS'';'))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
