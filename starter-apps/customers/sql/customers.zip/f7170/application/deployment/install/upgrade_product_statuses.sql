prompt --application/deployment/install/upgrade_product_statuses
begin
--   Manifest
--     INSTALL: UPGRADE-product statuses
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_product_statuses ('||wwv_flow.LF||
'    id          number         not NULL,'||wwv_flow.LF||
'    status      va';
wwv_flow_imp.g_varchar2_table(2) := 'rchar2(255),'||wwv_flow.LF||
'    description varchar2(512),'||wwv_flow.LF||
'    is_current_yn varchar2(1),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created     ti';
wwv_flow_imp.g_varchar2_table(3) := 'mestamp with time zone not null,'||wwv_flow.LF||
'    created_by  varchar2(255) not null,'||wwv_flow.LF||
'    updated     timestamp w';
wwv_flow_imp.g_varchar2_table(4) := 'ith time zone,'||wwv_flow.LF||
'    updated_by  varchar2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_product_statuses'||wwv_flow.LF||
'   add con';
wwv_flow_imp.g_varchar2_table(5) := 'straint eba_cust_product_statuses_pk'||wwv_flow.LF||
'       primary key (id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger  eba_cust_';
wwv_flow_imp.g_varchar2_table(6) := 'product_statuses_biu'||wwv_flow.LF||
'   before insert or update on eba_cust_product_statuses'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(7) := '   if :NEW.ID is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX''';
wwv_flow_imp.g_varchar2_table(8) := ')'||wwv_flow.LF||
'           into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'       :NEW.CREAT';
wwv_flow_imp.g_varchar2_table(9) := 'ED := current_timestamp;'||wwv_flow.LF||
'       :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'       :NEW.UPDATED := c';
wwv_flow_imp.g_varchar2_table(10) := 'urrent_timestamp;'||wwv_flow.LF||
'       :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'  '||wwv_flow.LF||
'    if updating ';
wwv_flow_imp.g_varchar2_table(11) := 'then'||wwv_flow.LF||
'       :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'       :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(12) := '  end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_cust_product_statuses (status, description, is_current_yn) values';
wwv_flow_imp.g_varchar2_table(13) := ' (''Phase 1'', ''Candidates and Discovery'', ''N'');'||wwv_flow.LF||
'insert into eba_cust_product_statuses (status, descri';
wwv_flow_imp.g_varchar2_table(14) := 'ption, is_current_yn) values (''Phase 2'', ''Active Discussions'', ''N'');'||wwv_flow.LF||
'insert into eba_cust_product_st';
wwv_flow_imp.g_varchar2_table(15) := 'atuses (status, description, is_current_yn) values (''Phase 3'', ''Engaged With Customer'', ''N'');'||wwv_flow.LF||
'insert';
wwv_flow_imp.g_varchar2_table(16) := ' into eba_cust_product_statuses (status, description, is_current_yn) values (''Phase 4'', ''Reference A';
wwv_flow_imp.g_varchar2_table(17) := 'vailable and Published'', ''Y'');'||wwv_flow.LF||
'commit;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(14294308631080802322)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'product statuses'
,p_sequence=>260
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_CUST_PRODUCT_STATUSES'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
