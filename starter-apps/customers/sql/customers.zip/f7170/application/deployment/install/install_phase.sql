prompt --application/deployment/install/install_phase
begin
--   Manifest
--     INSTALL: INSTALL-phase
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_ref_phase ('||wwv_flow.LF||
'   id                      number       not null,'||wwv_flow.LF||
'   status       ';
wwv_flow_imp.g_varchar2_table(2) := '           varchar2(60) not null,'||wwv_flow.LF||
'   description             varchar2(4000),'||wwv_flow.LF||
'   is_an_active_referen';
wwv_flow_imp.g_varchar2_table(3) := 'ce  varchar2(1) not null,'||wwv_flow.LF||
'   display_sequence        number,'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   created               timestam';
wwv_flow_imp.g_varchar2_table(4) := 'p with time zone not null,'||wwv_flow.LF||
'   created_by            varchar2(255) not null,'||wwv_flow.LF||
'   updated              ';
wwv_flow_imp.g_varchar2_table(5) := ' timestamp with time zone,'||wwv_flow.LF||
'   updated_by            varchar2(255)'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_ref_pha';
wwv_flow_imp.g_varchar2_table(6) := 'se add '||wwv_flow.LF||
'constraint eba_cust_ref_phase_pk primary key (id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index eba_cust_ref_phase_';
wwv_flow_imp.g_varchar2_table(7) := 'uk on eba_cust_ref_phase(status)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_cust_ref_phase'||wwv_flow.LF||
'   add constraint eba_cust_ref_ph';
wwv_flow_imp.g_varchar2_table(8) := 'ase_uk'||wwv_flow.LF||
'       unique (status)'||wwv_flow.LF||
'       using index eba_cust_ref_phase_uk'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger';
wwv_flow_imp.g_varchar2_table(9) := ' biu_eba_cust_ref_phase'||wwv_flow.LF||
'   before insert or update on eba_cust_ref_phase'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if';
wwv_flow_imp.g_varchar2_table(10) := ' inserting then'||wwv_flow.LF||
'      if :NEW.ID is null then'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(11) := 'XXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'        into :new.id'||wwv_flow.LF||
'        from dual;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      :NEW.CREATED := curren';
wwv_flow_imp.g_varchar2_table(12) := 't_timestamp;'||wwv_flow.LF||
'      :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'      :NEW.UPDATED := current_timesta';
wwv_flow_imp.g_varchar2_table(13) := 'mp;'||wwv_flow.LF||
'      :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if updating then'||wwv_flow.LF||
'      :NEW.UPDA';
wwv_flow_imp.g_varchar2_table(14) := 'TED := current_timestamp;'||wwv_flow.LF||
'      :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show e';
wwv_flow_imp.g_varchar2_table(15) := 'rrors'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_cust_ref_phase (id, status, description, is_an_active_reference, display_sequ';
wwv_flow_imp.g_varchar2_table(16) := 'ence) values (1, ''Phase 1'',''Candidates and Discovery'',''N'',1);'||wwv_flow.LF||
'insert into eba_cust_ref_phase (id, st';
wwv_flow_imp.g_varchar2_table(17) := 'atus, description, is_an_active_reference, display_sequence) values (2, ''Phase 2'',''Active Discussion';
wwv_flow_imp.g_varchar2_table(18) := 's'',''N'',2);'||wwv_flow.LF||
'insert into eba_cust_ref_phase (id, status, description, is_an_active_reference, display_';
wwv_flow_imp.g_varchar2_table(19) := 'sequence) values (3, ''Phase 3'',''Engaged With Customer'',''N'',3);'||wwv_flow.LF||
'insert into eba_cust_ref_phase (id, s';
wwv_flow_imp.g_varchar2_table(20) := 'tatus, description, is_an_active_reference, display_sequence) values (4, ''Phase 4'',''Reference Availa';
wwv_flow_imp.g_varchar2_table(21) := 'ble and Published'',''Y'',4);'||wwv_flow.LF||
'commit;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(15833123843001265973)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'phase'
,p_sequence=>510
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
