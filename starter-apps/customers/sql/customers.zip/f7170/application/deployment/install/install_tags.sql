prompt --application/deployment/install/install_tags
begin
--   Manifest
--     INSTALL: INSTALL-tags
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table  eba_cust_tags ('||wwv_flow.LF||
'    tag_id                      number not null,'||wwv_flow.LF||
'    tag              ';
wwv_flow_imp.g_varchar2_table(2) := '           varchar2(255) not null enable,'||wwv_flow.LF||
'    content_id                  number,'||wwv_flow.LF||
'    content_type  ';
wwv_flow_imp.g_varchar2_table(3) := '              varchar2(30),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created               timestamp with time zone not null,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(4) := 'created_by            varchar2(255) not null,'||wwv_flow.LF||
'    updated               timestamp with time zone,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(5) := '  updated_by            varchar2(255)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_tags'||wwv_flow.LF||
'   add constraint eba_cust_ta';
wwv_flow_imp.g_varchar2_table(6) := 'gs_pk'||wwv_flow.LF||
'       primary key (tag_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_tags'||wwv_flow.LF||
'   add constraint eba_cust_tags_ck che';
wwv_flow_imp.g_varchar2_table(7) := 'ck'||wwv_flow.LF||
'       (content_type in (''CUSTOMER'',''CONTACT'',''PRODUCT'',''FILE''))'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_cust_tags_ty';
wwv_flow_imp.g_varchar2_table(8) := 'pe_sum ('||wwv_flow.LF||
'    tag                             varchar2(255),'||wwv_flow.LF||
'    content_type                    varc';
wwv_flow_imp.g_varchar2_table(9) := 'har2(30),'||wwv_flow.LF||
'    tag_count                       number,'||wwv_flow.LF||
'    constraint eba_cust_tags_type_sum_pk prima';
wwv_flow_imp.g_varchar2_table(10) := 'ry key (tag,content_type)'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_cust_tags_sum ('||wwv_flow.LF||
'    tag                         ';
wwv_flow_imp.g_varchar2_table(11) := '    varchar2(255),'||wwv_flow.LF||
'    tag_count                       number,'||wwv_flow.LF||
'    constraint eba_cust_tags_sum_pk p';
wwv_flow_imp.g_varchar2_table(12) := 'rimary key (tag)'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16674622401426438142)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'tags'
,p_sequence=>320
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
