prompt --application/deployment/install/install_products
begin
--   Manifest
--     INSTALL: INSTALL-products
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_products ('||wwv_flow.LF||
'    id                      number       not NULL,'||wwv_flow.LF||
'    row_version_';
wwv_flow_imp.g_varchar2_table(2) := 'number      number,'||wwv_flow.LF||
'    product_family_id       number,'||wwv_flow.LF||
'    product_name            varchar2(255) no';
wwv_flow_imp.g_varchar2_table(3) := 't null,'||wwv_flow.LF||
'    description             varchar2(4000) ,'||wwv_flow.LF||
'    tags                    varchar2(4000),'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(4) := ' is_active               varchar2(1) default ''Y'','||wwv_flow.LF||
'    price_list_part_number  varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(5) := '    created               timestamp with time zone not null,'||wwv_flow.LF||
'    created_by            varchar2(255)';
wwv_flow_imp.g_varchar2_table(6) := ' not null,'||wwv_flow.LF||
'    updated               timestamp with time zone,'||wwv_flow.LF||
'    updated_by            varchar2(25';
wwv_flow_imp.g_varchar2_table(7) := '5),'||wwv_flow.LF||
'    constraint eba_cust_products_pk primary key (id),'||wwv_flow.LF||
'    constraint eba_cust_prod_fam_fk foreig';
wwv_flow_imp.g_varchar2_table(8) := 'n key (product_family_id) references eba_cust_product_families(id) on delete cascade'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create uniq';
wwv_flow_imp.g_varchar2_table(9) := 'ue index eba_cust_products_uk on eba_cust_products(product_name)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_products'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(10) := ' add constraint eba_cust_products_uk'||wwv_flow.LF||
'       unique (product_name)'||wwv_flow.LF||
'       using index eba_cust_produc';
wwv_flow_imp.g_varchar2_table(11) := 'ts_uk'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16674620587312415208)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'products'
,p_sequence=>200
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
