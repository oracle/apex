prompt --application/deployment/install/install_customer_statuses
begin
--   Manifest
--     INSTALL: INSTALL-Customer Statuses
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_status ('||wwv_flow.LF||
'   id                      number       not null,'||wwv_flow.LF||
'   row_version_numb';
wwv_flow_imp.g_varchar2_table(2) := 'er      number,'||wwv_flow.LF||
'   status                  varchar2(60) not null,'||wwv_flow.LF||
'   description             varchar';
wwv_flow_imp.g_varchar2_table(3) := '2(4000) ,'||wwv_flow.LF||
'   is_active               varchar2(1)  default ''Y'','||wwv_flow.LF||
''||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   created               times';
wwv_flow_imp.g_varchar2_table(4) := 'tamp with time zone not null,'||wwv_flow.LF||
'   created_by            varchar2(255) not null,'||wwv_flow.LF||
'   updated           ';
wwv_flow_imp.g_varchar2_table(5) := '    timestamp with time zone,'||wwv_flow.LF||
'   updated_by            varchar2(255)'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_stat';
wwv_flow_imp.g_varchar2_table(6) := 'us'||wwv_flow.LF||
'   add constraint eba_cust_status_pk'||wwv_flow.LF||
'       primary key (id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust_statu';
wwv_flow_imp.g_varchar2_table(7) := 's_uk on eba_cust_status(status)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_status'||wwv_flow.LF||
'   add constraint eba_cust_status_uk'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(8) := '      unique (status)'||wwv_flow.LF||
'       using index eba_cust_status_uk'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16674620379693413002)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Customer Statuses'
,p_sequence=>160
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
