prompt --application/deployment/install/install_access_levels_and_users
begin
--   Manifest
--     INSTALL: INSTALL-access levels and users
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_access_levels ('||wwv_flow.LF||
'    id                      number              not null'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(2) := '                                           constraint eba_cust_access_levels_pk'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(3) := '                            primary key,'||wwv_flow.LF||
'    access_level            varchar2(30)        not null'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(4) := '                                              constraint eba_cust_acc_lvl_acc_lvl_ck'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(5) := '                                 check (access_level in ('||wwv_flow.LF||
'                                          ';
wwv_flow_imp.g_varchar2_table(6) := '          ''Administrator'','||wwv_flow.LF||
'                                                    ''Contributor'','||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(7) := '                                              ''Reader'' )),'||wwv_flow.LF||
'    row_version             number )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'cr';
wwv_flow_imp.g_varchar2_table(8) := 'eate unique index eba_cust_access_levels_uk on eba_cust_access_levels(access_level);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table';
wwv_flow_imp.g_varchar2_table(9) := ' eba_cust_users ('||wwv_flow.LF||
'    id                      number              not null'||wwv_flow.LF||
'                         ';
wwv_flow_imp.g_varchar2_table(10) := '                       constraint eba_cust_users_pk'||wwv_flow.LF||
'                                                ';
wwv_flow_imp.g_varchar2_table(11) := 'primary key,'||wwv_flow.LF||
'    username                varchar2(255)       not null'||wwv_flow.LF||
'                              ';
wwv_flow_imp.g_varchar2_table(12) := '                  constraint eba_cust_users_username_ck'||wwv_flow.LF||
'                                            ';
wwv_flow_imp.g_varchar2_table(13) := '    check (upper(username)=username),'||wwv_flow.LF||
'    access_level_id         number              not null'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(14) := '                                           constraint eba_cust_users_acc_level_fk'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(15) := '                              references eba_cust_access_levels,'||wwv_flow.LF||
'    account_locked          varchar';
wwv_flow_imp.g_varchar2_table(16) := '2(1)         not null'||wwv_flow.LF||
'                                                constraint eba_cust_users_acc_';
wwv_flow_imp.g_varchar2_table(17) := 'locked_ck'||wwv_flow.LF||
'                                                check (account_locked in (''Y'',''N'')),'||wwv_flow.LF||
'    r';
wwv_flow_imp.g_varchar2_table(18) := 'ow_version             number,'||wwv_flow.LF||
'    created_by              varchar2(255)       not null,'||wwv_flow.LF||
'    created';
wwv_flow_imp.g_varchar2_table(19) := '                 timestamp with time zone,'||wwv_flow.LF||
'    updated_by              varchar2(255),'||wwv_flow.LF||
'    updated   ';
wwv_flow_imp.g_varchar2_table(20) := '              timestamp with time zone )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust_users_uk on eba_cust_users (';
wwv_flow_imp.g_varchar2_table(21) := 'username);'||wwv_flow.LF||
'create index eba_cust_users_acc_lvl_idx on eba_cust_users (access_level_id);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(17807608228720824417)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'access levels and users'
,p_sequence=>110
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
