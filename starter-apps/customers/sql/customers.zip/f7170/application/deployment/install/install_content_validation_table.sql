prompt --application/deployment/install/install_content_validation_table
begin
--   Manifest
--     INSTALL: INSTALL-Content Validation Table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_verifications'||wwv_flow.LF||
'('||wwv_flow.LF||
'    id                   number primary key,'||wwv_flow.LF||
'    cust_id      ';
wwv_flow_imp.g_varchar2_table(2) := '        number,'||wwv_flow.LF||
'    verified_by          varchar2(255) not null,'||wwv_flow.LF||
'    verification_comment varchar2(4';
wwv_flow_imp.g_varchar2_table(3) := '000),'||wwv_flow.LF||
'    created              timestamp(6) with time zone,'||wwv_flow.LF||
'    created_by           varchar2(255),'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(4) := '    updated              timestamp(6) with time zone,'||wwv_flow.LF||
'    updated_by           varchar2(255)'||wwv_flow.LF||
');'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'c';
wwv_flow_imp.g_varchar2_table(5) := 'reate index eba_cust_verify_idx1 on eba_cust_verifications (cust_id);'||wwv_flow.LF||
'    '||wwv_flow.LF||
'create or replace trigger';
wwv_flow_imp.g_varchar2_table(6) := ' eba_cust_verify_biu_fer'||wwv_flow.LF||
'   before insert or update on eba_cust_verifications'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(7) := '   if :new.id is null then'||wwv_flow.LF||
'     :new.id := eba_cust_seq.nextval;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(8) := '    :new.created := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(apex_application.g_user,user);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(9) := '   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.up';
wwv_flow_imp.g_varchar2_table(10) := 'dated_by := nvl(apex_application.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger eba_cust_verify_biu_';
wwv_flow_imp.g_varchar2_table(11) := 'fer enable;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(14947960295798291398)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Content Validation Table'
,p_sequence=>500
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
