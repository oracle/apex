prompt --application/deployment/install/install_framework_body
begin
--   Manifest
--     INSTALL: INSTALL-Framework Body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE OR REPLACE PACKAGE BODY "EBA_CUST_FW" as'||wwv_flow.LF||
'    function conv_txt_html ('||wwv_flow.LF||
'        p_txt_message i';
wwv_flow_imp.g_varchar2_table(2) := 'n varchar2 )'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_html_message   varchar2(32767) default p_txt_m';
wwv_flow_imp.g_varchar2_table(3) := 'essage;'||wwv_flow.LF||
'        l_temp_url varchar2(32767) := null;'||wwv_flow.LF||
'        l_length number;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        l_htm';
wwv_flow_imp.g_varchar2_table(4) := 'l_message := replace(l_html_message, chr(10), ''<br />'');'||wwv_flow.LF||
'        l_html_message := replace(l_html_me';
wwv_flow_imp.g_varchar2_table(5) := 'ssage, chr(13), null);'||wwv_flow.LF||
'        return l_html_message;'||wwv_flow.LF||
'    end conv_txt_html;'||wwv_flow.LF||
'    function conv_urls_';
wwv_flow_imp.g_varchar2_table(6) := 'links ('||wwv_flow.LF||
'        p_string in varchar2 )'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_string   varchar2(32';
wwv_flow_imp.g_varchar2_table(7) := '767) default p_string;'||wwv_flow.LF||
'        l_endofUrl varchar2(4000) default chr(10) || chr(13) || chr(9) || '' )';
wwv_flow_imp.g_varchar2_table(8) := '<>'';'||wwv_flow.LF||
'        l_url         varchar2(4000);'||wwv_flow.LF||
'        l_current_pos number := 1;'||wwv_flow.LF||
'        n             ';
wwv_flow_imp.g_varchar2_table(9) := 'number := 1;'||wwv_flow.LF||
'        m             number := 1;'||wwv_flow.LF||
'        p             number := 1;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(10) := ' l_string := p_string || '' '';'||wwv_flow.LF||
'        for i in 1 .. 1000 loop'||wwv_flow.LF||
'            n := instr( lower(l_string';
wwv_flow_imp.g_varchar2_table(11) := '), ''http://'', l_current_pos );'||wwv_flow.LF||
'            m := instr( lower(l_string), ''https://'', l_current_pos );';
wwv_flow_imp.g_varchar2_table(12) := ''||wwv_flow.LF||
'            p := instr( lower(l_string), ''ftp://'', l_current_pos   );'||wwv_flow.LF||
'            -- set n to posit';
wwv_flow_imp.g_varchar2_table(13) := 'ion of first link'||wwv_flow.LF||
'            if m > 0 and (n = 0 or m < n) and (p = 0 or m < p) then'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(14) := ' n := m;'||wwv_flow.LF||
'            elsif p > 0 and (n = 0 or p < n) then'||wwv_flow.LF||
'               n := p;'||wwv_flow.LF||
'            end if';
wwv_flow_imp.g_varchar2_table(15) := ';'||wwv_flow.LF||
'            exit when n = 0 or length(l_string) > 32000;'||wwv_flow.LF||
'            for j in 0 .. length( l_strin';
wwv_flow_imp.g_varchar2_table(16) := 'g ) - n loop'||wwv_flow.LF||
'                if ( instr( l_endofUrl, substr( l_string, n+j, 1 ) ) > 0 ) then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(17) := '            l_url := rtrim( substr( l_string, n, j ), ''.''||chr(32)||chr(10) );'||wwv_flow.LF||
'                   l_';
wwv_flow_imp.g_varchar2_table(18) := 'url := ''<a href="'' || l_url || ''">'' || l_url || ''</a>'';'||wwv_flow.LF||
'                   l_string := substr( l_str';
wwv_flow_imp.g_varchar2_table(19) := 'ing, 1, n-1 ) || l_url || substr( l_string, n+j );'||wwv_flow.LF||
'                   l_current_pos := n + length(l_';
wwv_flow_imp.g_varchar2_table(20) := 'url);'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(21) := '   return l_string;'||wwv_flow.LF||
'    end conv_urls_links;'||wwv_flow.LF||
'    function tags_cleaner ('||wwv_flow.LF||
'        p_tags  in varchar2';
wwv_flow_imp.g_varchar2_table(22) := ','||wwv_flow.LF||
'        p_case  in varchar2 default ''U'' )'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        type tags is tabl';
wwv_flow_imp.g_varchar2_table(23) := 'e of varchar2(255) index by varchar2(255);'||wwv_flow.LF||
'        l_tags_a        tags;'||wwv_flow.LF||
'        l_tag           var';
wwv_flow_imp.g_varchar2_table(24) := 'char2(255);'||wwv_flow.LF||
'        l_tags          apex_application_global.vc_arr2;'||wwv_flow.LF||
'        l_tags_string   varchar';
wwv_flow_imp.g_varchar2_table(25) := '2(32767);'||wwv_flow.LF||
'        i               integer;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        l_tags := apex_util.string_to_table(p_t';
wwv_flow_imp.g_varchar2_table(26) := 'ags,'','');'||wwv_flow.LF||
'        for i in 1..l_tags.count loop'||wwv_flow.LF||
'            --remove all whitespace, including tabs,';
wwv_flow_imp.g_varchar2_table(27) := ' spaces, line feeds and carraige returns with a single space'||wwv_flow.LF||
'            l_tag := substr(trim(regexp';
wwv_flow_imp.g_varchar2_table(28) := '_replace(l_tags(i),''[[:space:]]{1,}'','' '')),1,255);'||wwv_flow.LF||
'            if l_tag is not null and l_tag != '' ''';
wwv_flow_imp.g_varchar2_table(29) := ' then'||wwv_flow.LF||
'                if p_case = ''U'' then'||wwv_flow.LF||
'                    l_tag := upper(l_tag);'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(30) := '  elsif p_case = ''L'' then'||wwv_flow.LF||
'                    l_tag := lower(l_tag);'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(31) := '         --add it to the associative array, if it is a duplicate, it will just be replaced'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(32) := '       l_tags_a(l_tag) := l_tag;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        l_tag := null;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(33) := '  l_tag := l_tags_a.first;'||wwv_flow.LF||
'        while l_tag is not null loop'||wwv_flow.LF||
'            l_tags_string := l_tags_';
wwv_flow_imp.g_varchar2_table(34) := 'string||l_tag;'||wwv_flow.LF||
'            if l_tag != l_tags_a.last then'||wwv_flow.LF||
'                l_tags_string := l_tags_st';
wwv_flow_imp.g_varchar2_table(35) := 'ring || '', '';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            l_tag := l_tags_a.next(l_tag);'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(36) := '   return substr(l_tags_string, 1, 4000);'||wwv_flow.LF||
'    end tags_cleaner;'||wwv_flow.LF||
'    procedure tag_sync ('||wwv_flow.LF||
'        p_n';
wwv_flow_imp.g_varchar2_table(37) := 'ew_tags          in varchar2,'||wwv_flow.LF||
'        p_old_tags          in varchar2,'||wwv_flow.LF||
'        p_content_type      i';
wwv_flow_imp.g_varchar2_table(38) := 'n varchar2,'||wwv_flow.LF||
'        p_content_id        in number )'||wwv_flow.LF||
'    as'||wwv_flow.LF||
'        type tags is table of varchar2(25';
wwv_flow_imp.g_varchar2_table(39) := '5) index by varchar2(255);'||wwv_flow.LF||
'        l_new_tags_a    tags;'||wwv_flow.LF||
'        l_old_tags_a    tags;'||wwv_flow.LF||
'        l_new';
wwv_flow_imp.g_varchar2_table(40) := '_tags      apex_application_global.vc_arr2;'||wwv_flow.LF||
'        l_old_tags      apex_application_global.vc_arr2;';
wwv_flow_imp.g_varchar2_table(41) := ''||wwv_flow.LF||
'        l_merge_tags    apex_application_global.vc_arr2;'||wwv_flow.LF||
'        l_dummy_tag     varchar2(255);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(42) := '     i               integer;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        l_old_tags := apex_util.string_to_table(p_old_tags,''';
wwv_flow_imp.g_varchar2_table(43) := ', '');'||wwv_flow.LF||
'        l_new_tags := apex_util.string_to_table(p_new_tags,'', '');'||wwv_flow.LF||
'        if l_old_tags.count ';
wwv_flow_imp.g_varchar2_table(44) := '> 0 then --do inserts and deletes'||wwv_flow.LF||
'            --build the associative arrays'||wwv_flow.LF||
'            for i in 1.';
wwv_flow_imp.g_varchar2_table(45) := '.l_old_tags.count loop'||wwv_flow.LF||
'                l_old_tags_a(l_old_tags(i)) := l_old_tags(i);'||wwv_flow.LF||
'            end';
wwv_flow_imp.g_varchar2_table(46) := ' loop;'||wwv_flow.LF||
'            for i in 1..l_new_tags.count loop'||wwv_flow.LF||
'                l_new_tags_a(l_new_tags(i)) := ';
wwv_flow_imp.g_varchar2_table(47) := 'l_new_tags(i);'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'            --do the inserts'||wwv_flow.LF||
'            for i in 1..l_new_tags';
wwv_flow_imp.g_varchar2_table(48) := '.count loop'||wwv_flow.LF||
'                begin'||wwv_flow.LF||
'                    l_dummy_tag := l_old_tags_a(l_new_tags(i));'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(49) := '              exception when no_data_found then'||wwv_flow.LF||
'                    insert into eba_cust_tags (tag, ';
wwv_flow_imp.g_varchar2_table(50) := 'content_id, content_type )'||wwv_flow.LF||
'                    values (l_new_tags(i), p_content_id, p_content_type )';
wwv_flow_imp.g_varchar2_table(51) := ';'||wwv_flow.LF||
'                    l_merge_tags(l_merge_tags.count + 1) := l_new_tags(i);'||wwv_flow.LF||
'                end;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(52) := '          end loop;'||wwv_flow.LF||
'            --do the deletes'||wwv_flow.LF||
'            for i in 1..l_old_tags.count loop'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(53) := '           begin'||wwv_flow.LF||
'                    l_dummy_tag := l_new_tags_a(l_old_tags(i));'||wwv_flow.LF||
'                exc';
wwv_flow_imp.g_varchar2_table(54) := 'eption when no_data_found then'||wwv_flow.LF||
'                    delete from eba_cust_tags where content_id = p_co';
wwv_flow_imp.g_varchar2_table(55) := 'ntent_id and tag = l_old_tags(i);'||wwv_flow.LF||
'                    l_merge_tags(l_merge_tags.count + 1) := l_old_';
wwv_flow_imp.g_varchar2_table(56) := 'tags(i);'||wwv_flow.LF||
'                end;'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'        else --just do inserts'||wwv_flow.LF||
'            for i';
wwv_flow_imp.g_varchar2_table(57) := ' in 1..l_new_tags.count loop'||wwv_flow.LF||
'                insert into eba_cust_tags (tag, content_id, content_typ';
wwv_flow_imp.g_varchar2_table(58) := 'e )'||wwv_flow.LF||
'                values (l_new_tags(i), p_content_id, p_content_type );'||wwv_flow.LF||
'                l_merge_t';
wwv_flow_imp.g_varchar2_table(59) := 'ags(l_merge_tags.count + 1) := l_new_tags(i);'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        for i in';
wwv_flow_imp.g_varchar2_table(60) := ' 1..l_merge_tags.count loop'||wwv_flow.LF||
'            merge into eba_cust_tags_type_sum s'||wwv_flow.LF||
'            using (selec';
wwv_flow_imp.g_varchar2_table(61) := 't count(*) tag_count'||wwv_flow.LF||
'                     from eba_cust_tags'||wwv_flow.LF||
'                    where tag = l_merge';
wwv_flow_imp.g_varchar2_table(62) := '_tags(i) and content_type = p_content_type ) t'||wwv_flow.LF||
'            on (s.tag = l_merge_tags(i) and s.content';
wwv_flow_imp.g_varchar2_table(63) := '_type = p_content_type )'||wwv_flow.LF||
'            when not matched then insert (tag, content_type, tag_count)'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(64) := '                               values (l_merge_tags(i), p_content_type, t.tag_count)'||wwv_flow.LF||
'            whe';
wwv_flow_imp.g_varchar2_table(65) := 'n matched then update set s.tag_count = t.tag_count;'||wwv_flow.LF||
'            merge into eba_cust_tags_sum s'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(66) := '        using (select sum(tag_count) tag_count'||wwv_flow.LF||
'                     from eba_cust_tags_type_sum'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(67) := '                where tag = l_merge_tags(i) ) t'||wwv_flow.LF||
'            on (s.tag = l_merge_tags(i) )'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(68) := '  when not matched then insert (tag, tag_count)'||wwv_flow.LF||
'                                  values (l_merge_ta';
wwv_flow_imp.g_varchar2_table(69) := 'gs(i), t.tag_count)'||wwv_flow.LF||
'            when matched then update set s.tag_count = t.tag_count;'||wwv_flow.LF||
'        end ';
wwv_flow_imp.g_varchar2_table(70) := 'loop;'||wwv_flow.LF||
'    end tag_sync;'||wwv_flow.LF||
'    function selective_escape ('||wwv_flow.LF||
'        p_text  in varchar2,'||wwv_flow.LF||
'        p_tags ';
wwv_flow_imp.g_varchar2_table(71) := ' in varchar2 default ''<h2>,</h2>,<p>,</p>,<b>,</b>,<li>,</li>,<ul>,</ul>,<br />,<i>,</i>,<h3>,</h3>''';
wwv_flow_imp.g_varchar2_table(72) := ''||wwv_flow.LF||
'        ) return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        t apex_application_global.vc_arr2;'||wwv_flow.LF||
'        x varchar2(3276';
wwv_flow_imp.g_varchar2_table(73) := '7) := p_text;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        t := apex_util.string_to_table(p_tags, '','');'||wwv_flow.LF||
'        for i in 1..t.c';
wwv_flow_imp.g_varchar2_table(74) := 'ount loop'||wwv_flow.LF||
'            x := replace(x,t(i),''Aa''||i||''aA'');'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        x := apex_escape';
wwv_flow_imp.g_varchar2_table(75) := '.html(x);'||wwv_flow.LF||
'        for i in 1..t.count loop'||wwv_flow.LF||
'            x := replace(x,''Aa''||i||''aA'',t(i));'||wwv_flow.LF||
'        e';
wwv_flow_imp.g_varchar2_table(76) := 'nd loop;'||wwv_flow.LF||
'        return x;'||wwv_flow.LF||
'    end selective_escape;'||wwv_flow.LF||
'    function get_preference_value ('||wwv_flow.LF||
'        p_p';
wwv_flow_imp.g_varchar2_table(77) := 'reference_name varchar2 )'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_preference_value varchar2(255);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(78) := '   begin'||wwv_flow.LF||
'        select preference_value'||wwv_flow.LF||
'            into l_preference_value'||wwv_flow.LF||
'        from eba_cust_p';
wwv_flow_imp.g_varchar2_table(79) := 'references'||wwv_flow.LF||
'        where preference_name = p_preference_name;'||wwv_flow.LF||
'        return l_preference_value;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(80) := ' exception'||wwv_flow.LF||
'        when no_data_found then'||wwv_flow.LF||
'            return ''Preference does not exist'';'||wwv_flow.LF||
'    end g';
wwv_flow_imp.g_varchar2_table(81) := 'et_preference_value;'||wwv_flow.LF||
'    procedure set_preference_value ('||wwv_flow.LF||
'        p_preference_name  varchar2, '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(82) := '    p_preference_value varchar2 )'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        merge into eba_cust_preferences dest'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(83) := '    using ( select upper(p_preference_name) preference_name,'||wwv_flow.LF||
'                    p_preference_value ';
wwv_flow_imp.g_varchar2_table(84) := 'preference_value'||wwv_flow.LF||
'                from dual ) src'||wwv_flow.LF||
'        on ( upper(dest.preference_name) = src.pref';
wwv_flow_imp.g_varchar2_table(85) := 'erence_name )'||wwv_flow.LF||
'        when matched then'||wwv_flow.LF||
'            update set dest.preference_value = src.preferenc';
wwv_flow_imp.g_varchar2_table(86) := 'e_value'||wwv_flow.LF||
'        when not matched then'||wwv_flow.LF||
'            insert (dest.preference_name, dest.preference_valu';
wwv_flow_imp.g_varchar2_table(87) := 'e)'||wwv_flow.LF||
'            values (src.preference_name, src.preference_value);'||wwv_flow.LF||
'    end set_preference_value;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(88) := ' function compress_int ('||wwv_flow.LF||
'        n in integer )'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    as'||wwv_flow.LF||
'        ret varchar2(';
wwv_flow_imp.g_varchar2_table(89) := '30);'||wwv_flow.LF||
'        quotient integer;'||wwv_flow.LF||
'        remainder integer;'||wwv_flow.LF||
'        digit char(1);'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        r';
wwv_flow_imp.g_varchar2_table(90) := 'et := '''';'||wwv_flow.LF||
'        quotient := n;'||wwv_flow.LF||
'        while quotient > 0'||wwv_flow.LF||
'        loop'||wwv_flow.LF||
'            remainder := mo';
wwv_flow_imp.g_varchar2_table(91) := 'd(quotient, 10 + 26);'||wwv_flow.LF||
'            quotient := floor(quotient  / (10 + 26));'||wwv_flow.LF||
'            if remainder';
wwv_flow_imp.g_varchar2_table(92) := ' < 26 then'||wwv_flow.LF||
'                digit := chr(ascii(''A'') + remainder);'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'                di';
wwv_flow_imp.g_varchar2_table(93) := 'git := chr(ascii(''0'') + remainder - 26);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            ret := digit || ret;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(94) := '  end loop ;'||wwv_flow.LF||
'        if length(ret) < 5 then'||wwv_flow.LF||
'            ret := lpad(ret, 4, ''A'');'||wwv_flow.LF||
'        end if ;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(95) := '        return upper(ret);'||wwv_flow.LF||
'    end compress_int;'||wwv_flow.LF||
'    procedure add_error_log ( '||wwv_flow.LF||
'        p_error in a';
wwv_flow_imp.g_varchar2_table(96) := 'pex_error.t_error )'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'    pragma autonomous_transaction;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        -- Remove old errors';
wwv_flow_imp.g_varchar2_table(97) := ''||wwv_flow.LF||
'        delete from eba_cust_errors where err_time <= current_timestamp - 21;'||wwv_flow.LF||
'        -- Log the er';
wwv_flow_imp.g_varchar2_table(98) := 'ror.'||wwv_flow.LF||
'        insert into eba_cust_errors ('||wwv_flow.LF||
'            app_id,'||wwv_flow.LF||
'            app_page_id,'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(99) := 'app_user,'||wwv_flow.LF||
'            user_agent,'||wwv_flow.LF||
'            ip_address,'||wwv_flow.LF||
'            ip_address2,'||wwv_flow.LF||
'            messa';
wwv_flow_imp.g_varchar2_table(100) := 'ge,'||wwv_flow.LF||
'            page_item_name,'||wwv_flow.LF||
'            region_id,'||wwv_flow.LF||
'            column_alias,'||wwv_flow.LF||
'            row_num';
wwv_flow_imp.g_varchar2_table(101) := ','||wwv_flow.LF||
'            apex_error_code,'||wwv_flow.LF||
'            ora_sqlcode,'||wwv_flow.LF||
'            ora_sqlerrm,'||wwv_flow.LF||
'            error_b';
wwv_flow_imp.g_varchar2_table(102) := 'acktrace )'||wwv_flow.LF||
'        select v(''APP_ID''),'||wwv_flow.LF||
'            v(''APP_PAGE_ID''),'||wwv_flow.LF||
'            v(''APP_USER''),'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(103) := '        owa_util.get_cgi_env(''HTTP_USER_AGENT''),'||wwv_flow.LF||
'            owa_util.get_cgi_env(''REMOTE_ADDR''),'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(104) := '          sys_context(''USERENV'', ''IP_ADDRESS''),'||wwv_flow.LF||
'            substr(p_error.message,0,4000),'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(105) := '    p_error.page_item_name,'||wwv_flow.LF||
'            p_error.region_id,'||wwv_flow.LF||
'            p_error.column_alias,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(106) := '     p_error.row_num,'||wwv_flow.LF||
'            p_error.apex_error_code,'||wwv_flow.LF||
'            p_error.ora_sqlcode,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(107) := '    substr(p_error.ora_sqlerrm,0,4000),'||wwv_flow.LF||
'            substr(p_error.error_backtrace,0,4000)'||wwv_flow.LF||
'        f';
wwv_flow_imp.g_varchar2_table(108) := 'rom dual;'||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
'    end add_error_log;'||wwv_flow.LF||
'    function apex_error_handling ('||wwv_flow.LF||
'        p_error ';
wwv_flow_imp.g_varchar2_table(109) := 'in apex_error.t_error )'||wwv_flow.LF||
'        return apex_error.t_error_result'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_result          ap';
wwv_flow_imp.g_varchar2_table(110) := 'ex_error.t_error_result;'||wwv_flow.LF||
'        l_constraint_name varchar2(255);'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        l_result := apex';
wwv_flow_imp.g_varchar2_table(111) := '_error.init_error_result ('||wwv_flow.LF||
'                        p_error => p_error );'||wwv_flow.LF||
'        -- If it is an inte';
wwv_flow_imp.g_varchar2_table(112) := 'rnal error raised by APEX, like an invalid statement or'||wwv_flow.LF||
'        -- code which can not be executed, t';
wwv_flow_imp.g_varchar2_table(113) := 'he error text might contain security sensitive'||wwv_flow.LF||
'        -- information. To avoid this security proble';
wwv_flow_imp.g_varchar2_table(114) := 'm we can rewrite the error to'||wwv_flow.LF||
'        -- a generic error message and log the original error message ';
wwv_flow_imp.g_varchar2_table(115) := 'for further'||wwv_flow.LF||
'        -- investigation by the help desk.'||wwv_flow.LF||
'        if p_error.is_internal_error then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(116) := '         -- mask all errors that are not common runtime errors (Access Denied'||wwv_flow.LF||
'            -- errors ';
wwv_flow_imp.g_varchar2_table(117) := 'raised by application / page authorization and all errors'||wwv_flow.LF||
'            -- regarding session and sessi';
wwv_flow_imp.g_varchar2_table(118) := 'on state)'||wwv_flow.LF||
'            if not p_error.is_common_runtime_error then'||wwv_flow.LF||
'                add_error_log( p_e';
wwv_flow_imp.g_varchar2_table(119) := 'rror );'||wwv_flow.LF||
'                -- Change the message to the generic error message which doesn''t expose'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(120) := '            -- any sensitive information.'||wwv_flow.LF||
'                l_result.message         := ''An unexpected';
wwv_flow_imp.g_varchar2_table(121) := ' internal application error has occurred.'';'||wwv_flow.LF||
'                l_result.additional_info := null;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(122) := '      end if;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            -- Always show the error as inline error'||wwv_flow.LF||
'            -- Note:';
wwv_flow_imp.g_varchar2_table(123) := ' If you have created manual tabular forms (using the package'||wwv_flow.LF||
'            --       apex_item/htmldb_i';
wwv_flow_imp.g_varchar2_table(124) := 'tem in the SQL statement) you should still'||wwv_flow.LF||
'            --       use "On error page" on that pages to';
wwv_flow_imp.g_varchar2_table(125) := ' avoid loosing entered data'||wwv_flow.LF||
'            l_result.display_location := case'||wwv_flow.LF||
'                          ';
wwv_flow_imp.g_varchar2_table(126) := '                 when l_result.display_location = apex_error.c_on_error_page then apex_error.c_inlin';
wwv_flow_imp.g_varchar2_table(127) := 'e_in_notification'||wwv_flow.LF||
'                                           else l_result.display_location'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(128) := '                                 end;'||wwv_flow.LF||
'            -- If it''s a constraint violation like'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(129) := ' --'||wwv_flow.LF||
'            --   -) ORA-00001: unique constraint violated'||wwv_flow.LF||
'            --   -) ORA-02091: transac';
wwv_flow_imp.g_varchar2_table(130) := 'tion rolled back (-> can hide a deferred constraint)'||wwv_flow.LF||
'            --   -) ORA-02290: check constraint';
wwv_flow_imp.g_varchar2_table(131) := ' violated'||wwv_flow.LF||
'            --   -) ORA-02291: integrity constraint violated - parent key not found'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(132) := '      --   -) ORA-02292: integrity constraint violated - child record found'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(133) := '   -- we try to get a friendly error message from our constraint lookup configuration.'||wwv_flow.LF||
'            -';
wwv_flow_imp.g_varchar2_table(134) := '- If we don''t find the constraint in our lookup table we fallback to'||wwv_flow.LF||
'            -- the original ORA';
wwv_flow_imp.g_varchar2_table(135) := ' error message.'||wwv_flow.LF||
'            if p_error.ora_sqlcode in (-1, -2091, -2290, -2291, -2292) then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(136) := '        l_constraint_name := apex_error.extract_constraint_name ('||wwv_flow.LF||
'                                  ';
wwv_flow_imp.g_varchar2_table(137) := '       p_error => p_error );'||wwv_flow.LF||
'                begin'||wwv_flow.LF||
'                    select message'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(138) := '        into l_result.message'||wwv_flow.LF||
'                      from eba_cust_error_lookup'||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(139) := 'where constraint_name = l_constraint_name;'||wwv_flow.LF||
'                exception when no_data_found then null; -';
wwv_flow_imp.g_varchar2_table(140) := '- not every constraint has to be in our lookup table'||wwv_flow.LF||
'                end;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(141) := '      -- If an ORA error has been raised, for example a raise_application_error(-20xxx, ''...'')'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(142) := '       -- in a table trigger or in a PL/SQL package called by a process and we'||wwv_flow.LF||
'            -- haven''';
wwv_flow_imp.g_varchar2_table(143) := 't found the error in our lookup table, then we just want to see'||wwv_flow.LF||
'            -- the actual error text';
wwv_flow_imp.g_varchar2_table(144) := ' and not the full error stack with all the ORA error numbers.'||wwv_flow.LF||
'            if p_error.ora_sqlcode is ';
wwv_flow_imp.g_varchar2_table(145) := 'not null and l_result.message = p_error.message then'||wwv_flow.LF||
'                l_result.message := apex_error.';
wwv_flow_imp.g_varchar2_table(146) := 'get_first_ora_error_text ('||wwv_flow.LF||
'                                        p_error => p_error );'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(147) := ' end if;'||wwv_flow.LF||
'            -- If no associated page item/tabular form column has been set, we can use'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(148) := '        -- apex_error.auto_set_associated_item to automatically guess the affected'||wwv_flow.LF||
'            -- er';
wwv_flow_imp.g_varchar2_table(149) := 'ror field by examine the ORA error for constraint names or column names.'||wwv_flow.LF||
'            if l_result.pag';
wwv_flow_imp.g_varchar2_table(150) := 'e_item_name is null and l_result.column_alias is null then'||wwv_flow.LF||
'                apex_error.auto_set_assoc';
wwv_flow_imp.g_varchar2_table(151) := 'iated_item ('||wwv_flow.LF||
'                    p_error        => p_error,'||wwv_flow.LF||
'                    p_error_result => l_';
wwv_flow_imp.g_varchar2_table(152) := 'result );'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        return l_result;'||wwv_flow.LF||
'    end apex_error_handling;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(153) := 'end eba_cust_fw;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16723635280125861217)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Framework Body'
,p_sequence=>390
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
