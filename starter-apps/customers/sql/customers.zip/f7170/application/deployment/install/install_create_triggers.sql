prompt --application/deployment/install/install_create_triggers
begin
--   Manifest
--     INSTALL: INSTALL-create triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger eba_cust_users_biu'||wwv_flow.LF||
'    before insert or update on eba_cust_users'||wwv_flow.LF||
'    for e';
wwv_flow_imp.g_varchar2_table(2) := 'ach row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            :new.id := eba_cust.';
wwv_flow_imp.g_varchar2_table(3) := 'gen_id();'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created_by         := nvl(v(''APP_USER''), USER);'||wwv_flow.LF||
'        :new.';
wwv_flow_imp.g_varchar2_table(4) := 'created            := current_timestamp;'||wwv_flow.LF||
'        :new.row_version        := 1;'||wwv_flow.LF||
'        if :new.accou';
wwv_flow_imp.g_varchar2_table(5) := 'nt_locked is null then'||wwv_flow.LF||
'            :new.account_locked := ''N'';    '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(6) := 'f updating then'||wwv_flow.LF||
'            :new.updated_by         := nvl(v(''APP_USER''), USER);'||wwv_flow.LF||
'            :new.up';
wwv_flow_imp.g_varchar2_table(7) := 'dated            := current_timestamp;'||wwv_flow.LF||
'            :new.row_version        := nvl(:old.row_version,1';
wwv_flow_imp.g_varchar2_table(8) := ') + 1;                                '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- Always store username as upper case'||wwv_flow.LF||
'    :n';
wwv_flow_imp.g_varchar2_table(9) := 'ew.username := upper(:new.username);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_cust_users_b';
wwv_flow_imp.g_varchar2_table(10) := 'd'||wwv_flow.LF||
'    before delete on eba_cust_users'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- Disallow deletes to a user''s own';
wwv_flow_imp.g_varchar2_table(11) := ' record.'||wwv_flow.LF||
'    if v(''APP_USER'') = upper(:old.username) then'||wwv_flow.LF||
'        raise_application_error(-20002, ''D';
wwv_flow_imp.g_varchar2_table(12) := 'elete disallowed, you cannot delete your own access control details.'');'||wwv_flow.LF||
'    end if;    '||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show ';
wwv_flow_imp.g_varchar2_table(13) := 'errors'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_cust_preferences_biu'||wwv_flow.LF||
'before insert or update on eba_cust_pref';
wwv_flow_imp.g_varchar2_table(14) := 'erences'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        :new.id := eba_cust';
wwv_flow_imp.g_varchar2_table(15) := '.gen_id();'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(16) := '     :new.created_on := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by ';
wwv_flow_imp.g_varchar2_table(17) := ':= nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated_on := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.prefe';
wwv_flow_imp.g_varchar2_table(18) := 'rence_name := upper(:new.preference_name);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cu';
wwv_flow_imp.g_varchar2_table(19) := 'st_industries'||wwv_flow.LF||
'   before insert or update on eba_cust_industries'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if in';
wwv_flow_imp.g_varchar2_table(20) := 'serting then'||wwv_flow.LF||
'         if :NEW.ID is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(21) := 'XXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'           into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CR';
wwv_flow_imp.g_varchar2_table(22) := 'EATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :NEW.UPDAT';
wwv_flow_imp.g_varchar2_table(23) := 'ED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_vers';
wwv_flow_imp.g_varchar2_table(24) := 'ion_number := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(25) := '        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:new.row';
wwv_flow_imp.g_varchar2_table(26) := '_version_number,0) + 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cust';
wwv_flow_imp.g_varchar2_table(27) := '_geographies'||wwv_flow.LF||
'   before insert or update on eba_cust_geographies'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if in';
wwv_flow_imp.g_varchar2_table(28) := 'serting then'||wwv_flow.LF||
'         if :NEW.ID is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(29) := 'XXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'           into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CR';
wwv_flow_imp.g_varchar2_table(30) := 'EATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :NEW.UPDAT';
wwv_flow_imp.g_varchar2_table(31) := 'ED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_vers';
wwv_flow_imp.g_varchar2_table(32) := 'ion_number := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(33) := '        :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:new.row';
wwv_flow_imp.g_varchar2_table(34) := '_version_number,0) + 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cust';
wwv_flow_imp.g_varchar2_table(35) := '_categories'||wwv_flow.LF||
'   before insert or update on eba_cust_categories'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inse';
wwv_flow_imp.g_varchar2_table(36) := 'rting then'||wwv_flow.LF||
'         if :NEW.ID is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(37) := 'XXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'           into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREA';
wwv_flow_imp.g_varchar2_table(38) := 'TED := current_timestamp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :NEW.UPDATED';
wwv_flow_imp.g_varchar2_table(39) := ' := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_versio';
wwv_flow_imp.g_varchar2_table(40) := 'n_number := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(41) := '      :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:new.row_v';
wwv_flow_imp.g_varchar2_table(42) := 'ersion_number,0) + 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cust_s';
wwv_flow_imp.g_varchar2_table(43) := 'tatus'||wwv_flow.LF||
'   before insert or update on eba_cust_status'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then';
wwv_flow_imp.g_varchar2_table(44) := ''||wwv_flow.LF||
'         if :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(45) := 'XXXXXXX'')'||wwv_flow.LF||
'            into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := c';
wwv_flow_imp.g_varchar2_table(46) := 'urrent_timestamp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :NEW.UPDATED := curr';
wwv_flow_imp.g_varchar2_table(47) := 'ent_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number';
wwv_flow_imp.g_varchar2_table(48) := ' := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :N';
wwv_flow_imp.g_varchar2_table(49) := 'EW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:new.row_version_n';
wwv_flow_imp.g_varchar2_table(50) := 'umber,0) + 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cust_type'||wwv_flow.LF||
'   be';
wwv_flow_imp.g_varchar2_table(51) := 'fore insert or update on eba_cust_type'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         if ';
wwv_flow_imp.g_varchar2_table(52) := ':NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(53) := '         into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_timest';
wwv_flow_imp.g_varchar2_table(54) := 'amp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp';
wwv_flow_imp.g_varchar2_table(55) := ';'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(56) := 'end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY';
wwv_flow_imp.g_varchar2_table(57) := ' := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:new.row_version_number,0) + 1;';
wwv_flow_imp.g_varchar2_table(58) := ''||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cust_use_case'||wwv_flow.LF||
'   before inse';
wwv_flow_imp.g_varchar2_table(59) := 'rt or update on eba_cust_use_case'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         if :NEW.';
wwv_flow_imp.g_varchar2_table(60) := 'ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(61) := '    into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(62) := '         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(63) := '      :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'      end i';
wwv_flow_imp.g_varchar2_table(64) := 'f;'||wwv_flow.LF||
''||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := n';
wwv_flow_imp.g_varchar2_table(65) := 'vl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(66) := '  end if;'||wwv_flow.LF||
'   end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cust_products'||wwv_flow.LF||
'   before insert or';
wwv_flow_imp.g_varchar2_table(67) := ' update on eba_cust_products'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if :new.tags is not null then'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(68) := '  :new.tags := eba_cust_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         i';
wwv_flow_imp.g_varchar2_table(69) := 'f :NEW.ID is null then'||wwv_flow.LF||
'            select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(70) := '           into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_time';
wwv_flow_imp.g_varchar2_table(71) := 'stamp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :NEW.UPDATED := current_timesta';
wwv_flow_imp.g_varchar2_table(72) := 'mp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(73) := '    eba_cust_fw.tag_sync('||wwv_flow.LF||
'            p_new_tags      => :new.tags,'||wwv_flow.LF||
'            p_old_tags      => n';
wwv_flow_imp.g_varchar2_table(74) := 'ull,'||wwv_flow.LF||
'            p_content_type  => ''PRODUCT'','||wwv_flow.LF||
'            p_content_id    => :new.id );'||wwv_flow.LF||
''||wwv_flow.LF||
'      end ';
wwv_flow_imp.g_varchar2_table(75) := 'if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := ';
wwv_flow_imp.g_varchar2_table(76) := 'nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(77) := '     eba_cust_fw.tag_sync('||wwv_flow.LF||
'            p_new_tags      => :new.tags,'||wwv_flow.LF||
'            p_old_tags      => ';
wwv_flow_imp.g_varchar2_table(78) := ':old.tags,'||wwv_flow.LF||
'            p_content_type  => ''PRODUCT'','||wwv_flow.LF||
'            p_content_id    => :new.id );'||wwv_flow.LF||
''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(79) := '  end if;'||wwv_flow.LF||
'   end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger bd_eba_cust_products'||wwv_flow.LF||
'    before delete on';
wwv_flow_imp.g_varchar2_table(80) := ' eba_cust_products'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    eba_cust_fw.tag_sync('||wwv_flow.LF||
'        p_new_tags      => null';
wwv_flow_imp.g_varchar2_table(81) := ','||wwv_flow.LF||
'        p_old_tags      => :old.tags,'||wwv_flow.LF||
'        p_content_type  => ''PRODUCT'','||wwv_flow.LF||
'        p_content_id  ';
wwv_flow_imp.g_varchar2_table(82) := '  => :old.id );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cust_product_uses'||wwv_flow.LF||
'   before i';
wwv_flow_imp.g_varchar2_table(83) := 'nsert or update on eba_cust_product_uses'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         i';
wwv_flow_imp.g_varchar2_table(84) := 'f :NEW.ID is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(85) := '         into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_timest';
wwv_flow_imp.g_varchar2_table(86) := 'amp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp';
wwv_flow_imp.g_varchar2_table(87) := ';'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(88) := 'end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY';
wwv_flow_imp.g_varchar2_table(89) := ' := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:new.row_version_number,0) + 1;';
wwv_flow_imp.g_varchar2_table(90) := ''||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cust_contacts'||wwv_flow.LF||
'   before ins';
wwv_flow_imp.g_varchar2_table(91) := 'ert or update on eba_cust_contacts'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if :new.tags is not null then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(92) := '        :new.tags := eba_cust_fw.tags_cleaner(:new.tags);'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(93) := '     if :NEW.ID is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(94) := 'X'')'||wwv_flow.LF||
'           into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_';
wwv_flow_imp.g_varchar2_table(95) := 'timestamp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :NEW.UPDATED := current_tim';
wwv_flow_imp.g_varchar2_table(96) := 'estamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(97) := '        eba_cust_fw.tag_sync('||wwv_flow.LF||
'            p_new_tags      => :new.tags,'||wwv_flow.LF||
'            p_old_tags      ';
wwv_flow_imp.g_varchar2_table(98) := '=> null,'||wwv_flow.LF||
'            p_content_type  => ''CONTACT'','||wwv_flow.LF||
'            p_content_id    => :new.id );'||wwv_flow.LF||
'      e';
wwv_flow_imp.g_varchar2_table(99) := 'nd if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY ';
wwv_flow_imp.g_varchar2_table(100) := ':= nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(101) := '        eba_cust_fw.tag_sync('||wwv_flow.LF||
'            p_new_tags      => :new.tags,'||wwv_flow.LF||
'            p_old_tags      ';
wwv_flow_imp.g_varchar2_table(102) := '=> :old.tags,'||wwv_flow.LF||
'            p_content_type  => ''CONTACT'','||wwv_flow.LF||
'            p_content_id    => :new.id );'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(103) := '    end if;'||wwv_flow.LF||
'   end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cust_contact_types'||wwv_flow.LF||
'   before i';
wwv_flow_imp.g_varchar2_table(104) := 'nsert or update on eba_cust_contact_types'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(105) := 'if :NEW.ID is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(106) := '          into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_times';
wwv_flow_imp.g_varchar2_table(107) := 'tamp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestam';
wwv_flow_imp.g_varchar2_table(108) := 'p;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(109) := ' end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_B';
wwv_flow_imp.g_varchar2_table(110) := 'Y := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := nvl(:new.row_version_number,0) + 1';
wwv_flow_imp.g_varchar2_table(111) := ';'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger bd_eba_cust_contacts'||wwv_flow.LF||
'    before delete on eba_';
wwv_flow_imp.g_varchar2_table(112) := 'cust_contacts'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    eba_cust_fw.tag_sync('||wwv_flow.LF||
'        p_new_tags      => null,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(113) := '     p_old_tags      => :old.tags,'||wwv_flow.LF||
'        p_content_type  => ''CONTACT'','||wwv_flow.LF||
'        p_content_id    => ';
wwv_flow_imp.g_varchar2_table(114) := ':old.id );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace'||wwv_flow.LF||
'trigger biu_eba_cust_files'||wwv_flow.LF||
'  before insert or upd';
wwv_flow_imp.g_varchar2_table(115) := 'ate on eba_cust_files'||wwv_flow.LF||
'  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  if (inserting or updating) and nvl(dbms_lob.getlength(:';
wwv_flow_imp.g_varchar2_table(116) := 'new.file_blob),0) > 15728640 then'||wwv_flow.LF||
'    raise_application_error(-20000, ''The size of the uploaded file';
wwv_flow_imp.g_varchar2_table(117) := ' was over 15MB. Please upload a smaller file.'');'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
'  if inserting then'||wwv_flow.LF||
'    if :NEW.ID is nul';
wwv_flow_imp.g_varchar2_table(118) := 'l then'||wwv_flow.LF||
'      select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'        into :new.id'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(119) := '      from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'    :NEW.CREATED_BY := nvl(v(''AP';
wwv_flow_imp.g_varchar2_table(120) := 'P_USER''),USER);'||wwv_flow.LF||
'    :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'    :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER';
wwv_flow_imp.g_varchar2_table(121) := ');'||wwv_flow.LF||
'    :new.row_version_number := 1;'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  if updating then'||wwv_flow.LF||
'    :NEW.UPDATED := current_times';
wwv_flow_imp.g_varchar2_table(122) := 'tamp;'||wwv_flow.LF||
'    :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'    :new.row_version_number := nvl(:new.row_ve';
wwv_flow_imp.g_varchar2_table(123) := 'rsion_number,0) + 1;'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  eba_cust_fw.tag_sync('||wwv_flow.LF||
'    p_new_tags      => :new.tags,'||wwv_flow.LF||
'    p_old_';
wwv_flow_imp.g_varchar2_table(124) := 'tags      => :old.tags,'||wwv_flow.LF||
'    p_content_type  => ''FILE'','||wwv_flow.LF||
'    p_content_id    => :new.id );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show';
wwv_flow_imp.g_varchar2_table(125) := ' errors'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger bd_eba_cust_files'||wwv_flow.LF||
'    before delete on eba_cust_files'||wwv_flow.LF||
'    for eac';
wwv_flow_imp.g_varchar2_table(126) := 'h row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba_cust_fw.tag_sync('||wwv_flow.LF||
'        p_new_tags      => null,'||wwv_flow.LF||
'        p_old_tags      => :o';
wwv_flow_imp.g_varchar2_table(127) := 'ld.tags,'||wwv_flow.LF||
'        p_content_type  => ''FILE'','||wwv_flow.LF||
'        p_content_id    => :old.id );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors';
wwv_flow_imp.g_varchar2_table(128) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cust_links'||wwv_flow.LF||
'   before insert or update on eba_cust_links'||wwv_flow.LF||
'   for e';
wwv_flow_imp.g_varchar2_table(129) := 'ach row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         if :NEW.ID is null then'||wwv_flow.LF||
'           select to_numbe';
wwv_flow_imp.g_varchar2_table(130) := 'r(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'           into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(131) := '    end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl(v(''APP_USER''';
wwv_flow_imp.g_varchar2_table(132) := '),USER);'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),U';
wwv_flow_imp.g_varchar2_table(133) := 'SER);'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UPD';
wwv_flow_imp.g_varchar2_table(134) := 'ATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_ve';
wwv_flow_imp.g_varchar2_table(135) := 'rsion_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or ';
wwv_flow_imp.g_varchar2_table(136) := 'replace trigger biu_eba_cust_administrators'||wwv_flow.LF||
'   before insert or update on eba_cust_administrators'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(137) := ' for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         if :NEW.ID is null then'||wwv_flow.LF||
'            select t';
wwv_flow_imp.g_varchar2_table(138) := 'o_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'              into :new.id'||wwv_flow.LF||
'              fro';
wwv_flow_imp.g_varchar2_table(139) := 'm dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.CREATED_BY := nvl';
wwv_flow_imp.g_varchar2_table(140) := '(v(''APP_USER''),USER);'||wwv_flow.LF||
'         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(';
wwv_flow_imp.g_varchar2_table(141) := '''APP_USER''),USER);'||wwv_flow.LF||
'         :new.row_version_number := 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(142) := '         :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(143) := '      :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show er';
wwv_flow_imp.g_varchar2_table(144) := 'rors'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger  eba_cust_tags_biu'||wwv_flow.LF||
'   before insert or update on eba_cust_tags'||wwv_flow.LF||
'   f';
wwv_flow_imp.g_varchar2_table(145) := 'or each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    :new.tag := upper(:new.tag);'||wwv_flow.LF||
''||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'       if :NEW.TAG_ID is n';
wwv_flow_imp.g_varchar2_table(146) := 'ull then'||wwv_flow.LF||
'          select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'            into ';
wwv_flow_imp.g_varchar2_table(147) := ':new.tag_id'||wwv_flow.LF||
'            from dual;'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'       :';
wwv_flow_imp.g_varchar2_table(148) := 'NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'       :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'       :NEW.UPD';
wwv_flow_imp.g_varchar2_table(149) := 'ATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'  '||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'       :NEW.UPDATED := curre';
wwv_flow_imp.g_varchar2_table(150) := 'nt_timestamp;'||wwv_flow.LF||
'       :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'-- ';
wwv_flow_imp.g_varchar2_table(151) := 'HISTORY TRIGGERS'||wwv_flow.LF||
'create or replace trigger au_eba_cust_customers'||wwv_flow.LF||
'    after update on eba_cust_custom';
wwv_flow_imp.g_varchar2_table(152) := 'ers'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'    nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(153) := ' -- CUSTOMER_NAME (default)'||wwv_flow.LF||
'    if nvl(:old.customer_name, ''0'') != nvl(:new.customer_name,''0'') then ';
wwv_flow_imp.g_varchar2_table(154) := ''||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_';
wwv_flow_imp.g_varchar2_table(155) := 'value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''CUSTOMER_NAME'', substr(:';
wwv_flow_imp.g_varchar2_table(156) := 'old.customer_name,0,4000), substr(:new.customer_name,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CUSTOMER_NAME_UP';
wwv_flow_imp.g_varchar2_table(157) := 'PER (default)'||wwv_flow.LF||
'    if nvl(:old.customer_name_upper, ''0'') != nvl(:new.customer_name_upper,''0'') then '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(158) := '       insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_va';
wwv_flow_imp.g_varchar2_table(159) := 'lue, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''CUSTOMER_NAME_UPPER'', subs';
wwv_flow_imp.g_varchar2_table(160) := 'tr(:old.customer_name_upper,0,4000), substr(:new.customer_name_upper,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- ';
wwv_flow_imp.g_varchar2_table(161) := 'INDUSTRY_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:old.industry_id,-999) != nvl(:new.industry_id,-999) then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(162) := '   ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select industry_name val from eba_cust_industries t wh';
wwv_flow_imp.g_varchar2_table(163) := 'ere t.id = :old.industry_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in (sel';
wwv_flow_imp.g_varchar2_table(164) := 'ect industry_name val from eba_cust_industries t where t.id = :new.industry_id) loop'||wwv_flow.LF||
'            nv ';
wwv_flow_imp.g_varchar2_table(165) := ':= c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, com';
wwv_flow_imp.g_varchar2_table(166) := 'ponent_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id';
wwv_flow_imp.g_varchar2_table(167) := ', ''INDUSTRY_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CATEGORY_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:old.category_id,-';
wwv_flow_imp.g_varchar2_table(168) := '999) != nvl(:new.category_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select ca';
wwv_flow_imp.g_varchar2_table(169) := 'tegory val from eba_cust_categories t where t.id = :old.category_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(170) := '        end loop;'||wwv_flow.LF||
'        for c1 in (select category val from eba_cust_categories t where t.id = :ne';
wwv_flow_imp.g_varchar2_table(171) := 'w.category_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history';
wwv_flow_imp.g_varchar2_table(172) := ' (table_name, component_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(173) := '(''CUSTOMERS'', :new.row_key, :new.id, ''CATEGORY_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- STATUS_ID (foreign k';
wwv_flow_imp.g_varchar2_table(174) := 'ey)'||wwv_flow.LF||
'    if nvl(:old.status_id,-999) != nvl(:new.status_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;';
wwv_flow_imp.g_varchar2_table(175) := ''||wwv_flow.LF||
'        for c1 in (select status val from eba_cust_status t where t.id = :old.status_id) loop'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(176) := '       ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in (select status val from eba_cust_status t w';
wwv_flow_imp.g_varchar2_table(177) := 'here t.id = :new.status_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba';
wwv_flow_imp.g_varchar2_table(178) := '_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values';
wwv_flow_imp.g_varchar2_table(179) := ''||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''STATUS_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- GEOGRAPHY';
wwv_flow_imp.g_varchar2_table(180) := '_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:old.geography_id,-999) != nvl(:new.geography_id,-999) then'||wwv_flow.LF||
'        ov ';
wwv_flow_imp.g_varchar2_table(181) := ':= null; nv := null;'||wwv_flow.LF||
'        for c1 in (select geography_name val from eba_cust_geographies t where ';
wwv_flow_imp.g_varchar2_table(182) := 't.id = :old.geography_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in (select';
wwv_flow_imp.g_varchar2_table(183) := ' geography_name val from eba_cust_geographies t where t.id = :new.geography_id) loop'||wwv_flow.LF||
'            nv ';
wwv_flow_imp.g_varchar2_table(184) := ':= c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, com';
wwv_flow_imp.g_varchar2_table(185) := 'ponent_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id';
wwv_flow_imp.g_varchar2_table(186) := ', ''GEOGRAPHY_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- REFERENCABLE (default)'||wwv_flow.LF||
'    if nvl(:old.referencable, ''';
wwv_flow_imp.g_varchar2_table(187) := '0'') != nvl(:new.referencable,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_';
wwv_flow_imp.g_varchar2_table(188) := 'rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_';
wwv_flow_imp.g_varchar2_table(189) := 'key, :new.id, ''REFERENCABLE'', substr(:old.referencable,0,4000), substr(:new.referencable,0,4000) ); ';
wwv_flow_imp.g_varchar2_table(190) := ''||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- MARQUEE_CUSTOMER_YN (default)'||wwv_flow.LF||
'    if nvl(:old.marquee_customer_yn, ''0'') != nvl(:';
wwv_flow_imp.g_varchar2_table(191) := 'new.marquee_customer_yn,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowke';
wwv_flow_imp.g_varchar2_table(192) := 'y, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, ';
wwv_flow_imp.g_varchar2_table(193) := ':new.id, ''MARQUEE_CUSTOMER'', substr(:old.marquee_customer_yn,0,4000), substr(:new.marquee_customer_y';
wwv_flow_imp.g_varchar2_table(194) := 'n,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- TAGS (default)'||wwv_flow.LF||
'    if nvl(:old.tags, ''0'') != nvl(:new.tags,''0'') the';
wwv_flow_imp.g_varchar2_table(195) := 'n '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, ol';
wwv_flow_imp.g_varchar2_table(196) := 'd_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''TAGS'', substr(:old.tag';
wwv_flow_imp.g_varchar2_table(197) := 's,0,4000), substr(:new.tags,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CUSTOMER_PRODUCTS (default)'||wwv_flow.LF||
'    if nvl(:o';
wwv_flow_imp.g_varchar2_table(198) := 'ld.customer_products, ''0'') != nvl(:new.customer_products,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_his';
wwv_flow_imp.g_varchar2_table(199) := 'tory (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(200) := '     (''CUSTOMERS'', :new.row_key, :new.id, ''CUSTOMER_PRODUCTS'', substr(:old.customer_products,0,4000)';
wwv_flow_imp.g_varchar2_table(201) := ', substr(:new.customer_products,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- NUMBER_OF_USERS (default)'||wwv_flow.LF||
'    if nvl(';
wwv_flow_imp.g_varchar2_table(202) := ':old.number_of_users, ''0'') != nvl(:new.number_of_users,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_histo';
wwv_flow_imp.g_varchar2_table(203) := 'ry (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(204) := '   (''CUSTOMERS'', :new.row_key, :new.id, ''NUMBER_OF_USERS'', substr(:old.number_of_users,0,4000), subs';
wwv_flow_imp.g_varchar2_table(205) := 'tr(:new.number_of_users,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- SUMMARY (default)'||wwv_flow.LF||
'    if nvl(:old.summary, ''0';
wwv_flow_imp.g_varchar2_table(206) := ''') != nvl(:new.summary,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey';
wwv_flow_imp.g_varchar2_table(207) := ', component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :';
wwv_flow_imp.g_varchar2_table(208) := 'new.id, ''SUMMARY'', substr(:old.summary,0,4000), substr(:new.summary,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- C';
wwv_flow_imp.g_varchar2_table(209) := 'USTOMER_PROFILE (default)'||wwv_flow.LF||
'    if nvl(:old.customer_profile, ''0'') != nvl(:new.customer_profile,''0'') t';
wwv_flow_imp.g_varchar2_table(210) := 'hen '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, ';
wwv_flow_imp.g_varchar2_table(211) := 'old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''CUSTOMER_PROFILE'', s';
wwv_flow_imp.g_varchar2_table(212) := 'ubstr(:old.customer_profile,0,4000), substr(:new.customer_profile,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- APP';
wwv_flow_imp.g_varchar2_table(213) := 'LICATIONS (default)'||wwv_flow.LF||
'    if nvl(:old.applications, ''0'') != nvl(:new.applications,''0'') then '||wwv_flow.LF||
'        i';
wwv_flow_imp.g_varchar2_table(214) := 'nsert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new';
wwv_flow_imp.g_varchar2_table(215) := '_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''APPLICATIONS'', substr(:old.applica';
wwv_flow_imp.g_varchar2_table(216) := 'tions,0,4000), substr(:new.applications,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- WEB_SITE (default)'||wwv_flow.LF||
'    if nvl';
wwv_flow_imp.g_varchar2_table(217) := '(:old.web_site, ''0'') != nvl(:new.web_site,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_nam';
wwv_flow_imp.g_varchar2_table(218) := 'e, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMER';
wwv_flow_imp.g_varchar2_table(219) := 'S'', :new.row_key, :new.id, ''WEB_SITE'', substr(:old.web_site,0,4000), substr(:new.web_site,0,4000) );';
wwv_flow_imp.g_varchar2_table(220) := ' '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- LINKEDIN (default)'||wwv_flow.LF||
'    if nvl(:old.linkedin, ''0'') != nvl(:new.linkedin,''0'') the';
wwv_flow_imp.g_varchar2_table(221) := 'n '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, ol';
wwv_flow_imp.g_varchar2_table(222) := 'd_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''LINKEDIN'', substr(:old';
wwv_flow_imp.g_varchar2_table(223) := '.linkedin,0,4000), substr(:new.linkedin,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- FACEBOOK (default)'||wwv_flow.LF||
'    if nvl';
wwv_flow_imp.g_varchar2_table(224) := '(:old.facebook, ''0'') != nvl(:new.facebook,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_nam';
wwv_flow_imp.g_varchar2_table(225) := 'e, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMER';
wwv_flow_imp.g_varchar2_table(226) := 'S'', :new.row_key, :new.id, ''FACEBOOK'', substr(:old.facebook,0,4000), substr(:new.facebook,0,4000) );';
wwv_flow_imp.g_varchar2_table(227) := ' '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- TWITTER (default)'||wwv_flow.LF||
'    if nvl(:old.twitter, ''0'') != nvl(:new.twitter,''0'') then '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(228) := '        insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_v';
wwv_flow_imp.g_varchar2_table(229) := 'alue, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''TWITTER'', substr(:old.twi';
wwv_flow_imp.g_varchar2_table(230) := 'tter,0,4000), substr(:new.twitter,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- STOCK_SYMBOL (default)'||wwv_flow.LF||
'    if nvl(:';
wwv_flow_imp.g_varchar2_table(231) := 'old.stock_symbol, ''0'') != nvl(:new.stock_symbol,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (tab';
wwv_flow_imp.g_varchar2_table(232) := 'le_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CU';
wwv_flow_imp.g_varchar2_table(233) := 'STOMERS'', :new.row_key, :new.id, ''STOCK_SYMBOL'', substr(:old.stock_symbol,0,4000), substr(:new.stock';
wwv_flow_imp.g_varchar2_table(234) := '_symbol,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- SIC (default)'||wwv_flow.LF||
'    if nvl(:old.sic, ''0'') != nvl(:new.sic,''0'') ';
wwv_flow_imp.g_varchar2_table(235) := 'then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_name,';
wwv_flow_imp.g_varchar2_table(236) := ' old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.id, ''SIC'', substr(:old.s';
wwv_flow_imp.g_varchar2_table(237) := 'ic,0,4000), substr(:new.sic,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- DUNS (default)'||wwv_flow.LF||
'    if nvl(:old.duns, ''0'')';
wwv_flow_imp.g_varchar2_table(238) := ' != nvl(:new.duns,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, com';
wwv_flow_imp.g_varchar2_table(239) := 'ponent_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CUSTOMERS'', :new.row_key, :new.i';
wwv_flow_imp.g_varchar2_table(240) := 'd, ''DUNS'', substr(:old.duns,0,4000), substr(:new.duns,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end au_eba_cust_custom';
wwv_flow_imp.g_varchar2_table(241) := 'ers;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger au_eba_cust_customers enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger au_eba_cust_product_u';
wwv_flow_imp.g_varchar2_table(242) := 'ses'||wwv_flow.LF||
'    after update on eba_cust_product_uses'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    ov varchar2(4000) := null';
wwv_flow_imp.g_varchar2_table(243) := ';'||wwv_flow.LF||
'    nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- PRODUCT_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:old.product_id,-9';
wwv_flow_imp.g_varchar2_table(244) := '99) != nvl(:new.product_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select prod';
wwv_flow_imp.g_varchar2_table(245) := 'uct_name val from eba_cust_products t where t.id = :old.product_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(246) := '       end loop;'||wwv_flow.LF||
'        for c1 in (select product_name val from eba_cust_products t where t.id = :n';
wwv_flow_imp.g_varchar2_table(247) := 'ew.product_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history';
wwv_flow_imp.g_varchar2_table(248) := ' (table_name, component_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(249) := '(''PRODUCT_USES'', null, :new.customer_id, ''PRODUCT_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end au_eba_cust_product_';
wwv_flow_imp.g_varchar2_table(250) := 'uses;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger au_eba_cust_product_uses enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger au_eba_cust_conta';
wwv_flow_imp.g_varchar2_table(251) := 'cts'||wwv_flow.LF||
'    after update on eba_cust_contacts'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(252) := '  nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- CUSTOMER_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:old.customer_id,-999';
wwv_flow_imp.g_varchar2_table(253) := ') != nvl(:new.customer_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select custo';
wwv_flow_imp.g_varchar2_table(254) := 'mer_name val from eba_cust_customers t where t.id = :old.customer_id) loop'||wwv_flow.LF||
'            ov := c1.val;';
wwv_flow_imp.g_varchar2_table(255) := ''||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in (select customer_name val from eba_cust_customers t where t.id ';
wwv_flow_imp.g_varchar2_table(256) := '= :new.customer_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_hi';
wwv_flow_imp.g_varchar2_table(257) := 'story (table_name, component_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(258) := '     (''CONTACTS'', null, :new.id, ''CUSTOMER_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- NAME (default)'||wwv_flow.LF||
'    if nv';
wwv_flow_imp.g_varchar2_table(259) := 'l(:old.name, ''0'') != nvl(:new.name,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, comp';
wwv_flow_imp.g_varchar2_table(260) := 'onent_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null';
wwv_flow_imp.g_varchar2_table(261) := ', :new.id, ''NAME'', substr(:old.name,0,4000), substr(:new.name,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- TITLE (';
wwv_flow_imp.g_varchar2_table(262) := 'default)'||wwv_flow.LF||
'    if nvl(:old.title, ''0'') != nvl(:new.title,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_histo';
wwv_flow_imp.g_varchar2_table(263) := 'ry (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(264) := '   (''CONTACTS'', null, :new.id, ''TITLE'', substr(:old.title,0,4000), substr(:new.title,0,4000) ); '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(265) := ' end if;'||wwv_flow.LF||
'    -- COMPANY (default)'||wwv_flow.LF||
'    if nvl(:old.company, ''0'') != nvl(:new.company,''0'') then '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(266) := '   insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value,';
wwv_flow_imp.g_varchar2_table(267) := ' new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''COMPANY'', substr(:old.company,0,4000), ';
wwv_flow_imp.g_varchar2_table(268) := 'substr(:new.company,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- ADDRESS_LINE1 (default)'||wwv_flow.LF||
'    if nvl(:old.address_l';
wwv_flow_imp.g_varchar2_table(269) := 'ine1, ''0'') != nvl(:new.address_line1,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, co';
wwv_flow_imp.g_varchar2_table(270) := 'mponent_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', nu';
wwv_flow_imp.g_varchar2_table(271) := 'll, :new.id, ''ADDRESS_LINE1'', substr(:old.address_line1,0,4000), substr(:new.address_line1,0,4000) )';
wwv_flow_imp.g_varchar2_table(272) := '; '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- ADDRESS_LINE2 (default)'||wwv_flow.LF||
'    if nvl(:old.address_line2, ''0'') != nvl(:new.addres';
wwv_flow_imp.g_varchar2_table(273) := 's_line2,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id,';
wwv_flow_imp.g_varchar2_table(274) := ' column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''ADDRESS_LINE2'',';
wwv_flow_imp.g_varchar2_table(275) := ' substr(:old.address_line2,0,4000), substr(:new.address_line2,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CITY (d';
wwv_flow_imp.g_varchar2_table(276) := 'efault)'||wwv_flow.LF||
'    if nvl(:old.city, ''0'') != nvl(:new.city,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history ';
wwv_flow_imp.g_varchar2_table(277) := '(table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(278) := '(''CONTACTS'', null, :new.id, ''CITY'', substr(:old.city,0,4000), substr(:new.city,0,4000) ); '||wwv_flow.LF||
'    end i';
wwv_flow_imp.g_varchar2_table(279) := 'f;'||wwv_flow.LF||
'    -- STATE (default)'||wwv_flow.LF||
'    if nvl(:old.state, ''0'') != nvl(:new.state,''0'') then '||wwv_flow.LF||
'        insert in';
wwv_flow_imp.g_varchar2_table(280) := 'to eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) ';
wwv_flow_imp.g_varchar2_table(281) := 'values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''STATE'', substr(:old.state,0,4000), substr(:new.stat';
wwv_flow_imp.g_varchar2_table(282) := 'e,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- COUNTRY (default)'||wwv_flow.LF||
'    if nvl(:old.country, ''0'') != nvl(:new.country';
wwv_flow_imp.g_varchar2_table(283) := ',''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column';
wwv_flow_imp.g_varchar2_table(284) := '_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''COUNTRY'', substr(:old.';
wwv_flow_imp.g_varchar2_table(285) := 'country,0,4000), substr(:new.country,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- ZIP (default)'||wwv_flow.LF||
'    if nvl(:old.zi';
wwv_flow_imp.g_varchar2_table(286) := 'p, ''0'') != nvl(:new.zip,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowke';
wwv_flow_imp.g_varchar2_table(287) := 'y, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ';
wwv_flow_imp.g_varchar2_table(288) := '''ZIP'', substr(:old.zip,0,4000), substr(:new.zip,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- EMAIL (default)'||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(289) := 'f nvl(:old.email, ''0'') != nvl(:new.email,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name';
wwv_flow_imp.g_varchar2_table(290) := ', component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS''';
wwv_flow_imp.g_varchar2_table(291) := ', null, :new.id, ''EMAIL'', substr(:old.email,0,4000), substr(:new.email,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(292) := '- PHONE (default)'||wwv_flow.LF||
'    if nvl(:old.phone, ''0'') != nvl(:new.phone,''0'') then '||wwv_flow.LF||
'        insert into eba_c';
wwv_flow_imp.g_varchar2_table(293) := 'ust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(294) := '            (''CONTACTS'', null, :new.id, ''PHONE'', substr(:old.phone,0,4000), substr(:new.phone,0,4000';
wwv_flow_imp.g_varchar2_table(295) := ') ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CELL_PHONE (default)'||wwv_flow.LF||
'    if nvl(:old.cell_phone, ''0'') != nvl(:new.cell_phon';
wwv_flow_imp.g_varchar2_table(296) := 'e,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, colum';
wwv_flow_imp.g_varchar2_table(297) := 'n_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''CELL_PHONE'', substr(:';
wwv_flow_imp.g_varchar2_table(298) := 'old.cell_phone,0,4000), substr(:new.cell_phone,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- FAX (default)'||wwv_flow.LF||
'    if n';
wwv_flow_imp.g_varchar2_table(299) := 'vl(:old.fax, ''0'') != nvl(:new.fax,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, compo';
wwv_flow_imp.g_varchar2_table(300) := 'nent_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null,';
wwv_flow_imp.g_varchar2_table(301) := ' :new.id, ''FAX'', substr(:old.fax,0,4000), substr(:new.fax,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CONTACT_TYP';
wwv_flow_imp.g_varchar2_table(302) := 'E_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:old.contact_type_id,-999) != nvl(:new.contact_type_id,-999) then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(303) := '    ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select contact_type val from eba_cust_contact_types t';
wwv_flow_imp.g_varchar2_table(304) := ' where t.id = :old.contact_type_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 ';
wwv_flow_imp.g_varchar2_table(305) := 'in (select contact_type val from eba_cust_contact_types t where t.id = :new.contact_type_id) loop'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(306) := '          nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name, componen';
wwv_flow_imp.g_varchar2_table(307) := 't_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            (''CONTACTS'', null, :ne';
wwv_flow_imp.g_varchar2_table(308) := 'w.id, ''CONTACT_TYPE_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- NOTES (default)'||wwv_flow.LF||
'    if nvl(:old.notes, ''0'') != ';
wwv_flow_imp.g_varchar2_table(309) := 'nvl(:new.notes,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, compon';
wwv_flow_imp.g_varchar2_table(310) := 'ent_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null, :new.id, ''NOTES'', ';
wwv_flow_imp.g_varchar2_table(311) := 'substr(:old.notes,0,4000), substr(:new.notes,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- TAGS (default)'||wwv_flow.LF||
'    if nv';
wwv_flow_imp.g_varchar2_table(312) := 'l(:old.tags, ''0'') != nvl(:new.tags,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, comp';
wwv_flow_imp.g_varchar2_table(313) := 'onent_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''CONTACTS'', null';
wwv_flow_imp.g_varchar2_table(314) := ', :new.id, ''TAGS'', substr(:old.tags,0,4000), substr(:new.tags,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end au_eba_cus';
wwv_flow_imp.g_varchar2_table(315) := 't_contacts;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger au_eba_cust_contacts enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger au_eba_cust_act';
wwv_flow_imp.g_varchar2_table(316) := 'ivities'||wwv_flow.LF||
'    after update on eba_cust_activities'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    pragma autonomous_trans';
wwv_flow_imp.g_varchar2_table(317) := 'action;'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'    nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- TYPE_ID (foreign ';
wwv_flow_imp.g_varchar2_table(318) := 'key)'||wwv_flow.LF||
'    if nvl(:old.type_id,-999) != nvl(:new.type_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(319) := '      for c1 in (select name val from eba_cust_activity_types t where t.id = :old.type_id) loop'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(320) := '        ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in (select name val from eba_cust_activity_ty';
wwv_flow_imp.g_varchar2_table(321) := 'pes t where t.id = :new.type_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert int';
wwv_flow_imp.g_varchar2_table(322) := 'o eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) v';
wwv_flow_imp.g_varchar2_table(323) := 'alues'||wwv_flow.LF||
'            (''ACTIVITIES'', null, :new.id, ''TYPE_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- NAME (default';
wwv_flow_imp.g_varchar2_table(324) := ')'||wwv_flow.LF||
'    if nvl(:old.name, ''0'') != nvl(:new.name,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table';
wwv_flow_imp.g_varchar2_table(325) := '_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''ACTI';
wwv_flow_imp.g_varchar2_table(326) := 'VITIES'', null, :new.id, ''NAME'', substr(:old.name,0,4000), substr(:new.name,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(327) := '   -- DESCRIPTION (default)'||wwv_flow.LF||
'    if nvl(:old.description, ''0'') != nvl(:new.description,''0'') then '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(328) := '     insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_valu';
wwv_flow_imp.g_varchar2_table(329) := 'e, new_value) values '||wwv_flow.LF||
'            (''ACTIVITIES'', null, :new.id, ''DESCRIPTION'', substr(:old.descripti';
wwv_flow_imp.g_varchar2_table(330) := 'on,0,4000), substr(:new.description,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- ACTIVITY_DATE (date/timestamp)'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(331) := '  if (:old.activity_date is null and :new.activity_date is not null) or '||wwv_flow.LF||
'        (:old.activity_date';
wwv_flow_imp.g_varchar2_table(332) := ' is not null and :new.activity_date is null) or '||wwv_flow.LF||
'        (:old.activity_date != :new.activity_date) ';
wwv_flow_imp.g_varchar2_table(333) := 'then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_name,';
wwv_flow_imp.g_varchar2_table(334) := ' old_value, new_value) values '||wwv_flow.LF||
'            (''ACTIVITIES'', null, :new.id, ''ACTIVITY_DATE'', to_char(:o';
wwv_flow_imp.g_varchar2_table(335) := 'ld.activity_date, ''DD-MON-YYYY''), to_char(:new.activity_date, ''DD-MON-YYYY'') );'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- O';
wwv_flow_imp.g_varchar2_table(336) := 'WNER (default)'||wwv_flow.LF||
'    if nvl(:old.owner, ''0'') != nvl(:new.owner,''0'') then '||wwv_flow.LF||
'        insert into eba_cust';
wwv_flow_imp.g_varchar2_table(337) := '_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(338) := '         (''ACTIVITIES'', null, :new.id, ''OWNER'', substr(:old.owner,0,4000), substr(:new.owner,0,4000)';
wwv_flow_imp.g_varchar2_table(339) := ' ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- LOCATION (default)'||wwv_flow.LF||
'    if nvl(:old.location, ''0'') != nvl(:new.location,''0'') ';
wwv_flow_imp.g_varchar2_table(340) := 'then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, component_id, column_name,';
wwv_flow_imp.g_varchar2_table(341) := ' old_value, new_value) values '||wwv_flow.LF||
'            (''ACTIVITIES'', null, :new.id, ''LOCATION'', substr(:old.loc';
wwv_flow_imp.g_varchar2_table(342) := 'ation,0,4000), substr(:new.location,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end au_eba_cust_activities;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(343) := '/'||wwv_flow.LF||
'alter trigger au_eba_cust_activities enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger au_eba_cust_competitors'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(344) := '   after update on eba_cust_competitors'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    pragma autonomous_transaction;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(345) := '    ov varchar2(4000) := null;'||wwv_flow.LF||
'    nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- NAME (default)'||wwv_flow.LF||
'    if nvl';
wwv_flow_imp.g_varchar2_table(346) := '(:old.name, ''0'') != nvl(:new.name,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, compo';
wwv_flow_imp.g_varchar2_table(347) := 'nent_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''COMPETITORS'', nu';
wwv_flow_imp.g_varchar2_table(348) := 'll, :new.id, ''NAME'', substr(:old.name,0,4000), substr(:new.name,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- DESCR';
wwv_flow_imp.g_varchar2_table(349) := 'IPTION (default)'||wwv_flow.LF||
'    if nvl(:old.description, ''0'') != nvl(:new.description,''0'') then '||wwv_flow.LF||
'        insert';
wwv_flow_imp.g_varchar2_table(350) := ' into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_valu';
wwv_flow_imp.g_varchar2_table(351) := 'e) values '||wwv_flow.LF||
'            (''COMPETITORS'', null, :new.id, ''DESCRIPTION'', substr(:old.description,0,4000)';
wwv_flow_imp.g_varchar2_table(352) := ', substr(:new.description,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- WEBSITE (default)'||wwv_flow.LF||
'    if nvl(:old.website, ';
wwv_flow_imp.g_varchar2_table(353) := '''0'') != nvl(:new.website,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowk';
wwv_flow_imp.g_varchar2_table(354) := 'ey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''COMPETITORS'', null, :new.';
wwv_flow_imp.g_varchar2_table(355) := 'id, ''WEBSITE'', substr(:old.website,0,4000), substr(:new.website,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(356) := 'end au_eba_cust_competitors;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger au_eba_cust_competitors enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace tri';
wwv_flow_imp.g_varchar2_table(357) := 'gger  eba_cust_product_statuses_biu'||wwv_flow.LF||
'   before insert or update on eba_cust_product_statuses'||wwv_flow.LF||
'   for e';
wwv_flow_imp.g_varchar2_table(358) := 'ach row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :NEW.ID is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(359) := 'XXXXXXXXXXXXXX'')'||wwv_flow.LF||
'           into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(360) := '     :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'       :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'       :N';
wwv_flow_imp.g_varchar2_table(361) := 'EW.UPDATED := current_timestamp;'||wwv_flow.LF||
'       :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'  '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(362) := '   if updating then'||wwv_flow.LF||
'       :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'       :NEW.UPDATED_BY := nvl(v(''APP_U';
wwv_flow_imp.g_varchar2_table(363) := 'SER''),USER);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger au_eba_cust_cust_partner_ref'||wwv_flow.LF||
'    after in';
wwv_flow_imp.g_varchar2_table(364) := 'sert or update or delete on eba_cust_cust_partner_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    pragma autonomous';
wwv_flow_imp.g_varchar2_table(365) := '_transaction;'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'    nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    ov := null; nv';
wwv_flow_imp.g_varchar2_table(366) := ' := null;'||wwv_flow.LF||
'    for c1 in (select name val from eba_cust_impl_partners t where t.id = :old.partner_id)';
wwv_flow_imp.g_varchar2_table(367) := ' loop'||wwv_flow.LF||
'        ov := c1.val;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    for c1 in (select name val from eba_cust_impl_partners';
wwv_flow_imp.g_varchar2_table(368) := ' t where t.id = :new.partner_id) loop'||wwv_flow.LF||
'        nv := c1.val;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    insert into eba_cust_h';
wwv_flow_imp.g_varchar2_table(369) := 'istory (table_name, component_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(370) := '  (''CUSTOMERS'', null, nvl(:new.customer_id,:old.customer_id), ''PARTNER_ID'', ov, nv);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end';
wwv_flow_imp.g_varchar2_table(371) := ' au_eba_cust_cust_partner_ref;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger au_eba_cust_cust_partner_ref enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or repl';
wwv_flow_imp.g_varchar2_table(372) := 'ace trigger au_eba_cust_cust_competitor_re'||wwv_flow.LF||
'    after insert or update or delete on eba_cust_cust_com';
wwv_flow_imp.g_varchar2_table(373) := 'petitor_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    pragma autonomous_transaction;'||wwv_flow.LF||
'    ov varchar2(4000) := nul';
wwv_flow_imp.g_varchar2_table(374) := 'l;'||wwv_flow.LF||
'    nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    ov := null; nv := null;'||wwv_flow.LF||
'    for c1 in (select name val f';
wwv_flow_imp.g_varchar2_table(375) := 'rom eba_cust_competitors t where t.id = :old.competitor_id) loop'||wwv_flow.LF||
'        ov := c1.val;'||wwv_flow.LF||
'    end loop;';
wwv_flow_imp.g_varchar2_table(376) := ''||wwv_flow.LF||
'    for c1 in (select name val from eba_cust_competitors t where t.id = :new.competitor_id) loop'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(377) := '      nv := c1.val;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    insert into eba_cust_history (table_name, component_rowkey, co';
wwv_flow_imp.g_varchar2_table(378) := 'mponent_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'        (''CUSTOMERS'', null, nvl(:new.customer_';
wwv_flow_imp.g_varchar2_table(379) := 'id,:old.customer_id), ''COMPETITOR_ID'', ov, nv);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end au_eba_cust_cust_competitor_re;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'al';
wwv_flow_imp.g_varchar2_table(380) := 'ter trigger au_eba_cust_cust_competitor_re enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger au_eba_cust_customer_';
wwv_flow_imp.g_varchar2_table(381) := 'reftype_r'||wwv_flow.LF||
'    after insert or update or delete on eba_cust_customer_reftype_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'dec';
wwv_flow_imp.g_varchar2_table(382) := 'lare'||wwv_flow.LF||
'    pragma autonomous_transaction;'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'    nv varchar2(4000) := null';
wwv_flow_imp.g_varchar2_table(383) := ';'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    ov := null; nv := null;'||wwv_flow.LF||
'    for c1 in (select reference_type val from eba_cust_reference';
wwv_flow_imp.g_varchar2_table(384) := '_types t where t.id = :old.reference_type_id) loop'||wwv_flow.LF||
'        ov := c1.val;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    for c1 in';
wwv_flow_imp.g_varchar2_table(385) := ' (select reference_type val from eba_cust_reference_types t where t.id = :new.reference_type_id) loo';
wwv_flow_imp.g_varchar2_table(386) := 'p'||wwv_flow.LF||
'        nv := c1.val;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    insert into eba_cust_history (table_name, component_rowkey';
wwv_flow_imp.g_varchar2_table(387) := ', component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'        (''CUSTOMERS'', null, nvl(:new.custo';
wwv_flow_imp.g_varchar2_table(388) := 'mer_id,:old.customer_id), ''REFERENCE_TYPE_ID'', ov, nv);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end au_eba_cust_customer_reftype';
wwv_flow_imp.g_varchar2_table(389) := '_r;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger au_eba_cust_customer_reftype_r enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger au_eba_cust_a';
wwv_flow_imp.g_varchar2_table(390) := 'ctivity_ref'||wwv_flow.LF||
'    after update on eba_cust_activity_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    pragma autonomous';
wwv_flow_imp.g_varchar2_table(391) := '_transaction;'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'    nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- ACTIVITY_ID';
wwv_flow_imp.g_varchar2_table(392) := ' (foreign key)'||wwv_flow.LF||
'    if nvl(:old.activity_id,-999) != nvl(:new.activity_id,-999) then'||wwv_flow.LF||
'        ov := nu';
wwv_flow_imp.g_varchar2_table(393) := 'll; nv := null;'||wwv_flow.LF||
'        for c1 in (select name val from eba_cust_activities t where t.id = :old.acti';
wwv_flow_imp.g_varchar2_table(394) := 'vity_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in (select name val from eb';
wwv_flow_imp.g_varchar2_table(395) := 'a_cust_activities t where t.id = :new.activity_id) loop'||wwv_flow.LF||
'            nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(396) := '        insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_v';
wwv_flow_imp.g_varchar2_table(397) := 'alue, new_value) values'||wwv_flow.LF||
'            (''ACTIVITY_REF'', null, :new.id, ''ACTIVITY_ID'', ov, nv);'||wwv_flow.LF||
'    end ';
wwv_flow_imp.g_varchar2_table(398) := 'if;'||wwv_flow.LF||
'    -- CUSTOMER_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:old.customer_id,-999) != nvl(:new.customer_id,-999)';
wwv_flow_imp.g_varchar2_table(399) := ' then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select row_key val from eba_cust_customers ';
wwv_flow_imp.g_varchar2_table(400) := 't where t.id = :old.customer_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        for c1 in ';
wwv_flow_imp.g_varchar2_table(401) := '(select row_key val from eba_cust_customers t where t.id = :new.customer_id) loop'||wwv_flow.LF||
'            nv := ';
wwv_flow_imp.g_varchar2_table(402) := 'c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, compon';
wwv_flow_imp.g_varchar2_table(403) := 'ent_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            (''ACTIVITY_REF'', null, :new.id, ''CUSTO';
wwv_flow_imp.g_varchar2_table(404) := 'MER_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- CONTACT_ID (foreign key)'||wwv_flow.LF||
'    if nvl(:old.contact_id,-999) != nv';
wwv_flow_imp.g_varchar2_table(405) := 'l(:new.contact_id,-999) then'||wwv_flow.LF||
'        ov := null; nv := null;'||wwv_flow.LF||
'        for c1 in (select name val from';
wwv_flow_imp.g_varchar2_table(406) := ' eba_cust_contacts t where t.id = :old.contact_id) loop'||wwv_flow.LF||
'            ov := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(407) := '        for c1 in (select name val from eba_cust_contacts t where t.id = :new.contact_id) loop'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(408) := '       nv := c1.val;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_r';
wwv_flow_imp.g_varchar2_table(409) := 'owkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'            (''ACTIVITY_REF'', null, :n';
wwv_flow_imp.g_varchar2_table(410) := 'ew.id, ''CONTACT_ID'', ov, nv);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- ACTIVITY_DATE (date/timestamp)'||wwv_flow.LF||
'    if (:old.activit';
wwv_flow_imp.g_varchar2_table(411) := 'y_date is null and :new.activity_date is not null) or '||wwv_flow.LF||
'        (:old.activity_date is not null and :';
wwv_flow_imp.g_varchar2_table(412) := 'new.activity_date is null) or '||wwv_flow.LF||
'        (:old.activity_date != :new.activity_date) then '||wwv_flow.LF||
'        inse';
wwv_flow_imp.g_varchar2_table(413) := 'rt into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, new_va';
wwv_flow_imp.g_varchar2_table(414) := 'lue) values '||wwv_flow.LF||
'            (''ACTIVITY_REF'', null, :new.id, ''ACTIVITY_DATE'', to_char(:old.activity_date';
wwv_flow_imp.g_varchar2_table(415) := ', ''DD-MON-YYYY''), to_char(:new.activity_date, ''DD-MON-YYYY'') );'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- OWNER (default)'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(416) := '   if nvl(:old.owner, ''0'') != nvl(:new.owner,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_';
wwv_flow_imp.g_varchar2_table(417) := 'name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''ACTIV';
wwv_flow_imp.g_varchar2_table(418) := 'ITY_REF'', null, :new.id, ''OWNER'', substr(:old.owner,0,4000), substr(:new.owner,0,4000) ); '||wwv_flow.LF||
'    end i';
wwv_flow_imp.g_varchar2_table(419) := 'f;'||wwv_flow.LF||
'    -- LOCATION (default)'||wwv_flow.LF||
'    if nvl(:old.location, ''0'') != nvl(:new.location,''0'') then '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(420) := 'insert into eba_cust_history (table_name, component_rowkey, component_id, column_name, old_value, ne';
wwv_flow_imp.g_varchar2_table(421) := 'w_value) values '||wwv_flow.LF||
'            (''ACTIVITY_REF'', null, :new.id, ''LOCATION'', substr(:old.location,0,4000';
wwv_flow_imp.g_varchar2_table(422) := '), substr(:new.location,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- NOTES (default)'||wwv_flow.LF||
'    if nvl(:old.notes, ''0'') !';
wwv_flow_imp.g_varchar2_table(423) := '= nvl(:new.notes,''0'') then '||wwv_flow.LF||
'        insert into eba_cust_history (table_name, component_rowkey, comp';
wwv_flow_imp.g_varchar2_table(424) := 'onent_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''ACTIVITY_REF'', null, :new.id, ''NO';
wwv_flow_imp.g_varchar2_table(425) := 'TES'', substr(:old.notes,0,4000), substr(:new.notes,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end au_eba_cu';
wwv_flow_imp.g_varchar2_table(426) := 'st_activity_ref;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger au_eba_cust_activity_ref enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'show errors'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(17822466705920678542)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'create triggers'
,p_sequence=>370
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
