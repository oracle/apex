prompt --application/deployment/install/install_activities
begin
--   Manifest
--     INSTALL: INSTALL-Activities
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- Activity Types'||wwv_flow.LF||
'create table eba_cust_activity_types ('||wwv_flow.LF||
'    id                 number not null,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(2) := ' row_version_number number not null,'||wwv_flow.LF||
'    name               varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created       ';
wwv_flow_imp.g_varchar2_table(3) := '     timestamp with time zone not null,'||wwv_flow.LF||
'    created_by         varchar2(255) not null,'||wwv_flow.LF||
'    updated  ';
wwv_flow_imp.g_varchar2_table(4) := '          timestamp with time zone,'||wwv_flow.LF||
'    updated_by         varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    constraint eba_';
wwv_flow_imp.g_varchar2_table(5) := 'cust_activity_types_pk primary key ( id ) using index'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust_activity_type';
wwv_flow_imp.g_varchar2_table(6) := 's_uk on eba_cust_activity_types( name );'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cust_activity_types'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(7) := '  before insert or update on eba_cust_activity_types'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(8) := '      if :new.id is null then'||wwv_flow.LF||
'            :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(9) := 'XXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := nvl';
wwv_flow_imp.g_varchar2_table(10) := '(v(''APP_USER''),user);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        :new.row_version_number';
wwv_flow_imp.g_varchar2_table(11) := ' := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.';
wwv_flow_imp.g_varchar2_table(12) := 'updated_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end biu_eba_cust_activity_types;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger biu_eba_cust';
wwv_flow_imp.g_varchar2_table(13) := '_activity_types enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into eba_cust_activity_types ( id, name ) values ( 1, ''P';
wwv_flow_imp.g_varchar2_table(14) := 'resentation'' );'||wwv_flow.LF||
'    insert into eba_cust_activity_types ( id, name ) values ( 2, ''Phone Call'' );'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(15) := ' insert into eba_cust_activity_types ( id, name ) values ( 3, ''Conference'' );'||wwv_flow.LF||
'    insert into eba_cu';
wwv_flow_imp.g_varchar2_table(16) := 'st_activity_types ( id, name ) values ( 4, ''Meeting'' );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Activities'||wwv_flow.LF||
'create table eba_cust_';
wwv_flow_imp.g_varchar2_table(17) := 'activities ('||wwv_flow.LF||
'    id                 number not null,'||wwv_flow.LF||
'    row_version_number number not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(18) := '    type_id            number not null,'||wwv_flow.LF||
'    name               varchar2(255),'||wwv_flow.LF||
'    description       ';
wwv_flow_imp.g_varchar2_table(19) := ' varchar2(4000),'||wwv_flow.LF||
'    activity_date      date,'||wwv_flow.LF||
'    owner              varchar2(255),'||wwv_flow.LF||
'    location    ';
wwv_flow_imp.g_varchar2_table(20) := '       varchar2(4000),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created            timestamp with time zone not null,'||wwv_flow.LF||
'    created_';
wwv_flow_imp.g_varchar2_table(21) := 'by         varchar2(255) not null,'||wwv_flow.LF||
'    updated            timestamp with time zone,'||wwv_flow.LF||
'    updated_by  ';
wwv_flow_imp.g_varchar2_table(22) := '       varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    constraint eba_cust_activities_pk primary key ( id ) using index,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(23) := '   constraint eba_cust_activities_fk foreign key ( type_id )'||wwv_flow.LF||
'        references eba_cust_activity_ty';
wwv_flow_imp.g_varchar2_table(24) := 'pes( id )'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create index eba_cust_activities_idx1 on eba_cust_activities( type_id )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or re';
wwv_flow_imp.g_varchar2_table(25) := 'place trigger biu_eba_cust_activities'||wwv_flow.LF||
'    before insert or update on eba_cust_activities'||wwv_flow.LF||
'    for eac';
wwv_flow_imp.g_varchar2_table(26) := 'h row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            :new.id := to_number(s';
wwv_flow_imp.g_varchar2_table(27) := 'ys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created := current_times';
wwv_flow_imp.g_varchar2_table(28) := 'tamp;'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(29) := 'else'||wwv_flow.LF||
'        :new.row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.upd';
wwv_flow_imp.g_varchar2_table(30) := 'ated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end biu_eba_cust_activiti';
wwv_flow_imp.g_varchar2_table(31) := 'es;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger biu_eba_cust_activities enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Activity Files'||wwv_flow.LF||
'create table eba_cust_activ';
wwv_flow_imp.g_varchar2_table(32) := 'ity_files ('||wwv_flow.LF||
'    id                 number not null,'||wwv_flow.LF||
'    row_version_number number not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(33) := '   activity_id        number not null,'||wwv_flow.LF||
'    file_name          varchar2(512),'||wwv_flow.LF||
'    file_mimetype      ';
wwv_flow_imp.g_varchar2_table(34) := 'varchar2(512),'||wwv_flow.LF||
'    file_charset       varchar2(512),'||wwv_flow.LF||
'    file_last_update   date,'||wwv_flow.LF||
'    file_blob     ';
wwv_flow_imp.g_varchar2_table(35) := '     blob,'||wwv_flow.LF||
'    file_comments      varchar2(4000),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created            timestamp (6) with t';
wwv_flow_imp.g_varchar2_table(36) := 'ime zone not null,'||wwv_flow.LF||
'    created_by         varchar2(255) not null,'||wwv_flow.LF||
'    updated            timestamp (';
wwv_flow_imp.g_varchar2_table(37) := '6) with time zone,'||wwv_flow.LF||
'    updated_by         varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    constraint eba_cust_activity_fil';
wwv_flow_imp.g_varchar2_table(38) := 'es_pk primary key ( id ) using index,'||wwv_flow.LF||
'    constraint eba_cust_activity_files_fk foreign key ( activi';
wwv_flow_imp.g_varchar2_table(39) := 'ty_id )'||wwv_flow.LF||
'        references eba_cust_activities ( id ) on delete cascade'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create index eba_cust_ac';
wwv_flow_imp.g_varchar2_table(40) := 'tivity_files_idx1 on eba_cust_activity_files( activity_id )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger biu_eba_cust';
wwv_flow_imp.g_varchar2_table(41) := '_activity_files'||wwv_flow.LF||
'    before insert or update on eba_cust_activity_files'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if';
wwv_flow_imp.g_varchar2_table(42) := ' inserting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            :new.id := to_number(sys_guid(),''XXXXXXX';
wwv_flow_imp.g_varchar2_table(43) := 'XXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new';
wwv_flow_imp.g_varchar2_table(44) := '.created_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        :new.';
wwv_flow_imp.g_varchar2_table(45) := 'row_version_number := nvl(:new.row_version_number,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := current_ti';
wwv_flow_imp.g_varchar2_table(46) := 'mestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end biu_eba_cust_activity_files;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter tr';
wwv_flow_imp.g_varchar2_table(47) := 'igger biu_eba_cust_activity_files enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Activity References'||wwv_flow.LF||
'create table eba_cust_activity_r';
wwv_flow_imp.g_varchar2_table(48) := 'ef ('||wwv_flow.LF||
'    id            number not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    activity_id   number not null,'||wwv_flow.LF||
'    customer_id   ';
wwv_flow_imp.g_varchar2_table(49) := 'number not null,'||wwv_flow.LF||
'    contact_id    number,'||wwv_flow.LF||
'    activity_date date,'||wwv_flow.LF||
'    owner         varchar2(255),'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(50) := '    location      varchar2(4000),'||wwv_flow.LF||
'    notes         varchar2(4000),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    row_version_number nu';
wwv_flow_imp.g_varchar2_table(51) := 'mber default 1 not null,'||wwv_flow.LF||
'    created            timestamp (6) with time zone not null,'||wwv_flow.LF||
'    created_b';
wwv_flow_imp.g_varchar2_table(52) := 'y         varchar2(255) not null,'||wwv_flow.LF||
'    updated            timestamp (6) with time zone,'||wwv_flow.LF||
'    updated_b';
wwv_flow_imp.g_varchar2_table(53) := 'y         varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    constraint eba_cust_activity_ref_pk primary key ( id ) using ind';
wwv_flow_imp.g_varchar2_table(54) := 'ex,'||wwv_flow.LF||
'    constraint eba_cust_activity_ref_fk1 foreign key ( activity_id )'||wwv_flow.LF||
'        references eba_cust';
wwv_flow_imp.g_varchar2_table(55) := '_activities ( id ) on delete cascade,'||wwv_flow.LF||
'    constraint eba_cust_activity_ref_fk2 foreign key ( custome';
wwv_flow_imp.g_varchar2_table(56) := 'r_id )'||wwv_flow.LF||
'        references eba_cust_customers ( id ) on delete cascade,'||wwv_flow.LF||
'    constraint eba_cust_activ';
wwv_flow_imp.g_varchar2_table(57) := 'ity_ref_fk3 foreign key ( contact_id )'||wwv_flow.LF||
'        references eba_cust_contacts ( id ) on delete set nul';
wwv_flow_imp.g_varchar2_table(58) := 'l'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create index eba_cust_activity_ref_idx1 on eba_cust_activity_ref ( activity_id )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create inde';
wwv_flow_imp.g_varchar2_table(59) := 'x eba_cust_activity_ref_idx2 on eba_cust_activity_ref ( customer_id )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create index eba_cust_activi';
wwv_flow_imp.g_varchar2_table(60) := 'ty_ref_idx3 on eba_cust_activity_ref ( contact_id )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger biu_eba_cust_activit';
wwv_flow_imp.g_varchar2_table(61) := 'y_ref'||wwv_flow.LF||
'    before insert or update on eba_cust_activity_ref'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting t';
wwv_flow_imp.g_varchar2_table(62) := 'hen'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(63) := 'XXXXXXXXXXXXX'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by ';
wwv_flow_imp.g_varchar2_table(64) := ':= nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'        :new.row_version_number := 1; '||wwv_flow.LF||
'    else '||wwv_flow.LF||
'        :new.row_versio';
wwv_flow_imp.g_varchar2_table(65) := 'n_number := nvl(:new.row_version_number,0) + 1; '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(66) := '    :new.updated_by := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'end biu_eba_cust_activity_ref;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger biu_e';
wwv_flow_imp.g_varchar2_table(67) := 'ba_cust_activity_ref enable;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(18149793668795561929)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Activities'
,p_sequence=>360
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
