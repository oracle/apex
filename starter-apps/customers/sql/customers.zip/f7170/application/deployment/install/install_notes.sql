prompt --application/deployment/install/install_notes
begin
--   Manifest
--     INSTALL: INSTALL-notes
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE EBA_CUST_NOTES'||wwv_flow.LF||
'   ( '||wwv_flow.LF||
'    ID                     NUMBER constraint EBA_CUST_notes_pk pri';
wwv_flow_imp.g_varchar2_table(2) := 'mary key, '||wwv_flow.LF||
'    ROW_VERSION_NUMBER     NUMBER not null, '||wwv_flow.LF||
'    CUSTOMER_ID            NUMBER not null'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(3) := '                            references eba_cust_customers (id)'||wwv_flow.LF||
'                             on delet';
wwv_flow_imp.g_varchar2_table(4) := 'e cascade,'||wwv_flow.LF||
'    CONTACT_ID             NUMBER'||wwv_flow.LF||
'                             references eba_cust_contac';
wwv_flow_imp.g_varchar2_table(5) := 'ts (id)'||wwv_flow.LF||
'                             on delete cascade,'||wwv_flow.LF||
'    NOTE_DATE              DATE,'||wwv_flow.LF||
'    NOTE   ';
wwv_flow_imp.g_varchar2_table(6) := '                CLOB, '||wwv_flow.LF||
'    tags                   VARCHAR2(4000 BYTE), '||wwv_flow.LF||
'    CREATED                t';
wwv_flow_imp.g_varchar2_table(7) := 'imestamp with time zone, '||wwv_flow.LF||
'    CREATED_BY             VARCHAR2(255 BYTE), '||wwv_flow.LF||
'    UPDATED               ';
wwv_flow_imp.g_varchar2_table(8) := ' timestamp with time zone, '||wwv_flow.LF||
'    UPDATED_BY             VARCHAR2(255 BYTE)'||wwv_flow.LF||
'   );'||wwv_flow.LF||
''||wwv_flow.LF||
'create index EBA_CU';
wwv_flow_imp.g_varchar2_table(9) := 'ST_NOTES_i1 on EBA_CUST_NOTES(customer_id);'||wwv_flow.LF||
'create index eba_cust_notes_contact_idx on eba_cust_note';
wwv_flow_imp.g_varchar2_table(10) := 's(contact_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER BIU_EBA_CUST_NOTES '||wwv_flow.LF||
'   before insert or update on EBA_CUST';
wwv_flow_imp.g_varchar2_table(11) := '_NOTES'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new."ID" is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXX';
wwv_flow_imp.g_varchar2_table(12) := 'XXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.creat';
wwv_flow_imp.g_varchar2_table(13) := 'ed := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated :=';
wwv_flow_imp.g_varchar2_table(14) := ' current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_num';
wwv_flow_imp.g_varchar2_table(15) := 'ber := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + ';
wwv_flow_imp.g_varchar2_table(16) := '1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new';
wwv_flow_imp.g_varchar2_table(17) := '.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TRIGGER BIU_EBA_CUST_NOTES ENABLE';
wwv_flow_imp.g_varchar2_table(18) := ';'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16437400283215528660)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'notes'
,p_sequence=>450
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
