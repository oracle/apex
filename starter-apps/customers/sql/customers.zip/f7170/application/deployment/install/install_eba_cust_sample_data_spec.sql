prompt --application/deployment/install/install_eba_cust_sample_data_spec
begin
--   Manifest
--     INSTALL: INSTALL-eba_cust_sample_data spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_cust_sample_data as'||wwv_flow.LF||
''||wwv_flow.LF||
'    ---------------------------------------------';
wwv_flow_imp.g_varchar2_table(2) := '----------------------------'||wwv_flow.LF||
'    procedure create_sample_data;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    ----------------------------';
wwv_flow_imp.g_varchar2_table(3) := '---------------------------------------------'||wwv_flow.LF||
'    procedure remove_sample_data;'||wwv_flow.LF||
'        '||wwv_flow.LF||
'end eba_cus';
wwv_flow_imp.g_varchar2_table(4) := 't_sample_data;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16602277293435520775)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'eba_cust_sample_data spec'
,p_sequence=>70
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(15099659141625396097)
,p_script_id=>wwv_flow_imp.id(16602277293435520775)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_CUST_SAMPLE_DATA'
);
wwv_flow_imp.component_end;
end;
/
