prompt --application/deployment/install/upgrade_sales_channel
begin
--   Manifest
--     INSTALL: UPGRADE-sales channel
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_sales_channel ('||wwv_flow.LF||
'   id                      number       not null,'||wwv_flow.LF||
'   channel  ';
wwv_flow_imp.g_varchar2_table(2) := '               varchar2(60) not null,'||wwv_flow.LF||
'   description             varchar2(4000),'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   created   ';
wwv_flow_imp.g_varchar2_table(3) := '            timestamp with time zone not null,'||wwv_flow.LF||
'   created_by            varchar2(255) not null,'||wwv_flow.LF||
'   u';
wwv_flow_imp.g_varchar2_table(4) := 'pdated               timestamp with time zone,'||wwv_flow.LF||
'   updated_by            varchar2(255)'||wwv_flow.LF||
'  )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter ta';
wwv_flow_imp.g_varchar2_table(5) := 'ble eba_cust_sales_channel add '||wwv_flow.LF||
'constraint eba_cust_sales_channel_pk primary key (id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create uniq';
wwv_flow_imp.g_varchar2_table(6) := 'ue index eba_cust_sales_channel_uk on eba_cust_sales_channel(channel)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_cust_sales_';
wwv_flow_imp.g_varchar2_table(7) := 'channel'||wwv_flow.LF||
'   add constraint eba_cust_sales_channel_uk'||wwv_flow.LF||
'       unique (channel)'||wwv_flow.LF||
'       using index eba_c';
wwv_flow_imp.g_varchar2_table(8) := 'ust_sales_channel_uk'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_cust_sales_channel'||wwv_flow.LF||
'   before insert or up';
wwv_flow_imp.g_varchar2_table(9) := 'date on eba_cust_sales_channel'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'      if :NEW.ID is null t';
wwv_flow_imp.g_varchar2_table(10) := 'hen'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'        into :new.id'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(11) := '     from dual;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'      :NEW.CREATED_BY := nvl(';
wwv_flow_imp.g_varchar2_table(12) := 'v(''APP_USER''),USER);'||wwv_flow.LF||
'      :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'      :NEW.UPDATED_BY := nvl(v(''APP_US';
wwv_flow_imp.g_varchar2_table(13) := 'ER''),USER);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if updating then'||wwv_flow.LF||
'      :NEW.UPDATED := current_timestamp;'||wwv_flow.LF||
'      :NEW.UPDAT';
wwv_flow_imp.g_varchar2_table(14) := 'ED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_cust_sales_channel ';
wwv_flow_imp.g_varchar2_table(15) := '(id, channel) values (1, ''Direct'');'||wwv_flow.LF||
'insert into eba_cust_sales_channel (id, channel) values (2, ''Fie';
wwv_flow_imp.g_varchar2_table(16) := 'ld'');'||wwv_flow.LF||
'insert into eba_cust_sales_channel (id, channel) values (3, ''Store'');'||wwv_flow.LF||
'insert into eba_cust_sal';
wwv_flow_imp.g_varchar2_table(17) := 'es_channel (id, channel) values (4, ''Partner'');'||wwv_flow.LF||
'commit;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(15858034743503249286)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'sales channel'
,p_sequence=>190
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_CUST_SALES_CHANNEL'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
