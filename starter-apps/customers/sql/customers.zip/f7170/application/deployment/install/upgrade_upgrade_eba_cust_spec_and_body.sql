prompt --application/deployment/install/upgrade_upgrade_eba_cust_spec_and_body
begin
--   Manifest
--     INSTALL: UPGRADE-Upgrade eba_cust spec and body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_cust as'||wwv_flow.LF||
''||wwv_flow.LF||
'    ---------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(2) := '----------------'||wwv_flow.LF||
'    -- Generates a unique Identifier'||wwv_flow.LF||
'    ------------------------------------------';
wwv_flow_imp.g_varchar2_table(3) := '-------------------------------'||wwv_flow.LF||
'    function gen_id return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ----------------------------';
wwv_flow_imp.g_varchar2_table(4) := '---------------------------------------------'||wwv_flow.LF||
'    -- Gets the current user''s authorization level. Ca';
wwv_flow_imp.g_varchar2_table(5) := 'n depend on the following:'||wwv_flow.LF||
'    --  * If access control is currently disabled, returns highest level ';
wwv_flow_imp.g_varchar2_table(6) := 'of 3.'||wwv_flow.LF||
'    --  * If access control is enabled, but user is not in list, returns 0'||wwv_flow.LF||
'    --  * If access';
wwv_flow_imp.g_varchar2_table(7) := ' control is enabled and user is in list, returns their'||wwv_flow.LF||
'    --    access level.'||wwv_flow.LF||
'    -----------------';
wwv_flow_imp.g_varchar2_table(8) := '--------------------------------------------------------'||wwv_flow.LF||
'    function get_authorization_level ('||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(9) := '    p_username             varchar2)'||wwv_flow.LF||
'        return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -----------------------------------';
wwv_flow_imp.g_varchar2_table(10) := '--------------------------------------'||wwv_flow.LF||
'    -- Gets the current user''s feature level. '||wwv_flow.LF||
'    --   Based';
wwv_flow_imp.g_varchar2_table(11) := ' on combination of the ACL Feature''s access level and user''s access level (if access control enabled';
wwv_flow_imp.g_varchar2_table(12) := ') '||wwv_flow.LF||
'    -------------------------------------------------------------------------'||wwv_flow.LF||
'    function get_fe';
wwv_flow_imp.g_varchar2_table(13) := 'ature_level ('||wwv_flow.LF||
'        p_username             varchar2,'||wwv_flow.LF||
'        p_authorization_name   varchar2)'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(14) := '    return boolean;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -------------------------------------------------------------------------'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(15) := '   procedure eba_cust_add_views_log('||wwv_flow.LF||
'        p_view_type varchar2,'||wwv_flow.LF||
'        p_id number'||wwv_flow.LF||
'    );'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(16) := '  '||wwv_flow.LF||
'end eba_cust;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace package body eba_cust as'||wwv_flow.LF||
'   '||wwv_flow.LF||
'    -----------------';
wwv_flow_imp.g_varchar2_table(17) := '--------------------------------------------------------'||wwv_flow.LF||
'    -- Generates a unique Identifier'||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(18) := '-----------------------------------------------------------------------'||wwv_flow.LF||
'    function gen_id'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(19) := 'return number'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_id  number;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        select to_number(sys_guid(), ''XXXXXXXXX';
wwv_flow_imp.g_varchar2_table(20) := 'XXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'          into l_id'||wwv_flow.LF||
'          from dual;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'        return l_id;'||wwv_flow.LF||
'    end';
wwv_flow_imp.g_varchar2_table(21) := ' gen_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -------------------------------------------------------------------------'||wwv_flow.LF||
'    -- Gets ';
wwv_flow_imp.g_varchar2_table(22) := 'the current user''s authorization level. Depends on the following:'||wwv_flow.LF||
'    --  * If access control is cur';
wwv_flow_imp.g_varchar2_table(23) := 'rently disabled, returns highest level of 3.'||wwv_flow.LF||
'    --  * If access control is enabled, but user is not';
wwv_flow_imp.g_varchar2_table(24) := ' in list, returns 0'||wwv_flow.LF||
'    --  * If access control is enabled and user is in list, returns their'||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(25) := '    access level.'||wwv_flow.LF||
'    -------------------------------------------------------------------------'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(26) := 'function get_authorization_level ('||wwv_flow.LF||
'        p_username             varchar2)'||wwv_flow.LF||
'        return number'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(27) := '  is'||wwv_flow.LF||
'        l_access_level_id       eba_cust_users.access_level_id%type := 0;  -- default to lowest';
wwv_flow_imp.g_varchar2_table(28) := ' privilege.'||wwv_flow.LF||
'        l_account_locked        eba_cust_users.account_locked%type;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        --';
wwv_flow_imp.g_varchar2_table(29) := ' If access control is disabled, default to highest privilege'||wwv_flow.LF||
'        if eba_cust_fw.get_preference_v';
wwv_flow_imp.g_varchar2_table(30) := 'alue(''ACCESS_CONTROL_ENABLED'') = ''N'' then'||wwv_flow.LF||
'            return 3;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            -- Query fo';
wwv_flow_imp.g_varchar2_table(31) := 'r user''s access level, throws no_data_found if no user'||wwv_flow.LF||
'            select access_level_id,'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(32) := '          account_locked'||wwv_flow.LF||
'              into l_access_level_id,'||wwv_flow.LF||
'                   l_account_locked'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(33) := '             from eba_cust_users'||wwv_flow.LF||
'             where username = p_username;'||wwv_flow.LF||
'            -- Check if u';
wwv_flow_imp.g_varchar2_table(34) := 'ser''s account is locked, return 0 (no privilege), otherwise stick'||wwv_flow.LF||
'            -- with their level.'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(35) := '           if l_account_locked = ''Y'' then'||wwv_flow.LF||
'                return 0;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(36) := '-- Overwrite user access level 1 with access level 2 if access control scope is PUBLIC_CONTRIBUTE'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(37) := '          if l_access_level_id = 1 and eba_cust_fw.get_preference_value(''ACCESS_CONTROL_SCOPE'') = ''P';
wwv_flow_imp.g_varchar2_table(38) := 'UBLIC_CONTRIBUTE'' then'||wwv_flow.LF||
'                return 2;'||wwv_flow.LF||
'            end if;            '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(39) := '     return l_access_level_id;'||wwv_flow.LF||
'    exception'||wwv_flow.LF||
'        when no_data_found then'||wwv_flow.LF||
'            -- If no us';
wwv_flow_imp.g_varchar2_table(40) := 'er exists with passed username, do a final check if reader access is set to any authenticated user'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(41) := '           if eba_cust_fw.get_preference_value(''ACCESS_CONTROL_SCOPE'') = ''PUBLIC_CONTRIBUTE'' then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(42) := '              return 2;'||wwv_flow.LF||
'            elsif eba_cust_fw.get_preference_value(''ACCESS_CONTROL_SCOPE'') =';
wwv_flow_imp.g_varchar2_table(43) := ' ''PUBLIC_READONLY'' then'||wwv_flow.LF||
'                return 1;'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'                return 0;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(44) := '     end if;           '||wwv_flow.LF||
'    end get_authorization_level;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --------------------------------------';
wwv_flow_imp.g_varchar2_table(45) := '-----------------------------------'||wwv_flow.LF||
'    -- Gets the current user''s feature level. '||wwv_flow.LF||
'    --   Based on';
wwv_flow_imp.g_varchar2_table(46) := ' combination of the ACL Feature''s access level and user''s access level (if access control enabled) '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(47) := '    -------------------------------------------------------------------------'||wwv_flow.LF||
'    function get_featu';
wwv_flow_imp.g_varchar2_table(48) := 're_level ('||wwv_flow.LF||
'        p_username             varchar2,'||wwv_flow.LF||
'        p_authorization_name   varchar2)'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(49) := ' return boolean'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_feature_level_id    eba_cust_acl_features.access_level_id%type := 1';
wwv_flow_imp.g_varchar2_table(50) := ';  -- default to lowest privilege required'||wwv_flow.LF||
'        l_user_level_id       eba_cust_users.access_level';
wwv_flow_imp.g_varchar2_table(51) := '_id%type := 0;  -- default to lowest privilege.'||wwv_flow.LF||
'        l_account_locked      eba_cust_users.account';
wwv_flow_imp.g_varchar2_table(52) := '_locked%type;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        -- If access control is disabled, default to highest privilege'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(53) := '   if eba_cust_fw.get_preference_value(''ACCESS_CONTROL_ENABLED'') = ''N'' then'||wwv_flow.LF||
'            return true;';
wwv_flow_imp.g_varchar2_table(54) := ''||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- Determine the Feature level from ACL Features'||wwv_flow.LF||
'        for c1 in (select';
wwv_flow_imp.g_varchar2_table(55) := ' access_level_id'||wwv_flow.LF||
'                   from eba_cust_acl_features'||wwv_flow.LF||
'                   where authorizatio';
wwv_flow_imp.g_varchar2_table(56) := 'n_name = p_authorization_name'||wwv_flow.LF||
'                  ) loop'||wwv_flow.LF||
'            l_feature_level_id := c1.access_l';
wwv_flow_imp.g_varchar2_table(57) := 'evel_id;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- Query for user''s access level, throws no_data_found if no use';
wwv_flow_imp.g_varchar2_table(58) := 'r'||wwv_flow.LF||
'        begin'||wwv_flow.LF||
'            select access_level_id,'||wwv_flow.LF||
'                   account_locked'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(59) := 'into l_user_level_id,'||wwv_flow.LF||
'                   l_account_locked'||wwv_flow.LF||
'              from eba_cust_users'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(60) := '     where username = p_username;'||wwv_flow.LF||
'            -- Check if user''s account is locked, return false (no';
wwv_flow_imp.g_varchar2_table(61) := ' privilege), otherwise stick with their level.'||wwv_flow.LF||
'            if l_account_locked = ''Y'' then'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(62) := '      return false;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            -- Overwrite user access level 1 with access lev';
wwv_flow_imp.g_varchar2_table(63) := 'el 2 if access control scope is PUBLIC_CONTRIBUTE'||wwv_flow.LF||
'            if l_user_level_id = 1 and eba_cust_fw';
wwv_flow_imp.g_varchar2_table(64) := '.get_preference_value(''ACCESS_CONTROL_SCOPE'') = ''PUBLIC_CONTRIBUTE'' then'||wwv_flow.LF||
'                l_user_leve';
wwv_flow_imp.g_varchar2_table(65) := 'l_id := 2;'||wwv_flow.LF||
'            end if;            '||wwv_flow.LF||
'        exception'||wwv_flow.LF||
'            when no_data_found then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(66) := '         -- If no user exists with passed username, do a final check if reader access is set to any ';
wwv_flow_imp.g_varchar2_table(67) := 'authenticated user'||wwv_flow.LF||
'            if eba_cust_fw.get_preference_value(''ACCESS_CONTROL_SCOPE'') = ''PUBLIC';
wwv_flow_imp.g_varchar2_table(68) := '_CONTRIBUTE'' then'||wwv_flow.LF||
'                l_user_level_id := 2;'||wwv_flow.LF||
'            elsif eba_cust_fw.get_preference';
wwv_flow_imp.g_varchar2_table(69) := '_value(''ACCESS_CONTROL_SCOPE'') = ''PUBLIC_READONLY'' then'||wwv_flow.LF||
'                l_user_level_id := 1;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(70) := '      end if;           '||wwv_flow.LF||
'        end;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- Compare the Feature level to the User level'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(71) := '  -- If the User level is at least as high as the Feature level then the user can perform the given ';
wwv_flow_imp.g_varchar2_table(72) := 'function.'||wwv_flow.LF||
'        if l_feature_level_id <= l_user_level_id then'||wwv_flow.LF||
'          return true;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(73) := '          return false;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end get_feature_level;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure eba_cust_add_vie';
wwv_flow_imp.g_varchar2_table(74) := 'ws_log(p_view_type varchar2,p_id number) as'||wwv_flow.LF||
'       l_count number;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'         select count(*';
wwv_flow_imp.g_varchar2_table(75) := ')'||wwv_flow.LF||
'           into l_count'||wwv_flow.LF||
'           from eba_cust_views_log'||wwv_flow.LF||
'          where table_primary_id = p_id';
wwv_flow_imp.g_varchar2_table(76) := ''||wwv_flow.LF||
'            and view_type = p_view_type;'||wwv_flow.LF||
'         if l_count >= 1 then'||wwv_flow.LF||
'               update eba_cu';
wwv_flow_imp.g_varchar2_table(77) := 'st_views_log'||wwv_flow.LF||
'                  set view_count = view_count + 1'||wwv_flow.LF||
'                where table_primary_i';
wwv_flow_imp.g_varchar2_table(78) := 'd = p_id'||wwv_flow.LF||
'                 and view_type = p_view_type ;'||wwv_flow.LF||
'         else'||wwv_flow.LF||
'               insert into eba';
wwv_flow_imp.g_varchar2_table(79) := '_cust_views_log( view_type, table_primary_id )'||wwv_flow.LF||
'               values (p_view_type, p_id);         '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(80) := '        end if;'||wwv_flow.LF||
'    end;'||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_cust;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1374571950421165175)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Upgrade eba_cust spec and body'
,p_sequence=>440
,p_script_type=>'UPGRADE'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
