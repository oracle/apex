prompt --application/deployment/install/install_feedback_tables_data_and_triggers
begin
--   Manifest
--     INSTALL: INSTALL-Feedback tables, data, and triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_feedback_types'||wwv_flow.LF||
'('||wwv_flow.LF||
'    id             number constraint eba_cust_feedback_types_';
wwv_flow_imp.g_varchar2_table(2) := 'pk not null primary key,'||wwv_flow.LF||
'    feedback_type  varchar2(30),'||wwv_flow.LF||
'    created        timestamp with time zon';
wwv_flow_imp.g_varchar2_table(3) := 'e,'||wwv_flow.LF||
'    created_by     varchar2(255),'||wwv_flow.LF||
'    updated        timestamp with time zone,'||wwv_flow.LF||
'    updated_by    ';
wwv_flow_imp.g_varchar2_table(4) := ' varchar2(255)'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_cust_feedback_types_biu'||wwv_flow.LF||
'    before insert or update';
wwv_flow_imp.g_varchar2_table(5) := ' '||wwv_flow.LF||
'    on eba_cust_feedback_types'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        :new.id ';
wwv_flow_imp.g_varchar2_table(6) := ':= to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(7) := '   :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := NVL(V(''APP_USER''),user);'||wwv_flow.LF||
'    end if';
wwv_flow_imp.g_varchar2_table(8) := ';'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := NVL(V(''APP_USER''),user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alt';
wwv_flow_imp.g_varchar2_table(9) := 'er trigger eba_cust_feedback_types_biu enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_cust_feedback_types (id, feedback_t';
wwv_flow_imp.g_varchar2_table(10) := 'ype) values (1, ''General Comment'');'||wwv_flow.LF||
'insert into eba_cust_feedback_types (id, feedback_type) values (';
wwv_flow_imp.g_varchar2_table(11) := '2, ''Enhancement Request'');'||wwv_flow.LF||
'insert into eba_cust_feedback_types (id, feedback_type) values (3, ''Bug'')';
wwv_flow_imp.g_varchar2_table(12) := ';'||wwv_flow.LF||
'commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_cust_feedback'||wwv_flow.LF||
'('||wwv_flow.LF||
'    id             number constraint eba_cust_feedback_p';
wwv_flow_imp.g_varchar2_table(13) := 'k not null primary key,'||wwv_flow.LF||
'    application_id number not null,'||wwv_flow.LF||
'    page_id        number not null,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(14) := 'feedback       varchar2(4000),'||wwv_flow.LF||
'    response       varchar2(4000),'||wwv_flow.LF||
'    type_id        number,'||wwv_flow.LF||
'    sta';
wwv_flow_imp.g_varchar2_table(15) := 'tus         varchar2(30),'||wwv_flow.LF||
'    created        timestamp with time zone,'||wwv_flow.LF||
'    created_by     varchar2(2';
wwv_flow_imp.g_varchar2_table(16) := '55),'||wwv_flow.LF||
'    updated        timestamp with time zone,'||wwv_flow.LF||
'    updated_by     varchar2(255),'||wwv_flow.LF||
'    constraint e';
wwv_flow_imp.g_varchar2_table(17) := 'ba_cust_feedback_type_fk foreign key (type_id) references eba_cust_feedback_types (id)'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create in';
wwv_flow_imp.g_varchar2_table(18) := 'dex eba_cust_feedback_type_idx on eba_cust_feedback (type_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_cust_f';
wwv_flow_imp.g_varchar2_table(19) := 'eedback_biu'||wwv_flow.LF||
'    before insert or update '||wwv_flow.LF||
'    on eba_cust_feedback'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new';
wwv_flow_imp.g_varchar2_table(20) := '.id is null then'||wwv_flow.LF||
'        :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    en';
wwv_flow_imp.g_varchar2_table(21) := 'd if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.created_by := NV';
wwv_flow_imp.g_varchar2_table(22) := 'L(V(''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := NVL';
wwv_flow_imp.g_varchar2_table(23) := '(V(''APP_USER''),user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger eba_cust_feedback_biu enable'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(18744480220278964370)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'Feedback tables, data, and triggers'
,p_sequence=>520
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
