prompt --application/deployment/install/upgrade_add_sales_channel
begin
--   Manifest
--     INSTALL: UPGRADE-add sales channel
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'alter table EBA_CUST_CUSTOMERS add SALES_CHANNEL_ID number;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_cust_customers'||wwv_flow.LF||
'   add';
wwv_flow_imp.g_varchar2_table(2) := ' constraint eba_customers_channel_fk'||wwv_flow.LF||
'       foreign key (sales_channel_id)'||wwv_flow.LF||
'       references eba_cus';
wwv_flow_imp.g_varchar2_table(3) := 't_sales_channel(id) on delete set null'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_cust_customers_05 on eba_cust_customers (';
wwv_flow_imp.g_varchar2_table(4) := 'sales_channel_id);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(15858035667370282672)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'add sales channel'
,p_sequence=>200
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tab_cols',
'where table_name = ''EBA_CUST_CUSTOMERS''',
'    and column_name = ''SALES_CHANNEL_ID'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
