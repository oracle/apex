prompt --application/deployment/install/install_customers
begin
--   Manifest
--     INSTALL: INSTALL-customers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_cust_customers ('||wwv_flow.LF||
'    id                            number         not null,'||wwv_flow.LF||
'    par';
wwv_flow_imp.g_varchar2_table(2) := 'ent_customer_id            number,'||wwv_flow.LF||
'    row_version_number            number         not null,'||wwv_flow.LF||
'    ro';
wwv_flow_imp.g_varchar2_table(3) := 'w_key                       varchar2(60)   not null,'||wwv_flow.LF||
'    customer_name                 varchar2(255)';
wwv_flow_imp.g_varchar2_table(4) := '  not null,'||wwv_flow.LF||
'    customer_name_upper           varchar2(255)  not null,'||wwv_flow.LF||
'    customer_account_number  ';
wwv_flow_imp.g_varchar2_table(5) := '     varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    industry_id                   number,'||wwv_flow.LF||
'    category_id                ';
wwv_flow_imp.g_varchar2_table(6) := '   number,'||wwv_flow.LF||
'    status_id                     number,'||wwv_flow.LF||
'    type_id                       number,'||wwv_flow.LF||
'    u';
wwv_flow_imp.g_varchar2_table(7) := 'se_case_id                   number,'||wwv_flow.LF||
'    geography_id                  number,'||wwv_flow.LF||
'    country_id       ';
wwv_flow_imp.g_varchar2_table(8) := '             number,'||wwv_flow.LF||
'    default_timezone              varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    referencable       ';
wwv_flow_imp.g_varchar2_table(9) := '           varchar2(30),'||wwv_flow.LF||
'    marquee_customer_yn           varchar2(1),'||wwv_flow.LF||
'    reference_phase_id      ';
wwv_flow_imp.g_varchar2_table(10) := '      number,'||wwv_flow.LF||
'    ref_recruitment_owner         varchar2(255),'||wwv_flow.LF||
'    strategic_customer_program_yn var';
wwv_flow_imp.g_varchar2_table(11) := 'char2(1)    default ''N'','||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    tags                          varchar2(4000),'||wwv_flow.LF||
'    sales_channel_';
wwv_flow_imp.g_varchar2_table(12) := 'id              number,'||wwv_flow.LF||
'    customer_products             varchar2(4000),'||wwv_flow.LF||
'    number_of_users       ';
wwv_flow_imp.g_varchar2_table(13) := '        varchar2(60),'||wwv_flow.LF||
'    summary                       varchar2(4000),'||wwv_flow.LF||
'    customer_profile        ';
wwv_flow_imp.g_varchar2_table(14) := '      clob,'||wwv_flow.LF||
'    applications                  clob,'||wwv_flow.LF||
'    logo_blob                     blob,'||wwv_flow.LF||
'    logo';
wwv_flow_imp.g_varchar2_table(15) := '_name                     varchar2(512),'||wwv_flow.LF||
'    logo_mimetype                 varchar2(512),'||wwv_flow.LF||
'    logo_c';
wwv_flow_imp.g_varchar2_table(16) := 'harset                  varchar2(512),'||wwv_flow.LF||
'    logo_lastupd                  date,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    web_site  ';
wwv_flow_imp.g_varchar2_table(17) := '                    varchar2(1000),'||wwv_flow.LF||
'    linkedin                      varchar2(1000),'||wwv_flow.LF||
'    facebook  ';
wwv_flow_imp.g_varchar2_table(18) := '                    varchar2(1000),'||wwv_flow.LF||
'    twitter                       varchar2(1000),'||wwv_flow.LF||
'    stock_symb';
wwv_flow_imp.g_varchar2_table(19) := 'ol                  varchar2(30),'||wwv_flow.LF||
'    total_contract_value          number,'||wwv_flow.LF||
'    annual_recurring_rev';
wwv_flow_imp.g_varchar2_table(20) := 'enue      number,'||wwv_flow.LF||
'    currency                      varchar2(20),'||wwv_flow.LF||
'    discount_level                ';
wwv_flow_imp.g_varchar2_table(21) := 'number,'||wwv_flow.LF||
'    sic                           varchar2(30),  -- standard industry code'||wwv_flow.LF||
'    duns         ';
wwv_flow_imp.g_varchar2_table(22) := '                 varchar2(30),  -- dun and bradstreet number'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    support_id                  ';
wwv_flow_imp.g_varchar2_table(23) := '  varchar2(50),'||wwv_flow.LF||
'    party_id                      varchar2(50),'||wwv_flow.LF||
'    parent_party_id               va';
wwv_flow_imp.g_varchar2_table(24) := 'rchar2(50),'||wwv_flow.LF||
'    party_name                    varchar2(255),'||wwv_flow.LF||
'    partent_party_name            varch';
wwv_flow_imp.g_varchar2_table(25) := 'ar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                       timestamp with time zone not null,'||wwv_flow.LF||
'    created_by';
wwv_flow_imp.g_varchar2_table(26) := '                    varchar2(255) not null,'||wwv_flow.LF||
'    updated                       timestamp with time zo';
wwv_flow_imp.g_varchar2_table(27) := 'ne,'||wwv_flow.LF||
'    updated_by                    varchar2(255)'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_customers'||wwv_flow.LF||
'    add const';
wwv_flow_imp.g_varchar2_table(28) := 'raint eba_cust_customers_pk'||wwv_flow.LF||
'        primary key (id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_cust_customers_uk on ';
wwv_flow_imp.g_varchar2_table(29) := 'eba_cust_customers(customer_name)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_customers'||wwv_flow.LF||
'    add constraint eba_cust_custo';
wwv_flow_imp.g_varchar2_table(30) := 'mers_uk'||wwv_flow.LF||
'        unique (customer_name)'||wwv_flow.LF||
'        using index eba_cust_customers_uk'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_c';
wwv_flow_imp.g_varchar2_table(31) := 'ust_customers'||wwv_flow.LF||
'    add constraint eba_cust_customers_industry_fk'||wwv_flow.LF||
'        foreign key (industry_id)'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(32) := '      references eba_cust_industries (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_customers'||wwv_flow.LF||
'    add';
wwv_flow_imp.g_varchar2_table(33) := ' constraint eba_customers_category_fk'||wwv_flow.LF||
'        foreign key (category_id)'||wwv_flow.LF||
'        references eba_cust_';
wwv_flow_imp.g_varchar2_table(34) := 'categories (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_customers'||wwv_flow.LF||
'    add constraint eba_customers_';
wwv_flow_imp.g_varchar2_table(35) := 'status_fk'||wwv_flow.LF||
'        foreign key (status_id)'||wwv_flow.LF||
'        references eba_cust_status (id) on delete cascade'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(36) := '/'||wwv_flow.LF||
'alter table eba_cust_customers'||wwv_flow.LF||
'    add constraint eba_customers_type_fk'||wwv_flow.LF||
'        foreign key (type_';
wwv_flow_imp.g_varchar2_table(37) := 'id)'||wwv_flow.LF||
'        references eba_cust_type (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_customers'||wwv_flow.LF||
'    add';
wwv_flow_imp.g_varchar2_table(38) := ' constraint eba_customers_use_case_fk'||wwv_flow.LF||
'        foreign key (use_case_id)'||wwv_flow.LF||
'        references eba_cust_';
wwv_flow_imp.g_varchar2_table(39) := 'use_case (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_customers'||wwv_flow.LF||
'    add constraint eba_customers_ge';
wwv_flow_imp.g_varchar2_table(40) := 'ography_fk'||wwv_flow.LF||
'        foreign key (geography_id)'||wwv_flow.LF||
'        references eba_cust_geographies (id) on delete';
wwv_flow_imp.g_varchar2_table(41) := ' cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cust_customers'||wwv_flow.LF||
'    add constraint eba_customers_country_fk'||wwv_flow.LF||
'        foreig';
wwv_flow_imp.g_varchar2_table(42) := 'n key (country_id)'||wwv_flow.LF||
'        references eba_cust_countries (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_cu';
wwv_flow_imp.g_varchar2_table(43) := 'st_customers'||wwv_flow.LF||
'    add constraint eba_customers_parent_fk'||wwv_flow.LF||
'        foreign key (parent_customer_id)'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(44) := '     references eba_cust_customers (id) on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_cust_customers_01 on e';
wwv_flow_imp.g_varchar2_table(45) := 'ba_cust_customers (industry_id);'||wwv_flow.LF||
'create index eba_cust_customers_02 on eba_cust_customers (category_';
wwv_flow_imp.g_varchar2_table(46) := 'id);'||wwv_flow.LF||
'create index eba_cust_customers_03 on eba_cust_customers (status_id);'||wwv_flow.LF||
'create index eba_cust_cus';
wwv_flow_imp.g_varchar2_table(47) := 'tomers_04 on eba_cust_customers (geography_id,country_id);'||wwv_flow.LF||
'create index eba_cust_customers_05 on eba';
wwv_flow_imp.g_varchar2_table(48) := '_cust_customers (type_id);'||wwv_flow.LF||
'create index eba_cust_customers_06 on eba_cust_customers (use_case_id);'||wwv_flow.LF||
'c';
wwv_flow_imp.g_varchar2_table(49) := 'reate index eba_cust_customers_07 on eba_cust_customers (parent_customer_id);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16674620772898420501)
,p_install_id=>wwv_flow_imp.id(17807606927811771520)
,p_name=>'customers'
,p_sequence=>220
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
