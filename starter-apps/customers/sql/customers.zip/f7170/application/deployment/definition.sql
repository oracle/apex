prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7170
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7170
,p_default_id_offset=>15507297261585890
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'drop sequence eba_cust_seq;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table eba_cust_errors               cascade constraints;'||wwv_flow.LF||
'drop tabl';
wwv_flow_imp.g_varchar2_table(2) := 'e eba_cust_history              cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_countries            cascad';
wwv_flow_imp.g_varchar2_table(3) := 'e constraints;'||wwv_flow.LF||
'drop table eba_cust_error_lookup         cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_fil';
wwv_flow_imp.g_varchar2_table(4) := 'es                cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_links                cascade constraints;';
wwv_flow_imp.g_varchar2_table(5) := ''||wwv_flow.LF||
'drop table eba_cust_notes                cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_notifications    ';
wwv_flow_imp.g_varchar2_table(6) := '    cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_preferences          cascade constraints;'||wwv_flow.LF||
'drop table eb';
wwv_flow_imp.g_varchar2_table(7) := 'a_cust_product_uses         cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_tags                 cascade co';
wwv_flow_imp.g_varchar2_table(8) := 'nstraints;'||wwv_flow.LF||
'drop table eba_cust_tags_sum             cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_tags_ty';
wwv_flow_imp.g_varchar2_table(9) := 'pe_sum        cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_users                cascade constraints;'||wwv_flow.LF||
'dro';
wwv_flow_imp.g_varchar2_table(10) := 'p table eba_cust_administrators       cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_views_log            ';
wwv_flow_imp.g_varchar2_table(11) := 'cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_access_levels        cascade constraints;'||wwv_flow.LF||
'drop table eba_cu';
wwv_flow_imp.g_varchar2_table(12) := 'st_contacts             cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_sales_channel        cascade constr';
wwv_flow_imp.g_varchar2_table(13) := 'aints;'||wwv_flow.LF||
'drop table eba_cust_customers            cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_geographies';
wwv_flow_imp.g_varchar2_table(14) := '          cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_industries           cascade constraints;'||wwv_flow.LF||
'drop ta';
wwv_flow_imp.g_varchar2_table(15) := 'ble eba_cust_product_families     cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_products             casc';
wwv_flow_imp.g_varchar2_table(16) := 'ade constraints;'||wwv_flow.LF||
'drop table eba_cust_status               cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_c';
wwv_flow_imp.g_varchar2_table(17) := 'ontact_types        cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_customer_reftype_ref cascade constraint';
wwv_flow_imp.g_varchar2_table(18) := 's;'||wwv_flow.LF||
'drop table eba_cust_reference_types      cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_categories     ';
wwv_flow_imp.g_varchar2_table(19) := '      cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_tz_pref              cascade constraints;'||wwv_flow.LF||
'drop table ';
wwv_flow_imp.g_varchar2_table(20) := 'eba_cust_clicks               cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_verifications        cascade ';
wwv_flow_imp.g_varchar2_table(21) := 'constraints;'||wwv_flow.LF||
'drop table EBA_CUST_REF_PHASE            cascade constraints;'||wwv_flow.LF||
'drop table EBA_CUST_PRODU';
wwv_flow_imp.g_varchar2_table(22) := 'CT_STATUSES     cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_type                 cascade constraints;'||wwv_flow.LF||
'd';
wwv_flow_imp.g_varchar2_table(23) := 'rop table eba_cust_use_case             cascade constraints;'||wwv_flow.LF||
'drop table EBA_CUST_COMPETITORS        ';
wwv_flow_imp.g_varchar2_table(24) := '  cascade constraints;'||wwv_flow.LF||
'drop table EBA_CUST_CUST_COMPETITOR_REF  cascade constraints;'||wwv_flow.LF||
'drop table EBA_';
wwv_flow_imp.g_varchar2_table(25) := 'CUST_CUST_PARTNER_REF     cascade constraints;'||wwv_flow.LF||
'drop table EBA_CUST_IMPL_PARTNERS        cascade cons';
wwv_flow_imp.g_varchar2_table(26) := 'traints;'||wwv_flow.LF||
'drop table eba_cust_activity_ref         cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_activity_';
wwv_flow_imp.g_varchar2_table(27) := 'files       cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_activities           cascade constraints;'||wwv_flow.LF||
'drop ';
wwv_flow_imp.g_varchar2_table(28) := 'table eba_cust_activity_types       cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_feedback_types       ca';
wwv_flow_imp.g_varchar2_table(29) := 'scade constraints;'||wwv_flow.LF||
'drop table eba_cust_feedback             cascade constraints;'||wwv_flow.LF||
'drop table eba_cust';
wwv_flow_imp.g_varchar2_table(30) := '_email_log            cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_acl_features         cascade constrai';
wwv_flow_imp.g_varchar2_table(31) := 'nts;'||wwv_flow.LF||
'drop table eba_cust_issue_statuses       cascade constraints;'||wwv_flow.LF||
'drop table eba_cust_issues       ';
wwv_flow_imp.g_varchar2_table(32) := '        cascade constraints;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'drop view eba_cust_customers_v;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop package eba_cust;'||wwv_flow.LF||
'drop package ';
wwv_flow_imp.g_varchar2_table(33) := 'eba_cust_sample_data;'||wwv_flow.LF||
'drop package eba_cust_fw;'||wwv_flow.LF||
'drop package eba_cust_email;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop procedure eba_cus';
wwv_flow_imp.g_varchar2_table(34) := 't_tz_init;';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(17807606927811771520)
,p_welcome_message=>'This is a basic customer tracking application. Use the application to manage manage your Customers, their Contacts and related information.'
,p_configuration_message=>'Customers Installation. You can configure the following attributes of your application.'
,p_build_options_message=>'Customers Installation. You can choose to include the following build options.'
,p_validation_message=>'Customers Installation. The following validations will be performed to ensure your system is compatible with this application.'
,p_install_message=>'Customers Installation. Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_message=>'The application installer has detected that this application''s supporting objects were previously installed.  This wizard will guide you through the process of upgrading these supporting objects.'
,p_upgrade_confirm_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_success_message=>'Your application''s supporting objects have been installed.'
,p_upgrade_failure_message=>'Installation of database objects and seed data has failed.'
,p_get_version_sql_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from user_tables',
' where table_name like ''EBA_CUST_%'''))
,p_deinstall_success_message=>'Customers deinstallation complete.'
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_free_kb=>1856
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE SEQUENCE:CREATE TRIGGER'
,p_required_names_available=>'EBA_CUST_ACCESS_LEVELS:EBA_CUST_ADMINISTRATORS:EBA_CUST_CATEGORIES:EBA_CUST_CONTACT_TYPES:EBA_CUST_CONTACTS:EBA_CUST_COUNTRIES:EBA_CUST_CUSTOMERS:EBA_CUST_ERROR_LOOKUP:EBA_CUST_FILES:EBA_CUST_GEOGRAPHIES:EBA_CUST_HISTORY:EBA_CUST_INDUSTRIES:EBA_CUST_'
||'LINKS:EBA_CUST_NOTES:EBA_CUST_NOTIFICATIONS:EBA_CUST_PREFERENCES:EBA_CUST_PRODUCT_USES:EBA_CUST_PRODUCTS:EBA_CUST_STATUS:EBA_CUST_TAGS:EBA_CUST_TAGS_SUM:EBA_CUST_TAGS_TYPE_SUM:EBA_CUST_TZ_PREF:EBA_CUST_USERS:EBA_CUST_VIEWS_LOG:EBA_CUST:EBA_CUST_SAMPL'
||'E_DATA:EBA_CUST_TZ_INIT:EBA_CUST_CUSTOMERS_V:EBA_CUST_SEQ:EBA_CUST_FW:EBA_CUST_CLICKS:EBA_CUST_VERIFICATIONS:EBA_CUST_TYPE:EBA_CUST_USE_CASE:EBA_CUST_COMPETITORS:EBA_CUST_CUST_COMPETITOR_REF:EBA_CUST_CUST_PARTNER_REF:EBA_CUST_IMPL_PARTNERS:EBA_CUST_P'
||'RODUCT_FAMILIES:EBA_CUST_ACTIVITIES:EBA_CUST_ACTIVITY_FILES:EBA_CUST_ACTIVITY_REF:EBA_CUST_ACTIVITY_TYPES:EBA_CUST_FEEDBACK_TYPES:EBA_CUST_FEEDBACK:EBA_CUST_EMAIL_LOG:EBA_CUST_EMAIL:EBA_CUST_ISSUE_STATUSES:EBA_CUST_ISSUES'
,p_deinstall_message=>'This operation will completely remove this application from your workspace.'
);
wwv_flow_imp.component_end;
end;
/
