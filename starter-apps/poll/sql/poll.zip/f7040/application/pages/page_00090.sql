prompt --application/pages/page_00090
begin
--   Manifest
--     PAGE: 00090
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>90
,p_name=>'Email Results'
,p_alias=>'EMAIL-RESULTS'
,p_page_mode=>'MODAL'
,p_step_title=>'Email Results'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(13924471206505337852)
,p_step_template=>2103835248774687739
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(13937152132781279884)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14050859416228237687)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(17605462679702233991)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(14051179632960338395)
,p_name=>'Community Members'
,p_static_id=>'community-members'
,p_parent_plug_id=>wwv_flow_imp.id(14050869730985872184)
,p_template=>2667762537863948531
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--noBorders:t-Report--rowHighlightOff'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.email',
'from eba_qpoll_respondents r,',
'     eba_qpoll_resp_comm_ref rc',
'where rc.community_id = :P90_COMMUNITY_ID',
'  and r.id = rc.respondent_id',
'order by 1'))
,p_display_when_condition=>'select null from EBA_QPOLL_RESP_COMMUNITIES'
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2542081983073888486
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'SHOW_ALL'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14051179803893338429)
,p_query_column_id=>1
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>1
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14050869730985872184)
,p_plug_name=>'Email Results for &POLL_NAME.'
,p_static_id=>'email-results-for-poll-name'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>5
,p_plug_display_point=>'BODY_3'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14050870409776885006)
,p_plug_name=>'header'
,p_static_id=>'header'
,p_parent_plug_id=>wwv_flow_imp.id(14050869730985872184)
,p_region_css_classes=>'infoTextRegion'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>7
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>You can select a community, provide email addresses or both.  A formatted summary of the poll results will be sent to all the email addresses, as long as they have not opted out of receiving email from this application.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14050859715384237696)
,p_plug_name=>'items 1'
,p_static_id=>'items'
,p_parent_plug_id=>wwv_flow_imp.id(14050869730985872184)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14051181333091347850)
,p_plug_name=>'items 2'
,p_static_id=>'items-2'
,p_parent_plug_id=>wwv_flow_imp.id(14050869730985872184)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14050869224489851400)
,p_button_sequence=>5
,p_button_plug_id=>wwv_flow_imp.id(14051181333091347850)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_image_alt=>'Cancel'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14050869013408848187)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(14051181333091347850)
,p_button_name=>'EMAIL_RESULTS'
,p_static_id=>'email-results'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Email Results'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(14050875609922184881)
,p_branch_action=>'f?p=&APP_ID.:91:&SESSION.::&DEBUG.:::'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(14050869013408848187)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14051174229707217622)
,p_name=>'P90_COMMUNITY_ID'
,p_item_sequence=>7
,p_item_plug_id=>wwv_flow_imp.id(14050859715384237696)
,p_prompt=>'Community'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'COMMUNITIES, P90'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select -'
,p_cHeight=>1
,p_tag_attributes=>'style="width:300px;"'
,p_display_when=>'select null from EBA_QPOLL_RESP_COMMUNITIES'
,p_display_when_type=>'EXISTS'
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_help_text=>'Select the community of users that you wish to send poll results to.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14050862009364259314)
,p_name=>'P90_EMAIL_FROM'
,p_item_sequence=>5
,p_item_plug_id=>wwv_flow_imp.id(14050859715384237696)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Email From'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'case when instr(:APP_USER,''@'') > 0 then lower(:APP_USER)',
'     else replace(eba_qpoll_fw.get_preference_value(''NOTIFICATION_EMAIL_FROM''), ''N/A'', null)',
'     end'))
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14050861531145249267)
,p_name=>'P90_EMAIL_TO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(14051181333091347850)
,p_prompt=>'Addresses to email results to'
,p_placeholder=>'Enter email addresses here'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14051030730666954360)
,p_name=>'P90_INTRO_TEXT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(14051181333091347850)
,p_prompt=>'Introduction Text'
,p_placeholder=>'If provided, this text will be included in the email before the results'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(14051175811579241274)
,p_validation_name=>'P90_COMMUNITY_ID and/or emails'
,p_static_id=>'p90-community-id-and-or-emails'
,p_validation_sequence=>10
,p_validation=>':P90_COMMUNITY_ID is not null or :P90_EMAIL_TO is not null'
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'You must select a community and/or provide email addresses to send poll results to.'
,p_when_button_pressed=>wwv_flow_imp.id(14050869013408848187)
,p_associated_item=>wwv_flow_imp.id(14051174229707217622)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4551239066702583546)
,p_name=>'Cancel'
,p_static_id=>'cancel'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(14050869224489851400)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4551239239347583547)
,p_event_id=>wwv_flow_imp.id(4551239066702583546)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-dialog-cancel'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(14051179907811340520)
,p_name=>'Show Community Members Report'
,p_static_id=>'show-community-members-report'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P90_COMMUNITY_ID'
,p_condition_element=>'P90_COMMUNITY_ID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14051180627012340534)
,p_event_id=>wwv_flow_imp.id(14051179907811340520)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-execute-plsql-code'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'items_to_submit', 'P90_COMMUNITY_ID',
  'language', 'PLSQL',
  'plsql_code', 'null;',
  'show_processing', 'N')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14051180416299340534)
,p_event_id=>wwv_flow_imp.id(14051179907811340520)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(14051179632960338395)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14051180826303340534)
,p_event_id=>wwv_flow_imp.id(14051179907811340520)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(14051179632960338395)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14051180205173340530)
,p_event_id=>wwv_flow_imp.id(14051179907811340520)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(14051179632960338395)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14050866120860187987)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load emails'
,p_static_id=>'load-emails'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_line      varchar2(32767);',
'    l_emails    wwv_flow_global.vc_arr2;',
'    l_email     varchar2(4000);',
'    l_at        number;',
'    l_dot       number;',
'    l_valid     boolean := true;',
'    l_domain    varchar2(4000);',
'begin',
'    ---------------------',
'    -- create collections',
'    --',
'    apex_collection.CREATE_OR_TRUNCATE_COLLECTION (''EBA_QPOLL_EMAIL_RES_INVALID'');',
'    apex_collection.CREATE_OR_TRUNCATE_COLLECTION (''EBA_QPOLL_EMAIL_RES_VALID'');',
'',
'  if :P90_EMAIL_TO is not null then',
'',
'    --------------------------------------------',
'    -- replace delimiting characters with commas',
'    --',
'    l_line := :P90_EMAIL_TO;',
'    l_line := replace(l_line,chr(10),'' '');',
'    l_line := replace(l_line,chr(13),'' '');',
'    l_line := replace(l_line,chr(9),'' '');',
'    l_line := replace(l_line,''<'','' '');',
'    l_line := replace(l_line,''>'','' '');',
'    l_line := replace(l_line,'';'','' '');',
'    l_line := replace(l_line,'':'','' '');',
'    l_line := replace(l_line,''('','' '');',
'    l_line := replace(l_line,'')'','' '');',
'    l_line := replace(l_line,'' '','','');',
'',
'    -----------------------------------------',
'    -- get one comma separated line of emails',
'    --',
'    for j in 1..1000 loop',
'        if instr(l_line,'',,'') > 0 then',
'           l_line := replace(l_line,'',,'','','');',
'        else',
'           exit;',
'        end if;',
'    end loop;',
'',
'    -------------------------',
'    -- get an array of emails',
'    --',
'    l_emails := wwv_flow_utilities.string_to_table(l_line,'','');',
'',
'    -----------------------------',
'    -- add emails to a collection',
'    --',
'    l_email := null;',
'    l_domain := null;',
'    l_at := 0;',
'    l_dot := 0;',
'    for j in 1..l_emails.count loop',
'        l_valid := true;',
'        l_email := trim(l_emails(j));',
'        l_email := replace(l_email,chr(49824),null);',
'        l_email := lower(l_email);',
'',
'        if l_email is not null then',
'            -----------',
'            -- Validate',
'            --',
'            l_at := instr(nvl(l_email,''x''),''@'');',
'            l_domain := substr(l_email,l_at+1);',
'            l_dot := instr(l_domain,''.'');',
'            if l_at < 2 then',
'                -- invalid email',
'                apex_collection.add_member(',
'                    p_collection_name => ''EBA_QPOLL_EMAIL_RES_INVALID'',',
'                    p_c001            => l_email,',
'                    p_c002            => ''INVALID EMAIL'');',
'                commit;',
'                l_valid := false;',
'            end if;',
'',
'            if l_dot = 0 and l_valid then',
'                apex_collection.add_member(',
'                    p_collection_name => ''EBA_QPOLL_EMAIL_RES_INVALID'',',
'                    p_c001            => l_email,',
'                    p_c002            => ''INVALID EMAIL'');',
'                commit;',
'                l_valid := false;',
'            end if;',
'',
'',
'            l_email := trim(l_email);',
'            l_email := trim(both ''.'' from l_email);',
'            l_email := replace(l_email,'' '',null);',
'            l_email := replace(l_email,chr(10),null);',
'            l_email := replace(l_email,chr(9),null);',
'            l_email := replace(l_email,chr(13),null);',
'            l_email := replace(l_email,chr(49824),null);',
'',
'            if l_valid and length(l_email) > 255 then',
'                apex_collection.add_member(',
'                    p_collection_name => ''EBA_QPOLL_EMAIL_RES_INVALID'',',
'                    p_c001            => l_email,',
'                    p_c002            => ''INVALID EMAIL'');',
'                commit;',
'                l_valid := false;',
'            end if;',
'',
'            if l_valid then',
'                for c1 in (select /* APEXeaf772 */  c001',
'                             from wwv_flow_collections',
'                            where collection_name = ''EBA_QPOLL_EMAIL_RES_VALID''',
'                              and c001 = l_email',
'                ) loop',
'                    apex_collection.add_member(',
'                        p_collection_name => ''EBA_QPOLL_EMAIL_RES_INVALID'',',
'                        p_c001            => l_email,',
'                        p_c002            => ''DUPLICATE EMAIL'');',
'                        commit;',
'                    l_valid := false;',
'                    exit;',
'                end loop;',
'            end if;',
'',
'            if l_valid then',
'                for c1 in (select  1',
'                             from eba_qpoll_respondents r,',
'                                  eba_qpoll_email_opt_out o',
'                            where r.id = o.respondent_id',
'                              and r.email = l_email',
'                ) loop',
'                    apex_collection.add_member(',
'                        p_collection_name => ''EBA_QPOLL_EMAIL_RES_INVALID'',',
'                        p_c001            => l_email,',
'                        p_c002            => ''OPTED OUT'');',
'                        commit;',
'                    l_valid := false;',
'                    exit;',
'                end loop;',
'            end if;',
'',
'            if l_valid then',
'                apex_collection.add_member(',
'                    p_collection_name => ''EBA_QPOLL_EMAIL_RES_VALID'',',
'                    p_c001            => l_email);',
'                    commit;',
'            end if;',
'',
'        end if;',
'        l_email := null;',
'    end loop;',
'',
'  end if;',
'',
'  if :P90_COMMUNITY_ID is not null then',
'    for c0 in (',
'       select r.id respondent_id, r.email',
'         from eba_qpoll_respondents r,',
'              eba_qpoll_resp_comm_ref cr',
'        where r.id = cr.respondent_id',
'          and cr.community_id = :P90_COMMUNITY_ID',
'    ) loop',
'        l_valid := true;',
'        for c1 in (select /* APEXeaf772 */  c001',
'                     from wwv_flow_collections',
'                    where collection_name = ''EBA_QPOLL_EMAIL_RES_VALID''',
'                      and c001 = c0.email',
'        ) loop',
'            apex_collection.add_member(',
'                p_collection_name => ''EBA_QPOLL_EMAIL_RES_INVALID'',',
'                p_c001            => c0.email,',
'                p_c002            => ''DUPLICATE EMAIL'');',
'                commit;',
'            l_valid := false;',
'            exit;',
'        end loop;',
'',
'        if l_valid then',
'            for c1 in (select  1',
'                         from eba_qpoll_email_opt_out',
'                        where respondent_id = c0.respondent_id',
'            ) loop',
'                apex_collection.add_member(',
'                    p_collection_name => ''EBA_QPOLL_EMAIL_RES_INVALID'',',
'                    p_c001            => c0.email,',
'                    p_c002            => ''OPTED OUT'');',
'                    commit;',
'                l_valid := false;',
'                exit;',
'            end loop;',
'        end if;',
'',
'        if l_valid then',
'            apex_collection.add_member(',
'                p_collection_name => ''EBA_QPOLL_EMAIL_RES_VALID'',',
'                p_c001            => c0.email);',
'                commit;',
'        end if;',
'    end loop;',
'  end if;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>14033753281253460342
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14050866324632236376)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Send emails'
,p_static_id=>'send-emails'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_html_body        clob;',
'   l_email_id         number;',
'begin',
'',
'   l_html_body := eba_qpoll.prepare_poll_results(:POLL_ID);',
'',
'   for c in (',
'      select c001 as email',
'        from apex_collections',
'       where collection_name = ''EBA_QPOLL_EMAIL_RES_VALID''',
'   ) loop',
'     ',
'      eba_qpoll_email.send (',
'         p_app_id             => :APP_ID,',
'         p_template_static_id => ''RESULTS'',',
'         p_placeholders       => ''{'' || ',
'                                 ''    "POLL_NAME":''         || apex_json.stringify( :POLL_NAME ) || ',
'                                 ''   ,"APPLICATION_TITLE":'' || apex_json.stringify( apex_escape.html(:APPLICATION_TITLE) ) || ',
'                                 ''   ,"INTRO_TEXT":''        || apex_json.stringify( case when :P90_INTRO_TEXT is not null',
'                                                                                         then ''<p>''||apex_escape.html(:P90_INTRO_TEXT)||''</p>''',
'                                                                                         else null',
'                                                                                         end ) || ',
'                                 ''   ,"OPT_OUT_TEXT":''      || apex_json.stringify( apex_lang.message(''OPT_OUT_TEXT'', ',
'                                                                                    :APP_PATH ||',
'                                                                                    APEX_UTIL.PREPARE_URL(p_url => ''f?p='' ||:APP_ID || '':optout'',',
'                                                                                        p_plain_url => TRUE),',
'                                                                                    apex_escape.html(:APPLICATION_TITLE)) ) || ',
'                                 ''   ,"BODY":''  || apex_json.stringify(l_html_body) || ',
'                                          ''}'' , ',
'         p_to                  => c.email,',
'         p_from                => :P90_EMAIL_FROM,',
'         p_cc                  => null,',
'         p_poll_id             => :POLL_ID,',
'         p_email_id            => l_email_id);',
'',
'   end loop;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'#SQLERRM#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>14033753485025508731
);
wwv_flow_imp.component_end;
end;
/
