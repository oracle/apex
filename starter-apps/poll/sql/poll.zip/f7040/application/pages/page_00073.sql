prompt --application/pages/page_00073
begin
--   Manifest
--     PAGE: 00073
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>73
,p_name=>'View Response'
,p_alias=>'VIEW-RESPONSE'
,p_page_mode=>'MODAL'
,p_step_title=>'View Response'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(13924471206505337852)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_step_template=>2101883943284197310
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(165977452478131556)
,p_required_patch=>wwv_flow_imp.id(13938293017878681149)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13940723729331748383)
,p_plug_name=>'buttons'
,p_static_id=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2127905476394690047
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13940724903421772043)
,p_plug_name=>'Response'
,p_static_id=>'response'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--hiddenOverflow'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sys.htp.p(''<h2>''||apex_escape.html(:P73_POLL_NAME)||''</h2>'');',
'',
'for c1 in (',
'select r.id, r.email, r.updated, round(r.grade,1) grade, p.enable_score_yn, round(r.score,1) score, p.score_type,',
'       p.anonymous_yn',
'from EBA_QPOLL_POLLS p,',
'     EBA_QPOLL_RESULTS r',
'where p.id = :POLL_ID',
'  and p.id = r.poll_id ',
'  and r.id = :P73_RESULT_ID',
') loop',
'sys.htp.p(''<p>Submitted: ''||apex_util.get_since(c1.updated)||''<br/>'');',
'sys.htp.p(''By: ''||case when c1.anonymous_yn = ''Y'' then ''anonymous'' else apex_escape.html(lower(c1.email)) end ||''</p>'');',
'',
'if :POLL_OR_QUIZ = ''Q'' then',
'   sys.htp.p(''<p>Score: ''|| c1.grade ||'' %</p>'');',
'end if;',
'',
'if c1.score_type in (''C'',''A'') and c1.enable_score_yn = ''Y'' then',
'   sys.htp.p(''<p>Score: ''|| c1.score ||''</p>'');',
'end if;',
'',
'for c2 in (',
'select id, QUESTION, display_sequence, ',
'     ANSWER_01, ',
'     answer_02, ',
'     answer_03, ',
'     answer_04, ',
'     answer_05,',
'     answer_06, ',
'     answer_07, ',
'     answer_08, ',
'     answer_09,',
'     answer_10,',
'     answer_correct_yn',
'from EBA_QPOLL_RESULT_DETAILS',
'where result_id = c1.id) loop',
'sys.htp.p(''<p>'');',
'if :POLL_OR_QUIZ = ''Q'' and c2.answer_correct_yn = ''N'' then',
'   sys.htp.p(''<img src="#IMAGE_PREFIX#menu/inline_error_16x16.gif" alt="Wrong Answer" /> '');',
'end if;',
'sys.htp.p(''Question: ''||c2.display_sequence||'': <strong>''|| apex_escape.html(c2.question)||''</strong></p>'');',
'sys.htp.p(''<p>Answer: '');',
'sys.htp.p(apex_escape.html(c2.answer_01));',
'sys.htp.p(apex_escape.html(c2.answer_02));',
'sys.htp.p(apex_escape.html(c2.answer_03));',
'sys.htp.p(apex_escape.html(c2.answer_04));',
'sys.htp.p(apex_escape.html(c2.answer_05));',
'sys.htp.p(apex_escape.html(c2.answer_06));',
'sys.htp.p(apex_escape.html(c2.answer_07));',
'sys.htp.p(apex_escape.html(c2.answer_08));',
'sys.htp.p(apex_escape.html(c2.answer_09));',
'sys.htp.p(apex_escape.html(c2.answer_10));',
'sys.htp.p(''</p>'');',
'end loop;',
'',
'end loop;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13940727725070816076)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(13940723729331748383)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13940727610672813837)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(13940723729331748383)
,p_button_name=>'DELETE'
,p_static_id=>'delete'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Delete'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_required_patch=>wwv_flow_imp.id(13938293017878681149)
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(13940728919705839979)
,p_branch_action=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(13940727610672813837)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13942863815033958831)
,p_name=>'P73_POLL_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(13940724903421772043)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13940725816304780767)
,p_name=>'P73_RESULT_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(13940724903421772043)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13940726714072794046)
,p_computation_sequence=>10
,p_computation_item=>'P73_POLL_NAME'
,p_static_id=>'p73-poll-name'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>'select poll_name from EBA_QPOLL_POLLS where id = :POLL_ID'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(271747196549136589)
,p_name=>'cancel'
,p_static_id=>'cancel'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(13940727725070816076)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(271747321926136590)
,p_event_id=>wwv_flow_imp.id(271747196549136589)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-dialog-close'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13942875728643681296)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete Response'
,p_static_id=>'delete-response'
,p_process_sql_clob=>'delete from EBA_QPOLL_RESULTS where id = :P73_RESULT_ID;'
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'#SQLERRM#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(13940727610672813837)
,p_process_success_message=>'Response deleted.'
,p_internal_uid=>13925762889036953651
);
wwv_flow_imp.component_end;
end;
/
