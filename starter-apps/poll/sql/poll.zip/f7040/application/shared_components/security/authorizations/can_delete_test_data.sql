prompt --application/shared_components/security/authorizations/can_delete_test_data
begin
--   Manifest
--     SECURITY SCHEME: Can Delete Test Data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(13970193809206418049)
,p_name=>'Can Delete Test Data'
,p_static_id=>'can-delete-test-data'
,p_scheme_type=>'NATIVE_EXISTS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'sql_query', wwv_flow_string.join(wwv_flow_t_varchar2(
    'select 1',
    '  from eba_qpoll_results',
    ' where poll_id = :POLL_ID',
    '   and nvl(is_valid_yn,''Y'') = ''Y''',
    '   and preactive_yn = ''Y''',
    '   and eba_qpoll.get_access_role (',
    '           p_app_id   => :APP_ID,',
    '           p_username => :APP_USER) in (''CONTRIBUTOR'',''ADMINISTRATOR'')')))).to_clob
,p_error_message=>'There is no test data for this poll.'
,p_version_scn=>'1089050995'
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_imp.component_end;
end;
/
