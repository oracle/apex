prompt --application/shared_components/user_interface/lovs/score
begin
--   Manifest
--     SCORE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(13948246512993307083)
,p_lov_name=>'SCORE'
,p_static_id=>'score'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select i-1 d, i-1 r',
'from wwv_flow_dual100 ',
'where i < 12',
'order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>'1089050995'
);
wwv_flow_imp.component_end;
end;
/
