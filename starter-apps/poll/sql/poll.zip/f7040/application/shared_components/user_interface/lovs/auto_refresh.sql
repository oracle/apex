prompt --application/shared_components/user_interface/lovs/auto_refresh
begin
--   Manifest
--     AUTO REFRESH
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(14009130003662212712)
,p_lov_name=>'AUTO REFRESH'
,p_static_id=>'auto-refresh'
,p_lov_query=>'.'||wwv_flow_imp.id(14009130003662212712)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089050995'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14009132332755241445)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'No, Manual'
,p_lov_return_value=>'N'
,p_static_id=>'no-manual'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14009130216578212714)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Yes, every 5 seconds'
,p_lov_return_value=>'Y'
,p_static_id=>'yes-every-5-seconds'
);
wwv_flow_imp.component_end;
end;
/
