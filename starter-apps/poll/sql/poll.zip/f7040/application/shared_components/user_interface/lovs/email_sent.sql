prompt --application/shared_components/user_interface/lovs/email_sent
begin
--   Manifest
--     EMAIL_SENT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(14001117924000933581)
,p_lov_name=>'EMAIL_SENT'
,p_static_id=>'email-sent'
,p_lov_query=>'.'||wwv_flow_imp.id(14001117924000933581)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089050995'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14001118525481933591)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Opted Out'
,p_lov_return_value=>'OPTED_OUT'
,p_static_id=>'opted-out'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14001118808901933592)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Previously Sent'
,p_lov_return_value=>'PREVIOUSLY_SENT'
,p_static_id=>'previously-sent'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14001118204546933588)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Yes'
,p_lov_return_value=>'YES'
,p_static_id=>'yes'
);
wwv_flow_imp.component_end;
end;
/
