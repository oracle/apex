prompt --application/pages/page_00014
begin
--   Manifest
--     PAGE: 00014
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>14
,p_name=>'&APPLICATION_TITLE. - Request Access'
,p_alias=>'REQUEST-ACCESS'
,p_step_title=>'&APPLICATION_TITLE. - Request Access'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(13924462718486256148)
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(13919837625554089123)
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14008975306020752489)
,p_plug_name=>'hide nobody'
,p_static_id=>'hide-nobody'
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<style>.userBlock{display: none !important} .logoBarNav {padding-top: 8px;visibility: hidden;}</style>'
,p_translate_title=>'N'
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if apex_authentication.is_authenticated then',
'   return false;',
'else',
'   return true;',
'end if;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13919759402876112391)
,p_plug_name=>'Request Access'
,p_static_id=>'request-access'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--defaultIcons:t-Alert--info:t-Form--stretchInputs'
,p_plug_template=>2042159785845301134
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>To access the &APPLICATION_TITLE. application you need to be an authorized user. If you are not already authorized, please submit a request using the form below.</p>',
'<br>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13919760012227115113)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(13919759402876112391)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:&LAST_VIEW.:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13919767720294249827)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(13919759402876112391)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Request Access'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(13919772027429374129)
,p_branch_action=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.:::'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13919766731878205006)
,p_name=>'P14_EMAIL_ADDRESS'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(13919759402876112391)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if regexp_instr(:APP_USER,''^[-!#$%&''''''''*+/0-9=?A-Z^_a-z{|}~](\.?[-!#$%&''''''''*+/0-9=?A-Z^_a-z{|}~])*@(-?[a-zA-Z0-9+])+(\.(-?[a-zA-Z0-9+])*)+$'')',
'= 1',
'   then return :APP_USER;',
'end if;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Email Address'
,p_source=>'EMAIL_ADDRESS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'Please enter the email address we will use to send the results of your account request to. This field is limited to 255 characters.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13919769323202269747)
,p_name=>'P14_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(13919759402876112391)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13919767227552222146)
,p_name=>'P14_JUSTIFICATION'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(13919759402876112391)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Justification'
,p_source=>'JUSTIFICATION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>3
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Please tell us why you would like access to &APPLICATION_TITLE.. This field is limited to 4,000 characters.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13919769517595272363)
,p_name=>'P14_STATUS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(13919759402876112391)
,p_use_cache_before_default=>'NO'
,p_item_default=>'pending'
,p_source=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13919976404947082839)
,p_name=>'P14_USERNAME'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(13919759402876112391)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Username'
,p_source=>'USERNAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_display_when=>'eba_qpoll_fw.get_preference_value(''USERNAME_FORMAT'') = ''STRING'''
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Please enter the username you would like to login with. This field is restricted to 255 characters.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13921625711935729104)
,p_computation_sequence=>10
,p_computation_item=>'P14_USERNAME'
,p_static_id=>'p14-username'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'upper(:P14_EMAIL_ADDRESS)'
,p_compute_when=>'eba_qpoll_fw.get_preference_value(''USERNAME_FORMAT'') = ''EMAIL'''
,p_compute_when_text=>'PLSQL'
,p_compute_when_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(13919771626159344367)
,p_validation_name=>'P14_EMAIL_ADDRESS already has proper access'
,p_static_id=>'p14-email-address-already-has-proper-access'
,p_validation_sequence=>40
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_user_found       varchar2(1) := ''N'';',
'   l_apex_user_found  varchar2(1) := ''N'';',
'begin',
'   for c1 in (',
'      select 1',
'        from apex_appl_acl_users',
'       where application_id = :APP_ID',
'         and user_name_lc = lower(:P14_EMAIL_ADDRESS)',
'   ) loop',
'      l_user_found := ''Y'';',
'   end loop;',
'',
'   -- not an application user',
'   if l_user_found = ''N'' then',
'      return true;',
'   end if;',
'',
'   -- only if is an application user',
'   for c1 in (',
'      select 1',
'        from apex_applications',
'       where application_id = :APP_ID',
'         and authentication_scheme_type = ''Application Express Accounts''',
'   ) loop',
'      for c2 in (',
'         select 1',
'           from apex_workspace_apex_users',
'          where lower(user_name) = lower(:P14_EMAIL_ADDRESS)',
'      ) loop',
'         -- already have apex account',
'         return false;',
'      end loop;',
'',
'      return true;',
'   end loop;',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'This Email Address already has access to this self-service system.'
,p_when_button_pressed=>wwv_flow_imp.id(13919767720294249827)
,p_associated_item=>wwv_flow_imp.id(13919766731878205006)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(13919770614119304348)
,p_validation_name=>'P14_EMAIL_ADDRESS Unique'
,p_static_id=>'p14-email-address-unique'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'   select 1 ',
'     from eba_qpoll_access_requests',
'    where email_address = lower(:P14_EMAIL_ADDRESS)',
'      and status = ''pending''',
') loop',
'   return false;',
'end loop;',
'',
'return true;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Outstanding request for this email address already exists.'
,p_when_button_pressed=>wwv_flow_imp.id(13919767720294249827)
,p_associated_item=>wwv_flow_imp.id(13919766731878205006)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(13919771432426326275)
,p_validation_name=>'P14_EMAIL_ADDRESS valid format'
,p_static_id=>'p14-email-address-valid-format'
,p_validation_sequence=>30
,p_validation=>'P14_EMAIL_ADDRESS'
,p_validation2=>'^[-!#$%&''''''''*+/0-9=?A-Z^_a-z{|}~](\.?[-!#$%&''''''''*+/0-9=?A-Z^_a-z{|}~])*@(-?[a-zA-Z0-9+])+(\.(-?[a-zA-Z0-9+])*)+$'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>'Email Address is not in a valid format.'
,p_associated_item=>wwv_flow_imp.id(13919766731878205006)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(13919771225968314030)
,p_validation_name=>'P14_JUSTIFICATION <= 4000'
,p_static_id=>'p14-justification'
,p_validation_sequence=>20
,p_validation=>'length(:P14_JUSTIFICATION) <= 4000'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Justification must be less than 4000 characters.'
,p_associated_item=>wwv_flow_imp.id(13919767227552222146)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(13919976716149092789)
,p_validation_name=>'P14_USERNAME not null'
,p_static_id=>'p14-username-not-null'
,p_validation_sequence=>50
,p_validation=>'P14_USERNAME'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have some value.'
,p_validation_condition=>'eba_qpoll_fw.get_preference_value(''USERNAME_FORMAT'') = ''STRING'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(13919767720294249827)
,p_associated_item=>wwv_flow_imp.id(13919976404947082839)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13919771715764371549)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row for EBA_QPOLL_ACCESS_REQUESTS'
,p_static_id=>'process-row-for-eba-qpoll-access-requests'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'lock_row', 'Y',
  'primary_key_column', 'ID',
  'primary_key_item', 'P14_ID',
  'supported_operations', 'I',
  'table_name', 'EBA_QPOLL_ACCESS_REQUESTS')).to_clob
,p_process_error_message=>'#SQLERRM#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Your access request has been submitted. You will receive an email with login credentials upon approval.'
,p_internal_uid=>13902658876157643904
);
wwv_flow_imp.component_end;
end;
/
