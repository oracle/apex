prompt --application/pages/page_00057
begin
--   Manifest
--     PAGE: 00057
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>17112839606727645
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>57
,p_name=>'Email Preview'
,p_alias=>'EMAIL-PREVIEW'
,p_step_title=>'Email Preview'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(16401245157324588065)
,p_step_template=>2979075366320325194
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(165977452478131556)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13919966507561658370)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13919966715457658374)
,p_plug_name=>'Show Template'
,p_region_name=>'show-template'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_3'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_poll_url   varchar2(4000);',
'   l_body       clob;',
'   l_subject    varchar2(4000);',
'   l_html_body  clob;',
'   l_text_body  clob;',
'begin',
'',
'l_poll_url := ''<a href="#">''||apex_escape.html(:POLL_NAME)||''</a>'';',
'                                                     ',
'l_body := replace(:P72_INVITE_BODY,''#POLL_LINK#'',l_poll_url);',
'   ',
'for c1 in (',
'    select case when :P57_METHOD = ''INVITE''',
'                then nvl(apex_escape.html(:P72_INVITE_SUBJECT),''Please Share Your Opinion on ''||:POLL_NAME) ',
'                else nvl(apex_escape.html(:P1072_REMINDER_SUBJECT),''Reminder: Please Share Your Opinion on ''||:POLL_NAME) ',
'                end invite_subject, ',
'           case when :P57_METHOD = ''INVITE''',
'                then nvl(apex_escape.html(:P72_INVITE_BODY),''<p>Please take #POLL_LINK#.</p>',
'''||',
'           case when authentication_req_yn = ''N''',
'                then apex_lang.message(''UNAUTH_MSG'') end ||',
'''<p>Thanks in advance for your participation!</p>',
'<p>Best Regards,</p>',
'<p>The ''||apex_escape.html(:APPLICATION_TITLE)||'' Team</p>'') ',
'                else nvl(apex_escape.html(:P1072_REMINDER_BODY),''<p>Please take #POLL_LINK#.</p>',
'''||',
'           case when authentication_req_yn = ''N''',
'                then apex_lang.message(''UNAUTH_MSG'') end ||',
'''<p>Thanks in advance for your participation!</p>',
'<p>Best Regards,</p>',
'<p>The ''||apex_escape.html(:APPLICATION_TITLE)||'' Team</p>'') end invite_body',
'      from eba_qpoll_polls',
'     where id = :POLL_ID',
') loop',
'',
'   apex_mail.prepare_template (',
'      p_static_id       => ''INVITE'',',
'      p_placeholders    => ''{'' || ',
'                           ''    "SUBJECT":''           || apex_json.stringify( c1.invite_subject ) || ',
'                           ''   ,"APPLICATION_TITLE":'' || apex_json.stringify( apex_escape.html(:APPLICATION_TITLE) ) || ',
'                           ''   ,"OPT_OUT_TEXT":''      || apex_json.stringify( apex_lang.message(''OPT_OUT_TEXT'', ',
'                                                                              :APP_PATH || ''/f?p='' || :APP_ID || '':optout'',',
'                                                                              apex_escape.html(:APPLICATION_TITLE)) ) || ',
'                           ''   ,"BODY":''  || apex_json.stringify( replace(c1.invite_body,''#POLL_LINK#'',''<a href="#">''||:POLL_NAME||''</a>'') ) || ',
'                           ''}'' , ',
'      p_application_id  => :APP_ID,',
'      p_subject         => l_subject,',
'      p_html            => l_html_body,',
'      p_text            => l_text_body );',
'      ',
'   sys.htp.p(l_html_body);',
'   ',
'end loop;',
'      ',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13919967804975676860)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(13919966507561658370)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Close Preview'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'javascript:window.close();'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(437592769626961275)
,p_name=>'P57_METHOD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(13919966507561658370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
