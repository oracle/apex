prompt --application/pages/page_00018
begin
--   Manifest
--     PAGE: 00018
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>18
,p_name=>'Poll History'
,p_alias=>'POLL-HISTORY'
,p_page_mode=>'MODAL'
,p_step_title=>'Poll History'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(13925947051057752382)
,p_step_template=>2121795032473542284
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(167453297030546086)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(33360406715541336659)
,p_name=>'History'
,p_region_name=>'HISTORY'
,p_template=>4072358936313175081
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:t-Comments--chat'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select '''' comment_modifiers, ',
'    ''Question Update'' note_type,',
'    replace(initcap(replace(replace(f.column_name,''_ID'',null),''_'','' '')),chr(10),''<br>'') comment_text,',
'    '' changed from "''||f.old_value||''"'' attribute_1,',
'    '' to "''||f.new_value||''"'' attribute_2,',
'    '' '' attribute_3,',
'    '' '' attribute_4,',
'    lower(f.changed_by) user_name,',
'    apex_util.get_since(f.change_date) comment_date,',
'    '' '' link,',
'    null update_id,',
'    f.change_date,',
'    '''' actions,',
'    upper(',
'          decode(instr(replace(f.changed_by,''.'','' ''),'' ''),',
'                 0, ',
'                 substr(f.changed_by,1,2),',
'                 substr(f.changed_by,1,1)||substr(f.changed_by,instr(replace(f.changed_by,''.'','' ''),'' '')+1,1)',
'           )) user_icon',
'from eba_qpoll_history f,',
'    eba_qpoll_questions q',
'where f.table_name = ''QUESTIONS''',
'    and f.component_id = q.id',
'    and q.poll_id = :POLL_ID',
'    and ( f.column_name != ''QUESTION''',
'        or ( f.old_value is not null and f.new_value is not null ) )',
'union all',
'select  '''' comment_modifiers, ',
'    ''Question Added'' comment_type,',
'    replace(initcap(replace(replace(f.column_name,''_ID'',null),''_'','' '')),chr(10),''<br>'') comment_text,',
'    '' '' attribute_1,',
'    '' added "''||f.new_value||''"'' attribute_2,',
'    '' '' attribute_3,',
'    '' '' attribute_4,',
'    lower(f.changed_by) user_name,',
'    apex_util.get_since(f.change_date) comment_date,',
'    '' '' link,',
'    null update_id,',
'    f.change_date,',
'    '''' actions,',
'    upper(',
'          decode(instr(replace(f.changed_by,''.'','' ''),'' ''),',
'                 0, ',
'                 substr(f.changed_by,1,2),',
'                 substr(f.changed_by,1,1)||substr(f.changed_by,instr(replace(f.changed_by,''.'','' ''),'' '')+1,1)',
'           )) user_icon',
'from eba_qpoll_history f',
'where f.table_name = ''QUESTIONS''',
'    and f.poll_id = :POLL_ID',
'    and f.column_name = ''QUESTION''',
'    and f.old_value is null',
'union all',
'select '''' comment_modifiers, ',
'    ''Question Removed'' comment_type,',
'    replace(initcap(replace(replace(f.column_name,''_ID'',null),''_'','' '')),chr(10),''<br>'') comment_text,',
'    '' removed "''||f.old_value||''"'' attribute_1,',
'    '' '' attribute_2,',
'    '' '' attribute_3,',
'    '' '' attribute_4,',
'    lower(f.changed_by) user_name,',
'    apex_util.get_since(f.change_date) comment_date,',
'    '' '' link,',
'    null update_id,',
'    f.change_date,',
'    '''' actions,',
'    upper(',
'          decode(instr(replace(f.changed_by,''.'','' ''),'' ''),',
'                 0, ',
'                 substr(f.changed_by,1,2),',
'                 substr(f.changed_by,1,1)||substr(f.changed_by,instr(replace(f.changed_by,''.'','' ''),'' '')+1,1)',
'           )) user_icon',
'from eba_qpoll_history f',
'where f.table_name = ''QUESTIONS''',
'    and f.poll_id = :POLL_ID',
'    and f.column_name = ''QUESTION''',
'    and f.new_value is null',
'order by 12 desc'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from eba_qpoll_history f',
'where f.table_name = ''QUESTIONS''',
'    and f.poll_id = :POLL_ID',
'    and f.column_name = ''QUESTION'''))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2613168815517880001
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'No history found.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(721541032201415728)
,p_query_column_id=>1
,p_column_alias=>'COMMENT_MODIFIERS'
,p_column_display_sequence=>9
,p_column_heading=>'Comment Modifiers'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(721541417724415728)
,p_query_column_id=>2
,p_column_alias=>'NOTE_TYPE'
,p_column_display_sequence=>1
,p_column_heading=>'NOTE_TYPE'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(721541812598415729)
,p_query_column_id=>3
,p_column_alias=>'COMMENT_TEXT'
,p_column_display_sequence=>10
,p_column_heading=>'Comment Text'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(721542203724415729)
,p_query_column_id=>4
,p_column_alias=>'ATTRIBUTE_1'
,p_column_display_sequence=>2
,p_column_heading=>'ATTRIBUTE_1'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(721542611352415730)
,p_query_column_id=>5
,p_column_alias=>'ATTRIBUTE_2'
,p_column_display_sequence=>4
,p_column_heading=>'ATTRIBUTE_2'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(721543007190415736)
,p_query_column_id=>6
,p_column_alias=>'ATTRIBUTE_3'
,p_column_display_sequence=>3
,p_column_heading=>'ATTRIBUTE_3'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(721543410079415737)
,p_query_column_id=>7
,p_column_alias=>'ATTRIBUTE_4'
,p_column_display_sequence=>5
,p_column_heading=>'ATTRIBUTE_4'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(721543855308415737)
,p_query_column_id=>8
,p_column_alias=>'USER_NAME'
,p_column_display_sequence=>11
,p_column_heading=>'User Name'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(721544213411415737)
,p_query_column_id=>9
,p_column_alias=>'COMMENT_DATE'
,p_column_display_sequence=>12
,p_column_heading=>'Comment Date'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(721544603546415738)
,p_query_column_id=>10
,p_column_alias=>'LINK'
,p_column_display_sequence=>6
,p_column_heading=>'LINK'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(721545058860415739)
,p_query_column_id=>11
,p_column_alias=>'UPDATE_ID'
,p_column_display_sequence=>7
,p_column_heading=>'UPDATE_ID'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(721545477745415739)
,p_query_column_id=>12
,p_column_alias=>'CHANGE_DATE'
,p_column_display_sequence=>8
,p_column_heading=>'CHANGE_DATE'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(721545844930415739)
,p_query_column_id=>13
,p_column_alias=>'ACTIONS'
,p_column_display_sequence=>13
,p_column_heading=>'Actions'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(721546239637415740)
,p_query_column_id=>14
,p_column_alias=>'USER_ICON'
,p_column_display_sequence=>14
,p_column_heading=>'User Icon'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(48188810309492579787)
,p_name=>'Change History'
,p_region_name=>'change_history'
,p_template=>2040683448887306517
,p_display_sequence=>30
,p_icon_css_classes=>'fa-clock-o'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info:t-Alert--accessibleHeading'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_new_grid_row=>false
,p_new_grid_column=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select    ',
'    lower(created_by) || '' (''||apex_util.get_since(created)||'')'' CREATED,',
'    lower(updated_by) || '' (''||apex_util.get_since(UPDATED)||'')'' updated',
'from EBA_QPOLL_POLLS q',
'where id = :POLL_ID',
'order by 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2100515439059797523
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(721772527715771727)
,p_query_column_id=>1
,p_column_alias=>'CREATED'
,p_column_display_sequence=>1
,p_column_heading=>'Created'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(721772924892771727)
,p_query_column_id=>2
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>2
,p_column_heading=>'Updated'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp.component_end;
end;
/
