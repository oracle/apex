prompt --application/pages/page_00023
begin
--   Manifest
--     PAGE: 00023
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-17'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>23
,p_user_interface_id=>wwv_flow_imp.id(14332515601885435799)
,p_name=>'Invitations Sent'
,p_alias=>'INVITATIONS-SENT'
,p_step_title=>'Invitations Sent'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(13907358366898610207)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'section.uSuccessRegion p.desc {',
'font-size: 14px;',
'line-height: 1.5;',
'font-weight: normal;',
'margin-bottom: 16px;',
'color: #404040;',
'text-align: left;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(148864612871403911)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'03'
,p_last_upd_yyyymmddhh24miss=>'20210301100151'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13996902078842922492)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14588574158926420242)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(17588349840095506346)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(14588592018629420306)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13996902382411927651)
,p_plug_name=>'Invitations Sent!'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--defaultIcons:t-Alert--success'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14588560922544420208)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_source=>'<p>Details of how many emails were sent, how many were not sent because the user had previously been invited and how many users have opted out of receiving emails are displayed below.</p>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(13996931266966758858)
,p_name=>'Community Invites'
,p_parent_plug_id=>wwv_flow_imp.id(13996902382411927651)
,p_template=>wwv_flow_imp.id(14588562352722420217)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_display_point=>'SUB_REGIONS'
,p_item_display_point=>'BELOW'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select decode(email_sent,''YES'',''Emails Sent'',',
'                         ''OPTED_OUT'',''Opted Out'',',
'                         ''PREVIOUSLY_SENT'',''Previously Sent'',',
'                         ''MANUAL_INVITE'',''Manual Invites'',',
'                         email_sent) email_sent, count(*) cnt',
'  from eba_qpoll_invites',
' where comm_invite_id = :P72_COMM_INVITE_ID',
'    or comm_invite_id = :P72_COMM_INVITE_ID2',
'group by email_sent'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(14588581295199420263)
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'No community invites found.'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13996931575287758874)
,p_query_column_id=>1
,p_column_alias=>'EMAIL_SENT'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13996931665861758876)
,p_query_column_id=>2
,p_column_alias=>'CNT'
,p_column_display_sequence=>1
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13996933079873819288)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(13996902078842922492)
,p_button_name=>'INVITE_MORE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(14588591799596420304)
,p_button_image_alt=>'Invite More'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:72:&SESSION.::&DEBUG.:72:P72_POLL_ID,P72_INVITE_METHOD:&P72_POLL_ID.,&P72_INVITE_METHOD.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from EBA_QPOLL_RESP_COMMUNITIES',
'where id not in',
'      (select community_id',
'         from eba_qpoll_comm_invites',
'        where poll_id = :P72_POLL_ID)'))
,p_button_condition_type=>'EXISTS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13996915169972851367)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(13996902078842922492)
,p_button_name=>'VIEW_EMAILS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(14588591799596420304)
,p_button_image_alt=>'View Emails'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:59:&SESSION.::&DEBUG.:CIR,RIR:IR_POLL_ID:&P72_POLL_ID.'
,p_security_scheme=>wwv_flow_imp.id(148864362900403911)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13997041279285413582)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(13996902078842922492)
,p_button_name=>'VIEW_INVITES'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(14588591799596420304)
,p_button_image_alt=>'View Invitations'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:CIR,RIR:IR_POLL_ID,IRC_COMM_INVITE_ID:&P72_POLL_ID.,&P72_COMM_INVITE_ID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14002436266084189303)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(13996902078842922492)
,p_button_name=>'VIEW_POLL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(14588591799596420304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Manage Poll'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:100:LPOLL_ID:&P72_POLL_ID.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14033630567648615342)
,p_name=>'P23_OTHER_INVITEES_MSG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(13996931266966758858)
,p_use_cache_before_default=>'NO'
,p_source=>'P72_OTHER_INVITEES_MSG'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(14588590531784420290)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
