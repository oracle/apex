prompt --application/pages/page_00048
begin
--   Manifest
--     PAGE: 00048
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>48
,p_name=>'Poll Details'
,p_alias=>'POLL-DETAILS2'
,p_page_mode=>'MODAL'
,p_step_title=>'Poll Details'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(13924471206505337852)
,p_step_template=>2101883943284197310
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_required_role=>wwv_flow_imp.id(165977452478131556)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4551234547378583500)
,p_plug_name=>'Advanced'
,p_static_id=>'advanced'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13880207504245634999)
,p_plug_name=>'bottom buttons'
,p_static_id=>'bottom-buttons'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>2127905476394690047
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24141964418489480060)
,p_plug_name=>'Customize Display'
,p_static_id=>'customize-display'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13880201712258634969)
,p_plug_name=>'Details'
,p_static_id=>'details'
,p_region_css_classes=>'infoTextRegion'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4551234744162583502)
,p_plug_name=>'Poll'
,p_static_id=>'poll'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(504747472003661845)
,p_plug_name=>'published'
,p_static_id=>'published'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>2042159785845301134
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Be cautious of what you change because this Poll is currently Published.'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_polls',
' where id = :P48_ID',
'   and status_id = 3'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4551234581871583501)
,p_plug_name=>'RDS'
,p_static_id=>'rds'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13880202117306634970)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(13880207504245634999)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13880201908952634970)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(13880207504245634999)
,p_button_name=>'SAVE'
,p_static_id=>'save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CREATE'
,p_button_condition=>'P48_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13935315534565920390)
,p_name=>'P48_ALL_VIEW_RESULTS_YN'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(4551234547378583500)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Invitees Can View Results'
,p_source=>'ALL_VIEW_RESULTS_YN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Poll results are always viewable by Readers, Contributors and Administrators of this application. Click this to allow those invited to take this poll to view the results, whether or not they have Reader or greater access. If Yes, there will the optio'
||'n to include a "View Results" link in all email invitations and a "View Results" button will be displayed on the thank you page after completing the poll.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13935314908267917351)
,p_name=>'P48_ANONYMOUS_YN'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(13880201712258634969)
,p_use_cache_before_default=>'NO'
,p_item_default=>'N'
,p_prompt=>'Anonymize Results'
,p_source=>'ANONYMOUS_YN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'If set to Yes, the name of the respondent will not be displayed when viewing results (e.g. who selected which answer).  If you choose <strong>No</strong>, each response will be labeled with the respondent.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28457525082333974923)
,p_name=>'P48_ANON_NO_CHANGE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(13880201712258634969)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Note'
,p_source=>'When a Poll is set to Anonymize Results and there are already responses, you cannot change the setting.'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14009827626757234315)
,p_name=>'P48_AUTHENTICATION_REQ_YN'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(13880201712258634969)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Require Login'
,p_source=>'AUTHENTICATION_REQ_YN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'If you select <strong>Yes</strong> for login required, all invitees will be required to login to take the poll.  If you choose <strong>No</strong> for login required, then your users will only require access to the server to take the poll.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13938455732941369931)
,p_name=>'P48_CAN_UPDATE_ANSWERS_YN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(4551234547378583500)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Can Update Answers'
,p_source=>'CAN_UPDATE_ANSWERS_YN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'If you allow update, a respondent can access the poll again and update their answers.  '
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13949109708623644839)
,p_name=>'P48_ENABLE_SCORE_YN'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(4551234547378583500)
,p_use_cache_before_default=>'NO'
,p_item_default=>'N'
,p_prompt=>'Scoring Enabled'
,p_source=>'ENABLE_SCORE_YN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'If scoring is enabled, the score of each response will be displayed in the results.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13880202532910634974)
,p_name=>'P48_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4551234744162583502)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7524286896267137273)
,p_name=>'P48_IMAGE_BLOB'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(24141964418489480060)
,p_use_cache_before_default=>'NO'
,p_item_default=>'IMAGE_BLOB'
,p_prompt=>'Image'
,p_source=>'IMAGE_BLOB'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>60
,p_cMaxlength=>4000
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'If you include an image, it will be displayed at the top of any poll created from this question set.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_copy_paste', 'N',
  'blob_last_updated_column', 'IMAGE_LAST_UPDATED',
  'character_set_column', 'IMAGE_CHARSET',
  'display_as', 'INLINE',
  'display_download_link', 'N',
  'filename_column', 'IMAGE_FILENAME',
  'mime_type_column', 'IMAGE_MIMETYPE',
  'storage_type', 'DB_COLUMN')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7524287860060137274)
,p_name=>'P48_IMAGE_HEIGHT'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(24141964418489480060)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Image Height'
,p_source=>'IMAGE_HEIGHT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>5
,p_cMaxlength=>4000
,p_colspan=>4
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7524288204165137274)
,p_name=>'P48_IMAGE_WIDTH'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(24141964418489480060)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Width'
,p_source=>'IMAGE_WIDTH'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>5
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13942004819818172872)
,p_name=>'P48_INTRO_TEXT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(24141964418489480060)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Introduction Text'
,p_source=>'INTRO_TEXT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>3
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Introduction text, if provided, is displayed on the main poll page.  Use this to explain the poll, if necessary.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13951266709887417772)
,p_name=>'P48_INVITE_ONLY_YN'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(13880201712258634969)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Invite Only'
,p_source=>'INVITE_ONLY_YN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Selecting invite only <strong>Yes</strong> will restrict the list of people who can take your poll to those who have been invited.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13942004623053171331)
,p_name=>'P48_POLL_DETAILS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(13880201712258634969)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Description'
,p_source=>'POLL_DETAILS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>2
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'This is only displayed to Contributors when managing the poll - not displayed to users when taking a poll.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13880203514220634987)
,p_name=>'P48_POLL_NAME'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(4551234744162583502)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Poll Name'
,p_source=>'POLL_NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'The poll name will display in the email invitations as well as within this application.  Please use a descriptive name.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7524284230478137269)
,p_name=>'P48_POLL_OR_QUIZ'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(13880201712258634969)
,p_use_cache_before_default=>'NO'
,p_item_default=>'P'
,p_prompt=>'Type'
,p_source=>'POLL_OR_QUIZ'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'POLL OR QUIZ'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_help_text=>'Identify if the question set represents a poll or a quiz.  A poll can have scoring enabled to allow you to assign 0-10 to each answer and evaluate the responses based on either the average or cumulative score.  With a quiz, you identify the correct a'
||'nswer(s) and a grade is then assigned to each response.'
,p_inline_help_text=>'Choose the <strong>Poll</strong> type if there is no correct answer. Choose type <strong>Quiz</strong> if questions have correct answers.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7524285972901137272)
,p_name=>'P48_SCORE_TYPE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(4551234547378583500)
,p_use_cache_before_default=>'NO'
,p_item_default=>'N'
,p_prompt=>'Poll Score Type'
,p_source=>'SCORE_TYPE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'QSET_SCORE_TYPE'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_help_text=>'Polls may be scored, meaning that answers to questions can be given a weighting of 0 to 10.  Scoring answers allows a poll, designed to be scored, the ability to distill poll results into a single numeric value.  Use scoring if you are asking satisfa'
||'ction type questions.  Textual responses can not be scored.'
,p_inline_help_text=>'Polls can be scored, this allows answers to be assigned a numeric value allowing you to sum or average responses over all answers.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13880204107912634988)
,p_name=>'P48_STATUS_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(4551234744162583502)
,p_use_cache_before_default=>'NO'
,p_item_default=>'4'
,p_prompt=>'Status'
,p_source=>'STATUS_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'POLL STATUSES'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_help_text=>'Select <strong>Published</strong> if you wish to make this poll available to be taken (by the general user community or by those you have invited).  If you select <strong>Testing</strong>, the poll can be tested by users who are contributors.  Use th'
||'is to ensure your poll is set up correctly.  Once you are done testing and are ready to publish, you can easily remove your testing responses.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '4',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13942005016584174337)
,p_name=>'P48_THANK_YOU_TEXT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(24141964418489480060)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Thank You Text'
,p_source=>'THANK_YOU_TEXT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>3
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Thank you text, if provided, is shown on the page the user is navigated to after they submit their response.  It does not need to thank them for submitting - the page already contains "Thank you for submitting your poll".'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7524285073000137271)
,p_name=>'P48_USE_SECTIONS_YN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(24141964418489480060)
,p_use_cache_before_default=>'NO'
,p_item_default=>'N'
,p_prompt=>'Use Sections'
,p_source=>'USE_SECTIONS_YN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'If set to Yes, you will be able to define sections and then assign questions to those sections.  If set to No, even if sections are defined, they will not be displayed within the poll.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(28457530486516983462)
,p_name=>'hide P48_ANON_NO_CHANGE'
,p_static_id=>'hide-p48-anon-no-change'
,p_event_sequence=>15
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28457530895258983464)
,p_event_id=>wwv_flow_imp.id(28457530486516983462)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P48_ANON_NO_CHANGE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(245149508197686495)
,p_name=>'show/hide enable score'
,p_static_id=>'show-hide-enable-score'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P48_SCORE_TYPE'
,p_condition_element=>'P48_SCORE_TYPE'
,p_triggering_condition_type=>'IN_LIST'
,p_triggering_expression=>'A,C'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(250083664719050547)
,p_event_id=>wwv_flow_imp.id(245149508197686495)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P48_ENABLE_SCORE_YN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(250083805682050548)
,p_event_id=>wwv_flow_imp.id(245149508197686495)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-set-value'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P48_ENABLE_SCORE_YN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'suppress_change_event', 'N',
  'type', 'STATIC_ASSIGNMENT',
  'value', 'N')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(250083608739050546)
,p_event_id=>wwv_flow_imp.id(245149508197686495)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P48_ENABLE_SCORE_YN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7524295917823140239)
,p_name=>'show/hide poll score type'
,p_static_id=>'show-hide-poll-score-type'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P48_POLL_OR_QUIZ'
,p_condition_element=>'P48_POLL_OR_QUIZ'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Q'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7524296362427140240)
,p_event_id=>wwv_flow_imp.id(7524295917823140239)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P48_SCORE_TYPE,P48_ENABLE_SCORE_YN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7524297353733140241)
,p_event_id=>wwv_flow_imp.id(7524295917823140239)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-set-value'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P48_SCORE_TYPE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'suppress_change_event', 'N',
  'type', 'STATIC_ASSIGNMENT',
  'value', 'N')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(245149399315686494)
,p_event_id=>wwv_flow_imp.id(7524295917823140239)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-set-value-2'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P48_ENABLE_SCORE_YN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'suppress_change_event', 'N',
  'type', 'STATIC_ASSIGNMENT',
  'value', 'N')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7524296811479140241)
,p_event_id=>wwv_flow_imp.id(7524295917823140239)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P48_SCORE_TYPE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(28457413001384140308)
,p_name=>'when anon and results, cannot change'
,p_static_id=>'when-anon-and-results-cannot-change'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'EXISTS'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_qpoll_results',
' where poll_id = :POLL_ID',
'   and :P48_ANONYMOUS_YN = ''Y'''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28457413394354140310)
,p_event_id=>wwv_flow_imp.id(28457413001384140308)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_static_id=>'native-disable'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P48_ANONYMOUS_YN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(28457532691626986276)
,p_event_id=>wwv_flow_imp.id(28457413001384140308)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P48_ANON_NO_CHANGE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(14009827916872239427)
,p_name=>'When not authenticated, invite only'
,p_static_id=>'when-not-authenticated-invite-only'
,p_event_sequence=>2
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P48_AUTHENTICATION_REQ_YN'
,p_condition_element=>'P48_AUTHENTICATION_REQ_YN'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'N'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14009828429758239451)
,p_event_id=>wwv_flow_imp.id(14009827916872239427)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-disable'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P48_INVITE_ONLY_YN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14009828631947239452)
,p_event_id=>wwv_flow_imp.id(14009827916872239427)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-enable'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P48_INVITE_ONLY_YN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14009828231128239451)
,p_event_id=>wwv_flow_imp.id(14009827916872239427)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-set-value'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P48_INVITE_ONLY_YN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'suppress_change_event', 'N',
  'type', 'STATIC_ASSIGNMENT',
  'value', 'Y')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(264796590354774858)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'close dialog'
,p_static_id=>'close-dialog'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_success_messages', 'N')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>247683750748047213
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13880206909778634998)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from EBA_QPOLL_POLLS'
,p_static_id=>'fetch-row-from-eba-qpoll-polls'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'primary_key_column', 'ID',
  'primary_key_item', 'P48_ID',
  'table_name', 'EBA_QPOLL_POLLS')).to_clob
,p_internal_uid=>13863094070171907353
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13880207123248634999)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of EBA_QPOLL_POLLS'
,p_static_id=>'process-row-of-eba-qpoll-polls'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'lock_row', 'Y',
  'primary_key_column', 'ID',
  'primary_key_item', 'P48_ID',
  'supported_operations', 'I:U',
  'table_name', 'EBA_QPOLL_POLLS')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>13863094283641907354
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13880207330639634999)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_static_id=>'reset-page'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'type', 'CLEAR_CACHE_CURRENT_PAGE')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>13863094491032907354
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(245146701078686467)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set POLL_NAME'
,p_static_id=>'set-poll-name'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':POLL_NAME       := null;',
':POLL_OR_QUIZ    := null;',
':POLL_AUTHENTICATION_REQ_YN := null;',
'',
'for c1 in (',
'   select id, apex_escape.html(poll_name) as poll_name, poll_or_quiz, authentication_req_yn',
'     from eba_qpoll_polls',
'    where id = :POLL_ID',
') loop',
'   :POLL_NAME       := c1.poll_name;',
'   :POLL_OR_QUIZ    := c1.poll_or_quiz;',
'   :POLL_AUTHENTICATION_REQ_YN := c1.authentication_req_yn;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>228033861471958822
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14009829922066240964)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set values of disabled items'
,p_static_id=>'set-values-of-disabled-items'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P48_AUTHENTICATION_REQ_YN = ''N'' then',
'   :P48_INVITE_ONLY_YN := ''Y'';',
'end if;',
'',
'-- if was anonymous and there is one result, can''t change',
'for c1 in (',
'   select p.anonymous_yn',
'     from eba_qpoll_polls p,',
'          eba_qpoll_results r',
'    where p.id = :POLL_ID',
'      and p.id = r.poll_id',
') loop',
'   if c1.anonymous_yn = ''Y'' then',
'      :P48_ANONYMOUS_YN := ''Y'';',
'   end if;',
'   exit;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(13880201908952634970)
,p_internal_uid=>13992717082459513319
);
wwv_flow_imp.component_end;
end;
/
