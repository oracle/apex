prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7040
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(14524202803791474312)
,p_group_name=>'ACL'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(16402721001877002595)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(13950547359738495930)
,p_group_name=>'Communities'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(14524202500328473272)
,p_group_name=>'Help'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(14524202601367473615)
,p_group_name=>'Home'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(13948775873924918015)
,p_group_name=>'Invite'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(14524202702752474002)
,p_group_name=>'Login'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(13975306160944746875)
,p_group_name=>'Opt Out'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(13925947051057752382)
,p_group_name=>'Polls'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(13925938563038670678)
,p_group_name=>'Request Access'
);
wwv_flow_imp.component_end;
end;
/
