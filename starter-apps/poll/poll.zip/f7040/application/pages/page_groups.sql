prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7040
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(14522726959239059782)
,p_group_name=>'ACL'
,p_static_id=>'acl'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(16401245157324588065)
,p_group_name=>'Administration'
,p_static_id=>'administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(13949071515186081400)
,p_group_name=>'Communities'
,p_static_id=>'communities'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(14522726655776058742)
,p_group_name=>'Help'
,p_static_id=>'help'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(14522726756815059085)
,p_group_name=>'Home'
,p_static_id=>'home'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(13947300029372503485)
,p_group_name=>'Invite'
,p_static_id=>'invite'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(14522726858200059472)
,p_group_name=>'Login'
,p_static_id=>'login'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(13973830316392332345)
,p_group_name=>'Opt Out'
,p_static_id=>'opt-out'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(13924471206505337852)
,p_group_name=>'Polls'
,p_static_id=>'polls'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(13924462718486256148)
,p_group_name=>'Request Access'
,p_static_id=>'request-access'
);
wwv_flow_imp.component_end;
end;
/
