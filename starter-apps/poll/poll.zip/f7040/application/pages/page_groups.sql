prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7040
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(14505614119632332137)
,p_group_name=>'ACL'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(16384132317717860420)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(13931958675579353755)
,p_group_name=>'Communities'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(14505613816169331097)
,p_group_name=>'Help'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(14505613917208331440)
,p_group_name=>'Home'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(13930187189765775840)
,p_group_name=>'Invite'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(14505614018593331827)
,p_group_name=>'Login'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(13956717476785604700)
,p_group_name=>'Opt Out'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(13907358366898610207)
,p_group_name=>'Polls'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(13907349878879528503)
,p_group_name=>'Request Access'
);
wwv_flow_imp.component_end;
end;
/
