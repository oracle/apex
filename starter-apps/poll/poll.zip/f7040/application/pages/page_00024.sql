prompt --application/pages/page_00024
begin
--   Manifest
--     PAGE: 00024
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>17112839606727645
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>24
,p_name=>'Details'
,p_alias=>'POLL-DETAILS1'
,p_page_mode=>'MODAL'
,p_step_title=>'Details'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(13924471206505337852)
,p_step_template=>2121795032473542284
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(165977452478131556)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(15667403886086194508)
,p_name=>'Details'
,p_template=>4072358936313175081
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ID,',
'    ROW_KEY,',
'    poll_name || '' - ''|| row_key ||',
'       case when poll_or_quiz = ''Q''',
'            then '' (''||apex_lang.message(''QUIZ_INITCAP'')||'')'' ',
'            end POLL_NAME,',
'    POLL_DETAILS,',
'    STATUS_ID,',
'    status_id poll_status,',
'    p.use_sections_yn,',
'    p.authentication_req_yn,',
'    p.invite_only_yn,',
'    p.ANONYMOUS_YN,',
'    p.can_update_answers_yn,',
'    case when p.score_type in (''C'',''A'') and p.enable_score_yn = ''Y'' then apex_lang.message(''SCORE_''||p.score_type) end score_type,',
'    p.ALL_VIEW_RESULTS_YN,',
'    p.START_TIME,',
'    p.STOP_TIME,',
'    null take_url',
'from EBA_QPOLL_POLLS p',
'where p.id = :POLL_ID'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2100515439059797523
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'no data found'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(643680150484363961)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>14
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(643680272676363962)
,p_query_column_id=>2
,p_column_alias=>'ROW_KEY'
,p_column_display_sequence=>15
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(643680373750363963)
,p_query_column_id=>3
,p_column_alias=>'POLL_NAME'
,p_column_display_sequence=>1
,p_column_heading=>'Poll Name'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(643680519272363964)
,p_query_column_id=>4
,p_column_alias=>'POLL_DETAILS'
,p_column_display_sequence=>3
,p_column_heading=>'Poll Details'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(643680621126363965)
,p_query_column_id=>5
,p_column_alias=>'STATUS_ID'
,p_column_display_sequence=>16
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(643680677972363966)
,p_query_column_id=>6
,p_column_alias=>'POLL_STATUS'
,p_column_display_sequence=>2
,p_column_heading=>'Poll Status'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(230579502674626825)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(720093212493029588)
,p_query_column_id=>7
,p_column_alias=>'USE_SECTIONS_YN'
,p_column_display_sequence=>4
,p_column_heading=>'Use Sections'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_qpoll_polls',
' where id = :POLL_ID',
'   and use_sections_yn = ''Y'''))
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(13935307710622230175)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(720093581654029588)
,p_query_column_id=>8
,p_column_alias=>'AUTHENTICATION_REQ_YN'
,p_column_display_sequence=>5
,p_column_heading=>'Login Required'
,p_heading_alignment=>'LEFT'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(16079746045092670001)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(720093994229029588)
,p_query_column_id=>9
,p_column_alias=>'INVITE_ONLY_YN'
,p_column_display_sequence=>6
,p_column_heading=>'Invite Only'
,p_heading_alignment=>'LEFT'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(13935307710622230175)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(720094430115029589)
,p_query_column_id=>10
,p_column_alias=>'ANONYMOUS_YN'
,p_column_display_sequence=>7
,p_column_heading=>'Anonymize'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_qpoll_polls',
' where id = :POLL_ID',
'   and anonymous_yn = ''Y'''))
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(16079746045092670001)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(720094824638029589)
,p_query_column_id=>11
,p_column_alias=>'CAN_UPDATE_ANSWERS_YN'
,p_column_display_sequence=>8
,p_column_heading=>'Can Update Answers'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_qpoll_polls',
' where id = :POLL_ID',
'   and authentication_req_yn = ''Y'''))
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(16079746045092670001)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(720095238766029589)
,p_query_column_id=>12
,p_column_alias=>'SCORE_TYPE'
,p_column_display_sequence=>10
,p_column_heading=>'Score Type'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 ',
'from EBA_QPOLL_POLLS',
'where id = :POLL_ID',
'  and score_type in (''C'',''A'')',
'  and enable_score_yn = ''Y'''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(720095581829029590)
,p_query_column_id=>13
,p_column_alias=>'ALL_VIEW_RESULTS_YN'
,p_column_display_sequence=>9
,p_column_heading=>'Invitees View Results'
,p_heading_alignment=>'LEFT'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(16079746045092670001)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(720096000595029590)
,p_query_column_id=>14
,p_column_alias=>'START_TIME'
,p_column_display_sequence=>11
,p_column_heading=>'Started'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_qpoll_polls',
' where id = :POLL_ID',
'   and START_TIME is not null',
'   and status_id in (3,4)'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(720096420532029590)
,p_query_column_id=>15
,p_column_alias=>'STOP_TIME'
,p_column_display_sequence=>12
,p_column_heading=>'Ended'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_qpoll_polls',
' where id = :POLL_ID',
'   and status_id = 4',
'   and STOP_TIME is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(720096830894029590)
,p_query_column_id=>16
,p_column_alias=>'TAKE_URL'
,p_column_display_sequence=>13
,p_column_heading=>'Poll URL'
,p_column_html_expression=>'&P24_TAKE_URL.'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from EBA_QPOLL_POLLS p',
'where id = :POLL_ID',
'and status_id in (2,3)'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23638761557253981)
,p_name=>'P24_TAKE_URL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(15667403886086194508)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(23638884330253982)
,p_computation_sequence=>10
,p_computation_item=>'P24_TAKE_URL'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'   select authentication_req_yn',
'     from eba_qpoll_polls',
'    where id = :POLL_ID',
') loop',
'   if c1.authentication_req_yn = ''N'' then ',
'      return ''This poll is not authenticated thus each invitee gets a unique URL'';',
'   else',
'      return :APP_PATH||apex_util.prepare_url(p_url => ''f?p=''||:APP_ID||'':500:0::::LPOLL_ID:''||:POLL_ID,',
'                                               p_checksum_type => ''1'',',
'                                               p_plain_url => TRUE);',
'   end if;',
'end loop;'))
);
wwv_flow_imp.component_end;
end;
/
