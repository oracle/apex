prompt --application/pages/page_00070
begin
--   Manifest
--     PAGE: 00070
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>17112839606727645
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>70
,p_name=>'Add Community / Members'
,p_alias=>'ADD-COMMUNITY-MEMBERS'
,p_page_mode=>'MODAL'
,p_step_title=>'Add Community / Members'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(13949071515186081400)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(165977452478131556)
,p_protection_level=>'C'
,p_help_text=>'<p>Select an "Action" and provide the required data. You may optionally enter (or paste) email addresses in any format. When you copy and paste email addresses from email messages, extraneous text will be filtered out. Existing or duplicate email add'
||'resses will be ignored.  Do NOT Use email mailing lists only include individual people.</p>'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13937709926242334844)
,p_plug_name=>'Provide Respondent Community Details'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noBorder:t-Region--hiddenOverflow:t-Form--labelsAbove'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13937717517303439695)
,p_plug_name=>'Wizard Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_02'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13937718833280472773)
,p_plug_name=>'footer'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13937710515618334852)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(13937718833280472773)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:&LAST_VIEW.:&SESSION.::&DEBUG.:70,71::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13937710805501334852)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(13937718833280472773)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(13937711210400334856)
,p_branch_action=>'f?p=&APP_ID.:71:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(13937710805501334852)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13938412022782544909)
,p_name=>'P70_RESPONDENT_EMAIL_ADDRESSES'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(13937709926242334844)
,p_prompt=>'Email Addresses (paste any text that contains emails)'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>32767
,p_cHeight=>5
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13938470703646869740)
,p_name=>'P70_COMMUNITY_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(13937709926242334844)
,p_prompt=>'"From" Respondent Community'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'COMMUNITY FROM'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select name, id',
'from EBA_QPOLL_RESP_COMMUNITIES',
'where id <> nvl(:P70_COMMUNITY_ID_TO,-1)',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select -'
,p_cHeight=>1
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13938474308785912912)
,p_name=>'P70_COMMUNITY_NAME'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(13937709926242334844)
,p_prompt=>'Community Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_restricted_characters=>'WEB_SAFE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13938506825296816951)
,p_name=>'P70_COMMUNITY_ACTION'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(13937709926242334844)
,p_item_default=>'-2'
,p_prompt=>'Action'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'COMMUNITY ACTIONS'
,p_lov=>'.'||wwv_flow_imp.id(13938487316221705467)||'.'
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13938512309276900292)
,p_name=>'P70_COMMUNITY_ID_TO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(13937709926242334844)
,p_prompt=>'"To" Community'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'COMMUNITY TO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select name, id',
'from EBA_QPOLL_RESP_COMMUNITIES',
'where id <> nvl(:P70_COMMUNITY_ID,-1)',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select -'
,p_cHeight=>1
,p_read_only_when=>'(:P70_COMMUNITY_ACTION = ''-3'' and :P70_COMMUNITY_ID_TO is not null) or :P70_COMMUNITY_ID_TO is not null'
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13942264828243295070)
,p_name=>'P70_RESPONDENT_ID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(13937709926242334844)
,p_prompt=>'Existing Member'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'P70 AVAILABLE RESPONDENTS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(name,email) || '' ('' || lower(email) || '')'' d, id r',
'from   EBA_QPOLL_RESPONDENTS',
'where id not in (select respondent_id from EBA_QPOLL_RESP_COMM_REF where community_id = :P70_COMMUNITY_ID_TO)',
'order by lower(nvl(name,email))'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select -'
,p_cHeight=>1
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(13938867928233711991)
,p_validation_name=>'P70_COMMUNITY_ID Not Null'
,p_validation_sequence=>10
,p_validation=>'P70_COMMUNITY_ID'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have some value.'
,p_validation_condition=>'P70_COMMUNITY_ACTION'
,p_validation_condition2=>'-1:0'
,p_validation_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_when_button_pressed=>wwv_flow_imp.id(13937710805501334852)
,p_associated_item=>wwv_flow_imp.id(13938470703646869740)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(13938868111628719740)
,p_validation_name=>'P70_COMMUNITY_ID_TO Not Null'
,p_validation_sequence=>20
,p_validation=>'P70_COMMUNITY_ID_TO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have some value.'
,p_validation_condition=>'P70_COMMUNITY_ACTION'
,p_validation_condition2=>'-1:-3:-4'
,p_validation_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_when_button_pressed=>wwv_flow_imp.id(13937710805501334852)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(13938868328005727281)
,p_validation_name=>'P70_COMMUNITY_NAME Not Null'
,p_validation_sequence=>30
,p_validation=>'P70_COMMUNITY_NAME'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have some value.'
,p_validation_condition=>'P70_COMMUNITY_ACTION'
,p_validation_condition2=>'-2:0'
,p_validation_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_when_button_pressed=>wwv_flow_imp.id(13937710805501334852)
,p_associated_item=>wwv_flow_imp.id(13938474308785912912)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(13942287304671445541)
,p_validation_name=>'P70_RESPONDENT_EMAIL_ADDRESSES Not Null'
,p_validation_sequence=>40
,p_validation=>'P70_RESPONDENT_EMAIL_ADDRESSES'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have some value.'
,p_validation_condition=>'P70_COMMUNITY_ACTION'
,p_validation_condition2=>'-4:-5'
,p_validation_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_when_button_pressed=>wwv_flow_imp.id(13937710805501334852)
,p_associated_item=>wwv_flow_imp.id(13938412022782544909)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(13942288620316559853)
,p_validation_name=>'P70_RESPONDENT_ID Not Null'
,p_validation_sequence=>50
,p_validation=>'P70_RESPONDENT_ID'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have some value.'
,p_validation_condition=>'P70_COMMUNITY_ACTION'
,p_validation_condition2=>'-3'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(13937710805501334852)
,p_associated_item=>wwv_flow_imp.id(13942264828243295070)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(13942530109445170228)
,p_name=>'Clear Errors'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P70_COMMUNITY_ACTION'
,p_condition_element=>'P70_COMMUNITY_ACTION'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942530427825170230)
,p_event_id=>wwv_flow_imp.id(13942530109445170228)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''span.uLabelError'').hide();',
'$(''section#uNotificationMessage'').hide();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(13938474434090925217)
,p_name=>'Show/Hide Community Name'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P70_COMMUNITY_ACTION'
,p_condition_element=>'P70_COMMUNITY_ACTION'
,p_triggering_condition_type=>'IN_LIST'
,p_triggering_expression=>'-2,0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942305125003423801)
,p_event_id=>wwv_flow_imp.id(13938474434090925217)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P70_COMMUNITY_ACTION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942305312710429459)
,p_event_id=>wwv_flow_imp.id(13938474434090925217)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P70_COMMUNITY_ACTION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13938474709262925222)
,p_event_id=>wwv_flow_imp.id(13938474434090925217)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P70_COMMUNITY_NAME'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13938474910367925223)
,p_event_id=>wwv_flow_imp.id(13938474434090925217)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P70_COMMUNITY_NAME'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(13938508129137841659)
,p_name=>'Show/Hide Community ID'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P70_COMMUNITY_ACTION'
,p_condition_element=>'P70_COMMUNITY_ACTION'
,p_triggering_condition_type=>'IN_LIST'
,p_triggering_expression=>'-1,0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942305505593432733)
,p_event_id=>wwv_flow_imp.id(13938508129137841659)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P70_COMMUNITY_ACTION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942305732970435250)
,p_event_id=>wwv_flow_imp.id(13938508129137841659)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P70_COMMUNITY_ACTION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13938508430257841661)
,p_event_id=>wwv_flow_imp.id(13938508129137841659)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P70_COMMUNITY_ID'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13938508629889841662)
,p_event_id=>wwv_flow_imp.id(13938508129137841659)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P70_COMMUNITY_ID'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(13938512429708907992)
,p_name=>'Show/Hide Community ID To'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P70_COMMUNITY_ACTION'
,p_condition_element=>'P70_COMMUNITY_ACTION'
,p_triggering_condition_type=>'IN_LIST'
,p_triggering_expression=>'-1,-3,-4'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942305927794437702)
,p_event_id=>wwv_flow_imp.id(13938512429708907992)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P70_COMMUNITY_ACTION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942306123049439888)
,p_event_id=>wwv_flow_imp.id(13938512429708907992)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P70_COMMUNITY_ACTION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13938512715730907992)
,p_event_id=>wwv_flow_imp.id(13938512429708907992)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P70_COMMUNITY_ID_TO'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13938512930617907992)
,p_event_id=>wwv_flow_imp.id(13938512429708907992)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P70_COMMUNITY_ID_TO'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(13942265015557307318)
,p_name=>'Show/Hide Respondent'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P70_COMMUNITY_ACTION'
,p_condition_element=>'P70_COMMUNITY_ACTION'
,p_triggering_condition_type=>'IN_LIST'
,p_triggering_expression=>'-3'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942307404071448710)
,p_event_id=>wwv_flow_imp.id(13942265015557307318)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P70_COMMUNITY_ACTION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942307631664451061)
,p_event_id=>wwv_flow_imp.id(13942265015557307318)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P70_COMMUNITY_ACTION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942265326145307319)
,p_event_id=>wwv_flow_imp.id(13942265015557307318)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P70_RESPONDENT_ID'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942265516661307319)
,p_event_id=>wwv_flow_imp.id(13942265015557307318)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P70_RESPONDENT_ID'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(13942287617820471801)
,p_name=>'Change Emails textarea label to required for add new respondents'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P70_COMMUNITY_ACTION'
,p_condition_element=>'P70_COMMUNITY_ACTION'
,p_triggering_condition_type=>'IN_LIST'
,p_triggering_expression=>'-4,-5'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942307825409453951)
,p_event_id=>wwv_flow_imp.id(13942287617820471801)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P70_COMMUNITY_ACTION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942308020665456158)
,p_event_id=>wwv_flow_imp.id(13942287617820471801)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P70_COMMUNITY_ACTION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942288114229471802)
,p_event_id=>wwv_flow_imp.id(13942287617820471801)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''label[for="P70_RESPONDENT_EMAIL_ADDRESSES"]'').removeClass(''uRequired'');',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942308227769468082)
,p_event_id=>wwv_flow_imp.id(13942287617820471801)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P70_RESPONDENT_EMAIL_ADDRESSES'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942287916153471802)
,p_event_id=>wwv_flow_imp.id(13942287617820471801)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''label[for="P70_RESPONDENT_EMAIL_ADDRESSES"] img.uAsterisk'').remove();',
'$(''label[for="P70_RESPONDENT_EMAIL_ADDRESSES"]'').removeClass(''uOptional'');',
'$(''label[for="P70_RESPONDENT_EMAIL_ADDRESSES"]'').addClass(''uRequired'');',
'$(''label[for="P70_RESPONDENT_EMAIL_ADDRESSES"]'').append(''<img class="uAsterisk" alt="Value Required" src="#IMAGE_PREFIX#f_spacer.gif">'');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(13942263627930254119)
,p_name=>'Show/Hide RESPONDENT_EMAIL_ADDRESSES'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P70_COMMUNITY_ACTION'
,p_condition_element=>'P70_COMMUNITY_ACTION'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'-3'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942306317442442442)
,p_event_id=>wwv_flow_imp.id(13942263627930254119)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P70_COMMUNITY_ACTION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942306513129444454)
,p_event_id=>wwv_flow_imp.id(13942263627930254119)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P70_COMMUNITY_ACTION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942264106603254124)
,p_event_id=>wwv_flow_imp.id(13942263627930254119)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''html body form#wwvFlowForm div#uBodyContainer div#uOneCol div.cWizard div.cWizardContentContainer div.cWizardContent div table.formlayout tbody tr td label[for="P70_RESPONDENT_EMAIL_ADDRESSES"]'').parent().show();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942298811472095768)
,p_event_id=>wwv_flow_imp.id(13942263627930254119)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''html body form#wwvFlowForm div#uBodyContainer div#uOneCol div.cWizard div.cWizardContentContainer div.cWizardContent div table.formlayout tbody tr td label[for="P70_RESPONDENT_EMAIL_ADDRESSES"]'').parent().hide();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9492221561179536605)
,p_event_id=>wwv_flow_imp.id(13942263627930254119)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P70_RESPONDENT_EMAIL_ADDRESSES'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9492221914592539374)
,p_event_id=>wwv_flow_imp.id(13942263627930254119)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P70_RESPONDENT_EMAIL_ADDRESSES'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(14008368520779052587)
,p_name=>'Set From Community id'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P70_COMMUNITY_ID'
,p_condition_element=>'P70_COMMUNITY_ID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14008368803772052588)
,p_event_id=>wwv_flow_imp.id(14008368520779052587)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P70_COMMUNITY_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14008370409459075256)
,p_event_id=>wwv_flow_imp.id(14008368520779052587)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P70_COMMUNITY_ID_TO'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13938416533343702820)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create Collections for copy communities'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_line      varchar2(32767);',
'    l_emails    wwv_flow_global.vc_arr2;',
'    l_email     varchar2(4000);',
'    l_at        number;',
'    l_dot       number;',
'    l_valid     boolean := true;',
'    l_domain    varchar2(4000);',
'begin',
'    ---------------------',
'    -- create collections',
'    --',
'    apex_collection.CREATE_OR_TRUNCATE_COLLECTION (''EBA_QPOLL_RESPONDENT_INVALID'');',
'    apex_collection.CREATE_OR_TRUNCATE_COLLECTION (''EBA_QPOLL_RESPONDENT_VALID'');',
'    apex_collection.CREATE_OR_TRUNCATE_COLLECTION (''EBA_QPOLL_RESPONDENT_CREATE'');',
'',
'    --------------------------------------------',
'    -- replace delimiting characters with commas',
'    --',
'    l_line := :P70_RESPONDENT_EMAIL_ADDRESSES;',
'    l_line := replace(l_line,chr(10),'' '');',
'    l_line := replace(l_line,chr(13),'' '');',
'    l_line := replace(l_line,chr(9),'' '');',
'    l_line := replace(l_line,''<'','' '');',
'    l_line := replace(l_line,''>'','' '');',
'    l_line := replace(l_line,'';'','' '');',
'    l_line := replace(l_line,'':'','' '');',
'    l_line := replace(l_line,''('','' '');',
'    l_line := replace(l_line,'')'','' '');',
'    l_line := replace(l_line,'' '','','');',
'',
'    -----------------------------------------',
'    -- get one comma separated line of emails',
'    --',
'    for j in 1..1000 loop',
'        if instr(l_line,'',,'') > 0 then',
'           l_line := replace(l_line,'',,'','','');',
'        else',
'           exit;',
'        end if;',
'    end loop;',
'',
'    -------------------------',
'    -- get an array of emails',
'    --',
'    l_emails := wwv_flow_utilities.string_to_table(l_line,'','');',
'',
'    -----------------------------',
'    -- add emails to a collection',
'    --',
'    l_email := null;',
'    l_domain := null;',
'    l_at := 0;',
'    l_dot := 0;',
'    for j in 1..l_emails.count loop',
'        l_valid := true;',
'        l_email := trim(l_emails(j));',
'        l_email := replace(l_email,chr(49824),null);',
'',
'        if l_email is not null then',
'            -----------',
'            -- Validate',
'            --',
'            l_at := instr(nvl(l_email,''x''),''@'');',
'            l_domain := substr(l_email,l_at+1);',
'            l_dot := instr(l_domain,''.'');',
'            if l_at < 2 then',
'                -- invalid email',
'                apex_collection.add_member(',
'                    p_collection_name => ''EBA_QPOLL_RESPONDENT_INVALID'',',
'                    p_c001            => l_email,',
'                    p_c002            => apex_lang.message(''MISSING_AT_SIGN''));',
'                commit;',
'                l_valid := false;',
'            end if;',
'',
'            if l_dot = 0 and l_valid then',
'                apex_collection.add_member(',
'                    p_collection_name => ''EBA_QPOLL_RESPONDENT_INVALID'',',
'                    p_c001            => l_email,',
'                    p_c002            => apex_lang.message(''MISSING_DOT''));',
'                commit;',
'                l_valid := false;',
'            end if;',
'',
'',
'            l_email := trim(l_email);',
'            l_email := trim(both ''.'' from l_email);',
'            l_email := replace(l_email,'' '',null);',
'            l_email := replace(l_email,chr(10),null);',
'            l_email := replace(l_email,chr(9),null);',
'            l_email := replace(l_email,chr(13),null);',
'            l_email := replace(l_email,chr(49824),null);',
'',
'            if l_valid and length(l_email) > 255 then',
'                apex_collection.add_member(',
'                    p_collection_name => ''EBA_QPOLL_RESPONDENT_INVALID'',',
'                    p_c001            => upper(l_email),',
'                    p_c002            => apex_lang.message(''EMAIL_TOO_LONG''));',
'                commit;',
'                l_valid := false;',
'            end if;',
'',
'            if l_valid then',
'                for c1 in (select /* APEX76a66f */ r.email',
'                             from eba_qpoll_respondents r,',
'                                  eba_qpoll_resp_comm_ref j',
'                            where upper(r.email) = upper(l_email)',
'                              and r.id = j.respondent_id',
'                              and j.community_id = :P70_COMMUNITY_ID_TO)',
'                loop',
'                    wwv_flow_collection.add_member(',
'                        p_collection_name => ''EBA_QPOLL_RESPONDENT_INVALID'',',
'                        p_c001            => upper(l_email),',
'                        p_c002            => apex_lang.message(''ALREADY_IN_COMMUNITY''));',
'                    commit;',
'                    l_valid := false;',
'                    exit;',
'                end loop;',
'            end if;',
'',
'            if l_valid then',
'                for c1 in (select /* APEXeaf772 */  c001',
'                             from wwv_flow_collections',
'                            where collection_name = ''EBA_QPOLL_RESPONDENT_VALID''',
'                              and c001 = upper(l_email))',
'                loop',
'                    apex_collection.add_member(',
'                        p_collection_name => ''EBA_QPOLL_RESPONDENT_INVALID'',',
'                        p_c001            => upper(l_email),',
'                        p_c002            => apex_lang.message(''DUPLICATE_EMAIL''));',
'                        commit;',
'                    l_valid := false;',
'                    exit;',
'                end loop;',
'            end if;',
'',
'            if l_valid then',
'                apex_collection.add_member(',
'                    p_collection_name => ''EBA_QPOLL_RESPONDENT_VALID'',',
'                    p_c001            => upper(l_email));',
'                    commit;',
'            end if;',
'',
'        end if;',
'        l_email := null;',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'#SQLERRM#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(13937710805501334852)
,p_process_when=>'P70_COMMUNITY_ACTION'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_process_when2=>'-3'
,p_internal_uid=>13921303693736975175
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13942267231861539089)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create Collections for adding respondent'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_valid     boolean := true;',
'    l_email     varchar2(1000);',
'    l_domain    varchar2(4000);',
'begin',
'    ---------------------',
'    -- create collections',
'    --',
'    apex_collection.CREATE_OR_TRUNCATE_COLLECTION (''EBA_QPOLL_RESPONDENT_INVALID'');',
'    apex_collection.CREATE_OR_TRUNCATE_COLLECTION (''EBA_QPOLL_RESPONDENT_VALID'');',
'    apex_collection.CREATE_OR_TRUNCATE_COLLECTION (''EBA_QPOLL_RESPONDENT_CREATE'');',
' ',
'    for c1 in (select /* APEX76a66f */ r.email',
'                 from EBA_QPOLL_RESP_COMM_REF ref,',
'                      EBA_QPOLL_RESPONDENTS r',
'                where ref.respondent_id = :P70_RESPONDENT_ID',
'                  and r.id = ref.respondent_id',
'                  and ref.community_id = :P70_COMMUNITY_ID_TO)',
'    loop',
'        l_email := c1.email;',
'        wwv_flow_collection.add_member(',
'            p_collection_name => ''EBA_QPOLL_RESPONDENT_INVALID'',',
'            p_c001            => upper(l_email),',
'            p_c002            => apex_lang.message(''ALREADY_IN_COMMUNITY''));',
'        commit;',
'        l_valid := false;',
'        exit;',
'    end loop;',
'',
'    select /* APEX76a66f */ r.email',
'      into l_email',
'      from EBA_QPOLL_RESPONDENTS r',
'     where r.id = :P70_RESPONDENT_ID;',
'',
'    l_email := replace(l_email,chr(49824),null);',
'',
'    if l_email is not null then',
'        l_valid := true;',
'    end if;',
'',
'    if l_valid then',
'        for c1 in (select /* APEXeaf772 */  c001',
'                     from wwv_flow_collections',
'                    where collection_name = ''EBA_QPOLL_RESPONDENT_VALID''',
'                      and c001 = upper(l_email))',
'        loop',
'            apex_collection.add_member(',
'                p_collection_name => ''EBA_QPOLL_RESPONDENT_INVALID'',',
'                p_c001            => upper(l_email),',
'                p_c002            => apex_lang.message(''DUPLICATE_EMAIL''));',
'                commit;',
'            l_valid := false;',
'            exit;',
'        end loop;',
'    end if;',
'',
'    if l_valid then',
'        apex_collection.add_member(',
'            p_collection_name => ''EBA_QPOLL_RESPONDENT_VALID'',',
'            p_c001            => upper(l_email));',
'            commit;',
'    end if;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'#SQLERRM#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(13937710805501334852)
,p_process_when=>'P70_COMMUNITY_ACTION'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'-3'
,p_internal_uid=>13925154392254811444
);
wwv_flow_imp.component_end;
end;
/
