prompt --application/pages/page_00036
begin
--   Manifest
--     PAGE: 00036
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>36
,p_name=>'Manual Invitations Recorded'
,p_alias=>'MANUAL-INVITATIONS-RECORDED'
,p_page_mode=>'MODAL'
,p_step_title=>'Manual Invitations Recorded'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(13924471206505337852)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'section.uSuccessRegion p.desc {',
'font-size: 14px;',
'line-height: 1.5;',
'font-weight: normal;',
'margin-bottom: 16px;',
'color: #404040;',
'text-align: left;',
'}'))
,p_step_template=>2101883943284197310
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(165977452478131556)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14014016617023667950)
,p_plug_name=>'buttons'
,p_static_id=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2127905476394690047
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(14014047413442734472)
,p_name=>'Community Invitations'
,p_static_id=>'community-invitations'
,p_parent_plug_id=>wwv_flow_imp.id(14014016234441667921)
,p_template=>4502917002193490937
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_display_point=>'SUB_REGIONS'
,p_item_display_point=>'BELOW'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select decode(email_sent,''YES'',''Emails Sent'',',
'                         ''OPTED_OUT'',''Opted Out'',',
'                         ''PREVIOUSLY_SENT'',''Previously Sent'',',
'                         ''MANUAL_INVITE'',''Manual Invites'',',
'                         email_sent) email_sent, count(*) cnt',
'  from eba_qpoll_invites',
' where comm_invite_id = :P72_COMM_INVITE_ID',
'    or comm_invite_id = :P72_COMM_INVITE_ID2',
'group by email_sent'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_invites',
' where comm_invite_id = :P72_COMM_INVITE_ID',
'    or comm_invite_id = :P72_COMM_INVITE_ID2'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'No community invites found.'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14014047726568734475)
,p_query_column_id=>2
,p_column_alias=>'CNT'
,p_column_display_sequence=>1
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14014047613972734474)
,p_query_column_id=>1
,p_column_alias=>'EMAIL_SENT'
,p_column_display_sequence=>2
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14014016234441667921)
,p_plug_name=>'Invitations Recorded'
,p_static_id=>'invitations-recorded'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_3'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p class="desc">The number of manual invitations recorded is below.  You can invite more or view the links to pass onto the users.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(250084887194050559)
,p_plug_name=>'Other'
,p_static_id=>'other'
,p_parent_plug_id=>wwv_flow_imp.id(14014016234441667921)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14014047122722730617)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(14014016617023667950)
,p_button_name=>'INVITE_MORE'
,p_static_id=>'invite-more'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Invite More'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:72:&SESSION.::&DEBUG.:72:P72_POLL_ID,P72_INVITE_METHOD:&P72_POLL_ID.,&P72_INVITE_METHOD.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from EBA_QPOLL_RESP_COMMUNITIES',
'where id not in',
'      (select community_id',
'         from eba_qpoll_comm_invites',
'        where poll_id = :P72_POLL_ID)'))
,p_button_condition_type=>'EXISTS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14014049306751753144)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(14014016617023667950)
,p_button_name=>'VIEW_LINKS'
,p_static_id=>'view-links'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'View Invitations'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:CIR,RIR:IR_POLL_ID,IRC_COMM_INVITE_ID:&P72_POLL_ID.,&P72_COMM_INVITE_ID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14019550134274025241)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(14014016617023667950)
,p_button_name=>'VIEW_POLL'
,p_static_id=>'view-poll'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Manage Poll'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:100:LPOLL_ID:&P72_POLL_ID.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14050743826436349346)
,p_name=>'P36_OTHER_INVITEES_MSG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(250084887194050559)
,p_use_cache_before_default=>'NO'
,p_source=>'P72_OTHER_INVITEES_MSG'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>2042262243893469891
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML',
  'send_on_page_submit', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
