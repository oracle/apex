prompt --application/pages/page_00019
begin
--   Manifest
--     PAGE: 00019
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>19
,p_name=>'Create Poll'
,p_alias=>'CREATE-POLL'
,p_page_mode=>'MODAL'
,p_step_title=>'Create Poll'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(13907358366898610207)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(148864612871403911)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(254634783162408948)
,p_plug_name=>'Poll Name'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14588562352722420217)
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'BELOW'
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P19_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4534122362571855862)
,p_plug_name=>'Advanced'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(14588571552078420238)
,p_plug_display_sequence=>60
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4534124706303855885)
,p_plug_name=>'Note'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14588562352722420217)
,p_plug_display_sequence=>70
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p><a href="f?p=&APP_ID.:76:&APP_SESSION.:::76">Create a Poll as a copy of an existing poll</a></p>'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from eba_qpoll_polls'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4534124736029855886)
,p_plug_name=>'buttons'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI:margin-bottom-none'
,p_plug_template=>wwv_flow_imp.id(14588562520626420219)
,p_plug_display_sequence=>100
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7528523330760814908)
,p_plug_name=>'Customize Display'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(14588571552078420238)
,p_plug_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14505379634542691605)
,p_plug_name=>'Details'
,p_region_css_classes=>'infoTextRegion'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--noBorder:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14588571552078420238)
,p_plug_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7528505423819783622)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4534124736029855886)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(14588591799596420304)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:&LAST_VIEW.:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4534122268013855861)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(4534124736029855886)
,p_button_name=>'create'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(14588591799596420304)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Poll'
,p_button_position=>'CREATE'
,p_button_condition=>'P19_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(7528511975534783632)
,p_branch_action=>'f?p=&APP_ID.:100:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7528491992797783597)
,p_name=>'P19_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(14505379634542691605)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7528493967522783604)
,p_name=>'P19_POLL_NAME'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(254634783162408948)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Poll Name'
,p_source=>'POLL_NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(14588591118357420296)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_help_text=>'The poll name will display in the email invitations as well as within this application.  Please use a descriptive name.'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7528494857957783605)
,p_name=>'P19_STATUS_ID'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(14505379634542691605)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1'
,p_source=>'STATUS_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_help_text=>'Select <strong>Published</strong> if you wish to make this poll available to be taken (by the general user community or by those you have invited).  If you select <strong>Testing</strong>, the poll can be tested by users who are contributors.  Use th'
||'is to ensure your poll is set up correctly.  Once you are done testing and are ready to publish, you can easily remove your testing responses.'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7528495818010783607)
,p_name=>'P19_POLL_DETAILS'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(14505379634542691605)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Description'
,p_source=>'POLL_DETAILS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>2
,p_field_template=>wwv_flow_imp.id(14588590882381420294)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'This is only displayed to Contributors when managing the poll - not displayed to users when taking a poll.'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7528496662491783608)
,p_name=>'P19_AUTHENTICATION_REQ_YN'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(14505379634542691605)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Require Login'
,p_source=>'AUTHENTICATION_REQ_YN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(14588590882381420294)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'If you select <strong>Yes</strong> for login required, all invitees will be required to login to take the poll.  If you choose <strong>No</strong> for login required, then your users will only require access to the server to take the poll.'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7528497565160783609)
,p_name=>'P19_INVITE_ONLY_YN'
,p_is_required=>true
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(14505379634542691605)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Invite Only'
,p_source=>'INVITE_ONLY_YN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(14588590882381420294)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Selecting invite only <strong>Yes</strong> will restrict the list of people who can take your poll to those who have been invited.'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7528498465131783609)
,p_name=>'P19_ANONYMOUS_YN'
,p_is_required=>true
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(14505379634542691605)
,p_use_cache_before_default=>'NO'
,p_item_default=>'N'
,p_prompt=>'Anonymize Results'
,p_source=>'ANONYMOUS_YN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(14588590882381420294)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'If set to Yes, the name of the respondent will not be displayed when viewing results (e.g. who selected which answer).  If you choose <strong>No</strong>, each response will be labeled with the respondent.'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7528499377612783610)
,p_name=>'P19_ANON_NO_CHANGE'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(14505379634542691605)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Note'
,p_source=>'When a Poll is set to Anonymize Results and there are already responses, you cannot change the setting.'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(14588590882381420294)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7528499745793783610)
,p_name=>'P19_CAN_UPDATE_ANSWERS_YN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4534122362571855862)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Can Update Answers'
,p_source=>'CAN_UPDATE_ANSWERS_YN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(14588590882381420294)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'If you allow update, a respondent can access the poll again and update their answers.  '
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7528500660306783611)
,p_name=>'P19_ALL_VIEW_RESULTS_YN'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(4534122362571855862)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Invitees Can View Results'
,p_source=>'ALL_VIEW_RESULTS_YN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(14588590882381420294)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Poll results are always viewable by Readers, Contributors and Administrators of this application. Click this to allow those invited to take this poll to view the results, whether or not they have Reader or greater access. If Yes, there will the optio'
||'n to include a "View Results" link in all email invitations and a "View Results" button will be displayed on the thank you page after completing the poll.'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7528501633023783611)
,p_name=>'P19_ENABLE_SCORE_YN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(4534122362571855862)
,p_use_cache_before_default=>'NO'
,p_item_default=>'N'
,p_prompt=>'Scoring Enabled'
,p_source=>'ENABLE_SCORE_YN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(14588590882381420294)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'If scoring is enabled, the score of each response will be displayed in the results.'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7528502494581783612)
,p_name=>'P19_INTRO_TEXT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(7528523330760814908)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Introduction Text'
,p_source=>'INTRO_TEXT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>3
,p_field_template=>wwv_flow_imp.id(14588590882381420294)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Introduction text, if provided, is displayed on the main poll page.  Use this to explain the poll, if necessary.'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7528503417051783612)
,p_name=>'P19_THANK_YOU_TEXT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(7528523330760814908)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Thank You Text'
,p_source=>'THANK_YOU_TEXT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cMaxlength=>4000
,p_cHeight=>3
,p_field_template=>wwv_flow_imp.id(14588590882381420294)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Thank you text, if provided, is shown on the page the user is navigated to after they submit their response.  It does not need to thank them for submitting - the page already contains "Thank you for submitting your poll".'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7528513678370790564)
,p_name=>'P19_POLL_OR_QUIZ'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(14505379634542691605)
,p_use_cache_before_default=>'NO'
,p_item_default=>'P'
,p_prompt=>'Type'
,p_source=>'POLL_OR_QUIZ'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'POLL OR QUIZ'
,p_lov=>'.'||wwv_flow_imp.id(322967159767603563)||'.'
,p_field_template=>wwv_flow_imp.id(14588590882381420294)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_help_text=>'Identify if the question set represents a poll or a quiz.  A poll can have scoring enabled to allow you to assign 0-10 to each answer and evaluate the responses based on either the average or cumulative score.  With a quiz, you identify the correct a'
||'nswer(s) and a grade is then assigned to each response.'
,p_inline_help_text=>'Choose the <strong>Poll</strong> type if there is no correct answer. Choose type <strong>Quiz</strong> if questions have correct answers.'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7528514549081790565)
,p_name=>'P19_USE_SECTIONS_YN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(7528523330760814908)
,p_use_cache_before_default=>'NO'
,p_item_default=>'N'
,p_prompt=>'Use Sections'
,p_source=>'USE_SECTIONS_YN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(14588590882381420294)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'If set to Yes, you will be able to define sections and then assign questions to those sections.  If set to No, even if sections are defined, they will not be displayed within the poll.'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7528515486999790566)
,p_name=>'P19_SCORE_TYPE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(4534122362571855862)
,p_use_cache_before_default=>'NO'
,p_item_default=>'N'
,p_prompt=>'Poll Score Type'
,p_source=>'SCORE_TYPE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'QSET_SCORE_TYPE'
,p_lov=>'.'||wwv_flow_imp.id(13931108289557842162)||'.'
,p_field_template=>wwv_flow_imp.id(14588590882381420294)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_help_text=>'Polls may be scored, meaning that answers to questions can be given a weighting of 0 to 10.  Scoring answers allows a poll, designed to be scored, the ability to distill poll results into a single numeric value.  Use scoring if you are asking satisfa'
||'ction type questions.  Textual responses can not be scored.'
,p_inline_help_text=>'Polls can be scored, this allows answers to be assigned a numeric value allowing you to sum or average responses over all answers.'
,p_attribute_01=>'3'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7528516432617790567)
,p_name=>'P19_IMAGE_BLOB'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(7528523330760814908)
,p_use_cache_before_default=>'NO'
,p_item_default=>'IMAGE_BLOB'
,p_prompt=>'Image'
,p_source=>'IMAGE_BLOB'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>60
,p_field_template=>wwv_flow_imp.id(14588590882381420294)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'If you include an image, it will be displayed at the top of any poll created from this question set.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'DB_COLUMN'
,p_attribute_02=>'IMAGE_MIMETYPE'
,p_attribute_03=>'IMAGE_FILENAME'
,p_attribute_04=>'IMAGE_CHARSET'
,p_attribute_05=>'IMAGE_LAST_UPDATED'
,p_attribute_06=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7528517252032790568)
,p_name=>'P19_IMAGE_HEIGHT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(7528523330760814908)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Image Height'
,p_source=>'IMAGE_HEIGHT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>5
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(14588590882381420294)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7528517714552790568)
,p_name=>'P19_IMAGE_WIDTH'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(7528523330760814908)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Width'
,p_source=>'IMAGE_WIDTH'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>5
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(14588590882381420294)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(7528519470177792702)
,p_computation_sequence=>20
,p_computation_item=>'P19_SCORE_TYPE'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'N'
,p_compute_when=>'P19_POLL_OR_QUIZ'
,p_compute_when_text=>'Q'
,p_compute_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(4534122679119855865)
,p_computation_sequence=>30
,p_computation_item=>'P19_ENABLE_SCORE_YN'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'N'
,p_compute_when=>'P19_ENABLE_SCORE_YN'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7528507671655783629)
,p_name=>'When not authenticated, invite only'
,p_event_sequence=>2
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_AUTHENTICATION_REQ_YN'
,p_condition_element=>'P19_AUTHENTICATION_REQ_YN'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'N'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7528508151125783630)
,p_event_id=>wwv_flow_imp.id(7528507671655783629)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_INVITE_ONLY_YN'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7528508717757783630)
,p_event_id=>wwv_flow_imp.id(7528507671655783629)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_INVITE_ONLY_YN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7528509169360783631)
,p_event_id=>wwv_flow_imp.id(7528507671655783629)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_INVITE_ONLY_YN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7528509563990783631)
,p_name=>'hide P19_ANON_NO_CHANGE'
,p_event_sequence=>15
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7528510083455783631)
,p_event_id=>wwv_flow_imp.id(7528509563990783631)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_ANON_NO_CHANGE'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7528510491006783631)
,p_name=>'when anon and results, cannot change'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'EXISTS'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_qpoll_results',
' where poll_id = :POLL_ID',
'   and :P19_ANONYMOUS_YN = ''Y'''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7528511016947783632)
,p_event_id=>wwv_flow_imp.id(7528510491006783631)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_ANONYMOUS_YN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7528511528315783632)
,p_event_id=>wwv_flow_imp.id(7528510491006783631)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_ANON_NO_CHANGE'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7528523338756814909)
,p_name=>'when quiz, no poll score type'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_POLL_OR_QUIZ'
,p_condition_element=>'P19_POLL_OR_QUIZ'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Q'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(228036330142958847)
,p_event_id=>wwv_flow_imp.id(7528523338756814909)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_SCORE_TYPE,P19_ENABLE_SCORE_YN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7528523543674814911)
,p_event_id=>wwv_flow_imp.id(7528523338756814909)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_SCORE_TYPE'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7528524022642814915)
,p_event_id=>wwv_flow_imp.id(7528523338756814909)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_SCORE_TYPE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(228036412545958848)
,p_event_id=>wwv_flow_imp.id(7528523338756814909)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_ENABLE_SCORE_YN'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7528523713414814912)
,p_name=>'when score type, display enable score'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P19_SCORE_TYPE'
,p_condition_element=>'P19_SCORE_TYPE'
,p_triggering_condition_type=>'IN_LIST'
,p_triggering_expression=>'A,C'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7528523815509814913)
,p_event_id=>wwv_flow_imp.id(7528523713414814912)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_ENABLE_SCORE_YN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7528523838895814914)
,p_event_id=>wwv_flow_imp.id(7528523713414814912)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_ENABLE_SCORE_YN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7528524048694814916)
,p_event_id=>wwv_flow_imp.id(7528523713414814912)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_ENABLE_SCORE_YN'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(232971068679322904)
,p_name=>'hide enable_scoring (for default view)'
,p_event_sequence=>50
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(232971183580322905)
,p_event_id=>wwv_flow_imp.id(232971068679322904)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P19_ENABLE_SCORE_YN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(4534122539282855864)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'dml'
,p_attribute_02=>'EBA_QPOLL_POLLS'
,p_attribute_03=>'P19_ID'
,p_attribute_04=>'ID'
,p_attribute_09=>'LPOLL_ID'
,p_attribute_11=>'I'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>4534122539282855864
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7528506909634783628)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>7528506909634783628
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7528507324188783628)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set values of disabled items'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P19_AUTHENTICATION_REQ_YN = ''N'' then',
'   :P19_INVITE_ONLY_YN := ''Y'';',
'end if;',
'',
'-- if was anonymous and there is one result, can''t change',
'for c1 in (',
'   select p.anonymous_yn',
'     from eba_qpoll_polls p,',
'          eba_qpoll_results r',
'    where p.id = :POLL_ID',
'      and p.id = r.poll_id',
') loop',
'   if c1.anonymous_yn = ''Y'' then',
'      :P19_ANONYMOUS_YN := ''Y'';',
'   end if;',
'   exit;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>7528507324188783628
);
wwv_flow_imp.component_end;
end;
/
