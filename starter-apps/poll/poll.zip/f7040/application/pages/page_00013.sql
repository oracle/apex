prompt --application/pages/page_00013
begin
--   Manifest
--     PAGE: 00013
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>13
,p_name=>'Invitation Details'
,p_alias=>'INVITATION-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Invitation Details'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(13924471206505337852)
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_required_role=>wwv_flow_imp.id(165977452478131556)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14047541724484379981)
,p_plug_name=>'Invitation Details'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_region_attributes=>'style="width: 1000px;"'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(437593631108961283)
,p_plug_name=>'Email Body'
,p_parent_plug_id=>wwv_flow_imp.id(14047541724484379981)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>75
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_poll_url   varchar2(4000);',
'   l_body       clob;',
'   l_subject    varchar2(4000);',
'   l_html_body  clob;',
'   l_text_body  clob;',
'begin',
'',
'l_poll_url := ''<a href="#">''||apex_escape.html(:POLL_NAME)||''</a>'';',
'                                                     ',
'l_body := replace(:P72_INVITE_BODY,''#POLL_LINK#'',l_poll_url);',
'   ',
'for c1 in (',
'    select',
'        sent_time,',
'        subject,',
'        apex_escape.html(text_body) message',
'    from',
'        eba_qpoll_emails',
'    where',
'        id = :P13_EMAIL_ID',
'    and',
'        poll_id = :P13_POLL_ID',
') loop',
'',
'   apex_mail.prepare_template (',
'      p_static_id       => ''INVITE'',',
'      p_placeholders    => ''{'' || ',
'                           ''    "SUBJECT":''           || apex_json.stringify( c1.subject ) || ',
'                           ''   ,"APPLICATION_TITLE":'' || apex_json.stringify( apex_escape.html(:APPLICATION_TITLE) ) || ',
'                           ''   ,"OPT_OUT_TEXT":''      || apex_json.stringify( apex_lang.message(''OPT_OUT_TEXT'', ',
'                                                                              :APP_PATH || ''/f?p='' || :APP_ID || '':optout'',',
'                                                                              apex_escape.html(:APPLICATION_TITLE)) ) || ',
'                           ''   ,"BODY":''  || apex_json.stringify( replace(c1.message,''#POLL_LINK#'',''<a href="#">''||:POLL_NAME||''</a>'') ) || ',
'                           ''}'' , ',
'      p_application_id  => :APP_ID,',
'      p_subject         => l_subject,',
'      p_html            => l_html_body,',
'      p_text            => l_text_body );',
'      ',
'   return l_html_body;',
'   ',
'end loop;',
'      ',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P13_EMAIL_ID,P13_POLL_ID'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_emailS',
' where id = :P13_EMAIL_ID',
'   and poll_id = :P13_POLL_ID'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(584911537956635147)
,p_plug_name=>'No Email in History'
,p_parent_plug_id=>wwv_flow_imp.id(14047541724484379981)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>55
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'There is no email in the history matching this.  The email log was likely purged.'
,p_plug_display_condition_type=>'NOT_EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_emailS',
' where id = :P13_EMAIL_ID',
'   and poll_id = :P13_POLL_ID'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(14001076113931353426)
,p_name=>'Email Details'
,p_parent_plug_id=>wwv_flow_imp.id(14047541724484379981)
,p_template=>4072358936313175081
,p_display_sequence=>65
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       subject,',
'       sent_time,',
'       sent_to,',
'       cc,',
'       lower(sent_by) sent_by',
'  from eba_qpoll_emailS',
' where id = :P13_EMAIL_ID',
'   and poll_id = :P13_POLL_ID'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_emailS',
' where id = :P13_EMAIL_ID',
'   and poll_id = :P13_POLL_ID'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>2100515439059797523
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14001076409862353464)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14001076511345353473)
,p_query_column_id=>2
,p_column_alias=>'SUBJECT'
,p_column_display_sequence=>2
,p_column_heading=>'Subject'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14001076632592353473)
,p_query_column_id=>3
,p_column_alias=>'SENT_TIME'
,p_column_display_sequence=>3
,p_column_heading=>'Sent'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14001076727607353473)
,p_query_column_id=>4
,p_column_alias=>'SENT_TO'
,p_column_display_sequence=>4
,p_column_heading=>'Sent To'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14001076806033353473)
,p_query_column_id=>5
,p_column_alias=>'CC'
,p_column_display_sequence=>5
,p_column_heading=>'CC'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_emails',
' where id = :P13_EMAIL_ID',
'   and poll_id = :P13_POLL_ID',
'   and cc is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14001077018895353473)
,p_query_column_id=>6
,p_column_alias=>'SENT_BY'
,p_column_display_sequence=>6
,p_column_heading=>'Sent From'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(14047535510565528821)
,p_name=>'Invitation Details'
,p_parent_plug_id=>wwv_flow_imp.id(14047541724484379981)
,p_template=>4501440665235496320
,p_display_sequence=>45
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select i.respondent_email,',
'       p.poll_name,',
'       ci.community_name,',
'       lower(i.created_by) invitation_sent_by,',
'       i.created  invitation_sent,',
'       decode(i.email_sent, ''YES'', ''Email'',',
'              ''REMINDER_SENT'', ''Reminder'',',
'              ''OPTED_OUT'',''Opted Out'',',
'              ''PREVIOUSLY_SENT'',''Previously Sent'',',
'              ''MANUAL_INVITE'', ''Manual Invite'',',
'              i.email_sent) invite_method,',
'       (select max(created)',
'          from eba_qpoll_results r',
'         where r.poll_id = p.id',
'           and r.IS_VALID_YN = ''Y''',
'           and r.respondent_id = i.respondent_id) response_date,',
'       :P13_INVITE_URL poll_url',
'  from eba_qpoll_polls p,',
'       eba_qpoll_comm_invites ci,',
'       eba_qpoll_invites i',
' where p.id = :P13_POLL_ID',
'   and p.id = ci.poll_id',
'   and ci.id = i.comm_invite_id',
'   and i.id = :P13_INVITE_ID'))
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>2100515439059797523
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14047536232048528848)
,p_query_column_id=>1
,p_column_alias=>'RESPONDENT_EMAIL'
,p_column_display_sequence=>1
,p_column_heading=>'Invitee'
,p_column_html_expression=>'<strong>#RESPONDENT_EMAIL#</strong>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14047535821321528843)
,p_query_column_id=>2
,p_column_alias=>'POLL_NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Poll'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14047535916274528847)
,p_query_column_id=>3
,p_column_alias=>'COMMUNITY_NAME'
,p_column_display_sequence=>3
,p_column_heading=>'Community'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_polls p,',
'       eba_qpoll_comm_invites ci,',
'       eba_qpoll_invites i',
' where p.id = :P13_POLL_ID',
'   and p.id = ci.poll_id',
'   and ci.id = i.comm_invite_id',
'   and i.id = :P13_INVITE_ID',
'   and ci.community_name is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14047536014130528847)
,p_query_column_id=>4
,p_column_alias=>'INVITATION_SENT_BY'
,p_column_display_sequence=>5
,p_column_heading=>'Invited By'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14047536107863528847)
,p_query_column_id=>5
,p_column_alias=>'INVITATION_SENT'
,p_column_display_sequence=>6
,p_column_heading=>'Invited'
,p_column_format=>'fmDay, fmDD fmMonth, YYYY  HH24:MI'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14047536304100528848)
,p_query_column_id=>6
,p_column_alias=>'INVITE_METHOD'
,p_column_display_sequence=>4
,p_column_heading=>'Method'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14047536514273528848)
,p_query_column_id=>7
,p_column_alias=>'RESPONSE_DATE'
,p_column_display_sequence=>7
,p_column_heading=>'Responded'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14047536623995528848)
,p_query_column_id=>8
,p_column_alias=>'POLL_URL'
,p_column_display_sequence=>8
,p_column_heading=>'Poll URL'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(437590346811961251)
,p_name=>'P13_INVITE_URL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(14047541724484379981)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13942059631539929960)
,p_name=>'P13_POLL_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(14047541724484379981)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13942141019347709801)
,p_name=>'P13_EMAIL_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(14047541724484379981)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14047537607843756609)
,p_name=>'P13_INVITE_ID'
,p_item_sequence=>15
,p_item_plug_id=>wwv_flow_imp.id(14047541724484379981)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(437590534960961252)
,p_computation_sequence=>10
,p_computation_item=>'P13_INVITE_URL'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
' select i.respondent_id, p.authentication_req_yn',
'  from eba_qpoll_polls p,',
'       eba_qpoll_comm_invites ci,',
'       eba_qpoll_invites i',
' where p.id = :P13_POLL_ID',
'   and p.id = ci.poll_id',
'   and ci.id = i.comm_invite_id',
'   and i.id = :P13_INVITE_ID',
') loop',
'   return :APP_PATH||apex_util.prepare_url(p_url => ''f?p=''||:APP_ID||'':''||case when c1.authentication_req_yn=''Y''',
'                                                                                    then ''500''',
'                                                                                    else ''50'' end||'':0::::LPOLL_ID,PID:'' ||:P13_POLL_ID||'',''||c1.respondent_id,',
'                                      p_checksum_type => ''1'',',
'                                      p_plain_url => TRUE);',
'end loop;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(13942058004850922031)
,p_name=>'Load Email'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P13_EMAIL_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942058512948922031)
,p_event_id=>wwv_flow_imp.id(13942058004850922031)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P13_EMAIL_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13942058326454922031)
,p_event_id=>wwv_flow_imp.id(13942058004850922031)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'openModal("view_email");',
'$("#view_email").parent().width("700px");'))
);
wwv_flow_imp.component_end;
end;
/
