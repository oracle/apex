prompt --application/pages/page_00072
begin
--   Manifest
--     PAGE: 00072
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>72
,p_name=>'Invite'
,p_alias=>'INVITE'
,p_page_mode=>'MODAL'
,p_step_title=>'Invite'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(13947300029372503485)
,p_step_template=>2101883943284197310
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(165977452478131556)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13949153406703867281)
,p_plug_name=>'Advanced'
,p_static_id=>'advanced'
,p_parent_plug_id=>wwv_flow_imp.id(13940705308767234163)
,p_region_css_classes=>'infoTextRegion'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'This application''s current EMAIL FROM address is: <strong>&P72_EMAIL_FROM.</strong>.  The EMAIL FROM address value can be controlled by navigating to application administration.'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P72_EMAIL_FROM'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(14014020830095865745)
,p_name=>'Already Invited'
,p_static_id=>'already-invited'
,p_parent_plug_id=>wwv_flow_imp.id(13940705308767234163)
,p_template=>2665811232373458102
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(community_name,''Individuals'') community_name,',
'       (select count(*) ',
'          from eba_qpoll_results r,',
'               eba_qpoll_invites i',
'         where r.poll_id = :POLL_ID',
'           and r.IS_VALID_YN = ''Y''',
'           and i.comm_invite_id = c.id',
'           and r.respondent_id = i.respondent_id ) num_responses,',
'       (select count(*)',
'          from eba_qpoll_invites ',
'         where comm_invite_id = c.id) num_requests,',
'       created invite_date',
'  from eba_qpoll_comm_invites c',
' where poll_id = :P72_POLL_ID',
'   and community_name is not null',
'union',
'select respondent_email community_name,',
'       nvl((select 1 ',
'          from eba_qpoll_results',
'         where poll_id = :POLL_ID',
'           and IS_VALID_YN = ''Y''',
'           and respondent_id = i.respondent_id ),0) num_responses,',
'       null num_requests,',
'       c.created invite_date',
'  from eba_qpoll_comm_invites c,',
'       eba_qpoll_invites i',
' where c.poll_id = :P72_POLL_ID',
'   and c.community_name is null',
'   and c.id = i.comm_invite_id',
'order by invite_date desc'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_comm_invites c',
' where poll_id = :P72_POLL_ID'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P72_POLL_ID'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14014021211029865771)
,p_query_column_id=>1
,p_column_alias=>'COMMUNITY_NAME'
,p_column_display_sequence=>1
,p_column_heading=>'Community/Individual'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14014021503708865771)
,p_query_column_id=>4
,p_column_alias=>'INVITE_DATE'
,p_column_display_sequence=>4
,p_column_heading=>'Invited'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14014021428135865771)
,p_query_column_id=>3
,p_column_alias=>'NUM_REQUESTS'
,p_column_display_sequence=>2
,p_column_heading=>'Invitations'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14014021325354865771)
,p_query_column_id=>2
,p_column_alias=>'NUM_RESPONSES'
,p_column_display_sequence=>3
,p_column_heading=>'Responses'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13940704917803223070)
,p_plug_name=>'buttons'
,p_static_id=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2127905476394690047
,p_plug_display_sequence=>70
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(13940706516788340649)
,p_name=>'Community Members'
,p_static_id=>'community-members'
,p_parent_plug_id=>wwv_flow_imp.id(13940705308767234163)
,p_template=>2665811232373458102
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:is-expanded:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    r.email',
'from',
'    eba_qpoll_respondents r,',
'    EBA_QPOLL_RESP_COMMUNITIES c,',
'    eba_qpoll_resp_comm_ref rc',
'where',
'    c.id = :P72_COMMUNITY_ID',
'and',
'    rc.community_id = c.id',
'and',
'    r.id = rc.respondent_id',
'order by 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13940706819398340650)
,p_query_column_id=>1
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>1
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13940705308767234163)
,p_plug_name=>'Invite Community and/or Individuals'
,p_static_id=>'invite-community-and-or-individuals'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14032904919243627011)
,p_plug_name=>'Warning - EMAIL FROM Address Undefined'
,p_static_id=>'warning-email-from-address-undefined'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>2042159785845301134
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'Invitations cannot be sent because the EMAIL FROM address has not been defined.  Please contact an administrator.'
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P72_EMAIL_FROM'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28444334390791025626)
,p_plug_name=>'Warning - Poll In Testing Phase'
,p_static_id=>'warning-poll-in-testing-phase'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>2042159785845301134
,p_plug_display_sequence=>15
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'This poll is in the testing phase.  If an invitee is not a Contributor or Administrator, they will be able to view and take the poll.'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_qpoll_polls',
' where id = :P72_POLL_ID',
'   and status_id = 2'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13950128104333107556)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(13940705308767234163)
,p_button_name=>'add_community'
,p_static_id=>'add-community'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconRight'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Add New Community'
,p_button_redirect_url=>'f?p=&APP_ID.:70:&SESSION.::&DEBUG.:RP,70::'
,p_icon_css_classes=>'fa-chevron-right'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13940711233158402084)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(13940704917803223070)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13949154134932913347)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(13940704917803223070)
,p_button_name=>'PREVIEW'
,p_static_id=>'preview'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Preview'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13940711607794413681)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(13940704917803223070)
,p_button_name=>'SEND'
,p_static_id=>'send'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Invite'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(13940729627888851394)
,p_branch_name=>'if email'
,p_branch_action=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(13940711607794413681)
,p_branch_sequence=>10
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P72_INVITE_METHOD'
,p_branch_condition_text=>'EMAIL'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(14014041929742317057)
,p_branch_name=>'if manual'
,p_branch_action=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:::'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(13940711607794413681)
,p_branch_sequence=>20
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P72_INVITE_METHOD'
,p_branch_condition_text=>'MANUAL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13940705824489260428)
,p_name=>'P72_COMMUNITY_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(13940705308767234163)
,p_prompt=>'Community'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'COMMUNITIES, P72'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select -'
,p_lov_cascade_parent_items=>'P72_POLL_ID'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_tag_attributes=>'style="width:300px;"'
,p_display_when=>'select null from EBA_QPOLL_RESP_COMMUNITIES'
,p_display_when_type=>'EXISTS'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_help_text=>'Select the community of users that you wish to invite to take this poll.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14014045427413530881)
,p_name=>'P72_COMM_INVITE_ID'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(13940705308767234163)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14050741911075885439)
,p_name=>'P72_COMM_INVITE_ID2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(13940705308767234163)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14032904719031619188)
,p_name=>'P72_EMAIL_FROM'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(13940705308767234163)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(437591828067961265)
,p_name=>'P72_INVITE_BODY'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(13940705308767234163)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(invite_body,''<p>Please take #POLL_LINK#.</p>',
'''||',
'           case when authentication_req_yn = ''N''',
'                then apex_lang.message(''UNAUTH_MSG'') end ||',
'''<p>Thanks in advance for your participation!</p>',
'<p>Best Regards,</p>',
'<p>The ''||:APPLICATION_TITLE||'' Team</p>'') default_body',
'  from eba_qpoll_polls',
' where id = :POLL_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Email Body'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cHeight=>8
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Include html formatted content to be used as the body of the email inviting people to take your poll or quiz.  Make sure you include #POLL_LINK# in your text.  It will be replaced with a link to take the poll and will include the poll name.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14009137028762380086)
,p_name=>'P72_INVITE_METHOD'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(13940705308767234163)
,p_item_default=>'EMAIL'
,p_prompt=>'Invite Method'
,p_source=>'EMAIL'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'INVITE METHOD'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Use the <strong>Invite Method</strong> method if you wish to send email invitations from this system.',
'Use the <strong>Manual</strong> method if you wish to invite users to take this poll yourself; and not via an email from this system.'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(437591640274961264)
,p_name=>'P72_INVITE_SUBJECT'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(13940705308767234163)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(invite_subject,''Please Share Your Opinion on '' || POLL_NAME)',
'  from eba_qpoll_polls',
' where id = :POLL_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Email Subject'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>255
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14050690607434611171)
,p_name=>'P72_OTHER_INVITEES'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(13940705308767234163)
,p_prompt=>'Individuals'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>3
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'You can include individuals, that are not in a community, to take a poll.  You can do this when inviting a community or just invite individuals (without any community).'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15461977611517857321)
,p_name=>'P72_OTHER_INVITEES_MSG'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(13940705308767234163)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13940705610483251721)
,p_name=>'P72_POLL_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(13940705308767234163)
,p_prompt=>'Poll'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'ACTIVE AND STAGED POLES'
,p_tag_attributes=>'style="width:300px;"'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13940719226742669631)
,p_name=>'P72_POLL_NAME'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(13940705308767234163)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(437590875000961256)
,p_name=>'P72_PREVIEW_URL'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(13940705308767234163)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.prepare_url( p_url => ''f?p=''||:APP_ID||'':57:''||:APP_SESSION||''::NO:57:P57_METHOD:INVITE:'', ',
'                       p_checksum_type => ''SESSION'', ',
'                       p_plain_url => TRUE)'))
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(14032905518803634392)
,p_computation_sequence=>20
,p_computation_item=>'P72_EMAIL_FROM'
,p_static_id=>'p72-email-from'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'eba_qpoll_fw.get_preference_value(''NOTIFICATION_EMAIL_FROM'')'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13940720204960679738)
,p_computation_sequence=>10
,p_computation_item=>'P72_POLL_NAME'
,p_static_id=>'p72-poll-name'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    poll_name',
'from',
'    eba_qpoll_polls',
'where',
'    id = :P72_POLL_ID;'))
,p_compute_when=>'P72_POLL_ID'
,p_compute_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(13949131304832330370)
,p_validation_name=>'Application From Address is valid'
,p_static_id=>'application-from-address-is-valid'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if eba_qpoll_fw.get_preference_value(''NOTIFICATION_EMAIL_FROM'') = ''N/A'' or instr(eba_qpoll_fw.get_preference_value(''NOTIFICATION_EMAIL_FROM''),''@example.com'') > 0 then',
'    return false;',
'else',
'    return true;',
'end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'The "From" address that this application uses to send emails has been improperly configured. It either has not been defined or it is using an invalid domain name (e.g. it ends in "@example.com" when your server''s domain name is NOT "example.com"). An'
||' application administrator must update the application''s FROM address to resolve this problem.'
,p_validation_condition=>':P72_INVITE_METHOD = ''EMAIL'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(13940711607794413681)
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(437592219861961269)
,p_validation_name=>'Email body contains #POLL_LINK#'
,p_static_id=>'email-body-contains-poll-link'
,p_validation_sequence=>20
,p_validation=>'instr(:P72_INVITE_BODY,''#POLL_LINK#'') > 0'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'You must include #POLL_LINK# in your Email Body.'
,p_validation_condition=>'P72_INVITE_METHOD'
,p_validation_condition2=>'EMAIL'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(13940711607794413681)
,p_associated_item=>wwv_flow_imp.id(437591828067961265)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(14050691708069626020)
,p_validation_name=>'P72_COMMUNITY_ID or other_invitees not null'
,p_static_id=>'p72-community-id-or-other-invitees-not-null'
,p_validation_sequence=>5
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P72_COMMUNITY_ID is not null or',
':P72_OTHER_INVITEES is not null'))
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'You must invite a community, individuals or both.'
,p_when_button_pressed=>wwv_flow_imp.id(13940711607794413681)
,p_associated_item=>wwv_flow_imp.id(13940705824489260428)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(437592253066961270)
,p_validation_name=>'subject not null'
,p_static_id=>'subject-not-null'
,p_validation_sequence=>30
,p_validation=>'P72_INVITE_SUBJECT'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'You must provide a subject for your email invitations.'
,p_validation_condition=>'P72_INVITE_METHOD'
,p_validation_condition2=>'EMAIL'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(13940711607794413681)
,p_associated_item=>wwv_flow_imp.id(437591640274961264)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(14049986105854000331)
,p_name=>'Disable results link when manual'
,p_static_id=>'disable-results-link-when-manual'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P72_INVITE_METHOD'
,p_condition_element=>'P72_INVITE_METHOD'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'MANUAL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14049986405319000343)
,p_event_id=>wwv_flow_imp.id(14049986105854000331)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-disable'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P72_INCLUDE_RESULTS_LINK'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14049986608940000349)
,p_event_id=>wwv_flow_imp.id(14049986105854000331)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-enable'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P72_INCLUDE_RESULTS_LINK'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(250084659465050557)
,p_event_id=>wwv_flow_imp.id(14049986105854000331)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-set-value'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P72_INCLUDE_RESULTS_LINK'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'suppress_change_event', 'N',
  'type', 'STATIC_ASSIGNMENT',
  'value', 'N')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(14032905632880640402)
,p_name=>'Disable send when no EMAIL FROM'
,p_static_id=>'disable-send-when-no-email-from'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'ITEM_IS_NULL'
,p_display_when_cond=>'P72_EMAIL_FROM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14032905931011640428)
,p_event_id=>wwv_flow_imp.id(14032905632880640402)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_static_id=>'native-disable'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(13940711607794413681)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(271747812719136595)
,p_name=>'hide Community Members report'
,p_static_id=>'hide-community-members-report'
,p_event_sequence=>50
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(437589935345961246)
,p_event_id=>wwv_flow_imp.id(271747812719136595)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(13940706516788340649)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(437591840651961266)
,p_name=>'hide subject/body when manual invite'
,p_static_id=>'hide-subject-body-when-manual-invite'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P72_INVITE_METHOD'
,p_condition_element=>'P72_INVITE_METHOD'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'EMAIL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(437592088975961268)
,p_event_id=>wwv_flow_imp.id(437591840651961266)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P72_INVITE_SUBJECT,P72_INVITE_BODY'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(437591981752961267)
,p_event_id=>wwv_flow_imp.id(437591840651961266)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P72_INVITE_SUBJECT,P72_INVITE_BODY'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(13949157416886955408)
,p_name=>'Preview Button'
,p_static_id=>'preview-button'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(13949154134932913347)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(437593150709961279)
,p_event_id=>wwv_flow_imp.id(13949157416886955408)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-execute-plsql-code'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'items_to_submit', 'P72_INVITE_SUBJECT,P72_INVITE_BODY',
  'language', 'PLSQL',
  'plsql_code', 'null; -- to get these items saved',
  'show_processing', 'N')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13949157707172955412)
,p_event_id=>wwv_flow_imp.id(13949157416886955408)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', 'window.open($v(''P72_PREVIEW_URL''));')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(13940706909993348079)
,p_name=>'Show Community Members Report'
,p_static_id=>'show-community-members-report'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P72_COMMUNITY_ID'
,p_condition_element=>'P72_COMMUNITY_ID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13940708105437360365)
,p_event_id=>wwv_flow_imp.id(13940706909993348079)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-execute-plsql-code'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'items_to_submit', 'P72_COMMUNITY_ID',
  'language', 'PLSQL',
  'plsql_code', 'null;',
  'show_processing', 'N')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13940707418153348084)
,p_event_id=>wwv_flow_imp.id(13940706909993348079)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(13940706516788340649)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13940710318783384566)
,p_event_id=>wwv_flow_imp.id(13940706909993348079)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(13940706516788340649)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13940707231180348083)
,p_event_id=>wwv_flow_imp.id(13940706909993348079)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(13940706516788340649)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14050700124542055467)
,p_process_sequence=>5
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load other invitees'
,p_static_id=>'load-other-invitees'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_validate_emails  varchar2(1);',
'    l_line             varchar2(32767);',
'    l_emails           wwv_flow_global.vc_arr2;',
'    l_email            varchar2(4000);',
'    l_at               number;',
'    l_dot              number;',
'    l_valid            boolean := true;',
'    l_domain           varchar2(4000);',
'begin',
'',
'    if eba_qpoll_fw.get_preference_value(''USERNAME_FORMAT'') = ''EMAIL'' then ',
'       l_validate_emails := ''Y'';',
'    else',
'       l_validate_emails := ''N'';',
'    end if;',
'    ',
'    ---------------------',
'    -- create collections',
'    --',
'    apex_collection.CREATE_OR_TRUNCATE_COLLECTION (''EBA_QPOLL_INVITEES_INVALID'');',
'    apex_collection.CREATE_OR_TRUNCATE_COLLECTION (''EBA_QPOLL_INVITEES_VALID'');',
' ',
'    --------------------------------------------',
'    -- replace delimiting characters with commas',
'    --',
'    l_line := :P72_OTHER_INVITEES;',
'    l_line := replace(l_line,chr(10),'' '');',
'    l_line := replace(l_line,chr(13),'' '');',
'    l_line := replace(l_line,chr(9),'' '');',
'    l_line := replace(l_line,''<'','' '');',
'    l_line := replace(l_line,''>'','' '');',
'    l_line := replace(l_line,'';'','' '');',
'    l_line := replace(l_line,'':'','' '');',
'    l_line := replace(l_line,''('','' '');',
'    l_line := replace(l_line,'')'','' '');',
'    l_line := replace(l_line,'' '','','');',
'',
'    -----------------------------------------',
'    -- get one comma separated line of emails',
'    --',
'    for j in 1..1000 loop',
'        if instr(l_line,'',,'') > 0 then',
'           l_line := replace(l_line,'',,'','','');',
'        else',
'           exit;',
'        end if;',
'    end loop;',
'',
'    -------------------------',
'    -- get an array of emails',
'    --',
'    l_emails := wwv_flow_utilities.string_to_table(l_line,'','');',
'',
'    -----------------------------',
'    -- add emails to a collection',
'    --',
'    l_email := null;',
'    l_domain := null;',
'    l_at := 0;',
'    l_dot := 0;',
'    for j in 1..l_emails.count loop',
'        l_valid := true;',
'        l_email := trim(l_emails(j));',
'        l_email := replace(l_email,chr(49824),null);',
'',
'        if l_email is not null then',
'            if l_validate_emails = ''Y'' then',
'               -----------',
'               -- Validate',
'               --',
'               l_at := instr(nvl(l_email,''x''),''@'');',
'               l_domain := substr(l_email,l_at+1);',
'               l_dot := instr(l_domain,''.'');',
'               if l_at < 2 then',
'                   apex_collection.add_member(',
'                       p_collection_name => ''EBA_QPOLL_INVITEES_INVALID'',',
'                       p_c001            => l_email,',
'                       p_c002            => ''INVALID EMAIL'');',
'                   commit;',
'                   l_valid := false;',
'               end if;',
'',
'               if l_dot = 0 and l_valid then',
'                   apex_collection.add_member(',
'                       p_collection_name => ''EBA_QPOLL_INVITEES_INVALID'',',
'                       p_c001            => l_email,',
'                       p_c002            => ''INVALID EMAIL'');',
'                   commit;',
'                   l_valid := false;',
'               end if;',
'            end if;',
'',
'            l_email := trim(l_email);',
'            l_email := trim(both ''.'' from l_email);',
'            l_email := replace(l_email,'' '',null);',
'            l_email := replace(l_email,chr(10),null);',
'            l_email := replace(l_email,chr(9),null);',
'            l_email := replace(l_email,chr(13),null);',
'            l_email := replace(l_email,chr(49824),null);',
'',
'            if l_valid and length(l_email) > 255 then',
'                apex_collection.add_member(',
'                    p_collection_name => ''EBA_QPOLL_INVITEES_INVALID'',',
'                    p_c001            => upper(l_email),',
'                    p_c002            => ''NAME TOO LONG'');',
'                commit;',
'                l_valid := false;',
'            end if;',
'',
'            if l_valid then',
'                for c1 in (select /* APEXeaf772 */  c001',
'                             from wwv_flow_collections',
'                            where collection_name = ''EBA_QPOLL_INVITEES_VALID''',
'                              and c001 = upper(l_email))',
'                loop',
'                    apex_collection.add_member(',
'                        p_collection_name => ''EBA_QPOLL_INVITEES_INVALID'',',
'                        p_c001            => upper(l_email),',
'                        p_c002            => ''DUPLICATE USER'');',
'                        commit;',
'                    l_valid := false;',
'                    exit;',
'                end loop;',
'            end if;',
'',
'            if l_valid then',
'                for c1 in (select /* APEXeaf772 */  1',
'                             from eba_qpoll_invites i,',
'                                  eba_qpoll_comm_invites ci',
'                            where i.comm_invite_id = ci.id',
'                              and upper(i.respondent_email) = upper(l_email)',
'                              and ci.poll_id = :P72_POLL_ID )',
'                loop',
'                    apex_collection.add_member(',
'                        p_collection_name => ''EBA_QPOLL_INVITEES_INVALID'',',
'                        p_c001            => upper(l_email),',
'                        p_c002            => ''ALREADY INVITED'');',
'                        commit;',
'                    l_valid := false;',
'                    exit;',
'                end loop;',
'            end if;',
'',
'            if l_valid then',
'                apex_collection.add_member(',
'                    p_collection_name => ''EBA_QPOLL_INVITEES_VALID'',',
'                    p_c001            => lower(l_email));',
'                    commit;',
'            end if;',
'',
'        end if;',
'        l_email := null;',
'    end loop;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(13940711607794413681)
,p_process_when=>'P72_OTHER_INVITEES'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>14033587284935327822
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13940713733954534793)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Record and Send Invitations'
,p_static_id=>'record-and-send-invitations'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_comm_invite_id   number;',
'   l_page_link        number := 50;',
'   l_invited_yn       varchar2(1);',
'   l_opted_out_yn     varchar2(1);',
'   l_email_id         number;',
'   l_poll_url         varchar2(4000);',
'   l_body             clob;',
'',
'   l_cnt_ind_already_invited  number := 0;',
'   l_respondent_id    number;',
'   l_comm_invite_id2  number;',
'   l_msg              varchar2(4000);',
'begin',
'',
'-- save new defaults',
'if nvl(:P72_INVITE_METHOD,''EMAIL'') = ''EMAIL'' then',
'   update eba_qpoll_polls',
'      set invite_subject = :P72_INVITE_SUBJECT,',
'          invite_body = :P72_INVITE_BODY',
'    where id = :POLL_ID;',
'   commit;',
'end if;',
'',
'',
'for c1 in (',
'   select authentication_req_yn',
'     from eba_qpoll_polls',
'    where id = :P72_POLL_ID',
') loop',
'   if c1.authentication_req_yn = ''Y'' then',
'      l_page_link := 500;',
'   else',
'      l_page_link := 50;',
'   end if;',
'end loop;',
'',
'if :P72_COMMUNITY_ID is not null then',
'   for c1 in (',
'      select name',
'        from eba_qpoll_resp_communities',
'       where id = :P72_COMMUNITY_ID',
'   ) loop',
'      insert into eba_qpoll_comm_invites',
'         (poll_id, community_id, community_name, invite_method)',
'      values',
'         (:P72_POLL_ID, :P72_COMMUNITY_ID, c1.name, :P72_INVITE_METHOD)',
'      returning id into l_comm_invite_id;',
'     :P72_COMM_INVITE_ID := l_comm_invite_id;',
'   end loop;',
'',
'   for c1 in (',
'      select r.id as respondent_id,',
'             r.name,',
'             r.email',
'        from eba_qpoll_respondents r,',
'             eba_qpoll_resp_communities c,',
'             eba_qpoll_resp_comm_ref rc',
'       where c.id = :P72_COMMUNITY_ID',
'         and rc.community_id = c.id',
'         and r.id = rc.respondent_id',
'   ) loop',
'',
'      l_invited_yn    := ''N'';',
'      l_opted_out_yn  := ''N'';',
'',
'      -- check if already invited to take this poll',
'      for c2 in (',
'         select 1',
'           from eba_qpoll_comm_invites ci,',
'                eba_qpoll_invites i',
'          where ci.poll_id = :P72_POLL_ID',
'            and ci.id = i.comm_invite_id',
'            and i.respondent_id = c1.respondent_id',
'      ) loop',
'          l_invited_yn := ''Y'';',
'      end loop;',
'',
'      if l_invited_yn = ''N'' and nvl(:P72_INVITE_METHOD,''EMAIL'') = ''EMAIL'' then',
'         -- check if opted out of email',
'         for c2 in (',
'            select 1',
'              from eba_qpoll_email_opt_out',
'             where respondent_id = c1.respondent_id',
'         ) loop',
'            l_opted_out_yn := ''Y'';',
'         end loop;',
'      end if;',
'',
'      if l_invited_yn = ''N'' and l_opted_out_yn = ''N'' and',
'         nvl(:P72_INVITE_METHOD,''EMAIL'') = ''EMAIL'' then',
'',
'         l_poll_url := ''<a href="''|| :APP_PATH ||',
'                               APEX_UTIL.PREPARE_URL(p_url => ''f?p=''||:APP_ID||'':''||l_page_link||'':::::LPOLL_ID,PID:'' ||',
'                                                               :P72_POLL_ID||'',''||c1.respondent_id,',
'                                                     p_checksum_type => ''1'',',
'                                                     p_plain_url => TRUE)||''">'' || :POLL_NAME || ''</a>''; -- :POLL_NAME is stored as an escaped value (no need to over-escape it)',
'                                                     ',
'        l_body := replace(:P72_INVITE_BODY,''#POLL_LINK#'',l_poll_url);',
'        ',
'         eba_qpoll_email.send (',
'            p_app_id             => :APP_ID,',
'            p_template_static_id => ''INVITE'',',
'            p_placeholders       => ''{'' || ',
'                                    ''    "SUBJECT":''           || apex_json.stringify( :P72_INVITE_SUBJECT ) || ',
'                                    ''   ,"APPLICATION_TITLE":'' || apex_json.stringify( apex_escape.html(:APPLICATION_TITLE) ) || ',
'                                    ''   ,"OPT_OUT_TEXT":''      || apex_json.stringify( apex_lang.message(''OPT_OUT_TEXT'', ',
'                                                                                       :APP_PATH ||',
'                                                                                        APEX_UTIL.PREPARE_URL(p_url => ''f?p='' ||:APP_ID || '':optout'',',
'                                                                                            p_plain_url => TRUE),',
'                                                                                       apex_escape.html(:APPLICATION_TITLE)) ) || ',
'                                    ''   ,"BODY":''  || apex_json.stringify( l_body ) || ',
'                                    ''}'' , ',
'            p_to                  => c1.email,',
'            p_from                => eba_qpoll_fw.get_preference_value(''NOTIFICATION_EMAIL_FROM''),',
'            p_cc                  => null,',
'            p_poll_id             => :P72_POLL_ID,',
'            p_community_id        => :P72_COMMUNITY_ID,',
'            p_respondent_id       => c1.respondent_id,',
'            p_email_id            => l_email_id);',
'',
'      end if;',
'',
'      if l_invited_yn = ''N'' then',
'         insert into eba_qpoll_invites',
'            (comm_invite_id, respondent_id, respondent_email, ',
'             email_sent, email_id)',
'         values',
'            (l_comm_invite_id, c1.respondent_id, lower(c1.email),',
'             case when :P72_INVITE_METHOD = ''MANUAL'' then ''MANUAL_INVITE''',
'                  when l_invited_yn = ''Y'' then ''PREVIOUSLY_SENT''',
'                  when l_opted_out_yn = ''Y'' then ''OPTED_OUT''',
'                  else ''YES'' end, ',
'             l_email_id );',
'      end if;',
'   end loop;',
'',
'end if;',
'',
'if :P72_OTHER_INVITEES is not null then',
'    for c in (',
'        select c001 as respondent',
'          from apex_collections',
'         where collection_name = ''EBA_QPOLL_INVITEES_VALID''',
'    ) loop',
'',
'      begin',
'         select r.id',
'           into l_respondent_id',
'           from eba_qpoll_respondents r',
'          where lower(r.email) = c.respondent;',
'      exception',
'        when no_data_found then',
'             l_respondent_id := null;',
'     end;',
'',
'     if l_respondent_id is null then',
'        insert into eba_qpoll_respondents',
'           (email)',
'        values',
'           (c.respondent)',
'        returning id into l_respondent_id;',
'     end if;',
'',
'      l_invited_yn    := ''N'';',
'      l_opted_out_yn  := ''N'';',
'',
'      -- check if already invited to take this poll',
'      for c2 in (',
'         select 1',
'           from eba_qpoll_comm_invites ci,',
'                eba_qpoll_invites i',
'          where ci.poll_id = :P72_POLL_ID',
'            and ci.id = i.comm_invite_id',
'            and i.respondent_id = l_respondent_id',
'      ) loop',
'          l_invited_yn := ''Y'';',
'          l_cnt_ind_already_invited := l_cnt_ind_already_invited + 1;',
'      end loop;',
'',
'      if l_invited_yn = ''N'' and nvl(:P72_INVITE_METHOD,''EMAIL'') = ''EMAIL'' then',
'         -- check if opted out of email',
'         for c2 in (',
'            select 1',
'              from eba_qpoll_email_opt_out',
'             where respondent_id = l_respondent_id',
'         ) loop',
'            l_opted_out_yn := ''Y'';',
'         end loop;',
'      end if;',
'',
'      if l_invited_yn = ''N'' and l_opted_out_yn = ''N'' and',
'         nvl(:P72_INVITE_METHOD,''EMAIL'') = ''EMAIL'' then',
'',
'         l_poll_url := ''<a href="''|| :APP_PATH ||',
'                               APEX_UTIL.PREPARE_URL(p_url => ''f?p='' || :APP_ID || '':'' || l_page_link || '':::::LPOLL_ID,PID:'' || :P72_POLL_ID || '','' || l_respondent_id,',
'                                                     p_checksum_type => ''1'',',
'                                                     p_plain_url => TRUE) || ''">'' || :POLL_NAME || ''</a>'';  -- :POLL_NAME is stored as an escaped value (no need to over-escape it)',
'                                                     ',
'        l_body := replace(:P72_INVITE_BODY, ''#POLL_LINK#'', l_poll_url);',
'        ',
'         eba_qpoll_email.send (',
'            p_app_id             => :APP_ID,',
'            p_template_static_id => ''INVITE'',',
'            p_placeholders       => ''{'' || ',
'                                    ''    "SUBJECT":''           || apex_json.stringify( :P72_INVITE_SUBJECT ) || ',
'                                    ''   ,"APPLICATION_TITLE":'' || apex_json.stringify( apex_escape.html(:APPLICATION_TITLE) ) || ',
'                                    ''   ,"OPT_OUT_TEXT":''      || apex_json.stringify( apex_lang.message(''OPT_OUT_TEXT'', ',
'                                                                 :APP_PATH ||',
'                                                                 APEX_UTIL.PREPARE_URL(p_url => ''f?p='' ||:APP_ID || '':optout'',',
'                                                                                       p_plain_url => TRUE),',
'                                                                 apex_escape.html(:APPLICATION_TITLE)) ) || ',
'                                    ''   ,"BODY":''  || apex_json.stringify( l_body ) || ',
'                                    ''}'' , ',
'            p_to                  => c.respondent,',
'            p_from                => :P72_EMAIL_FROM,',
'            p_cc                  => null,',
'            p_poll_id             => :P72_POLL_ID,',
'            p_respondent_id       => l_respondent_id,',
'            p_email_id            => l_email_id );',
'        ',
'      end if;',
'',
'      if l_invited_yn = ''N'' then',
'         if l_comm_invite_id2 is null then',
'            insert into eba_qpoll_comm_invites',
'               (poll_id, invite_method)',
'            values',
'               (:P72_POLL_ID, :P72_INVITE_METHOD)',
'            returning id into l_comm_invite_id2;',
'            :P72_COMM_INVITE_ID2 := l_comm_invite_id2;',
'         end if;',
'',
'         insert into eba_qpoll_invites',
'            (comm_invite_id, respondent_id, respondent_email, ',
'             email_sent, email_id)',
'         values',
'            (l_comm_invite_id2, l_respondent_id, lower(c.respondent),',
'             case when :P72_INVITE_METHOD = ''MANUAL'' then ''MANUAL_INVITE''',
'                  when l_invited_yn = ''Y'' then ''PREVIOUSLY_SENT''',
'                  when l_opted_out_yn = ''Y'' then ''OPTED_OUT''',
'                  else ''YES'' end, ',
'             l_email_id);',
'      end if;',
'',
'     l_respondent_id := null;',
'',
'   end loop;',
'',
'   for c1 in (',
'      select count(*) cnt',
'        from wwv_flow_collections',
'       where collection_name = ''EBA_QPOLL_INVITEES_INVALID''',
'         and c002 = ''INVALID EMAIL''',
'   ) loop',
'      if c1.cnt != 0 then',
'         l_msg := c1.cnt || '' invalid emails, '';',
'      end if;',
'   end loop;',
'',
'   for c1 in (',
'      select count(*) cnt',
'        from wwv_flow_collections',
'       where collection_name = ''EBA_QPOLL_INVITEES_INVALID''',
'         and c002 = ''DUPLICATE USER''',
'   ) loop',
'      if c1.cnt != 0 then',
'         l_msg := l_msg || c1.cnt || '' duplicate users, '';',
'      end if;',
'   end loop;',
'',
'   for c1 in (',
'      select count(*) cnt',
'        from wwv_flow_collections',
'       where collection_name = ''EBA_QPOLL_INVITEES_INVALID''',
'         and c002 = ''ALREADY INVITED''',
'   ) loop',
'      if c1.cnt != 0 or l_cnt_ind_already_invited != 0 then',
'         l_msg := l_msg || c1.cnt + l_cnt_ind_already_invited || '' already invited, '';',
'      end if;',
'   end loop;',
'   ',
'   for c1 in (',
'      select count(*) cnt',
'        from wwv_flow_collections',
'       where collection_name = ''EBA_QPOLL_INVITEES_INVALID''',
'         and c002 = ''NAME TOO LONG''',
'   ) loop',
'      if c1.cnt != 0 then',
'         l_msg := l_msg || c1.cnt || '' names too long, '';',
'      end if;',
'   end loop;',
'',
'   if l_msg is not null then',
'      l_msg := rtrim(l_msg,'', '');',
'      :P72_OTHER_INVITEES_MSG := ''<strong>Individual Invitations</strong>: '' || l_msg;',
'   end if;',
'',
'   ---------------------',
'   -- delete collections',
'   --',
'   wwv_flow_collection.DELETE_COLLECTION(''EBA_QPOLL_INVITEES_INVALID'');',
'   wwv_flow_collection.DELETE_COLLECTION(''EBA_QPOLL_INVITEES_VALID'');',
'',
'end if;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'#SQLERRM#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(13940711607794413681)
,p_internal_uid=>13923600894347807148
);
wwv_flow_imp.component_end;
end;
/
