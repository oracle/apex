prompt --application/pages/page_00100
begin
--   Manifest
--     PAGE: 00100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>100
,p_name=>'Poll Details'
,p_alias=>'POLL-DETAILS'
,p_step_title=>'Poll Details'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(13925947051057752382)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.center-button {',
'    padding: 8px;',
'}',
'.center-button .uButton {',
'    display: block;',
'    margin: 0 8px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(167453297030546086)
,p_protection_level=>'C'
,p_help_text=>'Use this page to manage the selected poll. You can edit the attributes to change who can take the poll and if login will be required.  You can Invite users to take the poll, and view the results.'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(251560903450465091)
,p_plug_name=>'Main Content'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>140
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(224745400250830995)
,p_plug_name=>'RDS'
,p_parent_plug_id=>wwv_flow_imp.id(251560903450465091)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_comm_invites c',
' where poll_id = :POLL_ID',
' union',
'select 1',
'  from eba_qpoll_results',
' where poll_id = :POLL_ID',
'   and nvl(is_valid_yn,''Y'') = ''Y'''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(251564298649465125)
,p_plug_name=>'no sections yet'
,p_parent_plug_id=>wwv_flow_imp.id(251560903450465091)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>70
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'No sections defined yet.'
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P100_USE_SECTIONS_YN = ''Y'' then',
'   for c1 in (',
'      select count(*) c',
'        from EBA_QPOLL_SECTIONS',
'       where POLL_ID = :POLL_ID',
'   ) loop',
'      if c1.c = 0 then',
'         return TRUE;',
'      end if;',
'   end loop;',
'end if;',
'return FALSE;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(273218844397551077)
,p_plug_name=>'no questions yet'
,p_parent_plug_id=>wwv_flow_imp.id(251560903450465091)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>80
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'No questions defined yet.'
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P100_USE_SECTIONS_YN = ''Y'' then',
'   for c1 in (',
'      select count(*) c',
'        from EBA_QPOLL_SECTIONS',
'       where POLL_ID = :POLL_ID',
'   ) loop',
'      if c1.c = 0 then',
'         return FALSE;',
'      end if;',
'   end loop;',
'end if;',
'',
'for c1 in (',
'   select count(*) c',
'     from EBA_QPOLL_QUESTIONS',
'    where POLL_ID = :POLL_ID',
') loop',
'   if c1.c = 0 then',
'      return TRUE;',
'   end if;',
'end loop;',
'',
'return FALSE;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13881662550369483885)
,p_plug_name=>'Hidden Items'
,p_parent_plug_id=>wwv_flow_imp.id(251560903450465091)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(13881687266288113002)
,p_name=>'Respondents'
,p_region_name=>'respondents'
,p_parent_plug_id=>wwv_flow_imp.id(251560903450465091)
,p_template=>4072358936313175081
,p_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--inline:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.id, ',
'       case when p.anonymous_yn = ''Y'' then ''anonymous'' else lower(r.EMAIL) end email, ',
'       round(r.grade,1) || case when r.grade is not null then '' %'' end grade, ',
'       r.score,',
'       r.created, ',
'       r.updated,',
'       r.preactive_yn,',
'       (select listagg(c.community_name,'', '') within group (order by c.community_name)',
'          from eba_qpoll_comm_invites c,',
'               eba_qpoll_invites i',
'         where p.id = c.poll_id',
'           and c.id = i.comm_invite_id',
'           and r.respondent_id = i.respondent_id) community',
'from EBA_QPOLL_RESULTS r,',
'     eba_qpoll_polls p',
'where p.id = :POLL_ID',
'  and p.id = r.POLL_ID',
'  and nvl(r.is_valid_yn,''Y'') = ''Y''',
'order by 3 desc'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from EBA_QPOLL_RESULTS r,',
'     eba_qpoll_polls p',
'where p.id = :POLL_ID',
'  and p.id = r.POLL_ID',
'  and nvl(r.is_valid_yn,''Y'') = ''Y'''))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>20
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No responses have been submitted. '
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_query_row_count_max=>5000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13942197457012151507)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13881687567001113003)
,p_query_column_id=>2
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>2
,p_column_heading=>'Respondent'
,p_column_link=>'f?p=&APP_ID.:73:&SESSION.::&DEBUG.:73:P73_RESULT_ID:#ID#'
,p_column_linktext=>'#EMAIL#'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13946431061224724487)
,p_query_column_id=>3
,p_column_alias=>'GRADE'
,p_column_display_sequence=>4
,p_column_heading=>'Score'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'POLL_OR_QUIZ'
,p_display_when_condition2=>'Q'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13951672051371237903)
,p_query_column_id=>4
,p_column_alias=>'SCORE'
,p_column_display_sequence=>5
,p_column_heading=>'Score'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from EBA_QPOLL_QUESTIONS q,',
'       EBA_QPOLL_POLLS p',
'  where q.poll_ID = p.id and',
'        p.id = :POLL_ID and',
'        p.score_type in (''A'',''C'') and ',
'        p.enable_score_yn = ''Y'' and',
'        q.enable_score_yn = ''Y'''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13942196466741116588)
,p_query_column_id=>5
,p_column_alias=>'CREATED'
,p_column_display_sequence=>7
,p_column_heading=>'Submitted'
,p_column_format=>'SINCE'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13942196562161116589)
,p_query_column_id=>6
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>8
,p_column_heading=>'Updated'
,p_column_format=>'SINCE'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_polls',
' where id = :POLL_ID',
'   and can_update_answers_yn = ''Y'''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13971673156931907058)
,p_query_column_id=>7
,p_column_alias=>'PREACTIVE_YN'
,p_column_display_sequence=>6
,p_column_heading=>'Test Data'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_results',
'  where poll_id = :POLL_ID and',
'        preactive_yn = ''Y'''))
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(13936783555174644705)
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8232708601966939492)
,p_query_column_id=>8
,p_column_alias=>'COMMUNITY'
,p_column_display_sequence=>3
,p_column_heading=>'Communities'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_qpoll_comm_invites',
' where poll_id = :POLL_ID'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(13944332966712100408)
,p_name=>'Community Invitations'
,p_parent_plug_id=>wwv_flow_imp.id(251560903450465091)
,p_template=>4072358936313175081
,p_display_sequence=>110
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    v1.num_responses,',
'    v1.num_requests,',
'    v1.invite_date,',
'    case when v1.num_requests = 0 then null',
'         else to_char((v1.num_responses/v1.num_requests) * 100,''999G999G999G990'')||''%''',
'         end as pct_responded,',
'    ''<a href="''||apex_util.prepare_url(''f?p=''||:APP_ID||'':16:''||:APP_SESSION||'':::RIR,CIR:IR_POLL_ID,IR_COMM_INVITE_ID:''||:POLL_ID||'',''||comm_invite_id)||''">''',
'        ||apex_escape.html(v1.community_name)||''</a>'' community_name,',
'    invite_method',
'from',
'(',
'    select ID comm_invite_id,',
'           community_name,',
'           (select count(unique(r.respondent_id)) ',
'              from eba_qpoll_results r,',
'                   eba_qpoll_invites i',
'             where r.poll_id = :POLL_ID',
'               and r.IS_VALID_YN = ''Y''',
'               and i.comm_invite_id = c.id',
'               and r.respondent_id = i.respondent_id ) num_responses,',
'           (select count(unique respondent_email)',
'              from eba_qpoll_invites ',
'             where comm_invite_id = c.id) num_requests,',
'           created invite_date,',
'           initcap(invite_method) invite_method',
'      from eba_qpoll_comm_invites c',
'     where poll_id = :POLL_ID',
'       and community_name is not null',
') v1',
'order by v1.invite_date desc nulls last, upper(v1.community_name)'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_comm_invites ',
' where poll_id = :POLL_ID',
'   and community_name is not null'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>10000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'no invitations found'
,p_query_row_count_max=>10000
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13944333455803100452)
,p_query_column_id=>1
,p_column_alias=>'NUM_RESPONSES'
,p_column_display_sequence=>5
,p_column_heading=>'Responses'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13944333553385100452)
,p_query_column_id=>2
,p_column_alias=>'NUM_REQUESTS'
,p_column_display_sequence=>4
,p_column_heading=>'Invitations'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13948723053826789043)
,p_query_column_id=>3
,p_column_alias=>'INVITE_DATE'
,p_column_display_sequence=>1
,p_column_heading=>'Sent'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13944333674215100452)
,p_query_column_id=>4
,p_column_alias=>'PCT_RESPONDED'
,p_column_display_sequence=>6
,p_column_heading=>'Response Rate'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13944333975457100452)
,p_query_column_id=>5
,p_column_alias=>'COMMUNITY_NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Community'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14052209449740056690)
,p_query_column_id=>6
,p_column_alias=>'INVITE_METHOD'
,p_column_display_sequence=>3
,p_column_heading=>'Method'
,p_heading_alignment=>'LEFT'
,p_named_lov=>wwv_flow_imp.id(14010612974336795626)
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(14052196056382716797)
,p_name=>'Individual Invitations'
,p_parent_plug_id=>wwv_flow_imp.id(251560903450465091)
,p_template=>4072358936313175081
,p_display_sequence=>120
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--inline:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''<a href="''||apex_util.prepare_url(''f?p=''||:APP_ID||'':16:''||:APP_SESSION||'':::RIR,CIR:IR_POLL_ID,IR_INVITE_ID:''||:POLL_ID||'',''||i.id)',
'        ||''">''||apex_escape.html(i.respondent_email)||''</a>'' invitee,',
'    nvl((select ''Yes'' ',
'         from eba_qpoll_results r',
'         where r.poll_id = :POLL_ID',
'             and r.IS_VALID_YN = ''Y''',
'             and r.respondent_id = i.respondent_id ),''No'') responded,',
'    c.created invite_date,',
'    initcap(c.invite_method) invite_method',
'from eba_qpoll_comm_invites c,',
'    eba_qpoll_invites i',
'where c.poll_id = :POLL_ID',
'    and c.id = i.comm_invite_id',
'    and c.community_name is null',
'order by c.created desc, upper(i.respondent_email)'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_comm_invites ',
' where poll_id = :POLL_ID',
'   and community_name is null'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>10000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no invitations found'
,p_query_num_rows_type=>'0'
,p_query_row_count_max=>10000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14052197376933755399)
,p_query_column_id=>1
,p_column_alias=>'INVITEE'
,p_column_display_sequence=>2
,p_column_heading=>'Invitee'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14052197466165755400)
,p_query_column_id=>2
,p_column_alias=>'RESPONDED'
,p_column_display_sequence=>4
,p_column_heading=>'Responded'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P100_ANONYMOUS_YN'
,p_display_when_condition2=>'N'
,p_lov_show_nulls=>'YES'
,p_derived_column=>'N'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14052196271646716813)
,p_query_column_id=>3
,p_column_alias=>'INVITE_DATE'
,p_column_display_sequence=>1
,p_column_heading=>'Sent'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'NO'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14052209773235061047)
,p_query_column_id=>4
,p_column_alias=>'INVITE_METHOD'
,p_column_display_sequence=>3
,p_column_heading=>'Method'
,p_heading_alignment=>'LEFT'
,p_named_lov=>wwv_flow_imp.id(14010612974336795626)
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(14052197853920763430)
,p_name=>'Not Invited'
,p_parent_plug_id=>wwv_flow_imp.id(251560903450465091)
,p_template=>4072358936313175081
,p_display_sequence=>130
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select email,',
'       created',
'  from eba_qpoll_results',
' where poll_id = :POLL_ID',
'   and IS_VALID_YN = ''Y''',
'   and respondent_id not in (select i.respondent_id',
'                               from eba_qpoll_comm_invites c,',
'                                    eba_qpoll_invites i',
'                              where c.poll_id = :POLL_ID',
'                                and c.id = i.comm_invite_id)',
'order by created desc, upper(email)'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_results',
' where poll_id = :POLL_ID',
'   and IS_VALID_YN = ''Y''',
'   and respondent_id not in (select i.respondent_id',
'                               from eba_qpoll_comm_invites c,',
'                                    eba_qpoll_invites i',
'                              where c.poll_id = :POLL_ID',
'                                and c.id = i.comm_invite_id)'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>10000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'no invitations found'
,p_query_row_count_max=>10000
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14052199168282789790)
,p_query_column_id=>1
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>1
,p_column_heading=>'Respondent'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14052199263658789790)
,p_query_column_id=>2
,p_column_alias=>'CREATED'
,p_column_display_sequence=>2
,p_column_heading=>'Responded'
,p_column_format=>'SINCE'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28415967844147701002)
,p_plug_name=>'Published!'
,p_parent_plug_id=>wwv_flow_imp.id(251560903450465091)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--success'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<p>Now that your poll has been published, you can send invitations to pre-defined communities and/or individuals using the Invite button on the right.</p>'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'REQUEST_EQUALS_CONDITION'
,p_plug_display_when_condition=>'NEW'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28451015196452736770)
,p_plug_name=>'No Invitations'
,p_parent_plug_id=>wwv_flow_imp.id(251560903450465091)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<p>Your poll is Invite Only but you have not invited anyone to take it.  Use the Invite button on the right to send invitations.</p>'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_qpoll_polls',
' where id = :POLL_ID',
'   and invite_only_yn = ''Y''',
'   and status_id = 3',
'   and not exists (select 1',
'                     from eba_qpoll_comm_invites',
'                    where poll_id = :POLL_ID)',
'   and nvl(:REQUEST,''OLD'') != ''NEW'''))
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(31664321038778980412)
,p_name=>'Sections'
,p_region_name=>'sections_report'
,p_parent_plug_id=>wwv_flow_imp.id(251560903450465091)
,p_template=>4072358936313175081
,p_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--inline:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id, title, section_text, CREATED, display_sequence sequence',
'from EBA_QPOLL_SECTIONS',
'where POLL_ID = :POLL_ID',
'order by display_sequence, title'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from EBA_QPOLL_SECTIONS',
' where POLL_ID = :POLL_ID'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>22
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'No sections have been defined for this poll yet.'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18709511399659922246)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'id'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18709511800624922247)
,p_query_column_id=>2
,p_column_alias=>'TITLE'
,p_column_display_sequence=>2
,p_column_heading=>'Title'
,p_column_link=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:38:P38_ID:#ID#'
,p_column_linktext=>'#TITLE#'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18709512164701922247)
,p_query_column_id=>3
,p_column_alias=>'SECTION_TEXT'
,p_column_display_sequence=>3
,p_column_heading=>'Section Text'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18709512600012922248)
,p_query_column_id=>4
,p_column_alias=>'CREATED'
,p_column_display_sequence=>4
,p_column_heading=>'Created'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'NO'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18709512953378922248)
,p_query_column_id=>5
,p_column_alias=>'SEQUENCE'
,p_column_display_sequence=>5
,p_column_heading=>'Sequence'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(32495157472002985970)
,p_name=>'Questions'
,p_region_name=>'questions_report'
,p_parent_plug_id=>wwv_flow_imp.id(251560903450465091)
,p_template=>4072358936313175081
,p_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    q.ID,',
'    s.title,',
'    q.QUESTION,',
'    q.CREATED,',
'    q.UPDATED,',
'    q.display_sequence, ',
'    q.mandatory_yn,',
'    case when q.QUESTION_TYPE in (''TEXTAREA'',''TEXT'') then null',
'         else decode(USE_CUSTOM_ANSWERS_YN,',
'           ''N'', a.answer_01||',
'                decode(a.answer_02,null,null,'', ''||a.answer_02)||',
'                decode(a.answer_03,null,null,'', ''||a.answer_03)||',
'                decode(a.answer_04,null,null,'', ''||a.answer_04)||',
'                decode(a.answer_05,null,null,'', ''||a.answer_05)||',
'                decode(a.answer_06,null,null,'', ''||a.answer_06)||',
'                decode(a.answer_07,null,null,'', ''||a.answer_07)||',
'                decode(a.answer_08,null,null,'', ''||a.answer_08)||',
'                decode(a.answer_09,null,null,'', ''||a.answer_09)||',
'                decode(a.answer_10,null,null,'', ''||a.answer_10)||',
'                decode(a.answer_11,null,null,'', ''||a.answer_11)||',
'                decode(a.answer_12,null,null,'', ''||a.answer_12),',
'           q.answer_01||',
'                decode(q.answer_02,null,null,'', ''||q.answer_02)||',
'                decode(q.answer_03,null,null,'', ''||q.answer_03)||',
'                decode(q.answer_04,null,null,'', ''||q.answer_04)||',
'                decode(q.answer_05,null,null,'', ''||q.answer_05)||',
'                decode(q.answer_06,null,null,'', ''||q.answer_06)||',
'                decode(q.answer_07,null,null,'', ''||q.answer_07)||',
'                decode(q.answer_08,null,null,'', ''||q.answer_08)||',
'                decode(q.answer_09,null,null,'', ''||q.answer_09)||',
'                decode(q.answer_10,null,null,'', ''||q.answer_10)||',
'                decode(q.answer_11,null,null,'', ''||q.answer_11)||',
'                decode(q.answer_12,null,null,'', ''||q.answer_12)) end answers,',
'    case when p.POLL_OR_QUIZ = ''Q'' and question_type = ''CHECKBOX''',
'         then eba_qpoll_quiz.delim_answers_disp(q.correct_answer)',
'         else q.correct_answer',
'         end correct_answer,',
'    decode(q.QUESTION_TYPE,',
'       ''RADIO_GROUP'',''Pick One'',',
'       ''CHECKBOX'',''Pick Many'',',
'       ''PICK_TWO'',''Pick Two'',',
'       ''ALLOCATION'',''Allocate $100'',',
'       ''STACK'',''Stack Rank'',',
'       ''TEXTAREA'',''Free form text'',',
'       ''TEXT'',''Text field'',',
'       ''Canned Answers'') question_type,',
'     USE_CUSTOM_ANSWERS_YN ',
'from eba_qpoll_polls p,',
'     EBA_QPOLL_QUESTIONS q,',
'     EBA_QPOLL_CANNED_ANSWERS a,',
'     eba_qpoll_sections s',
'where p.id = :POLL_ID and',
'     p.id = q.POLL_ID and',
'     q.question_type = a.code(+) and',
'     q.section_id = s.id (+)',
'order by s.display_sequence, s.title nulls last, q.display_sequence'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from EBA_QPOLL_QUESTIONS',
' where POLL_ID = :POLL_ID'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>20
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'No questions.'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18709313500054910913)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18709313822963910914)
,p_query_column_id=>2
,p_column_alias=>'TITLE'
,p_column_display_sequence=>3
,p_column_heading=>'Section'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P100_USE_SECTIONS_YN'
,p_display_when_condition2=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18709314280710910915)
,p_query_column_id=>3
,p_column_alias=>'QUESTION'
,p_column_display_sequence=>4
,p_column_heading=>'Question'
,p_column_link=>'f?p=&APP_ID.:88:&SESSION.::&DEBUG.:RP,88:P88_ID,P88_POLL_ID:#ID#,&POLL_ID.'
,p_column_linktext=>'#QUESTION#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18709314683800910915)
,p_query_column_id=>4
,p_column_alias=>'CREATED'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18709315034624910916)
,p_query_column_id=>5
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18709315411505910917)
,p_query_column_id=>6
,p_column_alias=>'DISPLAY_SEQUENCE'
,p_column_display_sequence=>2
,p_column_heading=>'Sequence'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18709315907018910918)
,p_query_column_id=>7
,p_column_alias=>'MANDATORY_YN'
,p_column_display_sequence=>10
,p_column_heading=>'Mandatory?'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_polls',
' where id = :POLL_ID',
'   and POLL_OR_QUIZ = ''P'''))
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(16081221889645084531)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18709316610471910919)
,p_query_column_id=>8
,p_column_alias=>'ANSWERS'
,p_column_display_sequence=>8
,p_column_heading=>'Answers'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18709317078744910920)
,p_query_column_id=>9
,p_column_alias=>'CORRECT_ANSWER'
,p_column_display_sequence=>9
,p_column_heading=>'Correct Answer'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_polls',
' where id = :POLL_ID',
'   and POLL_OR_QUIZ = ''Q'''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18709317419606910921)
,p_query_column_id=>10
,p_column_alias=>'QUESTION_TYPE'
,p_column_display_sequence=>5
,p_column_heading=>'Type'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18709317830111910922)
,p_query_column_id=>11
,p_column_alias=>'USE_CUSTOM_ANSWERS_YN'
,p_column_display_sequence=>11
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(251561314265465095)
,p_plug_name=>'Right Content'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>150
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>2
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(251561178279465093)
,p_plug_name=>'Menu'
,p_region_name=>'actions'
,p_parent_plug_id=>wwv_flow_imp.id(251561314265465095)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_list_id=>wwv_flow_imp.id(272934250663090596)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>3493710807219547415
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13881675570304029055)
,p_plug_name=>'Side Buttons'
,p_parent_plug_id=>wwv_flow_imp.id(251561314265465095)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13951266353224186909)
,p_plug_name=>'Summary'
,p_region_name=>'summary'
,p_parent_plug_id=>wwv_flow_imp.id(251561314265465095)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_comm_invites',
' where poll_id = :POLL_ID',
'union',
'select 1',
'  from eba_qpoll_results',
' where poll_id = :POLL_ID',
'   and nvl(is_valid_yn,''Y'') = ''Y''',
'union',
'select 1',
'  from eba_qpoll_results',
' where poll_id = :POLL_ID',
'   and nvl(is_valid_yn,''Y'') = ''Y''',
'   and preactive_yn = ''Y''',
'   and eba_qpoll.get_access_role (',
'           p_app_id   => :APP_ID,',
'           p_username => :APP_USER) in (''CONTRIBUTOR'',''ADMINISTRATOR'')'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(251561417133465096)
,p_name=>'Invites'
,p_region_name=>'invites'
,p_parent_plug_id=>wwv_flow_imp.id(13951266353224186909)
,p_template=>4501440665235496320
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--fixed:t-BadgeList--circular'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c "Unique Invitations"',
'from',
'(',
'select count (unique respondent_id) c',
'  from eba_qpoll_comm_invites c,',
'       eba_qpoll_invites i',
' where c.poll_id = :POLL_ID',
'   and c.id = i.comm_invite_id',
')'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_comm_invites',
' where poll_id = :POLL_ID'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2104643962563030528
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(251561741807465099)
,p_query_column_id=>1
,p_column_alias=>'Unique Invitations'
,p_column_display_sequence=>1
,p_column_heading=>'Unique Invitations'
,p_column_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:RP,16,RIR,CIR:IR_POLL_ID:&POLL_ID.'
,p_column_linktext=>'#Unique Invitations#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(251561861766465100)
,p_name=>'Results'
,p_region_name=>'results'
,p_parent_plug_id=>wwv_flow_imp.id(13951266353224186909)
,p_template=>4501440665235496320
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--fixed:t-BadgeList--circular'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c "Responses"',
'from',
'(',
'select count(*) c',
'  from EBA_QPOLL_RESULTS ',
' where POLL_ID = :POLL_ID',
'   and nvl(is_valid_yn,''Y'') = ''Y''',
')',
''))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_results',
' where poll_id = :POLL_ID',
'   and nvl(is_valid_yn,''Y'') = ''Y'''))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2104643962563030528
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(251561970767465101)
,p_query_column_id=>1
,p_column_alias=>'Responses'
,p_column_display_sequence=>1
,p_column_heading=>'Responses'
,p_column_link=>'f?p=&APP_ID.:66:&SESSION.::&DEBUG.:RP,66:LPOLL_ID:&POLL_ID.'
,p_column_linktext=>'#Responses#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(251562197593465104)
,p_name=>'Response Rate1'
,p_region_name=>'response_rate_a'
,p_parent_plug_id=>wwv_flow_imp.id(13951266353224186909)
,p_template=>4501440665235496320
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--fixed:t-BadgeList--circular'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select round((i.num_responses/i.num_requests) * 100) ||''%'' "Response Rate"',
'from',
'(',
' select',
'        (select count (unique r.respondent_id)',
'           from eba_qpoll_results r,',
'                eba_qpoll_comm_invites c,',
'                eba_qpoll_invites i',
'          where r.poll_id = :POLL_ID',
'            and r.IS_VALID_YN = ''Y''',
'            and c.poll_id = :POLL_ID',
'            and c.id = i.comm_invite_id ',
'            and r.respondent_id = i.respondent_id ) num_responses,',
'        (select count (unique respondent_id)',
'          from eba_qpoll_comm_invites c,',
'               eba_qpoll_invites i',
'         where c.poll_id = :POLL_ID',
'           and c.id = i.comm_invite_id) num_requests',
'    from dual',
') i'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_comm_invites ',
' where poll_id = :POLL_ID',
'   and :P100_ANONYMOUS_YN = ''N'''))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2104643962563030528
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(251562552428465107)
,p_query_column_id=>1
,p_column_alias=>'Response Rate'
,p_column_display_sequence=>1
,p_column_heading=>'Response Rate'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(251562592398465108)
,p_name=>'Response Rate2'
,p_region_name=>'response_rate_b'
,p_parent_plug_id=>wwv_flow_imp.id(13951266353224186909)
,p_template=>4072358936313175081
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--fixed:t-BadgeList--circular'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select least(round((i.num_responses/i.num_requests) * 100),100) ||''%'' "Response Rate"',
'from',
'(',
' select',
'        (select count (*)',
'           from eba_qpoll_results r',
'          where r.poll_id = :POLL_ID',
'            and r.IS_VALID_YN = ''Y'' ) num_responses,',
'        (select count (unique respondent_id)',
'          from eba_qpoll_comm_invites c,',
'               eba_qpoll_invites i',
'         where c.poll_id = :POLL_ID',
'           and c.id = i.comm_invite_id) num_requests',
'    from dual',
') i'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_comm_invites ',
' where poll_id = :POLL_ID',
'   and :P100_ANONYMOUS_YN = ''Y'''))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2104643962563030528
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(251562922573465111)
,p_query_column_id=>1
,p_column_alias=>'Response Rate'
,p_column_display_sequence=>1
,p_column_heading=>'Response Rate'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(251563016778465112)
,p_name=>'Test Data'
,p_region_name=>'test_data'
,p_parent_plug_id=>wwv_flow_imp.id(13951266353224186909)
,p_template=>4501440665235496320
,p_display_sequence=>80
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--fixed:t-BadgeList--circular'
,p_display_point=>'SUB_REGIONS'
,p_item_display_point=>'BELOW'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    count(*) "Test Responses"',
'from',
'    EBA_QPOLL_RESULTS r',
'where',
'    poll_id = :POLL_ID',
'and nvl(r.is_valid_yn,''Y'') = ''Y''',
'and preactive_yn = ''Y'''))
,p_required_role=>wwv_flow_imp.id(13971669653758832579)
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2104643962563030528
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(251564266077465124)
,p_query_column_id=>1
,p_column_alias=>'Test Responses'
,p_column_display_sequence=>1
,p_column_heading=>'Test Responses'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(251563472572465116)
,p_name=>'Quiz Average'
,p_region_name=>'quiz_average'
,p_parent_plug_id=>wwv_flow_imp.id(13951266353224186909)
,p_template=>4072358936313175081
,p_display_sequence=>110
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--fixed:t-BadgeList--circular'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    round(avg(grade),1) ||''%'' "Average Score"',
'from',
'    EBA_QPOLL_RESULTS r',
'where',
'    poll_id = :POLL_ID',
'and nvl(r.is_valid_yn,''Y'') = ''Y'''))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_results',
' where poll_id = :POLL_ID',
'   and :POLL_OR_QUIZ = ''Q'''))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2104643962563030528
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(251563688465465119)
,p_query_column_id=>1
,p_column_alias=>'Average Score'
,p_column_display_sequence=>1
,p_column_heading=>'Average Score'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(251563861433465120)
,p_name=>'Average Score'
,p_region_name=>'average_score'
,p_parent_plug_id=>wwv_flow_imp.id(13951266353224186909)
,p_template=>4072358936313175081
,p_display_sequence=>130
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--fixed:t-BadgeList--circular'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    round(avg(score),1) "Average Score"',
'from',
'    EBA_QPOLL_RESULTS r',
'where',
'    poll_id = :POLL_ID',
'and nvl(r.is_valid_yn,''Y'') = ''Y''',
'and score is not null'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from EBA_QPOLL_QUESTIONS q,',
'       EBA_QPOLL_POLLS p,',
'       EBA_QPOLL_RESULTS r',
'  where q.poll_id = p.id and',
'        p.id = :POLL_ID and',
'        p.score_type in (''A'',''C'') and ',
'        p.enable_score_yn = ''Y'' and',
'        q.enable_score_yn = ''Y'' and',
'        r.poll_id = p.id and',
'        nvl(r.is_valid_yn,''Y'') = ''Y'' and',
'        r.score is not null'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2104643962563030528
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(251564116587465123)
,p_query_column_id=>1
,p_column_alias=>'Average Score'
,p_column_display_sequence=>1
,p_column_heading=>'Average Score'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29025213786179126726)
,p_plug_name=>'Outstanding Invitations'
,p_region_name=>'oustanding_invitations'
,p_parent_plug_id=>wwv_flow_imp.id(251561314265465095)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :OUTSTANDING_INVITES = 1 then',
'   sys.htp.p(''<p class="u-tC" style="font-size: 11px"><a href="''||apex_util.prepare_url(''f?p=''||:APP_ID||'':16:''||:APP_SESSION||''::NO:RIR,CIR:IR_HAS_RESPONDED,IR_POLL_ID:No,''||:POLL_ID)||''">''||:OUTSTANDING_INVITES||'' Oustanding Invitation</a></p>'');',
'else',
'   sys.htp.p(''<p class="u-tC" style="font-size: 11px"><a href="''||apex_util.prepare_url(''f?p=''||:APP_ID||'':16:''||:APP_SESSION||''::NO:RIR,CIR:IR_HAS_RESPONDED,IR_POLL_ID:No,''||:POLL_ID)||''">''||:OUTSTANDING_INVITES||'' Oustanding Invitations</a></p>'');',
'end if;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_num_rows=>15
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_comm_invites',
' where poll_id = :POLL_ID',
'   and nvl(:OUTSTANDING_INVITES,0) > 0'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13880952272067074537)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(17606938524254648521)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
,p_plug_footer=>'&P100_POLL_STATUS.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(273218755758551076)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(251564298649465125)
,p_button_name=>'ADD_SECTION2'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Section'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:RP,38:P38_POLL_ID:&POLL_ID.'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(273218917073551078)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(273218844397551077)
,p_button_name=>'ADD_QUESTION2'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Question'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:88:&SESSION.::&DEBUG.:RP,88:P88_POLL_ID:&POLL_ID.'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13971670867548841347)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(251563016778465112)
,p_button_name=>'DELETE_TEST_DATA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft:t-Button--stretch'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Delete Test Data'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:82:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-trash-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(251561227760465094)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(13881675570304029055)
,p_button_name=>'ACTIONS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--primary:t-Button--iconRight:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Actions'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'js-menuButton'
,p_icon_css_classes=>'fa-angle-down'
,p_button_cattributes=>'data-menu="actions_menu"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25114133459668506)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(13881675570304029055)
,p_button_name=>'Preview'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Preview'
,p_button_redirect_url=>'f?p=&APP_ID.:67:&SESSION.::&DEBUG.:67::'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from EBA_QPOLL_POLLS',
' where id = :POLL_ID',
'   and status_id in (1,2)',
'   and exists (select 1 from EBA_QPOLL_QUESTIONS',
'                where POLL_ID = :POLL_ID)'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-eye'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(25114282258668507)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(13881675570304029055)
,p_button_name=>'Publish'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Publish'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5::'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from EBA_QPOLL_POLLS',
' where id = :POLL_ID',
'   and status_id in (1,2)',
'   and exists (select 1 from EBA_QPOLL_QUESTIONS',
'                where POLL_ID = :POLL_ID)'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-box-arrow-out-east'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13948650867151976287)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(13881675570304029055)
,p_button_name=>'INVITE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Invite'
,p_button_redirect_url=>'f?p=&APP_ID.:72:&SESSION.::&DEBUG.:72:P72_POLL_ID:&POLL_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from EBA_QPOLL_POLLS p',
'where id = :POLL_ID',
'and status_id = 3'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-send'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14048339762190035861)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(13881675570304029055)
,p_button_name=>'REMINDER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Send Reminders'
,p_button_redirect_url=>'f?p=&APP_ID.:1072:&SESSION.::&DEBUG.:1072:P1072_POLL_ID:&POLL_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 ',
'  from eba_qpoll_polls p,',
'       eba_qpoll_comm_invites c,',
'       eba_qpoll_invites i',
' where p.id = :POLL_ID',
'   and p.status_id = 3',
'   and p.id = c.poll_id',
'   and c.id = i.comm_invite_id',
'   and i.respondent_id not in',
'       (select respondent_id',
'          from eba_qpoll_results',
'         where poll_id = :POLL_ID',
'           and IS_VALID_YN = ''Y'')'))
,p_button_condition_type=>'EXISTS'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13971664374523747016)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(13881675570304029055)
,p_button_name=>'TAKE_POLL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Take Poll'
,p_button_redirect_url=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.:50::'
,p_grid_new_row=>'Y'
,p_security_scheme=>wwv_flow_imp.id(13938628760715717315)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13971664952094757358)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(13881675570304029055)
,p_button_name=>'UPDATE_RESPONSE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Update Response'
,p_button_redirect_url=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.:50::'
,p_grid_new_row=>'Y'
,p_security_scheme=>wwv_flow_imp.id(13939981875469213669)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13971665773407793065)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(13881675570304029055)
,p_button_name=>'RESPONSE_HAS_ERRORS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Response Has Errors'
,p_button_redirect_url=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.:50::'
,p_grid_new_row=>'Y'
,p_security_scheme=>wwv_flow_imp.id(13971665452513772329)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13937658473889707317)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(13881675570304029055)
,p_button_name=>'view_results'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'View Results'
,p_button_redirect_url=>'f?p=&APP_ID.:66:&SESSION.::&DEBUG.:RP,66:LPOLL_ID:&POLL_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from EBA_QPOLL_RESULTS',
'where poll_id = :POLL_ID',
'  and nvl(is_valid_yn,''Y'') = ''Y'''))
,p_button_condition_type=>'EXISTS'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18709318215182910922)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(32495157472002985970)
,p_button_name=>'ADD_QUESTION'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Question'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:88:&SESSION.::&DEBUG.:RP,88:P88_POLL_ID:&POLL_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_qpoll_polls',
' where id = :POLL_ID',
'   and status_id = 4'))
,p_button_condition_type=>'NOT_EXISTS'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14035328553344633421)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(13881687266288113002)
,p_button_name=>'non-respondents'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Non-Respondents'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:RP,CIR,RIR:IR_POLL_ID,IR_HAS_RESPONDED:&POLL_ID.,No'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_comm_invites',
' where poll_id = :POLL_ID',
'   and nvl(:OUTSTANDING_INVITES,0) > 0'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18709513403255922249)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(31664321038778980412)
,p_button_name=>'ADD_SECTION'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Add Section'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:38:P38_POLL_ID:&POLL_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_qpoll_polls',
' where id = :POLL_ID',
'   and status_id = 4'))
,p_button_condition_type=>'NOT_EXISTS'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14051459267678368951)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(13944332966712100408)
,p_button_name=>'VIEW_INVITATIONS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'View Community Invitations'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:16:&SESSION.:COMM:&DEBUG.:RIR:IR_POLL_ID:&POLL_ID.'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14052196765119716818)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(14052196056382716797)
,p_button_name=>'VIEW_INVITATIONS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'View Individual Invitations'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:16:&SESSION.:IND:&DEBUG.:RIR,CIR:IR_POLL_ID:&POLL_ID.'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(25114355323668508)
,p_name=>'P100_POLL_STATUS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(13880952272067074537)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13044450619470284195)
,p_name=>'P100_USE_SECTIONS_YN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(32495157472002985970)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28517144117492055019)
,p_name=>'P100_ANONYMOUS_YN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(13881662550369483885)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13951278863903435992)
,p_computation_sequence=>10
,p_computation_item=>'LAST_VIEW'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'&APP_PAGE_ID.'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8244690369880425995)
,p_name=>'Refresh after Deleting Test Data'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(13971670867548841347)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8244690490245425996)
,p_event_id=>wwv_flow_imp.id(8244690369880425995)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'#respondents, #test_data, #quiz_average, #average_score'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4552712191058998048)
,p_name=>'Refresh after questions'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(32495157472002985970)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4552712289576998049)
,p_event_id=>wwv_flow_imp.id(4552712191058998048)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(32495157472002985970)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(586387581117049679)
,p_name=>'Refresh after actions - add question'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#actions_menu'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data.dialogPageId === 88'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(586387600064049680)
,p_event_id=>wwv_flow_imp.id(586387581117049679)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(32495157472002985970)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(586388245760049686)
,p_name=>'Refresh after actions - add section'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#actions_menu'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data.dialogPageId === 38'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_da_event_comment=>'need to add p38 & 48'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(586388431095049688)
,p_event_id=>wwv_flow_imp.id(586388245760049686)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(31664321038778980412)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(586388847053049692)
,p_name=>'Refresh after actions - edit poll'
,p_event_sequence=>60
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#actions_menu'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data.dialogPageId === 48'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_da_event_comment=>'need to add p38 & 48'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(266272547584189389)
,p_event_id=>wwv_flow_imp.id(586388847053049692)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(251559985831465082)
,p_name=>'Refresh after respondents'
,p_event_sequence=>70
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(13881687266288113002)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(251560136745465083)
,p_event_id=>wwv_flow_imp.id(251559985831465082)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(13881687266288113002)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4552711953588998046)
,p_name=>'Refresh after sections'
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(31664321038778980412)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4552712066980998047)
,p_event_id=>wwv_flow_imp.id(4552711953588998046)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(31664321038778980412)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4552712391416998050)
,p_event_id=>wwv_flow_imp.id(4552711953588998046)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(32495157472002985970)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(122218140952486825)
,p_name=>'when question added from no questions yet'
,p_event_sequence=>90
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(273218844397551077)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(420354336614317076)
,p_event_id=>wwv_flow_imp.id(122218140952486825)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(32495157472002985970)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(420354465942317077)
,p_event_id=>wwv_flow_imp.id(122218140952486825)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(273218844397551077)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(25114397112668509)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Details'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'select status_id, use_sections_yn, anonymous_yn',
'  from EBA_QPOLL_POLLS',
' where id = :POLL_ID',
') loop',
'   :P100_POLL_STATUS     := case c1.status_id when 1 then ''Being Authored''',
'                                              when 2 then ''Testing''',
'                                              when 3 then ''Published''',
'                                              when 4 then ''Completed'' end;',
'   :P100_USE_SECTIONS_YN := c1.use_sections_yn;',
'   :P100_ANONYMOUS_YN    := c1.anonymous_yn;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>6525712953526334
);
wwv_flow_imp.component_end;
end;
/
