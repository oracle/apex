prompt --application/pages/page_00100
begin
--   Manifest
--     PAGE: 00100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-17'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>100
,p_user_interface_id=>wwv_flow_imp.id(14332515601885435799)
,p_name=>'Poll Details'
,p_alias=>'POLL-DETAILS'
,p_step_title=>'Poll Details'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(13907358366898610207)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.center-button {',
'    padding: 8px;',
'}',
'.center-button .uButton {',
'    display: block;',
'    margin: 0 8px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(148864612871403911)
,p_protection_level=>'C'
,p_help_text=>'Use this page to manage the selected poll. You can edit the attributes to change who can take the poll and if login will be required.  You can Invite users to take the poll, and view the results.'
,p_page_component_map=>'03'
,p_last_upd_yyyymmddhh24miss=>'20210518144730'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(232972219291322916)
,p_plug_name=>'Main Content'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14588562352722420217)
,p_plug_display_sequence=>140
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(206156716091688820)
,p_plug_name=>'RDS'
,p_parent_plug_id=>wwv_flow_imp.id(232972219291322916)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14588562352722420217)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_comm_invites c',
' where poll_id = :POLL_ID',
' union',
'select 1',
'  from eba_qpoll_results',
' where poll_id = :POLL_ID',
'   and nvl(is_valid_yn,''Y'') = ''Y'''))
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(232975614490322950)
,p_plug_name=>'no sections yet'
,p_parent_plug_id=>wwv_flow_imp.id(232972219291322916)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(14588560922544420208)
,p_plug_display_sequence=>70
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'No sections defined yet.'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P100_USE_SECTIONS_YN = ''Y'' then',
'   for c1 in (',
'      select count(*) c',
'        from EBA_QPOLL_SECTIONS',
'       where POLL_ID = :POLL_ID',
'   ) loop',
'      if c1.c = 0 then',
'         return TRUE;',
'      end if;',
'   end loop;',
'end if;',
'return FALSE;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(254630160238408902)
,p_plug_name=>'no questions yet'
,p_parent_plug_id=>wwv_flow_imp.id(232972219291322916)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(14588560922544420208)
,p_plug_display_sequence=>80
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'No questions defined yet.'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P100_USE_SECTIONS_YN = ''Y'' then',
'   for c1 in (',
'      select count(*) c',
'        from EBA_QPOLL_SECTIONS',
'       where POLL_ID = :POLL_ID',
'   ) loop',
'      if c1.c = 0 then',
'         return FALSE;',
'      end if;',
'   end loop;',
'end if;',
'',
'for c1 in (',
'   select count(*) c',
'     from EBA_QPOLL_QUESTIONS',
'    where POLL_ID = :POLL_ID',
') loop',
'   if c1.c = 0 then',
'      return TRUE;',
'   end if;',
'end loop;',
'',
'return FALSE;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13863073866210341710)
,p_plug_name=>'Hidden Items'
,p_parent_plug_id=>wwv_flow_imp.id(232972219291322916)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14588562352722420217)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(13863098582128970827)
,p_name=>'Respondents'
,p_region_name=>'respondents'
,p_parent_plug_id=>wwv_flow_imp.id(232972219291322916)
,p_template=>wwv_flow_imp.id(14588571552078420238)
,p_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--inline:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.id, ',
'       case when p.anonymous_yn = ''Y'' then ''anonymous'' else lower(r.EMAIL) end email, ',
'       round(r.grade,1) || case when r.grade is not null then '' %'' end grade, ',
'       r.score,',
'       r.created, ',
'       r.updated,',
'       r.preactive_yn,',
'       (select listagg(c.community_name,'', '') within group (order by c.community_name)',
'          from eba_qpoll_comm_invites c,',
'               eba_qpoll_invites i',
'         where p.id = c.poll_id',
'           and c.id = i.comm_invite_id',
'           and r.respondent_id = i.respondent_id) community',
'from EBA_QPOLL_RESULTS r,',
'     eba_qpoll_polls p',
'where p.id = :POLL_ID',
'  and p.id = r.POLL_ID',
'  and nvl(r.is_valid_yn,''Y'') = ''Y''',
'order by 3 desc'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from EBA_QPOLL_RESULTS r,',
'     eba_qpoll_polls p',
'where p.id = :POLL_ID',
'  and p.id = r.POLL_ID',
'  and nvl(r.is_valid_yn,''Y'') = ''Y'''))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(14588580241300420261)
,p_query_num_rows=>20
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No responses have been submitted. '
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_query_row_count_max=>5000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13923608772853009332)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13863098882841970828)
,p_query_column_id=>2
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>2
,p_column_heading=>'Respondent'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:73:&SESSION.::&DEBUG.:73:P73_RESULT_ID:#ID#'
,p_column_linktext=>'#EMAIL#'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13927842377065582312)
,p_query_column_id=>3
,p_column_alias=>'GRADE'
,p_column_display_sequence=>4
,p_column_heading=>'Score'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'POLL_OR_QUIZ'
,p_display_when_condition2=>'Q'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13933083367212095728)
,p_query_column_id=>4
,p_column_alias=>'SCORE'
,p_column_display_sequence=>5
,p_column_heading=>'Score'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from EBA_QPOLL_QUESTIONS q,',
'       EBA_QPOLL_POLLS p',
'  where q.poll_ID = p.id and',
'        p.id = :POLL_ID and',
'        p.score_type in (''A'',''C'') and ',
'        p.enable_score_yn = ''Y'' and',
'        q.enable_score_yn = ''Y'''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13923607782581974413)
,p_query_column_id=>5
,p_column_alias=>'CREATED'
,p_column_display_sequence=>7
,p_column_heading=>'Submitted'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13923607878001974414)
,p_query_column_id=>6
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>8
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_polls',
' where id = :POLL_ID',
'   and can_update_answers_yn = ''Y'''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13953084472772764883)
,p_query_column_id=>7
,p_column_alias=>'PREACTIVE_YN'
,p_column_display_sequence=>6
,p_column_heading=>'Test Data'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_results',
'  where poll_id = :POLL_ID and',
'        preactive_yn = ''Y'''))
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(13918194871015502530)
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8214119917807797317)
,p_query_column_id=>8
,p_column_alias=>'COMMUNITY'
,p_column_display_sequence=>3
,p_column_heading=>'Communities'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_qpoll_comm_invites',
' where poll_id = :POLL_ID'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(13925744282552958233)
,p_name=>'Community Invitations'
,p_parent_plug_id=>wwv_flow_imp.id(232972219291322916)
,p_template=>wwv_flow_imp.id(14588571552078420238)
,p_display_sequence=>110
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    v1.num_responses,',
'    v1.num_requests,',
'    v1.invite_date,',
'    case when v1.num_requests = 0 then null',
'         else to_char((v1.num_responses/v1.num_requests) * 100,''999G999G999G990'')||''%''',
'         end as pct_responded,',
'    ''<a href="f?p=''||:APP_ID||'':16:''||:APP_SESSION||'':::RIR,CIR:IR_POLL_ID,IR_COMM_INVITE_ID:''||:POLL_ID||'',''||comm_invite_id||''">''',
'        ||apex_escape.html(v1.community_name)||''</a>'' community_name,',
'    invite_method',
'from',
'(',
'    select ID comm_invite_id,',
'           community_name,',
'           (select count(unique(r.respondent_id)) ',
'              from eba_qpoll_results r,',
'                   eba_qpoll_invites i',
'             where r.poll_id = :POLL_ID',
'               and r.IS_VALID_YN = ''Y''',
'               and i.comm_invite_id = c.id',
'               and r.respondent_id = i.respondent_id ) num_responses,',
'           (select count(unique respondent_email)',
'              from eba_qpoll_invites ',
'             where comm_invite_id = c.id) num_requests,',
'           created invite_date,',
'           initcap(invite_method) invite_method',
'      from eba_qpoll_comm_invites c',
'     where poll_id = :POLL_ID',
'       and community_name is not null',
') v1',
'order by v1.invite_date desc nulls last, upper(v1.community_name)'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_comm_invites ',
' where poll_id = :POLL_ID',
'   and community_name is not null'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(14588580241300420261)
,p_query_num_rows=>10000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'no invitations found'
,p_query_row_count_max=>10000
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13925744771643958277)
,p_query_column_id=>1
,p_column_alias=>'NUM_RESPONSES'
,p_column_display_sequence=>5
,p_column_heading=>'Responses'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13925744869225958277)
,p_query_column_id=>2
,p_column_alias=>'NUM_REQUESTS'
,p_column_display_sequence=>4
,p_column_heading=>'Invitations'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13930134369667646868)
,p_query_column_id=>3
,p_column_alias=>'INVITE_DATE'
,p_column_display_sequence=>1
,p_column_heading=>'Sent'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13925744990055958277)
,p_query_column_id=>4
,p_column_alias=>'PCT_RESPONDED'
,p_column_display_sequence=>6
,p_column_heading=>'Response Rate'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13925745291297958277)
,p_query_column_id=>5
,p_column_alias=>'COMMUNITY_NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Community'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14033620765580914515)
,p_query_column_id=>6
,p_column_alias=>'INVITE_METHOD'
,p_column_display_sequence=>3
,p_column_heading=>'Method'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_named_lov=>wwv_flow_imp.id(13992024290177653451)
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(14033607372223574622)
,p_name=>'Individual Invitations'
,p_parent_plug_id=>wwv_flow_imp.id(232972219291322916)
,p_template=>wwv_flow_imp.id(14588571552078420238)
,p_display_sequence=>120
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--inline:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''<a href="''||apex_util.prepare_url(''f?p=''||:APP_ID||'':16:''||:APP_SESSION||'':::RIR,CIR:IR_POLL_ID,IR_INVITE_ID:''||:POLL_ID||'',''||i.id)',
'        ||''">''||apex_escape.html(i.respondent_email)||''</a>'' invitee,',
'    nvl((select ''Yes'' ',
'         from eba_qpoll_results r',
'         where r.poll_id = :POLL_ID',
'             and r.IS_VALID_YN = ''Y''',
'             and r.respondent_id = i.respondent_id ),''No'') responded,',
'    c.created invite_date,',
'    initcap(c.invite_method) invite_method',
'from eba_qpoll_comm_invites c,',
'    eba_qpoll_invites i',
'where c.poll_id = :POLL_ID',
'    and c.id = i.comm_invite_id',
'    and c.community_name is null',
'order by c.created desc, upper(i.respondent_email)'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_comm_invites ',
' where poll_id = :POLL_ID',
'   and community_name is null'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(14588580241300420261)
,p_query_num_rows=>10000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no invitations found'
,p_query_num_rows_type=>'0'
,p_query_row_count_max=>10000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14033608692774613224)
,p_query_column_id=>1
,p_column_alias=>'INVITEE'
,p_column_display_sequence=>2
,p_column_heading=>'Invitee'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14033608782006613225)
,p_query_column_id=>2
,p_column_alias=>'RESPONDED'
,p_column_display_sequence=>4
,p_column_heading=>'Responded'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P100_ANONYMOUS_YN'
,p_display_when_condition2=>'N'
,p_lov_show_nulls=>'YES'
,p_derived_column=>'N'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14033607587487574638)
,p_query_column_id=>3
,p_column_alias=>'INVITE_DATE'
,p_column_display_sequence=>1
,p_column_heading=>'Sent'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'NO'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14033621089075918872)
,p_query_column_id=>4
,p_column_alias=>'INVITE_METHOD'
,p_column_display_sequence=>3
,p_column_heading=>'Method'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_named_lov=>wwv_flow_imp.id(13992024290177653451)
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(14033609169761621255)
,p_name=>'Not Invited'
,p_parent_plug_id=>wwv_flow_imp.id(232972219291322916)
,p_template=>wwv_flow_imp.id(14588571552078420238)
,p_display_sequence=>130
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select email,',
'       created',
'  from eba_qpoll_results',
' where poll_id = :POLL_ID',
'   and IS_VALID_YN = ''Y''',
'   and respondent_id not in (select i.respondent_id',
'                               from eba_qpoll_comm_invites c,',
'                                    eba_qpoll_invites i',
'                              where c.poll_id = :POLL_ID',
'                                and c.id = i.comm_invite_id)',
'order by created desc, upper(email)'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_results',
' where poll_id = :POLL_ID',
'   and IS_VALID_YN = ''Y''',
'   and respondent_id not in (select i.respondent_id',
'                               from eba_qpoll_comm_invites c,',
'                                    eba_qpoll_invites i',
'                              where c.poll_id = :POLL_ID',
'                                and c.id = i.comm_invite_id)'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(14588580241300420261)
,p_query_num_rows=>10000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'no invitations found'
,p_query_row_count_max=>10000
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14033610484123647615)
,p_query_column_id=>1
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>1
,p_column_heading=>'Respondent'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14033610579499647615)
,p_query_column_id=>2
,p_column_alias=>'CREATED'
,p_column_display_sequence=>2
,p_column_heading=>'Responded'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28397379159988558827)
,p_plug_name=>'Published!'
,p_parent_plug_id=>wwv_flow_imp.id(232972219291322916)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--success'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14588560922544420208)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<p>Now that your poll has been published, you can send invitations to pre-defined communities and/or individuals using the Invite button on the right.</p>'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'REQUEST_EQUALS_CONDITION'
,p_plug_display_when_condition=>'NEW'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28432426512293594595)
,p_plug_name=>'No Invitations'
,p_parent_plug_id=>wwv_flow_imp.id(232972219291322916)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14588560922544420208)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<p>Your poll is Invite Only but you have not invited anyone to take it.  Use the Invite button on the right to send invitations.</p>'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_qpoll_polls',
' where id = :POLL_ID',
'   and invite_only_yn = ''Y''',
'   and status_id = 3',
'   and not exists (select 1',
'                     from eba_qpoll_comm_invites',
'                    where poll_id = :POLL_ID)',
'   and nvl(:REQUEST,''OLD'') != ''NEW'''))
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(31645732354619838237)
,p_name=>'Sections'
,p_region_name=>'sections_report'
,p_parent_plug_id=>wwv_flow_imp.id(232972219291322916)
,p_template=>wwv_flow_imp.id(14588571552078420238)
,p_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--inline:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id, title, section_text, CREATED, display_sequence sequence',
'from EBA_QPOLL_SECTIONS',
'where POLL_ID = :POLL_ID',
'order by display_sequence, title'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from EBA_QPOLL_SECTIONS',
' where POLL_ID = :POLL_ID'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(14588580241300420261)
,p_query_num_rows=>22
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'No sections have been defined for this poll yet.'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18690922715500780071)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'id'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18690923116465780072)
,p_query_column_id=>2
,p_column_alias=>'TITLE'
,p_column_display_sequence=>2
,p_column_heading=>'Title'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:38:P38_ID:#ID#'
,p_column_linktext=>'#TITLE#'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18690923480542780072)
,p_query_column_id=>3
,p_column_alias=>'SECTION_TEXT'
,p_column_display_sequence=>3
,p_column_heading=>'Section Text'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18690923915853780073)
,p_query_column_id=>4
,p_column_alias=>'CREATED'
,p_column_display_sequence=>4
,p_column_heading=>'Created'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_lov_show_nulls=>'NO'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18690924269219780073)
,p_query_column_id=>5
,p_column_alias=>'SEQUENCE'
,p_column_display_sequence=>5
,p_column_heading=>'Sequence'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(32476568787843843795)
,p_name=>'Questions'
,p_region_name=>'questions_report'
,p_parent_plug_id=>wwv_flow_imp.id(232972219291322916)
,p_template=>wwv_flow_imp.id(14588571552078420238)
,p_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    q.ID,',
'    s.title,',
'    q.QUESTION,',
'    q.CREATED,',
'    q.UPDATED,',
'    q.display_sequence, ',
'    q.mandatory_yn,',
'    case when q.QUESTION_TYPE in (''TEXTAREA'',''TEXT'') then null',
'         else decode(USE_CUSTOM_ANSWERS_YN,',
'           ''N'', a.answer_01||',
'                decode(a.answer_02,null,null,'', ''||a.answer_02)||',
'                decode(a.answer_03,null,null,'', ''||a.answer_03)||',
'                decode(a.answer_04,null,null,'', ''||a.answer_04)||',
'                decode(a.answer_05,null,null,'', ''||a.answer_05)||',
'                decode(a.answer_06,null,null,'', ''||a.answer_06)||',
'                decode(a.answer_07,null,null,'', ''||a.answer_07)||',
'                decode(a.answer_08,null,null,'', ''||a.answer_08)||',
'                decode(a.answer_09,null,null,'', ''||a.answer_09)||',
'                decode(a.answer_10,null,null,'', ''||a.answer_10)||',
'                decode(a.answer_11,null,null,'', ''||a.answer_11)||',
'                decode(a.answer_12,null,null,'', ''||a.answer_12),',
'           q.answer_01||',
'                decode(q.answer_02,null,null,'', ''||q.answer_02)||',
'                decode(q.answer_03,null,null,'', ''||q.answer_03)||',
'                decode(q.answer_04,null,null,'', ''||q.answer_04)||',
'                decode(q.answer_05,null,null,'', ''||q.answer_05)||',
'                decode(q.answer_06,null,null,'', ''||q.answer_06)||',
'                decode(q.answer_07,null,null,'', ''||q.answer_07)||',
'                decode(q.answer_08,null,null,'', ''||q.answer_08)||',
'                decode(q.answer_09,null,null,'', ''||q.answer_09)||',
'                decode(q.answer_10,null,null,'', ''||q.answer_10)||',
'                decode(q.answer_11,null,null,'', ''||q.answer_11)||',
'                decode(q.answer_12,null,null,'', ''||q.answer_12)) end answers,',
'    case when p.POLL_OR_QUIZ = ''Q'' and question_type = ''CHECKBOX''',
'         then eba_qpoll_quiz.delim_answers_disp(q.correct_answer)',
'         else q.correct_answer',
'         end correct_answer,',
'    decode(q.QUESTION_TYPE,',
'       ''RADIO_GROUP'',''Pick One'',',
'       ''CHECKBOX'',''Pick Many'',',
'       ''PICK_TWO'',''Pick Two'',',
'       ''ALLOCATION'',''Allocate $100'',',
'       ''STACK'',''Stack Rank'',',
'       ''TEXTAREA'',''Free form text'',',
'       ''TEXT'',''Text field'',',
'       ''Canned Answers'') question_type,',
'     USE_CUSTOM_ANSWERS_YN ',
'from eba_qpoll_polls p,',
'     EBA_QPOLL_QUESTIONS q,',
'     EBA_QPOLL_CANNED_ANSWERS a,',
'     eba_qpoll_sections s',
'where p.id = :POLL_ID and',
'     p.id = q.POLL_ID and',
'     q.question_type = a.code(+) and',
'     q.section_id = s.id (+)',
'order by s.display_sequence, s.title nulls last, q.display_sequence'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from EBA_QPOLL_QUESTIONS',
' where POLL_ID = :POLL_ID'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(14588580241300420261)
,p_query_num_rows=>20
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'No questions.'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_query_asc_image=>'apex/builder/dup.gif'
,p_query_asc_image_attr=>'width="16" height="16" alt="" '
,p_query_desc_image=>'apex/builder/ddown.gif'
,p_query_desc_image_attr=>'width="16" height="16" alt="" '
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-17'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18690724815895768738)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18690725138804768739)
,p_query_column_id=>2
,p_column_alias=>'TITLE'
,p_column_display_sequence=>3
,p_column_heading=>'Section'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_condition=>'P100_USE_SECTIONS_YN'
,p_display_when_condition2=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18690725596551768740)
,p_query_column_id=>3
,p_column_alias=>'QUESTION'
,p_column_display_sequence=>4
,p_column_heading=>'Question'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:88:&SESSION.::&DEBUG.:RP,88:P88_ID,P88_POLL_ID:#ID#,&POLL_ID.'
,p_column_linktext=>'#QUESTION#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18690725999641768740)
,p_query_column_id=>4
,p_column_alias=>'CREATED'
,p_column_display_sequence=>6
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18690726350465768741)
,p_query_column_id=>5
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>7
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18690726727346768742)
,p_query_column_id=>6
,p_column_alias=>'DISPLAY_SEQUENCE'
,p_column_display_sequence=>2
,p_column_heading=>'Sequence'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18690727222859768743)
,p_query_column_id=>7
,p_column_alias=>'MANDATORY_YN'
,p_column_display_sequence=>10
,p_column_heading=>'Mandatory?'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_polls',
' where id = :POLL_ID',
'   and POLL_OR_QUIZ = ''P'''))
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(16062633205485942356)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18690727926312768744)
,p_query_column_id=>8
,p_column_alias=>'ANSWERS'
,p_column_display_sequence=>8
,p_column_heading=>'Answers'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18690728394585768745)
,p_query_column_id=>9
,p_column_alias=>'CORRECT_ANSWER'
,p_column_display_sequence=>9
,p_column_heading=>'Correct Answer'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_polls',
' where id = :POLL_ID',
'   and POLL_OR_QUIZ = ''Q'''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18690728735447768746)
,p_query_column_id=>10
,p_column_alias=>'QUESTION_TYPE'
,p_column_display_sequence=>5
,p_column_heading=>'Type'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(18690729145952768747)
,p_query_column_id=>11
,p_column_alias=>'USE_CUSTOM_ANSWERS_YN'
,p_column_display_sequence=>11
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(232972630106322920)
,p_plug_name=>'Right Content'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14588562352722420217)
,p_plug_display_sequence=>150
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>2
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(232972494120322918)
,p_plug_name=>'Menu'
,p_region_name=>'actions'
,p_parent_plug_id=>wwv_flow_imp.id(232972630106322920)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14588562352722420217)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_list_id=>wwv_flow_imp.id(254345566503948421)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(15088899616287086431)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13863086886144886880)
,p_plug_name=>'Side Buttons'
,p_parent_plug_id=>wwv_flow_imp.id(232972630106322920)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14588562352722420217)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13932677669065044734)
,p_plug_name=>'Summary'
,p_region_name=>'summary'
,p_parent_plug_id=>wwv_flow_imp.id(232972630106322920)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(14588571552078420238)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_comm_invites',
' where poll_id = :POLL_ID',
'union',
'select 1',
'  from eba_qpoll_results',
' where poll_id = :POLL_ID',
'   and nvl(is_valid_yn,''Y'') = ''Y''',
'union',
'select 1',
'  from eba_qpoll_results',
' where poll_id = :POLL_ID',
'   and nvl(is_valid_yn,''Y'') = ''Y''',
'   and preactive_yn = ''Y''',
'   and eba_qpoll.get_access_role (',
'           p_app_id   => :APP_ID,',
'           p_username => :APP_USER) in (''CONTRIBUTOR'',''ADMINISTRATOR'')'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(232972732974322921)
,p_name=>'Invites'
,p_region_name=>'invites'
,p_parent_plug_id=>wwv_flow_imp.id(13932677669065044734)
,p_template=>wwv_flow_imp.id(14588562352722420217)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--fixed:t-BadgeList--circular'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c "Unique Invitations"',
'from',
'(',
'select count (unique respondent_id) c',
'  from eba_qpoll_comm_invites c,',
'       eba_qpoll_invites i',
' where c.poll_id = :POLL_ID',
'   and c.id = i.comm_invite_id',
')'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_comm_invites',
' where poll_id = :POLL_ID'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(14588575446979420249)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(232973057648322924)
,p_query_column_id=>1
,p_column_alias=>'Unique Invitations'
,p_column_display_sequence=>1
,p_column_heading=>'Unique Invitations'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:RP,16,RIR,CIR:IR_POLL_ID:&POLL_ID.'
,p_column_linktext=>'#Unique Invitations#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(232973177607322925)
,p_name=>'Results'
,p_region_name=>'results'
,p_parent_plug_id=>wwv_flow_imp.id(13932677669065044734)
,p_template=>wwv_flow_imp.id(14588562352722420217)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--fixed:t-BadgeList--circular'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c "Responses"',
'from',
'(',
'select count(*) c',
'  from EBA_QPOLL_RESULTS ',
' where POLL_ID = :POLL_ID',
'   and nvl(is_valid_yn,''Y'') = ''Y''',
')',
''))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_results',
' where poll_id = :POLL_ID',
'   and nvl(is_valid_yn,''Y'') = ''Y'''))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(14588575446979420249)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(232973286608322926)
,p_query_column_id=>1
,p_column_alias=>'Responses'
,p_column_display_sequence=>1
,p_column_heading=>'Responses'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:66:&SESSION.::&DEBUG.:RP,66:LPOLL_ID:&POLL_ID.'
,p_column_linktext=>'#Responses#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(232973513434322929)
,p_name=>'Response Rate1'
,p_region_name=>'response_rate_a'
,p_parent_plug_id=>wwv_flow_imp.id(13932677669065044734)
,p_template=>wwv_flow_imp.id(14588562352722420217)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--fixed:t-BadgeList--circular'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select round((i.num_responses/i.num_requests) * 100) ||''%'' "Response Rate"',
'from',
'(',
' select',
'        (select count (unique r.respondent_id)',
'           from eba_qpoll_results r,',
'                eba_qpoll_comm_invites c,',
'                eba_qpoll_invites i',
'          where r.poll_id = :POLL_ID',
'            and r.IS_VALID_YN = ''Y''',
'            and c.poll_id = :POLL_ID',
'            and c.id = i.comm_invite_id ',
'            and r.respondent_id = i.respondent_id ) num_responses,',
'        (select count (unique respondent_id)',
'          from eba_qpoll_comm_invites c,',
'               eba_qpoll_invites i',
'         where c.poll_id = :POLL_ID',
'           and c.id = i.comm_invite_id) num_requests',
'    from dual',
') i'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_comm_invites ',
' where poll_id = :POLL_ID',
'   and :P100_ANONYMOUS_YN = ''N'''))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(14588575446979420249)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(232973868269322932)
,p_query_column_id=>1
,p_column_alias=>'Response Rate'
,p_column_display_sequence=>1
,p_column_heading=>'Response Rate'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(232973908239322933)
,p_name=>'Response Rate2'
,p_region_name=>'response_rate_b'
,p_parent_plug_id=>wwv_flow_imp.id(13932677669065044734)
,p_template=>wwv_flow_imp.id(14588571552078420238)
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--fixed:t-BadgeList--circular'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select least(round((i.num_responses/i.num_requests) * 100),100) ||''%'' "Response Rate"',
'from',
'(',
' select',
'        (select count (*)',
'           from eba_qpoll_results r',
'          where r.poll_id = :POLL_ID',
'            and r.IS_VALID_YN = ''Y'' ) num_responses,',
'        (select count (unique respondent_id)',
'          from eba_qpoll_comm_invites c,',
'               eba_qpoll_invites i',
'         where c.poll_id = :POLL_ID',
'           and c.id = i.comm_invite_id) num_requests',
'    from dual',
') i'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_comm_invites ',
' where poll_id = :POLL_ID',
'   and :P100_ANONYMOUS_YN = ''Y'''))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(14588575446979420249)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(232974238414322936)
,p_query_column_id=>1
,p_column_alias=>'Response Rate'
,p_column_display_sequence=>1
,p_column_heading=>'Response Rate'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(232974332619322937)
,p_name=>'Test Data'
,p_region_name=>'test_data'
,p_parent_plug_id=>wwv_flow_imp.id(13932677669065044734)
,p_template=>wwv_flow_imp.id(14588562352722420217)
,p_display_sequence=>80
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--fixed:t-BadgeList--circular'
,p_display_point=>'SUB_REGIONS'
,p_item_display_point=>'BELOW'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    count(*) "Test Responses"',
'from',
'    EBA_QPOLL_RESULTS r',
'where',
'    poll_id = :POLL_ID',
'and nvl(r.is_valid_yn,''Y'') = ''Y''',
'and preactive_yn = ''Y'''))
,p_required_role=>wwv_flow_imp.id(13953080969599690404)
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(14588575446979420249)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(232975581918322949)
,p_query_column_id=>1
,p_column_alias=>'Test Responses'
,p_column_display_sequence=>1
,p_column_heading=>'Test Responses'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(232974788413322941)
,p_name=>'Quiz Average'
,p_region_name=>'quiz_average'
,p_parent_plug_id=>wwv_flow_imp.id(13932677669065044734)
,p_template=>wwv_flow_imp.id(14588571552078420238)
,p_display_sequence=>110
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--fixed:t-BadgeList--circular'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    round(avg(grade),1) ||''%'' "Average Score"',
'from',
'    EBA_QPOLL_RESULTS r',
'where',
'    poll_id = :POLL_ID',
'and nvl(r.is_valid_yn,''Y'') = ''Y'''))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_results',
' where poll_id = :POLL_ID',
'   and :POLL_OR_QUIZ = ''Q'''))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(14588575446979420249)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(232975004306322944)
,p_query_column_id=>1
,p_column_alias=>'Average Score'
,p_column_display_sequence=>1
,p_column_heading=>'Average Score'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(232975177274322945)
,p_name=>'Average Score'
,p_region_name=>'average_score'
,p_parent_plug_id=>wwv_flow_imp.id(13932677669065044734)
,p_template=>wwv_flow_imp.id(14588571552078420238)
,p_display_sequence=>130
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--large:t-BadgeList--fixed:t-BadgeList--circular'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    round(avg(score),1) "Average Score"',
'from',
'    EBA_QPOLL_RESULTS r',
'where',
'    poll_id = :POLL_ID',
'and nvl(r.is_valid_yn,''Y'') = ''Y''',
'and score is not null'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from EBA_QPOLL_QUESTIONS q,',
'       EBA_QPOLL_POLLS p,',
'       EBA_QPOLL_RESULTS r',
'  where q.poll_id = p.id and',
'        p.id = :POLL_ID and',
'        p.score_type in (''A'',''C'') and ',
'        p.enable_score_yn = ''Y'' and',
'        q.enable_score_yn = ''Y'' and',
'        r.poll_id = p.id and',
'        nvl(r.is_valid_yn,''Y'') = ''Y'' and',
'        r.score is not null'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(14588575446979420249)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(232975432428322948)
,p_query_column_id=>1
,p_column_alias=>'Average Score'
,p_column_display_sequence=>1
,p_column_heading=>'Average Score'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29006625102019984551)
,p_plug_name=>'Outstanding Invitations'
,p_region_name=>'oustanding_invitations'
,p_parent_plug_id=>wwv_flow_imp.id(232972630106322920)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(14588571552078420238)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :OUTSTANDING_INVITES = 1 then',
'   sys.htp.p(''<p class="u-tC" style="font-size: 11px"><a href="''||apex_util.prepare_url(''f?p=''||:APP_ID||'':16:''||:APP_SESSION||''::NO:RIR,CIR:IR_HAS_RESPONDED,IR_POLL_ID:No,''||:POLL_ID)||''">''||:OUTSTANDING_INVITES||'' Oustanding Invitation</a></p>'');',
'else',
'   sys.htp.p(''<p class="u-tC" style="font-size: 11px"><a href="''||apex_util.prepare_url(''f?p=''||:APP_ID||'':16:''||:APP_SESSION||''::NO:RIR,CIR:IR_HAS_RESPONDED,IR_POLL_ID:No,''||:POLL_ID)||''">''||:OUTSTANDING_INVITES||'' Oustanding Invitations</a></p>'');',
'end if;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_comm_invites',
' where poll_id = :POLL_ID',
'   and nvl(:OUTSTANDING_INVITES,0) > 0'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13862363587907932362)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(14588574158926420242)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(17588349840095506346)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(14588592018629420306)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_footer=>'&P100_POLL_STATUS.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(254630071599408901)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(232975614490322950)
,p_button_name=>'ADD_SECTION2'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(14588591398189420302)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Section'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:RP,38:P38_POLL_ID:&POLL_ID.'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(254630232914408903)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(254630160238408902)
,p_button_name=>'ADD_QUESTION2'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(14588591398189420302)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Question'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:88:&SESSION.::&DEBUG.:RP,88:P88_POLL_ID:&POLL_ID.'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13953082183389699172)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(232974332619322937)
,p_button_name=>'DELETE_TEST_DATA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(14588591398189420302)
,p_button_image_alt=>'Delete Test Data'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:82:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-trash-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(232972543601322919)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(13863086886144886880)
,p_button_name=>'ACTIONS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--primary:t-Button--iconRight:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(14588591398189420302)
,p_button_image_alt=>'Actions'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'js-menuButton'
,p_icon_css_classes=>'fa-angle-down'
,p_button_cattributes=>'data-menu="actions_menu"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6525449300526331)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(13863086886144886880)
,p_button_name=>'Preview'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(14588591398189420302)
,p_button_image_alt=>'Preview'
,p_button_redirect_url=>'f?p=&APP_ID.:67:&SESSION.::&DEBUG.:67::'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from EBA_QPOLL_POLLS',
' where id = :POLL_ID',
'   and status_id in (1,2)',
'   and exists (select 1 from EBA_QPOLL_QUESTIONS',
'                where POLL_ID = :POLL_ID)'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-eye'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6525598099526332)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(13863086886144886880)
,p_button_name=>'Publish'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(14588591398189420302)
,p_button_image_alt=>'Publish'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5::'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from EBA_QPOLL_POLLS',
' where id = :POLL_ID',
'   and status_id in (1,2)',
'   and exists (select 1 from EBA_QPOLL_QUESTIONS',
'                where POLL_ID = :POLL_ID)'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-box-arrow-out-east'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13930062182992834112)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(13863086886144886880)
,p_button_name=>'INVITE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(14588591398189420302)
,p_button_image_alt=>'Invite'
,p_button_redirect_url=>'f?p=&APP_ID.:72:&SESSION.::&DEBUG.:72:P72_POLL_ID:&POLL_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from EBA_QPOLL_POLLS p',
'where id = :POLL_ID',
'and status_id = 3'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-send'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14029751078030893686)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(13863086886144886880)
,p_button_name=>'REMINDER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(14588591799596420304)
,p_button_image_alt=>'Send Reminders'
,p_button_redirect_url=>'f?p=&APP_ID.:1072:&SESSION.::&DEBUG.:1072:P1072_POLL_ID:&POLL_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 ',
'  from eba_qpoll_polls p,',
'       eba_qpoll_comm_invites c,',
'       eba_qpoll_invites i',
' where p.id = :POLL_ID',
'   and p.status_id = 3',
'   and p.id = c.poll_id',
'   and c.id = i.comm_invite_id',
'   and i.respondent_id not in',
'       (select respondent_id',
'          from eba_qpoll_results',
'         where poll_id = :POLL_ID',
'           and IS_VALID_YN = ''Y'')'))
,p_button_condition_type=>'EXISTS'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13953075690364604841)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(13863086886144886880)
,p_button_name=>'TAKE_POLL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(14588591799596420304)
,p_button_image_alt=>'Take Poll'
,p_button_redirect_url=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.:50::'
,p_grid_new_row=>'Y'
,p_security_scheme=>wwv_flow_imp.id(13920040076556575140)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13953076267935615183)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(13863086886144886880)
,p_button_name=>'UPDATE_RESPONSE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(14588591799596420304)
,p_button_image_alt=>'Update Response'
,p_button_redirect_url=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.:50::'
,p_grid_new_row=>'Y'
,p_security_scheme=>wwv_flow_imp.id(13921393191310071494)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13953077089248650890)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(13863086886144886880)
,p_button_name=>'RESPONSE_HAS_ERRORS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(14588591799596420304)
,p_button_image_alt=>'Response Has Errors'
,p_button_redirect_url=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.:50::'
,p_grid_new_row=>'Y'
,p_security_scheme=>wwv_flow_imp.id(13953076768354630154)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13919069789730565142)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(13863086886144886880)
,p_button_name=>'view_results'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(14588591799596420304)
,p_button_image_alt=>'View Results'
,p_button_redirect_url=>'f?p=&APP_ID.:66:&SESSION.::&DEBUG.:RP,66:LPOLL_ID:&POLL_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from EBA_QPOLL_RESULTS',
'where poll_id = :POLL_ID',
'  and nvl(is_valid_yn,''Y'') = ''Y'''))
,p_button_condition_type=>'EXISTS'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18690729531023768747)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(32476568787843843795)
,p_button_name=>'ADD_QUESTION'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(14588591398189420302)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Question'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:88:&SESSION.::&DEBUG.:RP,88:P88_POLL_ID:&POLL_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_qpoll_polls',
' where id = :POLL_ID',
'   and status_id = 4'))
,p_button_condition_type=>'NOT_EXISTS'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14016739869185491246)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(13863098582128970827)
,p_button_name=>'non-respondents'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(14588591272708420298)
,p_button_image_alt=>'Non-Respondents'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:RP,CIR,RIR:IR_POLL_ID,IR_HAS_RESPONDED:&POLL_ID.,No'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_comm_invites',
' where poll_id = :POLL_ID',
'   and nvl(:OUTSTANDING_INVITES,0) > 0'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18690924719096780074)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(31645732354619838237)
,p_button_name=>'ADD_SECTION'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(14588591272708420298)
,p_button_image_alt=>'Add Section'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:38:P38_POLL_ID:&POLL_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_qpoll_polls',
' where id = :POLL_ID',
'   and status_id = 4'))
,p_button_condition_type=>'NOT_EXISTS'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14032870583519226776)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(13925744282552958233)
,p_button_name=>'VIEW_INVITATIONS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(14588591272708420298)
,p_button_image_alt=>'View Community Invitations'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:16:&SESSION.:COMM:&DEBUG.:RIR:IR_POLL_ID:&POLL_ID.'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-17'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14033608080960574643)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(14033607372223574622)
,p_button_name=>'VIEW_INVITATIONS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(14588591272708420298)
,p_button_image_alt=>'View Individual Invitations'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:16:&SESSION.:IND:&DEBUG.:RIR,CIR:IR_POLL_ID:&POLL_ID.'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6525671164526333)
,p_name=>'P100_POLL_STATUS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(13862363587907932362)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13025861935311142020)
,p_name=>'P100_USE_SECTIONS_YN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(32476568787843843795)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28498555433332912844)
,p_name=>'P100_ANONYMOUS_YN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(13863073866210341710)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13932690179744293817)
,p_computation_sequence=>10
,p_computation_item=>'LAST_VIEW'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'&APP_PAGE_ID.'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8226101685721283820)
,p_name=>'Refresh after Deleting Test Data'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(13953082183389699172)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8226101806086283821)
,p_event_id=>wwv_flow_imp.id(8226101685721283820)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'#respondents, #test_data, #quiz_average, #average_score'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4534123506899855873)
,p_name=>'Refresh after questions'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(32476568787843843795)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4534123605417855874)
,p_event_id=>wwv_flow_imp.id(4534123506899855873)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(32476568787843843795)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(567798896957907504)
,p_name=>'Refresh after actions - add question'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#actions_menu'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data.dialogPageId === 88'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(567798915904907505)
,p_event_id=>wwv_flow_imp.id(567798896957907504)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(32476568787843843795)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(567799561600907511)
,p_name=>'Refresh after actions - add section'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#actions_menu'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data.dialogPageId === 38'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
,p_da_event_comment=>'need to add p38 & 48'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(567799746935907513)
,p_event_id=>wwv_flow_imp.id(567799561600907511)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(31645732354619838237)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(567800162893907517)
,p_name=>'Refresh after actions - edit poll'
,p_event_sequence=>60
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#actions_menu'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data.dialogPageId === 48'
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
,p_da_event_comment=>'need to add p38 & 48'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(247683863425047214)
,p_event_id=>wwv_flow_imp.id(567800162893907517)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(232971301672322907)
,p_name=>'Refresh after respondents'
,p_event_sequence=>70
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(13863098582128970827)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(232971452586322908)
,p_event_id=>wwv_flow_imp.id(232971301672322907)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(13863098582128970827)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4534123269429855871)
,p_name=>'Refresh after sections'
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(31645732354619838237)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4534123382821855872)
,p_event_id=>wwv_flow_imp.id(4534123269429855871)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(31645732354619838237)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4534123707257855875)
,p_event_id=>wwv_flow_imp.id(4534123269429855871)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(32476568787843843795)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(103629456793344650)
,p_name=>'when question added from no questions yet'
,p_event_sequence=>90
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(254630160238408902)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401765652455174901)
,p_event_id=>wwv_flow_imp.id(103629456793344650)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(32476568787843843795)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401765781783174902)
,p_event_id=>wwv_flow_imp.id(103629456793344650)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(254630160238408902)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6525712953526334)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Details'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'select status_id, use_sections_yn, anonymous_yn',
'  from EBA_QPOLL_POLLS',
' where id = :POLL_ID',
') loop',
'   :P100_POLL_STATUS     := case c1.status_id when 1 then ''Being Authored''',
'                                              when 2 then ''Testing''',
'                                              when 3 then ''Published''',
'                                              when 4 then ''Completed'' end;',
'   :P100_USE_SECTIONS_YN := c1.use_sections_yn;',
'   :P100_ANONYMOUS_YN    := c1.anonymous_yn;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
