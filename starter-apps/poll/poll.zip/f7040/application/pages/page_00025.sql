prompt --application/pages/page_00025
begin
--   Manifest
--     PAGE: 00025
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>25
,p_name=>'View Email'
,p_alias=>'VIEW-EMAIL'
,p_page_mode=>'MODAL'
,p_step_title=>'View Email'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2101883943284197310
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(129185598036949069)
,p_plug_name=>'Preview Email'
,p_static_id=>'preview-email'
,p_parent_plug_id=>wwv_flow_imp.id(14444279327923543271)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_poll_url   varchar2(4000);',
'   l_body       clob;',
'   l_subject    varchar2(4000);',
'   l_html_body  clob;',
'   l_text_body  clob;',
'begin',
'',
'l_poll_url := ''<a href="#">''||apex_escape.html(:POLL_NAME)||''</a>'';',
'                                                     ',
'l_body := replace(:P72_INVITE_BODY,''#POLL_LINK#'',l_poll_url);',
'   ',
'for c1 in (',
'    select',
'        sent_time,',
'        subject,',
'        apex_escape.html(text_body) message',
'    from eba_qpoll_emails',
'    where id = :P25_EMAIL_ID',
') loop',
'',
'   apex_mail.prepare_template (',
'      p_static_id       => ''INVITE'',',
'      p_placeholders    => ''{'' || ',
'                           ''    "SUBJECT":''           || apex_json.stringify( c1.subject ) || ',
'                           ''   ,"APPLICATION_TITLE":'' || apex_json.stringify( apex_escape.html(:APPLICATION_TITLE) ) || ',
'                           ''   ,"OPT_OUT_TEXT":''      || apex_json.stringify( apex_lang.message(''OPT_OUT_TEXT'', ',
'                                                                              :APP_PATH || ''/f?p='' || :APP_ID || '':optout'',',
'                                                                              apex_escape.html(:APPLICATION_TITLE)) ) || ',
'                           ''   ,"BODY":''  || apex_json.stringify( replace(c1.message,''#POLL_LINK#'',''<a href="#">''||:POLL_NAME||''</a>'') ) || ',
'                           ''}'' , ',
'      p_application_id  => :APP_ID,',
'      p_subject         => l_subject,',
'      p_html            => l_html_body,',
'      p_text            => l_text_body );',
'      ',
'   return l_html_body;',
'   ',
'end loop;',
'      ',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P25_EMAIL_ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14444279327923543271)
,p_plug_name=>'View Email'
,p_static_id=>'view-email'
,p_region_name=>'view_email'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(539744410652839291)
,p_name=>'P25_EMAIL_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(14444279327923543271)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
