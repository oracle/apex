prompt --application/pages/page_00017
begin
--   Manifest
--     PAGE: 00017
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>17
,p_name=>'Detailed Results'
,p_alias=>'DETAILED-RESULTS'
,p_step_title=>'Detailed Results'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(13937152132781279884)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14381235616393773798)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>5
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(17605462679702233991)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21299288316884833840)
,p_plug_name=>'Current Poll'
,p_static_id=>'current-poll'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42905129185327007288)
,p_plug_name=>'Result Details'
,p_static_id=>'result-details'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2102002977963900996
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.id result_id,',
'      case when p.anonymous_yn = ''Y'' then ''anonymous'' else lower(r.email) end respondent,',
'      (select distinct c.community_name',
'         from eba_qpoll_comm_invites c',
'        where p.id = c.poll_id',
'          and exists ( select 1',
'                         from eba_qpoll_invites i ',
'                        where c.id = i.comm_invite_id',
'                          and r.respondent_id = i.respondent_id) ) community,',
'      r.updated submission_date,',
'      d.answer_01||',
'        decode(d.answer_02,null,null,'', ''||d.answer_02)||',
'        decode(d.answer_03,null,null,'', ''||d.answer_03)||',
'        decode(d.answer_04,null,null,'', ''||d.answer_04)||',
'        decode(d.answer_05,null,null,'', ''||d.answer_05)||',
'        decode(d.answer_06,null,null,'', ''||d.answer_06)||',
'        decode(d.answer_07,null,null,'', ''||d.answer_07)||',
'        decode(d.answer_08,null,null,'', ''||d.answer_08)||',
'        decode(d.answer_09,null,null,'', ''||d.answer_09)||',
'        decode(d.answer_10,null,null,'', ''||d.answer_10)||',
'        decode(d.answer_11,null,null,'', ''||d.answer_11)||',
'        decode(d.answer_12,null,null,'', ''||d.answer_12) answer1,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2,',
'            EBA_QPOLL_QUESTIONS q2',
'      where r.id = d2.result_id ',
'        and q2.id = d2.question_id',
'        and q2.poll_id = p.id',
'        and d2.display_sequence = 2) answer2,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2,',
'            EBA_QPOLL_QUESTIONS q2',
'      where r.id = d2.result_id ',
'        and q2.id = d2.question_id',
'        and q2.poll_id = p.id',
'        and d2.display_sequence = 3) answer3,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2,',
'            EBA_QPOLL_QUESTIONS q2',
'      where r.id = d2.result_id ',
'        and q2.id = d2.question_id',
'        and q2.poll_id = p.id',
'        and d2.display_sequence = 4) answer4,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2,',
'            EBA_QPOLL_QUESTIONS q2',
'      where r.id = d2.result_id ',
'        and q2.id = d2.question_id',
'        and q2.poll_id = p.id',
'        and d2.display_sequence = 5) answer5,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2,',
'            EBA_QPOLL_QUESTIONS q2',
'      where r.id = d2.result_id ',
'        and q2.id = d2.question_id',
'        and q2.poll_id = p.id',
'        and d2.display_sequence = 6) answer6,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2,',
'            EBA_QPOLL_QUESTIONS q2',
'      where r.id = d2.result_id ',
'        and q2.id = d2.question_id',
'        and q2.poll_id = p.id',
'        and d2.display_sequence = 7) answer7,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2,',
'            EBA_QPOLL_QUESTIONS q2',
'      where r.id = d2.result_id ',
'        and q2.id = d2.question_id',
'        and q2.poll_id = p.id',
'        and d2.display_sequence = 8) answer8,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2,',
'            EBA_QPOLL_QUESTIONS q2',
'      where r.id = d2.result_id ',
'        and q2.id = d2.question_id',
'        and q2.poll_id = p.id',
'        and d2.display_sequence = 9) answer9,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2,',
'            EBA_QPOLL_QUESTIONS q2',
'      where r.id = d2.result_id ',
'        and q2.id = d2.question_id',
'        and q2.poll_id = p.id',
'        and d2.display_sequence = 10) answer10,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2,',
'            EBA_QPOLL_QUESTIONS q2',
'      where r.id = d2.result_id ',
'        and q2.id = d2.question_id',
'        and q2.poll_id = p.id',
'        and d2.display_sequence = 11) answer11,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2,',
'            EBA_QPOLL_QUESTIONS q2',
'      where r.id = d2.result_id ',
'        and q2.id = d2.question_id',
'        and q2.poll_id = p.id',
'        and d2.display_sequence = 12) answer12,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2,',
'            EBA_QPOLL_QUESTIONS q2',
'      where r.id = d2.result_id ',
'        and q2.id = d2.question_id',
'        and q2.poll_id = p.id',
'        and d2.display_sequence = 13) answer13,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2,',
'            EBA_QPOLL_QUESTIONS q2',
'      where r.id = d2.result_id ',
'        and q2.id = d2.question_id',
'        and q2.poll_id = p.id',
'        and d2.display_sequence = 14) answer14,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2,',
'            EBA_QPOLL_QUESTIONS q2',
'      where r.id = d2.result_id ',
'        and q2.id = d2.question_id',
'        and q2.poll_id = p.id',
'        and d2.display_sequence = 15) answer15,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2,',
'            EBA_QPOLL_QUESTIONS q2',
'      where r.id = d2.result_id ',
'        and q2.id = d2.question_id',
'        and q2.poll_id = p.id',
'        and d2.display_sequence = 16) answer16,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2,',
'            EBA_QPOLL_QUESTIONS q2',
'      where r.id = d2.result_id ',
'        and q2.id = d2.question_id',
'        and q2.poll_id = p.id',
'        and d2.display_sequence = 17) answer17,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2,',
'            EBA_QPOLL_QUESTIONS q2',
'      where r.id = d2.result_id ',
'        and q2.id = d2.question_id',
'        and q2.poll_id = p.id',
'        and d2.display_sequence = 18) answer18,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2,',
'            EBA_QPOLL_QUESTIONS q2',
'      where r.id = d2.result_id ',
'        and q2.id = d2.question_id',
'        and q2.poll_id = p.id',
'        and d2.display_sequence = 19) answer19,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2,',
'            EBA_QPOLL_QUESTIONS q2',
'      where r.id = d2.result_id ',
'        and q2.id = d2.question_id',
'        and q2.poll_id = p.id',
'        and d2.display_sequence = 20) answer20',
'  from EBA_QPOLL_POLLS p,',
'       EBA_QPOLL_RESULTS r,',
'       EBA_QPOLL_RESULT_DETAILS d,',
'       EBA_QPOLL_QUESTIONS q',
' where p.id                     = r.poll_id',
'   and r.id                     = d.result_id ',
'   and q.id                     = d.question_id',
'   and q.poll_id                = r.poll_id',
'   and p.id                     = :POLL_ID',
'   and d.display_sequence       = 1',
'   and nvl(r.is_valid_yn,''Y'')   = ''Y'' ',
'   and (   p.status_id = 4 or p.status_id = 3 ',
'        or (    p.status_id = 2 ',
'            and eba_qpoll.get_access_role (',
'             p_app_id   => :APP_ID,',
'             p_username => :APP_USER) in (''CONTRIBUTOR'',''ADMINISTRATOR'') ) )',
'   and (   eba_qpoll.get_access_role (',
'               p_app_id   => :APP_ID,',
'               p_username => :APP_USER) != ''NONE''',
'       or (     p.all_view_results_yn = ''Y'' ',
'            and exists ',
'                (select 1',
'                   from eba_qpoll_comm_invites c,',
'                        eba_qpoll_invites i',
'                  where c.poll_id = p.id',
'                    and c.id = i.comm_invite_id',
'                    and upper(respondent_email) = :APP_USER) ) )',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(42905129282529007288)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_pivot=>'N'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'Y'
,p_internal_uid=>42888016442922279643
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378212172530674512)
,p_db_column_name=>'ANSWER1'
,p_display_order=>43
,p_column_identifier=>'AH'
,p_column_label=>'&P17_Q1.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q1'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378216986334674521)
,p_db_column_name=>'ANSWER10'
,p_display_order=>133
,p_column_identifier=>'AQ'
,p_column_label=>'&P17_Q10.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q10'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378217341826674522)
,p_db_column_name=>'ANSWER11'
,p_display_order=>143
,p_column_identifier=>'AR'
,p_column_label=>'&P17_Q11.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q11'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378217747325674522)
,p_db_column_name=>'ANSWER12'
,p_display_order=>153
,p_column_identifier=>'AS'
,p_column_label=>'&P17_Q12.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q12'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378218234529674523)
,p_db_column_name=>'ANSWER13'
,p_display_order=>163
,p_column_identifier=>'AT'
,p_column_label=>'&P17_Q13.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q13'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378218555771674524)
,p_db_column_name=>'ANSWER14'
,p_display_order=>173
,p_column_identifier=>'AU'
,p_column_label=>'&P17_Q14.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q14'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378219020488674524)
,p_db_column_name=>'ANSWER15'
,p_display_order=>183
,p_column_identifier=>'AV'
,p_column_label=>'&P17_Q15.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q15'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378219438722674525)
,p_db_column_name=>'ANSWER16'
,p_display_order=>193
,p_column_identifier=>'AW'
,p_column_label=>'&P17_Q16.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q16'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378219778349674526)
,p_db_column_name=>'ANSWER17'
,p_display_order=>203
,p_column_identifier=>'AX'
,p_column_label=>'&P17_Q17.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q17'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378220154787674527)
,p_db_column_name=>'ANSWER18'
,p_display_order=>213
,p_column_identifier=>'AY'
,p_column_label=>'&P17_Q18.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q18'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378220625905674527)
,p_db_column_name=>'ANSWER19'
,p_display_order=>223
,p_column_identifier=>'AZ'
,p_column_label=>'&P17_Q19.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q19'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378212571310674513)
,p_db_column_name=>'ANSWER2'
,p_display_order=>53
,p_column_identifier=>'AI'
,p_column_label=>'&P17_Q2.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q2'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378221019914674528)
,p_db_column_name=>'ANSWER20'
,p_display_order=>233
,p_column_identifier=>'BA'
,p_column_label=>'&P17_Q20.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q20'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378212969876674514)
,p_db_column_name=>'ANSWER3'
,p_display_order=>63
,p_column_identifier=>'AJ'
,p_column_label=>'&P17_Q3.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q3'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378213421106674514)
,p_db_column_name=>'ANSWER4'
,p_display_order=>73
,p_column_identifier=>'AK'
,p_column_label=>'&P17_Q4.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q4'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378213748136674515)
,p_db_column_name=>'ANSWER5'
,p_display_order=>83
,p_column_identifier=>'AL'
,p_column_label=>'&P17_Q5.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q5'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378214213462674516)
,p_db_column_name=>'ANSWER6'
,p_display_order=>93
,p_column_identifier=>'AM'
,p_column_label=>'&P17_Q6.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q6'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378215766025674518)
,p_db_column_name=>'ANSWER7'
,p_display_order=>103
,p_column_identifier=>'AN'
,p_column_label=>'&P17_Q7.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q7'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378216139682674520)
,p_db_column_name=>'ANSWER8'
,p_display_order=>113
,p_column_identifier=>'AO'
,p_column_label=>'&P17_Q8.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q8'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378216571946674521)
,p_db_column_name=>'ANSWER9'
,p_display_order=>123
,p_column_identifier=>'AP'
,p_column_label=>'&P17_Q9.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q9'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378214552738674516)
,p_db_column_name=>'COMMUNITY'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Community'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378215000662674517)
,p_db_column_name=>'RESPONDENT'
,p_display_order=>12
,p_column_identifier=>'AB'
,p_column_label=>'Respondent'
,p_column_link=>'f?p=&APP_ID.:73:&SESSION.::&DEBUG.:RP,73:P73_RESULT_ID:#RESULT_ID#'
,p_column_linktext=>'#RESPONDENT#'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(271746871772136586)
,p_db_column_name=>'RESULT_ID'
,p_display_order=>243
,p_column_identifier=>'BB'
,p_column_label=>'Result Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(378215425522674517)
,p_db_column_name=>'SUBMISSION_DATE'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Submission Date'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(42905132158465014703)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3611085'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'RESPONDENT:ANSWER1:ANSWER2:ANSWER3:ANSWER4:ANSWER5:ANSWER6:ANSWER7:ANSWER8:ANSWER9:ANSWER10:ANSWER11:ANSWER12:ANSWER13:ANSWER14:ANSWER15:ANSWER16:ANSWER17:ANSWER18:ANSWER19:ANSWER20:RESULT_ID'
,p_sort_column_1=>'POLL_ID'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'RESPONDENT'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'QUESTION_DISPLAY_SEQ'
,p_sort_direction_3=>'ASC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(378241697652741933)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(14381235616393773798)
,p_button_name=>'BACK'
,p_static_id=>'back'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2350584059425431644
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Back'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:&LAST_VIEW.:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-double-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(394766810533059569)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(14381235616393773798)
,p_button_name=>'cross_poll'
,p_static_id=>'cross-poll'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Alternate View'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:41:&SESSION.:CIR,RIR:&DEBUG.:RP,41,CIR,RIR:IR_POLL_ID:&POLL_ID.'
,p_icon_css_classes=>'fa-chevron-right'
,p_security_scheme=>wwv_flow_imp.id(165977202507131556)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(394767155071063272)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(14381235616393773798)
,p_button_name=>'REMOVE_RESULTS'
,p_static_id=>'remove-results'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Remove Results'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:40:&SESSION.:CIR,RIR:&DEBUG.:RP::'
,p_security_scheme=>wwv_flow_imp.id(165977202507131556)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(378221757644674532)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(42905129185327007288)
,p_button_name=>'RESET_REPORT'
,p_static_id=>'reset-report'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&SESSION.::&DEBUG.:RP,&APP_PAGE_ID.,RIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378203598395674488)
,p_name=>'P17_POLL_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_prompt=>'Poll'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select poll_name from eba_qpoll_polls',
' where id = :POLL_ID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378203888972674497)
,p_name=>'P17_Q1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378207449756674500)
,p_name=>'P17_Q10'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378207875584674500)
,p_name=>'P17_Q11'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378208319727674500)
,p_name=>'P17_Q12'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378208733507674501)
,p_name=>'P17_Q13'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378209133338674501)
,p_name=>'P17_Q14'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378209449201674501)
,p_name=>'P17_Q15'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378209936880674501)
,p_name=>'P17_Q16'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378210242336674502)
,p_name=>'P17_Q17'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378210685010674502)
,p_name=>'P17_Q18'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378211081673674502)
,p_name=>'P17_Q19'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378204275662674497)
,p_name=>'P17_Q2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378211514493674503)
,p_name=>'P17_Q20'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378204703468674497)
,p_name=>'P17_Q3'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378205065300674498)
,p_name=>'P17_Q4'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378205530695674498)
,p_name=>'P17_Q5'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378205936285674498)
,p_name=>'P17_Q6'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378206300578674499)
,p_name=>'P17_Q7'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378206732645674499)
,p_name=>'P17_Q8'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378207046122674499)
,p_name=>'P17_Q9'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(21299288316884833840)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(271747020700136587)
,p_name=>'after edit respondent'
,p_static_id=>'after-edit-respondent'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(42905129185327007288)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(271747109979136588)
,p_event_id=>wwv_flow_imp.id(271747020700136587)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(42905129185327007288)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(271746720974136584)
,p_name=>'on close'
,p_static_id=>'on-close'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(394767155071063272)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(271746799462136585)
,p_event_id=>wwv_flow_imp.id(271746720974136584)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(42905129185327007288)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(378222177862674538)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'load questions'
,p_static_id=>'load-questions'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_nbr  number := 1;',
'begin',
'',
':P17_Q1 := null;',
':P17_Q2 := null;',
':P17_Q3 := null;',
':P17_Q4 := null;     ',
':P17_Q5 := null;   ',
':P17_Q6 := null;    ',
':P17_Q7 := null;    ',
':P17_Q8 := null;   ',
':P17_Q9 := null; ',
':P17_Q10 := null;',
':P17_Q11 := null;',
':P17_Q12 := null;',
':P17_Q13 := null;',
':P17_Q14 := null;      ',
':P17_Q15 := null;      ',
':P17_Q16 := null; ',
':P17_Q17 := null;   ',
':P17_Q18 := null;     ',
':P17_Q19 := null; ',
':P17_Q20 := null;',
'',
'for c1 in (',
'   select question',
'     from EBA_QPOLL_QUESTIONS',
'    where :POLL_ID = poll_id',
'    order by display_sequence',
') loop',
'   if l_nbr = 1 then',
'      :P17_Q1 := apex_escape.html(c1.question);',
'   elsif l_nbr = 2 then',
'      :P17_Q2 := apex_escape.html(c1.question);',
'   elsif l_nbr = 3 then',
'      :P17_Q3 := apex_escape.html(c1.question);',
'   elsif l_nbr = 4 then',
'      :P17_Q4 := apex_escape.html(c1.question);      ',
'   elsif l_nbr = 5 then',
'      :P17_Q5 := apex_escape.html(c1.question);      ',
'   elsif l_nbr = 6 then',
'      :P17_Q6 := apex_escape.html(c1.question);      ',
'   elsif l_nbr = 7 then',
'      :P17_Q7 := apex_escape.html(c1.question);      ',
'   elsif l_nbr = 8 then',
'      :P17_Q8 := apex_escape.html(c1.question);      ',
'   elsif l_nbr = 9 then',
'      :P17_Q9 := apex_escape.html(c1.question); ',
'   elsif l_nbr = 10 then',
'      :P17_Q10 := apex_escape.html(c1.question); ',
'   elsif l_nbr = 11 then',
'      :P17_Q11 := apex_escape.html(c1.question);',
'   elsif l_nbr = 12 then',
'      :P17_Q12 := apex_escape.html(c1.question);',
'   elsif l_nbr = 13 then',
'      :P17_Q13 := apex_escape.html(c1.question);',
'   elsif l_nbr = 14 then',
'      :P17_Q14 := apex_escape.html(c1.question);      ',
'   elsif l_nbr = 15 then',
'      :P17_Q15 := apex_escape.html(c1.question);      ',
'   elsif l_nbr = 16 then',
'      :P17_Q16 := apex_escape.html(c1.question);      ',
'   elsif l_nbr = 17 then',
'      :P17_Q17 := apex_escape.html(c1.question);      ',
'   elsif l_nbr = 18 then',
'      :P17_Q18 := apex_escape.html(c1.question);      ',
'   elsif l_nbr = 19 then',
'      :P17_Q19 := apex_escape.html(c1.question); ',
'   elsif l_nbr = 20 then',
'      :P17_Q20 := apex_escape.html(c1.question);  ',
'   end if;',
'   l_nbr := l_nbr + 1;',
'end loop;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>361109338255946893
);
wwv_flow_imp.component_end;
end;
/
