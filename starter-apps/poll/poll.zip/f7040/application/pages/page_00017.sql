prompt --application/pages/page_00017
begin
--   Manifest
--     PAGE: 00017
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>17
,p_name=>'Detailed Results'
,p_alias=>'DETAILED-RESULTS'
,p_step_title=>'Detailed Results'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(13938627977333694414)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14382711460946188328)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>5
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(17606938524254648521)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21300764161437248370)
,p_plug_name=>'Current Poll'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42906605029879421818)
,p_plug_name=>'Result Details'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.id result_id,',
'      case when p.anonymous_yn = ''Y'' then ''anonymous'' else lower(r.email) end respondent,',
'      (select c.community_name',
'         from eba_qpoll_comm_invites c,',
'              eba_qpoll_invites i',
'        where p.id = c.poll_id',
'          and c.id = i.comm_invite_id',
'          and r.respondent_id = i.respondent_id) community,',
'      r.updated submission_date,',
'      d.answer_01||',
'        decode(d.answer_02,null,null,'', ''||d.answer_02)||',
'        decode(d.answer_03,null,null,'', ''||d.answer_03)||',
'        decode(d.answer_04,null,null,'', ''||d.answer_04)||',
'        decode(d.answer_05,null,null,'', ''||d.answer_05)||',
'        decode(d.answer_06,null,null,'', ''||d.answer_06)||',
'        decode(d.answer_07,null,null,'', ''||d.answer_07)||',
'        decode(d.answer_08,null,null,'', ''||d.answer_08)||',
'        decode(d.answer_09,null,null,'', ''||d.answer_09)||',
'        decode(d.answer_10,null,null,'', ''||d.answer_10)||',
'        decode(d.answer_11,null,null,'', ''||d.answer_11)||',
'        decode(d.answer_12,null,null,'', ''||d.answer_12) answer1,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2',
'      where r.id = d2.result_id ',
'        and d2.display_sequence = 2) answer2,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2',
'      where r.id = d2.result_id ',
'        and d2.display_sequence = 3) answer3,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2',
'      where r.id = d2.result_id ',
'        and d2.display_sequence = 4) answer4,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2',
'      where r.id = d2.result_id ',
'        and d2.display_sequence = 5) answer5,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2',
'      where r.id = d2.result_id ',
'        and d2.display_sequence = 6) answer6,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2',
'      where r.id = d2.result_id ',
'        and d2.display_sequence = 7) answer7,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2',
'      where r.id = d2.result_id ',
'        and d2.display_sequence = 8) answer8,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2',
'      where r.id = d2.result_id ',
'        and d2.display_sequence = 9) answer9,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2',
'      where r.id = d2.result_id ',
'        and d2.display_sequence = 10) answer10,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2',
'      where r.id = d2.result_id ',
'        and d2.display_sequence = 11) answer11,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2',
'      where r.id = d2.result_id ',
'        and d2.display_sequence = 12) answer12,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2',
'      where r.id = d2.result_id ',
'        and d2.display_sequence = 13) answer13,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2',
'      where r.id = d2.result_id ',
'        and d2.display_sequence = 14) answer14,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2',
'      where r.id = d2.result_id ',
'        and d2.display_sequence = 15) answer15,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2',
'      where r.id = d2.result_id ',
'        and d2.display_sequence = 16) answer16,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2',
'      where r.id = d2.result_id ',
'        and d2.display_sequence = 17) answer17,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2',
'      where r.id = d2.result_id ',
'        and d2.display_sequence = 18) answer18,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2',
'      where r.id = d2.result_id ',
'        and d2.display_sequence = 19) answer19,',
'      (select d2.answer_01||',
'        decode(d2.answer_02,null,null,'', ''||d2.answer_02)||',
'        decode(d2.answer_03,null,null,'', ''||d2.answer_03)||',
'        decode(d2.answer_04,null,null,'', ''||d2.answer_04)||',
'        decode(d2.answer_05,null,null,'', ''||d2.answer_05)||',
'        decode(d2.answer_06,null,null,'', ''||d2.answer_06)||',
'        decode(d2.answer_07,null,null,'', ''||d2.answer_07)||',
'        decode(d2.answer_08,null,null,'', ''||d2.answer_08)||',
'        decode(d2.answer_09,null,null,'', ''||d2.answer_09)||',
'        decode(d2.answer_10,null,null,'', ''||d2.answer_10)||',
'        decode(d2.answer_11,null,null,'', ''||d2.answer_11)||',
'        decode(d2.answer_12,null,null,'', ''||d2.answer_12)',
'       from EBA_QPOLL_RESULT_DETAILS d2',
'      where r.id = d2.result_id ',
'        and d2.display_sequence = 20) answer20',
'  from EBA_QPOLL_POLLS p,',
'       EBA_QPOLL_RESULTS r,',
'       EBA_QPOLL_RESULT_DETAILS d',
' where p.id = :POLL_ID',
'   and d.display_sequence = 1',
'     and p.id = r.poll_id and',
'       nvl(r.is_valid_yn,''Y'') = ''Y'' and',
'       r.id = d.result_id ',
'  and (p.status_id = 4 or p.status_id = 3 or',
'       ( p.status_id = 2 and ',
'         eba_qpoll.get_access_role (',
'             p_app_id   => :APP_ID,',
'             p_username => :APP_USER) in (''CONTRIBUTOR'',''ADMINISTRATOR'') ) )',
'  and (eba_qpoll.get_access_role (',
'             p_app_id   => :APP_ID,',
'             p_username => :APP_USER) != ''NONE''',
'       or ',
'       (p.all_view_results_yn = ''Y'' and exists ',
'        (select 1',
'           from eba_qpoll_comm_invites c,',
'                eba_qpoll_invites i',
'          where c.poll_id = p.id',
'            and c.id = i.comm_invite_id',
'            and upper(respondent_email) = :APP_USER) ) )'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(42906605127081421818)
,p_name=>'Result Details'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_pivot=>'N'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'Y'
,p_owner=>'SBKENNED'
,p_internal_uid=>42888016442922279643
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379690845215089047)
,p_db_column_name=>'RESPONDENT'
,p_display_order=>12
,p_column_identifier=>'AB'
,p_column_label=>'Respondent'
,p_column_link=>'f?p=&APP_ID.:73:&SESSION.::&DEBUG.:RP,73:P73_RESULT_ID:#RESULT_ID#'
,p_column_linktext=>'#RESPONDENT#'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379691270075089047)
,p_db_column_name=>'SUBMISSION_DATE'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Submission Date'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379690397291089046)
,p_db_column_name=>'COMMUNITY'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Community'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379688017083089042)
,p_db_column_name=>'ANSWER1'
,p_display_order=>43
,p_column_identifier=>'AH'
,p_column_label=>'&P17_Q1.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379688415863089043)
,p_db_column_name=>'ANSWER2'
,p_display_order=>53
,p_column_identifier=>'AI'
,p_column_label=>'&P17_Q2.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379688814429089044)
,p_db_column_name=>'ANSWER3'
,p_display_order=>63
,p_column_identifier=>'AJ'
,p_column_label=>'&P17_Q3.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q3'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379689265659089044)
,p_db_column_name=>'ANSWER4'
,p_display_order=>73
,p_column_identifier=>'AK'
,p_column_label=>'&P17_Q4.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q4'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379689592689089045)
,p_db_column_name=>'ANSWER5'
,p_display_order=>83
,p_column_identifier=>'AL'
,p_column_label=>'&P17_Q5.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q5'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379690058015089046)
,p_db_column_name=>'ANSWER6'
,p_display_order=>93
,p_column_identifier=>'AM'
,p_column_label=>'&P17_Q6.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q6'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379691610578089048)
,p_db_column_name=>'ANSWER7'
,p_display_order=>103
,p_column_identifier=>'AN'
,p_column_label=>'&P17_Q7.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q7'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379691984235089050)
,p_db_column_name=>'ANSWER8'
,p_display_order=>113
,p_column_identifier=>'AO'
,p_column_label=>'&P17_Q8.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q8'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379692416499089051)
,p_db_column_name=>'ANSWER9'
,p_display_order=>123
,p_column_identifier=>'AP'
,p_column_label=>'&P17_Q9.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q9'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379692830887089051)
,p_db_column_name=>'ANSWER10'
,p_display_order=>133
,p_column_identifier=>'AQ'
,p_column_label=>'&P17_Q10.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q10'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379693186379089052)
,p_db_column_name=>'ANSWER11'
,p_display_order=>143
,p_column_identifier=>'AR'
,p_column_label=>'&P17_Q11.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q11'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379693591878089052)
,p_db_column_name=>'ANSWER12'
,p_display_order=>153
,p_column_identifier=>'AS'
,p_column_label=>'&P17_Q12.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q12'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379694079082089053)
,p_db_column_name=>'ANSWER13'
,p_display_order=>163
,p_column_identifier=>'AT'
,p_column_label=>'&P17_Q13.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q13'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379694400324089054)
,p_db_column_name=>'ANSWER14'
,p_display_order=>173
,p_column_identifier=>'AU'
,p_column_label=>'&P17_Q14.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q14'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379694865041089054)
,p_db_column_name=>'ANSWER15'
,p_display_order=>183
,p_column_identifier=>'AV'
,p_column_label=>'&P17_Q15.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q15'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379695283275089055)
,p_db_column_name=>'ANSWER16'
,p_display_order=>193
,p_column_identifier=>'AW'
,p_column_label=>'&P17_Q16.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q16'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379695622902089056)
,p_db_column_name=>'ANSWER17'
,p_display_order=>203
,p_column_identifier=>'AX'
,p_column_label=>'&P17_Q17.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q17'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379695999340089057)
,p_db_column_name=>'ANSWER18'
,p_display_order=>213
,p_column_identifier=>'AY'
,p_column_label=>'&P17_Q18.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q18'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379696470458089057)
,p_db_column_name=>'ANSWER19'
,p_display_order=>223
,p_column_identifier=>'AZ'
,p_column_label=>'&P17_Q19.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q19'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379696864467089058)
,p_db_column_name=>'ANSWER20'
,p_display_order=>233
,p_column_identifier=>'BA'
,p_column_label=>'&P17_Q20.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_display_condition=>'P17_Q20'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(273222716324551116)
,p_db_column_name=>'RESULT_ID'
,p_display_order=>243
,p_column_identifier=>'BB'
,p_column_label=>'Result Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(42906608003017429233)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3611085'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'RESPONDENT::ANSWER1:ANSWER2:ANSWER3:ANSWER4:ANSWER5:ANSWER6:ANSWER7:ANSWER8:ANSWER9:ANSWER10:ANSWER11:ANSWER12:ANSWER13:ANSWER14:ANSWER15:ANSWER16:ANSWER17:ANSWER18:ANSWER19:ANSWER20:RESULT_ID'
,p_sort_column_1=>'POLL_ID'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'RESPONDENT'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'QUESTION_DISPLAY_SEQ'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(379717542205156463)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(14382711460946188328)
,p_button_name=>'BACK'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Back'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:&LAST_VIEW.:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-double-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(396242655085474099)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(14382711460946188328)
,p_button_name=>'cross_poll'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Alternate View'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:41:&SESSION.:CIR,RIR:&DEBUG.:RP,41,CIR,RIR:IR_POLL_ID:&POLL_ID.'
,p_icon_css_classes=>'fa-chevron-right'
,p_security_scheme=>wwv_flow_imp.id(167453047059546086)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(396242999623477802)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(14382711460946188328)
,p_button_name=>'REMOVE_RESULTS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Remove Results'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:40:&SESSION.:CIR,RIR:&DEBUG.:RP::'
,p_security_scheme=>wwv_flow_imp.id(167453047059546086)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(379697602197089062)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(42906605029879421818)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&SESSION.::&DEBUG.:RP,&APP_PAGE_ID.,RIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379679442948089018)
,p_name=>'P17_POLL_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_prompt=>'Poll'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select poll_name from eba_qpoll_polls',
' where id = :POLL_ID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379679733525089027)
,p_name=>'P17_Q1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379680120215089027)
,p_name=>'P17_Q2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379680548021089027)
,p_name=>'P17_Q3'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379680909853089028)
,p_name=>'P17_Q4'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379681375248089028)
,p_name=>'P17_Q5'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379681780838089028)
,p_name=>'P17_Q6'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379682145131089029)
,p_name=>'P17_Q7'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379682577198089029)
,p_name=>'P17_Q8'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379682890675089029)
,p_name=>'P17_Q9'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379683294309089030)
,p_name=>'P17_Q10'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379683720137089030)
,p_name=>'P17_Q11'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379684164280089030)
,p_name=>'P17_Q12'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379684578060089031)
,p_name=>'P17_Q13'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379684977891089031)
,p_name=>'P17_Q14'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379685293754089031)
,p_name=>'P17_Q15'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379685781433089031)
,p_name=>'P17_Q16'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379686086889089032)
,p_name=>'P17_Q17'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379686529563089032)
,p_name=>'P17_Q18'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379686926226089032)
,p_name=>'P17_Q19'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(379687359046089033)
,p_name=>'P17_Q20'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(21300764161437248370)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(273222565526551114)
,p_name=>'on close'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(396242999623477802)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(273222644014551115)
,p_event_id=>wwv_flow_imp.id(273222565526551114)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(42906605029879421818)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(273222865252551117)
,p_name=>'after edit respondent'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(42906605029879421818)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(273222954531551118)
,p_event_id=>wwv_flow_imp.id(273222865252551117)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(42906605029879421818)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(379698022415089068)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'load questions'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_nbr  number := 1;',
'begin',
'',
':P17_Q1 := null;',
':P17_Q2 := null;',
':P17_Q3 := null;',
':P17_Q4 := null;     ',
':P17_Q5 := null;   ',
':P17_Q6 := null;    ',
':P17_Q7 := null;    ',
':P17_Q8 := null;   ',
':P17_Q9 := null; ',
':P17_Q10 := null;',
':P17_Q11 := null;',
':P17_Q12 := null;',
':P17_Q13 := null;',
':P17_Q14 := null;      ',
':P17_Q15 := null;      ',
':P17_Q16 := null; ',
':P17_Q17 := null;   ',
':P17_Q18 := null;     ',
':P17_Q19 := null; ',
':P17_Q20 := null;',
'',
'for c1 in (',
'   select question',
'     from EBA_QPOLL_QUESTIONS',
'    where :POLL_ID = poll_id',
'    order by display_sequence',
') loop',
'   if l_nbr = 1 then',
'      :P17_Q1 := apex_escape.html(c1.question);',
'   elsif l_nbr = 2 then',
'      :P17_Q2 := apex_escape.html(c1.question);',
'   elsif l_nbr = 3 then',
'      :P17_Q3 := apex_escape.html(c1.question);',
'   elsif l_nbr = 4 then',
'      :P17_Q4 := apex_escape.html(c1.question);      ',
'   elsif l_nbr = 5 then',
'      :P17_Q5 := apex_escape.html(c1.question);      ',
'   elsif l_nbr = 6 then',
'      :P17_Q6 := apex_escape.html(c1.question);      ',
'   elsif l_nbr = 7 then',
'      :P17_Q7 := apex_escape.html(c1.question);      ',
'   elsif l_nbr = 8 then',
'      :P17_Q8 := apex_escape.html(c1.question);      ',
'   elsif l_nbr = 9 then',
'      :P17_Q9 := apex_escape.html(c1.question); ',
'   elsif l_nbr = 10 then',
'      :P17_Q10 := apex_escape.html(c1.question); ',
'   elsif l_nbr = 11 then',
'      :P17_Q11 := apex_escape.html(c1.question);',
'   elsif l_nbr = 12 then',
'      :P17_Q12 := apex_escape.html(c1.question);',
'   elsif l_nbr = 13 then',
'      :P17_Q13 := apex_escape.html(c1.question);',
'   elsif l_nbr = 14 then',
'      :P17_Q14 := apex_escape.html(c1.question);      ',
'   elsif l_nbr = 15 then',
'      :P17_Q15 := apex_escape.html(c1.question);      ',
'   elsif l_nbr = 16 then',
'      :P17_Q16 := apex_escape.html(c1.question);      ',
'   elsif l_nbr = 17 then',
'      :P17_Q17 := apex_escape.html(c1.question);      ',
'   elsif l_nbr = 18 then',
'      :P17_Q18 := apex_escape.html(c1.question);      ',
'   elsif l_nbr = 19 then',
'      :P17_Q19 := apex_escape.html(c1.question); ',
'   elsif l_nbr = 20 then',
'      :P17_Q20 := apex_escape.html(c1.question);  ',
'   end if;',
'   l_nbr := l_nbr + 1;',
'end loop;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>361109338255946893
);
wwv_flow_imp.component_end;
end;
/
