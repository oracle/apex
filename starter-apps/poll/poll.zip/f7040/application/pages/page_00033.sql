prompt --application/pages/page_00033
begin
--   Manifest
--     PAGE: 00033
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>33
,p_name=>'Opt Out of Email'
,p_alias=>'OPTOUT'
,p_step_title=>'Opt Out of Email'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_group_id=>wwv_flow_imp.id(13973830316392332345)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'@media only screen and (max-width: 640px) {',
'section.uRegion {',
'  width: auto !important;',
'}',
'}'))
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13973787031313420310)
,p_plug_name=>'Hidden Items'
,p_static_id=>'hidden-items'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY_3'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14008976417580765364)
,p_plug_name=>'hide nobody'
,p_static_id=>'hide-nobody'
,p_region_template_options=>'#DEFAULT#'
,p_plug_display_sequence=>1
,p_plug_display_point=>'BODY_3'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<style>.userBlock{display: none !important} .logoBarNav {padding-top: 8px;visibility: hidden;}</style>'
,p_translate_title=>'N'
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if apex_authentication.is_authenticated then',
'   return false;',
'else',
'   return true;',
'end if;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13973788025568420317)
,p_plug_name=>'Opt In'
,p_static_id=>'opt-in'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY_3'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>You have already opted out from receiving emails from &APPLICATION_TITLE.. If you would like to start receiving emails from &APPLICATION_TITLE. again, click the "Opt Back In" button below. Otherwise, click the "Cancel" button.</p>'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_qpoll_email_opt_out',
' where respondent_id = :P33_PERSON_ID;'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13973787434406420314)
,p_plug_name=>'Opt Out'
,p_static_id=>'opt-out'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY_3'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>Clicking the "Opt Out" button below, will stop all &APPLICATION_TITLE. emails from being delivered to your email address. Click the "Cancel" button if you''d like to keep receiving emails from &APPLICATION_TITLE..</p>'
,p_plug_display_condition_type=>'NOT_EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from eba_qpoll_email_opt_out',
' where respondent_id = :P33_PERSON_ID;'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13973788417265420318)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(13973788025568420317)
,p_button_name=>'OPT_IN'
,p_static_id=>'opt-in'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Opt Back In'
,p_button_position=>'CREATE'
,p_button_condition=>'select 1 from eba_qpoll_email_opt_out where respondent_id = :P33_PERSON_ID'
,p_button_condition_type=>'EXISTS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13973787614729420315)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(13973787434406420314)
,p_button_name=>'OPT_OUT'
,p_static_id=>'opt-out'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Opt Out'
,p_button_position=>'CREATE'
,p_button_condition=>'select 1 from eba_qpoll_email_opt_out where respondent_id = :P33_PERSON_ID'
,p_button_condition_type=>'NOT_EXISTS'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(13973831018306340336)
,p_branch_name=>'out out confirmed'
,p_branch_action=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:33::'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(13973787614729420315)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13973787225405420312)
,p_name=>'P33_PERSON_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(13973787031313420310)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13973788815461420320)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Opt In'
,p_static_id=>'opt-in'
,p_process_sql_clob=>'delete from eba_qpoll_email_opt_out where respondent_id = :P33_PERSON_ID;'
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'#SQLERRM#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(13973788417265420318)
,p_process_when=>'P33_PERSON_ID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>'You''ve successfully opted back in to receiving emails from &APPLICATION_TITLE..'
,p_internal_uid=>13956675975854692675
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13973788607428420319)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Opt Out'
,p_static_id=>'opt-out'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into eba_qpoll_email_opt_out',
'(respondent_id)',
'values',
'(:P33_PERSON_ID);'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'#SQLERRM#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(13973787614729420315)
,p_process_when=>'P33_PERSON_ID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>'You''ve successfully opted-out of receiving emails from &APPLICATION_TITLE..'
,p_internal_uid=>13956675767821692674
);
wwv_flow_imp.component_end;
end;
/
