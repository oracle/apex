prompt --application/shared_components/legacy_data_loads/eba_qpoll_projects
begin
--   Manifest
--     EBA_QPOLL_PROJECTS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_load_table(
 p_id=>wwv_flow_imp.id(16469283746386975214)
,p_name=>'Decison Projects'
,p_owner=>'#OWNER#'
,p_table_name=>'EBA_QPOLL_PROJECTS'
,p_unique_column_1=>'PROJECT_NAME'
,p_is_uk1_case_sensitive=>'N'
,p_unique_column_2=>'PROJECT_OWNER'
,p_is_uk2_case_sensitive=>'N'
,p_is_uk3_case_sensitive=>'N'
,p_skip_validation=>'N'
);
wwv_flow_imp.component_end;
end;
/
