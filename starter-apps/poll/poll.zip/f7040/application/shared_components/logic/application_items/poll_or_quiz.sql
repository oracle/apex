prompt --application/shared_components/logic/application_items/poll_or_quiz
begin
--   Manifest
--     APPLICATION ITEM: POLL_OR_QUIZ
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(13943774047294377608)
,p_name=>'POLL_OR_QUIZ'
,p_protection_level=>'I'
,p_version_scn=>37166093786642
);
wwv_flow_imp.component_end;
end;
/
