prompt --application/shared_components/logic/application_items/poll_name
begin
--   Manifest
--     APPLICATION ITEM: POLL_NAME
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_flow_item(
 p_id=>wwv_flow_api.id(13920065183873650490)
,p_name=>'POLL_NAME'
,p_protection_level=>'I'
,p_escape_on_http_output=>'N'
);
wwv_flow_api.component_end;
end;
/
