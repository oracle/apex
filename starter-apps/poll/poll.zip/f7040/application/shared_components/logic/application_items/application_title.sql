prompt --application/shared_components/logic/application_items/application_title
begin
--   Manifest
--     APPLICATION ITEM: APPLICATION_TITLE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(14528583354310039795)
,p_name=>'APPLICATION_TITLE'
,p_protection_level=>'I'
,p_version_scn=>'37166093786642'
);
wwv_flow_imp.component_end;
end;
/
