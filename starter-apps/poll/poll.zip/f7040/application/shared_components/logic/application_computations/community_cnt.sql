prompt --application/shared_components/logic/application_computations/community_cnt
begin
--   Manifest
--     APPLICATION COMPUTATION: COMMUNITY_CNT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(15458253775109986261)
,p_computation_sequence=>10
,p_computation_item=>'COMMUNITY_CNT'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select count(*) ',
'  from EBA_QPOLL_RESP_COMMUNITIES'))
,p_version_scn=>37166093786642
);
wwv_flow_imp.component_end;
end;
/
