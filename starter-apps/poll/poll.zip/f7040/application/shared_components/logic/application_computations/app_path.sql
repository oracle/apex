prompt --application/shared_components/logic/application_computations/app_path
begin
--   Manifest
--     APPLICATION COMPUTATION: APP_PATH
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(14015437520090257283)
,p_computation_sequence=>10
,p_computation_item=>'APP_PATH'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_friendly_url_yn varchar2(3);',
'    l_app_path        varchar2(4000) := wwv_flow_utilities.get_protocol() || ''://'' || owa_util.get_cgi_env(''HTTP_HOST'');',
'begin',
'    select nvl(FRIENDLY_URL,''Yes'') into l_friendly_url_yn from APEX_APPLICATIONS where APPLICATION_ID = :APP_ID;',
'',
'    if l_friendly_url_yn = ''No'' then',
'        l_app_path := l_app_path || owa_util.get_cgi_env(''SCRIPT_NAME'') || ''/'';',
'    end if;',
'',
'    return l_app_path;',
'end;'))
,p_version_scn=>37166093786642
);
wwv_flow_imp.component_end;
end;
/
