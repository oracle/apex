prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 7040
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>17112839606727645
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(165976253114131534)
,p_build_option_name=>'Feature: Access Control'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>37166093786696
,p_feature_identifier=>'APPLICATION_ACCESS_CONTROL'
,p_build_option_comment=>'Incorporate role based user authentication within your application and manage username mappings to application roles.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(13919837625554089123)
,p_build_option_name=>'Self Service Requests'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>37166093786696
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'If included, users can request access to the application.  An administrator would then review and approve/decline the request.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(13938293017878681149)
,p_build_option_name=>'Allow Deletion of Responses'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>37166093786698
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'If included, Contributors and Administrators can delete responses.  Testing responses can always be deleted, this governs responses given when the poll/quiz is published.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(14047584910484344758)
,p_build_option_name=>'Enable Scrubbing Respondent Emails'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>37166093786698
,p_default_on_export=>'EXCLUDE'
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'If enabled, Administrators will be able to access a page to allow the removal of leading, non-displayed characters from Respondents.'
);
wwv_flow_imp.component_end;
end;
/
