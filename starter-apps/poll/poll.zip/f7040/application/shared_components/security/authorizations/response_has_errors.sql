prompt --application/shared_components/security/authorizations/response_has_errors
begin
--   Manifest
--     SECURITY SCHEME: Response Has Errors
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(13970189607961357799)
,p_name=>'Response Has Errors'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if eba_qpoll.poll_take_status(',
'                p_app_id   => :APP_ID,',
'                p_poll_id  => :POLL_ID,',
'                p_app_user => :APP_USER,',
'                p_app_session => :APP_SESSION) = ''HAS_ERRORS''',
'then return true;',
'else return false;',
'end if;'))
,p_error_message=>'You have already taken this poll.'
,p_version_scn=>1089050995
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_imp.component_end;
end;
/
