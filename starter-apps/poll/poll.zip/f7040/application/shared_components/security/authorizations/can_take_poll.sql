prompt --application/shared_components/security/authorizations/can_take_poll
begin
--   Manifest
--     SECURITY SCHEME: Can Take Poll
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>17112839606727645
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(13937152916163302785)
,p_name=>'Can Take Poll'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if eba_qpoll.poll_take_status (',
'                p_app_id   => :APP_ID,',
'                p_poll_id  => :POLL_ID,',
'                p_app_user => :APP_USER,',
'                p_app_session => :APP_SESSION) = ''CAN_TAKE_IT''',
'then return true;',
'else return false;',
'end if;'))
,p_error_message=>'You have already taken this poll.'
,p_version_scn=>1089050995
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_imp.component_end;
end;
/
