prompt --application/shared_components/security/authorizations/can_update_your_response
begin
--   Manifest
--     SECURITY SCHEME: Can Update Your Response
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(13938506030916799139)
,p_name=>'Can Update Your Response'
,p_static_id=>'can-update-your-response'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'plsql_function_body', wwv_flow_string.join(wwv_flow_t_varchar2(
    'if eba_qpoll.poll_take_status (',
    '                p_app_id   => :APP_ID,',
    '                p_poll_id  => :POLL_ID,',
    '                p_app_user => :APP_USER,',
    '                p_app_session => :APP_SESSION) = ''CAN_UPDATE''',
    'then return true;',
    'else return false;',
    'end if;')))).to_clob
,p_error_message=>'Your cannot update your response.'
,p_version_scn=>'1089050995'
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_imp.component_end;
end;
/
