prompt --application/shared_components/security/authorizations/can_view_your_response
begin
--   Manifest
--     SECURITY SCHEME: Can View Your Response
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(13938482722599423123)
,p_name=>'Can View Your Response'
,p_static_id=>'can-view-your-response'
,p_scheme_type=>'NATIVE_EXISTS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'sql_query', wwv_flow_string.join(wwv_flow_t_varchar2(
    'select 1',
    '  from eba_qpoll_polls p',
    ' where id = :POLL_ID',
    '  and ( (anonymous_yn = ''Y'' and',
    '         exists (select 1',
    '                   from eba_qpoll_results',
    '                  where poll_id = p.id',
    '                    and APEX_SESSION_ID = :APP_SESSION) ) ',
    '         or',
    '         (anonymous_yn = ''N'' and',
    '          exists (select 1',
    '                    from eba_qpoll_results',
    '                   where poll_id = p.id',
    '                     and apex_user = :APP_USER) ) )')))).to_clob
,p_error_message=>'You cannot view your results.'
,p_version_scn=>'1089050995'
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_imp.component_end;
end;
/
