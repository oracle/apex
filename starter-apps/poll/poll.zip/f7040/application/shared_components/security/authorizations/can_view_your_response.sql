prompt --application/shared_components/security/authorizations/can_view_your_response
begin
--   Manifest
--     SECURITY SCHEME: Can View Your Response
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(13921369882992695478)
,p_name=>'Can View Your Response'
,p_scheme_type=>'NATIVE_EXISTS'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_polls p',
' where id = :POLL_ID',
'  and ( (anonymous_yn = ''Y'' and',
'         exists (select 1',
'                   from eba_qpoll_results',
'                  where poll_id = p.id',
'                    and APEX_SESSION_ID = :APP_SESSION) ) ',
'         or',
'         (anonymous_yn = ''N'' and',
'          exists (select 1',
'                    from eba_qpoll_results',
'                   where poll_id = p.id',
'                     and apex_user = :APP_USER) ) )'))
,p_error_message=>'You cannot view your results.'
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_imp.component_end;
end;
/
