prompt --application/shared_components/email/templates/access_request_declined
begin
--   Manifest
--     REPORT LAYOUT: Access Request Declined
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_email_template(
 p_id=>wwv_flow_imp.id(31251217558693490559)
,p_name=>'Access Request Declined'
,p_static_id=>'ACCESS_REQUEST_DECLINED'
,p_version_number=>1
,p_subject=>'#APPLICATION_TITLE# Access Request'
,p_html_body=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>You recently requested access to #APPLICATION_TITLE#.</p> ',
'<p>Your request was declined.</p> ',
'<p>  ',
'  Reason: #ACTION_REASON# ',
'</p>'))
,p_html_header=>'#APPLICATION_TITLE#'
,p_html_footer=>'<div style="color: #707070;font-family: Arial;font-size: 12px;line-height: 125%;text-align:center;"> This is a system generated email. Please do not reply to this message.</div>'
,p_text_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'You recently requested access to #APPLICATION_TITLE#.',
'Your request was declined.',
'   ',
'  Reason: #ACTION_REASON# ',
''))
,p_version_scn=>37166093786698
);
wwv_flow_imp.component_end;
end;
/
