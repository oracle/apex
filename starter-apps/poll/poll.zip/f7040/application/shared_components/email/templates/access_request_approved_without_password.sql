prompt --application/shared_components/email/templates/access_request_approved_without_password
begin
--   Manifest
--     EMAIL TEMPLATE: Access Request Approved without password
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_email_template(
 p_id=>wwv_flow_imp.id(31269801256133628678)
,p_name=>'Access Request Approved without password'
,p_static_id=>'ACCESS_REQUEST_APPROVED_WITHOUT_PASSWORD'
,p_version_number=>1
,p_subject=>'#APPLICATION_TITLE# Access'
,p_html_body=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h1>You have been granted access to #APPLICATION_TITLE#.</h1> ',
'<p>You may now log in to #APP_LINK#.</p> ',
'<p>Your application login credentials are provided below.</p> ',
'<p> ',
'  Username: #USERNAME# ',
'</p>'))
,p_html_header=>'#APPLICATION_TITLE#'
,p_html_footer=>'<div style="color: #707070;font-family: Arial;font-size: 12px;line-height: 125%;text-align:center;"> This is a system generated email. Please do not reply to this message.</div>'
,p_text_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'You have been granted access to #APPLICATION_TITLE#.',
'You may now log in to #APP_LINK#.',
'Your application login credentials are provided below. ',
' ',
'  Username: #USERNAME# ',
''))
,p_version_scn=>37166093786698
);
wwv_flow_imp.component_end;
end;
/
