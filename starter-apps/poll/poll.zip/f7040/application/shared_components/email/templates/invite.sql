prompt --application/shared_components/email/templates/invite
begin
--   Manifest
--     EMAIL TEMPLATE: Poll Invitation or Reminder
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_email_template(
 p_id=>wwv_flow_imp.id(574601852971317148)
,p_name=>'Poll Invitation or Reminder'
,p_static_id=>'INVITE'
,p_version_number=>1
,p_subject=>'#SUBJECT#'
,p_html_body=>'#BODY!RAW#'
,p_html_header=>'#APPLICATION_TITLE#'
,p_html_footer=>'<div style="color: #707070;font-family: Arial;font-size: 12px;line-height: 125%;text-align:center;"> This is a system generated email. Please do not reply to this message. #OPT_OUT_TEXT!RAW#</div>'
,p_text_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#BODY#',
'',
'This is a system generated email. Please do not reply to this message. #OPT_OUT_TEXT#'))
,p_version_scn=>37166093786698
);
wwv_flow_imp.component_end;
end;
/
