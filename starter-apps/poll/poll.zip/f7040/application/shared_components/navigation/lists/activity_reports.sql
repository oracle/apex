prompt --application/shared_components/navigation/lists/activity_reports
begin
--   Manifest
--     LIST: Activity Reports
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(17624069282386460946)
,p_name=>'Activity Reports'
,p_static_id=>'activity-reports'
,p_version_scn=>'1089050994'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(16543309263395385638)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Activity Calendar'
,p_static_id=>'activity-calendar'
,p_list_item_link_target=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-calendar'
,p_list_text_01=>'Monthly calendar of page view activity summarized by user by day.'
,p_list_text_02=>'calendarIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(29743935611962876717)
,p_list_item_display_sequence=>2
,p_list_item_link_text=>'All Respondents'
,p_static_id=>'all-respondents'
,p_list_item_link_target=>'f?p=&APP_ID.:84:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table-user'
,p_list_text_01=>'View all respondents across all Polls.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(13970235806096064068)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Application Error Log'
,p_static_id=>'application-error-log'
,p_list_item_link_target=>'f?p=&APP_ID.:175:&SESSION.::&DEBUG.:RP,RIR:::'
,p_list_item_icon=>'fa-alert'
,p_list_text_01=>'Report of all internal errors encountered within the application.'
,p_list_text_02=>'&P4_APP_ERROR_LOG_CNT.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(13970236417298074030)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Application Log'
,p_static_id=>'application-log'
,p_list_item_link_target=>'f?p=&APP_ID.:61:&SESSION.::&DEBUG.:RP,RIR:::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'Report of various administrative actions.'
,p_list_text_02=>'&P4_APP_LOG_CNT.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(17625297173886745185)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Application Page Views'
,p_static_id=>'application-page-views'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'Report of individual page view, reporting the page, elapsed server generation time, user, date and other information.'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(13970236128512068846)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Application User Log'
,p_static_id=>'application-user-log'
,p_list_item_link_target=>'f?p=&APP_ID.:60:&SESSION.::&DEBUG.:RIR:::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'Report of all users created via self-service requests.'
,p_list_text_02=>'&P4_APP_USER_LOG_CNT.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14040786821234887383)
,p_list_item_display_sequence=>5
,p_list_item_link_text=>'Respondent Details'
,p_static_id=>'respondent-details'
,p_list_item_link_target=>'f?p=&APP_ID.:86:&SESSION.::&DEBUG.:86,RIR:::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'Displays polls taken and those invited to take but not taken for a selected respondent.'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(17625304578734746627)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Top Users'
,p_static_id=>'top-users'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'Report of page views summarized by user by day.'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'12'
);
wwv_flow_imp.component_end;
end;
/
