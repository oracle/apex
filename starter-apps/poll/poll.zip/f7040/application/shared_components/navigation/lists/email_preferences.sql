prompt --application/shared_components/navigation/lists/email_preferences
begin
--   Manifest
--     LIST: Email Preferences
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(13902820883922393280)
,p_name=>'Email Preferences'
,p_list_status=>'PUBLIC'
,p_version_scn=>1089050994
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(13904521880752216334)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Default Email Addresses'
,p_list_item_link_target=>'f?p=&APP_ID.:58:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-user'
,p_list_text_01=>'Configure the application''s default "From" and "Reply To" email addresses.'
,p_list_text_02=>'formIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(13904539071064761689)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Email History'
,p_list_item_link_target=>'f?p=&APP_ID.:59:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-envelope-search'
,p_list_text_01=>'Review previous emails that have been sent via this application.'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(13956683464134966096)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Opt Out User List'
,p_list_item_link_target=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-envelope-user'
,p_list_text_01=>'List of users that have opted out of receiving emails from &APPLICATION_TITLE..  Users can be removed and added by administrators.'
,p_list_text_02=>'formIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
