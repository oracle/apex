prompt --application/shared_components/navigation/lists/email_preferences
begin
--   Manifest
--     LIST: Email Preferences
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(13919933723529120925)
,p_name=>'Email Preferences'
,p_static_id=>'email-preferences'
,p_version_scn=>'1089050994'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(13921634720358943979)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Default Email Addresses'
,p_static_id=>'default-email-addresses'
,p_list_item_link_target=>'f?p=&APP_ID.:58:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-user'
,p_list_text_01=>'Configure the application''s default "From" and "Reply To" email addresses.'
,p_list_text_02=>'formIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(13921651910671489334)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Email History'
,p_static_id=>'email-history'
,p_list_item_link_target=>'f?p=&APP_ID.:59:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-envelope-search'
,p_list_text_01=>'Review previous emails that have been sent via this application.'
,p_list_text_02=>'reportIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(13973796303741693741)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Opt Out User List'
,p_static_id=>'opt-out-user-list'
,p_list_item_link_target=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-envelope-user'
,p_list_text_01=>'List of users that have opted out of receiving emails from &APPLICATION_TITLE..  Users can be removed and added by administrators.'
,p_list_text_02=>'formIcon'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
