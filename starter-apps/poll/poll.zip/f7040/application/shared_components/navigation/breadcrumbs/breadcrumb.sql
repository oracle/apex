prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU:  Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(17588349840095506346)
,p_name=>' Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(206217485814888257)
,p_parent_id=>0
,p_short_name=>'Advanced Search'
,p_link=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:::'
,p_page_id=>200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(361129772293023627)
,p_parent_id=>0
,p_short_name=>'Detailed Results'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(7528505866692783625)
,p_short_name=>'Create Poll'
,p_link=>'f?p=&APP_ID.:19:&SESSION.'
,p_page_id=>19
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13024687447479263613)
,p_parent_id=>0
,p_short_name=>'Section'
,p_link=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:::'
,p_page_id=>38
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13862363775001932364)
,p_parent_id=>0
,p_short_name=>'&POLL_NAME.'
,p_link=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_page_id=>100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13863094867474907355)
,p_parent_id=>0
,p_short_name=>'Edit Poll'
,p_link=>'f?p=&APP_ID.:48:&SESSION.::&DEBUG.:::'
,p_page_id=>48
,p_security_scheme=>wwv_flow_imp.id(148864612871403911)
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13902742177471750362)
,p_parent_id=>wwv_flow_imp.id(17606915360186348531)
,p_short_name=>'Access Requests'
,p_link=>'f?p=&FLOW_ID.:22:&SESSION.'
,p_page_id=>22
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13902743162944816699)
,p_parent_id=>wwv_flow_imp.id(13902742177471750362)
,p_short_name=>'Access Request Details'
,p_link=>'f?p=&FLOW_ID.:37:&SESSION.'
,p_page_id=>37
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13902743894949821853)
,p_parent_id=>0
,p_short_name=>'Purge Access Requests'
,p_link=>'f?p=&APP_ID.:49:&SESSION.::&DEBUG.:::'
,p_page_id=>49
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13904516791615118505)
,p_parent_id=>wwv_flow_imp.id(17606915360186348531)
,p_short_name=>'Default Email Addresses'
,p_link=>'f?p=&APP_ID.:58:&SESSION.::&DEBUG.:::'
,p_page_id=>58
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13904534877452676492)
,p_parent_id=>wwv_flow_imp.id(17606915360186348531)
,p_short_name=>'Email History'
,p_link=>'f?p=&APP_ID.:59:&SESSION.'
,p_page_id=>59
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13907306869535742394)
,p_parent_id=>wwv_flow_imp.id(17606915360186348531)
,p_short_name=>'Application User Log'
,p_link=>'f?p=&APP_ID.:60:&SESSION.'
,p_page_id=>60
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13907322367918165148)
,p_parent_id=>wwv_flow_imp.id(17606915360186348531)
,p_short_name=>'Application Log'
,p_link=>'f?p=&APP_ID.:61:&SESSION.'
,p_page_id=>61
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13918190780738339122)
,p_parent_id=>0
,p_short_name=>'&POLL_NAME.'
,p_link=>'f?p=&APP_ID.:66:&SESSION.::&DEBUG.:::'
,p_page_id=>66
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13920011492912958413)
,p_parent_id=>0
,p_short_name=>'&POLL_NAME.'
,p_link=>'f?p=&APP_ID.:68:&SESSION.::&DEBUG.:::'
,p_page_id=>68
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13920292772036834900)
,p_short_name=>'Your Response'
,p_link=>'f?p=&APP_ID.:69:&SESSION.'
,p_page_id=>69
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13920606277390745133)
,p_parent_id=>0
,p_short_name=>'Add Community / Members'
,p_link=>'f?p=&APP_ID.:70:&SESSION.::&DEBUG.:::'
,p_page_id=>70
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13921304872167003341)
,p_short_name=>'Community'
,p_link=>'f?p=&APP_ID.:71:&SESSION.::&DEBUG.:::'
,p_page_id=>71
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13924944870008194383)
,p_parent_id=>wwv_flow_imp.id(13983839785328080977)
,p_short_name=>'Invitation Details'
,p_link=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::'
,p_page_id=>13
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13925202865177981418)
,p_parent_id=>wwv_flow_imp.id(13931958464365351704)
,p_short_name=>'Members'
,p_link=>'f?p=&APP_ID.:74:&SESSION.::&DEBUG.:::'
,p_page_id=>74
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13931958464365351704)
,p_parent_id=>0
,p_short_name=>'Communities'
,p_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::'
,p_page_id=>9
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13932207983868313153)
,p_short_name=>'Delete Poll'
,p_link=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:::'
,p_page_id=>28
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13953079262894672032)
,p_parent_id=>wwv_flow_imp.id(13862363775001932364)
,p_short_name=>'Delete Test Data'
,p_link=>'f?p=&APP_ID.:82:&SESSION.'
,p_page_id=>82
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13956682078148947327)
,p_parent_id=>wwv_flow_imp.id(17606915360186348531)
,p_short_name=>'Opt Out User List'
,p_link=>'f?p=&APP_ID.:34:&SESSION.'
,p_page_id=>34
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13983839785328080977)
,p_short_name=>'Invitations'
,p_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:::'
,p_page_id=>16
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13991891191048460102)
,p_parent_id=>wwv_flow_imp.id(17606915360186348531)
,p_short_name=>'Build Options'
,p_link=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_page_id=>2
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13996902295375922497)
,p_parent_id=>0
,p_short_name=>'Invitations Sent'
,p_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::'
,p_page_id=>23
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13996903977266940305)
,p_parent_id=>wwv_flow_imp.id(13862363775001932364)
,p_short_name=>'Manual Invitations Recorded'
,p_link=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:::'
,p_page_id=>36
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14002993978091029288)
,p_parent_id=>0
,p_short_name=>'Results Across Polls'
,p_link=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:::'
,p_page_id=>41
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14003997890033315026)
,p_parent_id=>0
,p_short_name=>'Opt Out User Details'
,p_link=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.:::'
,p_page_id=>46
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14015821064463924039)
,p_parent_id=>0
,p_short_name=>'&P67_POLL_NAME.'
,p_link=>'f?p=&APP_ID.:67:&SESSION.::&DEBUG.:::'
,p_page_id=>67
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14023655793039814353)
,p_parent_id=>wwv_flow_imp.id(17606915360186348531)
,p_short_name=>'Respondent Details'
,p_link=>'f?p=&APP_ID.:86:&SESSION.::&DEBUG.:::'
,p_page_id=>86
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14030454075000018564)
,p_parent_id=>wwv_flow_imp.id(17606915360186348531)
,p_short_name=>'Remove Extraneous Characters'
,p_link=>'f?p=&APP_ID.:15:&SESSION.'
,p_page_id=>15
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14033746773018510048)
,p_parent_id=>wwv_flow_imp.id(13918190780738339122)
,p_short_name=>'Email Results'
,p_link=>'f?p=&APP_ID.:90:&SESSION.'
,p_page_id=>90
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14033748364064513863)
,p_parent_id=>wwv_flow_imp.id(13918190780738339122)
,p_short_name=>'Results Emailed'
,p_link=>'f?p=&APP_ID.:91:&SESSION.::&DEBUG.:::'
,p_page_id=>91
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14505612312880317479)
,p_parent_id=>wwv_flow_imp.id(17606915360186348531)
,p_short_name=>'Page Privileges'
,p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14519024513089228832)
,p_parent_id=>wwv_flow_imp.id(17606915360186348531)
,p_short_name=>'Rename Application'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14622363015423198712)
,p_parent_id=>wwv_flow_imp.id(17606915360186348531)
,p_short_name=>'Username Format'
,p_link=>'f?p=&APP_ID.:43:&SESSION.'
,p_page_id=>43
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14811004387595162547)
,p_parent_id=>wwv_flow_imp.id(17606915360186348531)
,p_short_name=>'Application Theme Style'
,p_link=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:::'
,p_page_id=>20
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14859688947143254606)
,p_short_name=>'&POLL_NAME.'
,p_link=>'f?p=&FLOW_ID.:50:&SESSION.'
,p_page_id=>50
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14955661997955873994)
,p_parent_id=>wwv_flow_imp.id(17606915360186348531)
,p_short_name=>'Manage Sample Data'
,p_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:::'
,p_page_id=>32
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16132065697765319076)
,p_parent_id=>wwv_flow_imp.id(17606915360186348531)
,p_short_name=>'Notifications'
,p_link=>'f?p=&FLOW_ID.:30:&SESSION.'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16132159809367331408)
,p_parent_id=>0
,p_short_name=>'Notification'
,p_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:::'
,p_page_id=>31
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16415031419450959570)
,p_parent_id=>wwv_flow_imp.id(17588350338000506350)
,p_short_name=>'Help'
,p_link=>'f?p=&FLOW_ID.:39:&SESSION.'
,p_page_id=>39
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16496186717166572911)
,p_parent_id=>wwv_flow_imp.id(17606915360186348531)
,p_short_name=>'Application Error Log'
,p_link=>'f?p=&APP_ID.:175:&SESSION.::&DEBUG.:::'
,p_page_id=>175
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16526191424466438616)
,p_parent_id=>wwv_flow_imp.id(17606915360186348531)
,p_short_name=>'Activity Calendar'
,p_link=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:::'
,p_page_id=>42
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(17588350338000506350)
,p_parent_id=>0
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&SESSION.'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(17606915360186348531)
,p_parent_id=>0
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(17608133630220999382)
,p_parent_id=>wwv_flow_imp.id(17606915360186348531)
,p_short_name=>'Top Users'
,p_link=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:::'
,p_page_id=>12
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(17608182141415013091)
,p_parent_id=>wwv_flow_imp.id(17606915360186348531)
,p_short_name=>'Application Page Views'
,p_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_imp.component_end;
end;
/
