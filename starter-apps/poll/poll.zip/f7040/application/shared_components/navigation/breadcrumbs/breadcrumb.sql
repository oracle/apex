prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU:  Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>17112839606727645
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(17605462679702233991)
,p_name=>' Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(223330325421615902)
,p_short_name=>'Advanced Search'
,p_link=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:::'
,p_page_id=>200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(378242611899751272)
,p_short_name=>'Detailed Results'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(7545618706299511270)
,p_short_name=>'Create Poll'
,p_link=>'f?p=&APP_ID.:19:&SESSION.'
,p_page_id=>19
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13041800287085991258)
,p_short_name=>'Section'
,p_link=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:::'
,p_page_id=>38
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13879476614608660009)
,p_short_name=>'&POLL_NAME.'
,p_link=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_page_id=>100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13880207707081635000)
,p_short_name=>'Edit Poll'
,p_link=>'f?p=&APP_ID.:48:&SESSION.::&DEBUG.:::'
,p_page_id=>48
,p_security_scheme=>wwv_flow_imp.id(165977452478131556)
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13919855017078478007)
,p_parent_id=>wwv_flow_imp.id(17624028199793076176)
,p_short_name=>'Access Requests'
,p_link=>'f?p=&FLOW_ID.:22:&SESSION.'
,p_page_id=>22
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13919856002551544344)
,p_parent_id=>wwv_flow_imp.id(13919855017078478007)
,p_short_name=>'Access Request Details'
,p_link=>'f?p=&FLOW_ID.:37:&SESSION.'
,p_page_id=>37
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13919856734556549498)
,p_short_name=>'Purge Access Requests'
,p_link=>'f?p=&APP_ID.:49:&SESSION.::&DEBUG.:::'
,p_page_id=>49
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13921629631221846150)
,p_parent_id=>wwv_flow_imp.id(17624028199793076176)
,p_short_name=>'Default Email Addresses'
,p_link=>'f?p=&APP_ID.:58:&SESSION.::&DEBUG.:::'
,p_page_id=>58
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13921647717059404137)
,p_parent_id=>wwv_flow_imp.id(17624028199793076176)
,p_short_name=>'Email History'
,p_link=>'f?p=&APP_ID.:59:&SESSION.'
,p_page_id=>59
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13924419709142470039)
,p_parent_id=>wwv_flow_imp.id(17624028199793076176)
,p_short_name=>'Application User Log'
,p_link=>'f?p=&APP_ID.:60:&SESSION.'
,p_page_id=>60
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13924435207524892793)
,p_parent_id=>wwv_flow_imp.id(17624028199793076176)
,p_short_name=>'Application Log'
,p_link=>'f?p=&APP_ID.:61:&SESSION.'
,p_page_id=>61
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13935303620345066767)
,p_short_name=>'&POLL_NAME.'
,p_link=>'f?p=&APP_ID.:66:&SESSION.::&DEBUG.:::'
,p_page_id=>66
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13937124332519686058)
,p_short_name=>'&POLL_NAME.'
,p_link=>'f?p=&APP_ID.:68:&SESSION.::&DEBUG.:::'
,p_page_id=>68
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13937405611643562545)
,p_short_name=>'Your Response'
,p_link=>'f?p=&APP_ID.:69:&SESSION.'
,p_page_id=>69
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13937719116997472778)
,p_short_name=>'Add Community / Members'
,p_link=>'f?p=&APP_ID.:70:&SESSION.::&DEBUG.:::'
,p_page_id=>70
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13938417711773730986)
,p_short_name=>'Community'
,p_link=>'f?p=&APP_ID.:71:&SESSION.::&DEBUG.:::'
,p_page_id=>71
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13942057709614922028)
,p_parent_id=>wwv_flow_imp.id(14000952624934808622)
,p_short_name=>'Invitation Details'
,p_link=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::'
,p_page_id=>13
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13942315704784709063)
,p_parent_id=>wwv_flow_imp.id(13949071303972079349)
,p_short_name=>'Members'
,p_link=>'f?p=&APP_ID.:74:&SESSION.::&DEBUG.:::'
,p_page_id=>74
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13949071303972079349)
,p_short_name=>'Communities'
,p_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::'
,p_page_id=>9
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13949320823475040798)
,p_short_name=>'Delete Poll'
,p_link=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:::'
,p_page_id=>28
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13970192102501399677)
,p_parent_id=>wwv_flow_imp.id(13879476614608660009)
,p_short_name=>'Delete Test Data'
,p_link=>'f?p=&APP_ID.:82:&SESSION.'
,p_page_id=>82
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13973794917755674972)
,p_parent_id=>wwv_flow_imp.id(17624028199793076176)
,p_short_name=>'Opt Out User List'
,p_link=>'f?p=&APP_ID.:34:&SESSION.'
,p_page_id=>34
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14000952624934808622)
,p_short_name=>'Invitations'
,p_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:::'
,p_page_id=>16
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14009004030655187747)
,p_parent_id=>wwv_flow_imp.id(17624028199793076176)
,p_short_name=>'Build Options'
,p_link=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_page_id=>2
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14014015134982650142)
,p_short_name=>'Invitations Sent'
,p_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::'
,p_page_id=>23
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14014016816873667950)
,p_parent_id=>wwv_flow_imp.id(13879476614608660009)
,p_short_name=>'Manual Invitations Recorded'
,p_link=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:::'
,p_page_id=>36
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14020106817697756933)
,p_short_name=>'Results Across Polls'
,p_link=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:::'
,p_page_id=>41
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14021110729640042671)
,p_short_name=>'Opt Out User Details'
,p_link=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.:::'
,p_page_id=>46
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14032933904070651684)
,p_short_name=>'&P67_POLL_NAME.'
,p_link=>'f?p=&APP_ID.:67:&SESSION.::&DEBUG.:::'
,p_page_id=>67
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14040768632646541998)
,p_parent_id=>wwv_flow_imp.id(17624028199793076176)
,p_short_name=>'Respondent Details'
,p_link=>'f?p=&APP_ID.:86:&SESSION.::&DEBUG.:::'
,p_page_id=>86
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14047566914606746209)
,p_parent_id=>wwv_flow_imp.id(17624028199793076176)
,p_short_name=>'Remove Extraneous Characters'
,p_link=>'f?p=&APP_ID.:15:&SESSION.'
,p_page_id=>15
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14050859612625237693)
,p_parent_id=>wwv_flow_imp.id(13935303620345066767)
,p_short_name=>'Email Results'
,p_link=>'f?p=&APP_ID.:90:&SESSION.'
,p_page_id=>90
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14050861203671241508)
,p_parent_id=>wwv_flow_imp.id(13935303620345066767)
,p_short_name=>'Results Emailed'
,p_link=>'f?p=&APP_ID.:91:&SESSION.::&DEBUG.:::'
,p_page_id=>91
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14522725152487045124)
,p_parent_id=>wwv_flow_imp.id(17624028199793076176)
,p_short_name=>'Page Privileges'
,p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14536137352695956477)
,p_parent_id=>wwv_flow_imp.id(17624028199793076176)
,p_short_name=>'Rename Application'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14639475855029926357)
,p_parent_id=>wwv_flow_imp.id(17624028199793076176)
,p_short_name=>'Username Format'
,p_link=>'f?p=&APP_ID.:43:&SESSION.'
,p_page_id=>43
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14828117227201890192)
,p_parent_id=>wwv_flow_imp.id(17624028199793076176)
,p_short_name=>'Application Theme Style'
,p_link=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:::'
,p_page_id=>20
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14876801786749982251)
,p_short_name=>'&POLL_NAME.'
,p_link=>'f?p=&FLOW_ID.:50:&SESSION.'
,p_page_id=>50
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14972774837562601639)
,p_parent_id=>wwv_flow_imp.id(17624028199793076176)
,p_short_name=>'Manage Sample Data'
,p_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:::'
,p_page_id=>32
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16149178537372046721)
,p_parent_id=>wwv_flow_imp.id(17624028199793076176)
,p_short_name=>'Notifications'
,p_link=>'f?p=&FLOW_ID.:30:&SESSION.'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16149272648974059053)
,p_short_name=>'Notification'
,p_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:::'
,p_page_id=>31
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16432144259057687215)
,p_parent_id=>wwv_flow_imp.id(17605463177607233995)
,p_short_name=>'Help'
,p_link=>'f?p=&FLOW_ID.:39:&SESSION.'
,p_page_id=>39
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16513299556773300556)
,p_parent_id=>wwv_flow_imp.id(17624028199793076176)
,p_short_name=>'Application Error Log'
,p_link=>'f?p=&APP_ID.:175:&SESSION.::&DEBUG.:::'
,p_page_id=>175
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16543304264073166261)
,p_parent_id=>wwv_flow_imp.id(17624028199793076176)
,p_short_name=>'Activity Calendar'
,p_link=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:::'
,p_page_id=>42
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(17605463177607233995)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&SESSION.'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(17624028199793076176)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(17625246469827727027)
,p_parent_id=>wwv_flow_imp.id(17624028199793076176)
,p_short_name=>'Top Users'
,p_link=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:::'
,p_page_id=>12
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(17625294981021740736)
,p_parent_id=>wwv_flow_imp.id(17624028199793076176)
,p_short_name=>'Application Page Views'
,p_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_imp.component_end;
end;
/
