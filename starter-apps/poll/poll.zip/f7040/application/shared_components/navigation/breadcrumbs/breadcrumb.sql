prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU:  Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(17606938524254648521)
,p_name=>' Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(224806169974030432)
,p_short_name=>'Advanced Search'
,p_link=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:::'
,p_page_id=>200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(379718456452165802)
,p_short_name=>'Detailed Results'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(7547094550851925800)
,p_short_name=>'Create Poll'
,p_link=>'f?p=&APP_ID.:19:&SESSION.'
,p_page_id=>19
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13043276131638405788)
,p_short_name=>'Section'
,p_link=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:::'
,p_page_id=>38
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13880952459161074539)
,p_short_name=>'&POLL_NAME.'
,p_link=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_page_id=>100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13881683551634049530)
,p_short_name=>'Edit Poll'
,p_link=>'f?p=&APP_ID.:48:&SESSION.::&DEBUG.:::'
,p_page_id=>48
,p_security_scheme=>wwv_flow_imp.id(167453297030546086)
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13921330861630892537)
,p_parent_id=>wwv_flow_imp.id(17625504044345490706)
,p_short_name=>'Access Requests'
,p_link=>'f?p=&FLOW_ID.:22:&SESSION.'
,p_page_id=>22
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13921331847103958874)
,p_parent_id=>wwv_flow_imp.id(13921330861630892537)
,p_short_name=>'Access Request Details'
,p_link=>'f?p=&FLOW_ID.:37:&SESSION.'
,p_page_id=>37
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13921332579108964028)
,p_short_name=>'Purge Access Requests'
,p_link=>'f?p=&APP_ID.:49:&SESSION.::&DEBUG.:::'
,p_page_id=>49
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13923105475774260680)
,p_parent_id=>wwv_flow_imp.id(17625504044345490706)
,p_short_name=>'Default Email Addresses'
,p_link=>'f?p=&APP_ID.:58:&SESSION.::&DEBUG.:::'
,p_page_id=>58
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13923123561611818667)
,p_parent_id=>wwv_flow_imp.id(17625504044345490706)
,p_short_name=>'Email History'
,p_link=>'f?p=&APP_ID.:59:&SESSION.'
,p_page_id=>59
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13925895553694884569)
,p_parent_id=>wwv_flow_imp.id(17625504044345490706)
,p_short_name=>'Application User Log'
,p_link=>'f?p=&APP_ID.:60:&SESSION.'
,p_page_id=>60
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13925911052077307323)
,p_parent_id=>wwv_flow_imp.id(17625504044345490706)
,p_short_name=>'Application Log'
,p_link=>'f?p=&APP_ID.:61:&SESSION.'
,p_page_id=>61
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13936779464897481297)
,p_short_name=>'&POLL_NAME.'
,p_link=>'f?p=&APP_ID.:66:&SESSION.::&DEBUG.:::'
,p_page_id=>66
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13938600177072100588)
,p_short_name=>'&POLL_NAME.'
,p_link=>'f?p=&APP_ID.:68:&SESSION.::&DEBUG.:::'
,p_page_id=>68
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13938881456195977075)
,p_short_name=>'Your Response'
,p_link=>'f?p=&APP_ID.:69:&SESSION.'
,p_page_id=>69
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13939194961549887308)
,p_short_name=>'Add Community / Members'
,p_link=>'f?p=&APP_ID.:70:&SESSION.::&DEBUG.:::'
,p_page_id=>70
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13939893556326145516)
,p_short_name=>'Community'
,p_link=>'f?p=&APP_ID.:71:&SESSION.::&DEBUG.:::'
,p_page_id=>71
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13943533554167336558)
,p_parent_id=>wwv_flow_imp.id(14002428469487223152)
,p_short_name=>'Invitation Details'
,p_link=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::'
,p_page_id=>13
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13943791549337123593)
,p_parent_id=>wwv_flow_imp.id(13950547148524493879)
,p_short_name=>'Members'
,p_link=>'f?p=&APP_ID.:74:&SESSION.::&DEBUG.:::'
,p_page_id=>74
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13950547148524493879)
,p_short_name=>'Communities'
,p_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::'
,p_page_id=>9
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13950796668027455328)
,p_short_name=>'Delete Poll'
,p_link=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:::'
,p_page_id=>28
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13971667947053814207)
,p_parent_id=>wwv_flow_imp.id(13880952459161074539)
,p_short_name=>'Delete Test Data'
,p_link=>'f?p=&APP_ID.:82:&SESSION.'
,p_page_id=>82
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13975270762308089502)
,p_parent_id=>wwv_flow_imp.id(17625504044345490706)
,p_short_name=>'Opt Out User List'
,p_link=>'f?p=&APP_ID.:34:&SESSION.'
,p_page_id=>34
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14002428469487223152)
,p_short_name=>'Invitations'
,p_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:::'
,p_page_id=>16
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14010479875207602277)
,p_parent_id=>wwv_flow_imp.id(17625504044345490706)
,p_short_name=>'Build Options'
,p_link=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_page_id=>2
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14015490979535064672)
,p_short_name=>'Invitations Sent'
,p_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::'
,p_page_id=>23
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14015492661426082480)
,p_parent_id=>wwv_flow_imp.id(13880952459161074539)
,p_short_name=>'Manual Invitations Recorded'
,p_link=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:::'
,p_page_id=>36
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14021582662250171463)
,p_short_name=>'Results Across Polls'
,p_link=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:::'
,p_page_id=>41
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14022586574192457201)
,p_short_name=>'Opt Out User Details'
,p_link=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.:::'
,p_page_id=>46
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14034409748623066214)
,p_short_name=>'&P67_POLL_NAME.'
,p_link=>'f?p=&APP_ID.:67:&SESSION.::&DEBUG.:::'
,p_page_id=>67
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14042244477198956528)
,p_parent_id=>wwv_flow_imp.id(17625504044345490706)
,p_short_name=>'Respondent Details'
,p_link=>'f?p=&APP_ID.:86:&SESSION.::&DEBUG.:::'
,p_page_id=>86
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14049042759159160739)
,p_parent_id=>wwv_flow_imp.id(17625504044345490706)
,p_short_name=>'Remove Extraneous Characters'
,p_link=>'f?p=&APP_ID.:15:&SESSION.'
,p_page_id=>15
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14052335457177652223)
,p_parent_id=>wwv_flow_imp.id(13936779464897481297)
,p_short_name=>'Email Results'
,p_link=>'f?p=&APP_ID.:90:&SESSION.'
,p_page_id=>90
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14052337048223656038)
,p_parent_id=>wwv_flow_imp.id(13936779464897481297)
,p_short_name=>'Results Emailed'
,p_link=>'f?p=&APP_ID.:91:&SESSION.::&DEBUG.:::'
,p_page_id=>91
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14524200997039459654)
,p_parent_id=>wwv_flow_imp.id(17625504044345490706)
,p_short_name=>'Page Privileges'
,p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14537613197248371007)
,p_parent_id=>wwv_flow_imp.id(17625504044345490706)
,p_short_name=>'Rename Application'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14640951699582340887)
,p_parent_id=>wwv_flow_imp.id(17625504044345490706)
,p_short_name=>'Username Format'
,p_link=>'f?p=&APP_ID.:43:&SESSION.'
,p_page_id=>43
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14829593071754304722)
,p_parent_id=>wwv_flow_imp.id(17625504044345490706)
,p_short_name=>'Application Theme Style'
,p_link=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:::'
,p_page_id=>20
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14878277631302396781)
,p_short_name=>'&POLL_NAME.'
,p_link=>'f?p=&FLOW_ID.:50:&SESSION.'
,p_page_id=>50
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14974250682115016169)
,p_parent_id=>wwv_flow_imp.id(17625504044345490706)
,p_short_name=>'Manage Sample Data'
,p_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:::'
,p_page_id=>32
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16150654381924461251)
,p_parent_id=>wwv_flow_imp.id(17625504044345490706)
,p_short_name=>'Notifications'
,p_link=>'f?p=&FLOW_ID.:30:&SESSION.'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16150748493526473583)
,p_short_name=>'Notification'
,p_link=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:::'
,p_page_id=>31
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16433620103610101745)
,p_parent_id=>wwv_flow_imp.id(17606939022159648525)
,p_short_name=>'Help'
,p_link=>'f?p=&FLOW_ID.:39:&SESSION.'
,p_page_id=>39
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16514775401325715086)
,p_parent_id=>wwv_flow_imp.id(17625504044345490706)
,p_short_name=>'Application Error Log'
,p_link=>'f?p=&APP_ID.:175:&SESSION.::&DEBUG.:::'
,p_page_id=>175
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16544780108625580791)
,p_parent_id=>wwv_flow_imp.id(17625504044345490706)
,p_short_name=>'Activity Calendar'
,p_link=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:::'
,p_page_id=>42
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(17606939022159648525)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&SESSION.'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(17625504044345490706)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(17626722314380141557)
,p_parent_id=>wwv_flow_imp.id(17625504044345490706)
,p_short_name=>'Top Users'
,p_link=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:::'
,p_page_id=>12
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(17626770825574155266)
,p_parent_id=>wwv_flow_imp.id(17625504044345490706)
,p_short_name=>'Application Page Views'
,p_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_imp.component_end;
end;
/
