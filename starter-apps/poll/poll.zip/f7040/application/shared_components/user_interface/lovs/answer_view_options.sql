prompt --application/shared_components/user_interface/lovs/answer_view_options
begin
--   Manifest
--     ANSWER VIEW OPTIONS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(13919974185343642850)
,p_lov_name=>'ANSWER VIEW OPTIONS'
,p_lov_query=>'.'||wwv_flow_imp.id(13919974185343642850)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089050995
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13919974380487642870)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Detailed Answers'
,p_lov_return_value=>'DA'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13919974664627642878)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Summarized Answers'
,p_lov_return_value=>'SA'
);
wwv_flow_imp.component_end;
end;
/
