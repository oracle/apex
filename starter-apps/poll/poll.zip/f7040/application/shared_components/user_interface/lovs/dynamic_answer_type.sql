prompt --application/shared_components/user_interface/lovs/dynamic_answer_type
begin
--   Manifest
--     DYNAMIC ANSWER TYPE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(13875600914451207054)
,p_lov_name=>'DYNAMIC ANSWER TYPE'
,p_static_id=>'dynamic-answer-type'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d, r',
'from',
'(',
'select ''Pick one'' d, ''RADIO_GROUP'' r, 1 sort_order',
'from dual',
'union all',
'select ''Pick many'' d, ''CHECKBOX'' r, 3 sort_order',
'from dual',
'union all',
'select ''Stack Rank'' d, ''STACK'' r, 4 sort_order',
'from dual',
'union all',
'select ''Allocate $100'' d, ''ALLOCATION'' r, 5 sort_order',
'from dual',
'union all',
'select name d, code r, sort_order',
'from   EBA_QPOLL_CANNED_ANSWERS',
')',
'order by sort_order, d'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>'1089050995'
);
wwv_flow_imp.component_end;
end;
/
