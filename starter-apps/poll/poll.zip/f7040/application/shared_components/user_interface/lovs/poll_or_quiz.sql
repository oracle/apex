prompt --application/shared_components/user_interface/lovs/poll_or_quiz
begin
--   Manifest
--     POLL OR QUIZ
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(340079999374331208)
,p_lov_name=>'POLL OR QUIZ'
,p_static_id=>'poll-or-quiz'
,p_lov_query=>'.'||wwv_flow_imp.id(340079999374331208)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089050995'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(340080326766331209)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Poll'
,p_lov_return_value=>'P'
,p_static_id=>'poll'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(340080736067331210)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Quiz'
,p_lov_return_value=>'Q'
,p_static_id=>'quiz'
);
wwv_flow_imp.component_end;
end;
/
