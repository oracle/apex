prompt --application/shared_components/user_interface/lovs/poll_or_quiz
begin
--   Manifest
--     POLL OR QUIZ
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(341555843926745738)
,p_lov_name=>'POLL OR QUIZ'
,p_lov_query=>'.'||wwv_flow_imp.id(341555843926745738)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089050995
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(341556171318745739)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Poll'
,p_lov_return_value=>'P'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(341556580619745740)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Quiz'
,p_lov_return_value=>'Q'
);
wwv_flow_imp.component_end;
end;
/
