prompt --application/shared_components/user_interface/lovs/poll_statuses
begin
--   Manifest
--     POLL STATUSES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(232055347227041355)
,p_lov_name=>'POLL STATUSES'
,p_lov_query=>'.'||wwv_flow_imp.id(232055347227041355)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089050995
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(232055667617041355)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Being Authored'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(232056050976041356)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Testing, Contributors only'
,p_lov_return_value=>'2'
,p_lov_disp_cond_type=>'EXISTS'
,p_lov_disp_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_questions',
' where poll_id = :POLL_ID'))
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(232056434758041356)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Published'
,p_lov_return_value=>'3'
,p_lov_disp_cond_type=>'EXISTS'
,p_lov_disp_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from eba_qpoll_questions',
' where poll_id = :POLL_ID'))
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(232056835512041356)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Closed'
,p_lov_return_value=>'4'
);
wwv_flow_imp.component_end;
end;
/
