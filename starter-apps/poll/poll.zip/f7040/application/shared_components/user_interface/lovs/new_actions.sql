prompt --application/shared_components/user_interface/lovs/new_actions
begin
--   Manifest
--     NEW ACTIONS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(13959981228749446325)
,p_lov_name=>'NEW ACTIONS'
,p_lov_query=>'.'||wwv_flow_imp.id(13959981228749446325)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089050995
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13959981430882446326)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Create a New Question Set'
,p_lov_return_value=>'QS'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13959982934210462301)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Create a new community of poll recipients'
,p_lov_return_value=>'C'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13959984624925481792)
,p_lov_disp_sequence=>30
,p_lov_disp_value=>'Publish a question set as a Poll'
,p_lov_return_value=>'P'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13959986917148500538)
,p_lov_disp_sequence=>40
,p_lov_disp_value=>'Send invitations to a community to take a published poll'
,p_lov_return_value=>'I'
);
wwv_flow_imp.component_end;
end;
/
