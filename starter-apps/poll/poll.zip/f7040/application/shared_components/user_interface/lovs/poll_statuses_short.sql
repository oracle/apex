prompt --application/shared_components/user_interface/lovs/poll_statuses_short
begin
--   Manifest
--     POLL STATUSES (SHORT)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(230581295587629747)
,p_lov_name=>'POLL STATUSES (SHORT)'
,p_static_id=>'poll-statuses-short'
,p_lov_query=>'.'||wwv_flow_imp.id(230581295587629747)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089050995'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(230581615250629748)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Being Authored'
,p_lov_return_value=>'1'
,p_static_id=>'being-authored'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(230582827166629754)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Closed'
,p_lov_return_value=>'4'
,p_static_id=>'closed'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(230582414070629750)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Published'
,p_lov_return_value=>'3'
,p_static_id=>'published'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(230581980552629749)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Testing'
,p_lov_return_value=>'2'
,p_static_id=>'testing'
);
wwv_flow_imp.component_end;
end;
/
