prompt --application/shared_components/user_interface/lovs/p1_contrib_reader_view
begin
--   Manifest
--     P1_CONTRIB_READER_VIEW
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(554285732322761223)
,p_lov_name=>'P1_CONTRIB_READER_VIEW'
,p_lov_query=>'.'||wwv_flow_imp.id(554285732322761223)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089050995
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(554286011530761224)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Contributor View'
,p_lov_return_value=>'C'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(554286417233761224)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Reader View'
,p_lov_return_value=>'R'
);
wwv_flow_imp.component_end;
end;
/
