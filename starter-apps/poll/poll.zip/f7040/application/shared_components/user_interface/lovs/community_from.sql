prompt --application/shared_components/user_interface/lovs/community_from
begin
--   Manifest
--     COMMUNITY FROM
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(13939949457232310503)
,p_lov_name=>'COMMUNITY FROM'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select name, id',
'from EBA_QPOLL_RESP_COMMUNITIES',
'where id <> nvl(:P70_COMMUNITY_ID_TO,-1)',
'order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1089050995
);
wwv_flow_imp.component_end;
end;
/
