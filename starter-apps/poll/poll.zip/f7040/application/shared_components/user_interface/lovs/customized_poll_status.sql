prompt --application/shared_components/user_interface/lovs/customized_poll_status
begin
--   Manifest
--     CUSTOMIZED POLL STATUS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(14016699084536086765)
,p_lov_name=>'CUSTOMIZED POLL STATUS'
,p_lov_query=>'.'||wwv_flow_imp.id(14016699084536086765)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14016699393170086771)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Published'
,p_lov_return_value=>'3N'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14016699695527086774)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Published, Invitees only'
,p_lov_return_value=>'3Y'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14016699976304086774)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Testing, Contributors only'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14016700288390086774)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Closed'
,p_lov_return_value=>'4'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(207054203036841939)
,p_lov_disp_sequence=>14
,p_lov_disp_value=>'Being Authored'
,p_lov_return_value=>'1'
);
wwv_flow_imp.component_end;
end;
/
