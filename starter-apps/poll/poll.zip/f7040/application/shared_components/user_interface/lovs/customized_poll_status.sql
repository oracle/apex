prompt --application/shared_components/user_interface/lovs/customized_poll_status
begin
--   Manifest
--     CUSTOMIZED POLL STATUS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(14033811924142814410)
,p_lov_name=>'CUSTOMIZED POLL STATUS'
,p_static_id=>'customized-poll-status'
,p_lov_query=>'.'||wwv_flow_imp.id(14033811924142814410)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089050995'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(224167042643569584)
,p_lov_disp_sequence=>14
,p_lov_disp_value=>'Being Authored'
,p_lov_return_value=>'1'
,p_static_id=>'being-authored'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14033813127996814419)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Closed'
,p_lov_return_value=>'4'
,p_static_id=>'closed'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14033812232776814416)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Published'
,p_lov_return_value=>'3N'
,p_static_id=>'published'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14033812535133814419)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Published, Invitees only'
,p_lov_return_value=>'3Y'
,p_static_id=>'published-invitees-only'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14033812815910814419)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Testing, Contributors only'
,p_lov_return_value=>'2'
,p_static_id=>'testing-contributors-only'
);
wwv_flow_imp.component_end;
end;
/
