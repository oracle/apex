prompt --application/shared_components/user_interface/lovs/customized_poll_status
begin
--   Manifest
--     CUSTOMIZED POLL STATUS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(14035287768695228940)
,p_lov_name=>'CUSTOMIZED POLL STATUS'
,p_lov_query=>'.'||wwv_flow_imp.id(14035287768695228940)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089050995
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14035288077329228946)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Published'
,p_lov_return_value=>'3N'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14035288379686228949)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Published, Invitees only'
,p_lov_return_value=>'3Y'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14035288660463228949)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Testing, Contributors only'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14035288972549228949)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Closed'
,p_lov_return_value=>'4'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(225642887195984114)
,p_lov_disp_sequence=>14
,p_lov_disp_value=>'Being Authored'
,p_lov_return_value=>'1'
);
wwv_flow_imp.component_end;
end;
/
