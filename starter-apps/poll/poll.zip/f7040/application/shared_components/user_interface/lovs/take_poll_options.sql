prompt --application/shared_components/user_interface/lovs/take_poll_options
begin
--   Manifest
--     TAKE POLL OPTIONS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(14002735218801071743)
,p_lov_name=>'TAKE POLL OPTIONS'
,p_lov_query=>'.'||wwv_flow_imp.id(14002735218801071743)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089050995
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14002735513319071744)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Take It'
,p_lov_return_value=>'Take It'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14002735832601071747)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Update'
,p_lov_return_value=>'Update'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14002736103888071748)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Has Errors'
,p_lov_return_value=>'Has Errors'
);
wwv_flow_imp.component_end;
end;
/
