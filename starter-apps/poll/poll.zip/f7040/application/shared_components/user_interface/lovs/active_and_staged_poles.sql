prompt --application/shared_components/user_interface/lovs/active_and_staged_poles
begin
--   Manifest
--     ACTIVE AND STAGED POLES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(13985630495470698992)
,p_lov_name=>'ACTIVE AND STAGED POLES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    poll_name dv, ',
'    id        rv',
'from',
'    eba_qpoll_polls p',
'where',
'    status_id > 1',
'order by',
'    1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
);
wwv_flow_imp.component_end;
end;
/
