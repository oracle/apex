prompt --application/shared_components/user_interface/lovs/i_accept
begin
--   Manifest
--     I ACCEPT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>17112839606727645
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(14008377833863501056)
,p_lov_name=>'I ACCEPT'
,p_lov_query=>'.'||wwv_flow_imp.id(14008377833863501056)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089050995
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14008378007600501056)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>' I Accept'
,p_lov_return_value=>'ACCEPTED'
);
wwv_flow_imp.component_end;
end;
/
