prompt --application/shared_components/user_interface/lovs/i_accept
begin
--   Manifest
--     I ACCEPT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(14008377833863501056)
,p_lov_name=>'I ACCEPT'
,p_static_id=>'i-accept'
,p_lov_query=>'.'||wwv_flow_imp.id(14008377833863501056)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089050995'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14008378007600501056)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>' I Accept'
,p_lov_return_value=>'ACCEPTED'
,p_static_id=>'i-accept'
);
wwv_flow_imp.component_end;
end;
/
