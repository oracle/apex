prompt --application/shared_components/user_interface/lovs/qset_score_type
begin
--   Manifest
--     QSET_SCORE_TYPE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(13931108289557842162)
,p_lov_name=>'QSET_SCORE_TYPE'
,p_lov_query=>'.'||wwv_flow_imp.id(13931108289557842162)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13931108585542842165)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'None'
,p_lov_return_value=>'N'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13931108887400842169)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Average'
,p_lov_return_value=>'A'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13931109179404842169)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Cumulative'
,p_lov_return_value=>'C'
);
wwv_flow_imp.component_end;
end;
/
