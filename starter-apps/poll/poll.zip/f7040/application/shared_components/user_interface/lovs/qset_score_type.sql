prompt --application/shared_components/user_interface/lovs/qset_score_type
begin
--   Manifest
--     QSET_SCORE_TYPE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(13949696973716984337)
,p_lov_name=>'QSET_SCORE_TYPE'
,p_lov_query=>'.'||wwv_flow_imp.id(13949696973716984337)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089050995
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13949697269701984340)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'None'
,p_lov_return_value=>'N'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13949697571559984344)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Average'
,p_lov_return_value=>'A'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13949697863563984344)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Cumulative'
,p_lov_return_value=>'C'
);
wwv_flow_imp.component_end;
end;
/
