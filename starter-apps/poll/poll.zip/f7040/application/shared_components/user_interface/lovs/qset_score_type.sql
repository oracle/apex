prompt --application/shared_components/user_interface/lovs/qset_score_type
begin
--   Manifest
--     QSET_SCORE_TYPE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(13948221129164569807)
,p_lov_name=>'QSET_SCORE_TYPE'
,p_static_id=>'qset-score-type'
,p_lov_query=>'.'||wwv_flow_imp.id(13948221129164569807)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089050995'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13948221727007569814)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Average'
,p_lov_return_value=>'A'
,p_static_id=>'average'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13948222019011569814)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Cumulative'
,p_lov_return_value=>'C'
,p_static_id=>'cumulative'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13948221425149569810)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'None'
,p_lov_return_value=>'N'
,p_static_id=>'none'
);
wwv_flow_imp.component_end;
end;
/
