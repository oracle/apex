prompt --application/shared_components/user_interface/lovs/invite_method
begin
--   Manifest
--     INVITE METHOD
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(14010612974336795626)
,p_lov_name=>'INVITE METHOD'
,p_lov_query=>'.'||wwv_flow_imp.id(14010612974336795626)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089050995
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14010613151141795626)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Automated Email'
,p_lov_return_value=>'EMAIL'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(14010613468174795626)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Manual'
,p_lov_return_value=>'MANUAL'
);
wwv_flow_imp.component_end;
end;
/
