prompt --application/shared_components/user_interface/lovs/no_yes_n_y
begin
--   Manifest
--     NO YES (N/Y)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(13935307710622230175)
,p_lov_name=>'NO YES (N/Y)'
,p_static_id=>'no-yes-n-y'
,p_lov_query=>'.'||wwv_flow_imp.id(13935307710622230175)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089050995'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13935307913578230186)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'No'
,p_lov_return_value=>'N'
,p_static_id=>'no'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13935308207775230194)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'Yes'
,p_lov_return_value=>'Y'
,p_static_id=>'yes'
);
wwv_flow_imp.component_end;
end;
/
