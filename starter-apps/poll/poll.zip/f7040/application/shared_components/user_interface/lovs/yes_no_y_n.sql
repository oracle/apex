prompt --application/shared_components/user_interface/lovs/yes_no_y_n
begin
--   Manifest
--     YES NO  (Y/N)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(16079746045092670001)
,p_lov_name=>'YES NO  (Y/N)'
,p_static_id=>'yes-no-y-n'
,p_lov_query=>'.'||wwv_flow_imp.id(16079746045092670001)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089050995'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(16079746551541670012)
,p_lov_disp_sequence=>20
,p_lov_disp_value=>'No'
,p_lov_return_value=>'N'
,p_static_id=>'no'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(16079746350912670007)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Yes'
,p_lov_return_value=>'Y'
,p_static_id=>'yes'
);
wwv_flow_imp.component_end;
end;
/
