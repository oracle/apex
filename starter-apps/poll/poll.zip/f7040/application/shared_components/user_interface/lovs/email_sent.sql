prompt --application/shared_components/user_interface/lovs/email_sent
begin
--   Manifest
--     EMAIL_SENT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(13984005084394205936)
,p_lov_name=>'EMAIL_SENT'
,p_lov_query=>'.'||wwv_flow_imp.id(13984005084394205936)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13984005364940205943)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Yes'
,p_lov_return_value=>'YES'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13984005685875205946)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Opted Out'
,p_lov_return_value=>'OPTED_OUT'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13984005969295205947)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Previously Sent'
,p_lov_return_value=>'PREVIOUSLY_SENT'
);
wwv_flow_imp.component_end;
end;
/
