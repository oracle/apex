prompt --application/shared_components/user_interface/lovs/question_type
begin
--   Manifest
--     QUESTION TYPE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(13873065729244067844)
,p_lov_name=>'QUESTION TYPE'
,p_static_id=>'question-type'
,p_lov_query=>'.'||wwv_flow_imp.id(13873065729244067844)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089050995'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874308911584445801)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Free form text'
,p_lov_return_value=>'TEXTAREA'
,p_static_id=>'free-form-text'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13873066234049067864)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Pick Many'
,p_lov_return_value=>'CHECKBOX'
,p_static_id=>'pick-many'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13873065925875067855)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Pick One'
,p_lov_return_value=>'RADIO_GROUP'
,p_static_id=>'pick-one'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874312407031478342)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Pick Two Values'
,p_lov_return_value=>'PICK_TWO'
,p_static_id=>'pick-two-values'
,p_lov_disp_cond_type=>'NEVER'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874316828942574528)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Complex to 5 = Simple'
,p_lov_return_value=>'RANGE_SIMPLE_TO_COMPLEX'
,p_static_id=>'range-1-complex-to-5-simple'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874309233569450785)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Disagree to 5 = Fully Agree'
,p_lov_return_value=>'RANGE_AGREE_DISAGREE'
,p_static_id=>'range-1-disagree-to-5-fully-agree'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874316508682568720)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Hard to 5 = Easy'
,p_lov_return_value=>'RANGE_HARD_TO_EASY'
,p_static_id=>'range-1-hard-to-5-easy'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874312822330486360)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Hate it to 5 = Love it'
,p_lov_return_value=>'RANGE_LOVE_HATE'
,p_static_id=>'range-1-hate-it-to-5-love-it'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874309528178453270)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Least Likely to 5 = Most Likely'
,p_lov_return_value=>'RANGE_LIKELIHOOD'
,p_static_id=>'range-1-least-likely-to-5-most-likely'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874319226303636476)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Least valuable to 5 = Most Valuable'
,p_lov_return_value=>'RANGE_VALUE'
,p_static_id=>'range-1-least-valuable-to-5-most-valuable'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874308615035444213)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Lowest to 5 = Highest'
,p_lov_return_value=>'RANGE_LOW_TO_HIGH'
,p_static_id=>'range-1-lowest-to-5-highest'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874318903240631987)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Megabytes or less to 5 = Petabytes or more'
,p_lov_return_value=>'RANGE_STORAGE'
,p_static_id=>'range-1-megabytes-or-less-to-5-petabytes-or-more'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874313108744492718)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Never to 5 = All of the time'
,p_lov_return_value=>'RANGE_FREQUENCY'
,p_static_id=>'range-1-never-to-5-all-of-the-time'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874318208428614415)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Not Applicable to 5 = Broadly Applicable'
,p_lov_return_value=>'RANGE_APPLICABILITY'
,p_static_id=>'range-1-not-applicable-to-5-broadly-applicable'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874317124628576539)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Obtuse to 5 = Elegant'
,p_lov_return_value=>'RANGE_ELEGANCE'
,p_static_id=>'range-1-obtuse-to-5-elegant'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874311525578469725)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Poor to 5 = Excellent'
,p_lov_return_value=>'RANGE_POOR_TO_EXCELLENT'
,p_static_id=>'range-1-poor-to-5-excellent'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874317804559601041)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Will not use to 5 = Will immediately use'
,p_lov_return_value=>'RANGE_TIMEFRAME'
,p_static_id=>'range-1-will-not-use-to-5-will-immediately-use'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874315814733550729)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Would not consider using to 5 = Will consider using'
,p_lov_return_value=>'RANGE_CONSIDERATION'
,p_static_id=>'range-1-would-not-consider-using-to-5-will-consider-using'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874316128523559542)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Would not endorse to 5 = Would fully endorse'
,p_lov_return_value=>'RANGE_ENDORSE'
,p_static_id=>'range-1-would-not-endorse-to-5-would-fully-endorse'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874313710888506917)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Would not recommend to 5 = Would highly recommend'
,p_lov_return_value=>'RANGE_RECOMMENDATION'
,p_static_id=>'range-1-would-not-recommend-to-5-would-highly-recommend'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874309820414456928)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Yes / No'
,p_lov_return_value=>'YES_NO'
,p_static_id=>'yes-no'
);
wwv_flow_imp.component_end;
end;
/
