prompt --application/shared_components/user_interface/lovs/question_type
begin
--   Manifest
--     QUESTION TYPE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(13874541573796482374)
,p_lov_name=>'QUESTION TYPE'
,p_lov_query=>'.'||wwv_flow_imp.id(13874541573796482374)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089050995
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874541770427482385)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Pick One'
,p_lov_return_value=>'RADIO_GROUP'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13874542078601482394)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Pick Many'
,p_lov_return_value=>'CHECKBOX'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13875784459587858743)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Lowest to 5 = Highest'
,p_lov_return_value=>'RANGE_LOW_TO_HIGH'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13875784756136860331)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Free form text'
,p_lov_return_value=>'TEXTAREA'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13875785078121865315)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Disagree to 5 = Fully Agree'
,p_lov_return_value=>'RANGE_AGREE_DISAGREE'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13875785372730867800)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Least Likely to 5 = Most Likely'
,p_lov_return_value=>'RANGE_LIKELIHOOD'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13875785664966871458)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Yes / No'
,p_lov_return_value=>'YES_NO'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13875787370130884255)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Poor to 5 = Excellent'
,p_lov_return_value=>'RANGE_POOR_TO_EXCELLENT'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13875788251583892872)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Pick Two Values'
,p_lov_return_value=>'PICK_TWO'
,p_lov_disp_cond_type=>'NEVER'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13875788666882900890)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Hate it to 5 = Love it'
,p_lov_return_value=>'RANGE_LOVE_HATE'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13875788953296907248)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Never to 5 = All of the time'
,p_lov_return_value=>'RANGE_FREQUENCY'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13875789555440921447)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Would not recommend to 5 = Would highly recommend'
,p_lov_return_value=>'RANGE_RECOMMENDATION'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13875791659285965259)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Would not consider using to 5 = Will consider using'
,p_lov_return_value=>'RANGE_CONSIDERATION'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13875791973075974072)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Would not endorse to 5 = Would fully endorse'
,p_lov_return_value=>'RANGE_ENDORSE'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13875792353234983250)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Hard to 5 = Easy'
,p_lov_return_value=>'RANGE_HARD_TO_EASY'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13875792673494989058)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Complex to 5 = Simple'
,p_lov_return_value=>'RANGE_SIMPLE_TO_COMPLEX'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13875792969180991069)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Obtuse to 5 = Elegant'
,p_lov_return_value=>'RANGE_ELEGANCE'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13875793649112015571)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Will not use to 5 = Will immediately use'
,p_lov_return_value=>'RANGE_TIMEFRAME'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13875794052981028945)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Not Applicable to 5 = Broadly Applicable'
,p_lov_return_value=>'RANGE_APPLICABILITY'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13875794747793046517)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Megabytes or less to 5 = Petabytes or more'
,p_lov_return_value=>'RANGE_STORAGE'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(13875795070856051006)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Least valuable to 5 = Most Valuable'
,p_lov_return_value=>'RANGE_VALUE'
);
wwv_flow_imp.component_end;
end;
/
