prompt --application/shared_components/user_interface/lovs/question_type
begin
--   Manifest
--     QUESTION TYPE
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-13'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(13855952889637340199)
,p_lov_name=>'QUESTION TYPE'
,p_lov_query=>'.'||wwv_flow_api.id(13855952889637340199)||'.'
,p_location=>'STATIC'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13855953086268340210)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Pick One'
,p_lov_return_value=>'RADIO_GROUP'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13855953394442340219)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Pick Many'
,p_lov_return_value=>'CHECKBOX'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13857195775428716568)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Lowest to 5 = Highest'
,p_lov_return_value=>'RANGE_LOW_TO_HIGH'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13857196071977718156)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Free form text'
,p_lov_return_value=>'TEXTAREA'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13857196393962723140)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Disagree to 5 = Fully Agree'
,p_lov_return_value=>'RANGE_AGREE_DISAGREE'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13857196688571725625)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Least Likely to 5 = Most Likely'
,p_lov_return_value=>'RANGE_LIKELIHOOD'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13857196980807729283)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Yes / No'
,p_lov_return_value=>'YES_NO'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13857198685971742080)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Poor to 5 = Excellent'
,p_lov_return_value=>'RANGE_POOR_TO_EXCELLENT'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13857199567424750697)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Pick Two Values'
,p_lov_return_value=>'PICK_TWO'
,p_lov_disp_cond_type=>'NEVER'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13857199982723758715)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Hate it to 5 = Love it'
,p_lov_return_value=>'RANGE_LOVE_HATE'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13857200269137765073)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Never to 5 = All of the time'
,p_lov_return_value=>'RANGE_FREQUENCY'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13857200871281779272)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Would not recommend to 5 = Would highly recommend'
,p_lov_return_value=>'RANGE_RECOMMENDATION'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13857202975126823084)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Would not consider using to 5 = Will consider using'
,p_lov_return_value=>'RANGE_CONSIDERATION'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13857203288916831897)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Would not endorse to 5 = Would fully endorse'
,p_lov_return_value=>'RANGE_ENDORSE'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13857203669075841075)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Hard to 5 = Easy'
,p_lov_return_value=>'RANGE_HARD_TO_EASY'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13857203989335846883)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Complex to 5 = Simple'
,p_lov_return_value=>'RANGE_SIMPLE_TO_COMPLEX'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13857204285021848894)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Obtuse to 5 = Elegant'
,p_lov_return_value=>'RANGE_ELEGANCE'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13857204964952873396)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Will not use to 5 = Will immediately use'
,p_lov_return_value=>'RANGE_TIMEFRAME'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13857205368821886770)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Not Applicable to 5 = Broadly Applicable'
,p_lov_return_value=>'RANGE_APPLICABILITY'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13857206063633904342)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Megabytes or less to 5 = Petabytes or more'
,p_lov_return_value=>'RANGE_STORAGE'
);
wwv_flow_api.create_static_lov_data(
 p_id=>wwv_flow_api.id(13857206386696908831)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Range: 1 = Least valuable to 5 = Most Valuable'
,p_lov_return_value=>'RANGE_VALUE'
);
wwv_flow_api.component_end;
end;
/
