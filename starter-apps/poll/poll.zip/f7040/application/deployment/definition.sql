prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7040
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'drop table eba_qpoll_sections           cascade constraints;'||wwv_flow.LF||
'drop table eba_qpoll_questions         ';
wwv_flow_imp.g_varchar2_table(2) := ' cascade constraints;'||wwv_flow.LF||
'drop table eba_qpoll_resp_communities   cascade constraints;'||wwv_flow.LF||
'drop table eba_qp';
wwv_flow_imp.g_varchar2_table(3) := 'oll_comm_invites       cascade constraints;'||wwv_flow.LF||
'drop table eba_qpoll_invites            cascade constrai';
wwv_flow_imp.g_varchar2_table(4) := 'nts;'||wwv_flow.LF||
'drop table eba_qpoll_canned_answers     cascade constraints;'||wwv_flow.LF||
'drop table eba_qpoll_respondents  ';
wwv_flow_imp.g_varchar2_table(5) := '      cascade constraints;'||wwv_flow.LF||
'drop table eba_qpoll_polls              cascade constraints;'||wwv_flow.LF||
'drop table e';
wwv_flow_imp.g_varchar2_table(6) := 'ba_qpoll_notifications      cascade constraints;'||wwv_flow.LF||
'drop table eba_qpoll_preferences        cascade con';
wwv_flow_imp.g_varchar2_table(7) := 'straints;'||wwv_flow.LF||
'drop table eba_qpoll_errors             cascade constraints;'||wwv_flow.LF||
'drop table eba_qpoll_results ';
wwv_flow_imp.g_varchar2_table(8) := '           cascade constraints;'||wwv_flow.LF||
'drop table eba_qpoll_access_requests    cascade constraints;'||wwv_flow.LF||
'drop ta';
wwv_flow_imp.g_varchar2_table(9) := 'ble eba_qpoll_error_log          cascade constraints;'||wwv_flow.LF||
'drop table eba_qpoll_application_log    cascad';
wwv_flow_imp.g_varchar2_table(10) := 'e constraints;'||wwv_flow.LF||
'drop table eba_qpoll_user_log           cascade constraints;'||wwv_flow.LF||
'drop table eba_qpoll_ema';
wwv_flow_imp.g_varchar2_table(11) := 'ils             cascade constraints;'||wwv_flow.LF||
'drop table eba_qpoll_result_details     cascade constraints;'||wwv_flow.LF||
'dr';
wwv_flow_imp.g_varchar2_table(12) := 'op table eba_qpoll_resp_comm_ref      cascade constraints;'||wwv_flow.LF||
'drop table eba_qpoll_email_opt_out      c';
wwv_flow_imp.g_varchar2_table(13) := 'ascade constraints;'||wwv_flow.LF||
'drop table eba_qpoll_history            cascade constraints;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop sequence eba_';
wwv_flow_imp.g_varchar2_table(14) := 'qpoll_seq;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop package eba_qpoll;'||wwv_flow.LF||
'drop package eba_qpoll_fw;'||wwv_flow.LF||
'drop package eba_qpoll_quiz;'||wwv_flow.LF||
'drop pac';
wwv_flow_imp.g_varchar2_table(15) := 'kage eba_qpoll_account;'||wwv_flow.LF||
'drop package eba_qpoll_email;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(15922417043420668813)
,p_welcome_message=>'This application installer will guide you through the process of creating your database objects and seed data.'
,p_configuration_message=>'You can configure the following attributes of your application.'
,p_build_options_message=>'You can choose to include the following build options.'
,p_validation_message=>'The following validations will be performed to ensure your system is compatible with this application.'
,p_install_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_install_success_message=>'Your application''s supporting objects have been installed.'
,p_install_failure_message=>'Installation of database objects and seed data has failed.'
,p_upgrade_message=>'The application installer has detected that this application''s supporting objects were previously installed.  This wizard will guide you through the process of upgrading these supporting objects.'
,p_upgrade_confirm_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_success_message=>'Your application''s supporting objects have been installed.'
,p_upgrade_failure_message=>'Installation of database objects and seed data has failed.'
,p_get_version_sql_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select object_name',
'from user_objects',
'where object_name like ''EBA_QPOLL_%'''))
,p_deinstall_success_message=>'Deinstallation complete.'
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE SEQUENCE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
,p_required_names_available=>'EBA_QPOLL_POLLS:EBA_QPOLL_NOTIFICATIONS:EBA_QPOLL_PREFERENCES:EBA_QPOLL:EBA_QPOLL_FW:EBA_QPOLL_SEQ:EBA_QPOLL_QUIZ:EBA_QPOLL_ACCOUNT:EBA_QPOLL_RESP_COMM_REF:EBA_QPOLL_RESPONDENTS:EBA_QPOLL_RESP_COMMUNITIES:EBA_QPOLL_RESULTS:EBA_QPOLL_RESULT_DETAILS:EB'
||'A_QPOLL_USER_LOG:EBA_QPOLL_APPLICATION_LOG:EBA_QPOLL_ERROR_LOG:EBA_QPOLL_ACCESS_REQUESTS:EBA_QPOLL_CANNED_ANSWERS:EBA_QPOLL_QUESTIONS:EBA_QPOLL_ERRORS:EBA_QPOLL_EMAIL_OPT_OUT:EBA_QPOLL_INVITES:EBA_QPOLL_COMM_INVITES:EBA_QPOLL_EMAILS:EBA_QPOLL_EMAIL'
,p_deinstall_message=>'This operation will completely remove this application from your workspace.'
);
wwv_flow_imp.component_end;
end;
/
