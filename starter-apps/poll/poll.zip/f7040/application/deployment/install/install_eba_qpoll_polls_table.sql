prompt --application/deployment/install/install_eba_qpoll_polls_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_polls table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE EBA_QPOLL_POLLS '||wwv_flow.LF||
'   ('||wwv_flow.LF||
'    ID                    NUMBER constraint EBA_QPOLL_POLL_PK pri';
wwv_flow_imp.g_varchar2_table(2) := 'mary key, '||wwv_flow.LF||
'    ROW_VERSION_NUMBER    NUMBER not null, '||wwv_flow.LF||
'    ROW_KEY               VARCHAR2(30), '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(3) := 'POLL_NAME             VARCHAR2(255) not null, '||wwv_flow.LF||
'    Poll_details          varchar2(4000),'||wwv_flow.LF||
'    intro_t';
wwv_flow_imp.g_varchar2_table(4) := 'ext            varchar2(4000),'||wwv_flow.LF||
'    thank_you_text        varchar2(4000),'||wwv_flow.LF||
'    STATUS_ID             N';
wwv_flow_imp.g_varchar2_table(5) := 'UMBER       not null'||wwv_flow.LF||
'                             constraint EBA_QPOLL_POLL_status_cc '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(6) := '                  check (status_id in (1,2,3,4)), '||wwv_flow.LF||
'    poll_or_quiz          varchar2(1)  not null,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(7) := '    score_type            varchar2(1)  default ''N'','||wwv_flow.LF||
'    use_sections_yn       varchar2(1)  default ''';
wwv_flow_imp.g_varchar2_table(8) := 'N'','||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    image_filename        VARCHAR2(4000),         '||wwv_flow.LF||
'    image_mimetype        VARCHAR2(512';
wwv_flow_imp.g_varchar2_table(9) := '),'||wwv_flow.LF||
'    image_charset         VARCHAR2(512),'||wwv_flow.LF||
'    image_blob            BLOB,'||wwv_flow.LF||
'    image_last_updated  ';
wwv_flow_imp.g_varchar2_table(10) := '  DATE,'||wwv_flow.LF||
'    image_width           number,'||wwv_flow.LF||
'    image_height          number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    anonymous_yn ';
wwv_flow_imp.g_varchar2_table(11) := '         varchar2(1) default ''N'','||wwv_flow.LF||
'    can_update_answers_yn varchar2(1) default ''N'','||wwv_flow.LF||
'    all_view_re';
wwv_flow_imp.g_varchar2_table(12) := 'sults_yn   varchar2(1) default ''Y'','||wwv_flow.LF||
'    enable_score_yn       varchar2(1) default ''N'', '||wwv_flow.LF||
'    invite_o';
wwv_flow_imp.g_varchar2_table(13) := 'nly_yn        varchar2(1) default ''N'','||wwv_flow.LF||
'    authentication_req_yn varchar2(1) default ''N'','||wwv_flow.LF||
'    start_';
wwv_flow_imp.g_varchar2_table(14) := 'time            TIMESTAMP WITH TIME ZONE, '||wwv_flow.LF||
'    stop_time             TIMESTAMP WITH TIME ZONE, '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(15) := '--'||wwv_flow.LF||
'    invite_subject        varchar2(4000),'||wwv_flow.LF||
'    invite_body           clob,'||wwv_flow.LF||
'    reminder_subject   ';
wwv_flow_imp.g_varchar2_table(16) := '   varchar2(4000),'||wwv_flow.LF||
'    reminder_body         clob,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    CREATED_BY            VARCHAR2(255), '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(17) := '    CREATED               TIMESTAMP WITH TIME ZONE, '||wwv_flow.LF||
'    UPDATED_BY            VARCHAR2(255), '||wwv_flow.LF||
'    U';
wwv_flow_imp.g_varchar2_table(18) := 'PDATED               TIMESTAMP WITH TIME ZONE'||wwv_flow.LF||
'   )  ;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create index EBA_QPOLL_POLLS_I1 on EBA_QPOLL';
wwv_flow_imp.g_varchar2_table(19) := '_POLLS(STATUS_ID);'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_qpoll_polls'||wwv_flow.LF||
'add constraint eba_qpoll_polls_cc1'||wwv_flow.LF||
'check (poll_or_qu';
wwv_flow_imp.g_varchar2_table(20) := 'iz in (''P'',''Q''));'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_qpoll_polls'||wwv_flow.LF||
'add constraint eba_qpoll_polls_cc2'||wwv_flow.LF||
'check (score_type ';
wwv_flow_imp.g_varchar2_table(21) := 'in (''A'',''C'',''N''));'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_qpoll_polls'||wwv_flow.LF||
'add constraint eba_qpoll_polls_cc3'||wwv_flow.LF||
'check (use_sectio';
wwv_flow_imp.g_varchar2_table(22) := 'ns_yn in (''Y'',''N''));'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_qpoll_polls'||wwv_flow.LF||
'add constraint eba_qpoll_polls_cc4'||wwv_flow.LF||
'check (anonymou';
wwv_flow_imp.g_varchar2_table(23) := 's_yn in (''Y'',''N''));'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_qpoll_polls'||wwv_flow.LF||
'add constraint eba_qpoll_polls_cc5'||wwv_flow.LF||
'check (can_updat';
wwv_flow_imp.g_varchar2_table(24) := 'e_answers_yn in (''Y'',''N''));'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_qpoll_polls'||wwv_flow.LF||
'add constraint eba_qpoll_polls_cc6'||wwv_flow.LF||
'check (a';
wwv_flow_imp.g_varchar2_table(25) := 'll_view_results_yn in (''Y'',''N''));'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_qpoll_polls'||wwv_flow.LF||
'add constraint eba_qpoll_polls_cc7'||wwv_flow.LF||
'ch';
wwv_flow_imp.g_varchar2_table(26) := 'eck (enable_score_yn in (''Y'',''N''));'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_qpoll_polls'||wwv_flow.LF||
'add constraint eba_qpoll_polls_cc8'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(27) := 'check (invite_only_yn in (''Y'',''N''));'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_qpoll_polls'||wwv_flow.LF||
'add constraint eba_qpoll_polls_cc9';
wwv_flow_imp.g_varchar2_table(28) := ''||wwv_flow.LF||
'check (authentication_req_yn in (''Y'',''N''));'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER EBA_QPOLL_POLLS_BIU'||wwv_flow.LF||
'   befo';
wwv_flow_imp.g_varchar2_table(29) := 're insert or update on EBA_QPOLL_POLLS'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is null then'||wwv_flow.LF||
'      :new.i';
wwv_flow_imp.g_varchar2_table(30) := 'd := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if :new.row_key is null';
wwv_flow_imp.g_varchar2_table(31) := ' then'||wwv_flow.LF||
'      :new.row_key := EBA_QPOLL_FW.compress_int(eba_qpoll_seq.nextval);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inser';
wwv_flow_imp.g_varchar2_table(32) := 'ting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,us';
wwv_flow_imp.g_varchar2_table(33) := 'er);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(34) := '       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:o';
wwv_flow_imp.g_varchar2_table(35) := 'ld.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := cur';
wwv_flow_imp.g_varchar2_table(36) := 'rent_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'   if :new.poll_or_';
wwv_flow_imp.g_varchar2_table(37) := 'quiz = ''Q'' then'||wwv_flow.LF||
'      :new.score_type := ''N'';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'   if :new.status_id = 3 and nvl(:old.stat';
wwv_flow_imp.g_varchar2_table(38) := 'us_id,0) != 3 then'||wwv_flow.LF||
'      :new.start_time := current_timestamp;'||wwv_flow.LF||
'   elsif :new.status_id = 4 and nvl(:';
wwv_flow_imp.g_varchar2_table(39) := 'old.status_id,0) != 4 then'||wwv_flow.LF||
'      :new.stop_time := current_timestamp;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'ALTER TRIGGE';
wwv_flow_imp.g_varchar2_table(40) := 'R EBA_QPOLL_POLLS_BIU ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13872443629301471712)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_polls table'
,p_sequence=>125
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
