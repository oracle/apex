prompt --application/deployment/install/install_eba_qpoll_quiz_body
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_quiz body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body eba_qpoll_quiz is'||wwv_flow.LF||
''||wwv_flow.LF||
'function delim_answers ('||wwv_flow.LF||
'   p_answer_01  in  varch';
wwv_flow_imp.g_varchar2_table(2) := 'ar2,'||wwv_flow.LF||
'   p_answer_02  in  varchar2,'||wwv_flow.LF||
'   p_answer_03  in  varchar2,'||wwv_flow.LF||
'   p_answer_04  in  varchar2,'||wwv_flow.LF||
'   p_';
wwv_flow_imp.g_varchar2_table(3) := 'answer_05  in  varchar2,'||wwv_flow.LF||
'   p_answer_06  in  varchar2,'||wwv_flow.LF||
'   p_answer_07  in  varchar2,'||wwv_flow.LF||
'   p_answer_08 ';
wwv_flow_imp.g_varchar2_table(4) := ' in  varchar2,'||wwv_flow.LF||
'   p_answer_09  in  varchar2,'||wwv_flow.LF||
'   p_answer_10  in  varchar2,'||wwv_flow.LF||
'   p_answer_11  in  varch';
wwv_flow_imp.g_varchar2_table(5) := 'ar2,'||wwv_flow.LF||
'   p_answer_12  in  varchar2'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'   l_concat   varchar2(4000);'||wwv_flow.LF||
'   l_deli';
wwv_flow_imp.g_varchar2_table(6) := 'm    varchar2(1);'||wwv_flow.LF||
'   l_answers  varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'   l_concat := p_answer_01 || p_answer_02 || ';
wwv_flow_imp.g_varchar2_table(7) := 'p_answer_03 || p_answer_04 ||'||wwv_flow.LF||
'               p_answer_05 || p_answer_06 || p_answer_07 || p_answer_0';
wwv_flow_imp.g_varchar2_table(8) := '8 ||'||wwv_flow.LF||
'               p_answer_09 || p_answer_10 || p_answer_11 || p_answer_12;'||wwv_flow.LF||
''||wwv_flow.LF||
'   if instr(l_concat,';
wwv_flow_imp.g_varchar2_table(9) := ''','') = 0 then'||wwv_flow.LF||
'      l_delim := '','';'||wwv_flow.LF||
'   elsif instr(l_concat,'':'') = 0 then'||wwv_flow.LF||
'      l_delim := '':'';'||wwv_flow.LF||
'   e';
wwv_flow_imp.g_varchar2_table(10) := 'lsif instr(l_concat,''/'') = 0 then'||wwv_flow.LF||
'      l_delim := ''/'';'||wwv_flow.LF||
'   elsif instr(l_concat,''~'') = 0 then'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(11) := 'l_delim := ''~'';'||wwv_flow.LF||
'   elsif instr(l_concat,''!'') = 0 then'||wwv_flow.LF||
'      l_delim := ''!'';'||wwv_flow.LF||
'   elsif instr(l_concat,';
wwv_flow_imp.g_varchar2_table(12) := '''$'') = 0 then'||wwv_flow.LF||
'      l_delim := ''$'';'||wwv_flow.LF||
'   elsif instr(l_concat,''%'') = 0 then'||wwv_flow.LF||
'      l_delim := ''%'';'||wwv_flow.LF||
'   e';
wwv_flow_imp.g_varchar2_table(13) := 'lsif instr(l_concat,''^'') = 0 then'||wwv_flow.LF||
'      l_delim := ''^'';'||wwv_flow.LF||
'   elsif instr(l_concat,''a'') = 0 then'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(14) := 'l_delim := ''a'';'||wwv_flow.LF||
'   elsif instr(l_concat,''x'') = 0 then'||wwv_flow.LF||
'      l_delim := ''x'';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'   if trim(p';
wwv_flow_imp.g_varchar2_table(15) := '_answer_01) is not null then'||wwv_flow.LF||
'      l_answers := trim(p_answer_01);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if trim(p_answer_02';
wwv_flow_imp.g_varchar2_table(16) := ') is not null then'||wwv_flow.LF||
'      l_answers := l_answers || l_delim || trim(p_answer_02);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if tr';
wwv_flow_imp.g_varchar2_table(17) := 'im(p_answer_03) is not null then'||wwv_flow.LF||
'      l_answers := l_answers || l_delim || trim(p_answer_03);'||wwv_flow.LF||
'   en';
wwv_flow_imp.g_varchar2_table(18) := 'd if;'||wwv_flow.LF||
'   if trim(p_answer_04) is not null then'||wwv_flow.LF||
'      l_answers := l_answers || l_delim || trim(p_ans';
wwv_flow_imp.g_varchar2_table(19) := 'wer_04);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if trim(p_answer_05) is not null then'||wwv_flow.LF||
'      l_answers := l_answers || l_delim';
wwv_flow_imp.g_varchar2_table(20) := ' || trim(p_answer_05);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if trim(p_answer_06) is not null then'||wwv_flow.LF||
'      l_answers := l_answ';
wwv_flow_imp.g_varchar2_table(21) := 'ers || l_delim || trim(p_answer_06);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if trim(p_answer_07) is not null then'||wwv_flow.LF||
'      l_ans';
wwv_flow_imp.g_varchar2_table(22) := 'wers := l_answers || l_delim || trim(p_answer_07);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if trim(p_answer_08) is not null th';
wwv_flow_imp.g_varchar2_table(23) := 'en'||wwv_flow.LF||
'      l_answers := l_answers || l_delim || trim(p_answer_08);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if trim(p_answer_09) ';
wwv_flow_imp.g_varchar2_table(24) := 'is not null then'||wwv_flow.LF||
'      l_answers := l_answers || l_delim || trim(p_answer_09);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if trim';
wwv_flow_imp.g_varchar2_table(25) := '(p_answer_10) is not null then'||wwv_flow.LF||
'      l_answers := l_answers || l_delim || trim(p_answer_10);'||wwv_flow.LF||
'   end ';
wwv_flow_imp.g_varchar2_table(26) := 'if;'||wwv_flow.LF||
'   if trim(p_answer_11) is not null then'||wwv_flow.LF||
'      l_answers := l_answers || l_delim || trim(p_answe';
wwv_flow_imp.g_varchar2_table(27) := 'r_11);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if trim(p_answer_12) is not null then'||wwv_flow.LF||
'      l_answers := l_answers || l_delim |';
wwv_flow_imp.g_varchar2_table(28) := '| trim(p_answer_12);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'   l_answers := l_delim || l_answers || l_delim;'||wwv_flow.LF||
''||wwv_flow.LF||
'   return l_answe';
wwv_flow_imp.g_varchar2_table(29) := 'rs;'||wwv_flow.LF||
''||wwv_flow.LF||
'end delim_answers;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function delim_answers_disp ('||wwv_flow.LF||
'   p_correct_answer  in  varchar2'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   r';
wwv_flow_imp.g_varchar2_table(30) := 'eturn varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'   l_delim        varchar2(1);'||wwv_flow.LF||
'   l_answer_disp  varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'   l_delim';
wwv_flow_imp.g_varchar2_table(31) := ' := substr(p_correct_answer,1,1);'||wwv_flow.LF||
''||wwv_flow.LF||
'   l_answer_disp := trim(both l_delim from p_correct_answer);'||wwv_flow.LF||
''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(32) := ' l_answer_disp := replace(l_answer_disp,l_delim, '', '');'||wwv_flow.LF||
''||wwv_flow.LF||
'   return l_answer_disp;'||wwv_flow.LF||
''||wwv_flow.LF||
'end delim_answers';
wwv_flow_imp.g_varchar2_table(33) := '_disp;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_qpoll_quiz;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13945070928486907471)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_quiz body'
,p_sequence=>520
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
