prompt --application/deployment/install/install_eba_qpoll_questions_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_questions table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE EBA_QPOLL_QUESTIONS'||wwv_flow.LF||
'   ('||wwv_flow.LF||
'    ID                    NUMBER constraint EBA_QPOLL_QUES_PK ';
wwv_flow_imp.g_varchar2_table(2) := 'primary key, '||wwv_flow.LF||
'    POLL_ID               NUMBER constraint EBA_QPOLL_QUES_FK'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(3) := '  references EBA_QPOLL_POLLS(id)'||wwv_flow.LF||
'                          on delete cascade,'||wwv_flow.LF||
'    ROW_VERSION_NUMBER';
wwv_flow_imp.g_varchar2_table(4) := '    NUMBER not null, '||wwv_flow.LF||
'    row_key               varchar2(30),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    section_id            NUMBE';
wwv_flow_imp.g_varchar2_table(5) := 'R constraint EBA_QPOLL_QUES_FK2'||wwv_flow.LF||
'                          references EBA_QPOLL_SECTIONS(id)'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(6) := '                  on delete set null,'||wwv_flow.LF||
'    display_sequence      number,'||wwv_flow.LF||
'    question              va';
wwv_flow_imp.g_varchar2_table(7) := 'rchar2(4000) not null,'||wwv_flow.LF||
'    question_type         varchar2(30)   not null,'||wwv_flow.LF||
'    mandatory_yn          ';
wwv_flow_imp.g_varchar2_table(8) := 'varchar2(1)    not null,'||wwv_flow.LF||
'    publish_yn            varchar2(1)    not null,'||wwv_flow.LF||
'    allow_comments_yn   ';
wwv_flow_imp.g_varchar2_table(9) := '  varchar2(1)    not null,'||wwv_flow.LF||
'    use_custom_answers_yn varchar2(1)    not null, '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    image_file';
wwv_flow_imp.g_varchar2_table(10) := 'name        VARCHAR2(4000),         '||wwv_flow.LF||
'    image_mimetype        VARCHAR2(512),'||wwv_flow.LF||
'    image_charset     ';
wwv_flow_imp.g_varchar2_table(11) := '    VARCHAR2(512),'||wwv_flow.LF||
'    image_blob            BLOB,'||wwv_flow.LF||
'    image_last_updated    DATE,'||wwv_flow.LF||
'    image_width  ';
wwv_flow_imp.g_varchar2_table(12) := '         number,'||wwv_flow.LF||
'    image_height          number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    answer_01             varchar2(4000),'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(13) := '    answer_02             varchar2(4000),'||wwv_flow.LF||
'    answer_03             varchar2(4000),'||wwv_flow.LF||
'    answer_04   ';
wwv_flow_imp.g_varchar2_table(14) := '          varchar2(4000),'||wwv_flow.LF||
'    answer_05             varchar2(4000),'||wwv_flow.LF||
'    answer_06             varcha';
wwv_flow_imp.g_varchar2_table(15) := 'r2(4000),'||wwv_flow.LF||
'    answer_07             varchar2(4000),'||wwv_flow.LF||
'    answer_08             varchar2(4000),'||wwv_flow.LF||
'    an';
wwv_flow_imp.g_varchar2_table(16) := 'swer_09             varchar2(4000),'||wwv_flow.LF||
'    answer_10             varchar2(4000),'||wwv_flow.LF||
'    answer_11         ';
wwv_flow_imp.g_varchar2_table(17) := '    varchar2(4000),'||wwv_flow.LF||
'    answer_12             varchar2(4000),'||wwv_flow.LF||
'    correct_answer        varchar2(400';
wwv_flow_imp.g_varchar2_table(18) := '0),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    enable_score_yn       varchar2(1) default ''N'','||wwv_flow.LF||
'    answer_01_score       number,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(19) := 'answer_02_score       number,'||wwv_flow.LF||
'    answer_03_score       number,'||wwv_flow.LF||
'    answer_04_score       number,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(20) := '  answer_05_score       number,'||wwv_flow.LF||
'    answer_06_score       number,'||wwv_flow.LF||
'    answer_07_score       number,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(21) := '    answer_08_score       number,'||wwv_flow.LF||
'    answer_09_score       number,'||wwv_flow.LF||
'    answer_10_score       number';
wwv_flow_imp.g_varchar2_table(22) := ','||wwv_flow.LF||
'    answer_11_score       number,'||wwv_flow.LF||
'    answer_12_score       number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    CREATED_BY         ';
wwv_flow_imp.g_varchar2_table(23) := '   VARCHAR2(255 byte), '||wwv_flow.LF||
'    CREATED               TIMESTAMP WITH TIME ZONE, '||wwv_flow.LF||
'    UPDATED_BY         ';
wwv_flow_imp.g_varchar2_table(24) := '   VARCHAR2(255 byte), '||wwv_flow.LF||
'    UPDATED               TIMESTAMP WITH TIME ZONE'||wwv_flow.LF||
'   )  ;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create index EB';
wwv_flow_imp.g_varchar2_table(25) := 'A_QPOLL_QUESTIONS_I1 on EBA_QPOLL_QUESTIONS( POLL_ID );'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_qpoll_questions'||wwv_flow.LF||
'add constra';
wwv_flow_imp.g_varchar2_table(26) := 'int eba_qpoll_questions_cc1'||wwv_flow.LF||
'check (mandatory_yn in (''Y'',''N''));'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_qpoll_questions'||wwv_flow.LF||
'add ';
wwv_flow_imp.g_varchar2_table(27) := 'constraint eba_qpoll_questions_cc2'||wwv_flow.LF||
'check (publish_yn in (''Y'',''N''));'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_qpoll_questions';
wwv_flow_imp.g_varchar2_table(28) := ''||wwv_flow.LF||
'add constraint eba_qpoll_questions_cc3'||wwv_flow.LF||
'check (allow_comments_yn in (''Y'',''N''));'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_qpo';
wwv_flow_imp.g_varchar2_table(29) := 'll_questions'||wwv_flow.LF||
'add constraint eba_qpoll_questions_cc4'||wwv_flow.LF||
'check (use_custom_answers_yn in (''Y'',''N''));'||wwv_flow.LF||
''||wwv_flow.LF||
'alt';
wwv_flow_imp.g_varchar2_table(30) := 'er table eba_qpoll_questions'||wwv_flow.LF||
'add constraint eba_qpoll_questions_cc5'||wwv_flow.LF||
'check (enable_score_yn in (''Y'',''';
wwv_flow_imp.g_varchar2_table(31) := 'N''));'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER EBA_QPOLL_QUESTIONS_BIU'||wwv_flow.LF||
'   before insert or update on EBA_QPOLL_QU';
wwv_flow_imp.g_varchar2_table(32) := 'ESTIONS'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is null then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(),''XXXX';
wwv_flow_imp.g_varchar2_table(33) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if :new.row_key is null then'||wwv_flow.LF||
'      :new.row_key := EBA';
wwv_flow_imp.g_varchar2_table(34) := '_QPOLL_FW.compress_int(eba_qpoll_seq.nextval);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created :';
wwv_flow_imp.g_varchar2_table(35) := '= current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := cur';
wwv_flow_imp.g_varchar2_table(36) := 'rent_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number ';
wwv_flow_imp.g_varchar2_table(37) := ':= 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(38) := '  end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.upd';
wwv_flow_imp.g_varchar2_table(39) := 'ated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.mandatory_yn := nvl(upper(:new.mandatory_yn';
wwv_flow_imp.g_varchar2_table(40) := '),''Y'');'||wwv_flow.LF||
'   :new.publish_yn := nvl(upper(:new.publish_yn),''Y'');'||wwv_flow.LF||
'   :new.allow_comments_yn := nvl(uppe';
wwv_flow_imp.g_varchar2_table(41) := 'r(:new.allow_comments_yn),''N'');'||wwv_flow.LF||
'   if :new.question_type in (''PICK_TWO'',''CHECKBOX'',''TEXTAREA'',''RADIO';
wwv_flow_imp.g_varchar2_table(42) := '_GROUP'',''STACK'',''ALLOCATION'') then'||wwv_flow.LF||
'       :new.use_custom_answers_yn := ''Y'';'||wwv_flow.LF||
'   else'||wwv_flow.LF||
'       :new.use';
wwv_flow_imp.g_varchar2_table(43) := '_custom_answers_yn := ''N'';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'ALTER TRIGGER EBA_QPOLL_QUESTIONS_BIU ENABLE;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13872263424773193063)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_questions table'
,p_sequence=>140
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
