prompt --application/deployment/install/install_eba_qpoll_preferences_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_preferences table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_qpoll_preferences ('||wwv_flow.LF||
'    id                      number              not null'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(2) := '                                          constraint eba_qpoll_preferences_pk'||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(3) := '                          primary key,'||wwv_flow.LF||
'    preference_name         varchar2(255)       not null'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(4) := '                                            constraint eba_qp_prefs_prefname_ck'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(5) := '                            check (upper(preference_name)=preference_name),'||wwv_flow.LF||
'    preference_value    ';
wwv_flow_imp.g_varchar2_table(6) := '    varchar2(255)       not null,'||wwv_flow.LF||
'    created_by              varchar2(255)       not null,'||wwv_flow.LF||
'    crea';
wwv_flow_imp.g_varchar2_table(7) := 'ted_on              timestamp with time zone,'||wwv_flow.LF||
'    updated_by              varchar2(255),'||wwv_flow.LF||
'    updated';
wwv_flow_imp.g_varchar2_table(8) := '_on              timestamp with time zone )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_qpoll_preferences_uk on eba_qp';
wwv_flow_imp.g_varchar2_table(9) := 'oll_preferences (preference_name);'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_qpoll_preferences_biu'||wwv_flow.LF||
'before ins';
wwv_flow_imp.g_varchar2_table(10) := 'ert or update on eba_qpoll_preferences'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null t';
wwv_flow_imp.g_varchar2_table(11) := 'hen'||wwv_flow.LF||
'        :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if ';
wwv_flow_imp.g_varchar2_table(12) := 'inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created_on := curren';
wwv_flow_imp.g_varchar2_table(13) := 't_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(14) := '      :new.updated_on := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.preference_name := upper(:new.prefe';
wwv_flow_imp.g_varchar2_table(15) := 'rence_name);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_preferences_biu enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16401155337137399470)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_preferences table'
,p_sequence=>50
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
