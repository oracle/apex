prompt --application/deployment/install/install_eba_qpoll_preferences_data
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_preferences data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16402632378320869786)
,p_install_id=>wwv_flow_imp.id(15923892887973083343)
,p_name=>'eba_qpoll_preferences data'
,p_sequence=>60
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into eba_qpoll_preferences (id, preference_name, preference_value) values (1, ''ACCESS_CONTROL_ENABLED'', ''N'');',
'insert into eba_qpoll_preferences (id, preference_name, preference_value) values (2, ''ACCESS_CONTROL_SCOPE'', ''ACL_ONLY'');',
'insert into eba_qpoll_preferences (id, preference_name, preference_value) values (3, ''USERNAME_FORMAT'', ''EMAIL'');',
'insert into eba_qpoll_preferences (id, preference_name, preference_value) values (4, ''NOTIFICATION_EMAIL_FROM'', ''N/A'');',
'insert into eba_qpoll_preferences (id, preference_name, preference_value) values (5, ''HOST_URL'', ''http://'' || owa_util.get_cgi_env(''HTTP_HOST'') || owa_util.get_cgi_env(''SCRIPT_NAME'') || ''/'');',
'insert into eba_qpoll_preferences (id, preference_name, preference_value) values (6, ''NOTIFICATION_EMAIL_REPLY_TO'', ''N/A'');',
'insert into eba_qpoll_preferences (id, preference_name, preference_value) values (11, ''APPLICATION_TITLE'', ''Poll'');',
'commit;',
'/',
'show errors'))
);
wwv_flow_imp.component_end;
end;
/
