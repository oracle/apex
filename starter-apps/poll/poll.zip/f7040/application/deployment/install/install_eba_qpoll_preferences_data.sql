prompt --application/deployment/install/install_eba_qpoll_preferences_data
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_preferences data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into eba_qpoll_preferences (id, preference_name, preference_value) values (1, ''ACCESS_CONTROL';
wwv_flow_imp.g_varchar2_table(2) := '_ENABLED'', ''N'');'||wwv_flow.LF||
'insert into eba_qpoll_preferences (id, preference_name, preference_value) values (2';
wwv_flow_imp.g_varchar2_table(3) := ', ''ACCESS_CONTROL_SCOPE'', ''ACL_ONLY'');'||wwv_flow.LF||
'insert into eba_qpoll_preferences (id, preference_name, prefe';
wwv_flow_imp.g_varchar2_table(4) := 'rence_value) values (3, ''USERNAME_FORMAT'', ''EMAIL'');'||wwv_flow.LF||
'insert into eba_qpoll_preferences (id, preferen';
wwv_flow_imp.g_varchar2_table(5) := 'ce_name, preference_value) values (4, ''NOTIFICATION_EMAIL_FROM'', ''N/A'');'||wwv_flow.LF||
'insert into eba_qpoll_prefe';
wwv_flow_imp.g_varchar2_table(6) := 'rences (id, preference_name, preference_value) values (5, ''HOST_URL'', ''http://'' || owa_util.get_cgi_';
wwv_flow_imp.g_varchar2_table(7) := 'env(''HTTP_HOST'') || owa_util.get_cgi_env(''SCRIPT_NAME'') || ''/'');'||wwv_flow.LF||
'insert into eba_qpoll_preferences (';
wwv_flow_imp.g_varchar2_table(8) := 'id, preference_name, preference_value) values (6, ''NOTIFICATION_EMAIL_REPLY_TO'', ''N/A'');'||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(9) := ' eba_qpoll_preferences (id, preference_name, preference_value) values (11, ''APPLICATION_TITLE'', ''Pol';
wwv_flow_imp.g_varchar2_table(10) := 'l'');'||wwv_flow.LF||
'commit;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16401156533768455256)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_preferences data'
,p_sequence=>60
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
