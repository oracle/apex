prompt --application/deployment/install/install_eba_qpoll_email_opt_out_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_email_opt_out table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_qpoll_email_opt_out'||wwv_flow.LF||
'('||wwv_flow.LF||
'    id            number not null,'||wwv_flow.LF||
'    respondent_id number n';
wwv_flow_imp.g_varchar2_table(2) := 'ot null enable,'||wwv_flow.LF||
'    created       timestamp (6) with time zone,'||wwv_flow.LF||
'    created_by    varchar2(255),'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(3) := ' constraint eba_qpoll_email_opt_out_pk primary key (id) enable,'||wwv_flow.LF||
'    constraint eba_qpoll_email_opt_o';
wwv_flow_imp.g_varchar2_table(4) := 'ut_fk foreign key (respondent_id) references eba_qpoll_respondents (id) on delete cascade enable'||wwv_flow.LF||
');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(5) := '/'||wwv_flow.LF||
'create index eba_qpoll_email_opt_out_i1 on eba_qpoll_email_opt_out( respondent_id );'||wwv_flow.LF||
''||wwv_flow.LF||
'create or re';
wwv_flow_imp.g_varchar2_table(6) := 'place trigger eba_qpoll_email_opt_out_biu'||wwv_flow.LF||
'   before insert on eba_qpoll_email_opt_out'||wwv_flow.LF||
'   for each ro';
wwv_flow_imp.g_varchar2_table(7) := 'w'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'       :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(8) := 'XXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'   :new.created := current_timestamp;'||wwv_flow.LF||
'   :new.created_by := nvl(wwv_flow.g_u';
wwv_flow_imp.g_varchar2_table(9) := 'ser,user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger eba_qpoll_email_opt_out_biu enable;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13973785122814397391)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_email_opt_out table'
,p_sequence=>420
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
