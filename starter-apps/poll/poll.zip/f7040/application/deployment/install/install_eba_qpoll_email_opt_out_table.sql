prompt --application/deployment/install/install_eba_qpoll_email_opt_out_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_email_opt_out table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13956672283207669746)
,p_install_id=>wwv_flow_imp.id(15905304203813941168)
,p_name=>'eba_qpoll_email_opt_out table'
,p_sequence=>420
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table eba_qpoll_email_opt_out',
'(',
'    id            number not null,',
'    respondent_id number not null enable,',
'    created       timestamp (6) with time zone,',
'    created_by    varchar2(255),',
'    constraint eba_qpoll_email_opt_out_pk primary key (id) enable,',
'    constraint eba_qpoll_email_opt_out_fk foreign key (respondent_id) references eba_qpoll_respondents (id) on delete cascade enable',
');',
'/',
'create index eba_qpoll_email_opt_out_i1 on eba_qpoll_email_opt_out( respondent_id );',
'',
'create or replace trigger eba_qpoll_email_opt_out_biu',
'   before insert on eba_qpoll_email_opt_out',
'   for each row',
'begin',
'    if :new.id is null then',
'       :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');',
'    end if;',
'   :new.created := current_timestamp;',
'   :new.created_by := nvl(wwv_flow.g_user,user);',
'end;',
'/',
'',
'alter trigger eba_qpoll_email_opt_out_biu enable;',
''))
);
wwv_flow_imp.component_end;
end;
/
