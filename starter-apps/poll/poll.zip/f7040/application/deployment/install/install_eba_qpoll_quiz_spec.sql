prompt --application/deployment/install/install_eba_qpoll_quiz_spec
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_quiz spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_qpoll_quiz is'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function delim_answers ('||wwv_flow.LF||
'   p_answer_01  in  varchar2,';
wwv_flow_imp.g_varchar2_table(2) := ''||wwv_flow.LF||
'   p_answer_02  in  varchar2,'||wwv_flow.LF||
'   p_answer_03  in  varchar2,'||wwv_flow.LF||
'   p_answer_04  in  varchar2,'||wwv_flow.LF||
'   p_answ';
wwv_flow_imp.g_varchar2_table(3) := 'er_05  in  varchar2,'||wwv_flow.LF||
'   p_answer_06  in  varchar2,'||wwv_flow.LF||
'   p_answer_07  in  varchar2,'||wwv_flow.LF||
'   p_answer_08  in ';
wwv_flow_imp.g_varchar2_table(4) := ' varchar2,'||wwv_flow.LF||
'   p_answer_09  in  varchar2,'||wwv_flow.LF||
'   p_answer_10  in  varchar2,'||wwv_flow.LF||
'   p_answer_11  in  varchar2,';
wwv_flow_imp.g_varchar2_table(5) := ''||wwv_flow.LF||
'   p_answer_12  in  varchar2'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function delim_answers_disp ('||wwv_flow.LF||
'   p_correct_';
wwv_flow_imp.g_varchar2_table(6) := 'answer  in  varchar2'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_qpoll_quiz;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13945070716712904051)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_quiz spec'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(14672339136510580353)
,p_script_id=>wwv_flow_imp.id(13945070716712904051)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_QPOLL_QUIZ'
);
wwv_flow_imp.component_end;
end;
/
