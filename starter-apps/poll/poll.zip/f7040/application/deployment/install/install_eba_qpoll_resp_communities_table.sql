prompt --application/deployment/install/install_eba_qpoll_resp_communities_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_resp_communities table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE EBA_QPOLL_RESP_COMMUNITIES'||wwv_flow.LF||
'   ('||wwv_flow.LF||
'    ID                    NUMBER constraint EBA_QPOLL_R';
wwv_flow_imp.g_varchar2_table(2) := 'ESP_COMM_PK primary key, '||wwv_flow.LF||
'    ROW_VERSION_NUMBER    NUMBER not null, '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    name               ';
wwv_flow_imp.g_varchar2_table(3) := '   varchar2(4000) not null,'||wwv_flow.LF||
'    publish_yn            varchar2(1),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    CREATED_BY            ';
wwv_flow_imp.g_varchar2_table(4) := 'VARCHAR2(255), '||wwv_flow.LF||
'    CREATED               TIMESTAMP WITH TIME ZONE, '||wwv_flow.LF||
'    UPDATED_BY            VARCH';
wwv_flow_imp.g_varchar2_table(5) := 'AR2(255), '||wwv_flow.LF||
'    UPDATED               TIMESTAMP WITH TIME ZONE'||wwv_flow.LF||
'   )  ;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index EBA_QPOL';
wwv_flow_imp.g_varchar2_table(6) := 'L_RESP_COMM_UK on EBA_QPOLL_RESP_COMMUNITIES(name);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER EBA_QPOLL_RESP_COMM_';
wwv_flow_imp.g_varchar2_table(7) := 'BIU'||wwv_flow.LF||
'   before insert or update on EBA_QPOLL_RESP_COMMUNITIES'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is ';
wwv_flow_imp.g_varchar2_table(8) := 'null then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   i';
wwv_flow_imp.g_varchar2_table(9) := 'f :new.publish_yn is null then'||wwv_flow.LF||
'      :new.publish_yn := ''Y'';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(10) := ':new.created := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.';
wwv_flow_imp.g_varchar2_table(11) := 'updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_v';
wwv_flow_imp.g_varchar2_table(12) := 'ersion_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_nu';
wwv_flow_imp.g_varchar2_table(13) := 'mber,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(14) := '      :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TRIGGER EBA_QPOLL_RESP_';
wwv_flow_imp.g_varchar2_table(15) := 'COMM_BIU ENABLE;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13872264520102229543)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_resp_communities table'
,p_sequence=>150
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
