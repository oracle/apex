prompt --application/deployment/install/install_eba_qpoll_results_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_results table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE EBA_QPOLL_RESULTS'||wwv_flow.LF||
'   ('||wwv_flow.LF||
'    ID                    NUMBER constraint EBA_QPOLL_RESULTS_PK';
wwv_flow_imp.g_varchar2_table(2) := ' primary key, '||wwv_flow.LF||
'    poll_ID               NUMBER constraint EBA_QPOLL_RESULTS_FK'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(3) := '      references EBA_QPOLL_POLLS (id)'||wwv_flow.LF||
'                          on delete cascade,'||wwv_flow.LF||
'    ROW_VERSION_N';
wwv_flow_imp.g_varchar2_table(4) := 'UMBER    NUMBER not null, '||wwv_flow.LF||
'    ROW_KEY               VARCHAR2(30), '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    ip_address           ';
wwv_flow_imp.g_varchar2_table(5) := ' varchar2(255),'||wwv_flow.LF||
'    apex_session_id       varchar2(255),'||wwv_flow.LF||
'    apex_user             varchar2(255),'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(6) := '  respondent_id         number,'||wwv_flow.LF||
'    preactive_yn          varchar2(1)  null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    grade       ';
wwv_flow_imp.g_varchar2_table(7) := '          number,'||wwv_flow.LF||
'    is_valid_yn           varchar2(1),'||wwv_flow.LF||
'    validation_errors     varchar2(4000),'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(8) := '   --'||wwv_flow.LF||
'    score                 number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    name                  varchar2(4000),'||wwv_flow.LF||
'    email  ';
wwv_flow_imp.g_varchar2_table(9) := '               varchar2(4000) not null,'||wwv_flow.LF||
'    company               varchar2(255),'||wwv_flow.LF||
'    title          ';
wwv_flow_imp.g_varchar2_table(10) := '       varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    CREATED_BY            VARCHAR2(255), '||wwv_flow.LF||
'    CREATED               TIM';
wwv_flow_imp.g_varchar2_table(11) := 'ESTAMP WITH TIME ZONE, '||wwv_flow.LF||
'    UPDATED_BY            VARCHAR2(255), '||wwv_flow.LF||
'    UPDATED               TIMESTAM';
wwv_flow_imp.g_varchar2_table(12) := 'P WITH TIME ZONE'||wwv_flow.LF||
'   )  ;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create index EBA_QPOLL_RESULTS_I1 on EBA_QPOLL_RESULTS( poll_ID );'||wwv_flow.LF||
'create';
wwv_flow_imp.g_varchar2_table(13) := ' index EBA_QPOLL_RESULTS_I2 on EBA_QPOLL_RESULTS( row_key );'||wwv_flow.LF||
'create index EBA_QPOLL_RESULTS_I3 on EB';
wwv_flow_imp.g_varchar2_table(14) := 'A_QPOLL_RESULTS( email );'||wwv_flow.LF||
'create index EBA_QPOLL_RESULTS_I4 on EBA_QPOLL_RESULTS( created );'||wwv_flow.LF||
'create ';
wwv_flow_imp.g_varchar2_table(15) := 'index EBA_QPOLL_RESULTS_I5 on EBA_QPOLL_RESULTS( is_valid_yn );'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER EBA_QPOLL';
wwv_flow_imp.g_varchar2_table(16) := '_RESULTS_BIU'||wwv_flow.LF||
'   before insert or update on EBA_QPOLL_RESULTS'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is ';
wwv_flow_imp.g_varchar2_table(17) := 'null then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(18) := 'if :new.row_key is null then'||wwv_flow.LF||
'       :new.row_key := eba_qpoll_fw.compress_int(eba_qpoll_seq.nextval)';
wwv_flow_imp.g_varchar2_table(19) := ';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       if :new.apex_user is null then'||wwv_flow.LF||
'          :new.apex_user :=';
wwv_flow_imp.g_varchar2_table(20) := ' nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       if :new.apex_session_id is null then'||wwv_flow.LF||
'          :new.';
wwv_flow_imp.g_varchar2_table(21) := 'apex_session_id := nvl(v(''SESSION_ID''),''unknown'');'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       :new.created := current_tim';
wwv_flow_imp.g_varchar2_table(22) := 'estamp;'||wwv_flow.LF||
'       if :new.created_by is null then'||wwv_flow.LF||
'          :new.created_by := nvl(wwv_flow.g_user,user';
wwv_flow_imp.g_varchar2_table(23) := ');'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       if :new.updated_by is null then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(24) := '         :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       :new.row_version_number';
wwv_flow_imp.g_varchar2_table(25) := ' := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(26) := '   end if;'||wwv_flow.LF||
'   if :new.preactive_yn is null'||wwv_flow.LF||
'      then :new.preactive_yn := ''N'';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.e';
wwv_flow_imp.g_varchar2_table(27) := 'mail := lower(:new.email);'||wwv_flow.LF||
'   if updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new';
wwv_flow_imp.g_varchar2_table(28) := '.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'ALTER TRIGGER EBA_QPOLL_RESULTS_BIU ENAB';
wwv_flow_imp.g_varchar2_table(29) := 'LE;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE TABLE EBA_QPOLL_RESULT_DETAILS'||wwv_flow.LF||
'   ('||wwv_flow.LF||
'    id                    number'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(30) := '       constraint EBA_QPOLL_RESULT_DET_PK'||wwv_flow.LF||
'                          primary key,'||wwv_flow.LF||
'    result_id      ';
wwv_flow_imp.g_varchar2_table(31) := '       number '||wwv_flow.LF||
'                          constraint EBA_QPOLL_RESULT_DET_FK'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(32) := '  references EBA_QPOLL_RESULTS on delete cascade,'||wwv_flow.LF||
'    ROW_VERSION_NUMBER    NUMBER not null, '||wwv_flow.LF||
'    qu';
wwv_flow_imp.g_varchar2_table(33) := 'estion              varchar2(4000),'||wwv_flow.LF||
'    question_id           number,'||wwv_flow.LF||
'    question_type         varc';
wwv_flow_imp.g_varchar2_table(34) := 'har2(30),'||wwv_flow.LF||
'    display_sequence      number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    answer_01             varchar2(4000),'||wwv_flow.LF||
'    ans';
wwv_flow_imp.g_varchar2_table(35) := 'wer_02             varchar2(4000),'||wwv_flow.LF||
'    answer_03             varchar2(4000),'||wwv_flow.LF||
'    answer_04          ';
wwv_flow_imp.g_varchar2_table(36) := '   varchar2(4000),'||wwv_flow.LF||
'    answer_05             varchar2(4000),'||wwv_flow.LF||
'    answer_06             varchar2(4000';
wwv_flow_imp.g_varchar2_table(37) := '),'||wwv_flow.LF||
'    answer_07             varchar2(4000),'||wwv_flow.LF||
'    answer_08             varchar2(4000),'||wwv_flow.LF||
'    answer_09';
wwv_flow_imp.g_varchar2_table(38) := '             varchar2(4000),'||wwv_flow.LF||
'    answer_10             varchar2(4000),'||wwv_flow.LF||
'    answer_11             var';
wwv_flow_imp.g_varchar2_table(39) := 'char2(4000),'||wwv_flow.LF||
'    answer_12             varchar2(4000),'||wwv_flow.LF||
'    answer_correct_yn     varchar2(1),'||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(40) := ''||wwv_flow.LF||
'    answer_id_01          number,'||wwv_flow.LF||
'    answer_id_02          number,'||wwv_flow.LF||
'    answer_id_03          numbe';
wwv_flow_imp.g_varchar2_table(41) := 'r,'||wwv_flow.LF||
'    answer_id_04          number,'||wwv_flow.LF||
'    answer_id_05          number,'||wwv_flow.LF||
'    answer_id_06          num';
wwv_flow_imp.g_varchar2_table(42) := 'ber,'||wwv_flow.LF||
'    answer_id_07          number,'||wwv_flow.LF||
'    answer_id_08          number,'||wwv_flow.LF||
'    answer_id_09          n';
wwv_flow_imp.g_varchar2_table(43) := 'umber,'||wwv_flow.LF||
'    answer_id_10          number,'||wwv_flow.LF||
'    answer_id_11          number,'||wwv_flow.LF||
'    answer_id_12         ';
wwv_flow_imp.g_varchar2_table(44) := ' number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    score                 number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    CREATED_BY            VARCHAR2(255), '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(45) := '   CREATED               TIMESTAMP WITH TIME ZONE, '||wwv_flow.LF||
'    UPDATED_BY            VARCHAR2(255), '||wwv_flow.LF||
'    UP';
wwv_flow_imp.g_varchar2_table(46) := 'DATED               TIMESTAMP WITH TIME ZONE'||wwv_flow.LF||
')  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_qpoll_result_details'||wwv_flow.LF||
'add constrai';
wwv_flow_imp.g_varchar2_table(47) := 'nt eba_qpoll_result_det_cc1'||wwv_flow.LF||
'check (answer_correct_yn in (''Y'',''N''));'||wwv_flow.LF||
''||wwv_flow.LF||
'create index EBA_QPOLL_RESULT_D';
wwv_flow_imp.g_varchar2_table(48) := 'ET_I1 on EBA_QPOLL_RESULT_DETAILS( result_id );'||wwv_flow.LF||
'create index EBA_QPOLL_RESULT_DET_I2 on EBA_QPOLL_RE';
wwv_flow_imp.g_varchar2_table(49) := 'SULT_DETAILS( question_id );'||wwv_flow.LF||
'create index EBA_QPOLL_RESULT_DET_I3 on EBA_QPOLL_RESULT_DETAILS( answe';
wwv_flow_imp.g_varchar2_table(50) := 'r_id_01 );'||wwv_flow.LF||
'create index EBA_QPOLL_RESULT_DET_I4 on EBA_QPOLL_RESULT_DETAILS( answer_id_02 );'||wwv_flow.LF||
'create ';
wwv_flow_imp.g_varchar2_table(51) := 'index EBA_QPOLL_RESULT_DET_I5 on EBA_QPOLL_RESULT_DETAILS( answer_id_03 );'||wwv_flow.LF||
'create index EBA_QPOLL_RE';
wwv_flow_imp.g_varchar2_table(52) := 'SULT_DET_I6 on EBA_QPOLL_RESULT_DETAILS( answer_id_04 );'||wwv_flow.LF||
'create index EBA_QPOLL_RESULT_DET_I7 on EBA';
wwv_flow_imp.g_varchar2_table(53) := '_QPOLL_RESULT_DETAILS( answer_id_05 );'||wwv_flow.LF||
'create index EBA_QPOLL_RESULT_DET_I8 on EBA_QPOLL_RESULT_DETA';
wwv_flow_imp.g_varchar2_table(54) := 'ILS( answer_id_06 );'||wwv_flow.LF||
'create index EBA_QPOLL_RESULT_DET_I9 on EBA_QPOLL_RESULT_DETAILS( answer_id_07 ';
wwv_flow_imp.g_varchar2_table(55) := ');'||wwv_flow.LF||
'create index EBA_QPOLL_RESULT_DET_I10 on EBA_QPOLL_RESULT_DETAILS( answer_id_08 );'||wwv_flow.LF||
'create index E';
wwv_flow_imp.g_varchar2_table(56) := 'BA_QPOLL_RESULT_DET_I11 on EBA_QPOLL_RESULT_DETAILS( answer_id_09 );'||wwv_flow.LF||
'create index EBA_QPOLL_RESULT_D';
wwv_flow_imp.g_varchar2_table(57) := 'ET_I12 on EBA_QPOLL_RESULT_DETAILS( answer_id_10 );'||wwv_flow.LF||
'create index EBA_QPOLL_RESULT_DET_I13 on EBA_QPO';
wwv_flow_imp.g_varchar2_table(58) := 'LL_RESULT_DETAILS( answer_id_11 );'||wwv_flow.LF||
'create index EBA_QPOLL_RESULT_DET_I14 on EBA_QPOLL_RESULT_DETAILS';
wwv_flow_imp.g_varchar2_table(59) := '( answer_id_12 );'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER EBA_QPOLL_RESULT_DETS_BIU'||wwv_flow.LF||
'   before insert or update o';
wwv_flow_imp.g_varchar2_table(60) := 'n EBA_QPOLL_RESULT_DETAILS'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is null then'||wwv_flow.LF||
'      :new.ID := to_numb';
wwv_flow_imp.g_varchar2_table(61) := 'er(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.creat';
wwv_flow_imp.g_varchar2_table(62) := 'ed := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated :=';
wwv_flow_imp.g_varchar2_table(63) := ' current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_num';
wwv_flow_imp.g_varchar2_table(64) := 'ber := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + ';
wwv_flow_imp.g_varchar2_table(65) := '1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new';
wwv_flow_imp.g_varchar2_table(66) := '.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'ALTER TRIGGER EBA_QPOLL_RESULT_DETS_BIU ';
wwv_flow_imp.g_varchar2_table(67) := 'ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13878799714069650383)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_results table'
,p_sequence=>220
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
