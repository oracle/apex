prompt --application/deployment/install/install_eba_qpoll_fw_body
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_fw body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE OR REPLACE PACKAGE BODY EBA_QPOLL_FW as'||wwv_flow.LF||
'    function conv_txt_html ('||wwv_flow.LF||
'        p_txt_message in';
wwv_flow_imp.g_varchar2_table(2) := ' varchar2 )'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_html_message   varchar2(32767) default p_txt_me';
wwv_flow_imp.g_varchar2_table(3) := 'ssage;'||wwv_flow.LF||
'        l_temp_url varchar2(32767) := null;'||wwv_flow.LF||
'        l_length number;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        l_html';
wwv_flow_imp.g_varchar2_table(4) := '_message := replace(l_html_message, chr(10), ''<br />'');'||wwv_flow.LF||
'        l_html_message := replace(l_html_mes';
wwv_flow_imp.g_varchar2_table(5) := 'sage, chr(13), null);'||wwv_flow.LF||
'        return l_html_message;'||wwv_flow.LF||
'    end conv_txt_html;'||wwv_flow.LF||
'    function conv_urls_l';
wwv_flow_imp.g_varchar2_table(6) := 'inks ('||wwv_flow.LF||
'        p_string in varchar2 )'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_string   varchar2(327';
wwv_flow_imp.g_varchar2_table(7) := '67) default p_string;'||wwv_flow.LF||
'        l_endofUrl varchar2(4000) default chr(10) || chr(13) || chr(9) || '' )<';
wwv_flow_imp.g_varchar2_table(8) := '>'';'||wwv_flow.LF||
'        l_url         varchar2(4000);'||wwv_flow.LF||
'        l_current_pos number := 1;'||wwv_flow.LF||
'        n             n';
wwv_flow_imp.g_varchar2_table(9) := 'umber := 1;'||wwv_flow.LF||
'        m             number := 1;'||wwv_flow.LF||
'        p             number := 1;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(10) := 'l_string := p_string || '' '';'||wwv_flow.LF||
'        for i in 1 .. 1000 loop'||wwv_flow.LF||
'            n := instr( lower(l_string)';
wwv_flow_imp.g_varchar2_table(11) := ', ''http://'', l_current_pos );'||wwv_flow.LF||
'            m := instr( lower(l_string), ''https://'', l_current_pos );'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(12) := '            p := instr( lower(l_string), ''ftp://'', l_current_pos   );'||wwv_flow.LF||
'            -- set n to positi';
wwv_flow_imp.g_varchar2_table(13) := 'on of first link'||wwv_flow.LF||
'            if m > 0 and (n = 0 or m < n) and (p = 0 or m < p) then'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(14) := 'n := m;'||wwv_flow.LF||
'            elsif p > 0 and (n = 0 or p < n) then'||wwv_flow.LF||
'               n := p;'||wwv_flow.LF||
'            end if;';
wwv_flow_imp.g_varchar2_table(15) := ''||wwv_flow.LF||
'            exit when n = 0 or length(l_string) > 32000;'||wwv_flow.LF||
'            for j in 0 .. length( l_string';
wwv_flow_imp.g_varchar2_table(16) := ' ) - n loop'||wwv_flow.LF||
'                if ( instr( l_endofUrl, substr( l_string, n+j, 1 ) ) > 0 ) then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(17) := '           l_url := rtrim( substr( l_string, n, j ), ''.''||chr(32)||chr(10) );'||wwv_flow.LF||
'                   l_u';
wwv_flow_imp.g_varchar2_table(18) := 'rl := ''<a href="'' || l_url || ''">'' || l_url || ''</a>'';'||wwv_flow.LF||
'                   l_string := substr( l_stri';
wwv_flow_imp.g_varchar2_table(19) := 'ng, 1, n-1 ) || l_url || substr( l_string, n+j );'||wwv_flow.LF||
'                   l_current_pos := n + length(l_u';
wwv_flow_imp.g_varchar2_table(20) := 'rl);'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(21) := '  return l_string;'||wwv_flow.LF||
'    end conv_urls_links;'||wwv_flow.LF||
'    function selective_escape ('||wwv_flow.LF||
'        p_text  in varch';
wwv_flow_imp.g_varchar2_table(22) := 'ar2,'||wwv_flow.LF||
'        p_tags  in varchar2 default ''<h2>,</h2>,<p>,</p>,<b>,</b>,<li>,</li>,<ul>,</ul>,<br />,';
wwv_flow_imp.g_varchar2_table(23) := '<i>,</i>,<h3>,</h3>'''||wwv_flow.LF||
'        ) return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        t apex_application_global.vc_arr2;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(24) := '     x varchar2(32767) := p_text;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        t := apex_util.string_to_table(p_tags, '','');'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(25) := '     for i in 1..t.count loop'||wwv_flow.LF||
'            x := replace(x,t(i),''Aa''||i||''aA'');'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(26) := '    x := apex_escape.html(x);'||wwv_flow.LF||
'        for i in 1..t.count loop'||wwv_flow.LF||
'            x := replace(x,''Aa''||i||''';
wwv_flow_imp.g_varchar2_table(27) := 'aA'',t(i));'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        return x;'||wwv_flow.LF||
'    end selective_escape;'||wwv_flow.LF||
'    function get_preference';
wwv_flow_imp.g_varchar2_table(28) := '_value ('||wwv_flow.LF||
'        p_preference_name varchar2 )'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_preference_va';
wwv_flow_imp.g_varchar2_table(29) := 'lue varchar2(255);'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        select preference_value'||wwv_flow.LF||
'            into l_preference_value'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(30) := '     from eba_qpoll_preferences'||wwv_flow.LF||
'        where preference_name = p_preference_name;'||wwv_flow.LF||
'        return l_';
wwv_flow_imp.g_varchar2_table(31) := 'preference_value;'||wwv_flow.LF||
'    exception'||wwv_flow.LF||
'        when no_data_found then'||wwv_flow.LF||
'            return ''Preference does ';
wwv_flow_imp.g_varchar2_table(32) := 'not exist'';'||wwv_flow.LF||
'    end get_preference_value;'||wwv_flow.LF||
'    procedure set_preference_value ('||wwv_flow.LF||
'        p_preference_';
wwv_flow_imp.g_varchar2_table(33) := 'name  varchar2, '||wwv_flow.LF||
'        p_preference_value varchar2 )'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        merge into eba_qpoll';
wwv_flow_imp.g_varchar2_table(34) := '_preferences dest'||wwv_flow.LF||
'        using ( select upper(p_preference_name) preference_name,'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(35) := '   p_preference_value preference_value'||wwv_flow.LF||
'                from dual ) src'||wwv_flow.LF||
'        on ( upper(dest.prefe';
wwv_flow_imp.g_varchar2_table(36) := 'rence_name) = src.preference_name )'||wwv_flow.LF||
'        when matched then'||wwv_flow.LF||
'            update set dest.preference';
wwv_flow_imp.g_varchar2_table(37) := '_value = src.preference_value'||wwv_flow.LF||
'        when not matched then'||wwv_flow.LF||
'            insert (dest.preference_name';
wwv_flow_imp.g_varchar2_table(38) := ', dest.preference_value)'||wwv_flow.LF||
'            values (src.preference_name, src.preference_value);'||wwv_flow.LF||
'    end set';
wwv_flow_imp.g_varchar2_table(39) := '_preference_value;'||wwv_flow.LF||
'    function compress_int ('||wwv_flow.LF||
'        n in integer )'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    as';
wwv_flow_imp.g_varchar2_table(40) := ''||wwv_flow.LF||
'        ret varchar2(30);'||wwv_flow.LF||
'        quotient integer;'||wwv_flow.LF||
'        remainder integer;'||wwv_flow.LF||
'        digit char(1';
wwv_flow_imp.g_varchar2_table(41) := ');'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        ret := '''';'||wwv_flow.LF||
'        quotient := n;'||wwv_flow.LF||
'        while quotient > 0'||wwv_flow.LF||
'        loop'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(42) := '       remainder := mod(quotient, 10 + 26);'||wwv_flow.LF||
'            quotient := floor(quotient  / (10 + 26));'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(43) := '          if remainder < 26 then'||wwv_flow.LF||
'                digit := chr(ascii(''A'') + remainder);'||wwv_flow.LF||
'            e';
wwv_flow_imp.g_varchar2_table(44) := 'lse'||wwv_flow.LF||
'                digit := chr(ascii(''0'') + remainder - 26);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            ret :';
wwv_flow_imp.g_varchar2_table(45) := '= digit || ret;'||wwv_flow.LF||
'        end loop ;'||wwv_flow.LF||
'        if length(ret) < 5 then'||wwv_flow.LF||
'            ret := lpad(ret, 4, ''';
wwv_flow_imp.g_varchar2_table(46) := 'A'');'||wwv_flow.LF||
'        end if ;'||wwv_flow.LF||
'        return upper(ret);'||wwv_flow.LF||
'    end compress_int;'||wwv_flow.LF||
'    procedure add_error_log (';
wwv_flow_imp.g_varchar2_table(47) := ' '||wwv_flow.LF||
'        p_error           in apex_error.t_error,'||wwv_flow.LF||
'        p_procedure_name  in varchar2 default nul';
wwv_flow_imp.g_varchar2_table(48) := 'l,'||wwv_flow.LF||
'        p_error_text      in varchar2 default null,'||wwv_flow.LF||
'        p_arg1_name       in varchar2 default';
wwv_flow_imp.g_varchar2_table(49) := ' null,'||wwv_flow.LF||
'        p_arg1_val        in varchar2 default null,'||wwv_flow.LF||
'        p_arg2_name       in varchar2 def';
wwv_flow_imp.g_varchar2_table(50) := 'ault null,'||wwv_flow.LF||
'        p_arg2_val        in varchar2 default null,'||wwv_flow.LF||
'        p_arg3_name       in varchar2';
wwv_flow_imp.g_varchar2_table(51) := ' default null,'||wwv_flow.LF||
'        p_arg3_val        in varchar2 default null,'||wwv_flow.LF||
'        p_arg4_name       in varc';
wwv_flow_imp.g_varchar2_table(52) := 'har2 default null,'||wwv_flow.LF||
'        p_arg4_val        in varchar2 default null )'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'    pragma autonomous';
wwv_flow_imp.g_varchar2_table(53) := '_transaction;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        -- Remove old errors'||wwv_flow.LF||
'        delete from eba_qpoll_errors where err_';
wwv_flow_imp.g_varchar2_table(54) := 'time <= current_timestamp - 21;'||wwv_flow.LF||
'        -- Log the error.'||wwv_flow.LF||
'        insert into eba_qpoll_errors ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(55) := '         app_id,'||wwv_flow.LF||
'            app_page_id,'||wwv_flow.LF||
'            app_user,'||wwv_flow.LF||
'            user_agent,'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(56) := 'ip_address,'||wwv_flow.LF||
'            ip_address2,'||wwv_flow.LF||
'            message,'||wwv_flow.LF||
'            page_item_name,'||wwv_flow.LF||
'            re';
wwv_flow_imp.g_varchar2_table(57) := 'gion_id,'||wwv_flow.LF||
'            column_alias,'||wwv_flow.LF||
'            row_num,'||wwv_flow.LF||
'            apex_error_code,'||wwv_flow.LF||
'            ora';
wwv_flow_imp.g_varchar2_table(58) := '_sqlcode,'||wwv_flow.LF||
'            ora_sqlerrm,'||wwv_flow.LF||
'            error_backtrace,'||wwv_flow.LF||
'            procedure_name,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(59) := '    error_text,'||wwv_flow.LF||
'            arg1_name,'||wwv_flow.LF||
'            arg1_val,'||wwv_flow.LF||
'            arg2_name,'||wwv_flow.LF||
'            arg2';
wwv_flow_imp.g_varchar2_table(60) := '_val,'||wwv_flow.LF||
'            arg3_name,'||wwv_flow.LF||
'            arg3_val,'||wwv_flow.LF||
'            arg4_name,'||wwv_flow.LF||
'            arg4_val )'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(61) := '     select v(''APP_ID''),'||wwv_flow.LF||
'            v(''APP_PAGE_ID''),'||wwv_flow.LF||
'            v(''APP_USER''),'||wwv_flow.LF||
'            owa_ut';
wwv_flow_imp.g_varchar2_table(62) := 'il.get_cgi_env(''HTTP_USER_AGENT''),'||wwv_flow.LF||
'            owa_util.get_cgi_env(''REMOTE_ADDR''),'||wwv_flow.LF||
'            sys_';
wwv_flow_imp.g_varchar2_table(63) := 'context(''USERENV'', ''IP_ADDRESS''),'||wwv_flow.LF||
'            substr(p_error.message,0,4000),'||wwv_flow.LF||
'            p_error.pa';
wwv_flow_imp.g_varchar2_table(64) := 'ge_item_name,'||wwv_flow.LF||
'            p_error.region_id,'||wwv_flow.LF||
'            p_error.column_alias,'||wwv_flow.LF||
'            p_error.r';
wwv_flow_imp.g_varchar2_table(65) := 'ow_num,'||wwv_flow.LF||
'            p_error.apex_error_code,'||wwv_flow.LF||
'            p_error.ora_sqlcode,'||wwv_flow.LF||
'            substr(p_e';
wwv_flow_imp.g_varchar2_table(66) := 'rror.ora_sqlerrm,0,4000),'||wwv_flow.LF||
'            substr(p_error.error_backtrace,0,4000),'||wwv_flow.LF||
'            p_procedur';
wwv_flow_imp.g_varchar2_table(67) := 'e_name,'||wwv_flow.LF||
'            p_error_text,'||wwv_flow.LF||
'            p_arg1_name,'||wwv_flow.LF||
'            p_arg1_val,'||wwv_flow.LF||
'            p_arg';
wwv_flow_imp.g_varchar2_table(68) := '2_name,'||wwv_flow.LF||
'            p_arg2_val,'||wwv_flow.LF||
'            p_arg3_name,'||wwv_flow.LF||
'            p_arg3_val,'||wwv_flow.LF||
'            p_arg4_';
wwv_flow_imp.g_varchar2_table(69) := 'name,'||wwv_flow.LF||
'            p_arg4_val'||wwv_flow.LF||
'        from dual;'||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
'    end add_error_log;'||wwv_flow.LF||
'    function ';
wwv_flow_imp.g_varchar2_table(70) := 'apex_error_handling ('||wwv_flow.LF||
'        p_error in apex_error.t_error )'||wwv_flow.LF||
'        return apex_error.t_error_resu';
wwv_flow_imp.g_varchar2_table(71) := 'lt'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_result          apex_error.t_error_result;'||wwv_flow.LF||
'        l_constraint_name varchar2(25';
wwv_flow_imp.g_varchar2_table(72) := '5);'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        l_result := apex_error.init_error_result ('||wwv_flow.LF||
'                        p_error => ';
wwv_flow_imp.g_varchar2_table(73) := 'p_error );'||wwv_flow.LF||
'        -- If it is an internal error raised by APEX, like an invalid statement or'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(74) := '  -- code which can not be executed, the error text might contain security sensitive'||wwv_flow.LF||
'        -- info';
wwv_flow_imp.g_varchar2_table(75) := 'rmation. To avoid this security problem we can rewrite the error to'||wwv_flow.LF||
'        -- a generic error messa';
wwv_flow_imp.g_varchar2_table(76) := 'ge and log the original error message for further'||wwv_flow.LF||
'        -- investigation by the help desk.'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(77) := ' if p_error.is_internal_error then'||wwv_flow.LF||
'            -- mask all errors that are not common runtime errors';
wwv_flow_imp.g_varchar2_table(78) := ' (Access Denied'||wwv_flow.LF||
'            -- errors raised by application / page authorization and all errors'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(79) := '        -- regarding session and session state)'||wwv_flow.LF||
'            if not p_error.is_common_runtime_error t';
wwv_flow_imp.g_varchar2_table(80) := 'hen'||wwv_flow.LF||
'                add_error_log( p_error );'||wwv_flow.LF||
'                -- Change the message to the generic e';
wwv_flow_imp.g_varchar2_table(81) := 'rror message which doesn''t expose'||wwv_flow.LF||
'                -- any sensitive information.'||wwv_flow.LF||
'                l_re';
wwv_flow_imp.g_varchar2_table(82) := 'sult.message         := ''An unexpected internal application error has occurred.'';'||wwv_flow.LF||
'                l_';
wwv_flow_imp.g_varchar2_table(83) := 'result.additional_info := null;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            -- Always show the erro';
wwv_flow_imp.g_varchar2_table(84) := 'r as inline error'||wwv_flow.LF||
'            -- Note: If you have created manual tabular forms (using the package'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(85) := '           --       apex_item/htmldb_item in the SQL statement) you should still'||wwv_flow.LF||
'            --     ';
wwv_flow_imp.g_varchar2_table(86) := '  use "On error page" on that pages to avoid loosing entered data'||wwv_flow.LF||
'            l_result.display_locat';
wwv_flow_imp.g_varchar2_table(87) := 'ion := case'||wwv_flow.LF||
'                                           when l_result.display_location = apex_error.c';
wwv_flow_imp.g_varchar2_table(88) := '_on_error_page then apex_error.c_inline_in_notification'||wwv_flow.LF||
'                                           e';
wwv_flow_imp.g_varchar2_table(89) := 'lse l_result.display_location'||wwv_flow.LF||
'                                         end;'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- If an OR';
wwv_flow_imp.g_varchar2_table(90) := 'A error has been raised, for example a raise_application_error(-20xxx, ''...'')'||wwv_flow.LF||
'            -- in a ta';
wwv_flow_imp.g_varchar2_table(91) := 'ble trigger or in a PL/SQL package called by a process and we'||wwv_flow.LF||
'            -- haven''t found the error';
wwv_flow_imp.g_varchar2_table(92) := ' in our lookup table, then we just want to see'||wwv_flow.LF||
'            -- the actual error text and not the full';
wwv_flow_imp.g_varchar2_table(93) := ' error stack with all the ORA error numbers.'||wwv_flow.LF||
'            if p_error.ora_sqlcode is not null and l_re';
wwv_flow_imp.g_varchar2_table(94) := 'sult.message = p_error.message then'||wwv_flow.LF||
'                l_result.message := apex_error.get_first_ora_err';
wwv_flow_imp.g_varchar2_table(95) := 'or_text ('||wwv_flow.LF||
'                                        p_error => p_error );'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(96) := '    -- If no associated page item/tabular form column has been set, we can use'||wwv_flow.LF||
'            -- apex_e';
wwv_flow_imp.g_varchar2_table(97) := 'rror.auto_set_associated_item to automatically guess the affected'||wwv_flow.LF||
'            -- error field by exam';
wwv_flow_imp.g_varchar2_table(98) := 'ine the ORA error for constraint names or column names.'||wwv_flow.LF||
'            if l_result.page_item_name is nu';
wwv_flow_imp.g_varchar2_table(99) := 'll and l_result.column_alias is null then'||wwv_flow.LF||
'                apex_error.auto_set_associated_item ('||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(100) := '                p_error        => p_error,'||wwv_flow.LF||
'                    p_error_result => l_result );'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(101) := '     end if;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        return l_result;'||wwv_flow.LF||
'    end apex_error_handling;'||wwv_flow.LF||
'end eba_qpoll_fw;';
wwv_flow_imp.g_varchar2_table(102) := ''||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16513294462885289975)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_fw body'
,p_sequence=>500
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
