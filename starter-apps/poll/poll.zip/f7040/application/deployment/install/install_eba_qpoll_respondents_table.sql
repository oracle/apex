prompt --application/deployment/install/install_eba_qpoll_respondents_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_respondents table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13874550174601690807)
,p_install_id=>wwv_flow_imp.id(15923892887973083343)
,p_name=>'eba_qpoll_respondents table'
,p_sequence=>160
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE EBA_QPOLL_RESPONDENTS',
'   (',
'    ID                    NUMBER constraint EBA_QPOLL_RESPONDENTS_PK primary key, ',
'    ROW_VERSION_NUMBER    NUMBER not null, ',
'    --',
'    name                  varchar2(4000)  null,',
'    email                 varchar2(4000) not null,',
'    company               varchar2(255),',
'    title                 varchar2(255),',
'    --',
'    CREATED_BY            VARCHAR2(255), ',
'    CREATED               TIMESTAMP WITH TIME ZONE, ',
'    UPDATED_BY            VARCHAR2(255), ',
'    UPDATED               TIMESTAMP WITH TIME ZONE',
'   )  ;',
'',
'',
'create unique index EBA_QPOLL_RESPONDENTS_UK on EBA_QPOLL_RESPONDENTS( email );',
'',
'CREATE OR REPLACE TRIGGER EBA_QPOLL_RESPONDENTS_BIU',
'   before insert or update on EBA_QPOLL_RESPONDENTS',
'   for each row',
'begin',
'   if :new.ID is null then',
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');',
'   end if;',
'   if inserting then',
'       :new.created := current_timestamp;',
'       :new.created_by := nvl(wwv_flow.g_user,user);',
'       :new.updated := current_timestamp;',
'       :new.updated_by := nvl(wwv_flow.g_user,user);',
'       :new.row_version_number := 1;',
'   elsif updating then',
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;',
'   end if;',
'   :new.email := lower(:new.email);',
'   if inserting or updating then',
'       :new.updated := current_timestamp;',
'       :new.updated_by := nvl(wwv_flow.g_user,user);',
'   end if;',
'end;',
'/',
'',
'ALTER TRIGGER EBA_QPOLL_RESPONDENTS_BIU ENABLE;',
''))
);
wwv_flow_imp.component_end;
end;
/
