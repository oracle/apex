prompt --application/deployment/install/install_eba_qpoll_respondents_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_respondents table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE EBA_QPOLL_RESPONDENTS'||wwv_flow.LF||
'   ('||wwv_flow.LF||
'    ID                    NUMBER constraint EBA_QPOLL_RESPON';
wwv_flow_imp.g_varchar2_table(2) := 'DENTS_PK primary key, '||wwv_flow.LF||
'    ROW_VERSION_NUMBER    NUMBER not null, '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    name                  ';
wwv_flow_imp.g_varchar2_table(3) := 'varchar2(4000)  null,'||wwv_flow.LF||
'    email                 varchar2(4000) not null,'||wwv_flow.LF||
'    company               v';
wwv_flow_imp.g_varchar2_table(4) := 'archar2(255),'||wwv_flow.LF||
'    title                 varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    CREATED_BY            VARCHAR2(255';
wwv_flow_imp.g_varchar2_table(5) := '), '||wwv_flow.LF||
'    CREATED               TIMESTAMP WITH TIME ZONE, '||wwv_flow.LF||
'    UPDATED_BY            VARCHAR2(255), '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(6) := '   UPDATED               TIMESTAMP WITH TIME ZONE'||wwv_flow.LF||
'   )  ;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index EBA_QPOLL_RESPONDENT';
wwv_flow_imp.g_varchar2_table(7) := 'S_UK on EBA_QPOLL_RESPONDENTS( email );'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER EBA_QPOLL_RESPONDENTS_BIU'||wwv_flow.LF||
'   befo';
wwv_flow_imp.g_varchar2_table(8) := 're insert or update on EBA_QPOLL_RESPONDENTS'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is null then'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(9) := ':new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then';
wwv_flow_imp.g_varchar2_table(10) := ''||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(11) := '   :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :n';
wwv_flow_imp.g_varchar2_table(12) := 'ew.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_ve';
wwv_flow_imp.g_varchar2_table(13) := 'rsion_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.email := lower(:new.email);'||wwv_flow.LF||
'   if inserting or updating then';
wwv_flow_imp.g_varchar2_table(14) := ''||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   e';
wwv_flow_imp.g_varchar2_table(15) := 'nd if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TRIGGER EBA_QPOLL_RESPONDENTS_BIU ENABLE;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13873074330049276277)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_respondents table'
,p_sequence=>160
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
