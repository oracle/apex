prompt --application/deployment/install/install_eba_qpoll_canned_answers_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_canned_answers table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE EBA_QPOLL_CANNED_ANSWERS'||wwv_flow.LF||
'   ('||wwv_flow.LF||
'    ID                    NUMBER constraint EBA_QPOLL_CAN';
wwv_flow_imp.g_varchar2_table(2) := 'NED_ANSWERS_PK primary key, '||wwv_flow.LF||
'    ROW_VERSION_NUMBER    NUMBER not null, '||wwv_flow.LF||
'    NAME                  V';
wwv_flow_imp.g_varchar2_table(3) := 'ARCHAR2(255) not null, '||wwv_flow.LF||
'    code                  varchar2(255) not null,'||wwv_flow.LF||
'    sort_order            ';
wwv_flow_imp.g_varchar2_table(4) := 'number,'||wwv_flow.LF||
'    description           varchar2(4000),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    intro_text            varchar2(4000),'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(5) := '   help_text             varchar2(4000),'||wwv_flow.LF||
'    answer_01             varchar2(4000),'||wwv_flow.LF||
'    answer_02    ';
wwv_flow_imp.g_varchar2_table(6) := '         varchar2(4000),'||wwv_flow.LF||
'    answer_03             varchar2(4000),'||wwv_flow.LF||
'    answer_04             varchar';
wwv_flow_imp.g_varchar2_table(7) := '2(4000),'||wwv_flow.LF||
'    answer_05             varchar2(4000),'||wwv_flow.LF||
'    answer_06             varchar2(4000),'||wwv_flow.LF||
'    ans';
wwv_flow_imp.g_varchar2_table(8) := 'wer_07             varchar2(4000),'||wwv_flow.LF||
'    answer_08             varchar2(4000),'||wwv_flow.LF||
'    answer_09          ';
wwv_flow_imp.g_varchar2_table(9) := '   varchar2(4000),'||wwv_flow.LF||
'    answer_10             varchar2(4000),'||wwv_flow.LF||
'    answer_11             varchar2(4000';
wwv_flow_imp.g_varchar2_table(10) := '),'||wwv_flow.LF||
'    answer_12             varchar2(4000),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    CREATED_BY            VARCHAR2(255 BYTE), '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(11) := '   CREATED               TIMESTAMP WITH TIME ZONE, '||wwv_flow.LF||
'    UPDATED_BY            VARCHAR2(255 BYTE), '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(12) := '   UPDATED               TIMESTAMP WITH TIME ZONE'||wwv_flow.LF||
'   )  ;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index EBA_QPOLL_CANNED_ANS';
wwv_flow_imp.g_varchar2_table(13) := 'WERS_i1 on EBA_QPOLL_CANNED_ANSWERS( NAME );'||wwv_flow.LF||
'create unique index EBA_QPOLL_CANNED_ANSWERS_i2 on EBA_';
wwv_flow_imp.g_varchar2_table(14) := 'QPOLL_CANNED_ANSWERS( code );'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER EBA_QPOLL_CANNED_ANSW_BIU'||wwv_flow.LF||
'   before insert';
wwv_flow_imp.g_varchar2_table(15) := ' or update on EBA_QPOLL_CANNED_ANSWERS'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is null then'||wwv_flow.LF||
'      :new.i';
wwv_flow_imp.g_varchar2_table(16) := 'd := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(17) := '  :new.created := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :ne';
wwv_flow_imp.g_varchar2_table(18) := 'w.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row';
wwv_flow_imp.g_varchar2_table(19) := '_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_';
wwv_flow_imp.g_varchar2_table(20) := 'number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;';
wwv_flow_imp.g_varchar2_table(21) := ''||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.code := replace(:new.code,''';
wwv_flow_imp.g_varchar2_table(22) := ' '','''');'||wwv_flow.LF||
'   :new.code := upper(:new.code);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'ALTER TRIGGER EBA_QPOLL_CANNED_ANSW_BIU ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(23) := ''||wwv_flow.LF||
'insert into EBA_QPOLL_CANNED_ANSWERS (id, NAME, code, answer_01, answer_02, answer_03, answer_04, a';
wwv_flow_imp.g_varchar2_table(24) := 'nswer_05)'||wwv_flow.LF||
'values (1, ''Range: 1 = Will not use to 5 = Will immediately use'', ''RANGE_TIMEFRAME'', '||wwv_flow.LF||
'''Wil';
wwv_flow_imp.g_varchar2_table(25) := 'l not use'', ''Unlikely to use'', ''Will consider using'', ''Likely to use'', ''Will use immediately'');'||wwv_flow.LF||
''||wwv_flow.LF||
'ins';
wwv_flow_imp.g_varchar2_table(26) := 'ert into EBA_QPOLL_CANNED_ANSWERS (id, NAME, code, answer_01, answer_02, answer_03, answer_04, answe';
wwv_flow_imp.g_varchar2_table(27) := 'r_05)'||wwv_flow.LF||
'values (2, ''Range: 1 = Least valuable to 5 = Most Valuable'', ''RANGE_VALUE'', '||wwv_flow.LF||
'''Least Valuable'',';
wwv_flow_imp.g_varchar2_table(28) := ' ''Limited Value'', ''Useful'', ''Valuable'', ''Most Valuable'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOLL_CANNED_ANSWERS (id,';
wwv_flow_imp.g_varchar2_table(29) := ' NAME, code, answer_01, answer_02, answer_03, answer_04, answer_05)'||wwv_flow.LF||
'values (3, ''Range: 1 = Megabytes';
wwv_flow_imp.g_varchar2_table(30) := ' or less to 5 = Petabytes or more'', ''RANGE_STORAGE'', '||wwv_flow.LF||
'''Megabytes or less'', ''100 MB'', ''Gigabytes'', ''T';
wwv_flow_imp.g_varchar2_table(31) := 'erabytes'', ''Petabytes or more'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOLL_CANNED_ANSWERS (id, NAME, code, answer_01, a';
wwv_flow_imp.g_varchar2_table(32) := 'nswer_02, answer_03, answer_04, answer_05)'||wwv_flow.LF||
'values (4, ''Range: 1 = Never to 5 = All of the time'', ''RA';
wwv_flow_imp.g_varchar2_table(33) := 'NGE_FREQUENCY'', '||wwv_flow.LF||
'''Never'', ''Infrequently'', ''Sometimes'', ''Frequently'', ''All of the time'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert int';
wwv_flow_imp.g_varchar2_table(34) := 'o EBA_QPOLL_CANNED_ANSWERS (id, NAME, code, answer_01, answer_02, answer_03, answer_04, answer_05)'||wwv_flow.LF||
'v';
wwv_flow_imp.g_varchar2_table(35) := 'alues (5, ''Range: 1 = Not Applicable to 5 = Most Applicable'', ''RANGE_APPLICABILITY'', '||wwv_flow.LF||
'''Not Applicabl';
wwv_flow_imp.g_varchar2_table(36) := 'e'', ''Less Applicable'', ''Applicable'', ''Broadly Applicable'', ''Most Applicable'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOL';
wwv_flow_imp.g_varchar2_table(37) := 'L_CANNED_ANSWERS (id, NAME, code, answer_01, answer_02, answer_03, answer_04, answer_05)'||wwv_flow.LF||
'values (6, ';
wwv_flow_imp.g_varchar2_table(38) := '''Range: 1 = Obtuse to 5 = Elegant'', ''RANGE_ELEGANCE'', '||wwv_flow.LF||
'''Obtuse'', ''Needs Improvement'', ''Somewhat Eleg';
wwv_flow_imp.g_varchar2_table(39) := 'ant'', ''Reasonably Elegant'', ''Elegant'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOLL_CANNED_ANSWERS (id, NAME, code, answe';
wwv_flow_imp.g_varchar2_table(40) := 'r_01, answer_02, answer_03, answer_04, answer_05)'||wwv_flow.LF||
'values (7, ''Range: 1 = Very Complex to 5 = Very Si';
wwv_flow_imp.g_varchar2_table(41) := 'mple'', ''RANGE_SIMPLE_TO_COMPLEX'', '||wwv_flow.LF||
'''Very Complex'', ''Complex'', ''Medium complexity'', ''Simple'', ''Very S';
wwv_flow_imp.g_varchar2_table(42) := 'imple'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOLL_CANNED_ANSWERS (id, NAME, code, answer_01, answer_02, answer_03, ans';
wwv_flow_imp.g_varchar2_table(43) := 'wer_04, answer_05)'||wwv_flow.LF||
'values (8, ''Range: 1 = Hard to 5 = Easy'', ''RANGE_HARD_TO_EASY'', '||wwv_flow.LF||
'''Very Hard'', ''Ha';
wwv_flow_imp.g_varchar2_table(44) := 'rd'', ''Neutral'', ''Easy'', ''Very Easy'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOLL_CANNED_ANSWERS (id, NAME, code, answer_';
wwv_flow_imp.g_varchar2_table(45) := '01, answer_02, answer_03, answer_04, answer_05)'||wwv_flow.LF||
'values (9, ''Range: 1 = Will not endorse to 5 = Will ';
wwv_flow_imp.g_varchar2_table(46) := 'fully endorse'', ''RANGE_ENDORSE'', '||wwv_flow.LF||
'''Will not endorse'', ''Unlikely to endorse'', ''Neutral'', ''Likely to e';
wwv_flow_imp.g_varchar2_table(47) := 'ndorse'', ''Will fully endorse'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOLL_CANNED_ANSWERS (id, NAME, code, answer_01, an';
wwv_flow_imp.g_varchar2_table(48) := 'swer_02, answer_03, answer_04, answer_05)'||wwv_flow.LF||
'values (10, ''Range: 1 = Will not consider using to 5 = Wil';
wwv_flow_imp.g_varchar2_table(49) := 'l definitely consider'', ''RANGE_CONSIDERATION'', '||wwv_flow.LF||
'''Will not consider'', ''Unlikely to consider'', ''Neutra';
wwv_flow_imp.g_varchar2_table(50) := 'l'', ''Will consider'', ''Will definitely consider'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOLL_CANNED_ANSWERS (id, NAME, c';
wwv_flow_imp.g_varchar2_table(51) := 'ode, answer_01, answer_02, answer_03, answer_04, answer_05)'||wwv_flow.LF||
'values (11, ''Range: 1 = Not recommend to';
wwv_flow_imp.g_varchar2_table(52) := ' 5 = Highly recommend'', ''RANGE_RECOMMENDATION'', '||wwv_flow.LF||
'''Not recommend'', ''Less recommend'', ''Neutral'', ''Reco';
wwv_flow_imp.g_varchar2_table(53) := 'mmend'', ''Highly recommend'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOLL_CANNED_ANSWERS (id, NAME, code, answer_01, answe';
wwv_flow_imp.g_varchar2_table(54) := 'r_02, answer_03, answer_04, answer_05)'||wwv_flow.LF||
'values (12, ''Range: 1 = Poor to 5 = Excellent'', ''RANGE_POOR_T';
wwv_flow_imp.g_varchar2_table(55) := 'O_EXCELLENT'', '||wwv_flow.LF||
'''Poor'', ''Needs Improvement'', ''Neutral'', ''Good'', ''Excellent'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOLL_';
wwv_flow_imp.g_varchar2_table(56) := 'CANNED_ANSWERS (id, NAME, code, answer_01, answer_02, answer_03, answer_04, answer_05)'||wwv_flow.LF||
'values (13, ''';
wwv_flow_imp.g_varchar2_table(57) := 'Range: 1 = Least Likely to 5 = Most Likely'', ''RANGE_LIKELIHOOD'', '||wwv_flow.LF||
'''Least likely'', ''Unlikely'', ''Neutr';
wwv_flow_imp.g_varchar2_table(58) := 'al'', ''Somewhat likely'', ''Most likely'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOLL_CANNED_ANSWERS (id, NAME, code, answe';
wwv_flow_imp.g_varchar2_table(59) := 'r_01, answer_02, answer_03, answer_04, answer_05)'||wwv_flow.LF||
'values (14, ''Range: 1 = Disagree to 5 = Fully Agre';
wwv_flow_imp.g_varchar2_table(60) := 'e'', ''RANGE_AGREE_DISAGREE'', '||wwv_flow.LF||
'''Disagree'', ''Somewhat disagree'', ''Neutral'', ''Agree'', ''Fully Agree'');'||wwv_flow.LF||
''||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(61) := 'nsert into EBA_QPOLL_CANNED_ANSWERS (id, NAME, code, answer_01, answer_02, answer_03, answer_04, ans';
wwv_flow_imp.g_varchar2_table(62) := 'wer_05)'||wwv_flow.LF||
'values (15, ''Range: 1 = Hate it to 5 = Love it'', ''RANGE_LOVE_HATE'', '||wwv_flow.LF||
'''Hate it'', ''Don''''t like';
wwv_flow_imp.g_varchar2_table(63) := ' it'', ''Neutral'', ''Like it'', ''Love it'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOLL_CANNED_ANSWERS (id, NAME, code, answe';
wwv_flow_imp.g_varchar2_table(64) := 'r_01, answer_02, answer_03, answer_04, answer_05)'||wwv_flow.LF||
'values (16, ''Range: 1 = Lowest to 5 = Highest'', ''R';
wwv_flow_imp.g_varchar2_table(65) := 'ANGE_LOW_TO_HIGH'', '||wwv_flow.LF||
'''Lowest'', ''Low'', ''Medium'', ''High'', ''Highest'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOLL_CANNED_ANS';
wwv_flow_imp.g_varchar2_table(66) := 'WERS (id, NAME, code, sort_order, answer_01, answer_02, answer_03, answer_04, answer_05)'||wwv_flow.LF||
'values (17,';
wwv_flow_imp.g_varchar2_table(67) := '''Range: Yes, No'', ''YES_NO'', 10,'||wwv_flow.LF||
'''Yes'', ''No'', null, null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOLL_CANNED_ANSWER';
wwv_flow_imp.g_varchar2_table(68) := 'S (id, NAME, code, sort_order, answer_01, answer_02, answer_03, answer_04, answer_05)'||wwv_flow.LF||
'values (18, ''R';
wwv_flow_imp.g_varchar2_table(69) := 'ange: True, False'', ''TRUE_FALSE'', 11,'||wwv_flow.LF||
'''True'', ''False'', null, null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOLL_CAN';
wwv_flow_imp.g_varchar2_table(70) := 'NED_ANSWERS (id, NAME, code, answer_01, answer_02, answer_03, answer_04, answer_05)'||wwv_flow.LF||
'values (19, ''Ran';
wwv_flow_imp.g_varchar2_table(71) := 'ge: Grades A to F'', ''GRADE'', '||wwv_flow.LF||
'    ''F - Failure'', ''D - Needs improvement'', ''C - Adequate'', ''B - Above';
wwv_flow_imp.g_varchar2_table(72) := ' average'', ''A - Outstanding'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOLL_CANNED_ANSWERS (id, NAME, code, sort_order, an';
wwv_flow_imp.g_varchar2_table(73) := 'swer_01, answer_02, answer_03, answer_04, answer_05)'||wwv_flow.LF||
'    values (20, ''Text Field (255 character maxi';
wwv_flow_imp.g_varchar2_table(74) := 'mum)'', ''TEXT'', 11.5,'||wwv_flow.LF||
'    ''Text field'', null, null, null, null);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOLL_CANNED_ANSWER';
wwv_flow_imp.g_varchar2_table(75) := 'S (id, NAME, code, sort_order, answer_01, answer_02, answer_03, answer_04, answer_05)'||wwv_flow.LF||
'    values (21';
wwv_flow_imp.g_varchar2_table(76) := ', ''Multi-line Text (4000 character maximum)'', ''TEXTAREA'', 12,'||wwv_flow.LF||
'    ''Free form text'', null, null, null';
wwv_flow_imp.g_varchar2_table(77) := ', null);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOLL_CANNED_ANSWERS (id, NAME, code, answer_01, answer_02, answer_03, ans';
wwv_flow_imp.g_varchar2_table(78) := 'wer_04, answer_05)'||wwv_flow.LF||
'values (22, ''Range: 1 = Unusable to 5 = Intuitive'', ''INTUITIVE'', '||wwv_flow.LF||
'    ''Unusable'',';
wwv_flow_imp.g_varchar2_table(79) := ' ''Poor'', ''Usable'', ''Good'', ''Intuitive'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOLL_CANNED_ANSWERS (id, NAME, code, answ';
wwv_flow_imp.g_varchar2_table(80) := 'er_01, answer_02, answer_03, answer_04, answer_05)'||wwv_flow.LF||
'values (23, ''Range: 1 = Very Little to 5 = Very M';
wwv_flow_imp.g_varchar2_table(81) := 'uch'', ''LIKE'', '||wwv_flow.LF||
'    ''Very little'', ''Little'', ''Neutral'', ''A little bit'', ''Very much'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EB';
wwv_flow_imp.g_varchar2_table(82) := 'A_QPOLL_CANNED_ANSWERS (id, NAME, code, answer_01, answer_02, answer_03, answer_04, answer_05)'||wwv_flow.LF||
'value';
wwv_flow_imp.g_varchar2_table(83) := 's (24, ''Range: 1 = Low to 5 = High'', ''LOW_HIGH'', '||wwv_flow.LF||
'    ''Low'', ''Below Average'', ''Average'', ''Above Aver';
wwv_flow_imp.g_varchar2_table(84) := 'age'', ''High'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOLL_CANNED_ANSWERS (id, NAME, code, answer_01, answer_02, answer_0';
wwv_flow_imp.g_varchar2_table(85) := '3, answer_04, answer_05)'||wwv_flow.LF||
'values (25, ''Range: 1 = Cold to 5 = Hot'', ''HOT_COLD'', '||wwv_flow.LF||
'    ''Cold'', ''Cool'', ';
wwv_flow_imp.g_varchar2_table(86) := '''Neutral'', ''Warm'', ''Hot'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into EBA_QPOLL_CANNED_ANSWERS (id, NAME, code, answer_01, answer_';
wwv_flow_imp.g_varchar2_table(87) := '02, answer_03, answer_04)'||wwv_flow.LF||
'values (26, ''Range: MoSCoW'', ''MosCoW'', '||wwv_flow.LF||
'    ''Must Have'', ''Should Have (hig';
wwv_flow_imp.g_varchar2_table(88) := 'h-priority, include if possible)'', ''Could Have (desirable, but not necessary)'', ''Won''''t Have (not ne';
wwv_flow_imp.g_varchar2_table(89) := 'eded, will not be included)'');'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13874517623188102713)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_canned_answers table'
,p_sequence=>210
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
