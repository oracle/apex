prompt --application/deployment/install/install_eba_qpoll_comm_invites_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_comm_invites table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE EBA_QPOLL_COMM_INVITES'||wwv_flow.LF||
'   ('||wwv_flow.LF||
'    id                    number  not null,  '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    po';
wwv_flow_imp.g_varchar2_table(2) := 'll_id               number  not null,'||wwv_flow.LF||
'    community_id          number,  '||wwv_flow.LF||
'    community_name        ';
wwv_flow_imp.g_varchar2_table(3) := 'varchar2(4000), -- if community_name is null, then individual invite'||wwv_flow.LF||
'    invite_method         varch';
wwv_flow_imp.g_varchar2_table(4) := 'ar2(30),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    CREATED_BY            VARCHAR2(255), '||wwv_flow.LF||
'    CREATED               TIMESTAMP WITH T';
wwv_flow_imp.g_varchar2_table(5) := 'IME ZONE,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    constraint eba_qpoll_comm_invites_pk '||wwv_flow.LF||
'      primary key (id),'||wwv_flow.LF||
'    constraint eb';
wwv_flow_imp.g_varchar2_table(6) := 'a_qpoll_comm_invites_fk1'||wwv_flow.LF||
'      foreign key (poll_id)'||wwv_flow.LF||
'      references eba_qpoll_polls (id)'||wwv_flow.LF||
'      on ';
wwv_flow_imp.g_varchar2_table(7) := 'delete cascade,'||wwv_flow.LF||
'    constraint eba_qpoll_comm_invites_fk2'||wwv_flow.LF||
'      foreign key (community_id)'||wwv_flow.LF||
'      ref';
wwv_flow_imp.g_varchar2_table(8) := 'erences eba_qpoll_resp_communities (id)'||wwv_flow.LF||
'      on delete set null'||wwv_flow.LF||
'   );'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_qpoll_com';
wwv_flow_imp.g_varchar2_table(9) := 'm_invites_i1 on eba_qpoll_comm_invites( community_id );'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER eba_qpoll_comm_in';
wwv_flow_imp.g_varchar2_table(10) := 'vites_bi'||wwv_flow.LF||
'   before insert on eba_qpoll_comm_invites'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is null then';
wwv_flow_imp.g_varchar2_table(11) := ''||wwv_flow.LF||
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.creat';
wwv_flow_imp.g_varchar2_table(12) := 'ed := current_timestamp;'||wwv_flow.LF||
'   :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TRIGGER eba_';
wwv_flow_imp.g_varchar2_table(13) := 'qpoll_comm_invites_bi ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE TABLE EBA_QPOLL_INVITES'||wwv_flow.LF||
'   ('||wwv_flow.LF||
'    id                    number';
wwv_flow_imp.g_varchar2_table(14) := '  not null,  '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    comm_invite_id        number  not null,'||wwv_flow.LF||
'    respondent_id         number  n';
wwv_flow_imp.g_varchar2_table(15) := 'ot null,'||wwv_flow.LF||
'    respondent_email      varchar2(4000) not null, -- at time of invitation'||wwv_flow.LF||
'    email_sent ';
wwv_flow_imp.g_varchar2_table(16) := '           varchar2(30)   not null, -- YES, OPTED_OUT or PREVIOUSLY_SENT'||wwv_flow.LF||
'    email_id              n';
wwv_flow_imp.g_varchar2_table(17) := 'umber, '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    CREATED_BY            VARCHAR2(255), '||wwv_flow.LF||
'    CREATED               TIMESTAMP WITH TI';
wwv_flow_imp.g_varchar2_table(18) := 'ME ZONE,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    constraint EBA_QPOLL_INVITES_PK '||wwv_flow.LF||
'      primary key (id),'||wwv_flow.LF||
'    constraint eba_qpol';
wwv_flow_imp.g_varchar2_table(19) := 'l_invites_fk1'||wwv_flow.LF||
'      foreign key (comm_invite_id)'||wwv_flow.LF||
'      references eba_qpoll_comm_invites (id)'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(20) := 'on delete cascade,'||wwv_flow.LF||
'    constraint eba_qpoll_invites_fk2'||wwv_flow.LF||
'      foreign key (respondent_id)'||wwv_flow.LF||
'      refe';
wwv_flow_imp.g_varchar2_table(21) := 'rences eba_qpoll_respondents (id),'||wwv_flow.LF||
'    constraint eba_qpoll_invites_fk3'||wwv_flow.LF||
'      foreign key (email_id)';
wwv_flow_imp.g_varchar2_table(22) := ''||wwv_flow.LF||
'      references eba_qpoll_emails (id)'||wwv_flow.LF||
'      on delete set null'||wwv_flow.LF||
'   );'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_qpoll_inv';
wwv_flow_imp.g_varchar2_table(23) := 'ites_i1 on eba_qpoll_invites( comm_invite_id );'||wwv_flow.LF||
'create index eba_qpoll_invites_i2 on eba_qpoll_invit';
wwv_flow_imp.g_varchar2_table(24) := 'es( respondent_id );'||wwv_flow.LF||
'create index eba_qpoll_invites_i3 on eba_qpoll_invites( email_id );'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR ';
wwv_flow_imp.g_varchar2_table(25) := 'REPLACE TRIGGER eba_qpoll_invites_bi'||wwv_flow.LF||
'   before insert on eba_qpoll_invites'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(26) := 'if :new.ID is null then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(27) := '  end if;'||wwv_flow.LF||
'   :new.created := current_timestamp;'||wwv_flow.LF||
'   :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'end';
wwv_flow_imp.g_varchar2_table(28) := ';'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TRIGGER eba_qpoll_invites_bi ENABLE;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(14000948931218781296)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_comm_invites table'
,p_sequence=>200
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
