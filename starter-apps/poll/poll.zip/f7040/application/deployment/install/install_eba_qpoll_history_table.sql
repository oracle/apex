prompt --application/deployment/install/install_eba_qpoll_history_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_history table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_qpoll_history ('||wwv_flow.LF||
'    id                  number,'||wwv_flow.LF||
'    row_version_number  number,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(2) := ' component_id        number,'||wwv_flow.LF||
'    poll_id             number,'||wwv_flow.LF||
'    component_rowkey    varchar2(30),'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(3) := '   table_name          varchar2(60) not null enable,'||wwv_flow.LF||
'    column_name         varchar2(60) not null e';
wwv_flow_imp.g_varchar2_table(4) := 'nable,'||wwv_flow.LF||
'    old_value           varchar2(4000),'||wwv_flow.LF||
'    new_value           varchar2(4000),'||wwv_flow.LF||
'    change_da';
wwv_flow_imp.g_varchar2_table(5) := 'te         timestamp (6) with time zone,'||wwv_flow.LF||
'    changed_by          varchar2(255),'||wwv_flow.LF||
'    constraint eba_q';
wwv_flow_imp.g_varchar2_table(6) := 'poll_history_pk primary key (id) enable'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_qpoll_history_i1 on eba_qpoll_history ';
wwv_flow_imp.g_varchar2_table(7) := '(component_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_qpoll_history_biu'||wwv_flow.LF||
'    before insert or update on eba';
wwv_flow_imp.g_varchar2_table(8) := '_qpoll_history'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'       :new.id := to_number(sys_gu';
wwv_flow_imp.g_varchar2_table(9) := 'id(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.change_date';
wwv_flow_imp.g_varchar2_table(10) := ' := current_timestamp;'||wwv_flow.LF||
'        :new.changed_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'        :new.row_versio';
wwv_flow_imp.g_varchar2_table(11) := 'n_number := 1;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.row_version_number := :new.row_version_number + ';
wwv_flow_imp.g_varchar2_table(12) := '1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_history_biu enable'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(14033517912009440801)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_history table'
,p_sequence=>430
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
