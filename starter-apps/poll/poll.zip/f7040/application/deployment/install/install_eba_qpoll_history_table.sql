prompt --application/deployment/install/install_eba_qpoll_history_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_history table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(14016405072402713156)
,p_install_id=>wwv_flow_imp.id(15905304203813941168)
,p_name=>'eba_qpoll_history table'
,p_sequence=>430
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table eba_qpoll_history (',
'    id                  number,',
'    row_version_number  number,',
'    component_id        number,',
'    poll_id             number,',
'    component_rowkey    varchar2(30),',
'    table_name          varchar2(60) not null enable,',
'    column_name         varchar2(60) not null enable,',
'    old_value           varchar2(4000),',
'    new_value           varchar2(4000),',
'    change_date         timestamp (6) with time zone,',
'    changed_by          varchar2(255),',
'    constraint eba_qpoll_history_pk primary key (id) enable',
')',
'/',
'',
'create index eba_qpoll_history_i1 on eba_qpoll_history (component_id)',
'/',
'',
'create or replace trigger eba_qpoll_history_biu',
'    before insert or update on eba_qpoll_history',
'    for each row',
'begin',
'    if :new.id is null then',
'       :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');',
'    end if;',
'    if inserting then',
'        :new.change_date := current_timestamp;',
'        :new.changed_by := nvl(wwv_flow.g_user,user);',
'        :new.row_version_number := 1;',
'    elsif updating then',
'        :new.row_version_number := :new.row_version_number + 1;',
'    end if;',
'end;',
'/',
'alter trigger eba_qpoll_history_biu enable',
'/'))
);
wwv_flow_imp.component_end;
end;
/
