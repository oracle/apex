prompt --application/deployment/install/install_eba_qpoll_notifications_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_notifications table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_qpoll_notifications ('||wwv_flow.LF||
'    id                        number            not null'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(2) := '                                            constraint eba_qpoll_note_pk'||wwv_flow.LF||
'                           ';
wwv_flow_imp.g_varchar2_table(3) := '                     primary key,'||wwv_flow.LF||
'    row_version_number        number,'||wwv_flow.LF||
'    notification_name       ';
wwv_flow_imp.g_varchar2_table(4) := '  varchar2(255)     not null,'||wwv_flow.LF||
'    notification_description  varchar2(4000)    null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    notif';
wwv_flow_imp.g_varchar2_table(5) := 'ication_type         varchar2(30)      not null'||wwv_flow.LF||
'                                                cons';
wwv_flow_imp.g_varchar2_table(6) := 'traint eba_qpoll_note_tp_cc'||wwv_flow.LF||
'                                                check (notification_type';
wwv_flow_imp.g_varchar2_table(7) := ' in (''RED'',''YELLOW'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    display_sequence          number,'||wwv_flow.LF||
'    display_from              ti';
wwv_flow_imp.g_varchar2_table(8) := 'mestamp with time zone,'||wwv_flow.LF||
'    display_until             timestamp with time zone,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created_b';
wwv_flow_imp.g_varchar2_table(9) := 'y                varchar2(255)       not null,'||wwv_flow.LF||
'    created                   timestamp with time zon';
wwv_flow_imp.g_varchar2_table(10) := 'e,'||wwv_flow.LF||
'    updated_by                varchar2(255)       not null,'||wwv_flow.LF||
'    updated                   timesta';
wwv_flow_imp.g_varchar2_table(11) := 'mp with time zone )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_qpoll_notifications_biu'||wwv_flow.LF||
'before insert or update';
wwv_flow_imp.g_varchar2_table(12) := ' on eba_qpoll_notifications'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(13) := ':new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting th';
wwv_flow_imp.g_varchar2_table(14) := 'en'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(15) := '      :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(16) := ' :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.row_version_number := n';
wwv_flow_imp.g_varchar2_table(17) := 'vl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.';
wwv_flow_imp.g_varchar2_table(18) := 'updated    := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.notification_type is null then'||wwv_flow.LF||
'       :new.';
wwv_flow_imp.g_varchar2_table(19) := 'notification_type := ''MANUAL'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.display_sequence is null then'||wwv_flow.LF||
'       :new.dis';
wwv_flow_imp.g_varchar2_table(20) := 'play_sequence := 10;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger eba_qpoll_notifications_biu enabl';
wwv_flow_imp.g_varchar2_table(21) := 'e;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'  '||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16148935236724035097)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_notifications table'
,p_sequence=>100
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
