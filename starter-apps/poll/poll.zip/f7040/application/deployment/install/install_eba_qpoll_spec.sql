prompt --application/deployment/install/install_eba_qpoll_spec
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package EBA_QPOLL is'||wwv_flow.LF||
'    ---------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(2) := '----------------'||wwv_flow.LF||
'    -- Gets the current user''s authorization level. Depends on the following:'||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(3) := '-  * If access control is currently disabled, returns highest role of ADMINISTRATOR.'||wwv_flow.LF||
'    --  * If ac';
wwv_flow_imp.g_varchar2_table(4) := 'cess control is enabled, but user is not in list, returns NONE.'||wwv_flow.LF||
'    --  * If access control is enabl';
wwv_flow_imp.g_varchar2_table(5) := 'ed and user is in list, returns their'||wwv_flow.LF||
'    --    access level.'||wwv_flow.LF||
'    ----------------------------------';
wwv_flow_imp.g_varchar2_table(6) := '---------------------------------------'||wwv_flow.LF||
'    function get_access_role ('||wwv_flow.LF||
'        p_app_id             ';
wwv_flow_imp.g_varchar2_table(7) := '  number,'||wwv_flow.LF||
'        p_username             varchar2)'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
'        '||wwv_flow.LF||
'    -- returns ';
wwv_flow_imp.g_varchar2_table(8) := 'error text if mandatory questions are not answered'||wwv_flow.LF||
'    function validate_submission'||wwv_flow.LF||
'        return v';
wwv_flow_imp.g_varchar2_table(9) := 'archar2;'||wwv_flow.LF||
'       '||wwv_flow.LF||
'    procedure remove_preactive_results ('||wwv_flow.LF||
'       p_poll_id   in  number );'||wwv_flow.LF||
'       '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(10) := '   function poll_take_status ('||wwv_flow.LF||
'          p_app_id       in  number,'||wwv_flow.LF||
'          p_poll_id      in  num';
wwv_flow_imp.g_varchar2_table(11) := 'ber,'||wwv_flow.LF||
'          p_app_user     in  varchar2,'||wwv_flow.LF||
'          p_app_session  in  number )'||wwv_flow.LF||
'          return v';
wwv_flow_imp.g_varchar2_table(12) := 'archar2;'||wwv_flow.LF||
'          '||wwv_flow.LF||
'    -- used for emailing results'||wwv_flow.LF||
'    function prepare_poll_results ('||wwv_flow.LF||
'        p_p';
wwv_flow_imp.g_varchar2_table(13) := 'oll_id  number )'||wwv_flow.LF||
'        return clob;'||wwv_flow.LF||
'        '||wwv_flow.LF||
'   procedure eba_qpoll_data_load;'||wwv_flow.LF||
'   '||wwv_flow.LF||
'   procedure eb';
wwv_flow_imp.g_varchar2_table(14) := 'a_qpoll_remove_data;'||wwv_flow.LF||
'        '||wwv_flow.LF||
'end EBA_QPOLL;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16401154634836332546)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll spec'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(14672338997573580343)
,p_script_id=>wwv_flow_imp.id(16401154634836332546)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_LIVEPOLL'
);
wwv_flow_imp.component_end;
end;
/
