prompt --application/deployment/install/install_eba_qpoll_email_spec
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_email spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13902804483538090421)
,p_install_id=>wwv_flow_imp.id(15905304203813941168)
,p_name=>'eba_qpoll_email spec'
,p_sequence=>35
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package eba_qpoll_email as',
'',
'procedure send (',
'   p_app_id              in   number,',
'   p_template_static_id  in   varchar2,',
'   p_placeholders        in   clob,',
'   p_to                  in   varchar2,',
'   p_from                in   varchar2,',
'   p_cc                  in   varchar2  default null,',
'   p_poll_id             in   number    default null,',
'   p_community_id        in   number    default null,',
'   p_respondent_id       in   number    default null,',
'   p_email_id            out  number );',
'   ',
'end eba_qpoll_email;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
