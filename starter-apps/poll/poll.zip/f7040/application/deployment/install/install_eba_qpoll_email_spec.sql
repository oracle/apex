prompt --application/deployment/install/install_eba_qpoll_email_spec
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_email spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_qpoll_email as'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure send ('||wwv_flow.LF||
'   p_app_id              in   number,';
wwv_flow_imp.g_varchar2_table(2) := ''||wwv_flow.LF||
'   p_template_static_id  in   varchar2,'||wwv_flow.LF||
'   p_placeholders        in   clob,'||wwv_flow.LF||
'   p_to                ';
wwv_flow_imp.g_varchar2_table(3) := '  in   varchar2,'||wwv_flow.LF||
'   p_from                in   varchar2,'||wwv_flow.LF||
'   p_cc                  in   varchar2  def';
wwv_flow_imp.g_varchar2_table(4) := 'ault null,'||wwv_flow.LF||
'   p_poll_id             in   number    default null,'||wwv_flow.LF||
'   p_community_id        in   numbe';
wwv_flow_imp.g_varchar2_table(5) := 'r    default null,'||wwv_flow.LF||
'   p_respondent_id       in   number    default null,'||wwv_flow.LF||
'   p_email_id            ou';
wwv_flow_imp.g_varchar2_table(6) := 't  number );'||wwv_flow.LF||
'   '||wwv_flow.LF||
'end eba_qpoll_email;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13919917323144818066)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_email spec'
,p_sequence=>35
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
