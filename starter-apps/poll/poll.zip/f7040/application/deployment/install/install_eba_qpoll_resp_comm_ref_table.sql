prompt --application/deployment/install/install_eba_qpoll_resp_comm_ref_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_resp_comm_ref table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_qpoll_resp_comm_ref ('||wwv_flow.LF||
'    id            number primary key,'||wwv_flow.LF||
'    respondent_id numbe';
wwv_flow_imp.g_varchar2_table(2) := 'r not null,'||wwv_flow.LF||
'    community_id  number not null,'||wwv_flow.LF||
'    created       timestamp with time zone,'||wwv_flow.LF||
'    creat';
wwv_flow_imp.g_varchar2_table(3) := 'ed_by    varchar2(255),'||wwv_flow.LF||
'    constraint eba_qpoll_rep_comm_ref_fk1'||wwv_flow.LF||
'        foreign key ( respondent_i';
wwv_flow_imp.g_varchar2_table(4) := 'd )'||wwv_flow.LF||
'        references eba_qpoll_respondents( id )'||wwv_flow.LF||
'        on delete cascade,'||wwv_flow.LF||
'    constraint eba_qpo';
wwv_flow_imp.g_varchar2_table(5) := 'll_rep_comm_ref_fk2'||wwv_flow.LF||
'        foreign key ( community_id )'||wwv_flow.LF||
'        references eba_qpoll_RESP_COMMUNITI';
wwv_flow_imp.g_varchar2_table(6) := 'ES( id )'||wwv_flow.LF||
'        on delete cascade'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index eba_qpoll_resp_comm_ref_UK on eba_qpoll_';
wwv_flow_imp.g_varchar2_table(7) := 'resp_comm_ref ( respondent_id,community_id )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create index eba_qpoll_resp_comm_ref_I1 on eba_qpoll_';
wwv_flow_imp.g_varchar2_table(8) := 'resp_comm_ref( community_id )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_qpoll_resp_comm_ref_bi'||wwv_flow.LF||
'   before inse';
wwv_flow_imp.g_varchar2_table(9) := 'rt on eba_qpoll_resp_comm_ref'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :NEW.ID is null then'||wwv_flow.LF||
'      :new.id := to_n';
wwv_flow_imp.g_varchar2_table(10) := 'umber(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.created := current_timestam';
wwv_flow_imp.g_varchar2_table(11) := 'p;'||wwv_flow.LF||
'   :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TRIGGER eba_qpoll_resp_comm_ref_bi';
wwv_flow_imp.g_varchar2_table(12) := ' ENABLE;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13938434635215138611)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_resp_comm_ref table'
,p_sequence=>170
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
