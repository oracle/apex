prompt --application/deployment/install/install_eba_qpoll_emails_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_emails table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_qpoll_emails ('||wwv_flow.LF||
'    id                     number         not null,'||wwv_flow.LF||
'    subject     ';
wwv_flow_imp.g_varchar2_table(2) := '           varchar2(400),'||wwv_flow.LF||
'    sent_time              timestamp with time zone,'||wwv_flow.LF||
'    sent_by          ';
wwv_flow_imp.g_varchar2_table(3) := '      varchar2(255)  not null,'||wwv_flow.LF||
'    sent_to                varchar2(4000) not null,'||wwv_flow.LF||
'    cc           ';
wwv_flow_imp.g_varchar2_table(4) := '          varchar2(4000),'||wwv_flow.LF||
'    template_static_id     varchar2(255), -- no fk as uses APEX-based temp';
wwv_flow_imp.g_varchar2_table(5) := 'lates'||wwv_flow.LF||
'    placeholders           clob,'||wwv_flow.LF||
'    text_body              clob,'||wwv_flow.LF||
'    html_body              c';
wwv_flow_imp.g_varchar2_table(6) := 'lob,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    email_status           varchar2(30),   -- SUCCESS or FAILURE'||wwv_flow.LF||
'    error_message      ';
wwv_flow_imp.g_varchar2_table(7) := '    varchar2(4000), -- only populated if failure'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    poll_id                number,'||wwv_flow.LF||
'    commu';
wwv_flow_imp.g_varchar2_table(8) := 'nity_id           number,'||wwv_flow.LF||
'    respondent_id          number,'||wwv_flow.LF||
'    constraint eba_qpoll_emails_pk prim';
wwv_flow_imp.g_varchar2_table(9) := 'ary key (id)'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_qpoll_emails_bi'||wwv_flow.LF||
'    before insert on eba_qpoll_email';
wwv_flow_imp.g_varchar2_table(10) := 's'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        :new.id := to_number(sys_guid(),''XXXXXX';
wwv_flow_imp.g_varchar2_table(11) := 'XXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.sent_to := lower(:new.sent_to);'||wwv_flow.LF||
'    :new.sent_tim';
wwv_flow_imp.g_varchar2_table(12) := 'e := current_timestamp;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger eba_qpoll_emails_bi enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    '||wwv_flow.LF||
'create index eb';
wwv_flow_imp.g_varchar2_table(13) := 'a_qpoll_emails_i1 on eba_qpoll_emails (community_id);'||wwv_flow.LF||
'create index eba_qpoll_emails_i2 on eba_qpoll_';
wwv_flow_imp.g_varchar2_table(14) := 'emails (poll_id);'||wwv_flow.LF||
'create index eba_qpoll_emails_i3 on eba_qpoll_emails (respondent_id);'||wwv_flow.LF||
'create index';
wwv_flow_imp.g_varchar2_table(15) := ' eba_qpoll_emails_i4 on eba_qpoll_emails (sent_to);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(573514370217126395)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_emails table'
,p_sequence=>190
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
