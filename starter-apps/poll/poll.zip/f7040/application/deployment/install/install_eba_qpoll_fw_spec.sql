prompt --application/deployment/install/install_eba_qpoll_fw_spec
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_fw spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_qpoll_fw as'||wwv_flow.LF||
'    function conv_txt_html ('||wwv_flow.LF||
'        p_txt_message in varc';
wwv_flow_imp.g_varchar2_table(2) := 'har2 )'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
'    function conv_urls_links ('||wwv_flow.LF||
'        p_string in varchar2 )'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(3) := '  return varchar2;'||wwv_flow.LF||
'    function selective_escape ('||wwv_flow.LF||
'        p_text  in varchar2,'||wwv_flow.LF||
'        p_tags  in v';
wwv_flow_imp.g_varchar2_table(4) := 'archar2 default ''<h2>,</h2>,<p>,</p>,<b>,</b>,<li>,</li>,<ul>,</ul>,<br />,<i>,</i>,<h3>,</h3>'' )'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(5) := '      return varchar2;'||wwv_flow.LF||
'    function get_preference_value ('||wwv_flow.LF||
'        p_preference_name in varchar2 )'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(6) := '       return varchar2;'||wwv_flow.LF||
'    procedure set_preference_value ('||wwv_flow.LF||
'        p_preference_name  in varchar2,';
wwv_flow_imp.g_varchar2_table(7) := ' '||wwv_flow.LF||
'        p_preference_value in varchar2 );'||wwv_flow.LF||
'    function compress_int ('||wwv_flow.LF||
'        n in integer )'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(8) := '   return varchar2;'||wwv_flow.LF||
'    procedure add_error_log ( '||wwv_flow.LF||
'        p_error           in apex_error.t_error,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(9) := '        p_procedure_name  in varchar2 default null,'||wwv_flow.LF||
'        p_error_text      in varchar2 default nu';
wwv_flow_imp.g_varchar2_table(10) := 'll,'||wwv_flow.LF||
'        p_arg1_name       in varchar2 default null,'||wwv_flow.LF||
'        p_arg1_val        in varchar2 defaul';
wwv_flow_imp.g_varchar2_table(11) := 't null,'||wwv_flow.LF||
'        p_arg2_name       in varchar2 default null,'||wwv_flow.LF||
'        p_arg2_val        in varchar2 de';
wwv_flow_imp.g_varchar2_table(12) := 'fault null,'||wwv_flow.LF||
'        p_arg3_name       in varchar2 default null,'||wwv_flow.LF||
'        p_arg3_val        in varchar';
wwv_flow_imp.g_varchar2_table(13) := '2 default null,'||wwv_flow.LF||
'        p_arg4_name       in varchar2 default null,'||wwv_flow.LF||
'        p_arg4_val        in var';
wwv_flow_imp.g_varchar2_table(14) := 'char2 default null );'||wwv_flow.LF||
'    function apex_error_handling ('||wwv_flow.LF||
'        p_error in apex_error.t_error )'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(15) := '     return apex_error.t_error_result;'||wwv_flow.LF||
'end eba_qpoll_fw;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16513169447516276071)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_fw spec'
,p_sequence=>15
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(14672339648748580377)
,p_script_id=>wwv_flow_imp.id(16513169447516276071)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_QPOLL_FW'
);
wwv_flow_imp.component_end;
end;
/
