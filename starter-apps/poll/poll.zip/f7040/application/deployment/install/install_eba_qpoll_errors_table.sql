prompt --application/deployment/install/install_eba_qpoll_errors_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_errors table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_qpoll_errors ('||wwv_flow.LF||
'    id                 number not null'||wwv_flow.LF||
'                       constr';
wwv_flow_imp.g_varchar2_table(2) := 'aint eba_qpoll_errors_pk'||wwv_flow.LF||
'                       primary key,'||wwv_flow.LF||
'    err_time           timestamp with t';
wwv_flow_imp.g_varchar2_table(3) := 'ime zone'||wwv_flow.LF||
'                       default current_timestamp'||wwv_flow.LF||
'                       not null,'||wwv_flow.LF||
'    app_i';
wwv_flow_imp.g_varchar2_table(4) := 'd             number,'||wwv_flow.LF||
'    app_page_id        number,'||wwv_flow.LF||
'    app_user           varchar2(512),'||wwv_flow.LF||
'    user_';
wwv_flow_imp.g_varchar2_table(5) := 'agent         varchar2(4000),'||wwv_flow.LF||
'    ip_address         varchar2(512), -- As reported by owa_util.get_c';
wwv_flow_imp.g_varchar2_table(6) := 'gi_env'||wwv_flow.LF||
'    ip_address2       varchar2(512), -- As reported by sys_context'||wwv_flow.LF||
'    -- From APEX_ERROR.T_E';
wwv_flow_imp.g_varchar2_table(7) := 'RROR:'||wwv_flow.LF||
'    message           varchar2(4000), /* Displayed error message */'||wwv_flow.LF||
'    page_item_name    varc';
wwv_flow_imp.g_varchar2_table(8) := 'har2(255),  /* Associated page item name */'||wwv_flow.LF||
'    region_id         number,         /* Associated tabu';
wwv_flow_imp.g_varchar2_table(9) := 'lar form region id of the primary application */'||wwv_flow.LF||
'    column_alias      varchar2(255),  /* Associated';
wwv_flow_imp.g_varchar2_table(10) := ' tabular form column alias */'||wwv_flow.LF||
'    row_num           number,         /* Associated tabular form row *';
wwv_flow_imp.g_varchar2_table(11) := '/'||wwv_flow.LF||
'    apex_error_code   varchar2(255),  /* Contains the system message code if it''''s an error raised';
wwv_flow_imp.g_varchar2_table(12) := ' by APEX */'||wwv_flow.LF||
'    ora_sqlcode       number,         /* SQLCODE on exception stack which triggered the ';
wwv_flow_imp.g_varchar2_table(13) := 'error, NULL if the error was not raised by an ORA error */'||wwv_flow.LF||
'    ora_sqlerrm       varchar2(4000), /* ';
wwv_flow_imp.g_varchar2_table(14) := 'SQLERRM which triggered the error, NULL if the error was not raised by an ORA error */'||wwv_flow.LF||
'    error_bac';
wwv_flow_imp.g_varchar2_table(15) := 'ktrace   varchar2(4000),  /* Output of dbms_utility.format_error_backtrace or dbms_utility.format_ca';
wwv_flow_imp.g_varchar2_table(16) := 'll_stack */'||wwv_flow.LF||
'    procedure_name    varchar2(1000) default null, /* used to track errors in access req';
wwv_flow_imp.g_varchar2_table(17) := 'uest process */'||wwv_flow.LF||
'    error_text        varchar2(4000) default null, /* used to track errors in access';
wwv_flow_imp.g_varchar2_table(18) := ' request process */'||wwv_flow.LF||
'    arg1_name         varchar2(255)  default null, /* used to track errors in ac';
wwv_flow_imp.g_varchar2_table(19) := 'cess request process */'||wwv_flow.LF||
'    arg1_val          varchar2(4000) default null, /* used to track errors i';
wwv_flow_imp.g_varchar2_table(20) := 'n access request process */'||wwv_flow.LF||
'    arg2_name         varchar2(255)  default null, /* used to track erro';
wwv_flow_imp.g_varchar2_table(21) := 'rs in access request process */'||wwv_flow.LF||
'    arg2_val          varchar2(4000) default null, /* used to track ';
wwv_flow_imp.g_varchar2_table(22) := 'errors in access request process */'||wwv_flow.LF||
'    arg3_name         varchar2(255)  default null, /* used to tr';
wwv_flow_imp.g_varchar2_table(23) := 'ack errors in access request process */'||wwv_flow.LF||
'    arg3_val          varchar2(4000) default null, /* used t';
wwv_flow_imp.g_varchar2_table(24) := 'o track errors in access request process */'||wwv_flow.LF||
'    arg4_name         varchar2(255)  default null, /* us';
wwv_flow_imp.g_varchar2_table(25) := 'ed to track errors in access request process */'||wwv_flow.LF||
'    arg4_val          varchar2(4000) default null /*';
wwv_flow_imp.g_varchar2_table(26) := ' used to track errors in access request process */'||wwv_flow.LF||
'    -- END APEX_ERROR.T_ERROR'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eb';
wwv_flow_imp.g_varchar2_table(27) := 'a_qpoll_errors_i1 on eba_qpoll_errors( err_time );'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_qpoll_errors_bi'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(28) := '  before insert or update on eba_qpoll_errors'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(29) := '    :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show err';
wwv_flow_imp.g_varchar2_table(30) := 'ors'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16513164661293674461)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_errors table'
,p_sequence=>70
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
