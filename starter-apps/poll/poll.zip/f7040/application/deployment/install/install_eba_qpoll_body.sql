prompt --application/deployment/install/install_eba_qpoll_body
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body eba_qpoll as '||wwv_flow.LF||
'    ---------------------------------------------------';
wwv_flow_imp.g_varchar2_table(2) := '---------------------- '||wwv_flow.LF||
'    -- Gets the current user''s authorization level. Depends on the following';
wwv_flow_imp.g_varchar2_table(3) := ': '||wwv_flow.LF||
'    --  * If access control is currently disabled, returns highest role of ADMINISTRATOR. '||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(4) := '  * If access control is enabled, but user is not in list, returns NONE. '||wwv_flow.LF||
'    --  * If access contro';
wwv_flow_imp.g_varchar2_table(5) := 'l is enabled and user is in list, returns their '||wwv_flow.LF||
'    --    access level. '||wwv_flow.LF||
'    ----------------------';
wwv_flow_imp.g_varchar2_table(6) := '--------------------------------------------------- '||wwv_flow.LF||
'    function get_access_role ( '||wwv_flow.LF||
'        p_app_i';
wwv_flow_imp.g_varchar2_table(7) := 'd               number, '||wwv_flow.LF||
'        p_username             varchar2 ) '||wwv_flow.LF||
'        return varchar2 '||wwv_flow.LF||
'    is ';
wwv_flow_imp.g_varchar2_table(8) := ''||wwv_flow.LF||
'    begin '||wwv_flow.LF||
'        -- If the user isn''t authenticated, they have no privilege. '||wwv_flow.LF||
'        if not apex';
wwv_flow_imp.g_varchar2_table(9) := '_authentication.is_authenticated then '||wwv_flow.LF||
'            return ''NONE''; '||wwv_flow.LF||
'        end if; '||wwv_flow.LF||
'        -- If ac';
wwv_flow_imp.g_varchar2_table(10) := 'cess control is disabled, default to highest privilege '||wwv_flow.LF||
'        if eba_qpoll_fw.get_preference_value';
wwv_flow_imp.g_varchar2_table(11) := '(''ACCESS_CONTROL_ENABLED'') = ''N'' then '||wwv_flow.LF||
'            return ''ADMINISTRATOR''; '||wwv_flow.LF||
'        elsif '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(12) := '   APEX_ACL.HAS_USER_ROLE ( '||wwv_flow.LF||
'                p_application_id  => p_app_id, '||wwv_flow.LF||
'                p_user_';
wwv_flow_imp.g_varchar2_table(13) := 'name       => p_username, '||wwv_flow.LF||
'                p_role_static_id  => ''ADMINISTRATOR'' )  '||wwv_flow.LF||
'            then';
wwv_flow_imp.g_varchar2_table(14) := ' return ''ADMINISTRATOR''; '||wwv_flow.LF||
'        elsif eba_qpoll_fw.get_preference_value(''ACCESS_CONTROL_SCOPE'') = ';
wwv_flow_imp.g_varchar2_table(15) := '''PUBLIC_CONTRIBUTE'' then '||wwv_flow.LF||
'            return ''CONTRIBUTOR'';  '||wwv_flow.LF||
'        elsif '||wwv_flow.LF||
'            APEX_ACL.HA';
wwv_flow_imp.g_varchar2_table(16) := 'S_USER_ROLE ( '||wwv_flow.LF||
'                p_application_id  => p_app_id, '||wwv_flow.LF||
'                p_user_name       => ';
wwv_flow_imp.g_varchar2_table(17) := 'p_username, '||wwv_flow.LF||
'                p_role_static_id  => ''CONTRIBUTOR'' )  '||wwv_flow.LF||
'            then return ''CONTRIB';
wwv_flow_imp.g_varchar2_table(18) := 'UTOR''; '||wwv_flow.LF||
'        elsif eba_qpoll_fw.get_preference_value(''ACCESS_CONTROL_SCOPE'') = ''PUBLIC_READONLY'' ';
wwv_flow_imp.g_varchar2_table(19) := 'then '||wwv_flow.LF||
'            return ''READER'';  '||wwv_flow.LF||
'        elsif '||wwv_flow.LF||
'            APEX_ACL.HAS_USER_ROLE ( '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(20) := '      p_application_id  => p_app_id, '||wwv_flow.LF||
'                p_user_name       => p_username, '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(21) := '    p_role_static_id  => ''READER'' )  '||wwv_flow.LF||
'            then return ''READER''; '||wwv_flow.LF||
'        else '||wwv_flow.LF||
'            r';
wwv_flow_imp.g_varchar2_table(22) := 'eturn ''NONE''; '||wwv_flow.LF||
'        end if;          '||wwv_flow.LF||
'    end get_access_role; '||wwv_flow.LF||
' '||wwv_flow.LF||
' '||wwv_flow.LF||
'-- returns error if mandatory';
wwv_flow_imp.g_varchar2_table(23) := ' questions are not answered '||wwv_flow.LF||
'function validate_submission '||wwv_flow.LF||
'   return varchar2 '||wwv_flow.LF||
'as '||wwv_flow.LF||
'   x             ';
wwv_flow_imp.g_varchar2_table(24) := ' varchar2(32767); '||wwv_flow.LF||
'   l_error_text   varchar2(4000); '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'for i in 1..20 loop '||wwv_flow.LF||
'    begin x := ape';
wwv_flow_imp.g_varchar2_table(25) := 'x_application.g_f01(i); exception when others then apex_application.g_f01(i) := ''''; end; '||wwv_flow.LF||
'    begin ';
wwv_flow_imp.g_varchar2_table(26) := 'x := apex_application.g_f02(i); exception when others then apex_application.g_f02(i) := ''''; end; '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(27) := '  begin x := apex_application.g_f03(i); exception when others then apex_application.g_f03(i) := ''''; ';
wwv_flow_imp.g_varchar2_table(28) := 'end; '||wwv_flow.LF||
'    begin x := apex_application.g_f04(i); exception when others then apex_application.g_f04(i)';
wwv_flow_imp.g_varchar2_table(29) := ' := ''''; end; '||wwv_flow.LF||
'    begin x := apex_application.g_f05(i); exception when others then apex_application.';
wwv_flow_imp.g_varchar2_table(30) := 'g_f05(i) := ''''; end; '||wwv_flow.LF||
'    begin x := apex_application.g_f06(i); exception when others then apex_appl';
wwv_flow_imp.g_varchar2_table(31) := 'ication.g_f06(i) := ''''; end; '||wwv_flow.LF||
'    begin x := apex_application.g_f07(i); exception when others then a';
wwv_flow_imp.g_varchar2_table(32) := 'pex_application.g_f07(i) := ''''; end; '||wwv_flow.LF||
'    begin x := apex_application.g_f08(i); exception when other';
wwv_flow_imp.g_varchar2_table(33) := 's then apex_application.g_f08(i) := ''''; end; '||wwv_flow.LF||
'    begin x := apex_application.g_f09(i); exception wh';
wwv_flow_imp.g_varchar2_table(34) := 'en others then apex_application.g_f09(i) := ''''; end; '||wwv_flow.LF||
'    begin x := apex_application.g_f10(i); exce';
wwv_flow_imp.g_varchar2_table(35) := 'ption when others then apex_application.g_f10(i) := ''''; end; '||wwv_flow.LF||
'    begin x := apex_application.g_f11(';
wwv_flow_imp.g_varchar2_table(36) := 'i); exception when others then apex_application.g_f11(i) := ''''; end; '||wwv_flow.LF||
'    begin x := apex_applicatio';
wwv_flow_imp.g_varchar2_table(37) := 'n.g_f12(i); exception when others then apex_application.g_f12(i) := ''''; end; '||wwv_flow.LF||
'    begin x := apex_ap';
wwv_flow_imp.g_varchar2_table(38) := 'plication.g_f13(i); exception when others then apex_application.g_f13(i) := ''''; end; '||wwv_flow.LF||
'    begin x :=';
wwv_flow_imp.g_varchar2_table(39) := ' apex_application.g_f14(i); exception when others then apex_application.g_f14(i) := ''''; end; '||wwv_flow.LF||
'    be';
wwv_flow_imp.g_varchar2_table(40) := 'gin x := apex_application.g_f15(i); exception when others then apex_application.g_f15(i) := ''''; end;';
wwv_flow_imp.g_varchar2_table(41) := ' '||wwv_flow.LF||
'    begin x := apex_application.g_f16(i); exception when others then apex_application.g_f16(i) := ';
wwv_flow_imp.g_varchar2_table(42) := '''''; end; '||wwv_flow.LF||
'    begin x := apex_application.g_f17(i); exception when others then apex_application.g_f1';
wwv_flow_imp.g_varchar2_table(43) := '7(i) := ''''; end; '||wwv_flow.LF||
'    begin x := apex_application.g_f18(i); exception when others then apex_applicat';
wwv_flow_imp.g_varchar2_table(44) := 'ion.g_f18(i) := ''''; end; '||wwv_flow.LF||
'    begin x := apex_application.g_f19(i); exception when others then apex_';
wwv_flow_imp.g_varchar2_table(45) := 'application.g_f19(i) := ''''; end; '||wwv_flow.LF||
'    begin x := apex_application.g_f20(i); exception when others th';
wwv_flow_imp.g_varchar2_table(46) := 'en apex_application.g_f20(i) := ''''; end; '||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    begin x := apex_application.g_f50(i); exceptio';
wwv_flow_imp.g_varchar2_table(47) := 'n when others then apex_application.g_f50(i) := ''''; end; '||wwv_flow.LF||
'end loop; '||wwv_flow.LF||
'for j in 1..20 loop '||wwv_flow.LF||
'    if len';
wwv_flow_imp.g_varchar2_table(48) := 'gth(apex_application.g_f50(j)) > 0 then '||wwv_flow.LF||
'       for c1 in ( '||wwv_flow.LF||
'           select mandatory_yn '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(49) := '      from EBA_QPOLL_QUESTIONS '||wwv_flow.LF||
'            where id = apex_application.g_f50(j) '||wwv_flow.LF||
'       ) loop '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(50) := '       if c1.mandatory_yn = ''Y'' then '||wwv_flow.LF||
'             if j = 1 then '||wwv_flow.LF||
'                if apex_applicatio';
wwv_flow_imp.g_varchar2_table(51) := 'n.g_f01(1) is null and '||wwv_flow.LF||
'                   apex_application.g_f01(2) is null and '||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(52) := ' apex_application.g_f01(3) is null and '||wwv_flow.LF||
'                   apex_application.g_f01(4) is null and '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(53) := '                 apex_application.g_f01(5) is null and '||wwv_flow.LF||
'                   apex_application.g_f01(6)';
wwv_flow_imp.g_varchar2_table(54) := ' is null and '||wwv_flow.LF||
'                   apex_application.g_f01(7) is null and '||wwv_flow.LF||
'                   apex_appl';
wwv_flow_imp.g_varchar2_table(55) := 'ication.g_f01(8) is null and '||wwv_flow.LF||
'                   apex_application.g_f01(9) is null and '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(56) := '       apex_application.g_f01(10) is null '||wwv_flow.LF||
'                 then '||wwv_flow.LF||
'                   l_error_text :=';
wwv_flow_imp.g_varchar2_table(57) := ' ''Question 1 is mandatory.  ''; '||wwv_flow.LF||
'                 end if; '||wwv_flow.LF||
'             elsif j = 2 then '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(58) := '     if apex_application.g_f02(1) is null and '||wwv_flow.LF||
'                   apex_application.g_f02(2) is null ';
wwv_flow_imp.g_varchar2_table(59) := 'and '||wwv_flow.LF||
'                   apex_application.g_f02(3) is null and '||wwv_flow.LF||
'                   apex_application.g';
wwv_flow_imp.g_varchar2_table(60) := '_f02(4) is null and '||wwv_flow.LF||
'                   apex_application.g_f02(5) is null and '||wwv_flow.LF||
'                   ap';
wwv_flow_imp.g_varchar2_table(61) := 'ex_application.g_f02(6) is null and '||wwv_flow.LF||
'                   apex_application.g_f02(7) is null and '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(62) := '              apex_application.g_f02(8) is null and '||wwv_flow.LF||
'                   apex_application.g_f02(9) is';
wwv_flow_imp.g_varchar2_table(63) := ' null and '||wwv_flow.LF||
'                   apex_application.g_f02(10) is null '||wwv_flow.LF||
'                 then '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(64) := '        l_error_text := l_error_text || ''Question 2 is mandatory.  ''; '||wwv_flow.LF||
'                 end if; '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(65) := '          elsif j = 3 then '||wwv_flow.LF||
'                if apex_application.g_f03(1) is null and '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(66) := '     apex_application.g_f03(2) is null and '||wwv_flow.LF||
'                   apex_application.g_f03(3) is null and';
wwv_flow_imp.g_varchar2_table(67) := ' '||wwv_flow.LF||
'                   apex_application.g_f03(4) is null and '||wwv_flow.LF||
'                   apex_application.g_f0';
wwv_flow_imp.g_varchar2_table(68) := '3(5) is null and '||wwv_flow.LF||
'                   apex_application.g_f03(6) is null and '||wwv_flow.LF||
'                   apex_';
wwv_flow_imp.g_varchar2_table(69) := 'application.g_f03(7) is null and '||wwv_flow.LF||
'                   apex_application.g_f03(8) is null and '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(70) := '           apex_application.g_f03(9) is null and '||wwv_flow.LF||
'                   apex_application.g_f03(10) is n';
wwv_flow_imp.g_varchar2_table(71) := 'ull '||wwv_flow.LF||
'                 then '||wwv_flow.LF||
'                   l_error_text := l_error_text || ''Question 3 is mandat';
wwv_flow_imp.g_varchar2_table(72) := 'ory.  ''; '||wwv_flow.LF||
'                 end if; '||wwv_flow.LF||
'             elsif j = 4 then '||wwv_flow.LF||
'                if apex_applicati';
wwv_flow_imp.g_varchar2_table(73) := 'on.g_f04(1) is null and '||wwv_flow.LF||
'                   apex_application.g_f04(2) is null and '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(74) := '  apex_application.g_f04(3) is null and '||wwv_flow.LF||
'                   apex_application.g_f04(4) is null and '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(75) := '                  apex_application.g_f04(5) is null and '||wwv_flow.LF||
'                   apex_application.g_f04(6';
wwv_flow_imp.g_varchar2_table(76) := ') is null and '||wwv_flow.LF||
'                   apex_application.g_f04(7) is null and '||wwv_flow.LF||
'                   apex_app';
wwv_flow_imp.g_varchar2_table(77) := 'lication.g_f04(8) is null and '||wwv_flow.LF||
'                   apex_application.g_f04(9) is null and '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(78) := '        apex_application.g_f04(10) is null '||wwv_flow.LF||
'                 then '||wwv_flow.LF||
'                   l_error_text :';
wwv_flow_imp.g_varchar2_table(79) := '= l_error_text || ''Question 4 is mandatory.  ''; '||wwv_flow.LF||
'                 end if; '||wwv_flow.LF||
'             elsif j = 5 ';
wwv_flow_imp.g_varchar2_table(80) := 'then '||wwv_flow.LF||
'                if apex_application.g_f05(1) is null and '||wwv_flow.LF||
'                   apex_application.';
wwv_flow_imp.g_varchar2_table(81) := 'g_f05(2) is null and '||wwv_flow.LF||
'                   apex_application.g_f05(3) is null and '||wwv_flow.LF||
'                   a';
wwv_flow_imp.g_varchar2_table(82) := 'pex_application.g_f05(4) is null and '||wwv_flow.LF||
'                   apex_application.g_f05(5) is null and '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(83) := '               apex_application.g_f05(6) is null and '||wwv_flow.LF||
'                   apex_application.g_f05(7) i';
wwv_flow_imp.g_varchar2_table(84) := 's null and '||wwv_flow.LF||
'                   apex_application.g_f05(8) is null and '||wwv_flow.LF||
'                   apex_applic';
wwv_flow_imp.g_varchar2_table(85) := 'ation.g_f05(9) is null and '||wwv_flow.LF||
'                   apex_application.g_f05(10) is null '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(86) := 'then '||wwv_flow.LF||
'                   l_error_text := l_error_text || ''Question 5 is mandatory.  ''; '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(87) := '     end if; '||wwv_flow.LF||
'             elsif j = 6 then '||wwv_flow.LF||
'                if apex_application.g_f06(1) is null an';
wwv_flow_imp.g_varchar2_table(88) := 'd '||wwv_flow.LF||
'                   apex_application.g_f06(2) is null and '||wwv_flow.LF||
'                   apex_application.g_f';
wwv_flow_imp.g_varchar2_table(89) := '06(3) is null and '||wwv_flow.LF||
'                   apex_application.g_f06(4) is null and '||wwv_flow.LF||
'                   apex';
wwv_flow_imp.g_varchar2_table(90) := '_application.g_f06(5) is null and '||wwv_flow.LF||
'                   apex_application.g_f06(6) is null and '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(91) := '            apex_application.g_f06(7) is null and '||wwv_flow.LF||
'                   apex_application.g_f06(8) is n';
wwv_flow_imp.g_varchar2_table(92) := 'ull and '||wwv_flow.LF||
'                   apex_application.g_f06(9) is null and '||wwv_flow.LF||
'                   apex_applicati';
wwv_flow_imp.g_varchar2_table(93) := 'on.g_f06(10) is null '||wwv_flow.LF||
'                 then '||wwv_flow.LF||
'                   l_error_text := l_error_text || ''Que';
wwv_flow_imp.g_varchar2_table(94) := 'stion 6 is mandatory.  ''; '||wwv_flow.LF||
'                 end if; '||wwv_flow.LF||
'             elsif j = 7 then '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(95) := 'if apex_application.g_f07(1) is null and '||wwv_flow.LF||
'                   apex_application.g_f07(2) is null and '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(96) := '                   apex_application.g_f07(3) is null and '||wwv_flow.LF||
'                   apex_application.g_f07(';
wwv_flow_imp.g_varchar2_table(97) := '4) is null and '||wwv_flow.LF||
'                   apex_application.g_f07(5) is null and '||wwv_flow.LF||
'                   apex_ap';
wwv_flow_imp.g_varchar2_table(98) := 'plication.g_f07(6) is null and '||wwv_flow.LF||
'                   apex_application.g_f07(7) is null and '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(99) := '         apex_application.g_f07(8) is null and '||wwv_flow.LF||
'                   apex_application.g_f07(9) is null';
wwv_flow_imp.g_varchar2_table(100) := ' and '||wwv_flow.LF||
'                   apex_application.g_f07(10) is null '||wwv_flow.LF||
'                 then '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(101) := '   l_error_text := l_error_text || ''Question 7 is mandatory.  ''; '||wwv_flow.LF||
'                 end if; '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(102) := '     elsif j = 8 then '||wwv_flow.LF||
'                if apex_application.g_f08(1) is null and '||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(103) := 'apex_application.g_f08(2) is null and '||wwv_flow.LF||
'                   apex_application.g_f08(3) is null and '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(104) := '                apex_application.g_f08(4) is null and '||wwv_flow.LF||
'                   apex_application.g_f08(5) ';
wwv_flow_imp.g_varchar2_table(105) := 'is null and '||wwv_flow.LF||
'                   apex_application.g_f08(6) is null and '||wwv_flow.LF||
'                   apex_appli';
wwv_flow_imp.g_varchar2_table(106) := 'cation.g_f08(7) is null and '||wwv_flow.LF||
'                   apex_application.g_f08(8) is null and '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(107) := '      apex_application.g_f08(9) is null and '||wwv_flow.LF||
'                   apex_application.g_f08(10) is null '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(108) := '                 then '||wwv_flow.LF||
'                   l_error_text := l_error_text || ''Question 8 is mandatory. ';
wwv_flow_imp.g_varchar2_table(109) := ' ''; '||wwv_flow.LF||
'                 end if; '||wwv_flow.LF||
'             elsif j = 9 then '||wwv_flow.LF||
'                if apex_application.g_';
wwv_flow_imp.g_varchar2_table(110) := 'f09(1) is null and '||wwv_flow.LF||
'                   apex_application.g_f09(2) is null and '||wwv_flow.LF||
'                   ape';
wwv_flow_imp.g_varchar2_table(111) := 'x_application.g_f09(3) is null and '||wwv_flow.LF||
'                   apex_application.g_f09(4) is null and '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(112) := '             apex_application.g_f09(5) is null and '||wwv_flow.LF||
'                   apex_application.g_f09(6) is ';
wwv_flow_imp.g_varchar2_table(113) := 'null and '||wwv_flow.LF||
'                   apex_application.g_f09(7) is null and '||wwv_flow.LF||
'                   apex_applicat';
wwv_flow_imp.g_varchar2_table(114) := 'ion.g_f09(8) is null and '||wwv_flow.LF||
'                   apex_application.g_f09(9) is null and '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(115) := '   apex_application.g_f09(10) is null '||wwv_flow.LF||
'                 then '||wwv_flow.LF||
'                   l_error_text := l_e';
wwv_flow_imp.g_varchar2_table(116) := 'rror_text || ''Question 9 is mandatory.  ''; '||wwv_flow.LF||
'                 end if; '||wwv_flow.LF||
'             elsif j = 10 then';
wwv_flow_imp.g_varchar2_table(117) := ' '||wwv_flow.LF||
'                if apex_application.g_f10(1) is null and '||wwv_flow.LF||
'                   apex_application.g_f1';
wwv_flow_imp.g_varchar2_table(118) := '0(2) is null and '||wwv_flow.LF||
'                   apex_application.g_f10(3) is null and '||wwv_flow.LF||
'                   apex_';
wwv_flow_imp.g_varchar2_table(119) := 'application.g_f10(4) is null and '||wwv_flow.LF||
'                   apex_application.g_f10(5) is null and '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(120) := '           apex_application.g_f10(6) is null and '||wwv_flow.LF||
'                   apex_application.g_f10(7) is nu';
wwv_flow_imp.g_varchar2_table(121) := 'll and '||wwv_flow.LF||
'                   apex_application.g_f10(8) is null and '||wwv_flow.LF||
'                   apex_applicatio';
wwv_flow_imp.g_varchar2_table(122) := 'n.g_f10(9) is null and '||wwv_flow.LF||
'                   apex_application.g_f10(10) is null '||wwv_flow.LF||
'                 then';
wwv_flow_imp.g_varchar2_table(123) := ' '||wwv_flow.LF||
'                   l_error_text := l_error_text || ''Question 10 is mandatory.  ''; '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(124) := '  end if; '||wwv_flow.LF||
'             elsif j = 11 then '||wwv_flow.LF||
'                if apex_application.g_f11(1) is null and ';
wwv_flow_imp.g_varchar2_table(125) := ''||wwv_flow.LF||
'                   apex_application.g_f11(2) is null and '||wwv_flow.LF||
'                   apex_application.g_f11';
wwv_flow_imp.g_varchar2_table(126) := '(3) is null and '||wwv_flow.LF||
'                   apex_application.g_f11(4) is null and '||wwv_flow.LF||
'                   apex_a';
wwv_flow_imp.g_varchar2_table(127) := 'pplication.g_f11(5) is null and '||wwv_flow.LF||
'                   apex_application.g_f11(6) is null and '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(128) := '          apex_application.g_f11(7) is null and '||wwv_flow.LF||
'                   apex_application.g_f11(8) is nul';
wwv_flow_imp.g_varchar2_table(129) := 'l and '||wwv_flow.LF||
'                   apex_application.g_f11(9) is null and '||wwv_flow.LF||
'                   apex_application';
wwv_flow_imp.g_varchar2_table(130) := '.g_f11(10) is null '||wwv_flow.LF||
'                 then '||wwv_flow.LF||
'                   l_error_text := l_error_text || ''Quest';
wwv_flow_imp.g_varchar2_table(131) := 'ion 11 is mandatory.  ''; '||wwv_flow.LF||
'                 end if; '||wwv_flow.LF||
'             elsif j = 12 then '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(132) := 'if apex_application.g_f12(1) is null and '||wwv_flow.LF||
'                   apex_application.g_f12(2) is null and '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(133) := '                   apex_application.g_f12(3) is null and '||wwv_flow.LF||
'                   apex_application.g_f12(';
wwv_flow_imp.g_varchar2_table(134) := '4) is null and '||wwv_flow.LF||
'                   apex_application.g_f12(5) is null and '||wwv_flow.LF||
'                   apex_ap';
wwv_flow_imp.g_varchar2_table(135) := 'plication.g_f12(6) is null and '||wwv_flow.LF||
'                   apex_application.g_f12(7) is null and '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(136) := '         apex_application.g_f12(8) is null and '||wwv_flow.LF||
'                   apex_application.g_f12(9) is null';
wwv_flow_imp.g_varchar2_table(137) := ' and '||wwv_flow.LF||
'                   apex_application.g_f12(10) is null '||wwv_flow.LF||
'                 then '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(138) := '   l_error_text := l_error_text || ''Question 12 is mandatory.  ''; '||wwv_flow.LF||
'                 end if; '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(139) := '      elsif j = 13 then '||wwv_flow.LF||
'                if apex_application.g_f13(1) is null and '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(140) := '  apex_application.g_f13(2) is null and '||wwv_flow.LF||
'                   apex_application.g_f13(3) is null and '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(141) := '                  apex_application.g_f13(4) is null and '||wwv_flow.LF||
'                   apex_application.g_f13(5';
wwv_flow_imp.g_varchar2_table(142) := ') is null and '||wwv_flow.LF||
'                   apex_application.g_f13(6) is null and '||wwv_flow.LF||
'                   apex_app';
wwv_flow_imp.g_varchar2_table(143) := 'lication.g_f13(7) is null and '||wwv_flow.LF||
'                   apex_application.g_f13(8) is null and '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(144) := '        apex_application.g_f13(9) is null and '||wwv_flow.LF||
'                   apex_application.g_f13(10) is null';
wwv_flow_imp.g_varchar2_table(145) := ' '||wwv_flow.LF||
'                 then '||wwv_flow.LF||
'                   l_error_text := l_error_text || ''Question 13 is mandator';
wwv_flow_imp.g_varchar2_table(146) := 'y.  ''; '||wwv_flow.LF||
'                 end if; '||wwv_flow.LF||
'             elsif j = 14 then '||wwv_flow.LF||
'                if apex_applicatio';
wwv_flow_imp.g_varchar2_table(147) := 'n.g_f14(1) is null and '||wwv_flow.LF||
'                   apex_application.g_f14(2) is null and '||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(148) := ' apex_application.g_f14(3) is null and '||wwv_flow.LF||
'                   apex_application.g_f14(4) is null and '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(149) := '                 apex_application.g_f14(5) is null and '||wwv_flow.LF||
'                   apex_application.g_f14(6)';
wwv_flow_imp.g_varchar2_table(150) := ' is null and '||wwv_flow.LF||
'                   apex_application.g_f14(7) is null and '||wwv_flow.LF||
'                   apex_appl';
wwv_flow_imp.g_varchar2_table(151) := 'ication.g_f14(8) is null and '||wwv_flow.LF||
'                   apex_application.g_f14(9) is null and '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(152) := '       apex_application.g_f14(10) is null '||wwv_flow.LF||
'                 then '||wwv_flow.LF||
'                   l_error_text :=';
wwv_flow_imp.g_varchar2_table(153) := ' l_error_text || ''Question 14 is mandatory.  ''; '||wwv_flow.LF||
'                 end if; '||wwv_flow.LF||
'             elsif j = 15';
wwv_flow_imp.g_varchar2_table(154) := ' then '||wwv_flow.LF||
'                if apex_application.g_f15(1) is null and '||wwv_flow.LF||
'                   apex_application';
wwv_flow_imp.g_varchar2_table(155) := '.g_f15(2) is null and '||wwv_flow.LF||
'                   apex_application.g_f15(3) is null and '||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(156) := 'apex_application.g_f15(4) is null and '||wwv_flow.LF||
'                   apex_application.g_f15(5) is null and '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(157) := '                apex_application.g_f15(6) is null and '||wwv_flow.LF||
'                   apex_application.g_f15(7) ';
wwv_flow_imp.g_varchar2_table(158) := 'is null and '||wwv_flow.LF||
'                   apex_application.g_f15(8) is null and '||wwv_flow.LF||
'                   apex_appli';
wwv_flow_imp.g_varchar2_table(159) := 'cation.g_f15(9) is null and '||wwv_flow.LF||
'                   apex_application.g_f15(10) is null '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(160) := ' then '||wwv_flow.LF||
'                   l_error_text := l_error_text || ''Question 15 is mandatory.  ''; '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(161) := '       end if; '||wwv_flow.LF||
'             elsif j = 16 then '||wwv_flow.LF||
'                if apex_application.g_f16(1) is null';
wwv_flow_imp.g_varchar2_table(162) := ' and '||wwv_flow.LF||
'                   apex_application.g_f16(2) is null and '||wwv_flow.LF||
'                   apex_application.';
wwv_flow_imp.g_varchar2_table(163) := 'g_f16(3) is null and '||wwv_flow.LF||
'                   apex_application.g_f16(4) is null and '||wwv_flow.LF||
'                   a';
wwv_flow_imp.g_varchar2_table(164) := 'pex_application.g_f16(5) is null and '||wwv_flow.LF||
'                   apex_application.g_f16(6) is null and '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(165) := '               apex_application.g_f16(7) is null and '||wwv_flow.LF||
'                   apex_application.g_f16(8) i';
wwv_flow_imp.g_varchar2_table(166) := 's null and '||wwv_flow.LF||
'                   apex_application.g_f16(9) is null and '||wwv_flow.LF||
'                   apex_applic';
wwv_flow_imp.g_varchar2_table(167) := 'ation.g_f16(10) is null '||wwv_flow.LF||
'                 then '||wwv_flow.LF||
'                   l_error_text := l_error_text || ''';
wwv_flow_imp.g_varchar2_table(168) := 'Question 16 is mandatory.  ''; '||wwv_flow.LF||
'                 end if; '||wwv_flow.LF||
'             elsif j = 17 then '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(169) := '     if apex_application.g_f17(1) is null and '||wwv_flow.LF||
'                   apex_application.g_f17(2) is null ';
wwv_flow_imp.g_varchar2_table(170) := 'and '||wwv_flow.LF||
'                   apex_application.g_f17(3) is null and '||wwv_flow.LF||
'                   apex_application.g';
wwv_flow_imp.g_varchar2_table(171) := '_f17(4) is null and '||wwv_flow.LF||
'                   apex_application.g_f17(5) is null and '||wwv_flow.LF||
'                   ap';
wwv_flow_imp.g_varchar2_table(172) := 'ex_application.g_f17(6) is null and '||wwv_flow.LF||
'                   apex_application.g_f17(7) is null and '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(173) := '              apex_application.g_f17(8) is null and '||wwv_flow.LF||
'                   apex_application.g_f17(9) is';
wwv_flow_imp.g_varchar2_table(174) := ' null and '||wwv_flow.LF||
'                   apex_application.g_f17(10) is null '||wwv_flow.LF||
'                 then '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(175) := '        l_error_text := l_error_text || ''Question 17 is mandatory.  ''; '||wwv_flow.LF||
'                 end if; '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(176) := '           elsif j = 18 then '||wwv_flow.LF||
'                if apex_application.g_f18(1) is null and '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(177) := '       apex_application.g_f18(2) is null and '||wwv_flow.LF||
'                   apex_application.g_f18(3) is null a';
wwv_flow_imp.g_varchar2_table(178) := 'nd '||wwv_flow.LF||
'                   apex_application.g_f18(4) is null and '||wwv_flow.LF||
'                   apex_application.g_';
wwv_flow_imp.g_varchar2_table(179) := 'f18(5) is null and '||wwv_flow.LF||
'                   apex_application.g_f18(6) is null and '||wwv_flow.LF||
'                   ape';
wwv_flow_imp.g_varchar2_table(180) := 'x_application.g_f18(7) is null and '||wwv_flow.LF||
'                   apex_application.g_f18(8) is null and '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(181) := '             apex_application.g_f18(9) is null and '||wwv_flow.LF||
'                   apex_application.g_f18(10) is';
wwv_flow_imp.g_varchar2_table(182) := ' null '||wwv_flow.LF||
'                 then '||wwv_flow.LF||
'                   l_error_text := l_error_text || ''Question 18 is man';
wwv_flow_imp.g_varchar2_table(183) := 'datory.  ''; '||wwv_flow.LF||
'                 end if; '||wwv_flow.LF||
'             elsif j = 19 then '||wwv_flow.LF||
'                if apex_appli';
wwv_flow_imp.g_varchar2_table(184) := 'cation.g_f19(1) is null and '||wwv_flow.LF||
'                   apex_application.g_f19(2) is null and '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(185) := '      apex_application.g_f19(3) is null and '||wwv_flow.LF||
'                   apex_application.g_f19(4) is null an';
wwv_flow_imp.g_varchar2_table(186) := 'd '||wwv_flow.LF||
'                   apex_application.g_f19(5) is null and '||wwv_flow.LF||
'                   apex_application.g_f';
wwv_flow_imp.g_varchar2_table(187) := '19(6) is null and '||wwv_flow.LF||
'                   apex_application.g_f19(7) is null and '||wwv_flow.LF||
'                   apex';
wwv_flow_imp.g_varchar2_table(188) := '_application.g_f19(8) is null and '||wwv_flow.LF||
'                   apex_application.g_f19(9) is null and '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(189) := '            apex_application.g_f19(10) is null '||wwv_flow.LF||
'                 then '||wwv_flow.LF||
'                   l_error_te';
wwv_flow_imp.g_varchar2_table(190) := 'xt := l_error_text || ''Question 19 is mandatory.  ''; '||wwv_flow.LF||
'                 end if; '||wwv_flow.LF||
'             elsif j';
wwv_flow_imp.g_varchar2_table(191) := ' = 20 then '||wwv_flow.LF||
'                if apex_application.g_f20(1) is null and '||wwv_flow.LF||
'                   apex_applic';
wwv_flow_imp.g_varchar2_table(192) := 'ation.g_f20(2) is null and '||wwv_flow.LF||
'                   apex_application.g_f20(3) is null and '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(193) := '     apex_application.g_f20(4) is null and '||wwv_flow.LF||
'                   apex_application.g_f20(5) is null and';
wwv_flow_imp.g_varchar2_table(194) := ' '||wwv_flow.LF||
'                   apex_application.g_f20(6) is null and '||wwv_flow.LF||
'                   apex_application.g_f2';
wwv_flow_imp.g_varchar2_table(195) := '0(7) is null and '||wwv_flow.LF||
'                   apex_application.g_f20(8) is null and '||wwv_flow.LF||
'                   apex_';
wwv_flow_imp.g_varchar2_table(196) := 'application.g_f20(9) is null and '||wwv_flow.LF||
'                   apex_application.g_f20(10) is null '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(197) := '      then '||wwv_flow.LF||
'                   l_error_text := l_error_text || ''Question 20 is mandatory.  ''; '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(198) := '            end if; '||wwv_flow.LF||
'             end if; '||wwv_flow.LF||
'          end if; '||wwv_flow.LF||
'       end loop; -- c1 '||wwv_flow.LF||
'    end if; '||wwv_flow.LF||
'e';
wwv_flow_imp.g_varchar2_table(199) := 'nd loop; --j '||wwv_flow.LF||
'if l_error_text is not null then '||wwv_flow.LF||
'   l_error_text := ''Error: '' || l_error_text; '||wwv_flow.LF||
'end i';
wwv_flow_imp.g_varchar2_table(200) := 'f; '||wwv_flow.LF||
'return l_error_text; '||wwv_flow.LF||
'end validate_submission; '||wwv_flow.LF||
' '||wwv_flow.LF||
'procedure remove_preactive_results ( '||wwv_flow.LF||
'    p_po';
wwv_flow_imp.g_varchar2_table(201) := 'll_id   in  number ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    delete from eba_qpoll_results '||wwv_flow.LF||
'     where poll_id = p_poll_id '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(202) := '       and preactive_yn = ''Y''; '||wwv_flow.LF||
'    commit; '||wwv_flow.LF||
'end remove_preactive_results; '||wwv_flow.LF||
' '||wwv_flow.LF||
'function poll_take_sta';
wwv_flow_imp.g_varchar2_table(203) := 'tus ( '||wwv_flow.LF||
'   p_app_id       in  number, '||wwv_flow.LF||
'   p_poll_id      in  number, '||wwv_flow.LF||
'   p_app_user     in  varchar2,';
wwv_flow_imp.g_varchar2_table(204) := ' '||wwv_flow.LF||
'   p_app_session  in  number ) '||wwv_flow.LF||
'   return varchar2 '||wwv_flow.LF||
'is '||wwv_flow.LF||
'   l_take_status  varchar2(30) := ''OTHER'';';
wwv_flow_imp.g_varchar2_table(205) := ' -- CAN_TAKE_IT, HAS_ERRORS, CAN_UPDATE, OTHER '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'   for c1 in ( '||wwv_flow.LF||
'      select ''CAN_TAKE_IT'' ta';
wwv_flow_imp.g_varchar2_table(206) := 'ke_status '||wwv_flow.LF||
'        from eba_qpoll_polls p '||wwv_flow.LF||
'       where p.id = p_poll_id '||wwv_flow.LF||
'         and (p.status_id ';
wwv_flow_imp.g_varchar2_table(207) := '= 3 or '||wwv_flow.LF||
'              (p.status_id = 2 and  '||wwv_flow.LF||
'               get_access_role ( '||wwv_flow.LF||
'                  p_a';
wwv_flow_imp.g_varchar2_table(208) := 'pp_id   => p_app_id, '||wwv_flow.LF||
'                  p_username => p_app_user) in (''CONTRIBUTOR'',''ADMINISTRATOR'')';
wwv_flow_imp.g_varchar2_table(209) := '))  '||wwv_flow.LF||
'         and not exists (select 1 '||wwv_flow.LF||
'                           from eba_qpoll_results '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(210) := '                 where poll_id = p.id '||wwv_flow.LF||
'                            and ((p.anonymous_yn = ''Y'' and  '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(211) := '                                  APEX_SESSION_ID = p_app_session and '||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(212) := '     is_valid_yn = ''N'') or '||wwv_flow.LF||
'                                 apex_user = p_app_user) ) '||wwv_flow.LF||
'         and';
wwv_flow_imp.g_varchar2_table(213) := ' ( invite_only_yn = ''N'' or  '||wwv_flow.LF||
'              (p.status_id = 2 and  '||wwv_flow.LF||
'               get_access_role ( '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(214) := '                  p_app_id   => p_app_id, '||wwv_flow.LF||
'                  p_username => p_app_user) in (''CONTRIBU';
wwv_flow_imp.g_varchar2_table(215) := 'TOR'',''ADMINISTRATOR'')) or '||wwv_flow.LF||
'               exists (select 1  '||wwv_flow.LF||
'                         from eba_qpoll';
wwv_flow_imp.g_varchar2_table(216) := '_comm_invites c, eba_qpoll_invites i '||wwv_flow.LF||
'                        where c.poll_id = p_poll_id and c.id =';
wwv_flow_imp.g_varchar2_table(217) := ' i.comm_invite_id '||wwv_flow.LF||
'                          and upper(respondent_email) = p_app_user)) '||wwv_flow.LF||
'   ) loop '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(218) := '      l_take_status := c1.take_status; '||wwv_flow.LF||
'   end loop; '||wwv_flow.LF||
'   if l_take_status = ''OTHER'' then '||wwv_flow.LF||
'      for ';
wwv_flow_imp.g_varchar2_table(219) := 'c2 in ( '||wwv_flow.LF||
'         select ''CAN_UPDATE'' take_status '||wwv_flow.LF||
'           from eba_qpoll_polls p, '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(220) := '   eba_qpoll_results r '||wwv_flow.LF||
'         where p.id = p_poll_id '||wwv_flow.LF||
'           and p.id = r.poll_id '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(221) := ' and (p.status_id = 3 or '||wwv_flow.LF||
'                (p.status_id = 2 and  '||wwv_flow.LF||
'                 get_access_role ( ';
wwv_flow_imp.g_varchar2_table(222) := ''||wwv_flow.LF||
'                    p_app_id   => p_app_id, '||wwv_flow.LF||
'                    p_username => p_app_user) in (''CON';
wwv_flow_imp.g_varchar2_table(223) := 'TRIBUTOR'',''ADMINISTRATOR'')))   '||wwv_flow.LF||
'           and r.apex_user = p_app_user '||wwv_flow.LF||
'           and p.can_update';
wwv_flow_imp.g_varchar2_table(224) := '_answers_yn = ''Y'' '||wwv_flow.LF||
'           and nvl(r.is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'      ) loop '||wwv_flow.LF||
'         l_take_status';
wwv_flow_imp.g_varchar2_table(225) := ' := c2.take_status; '||wwv_flow.LF||
'      end loop; '||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'   if l_take_status = ''OTHER'' then '||wwv_flow.LF||
'      for c3 i';
wwv_flow_imp.g_varchar2_table(226) := 'n ( '||wwv_flow.LF||
'         select ''HAS_ERRORS'' take_status '||wwv_flow.LF||
'           from eba_qpoll_polls p, '||wwv_flow.LF||
'                e';
wwv_flow_imp.g_varchar2_table(227) := 'ba_qpoll_results r '||wwv_flow.LF||
'         where p.id = p_poll_id '||wwv_flow.LF||
'           and p.id = r.poll_id '||wwv_flow.LF||
'           and';
wwv_flow_imp.g_varchar2_table(228) := ' (p.status_id = 3 or '||wwv_flow.LF||
'                (p.status_id = 2 and  '||wwv_flow.LF||
'                 get_access_role ( '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(229) := '                 p_app_id   => p_app_id, '||wwv_flow.LF||
'                    p_username => p_app_user) in (''CONTRIB';
wwv_flow_imp.g_varchar2_table(230) := 'UTOR'',''ADMINISTRATOR'')))  '||wwv_flow.LF||
'           and ((p.anonymous_yn = ''Y'' and  '||wwv_flow.LF||
'                 r.APEX_SESSI';
wwv_flow_imp.g_varchar2_table(231) := 'ON_ID = p_app_session and '||wwv_flow.LF||
'                 is_valid_yn = ''N'') or '||wwv_flow.LF||
'                r.apex_user = p_a';
wwv_flow_imp.g_varchar2_table(232) := 'pp_user)  '||wwv_flow.LF||
'           and nvl(r.is_valid_yn,''Y'') = ''N'' '||wwv_flow.LF||
'      ) loop '||wwv_flow.LF||
'         l_take_status := c3.t';
wwv_flow_imp.g_varchar2_table(233) := 'ake_status; '||wwv_flow.LF||
'      end loop; '||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'   return l_take_status; '||wwv_flow.LF||
'     '||wwv_flow.LF||
'end poll_take_status; '||wwv_flow.LF||
' '||wwv_flow.LF||
'p';
wwv_flow_imp.g_varchar2_table(234) := 'rocedure write_clob (  '||wwv_flow.LF||
'       p_clob    in out clob, '||wwv_flow.LF||
'       p_content in     varchar2 '||wwv_flow.LF||
'     )  '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(235) := '  is '||wwv_flow.LF||
'    begin '||wwv_flow.LF||
'       if p_content is not null then '||wwv_flow.LF||
'          sys.dbms_lob.writeappend( p_clob, l';
wwv_flow_imp.g_varchar2_table(236) := 'ength( p_content ), p_content ); '||wwv_flow.LF||
'       end if; '||wwv_flow.LF||
'    end write_clob; '||wwv_flow.LF||
'    procedure write_clob (  '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(237) := '       p_clob    in out clob, '||wwv_flow.LF||
'       p_content in     clob  '||wwv_flow.LF||
'    )  '||wwv_flow.LF||
'    is '||wwv_flow.LF||
'       l_length  integ';
wwv_flow_imp.g_varchar2_table(238) := 'er := sys.dbms_lob.getlength(p_content); '||wwv_flow.LF||
'    begin '||wwv_flow.LF||
'--       sys.dbms_lob.append( p_clob, p_content';
wwv_flow_imp.g_varchar2_table(239) := ' ); '||wwv_flow.LF||
'       if p_content is not null then '||wwv_flow.LF||
'          for i in 1 .. ceil(l_length/4000) loop '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(240) := '      write_clob( p_clob, sys.dbms_lob.substr(p_content, least(4000,l_length-((i-1)*4000)), 1+((i-1)';
wwv_flow_imp.g_varchar2_table(241) := '*4000)) ); '||wwv_flow.LF||
'          end loop; '||wwv_flow.LF||
'       end if; '||wwv_flow.LF||
'    end write_clob; '||wwv_flow.LF||
' '||wwv_flow.LF||
'-- used for emailing results';
wwv_flow_imp.g_varchar2_table(242) := ' '||wwv_flow.LF||
'function prepare_poll_results ( '||wwv_flow.LF||
'   p_poll_id  number '||wwv_flow.LF||
') '||wwv_flow.LF||
'return clob '||wwv_flow.LF||
'is '||wwv_flow.LF||
'   l_found             ';
wwv_flow_imp.g_varchar2_table(243) := ' boolean := false; '||wwv_flow.LF||
'   c                    integer := 0; '||wwv_flow.LF||
'   a                    integer := 0; '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(244) := ' l_max                number; '||wwv_flow.LF||
'   l_Pct2               number; '||wwv_flow.LF||
'   l_label              wwv_flow_glo';
wwv_flow_imp.g_varchar2_table(245) := 'bal.vc_arr2; '||wwv_flow.LF||
'   l_answer             wwv_flow_global.vc_arr2; '||wwv_flow.LF||
'   l_count              wwv_flow_glo';
wwv_flow_imp.g_varchar2_table(246) := 'bal.n_arr; '||wwv_flow.LF||
'   l_respondents        integer := 0; '||wwv_flow.LF||
'   l_correct_answer_yn  varchar2(1) := ''N''; '||wwv_flow.LF||
'   l';
wwv_flow_imp.g_varchar2_table(247) := '_section_id         number; '||wwv_flow.LF||
'   l_html_body          clob; '||wwv_flow.LF||
'   '||wwv_flow.LF||
'   procedure paint_answer ( '||wwv_flow.LF||
'      p';
wwv_flow_imp.g_varchar2_table(248) := '_count           in number    default null,  '||wwv_flow.LF||
'      p_pct             in number    default null,  '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(249) := '     p_label           in varchar2  default null, '||wwv_flow.LF||
'      p_correct_answer  in varchar2  default null';
wwv_flow_imp.g_varchar2_table(250) := ')  '||wwv_flow.LF||
'   is '||wwv_flow.LF||
'   begin '||wwv_flow.LF||
'      if p_label is not null then '||wwv_flow.LF||
'        l_pct2 := round(100 * (p_count/l_res';
wwv_flow_imp.g_varchar2_table(251) := 'pondents)); '||wwv_flow.LF||
'        write_clob(l_html_body, ''<tr>''); '||wwv_flow.LF||
'        write_clob(l_html_body, ''  <td class=';
wwv_flow_imp.g_varchar2_table(252) := '"ch-heading" style="font-weight: bold;font-size: 14px;line-height: 16px;text-align: left;">''); '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(253) := '    if p_correct_answer = ''Y'' then '||wwv_flow.LF||
'           write_clob(l_html_body, ''* ''); '||wwv_flow.LF||
'        end if; '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(254) := '    write_clob(l_html_body, apex_escape.html(p_label)||''</td>''); '||wwv_flow.LF||
'        write_clob(l_html_body, '' ';
wwv_flow_imp.g_varchar2_table(255) := ' <td class="ch-chart" style="width: 50%;">''); '||wwv_flow.LF||
'        write_clob(l_html_body, ''    <table class="ch';
wwv_flow_imp.g_varchar2_table(256) := '-pct" width="''||apex_escape.html(l_pct2)||''%" style="background-color: #B8B8B8;height: 16px;">''); '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(257) := '       write_clob(l_html_body, ''      <tr>''); '||wwv_flow.LF||
'        write_clob(l_html_body, ''        <td></td>'');';
wwv_flow_imp.g_varchar2_table(258) := ' '||wwv_flow.LF||
'        write_clob(l_html_body, ''      </tr>''); '||wwv_flow.LF||
'        write_clob(l_html_body, ''    </table>''); ';
wwv_flow_imp.g_varchar2_table(259) := ''||wwv_flow.LF||
'        write_clob(l_html_body, ''  </td>''); '||wwv_flow.LF||
'        write_clob(l_html_body, ''  <td class="ch-value';
wwv_flow_imp.g_varchar2_table(260) := '" style="font-size: 14px;line-height: 16px;color: #707070;" nowrap="nowrap">''||p_count||'' (''||l_pct2';
wwv_flow_imp.g_varchar2_table(261) := '||''%)</td>''); '||wwv_flow.LF||
'        write_clob(l_html_body, ''</tr>''); '||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'   end; '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'   sys.dbms';
wwv_flow_imp.g_varchar2_table(262) := '_lob.createtemporary( l_html_body, false ); '||wwv_flow.LF||
'   for c0 in ( '||wwv_flow.LF||
'      select p.poll_name, p.poll_detail';
wwv_flow_imp.g_varchar2_table(263) := 's, p.enable_score_yn, '||wwv_flow.LF||
'             p.poll_or_quiz, p.score_type, p.use_sections_yn, '||wwv_flow.LF||
'             n';
wwv_flow_imp.g_varchar2_table(264) := 'vl((select max(display_sequence)+10 from eba_qpoll_questions q '||wwv_flow.LF||
'                   where q.poll_id =';
wwv_flow_imp.g_varchar2_table(265) := ' p.id '||wwv_flow.LF||
'                     and p.use_sections_yn = ''Y''),10) max_question_seq '||wwv_flow.LF||
'        from eba_qpol';
wwv_flow_imp.g_varchar2_table(266) := 'l_polls p '||wwv_flow.LF||
'       where p.id = p_poll_id '||wwv_flow.LF||
'   ) loop '||wwv_flow.LF||
'      write_clob(l_html_body, ''<table cellpaddi';
wwv_flow_imp.g_varchar2_table(267) := 'ng="4">''); '||wwv_flow.LF||
'      if c0.poll_details is not null  then '||wwv_flow.LF||
'         write_clob(l_html_body, ''<tr><td><s';
wwv_flow_imp.g_varchar2_table(268) := 'trong>Details</strong></td><td>'' || apex_escape.html(c0.poll_details) ||''</td></tr>''); '||wwv_flow.LF||
'      end if';
wwv_flow_imp.g_varchar2_table(269) := '; '||wwv_flow.LF||
'      -- RESPONSE RATE '||wwv_flow.LF||
'      for c1 in ( '||wwv_flow.LF||
'         select 1 '||wwv_flow.LF||
'           from eba_qpoll_comm_invi';
wwv_flow_imp.g_varchar2_table(270) := 'tes  '||wwv_flow.LF||
'          where poll_id = p_poll_id '||wwv_flow.LF||
'      ) loop '||wwv_flow.LF||
'         for c2 in ( '||wwv_flow.LF||
'            select '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(271) := '                (select count (unique r.respondent_id) '||wwv_flow.LF||
'                    from eba_qpoll_results r';
wwv_flow_imp.g_varchar2_table(272) := ', '||wwv_flow.LF||
'                         eba_qpoll_comm_invites c, '||wwv_flow.LF||
'                         eba_qpoll_invites i ';
wwv_flow_imp.g_varchar2_table(273) := ''||wwv_flow.LF||
'                   where r.poll_id = p_poll_id '||wwv_flow.LF||
'                     and r.IS_VALID_YN = ''Y'' '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(274) := '                and c.poll_id = p_poll_id '||wwv_flow.LF||
'                     and c.id = i.comm_invite_id  '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(275) := '               and r.respondent_id = i.respondent_id ) num_responses, '||wwv_flow.LF||
'                 (select coun';
wwv_flow_imp.g_varchar2_table(276) := 't (unique respondent_id) '||wwv_flow.LF||
'                   from eba_qpoll_comm_invites c, '||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(277) := ' eba_qpoll_invites i '||wwv_flow.LF||
'                  where c.poll_id = p_poll_id '||wwv_flow.LF||
'                    and c.id = ';
wwv_flow_imp.g_varchar2_table(278) := 'i.comm_invite_id) num_requests '||wwv_flow.LF||
'             from dual '||wwv_flow.LF||
'         ) loop '||wwv_flow.LF||
'            if c2.num_reque';
wwv_flow_imp.g_varchar2_table(279) := 'sts > 0 then '||wwv_flow.LF||
'               write_clob(l_html_body, ''<tr><td><strong>Response Rate</strong></td><td';
wwv_flow_imp.g_varchar2_table(280) := '>'' || round((c2.num_responses/c2.num_requests) * 100) ||'' %</td></tr>''); '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(281) := '    end loop; '||wwv_flow.LF||
'         exit; '||wwv_flow.LF||
'      end loop; '||wwv_flow.LF||
'      if c0.poll_or_quiz = ''Q'' then '||wwv_flow.LF||
'         write_';
wwv_flow_imp.g_varchar2_table(282) := 'clob(l_html_body, ''<tr><td><strong>Type</strong></td><td>Quiz</td></tr>''); '||wwv_flow.LF||
'      else '||wwv_flow.LF||
'         wri';
wwv_flow_imp.g_varchar2_table(283) := 'te_clob(l_html_body, ''<tr><td><strong>Type</strong></td><td>Poll</td></tr>''); '||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(284) := '-- RESPONDENTS '||wwv_flow.LF||
'      for c1 in ( '||wwv_flow.LF||
'         select count(*) c ,  '||wwv_flow.LF||
'                count(distinct APE';
wwv_flow_imp.g_varchar2_table(285) := 'X_USER) respondents,  '||wwv_flow.LF||
'                min(created) first_submission, '||wwv_flow.LF||
'                max(created) ';
wwv_flow_imp.g_varchar2_table(286) := 'last_submission '||wwv_flow.LF||
'           from eba_qpoll_results '||wwv_flow.LF||
'          where poll_id = p_poll_id '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(287) := ' and nvl(is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'      ) loop '||wwv_flow.LF||
'         l_respondents := c1.c; '||wwv_flow.LF||
'         write_clob(';
wwv_flow_imp.g_varchar2_table(288) := 'l_html_body, ''<tr><td><strong>Respondents</strong></td><td>'' || to_char(c1.c,''999G999G999G999G999G99';
wwv_flow_imp.g_varchar2_table(289) := '9G990'') ||''</td></tr>''); '||wwv_flow.LF||
'         write_clob(l_html_body, ''<tr><td><strong>First Submission</strong';
wwv_flow_imp.g_varchar2_table(290) := '></td><td>'' || to_char(c1.first_submission,''DD-Mon-YYYY'') ||''</td></tr>''); '||wwv_flow.LF||
'         write_clob(l_ht';
wwv_flow_imp.g_varchar2_table(291) := 'ml_body, ''<tr><td><strong>Last Submission</strong></td><td>'' || to_char(c1.last_submission,''DD-Mon-Y';
wwv_flow_imp.g_varchar2_table(292) := 'YYY'') ||''</td></tr>''); '||wwv_flow.LF||
'      end loop; '||wwv_flow.LF||
'      if l_respondents = 0 then '||wwv_flow.LF||
'         write_clob(l_html';
wwv_flow_imp.g_varchar2_table(293) := '_body, ''<tr><td><strong>Respondents</strong></td><td>0</td></tr>''); '||wwv_flow.LF||
'         write_clob(l_html_body';
wwv_flow_imp.g_varchar2_table(294) := ', ''</table>''); '||wwv_flow.LF||
'      else '||wwv_flow.LF||
'         -- GRADE '||wwv_flow.LF||
'         if c0.poll_or_quiz = ''Q'' then '||wwv_flow.LF||
'            f';
wwv_flow_imp.g_varchar2_table(295) := 'or c1 in ( '||wwv_flow.LF||
'               select round(avg(grade),1) c  '||wwv_flow.LF||
'                 from eba_qpoll_results r ';
wwv_flow_imp.g_varchar2_table(296) := ''||wwv_flow.LF||
'                where poll_id = p_poll_id '||wwv_flow.LF||
'                  and nvl(r.is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(297) := '        ) loop '||wwv_flow.LF||
'               write_clob(l_html_body, ''<tr><td><strong>Average Grade</strong></td><';
wwv_flow_imp.g_varchar2_table(298) := 'td>'' || c1.c || '' %</td></tr>''); '||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'         else '||wwv_flow.LF||
'            for c1 in ( '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(299) := '            select decode(p.score_type,''A'',''Average'',''C'',''Cumulative'',p.score_type) st '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(300) := '     from eba_qpoll_questions q, '||wwv_flow.LF||
'                      eba_qpoll_polls p '||wwv_flow.LF||
'                 where q.';
wwv_flow_imp.g_varchar2_table(301) := 'poll_id = p.id and '||wwv_flow.LF||
'                       p.id = p_poll_id and '||wwv_flow.LF||
'                       p.score_type';
wwv_flow_imp.g_varchar2_table(302) := ' in (''A'',''C'') and  '||wwv_flow.LF||
'                       p.enable_score_yn = ''Y'' and '||wwv_flow.LF||
'                       q.ena';
wwv_flow_imp.g_varchar2_table(303) := 'ble_score_yn = ''Y'' '||wwv_flow.LF||
'            ) loop '||wwv_flow.LF||
'               for c2 in ( '||wwv_flow.LF||
'                  select round(a';
wwv_flow_imp.g_varchar2_table(304) := 'vg(score),1) c  '||wwv_flow.LF||
'                    from eba_qpoll_results r '||wwv_flow.LF||
'                   where poll_id = p_';
wwv_flow_imp.g_varchar2_table(305) := 'poll_id '||wwv_flow.LF||
'                     and nvl(r.is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'                     and score is no';
wwv_flow_imp.g_varchar2_table(306) := 't null '||wwv_flow.LF||
'               ) loop '||wwv_flow.LF||
'                  write_clob(l_html_body, ''<tr><td><strong>Average Gr';
wwv_flow_imp.g_varchar2_table(307) := 'ade</strong></td><td>'' || c2.c || '' %</td></tr>''); '||wwv_flow.LF||
'                  write_clob(l_html_body, ''<tr><';
wwv_flow_imp.g_varchar2_table(308) := 'td><strong>Score Type</strong></td><td>'' || apex_escape.html(c1.st) || ''</td></tr>''); '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(309) := '  end loop; '||wwv_flow.LF||
'               exit; '||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'         end if; '||wwv_flow.LF||
'         write_clob(l_ht';
wwv_flow_imp.g_varchar2_table(310) := 'ml_body, ''</table>''); '||wwv_flow.LF||
'         -- QUESTIONS '||wwv_flow.LF||
'         for c2 in ( '||wwv_flow.LF||
'            select '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(311) := '   q.ID question_id, '||wwv_flow.LF||
'               case when c0.use_sections_yn = ''Y'' then s.id end section_id, '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(312) := '              case when c0.use_sections_yn = ''Y'' then s.title end section_title, '||wwv_flow.LF||
'               s.s';
wwv_flow_imp.g_varchar2_table(313) := 'ection_text, '||wwv_flow.LF||
'               q.QUESTION, '||wwv_flow.LF||
'               q.CREATED, '||wwv_flow.LF||
'               q.UPDATED, '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(314) := '           q.display_sequence,  '||wwv_flow.LF||
'               q.QUESTION_TYPE, '||wwv_flow.LF||
'               decode(USE_CUSTOM_A';
wwv_flow_imp.g_varchar2_table(315) := 'NSWERS_YN,''N'',a.answer_01,q.answer_01) answer_01, '||wwv_flow.LF||
'               decode(USE_CUSTOM_ANSWERS_YN,''N'',a';
wwv_flow_imp.g_varchar2_table(316) := '.answer_02,q.answer_02) answer_02, '||wwv_flow.LF||
'               decode(USE_CUSTOM_ANSWERS_YN,''N'',a.answer_03,q.an';
wwv_flow_imp.g_varchar2_table(317) := 'swer_03) answer_03, '||wwv_flow.LF||
'               decode(USE_CUSTOM_ANSWERS_YN,''N'',a.answer_04,q.answer_04) answer';
wwv_flow_imp.g_varchar2_table(318) := '_04, '||wwv_flow.LF||
'               decode(USE_CUSTOM_ANSWERS_YN,''N'',a.answer_05,q.answer_05) answer_05, '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(319) := '      decode(USE_CUSTOM_ANSWERS_YN,''N'',a.answer_06,q.answer_06) answer_06, '||wwv_flow.LF||
'               decode(US';
wwv_flow_imp.g_varchar2_table(320) := 'E_CUSTOM_ANSWERS_YN,''N'',a.answer_07,q.answer_07) answer_07, '||wwv_flow.LF||
'               decode(USE_CUSTOM_ANSWER';
wwv_flow_imp.g_varchar2_table(321) := 'S_YN,''N'',a.answer_08,q.answer_08) answer_08, '||wwv_flow.LF||
'               decode(USE_CUSTOM_ANSWERS_YN,''N'',a.answ';
wwv_flow_imp.g_varchar2_table(322) := 'er_09,q.answer_09) answer_09, '||wwv_flow.LF||
'               decode(USE_CUSTOM_ANSWERS_YN,''N'',a.answer_10,q.answer_';
wwv_flow_imp.g_varchar2_table(323) := '10) answer_10, '||wwv_flow.LF||
'               decode(USE_CUSTOM_ANSWERS_YN,''N'',a.answer_11,q.answer_11) answer_11, ';
wwv_flow_imp.g_varchar2_table(324) := ''||wwv_flow.LF||
'               decode(USE_CUSTOM_ANSWERS_YN,''N'',a.answer_12,q.answer_12) answer_12, '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(325) := ' q.correct_answer, '||wwv_flow.LF||
'               q.use_custom_answers_yn, '||wwv_flow.LF||
'               q.enable_score_yn q_enab';
wwv_flow_imp.g_varchar2_table(326) := 'le_score '||wwv_flow.LF||
'            from eba_qpoll_questions q, '||wwv_flow.LF||
'                 eba_qpoll_canned_answers a, '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(327) := '              eba_qpoll_sections s '||wwv_flow.LF||
'            where q.poll_id = p_poll_id and '||wwv_flow.LF||
'                  q';
wwv_flow_imp.g_varchar2_table(328) := '.question_type = a.code(+) and '||wwv_flow.LF||
'                  q.section_id = s.id (+) '||wwv_flow.LF||
'            order by nvl(';
wwv_flow_imp.g_varchar2_table(329) := 's.display_sequence,c0.max_question_seq), case when c0.use_sections_yn = ''Y'' then s.title end nulls l';
wwv_flow_imp.g_varchar2_table(330) := 'ast, q.display_sequence '||wwv_flow.LF||
'         ) loop '||wwv_flow.LF||
'            c := c + 1; '||wwv_flow.LF||
'            if c > 1 then '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(331) := '         write_clob(l_html_body, ''<br/>''); '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'           if c0.use_sections_yn = ';
wwv_flow_imp.g_varchar2_table(332) := '''Y'' then '||wwv_flow.LF||
'              if nvl(c2.section_id,-1) != nvl(l_section_id,0) then '||wwv_flow.LF||
'                 write';
wwv_flow_imp.g_varchar2_table(333) := '_clob(l_html_body, ''<p class="lp-Question-questionText"><strong>''); '||wwv_flow.LF||
'                 write_clob(l_h';
wwv_flow_imp.g_varchar2_table(334) := 'tml_body, nvl(c2.section_title,''Additional Questions'')); '||wwv_flow.LF||
'                 write_clob(l_html_body, ''';
wwv_flow_imp.g_varchar2_table(335) := '</strong>''); '||wwv_flow.LF||
'                 if c2.section_text is not null then '||wwv_flow.LF||
'                    write_clob(l';
wwv_flow_imp.g_varchar2_table(336) := '_html_body, ''<br/>''); '||wwv_flow.LF||
'                    write_clob(l_html_body, apex_escape.html(c2.section_text)';
wwv_flow_imp.g_varchar2_table(337) := '); '||wwv_flow.LF||
'                 end if; '||wwv_flow.LF||
'                 write_clob(l_html_body, ''</p>''); '||wwv_flow.LF||
'              end i';
wwv_flow_imp.g_varchar2_table(338) := 'f; '||wwv_flow.LF||
'              l_section_id := c2.section_id; '||wwv_flow.LF||
'           end if; '||wwv_flow.LF||
'            write_clob(l_html_';
wwv_flow_imp.g_varchar2_table(339) := 'body, ''<p class="lp-Question-questionText">Q''||c||'': <strong>''||apex_escape.html(c2.question)||''</st';
wwv_flow_imp.g_varchar2_table(340) := 'rong></p>''); '||wwv_flow.LF||
'            -- if quiz, show average per question '||wwv_flow.LF||
'            if c0.poll_or_quiz = ''Q';
wwv_flow_imp.g_varchar2_table(341) := ''' then '||wwv_flow.LF||
'               for c4 in ( '||wwv_flow.LF||
'                  select count(*) total_cnt, sum(decode(d.answer';
wwv_flow_imp.g_varchar2_table(342) := '_correct_yn,''Y'',1,0)) total_right '||wwv_flow.LF||
'                    from eba_qpoll_result_details d, '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(343) := '              eba_qpoll_results r '||wwv_flow.LF||
'                   where d.question_id = c2.question_id '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(344) := '             and r.id = d.result_id '||wwv_flow.LF||
'                     and r.poll_id = p_poll_id '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(345) := ') loop '||wwv_flow.LF||
'                  write_clob(l_html_body, ''<p>Average Score: ''|| round(((c4.total_right/c4.t';
wwv_flow_imp.g_varchar2_table(346) := 'otal_cnt)*100),1) || '' %</p>''); '||wwv_flow.LF||
'               end loop; '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'            -- if sc';
wwv_flow_imp.g_varchar2_table(347) := 'ored poll, show average per question '||wwv_flow.LF||
'            if c0.score_type in (''A'',''C'') and c0.enable_score_';
wwv_flow_imp.g_varchar2_table(348) := 'yn = ''Y'' and c2.q_enable_score = ''Y'' then '||wwv_flow.LF||
'               for c4 in ( '||wwv_flow.LF||
'                  select roun';
wwv_flow_imp.g_varchar2_table(349) := 'd(avg(d.score),1) avg_score '||wwv_flow.LF||
'                    from eba_qpoll_result_details d, '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(350) := '        eba_qpoll_results r '||wwv_flow.LF||
'                   where d.question_id = c2.question_id '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(351) := '       and r.id = d.result_id '||wwv_flow.LF||
'                     and r.poll_id = p_poll_id '||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(352) := 'and d.score is not null '||wwv_flow.LF||
'               ) loop '||wwv_flow.LF||
'                  write_clob(l_html_body, ''<p>Averag';
wwv_flow_imp.g_varchar2_table(353) := 'e Score: ''|| c4.avg_score || ''</p>''); '||wwv_flow.LF||
'               end loop; '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'            --';
wwv_flow_imp.g_varchar2_table(354) := ' if quiz and textarea, show correct answer '||wwv_flow.LF||
'            if c0.poll_or_quiz = ''Q'' and c2.QUESTION_TYP';
wwv_flow_imp.g_varchar2_table(355) := 'E in (''TEXT'',''TEXTAREA'') then '||wwv_flow.LF||
'               write_clob(l_html_body, ''<p>Correct Answer: ''|| apex_e';
wwv_flow_imp.g_varchar2_table(356) := 'scape.html(c2.correct_answer) || ''</p>''); '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'            -- ANSWERS AND RESPONSES';
wwv_flow_imp.g_varchar2_table(357) := '  '||wwv_flow.LF||
'            if c2.QUESTION_TYPE = ''TEXT'' then '||wwv_flow.LF||
'                -- show each answer '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(358) := '   write_clob(l_html_body, ''<ul class="a-TextResponse">''); '||wwv_flow.LF||
'                for c3 in ( '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(359) := '        select d.ANSWER_01 answer, '||wwv_flow.LF||
'                          count(*) cnt '||wwv_flow.LF||
'                     fro';
wwv_flow_imp.g_varchar2_table(360) := 'm eba_qpoll_result_details d,  '||wwv_flow.LF||
'                          eba_qpoll_results r '||wwv_flow.LF||
'                    w';
wwv_flow_imp.g_varchar2_table(361) := 'here d.result_id = r.id and  '||wwv_flow.LF||
'                          d.question_id = c2.question_id and '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(362) := '                  r.poll_id = p_poll_id and '||wwv_flow.LF||
'                          nvl(r.is_valid_yn,''Y'') = ''Y'' ';
wwv_flow_imp.g_varchar2_table(363) := 'and '||wwv_flow.LF||
'                          d.answer_01 is not null '||wwv_flow.LF||
'                    group by d.ANSWER_01 '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(364) := '                  order by d.ANSWER_01 '||wwv_flow.LF||
'                ) loop '||wwv_flow.LF||
'                   write_clob(l_html';
wwv_flow_imp.g_varchar2_table(365) := '_body, ''<li>''); '||wwv_flow.LF||
'                   if lower(trim(c3.answer)) = lower(c2.correct_answer) then '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(366) := '                 write_clob(l_html_body, ''* ''); '||wwv_flow.LF||
'                   end if; '||wwv_flow.LF||
'                   writ';
wwv_flow_imp.g_varchar2_table(367) := 'e_clob(l_html_body, apex_escape.html(c3.answer)||'' (''|| c3.cnt ||'')''); '||wwv_flow.LF||
'                   write_clo';
wwv_flow_imp.g_varchar2_table(368) := 'b(l_html_body, ''</li>''); '||wwv_flow.LF||
'                end loop; -- c3 '||wwv_flow.LF||
'                write_clob(l_html_body, ''';
wwv_flow_imp.g_varchar2_table(369) := '</ul>''); '||wwv_flow.LF||
'            elsif c2.question_type != ''TEXTAREA'' then '||wwv_flow.LF||
'                -- show chart of ag';
wwv_flow_imp.g_varchar2_table(370) := 'gregated answers '||wwv_flow.LF||
'                a := 0; '||wwv_flow.LF||
'                l_max := 0; '||wwv_flow.LF||
'                for c3 in ( ';
wwv_flow_imp.g_varchar2_table(371) := ''||wwv_flow.LF||
'                   select answer, count(*) c '||wwv_flow.LF||
'                    from  '||wwv_flow.LF||
'                   ( '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(372) := '                select d.ANSWER_01 answer '||wwv_flow.LF||
'                      from eba_qpoll_result_details d, eb';
wwv_flow_imp.g_varchar2_table(373) := 'a_qpoll_results r '||wwv_flow.LF||
'                     where d.result_id = r.id and d.question_id = c2.question_id ';
wwv_flow_imp.g_varchar2_table(374) := 'and '||wwv_flow.LF||
'                           r.poll_id = p_poll_id and d.answer_01 is not null and '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(375) := '              nvl(r.is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'                    union all '||wwv_flow.LF||
'                    selec';
wwv_flow_imp.g_varchar2_table(376) := 't d.ANSWER_02 answer '||wwv_flow.LF||
'                      from eba_qpoll_result_details d, eba_qpoll_results r '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(377) := '                   where d.result_id = r.id and d.question_id = c2.question_id and '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(378) := '           r.poll_id = p_poll_id and d.answer_02 is not null and '||wwv_flow.LF||
'                           nvl(r.i';
wwv_flow_imp.g_varchar2_table(379) := 's_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'                    union all '||wwv_flow.LF||
'                    select d.ANSWER_03 answer ';
wwv_flow_imp.g_varchar2_table(380) := ''||wwv_flow.LF||
'                      from eba_qpoll_result_details d, eba_qpoll_results r '||wwv_flow.LF||
'                     wh';
wwv_flow_imp.g_varchar2_table(381) := 'ere d.result_id = r.id and d.question_id = c2.question_id and '||wwv_flow.LF||
'                           r.poll_id ';
wwv_flow_imp.g_varchar2_table(382) := '= p_poll_id and d.answer_03 is not null and '||wwv_flow.LF||
'                           nvl(r.is_valid_yn,''Y'') = ''Y''';
wwv_flow_imp.g_varchar2_table(383) := ' '||wwv_flow.LF||
'                    union all '||wwv_flow.LF||
'                    select d.ANSWER_04 answer '||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(384) := '  from eba_qpoll_result_details d, eba_qpoll_results r '||wwv_flow.LF||
'                     where d.result_id = r.i';
wwv_flow_imp.g_varchar2_table(385) := 'd and d.question_id = c2.question_id and '||wwv_flow.LF||
'                           r.poll_id = p_poll_id and d.ans';
wwv_flow_imp.g_varchar2_table(386) := 'wer_04 is not null and '||wwv_flow.LF||
'                           nvl(r.is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(387) := ' union all '||wwv_flow.LF||
'                    select d.ANSWER_05 answer '||wwv_flow.LF||
'                      from eba_qpoll_resu';
wwv_flow_imp.g_varchar2_table(388) := 'lt_details d, eba_qpoll_results r '||wwv_flow.LF||
'                     where d.result_id = r.id and d.question_id =';
wwv_flow_imp.g_varchar2_table(389) := ' c2.question_id and '||wwv_flow.LF||
'                           r.poll_id = p_poll_id and d.answer_05 is not null an';
wwv_flow_imp.g_varchar2_table(390) := 'd '||wwv_flow.LF||
'                           nvl(r.is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'                    union all '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(391) := '           select d.ANSWER_06 answer '||wwv_flow.LF||
'                      from eba_qpoll_result_details d, eba_qpo';
wwv_flow_imp.g_varchar2_table(392) := 'll_results r '||wwv_flow.LF||
'                     where d.result_id = r.id and d.question_id = c2.question_id and '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(393) := '                           r.poll_id = p_poll_id and d.answer_06 is not null and '||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(394) := '         nvl(r.is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'                    union all '||wwv_flow.LF||
'                    select d.A';
wwv_flow_imp.g_varchar2_table(395) := 'NSWER_07 answer '||wwv_flow.LF||
'                      from eba_qpoll_result_details d, eba_qpoll_results r '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(396) := '              where d.result_id = r.id and d.question_id = c2.question_id and '||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(397) := '      r.poll_id = p_poll_id and d.answer_07 is not null and '||wwv_flow.LF||
'                           nvl(r.is_val';
wwv_flow_imp.g_varchar2_table(398) := 'id_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'                    union all '||wwv_flow.LF||
'                    select d.ANSWER_08 answer '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(399) := '                  from eba_qpoll_result_details d, eba_qpoll_results r '||wwv_flow.LF||
'                     where d';
wwv_flow_imp.g_varchar2_table(400) := '.result_id = r.id and d.question_id = c2.question_id and '||wwv_flow.LF||
'                           r.poll_id = p_p';
wwv_flow_imp.g_varchar2_table(401) := 'oll_id and d.answer_08 is not null and '||wwv_flow.LF||
'                           nvl(r.is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(402) := '                 union all '||wwv_flow.LF||
'                    select d.ANSWER_09 answer '||wwv_flow.LF||
'                      fro';
wwv_flow_imp.g_varchar2_table(403) := 'm eba_qpoll_result_details d, eba_qpoll_results r '||wwv_flow.LF||
'                     where d.result_id = r.id and';
wwv_flow_imp.g_varchar2_table(404) := ' d.question_id = c2.question_id and '||wwv_flow.LF||
'                           r.poll_id = p_poll_id and d.answer_0';
wwv_flow_imp.g_varchar2_table(405) := '9 is not null and '||wwv_flow.LF||
'                           nvl(r.is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'                    unio';
wwv_flow_imp.g_varchar2_table(406) := 'n all '||wwv_flow.LF||
'                    select d.ANSWER_10 answer '||wwv_flow.LF||
'                      from eba_qpoll_result_de';
wwv_flow_imp.g_varchar2_table(407) := 'tails d, eba_qpoll_results r '||wwv_flow.LF||
'                     where d.result_id = r.id and d.question_id = c2.q';
wwv_flow_imp.g_varchar2_table(408) := 'uestion_id and '||wwv_flow.LF||
'                           r.poll_id = p_poll_id and d.answer_10 is not null and '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(409) := '                         nvl(r.is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'                    union all '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(410) := '      select d.ANSWER_11 answer '||wwv_flow.LF||
'                      from eba_qpoll_result_details d, eba_qpoll_re';
wwv_flow_imp.g_varchar2_table(411) := 'sults r '||wwv_flow.LF||
'                     where d.result_id = r.id and d.question_id = c2.question_id and '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(412) := '                      r.poll_id = p_poll_id and d.answer_11 is not null and '||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(413) := '    nvl(r.is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'                    union all '||wwv_flow.LF||
'                    select d.ANSWER';
wwv_flow_imp.g_varchar2_table(414) := '_12 answer '||wwv_flow.LF||
'                      from eba_qpoll_result_details d, eba_qpoll_results r '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(415) := '         where d.result_id = r.id and d.question_id = c2.question_id and '||wwv_flow.LF||
'                          ';
wwv_flow_imp.g_varchar2_table(416) := ' r.poll_id = p_poll_id and d.answer_12 is not null and '||wwv_flow.LF||
'                           nvl(r.is_valid_yn';
wwv_flow_imp.g_varchar2_table(417) := ',''Y'') = ''Y'' '||wwv_flow.LF||
'                   ) x '||wwv_flow.LF||
'                   group by answer '||wwv_flow.LF||
'                   order by';
wwv_flow_imp.g_varchar2_table(418) := ' 2 desc '||wwv_flow.LF||
'                ) loop '||wwv_flow.LF||
'                   a := a + 1; '||wwv_flow.LF||
'                   l_label(a) := c3';
wwv_flow_imp.g_varchar2_table(419) := '.answer; '||wwv_flow.LF||
'                   l_count(a) := c3.c; '||wwv_flow.LF||
'                   if c3.c > l_max then  '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(420) := '              l_max := c3.c;  '||wwv_flow.LF||
'                   end if; '||wwv_flow.LF||
'                end loop;  '||wwv_flow.LF||
'    '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(421) := '        write_clob(l_html_body, ''<table class="ch" cellpadding="4" style="width: 100%;font-size: 12p';
wwv_flow_imp.g_varchar2_table(422) := 'x;line-height: 16px;">''); '||wwv_flow.LF||
'     '||wwv_flow.LF||
'                l_answer(1) := c2.answer_01; '||wwv_flow.LF||
'                l_ans';
wwv_flow_imp.g_varchar2_table(423) := 'wer(2) := c2.answer_02; '||wwv_flow.LF||
'                l_answer(3) := c2.answer_03; '||wwv_flow.LF||
'                l_answer(4) :';
wwv_flow_imp.g_varchar2_table(424) := '= c2.answer_04; '||wwv_flow.LF||
'                l_answer(5) := c2.answer_05; '||wwv_flow.LF||
'                l_answer(6) := c2.ans';
wwv_flow_imp.g_varchar2_table(425) := 'wer_06; '||wwv_flow.LF||
'                l_answer(7) := c2.answer_07; '||wwv_flow.LF||
'                l_answer(8) := c2.answer_08; ';
wwv_flow_imp.g_varchar2_table(426) := ''||wwv_flow.LF||
'                l_answer(9) := c2.answer_09; '||wwv_flow.LF||
'                l_answer(10) := c2.answer_10; '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(427) := '          l_answer(11) := c2.answer_11; '||wwv_flow.LF||
'                l_answer(12) := c2.answer_12; '||wwv_flow.LF||
'     '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(428) := '          for m in 1..12 loop '||wwv_flow.LF||
'                    if l_answer(m) is null then exit; end if; '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(429) := '              l_found := false; '||wwv_flow.LF||
'                    for j in 1..a loop '||wwv_flow.LF||
'                        if ';
wwv_flow_imp.g_varchar2_table(430) := 'l_answer(m) = l_label(j) then '||wwv_flow.LF||
'                           if c0.poll_or_quiz = ''Q'' then '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(431) := '                   l_correct_answer_yn := ''N''; '||wwv_flow.LF||
'                              if c2.question_type = ';
wwv_flow_imp.g_varchar2_table(432) := '''CHECKBOX'' then '||wwv_flow.LF||
'                                 if instr(c2.correct_answer,  '||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(433) := '                substr(c2.correct_answer,1,1)||l_label(j)||substr(c2.correct_answer,1,1)) > 0 then '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(434) := '                                    l_correct_answer_yn := ''Y''; '||wwv_flow.LF||
'                                 en';
wwv_flow_imp.g_varchar2_table(435) := 'd if; '||wwv_flow.LF||
'                              elsif c2.use_custom_answers_yn = ''Y'' then '||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(436) := '             if lower(l_label(j)) = lower(c2.correct_answer) then '||wwv_flow.LF||
'                                 ';
wwv_flow_imp.g_varchar2_table(437) := '   l_correct_answer_yn := ''Y''; '||wwv_flow.LF||
'                                 end if; '||wwv_flow.LF||
'                          ';
wwv_flow_imp.g_varchar2_table(438) := '    else '||wwv_flow.LF||
'                                 if l_label(j) = c2.correct_answer then '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(439) := '                   l_correct_answer_yn := ''Y''; '||wwv_flow.LF||
'                                 end if; '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(440) := '                    end if; '||wwv_flow.LF||
'                            end if; '||wwv_flow.LF||
'                            paint_';
wwv_flow_imp.g_varchar2_table(441) := 'answer ( '||wwv_flow.LF||
'                               p_count => l_count(j),  '||wwv_flow.LF||
'                               p_p';
wwv_flow_imp.g_varchar2_table(442) := 'ct   => l_pct2,  '||wwv_flow.LF||
'                               p_label => l_label(j), '||wwv_flow.LF||
'                           ';
wwv_flow_imp.g_varchar2_table(443) := '    p_correct_answer => l_correct_answer_yn ); '||wwv_flow.LF||
'                            l_found := true; '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(444) := '                      exit; '||wwv_flow.LF||
'                        end if; '||wwv_flow.LF||
'                    end loop;  '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(445) := '              if not l_found then  '||wwv_flow.LF||
'                       if c0.poll_or_quiz = ''Q'' then '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(446) := '                l_correct_answer_yn := ''N''; '||wwv_flow.LF||
'                          if c2.question_type = ''CHECKB';
wwv_flow_imp.g_varchar2_table(447) := 'OX'' then '||wwv_flow.LF||
'                             if instr(c2.correct_answer,  '||wwv_flow.LF||
'                               ';
wwv_flow_imp.g_varchar2_table(448) := ' substr(c2.correct_answer,1,1)||l_answer(m)||substr(c2.correct_answer,1,1)) > 0 then '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(449) := '                  l_correct_answer_yn := ''Y''; '||wwv_flow.LF||
'                             end if; '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(450) := '           elsif c2.use_custom_answers_yn = ''Y'' then '||wwv_flow.LF||
'                             if lower(l_answer';
wwv_flow_imp.g_varchar2_table(451) := '(m)) = lower(c2.correct_answer) then '||wwv_flow.LF||
'                                l_correct_answer_yn := ''Y''; '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(452) := '                            end if; '||wwv_flow.LF||
'                          else '||wwv_flow.LF||
'                              i';
wwv_flow_imp.g_varchar2_table(453) := 'f l_answer(m) = c2.correct_answer then '||wwv_flow.LF||
'                                 l_correct_answer_yn := ''Y'';';
wwv_flow_imp.g_varchar2_table(454) := ' '||wwv_flow.LF||
'                              end if; '||wwv_flow.LF||
'                          end if; '||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(455) := 'end if; '||wwv_flow.LF||
'                        paint_answer ( '||wwv_flow.LF||
'                          p_count => 0,  '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(456) := '                 p_pct   => 0,  '||wwv_flow.LF||
'                          p_label => l_answer(m), '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(457) := '          p_correct_answer => l_correct_answer_yn ); '||wwv_flow.LF||
'                    end if; '||wwv_flow.LF||
'                e';
wwv_flow_imp.g_varchar2_table(458) := 'nd loop; '||wwv_flow.LF||
'                write_clob(l_html_body, ''</table>''); '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'            -- ';
wwv_flow_imp.g_varchar2_table(459) := 'DETAILED RESPONSES '||wwv_flow.LF||
'            write_clob(l_html_body, ''<table cellpadding="4" border="1" bordercol';
wwv_flow_imp.g_varchar2_table(460) := 'or="#B8B8B8" cellspacing="0" style="width: 100%;border-collapse:collapse;font-size: 14px;">''); '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(461) := '        write_clob(l_html_body, ''<tr><th>Respondent</th><th>Answer</th><th>Submitted</th>''); '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(462) := '      if c0.poll_or_quiz = ''Q'' then '||wwv_flow.LF||
'               write_clob(l_html_body, ''<td>Correct</td>''); '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(463) := '          end if; '||wwv_flow.LF||
'            write_clob(l_html_body, ''</tr>''); '||wwv_flow.LF||
'            for c3 in ( '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(464) := '      select 1 seq, d.ANSWER_01 answer, lower(r.apex_user) apex_user, r.created, '||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(465) := '    decode(answer_correct_yn,''Y'',apex_lang.message(''YES''),apex_lang.message(''NO'')) CORRECT '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(466) := '         from eba_qpoll_result_details d, eba_qpoll_results r '||wwv_flow.LF||
'                where d.result_id = r';
wwv_flow_imp.g_varchar2_table(467) := '.id and d.question_id = c2.question_id and '||wwv_flow.LF||
'                      r.poll_id = p_poll_id and d.answer';
wwv_flow_imp.g_varchar2_table(468) := '_01 is not null and '||wwv_flow.LF||
'                      nvl(r.is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'               union all '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(469) := '              select 2 seq, d.ANSWER_02 answer,lower(r.apex_user) apex_user, r.created, '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(470) := '           decode(answer_correct_yn,''Y'',apex_lang.message(''YES''),apex_lang.message(''NO'')) CORRECT '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(471) := '                from eba_qpoll_result_details d, eba_qpoll_results r '||wwv_flow.LF||
'                where d.result';
wwv_flow_imp.g_varchar2_table(472) := '_id = r.id and d.question_id = c2.question_id and '||wwv_flow.LF||
'                      r.poll_id = p_poll_id and d';
wwv_flow_imp.g_varchar2_table(473) := '.answer_02 is not null and '||wwv_flow.LF||
'                      nvl(r.is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'               union';
wwv_flow_imp.g_varchar2_table(474) := ' all '||wwv_flow.LF||
'               select 3 seq, d.ANSWER_03 answer, lower(r.apex_user) apex_user, r.created, '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(475) := '                   decode(answer_correct_yn,''Y'',apex_lang.message(''YES''),apex_lang.message(''NO'')) CO';
wwv_flow_imp.g_varchar2_table(476) := 'RRECT '||wwv_flow.LF||
'                 from eba_qpoll_result_details d, eba_qpoll_results r '||wwv_flow.LF||
'                where ';
wwv_flow_imp.g_varchar2_table(477) := 'd.result_id = r.id and d.question_id = c2.question_id and '||wwv_flow.LF||
'                      r.poll_id = p_poll_';
wwv_flow_imp.g_varchar2_table(478) := 'id and d.answer_03 is not null and '||wwv_flow.LF||
'                      nvl(r.is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(479) := '   union all '||wwv_flow.LF||
'               select 4 seq, d.ANSWER_04 answer, lower(r.apex_user) apex_user, r.creat';
wwv_flow_imp.g_varchar2_table(480) := 'ed, '||wwv_flow.LF||
'                      decode(answer_correct_yn,''Y'',apex_lang.message(''YES''),apex_lang.message(''';
wwv_flow_imp.g_varchar2_table(481) := 'NO'')) CORRECT '||wwv_flow.LF||
'                 from eba_qpoll_result_details d, eba_qpoll_results r '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(482) := '  where d.result_id = r.id and d.question_id = c2.question_id and '||wwv_flow.LF||
'                      r.poll_id =';
wwv_flow_imp.g_varchar2_table(483) := ' p_poll_id and d.answer_04 is not null and '||wwv_flow.LF||
'                      nvl(r.is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(484) := '           union all '||wwv_flow.LF||
'               select 5 seq, d.ANSWER_05 answer, lower(r.apex_user) apex_user,';
wwv_flow_imp.g_varchar2_table(485) := ' r.created, '||wwv_flow.LF||
'                      decode(answer_correct_yn,''Y'',apex_lang.message(''YES''),apex_lang.m';
wwv_flow_imp.g_varchar2_table(486) := 'essage(''NO'')) CORRECT '||wwv_flow.LF||
'                 from eba_qpoll_result_details d, eba_qpoll_results r '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(487) := '          where d.result_id = r.id and d.question_id = c2.question_id and '||wwv_flow.LF||
'                      r.p';
wwv_flow_imp.g_varchar2_table(488) := 'oll_id = p_poll_id and d.answer_05 is not null and '||wwv_flow.LF||
'                      nvl(r.is_valid_yn,''Y'') = ''';
wwv_flow_imp.g_varchar2_table(489) := 'Y'' '||wwv_flow.LF||
'               union all '||wwv_flow.LF||
'               select 6 seq, d.ANSWER_06 answer, lower(r.apex_user) ap';
wwv_flow_imp.g_varchar2_table(490) := 'ex_user, r.created, '||wwv_flow.LF||
'                      decode(answer_correct_yn,''Y'',apex_lang.message(''YES''),ape';
wwv_flow_imp.g_varchar2_table(491) := 'x_lang.message(''NO'')) CORRECT '||wwv_flow.LF||
'                 from eba_qpoll_result_details d, eba_qpoll_results r';
wwv_flow_imp.g_varchar2_table(492) := ' '||wwv_flow.LF||
'                where d.result_id = r.id and d.question_id = c2.question_id and '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(493) := '     r.poll_id = p_poll_id and d.answer_06 is not null and '||wwv_flow.LF||
'                      nvl(r.is_valid_yn,';
wwv_flow_imp.g_varchar2_table(494) := '''Y'') = ''Y'' '||wwv_flow.LF||
'               union all '||wwv_flow.LF||
'               select 7 seq, d.ANSWER_07 answer,lower(r.apex_u';
wwv_flow_imp.g_varchar2_table(495) := 'ser) apex_user, r.created, '||wwv_flow.LF||
'                      decode(answer_correct_yn,''Y'',apex_lang.message(''YE';
wwv_flow_imp.g_varchar2_table(496) := 'S''),apex_lang.message(''NO'')) CORRECT '||wwv_flow.LF||
'                 from eba_qpoll_result_details d, eba_qpoll_re';
wwv_flow_imp.g_varchar2_table(497) := 'sults r '||wwv_flow.LF||
'                where d.result_id = r.id and d.question_id = c2.question_id and '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(498) := '            r.poll_id = p_poll_id and d.answer_07 is not null and '||wwv_flow.LF||
'                      nvl(r.is_va';
wwv_flow_imp.g_varchar2_table(499) := 'lid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'               union all '||wwv_flow.LF||
'               select 8 seq, d.ANSWER_08 answer, lower(';
wwv_flow_imp.g_varchar2_table(500) := 'r.apex_user) apex_user, r.created, '||wwv_flow.LF||
'                      decode(answer_correct_yn,''Y'',apex_lang.mes';
wwv_flow_imp.g_varchar2_table(501) := 'sage(''YES''),apex_lang.message(''NO'')) CORRECT '||wwv_flow.LF||
'                 from eba_qpoll_result_details d, eba_';
wwv_flow_imp.g_varchar2_table(502) := 'qpoll_results r '||wwv_flow.LF||
'                where d.result_id = r.id and d.question_id = c2.question_id and '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(503) := '                    r.poll_id = p_poll_id and d.answer_08 is not null and '||wwv_flow.LF||
'                      nvl';
wwv_flow_imp.g_varchar2_table(504) := '(r.is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'               union all '||wwv_flow.LF||
'               select 9 seq, d.ANSWER_09 answer';
wwv_flow_imp.g_varchar2_table(505) := ', lower(r.apex_user) apex_user, r.created, '||wwv_flow.LF||
'                      decode(answer_correct_yn,''Y'',apex_';
wwv_flow_imp.g_varchar2_table(506) := 'lang.message(''YES''),apex_lang.message(''NO'')) CORRECT '||wwv_flow.LF||
'                 from eba_qpoll_result_details';
wwv_flow_imp.g_varchar2_table(507) := ' d, eba_qpoll_results r '||wwv_flow.LF||
'                where d.result_id = r.id and d.question_id = c2.question_id';
wwv_flow_imp.g_varchar2_table(508) := ' and '||wwv_flow.LF||
'                      r.poll_id = p_poll_id and d.answer_09 is not null and '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(509) := '     nvl(r.is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'               union all '||wwv_flow.LF||
'               select 10 seq, d.ANSWER_';
wwv_flow_imp.g_varchar2_table(510) := '10 answer, lower(r.apex_user) apex_user, r.created, '||wwv_flow.LF||
'                      decode(answer_correct_yn,';
wwv_flow_imp.g_varchar2_table(511) := '''Y'',apex_lang.message(''YES''),apex_lang.message(''NO'')) CORRECT '||wwv_flow.LF||
'                 from eba_qpoll_resul';
wwv_flow_imp.g_varchar2_table(512) := 't_details d, eba_qpoll_results r '||wwv_flow.LF||
'                where d.result_id = r.id and d.question_id = c2.qu';
wwv_flow_imp.g_varchar2_table(513) := 'estion_id and '||wwv_flow.LF||
'                      r.poll_id = p_poll_id and d.answer_10 is not null and '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(514) := '              nvl(r.is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'               union all '||wwv_flow.LF||
'               select 11 seq, ';
wwv_flow_imp.g_varchar2_table(515) := 'd.ANSWER_09 answer, lower(r.apex_user) apex_user, r.created, '||wwv_flow.LF||
'                      decode(answer_co';
wwv_flow_imp.g_varchar2_table(516) := 'rrect_yn,''Y'',apex_lang.message(''YES''),apex_lang.message(''NO'')) CORRECT '||wwv_flow.LF||
'                 from eba_qp';
wwv_flow_imp.g_varchar2_table(517) := 'oll_result_details d, eba_qpoll_results r '||wwv_flow.LF||
'                where d.result_id = r.id and d.question_i';
wwv_flow_imp.g_varchar2_table(518) := 'd = c2.question_id and '||wwv_flow.LF||
'                      r.poll_id = p_poll_id and d.answer_11 is not null and ';
wwv_flow_imp.g_varchar2_table(519) := ''||wwv_flow.LF||
'                      nvl(r.is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'               union all '||wwv_flow.LF||
'               select';
wwv_flow_imp.g_varchar2_table(520) := ' 12 seq, d.ANSWER_10 answer, lower(r.apex_user) apex_user, r.created, '||wwv_flow.LF||
'                      decode(';
wwv_flow_imp.g_varchar2_table(521) := 'answer_correct_yn,''Y'',apex_lang.message(''YES''),apex_lang.message(''NO'')) CORRECT '||wwv_flow.LF||
'                 fr';
wwv_flow_imp.g_varchar2_table(522) := 'om eba_qpoll_result_details d, eba_qpoll_results r '||wwv_flow.LF||
'                where d.result_id = r.id and d.q';
wwv_flow_imp.g_varchar2_table(523) := 'uestion_id = c2.question_id and '||wwv_flow.LF||
'                      r.poll_id = p_poll_id and d.answer_12 is not ';
wwv_flow_imp.g_varchar2_table(524) := 'null and '||wwv_flow.LF||
'                      nvl(r.is_valid_yn,''Y'') = ''Y'' '||wwv_flow.LF||
'               order by 3 '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(525) := ' ) loop '||wwv_flow.LF||
'               write_clob(l_html_body, ''<tr><td valign="top">''||apex_escape.html(c3.apex_us';
wwv_flow_imp.g_varchar2_table(526) := 'er)||''</td><td valign="top">''||apex_escape.html(c3.answer)||''</td><td valign="top">''||apex_util.get_';
wwv_flow_imp.g_varchar2_table(527) := 'since(c3.created)||''</td>''); '||wwv_flow.LF||
'               if c0.poll_or_quiz = ''Q'' then '||wwv_flow.LF||
'                  write_';
wwv_flow_imp.g_varchar2_table(528) := 'clob(l_html_body, ''<td valign="top">''||c3.correct||''</td>''); '||wwv_flow.LF||
'               end if; '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(529) := ' write_clob(l_html_body, ''</tr>''); '||wwv_flow.LF||
'            end loop; -- c3 '||wwv_flow.LF||
'            write_clob(l_html_body,';
wwv_flow_imp.g_varchar2_table(530) := ' ''</table>''); '||wwv_flow.LF||
'            if c = 20 then '||wwv_flow.LF||
'               exit; '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'         end l';
wwv_flow_imp.g_varchar2_table(531) := 'oop; -- c2 '||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'      return l_html_body; '||wwv_flow.LF||
'      sys.dbms_lob.freetemporary( l_html_body ';
wwv_flow_imp.g_varchar2_table(532) := '); '||wwv_flow.LF||
'   end loop; -- c0 '||wwv_flow.LF||
'exception '||wwv_flow.LF||
'   when others then '||wwv_flow.LF||
'      if l_html_body is not null then '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(533) := '    sys.dbms_lob.freetemporary( l_html_body ); '||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'      raise; '||wwv_flow.LF||
'end prepare_poll_result';
wwv_flow_imp.g_varchar2_table(534) := 's; '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure eba_qpoll_data_load '||wwv_flow.LF||
'as'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into eba_qpoll_polls'||wwv_flow.LF||
'    (id,poll_name,poll';
wwv_flow_imp.g_varchar2_table(535) := '_details,intro_text,thank_you_text,status_id,anonymous_yn,can_update_answers_yn,all_view_results_yn,';
wwv_flow_imp.g_varchar2_table(536) := 'enable_score_yn,'||wwv_flow.LF||
'     POLL_OR_QUIZ, score_type, start_time,stop_time,invite_only_yn)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(537) := '(1,''Sports'',''Sample poll that comes installed with the application sample data'',''Please take this sa';
wwv_flow_imp.g_varchar2_table(538) := 'mple poll.'',''Thanks for taking the sample poll.'',3,'||wwv_flow.LF||
'    ''N'',''N'',''Y'',''Y'',''P'', ''N'', current_timestamp,';
wwv_flow_imp.g_varchar2_table(539) := 'null,''N'');'||wwv_flow.LF||
'     insert into eba_qpoll_questions'||wwv_flow.LF||
'          (id, poll_id, display_sequence, question, ';
wwv_flow_imp.g_varchar2_table(540) := 'question_type, mandatory_yn, publish_yn, USE_CUSTOM_ANSWERS_YN,'||wwv_flow.LF||
'              answer_01,answer_02,an';
wwv_flow_imp.g_varchar2_table(541) := 'swer_03,answer_04,answer_05,answer_06,answer_07,answer_08,answer_09,answer_10,answer_11)'||wwv_flow.LF||
'      value';
wwv_flow_imp.g_varchar2_table(542) := 's'||wwv_flow.LF||
'         (1,1,10,''What is your favorite sport to watch others play?'',''RADIO_GROUP'',''Y'',''Y'',''Y'','||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(543) := '           ''Americas Cup Yacht Racing'','||wwv_flow.LF||
'             ''American Football'','||wwv_flow.LF||
'             ''Baseball'','||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(544) := '            ''Basketball'','||wwv_flow.LF||
'             ''Cricket'','||wwv_flow.LF||
'             ''Golf'','||wwv_flow.LF||
'             ''Rugby'','||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(545) := '      ''Soccer'','||wwv_flow.LF||
'             ''Tennis'','||wwv_flow.LF||
'             ''Volleyball'','||wwv_flow.LF||
'             ''Other'');'||wwv_flow.LF||
'     insert';
wwv_flow_imp.g_varchar2_table(546) := ' into eba_qpoll_questions'||wwv_flow.LF||
'          (id, poll_id, display_sequence, question, question_type, mandato';
wwv_flow_imp.g_varchar2_table(547) := 'ry_yn, publish_yn, USE_CUSTOM_ANSWERS_YN)'||wwv_flow.LF||
'      values'||wwv_flow.LF||
'          (2,1,20,''I like to play sports more';
wwv_flow_imp.g_varchar2_table(548) := ' than watch'',''RANGE_AGREE_DISAGREE'',''Y'',''Y'',''N'');'||wwv_flow.LF||
'        '||wwv_flow.LF||
'    insert into eba_qpoll_polls'||wwv_flow.LF||
'    (id,p';
wwv_flow_imp.g_varchar2_table(549) := 'oll_name,poll_details,intro_text,thank_you_text,status_id,anonymous_yn,can_update_answers_yn,all_vie';
wwv_flow_imp.g_varchar2_table(550) := 'w_results_yn,enable_score_yn,'||wwv_flow.LF||
'     POLL_OR_QUIZ, score_type, start_time,stop_time,invite_only_yn)'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(551) := '  values'||wwv_flow.LF||
'    (2,''Lecture'',''Sample poll that comes installed with the application sample data'',''Pleas';
wwv_flow_imp.g_varchar2_table(552) := 'e take this sample poll.'',''Thanks for taking the sample poll.'',3,'||wwv_flow.LF||
'    ''N'',''N'',''Y'',''Y'',''P'', ''A'',curre';
wwv_flow_imp.g_varchar2_table(553) := 'nt_timestamp,null,''N'');'||wwv_flow.LF||
'     '||wwv_flow.LF||
'     insert into eba_qpoll_questions'||wwv_flow.LF||
'          (id, poll_id, display_s';
wwv_flow_imp.g_varchar2_table(554) := 'equence, question, question_type, mandatory_yn, publish_yn, USE_CUSTOM_ANSWERS_YN,'||wwv_flow.LF||
'              ans';
wwv_flow_imp.g_varchar2_table(555) := 'wer_01,answer_02,answer_03,answer_04,answer_05)'||wwv_flow.LF||
'      values'||wwv_flow.LF||
'         (3,2,10,''How good was the lect';
wwv_flow_imp.g_varchar2_table(556) := 'ure overall?'',''RADIO_GROUP'',''Y'',''Y'',''N'','||wwv_flow.LF||
'             ''Terrible'','||wwv_flow.LF||
'             ''Seen better'','||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(557) := '       ''Average'','||wwv_flow.LF||
'             ''Pretty good'','||wwv_flow.LF||
'             ''Excellent'');'||wwv_flow.LF||
'     insert into eba_qpoll_';
wwv_flow_imp.g_varchar2_table(558) := 'questions'||wwv_flow.LF||
'          (id, poll_id, display_sequence, question, question_type, mandatory_yn, publish_y';
wwv_flow_imp.g_varchar2_table(559) := 'n, USE_CUSTOM_ANSWERS_YN,'||wwv_flow.LF||
'              answer_01,answer_02,answer_03,answer_04,answer_05)'||wwv_flow.LF||
'      val';
wwv_flow_imp.g_varchar2_table(560) := 'ues'||wwv_flow.LF||
'         (4,2,20,''What aspects of the lecture did you like?'',''CHECKBOX'',''N'',''Y'',''Y'','||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(561) := '  ''Presentation'','||wwv_flow.LF||
'             ''Examples'','||wwv_flow.LF||
'             ''Demonstration'','||wwv_flow.LF||
'             ''Questions and';
wwv_flow_imp.g_varchar2_table(562) := ' Answers'','||wwv_flow.LF||
'             ''Other'');'||wwv_flow.LF||
'     insert into eba_qpoll_questions'||wwv_flow.LF||
'          (id, poll_id, displ';
wwv_flow_imp.g_varchar2_table(563) := 'ay_sequence, question, question_type, mandatory_yn, publish_yn, USE_CUSTOM_ANSWERS_YN)'||wwv_flow.LF||
'      values'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(564) := '          (5,2,30,''Did you fall asleep during the lecture?'',''YES_NO'',''N'',''Y'',''N'');'||wwv_flow.LF||
'     insert into ';
wwv_flow_imp.g_varchar2_table(565) := 'eba_qpoll_questions'||wwv_flow.LF||
'          (id, poll_id, display_sequence, question, question_type, mandatory_yn,';
wwv_flow_imp.g_varchar2_table(566) := ' publish_yn, USE_CUSTOM_ANSWERS_YN)'||wwv_flow.LF||
'      values'||wwv_flow.LF||
'          (6,2,40,''How easily could you follow the ';
wwv_flow_imp.g_varchar2_table(567) := 'demonstrations?'',''RANGE_HARD_TO_EASY'',''Y'',''Y'',''N'');'||wwv_flow.LF||
'     insert into eba_qpoll_questions'||wwv_flow.LF||
'          (';
wwv_flow_imp.g_varchar2_table(568) := 'id, poll_id, display_sequence, question, question_type, mandatory_yn, publish_yn, USE_CUSTOM_ANSWERS';
wwv_flow_imp.g_varchar2_table(569) := '_YN)'||wwv_flow.LF||
'      values'||wwv_flow.LF||
'          (7,2,50,''How valuable was the subject matter covered to your current wor';
wwv_flow_imp.g_varchar2_table(570) := 'k?'',''RANGE_VALUE'',''Y'',''Y'',''N'');'||wwv_flow.LF||
'     insert into eba_qpoll_questions'||wwv_flow.LF||
'          (id, poll_id, display';
wwv_flow_imp.g_varchar2_table(571) := '_sequence, question, question_type, mandatory_yn, publish_yn, USE_CUSTOM_ANSWERS_YN)'||wwv_flow.LF||
'      values'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(572) := '        (8,2,60,''How likely are to use what you learnt today outside of the classroom?'',''RANGE_TIMEF';
wwv_flow_imp.g_varchar2_table(573) := 'RAME'',''Y'',''Y'',''N'');'||wwv_flow.LF||
'     insert into eba_qpoll_questions'||wwv_flow.LF||
'          (id, poll_id, display_sequence, q';
wwv_flow_imp.g_varchar2_table(574) := 'uestion, question_type, mandatory_yn, publish_yn, USE_CUSTOM_ANSWERS_YN)'||wwv_flow.LF||
'      values'||wwv_flow.LF||
'          (9,2';
wwv_flow_imp.g_varchar2_table(575) := ',70,''Please outline positive attributes about the lecture'',''TEXTAREA'',''N'',''Y'',''N'');'||wwv_flow.LF||
'     insert into';
wwv_flow_imp.g_varchar2_table(576) := ' eba_qpoll_questions'||wwv_flow.LF||
'          (id, poll_id, display_sequence, question, question_type, mandatory_yn';
wwv_flow_imp.g_varchar2_table(577) := ', publish_yn, USE_CUSTOM_ANSWERS_YN)'||wwv_flow.LF||
'      values'||wwv_flow.LF||
'          (10,2,80,''Please outline areas for impro';
wwv_flow_imp.g_varchar2_table(578) := 'vement for the lecture'',''TEXT'',''N'',''Y'',''N'');'||wwv_flow.LF||
'        '||wwv_flow.LF||
'commit;'||wwv_flow.LF||
'end eba_qpoll_data_load;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure e';
wwv_flow_imp.g_varchar2_table(579) := 'ba_qpoll_remove_data'||wwv_flow.LF||
'as'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    delete from eba_qpoll_polls where id < 5;'||wwv_flow.LF||
'    delete from eba_qpol';
wwv_flow_imp.g_varchar2_table(580) := 'l_questions where id < 5;'||wwv_flow.LF||
'end eba_qpoll_remove_data;'||wwv_flow.LF||
''||wwv_flow.LF||
'      '||wwv_flow.LF||
'end eba_qpoll; '||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16401154936005342375)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll body'
,p_sequence=>510
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
