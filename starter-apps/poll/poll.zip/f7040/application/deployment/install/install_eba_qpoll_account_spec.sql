prompt --application/deployment/install/install_eba_qpoll_account_spec
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_account spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE OR REPLACE PACKAGE "EBA_QPOLL_ACCOUNT" as'||wwv_flow.LF||
'    procedure add_application_log ('||wwv_flow.LF||
'       p_activi';
wwv_flow_imp.g_varchar2_table(2) := 'ty  in  varchar2,'||wwv_flow.LF||
'       p_details   in  varchar2  default null );'||wwv_flow.LF||
'    procedure add_user_log ('||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(3) := '   p_username       in  varchar2,'||wwv_flow.LF||
'       p_email_address  in  varchar2,'||wwv_flow.LF||
'       p_activity       in  ';
wwv_flow_imp.g_varchar2_table(4) := 'varchar2,'||wwv_flow.LF||
'       p_details        in  varchar2  default null );'||wwv_flow.LF||
'    procedure add_user ('||wwv_flow.LF||
'       p_em';
wwv_flow_imp.g_varchar2_table(5) := 'ail_address     in  varchar2,'||wwv_flow.LF||
'       p_email_user_yn     in  varchar2,'||wwv_flow.LF||
'       p_username          in';
wwv_flow_imp.g_varchar2_table(6) := '  varchar2,'||wwv_flow.LF||
'       p_app_id            in  number    default null,'||wwv_flow.LF||
'       p_app_title         in  va';
wwv_flow_imp.g_varchar2_table(7) := 'rchar2  default null,'||wwv_flow.LF||
'       p_app_link          in  varchar2  default null,'||wwv_flow.LF||
'       p_apex_password ';
wwv_flow_imp.g_varchar2_table(8) := '    out varchar2 );'||wwv_flow.LF||
'    procedure approve_access_request ('||wwv_flow.LF||
'       p_app_id           in  number,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(9) := '    p_app_title        in  varchar2,'||wwv_flow.LF||
'       p_app_link         in  varchar2,'||wwv_flow.LF||
'       p_request_id    ';
wwv_flow_imp.g_varchar2_table(10) := '   in  number,'||wwv_flow.LF||
'       p_actioned_reason  in  varchar2  default null );'||wwv_flow.LF||
'    procedure decline_access_';
wwv_flow_imp.g_varchar2_table(11) := 'request ('||wwv_flow.LF||
'       p_app_id           in  number,'||wwv_flow.LF||
'       p_app_title        in  varchar2,'||wwv_flow.LF||
'       p_req';
wwv_flow_imp.g_varchar2_table(12) := 'uest_id       in  number,'||wwv_flow.LF||
'       p_actioned_reason  in  varchar2 );'||wwv_flow.LF||
'end eba_qpoll_account;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13919974905322027064)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_account spec'
,p_sequence=>37
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
