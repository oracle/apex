prompt --application/deployment/install/install_eba_qpoll_sections_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_sections table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE EBA_QPOLL_SECTIONS'||wwv_flow.LF||
'   ('||wwv_flow.LF||
'    ID                    NUMBER not null constraint EBA_QPOLL_';
wwv_flow_imp.g_varchar2_table(2) := 'SECTIONS_PK primary key, '||wwv_flow.LF||
'    POLL_ID               NUMBER not null constraint EBA_QPOLL_SEC_FK'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(3) := '                      references EBA_QPOLL_POLLS(id)'||wwv_flow.LF||
'                          on delete cascade,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(4) := '  ROW_VERSION_NUMBER    NUMBER not null, '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    display_sequence      number,'||wwv_flow.LF||
'    title        ';
wwv_flow_imp.g_varchar2_table(5) := '         VARCHAR2(255) not null, '||wwv_flow.LF||
'    section_text          varchar2(4000), '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    image_filena';
wwv_flow_imp.g_varchar2_table(6) := 'me        VARCHAR2(4000),         '||wwv_flow.LF||
'    image_mimetype        VARCHAR2(512),'||wwv_flow.LF||
'    image_charset       ';
wwv_flow_imp.g_varchar2_table(7) := '  VARCHAR2(512),'||wwv_flow.LF||
'    image_blob            BLOB,'||wwv_flow.LF||
'    image_last_updated    DATE,'||wwv_flow.LF||
'    image_width    ';
wwv_flow_imp.g_varchar2_table(8) := '       number,'||wwv_flow.LF||
'    image_height          number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    CREATED_BY            VARCHAR2(255), '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(9) := '  CREATED               TIMESTAMP WITH TIME ZONE, '||wwv_flow.LF||
'    UPDATED_BY            VARCHAR2(255), '||wwv_flow.LF||
'    UPD';
wwv_flow_imp.g_varchar2_table(10) := 'ATED               TIMESTAMP WITH TIME ZONE'||wwv_flow.LF||
'   )  ;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create index EBA_QPOLL_SECTIONS_i1 on EBA_QPOL';
wwv_flow_imp.g_varchar2_table(11) := 'L_SECTIONS(POLL_ID);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER EBA_QPOLL_SECTIONS_BIU'||wwv_flow.LF||
'   before insert or update o';
wwv_flow_imp.g_varchar2_table(12) := 'n EBA_QPOLL_SECTIONS'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is null then'||wwv_flow.LF||
'      :new.id := to_number(sys';
wwv_flow_imp.g_varchar2_table(13) := '_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := ';
wwv_flow_imp.g_varchar2_table(14) := 'current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := curre';
wwv_flow_imp.g_varchar2_table(15) := 'nt_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number :=';
wwv_flow_imp.g_varchar2_table(16) := ' 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(17) := 'end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updat';
wwv_flow_imp.g_varchar2_table(18) := 'ed_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'ALTER TRIGGER EBA_QPOLL_SECTIONS_BIU ENABLE;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13041788943563946897)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_sections table'
,p_sequence=>135
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
