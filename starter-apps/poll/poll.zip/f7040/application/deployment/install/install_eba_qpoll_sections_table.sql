prompt --application/deployment/install/install_eba_qpoll_sections_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_sections table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13041788943563946897)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_sections table'
,p_sequence=>135
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE EBA_QPOLL_SECTIONS',
'   (',
'    ID                    NUMBER not null constraint EBA_QPOLL_SECTIONS_PK primary key, ',
'    POLL_ID               NUMBER not null constraint EBA_QPOLL_SEC_FK',
'                          references EBA_QPOLL_POLLS(id)',
'                          on delete cascade,',
'    ROW_VERSION_NUMBER    NUMBER not null, ',
'    --',
'    display_sequence      number,',
'    title                 VARCHAR2(255) not null, ',
'    section_text          varchar2(4000), ',
'    --',
'    image_filename        VARCHAR2(4000),         ',
'    image_mimetype        VARCHAR2(512),',
'    image_charset         VARCHAR2(512),',
'    image_blob            BLOB,',
'    image_last_updated    DATE,',
'    image_width           number,',
'    image_height          number,',
'    --',
'    CREATED_BY            VARCHAR2(255), ',
'    CREATED               TIMESTAMP WITH TIME ZONE, ',
'    UPDATED_BY            VARCHAR2(255), ',
'    UPDATED               TIMESTAMP WITH TIME ZONE',
'   )  ;',
'',
'',
'create index EBA_QPOLL_SECTIONS_i1 on EBA_QPOLL_SECTIONS(POLL_ID);',
'',
'',
'CREATE OR REPLACE TRIGGER EBA_QPOLL_SECTIONS_BIU',
'   before insert or update on EBA_QPOLL_SECTIONS',
'   for each row',
'begin',
'   if :new.ID is null then',
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');',
'   end if;',
'   if inserting then',
'       :new.created := current_timestamp;',
'       :new.created_by := nvl(wwv_flow.g_user,user);',
'       :new.updated := current_timestamp;',
'       :new.updated_by := nvl(wwv_flow.g_user,user);',
'       :new.row_version_number := 1;',
'   elsif updating then',
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;',
'   end if;',
'   if inserting or updating then',
'       :new.updated := current_timestamp;',
'       :new.updated_by := nvl(wwv_flow.g_user,user);',
'   end if; ',
'end;',
'/',
'ALTER TRIGGER EBA_QPOLL_SECTIONS_BIU ENABLE;',
''))
);
wwv_flow_imp.component_end;
end;
/
