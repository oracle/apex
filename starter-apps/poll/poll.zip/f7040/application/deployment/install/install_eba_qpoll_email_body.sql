prompt --application/deployment/install/install_eba_qpoll_email_body
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_email body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body eba_qpoll_email as'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure send ('||wwv_flow.LF||
'   p_app_id              in   nu';
wwv_flow_imp.g_varchar2_table(2) := 'mber,'||wwv_flow.LF||
'   p_template_static_id  in   varchar2,'||wwv_flow.LF||
'   p_placeholders        in   clob,'||wwv_flow.LF||
'   p_to           ';
wwv_flow_imp.g_varchar2_table(3) := '       in   varchar2,'||wwv_flow.LF||
'   p_from                in   varchar2,'||wwv_flow.LF||
'   p_cc                  in   varchar2';
wwv_flow_imp.g_varchar2_table(4) := '  default null,'||wwv_flow.LF||
'   p_poll_id             in   number    default null,'||wwv_flow.LF||
'   p_community_id        in   ';
wwv_flow_imp.g_varchar2_table(5) := 'number    default null,'||wwv_flow.LF||
'   p_respondent_id       in   number    default null,'||wwv_flow.LF||
'   p_email_id         ';
wwv_flow_imp.g_varchar2_table(6) := '   out  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'   l_subject            varchar2(4000);'||wwv_flow.LF||
'   l_html_body          clob;'||wwv_flow.LF||
'   l_text_';
wwv_flow_imp.g_varchar2_table(7) := 'body          clob;'||wwv_flow.LF||
'   l_apex_email_id      number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'   apex_application.g_flow_id := p_app_id';
wwv_flow_imp.g_varchar2_table(8) := ';'||wwv_flow.LF||
'   for c1 in ('||wwv_flow.LF||
'      select workspace, workspace_id'||wwv_flow.LF||
'        from apex_applications'||wwv_flow.LF||
'       where ap';
wwv_flow_imp.g_varchar2_table(9) := 'plication_id = p_app_id'||wwv_flow.LF||
'   ) loop'||wwv_flow.LF||
'      apex_util.set_workspace (p_workspace => c1.workspace);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(10) := ' apex_util.set_security_group_id (p_security_group_id => c1.workspace_id);'||wwv_flow.LF||
'   end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'   insert i';
wwv_flow_imp.g_varchar2_table(11) := 'nto eba_qpoll_emails'||wwv_flow.LF||
'      (template_static_id, placeholders, sent_to, sent_by, cc,'||wwv_flow.LF||
'       poll_id, ';
wwv_flow_imp.g_varchar2_table(12) := 'community_id, respondent_id)'||wwv_flow.LF||
'   values'||wwv_flow.LF||
'      (p_template_static_id, p_placeholders, p_to, p_from, p_';
wwv_flow_imp.g_varchar2_table(13) := 'cc,'||wwv_flow.LF||
'       p_poll_id, p_community_id, p_respondent_id)'||wwv_flow.LF||
'   returning id into p_email_id;'||wwv_flow.LF||
'   commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(14) := '   apex_mail.prepare_template ('||wwv_flow.LF||
'      p_static_id       => p_template_static_id,'||wwv_flow.LF||
'      p_placeholder';
wwv_flow_imp.g_varchar2_table(15) := 's    => p_placeholders,'||wwv_flow.LF||
'      p_application_id  => p_app_id,'||wwv_flow.LF||
'      p_subject         => l_subject,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(16) := '     p_html            => l_html_body,'||wwv_flow.LF||
'      p_text            => l_text_body );'||wwv_flow.LF||
''||wwv_flow.LF||
'   update eba_qpol';
wwv_flow_imp.g_varchar2_table(17) := 'l_emails'||wwv_flow.LF||
'      set subject   = l_subject,'||wwv_flow.LF||
'          text_body = l_text_body,'||wwv_flow.LF||
'          html_body = l';
wwv_flow_imp.g_varchar2_table(18) := '_html_body'||wwv_flow.LF||
'    where id = p_email_id;'||wwv_flow.LF||
'   commit;'||wwv_flow.LF||
'   '||wwv_flow.LF||
'   l_apex_email_id := apex_mail.send ('||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(19) := '                 p_to        => p_to,'||wwv_flow.LF||
'                         p_from      => p_from,'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(20) := '           p_cc        => p_cc,'||wwv_flow.LF||
'                         p_replyto   => replace(eba_qpoll_fw.get_pre';
wwv_flow_imp.g_varchar2_table(21) := 'ference_value(''NOTIFICATION_EMAIL_REPLY_TO''), ''N/A'', null),'||wwv_flow.LF||
'                         p_body      => ';
wwv_flow_imp.g_varchar2_table(22) := 'l_text_body,'||wwv_flow.LF||
'                         p_body_html => l_html_body,'||wwv_flow.LF||
'                         p_subj   ';
wwv_flow_imp.g_varchar2_table(23) := '   => l_subject );'||wwv_flow.LF||
''||wwv_flow.LF||
'   apex_mail.push_queue;'||wwv_flow.LF||
''||wwv_flow.LF||
'   for c1 in ('||wwv_flow.LF||
'      select mail_send_error'||wwv_flow.LF||
'        fr';
wwv_flow_imp.g_varchar2_table(24) := 'om apex_mail_queue'||wwv_flow.LF||
'       where id = l_apex_email_id'||wwv_flow.LF||
'         and mail_send_error is not null'||wwv_flow.LF||
'   ) l';
wwv_flow_imp.g_varchar2_table(25) := 'oop'||wwv_flow.LF||
'      update eba_qpoll_emails'||wwv_flow.LF||
'         set email_status = ''FAILURE'','||wwv_flow.LF||
'             error_message ';
wwv_flow_imp.g_varchar2_table(26) := '= c1.mail_send_error'||wwv_flow.LF||
'       where id = p_email_id;'||wwv_flow.LF||
'      commit;'||wwv_flow.LF||
'   end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'   for c1 in ('||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(27) := 'select email_status'||wwv_flow.LF||
'        from eba_qpoll_emails'||wwv_flow.LF||
'       where id = p_email_id'||wwv_flow.LF||
'   ) loop'||wwv_flow.LF||
'      if c1';
wwv_flow_imp.g_varchar2_table(28) := '.email_status is null then'||wwv_flow.LF||
'         update eba_qpoll_emails'||wwv_flow.LF||
'            set email_status = ''SUCCESS''';
wwv_flow_imp.g_varchar2_table(29) := ''||wwv_flow.LF||
'          where id = p_email_id;'||wwv_flow.LF||
'         commit;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end loop;'||wwv_flow.LF||
'end send;'||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_qpo';
wwv_flow_imp.g_varchar2_table(30) := 'll_email;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13919921326748904256)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_email body'
,p_sequence=>530
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
