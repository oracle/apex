prompt --application/deployment/install/install_eba_qpoll_user_log_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_user_log table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_qpoll_user_log'||wwv_flow.LF||
'('||wwv_flow.LF||
'   id             number not null enable, '||wwv_flow.LF||
'   username       varch';
wwv_flow_imp.g_varchar2_table(2) := 'ar2(255),'||wwv_flow.LF||
'   email_address  varchar2(255) not null enable, '||wwv_flow.LF||
'   activity       varchar2(255) not null';
wwv_flow_imp.g_varchar2_table(3) := ' enable, '||wwv_flow.LF||
'   details        varchar2(4000), '||wwv_flow.LF||
'   created        timestamp (6) with time zone not null';
wwv_flow_imp.g_varchar2_table(4) := ' enable, '||wwv_flow.LF||
'   created_trunc  date not null enable, '||wwv_flow.LF||
'   created_by     varchar2(255) not null enable, ';
wwv_flow_imp.g_varchar2_table(5) := ''||wwv_flow.LF||
'   constraint eba_qpoll_user_log_pk primary key (id) using index  enable'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_qpoll';
wwv_flow_imp.g_varchar2_table(6) := '_user_log_i1 on eba_qpoll_user_log (created_trunc);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_qpoll_user_log_bi';
wwv_flow_imp.g_varchar2_table(7) := ' '||wwv_flow.LF||
'   before insert on eba_qpoll_user_log'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.id is null then'||wwv_flow.LF||
'      :new';
wwv_flow_imp.g_varchar2_table(8) := '.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.email_address :=';
wwv_flow_imp.g_varchar2_table(9) := ' lower(:new.email_address);'||wwv_flow.LF||
'   :new.created       := current_timestamp;'||wwv_flow.LF||
'   :new.created_trunc := tru';
wwv_flow_imp.g_varchar2_table(10) := 'nc(current_timestamp);'||wwv_flow.LF||
'   :new.created_by    := lower(nvl(wwv_flow.g_user,user));'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trig';
wwv_flow_imp.g_varchar2_table(11) := 'ger eba_qpoll_user_log_bi enable;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13919884617689379657)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_user_log table'
,p_sequence=>310
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
