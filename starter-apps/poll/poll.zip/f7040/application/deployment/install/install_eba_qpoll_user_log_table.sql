prompt --application/deployment/install/install_eba_qpoll_user_log_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_user_log table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>17112839606727645
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13919884617689379657)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_user_log table'
,p_sequence=>310
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table eba_qpoll_user_log',
'(',
'   id             number not null enable, ',
'   username       varchar2(255),',
'   email_address  varchar2(255) not null enable, ',
'   activity       varchar2(255) not null enable, ',
'   details        varchar2(4000), ',
'   created        timestamp (6) with time zone not null enable, ',
'   created_trunc  date not null enable, ',
'   created_by     varchar2(255) not null enable, ',
'   constraint eba_qpoll_user_log_pk primary key (id) using index  enable',
');',
'',
'create index eba_qpoll_user_log_i1 on eba_qpoll_user_log (created_trunc);',
'',
'create or replace trigger eba_qpoll_user_log_bi ',
'   before insert on eba_qpoll_user_log',
'   for each row',
'begin',
'   if :new.id is null then',
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');',
'   end if;',
'   :new.email_address := lower(:new.email_address);',
'   :new.created       := current_timestamp;',
'   :new.created_trunc := trunc(current_timestamp);',
'   :new.created_by    := lower(nvl(wwv_flow.g_user,user));',
'end;',
'/',
'',
'alter trigger eba_qpoll_user_log_bi enable;'))
);
wwv_flow_imp.component_end;
end;
/
