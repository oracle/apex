prompt --application/deployment/install/install_eba_qpoll_access_requests_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_access_requests table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE  EBA_QPOLL_ACCESS_REQUESTS '||wwv_flow.LF||
'   ('||wwv_flow.LF||
'    ID                    NUMBER NOT NULL ENABLE, '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(2) := ' ROW_VERSION_NUMBER    NUMBER not null, '||wwv_flow.LF||
'    USERNAME              VARCHAR2(255), '||wwv_flow.LF||
'    EMAIL_ADDRESS';
wwv_flow_imp.g_varchar2_table(3) := '         VARCHAR2(255) NOT NULL ENABLE, '||wwv_flow.LF||
'    JUSTIFICATION         VARCHAR2(4000) NOT NULL ENABLE, '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(4) := '    CREATED_TRUNC         DATE NOT NULL ENABLE, '||wwv_flow.LF||
'    STATUS                VARCHAR2(255) NOT NULL EN';
wwv_flow_imp.g_varchar2_table(5) := 'ABLE, '||wwv_flow.LF||
'    ACTIONED_BY           VARCHAR2(255), '||wwv_flow.LF||
'    ACTIONED_REASON       VARCHAR2(4000), '||wwv_flow.LF||
'    CREA';
wwv_flow_imp.g_varchar2_table(6) := 'TED               TIMESTAMP (6) WITH TIME ZONE NOT NULL ENABLE, '||wwv_flow.LF||
'    CREATED_BY            VARCHAR2(';
wwv_flow_imp.g_varchar2_table(7) := '255) NOT NULL ENABLE, '||wwv_flow.LF||
'    UPDATED               TIMESTAMP (6) WITH TIME ZONE NOT NULL ENABLE, '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(8) := 'UPDATED_BY            VARCHAR2(255) NOT NULL ENABLE, '||wwv_flow.LF||
'     CONSTRAINT EBA_QPOLL_ACCESS_REQ_CC1 CHECK';
wwv_flow_imp.g_varchar2_table(9) := ' (status in (''pending'',''approved'',''declined'')) ENABLE, '||wwv_flow.LF||
'     CONSTRAINT EBA_QPOLL_ACCESS_REQ_PK PRIM';
wwv_flow_imp.g_varchar2_table(10) := 'ARY KEY (ID) USING INDEX  ENABLE'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE INDEX  EBA_QPOLL_ACCESS_REQ_I1 ON  EBA_QPOLL_ACCESS_';
wwv_flow_imp.g_varchar2_table(11) := 'REQUESTS (STATUS)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE  TRIGGER  EBA_QPOLL_ACCESS_REQ_BIU '||wwv_flow.LF||
'   before insert or updat';
wwv_flow_imp.g_varchar2_table(12) := 'e on '||wwv_flow.LF||
'   EBA_QPOLL_ACCESS_REQUESTS '||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.id is null then'||wwv_flow.LF||
'      :new.id :';
wwv_flow_imp.g_varchar2_table(13) := '= to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.email_address := lowe';
wwv_flow_imp.g_varchar2_table(14) := 'r(:new.email_address);'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'      :new.created    := current_timestamp;'||wwv_flow.LF||
'      :new.c';
wwv_flow_imp.g_varchar2_table(15) := 'reated_by := lower(nvl(v(''APP_USER''),user));'||wwv_flow.LF||
'      :new.created_trunc := trunc(current_timestamp);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(16) := '  end if;'||wwv_flow.LF||
'   :new.row_version_number := nvl(:old.row_version_number,0) + 1;'||wwv_flow.LF||
''||wwv_flow.LF||
'   :new.updated     := ';
wwv_flow_imp.g_varchar2_table(17) := 'current_timestamp;'||wwv_flow.LF||
'   :new.updated_by  := lower(nvl(v(''APP_USER''),user));'||wwv_flow.LF||
''||wwv_flow.LF||
'   if updating and :old.s';
wwv_flow_imp.g_varchar2_table(18) := 'tatus != :new.status then'||wwv_flow.LF||
'      :new.actioned_by := lower(nvl(v(''APP_USER''),user));'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(19) := '/'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TRIGGER  EBA_QPOLL_ACCESS_REQ_BIU ENABLE;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13918397026357895729)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_access_requests table'
,p_sequence=>350
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
