prompt --application/deployment/install/install_eba_qpoll_account_body
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_account body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE OR REPLACE PACKAGE BODY "EBA_QPOLL_ACCOUNT" as'||wwv_flow.LF||
''||wwv_flow.LF||
'    c_pwd_len constant number := 8;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(2) := 'procedure add_application_log ('||wwv_flow.LF||
'       p_activity  in  varchar2,'||wwv_flow.LF||
'       p_details   in  varchar2  de';
wwv_flow_imp.g_varchar2_table(3) := 'fault null )'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'       -- remove old entries'||wwv_flow.LF||
'       delete from eba_qpoll_application_';
wwv_flow_imp.g_varchar2_table(4) := 'log where created <= current_timestamp - 21;'||wwv_flow.LF||
'       -- add new entry'||wwv_flow.LF||
'       insert into eba_qpoll_ap';
wwv_flow_imp.g_varchar2_table(5) := 'plication_log'||wwv_flow.LF||
'          (activity, details)'||wwv_flow.LF||
'       values'||wwv_flow.LF||
'          (p_activity, p_details);'||wwv_flow.LF||
'    exc';
wwv_flow_imp.g_varchar2_table(6) := 'eption when others then'||wwv_flow.LF||
'        eba_qpoll_fw.add_error_log('||wwv_flow.LF||
'                       p_error => null,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(7) := '                       p_procedure_name  => ''add_application_log'','||wwv_flow.LF||
'                       p_error_te';
wwv_flow_imp.g_varchar2_table(8) := 'xt => sqlerrm,'||wwv_flow.LF||
'                       p_arg1_name => ''p_activity'','||wwv_flow.LF||
'                       p_arg1_val';
wwv_flow_imp.g_varchar2_table(9) := ' => p_activity,'||wwv_flow.LF||
'                       p_arg2_name => ''p_details'','||wwv_flow.LF||
'                       p_arg2_val';
wwv_flow_imp.g_varchar2_table(10) := ' => p_details);'||wwv_flow.LF||
'    end add_application_log;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    procedure add_user_log ('||wwv_flow.LF||
'       p_username    ';
wwv_flow_imp.g_varchar2_table(11) := '   in  varchar2,'||wwv_flow.LF||
'       p_email_address  in  varchar2,'||wwv_flow.LF||
'       p_activity       in  varchar2,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(12) := 'p_details        in  varchar2  default null )'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'       -- remove old entries'||wwv_flow.LF||
'       d';
wwv_flow_imp.g_varchar2_table(13) := 'elete from eba_qpoll_user_log where created <= current_timestamp - 21;'||wwv_flow.LF||
'       -- add new entry'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(14) := '  insert into eba_qpoll_user_log'||wwv_flow.LF||
'          (username, email_address, activity, details)'||wwv_flow.LF||
'       value';
wwv_flow_imp.g_varchar2_table(15) := 's'||wwv_flow.LF||
'          (p_username, p_email_address, p_activity, p_details);'||wwv_flow.LF||
'    exception when others then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(16) := '     eba_qpoll_fw.add_error_log('||wwv_flow.LF||
'                       p_error => null,'||wwv_flow.LF||
'                       p_pr';
wwv_flow_imp.g_varchar2_table(17) := 'ocedure_name  => ''add_user_log'','||wwv_flow.LF||
'                       p_error_text => sqlerrm,'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(18) := '    p_arg1_name => ''p_username'','||wwv_flow.LF||
'                       p_arg1_val => p_username,'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(19) := '     p_arg2_name => ''p_email_address'','||wwv_flow.LF||
'                       p_arg2_val => p_email_address,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(20) := '                p_arg3_name => ''p_activity'','||wwv_flow.LF||
'                       p_arg3_val => p_activity,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(21) := '                 p_arg4_name => ''p_details'','||wwv_flow.LF||
'                       p_arg4_val => p_details);'||wwv_flow.LF||
'    en';
wwv_flow_imp.g_varchar2_table(22) := 'd add_user_log;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    function rand_max('||wwv_flow.LF||
'        n in number )'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'    begin';
wwv_flow_imp.g_varchar2_table(23) := ''||wwv_flow.LF||
'        return mod( abs(dbms_random.random), n ) + 1;'||wwv_flow.LF||
'    end rand_max;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    function get_rando';
wwv_flow_imp.g_varchar2_table(24) := 'm_password ('||wwv_flow.LF||
'        p_length          in number )'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_consonan';
wwv_flow_imp.g_varchar2_table(25) := 'ts  varchar2(30) := ''bcdfghjklmnpqrstvwxyz'';'||wwv_flow.LF||
'        l_vowels      varchar2(30) := ''aeiou'';'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(26) := 'l_digits      varchar2(10) := ''0123456789'';'||wwv_flow.LF||
'        l_punctuation varchar2(10) := ''$&@!*'';'||wwv_flow.LF||
'        l';
wwv_flow_imp.g_varchar2_table(27) := '_str         varchar2(38);'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        for i in 1 .. p_length-2'||wwv_flow.LF||
'        loop'||wwv_flow.LF||
'            if mo';
wwv_flow_imp.g_varchar2_table(28) := 'd(i,2) = 0 then'||wwv_flow.LF||
'                l_str := l_str || substr(l_vowels,'||wwv_flow.LF||
'                                 ';
wwv_flow_imp.g_varchar2_table(29) := '  rand_max(length(l_vowels)),'||wwv_flow.LF||
'                                   1);'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(30) := '  l_str := l_str || substr(l_consonants,'||wwv_flow.LF||
'                                   rand_max(length(l_conson';
wwv_flow_imp.g_varchar2_table(31) := 'ants)),'||wwv_flow.LF||
'                                   1);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'      --l_str := ';
wwv_flow_imp.g_varchar2_table(32) := 'l_str || substr(l_punctuation, rand_max(length(l_punctuation)), 1);'||wwv_flow.LF||
'      l_str := l_str || substr(l';
wwv_flow_imp.g_varchar2_table(33) := '_digits, rand_max(length(l_digits)), 1);'||wwv_flow.LF||
'      l_str := l_str || substr(l_consonants, rand_max(lengt';
wwv_flow_imp.g_varchar2_table(34) := 'h(l_consonants)),1);'||wwv_flow.LF||
'      return l_str;'||wwv_flow.LF||
'    end get_random_password;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    procedure email_user_';
wwv_flow_imp.g_varchar2_table(35) := 'rejection ('||wwv_flow.LF||
'       p_app_id          in  number,'||wwv_flow.LF||
'       p_app_title       in  varchar2,'||wwv_flow.LF||
'       p_ema';
wwv_flow_imp.g_varchar2_table(36) := 'il_to        in  varchar2,'||wwv_flow.LF||
'       p_action_reason   in  varchar2 )'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'       l_email_id      num';
wwv_flow_imp.g_varchar2_table(37) := 'ber;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'      '||wwv_flow.LF||
'       eba_qpoll_email.send ('||wwv_flow.LF||
'          p_app_id             => p_app_id,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(38) := '      p_template_static_id => ''ACCESS_REQUEST_DECLINED'','||wwv_flow.LF||
'          p_placeholders       => ''{'' || '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(39) := '                                 ''    "ACTION_REASON":''     || apex_json.stringify( p_action_reason ';
wwv_flow_imp.g_varchar2_table(40) := ') || '||wwv_flow.LF||
'                                  ''   ,"APPLICATION_TITLE":'' || apex_json.stringify( p_app_tit';
wwv_flow_imp.g_varchar2_table(41) := 'le ) ||'||wwv_flow.LF||
'                                      ''}'' , '||wwv_flow.LF||
'          p_to                 => p_email_to,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(42) := '         p_from               => eba_qpoll_fw.get_preference_value(''NOTIFICATION_EMAIL_FROM''),'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(43) := '     p_email_id           => l_email_id );'||wwv_flow.LF||
'          '||wwv_flow.LF||
'    exception'||wwv_flow.LF||
'        when others then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(44) := '     raise;'||wwv_flow.LF||
'    end email_user_rejection;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    procedure email_user_creds ('||wwv_flow.LF||
'       p_email_to   ';
wwv_flow_imp.g_varchar2_table(45) := '    in  varchar2,'||wwv_flow.LF||
'       p_app_id         in  number,'||wwv_flow.LF||
'       p_app_title      in  varchar2,'||wwv_flow.LF||
'       p';
wwv_flow_imp.g_varchar2_table(46) := '_app_link       in  varchar2,'||wwv_flow.LF||
'       p_username       in  varchar2,'||wwv_flow.LF||
'       p_apex_password  in  varc';
wwv_flow_imp.g_varchar2_table(47) := 'har2 )'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'       l_email_id      number;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
''||wwv_flow.LF||
'      eba_qpoll_email.send ('||wwv_flow.LF||
'          p_app';
wwv_flow_imp.g_varchar2_table(48) := '_id             => p_app_id,'||wwv_flow.LF||
'          p_template_static_id => case when p_apex_password is not null';
wwv_flow_imp.g_varchar2_table(49) := ' '||wwv_flow.LF||
'                                       then ''ACCESS_REQUEST_APPROVED_WITH_PASSWORD'''||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(50) := '                         else ''ACCESS_REQUEST_APPROVED_WITHOUT_PASSWORD'''||wwv_flow.LF||
'                           ';
wwv_flow_imp.g_varchar2_table(51) := '            end,'||wwv_flow.LF||
'          p_placeholders       => ''{'' || '||wwv_flow.LF||
'                                  ''    "U';
wwv_flow_imp.g_varchar2_table(52) := 'SERNAME":''     || apex_json.stringify( p_username ) || '||wwv_flow.LF||
'                                  case when ';
wwv_flow_imp.g_varchar2_table(53) := 'p_apex_password is not null then'||wwv_flow.LF||
'                                  ''   ,"APEX_PASSWORD":''     || ape';
wwv_flow_imp.g_varchar2_table(54) := 'x_json.stringify( p_apex_password ) end || '||wwv_flow.LF||
'                                  ''   ,"APPLICATION_TITL';
wwv_flow_imp.g_varchar2_table(55) := 'E":'' || apex_json.stringify( p_app_title ) ||'||wwv_flow.LF||
'                                  ''   ,"APP_LINK":'' ||';
wwv_flow_imp.g_varchar2_table(56) := ' apex_json.stringify( p_app_link ) ||'||wwv_flow.LF||
'                                      ''}'' , '||wwv_flow.LF||
'          p_to   ';
wwv_flow_imp.g_varchar2_table(57) := '              => p_email_to,'||wwv_flow.LF||
'          p_from               => eba_qpoll_fw.get_preference_value(''NO';
wwv_flow_imp.g_varchar2_table(58) := 'TIFICATION_EMAIL_FROM''),'||wwv_flow.LF||
'          p_email_id           => l_email_id );'||wwv_flow.LF||
'      '||wwv_flow.LF||
'    exception'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(59) := '  when others then'||wwv_flow.LF||
'            raise;'||wwv_flow.LF||
'    end email_user_creds;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    procedure add_user ('||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(60) := ' p_email_address     in  varchar2,'||wwv_flow.LF||
'       p_email_user_yn     in  varchar2,'||wwv_flow.LF||
'       p_username       ';
wwv_flow_imp.g_varchar2_table(61) := '   in  varchar2,'||wwv_flow.LF||
'       p_app_id            in  number    default null,'||wwv_flow.LF||
'       p_app_title         i';
wwv_flow_imp.g_varchar2_table(62) := 'n  varchar2  default null,'||wwv_flow.LF||
'       p_app_link          in  varchar2  default null,'||wwv_flow.LF||
'       p_apex_pass';
wwv_flow_imp.g_varchar2_table(63) := 'word     out varchar2 )'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'       l_apex_admin       varchar2(30) := ''not found'';'||wwv_flow.LF||
'       l_user_';
wwv_flow_imp.g_varchar2_table(64) := 'id                       number;'||wwv_flow.LF||
'       l_workspace                     varchar2(255);'||wwv_flow.LF||
'       l_user';
wwv_flow_imp.g_varchar2_table(65) := '_name                     varchar2(100);'||wwv_flow.LF||
'       l_first_name                    varchar2(255);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(66) := '  l_last_name                     varchar2(255);'||wwv_flow.LF||
'       l_web_password                  varchar2(255';
wwv_flow_imp.g_varchar2_table(67) := ');'||wwv_flow.LF||
'       l_email_address                 varchar2(240);'||wwv_flow.LF||
'       l_start_date                    date';
wwv_flow_imp.g_varchar2_table(68) := ';'||wwv_flow.LF||
'       l_end_date                      date;'||wwv_flow.LF||
'       l_employee_id                   number(15,0);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(69) := '       l_allow_access_to_schemas       varchar2(4000);'||wwv_flow.LF||
'       l_person_type                   varcha';
wwv_flow_imp.g_varchar2_table(70) := 'r2(1);'||wwv_flow.LF||
'       l_default_schema                varchar2(30);'||wwv_flow.LF||
'       l_groups                        v';
wwv_flow_imp.g_varchar2_table(71) := 'archar2(1000);'||wwv_flow.LF||
'       l_developer_role                varchar2(60);'||wwv_flow.LF||
'       l_description            ';
wwv_flow_imp.g_varchar2_table(72) := '       varchar2(240);'||wwv_flow.LF||
'       l_account_expiry                date;'||wwv_flow.LF||
'       l_account_locked          ';
wwv_flow_imp.g_varchar2_table(73) := '      varchar2(1);'||wwv_flow.LF||
'       l_failed_access_attempts        number;'||wwv_flow.LF||
'       l_change_password_on_first_';
wwv_flow_imp.g_varchar2_table(74) := 'use  varchar2(1);'||wwv_flow.LF||
'       l_first_password_use_occurred   varchar2(1);'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'       -- Create new';
wwv_flow_imp.g_varchar2_table(75) := ' accounts with Contributor role'||wwv_flow.LF||
'       APEX_ACL.ADD_USER_ROLE ('||wwv_flow.LF||
'          p_application_id => p_app_';
wwv_flow_imp.g_varchar2_table(76) := 'id,'||wwv_flow.LF||
'          p_user_name      => nvl(p_username,p_email_address),'||wwv_flow.LF||
'          p_role_static_id => ''CO';
wwv_flow_imp.g_varchar2_table(77) := 'NTRIBUTOR'' );'||wwv_flow.LF||
'       -- if app using APEX Authentication, create APEX user, if necessary'||wwv_flow.LF||
'       for ';
wwv_flow_imp.g_varchar2_table(78) := 'c2 in ('||wwv_flow.LF||
'          select null'||wwv_flow.LF||
'            from apex_applications'||wwv_flow.LF||
'           where application_id = p';
wwv_flow_imp.g_varchar2_table(79) := '_app_id'||wwv_flow.LF||
'             and authentication_scheme_type = ''Application Express Accounts'''||wwv_flow.LF||
'       ) loop'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(80) := '         for c3 in ('||wwv_flow.LF||
'             select is_admin'||wwv_flow.LF||
'               from apex_workspace_apex_users'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(81) := '          where user_name = upper(nvl(p_username,p_email_address))'||wwv_flow.LF||
'          ) loop'||wwv_flow.LF||
'             l_a';
wwv_flow_imp.g_varchar2_table(82) := 'pex_admin := c3.is_admin;'||wwv_flow.LF||
'          end loop;'||wwv_flow.LF||
'          if l_apex_admin = ''not found'' then'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(83) := '    p_apex_password := get_random_password( c_pwd_len );'||wwv_flow.LF||
'             apex_util.create_user ('||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(84) := '          p_user_name     => upper(nvl(p_username,p_email_address)),'||wwv_flow.LF||
'                p_first_name   ';
wwv_flow_imp.g_varchar2_table(85) := ' => l_first_name,'||wwv_flow.LF||
'                p_last_name     => l_last_name,'||wwv_flow.LF||
'                p_email_address =>';
wwv_flow_imp.g_varchar2_table(86) := ' lower(p_email_address),'||wwv_flow.LF||
'                p_developer_privs => null,'||wwv_flow.LF||
'                p_change_passwor';
wwv_flow_imp.g_varchar2_table(87) := 'd_on_first_use => ''N'','||wwv_flow.LF||
'                p_web_password  => p_apex_password,'||wwv_flow.LF||
'                p_descrip';
wwv_flow_imp.g_varchar2_table(88) := 'tion   => ''Created by ''|| v(''APPLICATION_TITLE'') ||''.'' );'||wwv_flow.LF||
'          elsif l_apex_admin = ''No'' then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(89) := '            l_user_id := apex_util.get_user_id(upper(nvl(p_username,p_email_address)));'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(90) := ' apex_util.fetch_user ('||wwv_flow.LF||
'                p_user_id                       => l_user_id,'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(91) := '  p_workspace                     => l_workspace,'||wwv_flow.LF||
'                p_user_name                     =>';
wwv_flow_imp.g_varchar2_table(92) := ' l_email_address,'||wwv_flow.LF||
'                p_first_name                    => l_first_name,'||wwv_flow.LF||
'                p';
wwv_flow_imp.g_varchar2_table(93) := '_last_name                     => l_last_name,'||wwv_flow.LF||
'                p_web_password                  => l_';
wwv_flow_imp.g_varchar2_table(94) := 'web_password,'||wwv_flow.LF||
'                p_email_address                 => l_email_address,'||wwv_flow.LF||
'                p_';
wwv_flow_imp.g_varchar2_table(95) := 'start_date                    => l_start_date,'||wwv_flow.LF||
'                p_end_date                      => l_';
wwv_flow_imp.g_varchar2_table(96) := 'end_date,'||wwv_flow.LF||
'                p_employee_id                   => l_employee_id,'||wwv_flow.LF||
'                p_allow_';
wwv_flow_imp.g_varchar2_table(97) := 'access_to_schemas       => l_allow_access_to_schemas,'||wwv_flow.LF||
'                p_person_type                 ';
wwv_flow_imp.g_varchar2_table(98) := '  => l_person_type,'||wwv_flow.LF||
'                p_default_schema                => l_default_schema,'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(99) := '     p_groups                        => l_groups,'||wwv_flow.LF||
'                p_developer_role                =>';
wwv_flow_imp.g_varchar2_table(100) := ' l_developer_role,'||wwv_flow.LF||
'                p_description                   => l_description,'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(101) := ' p_account_expiry                => l_account_expiry,'||wwv_flow.LF||
'                p_account_locked              ';
wwv_flow_imp.g_varchar2_table(102) := '  => l_account_locked,'||wwv_flow.LF||
'                p_failed_access_attempts        => l_failed_access_attempts,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(103) := '                p_change_password_on_first_use  => l_change_password_on_first_use,'||wwv_flow.LF||
'                p';
wwv_flow_imp.g_varchar2_table(104) := '_first_password_use_occurred   => l_first_password_use_occurred );'||wwv_flow.LF||
'             apex_util.edit_user ';
wwv_flow_imp.g_varchar2_table(105) := '('||wwv_flow.LF||
'                p_user_id                       => l_user_id,'||wwv_flow.LF||
'                p_user_name         ';
wwv_flow_imp.g_varchar2_table(106) := '            => upper(nvl(p_username,p_email_address)),'||wwv_flow.LF||
'                p_first_name                 ';
wwv_flow_imp.g_varchar2_table(107) := '   => l_first_name,'||wwv_flow.LF||
'                p_last_name                     => l_last_name,'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(108) := 'p_web_password                  => l_web_password,'||wwv_flow.LF||
'                p_new_password                  =';
wwv_flow_imp.g_varchar2_table(109) := '> l_web_password,'||wwv_flow.LF||
'                p_email_address                 => lower(p_email_address),'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(110) := '         p_start_date                    => l_start_date,'||wwv_flow.LF||
'                p_end_date                ';
wwv_flow_imp.g_varchar2_table(111) := '      => l_end_date,'||wwv_flow.LF||
'                p_employee_id                   => l_employee_id,'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(112) := '   p_allow_access_to_schemas       => l_allow_access_to_schemas,'||wwv_flow.LF||
'                p_person_type      ';
wwv_flow_imp.g_varchar2_table(113) := '             => l_person_type,'||wwv_flow.LF||
'                p_default_schema                => l_default_schema,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(114) := '                p_group_ids                     => l_groups,'||wwv_flow.LF||
'                p_developer_roles      ';
wwv_flow_imp.g_varchar2_table(115) := '         => null,'||wwv_flow.LF||
'                p_description                   => l_description,'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(116) := 'p_account_expiry                => l_account_expiry,'||wwv_flow.LF||
'                p_account_locked               ';
wwv_flow_imp.g_varchar2_table(117) := ' => l_account_locked,'||wwv_flow.LF||
'                p_failed_access_attempts        => l_failed_access_attempts,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(118) := '               p_change_password_on_first_use  => l_change_password_on_first_use,'||wwv_flow.LF||
'                p_';
wwv_flow_imp.g_varchar2_table(119) := 'first_password_use_occurred   => l_first_password_use_occurred );'||wwv_flow.LF||
'          end if;'||wwv_flow.LF||
'       end loop;';
wwv_flow_imp.g_varchar2_table(120) := ''||wwv_flow.LF||
'       commit;'||wwv_flow.LF||
'       add_user_log ('||wwv_flow.LF||
'          p_username      => p_username,'||wwv_flow.LF||
'          p_email_add';
wwv_flow_imp.g_varchar2_table(121) := 'ress => lower(p_email_address),'||wwv_flow.LF||
'          p_activity      => ''Account request approved. User account';
wwv_flow_imp.g_varchar2_table(122) := ' created.'','||wwv_flow.LF||
'          p_details       => ''Application role: CONTRIBUTOR / APEX role: End-User'' );'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(123) := '     if p_email_user_yn = ''Y'' then'||wwv_flow.LF||
'          email_user_creds ('||wwv_flow.LF||
'             p_email_to      => lowe';
wwv_flow_imp.g_varchar2_table(124) := 'r(p_email_address),'||wwv_flow.LF||
'             p_app_id        => p_app_id,'||wwv_flow.LF||
'             p_app_title     => p_app_';
wwv_flow_imp.g_varchar2_table(125) := 'title,'||wwv_flow.LF||
'             p_app_link      => p_app_link,'||wwv_flow.LF||
'             p_username      => upper(p_username)';
wwv_flow_imp.g_varchar2_table(126) := ','||wwv_flow.LF||
'             p_apex_password => p_apex_password );'||wwv_flow.LF||
'          add_user_log ('||wwv_flow.LF||
'             p_usernam';
wwv_flow_imp.g_varchar2_table(127) := 'e      => p_username,'||wwv_flow.LF||
'             p_email_address => lower(p_email_address),'||wwv_flow.LF||
'             p_activit';
wwv_flow_imp.g_varchar2_table(128) := 'y      => ''Application credentials emailed to user.'' );'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    exception when others th';
wwv_flow_imp.g_varchar2_table(129) := 'en'||wwv_flow.LF||
'          rollback;'||wwv_flow.LF||
'          eba_qpoll_fw.add_error_log('||wwv_flow.LF||
'                         p_error => nul';
wwv_flow_imp.g_varchar2_table(130) := 'l,'||wwv_flow.LF||
'                         p_procedure_name  => ''add_user'','||wwv_flow.LF||
'                         p_error_text =';
wwv_flow_imp.g_varchar2_table(131) := '> sqlerrm,'||wwv_flow.LF||
'                         p_arg1_name => ''p_email_address'','||wwv_flow.LF||
'                         p_arg';
wwv_flow_imp.g_varchar2_table(132) := '1_val => p_email_address);'||wwv_flow.LF||
'          raise;'||wwv_flow.LF||
'    end add_user;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    procedure approve_access_requ';
wwv_flow_imp.g_varchar2_table(133) := 'est ('||wwv_flow.LF||
'       p_app_id           in  number,'||wwv_flow.LF||
'       p_app_title        in  varchar2,'||wwv_flow.LF||
'       p_app_lin';
wwv_flow_imp.g_varchar2_table(134) := 'k         in  varchar2,'||wwv_flow.LF||
'       p_request_id       in  number,'||wwv_flow.LF||
'       p_actioned_reason  in  varchar2';
wwv_flow_imp.g_varchar2_table(135) := '  default null )'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'       l_request_found    varchar2(1) := ''N'';'||wwv_flow.LF||
'       request_not_found  exce';
wwv_flow_imp.g_varchar2_table(136) := 'ption;'||wwv_flow.LF||
'       l_user_found       varchar2(1) := ''N'';'||wwv_flow.LF||
'       l_apex_password    varchar2(15);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(137) := 'l_email_id         number;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'       for c1 in ('||wwv_flow.LF||
'          select username, email_address'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(138) := '         from eba_qpoll_access_requests'||wwv_flow.LF||
'           where id = p_request_id'||wwv_flow.LF||
'             and status =';
wwv_flow_imp.g_varchar2_table(139) := ' ''pending'''||wwv_flow.LF||
'       ) loop'||wwv_flow.LF||
'          l_request_found := ''Y'';'||wwv_flow.LF||
'          update eba_qpoll_access_request';
wwv_flow_imp.g_varchar2_table(140) := 's'||wwv_flow.LF||
'             set status = ''approved'','||wwv_flow.LF||
'                 actioned_reason = p_actioned_reason'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(141) := '    where id = p_request_id;'||wwv_flow.LF||
'          for c2 in ('||wwv_flow.LF||
'             select ''Y'' found'||wwv_flow.LF||
'               from';
wwv_flow_imp.g_varchar2_table(142) := ' apex_appl_acl_users'||wwv_flow.LF||
'              where upper(user_name) = upper(nvl(c1.username,c1.email_address))';
wwv_flow_imp.g_varchar2_table(143) := ''||wwv_flow.LF||
'                and application_id = p_app_id'||wwv_flow.LF||
'          ) loop'||wwv_flow.LF||
'             l_user_found := c2.foun';
wwv_flow_imp.g_varchar2_table(144) := 'd;'||wwv_flow.LF||
'          end loop;'||wwv_flow.LF||
'          if l_user_found = ''N'' then'||wwv_flow.LF||
'             add_user ('||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(145) := 'p_email_address    => c1.email_address,'||wwv_flow.LF||
'                p_email_user_yn    => ''Y'','||wwv_flow.LF||
'                p';
wwv_flow_imp.g_varchar2_table(146) := '_username         => c1.username,'||wwv_flow.LF||
'                p_app_id           => p_app_id,'||wwv_flow.LF||
'                p_';
wwv_flow_imp.g_varchar2_table(147) := 'app_title        => p_app_title,'||wwv_flow.LF||
'                p_app_link         => p_app_link,'||wwv_flow.LF||
'                p';
wwv_flow_imp.g_varchar2_table(148) := '_apex_password    => l_apex_password );'||wwv_flow.LF||
'          else'||wwv_flow.LF||
'             eba_qpoll_email.send ('||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(149) := '       p_app_id             => p_app_id,'||wwv_flow.LF||
'                p_template_static_id => ''ACCESS_REQUEST_APP';
wwv_flow_imp.g_varchar2_table(150) := 'ROVED_WITHOUT_PASSWORD'','||wwv_flow.LF||
'                p_placeholders       => ''{'' || '||wwv_flow.LF||
'                           ';
wwv_flow_imp.g_varchar2_table(151) := '             ''    "USERNAME":''     || apex_json.stringify( c1.username ) || '||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(152) := '                 ''   ,"APPLICATION_TITLE":'' || apex_json.stringify( p_app_title ) ||'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(153) := '                         ''   ,"APP_LINK":'' || apex_json.stringify( p_app_link ) ||'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(154) := '                           ''}'' , '||wwv_flow.LF||
'                p_to                 => c1.email_address,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(155) := '        p_from               => eba_qpoll_fw.get_preference_value(''NOTIFICATION_EMAIL_FROM''),'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(156) := '          p_email_id           => l_email_id );'||wwv_flow.LF||
'          end if;'||wwv_flow.LF||
'          commit;'||wwv_flow.LF||
'       end loop;';
wwv_flow_imp.g_varchar2_table(157) := ''||wwv_flow.LF||
'       if l_request_found = ''N'' then'||wwv_flow.LF||
'          raise request_not_found;'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'    exceptio';
wwv_flow_imp.g_varchar2_table(158) := 'n'||wwv_flow.LF||
'        when request_not_found then'||wwv_flow.LF||
'            eba_qpoll_fw.add_error_log('||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(159) := '     p_error => null,'||wwv_flow.LF||
'                           p_procedure_name  => ''approve_access_request'','||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(160) := '                       p_error_text => ''Request not found, or not still pending.'','||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(161) := '          p_arg1_name => ''p_request_id'','||wwv_flow.LF||
'                           p_arg1_val => p_request_id,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(162) := '                       p_arg2_name => ''p_actioned_reason'','||wwv_flow.LF||
'                           p_arg2_val => ';
wwv_flow_imp.g_varchar2_table(163) := 'p_actioned_reason);'||wwv_flow.LF||
'            raise_application_error( -20900, ''Request not found, or not still pe';
wwv_flow_imp.g_varchar2_table(164) := 'nding.'', TRUE );'||wwv_flow.LF||
'        when others then'||wwv_flow.LF||
'            rollback;'||wwv_flow.LF||
'            eba_qpoll_fw.add_error_l';
wwv_flow_imp.g_varchar2_table(165) := 'og('||wwv_flow.LF||
'                           p_error => null,'||wwv_flow.LF||
'                           p_procedure_name  => ''app';
wwv_flow_imp.g_varchar2_table(166) := 'rove_access_request'', '||wwv_flow.LF||
'                           p_error_text => sqlerrm,'||wwv_flow.LF||
'                         ';
wwv_flow_imp.g_varchar2_table(167) := '  p_arg1_name => ''p_request_id'','||wwv_flow.LF||
'                           p_arg1_val => p_request_id,'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(168) := '               p_arg2_name => ''p_actioned_reason'','||wwv_flow.LF||
'                           p_arg2_val => p_action';
wwv_flow_imp.g_varchar2_table(169) := 'ed_reason,'||wwv_flow.LF||
'                           p_arg3_name => ''l_request_found'','||wwv_flow.LF||
'                           p';
wwv_flow_imp.g_varchar2_table(170) := '_arg3_val => l_request_found,'||wwv_flow.LF||
'                           p_arg4_name => ''l_user_found'','||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(171) := '               p_arg4_val => l_user_found );'||wwv_flow.LF||
'--          raise;'||wwv_flow.LF||
'    end approve_access_request;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(172) := ''||wwv_flow.LF||
'    procedure decline_access_request ('||wwv_flow.LF||
'       p_app_id           in  number,'||wwv_flow.LF||
'       p_app_title    ';
wwv_flow_imp.g_varchar2_table(173) := '    in  varchar2,'||wwv_flow.LF||
'       p_request_id       in  number,'||wwv_flow.LF||
'       p_actioned_reason  in  varchar2 )'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(174) := ' is'||wwv_flow.LF||
'       l_request_found    varchar2(1) := ''N'';'||wwv_flow.LF||
'       request_not_found  exception;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(175) := '    for c1 in ('||wwv_flow.LF||
'          select username, email_address'||wwv_flow.LF||
'            from eba_qpoll_access_requests'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(176) := '           where id = p_request_id'||wwv_flow.LF||
'             and status = ''pending'''||wwv_flow.LF||
'       ) loop'||wwv_flow.LF||
'          l_req';
wwv_flow_imp.g_varchar2_table(177) := 'uest_found := ''Y'';'||wwv_flow.LF||
'          update eba_qpoll_access_requests'||wwv_flow.LF||
'             set status = ''declined'','||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(178) := '                 actioned_reason = p_actioned_reason'||wwv_flow.LF||
'           where id = p_request_id;'||wwv_flow.LF||
'          c';
wwv_flow_imp.g_varchar2_table(179) := 'ommit;'||wwv_flow.LF||
'          add_user_log ('||wwv_flow.LF||
'              p_username      => c1.username,'||wwv_flow.LF||
'              p_email_';
wwv_flow_imp.g_varchar2_table(180) := 'address => lower(c1.email_address),'||wwv_flow.LF||
'              p_activity      => ''Account request declined. No u';
wwv_flow_imp.g_varchar2_table(181) := 'ser account was created.'');'||wwv_flow.LF||
'          email_user_rejection ('||wwv_flow.LF||
'             p_app_id        => p_app_i';
wwv_flow_imp.g_varchar2_table(182) := 'd,'||wwv_flow.LF||
'             p_app_title     => p_app_title,'||wwv_flow.LF||
'             p_email_to      => c1.email_address,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(183) := '           p_action_reason => p_actioned_reason );'||wwv_flow.LF||
'          add_user_log ('||wwv_flow.LF||
'             p_username ';
wwv_flow_imp.g_varchar2_table(184) := '     => c1.username,'||wwv_flow.LF||
'             p_email_address => lower(c1.email_address),'||wwv_flow.LF||
'             p_activit';
wwv_flow_imp.g_varchar2_table(185) := 'y      => ''Account request rejection emailed to user.'' );'||wwv_flow.LF||
'       end loop;'||wwv_flow.LF||
'    exception'||wwv_flow.LF||
'        whe';
wwv_flow_imp.g_varchar2_table(186) := 'n request_not_found then'||wwv_flow.LF||
'            eba_qpoll_fw.add_error_log('||wwv_flow.LF||
'                           p_error ';
wwv_flow_imp.g_varchar2_table(187) := '=> null,'||wwv_flow.LF||
'                           p_procedure_name  => ''decline_access_request'','||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(188) := '          p_error_text => ''Request not found, or not still pending.'','||wwv_flow.LF||
'                           p_a';
wwv_flow_imp.g_varchar2_table(189) := 'rg1_name => ''p_request_id'','||wwv_flow.LF||
'                           p_arg1_val => p_request_id,'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(190) := '          p_arg2_name => ''p_actioned_reason'','||wwv_flow.LF||
'                           p_arg2_val => p_actioned_re';
wwv_flow_imp.g_varchar2_table(191) := 'ason);'||wwv_flow.LF||
'            raise_application_error( -20900, ''Request not found, or not still pending.'', TRUE';
wwv_flow_imp.g_varchar2_table(192) := ' );'||wwv_flow.LF||
'        when others then'||wwv_flow.LF||
'            rollback;'||wwv_flow.LF||
'            eba_qpoll_fw.add_error_log('||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(193) := '                  p_error => null,'||wwv_flow.LF||
'                           p_procedure_name  => ''decline_access_r';
wwv_flow_imp.g_varchar2_table(194) := 'equest'','||wwv_flow.LF||
'                           p_error_text => sqlerrm,'||wwv_flow.LF||
'                           p_arg1_name ';
wwv_flow_imp.g_varchar2_table(195) := '=> ''p_request_id'','||wwv_flow.LF||
'                           p_arg1_val => p_request_id,'||wwv_flow.LF||
'                          ';
wwv_flow_imp.g_varchar2_table(196) := ' p_arg2_name => ''p_actioned_reason'','||wwv_flow.LF||
'                           p_arg2_val => p_actioned_reason);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(197) := '          raise;'||wwv_flow.LF||
'    end decline_access_request;'||wwv_flow.LF||
'end eba_qpoll_account;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13919975116403030280)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_account body'
,p_sequence=>540
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
