prompt --application/deployment/install/install_history_triggers
begin
--   Manifest
--     INSTALL: INSTALL-History Triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger eba_qpoll_questions_au'||wwv_flow.LF||
'    after insert or update or delete on eba_qpoll_q';
wwv_flow_imp.g_varchar2_table(2) := 'uestions'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    pragma autonomous_transaction;'||wwv_flow.LF||
'    ov varchar2(4000) := null;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(3) := '    nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- QUESTION (default)'||wwv_flow.LF||
'    if nvl(:old.question, ''0'') != nvl';
wwv_flow_imp.g_varchar2_table(4) := '(:new.question,''0'') then '||wwv_flow.LF||
'        insert into eba_qpoll_history (table_name, component_rowkey, compo';
wwv_flow_imp.g_varchar2_table(5) := 'nent_id, poll_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'            (''QUESTIONS'', :new.row_key,';
wwv_flow_imp.g_varchar2_table(6) := ' :new.id, nvl(:new.poll_id,:old.poll_id), ''QUESTION'', substr(:old.question,0,4000), substr(:new.ques';
wwv_flow_imp.g_varchar2_table(7) := 'tion,0,4000) ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if UPDATING then'||wwv_flow.LF||
'        -- POLL_ID (foreign key)'||wwv_flow.LF||
'        if nvl(:o';
wwv_flow_imp.g_varchar2_table(8) := 'ld.poll_id,-999) != nvl(:new.poll_id,-999) then'||wwv_flow.LF||
'            ov := null; nv := null;'||wwv_flow.LF||
'            for ';
wwv_flow_imp.g_varchar2_table(9) := 'c1 in (select row_key val from eba_qpoll_polls t where t.id = :old.poll_id) loop'||wwv_flow.LF||
'                ov ';
wwv_flow_imp.g_varchar2_table(10) := ':= c1.val;'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'            for c1 in (select row_key val from eba_qpoll_polls t wh';
wwv_flow_imp.g_varchar2_table(11) := 'ere t.id = :new.poll_id) loop'||wwv_flow.LF||
'                nv := c1.val;'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'            insert';
wwv_flow_imp.g_varchar2_table(12) := ' into eba_qpoll_history (table_name, component_rowkey, component_id, column_name, old_value, new_val';
wwv_flow_imp.g_varchar2_table(13) := 'ue) values'||wwv_flow.LF||
'                (''QUESTIONS'', :new.row_key, :new.id, ''POLL_ID'', ov, nv);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(14) := '        -- DISPLAY_SEQUENCE (default)'||wwv_flow.LF||
'        if nvl(:old.display_sequence, ''0'') != nvl(:new.display';
wwv_flow_imp.g_varchar2_table(15) := '_sequence,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_history (table_name, component_rowkey, compon';
wwv_flow_imp.g_varchar2_table(16) := 'ent_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'                (''QUESTIONS'', :new.row_key, :new.';
wwv_flow_imp.g_varchar2_table(17) := 'id, ''DISPLAY_SEQUENCE'', substr(:old.display_sequence,0,4000), substr(:new.display_sequence,0,4000) )';
wwv_flow_imp.g_varchar2_table(18) := '; '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- QUESTION (default)'||wwv_flow.LF||
'        if nvl(:old.question, ''0'') != nvl(:new.ques';
wwv_flow_imp.g_varchar2_table(19) := 'tion,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_history (table_name, component_rowkey, component_i';
wwv_flow_imp.g_varchar2_table(20) := 'd, column_name, old_value, new_value) values '||wwv_flow.LF||
'                (''QUESTIONS'', :new.row_key, :new.id, ''';
wwv_flow_imp.g_varchar2_table(21) := 'QUESTION'', substr(:old.question,0,4000), substr(:new.question,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        --';
wwv_flow_imp.g_varchar2_table(22) := ' QUESTION_TYPE (default)'||wwv_flow.LF||
'        if nvl(:old.question_type, ''0'') != nvl(:new.question_type,''0'') then';
wwv_flow_imp.g_varchar2_table(23) := ' '||wwv_flow.LF||
'            insert into eba_qpoll_history (table_name, component_rowkey, component_id, column_name';
wwv_flow_imp.g_varchar2_table(24) := ', old_value, new_value) values '||wwv_flow.LF||
'                (''QUESTIONS'', :new.row_key, :new.id, ''QUESTION_TYPE''';
wwv_flow_imp.g_varchar2_table(25) := ', substr(:old.question_type,0,4000), substr(:new.question_type,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -';
wwv_flow_imp.g_varchar2_table(26) := '- MANDATORY_YN (default)'||wwv_flow.LF||
'        if nvl(:old.mandatory_yn, ''0'') != nvl(:new.mandatory_yn,''0'') then '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(27) := '            insert into eba_qpoll_history (table_name, component_rowkey, component_id, column_name, ';
wwv_flow_imp.g_varchar2_table(28) := 'old_value, new_value) values '||wwv_flow.LF||
'                (''QUESTIONS'', :new.row_key, :new.id, ''MANDATORY_YN'', s';
wwv_flow_imp.g_varchar2_table(29) := 'ubstr(:old.mandatory_yn,0,4000), substr(:new.mandatory_yn,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- PUB';
wwv_flow_imp.g_varchar2_table(30) := 'LISH_YN (default)'||wwv_flow.LF||
'        if nvl(:old.publish_yn, ''0'') != nvl(:new.publish_yn,''0'') then '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(31) := ' insert into eba_qpoll_history (table_name, component_rowkey, component_id, column_name, old_value, ';
wwv_flow_imp.g_varchar2_table(32) := 'new_value) values '||wwv_flow.LF||
'                (''QUESTIONS'', :new.row_key, :new.id, ''PUBLISH_YN'', substr(:old.pu';
wwv_flow_imp.g_varchar2_table(33) := 'blish_yn,0,4000), substr(:new.publish_yn,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ALLOW_COMMENTS_YN (d';
wwv_flow_imp.g_varchar2_table(34) := 'efault)'||wwv_flow.LF||
'        if nvl(:old.allow_comments_yn, ''0'') != nvl(:new.allow_comments_yn,''0'') then '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(35) := '     insert into eba_qpoll_history (table_name, component_rowkey, component_id, column_name, old_val';
wwv_flow_imp.g_varchar2_table(36) := 'ue, new_value) values '||wwv_flow.LF||
'                (''QUESTIONS'', :new.row_key, :new.id, ''ALLOW_COMMENTS_YN'', sub';
wwv_flow_imp.g_varchar2_table(37) := 'str(:old.allow_comments_yn,0,4000), substr(:new.allow_comments_yn,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(38) := '  -- USE_CUSTOM_ANSWERS_YN (default)'||wwv_flow.LF||
'        if nvl(:old.use_custom_answers_yn, ''0'') != nvl(:new.use';
wwv_flow_imp.g_varchar2_table(39) := '_custom_answers_yn,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_history (table_name, component_rowke';
wwv_flow_imp.g_varchar2_table(40) := 'y, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'                (''QUESTIONS'', :new.row_k';
wwv_flow_imp.g_varchar2_table(41) := 'ey, :new.id, ''USE_CUSTOM_ANSWERS_YN'', substr(:old.use_custom_answers_yn,0,4000), substr(:new.use_cus';
wwv_flow_imp.g_varchar2_table(42) := 'tom_answers_yn,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ANSWER_01 (default)'||wwv_flow.LF||
'        if nvl(:old.answer';
wwv_flow_imp.g_varchar2_table(43) := '_01, ''0'') != nvl(:new.answer_01,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_history (table_name, co';
wwv_flow_imp.g_varchar2_table(44) := 'mponent_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'                (''QUESTIONS';
wwv_flow_imp.g_varchar2_table(45) := ''', :new.row_key, :new.id, ''ANSWER_01'', substr(:old.answer_01,0,4000), substr(:new.answer_01,0,4000) ';
wwv_flow_imp.g_varchar2_table(46) := '); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ANSWER_02 (default)'||wwv_flow.LF||
'        if nvl(:old.answer_02, ''0'') != nvl(:new.a';
wwv_flow_imp.g_varchar2_table(47) := 'nswer_02,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_history (table_name, component_rowkey, compone';
wwv_flow_imp.g_varchar2_table(48) := 'nt_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'                (''QUESTIONS'', :new.row_key, :new.i';
wwv_flow_imp.g_varchar2_table(49) := 'd, ''ANSWER_02'', substr(:old.answer_02,0,4000), substr(:new.answer_02,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(50) := '     -- ANSWER_03 (default)'||wwv_flow.LF||
'        if nvl(:old.answer_03, ''0'') != nvl(:new.answer_03,''0'') then '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(51) := '         insert into eba_qpoll_history (table_name, component_rowkey, component_id, column_name, old';
wwv_flow_imp.g_varchar2_table(52) := '_value, new_value) values '||wwv_flow.LF||
'                (''QUESTIONS'', :new.row_key, :new.id, ''ANSWER_03'', substr(';
wwv_flow_imp.g_varchar2_table(53) := ':old.answer_03,0,4000), substr(:new.answer_03,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ANSWER_04 (defa';
wwv_flow_imp.g_varchar2_table(54) := 'ult)'||wwv_flow.LF||
'        if nvl(:old.answer_04, ''0'') != nvl(:new.answer_04,''0'') then '||wwv_flow.LF||
'            insert into eb';
wwv_flow_imp.g_varchar2_table(55) := 'a_qpoll_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) valu';
wwv_flow_imp.g_varchar2_table(56) := 'es '||wwv_flow.LF||
'                (''QUESTIONS'', :new.row_key, :new.id, ''ANSWER_04'', substr(:old.answer_04,0,4000),';
wwv_flow_imp.g_varchar2_table(57) := ' substr(:new.answer_04,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ANSWER_05 (default)'||wwv_flow.LF||
'        if nvl(:ol';
wwv_flow_imp.g_varchar2_table(58) := 'd.answer_05, ''0'') != nvl(:new.answer_05,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_history (table_';
wwv_flow_imp.g_varchar2_table(59) := 'name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'                (''Q';
wwv_flow_imp.g_varchar2_table(60) := 'UESTIONS'', :new.row_key, :new.id, ''ANSWER_05'', substr(:old.answer_05,0,4000), substr(:new.answer_05,';
wwv_flow_imp.g_varchar2_table(61) := '0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ANSWER_06 (default)'||wwv_flow.LF||
'        if nvl(:old.answer_06, ''0'') != nv';
wwv_flow_imp.g_varchar2_table(62) := 'l(:new.answer_06,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_history (table_name, component_rowkey,';
wwv_flow_imp.g_varchar2_table(63) := ' component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'                (''QUESTIONS'', :new.row_key';
wwv_flow_imp.g_varchar2_table(64) := ', :new.id, ''ANSWER_06'', substr(:old.answer_06,0,4000), substr(:new.answer_06,0,4000) ); '||wwv_flow.LF||
'        end';
wwv_flow_imp.g_varchar2_table(65) := ' if;'||wwv_flow.LF||
'        -- ANSWER_07 (default)'||wwv_flow.LF||
'        if nvl(:old.answer_07, ''0'') != nvl(:new.answer_07,''0'') t';
wwv_flow_imp.g_varchar2_table(66) := 'hen '||wwv_flow.LF||
'            insert into eba_qpoll_history (table_name, component_rowkey, component_id, column_n';
wwv_flow_imp.g_varchar2_table(67) := 'ame, old_value, new_value) values '||wwv_flow.LF||
'                (''QUESTIONS'', :new.row_key, :new.id, ''ANSWER_07'',';
wwv_flow_imp.g_varchar2_table(68) := ' substr(:old.answer_07,0,4000), substr(:new.answer_07,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ANSWER_';
wwv_flow_imp.g_varchar2_table(69) := '08 (default)'||wwv_flow.LF||
'        if nvl(:old.answer_08, ''0'') != nvl(:new.answer_08,''0'') then '||wwv_flow.LF||
'            insert';
wwv_flow_imp.g_varchar2_table(70) := ' into eba_qpoll_history (table_name, component_rowkey, component_id, column_name, old_value, new_val';
wwv_flow_imp.g_varchar2_table(71) := 'ue) values '||wwv_flow.LF||
'                (''QUESTIONS'', :new.row_key, :new.id, ''ANSWER_08'', substr(:old.answer_08,';
wwv_flow_imp.g_varchar2_table(72) := '0,4000), substr(:new.answer_08,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ANSWER_09 (default)'||wwv_flow.LF||
'        if';
wwv_flow_imp.g_varchar2_table(73) := ' nvl(:old.answer_09, ''0'') != nvl(:new.answer_09,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_history';
wwv_flow_imp.g_varchar2_table(74) := ' (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(75) := '     (''QUESTIONS'', :new.row_key, :new.id, ''ANSWER_09'', substr(:old.answer_09,0,4000), substr(:new.an';
wwv_flow_imp.g_varchar2_table(76) := 'swer_09,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ANSWER_10 (default)'||wwv_flow.LF||
'        if nvl(:old.answer_10, ''0';
wwv_flow_imp.g_varchar2_table(77) := ''') != nvl(:new.answer_10,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_history (table_name, component';
wwv_flow_imp.g_varchar2_table(78) := '_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'                (''QUESTIONS'', :new';
wwv_flow_imp.g_varchar2_table(79) := '.row_key, :new.id, ''ANSWER_10'', substr(:old.answer_10,0,4000), substr(:new.answer_10,0,4000) ); '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(80) := '     end if;'||wwv_flow.LF||
'        -- CORRECT_ANSWER (default)'||wwv_flow.LF||
'        if nvl(:old.correct_answer, ''0'') != nvl(:ne';
wwv_flow_imp.g_varchar2_table(81) := 'w.correct_answer,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_history (table_name, component_rowkey,';
wwv_flow_imp.g_varchar2_table(82) := ' component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'                (''QUESTIONS'', :new.row_key';
wwv_flow_imp.g_varchar2_table(83) := ', :new.id, ''CORRECT_ANSWER'', substr(:old.correct_answer,0,4000), substr(:new.correct_answer,0,4000) ';
wwv_flow_imp.g_varchar2_table(84) := '); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ENABLE_SCORE_YN (default)'||wwv_flow.LF||
'        if nvl(:old.enable_score_yn, ''0'') !';
wwv_flow_imp.g_varchar2_table(85) := '= nvl(:new.enable_score_yn,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_history (table_name, compone';
wwv_flow_imp.g_varchar2_table(86) := 'nt_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'                (''QUESTIONS'', :n';
wwv_flow_imp.g_varchar2_table(87) := 'ew.row_key, :new.id, ''ENABLE_SCORE_YN'', substr(:old.enable_score_yn,0,4000), substr(:new.enable_scor';
wwv_flow_imp.g_varchar2_table(88) := 'e_yn,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ANSWER_01_SCORE (default)'||wwv_flow.LF||
'        if nvl(:old.answer_01_';
wwv_flow_imp.g_varchar2_table(89) := 'score, ''0'') != nvl(:new.answer_01_score,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_history (table_';
wwv_flow_imp.g_varchar2_table(90) := 'name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'                (''Q';
wwv_flow_imp.g_varchar2_table(91) := 'UESTIONS'', :new.row_key, :new.id, ''ANSWER_01_SCORE'', substr(:old.answer_01_score,0,4000), substr(:ne';
wwv_flow_imp.g_varchar2_table(92) := 'w.answer_01_score,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ANSWER_02_SCORE (default)'||wwv_flow.LF||
'        if nvl(:o';
wwv_flow_imp.g_varchar2_table(93) := 'ld.answer_02_score, ''0'') != nvl(:new.answer_02_score,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_hi';
wwv_flow_imp.g_varchar2_table(94) := 'story (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(95) := '          (''QUESTIONS'', :new.row_key, :new.id, ''ANSWER_02_SCORE'', substr(:old.answer_02_score,0,4000';
wwv_flow_imp.g_varchar2_table(96) := '), substr(:new.answer_02_score,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ANSWER_03_SCORE (default)'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(97) := '    if nvl(:old.answer_03_score, ''0'') != nvl(:new.answer_03_score,''0'') then '||wwv_flow.LF||
'            insert into';
wwv_flow_imp.g_varchar2_table(98) := ' eba_qpoll_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) v';
wwv_flow_imp.g_varchar2_table(99) := 'alues '||wwv_flow.LF||
'                (''QUESTIONS'', :new.row_key, :new.id, ''ANSWER_03_SCORE'', substr(:old.answer_03';
wwv_flow_imp.g_varchar2_table(100) := '_score,0,4000), substr(:new.answer_03_score,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ANSWER_04_SCORE (';
wwv_flow_imp.g_varchar2_table(101) := 'default)'||wwv_flow.LF||
'        if nvl(:old.answer_04_score, ''0'') != nvl(:new.answer_04_score,''0'') then '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(102) := '  insert into eba_qpoll_history (table_name, component_rowkey, component_id, column_name, old_value,';
wwv_flow_imp.g_varchar2_table(103) := ' new_value) values '||wwv_flow.LF||
'                (''QUESTIONS'', :new.row_key, :new.id, ''ANSWER_04_SCORE'', substr(:';
wwv_flow_imp.g_varchar2_table(104) := 'old.answer_04_score,0,4000), substr(:new.answer_04_score,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ANSW';
wwv_flow_imp.g_varchar2_table(105) := 'ER_05_SCORE (default)'||wwv_flow.LF||
'        if nvl(:old.answer_05_score, ''0'') != nvl(:new.answer_05_score,''0'') the';
wwv_flow_imp.g_varchar2_table(106) := 'n '||wwv_flow.LF||
'            insert into eba_qpoll_history (table_name, component_rowkey, component_id, column_nam';
wwv_flow_imp.g_varchar2_table(107) := 'e, old_value, new_value) values '||wwv_flow.LF||
'                (''QUESTIONS'', :new.row_key, :new.id, ''ANSWER_05_SCO';
wwv_flow_imp.g_varchar2_table(108) := 'RE'', substr(:old.answer_05_score,0,4000), substr(:new.answer_05_score,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(109) := '      -- ANSWER_06_SCORE (default)'||wwv_flow.LF||
'        if nvl(:old.answer_06_score, ''0'') != nvl(:new.answer_06_s';
wwv_flow_imp.g_varchar2_table(110) := 'core,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_history (table_name, component_rowkey, component_i';
wwv_flow_imp.g_varchar2_table(111) := 'd, column_name, old_value, new_value) values '||wwv_flow.LF||
'                (''QUESTIONS'', :new.row_key, :new.id, ''';
wwv_flow_imp.g_varchar2_table(112) := 'ANSWER_06_SCORE'', substr(:old.answer_06_score,0,4000), substr(:new.answer_06_score,0,4000) ); '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(113) := '   end if;'||wwv_flow.LF||
'        -- ANSWER_07_SCORE (default)'||wwv_flow.LF||
'        if nvl(:old.answer_07_score, ''0'') != nvl(:ne';
wwv_flow_imp.g_varchar2_table(114) := 'w.answer_07_score,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_history (table_name, component_rowkey';
wwv_flow_imp.g_varchar2_table(115) := ', component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'                (''QUESTIONS'', :new.row_ke';
wwv_flow_imp.g_varchar2_table(116) := 'y, :new.id, ''ANSWER_07_SCORE'', substr(:old.answer_07_score,0,4000), substr(:new.answer_07_score,0,40';
wwv_flow_imp.g_varchar2_table(117) := '00) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ANSWER_08_SCORE (default)'||wwv_flow.LF||
'        if nvl(:old.answer_08_score, ''0';
wwv_flow_imp.g_varchar2_table(118) := ''') != nvl(:new.answer_08_score,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_history (table_name, com';
wwv_flow_imp.g_varchar2_table(119) := 'ponent_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'                (''QUESTIONS''';
wwv_flow_imp.g_varchar2_table(120) := ', :new.row_key, :new.id, ''ANSWER_08_SCORE'', substr(:old.answer_08_score,0,4000), substr(:new.answer_';
wwv_flow_imp.g_varchar2_table(121) := '08_score,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ANSWER_09_SCORE (default)'||wwv_flow.LF||
'        if nvl(:old.answer';
wwv_flow_imp.g_varchar2_table(122) := '_09_score, ''0'') != nvl(:new.answer_09_score,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_history (ta';
wwv_flow_imp.g_varchar2_table(123) := 'ble_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(124) := ' (''QUESTIONS'', :new.row_key, :new.id, ''ANSWER_09_SCORE'', substr(:old.answer_09_score,0,4000), substr';
wwv_flow_imp.g_varchar2_table(125) := '(:new.answer_09_score,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ANSWER_10_SCORE (default)'||wwv_flow.LF||
'        if nv';
wwv_flow_imp.g_varchar2_table(126) := 'l(:old.answer_10_score, ''0'') != nvl(:new.answer_10_score,''0'') then '||wwv_flow.LF||
'            insert into eba_qpol';
wwv_flow_imp.g_varchar2_table(127) := 'l_history (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(128) := '              (''QUESTIONS'', :new.row_key, :new.id, ''ANSWER_10_SCORE'', substr(:old.answer_10_score,0,';
wwv_flow_imp.g_varchar2_table(129) := '4000), substr(:new.answer_10_score,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ANSWER_11 (default)'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(130) := '  if nvl(:old.answer_11, ''0'') != nvl(:new.answer_11,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_his';
wwv_flow_imp.g_varchar2_table(131) := 'tory (table_name, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(132) := '         (''QUESTIONS'', :new.row_key, :new.id, ''ANSWER_11'', substr(:old.answer_11,0,4000), substr(:ne';
wwv_flow_imp.g_varchar2_table(133) := 'w.answer_11,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ANSWER_12 (default)'||wwv_flow.LF||
'        if nvl(:old.answer_12';
wwv_flow_imp.g_varchar2_table(134) := ', ''0'') != nvl(:new.answer_12,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_history (table_name, compo';
wwv_flow_imp.g_varchar2_table(135) := 'nent_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'                (''QUESTIONS'', ';
wwv_flow_imp.g_varchar2_table(136) := ':new.row_key, :new.id, ''ANSWER_12'', substr(:old.answer_12,0,4000), substr(:new.answer_12,0,4000) ); ';
wwv_flow_imp.g_varchar2_table(137) := ''||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ANSWER_11_SCORE (default)'||wwv_flow.LF||
'        if nvl(:old.answer_11_score, ''0'') != n';
wwv_flow_imp.g_varchar2_table(138) := 'vl(:new.answer_11_score,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_history (table_name, component_';
wwv_flow_imp.g_varchar2_table(139) := 'rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'                (''QUESTIONS'', :new.';
wwv_flow_imp.g_varchar2_table(140) := 'row_key, :new.id, ''ANSWER_11_SCORE'', substr(:old.answer_11_score,0,4000), substr(:new.answer_11_scor';
wwv_flow_imp.g_varchar2_table(141) := 'e,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- ANSWER_12_SCORE (default)'||wwv_flow.LF||
'        if nvl(:old.answer_12_sco';
wwv_flow_imp.g_varchar2_table(142) := 're, ''0'') != nvl(:new.answer_12_score,''0'') then '||wwv_flow.LF||
'            insert into eba_qpoll_history (table_nam';
wwv_flow_imp.g_varchar2_table(143) := 'e, component_rowkey, component_id, column_name, old_value, new_value) values '||wwv_flow.LF||
'                (''QUES';
wwv_flow_imp.g_varchar2_table(144) := 'TIONS'', :new.row_key, :new.id, ''ANSWER_12_SCORE'', substr(:old.answer_12_score,0,4000), substr(:new.a';
wwv_flow_imp.g_varchar2_table(145) := 'nswer_12_score,0,4000) ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end au_eba_qpoll_questions;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(14033518120666443337)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'History Triggers'
,p_sequence=>440
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
