prompt --application/deployment/install/upgrade_timestamp_fix_bugid_31352674
begin
--   Manifest
--     INSTALL: UPGRADE-TIMESTAMP Fix (BUGID: 31352674)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- This script fixes BUG 31631691/31352674, replacing all columns of type TIMESTAMP(6) WITH LOCAL TI';
wwv_flow_imp.g_varchar2_table(2) := 'ME ZONE to TIMESTAMP WITH TIME ZONE'||wwv_flow.LF||
'-- it also updates all application triggers where columns where ';
wwv_flow_imp.g_varchar2_table(3) := 'updated with LOCALTIMESTAMP to CURRENT_TIMESTAMP'||wwv_flow.LF||
'-- '||wwv_flow.LF||
'-- This upgrade script will only run if there a';
wwv_flow_imp.g_varchar2_table(4) := 're tables that start with ''EBA_QPOLL_%'' with columns of data type'||wwv_flow.LF||
'-- TIMESTAMP(6) WITH LOCAL TIME ZO';
wwv_flow_imp.g_varchar2_table(5) := 'NE'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Disable all affected triggers'||wwv_flow.LF||
'alter trigger eba_qpoll_preferences_biu disable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigge';
wwv_flow_imp.g_varchar2_table(6) := 'r eba_qpoll_notifications_biu disable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_polls_biu disable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger ';
wwv_flow_imp.g_varchar2_table(7) := 'eba_qpoll_sections_biu disable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_questions_biu disable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba';
wwv_flow_imp.g_varchar2_table(8) := '_qpoll_resp_comm_biu disable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_respondents_biu disable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba';
wwv_flow_imp.g_varchar2_table(9) := '_qpoll_resp_comm_ref_bi disable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_emails_bi disable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qp';
wwv_flow_imp.g_varchar2_table(10) := 'oll_comm_invites_bi disable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_invites_bi disable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll';
wwv_flow_imp.g_varchar2_table(11) := '_canned_answ_biu disable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_results_biu disable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_r';
wwv_flow_imp.g_varchar2_table(12) := 'esult_dets_biu disable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_error_log_bi disable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_ap';
wwv_flow_imp.g_varchar2_table(13) := 'p_log_bi disable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_user_log_bi disable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_access_re';
wwv_flow_imp.g_varchar2_table(14) := 'q_biu disable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_email_opt_out_biu disable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_histor';
wwv_flow_imp.g_varchar2_table(15) := 'y_biu disable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Add temporary timestamp columns'||wwv_flow.LF||
'alter table eba_qpoll_preferences add (created_';
wwv_flow_imp.g_varchar2_table(16) := 'on1 timestamp with time zone,updated_on1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_errors ad';
wwv_flow_imp.g_varchar2_table(17) := 'd (err_time1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_notifications add (created1 timestamp';
wwv_flow_imp.g_varchar2_table(18) := ' with time zone,updated1 timestamp with time zone,display_from1 timestamp with time zone,display_unt';
wwv_flow_imp.g_varchar2_table(19) := 'il1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_polls add (created1 timestamp with time zone,u';
wwv_flow_imp.g_varchar2_table(20) := 'pdated1 timestamp with time zone,start_time1 timestamp with time zone,stop_time1 timestamp with time';
wwv_flow_imp.g_varchar2_table(21) := ' zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_sections add (created1 timestamp with time zone,updated1 timestamp wi';
wwv_flow_imp.g_varchar2_table(22) := 'th time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_questions add (created1 timestamp with time zone,updated1 time';
wwv_flow_imp.g_varchar2_table(23) := 'stamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_resp_communities add (created1 timestamp with time zon';
wwv_flow_imp.g_varchar2_table(24) := 'e,updated1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_respondents add (created1 timestamp wit';
wwv_flow_imp.g_varchar2_table(25) := 'h time zone,updated1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_resp_comm_ref add (created1 t';
wwv_flow_imp.g_varchar2_table(26) := 'imestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_emails add (sent_time1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(27) := 'alter table eba_qpoll_comm_invites add (created1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_i';
wwv_flow_imp.g_varchar2_table(28) := 'nvites add (created1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_canned_answers add (created1 ';
wwv_flow_imp.g_varchar2_table(29) := 'timestamp with time zone,updated1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_results add (cre';
wwv_flow_imp.g_varchar2_table(30) := 'ated1 timestamp with time zone,updated1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_result_det';
wwv_flow_imp.g_varchar2_table(31) := 'ails add (created1 timestamp with time zone,updated1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpo';
wwv_flow_imp.g_varchar2_table(32) := 'll_error_log add (created1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_application_log add (cr';
wwv_flow_imp.g_varchar2_table(33) := 'eated1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_user_log add (created1 timestamp with time ';
wwv_flow_imp.g_varchar2_table(34) := 'zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_access_requests add (created1 timestamp with time zone,updated1 timest';
wwv_flow_imp.g_varchar2_table(35) := 'amp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_email_opt_out add (created1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(36) := 'alter table eba_qpoll_history add (change_date1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Copy original column';
wwv_flow_imp.g_varchar2_table(37) := ' values into temporary column values'||wwv_flow.LF||
'update eba_qpoll_preferences set created_on1 = created_on,updat';
wwv_flow_imp.g_varchar2_table(38) := 'ed_on1 = updated_on;'||wwv_flow.LF||
'update eba_qpoll_errors set err_time1 = err_time;'||wwv_flow.LF||
'update eba_qpoll_notification';
wwv_flow_imp.g_varchar2_table(39) := 's set created1 = created,updated1 = updated,display_from1 = display_from,display_until1 = display_un';
wwv_flow_imp.g_varchar2_table(40) := 'til;'||wwv_flow.LF||
'update eba_qpoll_polls set created1 = created,updated1 = updated,start_time1 = start_time,stop_';
wwv_flow_imp.g_varchar2_table(41) := 'time1 = stop_time;'||wwv_flow.LF||
'update eba_qpoll_sections set created1 = created,updated1 = updated;'||wwv_flow.LF||
'update eba_q';
wwv_flow_imp.g_varchar2_table(42) := 'poll_questions set created1 = created,updated1 = updated;'||wwv_flow.LF||
'update eba_qpoll_resp_communities set crea';
wwv_flow_imp.g_varchar2_table(43) := 'ted1 = created,updated1 = updated;'||wwv_flow.LF||
'update eba_qpoll_respondents set created1 = created,updated1 = up';
wwv_flow_imp.g_varchar2_table(44) := 'dated;'||wwv_flow.LF||
'update eba_qpoll_resp_comm_ref set created1 = created;'||wwv_flow.LF||
'update eba_qpoll_emails set sent_time1';
wwv_flow_imp.g_varchar2_table(45) := ' = sent_time;'||wwv_flow.LF||
'update eba_qpoll_comm_invites set created1 = created;'||wwv_flow.LF||
'update eba_qpoll_invites set cre';
wwv_flow_imp.g_varchar2_table(46) := 'ated1 = created;'||wwv_flow.LF||
'update eba_qpoll_canned_answers set created1 = created,updated1 = updated;'||wwv_flow.LF||
'update e';
wwv_flow_imp.g_varchar2_table(47) := 'ba_qpoll_results set created1 = created,updated1 = updated;'||wwv_flow.LF||
'update eba_qpoll_result_details set crea';
wwv_flow_imp.g_varchar2_table(48) := 'ted1 = created,updated1 = updated;'||wwv_flow.LF||
'update eba_qpoll_error_log set created1 = created;'||wwv_flow.LF||
'update eba_qpo';
wwv_flow_imp.g_varchar2_table(49) := 'll_application_log set created1 = created;'||wwv_flow.LF||
'update eba_qpoll_user_log set created1 = created;'||wwv_flow.LF||
'update ';
wwv_flow_imp.g_varchar2_table(50) := 'eba_qpoll_access_requests set created1 = created,updated1 = updated;'||wwv_flow.LF||
'update eba_qpoll_email_opt_out ';
wwv_flow_imp.g_varchar2_table(51) := 'set created1 = created;'||wwv_flow.LF||
'update eba_qpoll_history set change_date1 = change_date;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Drop original t';
wwv_flow_imp.g_varchar2_table(52) := 'imestamp with local time zone columns'||wwv_flow.LF||
'alter table eba_qpoll_preferences drop (created_on,updated_on)';
wwv_flow_imp.g_varchar2_table(53) := ''||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_errors drop (err_time)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_notifications drop (created,';
wwv_flow_imp.g_varchar2_table(54) := 'updated,display_from,display_until)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_polls drop (created,updated,start_time,s';
wwv_flow_imp.g_varchar2_table(55) := 'top_time)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_sections drop (created,updated)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_questions ';
wwv_flow_imp.g_varchar2_table(56) := 'drop (created,updated)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_resp_communities drop (created,updated)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table';
wwv_flow_imp.g_varchar2_table(57) := ' eba_qpoll_respondents drop (created,updated)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_resp_comm_ref drop (created)'||wwv_flow.LF||
'/';
wwv_flow_imp.g_varchar2_table(58) := ''||wwv_flow.LF||
'alter table eba_qpoll_emails drop (sent_time)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_comm_invites drop (created)'||wwv_flow.LF||
'/';
wwv_flow_imp.g_varchar2_table(59) := ''||wwv_flow.LF||
'alter table eba_qpoll_invites drop (created)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_canned_answers drop (created,u';
wwv_flow_imp.g_varchar2_table(60) := 'pdated)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_results drop (created,updated)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_result_detail';
wwv_flow_imp.g_varchar2_table(61) := 's drop (created,updated)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_error_log drop (created)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_ap';
wwv_flow_imp.g_varchar2_table(62) := 'plication_log drop (created)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_user_log drop (created)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll';
wwv_flow_imp.g_varchar2_table(63) := '_access_requests drop (created,updated)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_email_opt_out drop (created)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter';
wwv_flow_imp.g_varchar2_table(64) := ' table eba_qpoll_history drop (change_date)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Rename temporary columns back to original column n';
wwv_flow_imp.g_varchar2_table(65) := 'ames'||wwv_flow.LF||
'alter table eba_qpoll_preferences rename column created_on1 to created_on'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpo';
wwv_flow_imp.g_varchar2_table(66) := 'll_preferences rename column updated_on1 to updated_on'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_errors rename column ';
wwv_flow_imp.g_varchar2_table(67) := 'err_time1 to err_time'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_notifications rename column created1 to created'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alte';
wwv_flow_imp.g_varchar2_table(68) := 'r table eba_qpoll_notifications rename column updated1 to updated'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_notificati';
wwv_flow_imp.g_varchar2_table(69) := 'ons rename column display_from1 to display_from'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_notifications rename column ';
wwv_flow_imp.g_varchar2_table(70) := 'display_until1 to display_until'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_polls rename column created1 to created'||wwv_flow.LF||
'/'||wwv_flow.LF||
'al';
wwv_flow_imp.g_varchar2_table(71) := 'ter table eba_qpoll_polls rename column updated1 to updated'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_polls rename col';
wwv_flow_imp.g_varchar2_table(72) := 'umn start_time1 to start_time'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_polls rename column stop_time1 to stop_time'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(73) := 'alter table eba_qpoll_sections rename column created1 to created'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_sections re';
wwv_flow_imp.g_varchar2_table(74) := 'name column updated1 to updated'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_questions rename column created1 to created'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(75) := '/'||wwv_flow.LF||
'alter table eba_qpoll_questions rename column updated1 to updated'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_resp_com';
wwv_flow_imp.g_varchar2_table(76) := 'munities rename column created1 to created'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_resp_communities rename column up';
wwv_flow_imp.g_varchar2_table(77) := 'dated1 to updated'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_respondents rename column created1 to created'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter tabl';
wwv_flow_imp.g_varchar2_table(78) := 'e eba_qpoll_respondents rename column updated1 to updated'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_resp_comm_ref rena';
wwv_flow_imp.g_varchar2_table(79) := 'me column created1 to created'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_emails rename column sent_time1 to sent_time'||wwv_flow.LF||
'/';
wwv_flow_imp.g_varchar2_table(80) := ''||wwv_flow.LF||
'alter table eba_qpoll_comm_invites rename column created1 to created'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_invite';
wwv_flow_imp.g_varchar2_table(81) := 's rename column created1 to created'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_canned_answers rename column created1 to';
wwv_flow_imp.g_varchar2_table(82) := ' created'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_canned_answers rename column updated1 to updated'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_';
wwv_flow_imp.g_varchar2_table(83) := 'qpoll_results rename column created1 to created'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_results rename column update';
wwv_flow_imp.g_varchar2_table(84) := 'd1 to updated'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_result_details rename column created1 to created'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table';
wwv_flow_imp.g_varchar2_table(85) := ' eba_qpoll_result_details rename column updated1 to updated'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_error_log rename';
wwv_flow_imp.g_varchar2_table(86) := ' column created1 to created'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_application_log rename column created1 to create';
wwv_flow_imp.g_varchar2_table(87) := 'd'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_user_log rename column created1 to created'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_access_';
wwv_flow_imp.g_varchar2_table(88) := 'requests rename column created1 to created'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_access_requests rename column upd';
wwv_flow_imp.g_varchar2_table(89) := 'ated1 to updated'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_qpoll_email_opt_out rename column created1 to created'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter tab';
wwv_flow_imp.g_varchar2_table(90) := 'le eba_qpoll_history rename column change_date1 to change_date'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Recreate Triggers using current';
wwv_flow_imp.g_varchar2_table(91) := '_timestamp'||wwv_flow.LF||
'create or replace trigger eba_qpoll_preferences_biu'||wwv_flow.LF||
'before insert or update on eba_qpoll_';
wwv_flow_imp.g_varchar2_table(92) := 'preferences'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        :new.id := to_n';
wwv_flow_imp.g_varchar2_table(93) := 'umber(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new';
wwv_flow_imp.g_varchar2_table(94) := '.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created_on := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(95) := '  if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated_on := cu';
wwv_flow_imp.g_varchar2_table(96) := 'rrent_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.preference_name := upper(:new.preference_name);'||wwv_flow.LF||
'end eba_qpoll_';
wwv_flow_imp.g_varchar2_table(97) := 'preferences_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger eba_qpoll_notifications_biu'||wwv_flow.LF||
'before insert or update on ';
wwv_flow_imp.g_varchar2_table(98) := 'eba_qpoll_notifications'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'       :new';
wwv_flow_imp.g_varchar2_table(99) := '.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(100) := '       :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(101) := '  :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :ne';
wwv_flow_imp.g_varchar2_table(102) := 'w.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.row_version_number := nvl(:';
wwv_flow_imp.g_varchar2_table(103) := 'old.row_version_number,1) + 1;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.upda';
wwv_flow_imp.g_varchar2_table(104) := 'ted    := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.notification_type is null then'||wwv_flow.LF||
'       :new.noti';
wwv_flow_imp.g_varchar2_table(105) := 'fication_type := ''MANUAL'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.display_sequence is null then'||wwv_flow.LF||
'       :new.display';
wwv_flow_imp.g_varchar2_table(106) := '_sequence := 10;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end eba_qpoll_notifications_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger eba_qpoll_';
wwv_flow_imp.g_varchar2_table(107) := 'polls_biu'||wwv_flow.LF||
'   before insert or update on eba_qpoll_polls'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is null ';
wwv_flow_imp.g_varchar2_table(108) := 'then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if :ne';
wwv_flow_imp.g_varchar2_table(109) := 'w.row_key is null then'||wwv_flow.LF||
'      :new.row_key := EBA_QPOLL_FW.compress_int(eba_qpoll_seq.nextval);'||wwv_flow.LF||
'   en';
wwv_flow_imp.g_varchar2_table(110) := 'd if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(w';
wwv_flow_imp.g_varchar2_table(111) := 'wv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_fl';
wwv_flow_imp.g_varchar2_table(112) := 'ow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version';
wwv_flow_imp.g_varchar2_table(113) := '_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :n';
wwv_flow_imp.g_varchar2_table(114) := 'ew.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(115) := ' if :new.poll_or_quiz = ''Q'' then'||wwv_flow.LF||
'      :new.score_type := ''N'';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'   if :new.status_id = 3 ';
wwv_flow_imp.g_varchar2_table(116) := 'and nvl(:old.status_id,0) != 3 then'||wwv_flow.LF||
'      :new.start_time := current_timestamp;'||wwv_flow.LF||
'   elsif :new.status';
wwv_flow_imp.g_varchar2_table(117) := '_id = 4 and nvl(:old.status_id,0) != 4 then'||wwv_flow.LF||
'      :new.stop_time := current_timestamp;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'en';
wwv_flow_imp.g_varchar2_table(118) := 'd eba_qpoll_polls_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger eba_qpoll_sections_biu'||wwv_flow.LF||
'   before insert or update';
wwv_flow_imp.g_varchar2_table(119) := ' on eba_qpoll_sections'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is null then'||wwv_flow.LF||
'      :new.id := to_number(s';
wwv_flow_imp.g_varchar2_table(120) := 'ys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created :';
wwv_flow_imp.g_varchar2_table(121) := '= current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := cur';
wwv_flow_imp.g_varchar2_table(122) := 'rent_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number ';
wwv_flow_imp.g_varchar2_table(123) := ':= 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(124) := '  end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.upd';
wwv_flow_imp.g_varchar2_table(125) := 'ated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'end eba_qpoll_sections_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace tr';
wwv_flow_imp.g_varchar2_table(126) := 'igger eba_qpoll_questions_biu'||wwv_flow.LF||
'   before insert or update on eba_qpoll_questions'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begi';
wwv_flow_imp.g_varchar2_table(127) := 'n'||wwv_flow.LF||
'   if :new.ID is null then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(128) := ''');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if :new.row_key is null then'||wwv_flow.LF||
'      :new.row_key := EBA_QPOLL_FW.compress_int(eba_q';
wwv_flow_imp.g_varchar2_table(129) := 'poll_seq.nextval);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(130) := ':new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.';
wwv_flow_imp.g_varchar2_table(131) := 'updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then';
wwv_flow_imp.g_varchar2_table(132) := ''||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or';
wwv_flow_imp.g_varchar2_table(133) := ' updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_us';
wwv_flow_imp.g_varchar2_table(134) := 'er,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.mandatory_yn := nvl(upper(:new.mandatory_yn),''Y'');'||wwv_flow.LF||
'   :new.publish_yn :';
wwv_flow_imp.g_varchar2_table(135) := '= nvl(upper(:new.publish_yn),''Y'');'||wwv_flow.LF||
'   :new.allow_comments_yn := nvl(upper(:new.allow_comments_yn),''N';
wwv_flow_imp.g_varchar2_table(136) := ''');'||wwv_flow.LF||
'   if :new.question_type in (''PICK_TWO'',''CHECKBOX'',''TEXTAREA'',''RADIO_GROUP'',''STACK'',''ALLOCATION''';
wwv_flow_imp.g_varchar2_table(137) := ') then'||wwv_flow.LF||
'       :new.use_custom_answers_yn := ''Y'';'||wwv_flow.LF||
'   else'||wwv_flow.LF||
'       :new.use_custom_answers_yn := ''N'';'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(138) := '  end if;'||wwv_flow.LF||
'end eba_qpoll_questions_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger eba_qpoll_resp_comm_biu'||wwv_flow.LF||
'   before';
wwv_flow_imp.g_varchar2_table(139) := ' insert or update on eba_qpoll_resp_communities'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is null then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(140) := '   :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if :new.publis';
wwv_flow_imp.g_varchar2_table(141) := 'h_yn is null then'||wwv_flow.LF||
'      :new.publish_yn := ''Y'';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created ';
wwv_flow_imp.g_varchar2_table(142) := ':= current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := cu';
wwv_flow_imp.g_varchar2_table(143) := 'rrent_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number';
wwv_flow_imp.g_varchar2_table(144) := ' := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(145) := '   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.up';
wwv_flow_imp.g_varchar2_table(146) := 'dated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end eba_qpoll_resp_comm_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace t';
wwv_flow_imp.g_varchar2_table(147) := 'rigger eba_qpoll_respondents_biu'||wwv_flow.LF||
'   before insert or update on eba_qpoll_respondents'||wwv_flow.LF||
'   for each row';
wwv_flow_imp.g_varchar2_table(148) := ''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is null then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(149) := 'XXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'       :new.creat';
wwv_flow_imp.g_varchar2_table(150) := 'ed_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by';
wwv_flow_imp.g_varchar2_table(151) := ' := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :n';
wwv_flow_imp.g_varchar2_table(152) := 'ew.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.email := lower(:new.';
wwv_flow_imp.g_varchar2_table(153) := 'email);'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updat';
wwv_flow_imp.g_varchar2_table(154) := 'ed_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end eba_qpoll_respondents_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace tr';
wwv_flow_imp.g_varchar2_table(155) := 'igger eba_qpoll_resp_comm_ref_bi'||wwv_flow.LF||
'   before insert on eba_qpoll_resp_comm_ref'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(156) := '  if :NEW.ID is null then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');';
wwv_flow_imp.g_varchar2_table(157) := ''||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.created := current_timestamp;'||wwv_flow.LF||
'   :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'e';
wwv_flow_imp.g_varchar2_table(158) := 'nd eba_qpoll_resp_comm_ref_bi;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger eba_qpoll_emails_bi'||wwv_flow.LF||
'    before insert on ';
wwv_flow_imp.g_varchar2_table(159) := 'eba_qpoll_emails'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        :new.id := to_number(sys';
wwv_flow_imp.g_varchar2_table(160) := '_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.sent_to := lower(:new.sent_to);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(161) := '  :new.sent_time := current_timestamp;'||wwv_flow.LF||
'end eba_qpoll_emails_bi;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger eba_qpol';
wwv_flow_imp.g_varchar2_table(162) := 'l_comm_invites_bi'||wwv_flow.LF||
'   before insert on eba_qpoll_comm_invites'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is ';
wwv_flow_imp.g_varchar2_table(163) := 'null then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :';
wwv_flow_imp.g_varchar2_table(164) := 'new.created := current_timestamp;'||wwv_flow.LF||
'   :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'end eba_qpoll_com';
wwv_flow_imp.g_varchar2_table(165) := 'm_invites_bi;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger eba_qpoll_invites_bi'||wwv_flow.LF||
'   before insert on eba_qpoll_invites';
wwv_flow_imp.g_varchar2_table(166) := ''||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is null then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(167) := 'XXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.created := current_timestamp;'||wwv_flow.LF||
'   :new.created_by := nvl(';
wwv_flow_imp.g_varchar2_table(168) := 'wwv_flow.g_user,user);'||wwv_flow.LF||
'end eba_qpoll_invites_bi;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger eba_qpoll_canned_answ_b';
wwv_flow_imp.g_varchar2_table(169) := 'iu'||wwv_flow.LF||
'   before insert or update on eba_qpoll_canned_answers'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is nul';
wwv_flow_imp.g_varchar2_table(170) := 'l then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if i';
wwv_flow_imp.g_varchar2_table(171) := 'nserting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_use';
wwv_flow_imp.g_varchar2_table(172) := 'r,user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,use';
wwv_flow_imp.g_varchar2_table(173) := 'r);'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nv';
wwv_flow_imp.g_varchar2_table(174) := 'l(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated :=';
wwv_flow_imp.g_varchar2_table(175) := ' current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.code := ';
wwv_flow_imp.g_varchar2_table(176) := 'replace(:new.code,'' '','''');'||wwv_flow.LF||
'   :new.code := upper(:new.code);'||wwv_flow.LF||
'end eba_qpoll_canned_answ_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create';
wwv_flow_imp.g_varchar2_table(177) := ' or replace trigger eba_qpoll_results_biu'||wwv_flow.LF||
'   before insert or update on eba_qpoll_results'||wwv_flow.LF||
'   for eac';
wwv_flow_imp.g_varchar2_table(178) := 'h row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is null then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(179) := 'XXXXXXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'    if :new.row_key is null then'||wwv_flow.LF||
'       :new.row_key := eba_qpoll_fw.compre';
wwv_flow_imp.g_varchar2_table(180) := 'ss_int(eba_qpoll_seq.nextval);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       if :new.apex_user is null the';
wwv_flow_imp.g_varchar2_table(181) := 'n'||wwv_flow.LF||
'          :new.apex_user := nvl(v(''APP_USER''),user);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       if :new.apex_session_id';
wwv_flow_imp.g_varchar2_table(182) := ' is null then'||wwv_flow.LF||
'          :new.apex_session_id := nvl(v(''SESSION_ID''),''unknown'');'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(183) := '  :new.created := current_timestamp;'||wwv_flow.LF||
'       if :new.created_by is null then'||wwv_flow.LF||
'          :new.created_b';
wwv_flow_imp.g_varchar2_table(184) := 'y := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       if :';
wwv_flow_imp.g_varchar2_table(185) := 'new.updated_by is null then'||wwv_flow.LF||
'          :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(186) := '      :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:ol';
wwv_flow_imp.g_varchar2_table(187) := 'd.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if :new.preactive_yn is null'||wwv_flow.LF||
'      then :new.preactive_yn';
wwv_flow_imp.g_varchar2_table(188) := ' := ''N'';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.email := lower(:new.email);'||wwv_flow.LF||
'   if updating then'||wwv_flow.LF||
'       :new.updated := c';
wwv_flow_imp.g_varchar2_table(189) := 'urrent_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end eba_qpoll_resu';
wwv_flow_imp.g_varchar2_table(190) := 'lts_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger eba_qpoll_result_dets_biu'||wwv_flow.LF||
'   before insert or update on eba_qpo';
wwv_flow_imp.g_varchar2_table(191) := 'll_result_details'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is null then'||wwv_flow.LF||
'      :new.ID := to_number(sys_gu';
wwv_flow_imp.g_varchar2_table(192) := 'id(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := cur';
wwv_flow_imp.g_varchar2_table(193) := 'rent_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_';
wwv_flow_imp.g_varchar2_table(194) := 'timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number := 1;';
wwv_flow_imp.g_varchar2_table(195) := ''||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end';
wwv_flow_imp.g_varchar2_table(196) := ' if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_';
wwv_flow_imp.g_varchar2_table(197) := 'by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end eba_qpoll_result_dets_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigg';
wwv_flow_imp.g_varchar2_table(198) := 'er eba_qpoll_error_log_bi '||wwv_flow.LF||
'   before insert on eba_qpoll_error_log'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.';
wwv_flow_imp.g_varchar2_table(199) := 'id is null then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if';
wwv_flow_imp.g_varchar2_table(200) := ';'||wwv_flow.LF||
'   :new.created       := current_timestamp;'||wwv_flow.LF||
'   :new.created_trunc := trunc(current_timestamp);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(201) := ':new.created_by    := lower(nvl(wwv_flow.g_user, user));'||wwv_flow.LF||
'end eba_qpoll_error_log_bi;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or rep';
wwv_flow_imp.g_varchar2_table(202) := 'lace trigger eba_qpoll_app_log_bi '||wwv_flow.LF||
'   before insert on eba_qpoll_application_log'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'beg';
wwv_flow_imp.g_varchar2_table(203) := 'in'||wwv_flow.LF||
'   if :new.id is null then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(204) := 'X'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.created       := current_timestamp;'||wwv_flow.LF||
'   :new.created_trunc := trunc(current_t';
wwv_flow_imp.g_varchar2_table(205) := 'imestamp);'||wwv_flow.LF||
'   :new.created_by    := lower(nvl(wwv_flow.g_user,user));'||wwv_flow.LF||
'end eba_qpoll_app_log_bi;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'cr';
wwv_flow_imp.g_varchar2_table(206) := 'eate or replace trigger eba_qpoll_user_log_bi '||wwv_flow.LF||
'   before insert on eba_qpoll_user_log'||wwv_flow.LF||
'   for each ro';
wwv_flow_imp.g_varchar2_table(207) := 'w'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.id is null then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(208) := 'XXXXXX'');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.email_address := lower(:new.email_address);'||wwv_flow.LF||
'   :new.created       := cu';
wwv_flow_imp.g_varchar2_table(209) := 'rrent_timestamp;'||wwv_flow.LF||
'   :new.created_trunc := trunc(current_timestamp);'||wwv_flow.LF||
'   :new.created_by    := lower(n';
wwv_flow_imp.g_varchar2_table(210) := 'vl(wwv_flow.g_user,user));'||wwv_flow.LF||
'end eba_qpoll_user_log_bi;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace  trigger  eba_qpoll_access';
wwv_flow_imp.g_varchar2_table(211) := '_req_biu '||wwv_flow.LF||
'   before insert or update on eba_qpoll_access_requests '||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.';
wwv_flow_imp.g_varchar2_table(212) := 'id is null then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end if';
wwv_flow_imp.g_varchar2_table(213) := ';'||wwv_flow.LF||
'   :new.email_address := lower(:new.email_address);'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'      :new.created    := ';
wwv_flow_imp.g_varchar2_table(214) := 'current_timestamp;'||wwv_flow.LF||
'      :new.created_by := lower(nvl(v(''APP_USER''),user));'||wwv_flow.LF||
'      :new.created_trunc';
wwv_flow_imp.g_varchar2_table(215) := ' := trunc(current_timestamp);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.row_version_number := nvl(:old.row_version_number,0';
wwv_flow_imp.g_varchar2_table(216) := ') + 1;'||wwv_flow.LF||
''||wwv_flow.LF||
'   :new.updated     := current_timestamp;'||wwv_flow.LF||
'   :new.updated_by  := lower(nvl(v(''APP_USER''),use';
wwv_flow_imp.g_varchar2_table(217) := 'r));'||wwv_flow.LF||
''||wwv_flow.LF||
'   if updating and :old.status != :new.status then'||wwv_flow.LF||
'      :new.actioned_by := lower(nvl(v(''APP_';
wwv_flow_imp.g_varchar2_table(218) := 'USER''),user));'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end eba_qpoll_access_req_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger eba_qpoll_email_';
wwv_flow_imp.g_varchar2_table(219) := 'opt_out_biu'||wwv_flow.LF||
'   before insert on eba_qpoll_email_opt_out'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null';
wwv_flow_imp.g_varchar2_table(220) := ' then'||wwv_flow.LF||
'       :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'   :ne';
wwv_flow_imp.g_varchar2_table(221) := 'w.created := current_timestamp;'||wwv_flow.LF||
'   :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'end eba_qpoll_email';
wwv_flow_imp.g_varchar2_table(222) := '_opt_out_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger eba_qpoll_history_biu'||wwv_flow.LF||
'    before insert or update on eba_q';
wwv_flow_imp.g_varchar2_table(223) := 'poll_history'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'       :new.id := to_number(sys_guid';
wwv_flow_imp.g_varchar2_table(224) := '(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.change_date :';
wwv_flow_imp.g_varchar2_table(225) := '= current_timestamp;'||wwv_flow.LF||
'        :new.changed_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'        :new.row_version_';
wwv_flow_imp.g_varchar2_table(226) := 'number := 1;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.row_version_number := :new.row_version_number + 1;';
wwv_flow_imp.g_varchar2_table(227) := ''||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end eba_qpoll_history_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Enable all affected triggers'||wwv_flow.LF||
'alter trigger eba_qpoll_p';
wwv_flow_imp.g_varchar2_table(228) := 'references_biu enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_notifications_biu enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll';
wwv_flow_imp.g_varchar2_table(229) := '_polls_biu enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_sections_biu enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_question';
wwv_flow_imp.g_varchar2_table(230) := 's_biu enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_resp_comm_biu enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_respondents_';
wwv_flow_imp.g_varchar2_table(231) := 'biu enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_resp_comm_ref_bi enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_emails_bi e';
wwv_flow_imp.g_varchar2_table(232) := 'nable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_comm_invites_bi enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_invites_bi enable';
wwv_flow_imp.g_varchar2_table(233) := ';'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_canned_answ_biu enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_results_biu enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(234) := 'alter trigger eba_qpoll_result_dets_biu enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_error_log_bi enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alt';
wwv_flow_imp.g_varchar2_table(235) := 'er trigger eba_qpoll_app_log_bi enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_user_log_bi enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigge';
wwv_flow_imp.g_varchar2_table(236) := 'r eba_qpoll_access_req_biu enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_qpoll_email_opt_out_biu enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigg';
wwv_flow_imp.g_varchar2_table(237) := 'er eba_qpoll_history_biu enable;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(410691098458704043)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'TIMESTAMP Fix (BUGID: 31352674)'
,p_sequence=>10
,p_script_type=>'UPGRADE'
,p_condition_type=>'EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from all_tab_cols',
' where table_name like ''EBA_QPOLL_%''',
'   and data_type = ''TIMESTAMP(6) WITH LOCAL TIME ZONE'''))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
