prompt --application/deployment/install/install_eba_qpoll_application_log_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_application_log table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_qpoll_application_log '||wwv_flow.LF||
'('||wwv_flow.LF||
'   id             number not null enable, '||wwv_flow.LF||
'   activity    ';
wwv_flow_imp.g_varchar2_table(2) := '   varchar2(255) not null enable, '||wwv_flow.LF||
'   details        varchar2(4000), '||wwv_flow.LF||
'   created        timestamp (6';
wwv_flow_imp.g_varchar2_table(3) := ') with time zone not null enable, '||wwv_flow.LF||
'   created_trunc  date not null enable, '||wwv_flow.LF||
'   created_by    varchar';
wwv_flow_imp.g_varchar2_table(4) := '2(255) not null enable, '||wwv_flow.LF||
'   constraint eba_qpoll_app_log_pk primary key (id)'||wwv_flow.LF||
'   using index  enable'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(5) := ');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_qpoll_app_log_i1 on eba_qpoll_application_log (created_trunc);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or repla';
wwv_flow_imp.g_varchar2_table(6) := 'ce trigger eba_qpoll_app_log_bi '||wwv_flow.LF||
'   before insert on eba_qpoll_application_log'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin';
wwv_flow_imp.g_varchar2_table(7) := ''||wwv_flow.LF||
'   if :new.id is null then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX''';
wwv_flow_imp.g_varchar2_table(8) := ');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   :new.created       := current_timestamp;'||wwv_flow.LF||
'   :new.created_trunc := trunc(current_tim';
wwv_flow_imp.g_varchar2_table(9) := 'estamp);'||wwv_flow.LF||
'   :new.created_by    := lower(nvl(wwv_flow.g_user,user));'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger eba_qpoll_';
wwv_flow_imp.g_varchar2_table(10) := 'app_log_bi enable;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13919881408882216265)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_application_log table'
,p_sequence=>300
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
