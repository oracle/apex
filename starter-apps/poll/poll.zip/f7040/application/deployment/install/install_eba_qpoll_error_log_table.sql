prompt --application/deployment/install/install_eba_qpoll_error_log_table
begin
--   Manifest
--     INSTALL: INSTALL-eba_qpoll_error_log table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_qpoll_error_log '||wwv_flow.LF||
'('||wwv_flow.LF||
'    id              number not null enable, '||wwv_flow.LF||
'    app_id         ';
wwv_flow_imp.g_varchar2_table(2) := ' number, '||wwv_flow.LF||
'    page_id         number, '||wwv_flow.LF||
'    procedure_name  varchar2(1000), '||wwv_flow.LF||
'    error           varc';
wwv_flow_imp.g_varchar2_table(3) := 'har2(4000) not null enable, '||wwv_flow.LF||
'    arg1_name       varchar2(255), '||wwv_flow.LF||
'    arg1_val        varchar2(4000),';
wwv_flow_imp.g_varchar2_table(4) := ' '||wwv_flow.LF||
'    arg2_name       varchar2(255), '||wwv_flow.LF||
'    arg2_val        varchar2(4000), '||wwv_flow.LF||
'    arg3_name       varch';
wwv_flow_imp.g_varchar2_table(5) := 'ar2(255), '||wwv_flow.LF||
'    arg3_val        varchar2(4000), '||wwv_flow.LF||
'    arg4_name       varchar2(255), '||wwv_flow.LF||
'    arg4_val    ';
wwv_flow_imp.g_varchar2_table(6) := '    varchar2(4000), '||wwv_flow.LF||
'    arg5_name       varchar2(255), '||wwv_flow.LF||
'    arg5_val        varchar2(4000), '||wwv_flow.LF||
'    ar';
wwv_flow_imp.g_varchar2_table(7) := 'g6_name       varchar2(255), '||wwv_flow.LF||
'    arg6_val        varchar2(4000), '||wwv_flow.LF||
'    arg7_name       varchar2(255)';
wwv_flow_imp.g_varchar2_table(8) := ', '||wwv_flow.LF||
'    arg7_val        varchar2(4000), '||wwv_flow.LF||
'    arg8_name       varchar2(255), '||wwv_flow.LF||
'    arg8_val        varc';
wwv_flow_imp.g_varchar2_table(9) := 'har2(4000), '||wwv_flow.LF||
'    arg9_name       varchar2(255), '||wwv_flow.LF||
'    arg9_val        varchar2(4000), '||wwv_flow.LF||
'    arg10_name';
wwv_flow_imp.g_varchar2_table(10) := '      varchar2(255), '||wwv_flow.LF||
'    arg10_val       varchar2(4000), '||wwv_flow.LF||
'    created         timestamp (6) with ti';
wwv_flow_imp.g_varchar2_table(11) := 'me zone not null enable, '||wwv_flow.LF||
'    created_trunc   date not null enable, '||wwv_flow.LF||
'    created_by      varchar2(25';
wwv_flow_imp.g_varchar2_table(12) := '5) not null enable, '||wwv_flow.LF||
'    constraint eba_qpoll_error_log_pk primary key (id) using index enable'||wwv_flow.LF||
');'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(13) := ''||wwv_flow.LF||
'create index eba_qpoll_error_log_i1 on eba_qpoll_error_log (created_trunc);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trig';
wwv_flow_imp.g_varchar2_table(14) := 'ger eba_qpoll_error_log_bi '||wwv_flow.LF||
'   before insert on eba_qpoll_error_log'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new';
wwv_flow_imp.g_varchar2_table(15) := '.id is null then'||wwv_flow.LF||
'      :new.id := to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'');'||wwv_flow.LF||
'   end i';
wwv_flow_imp.g_varchar2_table(16) := 'f;'||wwv_flow.LF||
'   :new.created       := current_timestamp;'||wwv_flow.LF||
'   :new.created_trunc := trunc(current_timestamp);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(17) := ' :new.created_by    := lower(nvl(wwv_flow.g_user, user));'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger eba_qpoll_error_log_';
wwv_flow_imp.g_varchar2_table(18) := 'bi enable;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13919865223625009386)
,p_install_id=>wwv_flow_imp.id(15922417043420668813)
,p_name=>'eba_qpoll_error_log table'
,p_sequence=>230
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
