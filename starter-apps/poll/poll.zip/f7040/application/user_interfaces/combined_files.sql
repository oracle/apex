prompt --application/user_interfaces/combined_files
begin
--   Manifest
--     COMBINED FILES: 7040
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7040
,p_default_id_offset=>1475844552414530
,p_default_owner=>'ORACLE'
);
null;
wwv_flow_imp.component_end;
end;
/
