prompt --application/pages/page_10760
begin
--   Manifest
--     PAGE: 10760
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10760
,p_name=>'External System Link'
,p_alias=>'EXTERNAL-SYSTEM-LINK'
,p_page_mode=>'MODAL'
,p_step_title=>'External System Link'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(141188315653614575172)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_required_role=>wwv_flow_imp.id(141188613860866575484)
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'SBKENNED'
,p_last_upd_yyyymmddhh24miss=>'20240322214932'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6339008584801104024)
,p_plug_name=>'External System Link'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188351742057575241)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'SP_EXTERNAL_TICKETING_SYSTEMS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6339015731373104073)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188501912119575289)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6339016159639104074)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6339015731373104073)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6339017477196104080)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(6339015731373104073)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P10760_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6339017882935104080)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(6339015731373104073)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P10760_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6339018363186104081)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(6339015731373104073)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P10760_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6339008926564104025)
,p_name=>'P10760_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6339008584801104024)
,p_item_source_plug_id=>wwv_flow_imp.id(6339008584801104024)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(141188584476664575383)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6339009670058104056)
,p_name=>'P10760_EXTERNAL_SYSTEM_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(6339008584801104024)
,p_item_source_plug_id=>wwv_flow_imp.id(6339008584801104024)
,p_prompt=>'External System Name'
,p_source=>'EXTERNAL_SYSTEM_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(141188583993679575382)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Name of the external system to link to.'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6339010069488104058)
,p_name=>'P10760_DESCRIPTION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(6339008584801104024)
,p_item_source_plug_id=>wwv_flow_imp.id(6339008584801104024)
,p_prompt=>'Description'
,p_source=>'DESCRIPTION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(141188584476664575383)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Describe this external system'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6339010479873104060)
,p_name=>'P10760_IS_ACTIVE_YN'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(6339008584801104024)
,p_item_source_plug_id=>wwv_flow_imp.id(6339008584801104024)
,p_prompt=>'Active'
,p_source=>'IS_ACTIVE_YN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(141188583993679575382)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Toggle to active to scan for this external link'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6339010943392104061)
,p_name=>'P10760_LINK_PATTERN'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(6339008584801104024)
,p_item_source_plug_id=>wwv_flow_imp.id(6339008584801104024)
,p_prompt=>'Link Pattern'
,p_source=>'LINK_PATTERN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>4000
,p_field_template=>wwv_flow_imp.id(141188583993679575382)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Substitute the Ticket ID using the #TICKET# or #TICKET_NUMERIC# substitution string.  #TICKET_NUMERIC# will strip all non-numeric characters from your regexp.',
' For example: https://jira.mycompany.com/jira/browse/#TICKET# or',
'              https://jira.mycompany.com/jira/browse/#TICKET_NUMERIC#'))
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7464040844612324367)
,p_name=>'P10760_TICKET_ID_REGEX'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(6339008584801104024)
,p_item_source_plug_id=>wwv_flow_imp.id(6339008584801104024)
,p_item_default=>'[Aa][Bb][Cc][Dd][-: ]\d{4,5}'
,p_prompt=>'Identify Ticket ID REGEXP'
,p_source=>'TICKET_ID_REGEX'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(141188583993679575382)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Use this regular expression to identify the pattern containing the ticket ID that is to be used to link to the external system.  For example: ',
'',
'<pre>[Aa][Bb][Cc][Dd][-: ]\d{4,5}</pre>',
'',
'which searches for case insensitive "ABCD" followed by a dash, colon or space and then 4 or 5 numbers.  This entire string, or just the numeric portion, can then used in the Link.'))
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7464040881690324368)
,p_name=>'P10760_EVAULATION_SEQUENCE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(6339008584801104024)
,p_item_source_plug_id=>wwv_flow_imp.id(6339008584801104024)
,p_prompt=>'Evaulation Sequence'
,p_source=>'EVAULATION_SEQUENCE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(141188584476664575383)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Only one external link is identified.  The search for systems will occur in this order.  Only active external systems will be included.'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10267219771221963494)
,p_name=>'P10760_REQUIRED_INITIATIVE_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(6339008584801104024)
,p_item_source_plug_id=>wwv_flow_imp.id(6339008584801104024)
,p_prompt=>'Required &NOMENCLATURE_INITIATIVE.'
,p_source=>'REQUIRED_INITIATIVE_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.focus_area ||'' - ''|| i.initiative d, i.id ',
'  from sp_focus_areas a,',
'       sp_initiatives i',
' where a.id = i.focus_area_id',
' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Any -'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(141188584476664575383)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_help_text=>'If provided, this REGEXP will only be used on &NOMENCLATURE_PROJECTS. within the &NOMENCLATURE_INITIATIVE..'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6339016200407104074)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(6339016159639104074)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6339017049167104079)
,p_event_id=>wwv_flow_imp.id(6339016200407104074)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6339019133668104083)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(6339008584801104024)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form External System Link'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>4473281364785458623
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6339019485211104083)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>4473281716328458623
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6339018723581104082)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(6339008584801104024)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form External System Link'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>4473280954698458622
);
wwv_flow_imp.component_end;
end;
/
