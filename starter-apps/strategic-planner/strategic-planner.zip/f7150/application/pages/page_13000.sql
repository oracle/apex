prompt --application/pages/page_13000
begin
--   Manifest
--     PAGE: 13000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>13000
,p_name=>'Contributor Checklist Admin'
,p_alias=>'CONTRIBUTOR-CHECKLIST-ADMIN'
,p_step_title=>'Contributor Checklist'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(3484469300187144248)
,p_page_css_classes=>'rw-pillar--sienna'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(141188613860866575484)
,p_required_patch=>wwv_flow_imp.id(3480948210361877450)
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_by=>'MICHAEL.HICHWA@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20231206012841'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3480798049533483222)
,p_plug_name=>'Contributor Checklist Admin'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188482213340575271)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       DISPLAY_SEQUENCE,',
'       CHECKLIST_ACTIVITY,',
'       WHY_IMPORTANT,',
'       HOW_TO_CHECK,',
'       LINK_TO_PAGE,',
'       CREATED,',
'       CREATED_BY,',
'       UPDATED,',
'       UPDATED_BY,',
'       ACTIVE_YN,',
'       BUILD_OPTION_NAME',
'  from SP_CONTRIBUTOR_CHECKLIST'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Contributor Checklist Admin'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(3480798098145483222)
,p_name=>'Contributor Checklist Admin'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:13001:&APP_SESSION.::&DEBUG.:RP:P13001_ID:\#ID#\'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_owner=>'MIKE'
,p_internal_uid=>1615060329262837762
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3480798513851483224)
,p_db_column_name=>'ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3480798870979483226)
,p_db_column_name=>'DISPLAY_SEQUENCE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Display Sequence'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3480799280664483226)
,p_db_column_name=>'CHECKLIST_ACTIVITY'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Checklist Activity'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3480799734479483227)
,p_db_column_name=>'WHY_IMPORTANT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Why Important'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3480800106056483227)
,p_db_column_name=>'HOW_TO_CHECK'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'How To Check'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3480800492683483228)
,p_db_column_name=>'LINK_TO_PAGE'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Link To Page'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3440146655775472105)
,p_db_column_name=>'ACTIVE_YN'
,p_display_order=>16
,p_column_identifier=>'K'
,p_column_label=>'Active'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3480800930711483228)
,p_db_column_name=>'CREATED'
,p_display_order=>26
,p_column_identifier=>'G'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3480801325687483229)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>36
,p_column_identifier=>'H'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3480801692045483229)
,p_db_column_name=>'UPDATED'
,p_display_order=>46
,p_column_identifier=>'I'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3480802105612483230)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>56
,p_column_identifier=>'J'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(5963094334216961684)
,p_db_column_name=>'BUILD_OPTION_NAME'
,p_display_order=>66
,p_column_identifier=>'L'
,p_column_label=>'Build Option Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(3484458576526136399)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'16187209'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DISPLAY_SEQUENCE:CHECKLIST_ACTIVITY:WHY_IMPORTANT:HOW_TO_CHECK:LINK_TO_PAGE:BUILD_OPTION_NAME:ACTIVE_YN:UPDATED:'
,p_sort_column_1=>'DISPLAY_SEQUENCE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'UPDATED'
,p_sort_direction_2=>'DESC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3480803962965483232)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188496742657575286)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(141188314805859575166)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(141188586951874575390)
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(44384485328840715461)
,p_name=>'SQL'
,p_template=>wwv_flow_imp.id(141188506007267575292)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''insert into SP_CONTRIBUTOR_CHECKLIST (ID, display_sequence, ',
'checklist_activity, why_important, how_to_check, active_yn, link_to_page) values (''||',
'       id||'', ''||',
'       display_sequence||'', ''||',
'       ''''''''||replace(checklist_activity,'''''''','''''''''''')||'''''', ''||',
'       ''''''''||replace(why_important,'''''''','''''''''''')||'''''', ''||',
'       ''''''''||replace(how_to_check,'''''''','''''''''''')||'''''', ''||',
'       ''''''''||replace(active_yn,'''''''','''''''''''')||'''''', ''||',
'       nvl(to_char(link_to_page),''null'')||''); ''||chr(10)||chr(10) sql',
'',
'  from sp_contributor_checklist',
'  order by display_sequence'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141188543836701575328)
,p_query_num_rows=>1500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3485312941715659186)
,p_query_column_id=>1
,p_column_alias=>'SQL'
,p_column_display_sequence=>10
,p_column_heading=>'SQL'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3480802640679483230)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3480803962965483232)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(141188585454452575388)
,p_button_image_alt=>'Add Checklist Item'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:13001:&APP_SESSION.::&DEBUG.:13001::'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3485286765572644116)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3480803962965483232)
,p_button_name=>'UP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141188584666839575384)
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3480802883299483231)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(3480798049533483222)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3480803420825483231)
,p_event_id=>wwv_flow_imp.id(3480802883299483231)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3480798049533483222)
);
wwv_flow_imp.component_end;
end;
/
