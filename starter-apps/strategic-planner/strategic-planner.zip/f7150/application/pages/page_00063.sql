prompt --application/pages/page_00063
begin
--   Manifest
--     PAGE: 00063
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>63
,p_name=>'Copy Release'
,p_alias=>'COPY-RELEASE'
,p_page_mode=>'MODAL'
,p_step_title=>'Copy Release'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10040674569356553454)
,p_step_template=>wwv_flow_imp.id(141188315653614575172)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_required_role=>wwv_flow_imp.id(141188614017151575484)
,p_required_patch=>wwv_flow_imp.id(6210148529518744054)
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20240417223731'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(23676568885514001286)
,p_name=>'Milestones'
,p_template=>wwv_flow_imp.id(141188482213340575271)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with r as (',
'    select trunc(sysdate-release_open_date) push_default',
'      from sp_release_trains',
'     where id = :P63_COPY_FROM_RELEASE_ID)',
'select MILESTONE_NAME,',
'       MILESTONE_DATE,',
'       milestone_date + r.push_default default_date,',
'       milestone_description',
'  from sp_release_milestones, r',
' where release_id = :P63_COPY_FROM_RELEASE_ID',
' order by milestone_date asc'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P63_COPY_FROM_RELEASE_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141188543836701575328)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No Milestones found.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6329460217227008099)
,p_query_column_id=>1
,p_column_alias=>'MILESTONE_NAME'
,p_column_display_sequence=>20
,p_column_heading=>'Milestone'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6329460356056008100)
,p_query_column_id=>2
,p_column_alias=>'MILESTONE_DATE'
,p_column_display_sequence=>30
,p_column_heading=>'Date'
,p_use_as_row_header=>'N'
,p_column_format=>'DD-MON-RR'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6691925419907681970)
,p_query_column_id=>3
,p_column_alias=>'DEFAULT_DATE'
,p_column_display_sequence=>40
,p_column_heading=>'Date plus Push Default'
,p_use_as_row_header=>'N'
,p_column_format=>'DD-MON-RR'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6691925554548681971)
,p_query_column_id=>4
,p_column_alias=>'MILESTONE_DESCRIPTION'
,p_column_display_sequence=>50
,p_column_heading=>'Milestone Description'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38602499093882000271)
,p_plug_name=>'Release'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188351742057575241)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38602506361529000304)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188501912119575289)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6686907233848054987)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38602506361529000304)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6686907611980054987)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(38602506361529000304)
,p_button_name=>'COPY'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Copy'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(6329461054289008107)
,p_branch_action=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.:117:P117_RELEASE_ID:&P63_NEW_RELEASE_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6329459601886008093)
,p_name=>'P63_PUSH_DAYS'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(38602499093882000271)
,p_prompt=>'Push Days'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>10
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(141188583993679575382)
,p_item_template_options=>'#DEFAULT#'
,p_restricted_characters=>'WEB_SAFE'
,p_help_text=>'The number of days to be added to each of the Milestone dates when the new Release is created.  The default is as if the release open of the selected release is today.'
,p_attribute_01=>'0'
,p_attribute_03=>'left'
,p_attribute_04=>'numeric'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6329459807555008095)
,p_name=>'P63_NEW_RELEASE_ID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(38602499093882000271)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6691924979837681966)
,p_name=>'P63_OPEN_DATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(38602499093882000271)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38602500388590000291)
,p_name=>'P63_COPY_FROM_RELEASE_ID'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(38602499093882000271)
,p_prompt=>'Copy From Release'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select release_train||'' ''||release || '' (open ''|| to_char(release_open_date,''DD-Mon-YY'')||'')'' d, id ',
'  from SP_RELEASE_TRAINS',
' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Release to Copy -'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(141188583993679575382)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38602501175615000295)
,p_name=>'P63_RELEASE'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(38602499093882000271)
,p_prompt=>'New Release'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(141188583993679575382)
,p_item_template_options=>'#DEFAULT#'
,p_restricted_characters=>'WEB_SAFE'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6686909128551054996)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(6686907233848054987)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6686909659689054999)
,p_event_id=>wwv_flow_imp.id(6686909128551054996)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6329459992605008097)
,p_name=>'refresh report when rel changes'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P63_COPY_FROM_RELEASE_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6329460073378008098)
,p_event_id=>wwv_flow_imp.id(6329459992605008097)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(23676568885514001286)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6691925107549681967)
,p_event_id=>wwv_flow_imp.id(6329459992605008097)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_name=>'default push days'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P63_PUSH_DAYS'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trunc(sysdate-release_open_date)',
'  from sp_release_trains',
' where id = :P63_COPY_FROM_RELEASE_ID'))
,p_attribute_07=>'P63_COPY_FROM_RELEASE_ID'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6329459744041008094)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Copy Release'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_strategic_proj_util.copy_release (',
'    p_copy_from_release_id => :P63_COPY_FROM_RELEASE_ID,',
'    p_new_release          => :P63_RELEASE,',
'    p_push_days            => :P63_PUSH_DAYS,',
'    p_new_release_id       => :P63_NEW_RELEASE_ID );'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Release failed to be copied.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Release copied.'
,p_internal_uid=>4463721975158362634
);
wwv_flow_imp.component_end;
end;
/
