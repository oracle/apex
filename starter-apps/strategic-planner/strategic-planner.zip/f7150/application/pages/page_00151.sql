prompt --application/pages/page_00151
begin
--   Manifest
--     PAGE: 00151
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>151
,p_name=>'Group Members'
,p_alias=>'GROUP-MEMBERS'
,p_step_title=>'Group Members'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(12076105398535035962)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.project-rds-region {',
'    background-color: rgb(219 204 175 / 20%);',
'}',
'.t-Body-title {',
'    --ut-palette-warning-shade: rgba(var(--oj-palette-neutral-rgb-160));',
'    --ut-component-background-color: rgba(var(--oj-palette-neutral-rgb-170)); ',
'    --ut-alert-horizontal-border-radius: 0;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(12065688736441871007)
,p_protection_level=>'C'
,p_page_component_map=>'25'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20240418003248'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10586228583469064861)
,p_plug_name=>'RDS'
,p_region_css_classes=>'u-padding-inline-dynamic project-rds-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141179964373655434900)
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'N'
,p_attribute_03=>'USER'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10586228668597064862)
,p_plug_name=>'Member &NOMENCLATURE_PROJECTS.'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141180093492639434928)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'       --',
'       -- IDs',
'       --',
'       p.ID as project_id,',
'       p.owner_id,',
'       --',
'       -- project information',
'       --',
'       p.PROJECT,',
'       (select FIRST_NAME ||'' ''||last_name from SP_TEAM_MEMBERS x where x.ID = p.OWNER_ID) the_owner,',
'       (select ''P''||PRIORITY from SP_PROJECT_PRIORITIES x where x.ID = p.PRIORITY_ID) priority,',
'       p.PCT_COMPLETE pct_complete,',
'       p.PROJECT_SIZE,',
'       p.friendly_identifier,',
'       p.project_url_name,',
'       replace(lower(p.tags),'','','', '') as tags,',
'       --',
'       -- favorite',
'       --',
'       nvl((',
'           select ''Yes'' ',
'           from sp_favorites f ',
'           where f.project_id = p.id and ',
'                 f.team_member_id = :P86_USER_ID),''No'') favorite,',
'       --',
'       -- project description',
'       --',
'       decode(nvl(dbms_lob.getlength(p.description),0),0,''Not Provided'',',
'           dbms_lob.substr(p.description,300,1)||',
'           decode(greatest(dbms_lob.getlength(p.description),300),300,null,''...'')) description,',
'       --',
'       -- contributors',
'       --',
'       rtrim((select tm.first_name||'' ''||tm.last_name ||'', '' x',
'        from SP_TEAM_MEMBERS tm ',
'        where tm.id = p.owner_id and p.owner_id not in (select pc.team_member_id from SP_PROJECT_CONTRIBUTORS pc where pc.project_id = p.id))||',
'       (select listagg(xtm.first_name||'' ''||xtm.last_name, '', '') within group (order by 1) names',
'       from SP_PROJECT_CONTRIBUTORS xpc, SP_TEAM_MEMBERS xtm',
'       where xpc.project_id = p.id and',
'             xpc.TEAM_MEMBER_ID = xtm.id',
'             ),'', '') contributors,',
'       --',
'       -- contributor emails',
'       --',
'       (select tm.email ||'', '' x',
'        from SP_TEAM_MEMBERS tm ',
'        where tm.id = p.owner_id and p.owner_id not in (select pc.team_member_id from SP_PROJECT_CONTRIBUTORS pc where pc.project_id = p.id))||',
'       (select listagg(xtm.email, '', '') within group (order by 1) names',
'       from SP_PROJECT_CONTRIBUTORS xpc, SP_TEAM_MEMBERS xtm',
'       where xpc.project_id = p.id and',
'             xpc.TEAM_MEMBER_ID = xtm.id',
'             ) contributor_emails,',
'       --',
'       -- reviewers',
'       --',
'       (select count(*) from SP_PROJECT_REVIEWS r where r.PROJECT_ID = p.id) reviews,',
'       (select count(*) from SP_PROJECT_REVIEWS r where r.PROJECT_ID = p.id and REVIEW_STATUS = ''COMPLETED'') completed_reviews,',
'       --',
'       -- updated',
'       --',
'       p.UPDATED,',
'       nvl((select first_name||'' ''||last_name from SP_TEAM_MEMBERS tm where tm.email = lower(p.updated_by)),lower(p.updated_by)) updated_by,',
'       --',
'       -- last comments',
'       --',
'       (select max(dbms_lob.substr(c.body,255,1)||',
'               decode(greatest(dbms_lob.getlength(c.body),255),255,null,''...'')) last_comment ',
'        from   SP_PROJECT_COMMENTS c ',
'        where c.project_id = p.id and ',
'              c.private_yn = ''N'' and ',
'              c.created = (select max(c2.created) from sp_project_comments c2 where c2.project_id = p.id and c2.private_yn = ''N''))',
'        as last_comment,',
'       --',
'       (select max(c.created) from sp_project_comments c where c.project_id = p.id and c.private_yn = ''N'') last_comment_on,',
'       (select first_name||'' ''||last_name from SP_TEAM_MEMBERS t where t.id = (select max(c.author_id) from sp_project_comments c where c.project_id = p.id and c.created = (select max(c.created) from sp_project_comments c where c.project_id = p.id an'
||'d c.private_yn = ''N''))) last_comment_by,',
'       --',
'       -- last owner comments',
'       --',
'       (select max(dbms_lob.substr(c.body,255,1)||',
'               decode(greatest(dbms_lob.getlength(c.body),255),255,null,''...'')) last_comment ',
'        from   SP_PROJECT_COMMENTS c ',
'        where c.project_id = p.id and ',
'              c.private_yn = ''N'' and ',
'              c.AUTHOR_ID = p.owner_id and',
'              c.created = (select max(c2.created) from sp_project_comments c2 where c2.project_id = p.id and c2.AUTHOR_ID = p.owner_id and c2.private_yn = ''N''))',
'        as last_comment_by_owner,',
'       --',
'       (select max(c.created) from sp_project_comments c where c.project_id = p.id and c.author_id = p.owner_id and c.private_yn = ''N'') last_comment_by_owner_on,',
'       (select count(*) from sp_project_comments c where c.project_id = p.id and c.created >= sysdate - 28 and c.private_yn = ''N'') comments_28d,',
'       --',
'       -- activity',
'       --',
'       nvl((select count(*) from SP_ACTIVITIES ap where ap.project_id = p.id and trunc(sysdate) >= ap.start_date and trunc(sysdate) <= ap.end_date),0) current_activity_count,',
'       --',
'       -- release',
'       --',
'       nvl(decode(',
'           p.RELEASE_DEPENDENT_YN,',
'           ''Y'',',
'           (select t.release_train||'' ''||t.release from SP_RELEASE_TRAINS t where t.id = p.release_id),',
'           decode(',
'               to_char(p.target_complete,''DD-MON-YYYY''),',
'               null,',
'               ''Not Targeted'',',
'               to_char(p.target_complete,''MON-YYYY'')',
'               )),''Not Targeted'')  release,',
'       --',
'       -- milestones',
'       --',
'       case when milestone1_label is not null then decode(milestone1_complete_yn,''Y'',s.milestone1_label||'' - Completed'',decode(milestone1_complete_date,null,s.milestone1_label||'' - No Date'',s.milestone1_label||'' - ''||to_char(milestone1_complete_date,'
||'''DD-MON''))) end m1,',
'       case when milestone2_label is not null then decode(milestone2_complete_yn,''Y'',s.milestone2_label||'' - Completed'',decode(milestone2_complete_date,null,s.milestone2_label||'' - No Date'',s.milestone2_label||'' - ''||to_char(milestone2_complete_date,'
||'''DD-MON''))) end m2,',
'       case when milestone3_label is not null then decode(milestone3_complete_yn,''Y'',s.milestone3_label||'' - Completed'',decode(milestone3_complete_date,null,s.milestone3_label||'' - No Date'',s.milestone3_label||'' - ''||to_char(milestone3_complete_date,'
||'''DD-MON''))) end m3,',
'       case when milestone4_label is not null then decode(milestone4_complete_yn,''Y'',s.milestone4_label||'' - Completed'',decode(milestone4_complete_date,null,s.milestone4_label||'' - No Date'',s.milestone4_label||'' - ''||to_char(milestone4_complete_date,'
||'''DD-MON''))) end m4,',
'       --',
'       -- initiative and area',
'       --',
'       i.initiative,',
'       (select focus_area from sp_focus_areas a where a.id = i.focus_area_id) area,',
'       --',
'       -- quick look',
'       --',
'       null quick_look',
'from  SP_PROJECTS p,',
'      sp_project_scales s,',
'      sp_initiatives i',
'where nvl(p.ARCHIVED_YN,''N'') = ''N'' and ',
'      p.DUPLICATE_OF_PROJECT_ID is null and',
'      p.status_scale = s.scale_letter and ',
'      p.initiative_id = i.id and ',
'      p.OWNER_ID in (select team_member_id from SP_GROUP_MEMBERS gm where gm.group_id = :P151_GROUP_ID)'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P151_GROUP_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Member &NOMENCLATURE_PROJECTS.'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(10586228772400064863)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MIKE'
,p_internal_uid=>8728879724218559746
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10586228913274064864)
,p_db_column_name=>'PROJECT_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Project Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10586229037442064865)
,p_db_column_name=>'OWNER_ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Owner Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10586229097961064866)
,p_db_column_name=>'PROJECT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Project'
,p_column_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:FI,PN:#FRIENDLY_IDENTIFIER#,#PROJECT_URL_NAME#'
,p_column_linktext=>'#PROJECT#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10586229165195064867)
,p_db_column_name=>'THE_OWNER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Owner'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865372199227073318)
,p_db_column_name=>'PRIORITY'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Priority'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865372346875073319)
,p_db_column_name=>'PCT_COMPLETE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Complete'
,p_column_html_expression=>'#PCT_COMPLETE#%'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865372431105073320)
,p_db_column_name=>'PROJECT_SIZE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Size'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865372488442073321)
,p_db_column_name=>'FRIENDLY_IDENTIFIER'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Friendly Identifier'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865372620790073322)
,p_db_column_name=>'PROJECT_URL_NAME'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Project Url Name'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865372649513073323)
,p_db_column_name=>'TAGS'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Tags'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865372844112073324)
,p_db_column_name=>'FAVORITE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Favorite'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865372937429073325)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865373033766073326)
,p_db_column_name=>'CONTRIBUTORS'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Contributors'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865373067801073327)
,p_db_column_name=>'CONTRIBUTOR_EMAILS'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Contributor Emails'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865373173434073328)
,p_db_column_name=>'REVIEWS'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Reviews'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865373346086073329)
,p_db_column_name=>'COMPLETED_REVIEWS'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Completed Reviews'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865373354100073330)
,p_db_column_name=>'UPDATED'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865373452249073331)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865373600043073332)
,p_db_column_name=>'LAST_COMMENT'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Last Comment'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865373704779073333)
,p_db_column_name=>'LAST_COMMENT_ON'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Last Comment On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865373836344073334)
,p_db_column_name=>'LAST_COMMENT_BY'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Last Comment By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865373895320073335)
,p_db_column_name=>'LAST_COMMENT_BY_OWNER'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Last Comment By Owner'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865373998820073336)
,p_db_column_name=>'LAST_COMMENT_BY_OWNER_ON'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Last Comment By Owner On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865374127121073337)
,p_db_column_name=>'COMMENTS_28D'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Comments 28d'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865374221062073338)
,p_db_column_name=>'CURRENT_ACTIVITY_COUNT'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Current Activity Count'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865374302857073339)
,p_db_column_name=>'RELEASE'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Release'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865374373665073340)
,p_db_column_name=>'M1'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'M1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865374476844073341)
,p_db_column_name=>'M2'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'M2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865374562636073342)
,p_db_column_name=>'M3'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'M3'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865374716415073343)
,p_db_column_name=>'M4'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'M4'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865374814830073344)
,p_db_column_name=>'INITIATIVE'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Initiative'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865374906598073345)
,p_db_column_name=>'AREA'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Area'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10865374967021073346)
,p_db_column_name=>'QUICK_LOOK'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Quick Look'
,p_column_link=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:RP,36:P36_ID:#PROJECT_ID#'
,p_column_linktext=>'<span class="fa fa-align-justify" aria-hidden="true"></span>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(10865262064206718748)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'90079131'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'INITIATIVE:PROJECT:THE_OWNER:RELEASE:PRIORITY:PCT_COMPLETE:PROJECT_SIZE:TAGS:FAVORITE:UPDATED:M1:M2:M3:M4:QUICK_LOOK:'
,p_sort_column_1=>'UPDATED'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10846485082612379268)
,p_plug_name=>'Group Members'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141180093492639434928)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select gm.ID,',
'       gm.GROUP_ID,',
'       gm.TEAM_MEMBER_ID,',
'       (select first_name||'' ''||last_name from sp_team_members tm where tm.id = gm.TEAM_MEMBER_ID) group_member,',
'       (select email from sp_team_members tm where tm.id = gm.TEAM_MEMBER_ID) email,',
'       gm.ASSIGNMENT,',
'       gm.CREATED,',
'       gm.CREATED_BY,',
'       gm.UPDATED,',
'       gm.UPDATED_BY,',
'       decode(nvl(gm.full_time_yn,''N''),''Y'',''Yes'',''N'',''No'') full_time,',
'       decode(nvl(gm.group_leader_yn,''N''),''Y'',''Yes'',''N'',''No'') leader',
'  from SP_GROUP_MEMBERS gm',
'  where gm.group_id = :P151_GROUP_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Group Members'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(10846485217356379268)
,p_name=>'Group Members'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:152:&APP_SESSION.::&DEBUG.:RP:P152_ID:\#ID#\'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(141180225296450435141)
,p_owner=>'MIKE'
,p_internal_uid=>8989136169174874151
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10846485589493379271)
,p_db_column_name=>'ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10846486798597379273)
,p_db_column_name=>'ASSIGNMENT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Assignment'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10846487121317379273)
,p_db_column_name=>'CREATED'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10846487493814379274)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10846487942366379274)
,p_db_column_name=>'UPDATED'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10846488311823379275)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10586227843401064853)
,p_db_column_name=>'GROUP_ID'
,p_display_order=>18
,p_column_identifier=>'I'
,p_column_label=>'Group Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10586227940749064854)
,p_db_column_name=>'TEAM_MEMBER_ID'
,p_display_order=>28
,p_column_identifier=>'J'
,p_column_label=>'Team Member Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10586227982349064855)
,p_db_column_name=>'GROUP_MEMBER'
,p_display_order=>38
,p_column_identifier=>'K'
,p_column_label=>'Group Member'
,p_column_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:RP,5:P5_ID:#TEAM_MEMBER_ID#'
,p_column_linktext=>'#GROUP_MEMBER#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10586228103841064856)
,p_db_column_name=>'EMAIL'
,p_display_order=>48
,p_column_identifier=>'L'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11901262152740267449)
,p_db_column_name=>'FULL_TIME'
,p_display_order=>58
,p_column_identifier=>'M'
,p_column_label=>'Full Time'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11901262269690267450)
,p_db_column_name=>'LEADER'
,p_display_order=>68
,p_column_identifier=>'N'
,p_column_label=>'Leader'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(10846523441885386893)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'89891744'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'GROUP_MEMBER:EMAIL:ASSIGNMENT:FULL_TIME:LEADER:UPDATED:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11901263832252267465)
,p_plug_name=>'Description'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141179964373655434900)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   x clob;',
'begin',
'   for c1 in (select description from SP_GROUPS where id = :P151_GROUP_ID) loop',
'       x := apex_escape.html(c1.description);',
'   end loop;',
'   return x;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12067745316825592519)
,p_plug_name=>'Associated &NOMENCLATURE_PROJECTS.'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141180093492639434928)
,p_plug_display_sequence=>31
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'       --',
'       -- IDs',
'       --',
'       p.ID as project_id,',
'       p.owner_id,',
'       --',
'       -- project information',
'       --',
'       p.PROJECT,',
'       (select FIRST_NAME ||'' ''||last_name from SP_TEAM_MEMBERS x where x.ID = p.OWNER_ID) the_owner,',
'       (select ''P''||PRIORITY from SP_PROJECT_PRIORITIES x where x.ID = p.PRIORITY_ID) priority,',
'       p.PCT_COMPLETE pct_complete,',
'       p.PROJECT_SIZE,',
'       p.friendly_identifier,',
'       p.project_url_name,',
'       replace(lower(p.tags),'','','', '') as tags,',
'       --',
'       -- favorite',
'       --',
'       nvl((',
'           select ''Yes'' ',
'           from sp_favorites f ',
'           where f.project_id = p.id and ',
'                 f.team_member_id = :P86_USER_ID),''No'') favorite,',
'       --',
'       -- project description',
'       --',
'       decode(nvl(dbms_lob.getlength(p.description),0),0,''Not Provided'',',
'           dbms_lob.substr(p.description,300,1)||',
'           decode(greatest(dbms_lob.getlength(p.description),300),300,null,''...'')) description,',
'       --',
'       -- contributors',
'       --',
'       rtrim((select tm.first_name||'' ''||tm.last_name ||'', '' x',
'        from SP_TEAM_MEMBERS tm ',
'        where tm.id = p.owner_id and p.owner_id not in (select pc.team_member_id from SP_PROJECT_CONTRIBUTORS pc where pc.project_id = p.id))||',
'       (select listagg(xtm.first_name||'' ''||xtm.last_name, '', '') within group (order by 1) names',
'       from SP_PROJECT_CONTRIBUTORS xpc, SP_TEAM_MEMBERS xtm',
'       where xpc.project_id = p.id and',
'             xpc.TEAM_MEMBER_ID = xtm.id',
'             ),'', '') contributors,',
'       --',
'       -- contributor emails',
'       --',
'       (select tm.email ||'', '' x',
'        from SP_TEAM_MEMBERS tm ',
'        where tm.id = p.owner_id and p.owner_id not in (select pc.team_member_id from SP_PROJECT_CONTRIBUTORS pc where pc.project_id = p.id))||',
'       (select listagg(xtm.email, '', '') within group (order by 1) names',
'       from SP_PROJECT_CONTRIBUTORS xpc, SP_TEAM_MEMBERS xtm',
'       where xpc.project_id = p.id and',
'             xpc.TEAM_MEMBER_ID = xtm.id',
'             ) contributor_emails,',
'       --',
'       -- reviewers',
'       --',
'       (select count(*) from SP_PROJECT_REVIEWS r where r.PROJECT_ID = p.id) reviews,',
'       (select count(*) from SP_PROJECT_REVIEWS r where r.PROJECT_ID = p.id and REVIEW_STATUS = ''COMPLETED'') completed_reviews,',
'       --',
'       -- updated',
'       --',
'       p.UPDATED,',
'       nvl((select first_name||'' ''||last_name from SP_TEAM_MEMBERS tm where tm.email = lower(p.updated_by)),lower(p.updated_by)) updated_by,',
'       --',
'       -- last comments',
'       --',
'       (select max(dbms_lob.substr(c.body,255,1)||',
'               decode(greatest(dbms_lob.getlength(c.body),255),255,null,''...'')) last_comment ',
'        from   SP_PROJECT_COMMENTS c ',
'        where c.project_id = p.id and ',
'              c.private_yn = ''N'' and ',
'              c.created = (select max(c2.created) from sp_project_comments c2 where c2.project_id = p.id and c2.private_yn = ''N''))',
'        as last_comment,',
'       --',
'       (select max(c.created) from sp_project_comments c where c.project_id = p.id and c.private_yn = ''N'') last_comment_on,',
'       (select first_name||'' ''||last_name from SP_TEAM_MEMBERS t where t.id = (select max(c.author_id) from sp_project_comments c where c.project_id = p.id and c.created = (select max(c.created) from sp_project_comments c where c.project_id = p.id an'
||'d c.private_yn = ''N''))) last_comment_by,',
'       --',
'       -- last owner comments',
'       --',
'       (select max(dbms_lob.substr(c.body,255,1)||',
'               decode(greatest(dbms_lob.getlength(c.body),255),255,null,''...'')) last_comment ',
'        from   SP_PROJECT_COMMENTS c ',
'        where c.project_id = p.id and ',
'              c.private_yn = ''N'' and ',
'              c.AUTHOR_ID = p.owner_id and',
'              c.created = (select max(c2.created) from sp_project_comments c2 where c2.project_id = p.id and c2.AUTHOR_ID = p.owner_id and c2.private_yn = ''N''))',
'        as last_comment_by_owner,',
'       --',
'       (select max(c.created) from sp_project_comments c where c.project_id = p.id and c.author_id = p.owner_id and c.private_yn = ''N'') last_comment_by_owner_on,',
'       (select count(*) from sp_project_comments c where c.project_id = p.id and c.created >= sysdate - 28 and c.private_yn = ''N'') comments_28d,',
'       --',
'       -- activity',
'       --',
'       nvl((select count(*) from SP_ACTIVITIES ap where ap.project_id = p.id and trunc(sysdate) >= ap.start_date and trunc(sysdate) <= ap.end_date),0) current_activity_count,',
'       --',
'       -- release',
'       --',
'       nvl(decode(',
'           p.RELEASE_DEPENDENT_YN,',
'           ''Y'',',
'           (select t.release_train||'' ''||t.release from SP_RELEASE_TRAINS t where t.id = p.release_id),',
'           decode(',
'               to_char(p.target_complete,''DD-MON-YYYY''),',
'               null,',
'               ''Not Targeted'',',
'               to_char(p.target_complete,''MON-YYYY'')',
'               )),''Not Targeted'')  release,',
'       --',
'       -- milestones',
'       --',
'       case when milestone1_label is not null then decode(milestone1_complete_yn,''Y'',s.milestone1_label||'' - Completed'',decode(milestone1_complete_date,null,s.milestone1_label||'' - No Date'',s.milestone1_label||'' - ''||to_char(milestone1_complete_date,'
||'''DD-MON''))) end m1,',
'       case when milestone2_label is not null then decode(milestone2_complete_yn,''Y'',s.milestone2_label||'' - Completed'',decode(milestone2_complete_date,null,s.milestone2_label||'' - No Date'',s.milestone2_label||'' - ''||to_char(milestone2_complete_date,'
||'''DD-MON''))) end m2,',
'       case when milestone3_label is not null then decode(milestone3_complete_yn,''Y'',s.milestone3_label||'' - Completed'',decode(milestone3_complete_date,null,s.milestone3_label||'' - No Date'',s.milestone3_label||'' - ''||to_char(milestone3_complete_date,'
||'''DD-MON''))) end m3,',
'       case when milestone4_label is not null then decode(milestone4_complete_yn,''Y'',s.milestone4_label||'' - Completed'',decode(milestone4_complete_date,null,s.milestone4_label||'' - No Date'',s.milestone4_label||'' - ''||to_char(milestone4_complete_date,'
||'''DD-MON''))) end m4,',
'       --',
'       -- initiative and area',
'       --',
'       i.initiative,',
'       (select focus_area from sp_focus_areas a where a.id = i.focus_area_id) area,',
'       --',
'       -- quick look',
'       --',
'       null quick_look',
'from  SP_PROJECTS p,',
'      sp_project_scales s,',
'      sp_initiatives i',
'where nvl(p.ARCHIVED_YN,''N'') = ''N'' and ',
'      p.DUPLICATE_OF_PROJECT_ID is null and',
'      p.status_scale = s.scale_letter and ',
'      p.initiative_id = i.id and ',
'      instr(',
'          '',''||p.tags||'','',',
'          '',''||:P151_GROUP_TAG||'',''',
'          ) > 0 and',
'      :P151_GROUP_TAG is not null'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P151_GROUP_TAG'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Associated &NOMENCLATURE_PROJECTS.'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(12067745405296592520)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MIKE'
,p_internal_uid=>10210396357115087403
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067745544054592521)
,p_db_column_name=>'PROJECT_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Project Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067745579801592522)
,p_db_column_name=>'OWNER_ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Owner Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067745678958592523)
,p_db_column_name=>'PROJECT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Project'
,p_column_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:FI,PN:#FRIENDLY_IDENTIFIER#,#PROJECT_URL_NAME#'
,p_column_linktext=>'#PROJECT#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067745784830592524)
,p_db_column_name=>'THE_OWNER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Owner'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067745866564592525)
,p_db_column_name=>'PRIORITY'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Priority'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067746014004592526)
,p_db_column_name=>'PCT_COMPLETE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Complete'
,p_column_html_expression=>'#PCT_COMPLETE#%'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067746059009592527)
,p_db_column_name=>'PROJECT_SIZE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Size'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067746201840592528)
,p_db_column_name=>'FRIENDLY_IDENTIFIER'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Friendly Identifier'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067746316919592529)
,p_db_column_name=>'PROJECT_URL_NAME'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Project Url Name'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067746349904592530)
,p_db_column_name=>'TAGS'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Tags'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067746495093592531)
,p_db_column_name=>'FAVORITE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Favorite'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067746550629592532)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067746679031592533)
,p_db_column_name=>'CONTRIBUTORS'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Contributors'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067746825796592534)
,p_db_column_name=>'CONTRIBUTOR_EMAILS'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Contributor Emails'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067746940299592535)
,p_db_column_name=>'REVIEWS'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Reviews'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067746954089592536)
,p_db_column_name=>'COMPLETED_REVIEWS'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Completed Reviews'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067747147880592537)
,p_db_column_name=>'UPDATED'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067747239236592538)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067747322147592539)
,p_db_column_name=>'LAST_COMMENT'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Last Comment'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067747394397592540)
,p_db_column_name=>'LAST_COMMENT_ON'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Last Comment On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067747464536592541)
,p_db_column_name=>'LAST_COMMENT_BY'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Last Comment By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067747624460592542)
,p_db_column_name=>'LAST_COMMENT_BY_OWNER'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Last Comment By Owner'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067747719973592543)
,p_db_column_name=>'LAST_COMMENT_BY_OWNER_ON'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Last Comment By Owner On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067747842819592544)
,p_db_column_name=>'COMMENTS_28D'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Comments 28d'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067747933234592545)
,p_db_column_name=>'CURRENT_ACTIVITY_COUNT'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Current Activity Count'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067747955130592546)
,p_db_column_name=>'RELEASE'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Release'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067748064440592547)
,p_db_column_name=>'M1'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'M1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067748240063592548)
,p_db_column_name=>'M2'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'M2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067748316728592549)
,p_db_column_name=>'M3'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'M3'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067748403903592550)
,p_db_column_name=>'M4'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'M4'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067748484603592551)
,p_db_column_name=>'INITIATIVE'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Initiative'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067748631487592552)
,p_db_column_name=>'AREA'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Area'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12067748654140592553)
,p_db_column_name=>'QUICK_LOOK'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Quick Look'
,p_column_link=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:RP,36:P36_ID:#PROJECT_ID#'
,p_column_linktext=>'<span class="fa fa-align-justify" aria-hidden="true"></span>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(12067917461778622448)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'102105685'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PROJECT:THE_OWNER:PRIORITY:PROJECT_SIZE:TAGS:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28852501748053011699)
,p_plug_name=>'Breadcrumb'
,p_region_sub_css_classes=>'has-header-actions'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141180108021956434943)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(141179926085158434823)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(141180198231173435047)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29716845103086026517)
,p_plug_name=>'Menubar'
,p_parent_plug_id=>wwv_flow_imp.id(28852501748053011699)
,p_region_sub_css_classes=>'header-actions'
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>'select 1 as actions from dual'
,p_template_component_type=>'PARTIAL'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_attributes=>wwv_flow_string.join_clob(wwv_flow_t_varchar2('{',
  '"APPLY_THEME_COLORS": "Y",',
  '"AVATAR_ICON": "fa-user",',
  '"AVATAR_SHAPE": "t-Avatar--rounded",',
  '"AVATAR_TYPE": "icon",',
  '"BADGE_COL_WIDTH": "t-ContentRow-badge--md",',
  '"BADGE_LABEL_DISPLAY": "N",',
  '"DISPLAY_AVATAR": "N",',
  '"DISPLAY_BADGE": "N",',
  '"HIDE_BORDERS": "N",',
  '"REMOVE_PADDING": "N"',
'}'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(29716846336592026529)
,p_name=>'ACTIONS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIONS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(48083601493779611926)
,p_name=>'Group'
,p_template=>wwv_flow_imp.id(141180095591799434930)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:t-Region--scrollBody:t-Region-orderBy--end:margin-left-md'
,p_component_template_options=>'#DEFAULT#:t-ContextualInfo-label--stacked'
,p_display_point=>'REGION_POSITION_01'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select g.group_name, g.id, g.created, g.updated,',
'       (select count(*) from SP_GROUP_MEMBERS gm where gm.group_id = g.id) members, group_tag',
'from SP_GROUPS  g',
'where g.id = :P151_GROUP_ID'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141180154054191434984)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10586227057025064846)
,p_query_column_id=>1
,p_column_alias=>'GROUP_NAME'
,p_column_display_sequence=>20
,p_column_heading=>'Group Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10846710768163053963)
,p_query_column_id=>2
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10586227238363064847)
,p_query_column_id=>3
,p_column_alias=>'CREATED'
,p_column_display_sequence=>40
,p_column_heading=>'Created'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10586227334974064848)
,p_query_column_id=>4
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>50
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10865375114218073347)
,p_query_column_id=>5
,p_column_alias=>'MEMBERS'
,p_column_display_sequence=>60
,p_column_heading=>'Members'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11901263634942267463)
,p_query_column_id=>6
,p_column_alias=>'GROUP_TAG'
,p_column_display_sequence=>30
,p_column_heading=>'Group Tag'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10846761319813390811)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(28852501748053011699)
,p_button_name=>'UP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141180195946138435041)
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10586226967800064845)
,p_name=>'P151_GROUP_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10846485082612379268)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10586228159326064857)
,p_name=>'P151_GROUP_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10846485082612379268)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12067748764263592554)
,p_name=>'P151_GROUP_TAG'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10586228264254064858)
,p_computation_sequence=>10
,p_computation_item=>'P151_GROUP_NAME'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>'select group_name from sp_groups g where g.id = :P151_GROUP_ID'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10865375212804073348)
,p_computation_sequence=>20
,p_computation_item=>'LAST_PROJECT_VIEW'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'151'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(12067749120655592557)
,p_computation_sequence=>30
,p_computation_item=>'P151_GROUP_TAG'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>'select group_tag from sp_groups where id = :P151_GROUP_ID'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10846489055848379276)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(10846485082612379268)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10846489623056379276)
,p_event_id=>wwv_flow_imp.id(10846489055848379276)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10846485082612379268)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10586227384025064849)
,p_name=>'create button dialog close'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(28852501748053011699)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10586227513958064850)
,p_event_id=>wwv_flow_imp.id(10586227384025064849)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10846485082612379268)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10586227580535064851)
,p_name=>'refresh on page edit'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(10846485082612379268)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10586227730408064852)
,p_event_id=>wwv_flow_imp.id(10586227580535064851)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10846485082612379268)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11901263889639267466)
,p_name=>'refresh on breadcrumb dialog close'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(28852501748053011699)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11901263993466267467)
,p_event_id=>wwv_flow_imp.id(11901263889639267466)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(48083601493779611926)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12067745227545592518)
,p_event_id=>wwv_flow_imp.id(11901263889639267466)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10846485082612379268)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12067749229347592558)
,p_event_id=>wwv_flow_imp.id(11901263889639267466)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11901263832252267465)
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(25828372925883769141)
,p_region_id=>wwv_flow_imp.id(29716845103086026517)
,p_position_id=>wwv_flow_imp.id(3709248475127512461)
,p_display_sequence=>10
,p_template_id=>wwv_flow_imp.id(3709249076804543590)
,p_label=>'Add Group Member'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:152:&SESSION.::&DEBUG.:RP,152:P152_GROUP_ID:&P151_GROUP_ID.'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-plus'
,p_is_hot=>true
,p_show_as_disabled=>false
,p_authorization_scheme=>wwv_flow_imp.id(141180225296450435141)
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(29716845403665026520)
,p_region_id=>wwv_flow_imp.id(29716845103086026517)
,p_position_id=>wwv_flow_imp.id(3709248475127512461)
,p_display_sequence=>20
,p_template_id=>wwv_flow_imp.id(3709250336324547738)
,p_label=>'Actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(11901263685814267464)
,p_component_action_id=>wwv_flow_imp.id(29716845403665026520)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Edit Group'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:150:&SESSION.::&DEBUG.:RP,150:P150_ID:&P151_GROUP_ID.'
,p_icon_css_classes=>'fa-edit'
,p_authorization_scheme=>wwv_flow_imp.id(141180225296450435141)
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(12067749431013592560)
,p_component_action_id=>wwv_flow_imp.id(29716845403665026520)
,p_menu_entry_type=>'ENTRY'
,p_label=>'About Groups'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:145:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-info'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(23931831739525091307)
,p_component_action_id=>wwv_flow_imp.id(29716845403665026520)
,p_menu_entry_type=>'SEPARATOR'
,p_display_sequence=>30
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(26948166132692123786)
,p_component_action_id=>wwv_flow_imp.id(29716845403665026520)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Reset'
,p_display_sequence=>50
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.:RP,151::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(29716846109572026527)
,p_component_action_id=>wwv_flow_imp.id(29716845403665026520)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Refresh'
,p_display_sequence=>40
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp.component_end;
end;
/
