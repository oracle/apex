prompt --application/pages/page_00040
begin
--   Manifest
--     PAGE: 00040
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>40
,p_name=>'Contributor Checklist'
,p_alias=>'CONTRIBUTOR-CHECKLIST'
,p_step_title=>'Contributor Checklist'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(141188613913166575484)
,p_protection_level=>'C'
,p_page_component_map=>'27'
,p_last_updated_by=>'SBKENNED'
,p_last_upd_yyyymmddhh24miss=>'20240411145434'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5551566001286794497)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188496742657575286)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(141188314805859575166)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(141188586951874575390)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7126002470078625814)
,p_plug_name=>'Your Responsibilities as a contributor to &NOMENCLATURE_STRATEGIC_PLANNER.'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(141188484312500575273)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       DISPLAY_SEQUENCE,',
'       replace(replace(CHECKLIST_ACTIVITY,',
'           ''#NOMENCLATURE_PROJECT#'', :NOMENCLATURE_PROJECT',
'           ),''#NOMENCLATURE_PROJECTS#'', :NOMENCLATURE_PROJECTS)',
'            CHECKLIST_ACTIVITY,',
'       replace(replace(WHY_IMPORTANT,',
'           ''#NOMENCLATURE_PROJECT#'', :NOMENCLATURE_PROJECT',
'           ),''#NOMENCLATURE_PROJECTS#'', :NOMENCLATURE_PROJECTS)',
'            WHY_IMPORTANT,',
'       HOW_TO_CHECK,',
'       LINK_TO_PAGE,',
'       CREATED,',
'       CREATED_BY,',
'       UPDATED,',
'       UPDATED_BY',
'  from SP_CONTRIBUTOR_CHECKLIST',
'  where active_yn = ''Y''',
'  order by DISPLAY_SEQUENCE'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_string.join_clob(wwv_flow_t_varchar2('{',
  '"TITLE": "\u0026CHECKLIST_ACTIVITY.",',
  '"DESCRIPTION": "\u0026WHY_IMPORTANT.",',
  '"DISPLAY_AVATAR": "Y",',
  '"DISPLAY_BADGE": "N",',
  '"AVATAR_TYPE": "icon",',
  '"AVATAR_ICON": "fa-check",',
  '"AVATAR_SHAPE": "t-Avatar--rounded",',
  '"APPLY_THEME_COLORS": "Y"',
'}'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7126002568978625815)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7126002606708625816)
,p_name=>'DISPLAY_SEQUENCE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DISPLAY_SEQUENCE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7126002718671625817)
,p_name=>'CHECKLIST_ACTIVITY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CHECKLIST_ACTIVITY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7126002876346625818)
,p_name=>'WHY_IMPORTANT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'WHY_IMPORTANT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7126002944256625819)
,p_name=>'HOW_TO_CHECK'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HOW_TO_CHECK'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7126003077394625820)
,p_name=>'LINK_TO_PAGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LINK_TO_PAGE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7126003141105625821)
,p_name=>'CREATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7126003221384625822)
,p_name=>'CREATED_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_BY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7126003294115625823)
,p_name=>'UPDATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UPDATED'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7126003473571625824)
,p_name=>'UPDATED_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UPDATED_BY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>100
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5551708622167816863)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5551566001286794497)
,p_button_name=>'UP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141188584666839575384)
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(7126003529648625825)
,p_region_id=>wwv_flow_imp.id(7126002470078625814)
,p_position_id=>wwv_flow_imp.id(10407406505956702127)
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:&LINK_TO_PAGE.:&SESSION.::&DEBUG.:RP,::'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(7126003632685625826)
,p_region_id=>wwv_flow_imp.id(7126002470078625814)
,p_position_id=>wwv_flow_imp.id(10420999532954077731)
,p_display_sequence=>20
,p_template_id=>wwv_flow_imp.id(10421001394151113008)
,p_label=>'Actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_action_css_classes=>'t-Button--noUI'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(7126003693543625827)
,p_component_action_id=>wwv_flow_imp.id(7126003632685625826)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Take Action'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:&LINK_TO_PAGE.:&SESSION.::&DEBUG.:RP,&LINK_TO_PAGE.::'
,p_icon_css_classes=>'fa-gear'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(7126004040390625830)
,p_component_action_id=>wwv_flow_imp.id(7126003632685625826)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Edit'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:122:&SESSION.::&DEBUG.:122:P122_ID:&ID.'
,p_icon_css_classes=>'fa-edit'
,p_authorization_scheme=>wwv_flow_imp.id(141188613860866575484)
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(7126004171173625831)
,p_component_action_id=>wwv_flow_imp.id(7126003632685625826)
,p_menu_entry_type=>'ENTRY'
,p_label=>'About this Item'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:123:&SESSION.::&DEBUG.:123:P123_ID:&ID.'
,p_icon_css_classes=>'fa-info'
);
wwv_flow_imp.component_end;
end;
/
