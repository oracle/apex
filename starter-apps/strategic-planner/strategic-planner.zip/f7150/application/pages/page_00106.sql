prompt --application/pages/page_00106
begin
--   Manifest
--     PAGE: 00106
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>106
,p_name=>'Initiative'
,p_alias=>'INITIATIVEABOUT'
,p_page_mode=>'MODAL'
,p_step_title=>'&NOMENCLATURE_INITIATIVE.'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2101883943284197310
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39636837560859375560)
,p_plug_name=>'About'
,p_static_id=>'about'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'An &NOMENCLATURE_INITIATIVE. is a way to organize &NOMENCLATURE_PROJECTS..  ',
'&NOMENCLATURE_INITIATIVES. also subdivide &NOMENCLATURE_AREAS..',
'</p>',
'<p>',
'The goal is to more easily locate a specific &NOMENCLATURE_PROJECT. within a large list of &NOMENCLATURE_PROJECTS..  ',
'</p>',
'<p>',
'     Click on a &NOMENCLATURE_INITIATIVE. to view the &NOMENCLATURE_PROJECTS. defined for the &NOMENCLATURE_INITIATIVE..',
'</p>',
'<p>',
'    Content Organization:<br><br>',
'     &NOMENCLATURE_AREAS. >  <strong>&NOMENCLATURE_INITIATIVES.</strong> >  &NOMENCLATURE_PROJECTS.',
'</p>',
'<br />',
'<br />'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41117985641936845447)
,p_plug_name=>'button container'
,p_static_id=>'button-container'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38305733447626240365)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(41117985641936845447)
,p_button_name=>'what_is_a_project'
,p_static_id=>'what-is-a-project'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'About &NOMENCLATURE_PROJECTS.'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:107:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa=info'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38305733880708240367)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(41117985641936845447)
,p_button_name=>'what_is_a_release'
,p_static_id=>'what-is-a-release'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'About Releases'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:108:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa=info'
,p_required_patch=>wwv_flow_imp.id(41242229044170008235)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38305734206672240367)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(41117985641936845447)
,p_button_name=>'what_is_activity'
,p_static_id=>'what-is-activity'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'About Activities'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa=info'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38303800229893703450)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(41117985641936845447)
,p_button_name=>'what_is_an_area'
,p_static_id=>'what-is-an-area'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'About &NOMENCLATURE_AREAS.'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:105:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa=info'
);
wwv_flow_imp.component_end;
end;
/
