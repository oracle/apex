prompt --application/pages/page_00073
begin
--   Manifest
--     PAGE: 00073
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>73
,p_name=>'User Quick Look'
,p_alias=>'USER-QUICK-LOOK'
,p_page_mode=>'MODAL'
,p_step_title=>'&NOMENCLATURE_USER. Quick Look'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.sp-tag {',
'    padding: 2px 4px;',
'    display: inline-block;',
'    vertical-align: text-bottom;',
'    border-radius: 3px;',
'    background-color: rgba(0,0,0,.1);',
'    text-overflow: ellipsis;',
'    white-space: nowrap;',
'}',
'.sp-tags-container {',
'    display: flex;',
'    align-items: center;',
'    flex-wrap: wrap;',
'    gap: 4px;',
'    justify-content: flex-start;',
'}'))
,p_step_template=>wwv_flow_imp.id(141188315653614575172)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'27'
,p_last_updated_by=>'SHAKEEB'
,p_last_upd_yyyymmddhh24miss=>'20240418172712'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(4734401105572791186)
,p_name=>'&NOMENCLATURE_USER. Details'
,p_template=>wwv_flow_imp.id(141188353094356575243)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:margin-top-sm'
,p_component_template_options=>'#DEFAULT#:t-ContextualInfo-label--stacked:t-Report--hideNoPagination'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tm.ID,',
'       tm.FIRST_NAME||'' ''||tm.LAST_NAME name,',
'       tm.EMAIL,',
'       replace(lower(tm.TAGS),'','','', '') tags,',
'       rtrim(replace(tm.competencies,'','','', '')) competencies,',
'       decode(tm.is_current_yn,''Y'',''Yes'',''N'',''No'',tm.is_current_yn) IS_CURRENT_YN,',
'       tm.created,',
'       tm.updated',
'from SP_TEAM_MEMBERS tm',
'where id = :P73_TEAM_MEMBER_ID'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P73_TEAM_MEMBER_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141188542774892575327)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4734401189379791187)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4734401315827791188)
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>20
,p_column_heading=>'Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4734401596913791191)
,p_query_column_id=>3
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>50
,p_column_heading=>'Email'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4734401829168791193)
,p_query_column_id=>4
,p_column_alias=>'TAGS'
,p_column_display_sequence=>130
,p_column_heading=>'Tags'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16753087866792553496)
,p_query_column_id=>5
,p_column_alias=>'COMPETENCIES'
,p_column_display_sequence=>120
,p_column_heading=>'Competencies'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>'select 1 from sp_team_members where competencies is not null and id = :P73_TEAM_MEMBER_ID'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4734402009780791195)
,p_query_column_id=>6
,p_column_alias=>'IS_CURRENT_YN'
,p_column_display_sequence=>90
,p_column_heading=>'Current'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6668923326580451798)
,p_query_column_id=>7
,p_column_alias=>'CREATED'
,p_column_display_sequence=>100
,p_column_heading=>'Created'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6668923416299451799)
,p_query_column_id=>8
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>110
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5963094591813961687)
,p_plug_name=>'Button Container'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188501912119575289)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(11636567349894603388)
,p_name=>'Associated Groups'
,p_template=>wwv_flow_imp.id(141188484312500575273)
,p_display_sequence=>70
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select g.GROUP_NAME, gm.CREATED added_to_group, g.id group_id, ',
'       (select count(*) from SP_GROUP_MEMBERS x where x.group_id = gm.group_id) members,',
'       decode(nvl(full_time_yn,''N''),''Y'',''Yes'',''No'') full_time,',
'       decode(nvl(group_leader_yn,''N''),''Y'',''Yes'',''No'') group_leader',
'from   SP_GROUP_MEMBERS gm,',
'       SP_GROUPS g',
'where  TEAM_MEMBER_ID = :P73_TEAM_MEMBER_ID and',
'       g.id = gm.GROUP_ID',
'order by upper(g.group_name)'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141188543836701575328)
,p_query_num_rows=>150
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11636567420965603389)
,p_query_column_id=>1
,p_column_alias=>'GROUP_NAME'
,p_column_display_sequence=>20
,p_column_heading=>'Group Name'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.:RP,151:P151_GROUP_ID:#GROUP_ID#'
,p_column_linktext=>'#GROUP_NAME#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11636567472659603390)
,p_query_column_id=>2
,p_column_alias=>'ADDED_TO_GROUP'
,p_column_display_sequence=>80
,p_column_heading=>'Added'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE_SHORT'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11636567663605603391)
,p_query_column_id=>3
,p_column_alias=>'GROUP_ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11636567700000603392)
,p_query_column_id=>4
,p_column_alias=>'MEMBERS'
,p_column_display_sequence=>70
,p_column_heading=>'Group Members'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11909650487563407788)
,p_query_column_id=>5
,p_column_alias=>'FULL_TIME'
,p_column_display_sequence=>50
,p_column_heading=>'Full Time'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11909650571335407789)
,p_query_column_id=>6
,p_column_alias=>'GROUP_LEADER'
,p_column_display_sequence=>60
,p_column_heading=>'Group Leader'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(15348387031755044164)
,p_name=>'Open Reviews'
,p_template=>wwv_flow_imp.id(141188484312500575273)
,p_display_sequence=>65
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--horizontalBorders'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.ID project_id,',
'       r.id review_id,',
'       p.PROJECT,',
'       (select FIRST_NAME ||'' ''||last_name from SP_TEAM_MEMBERS x where x.ID = p.OWNER_ID) the_owner,',
'       (select ''P''||PRIORITY from SP_PROJECT_PRIORITIES x where x.ID = p.PRIORITY_ID) priority,',
'       p.PCT_COMPLETE pct_complete,',
'       decode(p.release_id,',
'          null, decode(p.TARGET_COMPLETE,null,''No Target'',to_char(p.TARGET_COMPLETE,''DD-MON-YYYY'')),',
'          (select RELEASE_TRAIN||'' ''||release from SP_RELEASE_TRAINS r where r.id = p.RELEASE_ID)) release,',
'       p.PROJECT_SIZE,',
'       r.UPDATED,',
'       (select review_type from sp_project_review_types rt where rt.id = r.review_type_id) review_type,',
'       r.review_date,',
'       null attributes,',
'       p.owner_id,',
'       p.friendly_identifier,',
'       p.project_url_name,',
'       nvl((select first_name||'' ''||last_name from SP_TEAM_MEMBERS tm where tm.email = lower(r.updated_by)),lower(r.updated_by)) updated_by',
'  from SP_PROJECTS p,',
'       sp_project_reviews r',
' where nvl(p.ARCHIVED_YN,''N'') != ''Y'' and ',
'       p.DUPLICATE_OF_PROJECT_ID is null and',
'       p.id = r.project_id and',
'       r.owner_id = :P73_TEAM_MEMBER_ID and',
'       r.review_status != ''COMPLETED''',
' order by r.updated desc nulls last'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141188543836701575328)
,p_query_num_rows=>150
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15348387117912044165)
,p_query_column_id=>1
,p_column_alias=>'PROJECT_ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15348387259932044166)
,p_query_column_id=>2
,p_column_alias=>'REVIEW_ID'
,p_column_display_sequence=>20
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15348387271025044167)
,p_query_column_id=>3
,p_column_alias=>'PROJECT'
,p_column_display_sequence=>50
,p_column_heading=>'Project'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15348387431796044168)
,p_query_column_id=>4
,p_column_alias=>'THE_OWNER'
,p_column_display_sequence=>60
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15348387506603044169)
,p_query_column_id=>5
,p_column_alias=>'PRIORITY'
,p_column_display_sequence=>70
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15348387635029044170)
,p_query_column_id=>6
,p_column_alias=>'PCT_COMPLETE'
,p_column_display_sequence=>80
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15348387768471044171)
,p_query_column_id=>7
,p_column_alias=>'RELEASE'
,p_column_display_sequence=>90
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15348387800632044172)
,p_query_column_id=>8
,p_column_alias=>'PROJECT_SIZE'
,p_column_display_sequence=>100
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15348387922730044173)
,p_query_column_id=>9
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>120
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE_SHORT'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15348388002220044174)
,p_query_column_id=>10
,p_column_alias=>'REVIEW_TYPE'
,p_column_display_sequence=>30
,p_column_heading=>'Review Type'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15348388136819044175)
,p_query_column_id=>11
,p_column_alias=>'REVIEW_DATE'
,p_column_display_sequence=>40
,p_column_heading=>'Review Date'
,p_use_as_row_header=>'N'
,p_column_format=>'DD-MON'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15348388200293044176)
,p_query_column_id=>12
,p_column_alias=>'ATTRIBUTES'
,p_column_display_sequence=>110
,p_column_heading=>'Attributes'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="sp-tags-container">',
'    <span class="sp-tag">#PRIORITY#</span>',
'    <span class="sp-tag">#PROJECT_SIZE#</span>',
'    <span class="sp-tag">#PCT_COMPLETE#%</span>',
'    <span class="sp-tag">#RELEASE#</span>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15348388339124044177)
,p_query_column_id=>13
,p_column_alias=>'OWNER_ID'
,p_column_display_sequence=>140
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15348388376827044178)
,p_query_column_id=>14
,p_column_alias=>'FRIENDLY_IDENTIFIER'
,p_column_display_sequence=>150
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15348388502070044179)
,p_query_column_id=>15
,p_column_alias=>'PROJECT_URL_NAME'
,p_column_display_sequence=>160
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15348388621188044180)
,p_query_column_id=>16
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>170
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(19966084826209903358)
,p_plug_name=>'Current and Future &NOMENCLATURE_PROJECT. Activities'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(141188484312500575273)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ap.id, ',
'       at.activity_type,',
'       decode(greatest(length(ap.comments),80),80,ap.comments,substr(ap.comments,1,80)||''...'') comments,',
'       ap.start_date,',
'       ap.end_date,',
'       to_char(ap.end_date,''Day DD-MON-YYYY'') end_date_formatted,',
'       to_char(ap.start_date,''Day DD-MON-YYYY'')||'' to ''||to_char(ap.end_date,''Day DD-MON-YYYY'') TIMELINE,',
'       --',
'       -- determine if activity is past, current, or future',
'       --',
'       decode(trunc(ap.end_date),trunc(sysdate),''Current'',',
'       decode(trunc(ap.start_date),trunc(sysdate),''Current'',',
'       decode(',
'           greatest(trunc(ap.start_date),trunc(sysdate)),',
'               trunc(ap.start_date),''Future'',',
'           decode(',
'               greatest(trunc(ap.end_date),trunc(sysdate)),',
'               trunc(sysdate),',
'               ''Past'',''Current'')',
'           ))) timeframe,',
'       --',
'       -- optional project detail',
'       --',
'       decode(ap.project_id,null,null,(',
'           select decode(greatest(length(p.project),80),80,p.PROJECT,substr(p.project,1,80)||''...'') project ',
'           from sp_projects p ',
'           where p.id = ap.project_id and ',
'                 p.DUPLICATE_OF_PROJECT_ID is null and',
'                 p.ARCHIVED_YN = ''N'')',
'           ) project,',
'       decode(ap.project_id,null,null,(',
'           select friendly_identifier ',
'           from sp_projects p ',
'           where p.id = ap.project_id and ',
'                 p.DUPLICATE_OF_PROJECT_ID is null and',
'                 p.ARCHIVED_YN = ''N'')',
'           ) friendly_identifier,',
'       decode(ap.project_id,null,null,(',
'           select PROJECT_URL_NAME ',
'           from sp_projects p ',
'           where p.id = ap.project_id and ',
'                 p.DUPLICATE_OF_PROJECT_ID is null and',
'                 p.ARCHIVED_YN = ''N'')',
'           ) PROJECT_URL_NAME,',
'       --',
'       --',
'       --',
'       ap.end_date - ap.start_date days,',
'       round(ap.end_date - sysdate) days_remaining,',
'       ap.url,',
'       apex_util.get_since(ap.updated) last_updated,',
'       --',
'       -- team member info',
'       --',
'       tm.first_name||'' ''||tm.last_name name,',
'       --',
'       -- badge status is red if past due and green if within begin and and dates',
'       --',
'',
'       decode (trunc(sysdate),trunc(ap.end_date),''success'',',
'       decode (trunc(sysdate),trunc(ap.start_date),''success'',',
'       decode(',
'           greatest(to_char(ap.end_date,''YYYY.MM.DD''),to_char(sysdate,''YYYY.MM.DD'')),',
'           to_char(sysdate,''YYYY.MM.DD''),',
'           ''danger'',',
'           decode(',
'               greatest(to_char(ap.start_date,''YYYY.MM.DD''),to_char(sysdate,''YYYY.MM.DD'')),',
'               to_char(sysdate,''YYYY.MM.DD''),',
'               ''success'',''info'')))) as badge_class,       ',
'       --',
'       -- pie chart icon in 10% chunks that show time percent complete',
'       --',
'       ''fa-pie-chart-''||sp_date_range_pct_comp(ap.start_date, ap.end_date) icon',
'from sp_activities ap,',
'     sp_activity_types at,',
'     sp_team_members tm',
'where ',
'      ap.activity_type_id = at.id and',
'      tm.id = :P73_TEAM_MEMBER_ID and',
'      ap.team_member_id = tm.id and',
'      --',
'      -- excludes completed in the past',
'      --',
'      trunc(ap.end_date) >= trunc(sysdate)'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_ajax_items_to_submit=>'P73_TEAM_MEMBER_ID'
,p_plug_query_num_rows=>30
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_required_patch=>wwv_flow_imp.id(16149062091664614982)
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_string.join_clob(wwv_flow_t_varchar2('{',
  '"OVERLINE": "\u003Cstrong\u003E\u0026ACTIVITY_TYPE.\u003C\/strong\u003E: \u0026TIMELINE.",',
  '"TITLE": "\u0026PROJECT.",',
  '"DESCRIPTION": "\u003E\u0026COMMENTS.",',
  '"MISC": "\u0026LAST_UPDATED.",',
  '"DISPLAY_AVATAR": "Y",',
  '"DISPLAY_BADGE": "Y",',
  '"AVATAR_TYPE": "icon",',
  '"AVATAR_DESCRIPTION": "Elapsed Time",',
  '"AVATAR_ICON": "\u0026ICON.",',
  '"AVATAR_SHAPE": "t-Avatar--noShape",',
  '"BADGE_LABEL": "\u0026NOMENCLATURE_PROJECTS.",',
  '"BADGE_VALUE": "TIMEFRAME",',
  '"BADGE_STATE": "BADGE_CLASS",',
  '"BADGE_LABEL_DISPLAY": "N",',
  '"AVATAR_SIZE": "t-Avatar--sm",',
  '"BADGE_COL_WIDTH": "t-ContentRow-badge--sm",',
  '"APPLY_THEME_COLORS": "Y",',
  '"HIDE_BORDERS": "N",',
  '"REMOVE_PADDING": "N"',
'}'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(4747626940011263165)
,p_name=>'TIMEFRAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIMEFRAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>340
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(6301971387217430379)
,p_name=>'BADGE_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_CLASS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>330
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19966085001515903359)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19966086394134903373)
,p_name=>'DAYS_REMAINING'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DAYS_REMAINING'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>150
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19966086545873903375)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>170
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19966088490233903394)
,p_name=>'ACTIVITY_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIVITY_TYPE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>190
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19966088605510903395)
,p_name=>'COMMENTS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMMENTS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>200
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19966088706321903396)
,p_name=>'START_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'START_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>210
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19966088798061903397)
,p_name=>'END_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'END_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>220
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19987321490093454848)
,p_name=>'DAYS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DAYS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>230
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19987321527329454849)
,p_name=>'URL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'URL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>240
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19987321681148454850)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>250
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19987321803678454851)
,p_name=>'PROJECT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROJECT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>260
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19987321852403454852)
,p_name=>'FRIENDLY_IDENTIFIER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FRIENDLY_IDENTIFIER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>270
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19987321914216454853)
,p_name=>'TIMELINE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIMELINE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>280
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19987322061577454854)
,p_name=>'PROJECT_URL_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROJECT_URL_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>290
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19987322191482454855)
,p_name=>'LAST_UPDATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAST_UPDATED'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>300
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(19987322964477454863)
,p_name=>'END_DATE_FORMATTED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'END_DATE_FORMATTED'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>310
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(119795651400992066562)
,p_name=>'&NOMENCLATURE_PROJECT. Associations (Excludes Completed)'
,p_template=>wwv_flow_imp.id(141188484312500575273)
,p_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.id, ',
'       p.PROJECT, ',
'       i.INITIATIVE, ',
'       f.focus_area, ',
'       --',
'       -- contribution role',
'       --',
'       nvl((select max((select max(resource_type) from SP_RESOURCE_TYPES t where t.id = pc.RESPONSIBILITY_ID) )',
'        from SP_PROJECT_CONTRIBUTORS pc ',
'        where pc.team_member_id = :P73_TEAM_MEMBER_ID and project_id = p.id),'''') project_role,',
'       --',
'       -- reviewer role',
'       --',
'       nvl((select max((select max(review_type) from SP_PROJECT_REVIEW_TYPES t where t.id = pr.REVIEW_TYPE_ID) )',
'        from SP_PROJECT_REVIEWS pr',
'        where pr.owner_id = :P73_TEAM_MEMBER_ID and project_id = p.id),'''') reviewer_role,',
'       --',
'       -- project owner',
'       --',
'       decode(',
'          p.OWNER_ID,',
'          (select 1 x from SP_team_members a where a.email = lower(:APP_USER)),',
'          ''Yes'',',
'          ''No'') as is_owner,',
'       --',
'       -- project activity',
'       --',
'       (select ''Current '' from dual where exists (',
'           select 1 ',
'           from SP_ACTIVITIES a ',
'           where a.TEAM_MEMBER_ID = :P73_TEAM_MEMBER_ID and ',
'                 a.project_id = p.id and ',
'                 trunc(sysdate) between trunc(a.start_date) and trunc(a.end_date)',
'           )',
'           )||',
'        (select ''Future '' from dual where exists (',
'           select 1 ',
'           from SP_ACTIVITIES a ',
'           where a.TEAM_MEMBER_ID = :P73_TEAM_MEMBER_ID and ',
'                 a.project_id = p.id and ',
'                 trunc(sysdate) < trunc(a.start_date)',
'           )',
'           )||          ',
'        (select ''Past '' from dual where exists (',
'           select 1 ',
'           from SP_ACTIVITIES a ',
'           where a.TEAM_MEMBER_ID = :P73_TEAM_MEMBER_ID and ',
'                 a.project_id = p.id and ',
'                 trunc(sysdate) > trunc(a.end_date)',
'           )',
'           )           ',
'            Activity,',
'       --',
'       -- project attributes',
'       --',
'       p.PCT_COMPLETE PCT_COMPLETE,',
'       (select max(''P''||PRIORITY) from sp_project_priorities pp where pp.id = p.priority_id) priority,',
'       (select max(release_train||'' ''||release) from SP_RELEASE_TRAINS r where r.id = p.release_id) release,',
'       p.tags,',
'       p.project_size,',
'       p.updated,',
'       p.created,',
'       --',
'       -- columns needed to link to project',
'       --',
'       p.FRIENDLY_IDENTIFIER,',
'       p.PROJECT_URL_NAME',
'from SP_PROJECTS p,',
'     sp_initiatives i,',
'     sp_focus_areas f',
'where (p.owner_id = :P73_TEAM_MEMBER_ID or ',
'         :P73_TEAM_MEMBER_ID in (select c.team_member_id ',
'                                   from SP_PROJECT_CONTRIBUTORS c ',
'                                  where c.project_id = p.id) or',
'         :P73_TEAM_MEMBER_ID in (select c.owner_id from SP_PROJECT_REVIEWS c where c.project_id = p.id) or',
'         :P73_TEAM_MEMBER_ID in (select a.TEAM_MEMBER_ID from SP_ACTIVITIES a where a.PROJECT_ID = p.id)',
'      ) and',
'      p.INITIATIVE_ID = i.id and',
'      i.focus_area_id = f.id and',
'      p.ARCHIVED_YN = ''N'' and ',
'      p.DUPLICATE_OF_PROJECT_ID is null and',
'      p.pct_complete > 0 and ',
'      p.pct_complete < 100',
'order by p.updated desc',
'      ',
''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P73_TEAM_MEMBER_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141188543836701575328)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4747627482000263171)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4747627611824263172)
,p_query_column_id=>2
,p_column_alias=>'PROJECT'
,p_column_display_sequence=>20
,p_column_heading=>'Project'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:FI,PN:#FRIENDLY_IDENTIFIER#,#PROJECT_URL_NAME#'
,p_column_linktext=>'#PROJECT#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4747627707849263173)
,p_query_column_id=>3
,p_column_alias=>'INITIATIVE'
,p_column_display_sequence=>30
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4747627778799263174)
,p_query_column_id=>4
,p_column_alias=>'FOCUS_AREA'
,p_column_display_sequence=>40
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4747627946867263175)
,p_query_column_id=>5
,p_column_alias=>'PROJECT_ROLE'
,p_column_display_sequence=>50
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4747628064973263176)
,p_query_column_id=>6
,p_column_alias=>'REVIEWER_ROLE'
,p_column_display_sequence=>60
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4747628087613263177)
,p_query_column_id=>7
,p_column_alias=>'IS_OWNER'
,p_column_display_sequence=>70
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4747628241729263178)
,p_query_column_id=>8
,p_column_alias=>'ACTIVITY'
,p_column_display_sequence=>80
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4747628440544263180)
,p_query_column_id=>9
,p_column_alias=>'PCT_COMPLETE'
,p_column_display_sequence=>100
,p_column_heading=>'Complete'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'#PCT_COMPLETE#%'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4747628568290263181)
,p_query_column_id=>10
,p_column_alias=>'PRIORITY'
,p_column_display_sequence=>110
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4747628589471263182)
,p_query_column_id=>11
,p_column_alias=>'RELEASE'
,p_column_display_sequence=>120
,p_column_heading=>'Release'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>wwv_flow_imp.id(6210148529518744054)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4747628676714263183)
,p_query_column_id=>12
,p_column_alias=>'TAGS'
,p_column_display_sequence=>130
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4747628838965263184)
,p_query_column_id=>13
,p_column_alias=>'PROJECT_SIZE'
,p_column_display_sequence=>140
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4747628881924263185)
,p_query_column_id=>14
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>150
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE_SHORT'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4747628986257263186)
,p_query_column_id=>15
,p_column_alias=>'CREATED'
,p_column_display_sequence=>160
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4747629107377263187)
,p_query_column_id=>16
,p_column_alias=>'FRIENDLY_IDENTIFIER'
,p_column_display_sequence=>170
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4747629228691263188)
,p_query_column_id=>17
,p_column_alias=>'PROJECT_URL_NAME'
,p_column_display_sequence=>180
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5963095220621961693)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(5963094591813961687)
,p_button_name=>'manage_my_profile'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141188585454452575388)
,p_button_image_alt=>'Manage My Profile'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:RP,20:P20_ID:&APP_USER_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from sp_team_members tm',
'where tm.id = :P73_TEAM_MEMBER_ID and',
'      tm.email = lower(:APP_USER)'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-user'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6333239033126501162)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(5963094591813961687)
,p_button_name=>'external_link'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141188585454452575388)
,p_button_image_alt=>'External Directory'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'javascript:window.open(''&P73_EXT_LINK.'',''_blank'');'
,p_button_condition=>'P73_EXT_LINK'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-external-link'
,p_button_cattributes=>'title="External Directory"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4734403175782791207)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(5963094591813961687)
,p_button_name=>'edit_user'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141188585454452575388)
,p_button_image_alt=>'Edit (Admin)'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:RP,20:P20_ID:&P73_TEAM_MEMBER_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from sp_team_members tm',
'where tm.id = :P73_TEAM_MEMBER_ID and',
'      tm.email = lower(:APP_USER)'))
,p_button_condition_type=>'NOT_EXISTS'
,p_icon_css_classes=>'fa-edit'
,p_security_scheme=>wwv_flow_imp.id(141188613860866575484)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4747627427532263170)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(5963094591813961687)
,p_button_name=>'view_details'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141188585454452575388)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'View Details'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:RP,5:P5_ID:&P73_TEAM_MEMBER_ID.'
,p_icon_css_classes=>'fa-glasses'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4734403092518791206)
,p_name=>'P73_TEAM_MEMBER_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4734401105572791186)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5963095138739961692)
,p_name=>'P73_PHOTO_PLACEHOLDER'
,p_item_sequence=>20
,p_prompt=>'Photo'
,p_source=>'#APP_FILES#default-user-avatar.png'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 ',
'from sp_team_members ',
'where id = :P73_TEAM_MEMBER_ID and ',
'      photo is not null'))
,p_display_when_type=>'NOT_EXISTS'
,p_field_template=>wwv_flow_imp.id(141188582371029575375)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6241396794873947676)
,p_name=>'P73_PHOTO'
,p_item_sequence=>10
,p_prompt=>'Photo'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_colspan=>3
,p_grid_label_column_span=>0
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 ',
'from sp_team_members ',
'where id = :P73_TEAM_MEMBER_ID and ',
'photo is not null'))
,p_display_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(141188582371029575375)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'SQL'
,p_attribute_06=>'select PHOTO from sp_team_members where id = :P73_TEAM_MEMBER_ID'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6333032793508142934)
,p_name=>'P73_EXT_LINK'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(4734401105572791186)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select replace(apex_app_setting.get_value(''EXTERNAL_PERSON_LINK''),''#EMAIL#'',lower(email)) ',
'  from sp_team_members',
' where id = :P73_TEAM_MEMBER_ID',
'   and email is not null',
'   and apex_app_setting.get_value(''EXTERNAL_PERSON_LINK_DOMAIN'') is not null',
'   and lower(email) like ''%@''||lower(apex_app_setting.get_value(''EXTERNAL_PERSON_LINK_DOMAIN''))'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(19966086820956903378)
,p_region_id=>wwv_flow_imp.id(19966084826209903358)
,p_position_id=>wwv_flow_imp.id(3704044168831277200)
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:FI,PN:&FRIENDLY_IDENTIFIER.,&PROJECT_URL_NAME.'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(19966086984651903379)
,p_region_id=>wwv_flow_imp.id(19966084826209903358)
,p_position_id=>wwv_flow_imp.id(3717637195828652804)
,p_display_sequence=>20
,p_template_id=>wwv_flow_imp.id(3717639057025688081)
,p_label=>'Actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_action_css_classes=>'t-Button--noUI'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(19966087047136903380)
,p_component_action_id=>wwv_flow_imp.id(19966086984651903379)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Edit Activity'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:101:&SESSION.::&DEBUG.:RP,101:P101_ID:&ID.'
,p_icon_css_classes=>'fa-edit'
,p_authorization_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(20048199545991400449)
,p_component_action_id=>wwv_flow_imp.id(19966086984651903379)
,p_menu_entry_type=>'ENTRY'
,p_label=>'View &NOMENCLATURE_PROJECT.'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,:FI,PN:&FRIENDLY_IDENTIFIER.,&PROJECT_URL_NAME.'
,p_icon_css_classes=>'fa-glasses'
,p_authorization_scheme=>wwv_flow_imp.id(141188613913166575484)
);
wwv_flow_imp.component_end;
end;
/
