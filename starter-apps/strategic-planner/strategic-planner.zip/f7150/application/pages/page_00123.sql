prompt --application/pages/page_00123
begin
--   Manifest
--     PAGE: 00123
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>123
,p_name=>'Contributor Checklist'
,p_alias=>'CONTRIBUTOR-CHECKLIST-HELP'
,p_page_mode=>'MODAL'
,p_step_title=>'Contributor Checklist'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(3476080579486003905)
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(3472559489660737107)
,p_protection_level=>'C'
,p_page_component_map=>'25'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20240417230925'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3431756993444331753)
,p_plug_name=>'Why is this Important?'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(141180095591799434930)
,p_plug_display_sequence=>20
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_clob clob;',
'begin',
'for c1 in (select why_important from SP_CONTRIBUTOR_CHECKLIST where id = :P123_ID) loop',
'   l_clob := c1.why_important;',
'   l_clob := replace(l_clob,''#NOMENCLATURE_PROJECTS#'',:NOMENCLATURE_PROJECTS);',
'   l_clob := replace(l_clob,''#NOMENCLATURE_PROJECT#'',:NOMENCLATURE_PROJECT);',
'   return l_clob;',
'end loop;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3431757196624331755)
,p_plug_name=>'How to Action?'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(141180095591799434930)
,p_plug_display_sequence=>30
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_clob clob;',
'begin',
'for c1 in (select how_to_check from SP_CONTRIBUTOR_CHECKLIST where id = :P123_ID) loop',
'   l_clob := c1.how_to_check;',
'   l_clob := replace(l_clob,''#NOMENCLATURE_PROJECTS#'',:NOMENCLATURE_PROJECTS);',
'   l_clob := replace(l_clob,''#NOMENCLATURE_PROJECT#'',:NOMENCLATURE_PROJECT);',
'   return l_clob;',
'end loop;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3431757309886331756)
,p_plug_name=>'Checklist Activity:'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(141180095591799434930)
,p_plug_display_sequence=>10
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_clob clob;',
'begin',
'for c1 in (select checklist_activity from SP_CONTRIBUTOR_CHECKLIST where id = :P123_ID) loop',
'   l_clob := c1.checklist_activity;',
'   l_clob := replace(l_clob,''#NOMENCLATURE_PROJECTS#'',:NOMENCLATURE_PROJECTS);',
'   l_clob := replace(l_clob,''#NOMENCLATURE_PROJECT#'',:NOMENCLATURE_PROJECT);',
'   return l_clob;',
'end loop;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3431757059835331754)
,p_name=>'P123_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3431756993444331753)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
