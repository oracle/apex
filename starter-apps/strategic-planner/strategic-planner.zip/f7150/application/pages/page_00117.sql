prompt --application/pages/page_00117
begin
--   Manifest
--     PAGE: 00117
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>26954343551793662
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>117
,p_name=>'Release'
,p_alias=>'RELEASE2'
,p_step_title=>'Release &P117_RELEASE.'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.sp-tag {',
'    padding: 2px 4px;',
'    display: inline-block;',
'    vertical-align: text-bottom;',
'    border-radius: 3px;',
'    background-color: rgba(0,0,0,.1);',
'    text-overflow: ellipsis;',
'    white-space: nowrap;',
'}',
'.sp-tags-container {',
'    display: flex;',
'    align-items: center;',
'    flex-wrap: wrap;',
'    gap: 4px;',
'    justify-content: flex-start;',
'}',
'',
'.resize-region {',
'  resize: vertical;',
'  overflow: auto;',
'}',
'',
'.a-CardView-iconWrap,',
'.a-CardView-badge { align-self: flex-start; }',
'',
'.project-rds-region {',
'    background-color: rgb(219 204 175 / 20%);',
'}',
'.t-Body-title {',
'    --ut-palette-warning-shade: rgba(var(--oj-palette-neutral-rgb-160));',
'    --ut-component-background-color: rgba(var(--oj-palette-neutral-rgb-170)); ',
'    --ut-alert-horizontal-border-radius: 0;',
'}',
'',
'/* Percent Chart Styles */',
':root {',
'  --a-percent-chart-border-radius: 0.125rem;',
'  --a-percent-chart-bar-border-radius: 0.125rem;',
'  --a-percent-chart-bar-background-color: var(--rw-palette-slate-100);',
'  --ut-report-cell-hover-background-color: rgba(0, 0, 0, 0.025);',
'}',
'',
'/* Report Overrides */',
'.a-IRR-header {',
'  box-shadow: inset 0 -1px 0 var(--a-gv-header-cell-border-color);',
'}',
'',
'.t-Report {',
'  background-color: var(--rw-palette-neutral-0);',
'}',
'',
'.t-Report th {',
'  font-size: .6875rem;',
'}',
'',
'.t-Report th,',
'.t-Report td {',
'  border-inline-width: 0;',
'  transition: none;',
'}',
'',
'/* Group borders */',
'th#PCT_10,',
'td[headers="PCT_10"],',
'th#EFFORT_DAYS,',
'td[headers="EFFORT_DAYS"],',
'th#MOST_RECENT_COMMENT,',
'td[headers="MOST_RECENT_COMMENT"],',
'th#SPECS_COMPLETED,',
'td[headers="SPECS_COMPLETED"],',
'th#P1,',
'td[headers="P1"] {',
'  border-inline-start-width: 0.25rem;',
'}',
'',
'th#P1,',
'th#P2,',
'th#P3,',
'th#P4,',
'th#P5,',
'[headers="P1"],',
'[headers="P2"],',
'[headers="P3"],',
'[headers="P4"],',
'[headers="P5"] {',
'  background-color: var(--rw-palette-red-10);',
'}',
'',
'tr:hover th#P1,',
'tr:hover th#P2,',
'tr:hover th#P3,',
'tr:hover th#P4,',
'tr:hover th#P5,',
'tr:hover [headers="P1"],',
'tr:hover [headers="P2"],',
'tr:hover [headers="P3"],',
'tr:hover [headers="P4"],',
'tr:hover [headers="P5"] {',
'  background-color: var(--rw-palette-red-20);',
'}',
'',
'th#PCT_0,',
'th#PCT_10,',
'th#PCT_20,',
'th#PCT_30,',
'th#PCT_40,',
'th#PCT_50,',
'th#PCT_60,',
'th#PCT_70,',
'th#PCT_80,',
'th#PCT_90,',
'th#PCT_100,',
'th#PCT_COMPLETE,',
'[headers="PCT_0"],',
'[headers="PCT_10"],',
'[headers="PCT_20"],',
'[headers="PCT_30"],',
'[headers="PCT_40"],',
'[headers="PCT_50"],',
'[headers="PCT_60"],',
'[headers="PCT_70"],',
'[headers="PCT_80"],',
'[headers="PCT_90"],',
'[headers="PCT_100"],',
'[headers="PCT_COMPLETE"] {',
'  background-color: var(--rw-palette-green-10);',
'}',
'',
'tr:hover th#PCT_0,',
'tr:hover th#PCT_10,',
'tr:hover th#PCT_20,',
'tr:hover th#PCT_30,',
'tr:hover th#PCT_40,',
'tr:hover th#PCT_50,',
'tr:hover th#PCT_60,',
'tr:hover th#PCT_70,',
'tr:hover th#PCT_80,',
'tr:hover th#PCT_90,',
'tr:hover th#PCT_100,',
'tr:hover th#PCT_COMPLETE,',
'tr:hover [headers="PCT_0"],',
'tr:hover [headers="PCT_10"],',
'tr:hover [headers="PCT_20"],',
'tr:hover [headers="PCT_30"],',
'tr:hover [headers="PCT_40"],',
'tr:hover [headers="PCT_50"],',
'tr:hover [headers="PCT_60"],',
'tr:hover [headers="PCT_70"],',
'tr:hover [headers="PCT_80"],',
'tr:hover [headers="PCT_90"],',
'tr:hover [headers="PCT_100"],',
'tr:hover [headers="PCT_COMPLETE"] {',
'  background-color: var(--rw-palette-green-20);',
'}',
'',
'th#EFFORT_DAYS,',
'th#DAYS_COMPLETED,',
'th#DAYS_OUTSTANDING,',
'[headers="EFFORT_DAYS"],',
'[headers="DAYS_COMPLETED"],',
'[headers="DAYS_OUTSTANDING"] {',
'  background-color: var(--rw-palette-blue-10);',
'}',
'',
'tr:hover th#EFFORT_DAYS,',
'tr:hover th#DAYS_COMPLETED,',
'tr:hover th#DAYS_OUTSTANDING,',
'tr:hover [headers="EFFORT_DAYS"],',
'tr:hover [headers="DAYS_COMPLETED"],',
'tr:hover [headers="DAYS_OUTSTANDING"] {',
'  background-color: var(--rw-palette-blue-20);',
'}',
'',
'th#MOST_RECENT_COMMENT,',
'th#CURRENTLY_ACTIVE_PROJECTS,',
'[headers="MOST_RECENT_COMMENT"],',
'[headers="CURRENTLY_ACTIVE_PROJECTS"] {',
'  background-color: var(--rw-palette-plum-10);',
'}',
'',
'tr:hover th#MOST_RECENT_COMMENT,',
'tr:hover th#CURRENTLY_ACTIVE_PROJECTS,',
'tr:hover [headers="MOST_RECENT_COMMENT"],',
'tr:hover [headers="CURRENTLY_ACTIVE_PROJECTS"] {',
'  background-color: var(--rw-palette-plum-20);',
'}',
'',
'h3:first-of-type { margin-top: 0; }'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6590481937520851141)
,p_plug_name=>'RDS'
,p_region_css_classes=>'u-padding-inline-dynamic project-rds-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215307437908368905)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_08'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'SESSION')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6614934048809924427)
,p_plug_name=>'Links'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215436556892368933)
,p_plug_display_sequence=>130
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       RELEASE_ID,',
'       LINK_NAME,',
'       --LINK_URL,',
'       decode(greatest(length(l.link_url),80),80,',
'           l.link_url,',
'           substr(l.link_url,1,39)||''...''||substr(l.link_url,length(l.link_url)-39,39)',
'           ) link_url,',
'       decode(IMPORTANT_YN,''Y'',''Yes'',''N'',''No'',IMPORTANT_YN) IMPORTANT,',
'       CREATED,',
'       lower(CREATED_BY) created_by,',
'       UPDATED,',
'       UPDATED_BY',
'  from SP_RELEASE_LINKS l',
'where release_id = :P117_RELEASE_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P117_RELEASE_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Links'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(6614934124660924428)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:RP,38:P38_ID:#ID#'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_owner=>'MIKE'
,p_internal_uid=>4722242012226485306
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6614934238710924429)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6614934399415924430)
,p_db_column_name=>'RELEASE_ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Release Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6614934503765924431)
,p_db_column_name=>'LINK_NAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Link'
,p_column_html_expression=>'<a href="#LINK_URL#" target="_blank">#LINK_NAME#</a>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6614934531356924432)
,p_db_column_name=>'LINK_URL'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'URL'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6614934762222924434)
,p_db_column_name=>'CREATED'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6614934854380924435)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Added By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6614934991039924436)
,p_db_column_name=>'UPDATED'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6614935109805924437)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16587874639412848928)
,p_db_column_name=>'IMPORTANT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Important'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(6617318410883970936)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'47246263'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LINK_NAME:LINK_URL:IMPORTANT:UPDATED:CREATED_BY:'
,p_sort_column_1=>'IMPORTANT'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'UPDATED'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11069174565248088154)
,p_plug_name=>'Timeline'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215307437908368905)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14008466253588832544)
,p_plug_name=>'timeline buttons'
,p_parent_plug_id=>wwv_flow_imp.id(11069174565248088154)
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(141215456255671368951)
,p_plug_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14008466391760832545)
,p_plug_name=>'Timeline contents'
,p_parent_plug_id=>wwv_flow_imp.id(11069174565248088154)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215307437908368905)
,p_plug_display_sequence=>40
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return sp_release_timeline.show_week (',
'    p_release_id          => :P117_RELEASE_ID,',
'    p_show_past_yn        => nvl(:P117_INCLUDE_PAST_YN,''N''),',
'--    p_start_day           => case when :P117_INCLUDE_PAST_YN = ''Y'' ',
'--                                  then sysdate-(365*4)',
'--                                  else sysdate',
'--                                  end,',
'    p_exclude_complete_yn => :P117_EXCLUDE_COMPLETE_YN',
'    );'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_translate_title=>'N'
,p_ajax_items_to_submit=>'P117_RELEASE_ID,P117_INCLUDE_PAST_YN,P117_EXCLUDE_COMPLETE_YN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11258013965216626402)
,p_plug_name=>'&NOMENCLATURE_PROJECTS.'
,p_icon_css_classes=>' '
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215436556892368933)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.ID,',
'       p.PROJECT,',
'       (select FIRST_NAME ||'' ''||last_name from SP_TEAM_MEMBERS x where x.ID = p.OWNER_ID) the_owner,',
'       (select ''P''||PRIORITY from SP_PROJECT_PRIORITIES x where x.ID = p.PRIORITY_ID) priority,',
'       p.PCT_COMPLETE pct_complete,',
'       (select decode(greatest(length(initiative),15),15,initiative,substr(initiative,1,12)||''...'') initiative ',
'        from sp_initiatives i ',
'        where i.id = p.initiative_id) initiative,',
'       decode(p.release_id,',
'          null, decode(p.TARGET_COMPLETE,null,''No Target'',to_char(p.TARGET_COMPLETE,''DD-MON-YYYY'')),',
'          (select RELEASE_TRAIN||'' ''||release from SP_RELEASE_TRAINS r where r.id = p.RELEASE_ID)) release,',
'       p.PROJECT_SIZE,',
'       case when p.requires_reviews_yn = ''Y'' then ''Yes'' else ''No'' end requires_reviews,',
'       p.UPDATED,',
'       p.owner_id,',
'       p.friendly_identifier,',
'       p.project_url_name,',
'       nvl((select first_name||'' ''||last_name from SP_TEAM_MEMBERS tm where tm.email = lower(p.updated_by)),lower(p.updated_by)) updated_by,',
'       replace(lower(p.tags),'','','', '') as tags,',
'       --',
'       -- activities',
'       --',
'       (select count(*) from SP_ACTIVITIES a where a.project_id = p.id and sysdate between a.START_DATE and a.end_date) Current_activities,',
'       (select count(*) from SP_ACTIVITIES a where a.project_id = p.id) activities,',
'       --',
'       -- milestones',
'       --',
'       case when s.milestone1_label is not null then decode(milestone1_complete_yn,''Y'',s.milestone1_label||'' - Completed'',decode(milestone1_complete_date,null,s.milestone1_label||'' - No Date'',s.milestone1_label||'' - ''||to_char(milestone1_complete_dat'
||'e,''DD-MON''))) end m1,',
'       case when s.milestone2_label is not null then decode(milestone2_complete_yn,''Y'',s.milestone2_label||'' - Completed'',decode(milestone2_complete_date,null,s.milestone2_label||'' - No Date'',s.milestone2_label||'' - ''||to_char(milestone2_complete_dat'
||'e,''DD-MON''))) end m2,',
'       case when s.milestone3_label is not null then decode(milestone3_complete_yn,''Y'',s.milestone3_label||'' - Completed'',decode(milestone3_complete_date,null,s.milestone3_label||'' - No Date'',s.milestone3_label||'' - ''||to_char(milestone3_complete_dat'
||'e,''DD-MON''))) end m3,',
'       case when s.milestone4_label is not null then decode(milestone4_complete_yn,''Y'',s.milestone4_label||'' - Completed'',decode(milestone4_complete_date,null,s.milestone4_label||'' - No Date'',s.milestone4_label||'' - ''||to_char(milestone4_complete_dat'
||'e,''DD-MON''))) end m4,',
'       milestone1_complete_date m1_date,',
'       milestone1_complete_yn m1_complete,',
'       milestone2_complete_date m2_date,',
'       milestone2_complete_yn m2_complete,',
'       milestone3_complete_date m3_date,',
'       milestone3_complete_yn m3_complete,',
'       milestone4_complete_date m4_date,',
'       milestone4_complete_yn m4_complete,',
'       --',
'       -- description',
'       --',
'       decode(nvl(dbms_lob.getlength(p.description),0),0,''Not Provided'',',
'           dbms_lob.substr(p.description,300,1)||',
'           decode(greatest(dbms_lob.getlength(p.description),300),300,null,''...'')) description,',
'       --',
'       rtrim((select tm.first_name||'' ''||tm.last_name ||'', '' x',
'        from SP_TEAM_MEMBERS tm ',
'        where tm.id = p.owner_id and p.owner_id not in (select pc.team_member_id from SP_PROJECT_CONTRIBUTORS pc where pc.project_id = p.id))||',
'       (select listagg(xtm.first_name||'' ''||xtm.last_name, '', '') within group (order by 1) names',
'       from SP_PROJECT_CONTRIBUTORS xpc, SP_TEAM_MEMBERS xtm',
'       where xpc.project_id = p.id and',
'             xpc.TEAM_MEMBER_ID = xtm.id',
'             ),'', '') contributors,',
'       --',
'       -- last comment',
'       --',
'       (select max(dbms_lob.substr(c.body,255,1)||',
'               decode(greatest(dbms_lob.getlength(c.body),255),255,null,''...'')) last_comment ',
'        from   SP_PROJECT_COMMENTS c ',
'        where c.project_id = p.id and ',
'              c.private_yn = ''N'' and ',
'              c.created = (select max(c2.created) from sp_project_comments c2 where c2.project_id = p.id and c2.private_yn = ''N''))',
'        as last_comment,',
'       (select first_name||'' ''||last_name ',
'        from SP_TEAM_MEMBERS t ',
'        where t.id = (select max(c.author_id) from sp_project_comments c where c.project_id = p.id and c.created = (select max(c.created) from sp_project_comments c where c.project_id = p.id and c.private_yn = ''N''))) last_comment_by,',
'       --',
'       (select max(c.created) from sp_project_comments c where c.project_id = p.id and c.private_yn = ''N'') last_comment_on,',
'       --',
'       nvl((select ''Yes'' from sp_favorites f where f.project_id = p.id and f.team_member_id = :APP_USER_ID),''No'') favorite,',
'       nvl((select ''fa-heart u-danger-text'' from sp_favorites f where f.project_id = p.id and f.team_member_id = :APP_USER_ID),''fa-heart-o'') favorite_icon,',
'       null actions',
'from  SP_PROJECTS p,',
'      sp_project_scales s',
'where nvl(p.ARCHIVED_YN,''N'') = ''N'' and ',
'      p.DUPLICATE_OF_PROJECT_ID is null and',
'      p.release_id = :P117_RELEASE_ID and',
'      p.RELEASE_DEPENDENT_YN = ''Y'' and',
'      p.status_scale = s.scale_letter',
'',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P117_RELEASE_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'&NOMENCLATURE_PROJECTS.'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_footer=>'Click &NOMENCLATURE_PROJECT. name for detail view.'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(11258015609241626418)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'No &NOMENCLATURE_PROJECTS. Found'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:RP,24:P24_ID:#ID#'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(141215568360703369146)
,p_owner=>'MIKE'
,p_internal_uid=>9365323496807187296
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11258015618648626419)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11258015788320626420)
,p_db_column_name=>'PROJECT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'&NOMENCLATURE_PROJECT.'
,p_column_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:FI,PN:#FRIENDLY_IDENTIFIER#,#PROJECT_URL_NAME#'
,p_column_linktext=>'#PROJECT#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11289751036839004071)
,p_db_column_name=>'THE_OWNER'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Owner'
,p_column_link=>'f?p=&APP_ID.:73:&SESSION.::&DEBUG.:RP,73:P73_TEAM_MEMBER_ID:#OWNER_ID#'
,p_column_linktext=>'#THE_OWNER#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11289751156816004072)
,p_db_column_name=>'PRIORITY'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Priority'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11289751237359004073)
,p_db_column_name=>'PCT_COMPLETE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Complete'
,p_column_html_expression=>'#PCT_COMPLETE#%'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11289751364458004074)
,p_db_column_name=>'INITIATIVE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Initiative'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11289751471032004075)
,p_db_column_name=>'RELEASE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Release'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11289751551587004076)
,p_db_column_name=>'PROJECT_SIZE'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Size'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11289751692217004077)
,p_db_column_name=>'UPDATED'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11289751820862004079)
,p_db_column_name=>'OWNER_ID'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Owner Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11289752008077004080)
,p_db_column_name=>'FRIENDLY_IDENTIFIER'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Friendly Identifier'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11289752102079004081)
,p_db_column_name=>'PROJECT_URL_NAME'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Project Url Name'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11289752269956004083)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6590483616279851158)
,p_db_column_name=>'CURRENT_ACTIVITIES'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Current Activities'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6590483857660851160)
,p_db_column_name=>'ACTIVITIES'
,p_display_order=>170
,p_column_identifier=>'R'
,p_column_label=>'Activities'
,p_column_link=>'f?p=&APP_ID.:130:&SESSION.::&DEBUG.:RP,130:P130_PROJECT_ID:#ID#'
,p_column_linktext=>'#ACTIVITIES#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6621457647937807723)
,p_db_column_name=>'FAVORITE'
,p_display_order=>300
,p_column_identifier=>'AE'
,p_column_label=>'Favorite'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6621457769948807724)
,p_db_column_name=>'FAVORITE_ICON'
,p_display_order=>310
,p_column_identifier=>'AF'
,p_column_label=>'Favorite Icon'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6621460607004807752)
,p_db_column_name=>'ACTIONS'
,p_display_order=>320
,p_column_identifier=>'AG'
,p_column_label=>'Quick Look'
,p_column_link=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:RP,36:P36_ID:#ID#'
,p_column_linktext=>'<span class="fa fa-align-justify" aria-hidden="true"></span>'
,p_column_link_attr=>'title="&NOMENCLATURE_PROJECT. Quick Look"'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7356904967957154829)
,p_db_column_name=>'M1_DATE'
,p_display_order=>330
,p_column_identifier=>'AH'
,p_column_label=>'M1 Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'RR-MON-DD'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7356905062564154830)
,p_db_column_name=>'M1_COMPLETE'
,p_display_order=>340
,p_column_identifier=>'AI'
,p_column_label=>'M1 Complete'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7356905165445154831)
,p_db_column_name=>'M1'
,p_display_order=>350
,p_column_identifier=>'AJ'
,p_column_label=>'M1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7356905293129154832)
,p_db_column_name=>'M2_DATE'
,p_display_order=>360
,p_column_identifier=>'AK'
,p_column_label=>'M2 Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'RR-MON-DD'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7356905338238154833)
,p_db_column_name=>'M2_COMPLETE'
,p_display_order=>370
,p_column_identifier=>'AL'
,p_column_label=>'M2 Complete'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7356905454505154834)
,p_db_column_name=>'M2'
,p_display_order=>380
,p_column_identifier=>'AM'
,p_column_label=>'M2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7356905570053154835)
,p_db_column_name=>'M3_DATE'
,p_display_order=>390
,p_column_identifier=>'AN'
,p_column_label=>'M3 Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'RR-MON-DD'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7356905688511154836)
,p_db_column_name=>'M3_COMPLETE'
,p_display_order=>400
,p_column_identifier=>'AO'
,p_column_label=>'M3 Complete'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7356905713443154837)
,p_db_column_name=>'M3'
,p_display_order=>410
,p_column_identifier=>'AP'
,p_column_label=>'M3'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7356905902401154838)
,p_db_column_name=>'M4_DATE'
,p_display_order=>420
,p_column_identifier=>'AQ'
,p_column_label=>'M4 Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'RR-MON-DD'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7356905993106154839)
,p_db_column_name=>'M4_COMPLETE'
,p_display_order=>430
,p_column_identifier=>'AR'
,p_column_label=>'M4 Complete'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7356906080352154840)
,p_db_column_name=>'M4'
,p_display_order=>440
,p_column_identifier=>'AS'
,p_column_label=>'M4'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7380956496332318571)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>450
,p_column_identifier=>'AT'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10294174438024757159)
,p_db_column_name=>'CONTRIBUTORS'
,p_display_order=>460
,p_column_identifier=>'AU'
,p_column_label=>'Contributors'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10294174538427757160)
,p_db_column_name=>'LAST_COMMENT'
,p_display_order=>470
,p_column_identifier=>'AV'
,p_column_label=>'Last Comment'
,p_column_html_expression=>'#LAST_COMMENT# - #LAST_COMMENT_BY# - #LAST_COMMENT_ON#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10294174675076757161)
,p_db_column_name=>'LAST_COMMENT_ON'
,p_display_order=>480
,p_column_identifier=>'AW'
,p_column_label=>'Last Comment On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10294174766366757162)
,p_db_column_name=>'LAST_COMMENT_BY'
,p_display_order=>490
,p_column_identifier=>'AX'
,p_column_label=>'Last Comment By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10294174920443757164)
,p_db_column_name=>'TAGS'
,p_display_order=>500
,p_column_identifier=>'AY'
,p_column_label=>'Tags'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14241499285390255334)
,p_db_column_name=>'REQUIRES_REVIEWS'
,p_display_order=>510
,p_column_identifier=>'AZ'
,p_column_label=>'Requires Reviews'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(11289593076192648477)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'46976301'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PROJECT:THE_OWNER:ACTIVITIES:PRIORITY:PROJECT_SIZE:PCT_COMPLETE:M1:M2:M3:M4:CONTRIBUTORS:UPDATED:ACTIONS:'
,p_sort_column_1=>'UPDATED'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'PCT_COMPLETE'
,p_sort_direction_2=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13013908159270140865)
,p_plug_name=>'Exceptions'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215307437908368905)
,p_plug_display_sequence=>110
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from sp_release_trains',
' where id = :P117_RELEASE_ID',
'   and nvl(release_completed,''N'') = ''N'''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14008465841962832540)
,p_plug_name=>'exception buttons'
,p_parent_plug_id=>wwv_flow_imp.id(13013908159270140865)
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(141215456255671368951)
,p_plug_display_sequence=>10
,p_required_patch=>wwv_flow_imp.id(18721993490508994894)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14008465956753832541)
,p_plug_name=>'Exceptions body'
,p_parent_plug_id=>wwv_flow_imp.id(13013908159270140865)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(141215438656052368935)
,p_plug_display_sequence=>30
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return sp_release_timeline.release_exceptions (',
'    p_release_id              => :P117_RELEASE_ID,',
'    p_links                   => ''APP'',',
'    p_apex_session            => :APP_SESSION );'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P117_RELEASE_ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18880452978478091625)
,p_plug_name=>'Breadcrumb'
,p_region_sub_css_classes=>'has-header-actions'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215451086209368948)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(141215269149411368828)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(141215541295426369052)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22954606614107303559)
,p_plug_name=>'Menubar'
,p_parent_plug_id=>wwv_flow_imp.id(18880452978478091625)
,p_region_sub_css_classes=>'header-actions'
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>'select 1 as actions from dual'
,p_template_component_type=>'PARTIAL'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'AVATAR_ICON', 'fa-user',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_TYPE', 'icon',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--md',
  'BADGE_LABEL_DISPLAY', 'N',
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(22954607847613303571)
,p_name=>'ACTIONS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIONS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18881767277384682816)
,p_plug_name=>'Milestones'
,p_region_name=>'MILESTONES'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215436556892368933)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select m.ID,',
'       --',
'       -- milestone attributes',
'       --',
'       m.RELEASE_ID,',
'       m.MILESTONE_NAME,',
'       m.UPPER_MILESTONE_NAME,',
'       m.MILESTONE_DATE,',
'       m.ORIGINAL_MILESTONE_DATE,',
'       decode(m.MILESTONE_COMPLETED_YN,''N'',''No'',''Y'',''Yes'') MILESTONE_COMPLETED_YN,',
'       m.MILESTONE_DESCRIPTION,',
'       --',
'       -- milestones audit columns',
'       --',
'       m.CREATED,',
'       m.CREATED_BY,',
'       m.UPDATED,',
'       m.UPDATED_BY,',
'       --',
'       --',
'       --',
'       round(m.MILESTONE_DATE  - sysdate) days,',
'       --',
'       -- Milestone status based on milestone date',
'       --',
'       decode(',
'           greatest(round(m.MILESTONE_DATE  - sysdate),0),',
'           0,',
'           decode(m.MILESTONE_COMPLETED_YN,''Y'',''Completed'',''Past Due''),',
'           decode(m.MILESTONE_COMPLETED_YN,''Y'',''Completed'',''On Track'')',
'       ) status,',
'       --',
'       -- Days since release open',
'       --',
'       round(m.MILESTONE_DATE - (select r.RELEASE_OPEN_DATE from SP_RELEASE_TRAINS r where r.id = :P117_RELEASE_ID)) days_since_open,',
'       --',
'       -- Days remaining in the release',
'       --',
'       round( (select r.RELEASE_TARGET_DATE from SP_RELEASE_TRAINS r where r.id = :P117_RELEASE_ID)-  m.MILESTONE_DATE) days_until_release',
'  from SP_RELEASE_MILESTONES m',
'  where release_Id = :P117_RELEASE_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P117_RELEASE_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Milestones'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(18881767397466682816)
,p_name=>'Release Milestones'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:92:&APP_SESSION.::&DEBUG.:RP:P92_ID:\#ID#\'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(141215568360703369146)
,p_owner=>'MIKE'
,p_internal_uid=>16989075285032243694
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18881767790939682818)
,p_db_column_name=>'ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18881768573928682820)
,p_db_column_name=>'MILESTONE_NAME'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Milestone'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18881768955364682821)
,p_db_column_name=>'UPPER_MILESTONE_NAME'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Upper Milestone Name'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18881769373552682821)
,p_db_column_name=>'MILESTONE_DATE'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18881769804472682822)
,p_db_column_name=>'ORIGINAL_MILESTONE_DATE'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Original Milestone Date'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18881770208534682822)
,p_db_column_name=>'MILESTONE_COMPLETED_YN'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Completed '
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18881770553743682822)
,p_db_column_name=>'MILESTONE_DESCRIPTION'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18881771368872682823)
,p_db_column_name=>'CREATED'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18881771719733682823)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18881772166913682824)
,p_db_column_name=>'UPDATED'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18881772603137682824)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18896603278168169436)
,p_db_column_name=>'RELEASE_ID'
,p_display_order=>24
,p_column_identifier=>'O'
,p_column_label=>'Release Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20186368283127325697)
,p_db_column_name=>'DAYS'
,p_display_order=>34
,p_column_identifier=>'P'
,p_column_label=>'Days'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20186368369382325698)
,p_db_column_name=>'STATUS'
,p_display_order=>44
,p_column_identifier=>'Q'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20186369990003325714)
,p_db_column_name=>'DAYS_SINCE_OPEN'
,p_display_order=>54
,p_column_identifier=>'R'
,p_column_label=>'Days Since Open'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(20186370068549325715)
,p_db_column_name=>'DAYS_UNTIL_RELEASE'
,p_display_order=>64
,p_column_identifier=>'S'
,p_column_label=>'Days Until Release'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(18882403047685077633)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'122904977'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'MILESTONE_NAME:MILESTONE_DATE:DAYS:MILESTONE_COMPLETED_YN:STATUS:UPDATED'
,p_sort_column_1=>'MILESTONE_DATE'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(6591911361862532413)
,p_report_id=>wwv_flow_imp.id(18882403047685077633)
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STATUS'
,p_operator=>'='
,p_expr=>'Past Due'
,p_condition_sql=>' (case when ("STATUS" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''Past Due''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#ffd6d2'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(21475696331386100763)
,p_plug_name=>'Contributors'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215436556892368933)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select team_member_id,',
'       name,',
'       email,',
'       person_tags,',
'       identified_as_contributor,',
'       identified_as_reviewer,',
'       project_activivity_contributor,',
'       project_owner_count,',
'       --',
'       -- total responsibility count',
'       --',
'       identified_as_contributor +',
'       identified_as_reviewer +',
'       project_activivity_contributor +',
'       project_owner_count total,',
'       --',
'       -- types of contribution',
'       --',
'       decode(identified_as_contributor,     0,''No'',''Yes'') is_contributor,',
'       decode(identified_as_reviewer,        0,''No'',''Yes'') is_reviewer,',
'       decode(project_activivity_contributor,0,''No'',''Yes'') is_activity_contributor,',
'       decode(project_owner_count,           0,''No'',''Yes'') is_owner,',
'       --',
'       -- photo',
'       --',
'       photo,',
'       photo_mimetype',
'from',
'(',
'select tm.id                             team_member_id,',
'       tm.first_name||'' ''||tm.last_name  name,',
'       tm.email                          email,',
'       tm.tags                           person_tags,',
'       --',
'       -- contributors',
'       --',
'       (select count(distinct p.id) ',
'        from  SP_PROJECT_CONTRIBUTORS pc, ',
'              sp_projects p ',
'        where pc.PROJECT_ID = p.id and ',
'              pc.TEAM_MEMBER_ID = tm.id and',
'              p.release_id = rt.ID and ',
'              p.RELEASE_DEPENDENT_YN = ''Y'' and',
'              p.ARCHIVED_YN = ''N'' and ',
'              p.DUPLICATE_OF_PROJECT_ID is null and',
'              p.release_id = :P117_RELEASE_ID ',
'       ) identified_as_contributor,',
'       --',
'       -- Reviewer',
'       --',
'       (select count(distinct p.id) ',
'        from   SP_PROJECT_REVIEWS pr, ',
'               sp_projects p ',
'        where  pr.PROJECT_ID = p.id and ',
'               pr.OWNER_ID   = tm.id and',
'               p.release_id  = rt.ID  and',
'               p.ARCHIVED_YN = ''N'' and ',
'               p.DUPLICATE_OF_PROJECT_ID is null and',
'              p.release_id = :P117_RELEASE_ID ',
'        ) identified_as_reviewer,',
'        --',
'        -- activity contributor',
'        --',
'        (select count(distinct p.id)',
'         from  SP_ACTIVITIES dap, ',
'               sp_projects p ',
'         where p.release_id = rt.id and',
'               p.ARCHIVED_YN = ''N'' and ',
'               p.DUPLICATE_OF_PROJECT_ID is null and ',
'               dap.project_id = p.id and',
'               dap.TEAM_MEMBER_ID = tm.id and',
'              p.release_id = :P117_RELEASE_ID ',
'               ) project_activivity_contributor,',
'        --',
'        -- project owner',
'        --',
'        (select count(*) ',
'         from sp_projects p ',
'         where p.release_id = rt.id and',
'               p.owner_id = tm.id and',
'               p.ARCHIVED_YN = ''N'' and ',
'               p.DUPLICATE_OF_PROJECT_ID is null and',
'               p.release_id = :P117_RELEASE_ID ',
'        ) project_owner_count,',
'        --',
'        -- team member photo',
'        --',
'        tm.photo,',
'        tm.photo_mimetype',
'  from SP_RELEASE_TRAINS rt,',
'       SP_TEAM_MEMBERS tm',
'where rt.id = :P117_RELEASE_ID and ',
'      --',
'      -- search',
'      --',
'      (:P117_CONTRIBUTOR_SEARCH is null or instr(upper(tm.first_name||'' ''||last_name||'' ''||email), upper(:P117_CONTRIBUTOR_SEARCH)) > 0)',
') x',
'where (',
'            identified_as_contributor > 0 or ',
'            identified_as_reviewer > 0 or ',
'            project_activivity_contributor > 0 or ',
'            project_owner_count > 0',
'       )',
''))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_CONTENT_ROW'
,p_ajax_items_to_submit=>'P117_RELEASE_ID,P117_CONTRIBUTOR_SEARCH'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_plug_footer=>'<p>This list of contributors includes anyone who is identified as a &NOMENCLATURE_PROJECT. owner, contributor, reviewer, or who has activity logged against a &NOMENCLATURE_PROJECT. identified for this release.'
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'AVATAR_IMAGE', '{"source":"BLOB_COLUMN","blobColumn":"PHOTO","filenameColumn":"PHOTO_MIMETYPE","mimeTypeColumn":"","lastUpdatedColumn":""}',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_TYPE', 'image',
  'DESCRIPTION', 'Contributor: <strong>&IDENTIFIED_AS_CONTRIBUTOR.</strong>, Reviewer: <strong>&IDENTIFIED_AS_REVIEWER.</strong>, Activity: <strong>&PROJECT_ACTIVIVITY_CONTRIBUTOR.</strong>, &NOMENCLATURE_PROJECT. Owner: <strong>&PROJECT_OWNER_COUNT.</strong>',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'N',
  'MISC', '&EMAIL.',
  'TITLE', '&NAME.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10599867677325210622)
,p_name=>'TEAM_MEMBER_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TEAM_MEMBER_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10599867837122210623)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10599867887661210624)
,p_name=>'EMAIL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'EMAIL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10599868014905210625)
,p_name=>'PERSON_TAGS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PERSON_TAGS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10599868146930210626)
,p_name=>'IDENTIFIED_AS_CONTRIBUTOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IDENTIFIED_AS_CONTRIBUTOR'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10599868205454210627)
,p_name=>'IDENTIFIED_AS_REVIEWER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IDENTIFIED_AS_REVIEWER'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10599868272157210628)
,p_name=>'PROJECT_ACTIVIVITY_CONTRIBUTOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROJECT_ACTIVIVITY_CONTRIBUTOR'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10599868442960210629)
,p_name=>'PROJECT_OWNER_COUNT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROJECT_OWNER_COUNT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10599868515488210630)
,p_name=>'TOTAL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10599868633666210631)
,p_name=>'IS_CONTRIBUTOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IS_CONTRIBUTOR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>100
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10599868673324210632)
,p_name=>'IS_REVIEWER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IS_REVIEWER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>110
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10599868818522210633)
,p_name=>'IS_ACTIVITY_CONTRIBUTOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IS_ACTIVITY_CONTRIBUTOR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>120
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10599868953286210634)
,p_name=>'IS_OWNER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IS_OWNER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>130
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10689440206614516034)
,p_name=>'PHOTO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PHOTO'
,p_data_type=>'BLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>140
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10689440333259516035)
,p_name=>'PHOTO_MIMETYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PHOTO_MIMETYPE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>150
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26441835979605811953)
,p_plug_name=>'Reviewers'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215436556892368933)
,p_plug_display_sequence=>85
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.id project_id,',
'       p.project,',
'       (select ''P''||PRIORITY from SP_PROJECT_PRIORITIES x where x.ID = p.PRIORITY_ID) priority,',
'       p.PCT_COMPLETE pct_complete,',
'       p.project_size,',
'       t.id team_member_id,',
'       t.first_name||'' ''||last_name reviewer,',
'       t.email reviewer_email,',
'       (select review_type from sp_project_review_types rt where rt.id = r.review_type_id) type,',
'       initcap(review_status) status,',
'       review_date,',
'       review_comments        comments,',
'       r.updated,',
'       p.FRIENDLY_IDENTIFIER,',
'       p.PROJECT_URL_NAME,',
'       null quick_view',
'  from SP_PROJECTS p,',
'       sp_project_reviews r,',
'       sp_team_members t',
'where p.id = r.project_id and',
'      t.id = r.owner_id and',
'      nvl(p.ARCHIVED_YN,''N'') = ''N'' and ',
'      p.DUPLICATE_OF_PROJECT_ID is null and',
'      p.release_id = :P117_RELEASE_ID and',
'      p.RELEASE_DEPENDENT_YN = ''Y'''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P117_RELEASE_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'reviews content'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_required_patch=>wwv_flow_imp.id(11981789696428032972)
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(26441836091706811954)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'SBKENNED'
,p_internal_uid=>24549143979272372832
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14241499847304255340)
,p_db_column_name=>'REVIEWER'
,p_display_order=>10
,p_column_identifier=>'L'
,p_column_label=>'Reviewer'
,p_column_link=>'f?p=&APP_ID.:73:&SESSION.::&DEBUG.:73:P73_TEAM_MEMBER_ID:#TEAM_MEMBER_ID#'
,p_column_linktext=>'#REVIEWER#'
,p_column_link_attr=>'title="Reviewer Details"'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14241499949835255341)
,p_db_column_name=>'REVIEWER_EMAIL'
,p_display_order=>20
,p_column_identifier=>'M'
,p_column_label=>'Reviewer Email'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14241499444364255336)
,p_db_column_name=>'PROJECT'
,p_display_order=>30
,p_column_identifier=>'H'
,p_column_label=>'Project'
,p_column_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:FI,PN:#FRIENDLY_IDENTIFIER#,#PROJECT_URL_NAME#'
,p_column_linktext=>'#PROJECT#'
,p_column_link_attr=>'title="&NOMENCLATURE_PROJECT. Details"'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(26441836615193811959)
,p_db_column_name=>'TYPE'
,p_display_order=>40
,p_column_identifier=>'E'
,p_column_label=>'Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(26441836493068811958)
,p_db_column_name=>'STATUS'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14241500423975255346)
,p_db_column_name=>'REVIEW_DATE'
,p_display_order=>60
,p_column_identifier=>'P'
,p_column_label=>'Review Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(26441836749465811960)
,p_db_column_name=>'COMMENTS'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Comments'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14241499527288255337)
,p_db_column_name=>'PRIORITY'
,p_display_order=>80
,p_column_identifier=>'I'
,p_column_label=>'Priority'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14241499690656255338)
,p_db_column_name=>'PCT_COMPLETE'
,p_display_order=>90
,p_column_identifier=>'J'
,p_column_label=>'Pct Complete'
,p_column_html_expression=>'#PCT_COMPLETE#%'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14241499772988255339)
,p_db_column_name=>'PROJECT_SIZE'
,p_display_order=>100
,p_column_identifier=>'K'
,p_column_label=>'Project Size'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(26441836252659811956)
,p_db_column_name=>'UPDATED'
,p_display_order=>110
,p_column_identifier=>'B'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14241500062769255342)
,p_db_column_name=>'PROJECT_ID'
,p_display_order=>120
,p_column_identifier=>'N'
,p_column_label=>'Project Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14241500147685255343)
,p_db_column_name=>'TEAM_MEMBER_ID'
,p_display_order=>130
,p_column_identifier=>'O'
,p_column_label=>'Team Member'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14240982492834665845)
,p_db_column_name=>'FRIENDLY_IDENTIFIER'
,p_display_order=>140
,p_column_identifier=>'Q'
,p_column_label=>'Friendly Identifier'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14240982575695665846)
,p_db_column_name=>'PROJECT_URL_NAME'
,p_display_order=>150
,p_column_identifier=>'R'
,p_column_label=>'Project Url Name'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14240982711268665847)
,p_db_column_name=>'QUICK_VIEW'
,p_display_order=>160
,p_column_identifier=>'S'
,p_column_label=>'Quick View'
,p_column_link=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:RP,36:P36_ID:#PROJECT_ID#'
,p_column_linktext=>'<span class="fa fa-bars" aria-hidden="true"></span>'
,p_column_link_attr=>'Quick View'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(26674394426358662993)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'123483344'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'REVIEWER:PROJECT:TYPE:STATUS:REVIEW_DATE:UPDATED:QUICK_VIEW:'
,p_sort_column_1=>'REVIEWER'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'TYPE'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'STATUS'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(15572321582393852637)
,p_report_id=>wwv_flow_imp.id(26674394426358662993)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'STATUS'
,p_operator=>'!='
,p_expr=>'Completed'
,p_condition_sql=>'"STATUS" != #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# != ''Completed''  '
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(39129585865684997112)
,p_name=>'Release'
,p_template=>wwv_flow_imp.id(141215438656052368935)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:t-Region--scrollBody:t-Region-orderBy--end:margin-left-md'
,p_component_template_options=>'#DEFAULT#:t-ContextualInfo-label--stacked'
,p_display_point=>'REGION_POSITION_01'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.ID,',
'       r.RELEASE_TRAIN||'' ''||r.RELEASE release,',
'       decode(r.RELEASE_TARGET_DATE,null,    ''No Date'',to_char(r.RELEASE_TARGET_DATE,   ''DD-MON-YY'')) RELEASE_TARGET_DATE,',
'       decode(r.RELEASE_OPEN_DATE,null,      ''No Date'',to_char(r.RELEASE_OPEN_DATE,     ''DD-MON-YY'')) RELEASE_OPEN_DATE,',
'       greatest(round(r.RELEASE_TARGET_DATE - sysdate),0) days_remaining,',
'       --',
'       -- projects',
'       --',
'       (select count(*) ',
'       from sp_projects p ',
'       where p.release_id = r.id and ',
'             p.ARCHIVED_YN = ''N'' and ',
'             p.RELEASE_DEPENDENT_YN = ''Y'' and ',
'             p.DUPLICATE_OF_PROJECT_ID is null) projects,',
'       --',
'       --',
'       --',
'       round(r.RELEASE_TARGET_DATE - r.RELEASE_OPEN_DATE) release_length,',
'       -- ',
'       -- team members',
'       --',
'       (select count(distinct TEAM_MEMBER_ID) ',
'       from SP_PROJECT_CONTRIBUTORS c ',
'       where c.PROJECT_ID in (',
'           select id ',
'           from sp_projects p ',
'           where p.release_id = r.id and ',
'                 p.ARCHIVED_YN = ''N'' and ',
'                 p.RELEASE_DEPENDENT_YN = ''Y'' and ',
'                 p.DUPLICATE_OF_PROJECT_ID is null)) contributors,',
'       --',
'       -- owner',
'       --',
'       t.first_name||'' ''||t.last_name owner,',
'       --',
'       -- reviewers',
'       --',
'       (select count(distinct OWNER_ID) from SP_PROJECT_REVIEWS pr where pr.PROJECT_ID in (',
'           select id ',
'           from sp_projects p ',
'           where p.release_id = r.id and ',
'                 ARCHIVED_YN = ''N'' and ',
'                 p.RELEASE_DEPENDENT_YN = ''Y'' and ',
'                 p.DUPLICATE_OF_PROJECT_ID is null)) reviewers,',
'       --',
'       -- milestones',
'       --',
'       (select count(*) from SP_RELEASE_MILESTONES m where m.release_id = r.id) milestones,',
'       (select count(*) from sp_release_comments rc where rc.release_id = r.id) comments,',
'       --',
'       -- release open and close',
'       --',
'       decode(r.RELEASE_OPEN_COMPLETED,''Y'',''Yes'',''N'',''No'',''Unknown'') release_opened,',
'       decode(r.RELEASE_COMPLETED,''Y'',''Yes'',''N'',''No'',''Unknown'') release_completed',
'  from SP_RELEASE_TRAINS r,',
'       SP_TEAM_MEMBERS t',
' where r.id = :P117_RELEASE_ID and ',
'       r.RELEASE_OWNER_ID = t.id(+)'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141215497118444368989)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590600779701942629)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590601164117942630)
,p_query_column_id=>2
,p_column_alias=>'RELEASE'
,p_column_display_sequence=>40
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590598325870942625)
,p_query_column_id=>3
,p_column_alias=>'RELEASE_TARGET_DATE'
,p_column_display_sequence=>70
,p_column_heading=>'Target Complete'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590599168478942627)
,p_query_column_id=>4
,p_column_alias=>'RELEASE_OPEN_DATE'
,p_column_display_sequence=>60
,p_column_heading=>'Open'
,p_use_as_row_header=>'N'
,p_column_format=>'DD-MON-YY'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590601522780942631)
,p_query_column_id=>5
,p_column_alias=>'DAYS_REMAINING'
,p_column_display_sequence=>90
,p_column_heading=>'Remaining'
,p_use_as_row_header=>'N'
,p_column_format=>'99999'
,p_column_html_expression=>'#DAYS_REMAINING# days'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590599584660942627)
,p_query_column_id=>6
,p_column_alias=>'PROJECTS'
,p_column_display_sequence=>100
,p_column_heading=>'&NOMENCLATURE_PROJECTS.'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590599997638942628)
,p_query_column_id=>7
,p_column_alias=>'RELEASE_LENGTH'
,p_column_display_sequence=>80
,p_column_heading=>'Length'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'#RELEASE_LENGTH# days'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590600330739942628)
,p_query_column_id=>8
,p_column_alias=>'CONTRIBUTORS'
,p_column_display_sequence=>130
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590601969705942631)
,p_query_column_id=>9
,p_column_alias=>'OWNER'
,p_column_display_sequence=>150
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590598755911942626)
,p_query_column_id=>10
,p_column_alias=>'REVIEWERS'
,p_column_display_sequence=>140
,p_column_heading=>'Reviewers'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590602327101942632)
,p_query_column_id=>11
,p_column_alias=>'MILESTONES'
,p_column_display_sequence=>110
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6614935837059924445)
,p_query_column_id=>12
,p_column_alias=>'COMMENTS'
,p_column_display_sequence=>120
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14240982401100665844)
,p_query_column_id=>13
,p_column_alias=>'RELEASE_OPENED'
,p_column_display_sequence=>180
,p_column_heading=>'Release Opened'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14240982257865665843)
,p_query_column_id=>14
,p_column_alias=>'RELEASE_COMPLETED'
,p_column_display_sequence=>170
,p_column_heading=>'Release Completed'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(120641085269735322943)
,p_name=>'Comments'
,p_template=>wwv_flow_imp.id(141215306085609368903)
,p_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Comments--chat'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rc.ID,',
'       -- Display Columns',
'       tm.initials user_icon,',
'       apex_util.get_since(rc.created) comment_date,',
'       tm.first_name || '' '' || tm.last_name user_name,',
'       --',
'       rc.body_html comment_text,',
'       ''<a href="''||apex_util.prepare_URL(',
'           p_url => ''f?p=''||:APP_ID||'':83:''||:APP_SESSION||''::NO::P83_ID:''||rc.id,',
'           p_checksum_type => ''3''',
'       )||''">edit</a>'' actions,',
'       decode(rc.private_yn,null,null,''N'',null,''Y'','' Private Comment'') private_comment_label,',
'       '' '' attribute_1,',
'       '' '' attribute_2,',
'       '' '' attribute_3,',
'       '' '' attribute_4,',
'       ''u-color-''||ora_hash(rc.created_by,45) icon_modifier,',
'',
'       -- Data Columns',
'       rc.BODY,',
'       rc.BODY_HTML,',
'       rc.AUTHOR_ID,',
'       --',
'       rc.CREATED,',
'       rc.CREATED_BY,',
'       rc.UPDATED,',
'       rc.UPDATED_BY,',
'       tm.id team_member_id',
'  from sp_release_comments rc, ',
'       sp_team_members tm',
'where rc.author_id = tm.id and',
'      rc.release_id = :P117_RELEASE_ID and',
'      (nvl(rc.private_yn,''N'') = ''N'' or lower(rc.created_by) = lower(:app_user) )',
'order by created desc'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P117_RELEASE_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141215495969045368988)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No Comments'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590874052114632141)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590866881570632133)
,p_query_column_id=>2
,p_column_alias=>'USER_ICON'
,p_column_display_sequence=>150
,p_column_heading=>'User Icon'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590867229807632134)
,p_query_column_id=>3
,p_column_alias=>'COMMENT_DATE'
,p_column_display_sequence=>160
,p_column_heading=>'Comment Date'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590867643723632135)
,p_query_column_id=>4
,p_column_alias=>'USER_NAME'
,p_column_display_sequence=>170
,p_column_heading=>'User Name'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590868022092632135)
,p_query_column_id=>5
,p_column_alias=>'COMMENT_TEXT'
,p_column_display_sequence=>180
,p_column_heading=>'Comment Text'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if PRIVATE_COMMENT_LABEL/}<strong class="u-danger-text">#PRIVATE_COMMENT_LABEL#</strong><br />{endif/}',
'#COMMENT_TEXT#'))
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590868477035632136)
,p_query_column_id=>6
,p_column_alias=>'ACTIONS'
,p_column_display_sequence=>190
,p_column_heading=>'Actions'
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15323522812052323969)
,p_query_column_id=>7
,p_column_alias=>'PRIVATE_COMMENT_LABEL'
,p_column_display_sequence=>260
,p_column_heading=>'Private Comment Label'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590868840610632136)
,p_query_column_id=>8
,p_column_alias=>'ATTRIBUTE_1'
,p_column_display_sequence=>200
,p_column_heading=>'Attribute 1'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590869284139632136)
,p_query_column_id=>9
,p_column_alias=>'ATTRIBUTE_2'
,p_column_display_sequence=>210
,p_column_heading=>'Attribute 2'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590869672886632137)
,p_query_column_id=>10
,p_column_alias=>'ATTRIBUTE_3'
,p_column_display_sequence=>220
,p_column_heading=>'Attribute 3'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590870108462632137)
,p_query_column_id=>11
,p_column_alias=>'ATTRIBUTE_4'
,p_column_display_sequence=>230
,p_column_heading=>'Attribute 4'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590870477744632137)
,p_query_column_id=>12
,p_column_alias=>'ICON_MODIFIER'
,p_column_display_sequence=>240
,p_column_heading=>'Icon Modifier'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590870856448632138)
,p_query_column_id=>13
,p_column_alias=>'BODY'
,p_column_display_sequence=>40
,p_column_heading=>'Body'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590871238391632138)
,p_query_column_id=>14
,p_column_alias=>'BODY_HTML'
,p_column_display_sequence=>50
,p_column_heading=>'Body Html'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590871645068632138)
,p_query_column_id=>15
,p_column_alias=>'AUTHOR_ID'
,p_column_display_sequence=>80
,p_column_heading=>'Author Id'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590872028767632139)
,p_query_column_id=>16
,p_column_alias=>'CREATED'
,p_column_display_sequence=>110
,p_column_heading=>'Created'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590872464574632139)
,p_query_column_id=>17
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>120
,p_column_heading=>'Created By'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590872852063632139)
,p_query_column_id=>18
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>130
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590873229235632140)
,p_query_column_id=>19
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>140
,p_column_heading=>'Updated By'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6590873710271632140)
,p_query_column_id=>20
,p_column_alias=>'TEAM_MEMBER_ID'
,p_column_display_sequence=>250
,p_column_heading=>'User ID'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(148462711968184228055)
,p_plug_name=>'Documents'
,p_region_name=>'DOCUMENTS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215436556892368933)
,p_plug_display_sequence=>140
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d.ID,',
'       d.DOCUMENT_FILENAME,',
'       d.UPDATED,',
'       d.created,',
'       decode(greatest(length(d.doc_description),200),200,d.doc_description,substr(d.doc_description,1,200)||''...'') doc_description,',
'       d.tags,',
'       lower(created_by) created_by,',
'       dbms_lob.getlength(d.DOCUMENT_BLOB) doc_size,',
'       created date_created,',
'       substr(DOCUMENT_FILENAME,instr(DOCUMENT_FILENAME,''.'',-1)+1,length(DOCUMENT_FILENAME)-instr(DOCUMENT_FILENAME,''.'',-1)) file_extension,',
'       decode(important_yn,''Y'',''Yes'',''No'') important',
'  from SP_RELEASE_DOCUMENTS d',
' where release_id = :P117_RELEASE_ID',
'order by created desc',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P117_RELEASE_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Documents'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(34771325779849523379)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.:120:P120_ID:#ID#'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(141215568360703369146)
,p_owner=>'MIKE'
,p_internal_uid=>32878633667415084257
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(34771325881013523380)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(34771326013404523381)
,p_db_column_name=>'DOCUMENT_FILENAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Filename'
,p_column_link=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:42:P42_ID,P42_PREV_PAGE:#ID#,117'
,p_column_linktext=>'#DOCUMENT_FILENAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(34771326438205523385)
,p_db_column_name=>'DOC_DESCRIPTION'
,p_display_order=>40
,p_column_identifier=>'F'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(34771326643734523387)
,p_db_column_name=>'DOC_SIZE'
,p_display_order=>50
,p_column_identifier=>'H'
,p_column_label=>'Size'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FILESIZE'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(34771326190368523383)
,p_db_column_name=>'UPDATED'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(34771326266211523384)
,p_db_column_name=>'CREATED'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(34771326660772523388)
,p_db_column_name=>'DATE_CREATED'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Created On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(35208180851518372167)
,p_db_column_name=>'FILE_EXTENSION'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'File Extension'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45867864555458920970)
,p_db_column_name=>'TAGS'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Tags'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(32854360567718253414)
,p_db_column_name=>'IMPORTANT'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Important'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17928415282757018129)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'Added By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(34773062014653116150)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8109551'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENT_FILENAME:DOC_DESCRIPTION:CREATED_BY:IMPORTANT:DOC_SIZE:UPDATED:'
,p_sort_column_1=>'IMPORTANT'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'UPDATED'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'DOC_SIZE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6590874446221632141)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(120641085269735322943)
,p_button_name=>'POST_COMMENT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Post Comment'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_grid_column_css_classes=>'u-flex u-align-items-center'
,p_grid_new_row=>'Y'
,p_security_scheme=>wwv_flow_imp.id(141215568360703369146)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10621568320170998833)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(21475696331386100763)
,p_button_name=>'contributor_search_button'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Search'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6614935397639924440)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(6614934048809924427)
,p_button_name=>'add_link'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(141215539798004369050)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Link'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_security_scheme=>wwv_flow_imp.id(141215568360703369146)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13394402611120490023)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(14008465841962832540)
,p_button_name=>'SUBSCRIBE_TO_EXCEPTIONS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_image_alt=>'Subscribe me'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from sp_notifications n',
' where static_id = ''RELEASE_EXCEPTIONS''',
'   and is_active_yn = ''Y''',
'   and not exists (select 1',
'                     from sp_notification_subscriptions',
'                    where team_member_id = :APP_USER_ID',
'                      and notification_id = n.id',
'                      and release_id = :P117_RELEASE_ID',
'                      and opted_in_yn = ''Y'')',
'   and :APP_USER_ID is not null'))
,p_button_condition_type=>'EXISTS'
,p_required_patch=>wwv_flow_imp.id(13014838139098269244)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15323523091123323972)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(14008466253588832544)
,p_button_name=>'INCLUDE_PAST'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_image_alt=>'Include Past'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.::P117_INCLUDE_PAST_YN:Y'
,p_button_condition=>'P117_INCLUDE_PAST_YN'
,p_button_condition2=>'N'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14008466059403832542)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(14008465841962832540)
,p_button_name=>'UNSUBSCRIBE_EXCEPTIONS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_image_alt=>'Unsubscribe'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from sp_notifications n',
' where static_id = ''RELEASE_EXCEPTIONS''',
'   and is_active_yn = ''Y''',
'   and :APP_USER_ID is not null',
'   and exists (select 1',
'                 from sp_notification_subscriptions',
'                where team_member_id = :APP_USER_ID',
'                  and notification_id = n.id',
'                  and release_id = :P117_RELEASE_ID',
'                  and opted_in_yn = ''Y'')'))
,p_button_condition_type=>'EXISTS'
,p_required_patch=>wwv_flow_imp.id(13014838139098269244)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16587874284991848924)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(14008466253588832544)
,p_button_name=>'EXCLUDE_PAST'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_image_alt=>'Exclude Past'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.::P117_INCLUDE_PAST_YN:N'
,p_button_condition=>'P117_INCLUDE_PAST_YN'
,p_button_condition2=>'Y'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13013908236661140866)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(14008465841962832540)
,p_button_name=>'EMAIL_EXCEPTIONS_TO_ME'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_image_alt=>'Email to me'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15323519599860323937)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(14008466253588832544)
,p_button_name=>'INCLUDE_COMPLETED'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_image_alt=>'Include Completed'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.::P117_EXCLUDE_COMPLETE_YN:N'
,p_button_condition=>'P117_EXCLUDE_COMPLETE_YN'
,p_button_condition2=>'Y'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15323519439915323936)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(14008466253588832544)
,p_button_name=>'EXCLUDE_COMPLETED'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_image_alt=>'Exclude Completed'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.::P117_EXCLUDE_COMPLETE_YN:Y'
,p_button_condition=>'nvl(:P117_EXCLUDE_COMPLETE_YN,''N'') = ''N'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13201602489267446621)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(14008466253588832544)
,p_button_name=>'EMAIL_TO_ME'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_image_alt=>'Email to me'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_required_patch=>wwv_flow_imp.id(18721993490508994894)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6590482955244851151)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(18881767277384682816)
,p_button_name=>'add_milestone'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141215539798004369050)
,p_button_image_alt=>'Add Milestone'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:85:&SESSION.::&DEBUG.:RP,85:P85_RELEASE_ID:&P117_RELEASE_ID.'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6590483056277851152)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(11258013965216626402)
,p_button_name=>'add_project'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141215539798004369050)
,p_button_image_alt=>'Add &NOMENCLATURE_PROJECT.'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:104:&SESSION.::&DEBUG.:RP,104,24::'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(141215568360703369146)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17928189674439871879)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(148462711968184228055)
,p_button_name=>'view_images'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_image_alt=>'Image Gallery'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:29:P29_PROJECT_ID:&P117_PROJECT_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 ',
'  from SP_PROJECT_DOCUMENTS d',
' where project_id = :P117_PROJECT_ID and ',
'       (',
'           lower(DOCUMENT_FILENAME) like ''%.png'' or ',
'           lower(DOCUMENT_FILENAME) like ''%.jpg'' or ',
'           lower(DOCUMENT_FILENAME) like ''%.jpeg'' or ',
'           lower(DOCUMENT_FILENAME) like ''%.gif'' or ',
'           lower(DOCUMENT_FILENAME) like ''%.tiff'' or ',
'           lower(DOCUMENT_FILENAME) like ''%.ai'' ',
'       )'))
,p_button_condition_type=>'EXISTS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(17928190044281871879)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(148462711968184228055)
,p_button_name=>'add_document'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141215539798004369050)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Document'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.:RR,120:P120_RELEASE_ID:&P117_RELEASE_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(141215568360703369146)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6590583533538941191)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(18880452978478091625)
,p_button_name=>'UP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141215539010391369046)
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6590481552459851137)
,p_name=>'P117_RELEASE'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6590481687275851138)
,p_name=>'P117_RELEASE_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6590483193377851153)
,p_name=>'P117_INITIATIVE_ID'
,p_item_sequence=>160
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6614935283337924439)
,p_name=>'P117_LINK'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6614934048809924427)
,p_prompt=>'Link URL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(141215538337231369044)
,p_item_template_options=>'#DEFAULT#'
,p_security_scheme=>wwv_flow_imp.id(141215568360703369146)
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6614935684468924443)
,p_name=>'P117_LINK_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(6614934048809924427)
,p_prompt=>'Link Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(141215538337231369044)
,p_item_template_options=>'#DEFAULT#'
,p_security_scheme=>wwv_flow_imp.id(141215568360703369146)
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10621568311086998832)
,p_name=>'P117_CONTRIBUTOR_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(21475696331386100763)
,p_prompt=>'Search'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(141215538820216369045)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15323519055337323932)
,p_name=>'P117_EXCLUDE_COMPLETE_YN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(11069174565248088154)
,p_item_default=>'N'
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16239415468373725824)
,p_name=>'P117_PRIVATE_YN'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(120641085269735322943)
,p_item_default=>'N'
,p_prompt=>'This is a private comment'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(141215536714581369037)
,p_item_template_options=>'#DEFAULT#:margin-left-md'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16587874166479848923)
,p_name=>'P117_INCLUDE_PAST_YN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(11069174565248088154)
,p_item_default=>'N'
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129212003699315580161)
,p_name=>'P117_COMMENT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(120641085269735322943)
,p_prompt=>' '
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_field_template=>wwv_flow_imp.id(141215537113464369041)
,p_item_template_options=>'#DEFAULT#'
,p_security_scheme=>wwv_flow_imp.id(141215568360703369146)
,p_attribute_01=>'MARKDOWN'
,p_attribute_04=>'180'
,p_attribute_25=>'TINYMCE'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(6590481724205851139)
,p_computation_sequence=>10
,p_computation_item=>'P117_RELEASE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>'select release_train||'' ''||release d from sp_release_trains where id = :P117_RELEASE_ID'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(15323521716151323959)
,p_computation_sequence=>20
,p_computation_item=>'P117_EXCLUDE_COMPLETE_YN'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'N'
,p_compute_when=>'P117_EXCLUDE_COMPLETE_YN'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(16587874403535848925)
,p_computation_sequence=>30
,p_computation_item=>'P117_INCLUDE_PAST_YN'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'N'
,p_compute_when=>'P117_INCLUDE_PAST_YN'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6590482296334851144)
,p_name=>'post comment'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(6590874446221632141)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6590482338028851145)
,p_event_id=>wwv_flow_imp.id(6590482296334851144)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'post comment on server'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_strategic_proj_util.add_release_comment (',
'    p_app_user        => :APP_USER,',
'    p_comment         => :P117_COMMENT,',
'    p_release_id      => :P117_RELEASE_ID,',
'    p_private_yn      => :P117_PRIVATE_YN );',
'',
':P117_COMMENT := null;'))
,p_attribute_02=>'P117_COMMENT,P117_RELEASE_ID,P117_PRIVATE_YN'
,p_attribute_03=>'P117_COMMENT'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6590482510726851146)
,p_event_id=>wwv_flow_imp.id(6590482296334851144)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(120641085269735322943)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6590482572177851147)
,p_name=>'reload comments on dialog close'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(120641085269735322943)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6590482682297851148)
,p_event_id=>wwv_flow_imp.id(6590482572177851147)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(120641085269735322943)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16587874728180848929)
,p_name=>'reload links on dialog close'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(6614934048809924427)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16587874898787848930)
,p_event_id=>wwv_flow_imp.id(16587874728180848929)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6614934048809924427)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16818867332577820668)
,p_name=>'reload documents'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(148462711968184228055)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16818867433351820669)
,p_event_id=>wwv_flow_imp.id(16818867332577820668)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(148462711968184228055)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6590483307318851154)
,p_name=>'refresh milestones on dc'
,p_event_sequence=>70
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(18881767277384682816)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6590483326710851155)
,p_event_id=>wwv_flow_imp.id(6590483307318851154)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(18881767277384682816)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6590483474636851156)
,p_name=>'refresh projects on dc'
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(11258013965216626402)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6590483561347851157)
,p_event_id=>wwv_flow_imp.id(6590483474636851156)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11258013965216626402)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6614935504453924441)
,p_name=>'on add link click'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(6614935397639924440)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16818863642800820631)
,p_event_id=>wwv_flow_imp.id(6614935504453924441)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Please supply a Link URL and a Link Name.'
,p_attribute_02=>'Missing Link Details'
,p_client_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_client_condition_expression=>'$v(''P117_LINK'') === '''' || $v(''P117_LINK_NAME'') === '''''
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6614935570883924442)
,p_event_id=>wwv_flow_imp.id(6614935504453924441)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P117_LINK_NAME is not null and :P117_LINK is not null then',
'    insert into SP_RELEASE_LINKS (release_id, link_name, link_url) ',
'        values (:P117_RELEASE_ID, :P117_LINK_NAME, :P117_LINK);',
':P117_LINK_NAME := null;',
':P117_LINK := null;',
'end if;'))
,p_attribute_02=>'P117_LINK_NAME,P117_LINK,P117_RELEASE_ID'
,p_attribute_03=>'P117_LINK,P117_LINK_NAME'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6614935716328924444)
,p_event_id=>wwv_flow_imp.id(6614935504453924441)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6614934048809924427)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10621568440891998834)
,p_name=>'on cont button click'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10621568320170998833)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10621568594097998835)
,p_event_id=>wwv_flow_imp.id(10621568440891998834)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P117_CONTRIBUTOR_SEARCH'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10621568674986998836)
,p_event_id=>wwv_flow_imp.id(10621568440891998834)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(21475696331386100763)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(13013908465847140868)
,p_name=>'after release edit'
,p_event_sequence=>110
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(18880452978478091625)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13013908512471140869)
,p_event_id=>wwv_flow_imp.id(13013908465847140868)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'refresh Release'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(39129585865684997112)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13013908752017140871)
,p_event_id=>wwv_flow_imp.id(13013908465847140868)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'refresh Exceptions'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(13013908159270140865)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13394405175291490049)
,p_event_id=>wwv_flow_imp.id(13013908465847140868)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'refresh Timeline'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11069174565248088154)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13201605761993448387)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Email timeline to me'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_summary      clob;',
'begin',
'',
'    l_summary := sp_release_timeline.show_week (',
'                     p_release_id          => :P117_RELEASE_ID,',
'                     p_exclude_complete_yn => nvl(:P117_EXCLUDE_COMPLETE_YN,''N''));',
'',
'    apex_mail.send ( ',
'            p_to                 => :APP_USER,   ',
'            p_from               => :APP_USER,  ',
'            p_application_id     => :APP_ID,  ',
'            p_template_static_id => ''EMAIL_ME'',  ',
'            p_placeholders       => ''{'' || ''"APPLICATION_LINK": "'' || sp_strategic_proj_util.get_setting(p_static_id => ''APP_HOME_URL'') ||''", ''|| ',
'                                           ''"APP_NAME": ''   || apex_json.stringify( :NOMENCLATURE_STRATEGIC_PLANNER ) ||'', ''||',
'                                           ''"SUBJECT": ''    || apex_json.stringify( :NOMENCLATURE_STRATEGIC_PLANNER || '' '' || :P117_RELEASE ||'' Release Timeline'' ) ||'', ''||',
'                                           ''"SUMMARY": ''    || apex_json.stringify( l_summary ) ||',
'                                     ''}'' ); ',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(13201602489267446621)
,p_process_success_message=>'Timeline email sent.'
,p_internal_uid=>11308913649559009265
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13013908410537140867)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Email exceptions to me'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_summary      clob;',
'begin',
'',
'    l_summary := sp_release_timeline.release_exceptions (',
'                     p_release_id              => :P117_RELEASE_ID,',
'                     p_links                   => ''EMAIL'' );',
'',
'    apex_mail.send ( ',
'            p_to                 => :APP_USER,   ',
'            p_from               => :APP_USER,  ',
'            p_application_id     => :APP_ID,  ',
'            p_template_static_id => ''EMAIL_ME'',  ',
'            p_placeholders       => ''{'' || ''"APPLICATION_LINK": "'' || sp_strategic_proj_util.get_setting(p_static_id => ''APP_HOME_URL'') ||''", ''|| ',
'                                           ''"APP_NAME": ''   || apex_json.stringify( :NOMENCLATURE_STRATEGIC_PLANNER ) ||'', ''||',
'                                           ''"SUBJECT": ''    || apex_json.stringify( :NOMENCLATURE_STRATEGIC_PLANNER || '' '' || :P117_RELEASE ||'' Release Exceptions'' ) ||'', ''||',
'                                           ''"SUMMARY": ''    || apex_json.stringify( l_summary ) ||',
'                                     ''}'' ); ',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(13013908236661140866)
,p_process_success_message=>'Release Exceptions email sent.'
,p_internal_uid=>11121216298102701745
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13394402683064490024)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Subscribe to Exceptions'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_strategic_proj_util.notification_opt_in (',
'    p_team_member_id => :APP_USER_ID,',
'    p_notification_id => sp_strategic_proj_util.get_notification_id(''RELEASE_EXCEPTIONS''),',
'    p_release_id      => :P117_RELEASE_ID );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(13394402611120490023)
,p_process_success_message=>'Subscribed to Release Exceptions.'
,p_internal_uid=>11501710570630050902
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14008466165373832543)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Unsubscribe Exceptions'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_strategic_proj_util.notification_opt_out (',
'    p_team_member_id  => :APP_USER_ID,',
'    p_notification_id => sp_strategic_proj_util.get_notification_id(''RELEASE_EXCEPTIONS''),',
'    p_release_id      => :P117_RELEASE_ID );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(14008466059403832542)
,p_process_success_message=>'Unsubscribed from Release Exceptions.'
,p_internal_uid=>12115774052939393421
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(7369070500759686767)
,p_region_id=>wwv_flow_imp.id(22954606614107303559)
,p_position_id=>wwv_flow_imp.id(3744591539380446466)
,p_display_sequence=>10
,p_template_id=>wwv_flow_imp.id(3744592141057477595)
,p_label=>'Edit'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:27:P27_ID:&P117_RELEASE_ID.'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-edit'
,p_is_hot=>true
,p_show_as_disabled=>false
,p_authorization_scheme=>wwv_flow_imp.id(141215568360703369146)
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(10599868987099210635)
,p_region_id=>wwv_flow_imp.id(21475696331386100763)
,p_position_id=>wwv_flow_imp.id(10447953876505871393)
,p_display_sequence=>10
,p_template_id=>wwv_flow_imp.id(10447955737702906670)
,p_label=>'Actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_action_css_classes=>'t-Button--noUI'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(22954606914686303562)
,p_region_id=>wwv_flow_imp.id(22954606614107303559)
,p_position_id=>wwv_flow_imp.id(3744591539380446466)
,p_display_sequence=>20
,p_template_id=>wwv_flow_imp.id(3744593400577481743)
,p_label=>'Actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(6718880300869475637)
,p_component_action_id=>wwv_flow_imp.id(22954606914686303562)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Delete Release'
,p_display_sequence=>70
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:76:&SESSION.::&DEBUG.:RP,76:P76_ID:&P117_RELEASE_ID.'
,p_icon_css_classes=>'fa-trash-o'
,p_authorization_scheme=>wwv_flow_imp.id(141215568360703369146)
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(10599869198449210637)
,p_component_action_id=>wwv_flow_imp.id(10599868987099210635)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Contributor Details'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:RP,5:P5_ID:&TEAM_MEMBER_ID.'
,p_icon_css_classes=>'fa-user'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(10599869362804210638)
,p_component_action_id=>wwv_flow_imp.id(10599868987099210635)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Contributor Quick Look'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:73:&SESSION.::&DEBUG.:RP,73:P73_TEAM_MEMBER_ID:&TEAM_MEMBER_ID.'
,p_icon_css_classes=>'fa-user'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(15375344007915837852)
,p_component_action_id=>wwv_flow_imp.id(22954606914686303562)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Calendar'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.:RP,201:P201_RELEASE_ID:&P117_RELEASE_ID.'
,p_icon_css_classes=>'fa-calendar-o'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(15375344159387837854)
,p_component_action_id=>wwv_flow_imp.id(22954606914686303562)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Release History'
,p_display_sequence=>50
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:RP,:P200_RELEASE_ID:&P117_RELEASE_ID.'
,p_icon_css_classes=>'fa-clock-o'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(15375344263115837855)
,p_component_action_id=>wwv_flow_imp.id(22954606914686303562)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Dashboard'
,p_display_sequence=>40
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.:RP,202:P202_RELEASE_ID:&P117_RELEASE_ID.'
,p_icon_css_classes=>'fa-area-chart'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(15375345012782837863)
,p_component_action_id=>wwv_flow_imp.id(22954606914686303562)
,p_menu_entry_type=>'SEPARATOR'
,p_display_sequence=>60
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(16818863141179820626)
,p_component_action_id=>wwv_flow_imp.id(22954606914686303562)
,p_menu_entry_type=>'ENTRY'
,p_label=>'&NOMENCLATURE_PROJECT. Search'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:RP,300,CIR,RIR:P300_RELEASE_ID:&P117_RELEASE_ID.'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(22954606994346303563)
,p_component_action_id=>wwv_flow_imp.id(22954606914686303562)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Refresh'
,p_display_sequence=>90
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(22954607620593303569)
,p_component_action_id=>wwv_flow_imp.id(22954606914686303562)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Reset'
,p_display_sequence=>100
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.:RR,117:P117_RELEASE_ID:&P117_RELEASE_ID.'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(28884716392464157651)
,p_component_action_id=>wwv_flow_imp.id(22954606914686303562)
,p_menu_entry_type=>'SEPARATOR'
,p_display_sequence=>80
);
wwv_flow_imp.component_end;
end;
/
