prompt --application/pages/page_00082
begin
--   Manifest
--     PAGE: 00082
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>82
,p_name=>'Tag History'
,p_alias=>'TAG-HISTORY'
,p_page_mode=>'MODAL'
,p_step_title=>'Tag History'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20240417225348'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(4281061088739613307)
,p_name=>'Tag Changes'
,p_template=>wwv_flow_imp.id(141180095591799434930)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--noBorders'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sp_tag_diff(old_value,new_value) tag_changes,',
'       apex_util.get_since(CHANGED_ON) || '' - ''|| CHANGED_BY  changed',
'  from SP_PROJECT_HISTORY',
' where project_id = :P82_ID and ',
'       attribute_column = ''TAGS'' and ',
'       (',
'           upper(replace(old_value,'' '',null)) != upper(replace(new_value,'' '',null)) or',
'           old_value is null',
'       )',
'order by CHANGED_ON desc'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P82_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141180155116000434985)
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>150
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'None Found'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3108035635863259783)
,p_query_column_id=>1
,p_column_alias=>'TAG_CHANGES'
,p_column_display_sequence=>40
,p_column_heading=>'Tag Changes'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3108035964646259784)
,p_query_column_id=>2
,p_column_alias=>'CHANGED'
,p_column_display_sequence=>30
,p_column_heading=>'Changed'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3094722728300771021)
,p_name=>'P82_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4281061088739613307)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
