prompt --application/pages/page_00109
begin
--   Manifest
--     PAGE: 00109
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>109
,p_name=>'User'
,p_alias=>'USER'
,p_page_mode=>'MODAL'
,p_step_title=>'&NOMENCLATURE_USERS.'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10033027460167375484)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20231205235232'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6088395912230461387)
,p_plug_name=>'button container'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188351742057575241)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8817745897295260423)
,p_plug_name=>'About'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188351742057575241)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'A &NOMENCLATURE_USER. is someone who can be assigned to a &NOMENCLATURE_PROJECT. or other responsiblity. ',
'&NOMENCLATURE_USERS. can be, but are not required to be, users of this application.  ',
'By defining a &NOMENCLATURE_USER. you are defining someone to assign something to.',
'A &NOMENCLATURE_USERS. application role determines their privileges in this application.',
'A &NOMENCLATURE_USER. can be a administator, contributor, or reader or no privilege at all.  ',
'Contributors can create content, and readers can only view content. ',
'Contributors can create other users. ',
'</p>',
'<p>',
'    Examples of what a &NOMENCLATURE_USER. can be associated with:',
'    <ul>',
'        <li>&NOMENCLATURE_AREA. owner</li>',
'        <li>&NOMENCLATURE_INITIATIVE. owner</li>',
'        <li>&NOMENCLATURE_PROJECT. owner</li>',
'        <li>&NOMENCLATURE_PROJECT. contributor</li>',
'        <li>&NOMENCLATURE_PROJECT. reviewer</li>',
'        <li>&NOMENCLATURE_PROJECT. comment author</li>',
'        <li>Activity owner</li>',
'        <li>Release owner</li>',
'    </ul>',
'</p>',
'<p>',
'     Click the dot-dot-dot actions menu control to perform other functions related to &NOMENCLATURE_USERS..',
'</p>',
'',
'<br />',
'<br />'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3276144126012856304)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6088395912230461387)
,p_button_name=>'what_is_a_release'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141188585454452575388)
,p_button_image_alt=>'About Releases'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:108:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa=info'
,p_required_patch=>wwv_flow_imp.id(6210148529518744054)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3276144965233856304)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(6088395912230461387)
,p_button_name=>'what_is_an_area'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141188585454452575388)
,p_button_image_alt=>'About &NOMENCLATURE_AREAS.'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:105:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa=info'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3276143751836856303)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(6088395912230461387)
,p_button_name=>'what_is_a_initiative'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141188585454452575388)
,p_button_image_alt=>'About &NOMENCLATURE_INITIATIVES.'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:106:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa=info'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3276144470830856304)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(6088395912230461387)
,p_button_name=>'what_is_activity'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141188585454452575388)
,p_button_image_alt=>'About Activities'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa=info'
);
wwv_flow_imp.component_end;
end;
/
