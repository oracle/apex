prompt --application/pages/page_00109
begin
--   Manifest
--     PAGE: 00109
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>109
,p_name=>'User'
,p_alias=>'USER'
,p_page_mode=>'MODAL'
,p_step_title=>'&NOMENCLATURE_USERS.'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(45065107974818639665)
,p_step_template=>2101883943284197310
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43849826411946524604)
,p_plug_name=>'About'
,p_static_id=>'about'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'A &NOMENCLATURE_USER. is someone who can be assigned to a &NOMENCLATURE_PROJECT. or other responsiblity. ',
'&NOMENCLATURE_USERS. can be, but are not required to be, users of this application.  ',
'By defining a &NOMENCLATURE_USER. you are defining someone to assign something to.',
'A &NOMENCLATURE_USERS. application role determines their privileges in this application.',
'A &NOMENCLATURE_USER. can be a administator, contributor, or reader or no privilege at all.  ',
'Contributors can create content, and readers can only view content. ',
'Contributors can create other users. ',
'</p>',
'<p>',
'    Examples of what a &NOMENCLATURE_USER. can be associated with:',
'    <ul>',
'        <li>&NOMENCLATURE_AREA. owner</li>',
'        <li>&NOMENCLATURE_INITIATIVE. owner</li>',
'        <li>&NOMENCLATURE_PROJECT. owner</li>',
'        <li>&NOMENCLATURE_PROJECT. contributor</li>',
'        <li>&NOMENCLATURE_PROJECT. reviewer</li>',
'        <li>&NOMENCLATURE_PROJECT. comment author</li>',
'        <li>Activity owner</li>',
'        <li>Release owner</li>',
'    </ul>',
'</p>',
'<p>',
'     Click the dot-dot-dot actions menu control to perform other functions related to &NOMENCLATURE_USERS..',
'</p>',
'',
'<br />',
'<br />'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41120476426881725568)
,p_plug_name=>'button container'
,p_static_id=>'button-container'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38308224266488120484)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(41120476426881725568)
,p_button_name=>'what_is_a_initiative'
,p_static_id=>'what-is-a-initiative'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'About &NOMENCLATURE_INITIATIVES.'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:106:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa=info'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38308224640664120485)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(41120476426881725568)
,p_button_name=>'what_is_a_release'
,p_static_id=>'what-is-a-release'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'About Releases'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:108:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa=info'
,p_required_patch=>wwv_flow_imp.id(41242229044170008235)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38308224985482120485)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(41120476426881725568)
,p_button_name=>'what_is_activity'
,p_static_id=>'what-is-activity'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'About Activities'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa=info'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38308225479885120485)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(41120476426881725568)
,p_button_name=>'what_is_an_area'
,p_static_id=>'what-is-an-area'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'About &NOMENCLATURE_AREAS.'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:105:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa=info'
);
wwv_flow_imp.component_end;
end;
/
