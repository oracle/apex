prompt --application/pages/page_00086
begin
--   Manifest
--     PAGE: 00086
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>86
,p_name=>'Projects Interactive Report'
,p_alias=>'PROJECTS-INTERACTIVE-REPORT1'
,p_step_title=>'&NOMENCLATURE_PROJECTS. Interactive Report'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_by=>'SBKENNED'
,p_last_upd_yyyymmddhh24miss=>'20240411134913'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10440756293429196299)
,p_plug_name=>'Projects Interactive Report'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton'
,p_plug_template=>wwv_flow_imp.id(141180093492639434928)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'       --',
'       -- IDs',
'       --',
'       p.ID as project_id,',
'       p.owner_id,',
'       --',
'       -- project information',
'       --',
'       p.PROJECT,',
'       (select FIRST_NAME ||'' ''||last_name from SP_TEAM_MEMBERS x where x.ID = p.OWNER_ID) the_owner,',
'       (select ''P''||PRIORITY from SP_PROJECT_PRIORITIES x where x.ID = p.PRIORITY_ID) priority,',
'       p.PCT_COMPLETE pct_complete,',
'       case when p.requires_reviews_yn = ''Y'' then ''Yes'' else ''No'' end requires_reviews,',
'       p.friendly_identifier,',
'       p.project_url_name,',
'       replace(lower(p.tags),'','','', '') as tags,',
'       external_ticket_identifier,',
'       external_system_link,',
'       --',
'       -- favorite',
'       --',
'       nvl((',
'           select ''Yes'' ',
'           from sp_favorites f ',
'           where f.project_id = p.id and ',
'                 f.team_member_id = :P86_USER_ID),''No'') favorite,',
'       --',
'       -- project description',
'       --',
'       decode(nvl(dbms_lob.getlength(p.description),0),0,''Not Provided'',',
'           dbms_lob.substr(p.description,300,1)||',
'           decode(greatest(dbms_lob.getlength(p.description),300),300,null,''...'')) description,',
'       --',
'       -- contributors',
'       --',
'       rtrim((select tm.first_name||'' ''||tm.last_name ||'', '' x',
'        from SP_TEAM_MEMBERS tm ',
'        where tm.id = p.owner_id and p.owner_id not in (select pc.team_member_id from SP_PROJECT_CONTRIBUTORS pc where pc.project_id = p.id))||',
'       (select listagg(xtm.first_name||'' ''||xtm.last_name, '', '') within group (order by 1) names',
'       from SP_PROJECT_CONTRIBUTORS xpc, SP_TEAM_MEMBERS xtm',
'       where xpc.project_id = p.id and',
'             xpc.TEAM_MEMBER_ID = xtm.id',
'             ),'', '') contributors,',
'       --',
'       -- contributor emails',
'       --',
'       (select tm.email ||'', '' x',
'        from SP_TEAM_MEMBERS tm ',
'        where tm.id = p.owner_id and p.owner_id not in (select pc.team_member_id from SP_PROJECT_CONTRIBUTORS pc where pc.project_id = p.id))||',
'       (select listagg(xtm.email, '', '') within group (order by 1) names',
'       from SP_PROJECT_CONTRIBUTORS xpc, SP_TEAM_MEMBERS xtm',
'       where xpc.project_id = p.id and',
'             xpc.TEAM_MEMBER_ID = xtm.id',
'             ) contributor_emails,',
'       --',
'       -- reviewers',
'       --',
'       (select count(*) from SP_PROJECT_REVIEWS r where r.PROJECT_ID = p.id) reviews,',
'       (select count(*) from SP_PROJECT_REVIEWS r where r.PROJECT_ID = p.id and REVIEW_STATUS = ''COMPLETED'') completed_reviews,',
'       --',
'       -- updated',
'       --',
'       p.UPDATED,',
'       P.CREATED,',
'       nvl((select first_name||'' ''||last_name from SP_TEAM_MEMBERS tm where tm.email = lower(p.updated_by)),lower(p.updated_by)) updated_by,',
'       --',
'       -- last comments',
'       --',
'       (select max(dbms_lob.substr(c.body,255,1)||',
'               decode(greatest(dbms_lob.getlength(c.body),255),255,null,''...'')) last_comment ',
'        from   SP_PROJECT_COMMENTS c ',
'        where c.project_id = p.id and ',
'              c.private_yn = ''N'' and ',
'              c.created = (select max(c2.created) from sp_project_comments c2 where c2.project_id = p.id and c2.private_yn = ''N''))',
'        as last_comment,',
'       --',
'       (select max(c.created) from sp_project_comments c where c.project_id = p.id and c.private_yn = ''N'') last_comment_on,',
'       (select first_name||'' ''||last_name from SP_TEAM_MEMBERS t where t.id = (select max(c.author_id) from sp_project_comments c where c.project_id = p.id and c.created = (select max(c.created) from sp_project_comments c where c.project_id = p.id an'
||'d c.private_yn = ''N''))) last_comment_by,',
'       --',
'       -- last owner comments',
'       --',
'       (select max(dbms_lob.substr(c.body,255,1)||',
'               decode(greatest(dbms_lob.getlength(c.body),255),255,null,''...'')) last_comment ',
'        from   SP_PROJECT_COMMENTS c ',
'        where c.project_id = p.id and ',
'              c.private_yn = ''N'' and ',
'              c.AUTHOR_ID = p.owner_id and',
'              c.created = (select max(c2.created) from sp_project_comments c2 where c2.project_id = p.id and c2.AUTHOR_ID = p.owner_id and c2.private_yn = ''N''))',
'        as last_comment_by_owner,',
'       --',
'       (select max(c.created) from sp_project_comments c where c.project_id = p.id and c.author_id = p.owner_id and c.private_yn = ''N'') last_comment_by_owner_on,',
'       (select count(*) from sp_project_comments c where c.project_id = p.id and c.created >= sysdate - 28 and c.private_yn = ''N'') comments_28d,',
'       --',
'       -- activity',
'       --',
'       nvl((select count(*) from SP_ACTIVITIES ap where ap.project_id = p.id and trunc(sysdate) >= ap.start_date and trunc(sysdate) <= ap.end_date),0) current_activity_count,',
'       --',
'       -- release',
'       --',
'       nvl(decode(',
'           p.RELEASE_DEPENDENT_YN,',
'           ''Y'',',
'           (select t.release_train||'' ''||t.release from SP_RELEASE_TRAINS t where t.id = p.release_id),',
'           decode(',
'               to_char(p.target_complete,''DD-MON-YYYY''),',
'               null,',
'               ''Not Targeted'',',
'               to_char(p.target_complete,''MON-YYYY'')',
'               )),''Not Targeted'')  release,',
'       --',
'       -- milestones',
'       --',
'       case when milestone1_label is not null then decode(milestone1_complete_yn,''Y'',s.milestone1_label||'' - Completed'',decode(milestone1_complete_date,null,s.milestone1_label||'' - No Date'',s.milestone1_label||'' - ''||to_char(milestone1_complete_date,'
||'''DD-MON''))) end m1,',
'       case when milestone2_label is not null then decode(milestone2_complete_yn,''Y'',s.milestone2_label||'' - Completed'',decode(milestone2_complete_date,null,s.milestone2_label||'' - No Date'',s.milestone2_label||'' - ''||to_char(milestone2_complete_date,'
||'''DD-MON''))) end m2,',
'       case when milestone3_label is not null then decode(milestone3_complete_yn,''Y'',s.milestone3_label||'' - Completed'',decode(milestone3_complete_date,null,s.milestone3_label||'' - No Date'',s.milestone3_label||'' - ''||to_char(milestone3_complete_date,'
||'''DD-MON''))) end m3,',
'       case when milestone4_label is not null then decode(milestone4_complete_yn,''Y'',s.milestone4_label||'' - Completed'',decode(milestone4_complete_date,null,s.milestone4_label||'' - No Date'',s.milestone4_label||'' - ''||to_char(milestone4_complete_date,'
||'''DD-MON''))) end m4,',
'       --',
'       -- initiative and area',
'       --',
'       i.initiative,',
'       (select focus_area from sp_focus_areas a where a.id = i.focus_area_id) area,',
'       -- ',
'       -- size',
'       --',
'       p.PROJECT_SIZE,',
'       z.size_description,',
'       z.effort_days,',
'       round((100 - p.PCT_COMPLETE) * z.effort_days *.01) days_remaining,',
'       --',
'       -- quick look',
'       --',
'       null quick_look',
'from  SP_PROJECTS p,',
'      sp_project_scales s,',
'      sp_initiatives i,',
'       SP_PROJECT_SIZES z',
'where nvl(p.ARCHIVED_YN,''N'') = ''N'' and ',
'      p.DUPLICATE_OF_PROJECT_ID is null and',
'      p.status_scale = s.scale_letter and ',
'      p.initiative_id = i.id and',
'      p.PROJECT_SIZE = z.project_size'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P86_USER_ID'
,p_prn_page_header=>'Projects Interactive Report'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(10440756439335196299)
,p_name=>'Projects Interactive Report'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:RP,24:P24_ID:#PROJECT_ID#'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(141180225296450435141)
,p_owner=>'MIKE'
,p_internal_uid=>8583407391153691182
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440757014229196304)
,p_db_column_name=>'PROJECT_ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Project Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440757453572196308)
,p_db_column_name=>'OWNER_ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Owner Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440757943650196310)
,p_db_column_name=>'PROJECT'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'&NOMENCLATURE_PROJECT.'
,p_column_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:FI,PN:#FRIENDLY_IDENTIFIER#,#PROJECT_URL_NAME#'
,p_column_linktext=>'#PROJECT#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440758324380196312)
,p_db_column_name=>'THE_OWNER'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Owner'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440758654815196313)
,p_db_column_name=>'PRIORITY'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Priority'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440759054096196314)
,p_db_column_name=>'PCT_COMPLETE'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Comp'
,p_column_html_expression=>'#PCT_COMPLETE#%'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440759506440196315)
,p_db_column_name=>'PROJECT_SIZE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Size'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440759944722196316)
,p_db_column_name=>'FRIENDLY_IDENTIFIER'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Friendly Identifier'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440760329159196317)
,p_db_column_name=>'PROJECT_URL_NAME'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Project Url Name'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440760663069196320)
,p_db_column_name=>'UPDATED'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440761096958196321)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440761534700196322)
,p_db_column_name=>'LAST_COMMENT'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Last Comment'
,p_column_html_expression=>'#LAST_COMMENT# - #LAST_COMMENT_BY# - #LAST_COMMENT_ON#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440761856474196324)
,p_db_column_name=>'LAST_COMMENT_ON'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Last Comment Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440762389670196325)
,p_db_column_name=>'LAST_COMMENT_BY'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Last Comment By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440762914063196327)
,p_db_column_name=>'LAST_COMMENT_BY_OWNER'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Last Comment By Owner'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440763275718196329)
,p_db_column_name=>'LAST_COMMENT_BY_OWNER_ON'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Last Comment By Owner Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440764063222196333)
,p_db_column_name=>'CURRENT_ACTIVITY_COUNT'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Current Activity Count'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440764541404196335)
,p_db_column_name=>'INITIATIVE'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Initiative'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440764971798196337)
,p_db_column_name=>'RELEASE'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Release'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440765442560196338)
,p_db_column_name=>'M1'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'M1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440765819917196340)
,p_db_column_name=>'M2'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'M2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440766222591196341)
,p_db_column_name=>'M3'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'M3'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10440766589011196342)
,p_db_column_name=>'M4'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'M4'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10258829353351823134)
,p_db_column_name=>'AREA'
,p_display_order=>35
,p_column_identifier=>'Z'
,p_column_label=>'&NOMENCLATURE_AREA.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10258829510746823135)
,p_db_column_name=>'COMMENTS_28D'
,p_display_order=>45
,p_column_identifier=>'AA'
,p_column_label=>'Comments 28d'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10258829908224823139)
,p_db_column_name=>'CONTRIBUTORS'
,p_display_order=>55
,p_column_identifier=>'AB'
,p_column_label=>'Contributors'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10258829979026823140)
,p_db_column_name=>'REVIEWS'
,p_display_order=>65
,p_column_identifier=>'AC'
,p_column_label=>'Reviews'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10258830131486823141)
,p_db_column_name=>'COMPLETED_REVIEWS'
,p_display_order=>75
,p_column_identifier=>'AD'
,p_column_label=>'Reviews Completed'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10258830322416823143)
,p_db_column_name=>'CONTRIBUTOR_EMAILS'
,p_display_order=>85
,p_column_identifier=>'AF'
,p_column_label=>'Contributor Emails'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10258831219118823152)
,p_db_column_name=>'QUICK_LOOK'
,p_display_order=>95
,p_column_identifier=>'AG'
,p_column_label=>'Quick Look'
,p_column_link=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:RP,36:P36_ID:#PROJECT_ID#'
,p_column_linktext=>'<span class="fa fa-align-justify" aria-hidden="true"></span>'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10258831304279823153)
,p_db_column_name=>'TAGS'
,p_display_order=>105
,p_column_identifier=>'AH'
,p_column_label=>'Tags'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10258831796099823158)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>115
,p_column_identifier=>'AI'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10586224291085064818)
,p_db_column_name=>'FAVORITE'
,p_display_order=>125
,p_column_identifier=>'AJ'
,p_column_label=>'Favorite'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13973124777428898555)
,p_db_column_name=>'REQUIRES_REVIEWS'
,p_display_order=>135
,p_column_identifier=>'AL'
,p_column_label=>'Requires Reviews'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14206159680938321364)
,p_db_column_name=>'CREATED'
,p_display_order=>145
,p_column_identifier=>'AM'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14206159814119321365)
,p_db_column_name=>'EXTERNAL_TICKET_IDENTIFIER'
,p_display_order=>155
,p_column_identifier=>'AN'
,p_column_label=>'External Ticket Identifier'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14206159918462321366)
,p_db_column_name=>'EXTERNAL_SYSTEM_LINK'
,p_display_order=>165
,p_column_identifier=>'AO'
,p_column_label=>'External System Link'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14206159953565321367)
,p_db_column_name=>'SIZE_DESCRIPTION'
,p_display_order=>175
,p_column_identifier=>'AP'
,p_column_label=>'Size Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15288175135688389918)
,p_db_column_name=>'EFFORT_DAYS'
,p_display_order=>185
,p_column_identifier=>'AQ'
,p_column_label=>'Effort Days'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(15288175195387389919)
,p_db_column_name=>'DAYS_REMAINING'
,p_display_order=>195
,p_column_identifier=>'AR'
,p_column_label=>'Days Remaining'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(10440569411844553248)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'85832204'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'INITIATIVE:RELEASE:PROJECT:THE_OWNER:CONTRIBUTORS:PRIORITY:PCT_COMPLETE:PROJECT_SIZE:CURRENT_ACTIVITY_COUNT:LAST_COMMENT:FAVORITE:UPDATED:QUICK_LOOK:'
,p_sort_column_1=>'UPDATED'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(15288785526208289338)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'Milestones and Reviews'
,p_report_seq=>10
,p_report_alias=>'134314365'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'INITIATIVE:RELEASE:PROJECT:THE_OWNER:PRIORITY:PCT_COMPLETE:PROJECT_SIZE:M1:M2:M3:M4:REQUIRES_REVIEWS:REVIEWS:COMPLETED_REVIEWS:LAST_COMMENT:UPDATED:QUICK_LOOK'
,p_sort_column_1=>'UPDATED'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(15288814090413296725)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'Effort and Days Remaining'
,p_report_seq=>10
,p_report_alias=>'134314651'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'INITIATIVE:RELEASE:PROJECT:THE_OWNER:PRIORITY:PCT_COMPLETE:PROJECT_SIZE:EFFORT_DAYS:DAYS_REMAINING:LAST_COMMENT:UPDATED:QUICK_LOOK:'
,p_sort_column_1=>'UPDATED'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15059045822477833550)
,p_plug_name=>'Breadcrumb'
,p_region_sub_css_classes=>'has-header-actions'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141180108021956434943)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(141179926085158434823)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(141180198231173435047)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15923389177510848368)
,p_plug_name=>'Menubar'
,p_parent_plug_id=>wwv_flow_imp.id(15059045822477833550)
,p_region_sub_css_classes=>'header-actions'
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>'select 1 as actions from dual'
,p_template_component_type=>'PARTIAL'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_attributes=>wwv_flow_string.join_clob(wwv_flow_t_varchar2('{',
  '"APPLY_THEME_COLORS": "Y",',
  '"AVATAR_ICON": "fa-user",',
  '"AVATAR_SHAPE": "t-Avatar--rounded",',
  '"AVATAR_TYPE": "icon",',
  '"BADGE_COL_WIDTH": "t-ContentRow-badge--md",',
  '"BADGE_LABEL_DISPLAY": "N",',
  '"DISPLAY_AVATAR": "N",',
  '"DISPLAY_BADGE": "N",',
  '"HIDE_BORDERS": "N",',
  '"REMOVE_PADDING": "N"',
'}'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(15923390411016848380)
,p_name=>'ACTIONS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIONS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10444311551530711127)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(15059045822477833550)
,p_button_name=>'UP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141180195946138435041)
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:&LAST_PROJ_JUMP_PG.:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10258832627329823166)
,p_name=>'P86_USER_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10440756293429196299)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10258829769305823138)
,p_computation_sequence=>10
,p_computation_item=>'LAST_PROJECT_VIEW'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'86'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10258832714940823167)
,p_computation_sequence=>20
,p_computation_item=>'P86_USER_ID'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>'select id from sp_team_members where email = lower(:APP_USER)'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10258830621979823146)
,p_name=>'refresh on dc'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(15059045822477833550)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10258830738378823147)
,p_event_id=>wwv_flow_imp.id(10258830621979823146)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10440756293429196299)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10258832157711823162)
,p_name=>'refresh on dc from report'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(10440756293429196299)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10258832251292823163)
,p_event_id=>wwv_flow_imp.id(10258832157711823162)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10440756293429196299)
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(12066043325071525364)
,p_region_id=>wwv_flow_imp.id(15923389177510848368)
,p_position_id=>wwv_flow_imp.id(3709248475127512461)
,p_display_sequence=>10
,p_template_id=>wwv_flow_imp.id(3709249076804543590)
,p_label=>'Add &NOMENCLATURE_PROJECT.'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:104:&SESSION.::&DEBUG.:104,24::'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-plus'
,p_is_hot=>true
,p_show_as_disabled=>false
,p_authorization_scheme=>wwv_flow_imp.id(141180225296450435141)
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(15923389478089848371)
,p_region_id=>wwv_flow_imp.id(15923389177510848368)
,p_position_id=>wwv_flow_imp.id(3709248475127512461)
,p_display_sequence=>20
,p_template_id=>wwv_flow_imp.id(3709250336324547738)
,p_label=>'Actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(10258829746979823137)
,p_component_action_id=>wwv_flow_imp.id(15923389478089848371)
,p_menu_entry_type=>'ENTRY'
,p_label=>'My &NOMENCLATURE_PROJECTS.'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-package'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(11781284497301888436)
,p_component_action_id=>wwv_flow_imp.id(15923389478089848371)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Reset'
,p_display_sequence=>140
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:86:&SESSION.::&DEBUG.:RP,CIR,RIR,86::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(11781284665918888437)
,p_component_action_id=>wwv_flow_imp.id(15923389478089848371)
,p_menu_entry_type=>'SEPARATOR'
,p_display_sequence=>60
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(11781288106308888472)
,p_component_action_id=>wwv_flow_imp.id(15923389478089848371)
,p_menu_entry_type=>'ENTRY'
,p_label=>'About &NOMENCLATURE_PROJECTS.'
,p_display_sequence=>120
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:107:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-info'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(11850294593350504948)
,p_component_action_id=>wwv_flow_imp.id(15923389478089848371)
,p_menu_entry_type=>'ENTRY'
,p_label=>'&NOMENCLATURE_PROJECTS. Primary Report'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-package'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(12536580301495601157)
,p_component_action_id=>wwv_flow_imp.id(15923389478089848371)
,p_menu_entry_type=>'ENTRY'
,p_label=>'My Activity'
,p_display_sequence=>70
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-badge-check'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(12536580386319601158)
,p_component_action_id=>wwv_flow_imp.id(15923389478089848371)
,p_menu_entry_type=>'SEPARATOR'
,p_display_sequence=>110
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(12536580555338601159)
,p_component_action_id=>wwv_flow_imp.id(15923389478089848371)
,p_menu_entry_type=>'SEPARATOR'
,p_display_sequence=>80
,p_build_option_id=>wwv_flow_imp.id(6201759808817603711)
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(13145646102922141273)
,p_component_action_id=>wwv_flow_imp.id(15923389478089848371)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Releases'
,p_display_sequence=>90
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-ship'
,p_build_option_id=>wwv_flow_imp.id(6201759808817603711)
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(15923390183996848378)
,p_component_action_id=>wwv_flow_imp.id(15923389478089848371)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Refresh'
,p_display_sequence=>130
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:86:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp.component_end;
end;
/
