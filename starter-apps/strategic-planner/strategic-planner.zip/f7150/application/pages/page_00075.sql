prompt --application/pages/page_00075
begin
--   Manifest
--     PAGE: 00075
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>26954343551793662
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>75
,p_name=>'Current Activity'
,p_alias=>'CURRENT-ACTIVITY'
,p_step_title=>'Current Activity'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(4778314598698756343)
,p_name=>'Current Activity'
,p_template=>wwv_flow_imp.id(141215438656052368935)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'       tm.first_name||'' ''||tm.last_name person,',
'       tm.id team_member_id,',
'       count(distinct p.id) projects,',
'       --count(distinct decode(p.RELEASE_DEPENDENT_YN,''N'',null,p.release_id)) releases,',
'       sum(decode(instr(p.tags,''-COMMITTED''),0,0,1)) tagged_committed,',
'       sum(decode(instr(p.tags,''-TARGETED''),0,0,1)) tagged_tareted,',
'       sum(decode(instr(p.tags,''-QUICK-WIN''),0,0,1)) tagged_quick_win,',
'       sum(decode(instr(p.tags,''-BACKLOG''),0,0,1)) tagged_backlog,',
'       sum(decode(instr(p.tags,''-CANDIDATE''),0,0,1)) tagged_candidate,',
'       --',
'       -- priorities',
'       --',
'       sum(decode(pp.PRIORITY,1,1,0)) p1,',
'       sum(decode(pp.PRIORITY,2,1,0)) p2,',
'       sum(decode(pp.PRIORITY,3,1,0)) p3,',
'       sum(decode(pp.PRIORITY,4,1,0)) p4,',
'       sum(decode(pp.PRIORITY,5,1,0)) p5,',
'       --',
'       -- percent complete',
'       --',
'       sum(decode(p.PCT_COMPLETE,10,1,0)) s10_pct,',
'       sum(decode(p.PCT_COMPLETE,20,1,0)) s20_pct,',
'       sum(decode(p.PCT_COMPLETE,30,1,0)) s30_pct,',
'       sum(decode(p.PCT_COMPLETE,40,1,0)) s40_pct,',
'       sum(decode(p.PCT_COMPLETE,50,1,0)) s50_pct,',
'       sum(decode(p.PCT_COMPLETE,60,1,0)) s60_pct,',
'       sum(decode(p.PCT_COMPLETE,70,1,0)) s70_pct,',
'       sum(decode(p.PCT_COMPLETE,80,1,0)) s80_pct,',
'       sum(decode(p.PCT_COMPLETE,90,1,0)) s90_pct,',
'       sum(decode(p.PCT_COMPLETE,100,1,0)) s100_pct,',
'       --',
'       --',
'       --',
'       LISTAGG(DISTINCT (select release_train||'' ''||release ',
'                         from SP_RELEASE_TRAINS rt',
'                         where rt.id = p.release_id), '', '' ',
'            ON OVERFLOW TRUNCATE WITH COUNT) WITHIN GROUP ',
'            (ORDER BY (select release_train||'' ''||release ',
'                         from SP_RELEASE_TRAINS rt',
'                         where rt.id = p.release_id)) releases',
'from sp_activities ap,',
'     sp_projects p,',
'     sp_activity_types at,',
'     sp_team_members tm,',
'     SP_PROJECT_PRIORITIES pp',
'where ap.project_id = p.id and',
'      p.priority_id = pp.id and',
'      ap.activity_type_id = at.id and',
'      ap.team_member_id = tm.id and',
'      p.DUPLICATE_OF_PROJECT_ID is null and',
'      p.ARCHIVED_YN = ''N'' and',
'      trunc(sysdate) between ap.start_date and ap.end_date and',
'      (:P75_RELEASE = 0 or p.release_id = :P75_RELEASE)',
'group by tm.first_name, tm.last_name, tm.id'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P75_RELEASE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141215498180253368990)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_report_total_text_format=>'&nbsp;'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778315004979756348)
,p_query_column_id=>1
,p_column_alias=>'PERSON'
,p_column_display_sequence=>1
,p_column_heading=>'Person'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:73:&SESSION.::&DEBUG.:RP,73:P73_TEAM_MEMBER_ID:#TEAM_MEMBER_ID#'
,p_column_linktext=>'#PERSON#'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778315354821756349)
,p_query_column_id=>2
,p_column_alias=>'TEAM_MEMBER_ID'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778315736278756350)
,p_query_column_id=>3
,p_column_alias=>'PROJECTS'
,p_column_display_sequence=>3
,p_column_heading=>'Projects'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778409389820783425)
,p_query_column_id=>4
,p_column_alias=>'TAGGED_COMMITTED'
,p_column_display_sequence=>23
,p_column_heading=>'Tagged Committed'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778409474426783426)
,p_query_column_id=>5
,p_column_alias=>'TAGGED_TARETED'
,p_column_display_sequence=>33
,p_column_heading=>'Tagged Tareted'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778409610059783427)
,p_query_column_id=>6
,p_column_alias=>'TAGGED_QUICK_WIN'
,p_column_display_sequence=>43
,p_column_heading=>'Tagged Quick Win'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778409689286783428)
,p_query_column_id=>7
,p_column_alias=>'TAGGED_BACKLOG'
,p_column_display_sequence=>53
,p_column_heading=>'Tagged Backlog'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778409730567783429)
,p_query_column_id=>8
,p_column_alias=>'TAGGED_CANDIDATE'
,p_column_display_sequence=>63
,p_column_heading=>'Tagged Candidate'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778410394563783435)
,p_query_column_id=>9
,p_column_alias=>'P1'
,p_column_display_sequence=>73
,p_column_heading=>'P1'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778410467681783436)
,p_query_column_id=>10
,p_column_alias=>'P2'
,p_column_display_sequence=>83
,p_column_heading=>'P2'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778410535385783437)
,p_query_column_id=>11
,p_column_alias=>'P3'
,p_column_display_sequence=>93
,p_column_heading=>'P3'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778410659645783438)
,p_query_column_id=>12
,p_column_alias=>'P4'
,p_column_display_sequence=>103
,p_column_heading=>'P4'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778410741326783439)
,p_query_column_id=>13
,p_column_alias=>'P5'
,p_column_display_sequence=>113
,p_column_heading=>'P5'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778410874763783440)
,p_query_column_id=>14
,p_column_alias=>'S10_PCT'
,p_column_display_sequence=>123
,p_column_heading=>'10%'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778410992058783441)
,p_query_column_id=>15
,p_column_alias=>'S20_PCT'
,p_column_display_sequence=>133
,p_column_heading=>'20%'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778411068767783442)
,p_query_column_id=>16
,p_column_alias=>'S30_PCT'
,p_column_display_sequence=>143
,p_column_heading=>'30%'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778411171879783443)
,p_query_column_id=>17
,p_column_alias=>'S40_PCT'
,p_column_display_sequence=>153
,p_column_heading=>'40%'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778411305851783444)
,p_query_column_id=>18
,p_column_alias=>'S50_PCT'
,p_column_display_sequence=>163
,p_column_heading=>'50%'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778411401639783445)
,p_query_column_id=>19
,p_column_alias=>'S60_PCT'
,p_column_display_sequence=>164
,p_column_heading=>'60%'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778411478037783446)
,p_query_column_id=>20
,p_column_alias=>'S70_PCT'
,p_column_display_sequence=>183
,p_column_heading=>'70%'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778411573209783447)
,p_query_column_id=>21
,p_column_alias=>'S80_PCT'
,p_column_display_sequence=>193
,p_column_heading=>'80%'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778411613271783448)
,p_query_column_id=>22
,p_column_alias=>'S90_PCT'
,p_column_display_sequence=>203
,p_column_heading=>'90%'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778411737526783449)
,p_query_column_id=>23
,p_column_alias=>'S100_PCT'
,p_column_display_sequence=>213
,p_column_heading=>'100%'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4778409232668783424)
,p_query_column_id=>24
,p_column_alias=>'RELEASES'
,p_column_display_sequence=>13
,p_column_heading=>'Releases'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4778409817282783430)
,p_plug_name=>'Filter'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215306085609368903)
,p_plug_display_sequence=>2
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9424355101797469568)
,p_plug_name=>'Breadcrumb'
,p_region_sub_css_classes=>'has-header-actions'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215451086209368948)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(141215269149411368828)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(141215541295426369052)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10288698456830484386)
,p_plug_name=>'Menubar'
,p_parent_plug_id=>wwv_flow_imp.id(9424355101797469568)
,p_region_sub_css_classes=>'header-actions'
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>'select 1 as actions from dual'
,p_template_component_type=>'PARTIAL'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'AVATAR_ICON', 'fa-user',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_TYPE', 'icon',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--md',
  'BADGE_LABEL_DISPLAY', 'N',
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(10288699690336484398)
,p_name=>'ACTIONS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIONS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4778494119248412782)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9424355101797469568)
,p_button_name=>'UP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141215539010391369046)
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4778409950742783431)
,p_name=>'P75_RELEASE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4778409817282783430)
,p_item_default=>'0'
,p_prompt=>'Release'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select release_train||'' ''||release release_train, id ',
'from SP_RELEASE_TRAINS',
'where id in (',
'    select distinct release_id ',
'    from sp_projects p, sp_activities ap',
'    where ap.project_id = p.id and',
'          p.ARCHIVED_YN = ''N'' and',
'          p.DUPLICATE_OF_PROJECT_ID is null and',
'          p.RELEASE_DEPENDENT_YN = ''Y''',
')'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All Releases -'
,p_lov_null_value=>'0'
,p_field_template=>wwv_flow_imp.id(141215537113464369041)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'8'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4778410042468783432)
,p_name=>'release change'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P75_RELEASE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4778410177629783433)
,p_event_id=>wwv_flow_imp.id(4778410042468783432)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P75_RELEASE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4778410293770783434)
,p_event_id=>wwv_flow_imp.id(4778410042468783432)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(4778314598698756343)
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(10288698757409484389)
,p_region_id=>wwv_flow_imp.id(10288698456830484386)
,p_position_id=>wwv_flow_imp.id(3744591539380446466)
,p_display_sequence=>10
,p_template_id=>wwv_flow_imp.id(3744593400577481743)
,p_label=>'Actions'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(4774585808798056872)
,p_component_action_id=>wwv_flow_imp.id(10288698757409484389)
,p_menu_entry_type=>'ENTRY'
,p_label=>'&NOMENCLATURE_PROJECTS.'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-package'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(7520019486436581655)
,p_component_action_id=>wwv_flow_imp.id(10288698757409484389)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Reset'
,p_display_sequence=>40
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:75:&SESSION.::&DEBUG.:RP,75::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(10288699463316484396)
,p_component_action_id=>wwv_flow_imp.id(10288698757409484389)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Refresh'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:75:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(16218808235187338478)
,p_component_action_id=>wwv_flow_imp.id(10288698757409484389)
,p_menu_entry_type=>'SEPARATOR'
,p_display_sequence=>20
);
wwv_flow_imp.component_end;
end;
/
