prompt --application/pages/page_00201
begin
--   Manifest
--     PAGE: 00201
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>19055477148803894
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>201
,p_name=>'Release Calendar'
,p_alias=>'RELEASE-CALENDAR'
,p_step_title=>'Release Calendar'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(6256158350219341610)
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28099301066861121402)
,p_plug_name=>'Calendar'
,p_region_name=>'calendar'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id, ',
'       --',
'       -- attributes',
'       --',
'       owner,',
'       "DATE" the_date,',
'       milestone,',
'       milestone||'': ''||event display_value,',
'       event,',
'       event_detail,',
'       case when priority_id is not null then ''P''||to_char(priority_id) end priority,',
'       --',
'       -- badge state',
'       --',
'       case when is_completed = ''Completed'' then ''apex-cal-green''',
'            when trunc("DATE") < trunc(sysdate) then ''apex-cal-red''',
'            else ''apex-cal-yellow''',
'       end as event_color,',
'       --',
'       -- is completed, past due or open',
'       --',
'       case when "DATE" is null then ''Missing''',
'            when is_completed = ''Completed'' then ''Completed''',
'            when trunc("DATE") < trunc(sysdate) then ''Past Due''',
'            else ''Open''',
'       end as is_completed,',
'       --',
'       -- badge icon',
'       --',
'       case when is_completed = ''Completed'' then ''fa-check''',
'            when trunc("DATE") < trunc(sysdate) then ''fa-exclamation-triangle-o''',
'            else ''fa-play''',
'       end as badge_icon,',
'       --',
'       -- icon',
'       --',
'       case milestone ',
'            when ''Spec Complete'' then ''fa-file-text-o''',
'            when ''Demonstrable'' then ''fa-window-play''',
'            when ''Code Complete'' then ''fa-file-check''',
'            when ''Merged'' then ''fa-code-fork''',
'       end as icon,',
'       --',
'       -- link info',
'       --',
'       case when link_type = ''P'' then apex_page.get_url(p_page   => 3,',
'                                                        p_items  => ''FI,PN'',',
'                                                        p_values => fi||'',''||pn,',
'                                                        p_clear_cache => 3)',
'            when link_type = ''R'' then apex_page.get_url(p_page   => 117,',
'                                                        p_items  => ''P117_RELEASE_ID'',',
'                                                        p_values => ID,',
'                                                        p_clear_cache => 117)',
'            end link,',
'       fi,',
'       pn',
'from (',
'--',
'-- milestones',
'--',
'select ''P'' link_type,',
'       p.id as "ID",',
'       tm.first_name||'' ''||tm.last_Name                                   as owner,',
'       milestone1_complete_date                                           as "DATE",',
'       to_char(p.milestone1_complete_date,''YYYY.MM'')                      as "MONTH",',
'       s.milestone1_label                                                 as milestone,',
'       p.project                                                          as event,',
'       tm.first_name||'' ''||tm.last_Name||'', P''||p.priority_id||'', ''||p.PROJECT_SIZE  as event_detail,',
'       decode(p.milestone1_complete_yn,''N'',''Open'',''Y'',''Completed'',''Unknown'')    as is_completed,',
'       p.FRIENDLY_IDENTIFIER fi,',
'       p.PROJECT_URL_NAME pn,',
'       p.priority_id',
'  from sp_projects p,',
'       SP_TEAM_MEMBERS tm,',
'       sp_project_scales s',
'  where p.OWNER_ID = tm.id and',
'        p.milestone1_complete_date is not null and',
'        p.RELEASE_ID = :P201_RELEASE_ID and',
'        p.ARCHIVED_YN = ''N'' and ',
'        p.RELEASE_DEPENDENT_YN = ''Y'' and',
'        p.status_scale = s.scale_letter and',
'        s.milestone1_label is not null',
'union all',
'select ''P'' link_type,',
'       p.id as "ID",',
'       tm.first_name||'' ''||tm.last_Name                                   as owner,',
'       milestone2_complete_date                                           as "DATE",',
'       to_char(p.milestone2_complete_date,''YYYY.MM'')                      as "MONTH",',
'       s.milestone2_label                                                 as milestone,',
'       p.project                                                          as event,',
'       tm.first_name||'' ''||tm.last_Name||'', P''||p.priority_id||'', ''||p.PROJECT_SIZE  as event_detail,',
'       decode(p.milestone2_complete_yn,''N'',''Open'',''Y'',''Completed'',''Unknown'')    as is_completed,',
'       p.FRIENDLY_IDENTIFIER fi,',
'       p.PROJECT_URL_NAME pn,',
'       p.priority_id',
'  from sp_projects p,',
'       SP_TEAM_MEMBERS tm,',
'       sp_project_scales s',
'  where p.OWNER_ID = tm.id and',
'        p.milestone2_complete_date is not null and',
'        p.RELEASE_ID = :P201_RELEASE_ID and',
'        p.ARCHIVED_YN = ''N'' and ',
'        p.RELEASE_DEPENDENT_YN = ''Y'' and',
'        p.status_scale = s.scale_letter and',
'        s.milestone2_label is not null',
'union all',
'select ''P'' link_type,',
'       p.id as "ID",',
'       tm.first_name||'' ''||tm.last_Name                                   as owner,',
'       milestone3_complete_date                                           as "DATE",',
'       to_char(p.milestone3_complete_date,''YYYY.MM'')                      as "MONTH",',
'       s.milestone3_label                                                 as milestone,',
'       p.project                                                          as event,',
'       tm.first_name||'' ''||tm.last_Name||'', P''||p.priority_id||'', ''||p.PROJECT_SIZE  as event_detail,',
'       decode(p.milestone3_complete_yn,''N'',''Open'',''Y'',''Completed'',''Unknown'')    as is_completed,',
'       p.FRIENDLY_IDENTIFIER fi,',
'       p.PROJECT_URL_NAME pn,',
'       p.priority_id',
'  from sp_projects p,',
'       SP_TEAM_MEMBERS tm,',
'       sp_project_scales s',
'  where p.OWNER_ID = tm.id and',
'        p.milestone3_complete_date is not null and',
'        p.RELEASE_ID = :P201_RELEASE_ID and',
'        p.ARCHIVED_YN = ''N'' and ',
'        p.RELEASE_DEPENDENT_YN = ''Y'' and',
'        p.status_scale = s.scale_letter and',
'        s.milestone3_label is not null',
'union all',
'select ''P'' link_type,',
'       p.id as "ID",',
'       tm.first_name||'' ''||tm.last_Name                                   as owner,',
'       milestone4_complete_date                                           as "DATE",',
'       to_char(p.milestone4_complete_date,''YYYY.MM'')                      as "MONTH",',
'       s.milestone4_label                                                 as milestone,',
'       p.project                                                          as event,',
'       tm.first_name||'' ''||tm.last_Name||'', P''||p.priority_id||'', ''||p.PROJECT_SIZE  as event_detail,',
'       decode(p.milestone4_complete_yn,''N'',''Open'',''Y'',''Completed'',''Unknown'')    as is_completed,',
'       p.FRIENDLY_IDENTIFIER fi,',
'       p.PROJECT_URL_NAME pn,',
'       p.priority_id',
'  from sp_projects p,',
'       SP_TEAM_MEMBERS tm,',
'       sp_project_scales s',
'  where p.OWNER_ID = tm.id and',
'        p.milestone4_complete_date is not null and',
'        p.RELEASE_ID = :P201_RELEASE_ID and',
'        p.ARCHIVED_YN = ''N'' and ',
'        p.RELEASE_DEPENDENT_YN = ''Y'' and',
'        p.status_scale = s.scale_letter and',
'        s.milestone4_label is not null',
'union all',
'select ''R'' link_type,',
'       RELEASE_ID as "ID",',
'       ''Release Milestone''                                   as owner,',
'       milestone_date                                           as "DATE",',
'       to_char(milestone_date,''YYYY.MM'')                      as "MONTH",',
'       milestone_name                                                 as milestone,',
'       null                                                          as event,',
'       milestone_description  as event_detail,',
'       decode(milestone_completed_yn,''Y'',''Completed'',''Open'')    as is_completed,',
'       null fi,',
'       null pn,',
'       null priority_id',
'  from sp_release_milestones m',
'  where RELEASE_ID = :P201_RELEASE_ID      ',
') x'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_ajax_items_to_submit=>'P201_RELEASE_ID'
,p_plug_footer=>'<small><span style="background-color:#2ecc71;">Green</span> = Completed, <span style="background-color:#d91e18;">Red</span> = Past Due, <span style="background-color:#f1c40f;">Yellow</span> = Future</small>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'additional_calendar_views', 'list:navigation',
  'css_class', 'EVENT_COLOR',
  'display_column', 'DISPLAY_VALUE',
  'drag_and_drop', 'N',
  'end_date_column', 'THE_DATE',
  'event_sorting', 'AUTOMATIC',
  'maximum_events_day', '10',
  'multiple_line_event', 'Y',
  'primary_key_column', 'ID',
  'show_time', 'N',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'THE_DATE',
  'supplemental_information', wwv_flow_string.join(wwv_flow_t_varchar2(
    '&OWNER. &PRIORITY.<br/>',
    '&IS_COMPLETED.')),
  'view_edit_link', '&LINK.')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(47823903277167211246)
,p_plug_name=>'Breadcrumb'
,p_region_sub_css_classes=>'has-header-actions'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(141234324626560172722)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(51898056912796423180)
,p_plug_name=>'Menubar'
,p_parent_plug_id=>wwv_flow_imp.id(47823903277167211246)
,p_region_sub_css_classes=>'header-actions'
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>'select 1 as actions from dual'
,p_template_component_type=>'PARTIAL'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'AVATAR_ICON', 'fa-user',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_TYPE', 'icon',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--md',
  'BADGE_LABEL_DISPLAY', 'N',
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(51898058146302423192)
,p_name=>'ACTIONS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIONS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(68072870009130257036)
,p_name=>'Release'
,p_template=>4072358936313175081
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:t-Region--scrollBody:t-Region-orderBy--end:margin-left-md'
,p_component_template_options=>'#DEFAULT#:t-ContextualInfo-label--stacked'
,p_display_point=>'REGION_POSITION_01'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.ID,',
'       r.RELEASE_TRAIN||'' ''||r.RELEASE release,',
'       decode(r.RELEASE_TARGET_DATE,null,    ''No Date'',to_char(r.RELEASE_TARGET_DATE,   ''DD-MON-YY'')) RELEASE_TARGET_DATE,',
'       decode(r.RELEASE_OPEN_DATE,null,      ''No Date'',to_char(r.RELEASE_OPEN_DATE,     ''DD-MON-YY'')) RELEASE_OPEN_DATE,',
'       greatest(round(r.RELEASE_TARGET_DATE - sysdate),0) days_remaining,',
'       --',
'       -- projects',
'       --',
'       (select count(*) ',
'       from sp_projects p ',
'       where p.release_id = r.id and ',
'             p.ARCHIVED_YN = ''N'' and ',
'             p.RELEASE_DEPENDENT_YN = ''Y'' and ',
'             p.DUPLICATE_OF_PROJECT_ID is null) projects,',
'       --',
'       --',
'       --',
'       round(r.RELEASE_TARGET_DATE - r.RELEASE_OPEN_DATE) release_length,',
'       -- ',
'       -- team members',
'       --',
'       (select count(distinct TEAM_MEMBER_ID) ',
'       from SP_PROJECT_CONTRIBUTORS c ',
'       where c.PROJECT_ID in (',
'           select id ',
'           from sp_projects p ',
'           where p.release_id = r.id and ',
'                 p.ARCHIVED_YN = ''N'' and ',
'                 p.RELEASE_DEPENDENT_YN = ''Y'' and ',
'                 p.DUPLICATE_OF_PROJECT_ID is null)) contributors,',
'       --',
'       -- owner',
'       --',
'       t.first_name||'' ''||t.last_name owner,',
'       --',
'       -- reviewers',
'       --',
'       (select count(distinct OWNER_ID) from SP_PROJECT_REVIEWS pr where pr.PROJECT_ID in (',
'           select id ',
'           from sp_projects p ',
'           where p.release_id = r.id and ',
'                 ARCHIVED_YN = ''N'' and ',
'                 p.RELEASE_DEPENDENT_YN = ''Y'' and ',
'                 p.DUPLICATE_OF_PROJECT_ID is null)) reviewers,',
'       --',
'       -- milestones',
'       --',
'       (select count(*) from SP_RELEASE_MILESTONES m where m.release_id = r.id) milestones,',
'       (select count(*) from sp_release_comments rc where rc.release_id = r.id) comments,',
'       --',
'       -- release open and close',
'       --',
'       decode(r.RELEASE_OPEN_COMPLETED,''Y'',''Yes'',''N'',''No'',''Unknown'') release_opened,',
'       decode(r.RELEASE_COMPLETED,''Y'',''Yes'',''N'',''No'',''Unknown'') release_completed',
'  from SP_RELEASE_TRAINS r,',
'       SP_TEAM_MEMBERS t',
' where r.id = :P201_RELEASE_ID and ',
'       r.RELEASE_OWNER_ID = t.id(+)'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P201_RELEASE_ID'
,p_lazy_loading=>false
,p_query_row_template=>2115772683903439354
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16375413663450063009)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16375414049240063009)
,p_query_column_id=>2
,p_column_alias=>'RELEASE'
,p_column_display_sequence=>40
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16375411289450063007)
,p_query_column_id=>3
,p_column_alias=>'RELEASE_TARGET_DATE'
,p_column_display_sequence=>70
,p_column_heading=>'Target Complete'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16375411991310063007)
,p_query_column_id=>4
,p_column_alias=>'RELEASE_OPEN_DATE'
,p_column_display_sequence=>60
,p_column_heading=>'Open'
,p_column_format=>'DD-MON-YY'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16375414484649063010)
,p_query_column_id=>5
,p_column_alias=>'DAYS_REMAINING'
,p_column_display_sequence=>90
,p_column_heading=>'Remaining'
,p_column_format=>'99999'
,p_column_html_expression=>'#DAYS_REMAINING# days'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16375412481265063008)
,p_query_column_id=>6
,p_column_alias=>'PROJECTS'
,p_column_display_sequence=>100
,p_column_heading=>'&NOMENCLATURE_PROJECTS.'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16375412797589063008)
,p_query_column_id=>7
,p_column_alias=>'RELEASE_LENGTH'
,p_column_display_sequence=>80
,p_column_heading=>'Length'
,p_column_html_expression=>'#RELEASE_LENGTH# days'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16375413247628063009)
,p_query_column_id=>8
,p_column_alias=>'CONTRIBUTORS'
,p_column_display_sequence=>130
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16375414835562063010)
,p_query_column_id=>9
,p_column_alias=>'OWNER'
,p_column_display_sequence=>150
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16375411618343063007)
,p_query_column_id=>10
,p_column_alias=>'REVIEWERS'
,p_column_display_sequence=>140
,p_column_heading=>'Reviewers'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16375415201816063010)
,p_query_column_id=>11
,p_column_alias=>'MILESTONES'
,p_column_display_sequence=>110
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16375410800757063006)
,p_query_column_id=>12
,p_column_alias=>'COMMENTS'
,p_column_display_sequence=>120
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16375415606957063011)
,p_query_column_id=>13
,p_column_alias=>'RELEASE_OPENED'
,p_column_display_sequence=>180
,p_column_heading=>'Release Opened'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16375410425470063006)
,p_query_column_id=>14
,p_column_alias=>'RELEASE_COMPLETED'
,p_column_display_sequence=>170
,p_column_heading=>'Release Completed'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16375388593479056582)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(47823903277167211246)
,p_button_name=>'UP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29858068010862461742)
,p_name=>'P201_RELEASE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(68072870009130257036)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30836951974057600399)
,p_name=>'P201_RELEASE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(68072870009130257036)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(16377248845534092727)
,p_computation_sequence=>30
,p_computation_item=>'P201_RELEASE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>'select release_train||'' ''||release d from sp_release_trains where id = :P201_RELEASE_ID'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(51898057213375423183)
,p_region_id=>wwv_flow_imp.id(51898056912796423180)
,p_position_id=>362316004162771045
,p_display_sequence=>20
,p_template_id=>362317865359806322
,p_label=>'Actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(15394399793371641750)
,p_component_action_id=>wwv_flow_imp.id(51898057213375423183)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Release Dashboard'
,p_display_sequence=>40
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.:RP,202:P202_RELEASE_ID:&P201_RELEASE_ID.'
,p_icon_css_classes=>'fa-area-chart'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(15394399903976641751)
,p_component_action_id=>wwv_flow_imp.id(51898057213375423183)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Release History'
,p_display_sequence=>50
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:RP,200:P200_RELEASE_ID:&P201_RELEASE_ID.'
,p_icon_css_classes=>'fa-clock-o'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(15394401042854641762)
,p_component_action_id=>wwv_flow_imp.id(51898057213375423183)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Release Home'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.:RP,:P117_RELEASE_ID:&P201_RELEASE_ID.'
,p_icon_css_classes=>'fa-ship'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(15394401141705641763)
,p_component_action_id=>wwv_flow_imp.id(51898057213375423183)
,p_menu_entry_type=>'SEPARATOR'
,p_display_sequence=>70
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(37916263035342487333)
,p_component_action_id=>wwv_flow_imp.id(51898057213375423183)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Faceted Search'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:RP,300:P300_RELEASE_ID:&P201_RELEASE_ID.'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(51898057293035423184)
,p_component_action_id=>wwv_flow_imp.id(51898057213375423183)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Refresh'
,p_display_sequence=>80
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(51898057919282423190)
,p_component_action_id=>wwv_flow_imp.id(51898057213375423183)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Reset'
,p_display_sequence=>90
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.:RR,201:P201_RELEASE_ID:&P201_RELEASE_ID.'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(51898058063301423191)
,p_component_action_id=>wwv_flow_imp.id(51898057213375423183)
,p_menu_entry_type=>'SEPARATOR'
,p_display_sequence=>20
);
wwv_flow_imp.component_end;
end;
/
