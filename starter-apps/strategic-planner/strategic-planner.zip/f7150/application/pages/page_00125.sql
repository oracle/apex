prompt --application/pages/page_00125
begin
--   Manifest
--     PAGE: 00125
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>19055477148803894
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>125
,p_name=>'Choose Association'
,p_alias=>'CHOOSE-ASSOCIATION'
,p_page_mode=>'MODAL'
,p_step_title=>'&P125_USER_NAME.'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10079037280867973040)
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3628039691604416720)
,p_plug_name=>'Association'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5306472147419415796)
,p_plug_name=>'Header'
,p_region_template_options=>'#DEFAULT#:margin-top-md:margin-bottom-md'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>10
,p_plug_source=>'<strong>&NOMENCLATURE_PROJECT.</strong>: &P125_PROJECT.<br>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5307995511249224461)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3628039617759416719)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5307995511249224461)
,p_button_name=>'previous'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Previous'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:111:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3628034748088414516)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(5307995511249224461)
,p_button_name=>'cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3628040366765416726)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5307995511249224461)
,p_button_name=>'view_project'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'View &NOMENCLATURE_PROJECT.'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:FI,PN:&P125_FI.,&P125_PN.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3628040226496416725)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(5307995511249224461)
,p_button_name=>'Add_Association'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Association'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(3628041487411416737)
,p_branch_name=>'Go To Page 129'
,p_branch_action=>'f?p=&APP_ID.:119:&SESSION.::&DEBUG.:119:P119_PROJECT_ID,P119_USER_ID:&P125_PROJECT_ID.,&P125_USER_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3591707952908052956)
,p_name=>'P125_PROJECT_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(5306472147419415796)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3591708266020052959)
,p_name=>'P125_PROJECT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(5306472147419415796)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3628040152824416724)
,p_name=>'P125_SET_AS_OWNER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(3628039691604416720)
,p_prompt=>'Set As Owner'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_display_when=>'P125_PROJ_OWNER_ID'
,p_display_when_type=>'ITEM_IS_NULL'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3628040476964416727)
,p_name=>'P125_CONTRIBUTOR_DISP_ONLY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3628039691604416720)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select RESPONSIBILITY',
'from SP_PROJECT_CONTRIBUTORS',
'where PROJECT_ID = :P125_PROJECT_ID and',
'      TEAM_MEMBER_ID = :P125_USER_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'&P125_USER_NAME. Contribution'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P125_CONTRIBUTION'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3628040538804416728)
,p_name=>'P125_REVIEWER_DISPLAY_ONLY'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(3628039691604416720)
,p_prompt=>'&P125_USER_NAME. Review'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P125_RESOURCE_TYPE_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3628040684367416729)
,p_name=>'P125_FI'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(5306472147419415796)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3628040782721416730)
,p_name=>'P125_PN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(5306472147419415796)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3628040938742416732)
,p_name=>'P125_PROJ_OWNER_ID'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(5306472147419415796)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3628041079060416733)
,p_name=>'P125_CONTRIBUTION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(5306472147419415796)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3628041265624416735)
,p_name=>'P125_OWNER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(3628039691604416720)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select first_name||'' ''||last_name n',
'from sp_projects p,',
'     sp_team_members t',
'where p.id = :P125_PROJECT_ID and',
'      p.owner_id = t.id'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Owner'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P125_PROJ_OWNER_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3628042293283416746)
,p_name=>'P125_STATUS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(5306472147419415796)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3628231842969790736)
,p_name=>'P125_REVIEW_TYPE_ID'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(3628039691604416720)
,p_prompt=>'Review Type'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select review_type, id',
'from sp_project_review_types',
'order by display_seq'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Add -'
,p_cHeight=>1
,p_grid_row_css_classes=>'u-align-items-center'
,p_display_when=>'P125_REVIEW_TYPE_ID'
,p_display_when_type=>'ITEM_IS_NULL'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_restricted_characters=>'US_ONLY'
,p_security_scheme=>wwv_flow_imp.id(141234623837852173040)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3628288842575429626)
,p_name=>'P125_RESOURCE_TYPE_ID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(3628039691604416720)
,p_prompt=>'Contribution Type'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select RESOURCE_TYPE, id',
'from SP_RESOURCE_TYPES',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Add -'
,p_cHeight=>1
,p_display_when=>'P125_CONTRIBUTION'
,p_display_when_type=>'ITEM_IS_NULL'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_restricted_characters=>'US_ONLY'
,p_security_scheme=>wwv_flow_imp.id(141234623837852173040)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5306472555771415801)
,p_name=>'P125_USER_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(5306472147419415796)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5306472732397415802)
,p_name=>'P125_USER_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(5306472147419415796)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(3626717399182273703)
,p_computation_sequence=>20
,p_computation_item=>'P125_USER_NAME'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select decode(first_name,null,email,first_name||'' ''||last_name) un ',
'from sp_team_members ',
'where id = :P125_USER_ID'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3628039441992416717)
,p_name=>'close'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(3628034748088414516)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3628039509513416718)
,p_event_id=>wwv_flow_imp.id(3628039441992416717)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3628041319338416736)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Add associations'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P125_RESOURCE_TYPE_ID is not null and :P125_PROJECT_ID is not null and :P125_USER_ID is not null then',
'   insert into SP_PROJECT_CONTRIBUTORS (',
'      PROJECT_ID,',
'      TEAM_MEMBER_ID,',
'      RESPONSIBILITY_ID',
'   ) values (',
'      :P125_PROJECT_ID,',
'      :P125_USER_ID,',
'      :P125_RESOURCE_TYPE_ID',
'   );',
'   :P125_STATUS := ''Contribution Added; '';',
'end if;',
'',
'if :P125_REVIEW_TYPE_ID is not null and :P125_PROJECT_ID is not null and  :P125_USER_ID is not null then',
'    for c1 in (select count(*) c from SP_PROJECT_REVIEWS where project_id =  :P125_PROJECT_ID and OWNER_ID = :P125_USER_ID) loop',
'       if c1.c = 0 then ',
'            insert into SP_PROJECT_REVIEWS (',
'                PROJECT_ID,',
'                REVIEW_TYPE_ID,',
'                OWNER_ID',
'            ) values (',
'                :P125_PROJECT_ID,',
'                 :P125_REVIEW_TYPE_ID,',
'                 :P125_USER_ID',
'            );',
'            :P125_STATUS :=  :P125_STATUS || ''Reviewer Added; '';',
'       end if;',
'    end loop;',
'end if;',
'',
'if :P125_PROJ_OWNER_ID is null and :P125_SET_AS_OWNER is not null and :P125_USER_ID is not null then',
'    update sp_projects set owner_id = :P125_USER_ID where id = :P125_PROJECT_ID;',
'     :P125_STATUS :=  :P125_STATUS || ''Owner Set; '';',
'end if;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(3628040226496416725)
,p_process_success_message=>'&P125_STATUS.'
,p_internal_uid=>1716293729755173720
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3628040815346416731)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set project info'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in ( ',
'    select project, ',
'           OWNER_ID, ',
'           FRIENDLY_IDENTIFIER, ',
'           PROJECT_URL_NAME,',
'           (select max(REVIEW_TYPE_ID) from SP_PROJECT_REVIEWS r where r.PROJECT_ID = p.id and r.OWNER_ID = :P125_USER_ID) REVIEW_TYPE_ID,',
'           (select max(RESPONSIBILITY_ID) from SP_PROJECT_CONTRIBUTORS c where c.PROJECT_ID = p.id and c.TEAM_MEMBER_ID = :P125_USER_ID) contribution',
'    from sp_projects p',
'    where id = :P125_PROJECT_ID) loop',
'    :P125_FI := c1.FRIENDLY_IDENTIFIER;',
'    :P125_PN := c1.PROJECT_URL_NAME;',
'    :P125_PROJ_OWNER_ID := c1.owner_id;',
'    :P125_CONTRIBUTION := c1.contribution;',
'    if :P125_CONTRIBUTION is not null then',
'       for c2 in (',
'           select RESOURCE_TYPE',
'           from SP_RESOURCE_TYPES',
'           where id = :P125_CONTRIBUTION) loop',
'          :P125_CONTRIBUTOR_DISP_ONLY := c2.RESOURCE_TYPE;',
'       end loop;',
'    end if;',
'    :P125_REVIEW_TYPE_ID := c1.REVIEW_TYPE_ID;',
'    :P125_PROJECT := c1.project;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>1716293225763173715
);
wwv_flow_imp.component_end;
end;
/
