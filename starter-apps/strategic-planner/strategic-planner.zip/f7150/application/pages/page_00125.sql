prompt --application/pages/page_00125
begin
--   Manifest
--     PAGE: 00125
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>125
,p_name=>'Choose Association'
,p_alias=>'CHOOSE-ASSOCIATION'
,p_page_mode=>'MODAL'
,p_step_title=>'&P125_USER_NAME.'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10024638739466235141)
,p_step_template=>wwv_flow_imp.id(141179926932913434829)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20240417231057'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3573641150202678821)
,p_plug_name=>'Association'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141179963021356434898)
,p_plug_display_sequence=>30
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5252073606017677897)
,p_plug_name=>'Header'
,p_region_template_options=>'#DEFAULT#:margin-top-md:margin-bottom-md'
,p_plug_template=>wwv_flow_imp.id(141179964373655434900)
,p_plug_display_sequence=>10
,p_plug_source=>'<strong>&NOMENCLATURE_PROJECT.</strong>: &P125_PROJECT.<br>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5253596969847486562)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141180113191418434946)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3573641076357678820)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5253596969847486562)
,p_button_name=>'previous'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141180196733751435045)
,p_button_image_alt=>'Previous'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:111:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3573636206686676617)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(5253596969847486562)
,p_button_name=>'cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141180196552115435044)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3573641825363678827)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5253596969847486562)
,p_button_name=>'view_project'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141180196552115435044)
,p_button_image_alt=>'View &NOMENCLATURE_PROJECT.'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:FI,PN:&P125_FI.,&P125_PN.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3573641685094678826)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(5253596969847486562)
,p_button_name=>'Add_Association'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141180196552115435044)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Association'
,p_button_position=>'EDIT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(3573642946009678838)
,p_branch_name=>'Go To Page 129'
,p_branch_action=>'f?p=&APP_ID.:119:&SESSION.::&DEBUG.:119:P119_PROJECT_ID,P119_USER_ID:&P125_PROJECT_ID.,&P125_USER_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3537309411506315057)
,p_name=>'P125_PROJECT_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(5252073606017677897)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3537309724618315060)
,p_name=>'P125_PROJECT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(5252073606017677897)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3573641611422678825)
,p_name=>'P125_SET_AS_OWNER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(3573641150202678821)
,p_prompt=>'Set As Owner'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_display_when=>'P125_PROJ_OWNER_ID'
,p_display_when_type=>'ITEM_IS_NULL'
,p_field_template=>wwv_flow_imp.id(141180195755963435040)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3573641935562678828)
,p_name=>'P125_CONTRIBUTOR_DISP_ONLY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3573641150202678821)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select RESPONSIBILITY',
'from SP_PROJECT_CONTRIBUTORS',
'where PROJECT_ID = :P125_PROJECT_ID and',
'      TEAM_MEMBER_ID = :P125_USER_ID'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'&P125_USER_NAME. Contribution'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P125_CONTRIBUTION'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(141180195755963435040)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3573641997402678829)
,p_name=>'P125_REVIEWER_DISPLAY_ONLY'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(3573641150202678821)
,p_prompt=>'&P125_USER_NAME. Review'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P125_RESOURCE_TYPE_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(141180195755963435040)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3573642142965678830)
,p_name=>'P125_FI'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(5252073606017677897)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3573642241319678831)
,p_name=>'P125_PN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(5252073606017677897)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3573642397340678833)
,p_name=>'P125_PROJ_OWNER_ID'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(5252073606017677897)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3573642537658678834)
,p_name=>'P125_CONTRIBUTION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(5252073606017677897)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3573642724222678836)
,p_name=>'P125_OWNER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(3573641150202678821)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select first_name||'' ''||last_name n',
'from sp_projects p,',
'     sp_team_members t',
'where p.id = :P125_PROJECT_ID and',
'      p.owner_id = t.id'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Owner'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P125_PROJ_OWNER_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(141180195755963435040)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3573643751881678847)
,p_name=>'P125_STATUS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(5252073606017677897)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3573833301568052837)
,p_name=>'P125_REVIEW_TYPE_ID'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(3573641150202678821)
,p_prompt=>'Review Type'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select review_type, id',
'from sp_project_review_types',
'order by display_seq'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Add -'
,p_cHeight=>1
,p_grid_row_css_classes=>'u-align-items-center'
,p_display_when=>'P125_REVIEW_TYPE_ID'
,p_display_when_type=>'ITEM_IS_NULL'
,p_field_template=>wwv_flow_imp.id(141180195755963435040)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_restricted_characters=>'US_ONLY'
,p_security_scheme=>wwv_flow_imp.id(141180225296450435141)
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3573890301173691727)
,p_name=>'P125_RESOURCE_TYPE_ID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(3573641150202678821)
,p_prompt=>'Contribution Type'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select RESOURCE_TYPE, id',
'from SP_RESOURCE_TYPES',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Add -'
,p_cHeight=>1
,p_display_when=>'P125_CONTRIBUTION'
,p_display_when_type=>'ITEM_IS_NULL'
,p_field_template=>wwv_flow_imp.id(141180195755963435040)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_restricted_characters=>'US_ONLY'
,p_security_scheme=>wwv_flow_imp.id(141180225296450435141)
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5252074014369677902)
,p_name=>'P125_USER_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(5252073606017677897)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5252074190995677903)
,p_name=>'P125_USER_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(5252073606017677897)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(3572318857780535804)
,p_computation_sequence=>20
,p_computation_item=>'P125_USER_NAME'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select decode(first_name,null,email,first_name||'' ''||last_name) un ',
'from sp_team_members ',
'where id = :P125_USER_ID'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3573640900590678818)
,p_name=>'close'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(3573636206686676617)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3573640968111678819)
,p_event_id=>wwv_flow_imp.id(3573640900590678818)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3573642777936678837)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Add associations'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P125_RESOURCE_TYPE_ID is not null and :P125_PROJECT_ID is not null and :P125_USER_ID is not null then',
'   insert into SP_PROJECT_CONTRIBUTORS (',
'      PROJECT_ID,',
'      TEAM_MEMBER_ID,',
'      RESPONSIBILITY_ID',
'   ) values (',
'      :P125_PROJECT_ID,',
'      :P125_USER_ID,',
'      :P125_RESOURCE_TYPE_ID',
'   );',
'   :P125_STATUS := ''Contribution Added; '';',
'end if;',
'',
'if :P125_REVIEW_TYPE_ID is not null and :P125_PROJECT_ID is not null and  :P125_USER_ID is not null then',
'    for c1 in (select count(*) c from SP_PROJECT_REVIEWS where project_id =  :P125_PROJECT_ID and OWNER_ID = :P125_USER_ID) loop',
'       if c1.c = 0 then ',
'            insert into SP_PROJECT_REVIEWS (',
'                PROJECT_ID,',
'                REVIEW_TYPE_ID,',
'                OWNER_ID',
'            ) values (',
'                :P125_PROJECT_ID,',
'                 :P125_REVIEW_TYPE_ID,',
'                 :P125_USER_ID',
'            );',
'            :P125_STATUS :=  :P125_STATUS || ''Reviewer Added; '';',
'       end if;',
'    end loop;',
'end if;',
'',
'if :P125_PROJ_OWNER_ID is null and :P125_SET_AS_OWNER is not null and :P125_USER_ID is not null then',
'    update sp_projects set owner_id = :P125_USER_ID where id = :P125_PROJECT_ID;',
'     :P125_STATUS :=  :P125_STATUS || ''Owner Set; '';',
'end if;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(3573641685094678826)
,p_process_success_message=>'&P125_STATUS.'
,p_internal_uid=>1716293729755173720
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3573642273944678832)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set project info'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in ( ',
'    select project, ',
'           OWNER_ID, ',
'           FRIENDLY_IDENTIFIER, ',
'           PROJECT_URL_NAME,',
'           (select max(REVIEW_TYPE_ID) from SP_PROJECT_REVIEWS r where r.PROJECT_ID = p.id and r.OWNER_ID = :P125_USER_ID) REVIEW_TYPE_ID,',
'           (select max(RESPONSIBILITY_ID) from SP_PROJECT_CONTRIBUTORS c where c.PROJECT_ID = p.id and c.TEAM_MEMBER_ID = :P125_USER_ID) contribution',
'    from sp_projects p',
'    where id = :P125_PROJECT_ID) loop',
'    :P125_FI := c1.FRIENDLY_IDENTIFIER;',
'    :P125_PN := c1.PROJECT_URL_NAME;',
'    :P125_PROJ_OWNER_ID := c1.owner_id;',
'    :P125_CONTRIBUTION := c1.contribution;',
'    if :P125_CONTRIBUTION is not null then',
'       for c2 in (',
'           select RESOURCE_TYPE',
'           from SP_RESOURCE_TYPES',
'           where id = :P125_CONTRIBUTION) loop',
'          :P125_CONTRIBUTOR_DISP_ONLY := c2.RESOURCE_TYPE;',
'       end loop;',
'    end if;',
'    :P125_REVIEW_TYPE_ID := c1.REVIEW_TYPE_ID;',
'    :P125_PROJECT := c1.project;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>1716293225763173715
);
wwv_flow_imp.component_end;
end;
/
