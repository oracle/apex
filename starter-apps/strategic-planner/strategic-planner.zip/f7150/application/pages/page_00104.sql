prompt --application/pages/page_00104
begin
--   Manifest
--     PAGE: 00104
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>26954343551793662
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>104
,p_name=>'Add Project'
,p_alias=>'ADD-PROJECT'
,p_page_mode=>'MODAL'
,p_step_title=>'Add Project'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(141215269997166368834)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_required_role=>wwv_flow_imp.id(141215568360703369146)
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3229665263324616432)
,p_plug_name=>'Content'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215306085609368903)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3229666834281616448)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215456255671368951)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3229667169924616451)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3229666834281616448)
,p_button_name=>'cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3229666940389616449)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3229666834281616448)
,p_button_name=>'Next'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(141215539798004369050)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(3229667944935616459)
,p_branch_name=>'go to step 2'
,p_branch_action=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:RP,24:P24_INITIATIVE_ID:&P104_INITIATIVE.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3229665587093616435)
,p_name=>'P104_AREA'
,p_is_required=>true
,p_item_sequence=>5
,p_item_plug_id=>wwv_flow_imp.id(3229665263324616432)
,p_item_default=>'P104_DEFAULT_AREA'
,p_item_default_type=>'ITEM'
,p_prompt=>'Select &NOMENCLATURE_AREA.'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.focus_area d, a.id r',
'from sp_focus_areas a',
'where HIDDEN_BY_DEFAULT_YN = ''N''',
'order by upper(a.focus_area)'))
,p_field_template=>wwv_flow_imp.id(141215538820216369045)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_help_text=>'&NOMENCLATURE_AREAS. are a top level "folders" that are subdivided into &NOMENCLATURE_INITIATIVES..   &NOMENCLATURE_INITIATIVES. are used to organize &NOMENCLATURE_PROJECTS.'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3229665769893616437)
,p_name=>'P104_INITIATIVE'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3229665263324616432)
,p_item_default=>'P104_DEFAULT_INITIATIVE'
,p_item_default_type=>'ITEM'
,p_prompt=>'Select &NOMENCLATURE_INITIATIVE.'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select initiative, id',
'from SP_INITIATIVES i',
'where focus_area_id = :P104_area and',
'      nvl(HIDDEN_BY_DEFAULT_YN,''N'') = ''N''',
'order by upper(initiative)'))
,p_lov_cascade_parent_items=>'P104_AREA'
,p_ajax_optimize_refresh=>'Y'
,p_field_template=>wwv_flow_imp.id(141215538820216369045)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_help_text=>'&NOMENCLATURE_INITIATIVES. organize &NOMENCLATURE_PROJECTS. within &NOMENCLATURE_AREAS.'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3310868883034340663)
,p_name=>'P104_DEFAULT_AREA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(3229665263324616432)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3310869012128340664)
,p_name=>'P104_DEFAULT_INITIATIVE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(3229665263324616432)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(3229668111619616460)
,p_validation_name=>'Initiative must be specified'
,p_validation_sequence=>10
,p_validation=>'P104_INITIATIVE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'&NOMENCLATURE_INITIATIVE. must be specified.'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3229667271974616452)
,p_name=>'close dialog on cancel'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(3229667169924616451)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3229667329779616453)
,p_event_id=>wwv_flow_imp.id(3229667271974616452)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3310869062408340665)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set defaults based on last project view'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P104_DEFAULT_AREA := null;',
':P104_DEFAULT_INITIATIVE := null;',
'for c1 in (',
'    select l.project_id, i.focus_area_id, p.INITIATIVE_ID, l.PAGE_RENDERED',
'    from   SP_PROJ_INTERACTIONS_LOG l, sp_projects P, sp_initiatives i ',
'    where  l.APP_USER = lower(:APP_USER) and',
'           l.project_id = p.id and',
'           p.INITIATIVE_ID = i.id',
'    order by l.PAGE_RENDERED desc',
'    fetch first 1 rows only',
'',
') loop',
'    :P104_DEFAULT_AREA := c1.focus_area_id;',
'    :P104_DEFAULT_INITIATIVE := c1.INITIATIVE_ID;',
'end loop;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>1418176949973901543
);
wwv_flow_imp.component_end;
end;
/
