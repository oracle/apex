prompt --application/pages/page_00140
begin
--   Manifest
--     PAGE: 00140
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>19055477148803894
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>140
,p_name=>'Activity Quick Look'
,p_alias=>'ACTIVITY-QUICK-LOOK1'
,p_page_mode=>'MODAL'
,p_step_title=>'Activity Quick Look'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.sp-tag {',
'    padding: 2px 4px;',
'    display: inline-block;',
'    vertical-align: text-bottom;',
'    border-radius: 3px;',
'    background-color: rgba(0,0,0,.1);',
'    text-overflow: ellipsis;',
'    white-space: nowrap;',
'}',
'.sp-tags-container {',
'    display: flex;',
'    align-items: center;',
'    flex-wrap: wrap;',
'    gap: 4px;',
'    justify-content: flex-start;',
'}',
'',
'.resize-region {',
'  resize: vertical;',
'  overflow: auto;',
'}'))
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(5982986044270211287)
,p_name=>'Activity'
,p_template=>4501440665235496320
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ap.ID,',
'       ap.ACTIVITY_TYPE_ID,',
'       (select activity_type from SP_ACTIVITY_TYPES at where at.id = ap.ACTIVITY_TYPE_ID) activity_type,',
'       ap.PROJECT_ID,',
'       nvl((select project from sp_projects p where p.id = ap.project_id),''Non Specified'') project,',
'       ap.TEAM_MEMBER_ID,',
'       decode(tm.first_name,null,tm.email,tm.first_Name||'' ''||tm.last_name||'' (''||tm.email||'')'') name,',
'       trunc(ap.END_DATE) - trunc(ap.START_DATE) activity_length,',
'       to_char(ap.START_DATE,''FMDay DD-MON-YYYY'')|| '' - ''||to_char(ap.END_DATE,''FMDay DD-MON-YYYY'') dates,',
'       decode(',
'           greatest(trunc(sysdate),trunc(ap.end_date)),',
'           trunc(sysdate),',
'           ''Past'',',
'           decode(',
'               greatest(trunc(sysdate),trunc(ap.start_date)),',
'               trunc(sysdate),',
'               ''Current'',',
'               ''Future'')',
'           ) timeframe,',
'       ap.COMMENTS,',
'       apex_util.get_since(ap.CREATED) created,',
'       lower(ap.CREATED_BY) CREATED_BY,',
'       apex_util.get_since(ap.UPDATED) updated,',
'       lower(ap.UPDATED_BY) UPDATED_BY,',
'       sp_date_range_pct_comp(ap.start_date, ap.end_date)||''%'' time_elapesed,',
'       ap.URL',
'  from sp_activities ap, ',
'       sp_team_Members tm',
' where ap.id = :P140_ID and',
'       ap.team_member_id = tm.id(+)'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P140_ID'
,p_lazy_loading=>false
,p_query_row_template=>2100515439059797523
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4857124002699270108)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>0
,p_column_heading=>'ID'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_hidden_column=>'Y'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4857124423769270108)
,p_query_column_id=>2
,p_column_alias=>'ACTIVITY_TYPE_ID'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4857123278119270107)
,p_query_column_id=>3
,p_column_alias=>'ACTIVITY_TYPE'
,p_column_display_sequence=>32
,p_column_heading=>'Type'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4857124867857270109)
,p_query_column_id=>4
,p_column_alias=>'PROJECT_ID'
,p_column_display_sequence=>82
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4857127602445270112)
,p_query_column_id=>5
,p_column_alias=>'PROJECT'
,p_column_display_sequence=>102
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4857125233636270109)
,p_query_column_id=>6
,p_column_alias=>'TEAM_MEMBER_ID'
,p_column_display_sequence=>92
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4857123603434270107)
,p_query_column_id=>7
,p_column_alias=>'NAME'
,p_column_display_sequence=>22
,p_column_heading=>'Owner'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4857128444134270112)
,p_query_column_id=>8
,p_column_alias=>'ACTIVITY_LENGTH'
,p_column_display_sequence=>62
,p_column_heading=>'Activity Length'
,p_column_html_expression=>'#ACTIVITY_LENGTH# Days, #TIME_ELAPESED# elapsed'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4857128884997270113)
,p_query_column_id=>9
,p_column_alias=>'DATES'
,p_column_display_sequence=>42
,p_column_heading=>'Dates'
,p_column_html_expression=>'<strong>#TIMEFRAME#</strong>: #DATES#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4832769967610663325)
,p_query_column_id=>10
,p_column_alias=>'TIMEFRAME'
,p_column_display_sequence=>52
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4857125637782270109)
,p_query_column_id=>11
,p_column_alias=>'COMMENTS'
,p_column_display_sequence=>12
,p_column_heading=>'Activity'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4857126085293270110)
,p_query_column_id=>12
,p_column_alias=>'CREATED'
,p_column_display_sequence=>132
,p_column_heading=>'Created'
,p_column_html_expression=>'#CREATED# by #CREATED_BY#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4857126391918270110)
,p_query_column_id=>13
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>142
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4857126881479270111)
,p_query_column_id=>14
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>152
,p_column_heading=>'Updated'
,p_column_html_expression=>'#UPDATED# by #UPDATED_BY#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4857127210801270111)
,p_query_column_id=>15
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>162
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4857128074226270112)
,p_query_column_id=>16
,p_column_alias=>'TIME_ELAPESED'
,p_column_display_sequence=>72
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4832770865857663334)
,p_query_column_id=>17
,p_column_alias=>'URL'
,p_column_display_sequence=>122
,p_column_heading=>'URL'
,p_column_link=>'#URL#'
,p_column_linktext=>'#URL#'
,p_column_link_attr=>'target="_blank" title="open link in new browser tab"'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 ',
'from SP_ACTIVITIES',
'where id = :P140_ID and URL is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(7380539324756229124)
,p_name=>'Associated &NOMENCLATURE_INITIATIVE.'
,p_template=>2664334895415463485
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select i.ID initiative_id,',
'       f.focus_area area,',
'       i.initiative initiative,',
'       nvl((select t.first_name||'' ''||t.last_name from sp_team_members t where t.id = i.SPONSOR_ID),''No Owner'') initiative_owner,',
'       i.OBJECTIVE description',
'from ',
'       SP_INITIATIVES i,',
'       SP_FOCUS_AREAS f,',
'       sp_activities a',
'where ',
'      a.id = :P140_ID and',
'      i.focus_area_id = f.id and',
'      i.id = a.initiative_id and ',
'      a.initiative_id is not null'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from SP_ACTIVITIES a',
'where a.id = :P140_ID and a.initiative_id is not null'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P140_ID'
,p_lazy_loading=>false
,p_query_row_template=>2100515439059797523
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No &NOMENCLATURE_PROJECT. found'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7380541894855229150)
,p_query_column_id=>1
,p_column_alias=>'INITIATIVE_ID'
,p_column_display_sequence=>40
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7380539607044229127)
,p_query_column_id=>2
,p_column_alias=>'AREA'
,p_column_display_sequence=>20
,p_column_heading=>'&NOMENCLATURE_INITIATIVE. &NOMENCLATURE_AREA.'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7380539716423229128)
,p_query_column_id=>3
,p_column_alias=>'INITIATIVE'
,p_column_display_sequence=>10
,p_column_heading=>'&NOMENCLATURE_INITIATIVE.'
,p_column_link=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP,94:P94_INITIATIVE_ID:#INITIATIVE_ID#'
,p_column_linktext=>'#INITIATIVE#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7380542085711229151)
,p_query_column_id=>4
,p_column_alias=>'INITIATIVE_OWNER'
,p_column_display_sequence=>50
,p_column_heading=>' &NOMENCLATURE_INITIATIVE. Owner'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7380542102686229152)
,p_query_column_id=>5
,p_column_alias=>'DESCRIPTION'
,p_column_display_sequence=>60
,p_column_heading=>'Description'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(11707933456881938465)
,p_name=>'Associated &NOMENCLATURE_PROJECT.'
,p_template=>2664334895415463485
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.ID,',
'       f.focus_area area,',
'       i.initiative initiative,',
'       nvl((select t.first_name||'' ''||t.last_name from sp_team_members t where t.id = p.OWNER_ID),''No Owner'') the_owner,',
'       p.owner_id,',
'       p.TARGET_COMPLETE,',
'       p.project,',
'       --',
'       nvl((select ''<span class="fa fa-heart u-danger-text" aria-hidden="true"></span>'' ',
'            from sp_favorites fav',
'            where fav.project_id = p.id and ',
'                  fav.team_member_id = :P3_USER_ID),',
'            ''<span class="fa fa-heart-o" aria-hidden="true"></span>'') favorite_icon,',
'       --',
'       p.PCT_COMPLETE||''%'' PCT_COMPLETE,',
'       nvl((select ''P''||priority from sp_project_priorities pp where pp.id = p.priority_id),''Not Prioritized'') priority,',
'       null attributes,',
'       --',
'       -- optional release association',
'       --',
'       (select t.release_train||'' ''||t.release from SP_RELEASE_TRAINS t where t.id = p.release_id and p.RELEASE_DEPENDENT_YN = ''Y'') release,',
'       decode(p.RELEASE_DEPENDENT_YN,''Y'',p.release_id,null) release_id,',
'       --',
'       -- optional project targeted date',
'       --',
'       decode(p.RELEASE_DEPENDENT_YN,''N'',',
'           decode(',
'               to_char(p.target_complete,''DD-MON-YYYY''),',
'               null,',
'               ''Not Targeted'',',
'               to_char(p.target_complete,''DD-MON-YYYY'')',
'               )) targeted_date,',
'       --',
'       --',
'       --',
'       lower(p.TAGS) tags,',
'       lower(p.CREATED_BY)||'' ''||apex_util.get_since(p.CREATED) created,',
'       lower(p.UPDATED_BY)||'' ''||apex_util.get_since(p.updated) updated,',
'       --',
'       p.PROJECT_SIZE,',
'       p.project_url_name,',
'       p.friendly_identifier friendly_identifier1,',
'       --',
'       case when c.milestone1_label is not null then decode(milestone1_complete_yn,''Y'',''Completed - '',''No - '')||decode(milestone1_complete_date,null,''No Date'',to_char(milestone1_complete_date,''DD-MON'')) end m1,',
'       case when c.milestone2_label is not null then decode(milestone2_complete_yn,''Y'',''Completed - '',''No - '')||decode(milestone2_complete_date,null,''No Date'',to_char(milestone2_complete_date,''DD-MON'')) end m2,',
'       case when c.milestone3_label is not null then decode(milestone3_complete_yn,''Y'',''Completed - '',''No - '')||decode(milestone3_complete_date,null,''No Date'',to_char(milestone3_complete_date,''DD-MON'')) end m3,',
'       case when c.milestone4_label is not null then decode(milestone4_complete_yn,''Y'',''Completed - '',''No - '')||decode(milestone4_complete_date,null,''No Date'',to_char(milestone4_complete_date,''DD-MON'')) end m4',
'  from SP_PROJECTS p, ',
'       SP_INITIATIVES i,',
'       SP_FOCUS_AREAS f,',
'       SP_PROJECT_SIZES s,',
'       sp_project_scales c',
'where ',
'      p.archived_yn = ''N'' and',
'      p.initiative_id = i.id and',
'      i.focus_area_id = f.id and',
'      p.PROJECT_SIZE = s.project_size and',
'      p.DUPLICATE_OF_PROJECT_ID is null and',
'      p.id = (select project_id from sp_activities ap where ap.id = :P140_ID) and',
'      p.status_scale = c.scale_letter'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from SP_ACTIVITIES a',
'where a.id = :P140_ID and a.project_id is not null'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P140_ID'
,p_lazy_loading=>false
,p_query_row_template=>2100515439059797523
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No &NOMENCLATURE_PROJECT. found'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4856945238194929906)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7293671198257713766)
,p_query_column_id=>2
,p_column_alias=>'AREA'
,p_column_display_sequence=>50
,p_column_heading=>'&NOMENCLATURE_AREA.'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7380538604535229117)
,p_query_column_id=>3
,p_column_alias=>'INITIATIVE'
,p_column_display_sequence=>60
,p_column_heading=>'&NOMENCLATURE_INITIATIVE.'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4856945646320929907)
,p_query_column_id=>4
,p_column_alias=>'THE_OWNER'
,p_column_display_sequence=>70
,p_column_heading=>'Owner'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4856946004830929908)
,p_query_column_id=>5
,p_column_alias=>'OWNER_ID'
,p_column_display_sequence=>80
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4856946489341929909)
,p_query_column_id=>6
,p_column_alias=>'TARGET_COMPLETE'
,p_column_display_sequence=>90
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'NOT_EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from sp_projects',
'where id = :P140_ID and ',
'      RELEASE_DEPENDENT_YN = ''Y'' and',
'      RELEASE_ID is not null',
'      '))
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4856952868102929923)
,p_query_column_id=>7
,p_column_alias=>'PROJECT'
,p_column_display_sequence=>40
,p_column_heading=>'Project'
,p_column_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:3:FI,PN:#FRIENDLY_IDENTIFIER1#,#PROJECT_URL_NAME#'
,p_column_linktext=>'#PROJECT#'
,p_column_link_attr=>'title="navigate to detail view"'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4856952429783929922)
,p_query_column_id=>8
,p_column_alias=>'FAVORITE_ICON'
,p_column_display_sequence=>270
,p_column_heading=>'My Favorite'
,p_column_link=>'f?p=&APP_ID.:128:&SESSION.::&DEBUG.:RP,128:P128_PROJECT_ID:#ID#'
,p_column_linktext=>'#FAVORITE_ICON#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4856953274280929924)
,p_query_column_id=>9
,p_column_alias=>'PCT_COMPLETE'
,p_column_display_sequence=>260
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4856947663142929913)
,p_query_column_id=>10
,p_column_alias=>'PRIORITY'
,p_column_display_sequence=>180
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4856944880002929905)
,p_query_column_id=>11
,p_column_alias=>'ATTRIBUTES'
,p_column_display_sequence=>110
,p_column_heading=>'Attributes'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="sp-tags-container">',
'    <span class="sp-tag">#PRIORITY#</span>',
'    <span class="sp-tag">#PROJECT_SIZE#</span>',
'    <span class="sp-tag">#PCT_COMPLETE#</span>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4856948015603929914)
,p_query_column_id=>12
,p_column_alias=>'RELEASE'
,p_column_display_sequence=>160
,p_column_heading=>'Release'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from sp_projects P  ',
'where p.RELEASE_DEPENDENT_YN = ''Y'' ',
'  and p.release_id is not null ',
'  and p.id = (select project_id from SP_ACTIVITIES a where a.id = :P140_ID)',
''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7293671160826713765)
,p_query_column_id=>13
,p_column_alias=>'RELEASE_ID'
,p_column_display_sequence=>280
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7380538782031229118)
,p_query_column_id=>14
,p_column_alias=>'TARGETED_DATE'
,p_column_display_sequence=>170
,p_column_heading=>'Target Completion'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from sp_projects P  ',
'where p.RELEASE_DEPENDENT_YN = ''N'' ',
'  and p.TARGET_COMPLETE is not null ',
'  and p.id = (select project_id from SP_ACTIVITIES a where a.id = :P140_ID)'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7293671079735713764)
,p_query_column_id=>15
,p_column_alias=>'TAGS'
,p_column_display_sequence=>230
,p_column_heading=>'Tags'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4856948435312929914)
,p_query_column_id=>16
,p_column_alias=>'CREATED'
,p_column_display_sequence=>240
,p_column_heading=>'Created'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4856948844337929915)
,p_query_column_id=>17
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>250
,p_column_heading=>'Updated'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4856949284697929916)
,p_query_column_id=>18
,p_column_alias=>'PROJECT_SIZE'
,p_column_display_sequence=>190
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4856949676032929916)
,p_query_column_id=>19
,p_column_alias=>'PROJECT_URL_NAME'
,p_column_display_sequence=>200
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4856950011228929917)
,p_query_column_id=>20
,p_column_alias=>'FRIENDLY_IDENTIFIER1'
,p_column_display_sequence=>210
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7375963000964958749)
,p_query_column_id=>21
,p_column_alias=>'M1'
,p_column_display_sequence=>120
,p_column_heading=>'&P140_MILESTONE1_LABEL.'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P140_MILESTONE1_LABEL'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7375963176861958750)
,p_query_column_id=>22
,p_column_alias=>'M2'
,p_column_display_sequence=>130
,p_column_heading=>'&P140_MILESTONE2_LABEL.'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P140_MILESTONE2_LABEL'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7375963268918958751)
,p_query_column_id=>23
,p_column_alias=>'M3'
,p_column_display_sequence=>140
,p_column_heading=>'&P140_MILESTONE3_LABEL.'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P140_MILESTONE3_LABEL'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7375963378034958752)
,p_query_column_id=>24
,p_column_alias=>'M4'
,p_column_display_sequence=>150
,p_column_heading=>'&P140_MILESTONE4_LABEL.'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P140_MILESTONE4_LABEL'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5919399321241303351)
,p_name=>'P140_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(5982986044270211287)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7375963436713958753)
,p_name=>'P140_MILESTONE1_LABEL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(5982986044270211287)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7375963577941958754)
,p_name=>'P140_MILESTONE2_LABEL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(5982986044270211287)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7375963640273958755)
,p_name=>'P140_MILESTONE3_LABEL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(5982986044270211287)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7375963771952958756)
,p_name=>'P140_MILESTONE4_LABEL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(5982986044270211287)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7383760724338537469)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'load milestone labels'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'    select milestone1_label,',
'           milestone2_label,',
'           milestone3_label,',
'           milestone4_label',
'      from sp_project_scales',
'     where scale_letter = (select status_scale from sp_projects',
'                            where id = (select project_id from sp_activities where id = :P140_ID))',
') loop',
'    :P140_MILESTONE1_LABEL := c1.milestone1_label;',
'    :P140_MILESTONE2_LABEL := c1.milestone2_label;',
'    :P140_MILESTONE3_LABEL := c1.milestone3_label;',
'    :P140_MILESTONE4_LABEL := c1.milestone4_label;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>5472013134755294453
);
wwv_flow_imp.component_end;
end;
/
