prompt --application/pages/page_00052
begin
--   Manifest
--     PAGE: 00052
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>52
,p_name=>'Un-Archive &NOMENCLATURE_PROJECT.'
,p_alias=>'UN-ARCHIVE-NOMENCLATURE-PROJECT'
,p_page_mode=>'MODAL'
,p_step_title=>'Restore &NOMENCLATURE_PROJECT.'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10033027460167375484)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(141188614017151575484)
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20240417194659'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24372135591219165191)
,p_plug_name=>'Archive'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188351742057575241)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24372135971684165195)
,p_plug_name=>'Button Container'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188501912119575289)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13543280141161242980)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(24372135971684165195)
,p_button_name=>'Cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13543280559221242981)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(24372135971684165195)
,p_button_name=>'restore_Project'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Restore &NOMENCLATURE_PROJECT.'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(12694597726296567707)
,p_branch_name=>'branch to projects page'
,p_branch_action=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:P3_PROJECT_ID:&P52_PROJECT_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13543278979423242977)
,p_name=>'P52_PROJECT_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(24372135591219165191)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13543279430293242979)
,p_name=>'P52_PROJECT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(24372135591219165191)
,p_prompt=>'&NOMENCLATURE_PROJECT.'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(141188584476664575383)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13543280978200242982)
,p_computation_sequence=>10
,p_computation_item=>'P52_PROJECT'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select project',
'from sp_projects p',
'where id = :P52_PROJECT_ID'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(13543281758924242985)
,p_name=>'close dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(13543280141161242980)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13543282254647242986)
,p_event_id=>wwv_flow_imp.id(13543281758924242985)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13543281325694242983)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'unArchive project'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_strategic_proj_util.un_archive_project (',
'    p_project_id => :P52_PROJECT_ID',
'    );'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Unable to Archive Project'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(13543280559221242981)
,p_process_success_message=>'&NOMENCLATURE_PROJECT. Restored'
,p_internal_uid=>11677543556811597523
);
wwv_flow_imp.component_end;
end;
/
