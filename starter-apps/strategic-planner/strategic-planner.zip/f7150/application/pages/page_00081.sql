prompt --application/pages/page_00081
begin
--   Manifest
--     PAGE: 00081
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>26954343551793662
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>81
,p_name=>'Edit Milestones'
,p_alias=>'EDIT-MILESTONES'
,p_page_mode=>'MODAL'
,p_step_title=>'Edit Milestones'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10059981803719169146)
,p_step_template=>wwv_flow_imp.id(141215269997166368834)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_required_role=>wwv_flow_imp.id(141215568360703369146)
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(146724906559041780955)
,p_plug_name=>'Project'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215306085609368903)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'SP_PROJECTS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(146724916646737780975)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215456255671368951)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7359505737978264782)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(146724916646737780975)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7359506184319264783)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(146724916646737780975)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P81_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9254262337594407622)
,p_name=>'P81_MILESTONE4_COMPLETE_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_item_source_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_prompt=>'&P81_MILESTONE4_LABEL. Date'
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'MILESTONE4_COMPLETE_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(141215538820216369045)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9605095867903344618)
,p_name=>'P81_MILESTONE3_COMPLETE_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_item_source_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_prompt=>'&P81_MILESTONE3_LABEL. Date'
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'MILESTONE3_COMPLETE_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(141215538820216369045)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9605096986938344630)
,p_name=>'P81_MILESTONE1_COMPLETE_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_item_source_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_prompt=>'&P81_MILESTONE1_LABEL. Date'
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'MILESTONE1_COMPLETE_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(141215538820216369045)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9605097903719344639)
,p_name=>'P81_MILESTONE2_COMPLETE_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_item_source_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_prompt=>'&P81_MILESTONE2_LABEL. Date'
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'MILESTONE2_COMPLETE_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(141215538820216369045)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9605098035781344640)
,p_name=>'P81_MILESTONE1_COMPLETE_YN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_item_source_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_item_default=>'N'
,p_prompt=>'&P81_MILESTONE1_LABEL.'
,p_source=>'MILESTONE1_COMPLETE_YN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(141215538820216369045)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9605098113160344641)
,p_name=>'P81_MILESTONE2_COMPLETE_YN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_item_source_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_item_default=>'N'
,p_prompt=>'&P81_MILESTONE2_LABEL.'
,p_source=>'MILESTONE2_COMPLETE_YN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(141215538820216369045)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9605098258858344642)
,p_name=>'P81_MILESTONE3_COMPLETE_YN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_item_source_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_item_default=>'N'
,p_prompt=>'&P81_MILESTONE3_LABEL.'
,p_source=>'MILESTONE3_COMPLETE_YN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(141215538820216369045)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10295886358395664140)
,p_name=>'P81_MILESTONE4_COMPLETE_YN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_item_source_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_item_default=>'N'
,p_prompt=>'&P81_MILESTONE4_LABEL.'
,p_source=>'MILESTONE4_COMPLETE_YN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(141215538820216369045)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10506944265399697396)
,p_name=>'P81_STATUS_SCALE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_item_source_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_source=>'STATUS_SCALE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_restricted_characters=>'WEB_SAFE'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12749777421800628543)
,p_name=>'P81_MILESTONE1_LABEL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12749777575261628544)
,p_name=>'P81_MILESTONE2_LABEL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12749777596213628545)
,p_name=>'P81_MILESTONE3_LABEL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12749777686366628546)
,p_name=>'P81_MILESTONE4_LABEL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(146724907498850780998)
,p_name=>'P81_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_item_source_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(146724907884517781002)
,p_name=>'P81_PROJECT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_item_source_plug_id=>wwv_flow_imp.id(146724906559041780955)
,p_prompt=>'&NOMENCLATURE_PROJECT.'
,p_source=>'PROJECT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(141215538820216369045)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(7360070250573955051)
,p_validation_name=>'Milestone1 date required when completed'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (nvl(:P81_MILESTONE1_COMPLETE_YN,''N'') = ''Y'' and :P81_MILESTONE1_COMPLETE_DATE is null) then ',
'    return false;',
'else',
'    return true;',
'end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'&P81_MILESTONE1_LABEL. date is required when marked completed.'
,p_associated_item=>wwv_flow_imp.id(9605096986938344630)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(7360192639715956742)
,p_validation_name=>'Milestone2 date required when completed'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (nvl(:P81_MILESTONE2_COMPLETE_YN,''N'') = ''Y'' and :P81_MILESTONE2_COMPLETE_DATE is null) then ',
'    return false;',
'else',
'    return true;',
'end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'&P81_MILESTONE2_LABEL. date is required when marked completed.'
,p_associated_item=>wwv_flow_imp.id(9605097903719344639)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(7360246057045958072)
,p_validation_name=>'Milestone3 date required when completed'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (nvl(:P81_MILESTONE3_COMPLETE_YN,''N'') = ''Y'' and :P81_MILESTONE3_COMPLETE_DATE is null) then ',
'    return false;',
'else',
'    return true;',
'end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'&P81_MILESTONE3_LABEL. date is required when marked completed.'
,p_associated_item=>wwv_flow_imp.id(9605095867903344618)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(7360250625101959873)
,p_validation_name=>'Milestone4 date required when completed'
,p_validation_sequence=>40
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (nvl(:P81_MILESTONE4_COMPLETE_YN,''N'') = ''Y'' and :P81_MILESTONE4_COMPLETE_DATE is null) then ',
'    return false;',
'else',
'    return true;',
'end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'&P81_MILESTONE4_LABEL. date is required when marked completed.'
,p_associated_item=>wwv_flow_imp.id(9254262337594407622)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7359511586035264812)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(7359505737978264782)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7359512096309264816)
,p_event_id=>wwv_flow_imp.id(7359511586035264812)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7359515838540264820)
,p_name=>'hide unused Milestones'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7359516376353264821)
,p_event_id=>wwv_flow_imp.id(7359515838540264820)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P81_MILESTONE1_COMPLETE_DATE,P81_MILESTONE1_COMPLETE_YN'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P81_MILESTONE1_LABEL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7359519882172264824)
,p_event_id=>wwv_flow_imp.id(7359515838540264820)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P81_MILESTONE4_COMPLETE_DATE,P81_MILESTONE4_COMPLETE_YN'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P81_MILESTONE4_LABEL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7359516893419264821)
,p_event_id=>wwv_flow_imp.id(7359515838540264820)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P81_MILESTONE2_COMPLETE_DATE,P81_MILESTONE2_COMPLETE_YN'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P81_MILESTONE2_LABEL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7359519374259264823)
,p_event_id=>wwv_flow_imp.id(7359515838540264820)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P81_MILESTONE3_COMPLETE_DATE,P81_MILESTONE3_COMPLETE_YN'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P81_MILESTONE3_LABEL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7359517399789264822)
,p_event_id=>wwv_flow_imp.id(7359515838540264820)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P81_MILESTONE3_COMPLETE_DATE,P81_MILESTONE3_COMPLETE_YN'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P81_MILESTONE3_LABEL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7359518858648264823)
,p_event_id=>wwv_flow_imp.id(7359515838540264820)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P81_MILESTONE2_COMPLETE_DATE,P81_MILESTONE2_COMPLETE_YN'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P81_MILESTONE2_LABEL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7359517904005264822)
,p_event_id=>wwv_flow_imp.id(7359515838540264820)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P81_MILESTONE4_COMPLETE_DATE,P81_MILESTONE4_COMPLETE_YN'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P81_MILESTONE4_LABEL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7359518326172264823)
,p_event_id=>wwv_flow_imp.id(7359515838540264820)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P81_MILESTONE1_COMPLETE_DATE,P81_MILESTONE1_COMPLETE_YN'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P81_MILESTONE1_LABEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7359509964096264808)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'load milestone labels'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'    select milestone1_label,',
'           milestone2_label,',
'           milestone3_label,',
'           milestone4_label',
'      from sp_project_scales',
'     where scale_letter = (select status_scale from sp_projects',
'                            where id = :P81_ID)',
'        or (:P81_STATUS_SCALE is null and scale_letter = ''A'')',
') loop',
'    :P81_MILESTONE1_LABEL := c1.milestone1_label;',
'    :P81_MILESTONE2_LABEL := c1.milestone2_label;',
'    :P81_MILESTONE3_LABEL := c1.milestone3_label;',
'    :P81_MILESTONE4_LABEL := c1.milestone4_label;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>5466817851661825686
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7359499595822264757)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(146724906559041780955)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Project'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed'
,p_internal_uid=>5466807483387825635
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7359511163665264810)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>5466819051230825688
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7359499147926264755)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(146724906559041780955)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Project'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>5466807035491825633
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7359510787342264810)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'log'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_log.log_interaction(',
'    p_project_id => :P81_ID);'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>5466818674907825688
);
wwv_flow_imp.component_end;
end;
/
