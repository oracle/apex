prompt --application/pages/page_00036
begin
--   Manifest
--     PAGE: 00036
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>36
,p_name=>'Project Detail'
,p_alias=>'PROJECT-DETAIL'
,p_page_mode=>'MODAL'
,p_step_title=>'&NOMENCLATURE_PROJECT.'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.sp-tag {',
'    padding: 2px 4px;',
'    display: inline-block;',
'    vertical-align: text-bottom;',
'    border-radius: 3px;',
'    background-color: rgba(0,0,0,.1);',
'    text-overflow: ellipsis;',
'    white-space: nowrap;',
'}',
'.sp-tags-container {',
'    display: flex;',
'    align-items: center;',
'    flex-wrap: wrap;',
'    gap: 4px;',
'    justify-content: flex-start;',
'}',
'',
'.resize-region {',
'  resize: vertical;',
'  overflow: auto;',
'}'))
,p_step_template=>wwv_flow_imp.id(141188315653614575172)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'SBKENNED'
,p_last_upd_yyyymmddhh24miss=>'20240419132734'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3038761341948998972)
,p_name=>'Activity'
,p_template=>wwv_flow_imp.id(141188484312500575273)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--noBorders'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ap.id, ',
'       at.activity_type,',
'       ap.comments,',
'       to_char(ap.start_date,''DD-MON-YYYY'')||'' to ''||to_char(ap.end_date,''DD-MON'') TIMELINE,',
'       tm.first_name||'' ''||tm.last_name name,',
'       ap.updated',
'from sp_activities ap,',
'     sp_projects p,',
'     sp_activity_types at,',
'     sp_team_members tm',
'where ap.project_id = p.id and',
'      p.id = :P36_ID and',
'      ap.activity_type_id = at.id and',
'      ap.team_member_id = tm.id and',
'      --',
'      --',
'      --',
'      (  ',
'         sysdate between ap.start_date and ap.end_date ',
'      )',
'order by ap.start_date, ap.updated desc',
'',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141188543836701575328)
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>150
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No Open Activity Found'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3038761412971998973)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3038763232699998990)
,p_query_column_id=>2
,p_column_alias=>'ACTIVITY_TYPE'
,p_column_display_sequence=>30
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3038763346518998991)
,p_query_column_id=>3
,p_column_alias=>'COMMENTS'
,p_column_display_sequence=>40
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3038763428521998992)
,p_query_column_id=>4
,p_column_alias=>'TIMELINE'
,p_column_display_sequence=>50
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3038762389546998982)
,p_query_column_id=>5
,p_column_alias=>'NAME'
,p_column_display_sequence=>20
,p_column_heading=>'Name'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'#NAME#: #ACTIVITY_TYPE#: #COMMENTS# - #TIMELINE#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3385758721989960477)
,p_query_column_id=>6
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>60
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_column_format=>'since_short'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3038761866663998977)
,p_name=>'Related'
,p_template=>wwv_flow_imp.id(141188484312500575273)
,p_display_sequence=>70
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--noBorders'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct id, related_project, related_fi, related_pn',
'from (',
'select distinct r.ID,',
'       (select project from sp_projects p where p.id = r.RELATED_PROJECT_ID) related_project,',
'       (select p2.FRIENDLY_IDENTIFIER from sp_projects p2 where p2.id = r.RELATED_PROJECT_ID) related_fi,',
'       (select p2.PROJECT_URL_NAME from sp_projects p2 where p2.id = r.RELATED_PROJECT_ID) related_pn',
'  from SP_PROJECT_RELATED r,',
'       sp_projects p',
'where  r.PROJECT_ID = :P36_ID and ',
'       r.RELATED_PROJECT_ID = p.id ',
'union ',
'select distinct r.ID,',
'       (select project from sp_projects p where p.id = r.RELATED_PROJECT_ID) related_project,',
'       (select p2.FRIENDLY_IDENTIFIER from sp_projects p2 where p2.id = r.PROJECT_ID) related_fi,',
'       (select p2.PROJECT_URL_NAME from sp_projects p2 where p2.id = r.PROJECT_ID) related_pn',
'  from SP_PROJECT_RELATED r,',
'         sp_projects p',
'where  RELATED_PROJECT_ID = :P36_ID and',
'       r.RELATED_PROJECT_ID = p.id ',
') x',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141188543836701575328)
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>150
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'None Found'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3038761968635998978)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3038762106067998979)
,p_query_column_id=>2
,p_column_alias=>'RELATED_PROJECT'
,p_column_display_sequence=>20
,p_column_heading=>'Related Project'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:FI,PN:#RELATED_FI#,#RELATED_PN#'
,p_column_linktext=>'#RELATED_PROJECT#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3038762229662998980)
,p_query_column_id=>3
,p_column_alias=>'RELATED_FI'
,p_column_display_sequence=>30
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3038762306961998981)
,p_query_column_id=>4
,p_column_alias=>'RELATED_PN'
,p_column_display_sequence=>40
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3038762681530998985)
,p_name=>'Contributors'
,p_template=>wwv_flow_imp.id(141188484312500575273)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--noBorders'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c.ID,',
'       t.first_name||'' ''||t.last_name name,',
'       c.TEAM_MEMBER_ID,',
'       (select RESOURCE_TYPE from SP_RESOURCE_TYPES r where r.id = c.RESPONSIBILITY_ID) responsibility,',
'       c.updated',
'  from SP_PROJECT_CONTRIBUTORS c,',
'       SP_TEAM_MEMBERS t',
'where c.project_id = :P36_ID and',
'      t.id = c.TEAM_MEMBER_ID'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141188543836701575328)
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>150
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No &NOMENCLATURE_PROJECTS. Found'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3038762770456998986)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3038762924106998987)
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>20
,p_column_heading=>'Name'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'#NAME#, #RESPONSIBILITY#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3038763041518998988)
,p_query_column_id=>3
,p_column_alias=>'TEAM_MEMBER_ID'
,p_column_display_sequence=>30
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3038763072621998989)
,p_query_column_id=>4
,p_column_alias=>'RESPONSIBILITY'
,p_column_display_sequence=>40
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3395762789697019378)
,p_query_column_id=>5
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>50
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE_SHORT'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3038763517736998993)
,p_name=>'Tags'
,p_template=>wwv_flow_imp.id(141188484312500575273)
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--noBorders'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(lower(replace(p.TAGS,'','','', '')),''Not Found'') tags',
'  from SP_PROJECTS p',
'where ',
'      p.archived_yn = ''N'' and',
'      p.DUPLICATE_OF_PROJECT_ID is null and',
'      p.id = :P36_ID'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141188543836701575328)
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>150
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'None Found'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3360720697009195292)
,p_query_column_id=>1
,p_column_alias=>'TAGS'
,p_column_display_sequence=>20
,p_column_heading=>'Tags'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(3038764354356999001)
,p_name=>'Reviews'
,p_template=>wwv_flow_imp.id(141188484312500575273)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--noBorders'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.ID,',
'       (select first_name||'' ''||last_name||'' (''||email||'')'' from sp_team_members t where t.id = r.owner_id) owner,',
'       (select review_type from sp_project_review_types rt where rt.id = r.review_type_id) type,',
'       initcap(review_status) status,',
'       r.updated,',
'       decode(',
'           r.review_date,',
'           null,''Missing-Date'',',
'           to_char(r.review_date,''DD-MON'')',
'           ) review_date',
'  from sp_project_reviews r',
'where  r.project_id = :P36_ID',
'order by 2'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141188543836701575328)
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>150
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No &NOMENCLATURE_PROJECTS. Found'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3038764420456999002)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3038764797019999006)
,p_query_column_id=>2
,p_column_alias=>'OWNER'
,p_column_display_sequence=>20
,p_column_heading=>'Owner'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3038764956028999007)
,p_query_column_id=>3
,p_column_alias=>'TYPE'
,p_column_display_sequence=>30
,p_column_heading=>'Type'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3038765023770999008)
,p_query_column_id=>4
,p_column_alias=>'STATUS'
,p_column_display_sequence=>50
,p_column_heading=>'Status'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3038765073959999009)
,p_query_column_id=>5
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>60
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE_SHORT'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15348388719114044181)
,p_query_column_id=>6
,p_column_alias=>'REVIEW_DATE'
,p_column_display_sequence=>40
,p_column_heading=>'Review Date'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3360718691370195272)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188501912119575289)
,p_plug_display_sequence=>80
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(8716727110096654040)
,p_name=>'Attributes'
,p_template=>wwv_flow_imp.id(141188484312500575273)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.ID,',
'       f.focus_area area,',
'       i.initiative,',
'       nvl((select t.first_name||'' ''||t.last_name from sp_team_members t where t.id = p.OWNER_ID),''No Owner'') the_owner,',
'       p.owner_id,',
'       p.TARGET_COMPLETE,',
'       p.project,',
'       --',
'       nvl((select ''<span class="fa fa-heart u-danger-text" aria-hidden="true"></span>'' ',
'            from sp_favorites fav',
'            where fav.project_id = p.id and ',
'                  fav.team_member_id = :P3_USER_ID),',
'            ''<span class="fa fa-heart-o" aria-hidden="true"></span>'') favorite_icon,',
'       --',
'       p.PCT_COMPLETE||''%'' PCT_COMPLETE,',
'       nvl((select ''P''||priority from sp_project_priorities pp where pp.id = p.priority_id),''Not Prioritized'') priority,',
'       null attributes,',
'       nvl(decode(',
'           p.RELEASE_DEPENDENT_YN,',
'           ''Y'',',
'           (select t.release_train||'' ''||t.release from SP_RELEASE_TRAINS t where t.id = p.release_id),',
'           decode(',
'               to_char(p.target_complete,''DD-MON-YYYY''),',
'               null,',
'               ''Not Targeted'',',
'               to_char(p.target_complete,''MON-YYYY'')',
'               )),''Not Targeted'')  release,',
'       --',
'       --p.TAGS,',
'       lower(p.CREATED_BY)||'' ''||apex_util.get_since(p.CREATED) created,',
'       lower(p.UPDATED_BY)||'' ''||apex_util.get_since(p.updated) updated,',
'       --',
'       p.PROJECT_SIZE,',
'       p.project_url_name,',
'       p.friendly_identifier friendly_identifier1,',
'       --',
'       decode(p.milestone1_complete_yn,''Y'',''Yes, '')||decode(p.milestone1_complete_date,null,''No date'',to_char(p.milestone1_complete_date,''FMDay DD-MON-YYYY'')) m1_complete,',
'       --',
'       decode(p.milestone2_complete_yn,''Y'',''Yes, '')||decode(p.milestone2_complete_date,null,''No date'',to_char(p.milestone2_complete_date,''FMDay DD-MON-YYYY'')) m2_complete,',
'       --',
'       decode(p.milestone3_complete_yn,''Y'',''Yes, '')||decode(p.milestone3_complete_date,null,''No date'',to_char(p.milestone3_complete_date,''FMDay DD-MON-YYYY'')) m3_complete,',
'       --',
'       decode(p.milestone4_complete_yn,''Y'',''Yes, '')||decode(p.milestone4_complete_date,null,''No date'',to_char(p.milestone4_complete_date,''FMDay DD-MON-YYYY'')) m4_complete,',
'       --',
'       -- external link:',
'       --',
'       p.external_system_link external_link,',
'       :P36_PERMALINK permalink',
'  from SP_PROJECTS p, ',
'       SP_INITIATIVES i,',
'       SP_FOCUS_AREAS f,',
'       SP_PROJECT_SIZES s',
'where ',
'      p.archived_yn = ''N'' and',
'      p.initiative_id = i.id and',
'      i.focus_area_id = f.id and',
'      p.PROJECT_SIZE = s.project_size and',
'      p.DUPLICATE_OF_PROJECT_ID is null and',
'      p.id = :P36_ID'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P36_PERMALINK,P36_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141188553199715575337)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2995067792322550381)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7342113391918893078)
,p_query_column_id=>2
,p_column_alias=>'AREA'
,p_column_display_sequence=>30
,p_column_heading=>'&NOMENCLATURE_AREA.'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7342113536186893079)
,p_query_column_id=>3
,p_column_alias=>'INITIATIVE'
,p_column_display_sequence=>40
,p_column_heading=>'&NOMENCLATURE_INITIATIVE.'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2995068461035550387)
,p_query_column_id=>4
,p_column_alias=>'THE_OWNER'
,p_column_display_sequence=>50
,p_column_heading=>'Owner'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2995068546176550388)
,p_query_column_id=>5
,p_column_alias=>'OWNER_ID'
,p_column_display_sequence=>60
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2995068594353550389)
,p_query_column_id=>6
,p_column_alias=>'TARGET_COMPLETE'
,p_column_display_sequence=>70
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'NOT_EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from sp_projects',
'where id = :P36_ID and ',
'      RELEASE_DEPENDENT_YN = ''Y'' and',
'      RELEASE_ID is not null',
'      '))
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4189535596466787965)
,p_query_column_id=>7
,p_column_alias=>'PROJECT'
,p_column_display_sequence=>20
,p_column_heading=>'Project'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:3:FI,PN:#FRIENDLY_IDENTIFIER1#,#PROJECT_URL_NAME#'
,p_column_linktext=>'#PROJECT#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4189535909841787968)
,p_query_column_id=>8
,p_column_alias=>'FAVORITE_ICON'
,p_column_display_sequence=>240
,p_column_heading=>'My Favorite'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:128:&SESSION.::&DEBUG.:RP,128:P128_PROJECT_ID:#ID#'
,p_column_linktext=>'#FAVORITE_ICON#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3589822520809495366)
,p_query_column_id=>9
,p_column_alias=>'PCT_COMPLETE'
,p_column_display_sequence=>230
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2995069122162550394)
,p_query_column_id=>10
,p_column_alias=>'PRIORITY'
,p_column_display_sequence=>100
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3589822430329495365)
,p_query_column_id=>11
,p_column_alias=>'ATTRIBUTES'
,p_column_display_sequence=>90
,p_column_heading=>'Attributes'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="sp-tags-container">',
'    <span class="sp-tag">#PRIORITY#</span>',
'    <span class="sp-tag">#PROJECT_SIZE#</span>',
'    <span class="sp-tag">#PCT_COMPLETE#</span>',
'    <span class="sp-tag">#RELEASE#</span>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2995069347260550396)
,p_query_column_id=>12
,p_column_alias=>'RELEASE'
,p_column_display_sequence=>80
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from sp_projects',
'where id = :P36_ID and ',
'      RELEASE_DEPENDENT_YN = ''Y'' and',
'      RELEASE_ID is not null'))
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2995069497400550398)
,p_query_column_id=>13
,p_column_alias=>'CREATED'
,p_column_display_sequence=>210
,p_column_heading=>'Created'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2995069755837550400)
,p_query_column_id=>14
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>220
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2995069902369550402)
,p_query_column_id=>15
,p_column_alias=>'PROJECT_SIZE'
,p_column_display_sequence=>110
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2995070161784550404)
,p_query_column_id=>16
,p_column_alias=>'PROJECT_URL_NAME'
,p_column_display_sequence=>120
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(2995070264180550405)
,p_query_column_id=>17
,p_column_alias=>'FRIENDLY_IDENTIFIER1'
,p_column_display_sequence=>130
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7329952224906361183)
,p_query_column_id=>18
,p_column_alias=>'M1_COMPLETE'
,p_column_display_sequence=>150
,p_column_heading=>'&P36_MILESTONE1_LABEL.'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P36_MILESTONE1_LABEL'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7329952294176361184)
,p_query_column_id=>19
,p_column_alias=>'M2_COMPLETE'
,p_column_display_sequence=>160
,p_column_heading=>'&P36_MILESTONE2_LABEL.'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P36_MILESTONE2_LABEL'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7329952981849361191)
,p_query_column_id=>20
,p_column_alias=>'M3_COMPLETE'
,p_column_display_sequence=>170
,p_column_heading=>'&P36_MILESTONE3_LABEL.'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P36_MILESTONE3_LABEL'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7329953165580361192)
,p_query_column_id=>21
,p_column_alias=>'M4_COMPLETE'
,p_column_display_sequence=>180
,p_column_heading=>'&P36_MILESTONE4_LABEL.'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P36_MILESTONE4_LABEL'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7464041130589324370)
,p_query_column_id=>22
,p_column_alias=>'EXTERNAL_LINK'
,p_column_display_sequence=>200
,p_column_heading=>'External Link'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7464041445070324373)
,p_query_column_id=>23
,p_column_alias=>'PERMALINK'
,p_column_display_sequence=>190
,p_column_heading=>'Permalink'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(118733018720089278690)
,p_name=>'Links'
,p_template=>wwv_flow_imp.id(141188484312500575273)
,p_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--noBorders'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select l.id, ',
'       l.link_url, ',
'       l.created, ',
'       l.updated, ',
'       decode(',
'           greatest(length(l.link_url),80),',
'           length(l.link_url),',
'           substr(l.link_url,1,37)||''...''||substr(l.link_url,length(l.link_url)-40),',
'           l.link_url',
'           ) link_url_display',
'from SP_PROJECT_LINKS l ',
'where project_id = :P36_ID',
'order by created desc'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P36_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141188543836701575328)
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>150
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No links Found'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4189540099275788010)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4232463895948234362)
,p_query_column_id=>2
,p_column_alias=>'LINK_URL'
,p_column_display_sequence=>30
,p_column_heading=>'URL'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<a href="#LINK_URL#" target="_blank">#LINK_URL_DISPLAY#</a>'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4232464134006234364)
,p_query_column_id=>3
,p_column_alias=>'CREATED'
,p_column_display_sequence=>50
,p_column_heading=>'Created'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE_SHORT'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4232464210547234365)
,p_query_column_id=>4
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>60
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(4232464477224234368)
,p_query_column_id=>5
,p_column_alias=>'LINK_URL_DISPLAY'
,p_column_display_sequence=>80
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3360718984556195275)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3360718691370195272)
,p_button_name=>'Close'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3385757754614960467)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3038763517736998993)
,p_button_name=>'view_change_history'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141188584666839575384)
,p_button_image_alt=>'View Change History'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:82:&SESSION.::&DEBUG.:RP,82:P82_ID:&P36_ID.'
,p_icon_css_classes=>'fa-clock-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3395762205491019372)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3038762681530998985)
,p_button_name=>'edit_contributors'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141188584666839575384)
,p_button_image_alt=>'Edit Contributors'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:116:&SESSION.::&DEBUG.:116:P116_PROJECT_ID:&P36_ID.'
,p_icon_css_classes=>'fa-edit'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3589823249690495373)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8716727110096654040)
,p_button_name=>'project_history'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141188584666839575384)
,p_button_image_alt=>'History'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:124:&SESSION.::&DEBUG.::P124_ID:&P36_ID.'
,p_icon_css_classes=>'fa-clock-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4232464761165234370)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(118733018720089278690)
,p_button_name=>'add_link'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141188584666839575384)
,p_button_image_alt=>'Add Link'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP,6:P6_PROJECT_ID:&P36_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4232465304377234376)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3038761341948998972)
,p_button_name=>'view_activity'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141188584666839575384)
,p_button_image_alt=>'View Activity'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:130:&SESSION.::&DEBUG.:RP,130:P130_PROJECT_ID:&P36_ID.'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3360718923354195274)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(8716727110096654040)
,p_button_name=>'Edit'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141188584666839575384)
,p_button_image_alt=>'Edit'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:RP,24:P24_ID:&P36_ID.'
,p_icon_css_classes=>'fa-edit'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3385758656559960476)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3038761341948998972)
,p_button_name=>'add_activity'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141188584666839575384)
,p_button_image_alt=>'Add Activity'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:101:&SESSION.::&DEBUG.:RP,101:P101_PROJECT_ID:&P36_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3385761409368960504)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3038763517736998993)
,p_button_name=>'edit_tags'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141188584666839575384)
,p_button_image_alt=>'Edit'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:88:&SESSION.::&DEBUG.:RP,88:P88_PROJECT_ID:&P36_ID.'
,p_icon_css_classes=>'fa-edit'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3360719661539195281)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3360718691370195272)
,p_button_name=>'Description'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141188585454452575388)
,p_button_image_alt=>'Description'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:136:&SESSION.::&DEBUG.:RP,136:P136_ID:&P36_ID.'
,p_icon_css_classes=>'fa-file-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4189536127016787970)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3360718691370195272)
,p_button_name=>'Documents'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141188585454452575388)
,p_button_image_alt=>'Documents'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:141:&SESSION.::&DEBUG.:RP,141:P141_ID:&P36_ID.'
,p_icon_css_classes=>'fa-image'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3395761612757019366)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(3360718691370195272)
,p_button_name=>'Comments'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141188585454452575388)
,p_button_image_alt=>'Comments'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:RP,100:P100_PROJECT_ID:&P36_ID.'
,p_icon_css_classes=>'fa-comment-o'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3038761027978998969)
,p_name=>'P36_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8716727110096654040)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3103115819313911407)
,p_name=>'P36_LOG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(8716727110096654040)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3360720114125195286)
,p_name=>'P36_PROJECT_NAME'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(8716727110096654040)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7329952579476361187)
,p_name=>'P36_MILESTONE1_LABEL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(8716727110096654040)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'WEB_SAFE'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7329952694744361188)
,p_name=>'P36_MILESTONE2_LABEL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(8716727110096654040)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'WEB_SAFE'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7329952785469361189)
,p_name=>'P36_MILESTONE3_LABEL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(8716727110096654040)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'WEB_SAFE'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7329952942300361190)
,p_name=>'P36_MILESTONE4_LABEL'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(8716727110096654040)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'WEB_SAFE'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7464041284409324372)
,p_name=>'P36_PERMALINK'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(8716727110096654040)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'WEB_SAFE'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(3103115731536911406)
,p_computation_sequence=>10
,p_computation_item=>'P36_LOG'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>'return sp_log.log_and_summarize(:P36_ID);'
,p_computation_error_message=>'Unable to log view #SQLERRM#'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(3360720208710195287)
,p_computation_sequence=>20
,p_computation_item=>'P36_PROJECT_NAME'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select project',
'from SP_PROJECTS p',
'where p.id = :P36_ID'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3360719080662195276)
,p_name=>'close dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(3360718984556195275)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3360719260355195277)
,p_event_id=>wwv_flow_imp.id(3360719080662195276)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7464041177632324371)
,p_process_sequence=>2
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Determine Permalink'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_url                   varchar2(4000);',
'    l_friendly_identifier   varchar2(255) := null;',
'begin',
'    for c1 in (select friendly_identifier from sp_projects p where p.id = :P36_ID) loop',
'        l_friendly_identifier := c1.friendly_identifier;',
'    end loop;',
'    l_url := apex_page.get_url(',
'                     p_application => :APP_ID,',
'                     p_page        => 3,',
'                     p_session     => null,',
'                     p_items       => ''FI'',',
'                     p_values      => l_friendly_identifier,',
'                     p_plain_url   => TRUE );',
'    l_url := rtrim(OWA_UTIL.get_cgi_env(''HTTP_REFERER''),''/'') || l_url; ',
'    :P36_PERMALINK := l_url;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>5598303408749678911
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7336464968233824974)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'load milestone labels'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'    select milestone1_label,',
'           milestone2_label,',
'           milestone3_label,',
'           milestone4_label',
'      from sp_project_scales',
'     where scale_letter = (select status_scale ',
'                             from sp_projects',
'                            where id = :P36_ID)',
') loop',
'    :P36_MILESTONE1_LABEL := c1.milestone1_label;',
'    :P36_MILESTONE2_LABEL := c1.milestone2_label;',
'    :P36_MILESTONE3_LABEL := c1.milestone3_label;',
'    :P36_MILESTONE4_LABEL := c1.milestone4_label;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>5470727199351179514
);
wwv_flow_imp.component_end;
end;
/
