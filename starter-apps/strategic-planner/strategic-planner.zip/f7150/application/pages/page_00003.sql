prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Project Details'
,p_alias=>'PROJECT-DETAILS'
,p_step_title=>'&P3_PROJECT_NAME.'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10033027460167375484)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* .no-item-ui {',
'    --a-field-input-border-width: 0;',
'    --a-field-input-background-color: transparent;',
'}',
'.overline {',
'  color: var(--ut-region-text-color,var(--ut-component-text-default-color));',
'}',
'.ck.ck-content {',
'    min-height: 60px !important;',
'}',
'.project-info-region {',
'    background-color: rgb(219 204 175 / 50%);',
'    padding: 1rem 1rem 0 1rem;',
'} */',
'',
'.project-rds-region {',
'    background-color: rgb(219 204 175 / 20%);',
'}',
'.t-Body-title {',
'    --ut-palette-warning-shade: rgba(var(--oj-palette-neutral-rgb-160));',
'    --ut-component-background-color: rgba(var(--oj-palette-neutral-rgb-170)); ',
'    --ut-alert-horizontal-border-radius: 0;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_deep_linking=>'Y'
,p_page_component_map=>'27'
,p_last_updated_by=>'SHARON.KENNEDY@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20240430154538'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2680203976358345179)
,p_plug_name=>'Related'
,p_region_name=>'RELATED'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188482213340575271)
,p_plug_display_sequence=>120
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.ID,',
'       (select project from sp_projects p where p.id = r.RELATED_PROJECT_ID) related_project,',
'       (select project from sp_projects p where p.id = r.PROJECT_ID) project,',
'       (select p2.pct_complete from sp_projects p2 where p2.id = r.RELATED_PROJECT_ID) pct_complete,',
'       i.initiative related_initiative,',
'       a.focus_area related_area,',
'       a.id aria_id,',
'       i.id initiative_id,',
'       r.project_id,',
'       r.RELATED_PROJECT_ID,',
'       r.project_relation,',
'       r.CREATED,',
'       r.CREATED_BY,',
'       r.UPDATED,',
'       r.UPDATED_BY,',
'       p.FRIENDLY_IDENTIFIER,',
'       p.PROJECT_URL_NAME,',
'       (select p2.FRIENDLY_IDENTIFIER from sp_projects p2 where p2.id = r.RELATED_PROJECT_ID) related_fi,',
'       (select p2.PROJECT_URL_NAME from sp_projects p2 where p2.id = r.RELATED_PROJECT_ID) related_pn',
'  from SP_PROJECT_RELATED r,',
'       sp_projects p,',
'       sp_initiatives i,',
'       sp_focus_areas a',
'where  r.PROJECT_ID = :P3_PROJECT_ID and ',
'       r.RELATED_PROJECT_ID = p.id and ',
'       i.id = p.initiative_id and ',
'       i.focus_area_id = a.id and ',
'       p.DUPLICATE_OF_PROJECT_ID is null and',
'       p.ARCHIVED_YN = ''N''',
'union ',
'select r.ID,',
'       (select project from sp_projects p where p.id = r.RELATED_PROJECT_ID) related_project,',
'       (select project from sp_projects p where p.id = r.PROJECT_ID) project,',
'       (select p2.pct_complete from sp_projects p2 where p2.id = r.PROJECT_ID) pct_complete,',
'       i.initiative related_initiative,',
'       a.focus_area related_area,',
'       a.id aria_id,',
'       i.id initiative_id,',
'       r.project_id,',
'       r.RELATED_PROJECT_ID,',
'       r.project_relation,',
'       r.CREATED,',
'       r.CREATED_BY,',
'       r.UPDATED,',
'       r.UPDATED_BY,',
'       p.FRIENDLY_IDENTIFIER,',
'       p.PROJECT_URL_NAME,',
'       (select p2.FRIENDLY_IDENTIFIER from sp_projects p2 where p2.id = r.PROJECT_ID) related_fi,',
'       (select p2.PROJECT_URL_NAME from sp_projects p2 where p2.id = r.PROJECT_ID) related_pn',
'  from SP_PROJECT_RELATED r,',
'         sp_projects p,',
'       sp_initiatives i,',
'       sp_focus_areas a',
'where  RELATED_PROJECT_ID = :P3_PROJECT_ID and',
'       r.RELATED_PROJECT_ID = p.id and ',
'       i.id = p.initiative_id and ',
'       i.focus_area_id = a.id and ',
'       p.DUPLICATE_OF_PROJECT_ID is null and',
'       p.ARCHIVED_YN = ''N''',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P3_PROJECT_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Related'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2680204204856345181)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:RP,10:P10_ID:#ID#'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(141188614017151575484)
,p_owner=>'MIKE'
,p_internal_uid=>814466435973699721
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2680204270760345182)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2680204475656345184)
,p_db_column_name=>'RELATED_PROJECT_ID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Related Project Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2680204783729345187)
,p_db_column_name=>'CREATED'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2680204910307345188)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2680204972859345189)
,p_db_column_name=>'UPDATED'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2680205148060345190)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2680205173340345191)
,p_db_column_name=>'RELATED_PROJECT'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Related &NOMENCLATURE_PROJECT.'
,p_column_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:FI,PN:#RELATED_FI#,#RELATED_PN#'
,p_column_linktext=>'#RELATED_PROJECT#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6468144443799796785)
,p_db_column_name=>'PROJECT'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'&NOMENCLATURE_PROJECT.'
,p_column_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:FI,PN:#RELATED_FI#,#RELATED_PN#'
,p_column_linktext=>'#PROJECT#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6468144522702796786)
,p_db_column_name=>'PROJECT_ID'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Project Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6468144840040796789)
,p_db_column_name=>'PROJECT_RELATION'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Relationship'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6468145273856796794)
,p_db_column_name=>'RELATED_INITIATIVE'
,p_display_order=>140
,p_column_identifier=>'P'
,p_column_label=>'Related &NOMENCLATURE_INITIATIVE.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6468145457875796795)
,p_db_column_name=>'RELATED_AREA'
,p_display_order=>150
,p_column_identifier=>'Q'
,p_column_label=>'Related &NOMENCLATURE_AREA.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6468145541900796796)
,p_db_column_name=>'ARIA_ID'
,p_display_order=>160
,p_column_identifier=>'R'
,p_column_label=>'Aria Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6468145612670796797)
,p_db_column_name=>'INITIATIVE_ID'
,p_display_order=>170
,p_column_identifier=>'S'
,p_column_label=>'Initiative Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8653661652408254710)
,p_db_column_name=>'FRIENDLY_IDENTIFIER'
,p_display_order=>180
,p_column_identifier=>'T'
,p_column_label=>'Friendly Identifier'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8969911614098213961)
,p_db_column_name=>'PROJECT_URL_NAME'
,p_display_order=>190
,p_column_identifier=>'U'
,p_column_label=>'Project Url Name'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8969911680913213962)
,p_db_column_name=>'RELATED_FI'
,p_display_order=>200
,p_column_identifier=>'V'
,p_column_label=>'Related Fi'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8969911774542213963)
,p_db_column_name=>'RELATED_PN'
,p_display_order=>210
,p_column_identifier=>'W'
,p_column_label=>'Related Pn'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6691926391277681980)
,p_db_column_name=>'PCT_COMPLETE'
,p_display_order=>220
,p_column_identifier=>'X'
,p_column_label=>'Pct Complete'
,p_column_html_expression=>'#PCT_COMPLETE#%'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2908062301251721381)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'10423246'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PROJECT:RELATED_PROJECT:PROJECT_RELATION:RELATED_AREA:RELATED_INITIATIVE:CREATED:'
,p_sort_column_1=>'CREATED'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6237617626669791893)
,p_plug_name=>'Comments'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188351742057575241)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6237617698155791894)
,p_plug_name=>'Comment Form'
,p_parent_plug_id=>wwv_flow_imp.id(6237617626669791893)
,p_region_template_options=>'#DEFAULT#:margin-bottom-md'
,p_plug_template=>wwv_flow_imp.id(141188351742057575241)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(107826484215093920055)
,p_name=>'Comments Report'
,p_region_name=>'COMMENTS'
,p_parent_plug_id=>wwv_flow_imp.id(6237617626669791893)
,p_template=>wwv_flow_imp.id(141188351742057575241)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_component_template_options=>'#DEFAULT#:t-Comments--chat'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pc.ID,',
'       -- Display Columns',
'       tm.initials user_icon,',
'       pc.created comment_date,',
'       tm.first_name || '' '' || tm.last_name user_name,',
'       --',
'       pc.body_html comment_text,',
'       null actions,',
'       decode(pc.private_yn,null,null,''N'',null,''Y'','' Private Comment'') private_comment_label,',
'       '' '' attribute_1,',
'       '' '' attribute_2,',
'       '' '' attribute_3,',
'       '' '' attribute_4,',
'       ''u-color-''||ora_hash(pc.created_by,45) icon_modifier,',
'',
'       -- Data Columns',
'       pc.ROW_VERSION,',
'       pc.PROJECT_ID,',
'       pc.BODY,',
'       pc.BODY_HTML,',
'       pc.PUBLISH_YN,',
'       pc.AUTHOR_APP_USER,',
'       pc.AUTHOR_ID,',
'       pc.CONTENT_FLAG_STATUS,',
'       --',
'       pc.CREATED,',
'       pc.CREATED_BY,',
'       pc.UPDATED,',
'       pc.UPDATED_BY,',
'       tm.id team_member_id',
'  from SP_PROJECT_COMMENTS pc, ',
'       sp_team_members tm',
'where pc.author_id = tm.id and',
'      pc.project_id = :P3_PROJECT_ID and',
'      pc.comment_on = ''PROJECT'' and ',
'      (nvl(pc.private_yn,''N'') = ''N'' or lower(pc.created_by) = lower(:app_user) )',
'order by created desc'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P3_PROJECT_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141188541625493575326)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No Comments'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(107826484288687920056)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(107826485664200920070)
,p_query_column_id=>2
,p_column_alias=>'USER_ICON'
,p_column_display_sequence=>150
,p_column_heading=>'User Icon'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(107826485830990920071)
,p_query_column_id=>3
,p_column_alias=>'COMMENT_DATE'
,p_column_display_sequence=>160
,p_column_heading=>'Comment Date'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(107826485934184920072)
,p_query_column_id=>4
,p_column_alias=>'USER_NAME'
,p_column_display_sequence=>170
,p_column_heading=>'User Name'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(107826486007248920073)
,p_query_column_id=>5
,p_column_alias=>'COMMENT_TEXT'
,p_column_display_sequence=>180
,p_column_heading=>'Comment Text'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if PRIVATE_COMMENT_LABEL/}<strong class="u-danger-text">#PRIVATE_COMMENT_LABEL#</strong><br />{endif/}',
'#COMMENT_TEXT#'))
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(107826486071041920074)
,p_query_column_id=>6
,p_column_alias=>'ACTIONS'
,p_column_display_sequence=>190
,p_column_heading=>'Actions'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:28:P28_ID:#ID#'
,p_column_linktext=>'edit'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6237618035263791897)
,p_query_column_id=>7
,p_column_alias=>'PRIVATE_COMMENT_LABEL'
,p_column_display_sequence=>270
,p_column_heading=>'Private Comment Label'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(107826486241807920075)
,p_query_column_id=>8
,p_column_alias=>'ATTRIBUTE_1'
,p_column_display_sequence=>200
,p_column_heading=>'Attribute 1'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(107826486277071920076)
,p_query_column_id=>9
,p_column_alias=>'ATTRIBUTE_2'
,p_column_display_sequence=>210
,p_column_heading=>'Attribute 2'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(116397383628827177227)
,p_query_column_id=>10
,p_column_alias=>'ATTRIBUTE_3'
,p_column_display_sequence=>220
,p_column_heading=>'Attribute 3'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(116397383665169177228)
,p_query_column_id=>11
,p_column_alias=>'ATTRIBUTE_4'
,p_column_display_sequence=>230
,p_column_heading=>'Attribute 4'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(116397383767894177229)
,p_query_column_id=>12
,p_column_alias=>'ICON_MODIFIER'
,p_column_display_sequence=>240
,p_column_heading=>'Icon Modifier'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(107826484399339920057)
,p_query_column_id=>13
,p_column_alias=>'ROW_VERSION'
,p_column_display_sequence=>20
,p_column_heading=>'Row Version'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(107826484522620920058)
,p_query_column_id=>14
,p_column_alias=>'PROJECT_ID'
,p_column_display_sequence=>30
,p_column_heading=>'Project Id'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(107826484586232920059)
,p_query_column_id=>15
,p_column_alias=>'BODY'
,p_column_display_sequence=>40
,p_column_heading=>'Body'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(107826484755129920060)
,p_query_column_id=>16
,p_column_alias=>'BODY_HTML'
,p_column_display_sequence=>50
,p_column_heading=>'Body Html'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(107826484845349920061)
,p_query_column_id=>17
,p_column_alias=>'PUBLISH_YN'
,p_column_display_sequence=>60
,p_column_heading=>'Publish Yn'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(107826484944161920062)
,p_query_column_id=>18
,p_column_alias=>'AUTHOR_APP_USER'
,p_column_display_sequence=>70
,p_column_heading=>'Author App User'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(107826485029832920063)
,p_query_column_id=>19
,p_column_alias=>'AUTHOR_ID'
,p_column_display_sequence=>80
,p_column_heading=>'Author Id'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(107826485110931920064)
,p_query_column_id=>20
,p_column_alias=>'CONTENT_FLAG_STATUS'
,p_column_display_sequence=>90
,p_column_heading=>'Content Flag Status'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(107826485304407920066)
,p_query_column_id=>21
,p_column_alias=>'CREATED'
,p_column_display_sequence=>110
,p_column_heading=>'Created'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(107826485390229920067)
,p_query_column_id=>22
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>120
,p_column_heading=>'Created By'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(107826485481378920068)
,p_query_column_id=>23
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>130
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(107826485606359920069)
,p_query_column_id=>24
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>140
,p_column_heading=>'Updated By'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(116366340892199700140)
,p_query_column_id=>25
,p_column_alias=>'TEAM_MEMBER_ID'
,p_column_display_sequence=>250
,p_column_heading=>'User ID'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7208300697152108494)
,p_plug_name=>'Dates'
,p_region_name=>'DATES'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(141188484312500575273)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(5410620474233899472)
,p_name=>'Dates Detail'
,p_parent_plug_id=>wwv_flow_imp.id(7208300697152108494)
,p_template=>wwv_flow_imp.id(141188351742057575241)
,p_display_sequence=>21
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''<span class="fa fa-edit" aria-hidden="true"></span>'' edit,',
'       display_order, ',
'       milestone, ',
'       target_date, ',
'       decode(milestone_completed,''Y'',''Yes'',''No'') milestone_completed, ',
'       --',
'       -- for past due dates how many days past due',
'       --',
'       decode(milestone_completed,''Y'',0,(target_date - sysdate)) days_since,',
'       --',
'       -- comments',
'       --',
'       decode(milestone_completed,''Y'',''Complete'',',
'       decode(',
'           target_date,',
'           null,''No date provided'',',
'           decode(greatest(trunc(sysdate),target_date),trunc(sysdate),''Past Due'',null)',
'           )',
'           ) comments',
'from',
'(',
'select 1 display_order, s.milestone1_label milestone, p.milestone1_complete_date target_date, p.milestone1_complete_yn milestone_completed',
'  from sp_projects p,',
'       sp_project_scales s',
' where p.id = :P3_PROJECT_ID',
'   and p.status_scale = s.scale_letter',
'   and s.milestone1_label is not null',
'union all ',
'select 2 display_order, s.milestone2_label milestone, p.milestone2_complete_date target_date, p.milestone2_complete_yn milestone_completed',
'  from sp_projects p,',
'       sp_project_scales s',
' where p.id = :P3_PROJECT_ID',
'   and p.status_scale = s.scale_letter',
'   and s.milestone2_label is not null',
'union all ',
'select 3 display_order, s.milestone3_label milestone, p.milestone3_complete_date target_date, p.milestone3_complete_yn milestone_completed',
'  from sp_projects p,',
'       sp_project_scales s',
' where p.id = :P3_PROJECT_ID',
'   and p.status_scale = s.scale_letter',
'   and s.milestone3_label is not null',
'union all ',
'select 4 display_order, s.milestone4_label milestone, p.milestone4_complete_date target_date, p.milestone4_complete_yn milestone_completed',
'  from sp_projects p,',
'       sp_project_scales s',
' where p.id = :P3_PROJECT_ID',
'   and p.status_scale = s.scale_letter',
'   and s.milestone4_label is not null',
'order by 1',
') x'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P3_PROJECT_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141188543836701575328)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3973714718110858690)
,p_query_column_id=>1
,p_column_alias=>'EDIT'
,p_column_display_sequence=>20
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:81:&SESSION.::&DEBUG.:81:P81_ID:&P3_PROJECT_ID.'
,p_column_linktext=>'#EDIT#'
,p_column_alignment=>'CENTER'
,p_report_column_required_role=>wwv_flow_imp.id(141188614017151575484)
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5410621458540899481)
,p_query_column_id=>2
,p_column_alias=>'DISPLAY_ORDER'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5410621549407899482)
,p_query_column_id=>3
,p_column_alias=>'MILESTONE'
,p_column_display_sequence=>30
,p_column_heading=>'Milestone'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5410621607650899483)
,p_query_column_id=>4
,p_column_alias=>'TARGET_DATE'
,p_column_display_sequence=>40
,p_column_heading=>'Target Date'
,p_use_as_row_header=>'N'
,p_column_format=>'FMDay DD-MON-YYYY'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5410621723039899484)
,p_query_column_id=>5
,p_column_alias=>'MILESTONE_COMPLETED'
,p_column_display_sequence=>60
,p_column_heading=>'Completed'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5410621957962899486)
,p_query_column_id=>6
,p_column_alias=>'DAYS_SINCE'
,p_column_display_sequence=>50
,p_column_heading=>'Days to Complete'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(5410622034627899487)
,p_query_column_id=>7
,p_column_alias=>'COMMENTS'
,p_column_display_sequence=>70
,p_column_heading=>'Comments'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16127715224458028761)
,p_plug_name=>'dates button container'
,p_parent_plug_id=>wwv_flow_imp.id(7208300697152108494)
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(141188501912119575289)
,p_plug_display_sequence=>101
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8889265986795394743)
,p_plug_name=>'Breadcrumb'
,p_region_sub_css_classes=>'has-header-actions'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188496742657575286)
,p_plug_display_sequence=>0
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(141188314805859575166)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(141188586951874575390)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9753609341828409561)
,p_plug_name=>'Menubar'
,p_parent_plug_id=>wwv_flow_imp.id(8889265986795394743)
,p_region_sub_css_classes=>'header-actions'
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>'select 1 as actions from dual'
,p_template_component_type=>'PARTIAL'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_attributes=>wwv_flow_string.join_clob(wwv_flow_t_varchar2('{',
  '"APPLY_THEME_COLORS": "Y",',
  '"AVATAR_ICON": "fa-user",',
  '"AVATAR_SHAPE": "t-Avatar--rounded",',
  '"AVATAR_TYPE": "icon",',
  '"BADGE_COL_WIDTH": "t-ContentRow-badge--md",',
  '"BADGE_LABEL_DISPLAY": "N",',
  '"DISPLAY_AVATAR": "N",',
  '"DISPLAY_BADGE": "N",',
  '"HIDE_BORDERS": "N",',
  '"REMOVE_PADDING": "N"',
'}'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9753610575334409573)
,p_name=>'ACTIONS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIONS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(11686589296733518398)
,p_name=>'Tags'
,p_region_name=>'TAGS'
,p_template=>wwv_flow_imp.id(141188482213340575271)
,p_display_sequence=>130
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--noBorders:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  with rws as (',
'  select tags str from sp_projects ',
'  where id = :P3_PROJECT_ID and tags is not null',
')',
'  select action, trim(tag) tag from (',
'  select null action,',
'        regexp_substr (',
'           str,',
'           ''[^,]+'',',
'           1,',
'           level',
'         ) tag',
'  from   rws',
'  connect by level <= ',
'    length ( str ) - length ( replace ( str, '','' ) ) + 1) x',
'  order by tag'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141188543836701575328)
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>150
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11686590547139518410)
,p_query_column_id=>1
,p_column_alias=>'ACTION'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<button type="button" title="Remove Tag: #TAG#" aria-label="Remove Tag: #TAG#" class="t-Button t-Button--noLabel t-Button--icon t-Button--small t-Button--danger t-Button--simple js-remove-tag" data-tag="#TAG#"><span aria-hidden="true" class="t-Icon f'
||'a fa-trash-o"></span></button>'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11686590431910518409)
,p_query_column_id=>2
,p_column_alias=>'TAG'
,p_column_display_sequence=>20
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3103111330958911363)
,p_plug_name=>'Tag Buttons'
,p_parent_plug_id=>wwv_flow_imp.id(11686589296733518398)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188351742057575241)
,p_plug_display_sequence=>110
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11980339719927611990)
,p_plug_name=>'Reviews'
,p_region_name=>'REVIEWS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188482213340575271)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_required_patch=>wwv_flow_imp.id(11954835352876239310)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13981513608171038899)
,p_plug_name=>'Requires Review'
,p_parent_plug_id=>wwv_flow_imp.id(11980339719927611990)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188351742057575241)
,p_plug_display_sequence=>10
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_text  varchar2(255) := null;',
'begin',
'',
'for c1 in (',
'    select requires_reviews_yn,',
'           (select count(*)',
'             from sp_project_reviews',
'            where project_id = p.id) rev_cnt',
'      from sp_projects p',
'     where id = :P3_PROJECT_ID',
') loop',
'    if c1.requires_reviews_yn = ''Y'' then',
'        l_text := ''This project requires reviews.'';',
'    elsif c1.rev_cnt > 0 then',
'        l_text := ''This project does not require reviews but reviews had been added.'';',
'    else',
'        l_text := ''This project does not require reviews.'';',
'    end if;',
'end loop;',
'',
'return l_text;',
'',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P3_PROJECT_ID'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from sp_projects',
' where id = :P3_PROJECT_ID',
'   and requires_reviews_yn = ''Y'''))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13981513696471038900)
,p_plug_name=>'reviews content'
,p_parent_plug_id=>wwv_flow_imp.id(11980339719927611990)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188482213340575271)
,p_plug_display_sequence=>60
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.ID,',
'       (select first_name||'' ''||last_name||'' (''||email||'')'' from sp_team_members t where t.id = r.owner_id) owner,',
'       (select review_type from sp_project_review_types rt where rt.id = r.review_type_id) type,',
'       initcap(review_status) status,',
'       review_date,',
'       review_comments        comments,',
'       r.updated,',
'       r.review_URL',
'  from sp_project_reviews r',
'where  r.project_id = :P3_PROJECT_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P3_PROJECT_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'reviews content'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_required_patch=>wwv_flow_imp.id(11954835352876239310)
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(13981513808572038901)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:RP,11:P11_ID:#ID#'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_owner=>'SBKENNED'
,p_internal_uid=>12115776039689393441
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13981513871632038902)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13981513969525038903)
,p_db_column_name=>'UPDATED'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13981514099899038904)
,p_db_column_name=>'OWNER'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Owner'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13981514209934038905)
,p_db_column_name=>'STATUS'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13981514332059038906)
,p_db_column_name=>'TYPE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14214545900051461682)
,p_db_column_name=>'REVIEW_DATE'
,p_display_order=>60
,p_column_identifier=>'H'
,p_column_label=>'Review Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13981514466331038907)
,p_db_column_name=>'COMMENTS'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Comments'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13981514486898038908)
,p_db_column_name=>'REVIEW_URL'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Review URL'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(14214072143223889940)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'123483344'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'OWNER:TYPE:STATUS:REVIEW_DATE:COMMENTS:UPDATED:'
,p_sort_column_1=>'REVIEW_DATE'
,p_sort_direction_1=>'ASC NULLS LAST'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(17089705133106280497)
,p_report_id=>wwv_flow_imp.id(14214072143223889940)
,p_name=>'highlight completed'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'STATUS'
,p_operator=>'='
,p_expr=>'Completed'
,p_condition_sql=>' (case when ("STATUS" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''Completed''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_column_bg_color=>'#d0f1cc'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16127715848040028767)
,p_plug_name=>'Reviewer'
,p_parent_plug_id=>wwv_flow_imp.id(11980339719927611990)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188353094356575243)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12694596410552567694)
,p_plug_name=>'Duplicate of:'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning:margin-bottom-none'
,p_plug_template=>wwv_flow_imp.id(141188346379614575226)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source=>'&P3_DUP_PROJECT.'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from sp_projects where id = :P3_PROJECT_ID and DUPLICATE_OF_PROJECT_ID is not null'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12694596475826567695)
,p_plug_name=>'Archived &NOMENCLATURE_PROJECT.'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning:margin-bottom-none'
,p_plug_template=>wwv_flow_imp.id(141188346379614575226)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select ARCHIVED_YN from sp_projects where id = :P3_PROJECT_ID and ARCHIVED_YN = ''Y'''
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13771496067823393080)
,p_plug_name=>'Description'
,p_region_name=>'DESCRIPTION'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188351742057575241)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(15460204658967438806)
,p_plug_name=>'description button container'
,p_parent_plug_id=>wwv_flow_imp.id(13771496067823393080)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188351742057575241)
,p_plug_display_sequence=>1102
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32981495930878811205)
,p_plug_name=>'Description'
,p_parent_plug_id=>wwv_flow_imp.id(13771496067823393080)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(141188484312500575273)
,p_plug_display_sequence=>120
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    x clob;',
'begin',
'x := ''No description provided.'';',
'for c1 in (select description from sp_projects d where d.id = :P3_PROJECT_ID) loop',
'    x := apex_markdown.to_html(c1.description);',
'end loop;',
'return x;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13843563578109314067)
,p_plug_name=>'footer'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188353094356575243)
,p_plug_display_sequence=>140
,p_plug_display_point=>'REGION_POSITION_05'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16209832785220525881)
,p_plug_name=>'Activity'
,p_region_name=>'ACTIVITY'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188351742057575241)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_required_patch=>wwv_flow_imp.id(16149062091664614982)
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16160177181524074743)
,p_plug_name=>'Activity Content Row'
,p_parent_plug_id=>wwv_flow_imp.id(16209832785220525881)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(141188484312500575273)
,p_plug_display_sequence=>121
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ap.id, ',
'       at.activity_type,',
'       ap.comments,',
'       ap.start_date,',
'       ap.end_date,',
'       to_char(ap.end_date,''Day DD-MON-YYYY'') end_date_formatted,',
'       to_char(ap.start_date,''Day DD-MON-YYYY'')||'' to ''||to_char(ap.end_date,''Day DD-MON-YYYY'') TIMELINE,',
'       ap.end_date - ap.start_date days,',
'       round(ap.end_date - sysdate) days_remaining,',
'       ap.url,',
'       tm.first_name||'' ''||tm.last_name name,',
'       --',
'       p.project,',
'       p.friendly_identifier,',
'       p.PROJECT_URL_NAME,',
'       apex_util.get_since(ap.updated) last_updated,',
'       --',
'       tm.first_name||'' ''||tm.last_name owner,',
'       --',
'       -- optional initiative',
'       --',
'       decode(ap.initiative_id,null,null,(',
'           select initiative from sp_initiatives where id = ap.initiative_id',
'       )) initiative,',
'       ap.initiative_id,',
'       --',
'       -- timeframe',
'       --',
'        decode(',
'           greatest(trunc(sysdate),trunc(ap.end_date)),',
'           trunc(sysdate),',
'           ''Past'',',
'           decode(',
'               greatest(trunc(sysdate),trunc(ap.start_date)),',
'               trunc(sysdate),',
'               ''Current'',',
'               ''Future'')',
'           ) timeframe,',
'       --',
'       -- pie chart icon in 10% chunks that show time percent complete',
'       --',
'       ''fa-pie-chart-''||sp_date_range_pct_comp(ap.start_date, ap.end_date) icon',
'from sp_activities ap,',
'     sp_projects p,',
'     sp_activity_types at,',
'     sp_team_members tm',
'where ap.project_id = p.id and',
'      p.id = :P3_PROJECT_ID and',
'      ap.activity_type_id = at.id and',
'      ap.team_member_id = tm.id and',
'      --',
'      --',
'      --',
'      (  ',
'         trunc(sysdate) between ap.start_date and ap.end_date or ',
'         (nvl(:P3_INCLUDE_FUTURE,''N'') = ''Y'' and ap.start_date >= trunc(sysdate)) or',
'         (nvl(:P3_INCLUDE_PAST,''N'') = ''Y'' and ap.end_date < trunc(sysdate))',
'      )',
'order by ap.updated desc',
''))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_ajax_items_to_submit=>'P3_PROJECT_ID,P3_INCLUDE_FUTURE,P3_INCLUDE_PAST'
,p_plug_query_num_rows=>30
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_required_patch=>wwv_flow_imp.id(16149062091664614982)
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_string.join_clob(wwv_flow_t_varchar2('{',
  '"TITLE": "\u0026COMMENTS.",',
  '"DESCRIPTION": "\u003Cstrong\u003EOwner\u003C\/strong\u003E :\u0026OWNER.\u003Cbr\u003E\n\u003Cstrong\u003E\u0026ACTIVITY_TYPE.\u003C\/strong\u003E: \u0026TIMELINE.\u003Cbr\u003E\n{if PROJECT\/}\u003Cstrong\u003E\u0026NOMENCLATURE_PROJECT.\u003C\/strong\u003E: \u0026PROJECT.\u003Cbr\u003E{endif\/}\n{if INITIATIVE\/}\u003Cstrong\u003E\u0026NOMENCLATURE_INITIATIVE.\u003C\/strong\u003E: \u0026INITIATIVE.\u003Cbr\u003E{endif\/}",',
  '"MISC": "Updated \u0026LAST_UPDATED.",',
  '"DISPLAY_AVATAR": "Y",',
  '"DISPLAY_BADGE": "Y",',
  '"AVATAR_TYPE": "icon",',
  '"AVATAR_ICON": "\u0026ICON.",',
  '"AVATAR_SHAPE": "t-Avatar--noShape",',
  '"BADGE_LABEL": "\u0026NOMENCLATURE_PROJECTS.",',
  '"BADGE_VALUE": "TIMEFRAME",',
  '"BADGE_LABEL_DISPLAY": "N",',
  '"AVATAR_SIZE": "t-Avatar--md",',
  '"BADGE_COL_WIDTH": "t-ContentRow-badge--lg",',
  '"APPLY_THEME_COLORS": "Y",',
  '"HIDE_BORDERS": "N",',
  '"REMOVE_PADDING": "N"',
'}'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3545695342329455372)
,p_name=>'TIMEFRAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIMEFRAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>340
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7334532650122631599)
,p_name=>'INITIATIVE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INITIATIVE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>350
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7334532699903631600)
,p_name=>'INITIATIVE_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INITIATIVE_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>360
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(16160177356830074744)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(16160178749449074758)
,p_name=>'DAYS_REMAINING'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DAYS_REMAINING'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>150
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(16160178901188074760)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>170
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(16160180845548074779)
,p_name=>'ACTIVITY_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIVITY_TYPE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>190
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(16160180960825074780)
,p_name=>'COMMENTS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMMENTS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>200
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(16160181061636074781)
,p_name=>'START_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'START_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>210
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(16160181153376074782)
,p_name=>'END_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'END_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>220
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(16181413845407626233)
,p_name=>'DAYS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DAYS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>230
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(16181413882643626234)
,p_name=>'URL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'URL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>240
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(16181414036462626235)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>250
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(16181414158992626236)
,p_name=>'PROJECT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROJECT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>260
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(16181414207717626237)
,p_name=>'FRIENDLY_IDENTIFIER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FRIENDLY_IDENTIFIER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>270
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(16181414269530626238)
,p_name=>'TIMELINE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIMELINE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>280
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(16181414416891626239)
,p_name=>'PROJECT_URL_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROJECT_URL_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>290
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(16181414546796626240)
,p_name=>'LAST_UPDATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAST_UPDATED'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>300
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(16181415319791626248)
,p_name=>'END_DATE_FORMATTED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'END_DATE_FORMATTED'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>310
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(16209834995515525903)
,p_name=>'OWNER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OWNER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>330
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16209832933325525882)
,p_plug_name=>'Activity Filters'
,p_parent_plug_id=>wwv_flow_imp.id(16209832785220525881)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188351742057575241)
,p_plug_display_sequence=>1111
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29300998908470733966)
,p_plug_name=>'Contributors'
,p_region_name=>'CONTRIBUTORS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188482213340575271)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c.ID,',
'       t.first_name||'' ''||t.last_name name,',
'       t.initials,',
'       c.TEAM_MEMBER_ID,',
'       c.RESPONSIBILITY_ID,',
'       (select RESOURCE_TYPE from SP_RESOURCE_TYPES r where r.id = c.RESPONSIBILITY_ID) responsibility,',
'       c.tags,',
'       c.CREATED,',
'       c.updated,',
'       c.responsibility comments,',
'       --',
'       nvl((select count(*) from SP_PROJECT_COMMENTS pc where pc.PROJECT_ID = c.project_id and pc.AUTHOR_ID = c.team_member_id),0) +',
'       nvl((select count(*) from SP_PROJECT_DOCUMENTS pd where pd.PROJECT_ID = c.project_id and pd.created_by = upper(t.email)),0) +',
'       nvl((select count(*) from SP_PROJECT_LINKS l where l.PROJECT_ID = c.project_id and l.created_by = upper(t.email)),0) ',
'       contributions',
'  from SP_PROJECT_CONTRIBUTORS c,',
'       SP_TEAM_MEMBERS t',
'where c.project_id = :P3_PROJECT_ID and',
'      t.id = c.TEAM_MEMBER_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P3_PROJECT_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Contributors'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2680205823741345197)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:9:P9_ID:#ID#'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(141188614017151575484)
,p_owner=>'MIKE'
,p_internal_uid=>814468054858699737
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2680205897603345198)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2680206059745345199)
,p_db_column_name=>'NAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Name'
,p_column_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5:P5_ID:#TEAM_MEMBER_ID#'
,p_column_linktext=>'#NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2680206112673345200)
,p_db_column_name=>'INITIALS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Initials'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2680206174634345201)
,p_db_column_name=>'TEAM_MEMBER_ID'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'User  ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2680206366559345202)
,p_db_column_name=>'RESPONSIBILITY_ID'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Responsibility Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2680206431540345203)
,p_db_column_name=>'RESPONSIBILITY'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Responsibility'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2680206601659345205)
,p_db_column_name=>'COMMENTS'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Comments'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2680206493478345204)
,p_db_column_name=>'CREATED'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10043179370776618595)
,p_db_column_name=>'TAGS'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Tags'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10043179759128618598)
,p_db_column_name=>'UPDATED'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12195306571222928169)
,p_db_column_name=>'CONTRIBUTIONS'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Contributions'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2945291950532589773)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'10795542'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NAME:RESPONSIBILITY:COMMENTS:CONTRIBUTIONS:CREATED:UPDATED:'
,p_sort_column_1=>'UPDATED'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'CREATED'
,p_sort_direction_2=>'DESC'
,p_sum_columns_on_break=>'CONTRIBUTIONS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16127715612218028765)
,p_plug_name=>'contributor change button container'
,p_parent_plug_id=>wwv_flow_imp.id(29300998908470733966)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188353094356575243)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(33343640385626563406)
,p_name=>'&NOMENCLATURE_PROJECTS.'
,p_template=>wwv_flow_imp.id(141188351742057575241)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-ContextualInfo-label--stacked:t-Report--hideNoPagination'
,p_display_point=>'REGION_POSITION_01'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.ID,',
'       p.INITIATIVE_ID,',
'       f.focus_area,',
'       f.id focus_area_id,',
'       i.initiative,',
'       p.PROJECT,',
'       --',
'       -- owner',
'       --',
'       (select t.first_name||'' ''||t.last_name',
'       from SP_TEAM_MEMBERS t ',
'       where t.id = p.OWNER_ID) project_owner,',
'       --',
'       p.owner_id,',
'       --',
'       nvl(decode(p.RELEASE_DEPENDENT_YN,''N'',p.TARGET_COMPLETE,',
'           (select release_target_date from SP_RELEASE_TRAINS t where t.id = p.release_id) ),p.TARGET_COMPLETE) target_complete,',
'       --',
'       -- status',
'       --',
'       case p.pct_complete when 0 then s.pc0_label   ||'' - ''|| p.pct_complete ||''%''',
'                           when 10 then s.pc10_label ||'' - ''|| p.pct_complete ||''%''',
'                           when 20 then s.pc20_label ||'' - ''|| p.pct_complete ||''%''',
'                           when 30 then s.pc30_label ||'' - ''|| p.pct_complete ||''%''',
'                           when 40 then s.pc40_label ||'' - ''|| p.pct_complete ||''%''',
'                           when 50 then s.pc50_label ||'' - ''|| p.pct_complete ||''%''',
'                           when 60 then s.pc60_label ||'' - ''|| p.pct_complete ||''%''',
'                           when 70 then s.pc70_label ||'' - ''|| p.pct_complete ||''%''',
'                           when 80 then s.pc80_label ||'' - ''|| p.pct_complete ||''%''',
'                           when 90 then s.pc90_label ||'' - ''|| p.pct_complete ||''%''',
'                           when 100 then s.pc100_label ||'' - ''|| p.pct_complete ||''%''',
'                           end as status,',
'       --',
'       -- priority',
'       --',
'       p.PRIORITY_ID,',
'       nvl((select ''P''||PRIORITY from sp_project_priorities pp where pp.id = p.priority_id),''Not Prioritized'') priority,',
'       --',
'       nvl(decode(p.RELEASE_DEPENDENT_YN,''Yes'',''No''),''No'') RELEASE_DEPENDENT_YN,',
'       --',
'       -- only show release if tagged as release dependent',
'       --',
'       decode(p.RELEASE_DEPENDENT_YN,',
'           ''Y'',(select RELEASE_TRAIN||'' ''||release from SP_RELEASE_TRAINS r where r.id = p.release_id),',
'           decode(p.TARGET_COMPLETE,null,''Not Targeted'',to_char(p.TARGET_COMPLETE,''DD-MON-YYYY''))) release,',
'       --',
'       p.release_id,',
'       p.TAGS,',
'       p.CREATED,',
'       p.CREATED_BY,',
'       p.UPDATED,',
'       p.UPDATED_BY,',
'       p.project_size,',
'       p.friendly_identifier,',
'       decode(p.ACTIVE_YN,''Y'',''Yes'',''N'',''No'',''Unknown'') active_yn,',
'       --',
'       -- external link',
'       --',
'       p.external_system_link,',
'       p.external_ticket_identifier,',
'       --',
'       -- favorite_icon',
'       --',
'       nvl((select ''<span class="fa fa-heart u-danger-text" aria-hidden="true"></span>'' ',
'            from sp_favorites fav ',
'            where fav.project_id = p.id and ',
'                  fav.team_member_id = :P3_USER_ID),',
'                  ''<span class="fa fa-heart-o" aria-hidden="true"></span>'') favorite_icon',
'       --',
'  from SP_PROJECTS p, ',
'       SP_INITIATIVES i,',
'       SP_FOCUS_AREAS f,',
'       SP_PROJECT_SCALES s',
'where ',
'      p.initiative_id = i.id and',
'      i.focus_area_id = f.id and',
'      p.id = :P3_PROJECT_ID and  ',
'      p.status_scale = s.scale_letter',
'     '))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P3_USER_ID,P3_PROJECT_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141188542774892575327)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33343640413690563407)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33343640514012563408)
,p_query_column_id=>2
,p_column_alias=>'INITIATIVE_ID'
,p_column_display_sequence=>20
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33343640678759563409)
,p_query_column_id=>3
,p_column_alias=>'FOCUS_AREA'
,p_column_display_sequence=>30
,p_column_heading=>'Area'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:23:P23_FOCUS_AREA:#FOCUS_AREA#'
,p_column_linktext=>'#FOCUS_AREA#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33343642222729563425)
,p_query_column_id=>4
,p_column_alias=>'FOCUS_AREA_ID'
,p_column_display_sequence=>230
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33343640724715563410)
,p_query_column_id=>5
,p_column_alias=>'INITIATIVE'
,p_column_display_sequence=>40
,p_column_heading=>'Initiative'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP,:P94_INITIATIVE_ID:#INITIATIVE_ID#'
,p_column_linktext=>'#INITIATIVE#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33343640877715563411)
,p_query_column_id=>6
,p_column_alias=>'PROJECT'
,p_column_display_sequence=>60
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33494620085441918486)
,p_query_column_id=>7
,p_column_alias=>'PROJECT_OWNER'
,p_column_display_sequence=>50
,p_column_heading=>'Owner'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:RR,5:P5_ID:#OWNER_ID#'
,p_column_linktext=>'#PROJECT_OWNER#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33494620052832918485)
,p_query_column_id=>8
,p_column_alias=>'OWNER_ID'
,p_column_display_sequence=>240
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33343641086321563413)
,p_query_column_id=>9
,p_column_alias=>'TARGET_COMPLETE'
,p_column_display_sequence=>170
,p_column_heading=>'Target'
,p_use_as_row_header=>'N'
,p_column_format=>'DD-MON-YYYY'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from SP_PROJECTS p',
'where ',
'      RELEASE_DEPENDENT_YN = ''N'' and',
'      p.id = :P3_PROJECT_ID'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33343641297501563415)
,p_query_column_id=>10
,p_column_alias=>'STATUS'
,p_column_display_sequence=>100
,p_column_heading=>'Completeness'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33343641375297563416)
,p_query_column_id=>11
,p_column_alias=>'PRIORITY_ID'
,p_column_display_sequence=>110
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33343641498511563417)
,p_query_column_id=>12
,p_column_alias=>'PRIORITY'
,p_column_display_sequence=>120
,p_column_heading=>'Priority'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33343641589283563418)
,p_query_column_id=>13
,p_column_alias=>'RELEASE_DEPENDENT_YN'
,p_column_display_sequence=>130
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33343641698823563419)
,p_query_column_id=>14
,p_column_alias=>'RELEASE'
,p_column_display_sequence=>160
,p_column_heading=>'Release'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.:RP,117:p117_release_id:#RELEASE_ID#'
,p_column_linktext=>'#RELEASE#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from SP_PROJECTS p',
'where ',
'      release_id is not null and',
'      p.id = :P3_PROJECT_ID'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>wwv_flow_imp.id(6210148529518744054)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23501863080133439406)
,p_query_column_id=>15
,p_column_alias=>'RELEASE_ID'
,p_column_display_sequence=>270
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33343641704670563420)
,p_query_column_id=>16
,p_column_alias=>'TAGS'
,p_column_display_sequence=>180
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33343641875352563421)
,p_query_column_id=>17
,p_column_alias=>'CREATED'
,p_column_display_sequence=>190
,p_column_heading=>'Created'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE_SHORT'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33343641988460563422)
,p_query_column_id=>18
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>200
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33343642089719563423)
,p_query_column_id=>19
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>210
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE_SHORT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(33343642200215563424)
,p_query_column_id=>20
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>220
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1932026640590876397)
,p_query_column_id=>21
,p_column_alias=>'PROJECT_SIZE'
,p_column_display_sequence=>140
,p_column_heading=>'Size'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:34:P34_ID:#ID#'
,p_column_linktext=>'#PROJECT_SIZE#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(13771494210578393062)
,p_query_column_id=>22
,p_column_alias=>'FRIENDLY_IDENTIFIER'
,p_column_display_sequence=>250
,p_column_heading=>'Permalink'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:93:&SESSION.::&DEBUG.:RP,93:P93_ID:#ID#'
,p_column_linktext=>'#FRIENDLY_IDENTIFIER#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_required_patch=>wwv_flow_imp.id(7620836838353896630)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16343567850949639185)
,p_query_column_id=>23
,p_column_alias=>'ACTIVE_YN'
,p_column_display_sequence=>90
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_required_patch=>wwv_flow_imp.id(19957512337871264807)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8128594164361427464)
,p_query_column_id=>24
,p_column_alias=>'EXTERNAL_SYSTEM_LINK'
,p_column_display_sequence=>260
,p_column_heading=>'External Link'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<a href="#EXTERNAL_SYSTEM_LINK#" target="_blank">#EXTERNAL_TICKET_IDENTIFIER#</a>'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 ',
'from   SP_PROJECTS p',
'where  ID = :P3_PROJECT_ID and ',
'       p.external_ticket_identifier is not null and ',
'       p.external_ticket_system is not null and ',
'       p.display_external_link_yn = ''Y'''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8128594367692427466)
,p_query_column_id=>25
,p_column_alias=>'EXTERNAL_TICKET_IDENTIFIER'
,p_column_display_sequence=>300
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3973712321873858666)
,p_query_column_id=>26
,p_column_alias=>'FAVORITE_ICON'
,p_column_display_sequence=>280
,p_column_heading=>'My Favorite'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:128:&SESSION.::&DEBUG.:RP,128:P128_PROJECT_ID,P128_USER_ID:#ID#,&P3_USER_ID.'
,p_column_linktext=>'#FAVORITE_ICON#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33343642342724563426)
,p_plug_name=>'RDS'
,p_region_css_classes=>'u-padding-inline-dynamic project-rds-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188353094356575243)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_08'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'N'
,p_attribute_03=>'SESSION'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(116366341004147700141)
,p_plug_name=>'Links'
,p_region_name=>'LINKS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188482213340575271)
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select l.id, ',
'       l.LINK_name, ',
'       decode(greatest(length(l.link_url),80),80,',
'           l.link_url,',
'           substr(l.link_url,1,39)||''...''||substr(l.link_url,length(l.link_url)-39)',
'           ) link_url,',
'       l.created, ',
'       l.updated, ',
'       lower(created_by) added_by,',
'       decode(important_yn,''Y'',''Yes'',''N'',''No'',null,''No'') important',
'from SP_PROJECT_LINKS l ',
'where project_id = :P3_PROJECT_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P3_PROJECT_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Links'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2680203275449345172)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:6:P6_ID:#ID#'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(141188614017151575484)
,p_owner=>'MIKE'
,p_internal_uid=>814465506566699712
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2680203444802345173)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16560922221446055285)
,p_db_column_name=>'LINK_NAME'
,p_display_order=>20
,p_column_identifier=>'M'
,p_column_label=>'Link'
,p_column_link=>'#LINK_URL#'
,p_column_linktext=>'#LINK_NAME#'
,p_column_link_attr=>'target="_blank"'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2680203573389345175)
,p_db_column_name=>'LINK_URL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'URL'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2680203856295345177)
,p_db_column_name=>'CREATED'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10043179602923618597)
,p_db_column_name=>'UPDATED'
,p_display_order=>60
,p_column_identifier=>'H'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16560921181393055275)
,p_db_column_name=>'IMPORTANT'
,p_display_order=>70
,p_column_identifier=>'K'
,p_column_label=>'Important'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17901462518423224483)
,p_db_column_name=>'ADDED_BY'
,p_display_order=>80
,p_column_identifier=>'N'
,p_column_label=>'Added By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2698860420292500042)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8331227'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LINK_NAME:LINK_URL:IMPORTANT:UPDATED:ADDED_BY:'
,p_sort_column_1=>'IMPORTANT'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'UPDATED'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(116366342790322700159)
,p_plug_name=>'Documents'
,p_region_name=>'DOCUMENTS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188482213340575271)
,p_plug_display_sequence=>110
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d.ID,',
'       d.DOCUMENT_FILENAME,',
'       d.UPDATED,',
'       d.created,',
'       decode(greatest(length(d.doc_description),200),200,d.doc_description,substr(d.doc_description,1,200)||''...'') doc_description,',
'       d.tags,',
'       lower(created_by) created_by,',
'       dbms_lob.getlength(d.DOCUMENT_BLOB) doc_size,',
'       created date_created,',
'       substr(DOCUMENT_FILENAME,instr(DOCUMENT_FILENAME,''.'',-1)+1,length(DOCUMENT_FILENAME)-instr(DOCUMENT_FILENAME,''.'',-1)) file_extension,',
'       decode(important_yn,''Y'', ''Yes'',''No'') important',
'  from SP_PROJECT_DOCUMENTS d',
' where project_id = :P3_PROJECT_ID',
'order by created desc',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P3_PROJECT_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Documents'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2674956601987995483)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:12:P12_ID:#ID#'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(141188614017151575484)
,p_owner=>'MIKE'
,p_internal_uid=>809218833105350023
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2674956703151995484)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2674956835542995485)
,p_db_column_name=>'DOCUMENT_FILENAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Filename'
,p_column_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:30:P30_ID,P30_PREV_PAGE:#ID#,3'
,p_column_linktext=>'#DOCUMENT_FILENAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2674957260343995489)
,p_db_column_name=>'DOC_DESCRIPTION'
,p_display_order=>40
,p_column_identifier=>'F'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2674957465872995491)
,p_db_column_name=>'DOC_SIZE'
,p_display_order=>50
,p_column_identifier=>'H'
,p_column_label=>'Size'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FILESIZE'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2674957012506995487)
,p_db_column_name=>'UPDATED'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2674957088349995488)
,p_db_column_name=>'CREATED'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2674957482910995492)
,p_db_column_name=>'DATE_CREATED'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Created On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3111811673656844271)
,p_db_column_name=>'FILE_EXTENSION'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'File Extension'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13771495377597393074)
,p_db_column_name=>'TAGS'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Tags'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16791912560114027001)
,p_db_column_name=>'IMPORTANT'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Important'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17901460816666224466)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'Added By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2676692836791588254)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8109551'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENT_FILENAME:DOC_DESCRIPTION:CREATED_BY:IMPORTANT:DOC_SIZE:UPDATED:'
,p_sort_column_1=>'IMPORTANT'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'UPDATED'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'DOC_SIZE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3103111207406911362)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3103111330958911363)
,p_button_name=>'view_tag_history'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141188585454452575388)
,p_button_image_alt=>'View Tag History'
,p_button_redirect_url=>'f?p=&APP_ID.:82:&SESSION.::&DEBUG.:RP,82:P82_ID:&P3_PROJECT_ID.'
,p_icon_css_classes=>'fa-glasses'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13843563685436314068)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(13843563578109314067)
,p_button_name=>'log'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_image_alt=>'&P3_LOG.'
,p_button_redirect_url=>'f?p=&APP_ID.:600:&SESSION.::&DEBUG.:RP,600:P600_PROJECT_ID:&P3_PROJECT_ID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16127715673601028766)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(16127715612218028765)
,p_button_name=>'view_contributor_change_history'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141188585454452575388)
,p_button_image_alt=>'View Contributor Change History'
,p_button_redirect_url=>'f?p=&APP_ID.:97:&SESSION.::&DEBUG.:RP,97:P97_PROJECT_ID:&P3_PROJECT_ID.'
,p_icon_css_classes=>'fa-glasses'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16127715915500028768)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(16127715848040028767)
,p_button_name=>'view_reviewer_change_history'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_image_alt=>'View Reviewer Change History'
,p_button_redirect_url=>'f?p=&APP_ID.:99:&SESSION.::&DEBUG.:RP,99:P99_PROJECT_ID:&P3_PROJECT_ID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2680205409963345193)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(2680203976358345179)
,p_button_name=>'add_related_project'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Related &NOMENCLATURE_PROJECT.'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11686589873395518404)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(11686589296733518398)
,p_button_name=>'add_tag'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--gapBottom'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Tags'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16127715299138028762)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(16127715224458028761)
,p_button_name=>'dates_change_history'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141188585454452575388)
,p_button_image_alt=>'View Date Change History'
,p_button_redirect_url=>'f?p=&APP_ID.:98:&SESSION.::&DEBUG.:RP,98:P98_PROJECT_ID:&P3_PROJECT_ID.'
,p_icon_css_classes=>'fa-glasses'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15460204507795438805)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(15460204658967438806)
,p_button_name=>'view_description_change_history'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141188585454452575388)
,p_button_image_alt=>'View Description Change History'
,p_button_redirect_url=>'f?p=&APP_ID.:96:&SESSION.::&DEBUG.:RP,96:P96_PROJECT_ID:&P3_PROJECT_ID.'
,p_icon_css_classes=>'fa-glasses'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(116397384012953177231)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(6237617698155791894)
,p_button_name=>'POST_COMMENT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Post Comment'
,p_warn_on_unsaved_changes=>null
,p_grid_column_css_classes=>'u-flex u-align-items-center'
,p_grid_new_row=>'Y'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(34072257149074620708)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(29300998908470733966)
,p_button_name=>'add_contributor'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Contributor'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(34510940232415773967)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(116366341004147700141)
,p_button_name=>'add_link'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Link'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4734399452284791169)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(29300998908470733966)
,p_button_name=>'About_Contributor_Roles'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141188584666839575384)
,p_button_image_alt=>'About Contributor Roles'
,p_button_redirect_url=>'f?p=&APP_ID.:67:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-info'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11980341229126612005)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(11980339719927611990)
,p_button_name=>'add_review'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Review'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12694597617764567706)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(12694596475826567695)
,p_button_name=>'unmark_as_archived'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_image_alt=>'Restore'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:52:&SESSION.::&DEBUG.:RP,52:P52_PROJECT_ID:&P3_PROJECT_ID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13681279375201015384)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(12694596410552567694)
,p_button_name=>'view_Duplicate'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_image_alt=>'View Primary'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:P3_PROJECT_ID:&P3_DUP_PROJECT_ID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12694597439020567704)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(12694596410552567694)
,p_button_name=>'unmark_as_duplidate'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_image_alt=>'Not a Duplicate'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.:50:P50_PROJECT_ID:&P3_PROJECT_ID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13771495910889393079)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(32981495930878811205)
,p_button_name=>'edit_description'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141188585454452575388)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Edit'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:RP,32:P32_ID:&P3_PROJECT_ID.'
,p_icon_css_classes=>'fa-edit'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16209833202164525885)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(16160177181524074743)
,p_button_name=>'add_activity'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight:t-Button--padLeft:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(141188585454452575388)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Activity'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:101:&SESSION.::&DEBUG.:RP,101:P101_PROJECT_ID:&P3_PROJECT_ID.'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3111811081661844265)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(116366342790322700159)
,p_button_name=>'view_images'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_image_alt=>'Image Gallery'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:29:P29_PROJECT_ID:&P3_PROJECT_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 ',
'  from SP_PROJECT_DOCUMENTS d',
' where project_id = :P3_PROJECT_ID and ',
'       (',
'           lower(DOCUMENT_FILENAME) like ''%.png'' or ',
'           lower(DOCUMENT_FILENAME) like ''%.jpg'' or ',
'           lower(DOCUMENT_FILENAME) like ''%.jpeg'' or ',
'           lower(DOCUMENT_FILENAME) like ''%.gif'' or ',
'           lower(DOCUMENT_FILENAME) like ''%.tiff'' or ',
'           lower(DOCUMENT_FILENAME) like ''%.ai'' ',
'       )'))
,p_button_condition_type=>'EXISTS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(116366344332279700174)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(116366342790322700159)
,p_button_name=>'add_document'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(141188585454452575388)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Document'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:RR,12:P12_PROJECT_ID:&P3_PROJECT_ID.'
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(34494957050251716424)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8889265986795394743)
,p_button_name=>'UP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141188584666839575384)
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:&LAST_PROJECT_VIEW.:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1898568012186064537)
,p_name=>'P3_INCLUDE_FUTURE'
,p_item_sequence=>23
,p_item_plug_id=>wwv_flow_imp.id(16209832933325525882)
,p_item_default=>'Y'
,p_prompt=>'Include Future'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(141188584476664575383)
,p_item_template_options=>'#DEFAULT#:margin-left-sm'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2680205306157345192)
,p_name=>'P3_RELATED_PROJECT_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(2680203976358345179)
,p_prompt=>'Add Related &NOMENCLATURE_PROJECT.'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select (select focus_area from sp_focus_areas f where f.id = i.focus_area_id)||',
'       '' / ''||i.initiative ||',
'       '' / ''||p.project project, ',
'       p.id',
'from   sp_projects p,',
'       sp_initiatives i ',
'where  p.id != :P3_PROJECT_ID and',
'       p.id not in (',
'       select r.related_project_id ',
'       from   sp_project_related r ',
'       where  r.project_id = :P3_PROJECT_ID and r.related_project_id is not null) and',
'       p.initiative_id = i.id and  ',
'       p.ARCHIVED_YN = ''N''',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_grid_row_css_classes=>'u-align-items-center'
,p_field_template=>wwv_flow_imp.id(141188584476664575383)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2901863679500683303)
,p_name=>'P3_REVIEW_CONTRIBUTOR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(11980339719927611990)
,p_item_default=>'return sp_strategic_proj_util.get_user_id (:APP_USER);'
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Reviewer'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'SP_TEAM_MEMBERS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select last_name||'', ''||first_name||'' (''||lower(email)||'')'' d, id r',
'from SP_TEAM_MEMBERS',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- select User  -'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(141188584476664575383)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'2'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3589824267169495383)
,p_name=>'P3_INCLUDE_PAST'
,p_item_sequence=>33
,p_item_plug_id=>wwv_flow_imp.id(16209832933325525882)
,p_item_default=>'Y'
,p_prompt=>'Include Past'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(141188584476664575383)
,p_item_template_options=>'#DEFAULT#:margin-left-sm'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3973712454099858667)
,p_name=>'P3_USER_ID'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(8889265986795394743)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5363761279340880707)
,p_name=>'P3_PRIVATE_YN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(6237617698155791894)
,p_item_default=>'N'
,p_prompt=>'This is a private comment'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(141188582371029575375)
,p_item_template_options=>'#DEFAULT#:margin-left-md'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7627055303811961989)
,p_name=>'P3_CONTRIBUTORS_EMAIL'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(8889265986795394743)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7627055631871961992)
,p_name=>'P3_EMAIL_BODY'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(8889265986795394743)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11686589656825518401)
,p_name=>'P3_ADD_TAG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(11686589296733518398)
,p_prompt=>'Add Tags'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_row_css_classes=>'u-align-items-center'
,p_field_template=>wwv_flow_imp.id(141188584476664575383)
,p_item_template_options=>'#DEFAULT#'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_show_quick_picks=>'Y'
,p_quick_pick_label_01=>'&P3_T1.'
,p_quick_pick_value_01=>'&P3_T1.'
,p_quick_pick_label_02=>'&P3_T2.'
,p_quick_pick_value_02=>'&P3_T2.'
,p_quick_pick_label_03=>'&P3_T3.'
,p_quick_pick_value_03=>'&P3_T3.'
,p_quick_pick_label_04=>'&P3_T4.'
,p_quick_pick_value_04=>'&P3_T4.'
,p_quick_pick_label_05=>'&P3_T5.'
,p_quick_pick_value_05=>'&P3_T5.'
,p_quick_pick_label_06=>'&P3_T6.'
,p_quick_pick_value_06=>'&P3_T6.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11893716708370452561)
,p_name=>'P3_T1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(11686589296733518398)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11893716841850452562)
,p_name=>'P3_T2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(11686589296733518398)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11893716947904452563)
,p_name=>'P3_T3'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(11686589296733518398)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11893717003248452564)
,p_name=>'P3_T4'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(11686589296733518398)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11893717133526452565)
,p_name=>'P3_T5'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(11686589296733518398)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11893717263727452566)
,p_name=>'P3_T6'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(11686589296733518398)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12195306199716928165)
,p_name=>'P3_REVIEW_TYPE_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(11980339719927611990)
,p_prompt=>'Review Type'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select review_type, id',
'from sp_project_review_types',
'where include_yn = ''Y''',
'order by display_seq'))
,p_cHeight=>1
,p_grid_row_css_classes=>'u-align-items-center'
,p_field_template=>wwv_flow_imp.id(141188584476664575383)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13681279093934015381)
,p_name=>'P3_DUP_PROJECT'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(8889265986795394743)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13681279483816015385)
,p_name=>'P3_DUP_PROJECT_ID'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(8889265986795394743)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13771494357504393063)
,p_name=>'FI'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(8889265986795394743)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
,p_item_comment=>'friendly identifier'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13771494703206393067)
,p_name=>'PN'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(8889265986795394743)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13843563243899314063)
,p_name=>'P3_LOG'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(8889265986795394743)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16560922111669055284)
,p_name=>'P3_LINK_NAME'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(116366341004147700141)
,p_prompt=>'Link Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(141188583993679575382)
,p_item_template_options=>'#DEFAULT#'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32181101043133407491)
,p_name=>'P3_TAG_TO_REMOVE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(11686589296733518398)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33179043464670178195)
,p_name=>'P3_PROJECT_NAME'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(8889265986795394743)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33343642578466563428)
,p_name=>'P3_HAS_VOTED_CLASS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8889265986795394743)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33710322479550165879)
,p_name=>'P3_CONTRIBUTOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(29300998908470733966)
,p_item_default=>'return sp_strategic_proj_util.get_user_id (:APP_USER);'
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Add Contributor'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'SP_TEAM_MEMBERS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select last_name||'', ''||first_name||'' (''||lower(email)||'')'' d, id r',
'from SP_TEAM_MEMBERS',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- select User  -'
,p_cSize=>30
,p_grid_row_css_classes=>'u-align-items-center'
,p_field_template=>wwv_flow_imp.id(141188584476664575383)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'2'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33710322602295165880)
,p_name=>'P3_CONTRIBUTOR_ROLE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(29300998908470733966)
,p_item_default=>'select max(id) from SP_RESOURCE_TYPES where IS_DEFAULT_YN = ''Y'''
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Role'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select RESOURCE_TYPE, id',
'from SP_RESOURCE_TYPES',
'order by 1'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(141188584476664575383)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(34510940140471773966)
,p_name=>'P3_LINK'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(116366341004147700141)
,p_prompt=>'Link URL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(141188583993679575382)
,p_item_template_options=>'#DEFAULT#'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(113820667628121284076)
,p_name=>'P3_PROJECT_ID'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(8889265986795394743)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(116397383885700177230)
,p_name=>'P3_COMMENT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6237617698155791894)
,p_prompt=>' Comment'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(141188582371029575375)
,p_item_template_options=>'#DEFAULT#'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* JS Init Function for Comments Rich Text Editor */',
'function( options ) {',
'    options.editorOptions.paste_data_images = false;',
'    return options;',
'}'))
,p_attribute_01=>'MARKDOWN'
,p_attribute_04=>'180'
,p_attribute_25=>'TINYMCE'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(7627055682762961993)
,p_computation_sequence=>30
,p_computation_item=>'P3_EMAIL_BODY'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    x varchar2(4000) := null;',
'    i int;',
'begin',
'for c1 in (',
'    select FRIENDLY_IDENTIFIER',
'    from   SP_PROJECTS',
'    where  id = :P3_PROJECT_ID) loop',
'    x := APEX_MAIL.GET_INSTANCE_URL;',
'    i := instr(x,''/'',1,3); -- find third slash',
'    x := substr(x,1,i-1);  -- url domain',
'    x := x||APEX_PAGE.GET_URL(',
'        p_application => :APP_ID,',
'        p_page => :APP_PAGE_ID,',
'        p_items => ''fi'',',
'        p_values => c1.FRIENDLY_IDENTIFIER); -- full url',
'end loop;',
'return x; ',
'end;',
'',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13771494397973393064)
,p_computation_sequence=>1
,p_computation_item=>'P3_PROJECT_ID'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return sp_strategic_proj_util.get_project_id (',
'    p_friendly_identifier => :FI,',
'    p_project_url_name => :PN);'))
,p_compute_when=>'P3_PROJECT_ID'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(33179043496359178196)
,p_computation_sequence=>70
,p_computation_item=>'P3_PROJECT_NAME'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>'select project from sp_projects where id = :P3_project_id'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13681279215652015382)
,p_computation_sequence=>110
,p_computation_item=>'P3_DUP_PROJECT'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select (select b.project from sp_projects b where b.id = a.DUPLICATE_OF_PROJECT_ID) project',
'from sp_projects a',
'where a.id = :P3_PROJECT_ID'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13681279666534015386)
,p_computation_sequence=>120
,p_computation_item=>'P3_DUP_PROJECT_ID'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DUPLICATE_OF_PROJECT_ID',
'from sp_projects',
'where id = :P3_PROJECT_ID'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(7627055421735961990)
,p_computation_sequence=>130
,p_computation_item=>'P3_CONTRIBUTORS_EMAIL'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    x varchar2(32767) := null;',
'    l_contributors_found boolean := false;',
'begin',
'--',
'-- locate contributors',
'--',
'for c1 in (',
'    select lower(t.email) email',
'    from SP_PROJECT_CONTRIBUTORS c, SP_TEAM_MEMBERS t',
'    where c.project_id = :P3_PROJECT_ID and ',
'          c.TEAM_MEMBER_ID = t.id',
'    order by 1) loop',
'    x := x||c1.email||'','';',
'    l_contributors_found := true;',
'end loop;',
'--',
'-- if no contributors find owner',
'--',
'if not l_contributors_found then',
'   for c1 in (',
'       select  t.email',
'       from    SP_PROJECTS P, SP_TEAM_MEMBERS t',
'       where   p.id = :P3_PROJECT_ID and  ',
'               p.OWNER_ID = t.id) loop ',
'       x := x||c1.email||'','';',
'       l_contributors_found := true;',
'   end loop;',
'end if;',
'--',
'-- if no owner leverage user',
'--',
'if not l_contributors_found then',
'   x := lower(:APP_USER);',
'end if;',
'x := rtrim(x,'','');',
'return x;',
'end;'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13843563283801314064)
,p_computation_sequence=>140
,p_computation_item=>'P3_LOG'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>'return sp_log.log_and_summarize(:P3_PROJECT_ID);'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(1932491771314180283)
,p_computation_sequence=>160
,p_computation_item=>'P3_INCLUDE_FUTURE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'Y'
,p_compute_when=>'P3_INCLUDE_FUTURE'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(3973712554023858668)
,p_computation_sequence=>170
,p_computation_item=>'P3_USER_ID'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>'select id from sp_team_members where email = lower(:APP_USER)'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(116397384153453177232)
,p_name=>'Post Comment'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(116397384012953177231)
,p_condition_element=>'P3_COMMENT'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(116397384162601177233)
,p_event_id=>wwv_flow_imp.id(116397384153453177232)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- add comment',
'',
'sp_strategic_proj_util.add_project_comment (',
'    p_app_user      => :APP_USER,',
'    p_comment       => :P3_COMMENT,',
'    p_project_id    => :P3_PROJECT_ID,',
'    p_comment_on    => ''PROJECT'',',
'    p_component_id  => null,',
'    p_private_yn    => nvl(:P3_PRIVATE_YN,''N''));',
'',
'',
'-- reset comment',
':P3_COMMENT := null;'))
,p_attribute_02=>'P3_COMMENT,P3_PRIVATE_YN'
,p_attribute_03=>'P3_COMMENT'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(116397384345514177234)
,p_event_id=>wwv_flow_imp.id(116397384153453177232)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(107826484215093920055)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(116366342632675700157)
,p_name=>'rpt dialog close'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(116366341004147700141)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(116366342695654700158)
,p_event_id=>wwv_flow_imp.id(116366342632675700157)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(116366341004147700141)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(116366344472065700176)
,p_name=>'doc refresh dialog close'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(116366342790322700159)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(116912785171822285427)
,p_event_id=>wwv_flow_imp.id(116366344472065700176)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(116366342790322700159)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(34072257259237620709)
,p_name=>'add contributor'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(34072257149074620708)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34072257349398620710)
,p_event_id=>wwv_flow_imp.id(34072257259237620709)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'   c int := 0;',
'begin',
'   select count(*) into c from SP_PROJECT_CONTRIBUTORS where project_id = :P3_PROJECT_ID and TEAM_MEMBER_ID = :P3_CONTRIBUTOR;',
'   if c = 0 then ',
'      insert into SP_PROJECT_CONTRIBUTORS',
'      (PROJECT_ID, TEAM_MEMBER_ID, RESPONSIBILITY_ID)',
'      values',
'      (:P3_PROJECT_ID, :P3_CONTRIBUTOR, :P3_CONTRIBUTOR_ROLE);',
'   end if;',
'',
'   :P3_CONTRIBUTOR := null;',
'   for c1 in (select max(id) id from SP_RESOURCE_TYPES where IS_DEFAULT_YN = ''Y'') loop',
'       :P3_CONTRIBUTOR_ROLE := c1.id;',
'   end loop;',
'end;'))
,p_attribute_02=>'P3_PROJECT_ID,P3_CONTRIBUTOR,P3_CONTRIBUTOR_ROLE'
,p_attribute_03=>'P3_CONTRIBUTOR,P3_CONTRIBUTOR_ROLE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34510939804275773963)
,p_event_id=>wwv_flow_imp.id(34072257259237620709)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(29300998908470733966)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(34510940293495773968)
,p_name=>'add link'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(34510940232415773967)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16791909235934026968)
,p_event_id=>wwv_flow_imp.id(34510940293495773968)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Please supply a Link URL and a Link Name.'
,p_attribute_02=>'Missing Link Details'
,p_client_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_client_condition_expression=>'$v(''P3_LINK'') === '''' || $v(''P3_LINK_NAME'') === '''''
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34510940383025773969)
,p_event_id=>wwv_flow_imp.id(34510940293495773968)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P3_LINK_NAME is not null and :P3_LINK is not null',
'then sp_strategic_proj_util.add_project_link (',
'         p_project_id    => :P3_PROJECT_ID,',
'         p_link_name     => :P3_LINK_NAME,',
'         p_link_url      => :P3_LINK );',
'    :P3_LINK_NAME := null;',
'    :P3_LINK := null;',
'end if;'))
,p_attribute_02=>'P3_LINK_NAME,P3_LINK,P3_PROJECT_ID'
,p_attribute_03=>'P3_LINK,P3_LINK_NAME'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34510940562583773970)
,p_event_id=>wwv_flow_imp.id(34510940293495773968)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(116366341004147700141)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(34510941250094773977)
,p_name=>'refresh cont'
,p_event_sequence=>110
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(29300998908470733966)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34510941283598773978)
,p_event_id=>wwv_flow_imp.id(34510941250094773977)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(29300998908470733966)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(34540015662842437289)
,p_name=>'doc refresh on dialog close'
,p_event_sequence=>120
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(116366342790322700159)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34540015760109437290)
,p_event_id=>wwv_flow_imp.id(34540015662842437289)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(116366342790322700159)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1932026828289876399)
,p_name=>'refresh on dialog close'
,p_event_sequence=>130
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(107826484215093920055)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1932026946640876400)
,p_event_id=>wwv_flow_imp.id(1932026828289876399)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(107826484215093920055)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6468144133922796782)
,p_name=>'add related'
,p_event_sequence=>140
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(2680205409963345193)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6468144194436796783)
,p_event_id=>wwv_flow_imp.id(6468144133922796782)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_strategic_proj_util.add_related_project (',
'    p_related_project_id => :P3_RELATED_PROJECT_ID,',
'    p_project_id => :P3_PROJECT_ID',
');',
':P3_RELATED_PROJECT_ID := null;'))
,p_attribute_02=>'P3_RELATED_PROJECT_ID,P3_PROJECT_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6468145849416796799)
,p_event_id=>wwv_flow_imp.id(6468144133922796782)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_RELATED_PROJECT_ID'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6468144352830796784)
,p_event_id=>wwv_flow_imp.id(6468144133922796782)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2680203976358345179)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6468144588511796787)
,p_name=>'refresh related'
,p_event_sequence=>150
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(2680203976358345179)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6468144696654796788)
,p_event_id=>wwv_flow_imp.id(6468144588511796787)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2680203976358345179)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11686590001521518405)
,p_name=>'Add Tag'
,p_event_sequence=>160
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(11686589873395518404)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11686590107701518406)
,p_event_id=>wwv_flow_imp.id(11686590001521518405)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_strategic_proj_util.add_project_tag (',
'    p_project_id => :P3_PROJECT_ID,',
'    p_tag => :P3_ADD_TAG);',
':P3_ADD_TAG := null;'))
,p_attribute_02=>'P3_PROJECT_ID,P3_ADD_TAG'
,p_attribute_03=>'P3_ADD_TAG'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11686590271982518408)
,p_event_id=>wwv_flow_imp.id(11686590001521518405)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'clear new tag'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_ADD_TAG'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11686590190923518407)
,p_event_id=>wwv_flow_imp.id(11686590001521518405)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11686589296733518398)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(32181100865424407489)
,p_name=>'Remove Tag'
,p_event_sequence=>170
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.js-remove-tag'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(32181100966225407490)
,p_event_id=>wwv_flow_imp.id(32181100865424407489)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_TAG_TO_REMOVE'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).data(''tag'');'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(32181101129306407492)
,p_event_id=>wwv_flow_imp.id(32181100865424407489)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_strategic_proj_util.remove_project_tag (',
'    p_project_id => :P3_PROJECT_ID, ',
'    p_tag => :P3_TAG_TO_REMOVE);',
':P3_TAG_TO_REMOVE := null;'))
,p_attribute_02=>'P3_PROJECT_ID,P3_TAG_TO_REMOVE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(32181101197616407493)
,p_event_id=>wwv_flow_imp.id(32181100865424407489)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11686589296733518398)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11980340770332612001)
,p_name=>'review dc'
,p_event_sequence=>180
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(11980339719927611990)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11980340943011612002)
,p_event_id=>wwv_flow_imp.id(11980340770332612001)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(13981513608171038899)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14214546806950461691)
,p_event_id=>wwv_flow_imp.id(11980340770332612001)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(13981513696471038900)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12195306300011928166)
,p_name=>'add review DA'
,p_event_sequence=>190
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(11980341229126612005)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12195306499352928168)
,p_event_id=>wwv_flow_imp.id(12195306300011928166)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into sp_project_reviews (',
'    project_id,',
'    review_type_id,',
'    owner_id ',
'    ) values (',
'    :P3_PROJECT_ID,',
'    :P3_REVIEW_TYPE_ID,   ',
'    :P3_REVIEW_CONTRIBUTOR);',
':P3_REVIEW_CONTRIBUTOR := null;',
':P3_REVIEW_TYPE_ID := null;'))
,p_attribute_02=>'P3_REVIEW_TYPE_ID,P3_PROJECT_ID,P3_REVIEW_CONTRIBUTOR'
,p_attribute_03=>'P3_REVIEW_TYPE_ID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12195306412357928167)
,p_event_id=>wwv_flow_imp.id(12195306300011928166)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(13981513696471038900)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16209832970413525883)
,p_name=>'show future activity da'
,p_event_sequence=>200
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_INCLUDE_FUTURE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16209833470738525888)
,p_event_id=>wwv_flow_imp.id(16209832970413525883)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P3_INCLUDE_FUTURE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16209833111983525884)
,p_event_id=>wwv_flow_imp.id(16209832970413525883)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(16160177181524074743)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16209834468464525897)
,p_name=>'refresh on date dialog closed'
,p_event_sequence=>220
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(16127715224458028761)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16209834505790525898)
,p_event_id=>wwv_flow_imp.id(16209834468464525897)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5410620474233899472)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16209834655979525899)
,p_name=>'show activity on dc on add'
,p_event_sequence=>230
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(16209833202164525885)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16209834669137525900)
,p_event_id=>wwv_flow_imp.id(16209834655979525899)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(16160177181524074743)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16209834849032525901)
,p_name=>'refresh description'
,p_event_sequence=>240
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(13771495910889393079)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16209834923863525902)
,p_event_id=>wwv_flow_imp.id(16209834849032525901)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(15460204658967438806)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(16209835147923525904)
,p_name=>'refresh activity rpt on dc'
,p_event_sequence=>250
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(16160177181524074743)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16209835191362525905)
,p_event_id=>wwv_flow_imp.id(16209835147923525904)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(16160177181524074743)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1932491281735180278)
,p_name=>'edit description dialog closed'
,p_event_sequence=>260
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(15460204658967438806)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1932491393936180279)
,p_event_id=>wwv_flow_imp.id(1932491281735180278)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(32981495930878811205)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3958004716606535471)
,p_name=>'show past activity'
,p_event_sequence=>270
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_INCLUDE_PAST'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3958004833472535472)
,p_event_id=>wwv_flow_imp.id(3958004716606535471)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P3_INCLUDE_PAST,P3_INCLUDE_FUTURE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3958004960040535473)
,p_event_id=>wwv_flow_imp.id(3958004716606535471)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(16160177181524074743)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3973712593604858669)
,p_name=>'refresh on change bc'
,p_event_sequence=>280
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(33343640385626563406)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3973712755768858670)
,p_event_id=>wwv_flow_imp.id(3973712593604858669)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(33343640385626563406)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4308641172424960505)
,p_event_id=>wwv_flow_imp.id(3973712593604858669)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8889265986795394743)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4308641285539960506)
,p_event_id=>wwv_flow_imp.id(3973712593604858669)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(11686589296733518398)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4308641413153960507)
,p_event_id=>wwv_flow_imp.id(3973712593604858669)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5410620474233899472)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3973714827389858691)
,p_name=>'refresh dates region on dialog close'
,p_event_sequence=>290
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(5410620474233899472)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3973714871385858692)
,p_event_id=>wwv_flow_imp.id(3973714827389858691)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5410620474233899472)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4165871247888541793)
,p_name=>'on edit description dialog close'
,p_event_sequence=>300
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(32981495930878811205)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4165871341510541794)
,p_event_id=>wwv_flow_imp.id(4165871247888541793)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(32981495930878811205)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4247965602888071971)
,p_name=>'refresh on dialog closed bc'
,p_event_sequence=>310
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(8889265986795394743)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4247965756392071972)
,p_event_id=>wwv_flow_imp.id(4247965602888071971)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8889265986795394743)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4734400993221791185)
,p_event_id=>wwv_flow_imp.id(4247965602888071971)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(33343640385626563406)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7342112094205893065)
,p_event_id=>wwv_flow_imp.id(4247965602888071971)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5410620474233899472)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14214544740386461670)
,p_event_id=>wwv_flow_imp.id(4247965602888071971)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(13981513608171038899)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(14214546359087461686)
,p_name=>'refresh on dialog closed reviews'
,p_event_sequence=>320
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(13981513696471038900)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14214546370025461687)
,p_event_id=>wwv_flow_imp.id(14214546359087461686)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(13981513696471038900)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11893717304355452567)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'get default tags'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_strategic_proj_util.get_default_tags (',
'    p_tag_1      => :P3_T1,',
'    p_tag_2      => :P3_T2,',
'    p_tag_3      => :P3_T3,',
'    p_tag_4      => :P3_T4,',
'    p_tag_5      => :P3_T5,',
'    p_tag_6      => :P3_T6',
');'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>10027979535472807107
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(5896263489389086557)
,p_region_id=>wwv_flow_imp.id(9753609341828409561)
,p_position_id=>wwv_flow_imp.id(3717637195828652804)
,p_display_sequence=>10
,p_template_id=>wwv_flow_imp.id(3717637797505683933)
,p_label=>'Edit'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:RP,24:P24_ID:&P3_PROJECT_ID.'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-edit'
,p_is_hot=>true
,p_show_as_disabled=>false
,p_authorization_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(7334532861314631601)
,p_region_id=>wwv_flow_imp.id(16160177181524074743)
,p_position_id=>wwv_flow_imp.id(3704044168831277200)
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:140:&SESSION.::&DEBUG.:RP,140:P140_ID:&ID.'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(9753609642407409564)
,p_region_id=>wwv_flow_imp.id(9753609341828409561)
,p_position_id=>wwv_flow_imp.id(3717637195828652804)
,p_display_sequence=>20
,p_template_id=>wwv_flow_imp.id(3717639057025688081)
,p_label=>'Actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(16160179339966074764)
,p_region_id=>wwv_flow_imp.id(16160177181524074743)
,p_position_id=>wwv_flow_imp.id(3717637195828652804)
,p_display_sequence=>20
,p_template_id=>wwv_flow_imp.id(3717639057025688081)
,p_label=>'Actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_action_css_classes=>'t-Button--noUI'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(2995067312392550376)
,p_component_action_id=>wwv_flow_imp.id(16160179339966074764)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Activity Quick Look'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:140:&SESSION.::&DEBUG.:RP,140:P140_ID:&ID.'
,p_icon_css_classes=>'fa-badge-check'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(4247965868775071973)
,p_component_action_id=>wwv_flow_imp.id(9753609642407409564)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Clone'
,p_display_sequence=>40
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:RP,33:P33_PROJECT_ID:&P3_PROJECT_ID.'
,p_icon_css_classes=>'fa-clone'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(4247965879153071974)
,p_component_action_id=>wwv_flow_imp.id(9753609642407409564)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Archive'
,p_display_sequence=>60
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:47:&SESSION.::&DEBUG.:RP,47:P47_PROJECT_ID:&P3_PROJECT_ID.'
,p_icon_css_classes=>'fa-remove'
,p_condition_type=>'EXISTS'
,p_condition_expr1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ARCHIVED_YN ',
'  from sp_projects ',
' where id = :P3_PROJECT_ID',
'   and ARCHIVED_YN = ''N'''))
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(4247965979601071975)
,p_component_action_id=>wwv_flow_imp.id(9753609642407409564)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Mark as Duplicate'
,p_display_sequence=>50
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:49:&SESSION.::&DEBUG.:RP,49:P49_PROJECT_ID:&P3_PROJECT_ID.'
,p_icon_css_classes=>'fa-copy'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(4247966140790071976)
,p_component_action_id=>wwv_flow_imp.id(9753609642407409564)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Add Users from Comments'
,p_display_sequence=>80
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:57:&SESSION.::&DEBUG.:57:P57_PROJECT_ID:&P3_PROJECT_ID.'
,p_icon_css_classes=>'fa-user-plus'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(4247966258488071977)
,p_component_action_id=>wwv_flow_imp.id(9753609642407409564)
,p_menu_entry_type=>'SEPARATOR'
,p_display_sequence=>120
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(4247966269538071978)
,p_component_action_id=>wwv_flow_imp.id(9753609642407409564)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Map Contributors'
,p_display_sequence=>100
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:56:&SESSION.::&DEBUG.:RP,56:P56_PROJECT_ID:&P3_PROJECT_ID.'
,p_icon_css_classes=>'fa-users'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(4247966419319071979)
,p_component_action_id=>wwv_flow_imp.id(9753609642407409564)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Email Contributors'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:RP,15:P15_PROJECT_ID:&P3_PROJECT_ID.'
,p_icon_css_classes=>'fa-envelope-o'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(5611504661619449629)
,p_component_action_id=>wwv_flow_imp.id(9753609642407409564)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Reset'
,p_display_sequence=>140
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RR,3:PN,FI:&PN.,&FI.'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(5680514757668066141)
,p_component_action_id=>wwv_flow_imp.id(9753609642407409564)
,p_menu_entry_type=>'ENTRY'
,p_label=>'View History'
,p_display_sequence=>110
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:64:&SESSION.::&DEBUG.:RP,64:P64_PROJECT_ID:&P3_PROJECT_ID.'
,p_icon_css_classes=>'fa-clock-o'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(6366800550637162351)
,p_component_action_id=>wwv_flow_imp.id(9753609642407409564)
,p_menu_entry_type=>'SEPARATOR'
,p_display_sequence=>70
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(7464041002555324369)
,p_component_action_id=>wwv_flow_imp.id(9753609642407409564)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Links'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:93:&SESSION.::&DEBUG.:RP,93:P93_ID:&P3_PROJECT_ID.'
,p_icon_css_classes=>'fa-external-link'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(7464044077774324400)
,p_component_action_id=>wwv_flow_imp.id(9753609642407409564)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Add Links from Comments'
,p_display_sequence=>90
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:31:P31_ID:&P3_PROJECT_ID.'
,p_icon_css_classes=>'fa-external-link'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(9753610348314409571)
,p_component_action_id=>wwv_flow_imp.id(9753609642407409564)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Refresh'
,p_display_sequence=>130
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(16160179402451074765)
,p_component_action_id=>wwv_flow_imp.id(16160179339966074764)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Edit Activity'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:101:&SESSION.::&DEBUG.:RP,101:P101_ID:&ID.'
,p_icon_css_classes=>'fa-edit'
,p_authorization_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp.component_end;
end;
/
