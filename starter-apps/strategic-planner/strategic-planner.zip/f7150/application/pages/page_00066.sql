prompt --application/pages/page_00066
begin
--   Manifest
--     PAGE: 00066
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>66
,p_name=>'&P66_AREA. &NOMENCLATURE_INITIATIVES.'
,p_alias=>'AREA-INITIATIVES'
,p_step_title=>'&P66_AREA. &NOMENCLATURE_INITIATIVES.'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-CardView-actions {--a-cv-actions-padding-x: 8px;--a-cv-actions-padding-y: 8px;--a-cv-actions-background-color: transparent;}',
'',
'.no-item-ui {',
'    --a-field-input-border-width: 0;',
'    --a-field-input-background-color: transparent;',
'}',
'.a-CardView-iconWrap { align-self: flex-start; }',
''))
,p_step_template=>wwv_flow_imp.id(141188318576040575203)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'22'
,p_last_updated_by=>'SBKENNED'
,p_last_upd_yyyymmddhh24miss=>'20240411133800'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4567070861724075590)
,p_plug_name=>'Faceted Search'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188351742057575241)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(7243549549520045079)
,p_attribute_01=>'N'
,p_attribute_06=>'E'
,p_attribute_08=>'#active_facets'
,p_attribute_09=>'N'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4567071492356075597)
,p_plug_name=>'About'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:t-Region--scrollBody:margin-left-lg'
,p_plug_template=>wwv_flow_imp.id(141188484312500575273)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4567071786369075600)
,p_plug_name=>'Sort Container'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(141188501912119575289)
,p_plug_display_sequence=>2
,p_plug_source=>'<div id="active_facets"></div>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7243549549520045079)
,p_plug_name=>'&NOMENCLATURE_INITIATIVES.'
,p_region_css_classes=>'clear-avatar-icons'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(141188484312500575273)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select i.ID,',
'       ''No'' Favorite,',
'       i.FOCUS_AREA_ID,',
'       i.INITIATIVE,',
'       --',
'       -- shortened objective',
'       --',
'       decode(i.objective,null,''No description provided'',substr(i.OBJECTIVE,1,100)||decode(greatest(length(i.objective),100),100,null,''...'')) OBJECTIVE,',
'       --',
'       -- owner',
'       --',
'       nvl(tm.first_name||'' ''||tm.last_name,''Unknown'') SPONSOR,',
'       tm.id sponsor_id,',
'       --',
'       -- dates',
'       --',
'       i.CREATED,',
'       i.CREATED_BY,',
'       greatest(i.updated,nvl((select max(updated) from sp_projects p where p.initiative_id = i.id and ARCHIVED_YN = ''N''),i.updated)) updated,',
'       --',
'       -- projects',
'       --',
'       (select count(*) ',
'        from sp_projects p ',
'        where p.initiative_id = i.id and ',
'              p.ARCHIVED_YN = ''N'' and ',
'              p.DUPLICATE_OF_PROJECT_ID is null ) projects,',
'       --',
'       -- open projects',
'       --',
'       (select count(*) ',
'        from sp_projects p ',
'        where p.initiative_id = i.id and ',
'              p.ARCHIVED_YN = ''N'' and ',
'              p.pct_complete != 0 and ',
'              p.pct_complete != 100 and',
'              p.DUPLICATE_OF_PROJECT_ID is null ) open_projects,',
'       f.focus_area,',
'       to_char(i.created,''YYYY.MM'') created_month,',
'       to_char(i.updated,''YYYY.MM'') updated_month,',
'       nvl((select scale_name from sp_project_scales where scale_letter = nvl(i.status_scale,''A'')),i.status_scale) status_scale,',
'       --',
'       -- activities',
'       --',
'       (select count(*) ',
'        from sp_activities ap ',
'        where ap.initiative_id = i.id) initiative_activities,',
'       --',
'       -- image',
'       --',
'       i.image,',
'       i.image_mimetype,',
'       i.image_name, ',
'       i.image_last_updated,',
'       --',
'       -- other',
'       --',
'       i.tags,',
'       decode(nvl(i.hidden_by_default_yn,''N''),''Y'',''Hidden'',''N'',''Visible'',''Visible'') hidden_by_default',
'  from SP_INITIATIVES i, ',
'       sp_focus_areas f,',
'       sp_team_members tm',
'  where i.focus_area_id = f.id and',
'        f.id = :P66_AREA_ID and',
'        i.sponsor_id = tm.id(+)'))
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{"orderBys":[{"key":"INITIATIVE","expr":"initiative"},{"key":"UPDATED","expr":"updated desc"},{"key":"CREATED","expr":"created desc"},{"key":"PROJECTS","expr":"projects desc"},{"key":"OPEN_PROJECTS","expr":"open_projects desc"}],"itemName":"P66_ORDER'
||'_BY"}'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_ajax_items_to_submit=>'P66_AREA_ID'
,p_plug_query_num_rows=>20
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_string.join_clob(wwv_flow_t_varchar2('{',
  '"TITLE": "\u0026INITIATIVE.",',
  '"DESCRIPTION": "\u0026NOMENCLATURE_AREA.: \u003Cstrong\u003E\u0026FOCUS_AREA.\u003C\/strong\u003E\u003Cbr\u003E\n\u0026NOMENCLATURE_PROJECTS.: \u003Cstrong\u003E\u0026PROJECTS.\u003C\/strong\u003E, with \u0026OPEN_PROJECTS. open\u003Cbr\u003E\n\u0026NOMENCLATURE_INITIATIVE. Activities: \u003Cstrong\u003E\u0026INITIATIVE_ACTIVITIES.\u003Cbr\u003E\n\u003C\/strong\u003E\u0026OBJECTIVE.",',
  '"MISC": "\u0026SPONSOR.",',
  '"DISPLAY_AVATAR": "Y",',
  '"DISPLAY_BADGE": "N",',
  '"AVATAR_TYPE": "image",',
  '"AVATAR_IMAGE": "{\"source\":\"BLOB_COLUMN\",\"blobColumn\":\"IMAGE\",\"filenameColumn\":\"IMAGE_NAME\",\"mimeTypeColumn\":\"IMAGE_MIMETYPE\",\"lastUpdatedColumn\":\"IMAGE_LAST_UPDATED\"}",',
  '"AVATAR_DESCRIPTION": "\u0026NOMENCLATURE_INITIATIVE. Icon",',
  '"AVATAR_SHAPE": "t-Avatar--rounded",',
  '"AVATAR_SIZE": "t-Avatar--md",',
  '"APPLY_THEME_COLORS": "Y",',
  '"HIDE_BORDERS": "N",',
  '"REMOVE_PADDING": "N"',
'}'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7243550163507045085)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7243550207976045086)
,p_name=>'FAVORITE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FAVORITE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7243550317008045087)
,p_name=>'FOCUS_AREA_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FOCUS_AREA_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7243550467475045088)
,p_name=>'INITIATIVE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INITIATIVE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7243550582737045090)
,p_name=>'OBJECTIVE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OBJECTIVE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7243550692918045091)
,p_name=>'SPONSOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SPONSOR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>70
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7243550857785045092)
,p_name=>'CREATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7243550929231045093)
,p_name=>'CREATED_BY'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_BY'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7243551057485045094)
,p_name=>'UPDATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UPDATED'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>100
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7243551431840045098)
,p_name=>'PROJECTS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROJECTS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>140
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7243551510265045099)
,p_name=>'FOCUS_AREA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FOCUS_AREA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>160
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7243551653755045100)
,p_name=>'CREATED_MONTH'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_MONTH'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>170
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7243551703510045101)
,p_name=>'UPDATED_MONTH'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UPDATED_MONTH'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>180
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7243551839167045102)
,p_name=>'STATUS_SCALE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS_SCALE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>190
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7243551871197045103)
,p_name=>'INITIATIVE_ACTIVITIES'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INITIATIVE_ACTIVITIES'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>200
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7243552047473045104)
,p_name=>'TAGS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TAGS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>210
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7243552107851045105)
,p_name=>'HIDDEN_BY_DEFAULT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'HIDDEN_BY_DEFAULT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>220
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7342115532065893099)
,p_name=>'IMAGE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IMAGE'
,p_data_type=>'BLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>270
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7342115593872893100)
,p_name=>'IMAGE_MIMETYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IMAGE_MIMETYPE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>280
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7342115731174893101)
,p_name=>'IMAGE_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IMAGE_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>290
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7342115775054893102)
,p_name=>'IMAGE_LAST_UPDATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IMAGE_LAST_UPDATED'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>300
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7342115949581893103)
,p_name=>'SPONSOR_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SPONSOR_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>310
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(7464041537344324374)
,p_name=>'OPEN_PROJECTS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OPEN_PROJECTS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>150
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12057337574850996303)
,p_plug_name=>'Breadcrumb'
,p_region_sub_css_classes=>'has-header-actions'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188496742657575286)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(141188314805859575166)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(141188586951874575390)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12921680929884011121)
,p_plug_name=>'Menubar'
,p_parent_plug_id=>wwv_flow_imp.id(12057337574850996303)
,p_region_sub_css_classes=>'header-actions'
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>'select 1 as actions from dual'
,p_template_component_type=>'PARTIAL'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_attributes=>wwv_flow_string.join_clob(wwv_flow_t_varchar2('{',
  '"APPLY_THEME_COLORS": "Y",',
  '"AVATAR_ICON": "fa-user",',
  '"AVATAR_SHAPE": "t-Avatar--rounded",',
  '"AVATAR_TYPE": "icon",',
  '"BADGE_COL_WIDTH": "t-ContentRow-badge--md",',
  '"BADGE_LABEL_DISPLAY": "N",',
  '"DISPLAY_AVATAR": "N",',
  '"DISPLAY_BADGE": "N",',
  '"HIDE_BORDERS": "N",',
  '"REMOVE_PADDING": "N"',
'}'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(12921682163390011133)
,p_name=>'ACTIONS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIONS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16964178435809972735)
,p_plug_name=>'Area Details'
,p_region_css_classes=>'u-flex'
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding'
,p_plug_template=>wwv_flow_imp.id(141188351742057575241)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(42677951458830375955)
,p_name=>'Contextual Information'
,p_parent_plug_id=>wwv_flow_imp.id(16964178435809972735)
,p_template=>wwv_flow_imp.id(141188351742057575241)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-ContextualInfo-label--stacked:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select f.focus_area,',
'       --',
'       -- initiatives',
'       --',
'       (select count(*) ',
'        from sp_initiatives i ',
'        where i.focus_area_id = f.id) initiatives,',
'       --',
'       -- projects',
'       --',
'       (select count(*) ',
'        from sp_projects p, sp_initiatives i ',
'        where p.initiative_id = i.id and ',
'              i.focus_area_id = f.id and ',
'              p.DUPLICATE_OF_PROJECT_ID is null and ',
'              p.ARCHIVED_YN = ''N'' ',
'              ) projects,',
'        --',
'        -- owners',
'        --',
'        (select count(distinct i.SPONSOR_ID)',
'         from  sp_initiatives i ',
'         where i.focus_area_id = f.id and ',
'               i.SPONSOR_ID is not null) owners',
'  from ',
'       SP_FOCUS_AREAS f',
'where ',
'      f.id = :P66_AREA_ID',
'',
'     '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141188542774892575327)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'no data found'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6534260844584845081)
,p_query_column_id=>1
,p_column_alias=>'FOCUS_AREA'
,p_column_display_sequence=>30
,p_column_heading=>'&NOMENCLATURE_AREA.'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:23:P23_FOCUS_AREA:#FOCUS_AREA#'
,p_column_linktext=>'#FOCUS_AREA#'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6531786216372679767)
,p_query_column_id=>2
,p_column_alias=>'INITIATIVES'
,p_column_display_sequence=>40
,p_column_heading=>'Initiatives'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7247661006747116206)
,p_query_column_id=>3
,p_column_alias=>'PROJECTS'
,p_column_display_sequence=>50
,p_column_heading=>'&NOMENCLATURE_PROJECTS.'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7247661093329116207)
,p_query_column_id=>4
,p_column_alias=>'OWNERS'
,p_column_display_sequence=>60
,p_column_heading=>'Owners'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4638951148793990538)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(12057337574850996303)
,p_button_name=>'UP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141188584666839575384)
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4567070222016075584)
,p_name=>'P66_AREA_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(7243549549520045079)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4567070961704075591)
,p_name=>'P66_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4567070861724075590)
,p_prompt=>'Search'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4567071019480075592)
,p_name=>'P66_SPONSOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(4567070861724075590)
,p_prompt=>'Owner'
,p_source=>'SPONSOR'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4567071319245075595)
,p_name=>'P66_CREATED_MONTH'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(4567070861724075590)
,p_prompt=>'Created Month'
,p_source=>'CREATED_MONTH'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'DESC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4567071575989075598)
,p_name=>'P66_AREA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12057337574850996303)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4567072034338075602)
,p_name=>'P66_ORDER_BY'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4567071786369075600)
,p_item_display_point=>'NEXT'
,p_item_default=>'INITIATIVE'
,p_prompt=>'Order By'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:&NOMENCLATURE_INITIATIVE. Name;INITIATIVE,Updated most recent first;UPDATED,Created most recent first;CREATED,&NOMENCLATURE_PROJECTS. count;PROJECTS,Open &NOMENCLATURE_PROJECTS.;OPEN_PROJECTS'
,p_cHeight=>1
,p_tag_css_classes=>'w240 no-item-ui'
,p_field_template=>wwv_flow_imp.id(141188582371029575375)
,p_item_css_classes=>'u-pullRight'
,p_item_icon_css_classes=>'fa-sort-amount-desc'
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4734400891537791184)
,p_name=>'P66_PROJECTS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(4567070861724075590)
,p_prompt=>'&NOMENCLATURE_PROJECTS.'
,p_source=>'PROJECTS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov=>'STATIC2:Zero;|0,1 - 10;1|10,10 - 20;10|20,20 - 100;20|100,100-1000;100|1000,> 1000;1000|'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6668921203909451777)
,p_name=>'P66_TAGS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(4567070861724075590)
,p_prompt=>'Tags'
,p_source=>'TAGS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>','
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6668921511895451780)
,p_name=>'P66_HIDDEN_BY_DEFAULT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(4567070861724075590)
,p_prompt=>'Default Display'
,p_source=>'HIDDEN_BY_DEFAULT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9609689227169342546)
,p_name=>'P66_IMAGE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(16964178435809972735)
,p_prompt=>'Image'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
' ',
'select 1',
'  from sp_focus_areas',
' where id = :P66_AREA_ID',
'   and image is not null'))
,p_display_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(141188582371029575375)
,p_item_css_classes=>'initiative-icon'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'SQL'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select image,',
'       image_name alt_text,',
'       image_name,',
'       image_mimetype',
'  from sp_focus_areas',
' where id = :P66_AREA_ID'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(4567071695052075599)
,p_computation_sequence=>10
,p_computation_item=>'P66_AREA'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>'select focus_area from sp_focus_areas where id = :P66_AREA_ID'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5201293778619846777)
,p_name=>'refresh on dialog closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(12057337574850996303)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5201293921943846778)
,p_event_id=>wwv_flow_imp.id(5201293778619846777)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(12057337574850996303)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5201294087323846780)
,p_event_id=>wwv_flow_imp.id(5201293778619846777)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(4567070861724075590)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7342112427890893068)
,p_name=>'refresh on dialog menubar'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(12057337574850996303)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7342112561586893069)
,p_event_id=>wwv_flow_imp.id(7342112427890893068)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(42677951458830375955)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7342112569192893070)
,p_event_id=>wwv_flow_imp.id(7342112427890893068)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(4567070861724075590)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7342112688639893071)
,p_event_id=>wwv_flow_imp.id(7342112427890893068)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7243549549520045079)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7247657424345116170)
,p_name=>'refresh on DC'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(7243549549520045079)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7247657524898116171)
,p_event_id=>wwv_flow_imp.id(7247657424345116170)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7243549549520045079)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7247657644602116172)
,p_event_id=>wwv_flow_imp.id(7247657424345116170)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(4567070861724075590)
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(6260682563032804765)
,p_region_id=>wwv_flow_imp.id(12921680929884011121)
,p_position_id=>wwv_flow_imp.id(3717637195828652804)
,p_display_sequence=>10
,p_template_id=>wwv_flow_imp.id(3717637797505683933)
,p_label=>'Add &NOMENCLATURE_INITIATIVE.'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:RP,22:P22_FOCUS_AREA_ID:&P66_AREA_ID.'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-plus'
,p_is_hot=>true
,p_show_as_disabled=>false
,p_authorization_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(7243552174846045106)
,p_region_id=>wwv_flow_imp.id(7243549549520045079)
,p_position_id=>wwv_flow_imp.id(3717637195828652804)
,p_display_sequence=>10
,p_template_id=>wwv_flow_imp.id(3717639057025688081)
,p_label=>'Actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_action_css_classes=>'t-Button--noUI'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(7243552558152045109)
,p_region_id=>wwv_flow_imp.id(7243549549520045079)
,p_position_id=>wwv_flow_imp.id(3704044168831277200)
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP,94:P94_INITIATIVE_ID:&ID.'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(12921681230463011124)
,p_region_id=>wwv_flow_imp.id(12921680929884011121)
,p_position_id=>wwv_flow_imp.id(3717637195828652804)
,p_display_sequence=>20
,p_template_id=>wwv_flow_imp.id(3717639057025688081)
,p_label=>'Actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(5963094186190961683)
,p_component_action_id=>wwv_flow_imp.id(12921681230463011124)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Edit &NOMENCLATURE_AREA.'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:RP,18:P18_ID:&P66_AREA_ID.'
,p_icon_css_classes=>'fa-edit'
,p_authorization_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(7243552326562045107)
,p_component_action_id=>wwv_flow_imp.id(7243552174846045106)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Edit &NOMENCLATURE_INITIATIVE.'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:RP,22:P22_ID:&ID.'
,p_icon_css_classes=>'fa-edit'
,p_authorization_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(7243552403332045108)
,p_component_action_id=>wwv_flow_imp.id(7243552174846045106)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Add &NOMENCLATURE_PROJECT.'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:RP,24:P24_DEF_INITIATIVE_ID,P24_INITIATIVE_ID:&ID.,&ID.'
,p_icon_css_classes=>'fa-plus'
,p_authorization_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(7243552600267045110)
,p_component_action_id=>wwv_flow_imp.id(7243552174846045106)
,p_menu_entry_type=>'ENTRY'
,p_label=>'&NOMENCLATURE_INITIATIVE. Details'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP,94:P94_INITIATIVE_ID:&ID.'
,p_icon_css_classes=>'fa-lightbulb-o'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(7247660633317116202)
,p_component_action_id=>wwv_flow_imp.id(7243552174846045106)
,p_menu_entry_type=>'ENTRY'
,p_label=>'&NOMENCLATURE_PROJECT. Faceted Search'
,p_display_sequence=>50
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:RP,:P23_FOCUS_AREA,P23_INITIATIVE:&FOCUS_AREA.,&INITIATIVE.'
,p_icon_css_classes=>'fa-package'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(7378333153515499641)
,p_component_action_id=>wwv_flow_imp.id(12921681230463011124)
,p_menu_entry_type=>'ENTRY'
,p_label=>'About &NOMENCLATURE_INITIATIVES.'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:106:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-info'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(8779576249675051189)
,p_component_action_id=>wwv_flow_imp.id(12921681230463011124)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Reset'
,p_display_sequence=>50
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:66:&SESSION.::&DEBUG.:RP,66:P66_AREA_ID,P66_HIDDEN_BY_DEFAULT:&P66_AREA_ID.,Visible'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(8779576418292051190)
,p_component_action_id=>wwv_flow_imp.id(12921681230463011124)
,p_menu_entry_type=>'SEPARATOR'
,p_display_sequence=>30
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(12921681936370011131)
,p_component_action_id=>wwv_flow_imp.id(12921681230463011124)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Refresh'
,p_display_sequence=>60
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:66:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp.component_end;
end;
/
