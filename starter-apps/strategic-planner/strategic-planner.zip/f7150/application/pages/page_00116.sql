prompt --application/pages/page_00116
begin
--   Manifest
--     PAGE: 00116
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>116
,p_name=>'Contributors'
,p_alias=>'CONTRIBUTORS'
,p_page_mode=>'MODAL'
,p_step_title=>'Contributors'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(141188315653614575172)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20240417230614'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4232464993754234373)
,p_plug_name=>'Context'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188351742057575241)
,p_plug_display_sequence=>3
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6447006839245991108)
,p_plug_name=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188501912119575289)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30831374639156888358)
,p_plug_name=>'Contributors'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141188482213340575271)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c.ID,',
'       t.first_name||'' ''||t.last_name name,',
'       t.initials,',
'       c.TEAM_MEMBER_ID,',
'       c.RESPONSIBILITY_ID,',
'       (select RESOURCE_TYPE from SP_RESOURCE_TYPES r where r.id = c.RESPONSIBILITY_ID) responsibility,',
'       c.tags,',
'       c.CREATED,',
'       c.updated,',
'       c.responsibility comments',
'  from SP_PROJECT_CONTRIBUTORS c,',
'       SP_TEAM_MEMBERS t',
'where c.project_id = :P116_PROJECT_ID and',
'      t.id = c.TEAM_MEMBER_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'&P3_TEAM_MEMBERS. Contributors'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(4210581554427499589)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:9:P9_ID:#ID#'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(141188614017151575484)
,p_owner=>'MIKE'
,p_internal_uid=>2344843785544854129
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4210581628289499590)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4210581790431499591)
,p_db_column_name=>'NAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Name'
,p_column_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:5:P5_ID:#TEAM_MEMBER_ID#'
,p_column_linktext=>'#NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4210581843359499592)
,p_db_column_name=>'INITIALS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Initials'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4210581905320499593)
,p_db_column_name=>'TEAM_MEMBER_ID'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'User  ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4210582097245499594)
,p_db_column_name=>'RESPONSIBILITY_ID'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Responsibility Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4210582162226499595)
,p_db_column_name=>'RESPONSIBILITY'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Responsibility'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4210582332345499597)
,p_db_column_name=>'COMMENTS'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Comments'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4210582224164499596)
,p_db_column_name=>'CREATED'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11573555101462772987)
,p_db_column_name=>'TAGS'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Tags'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11573555489814772990)
,p_db_column_name=>'UPDATED'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(4475667681218744165)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'10795542'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NAME:RESPONSIBILITY:TAGS:COMMENTS:CREATED:UPDATED'
,p_sort_column_1=>'UPDATED'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'CREATED'
,p_sort_direction_2=>'DESC'
,p_sum_columns_on_break=>'CONTRIBUTIONS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3396117629509799908)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(30831374639156888358)
,p_button_name=>'add_contributor'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Contributor'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus'
,p_grid_new_row=>'Y'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3396815260748229463)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(6447006839245991108)
,p_button_name=>'Cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3396814855888229462)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(6447006839245991108)
,p_button_name=>'View_Project'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141188585272816575387)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'View Project'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:RP,36:P36_ID:&P116_PROJECT_ID.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3395762443292019374)
,p_name=>'P116_PROJECT_ID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(30831374639156888358)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4232464891844234372)
,p_name=>'P116_PROJECT_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(4232464993754234373)
,p_prompt=>'&NOMENCLATURE_PROJECT.'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(141188584476664575383)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35240702775659320328)
,p_name=>'P116_CONTRIBUTOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(30831374639156888358)
,p_item_default=>'return sp_strategic_proj_util.get_user_id (:APP_USER);'
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Add Contributor'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'SP_TEAM_MEMBERS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select last_name||'', ''||first_name||'' (''||lower(email)||'')'' d, id r',
'from SP_TEAM_MEMBERS',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- select User  -'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(141188584476664575383)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'2'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35240702898404320329)
,p_name=>'P116_CONTRIBUTOR_ROLE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(30831374639156888358)
,p_item_default=>'select max(id) from SP_RESOURCE_TYPES where IS_DEFAULT_YN = ''Y'''
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Role'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select RESOURCE_TYPE, id',
'from SP_RESOURCE_TYPES',
'order by 1'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(141188584476664575383)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_security_scheme=>wwv_flow_imp.id(141188614017151575484)
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(4232465138485234374)
,p_computation_sequence=>10
,p_computation_item=>'P116_PROJECT_NAME'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>'select project from sp_projects where id = :P116_PROJECT_ID '
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3395762564952019375)
,p_name=>'action'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(3396117629509799908)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3395762668049019376)
,p_event_id=>wwv_flow_imp.id(3395762564952019375)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'   c int := 0;',
'begin',
'   select count(*) into c ',
'   from  SP_PROJECT_CONTRIBUTORS ',
'   where project_id = :P116_PROJECT_ID and ',
'         TEAM_MEMBER_ID = :P116_CONTRIBUTOR;',
'   --',
'   if c = 0 then ',
'      insert into SP_PROJECT_CONTRIBUTORS',
'      (PROJECT_ID, TEAM_MEMBER_ID, RESPONSIBILITY_ID)',
'      values',
'      (:P116_PROJECT_ID, :P116_CONTRIBUTOR, :P116_CONTRIBUTOR_ROLE);',
'   end if;',
'',
'   :P116_CONTRIBUTOR := null;',
'   for c1 in (select max(id) id from SP_RESOURCE_TYPES where IS_DEFAULT_YN = ''Y'') loop',
'       :P116_CONTRIBUTOR_ROLE := c1.id;',
'   end loop;',
'end;'))
,p_attribute_02=>'P116_CONTRIBUTOR,P116_CONTRIBUTOR_ROLE,P116_PROJECT_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3395762762570019377)
,p_event_id=>wwv_flow_imp.id(3395762564952019375)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(30831374639156888358)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3395762941765019379)
,p_name=>'close dialog'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(3396815260748229463)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3395763024171019380)
,p_event_id=>wwv_flow_imp.id(3395762941765019379)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp.component_end;
end;
/
