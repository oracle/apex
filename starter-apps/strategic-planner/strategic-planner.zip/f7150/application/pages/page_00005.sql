prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>26954343551793662
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'UserDetail'
,p_alias=>'USERDETAIL'
,p_step_title=>'&P5_FIRST_NAME. &P5_LAST_NAME.'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(10059993393349169645)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.sp-tag {',
'    padding: 2px 4px;',
'    display: inline-block;',
'    vertical-align: text-bottom;',
'    border-radius: 3px;',
'    background-color: rgba(0,0,0,.1);',
'    text-overflow: ellipsis;',
'    white-space: nowrap;',
'}',
'.sp-tags-container {',
'    display: flex;',
'    align-items: center;',
'    flex-wrap: wrap;',
'    gap: 4px;',
'    justify-content: flex-start;',
'}',
'',
'h3:first-of-type { margin-top: 0; }'))
,p_step_template=>wwv_flow_imp.id(141215272919592368865)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.ck.ck-content {',
'    min-height: 60px !important;',
'}',
'',
'.project-info-region {',
'    background-color: rgb(219 204 175 / 50%);',
'    padding: 1rem 1rem 0 1rem;',
'}',
'.project-rds-region {',
'    background-color: rgb(219 204 175 / 20%);',
'}',
'',
'.no-item-ui {',
'    --a-field-input-border-width: 0;',
'    --a-field-input-background-color: transparent;',
'}',
'.overline {',
'  color: var(--ut-region-text-color,var(--ut-component-text-default-color));',
'}',
''))
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2809663608419611755)
,p_plug_name=>'RDS'
,p_region_css_classes=>'project-rds-region'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215307437908368905)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5900475389436449926)
,p_plug_name=>'Weekly Summary'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(141215438656052368935)
,p_plug_display_sequence=>71
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14008465030510832532)
,p_plug_name=>'buttons'
,p_parent_plug_id=>wwv_flow_imp.id(5900475389436449926)
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(141215456255671368951)
,p_plug_display_sequence=>10
,p_required_patch=>wwv_flow_imp.id(18721993490508994894)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14008465189640832533)
,p_plug_name=>'Weekly Summary content'
,p_parent_plug_id=>wwv_flow_imp.id(5900475389436449926)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(141215438656052368935)
,p_plug_display_sequence=>81
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return sp_contributor_summary.generate (',
'           p_team_member_id => :P5_ID,',
'           p_links          => ''APP'',',
'           p_apex_session   => :APP_SESSION );'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P5_ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5990050447980755364)
,p_plug_name=>'button container'
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:margin-left-none'
,p_plug_template=>wwv_flow_imp.id(141215307437908368905)
,p_plug_display_sequence=>2000
,p_plug_display_point=>'REGION_POSITION_02'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10700310081182694055)
,p_plug_name=>'Profile'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(141215438656052368935)
,p_plug_display_sequence=>500
,p_plug_display_point=>'REGION_POSITION_02'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(10336219585502558487)
,p_name=>'Profile Details'
,p_parent_plug_id=>wwv_flow_imp.id(10700310081182694055)
,p_template=>wwv_flow_imp.id(141215307437908368905)
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_component_template_options=>'#DEFAULT#:t-ContextualInfo-item--stacked:t-ContextualInfo-label--stacked:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tm.ID,',
'       tm.first_name||'' ''||tm.last_Name name,',
'       tm.INITIALS,',
'       tm.EMAIL,',
'       lower(tm.TAGS) tags,',
'       competencies,',
'       CREATED,',
'       UPDATED,',
'       APP_ROLE,',
'       location,',
'       nvl((select country_Name from sp_countries c where c.id = tm.country_id),''Not Provided'') Country,',
'       --',
'       -- active projects',
'       --',
'       (select count(*) ',
'       from SP_PROJECTS p',
'       where (',
'         p.owner_id = :P5_ID or ',
'         :P5_ID in (select c.team_member_id ',
'                    from SP_PROJECT_CONTRIBUTORS c ',
'                    where c.project_id = p.id) or',
'         :P5_ID in (select c.owner_id from SP_PROJECT_REVIEWS c where c.project_id = p.id) or',
'         :P5_ID in (select a.TEAM_MEMBER_ID from SP_ACTIVITIES a where a.PROJECT_ID = p.id)',
'         )',
'         and',
'         p.ARCHIVED_YN = ''N'' and ',
'         p.DUPLICATE_OF_PROJECT_ID is null and',
'         p.PCT_COMPLETE not in (0,100)',
'         ) as active_projects,',
'       --',
'       -- completed projects',
'       --',
'       (select count(*) ',
'       from SP_PROJECTS p',
'       where (',
'         p.owner_id = :P5_ID or ',
'         :P5_ID in (select c.team_member_id ',
'                    from SP_PROJECT_CONTRIBUTORS c ',
'                    where c.project_id = p.id) or',
'         :P5_ID in (select c.owner_id from SP_PROJECT_REVIEWS c where c.project_id = p.id) or',
'         :P5_ID in (select a.TEAM_MEMBER_ID from SP_ACTIVITIES a where a.PROJECT_ID = p.id)',
'         )',
'         and',
'         p.ARCHIVED_YN = ''N'' and ',
'         p.DUPLICATE_OF_PROJECT_ID is null and',
'         p.PCT_COMPLETE = 100',
'         ) as completed_projects,',
'         --',
'         -- group associations',
'         --',
'        (select count(*)',
'         from   SP_GROUP_MEMBERS gm,',
'                SP_GROUPS g',
'         where  TEAM_MEMBER_ID = :P5_ID and',
'                g.id = gm.GROUP_ID) ',
'        as group_associations',
'  from SP_TEAM_MEMBERS tm',
' where id = :P5_ID'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P5_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141215497118444368989)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6328437433817547666)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6328435423717547663)
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>20
,p_column_heading=>'Name'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6328436233207547665)
,p_query_column_id=>3
,p_column_alias=>'INITIALS'
,p_column_display_sequence=>30
,p_column_heading=>'Initials'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6328436621014547665)
,p_query_column_id=>4
,p_column_alias=>'EMAIL'
,p_column_display_sequence=>40
,p_column_heading=>'Email'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6328437046886547666)
,p_query_column_id=>5
,p_column_alias=>'TAGS'
,p_column_display_sequence=>160
,p_column_heading=>'Tags'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(14008465287428832534)
,p_query_column_id=>6
,p_column_alias=>'COMPETENCIES'
,p_column_display_sequence=>170
,p_column_heading=>'Competencies'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6328435027835547663)
,p_query_column_id=>7
,p_column_alias=>'CREATED'
,p_column_display_sequence=>180
,p_column_heading=>'Created'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6328434645152547661)
,p_query_column_id=>8
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>190
,p_column_heading=>'Last Updated'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6328435815362547664)
,p_query_column_id=>9
,p_column_alias=>'APP_ROLE'
,p_column_display_sequence=>70
,p_column_heading=>'Application Role'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(3274018153866163061)
,p_query_column_id=>10
,p_column_alias=>'LOCATION'
,p_column_display_sequence=>80
,p_column_heading=>'Location'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from SP_TEAM_MEMBERS tm',
' where id = :P5_ID',
'   and location is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6328437902974547666)
,p_query_column_id=>11
,p_column_alias=>'COUNTRY'
,p_column_display_sequence=>90
,p_column_heading=>'Country'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11936604585043201447)
,p_query_column_id=>12
,p_column_alias=>'ACTIVE_PROJECTS'
,p_column_display_sequence=>120
,p_column_heading=>'Active &NOMENCLATURE_PROJECTS.'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11936604644444201448)
,p_query_column_id=>13
,p_column_alias=>'COMPLETED_PROJECTS'
,p_column_display_sequence=>130
,p_column_heading=>'Completed &NOMENCLATURE_PROJECTS.'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11936604808529201449)
,p_query_column_id=>14
,p_column_alias=>'GROUP_ASSOCIATIONS'
,p_column_display_sequence=>140
,p_column_heading=>'Group Associations'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10792849966281629074)
,p_plug_name=>'Breadcrumb'
,p_region_sub_css_classes=>'has-header-actions'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215451086209368948)
,p_plug_display_sequence=>7
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(141215269149411368828)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(141215541295426369052)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11657193321314643892)
,p_plug_name=>'Menubar'
,p_parent_plug_id=>wwv_flow_imp.id(10792849966281629074)
,p_region_sub_css_classes=>'header-actions'
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>'select 1 as actions from dual'
,p_template_component_type=>'PARTIAL'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'AVATAR_ICON', 'fa-user',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_TYPE', 'icon',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--md',
  'BADGE_LABEL_DISPLAY', 'N',
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(11657194554820643904)
,p_name=>'ACTIONS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIONS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11936602221775201424)
,p_plug_name=>'Groups'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215436556892368933)
,p_plug_display_sequence=>141
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select g.GROUP_NAME, gm.CREATED added_to_group, g.id group_id, ',
'       (select count(*) from SP_GROUP_MEMBERS x where x.group_id = gm.group_id) members,',
'       decode(nvl(full_time_yn,''N''),''Y'',''Yes'',''N'',''No'') full_time,',
'       decode(nvl(group_leader_yn,''N''),''Y'',''Yes'',''N'',''No'') leader',
'from   SP_GROUP_MEMBERS gm,',
'       SP_GROUPS g',
'where  TEAM_MEMBER_ID = :P5_ID and',
'       g.id = gm.GROUP_ID',
'order by upper(g.group_name)'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P5_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Groups'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(11936602325332201425)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MIKE'
,p_internal_uid=>10043910212897762303
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11936604158368201443)
,p_db_column_name=>'GROUP_NAME'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Group Name'
,p_column_link=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.:RP,151:P151_GROUP_ID:#GROUP_ID#'
,p_column_linktext=>'#GROUP_NAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11936604282768201444)
,p_db_column_name=>'ADDED_TO_GROUP'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Added To Group'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11936604349088201445)
,p_db_column_name=>'GROUP_ID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Group Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11936604466819201446)
,p_db_column_name=>'MEMBERS'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Members'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11936605097148201452)
,p_db_column_name=>'FULL_TIME'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Full Time'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11936605184278201453)
,p_db_column_name=>'LEADER'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Leader'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(11936805003356775709)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'100441129'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'GROUP_NAME:FULL_TIME:LEADER:MEMBERS:ADDED_TO_GROUP:'
,p_sort_column_1=>'ADDED_TO_GROUP'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13394406780956490065)
,p_plug_name=>'Project Exceptions'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(141215438656052368935)
,p_plug_display_sequence=>121
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14008464851026832530)
,p_plug_name=>'buttons'
,p_parent_plug_id=>wwv_flow_imp.id(13394406780956490065)
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(141215456255671368951)
,p_plug_display_sequence=>5
,p_plug_display_point=>'SUB_REGIONS'
,p_required_patch=>wwv_flow_imp.id(18721993490508994894)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14008464925990832531)
,p_plug_name=>'Project Exceptions content'
,p_parent_plug_id=>wwv_flow_imp.id(13394406780956490065)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(141215438656052368935)
,p_plug_display_sequence=>25
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return sp_contributor_summary.project_exceptions (',
'           p_team_member_id  => :P5_ID,',
'           p_links           => ''APP'',',
'           p_apex_session    => :APP_SESSION );'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P5_ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14241501889127255360)
,p_plug_name=>'Project Changes'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(141215438656052368935)
,p_plug_display_sequence=>131
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P5_ID'
,p_plug_display_when_cond2=>'&APP_USER_ID.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14241501928824255361)
,p_plug_name=>'Project Change content'
,p_parent_plug_id=>wwv_flow_imp.id(14241501889127255360)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(141215438656052368935)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_changes_yn      varchar2(1);',
'    l_change_summary  clob;',
'begin',
'',
'    sp_contributor_summary.project_changes (',
'        p_team_member_id => :P5_ID,',
'        p_frequency      => ''WEEKLY'',',
'        p_links          => ''APP'',',
'        p_apex_session   => :APP_SESSION,',
'        p_changes_yn     => l_changes_yn,',
'        p_change_summary => l_change_summary );',
'',
'    if l_changes_yn = ''Y'' then',
'        return l_change_summary;',
'    else',
'        return ''No changes found for projects you own or have favorited.'';',
'    end if;',
'',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P5_ID'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(26919107944949069644)
,p_plug_name=>'buttons'
,p_parent_plug_id=>wwv_flow_imp.id(14241501889127255360)
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(141215456255671368951)
,p_plug_display_sequence=>2010
,p_required_patch=>wwv_flow_imp.id(18721993490508994894)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17111043616997483244)
,p_plug_name=>'Activity'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(141215438656052368935)
,p_plug_display_sequence=>61
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ap.id, ',
'       at.activity_type,',
'       ap.comments,',
'       ap.start_date,',
'       ap.end_date,',
'       to_char(ap.end_date,''Day DD-MON-YYYY'') end_date_formatted,',
'       to_char(ap.start_date,''Day DD-MON-YYYY'')||'' to ''||to_char(ap.end_date,''Day DD-MON-YYYY'') TIMELINE,',
'       ap.end_date - ap.start_date days,',
'       round(ap.end_date - sysdate) days_remaining,',
'       ap.url,',
'       apex_util.get_since(ap.updated) last_updated,',
'       --',
'       -- team member info',
'       --',
'       tm.first_name||'' ''||tm.last_name name,',
'       --',
'       -- project info',
'       --',
'       p.project,',
'       p.friendly_identifier,',
'       p.PROJECT_URL_NAME,',
'       --',
'       -- badge status is red if past due and green if within begin and and dates',
'       --',
'       decode(trunc(ap.start_date),trunc(sysdate),''success'',',
'       decode(trunc(ap.end_date),trunc(sysdate),''success'',',
'       decode(',
'           greatest(to_char(ap.end_date,''YYYY.MM.DD''),to_char(sysdate,''YYYY.MM.DD'')),',
'           to_char(sysdate,''YYYY.MM.DD''),',
'           ''danger'',',
'           ''success''))) as badge_class,',
'       --',
'       -- pie chart icon in 10% chunks that show time percent complete',
'       --',
'       ''fa-pie-chart-''||sp_date_range_pct_comp(ap.start_date, ap.end_date) icon',
'from sp_activities ap,',
'     sp_projects p,',
'     sp_activity_types at,',
'     sp_team_members tm',
'where ap.project_id = p.id(+) and',
'      ap.activity_type_id = at.id and',
'      tm.email = lower(:P5_EMAIL) and',
'      ap.team_member_id = tm.id and',
'      (p.id is null or p.DUPLICATE_OF_PROJECT_ID is null) and',
'      (p.id is null or p.ARCHIVED_YN = ''N'') and',
'      --',
'      (',
'         (nvl(:P5_INCLUDE_FUTURE,''N'') = ''Y'' and ap.start_date > trunc(sysdate)) or ',
'         (nvl(:P5_INCLUDE_PAST,''N'') = ''Y'' and ap.end_date < sysdate) or ',
'         trunc(sysdate) between trunc(ap.start_date) and ap.end_date ',
'      )',
''))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_ajax_items_to_submit=>'P5_EMAIL,P5_INCLUDE_FUTURE,P5_INCLUDE_PAST'
,p_plug_query_num_rows=>30
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_required_patch=>wwv_flow_imp.id(16176016435216408644)
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'AVATAR_ICON', '&ICON.',
  'AVATAR_SHAPE', 't-Avatar--noShape',
  'AVATAR_SIZE', 't-Avatar--md',
  'AVATAR_TYPE', 'icon',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--lg',
  'BADGE_LABEL', '&NOMENCLATURE_PROJECTS.',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_VALUE', 'ACTIVITY_TYPE',
  'DESCRIPTION', '&COMMENTS.',
  'DISPLAY_AVATAR', 'Y',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'MISC', '&LAST_UPDATED.',
  'OVERLINE', '&TIMELINE.',
  'REMOVE_PADDING', 'N',
  'TITLE', '&PROJECT.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3446930178005010265)
,p_name=>'BADGE_CLASS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BADGE_CLASS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>330
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17111043792303483245)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17111045184922483259)
,p_name=>'DAYS_REMAINING'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DAYS_REMAINING'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>150
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17111045336661483261)
,p_name=>'ICON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ICON'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>170
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17111047281021483280)
,p_name=>'ACTIVITY_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIVITY_TYPE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>190
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17111047396298483281)
,p_name=>'COMMENTS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMMENTS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>200
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17111047497109483282)
,p_name=>'START_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'START_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>210
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17111047588849483283)
,p_name=>'END_DATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'END_DATE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>220
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17132280280881034734)
,p_name=>'DAYS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DAYS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>230
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17132280318117034735)
,p_name=>'URL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'URL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>240
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17132280471936034736)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>250
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17132280594466034737)
,p_name=>'PROJECT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROJECT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>260
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17132280643191034738)
,p_name=>'FRIENDLY_IDENTIFIER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FRIENDLY_IDENTIFIER'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>270
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17132280705004034739)
,p_name=>'TIMELINE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIMELINE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>280
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17132280852365034740)
,p_name=>'PROJECT_URL_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROJECT_URL_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>290
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17132280982270034741)
,p_name=>'LAST_UPDATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LAST_UPDATED'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>300
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(17132281755265034749)
,p_name=>'END_DATE_FORMATTED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'END_DATE_FORMATTED'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>310
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(19157928852844078515)
,p_name=>'Open Reviews'
,p_template=>wwv_flow_imp.id(141215438656052368935)
,p_display_sequence=>62
,p_include_in_reg_disp_sel_yn=>'Y'
,p_icon_css_classes=>' '
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--showIcon:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--horizontalBorders:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.ID project_id,',
'       r.id review_id,',
'       p.PROJECT,',
'       (select FIRST_NAME ||'' ''||last_name from SP_TEAM_MEMBERS x where x.ID = p.OWNER_ID) the_owner,',
'       (select ''P''||PRIORITY from SP_PROJECT_PRIORITIES x where x.ID = p.PRIORITY_ID) priority,',
'       p.PCT_COMPLETE pct_complete,',
'       decode(p.release_id,',
'          null, decode(p.TARGET_COMPLETE,null,''No Target'',to_char(p.TARGET_COMPLETE,''DD-MON-YYYY'')),',
'          (select RELEASE_TRAIN||'' ''||release from SP_RELEASE_TRAINS r where r.id = p.RELEASE_ID)) release,',
'       p.PROJECT_SIZE,',
'       r.UPDATED,',
'       (select review_type from sp_project_review_types rt where rt.id = r.review_type_id) review_type,',
'       r.review_date,',
'       initcap(replace(r.review_status,''-'','' '')) status,',
'       null attributes,',
'       p.owner_id,',
'       p.friendly_identifier,',
'       p.project_url_name,',
'       nvl((select first_name||'' ''||last_name from SP_TEAM_MEMBERS tm where tm.email = lower(r.updated_by)),lower(r.updated_by)) updated_by',
'  from SP_PROJECTS p,',
'       sp_project_reviews r',
' where nvl(p.ARCHIVED_YN,''N'') != ''Y'' and ',
'       p.DUPLICATE_OF_PROJECT_ID is null and',
'       p.id = r.project_id and',
'       r.owner_id = :P5_ID and',
'       r.review_status != ''COMPLETED''',
' order by r.review_date asc nulls first',
'',
''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P5_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141215498180253368990)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No open reviews found.'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15323518630408323928)
,p_query_column_id=>1
,p_column_alias=>'PROJECT_ID'
,p_column_display_sequence=>170
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15323518748163323929)
,p_query_column_id=>2
,p_column_alias=>'REVIEW_ID'
,p_column_display_sequence=>180
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15550510580940759317)
,p_query_column_id=>3
,p_column_alias=>'PROJECT'
,p_column_display_sequence=>50
,p_column_heading=>'&NOMENCLATURE_PROJECT.'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:FI,PN:#FRIENDLY_IDENTIFIER#,#PROJECT_URL_NAME#'
,p_column_linktext=>'#PROJECT#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15550510954239759317)
,p_query_column_id=>4
,p_column_alias=>'THE_OWNER'
,p_column_display_sequence=>110
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15550511325134759318)
,p_query_column_id=>5
,p_column_alias=>'PRIORITY'
,p_column_display_sequence=>70
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15550511745328759318)
,p_query_column_id=>6
,p_column_alias=>'PCT_COMPLETE'
,p_column_display_sequence=>150
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15550512541939759319)
,p_query_column_id=>7
,p_column_alias=>'RELEASE'
,p_column_display_sequence=>160
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15550512988240759319)
,p_query_column_id=>8
,p_column_alias=>'PROJECT_SIZE'
,p_column_display_sequence=>60
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15550513327493759319)
,p_query_column_id=>9
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>90
,p_column_heading=>'Updated'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE_SHORT'
,p_column_html_expression=>'#UPDATED# - #UPDATED_BY#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15323518422974323926)
,p_query_column_id=>10
,p_column_alias=>'REVIEW_TYPE'
,p_column_display_sequence=>20
,p_column_heading=>'Type'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:11:P11_ID:#REVIEW_ID#'
,p_column_linktext=>'#REVIEW_TYPE#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15323518606104323927)
,p_query_column_id=>11
,p_column_alias=>'REVIEW_DATE'
,p_column_display_sequence=>30
,p_column_heading=>'Date'
,p_use_as_row_header=>'N'
,p_column_format=>'DD-MON'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15323521878856323960)
,p_query_column_id=>12
,p_column_alias=>'STATUS'
,p_column_display_sequence=>40
,p_column_heading=>'Status'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15550513713604759320)
,p_query_column_id=>13
,p_column_alias=>'ATTRIBUTES'
,p_column_display_sequence=>80
,p_column_heading=>'Attributes'
,p_use_as_row_header=>'N'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="sp-tags-container">',
'    <span class="sp-tag">#PRIORITY#</span>',
'    <span class="sp-tag">#PROJECT_SIZE#</span>',
'    <span class="sp-tag">#PCT_COMPLETE#%</span>',
'    <span class="sp-tag">#RELEASE#</span>',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15550514166168759320)
,p_query_column_id=>14
,p_column_alias=>'OWNER_ID'
,p_column_display_sequence=>120
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15550508541236759315)
,p_query_column_id=>15
,p_column_alias=>'FRIENDLY_IDENTIFIER'
,p_column_display_sequence=>130
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15550508939705759315)
,p_query_column_id=>16
,p_column_alias=>'PROJECT_URL_NAME'
,p_column_display_sequence=>140
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(15550509785266759316)
,p_query_column_id=>17
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>100
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(116939741687806079110)
,p_plug_name=>'&NOMENCLATURE_PROJECTS.'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215436556892368933)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select x.*,',
'       nvl(ltrim(case when x.is_owner = ''Yes'' then ''Owner'' end || ',
'                 case when x.project_role  is not null then '', ''||x.project_role end ||',
'                 case when x.reviewer_role is not null then '', ''||x.reviewer_role|| '' Reviewer'' end,'', ''),''Contributed'') Association',
'from (',
'select p.id, ',
'       p.PROJECT, ',
'       i.INITIATIVE, ',
'       f.focus_area, ',
'       --',
'       -- contribution role',
'       --',
'       nvl((select max((select max(resource_type) from SP_RESOURCE_TYPES t where t.id = pc.RESPONSIBILITY_ID) )',
'        from SP_PROJECT_CONTRIBUTORS pc ',
'        where pc.team_member_id = :P5_ID and project_id = p.id),'''') project_role,',
'       --',
'       -- reviewer role',
'       --',
'       nvl((select max((select max(review_type) from SP_PROJECT_REVIEW_TYPES t where t.id = pr.REVIEW_TYPE_ID) )',
'        from SP_PROJECT_REVIEWS pr',
'        where pr.owner_id = :P5_ID and project_id = p.id),'''') reviewer_role,',
'       --',
'       -- project owner',
'       --',
'       decode(',
'          p.OWNER_ID,',
'          (select 1 x from SP_team_members a where a.email = lower(:APP_USER)),',
'          ''Yes'',',
'          ''No'') as is_owner,',
'       --',
'       -- project activity',
'       --',
'       (select ''Current '' from dual where exists (',
'           select 1 ',
'           from SP_ACTIVITIES a ',
'           where a.TEAM_MEMBER_ID = :P5_ID and ',
'                 a.project_id = p.id and ',
'                 trunc(sysdate) between trunc(a.start_date) and trunc(a.end_date)',
'           )',
'           )||',
'        (select ''Future '' from dual where exists (',
'           select 1 ',
'           from SP_ACTIVITIES a ',
'           where a.TEAM_MEMBER_ID = :P5_ID and ',
'                 a.project_id = p.id and ',
'                 trunc(sysdate) < trunc(a.start_date)',
'           )',
'           )||          ',
'        (select ''Past '' from dual where exists (',
'           select 1 ',
'           from SP_ACTIVITIES a ',
'           where a.TEAM_MEMBER_ID = :P5_ID and ',
'                 a.project_id = p.id and ',
'                 trunc(sysdate) > trunc(a.end_date)',
'           )',
'           )           ',
'            Activity,',
'       --',
'       -- project attributes',
'       --',
'       p.PCT_COMPLETE PCT_COMPLETE,',
'       (select max(''P''||PRIORITY) from sp_project_priorities pp where pp.id = p.priority_id) priority,',
'       (select max(release_train||'' ''||release) from SP_RELEASE_TRAINS r where r.id = p.release_id) release,',
'       p.tags,',
'       p.project_size,',
'       p.updated,',
'       p.created,',
'       --',
'       -- columns needed to link to project',
'       --',
'       p.FRIENDLY_IDENTIFIER,',
'       p.PROJECT_URL_NAME',
'from SP_PROJECTS p,',
'     sp_initiatives i,',
'     sp_focus_areas f',
'where (p.owner_id = :P5_ID or ',
'         :P5_ID in (select c.team_member_id ',
'                    from SP_PROJECT_CONTRIBUTORS c ',
'                    where c.project_id = p.id) or',
'         :P5_ID in (select c.owner_id from SP_PROJECT_REVIEWS c where c.project_id = p.id) or',
'         :P5_ID in (select a.TEAM_MEMBER_ID from SP_ACTIVITIES a where a.PROJECT_ID = p.id)',
'      ) and',
'      p.INITIATIVE_ID = i.id and',
'      i.focus_area_id = f.id and',
'      p.ARCHIVED_YN = ''N'' and ',
'      p.DUPLICATE_OF_PROJECT_ID is null',
') x'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P5_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'&NOMENCLATURE_PROJECTS.'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(2809661725989611737)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MIKE'
,p_internal_uid=>916969613555172615
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2809661831081611738)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2809661951368611739)
,p_db_column_name=>'PROJECT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'&NOMENCLATURE_PROJECT.'
,p_column_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:FI,PN:#FRIENDLY_IDENTIFIER#,#PROJECT_URL_NAME#'
,p_column_linktext=>'#PROJECT#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2809662037405611740)
,p_db_column_name=>'INITIATIVE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'&NOMENCLATURE_INITIATIVE.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2809662205970611741)
,p_db_column_name=>'FOCUS_AREA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'&NOMENCLATURE_AREA.'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2809662378950611743)
,p_db_column_name=>'PRIORITY'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Priority'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2809662452428611744)
,p_db_column_name=>'UPDATED'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2809662515550611745)
,p_db_column_name=>'CREATED'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2809663899790611758)
,p_db_column_name=>'IS_OWNER'
,p_display_order=>90
,p_column_identifier=>'P'
,p_column_label=>'Owner'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4761354781613584841)
,p_db_column_name=>'ACTIVITY'
,p_display_order=>100
,p_column_identifier=>'R'
,p_column_label=>'Activity'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2809662692152611746)
,p_db_column_name=>'PROJECT_ROLE'
,p_display_order=>110
,p_column_identifier=>'I'
,p_column_label=>'Contribution'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2809662784604611747)
,p_db_column_name=>'REVIEWER_ROLE'
,p_display_order=>120
,p_column_identifier=>'J'
,p_column_label=>'Reviewer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2809662881572611748)
,p_db_column_name=>'RELEASE'
,p_display_order=>130
,p_column_identifier=>'K'
,p_column_label=>'Release'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2809662956755611749)
,p_db_column_name=>'TAGS'
,p_display_order=>140
,p_column_identifier=>'L'
,p_column_label=>'Tags'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2809663064154611750)
,p_db_column_name=>'PROJECT_SIZE'
,p_display_order=>150
,p_column_identifier=>'M'
,p_column_label=>'Size'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2809663120220611751)
,p_db_column_name=>'FRIENDLY_IDENTIFIER'
,p_display_order=>160
,p_column_identifier=>'N'
,p_column_label=>'Friendly Identifier'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2809663300200611752)
,p_db_column_name=>'PROJECT_URL_NAME'
,p_display_order=>170
,p_column_identifier=>'O'
,p_column_label=>'Project Url Name'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2809663924183611759)
,p_db_column_name=>'PCT_COMPLETE'
,p_display_order=>180
,p_column_identifier=>'Q'
,p_column_label=>'Complete'
,p_column_html_expression=>'#PCT_COMPLETE#%'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14241502687039255368)
,p_db_column_name=>'ASSOCIATION'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Association'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(2847621616157601793)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'9549296'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PROJECT:INITIATIVE:ASSOCIATION:RELEASE:PCT_COMPLETE:PRIORITY:UPDATED:'
,p_sort_column_1=>'UPDATED'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(14896876990645828936)
,p_report_id=>wwv_flow_imp.id(2847621616157601793)
,p_name=>'Active Projects'
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_expr_type=>'ROW'
,p_expr=>'Q not in (0,100)'
,p_condition_sql=>'"PCT_COMPLETE" NOT IN ( 0 , 100 )'
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6356412043680801736)
,p_plug_name=>'Note on Report'
,p_parent_plug_id=>wwv_flow_imp.id(116939741687806079110)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215306085609368903)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_count_0    number;',
'    l_count_100  number;',
'    l_owner      varchar2(4000);',
'    l_0_link     varchar2(4000);',
'    l_100_link   varchar2(4000);',
'    l_return     clob;',
'begin',
'    select count(*)',
'      into l_count_0',
'      from sp_projects p',
'     where pct_complete = 0',
'       and owner_id = :P5_ID',
'       and archived_yn = ''N'';',
'',
'    select count(*)',
'      into l_count_100',
'      from sp_projects p',
'     where pct_complete = 100',
'       and owner_id = :P5_ID',
'       and archived_yn = ''N'';',
'',
'    if l_count_0 > 0 or l_count_100 > 0 then',
'       select first_name||'' ''||last_name',
'         into l_owner',
'         from sp_team_members ',
'        where id = :P5_ID;',
'    end if;',
'',
'    if l_count_0 > 0 then',
'       l_0_link := ''<a href="''||apex_page.get_url(',
'                                   p_application => :APP_ID,',
'                                   p_page        => 23,',
'                                   p_session     => :APP_SESSION,',
'                                   p_items       => ''P23_COMPLETED,P23_THE_OWNER'',',
'                                   p_values      => ''Abandoned - 0%,''||l_owner,',
'                                   p_plain_url   => TRUE )||''">''||to_char(l_count_0,''999,999,999'')||'' 0% complete</a>'';',
'    end if;',
'',
'    if l_count_100 > 0 then',
'       l_100_link := ''<a href="''||apex_page.get_url(',
'                                   p_application => :APP_ID,',
'                                   p_page        => 23,',
'                                   p_session     => :APP_SESSION,',
'                                   p_items       => ''P23_COMPLETED,P23_THE_OWNER'',',
'                                   p_values      => ''Completed - 100%,''||l_owner,',
'                                   p_plain_url   => TRUE )||''">''||to_char(l_count_100,''999,999,999'')||'' 100% complete</a>'';',
'    end if;',
'',
'    if l_count_0 > 0 and l_count_100 > 0 then',
'       l_return := ''Report excludes ''|| l_0_link ||'' and ''||',
'                    l_100_link || '' '' ||',
'                    :NOMENCLATURE_PROJECTS ||'' owned by this user.'';',
'    elsif l_count_0 > 0 then',
'       l_return := ''Report excludes ''||l_0_link || '' ''||',
'                    case when l_count_0 = 1 then :NOMENCLATURE_PROJECT else :NOMENCLATURE_PROJECTS end ||''  owned by this user.'';',
'    elsif l_count_100 > 0 then',
'       l_return := ''Report excludes ''||l_100_link || '' ''||',
'                    case when l_count_100 = 1 then :NOMENCLATURE_PROJECT else :NOMENCLATURE_PROJECTS end ||''  owned by this user.'';',
'    end if;',
'',
'    return ''<br/>''||l_return;',
' end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P5_ID'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select 1',
'      from sp_projects p',
'     where pct_complete in (0,100)',
'       and owner_id = :P5_ID',
'       and archived_yn = ''N'''))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6356410783735801723)
,p_button_sequence=>1000
,p_button_plug_id=>wwv_flow_imp.id(5990050447980755364)
,p_button_name=>'external_link'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft:t-Button--padLeft:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(141215539798004369050)
,p_button_image_alt=>'External Directory'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:window.open(''&P5_EXT_LINK.'',''_blank'');'
,p_button_condition=>'P5_EXT_LINK'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-external-link'
,p_button_cattributes=>'title="External Directory"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14008464420978832526)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(14008464851026832530)
,p_button_name=>'SUBSCRIBE_ME_EXCEPT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_image_alt=>'Subscribe me'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from sp_notifications n',
' where static_id = ''PROJECT_EXCEPTIONS''',
'   and is_active_yn = ''Y''',
'   and not exists (select 1 from sp_notification_subscriptions',
'                    where notification_id = n.id',
'                      and team_member_id = :APP_USER_ID',
'                      and opted_in_yn = ''Y'')',
'   and :APP_USER_ID is not null',
'   and :P5_ID = :APP_USER_ID'))
,p_button_condition_type=>'EXISTS'
,p_required_patch=>wwv_flow_imp.id(13014838139098269244)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14803335852223676240)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(26919107944949069644)
,p_button_name=>'SUBSCRIBE_ME_CHANGES'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_image_alt=>'Subscribe me'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from sp_notifications n',
' where static_id = ''PROJECT_CHANGES''',
'   and is_active_yn = ''Y''',
'   and not exists (select 1 from sp_notification_subscriptions',
'                    where notification_id = n.id',
'                      and team_member_id = :APP_USER_ID',
'                      and opted_in_yn = ''Y'')',
'   and :APP_USER_ID is not null',
'   and :P5_ID = :APP_USER_ID'))
,p_button_condition_type=>'EXISTS'
,p_required_patch=>wwv_flow_imp.id(13014838139098269244)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14008466589915832547)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(14008464851026832530)
,p_button_name=>'UNSUBSCRIBE_ME_EXCEPT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_image_alt=>'Unsubscribe'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from sp_notifications n',
' where static_id = ''PROJECT_EXCEPTIONS''',
'   and is_active_yn = ''Y''',
'   and exists (select 1 from sp_notification_subscriptions',
'                where notification_id = n.id',
'                  and team_member_id = :APP_USER_ID',
'                  and opted_in_yn = ''Y'')',
'   and :P5_ID = :APP_USER_ID'))
,p_button_condition_type=>'EXISTS'
,p_required_patch=>wwv_flow_imp.id(13014838139098269244)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14803336302772676240)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(26919107944949069644)
,p_button_name=>'UNSUBSCRIBE_ME_CHANGES'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_image_alt=>'Unsubscribe'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from sp_notifications n',
' where static_id = ''PROJECT_CHANGES''',
'   and is_active_yn = ''Y''',
'   and exists (select 1 from sp_notification_subscriptions',
'                where notification_id = n.id',
'                  and team_member_id = :APP_USER_ID',
'                  and opted_in_yn = ''Y'')',
'   and :P5_ID = :APP_USER_ID'))
,p_button_condition_type=>'EXISTS'
,p_required_patch=>wwv_flow_imp.id(13014838139098269244)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13394403178878490029)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(14008465030510832532)
,p_button_name=>'SUBSCRIBE_ME_SUMMARY'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_image_alt=>'Subscribe me'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from sp_notifications n',
' where static_id = ''WEEKLY_SUMMARY''',
'   and is_active_yn = ''Y''',
'   and not exists (select 1 from sp_notification_subscriptions',
'                    where notification_id = n.id',
'                      and team_member_id = :APP_USER_ID',
'                      and opted_in_yn = ''Y'')',
'   and :APP_USER_ID is not null',
'   and :P5_ID = :APP_USER_ID'))
,p_button_condition_type=>'EXISTS'
,p_required_patch=>wwv_flow_imp.id(13014838139098269244)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14008464376731832525)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(14008464851026832530)
,p_button_name=>'EMAIL_ME_EXCEPT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_image_alt=>'Email to me'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14803335501508676239)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(26919107944949069644)
,p_button_name=>'EMAIL_ME_CHANGES'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_image_alt=>'Email to me'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14008466444436832546)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(14008465030510832532)
,p_button_name=>'UNSUBSCRIBE_ME_SUMMARY'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_image_alt=>'Unsubscribe'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from sp_notifications n',
' where static_id = ''WEEKLY_SUMMARY''',
'   and is_active_yn = ''Y''',
'   and exists (select 1 from sp_notification_subscriptions',
'                where notification_id = n.id',
'                  and team_member_id = :APP_USER_ID',
'                  and opted_in_yn = ''Y'')',
'   and :P5_ID = :APP_USER_ID'))
,p_button_condition_type=>'EXISTS'
,p_required_patch=>wwv_flow_imp.id(13014838139098269244)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13088071954553570940)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(14008465030510832532)
,p_button_name=>'EMAIL_ME_SUMMARY'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(141215539616368369049)
,p_button_image_alt=>'Email to me'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4764713116391496251)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10792849966281629074)
,p_button_name=>'UP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141215539010391369046)
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:74:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4761354007588584833)
,p_name=>'P5_INCLUDE_FUTURE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(17111043616997483244)
,p_item_default=>'N'
,p_prompt=>'Include Future'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(141215538820216369045)
,p_item_template_options=>'#DEFAULT#:margin-left-md'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4761354864092584842)
,p_name=>'P5_INCLUDE_PAST'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(17111043616997483244)
,p_item_default=>'N'
,p_prompt=>'Include Past'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(141215538820216369045)
,p_item_template_options=>'#DEFAULT#:margin-left-md'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6264571815553585554)
,p_name=>'P5_PHOTO_DEFAULT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(10700310081182694055)
,p_item_default=>'#APP_FILES#default-user-avatar.png'
,p_prompt=>'Photo'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_tag_css_classes=>'mxw160'
,p_display_when=>'select 1 from sp_team_members where id = :P5_ID and photo is not null'
,p_display_when_type=>'NOT_EXISTS'
,p_field_template=>wwv_flow_imp.id(141215536714581369037)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'URL'
,p_attribute_02=>'Placeholder Photo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6356410873233801724)
,p_name=>'P5_EXT_LINK'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(10700310081182694055)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select replace(apex_app_setting.get_value(''EXTERNAL_PERSON_LINK''),''#EMAIL#'',lower(email)) ',
'  from sp_team_members',
' where id = :P5_ID',
'   and email is not null',
'   and apex_app_setting.get_value(''EXTERNAL_PERSON_LINK_DOMAIN'') is not null',
'   and lower(email) like ''%@''||lower(apex_app_setting.get_value(''EXTERNAL_PERSON_LINK_DOMAIN''))'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'WEB_SAFE'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8680615244727048365)
,p_name=>'P5_EMAIL'
,p_item_sequence=>91
,p_item_plug_id=>wwv_flow_imp.id(116939741687806079110)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'WEB_SAFE'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8680615433957048367)
,p_name=>'P5_FIRST_NAME'
,p_item_sequence=>101
,p_item_plug_id=>wwv_flow_imp.id(116939741687806079110)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'WEB_SAFE'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8680615559784048368)
,p_name=>'P5_LAST_NAME'
,p_item_sequence=>111
,p_item_plug_id=>wwv_flow_imp.id(116939741687806079110)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'WEB_SAFE'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10417246638558546400)
,p_name=>'P5_PHOTO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10700310081182694055)
,p_prompt=>'Photo'
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_tag_css_classes=>'mxw160'
,p_display_when=>'select 1 from sp_team_members where id = :P5_ID and photo is not null'
,p_display_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(141215536714581369037)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'SQL'
,p_attribute_06=>'select PHOTO from sp_team_members where id = :P5_ID'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10425788643879863865)
,p_name=>'P5_NAME'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(10700310081182694055)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'WEB_SAFE'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(116939739953531079093)
,p_name=>'P5_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(116939741687806079110)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(8680613804264048350)
,p_computation_sequence=>50
,p_computation_item=>'LAST_PROJECT_VIEW'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'5'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(2809663723270611757)
,p_computation_sequence=>60
,p_computation_item=>'P5_EMAIL'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>'select email from sp_team_members t where id = :P5_ID'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4761354025672584834)
,p_name=>'on include future change'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_INCLUDE_FUTURE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4761354118316584835)
,p_event_id=>wwv_flow_imp.id(4761354025672584834)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P5_INCLUDE_FUTURE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4761354293889584836)
,p_event_id=>wwv_flow_imp.id(4761354025672584834)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(17111043616997483244)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4761354996485584843)
,p_name=>'on change of include past'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_INCLUDE_PAST'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4761355027666584844)
,p_event_id=>wwv_flow_imp.id(4761354996485584843)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_02=>'P5_INCLUDE_PAST'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4761355190217584845)
,p_event_id=>wwv_flow_imp.id(4761354996485584843)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(17111043616997483244)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3274016285253163042)
,p_name=>'refresh on modal close'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(11657193321314643892)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3274017647566163056)
,p_event_id=>wwv_flow_imp.id(3274016285253163042)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10336219585502558487)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15323518861686323930)
,p_name=>'refresh reviews'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(19157928852844078515)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15323518933706323931)
,p_event_id=>wwv_flow_imp.id(15323518861686323930)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(19157928852844078515)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13088134791130135744)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Email summary'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_summary      clob;',
'begin',
'',
'    l_summary := sp_contributor_summary.generate (',
'                     p_team_member_id    => :P5_ID,',
'                     p_show_activities   => ''Y'',',
'                     p_show_projects     => ''Y'',',
'                     p_links             => ''EMAIL''',
'                     );',
'',
'    apex_mail.send ( ',
'            p_to                 => :APP_USER,   ',
'            p_from               => :APP_USER,  ',
'            p_application_id     => :APP_ID,  ',
'            p_template_static_id => ''EMAIL_ME'',  ',
'            p_placeholders       => ''{'' || ''"APPLICATION_LINK": "'' || sp_strategic_proj_util.get_setting(p_static_id => ''APP_HOME_URL'') ||''", ''|| ',
'                                           ''"APP_NAME": ''   || apex_json.stringify( :NOMENCLATURE_STRATEGIC_PLANNER ) ||'', ''||',
'                                           ''"SUBJECT": ''    || apex_json.stringify( :NOMENCLATURE_STRATEGIC_PLANNER ||'' Weekly Summary'') ||'', ''||',
'                                           ''"SUMMARY": ''    || apex_json.stringify( l_summary ) ||',
'                                     ''}'' ); ',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(13088071954553570940)
,p_process_success_message=>'Weekly Summary email sent.'
,p_internal_uid=>11195442678695696622
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14008464574627832527)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Email exceptions'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_summary      clob;',
'begin',
'',
'    l_summary := sp_contributor_summary.project_exceptions (',
'                     p_team_member_id  => :P5_ID,',
'                     p_links           => ''EMAIL''',
'                     );',
'',
'    apex_mail.send ( ',
'            p_to                 => :APP_USER,   ',
'            p_from               => :APP_USER,  ',
'            p_application_id     => :APP_ID,  ',
'            p_template_static_id => ''EMAIL_ME'',  ',
'            p_placeholders       => ''{'' || ''"APPLICATION_LINK": "'' || sp_strategic_proj_util.get_setting(p_static_id => ''APP_HOME_URL'') ||''", ''|| ',
'                                           ''"APP_NAME": ''   || apex_json.stringify( :NOMENCLATURE_STRATEGIC_PLANNER ) ||'', ''||',
'                                           ''"SUBJECT": ''    || apex_json.stringify( :NOMENCLATURE_STRATEGIC_PLANNER ||'' ''||:NOMENCLATURE_PROJECT ||'' Exceptions'') ||'', ''||',
'                                           ''"SUMMARY": ''    || apex_json.stringify( l_summary ) ||',
'                                     ''}'' ); ',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(14008464376731832525)
,p_process_success_message=>'Project Exceptions email sent.'
,p_internal_uid=>12115772462193393405
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14241502016030255362)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Email changes'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_changes_yn  varchar2(1);',
'    l_summary     clob;',
'begin',
'',
'    sp_contributor_summary.project_changes (',
'        p_team_member_id => :APP_USER_ID,',
'        p_frequency      => ''WEEKLY'',',
'        p_links          => ''EMAIL'',',
'        p_changes_yn     => l_changes_yn,',
'        p_change_summary => l_summary );',
'',
'    if l_changes_yn = ''Y'' then',
'',
'        apex_mail.send ( ',
'                p_to                 => :APP_USER,   ',
'                p_from               => :APP_USER,  ',
'                p_application_id     => :APP_ID,  ',
'                p_template_static_id => ''EMAIL_ME'',  ',
'                p_placeholders       => ''{'' || ''"APPLICATION_LINK": "'' || sp_strategic_proj_util.get_setting(p_static_id => ''APP_HOME_URL'') ||''", ''|| ',
'                                               ''"APP_NAME": ''   || apex_json.stringify( :NOMENCLATURE_STRATEGIC_PLANNER ) ||'', ''||',
'                                               ''"SUBJECT": ''    || apex_json.stringify( :NOMENCLATURE_STRATEGIC_PLANNER ||'' ''||:NOMENCLATURE_PROJECT ||'' Changes'') ||'', ''||',
'                                               ''"SUMMARY": ''    || apex_json.stringify( l_summary ) ||',
'                                         ''}'' ); ',
'',
'    end if;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'#SQLERRM#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(14803335501508676239)
,p_process_success_message=>'Project changes email sent.'
,p_internal_uid=>12348809903595816240
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13394403308311490030)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Subscribe summary'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_strategic_proj_util.notification_opt_in (',
'    p_team_member_id  => :APP_USER_ID,',
'    p_notification_id => sp_strategic_proj_util.get_notification_id(''WEEKLY_SUMMARY'') );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(13394403178878490029)
,p_process_success_message=>'Subscribed to Weekly Summary.'
,p_internal_uid=>11501711195877050908
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14008466682620832548)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Unsubscribe summary'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_strategic_proj_util.notification_opt_out (',
'    p_team_member_id  => :APP_USER_ID,',
'    p_notification_id => sp_strategic_proj_util.get_notification_id(''WEEKLY_SUMMARY'') );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(14008466444436832546)
,p_process_success_message=>'Unsubscribed from Weekly Summary.'
,p_internal_uid=>12115774570186393426
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14008464693114832528)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Subscribe exceptions'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_strategic_proj_util.notification_opt_in (',
'    p_team_member_id  => :APP_USER_ID,',
'    p_notification_id => sp_strategic_proj_util.get_notification_id(''PROJECT_EXCEPTIONS'') );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(14008464420978832526)
,p_process_success_message=>'Subscribed to Project Exceptions.'
,p_internal_uid=>12115772580680393406
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14008466760905832549)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Unsubscribe exceptions'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_strategic_proj_util.notification_opt_out (',
'    p_team_member_id  => :APP_USER_ID,',
'    p_notification_id => sp_strategic_proj_util.get_notification_id(''PROJECT_EXCEPTIONS'') );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(14008466589915832547)
,p_process_success_message=>'Unsubscribed from Project Exceptions.'
,p_internal_uid=>12115774648471393427
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14241502304348255364)
,p_process_sequence=>120
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Subscribe changes'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_strategic_proj_util.notification_opt_in (',
'    p_team_member_id  => :APP_USER_ID,',
'    p_notification_id => sp_strategic_proj_util.get_notification_id(''PROJECT_CHANGES'') );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(14803335852223676240)
,p_process_success_message=>'Subscribed to Project Changes.'
,p_internal_uid=>12348810191913816242
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(14241502380422255365)
,p_process_sequence=>130
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Unsubscribe changes'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_strategic_proj_util.notification_opt_out (',
'    p_team_member_id  => :APP_USER_ID,',
'    p_notification_id => sp_strategic_proj_util.get_notification_id(''PROJECT_CHANGES'') );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(14803336302772676240)
,p_process_success_message=>'Unsubscribed from Project Changes.'
,p_internal_uid=>12348810267987816243
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(12222261717360721839)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'sync roles'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_strategic_proj_util.sync_team_member_app_role (',
'    p_app_id => :APP_ID,',
'    p_email  => :P5_EMAIL);'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>10329569604926282717
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8680615374481048366)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set first and last name session state'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (select first_name, last_name',
'from sp_team_members tm',
'where tm.id = :P5_ID) loop',
'    :P5_FIRST_NAME := c1.first_name;',
'    :P5_LAST_NAME  := c1.last_Name;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>6787923262046609244
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(6369789208374337643)
,p_region_id=>wwv_flow_imp.id(11657193321314643892)
,p_position_id=>wwv_flow_imp.id(3744591539380446466)
,p_display_sequence=>10
,p_template_id=>wwv_flow_imp.id(3744592141057477595)
,p_label=>'Edit My Profile'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:144:&SESSION.::&DEBUG.:RP,144:P144_ID:&P5_ID.'
,p_button_display_type=>'TEXT_WITH_ICON'
,p_icon_css_classes=>'fa-edit'
,p_is_hot=>true
,p_show_as_disabled=>false
,p_condition_type=>'EXISTS'
,p_condition_expr1=>'select 1 from sp_team_members where email = lower(:APP_USER) and id = :P5_ID'
,p_exec_cond_for_each_row=>true
,p_authorization_scheme=>wwv_flow_imp.id(141215568256718369146)
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(11657193621893643895)
,p_region_id=>wwv_flow_imp.id(11657193321314643892)
,p_position_id=>wwv_flow_imp.id(3744591539380446466)
,p_display_sequence=>20
,p_template_id=>wwv_flow_imp.id(3744593400577481743)
,p_label=>'Actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(17111045611744483264)
,p_region_id=>wwv_flow_imp.id(17111043616997483244)
,p_position_id=>wwv_flow_imp.id(3730998512383070862)
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:FI,PN:&FRIENDLY_IDENTIFIER.,&PROJECT_URL_NAME.'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(17111045775439483265)
,p_region_id=>wwv_flow_imp.id(17111043616997483244)
,p_position_id=>wwv_flow_imp.id(3744591539380446466)
,p_display_sequence=>20
,p_template_id=>wwv_flow_imp.id(3744593400577481743)
,p_label=>'Actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_action_css_classes=>'t-Button--noUI'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(4761354312755584837)
,p_component_action_id=>wwv_flow_imp.id(11657193621893643895)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Manage User Access'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:10012:&SESSION.:FROMPERSON:&DEBUG.:RP,10012:P10012_USER_NAME:&P5_EMAIL.'
,p_icon_css_classes=>'fa-lock'
,p_authorization_scheme=>wwv_flow_imp.id(141215568204418369146)
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(4761354470882584838)
,p_component_action_id=>wwv_flow_imp.id(11657193621893643895)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Edit (Admin)'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:RP,20:P20_ID:&P5_ID.'
,p_icon_css_classes=>'fa-edit'
,p_authorization_scheme=>wwv_flow_imp.id(141215568204418369146)
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(6872687170760709448)
,p_component_action_id=>wwv_flow_imp.id(11657193621893643895)
,p_menu_entry_type=>'SEPARATOR'
,p_display_sequence=>50
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(7515088641105683960)
,p_component_action_id=>wwv_flow_imp.id(11657193621893643895)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Reset'
,p_display_sequence=>60
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:RP,5:P5_ID:&P5_ID.'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(11657194327800643902)
,p_component_action_id=>wwv_flow_imp.id(11657193621893643895)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Refresh'
,p_display_sequence=>70
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(16587874502217848926)
,p_component_action_id=>wwv_flow_imp.id(11657193621893643895)
,p_menu_entry_type=>'ENTRY'
,p_label=>'My Quick Look'
,p_display_sequence=>40
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:73:&SESSION.::&DEBUG.:RP,73:P73_TEAM_MEMBER_ID:&APP_USER_ID.'
,p_icon_css_classes=>'fa-user'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(17111045837924483266)
,p_component_action_id=>wwv_flow_imp.id(17111045775439483265)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Edit Activity'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:101:&SESSION.::&DEBUG.:RP,101:P101_ID:&ID.'
,p_icon_css_classes=>'fa-edit'
,p_authorization_scheme=>wwv_flow_imp.id(141215568360703369146)
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(17193158336778980335)
,p_component_action_id=>wwv_flow_imp.id(17111045775439483265)
,p_menu_entry_type=>'ENTRY'
,p_label=>'View &NOMENCLATURE_PROJECT.'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,:FI,PN:&FRIENDLY_IDENTIFIER.,&PROJECT_URL_NAME.'
,p_icon_css_classes=>'fa-glasses'
,p_authorization_scheme=>wwv_flow_imp.id(141215568256718369146)
);
wwv_flow_imp.component_end;
end;
/
