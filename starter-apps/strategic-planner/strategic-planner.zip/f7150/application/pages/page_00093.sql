prompt --application/pages/page_00093
begin
--   Manifest
--     PAGE: 00093
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>93
,p_name=>'Links'
,p_alias=>'SYSTEM-LINKS'
,p_page_mode=>'MODAL'
,p_step_title=>'Links'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'25'
,p_last_updated_by=>'MIKE'
,p_last_upd_yyyymmddhh24miss=>'20240417225634'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5954706752525821353)
,p_plug_name=>'Perma Link'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141179964373655434900)
,p_plug_display_sequence=>20
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_url                   varchar2(4000);',
'    l_friendly_identifier   varchar2(255) := null;',
'begin',
'    for c1 in (select friendly_identifier from sp_projects p where p.id = :P93_ID) loop',
'        l_friendly_identifier := c1.friendly_identifier;',
'    end loop;',
'    l_url := apex_page.get_url(',
'                     p_application => :APP_ID,',
'                     p_page        => 3,',
'                     p_session     => null,',
'                     p_items       => ''FI'',',
'                     p_values      => l_friendly_identifier,',
'                     p_plain_url   => TRUE );',
'    l_url := rtrim(OWA_UTIL.get_cgi_env(''HTTP_REFERER''),''/'') || l_url; ',
'    return ''<br><strong>Permalink</strong>:<br>''||',
'           ''<a href="''||l_url||''" target="_blank">''||apex_escape.html(l_url)||''</a>'';',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5954707296169821358)
,p_plug_name=>'External Link'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141179964373655434900)
,p_plug_display_sequence=>30
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_clob clob := null;',
'begin',
'    l_clob := '''';',
'',
'    --',
'    --',
'    --',
'    for c1 in (',
'       select p.external_ticket_identifier,',
'              p.external_ticket_system,',
'              p.external_system_link',
'       from   SP_PROJECTS p',
'       where  id = :P93_ID and ',
'              p.external_ticket_identifier is not null and ',
'              p.external_ticket_system is not null) loop',
'           --',
'           -- External System',
'           --',
'           l_clob := l_clob||''<br><strong>External System</strong>:'';',
'           l_clob := l_clob||''<ul>'';',
'           l_clob := l_clob||''<li>System: ''||apex_escape.html(c1.external_ticket_system)||''</li>'';',
'           l_clob := l_clob||''<li>Identifier: ''||apex_escape.html(c1.external_ticket_identifier)||''</li>'';',
'           l_clob := l_clob||''</ul>'';',
'           --',
'           -- External System Link',
'           --',
'           l_clob := l_clob||''<a href="''||c1.external_system_link||''" target=_blank">''||',
'               apex_escape.html(c1.external_system_link)||''</a>'';',
'    end loop;',
'    return l_clob;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P93_ID'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5954706709951821352)
,p_name=>'P93_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
