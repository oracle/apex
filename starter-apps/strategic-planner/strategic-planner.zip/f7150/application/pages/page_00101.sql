prompt --application/pages/page_00101
begin
--   Manifest
--     PAGE: 00101
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>101
,p_name=>'Activity'
,p_alias=>'ACTIVITY'
,p_page_mode=>'MODAL'
,p_step_title=>'Activity'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(38309584282026711102)
,p_step_template=>1662662927374504442
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_required_role=>wwv_flow_imp.id(176220694531802839665)
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(51181300656086278708)
,p_plug_name=>'Activity'
,p_static_id=>'activity'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'TABLE'
,p_query_table=>'SP_ACTIVITIES'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(51181310365225278743)
,p_plug_name=>'Buttons'
,p_static_id=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2127905476394690047
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(51181310731023278744)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(51181310365225278743)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(51181312916889278748)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(51181310365225278743)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Activity'
,p_button_position=>'NEXT'
,p_button_condition=>'P101_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(51181312089055278748)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(51181310365225278743)
,p_button_name=>'DELETE'
,p_static_id=>'delete'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P101_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(51181312540818278748)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(51181310365225278743)
,p_button_name=>'SAVE'
,p_static_id=>'save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P101_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51181301370361278718)
,p_name=>'P101_ACTIVITY_TYPE_ID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_item_source_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select max(id) from SP_ACTIVITY_TYPES ',
'where is_default_yn = ''Y'''))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Activity Type'
,p_source=>'ACTIVITY_TYPE_ID'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t.ACTIVITY_TYPE,',
'       t.id',
'from SP_ACTIVITY_TYPES t',
'where t.IS_ACTIVE_YN = ''Y'' or ',
'      t.id in (select a.ACTIVITY_TYPE_ID from sp_activities a where a.id = :P101_ID)',
'order by t.DISPLAY_SEQUENCE'))
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_help_text=>'Identifies the type of activity to be performed.  The list of activities is configurable by the application administrator.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '4',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51181303596633278729)
,p_name=>'P101_COMMENTS'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_item_source_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_prompt=>'Activity'
,p_placeholder=>'Briefly describe your activity in 280 characters or less'
,p_source=>'COMMENTS'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>280
,p_cHeight=>3
,p_field_template=>1610598484065263269
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51181303229949278728)
,p_name=>'P101_END_DATE'
,p_source_data_type=>'DATE'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_item_source_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_item_default=>'select sysdate + 14 from dual'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'End Date'
,p_format_mask=>'FMDay DD-MON-YYYY'
,p_source=>'END_DATE'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>1610598484065263269
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
,p_quick_pick_type=>'STATIC'
,p_quick_pick_label_01=>'Same Day'
,p_quick_pick_value_01=>'SAMEDAY'
,p_quick_pick_label_02=>'One Week'
,p_quick_pick_value_02=>'+1W'
,p_quick_pick_label_03=>'Two Weeks'
,p_quick_pick_value_03=>'+2W'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44923620845751041171)
,p_name=>'P101_END_DATE_ONE_WEEK'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44923620691611041170)
,p_name=>'P101_END_DATE_SAME_DAY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44923621115061041174)
,p_name=>'P101_END_DATE_TWO_WEEKS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51181300958728278709)
,p_name=>'P101_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_item_source_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_source=>'ID'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_restricted_characters=>'US_ONLY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42366609554744895744)
,p_name=>'P101_INITIATIVE_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_item_source_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_prompt=>'Optional &NOMENCLATURE_INITIATIVE.'
,p_source=>'INITIATIVE_ID'
,p_display_as=>'NATIVE_SELECT_ONE'
,p_named_lov=>'SP_INITIATIVES.INITIATIVE'
,p_cSize=>30
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_restricted_characters=>'US_ONLY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'fetch_on_search', 'N',
  'infinite_scroll', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51181302043560278724)
,p_name=>'P101_PROJECT_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_item_source_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_prompt=>'Optional &NOMENCLATURE_PROJECT.'
,p_source=>'PROJECT_ID'
,p_display_as=>'NATIVE_SELECT_ONE'
,p_named_lov=>'PROJECTS DETAIL'
,p_cSize=>30
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_restricted_characters=>'US_ONLY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'fetch_on_search', 'N',
  'infinite_scroll', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51181302785628278726)
,p_name=>'P101_START_DATE'
,p_source_data_type=>'DATE'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_item_source_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_item_default=>'select sysdate + 0 from dual'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Start Date'
,p_format_mask=>'FMDay DD-MON-YYYY'
,p_source=>'START_DATE'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>1610598484065263269
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38804094305598280559)
,p_name=>'P101_TAGS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_item_source_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_prompt=>'Tags'
,p_source=>'TAGS'
,p_display_as=>'NATIVE_COMBOBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''research'' tag from dual',
'union select ''development'' tag from dual',
'union select ''integration'' tag from dual',
'union select ''collaboration'' tag from dual'))
,p_cSize=>30
,p_cMaxlength=>4000
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Enter comma separated tags.  Note any spaces will be replaced with a dash "-".'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'fetch_on_search', 'N',
  'infinite_scroll', 'N',
  'match_type', 'CONTAINS',
  'max_values_in_list', '7',
  'min_chars', '0',
  'multi_selection', 'Y')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>','
,p_item_comment=>'Enter comma delimited tags'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51181302402945278725)
,p_name=>'P101_TEAM_MEMBER_ID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_item_source_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_item_default=>'P101_USER_TEAM_MEMBER_ID'
,p_item_default_type=>'ITEM'
,p_prompt=>'Owner'
,p_source=>'TEAM_MEMBER_ID'
,p_display_as=>'NATIVE_SELECT_ONE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select last_name||'', ''||first_name||'' (''||lower(email)||'')'' d, id r',
'  from SP_TEAM_MEMBERS',
' where is_current_yn = ''Y''',
'    or id = :P101_TEAM_MEMBER_ID',
' order by 1'))
,p_cSize=>30
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_restricted_characters=>'US_ONLY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'fetch_on_search', 'N',
  'infinite_scroll', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(39818841627138329960)
,p_name=>'P101_URL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_item_source_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_prompt=>'URL'
,p_source=>'URL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>500
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51181036534785844474)
,p_name=>'P101_USER_TEAM_MEMBER_ID'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_restricted_characters=>'US_ONLY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(51181036636719844475)
,p_name=>'P101_USER_TEAM_MEMBER_NAME'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(51181300656086278708)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(44923621077955041173)
,p_computation_sequence=>40
,p_computation_item=>'P101_END_DATE_ONE_WEEK'
,p_static_id=>'p101-end-date-one-week'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(sysdate + 7,''FMDay DD-MON-YYYY'')',
'  from dual',
' where :P101_ID is null',
'union all',
'select to_char(start_date + 7,''FMDay DD-MON-YYYY'')',
'  from sp_activities',
' where id = :P101_ID',
'   and :P101_ID is not null'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(44923621188370041175)
,p_computation_sequence=>50
,p_computation_item=>'P101_END_DATE_TWO_WEEKS'
,p_static_id=>'p101-end-date-two-weeks'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(sysdate + 14,''FMDay DD-MON-YYYY'')',
'  from dual',
' where :P101_ID is null',
'union all',
'select to_char(start_date + 14,''FMDay DD-MON-YYYY'')',
'  from sp_activities',
' where id = :P101_ID',
'   and :P101_ID is not null'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(51181036712097844476)
,p_computation_sequence=>10
,p_computation_item=>'P101_USER_TEAM_MEMBER_ID'
,p_static_id=>'p101-user-team-member-id'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>'select id from sp_team_members where email = lower(:APP_USER)'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(51181036851898844477)
,p_computation_sequence=>20
,p_computation_item=>'P101_USER_TEAM_MEMBER_NAME'
,p_static_id=>'p101-user-team-member-name'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select first_name||'' ''||last_name||'' (''||email||'')'' x ',
'from sp_team_members where id = :P101_USER_TEAM_MEMBER_ID'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(51181310851730278744)
,p_name=>'Cancel Dialog'
,p_static_id=>'cancel-dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(51181310731023278744)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(51181311624133278747)
,p_event_id=>wwv_flow_imp.id(51181310851730278744)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-dialog-cancel'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(44923621284324041176)
,p_name=>'recalc end quick picks'
,p_static_id=>'recalc-end-quick-picks'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P101_START_DATE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44923621896104041182)
,p_event_id=>wwv_flow_imp.id(44923621284324041176)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_name=>'update end_date_one_week quick pick'
,p_static_id=>'update-end-date-one-week-quick-pick'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P101_END_DATE_ONE_WEEK'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'escape_special_characters', 'Y',
  'items_to_submit', 'P101_START_DATE',
  'sql_query', wwv_flow_string.join(wwv_flow_t_varchar2(
    'select to_char(nvl(to_date(:P101_START_DATE,''FMDay DD-MON-YYYY''),sysdate) + 7,''FMDay DD-MON-YYYY'')',
    '  from dual')),
  'suppress_change_event', 'N',
  'type', 'SQL_STATEMENT')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44923621422482041177)
,p_event_id=>wwv_flow_imp.id(44923621284324041176)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_name=>'update end_date_same_day quick pick'
,p_static_id=>'update-end-date-same-day-quick-pick'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P101_END_DATE_SAME_DAY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'escape_special_characters', 'Y',
  'items_to_submit', 'P101_START_DATE',
  'sql_query', wwv_flow_string.join(wwv_flow_t_varchar2(
    'select nvl(:P101_START_DATE,to_char(sysdate,''FMDay DD-MON-YYYY''))',
    '  from dual')),
  'suppress_change_event', 'N',
  'type', 'SQL_STATEMENT')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44923622056149041183)
,p_event_id=>wwv_flow_imp.id(44923621284324041176)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_name=>'update end_date_two_weeks quick pick'
,p_static_id=>'update-end-date-two-weeks-quick-pick'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P101_END_DATE_TWO_WEEKS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'escape_special_characters', 'Y',
  'items_to_submit', 'P101_START_DATE',
  'sql_query', wwv_flow_string.join(wwv_flow_t_varchar2(
    'select to_char(nvl(to_date(:P101_START_DATE,''FMDay DD-MON-YYYY''),sysdate) + 14,''FMDay DD-MON-YYYY'')',
    '  from dual')),
  'suppress_change_event', 'N',
  'type', 'SQL_STATEMENT')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(44923621688738041180)
,p_name=>'Update after quick pick'
,p_static_id=>'update-after-quick-pick'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P101_END_DATE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44923622132445041184)
,p_event_id=>wwv_flow_imp.id(44923621688738041180)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'set end for one week'
,p_static_id=>'set-end-for-one-week'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P101_END_DATE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_expression', '$v(''P101_END_DATE_ONE_WEEK'')',
  'suppress_change_event', 'N',
  'type', 'JAVASCRIPT_EXPRESSION')).to_clob
,p_wait_for_result=>'Y'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P101_END_DATE'
,p_client_condition_expression=>'+1W'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44923621796997041181)
,p_event_id=>wwv_flow_imp.id(44923621688738041180)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'set end for same day'
,p_static_id=>'set-end-for-same-day'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P101_END_DATE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_expression', '$v(''P101_END_DATE_SAME_DAY'')',
  'suppress_change_event', 'N',
  'type', 'JAVASCRIPT_EXPRESSION')).to_clob
,p_wait_for_result=>'Y'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P101_END_DATE'
,p_client_condition_expression=>'SAMEDAY'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44923622218753041185)
,p_event_id=>wwv_flow_imp.id(44923621688738041180)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'set end for two weeks'
,p_static_id=>'set-end-for-two-weeks'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P101_END_DATE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_expression', '$v(''P101_END_DATE_TWO_WEEKS'')',
  'suppress_change_event', 'N',
  'type', 'JAVASCRIPT_EXPRESSION')).to_clob
,p_wait_for_result=>'Y'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P101_END_DATE'
,p_client_condition_expression=>'+2W'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(51181314094340278751)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_static_id=>'close-dialog'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_success_messages', 'Y')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>14283495810806369110
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(51181313361913278749)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(51181300656086278708)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Activity'
,p_static_id=>'initialize-form-activity'
,p_internal_uid=>14283495078379369108
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38334209891506809551)
,p_process_sequence=>60
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'log'
,p_static_id=>'log'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_log.log_interaction(',
'    p_project_id => :P101_PROJECT_ID);'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>1436391607972899910
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(51181313725274278751)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(51181300656086278708)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Activity'
,p_static_id=>'process-form-activity'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'lock_row', 'Y',
  'prevent_lost_updates', 'Y',
  'return_primary_keys_after_insert', 'Y',
  'target_type', 'REGION_SOURCE')).to_clob
,p_process_error_message=>'Error'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed'
,p_internal_uid=>14283495441740369110
);
wwv_flow_imp.component_end;
end;
/
