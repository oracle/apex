prompt --application/pages/page_00200
begin
--   Manifest
--     PAGE: 00200
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>26954343551793662
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>200
,p_name=>'Release History'
,p_alias=>'RELEASE-HISTORY'
,p_step_title=>'Release History'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(24597724860659036099)
,p_plug_name=>'History'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215436556892368933)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.project                           project,',
'       ''P''||to_char(p.priority_id)         priority,',
'       p.PROJECT_SIZE                      project_size,',
'       (select tm.first_name||'' ''||tm.last_name',
'        from   sp_team_members TM  ',
'        where  tm.id = p.OWNER_ID)         owner,',
'       decode(p.ACTIVE_YN,''Y'',''Yes'',''No'')  active,',
'       p.FRIENDLY_IDENTIFIER               FI,',
'       p.PROJECT_URL_NAME                  PN,                   ',
'       --',
'       pc.PROJECT_ID                       project_id,',
'       pc.changed_on ATTRIBUTE_CHANGE_DATE,',
'       to_char(pc.changed_on,''YYYY.MM'') ATTRIBUTE_CHANGE_Month,',
'       --',
'       :NOMENCLATURE_PROJECT||'' ''||initcap(replace(pc.attribute_column,''_'','' '')) ATTRIBUTE_COLUMN,',
'       case pc.change_type when ''CREATE'' then ''Added''',
'                           when ''UPDATE'' then ''Updated''',
'                           when ''DELETE'' then ''Deleted''',
'                           else pc.change_type',
'            end change_type,',
'       decode(old_value,''Y'',''Yes'',''N'',''No'',old_value) OLD_VALUE,',
'       decode(pc.change_type,''DELETE'',decode(old_value,''Y'',''Yes'',''N'',''No'',old_value),decode(new_value,''Y'',''Yes'',''N'',''No'',new_value)) NEW_VALUE,',
'       changed_by',
'  from SP_PROJECT_HISTORY pc,',
'       sp_projects p',
'where  p.release_id = :P200_RELEASE_ID ',
'       and p.id = pc.project_id',
'       and p.ARCHIVED_YN = ''N''',
'union all',
'select null         project,',
'       null         priority,',
'       null         project_size,',
'       (select tm.first_name||'' ''||tm.last_name',
'        from   sp_team_members TM  ',
'        where  tm.id = r.RELEASE_OWNER_ID)         owner,',
'       null      active,',
'       null      FI,',
'       null      PN,                   ',
'       --',
'       null       project_id,',
'       h.changed_on ATTRIBUTE_CHANGE_DATE,',
'       to_char(h.changed_on,''YYYY.MM'') ATTRIBUTE_CHANGE_Month,',
'       --',
'       initcap(replace(h.attribute_column,''_'','' '')) ATTRIBUTE_COLUMN,',
'       case h.change_type when ''CREATE'' then ''Added''',
'                           when ''UPDATE'' then ''Updated''',
'                           when ''DELETE'' then ''Deleted''',
'                           else h.change_type',
'            end change_type,',
'       decode(old_value,''Y'',''Yes'',''N'',''No'',old_value) OLD_VALUE,',
'       decode(h.change_type,''DELETE'',decode(old_value,''Y'',''Yes'',''N'',''No'',old_value),decode(new_value,''Y'',''Yes'',''N'',''No'',new_value)) NEW_VALUE,',
'       changed_by',
'  from sp_release_history h,',
'       sp_release_trains r',
' where r.id = :P200_RELEASE_ID ',
'   and r.id = h.release_id'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P200_RELEASE_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'History'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(24597726275912036114)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MIKE'
,p_internal_uid=>22705034163477596992
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24597726436659036115)
,p_db_column_name=>'PROJECT'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Project'
,p_column_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:FI,PN:#FI#,#PN#'
,p_column_linktext=>'#PROJECT#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24597726498056036116)
,p_db_column_name=>'PRIORITY'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Priority'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24597726655490036117)
,p_db_column_name=>'PROJECT_SIZE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Size'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24957648007391788168)
,p_db_column_name=>'OWNER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Owner'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24957648235323788170)
,p_db_column_name=>'PROJECT_ID'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Project Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(29784208088257813446)
,p_db_column_name=>'CHANGE_TYPE'
,p_display_order=>70
,p_column_identifier=>'P'
,p_column_label=>'Change'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24957648291665788171)
,p_db_column_name=>'ATTRIBUTE_CHANGE_DATE'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'When'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24957648457907788172)
,p_db_column_name=>'ATTRIBUTE_CHANGE_MONTH'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Month'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24957648501028788173)
,p_db_column_name=>'ATTRIBUTE_COLUMN'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Attribute'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24957648566100788174)
,p_db_column_name=>'OLD_VALUE'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Old Value'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24957648757347788175)
,p_db_column_name=>'NEW_VALUE'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Value'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24957648855714788176)
,p_db_column_name=>'CHANGED_BY'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Changed By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24957650348200788191)
,p_db_column_name=>'ACTIVE'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'Active'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24957650372102788192)
,p_db_column_name=>'FI'
,p_display_order=>150
,p_column_identifier=>'N'
,p_column_label=>'Fi'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24957650548190788193)
,p_db_column_name=>'PN'
,p_display_order=>160
,p_column_identifier=>'O'
,p_column_label=>'Pn'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(24957474008168426436)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'39046340'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ATTRIBUTE_CHANGE_DATE:ATTRIBUTE_COLUMN:CHANGE_TYPE:CHANGED_BY:PROJECT:NEW_VALUE'
,p_sort_column_1=>'ATTRIBUTE_CHANGE_DATE'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'NEW_VALUE'
,p_sort_direction_2=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33341207153232593792)
,p_plug_name=>'Breadcrumb'
,p_region_sub_css_classes=>'has-header-actions'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(141215451086209368948)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(141215269149411368828)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(141215541295426369052)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37415360788861805726)
,p_plug_name=>'Menubar'
,p_parent_plug_id=>wwv_flow_imp.id(33341207153232593792)
,p_region_sub_css_classes=>'header-actions'
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>'select 1 as actions from dual'
,p_template_component_type=>'PARTIAL'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'AVATAR_ICON', 'fa-user',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_TYPE', 'icon',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--md',
  'BADGE_LABEL_DISPLAY', 'N',
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(37415362022367805738)
,p_name=>'ACTIONS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIONS'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(53590151951183633156)
,p_name=>'Release'
,p_template=>wwv_flow_imp.id(141215438656052368935)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:t-Region--scrollBody:t-Region-orderBy--end:margin-left-md'
,p_component_template_options=>'#DEFAULT#:t-ContextualInfo-label--stacked'
,p_display_point=>'REGION_POSITION_01'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.ID,',
'       r.RELEASE_TRAIN||'' ''||r.RELEASE release,',
'       decode(r.RELEASE_TARGET_DATE,null,    ''No Date'',to_char(r.RELEASE_TARGET_DATE,   ''DD-MON-YY'')) RELEASE_TARGET_DATE,',
'       decode(r.RELEASE_OPEN_DATE,null,      ''No Date'',to_char(r.RELEASE_OPEN_DATE,     ''DD-MON-YY'')) RELEASE_OPEN_DATE,',
'       greatest(round(r.RELEASE_TARGET_DATE - sysdate),0) days_remaining,',
'       --',
'       -- projects',
'       --',
'       (select count(*) ',
'       from sp_projects p ',
'       where p.release_id = r.id and ',
'             p.ARCHIVED_YN = ''N'' and ',
'             p.RELEASE_DEPENDENT_YN = ''Y'' and ',
'             p.DUPLICATE_OF_PROJECT_ID is null) projects,',
'       --',
'       --',
'       --',
'       round(r.RELEASE_TARGET_DATE - r.RELEASE_OPEN_DATE) release_length,',
'       -- ',
'       -- team members',
'       --',
'       (select count(distinct TEAM_MEMBER_ID) ',
'       from SP_PROJECT_CONTRIBUTORS c ',
'       where c.PROJECT_ID in (',
'           select id ',
'           from sp_projects p ',
'           where p.release_id = r.id and ',
'                 p.ARCHIVED_YN = ''N'' and ',
'                 p.RELEASE_DEPENDENT_YN = ''Y'' and ',
'                 p.DUPLICATE_OF_PROJECT_ID is null)) contributors,',
'       --',
'       -- owner',
'       --',
'       t.first_name||'' ''||t.last_name owner,',
'       --',
'       -- reviewers',
'       --',
'       (select count(distinct OWNER_ID) from SP_PROJECT_REVIEWS pr where pr.PROJECT_ID in (',
'           select id ',
'           from sp_projects p ',
'           where p.release_id = r.id and ',
'                 ARCHIVED_YN = ''N'' and ',
'                 p.RELEASE_DEPENDENT_YN = ''Y'' and ',
'                 p.DUPLICATE_OF_PROJECT_ID is null)) reviewers,',
'       --',
'       -- milestones',
'       --',
'       (select count(*) from SP_RELEASE_MILESTONES m where m.release_id = r.id) milestones,',
'       (select count(*) from sp_release_comments rc where rc.release_id = r.id) comments,',
'       --',
'       -- release open and close',
'       --',
'       decode(r.RELEASE_OPEN_COMPLETED,''Y'',''Yes'',''N'',''No'',''Unknown'') release_opened,',
'       decode(r.RELEASE_COMPLETED,''Y'',''Yes'',''N'',''No'',''Unknown'') release_completed',
'  from SP_RELEASE_TRAINS r,',
'       SP_TEAM_MEMBERS t',
' where r.id = :P200_RELEASE_ID and ',
'       r.RELEASE_OWNER_ID = t.id(+)'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(141215497118444368989)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16353261857634075175)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16353262238272075175)
,p_query_column_id=>2
,p_column_alias=>'RELEASE'
,p_column_display_sequence=>40
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16353259465704075172)
,p_query_column_id=>3
,p_column_alias=>'RELEASE_TARGET_DATE'
,p_column_display_sequence=>70
,p_column_heading=>'Target Complete'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16353260281931075173)
,p_query_column_id=>4
,p_column_alias=>'RELEASE_OPEN_DATE'
,p_column_display_sequence=>60
,p_column_heading=>'Open'
,p_use_as_row_header=>'N'
,p_column_format=>'DD-MON-YY'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16353262665381075175)
,p_query_column_id=>5
,p_column_alias=>'DAYS_REMAINING'
,p_column_display_sequence=>90
,p_column_heading=>'Remaining'
,p_use_as_row_header=>'N'
,p_column_format=>'99999'
,p_column_html_expression=>'#DAYS_REMAINING# days'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16353260648024075173)
,p_query_column_id=>6
,p_column_alias=>'PROJECTS'
,p_column_display_sequence=>100
,p_column_heading=>'&NOMENCLATURE_PROJECTS.'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16353261037259075174)
,p_query_column_id=>7
,p_column_alias=>'RELEASE_LENGTH'
,p_column_display_sequence=>80
,p_column_heading=>'Length'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'#RELEASE_LENGTH# days'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16353261461827075174)
,p_query_column_id=>8
,p_column_alias=>'CONTRIBUTORS'
,p_column_display_sequence=>130
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16353263091111075176)
,p_query_column_id=>9
,p_column_alias=>'OWNER'
,p_column_display_sequence=>150
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16353259856519075173)
,p_query_column_id=>10
,p_column_alias=>'REVIEWERS'
,p_column_display_sequence=>140
,p_column_heading=>'Reviewers'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16353263420889075176)
,p_query_column_id=>11
,p_column_alias=>'MILESTONES'
,p_column_display_sequence=>110
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16353259078859075172)
,p_query_column_id=>12
,p_column_alias=>'COMMENTS'
,p_column_display_sequence=>120
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16353263830691075177)
,p_query_column_id=>13
,p_column_alias=>'RELEASE_OPENED'
,p_column_display_sequence=>180
,p_column_heading=>'Release Opened'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(16353258675849075171)
,p_query_column_id=>14
,p_column_alias=>'RELEASE_COMPLETED'
,p_column_display_sequence=>170
,p_column_heading=>'Release Completed'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16353446592391941292)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(33341207153232593792)
,p_button_name=>'UP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(141215539010391369046)
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(15375344051875837853)
,p_name=>'P200_RELEASE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(53590151951183633156)
,p_display_as=>'NATIVE_HIDDEN'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16354228015070976510)
,p_name=>'P200_RELEASE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(53590151951183633156)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(16354278912579984897)
,p_computation_sequence=>30
,p_computation_item=>'P200_RELEASE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>'select release_train||'' ''||release d from sp_release_trains where id = :P200_RELEASE_ID'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(37415361089440805729)
,p_region_id=>wwv_flow_imp.id(37415360788861805726)
,p_position_id=>wwv_flow_imp.id(3744591539380446466)
,p_display_sequence=>20
,p_template_id=>wwv_flow_imp.id(3744593400577481743)
,p_label=>'Actions'
,p_button_display_type=>'ICON'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(15375344584493837858)
,p_component_action_id=>wwv_flow_imp.id(37415361089440805729)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Release Calendar'
,p_display_sequence=>40
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.:RP,201:P201_RELEASE_ID:&P200_RELEASE_ID.'
,p_icon_css_classes=>'fa-calendar-o'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(15375344636429837859)
,p_component_action_id=>wwv_flow_imp.id(37415361089440805729)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Release Dashboard'
,p_display_sequence=>50
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.:RP,202:P202_RELEASE_ID:&P200_RELEASE_ID.'
,p_icon_css_classes=>'fa-area-chart'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(15375345824543837871)
,p_component_action_id=>wwv_flow_imp.id(37415361089440805729)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Release Home'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.:RP,:P117_RELEASE_ID:&P200_RELEASE_ID.'
,p_icon_css_classes=>'fa-ship'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(15375345915022837872)
,p_component_action_id=>wwv_flow_imp.id(37415361089440805729)
,p_menu_entry_type=>'SEPARATOR'
,p_display_sequence=>70
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(23433566911407869879)
,p_component_action_id=>wwv_flow_imp.id(37415361089440805729)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Faceted Search'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:RP,300:P300_RELEASE_ID:&P200_RELEASE_ID.'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(37415361169100805730)
,p_component_action_id=>wwv_flow_imp.id(37415361089440805729)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Refresh'
,p_display_sequence=>80
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(37415361795347805736)
,p_component_action_id=>wwv_flow_imp.id(37415361089440805729)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Reset'
,p_display_sequence=>90
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:RR,200:P200_RELEASE_ID:&P200_RELEASE_ID.'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(37415361939366805737)
,p_component_action_id=>wwv_flow_imp.id(37415361089440805729)
,p_menu_entry_type=>'SEPARATOR'
,p_display_sequence=>20
);
wwv_flow_imp.component_end;
end;
/
