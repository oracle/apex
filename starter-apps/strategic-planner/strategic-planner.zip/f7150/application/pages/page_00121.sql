prompt --application/pages/page_00121
begin
--   Manifest
--     PAGE: 00121
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>121
,p_name=>'Request Approval'
,p_alias=>'REQUEST-APPROVAL'
,p_page_mode=>'MODAL'
,p_step_title=>'Request Approval'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(45065107974818639665)
,p_step_template=>1662662927374504442
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_required_role=>wwv_flow_imp.id(176220694531802839665)
,p_required_patch=>wwv_flow_imp.id(46253531127994752923)
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(48137805249268463172)
,p_name=>'Approval Chain'
,p_static_id=>'approval-chain'
,p_template=>4073835273271169698
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rownum, reviewer',
'  from',
'  (',
'select case when c.alternate_team_member_id is not null and   ',
'                 (c.alternate_start_date <= sysdate or c.alternate_start_date is null) and ',
'                 (c.alternate_end_date+1 > sysdate or c.alternate_end_date is null)',
'            then ''Alternate - ''||',
'                 (select last_name||'', ''||first_name||'' (''||lower(email)||'')''',
'                    from sp_team_members',
'                   where id = c.alternate_team_member_id)',
'            else tm.last_name||'', ''||tm.first_name||'' (''||lower(tm.email)||'')'' ',
'            end reviewer',
'  from sp_initiative_approvals ia,',
'       sp_initiative_approval_chain c,',
'       sp_team_members tm,',
'       sp_projects p',
' where ia.approval_type_id = :P121_APPROVAL_TYPE_ID',
'   and ia.initiative_id = p.initiative_id',
'   and p.id = :P121_PROJECT_ID',
'   and ia.id = c.initiative_approval_id',
'   and c.team_member_id = tm.id',
' order by c.approval_seq',
')'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P121_APPROVAL_TYPE_ID'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(48137805326810463173)
,p_query_column_id=>2
,p_column_alias=>'REVIEWER'
,p_column_display_sequence=>20
,p_column_heading=>'Reviewer'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(48137806004503463180)
,p_query_column_id=>1
,p_column_alias=>'ROWNUM'
,p_column_display_sequence=>10
,p_column_heading=>'Review Order'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77297770467975425082)
,p_plug_name=>'Button Container'
,p_static_id=>'button-container'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2127905476394690047
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77297770087510425078)
,p_plug_name=>'Request Approval'
,p_static_id=>'request-approval'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46050540517423022838)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(77297770467975425082)
,p_button_name=>'Cancel'
,p_static_id=>'cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46050540157499022838)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(77297770467975425082)
,p_button_name=>'request-approval'
,p_static_id=>'request-approval'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Request Approval'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(46050543316887022842)
,p_branch_name=>'Go To Page 3'
,p_branch_action=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:3:P3_PROJECT_ID:&P121_PROJECT_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46402949585002636868)
,p_name=>'P121_APPROVAL_TYPE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(77297770087510425078)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65671052107688927186)
,p_name=>'P121_APPROVAL_TYPE_ID'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(77297770087510425078)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'    select t.id r',
'      from sp_approval_types t,',
'           sp_initiative_approvals i,',
'           sp_projects p',
'     where t.id = i.approval_type_id',
'       and i.initiative_id = p.initiative_id',
'       and p.id = :P121_PROJECT_ID',
'       and t.id not in (select approval_type_id    ',
'                          from sp_project_approvals',
'                         where project_id = :P121_PROJECT_ID',
'                           and status in (''PENDING'',''APPROVED''))',
'     order by t.display_seq, t.approval_type',
') loop',
'    return c1.r;',
'end loop;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Approval Type'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t.approval_type d, t.id r',
'  from sp_approval_types t,',
'       sp_initiative_approvals i,',
'       sp_projects p',
' where t.id = i.approval_type_id',
'   and i.initiative_id = p.initiative_id',
'   and p.id = :P121_PROJECT_ID',
'   and t.id not in (select approval_type_id    ',
'                      from sp_project_approvals',
'                     where project_id = :P121_PROJECT_ID',
'                       and status in (''PENDING'',''APPROVED''))',
' order by t.display_seq, t.approval_type'))
,p_field_template=>1610598484065263269
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46402948048482636852)
,p_name=>'P121_APP_NAME'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(77297770087510425078)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45693374104363923245)
,p_name=>'P121_JUSTIFICATION'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(77297770087510425078)
,p_prompt=>'Justification'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(66468915706221502904)
,p_name=>'P121_PROJECT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(77297770087510425078)
,p_prompt=>'&NOMENCLATURE_PROJECT.'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(47426608796982148055)
,p_name=>'P121_PROJECT_APPROVAL_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(77297770087510425078)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_restricted_characters=>'US_ONLY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(66468915272188502902)
,p_name=>'P121_PROJECT_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(77297770087510425078)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_restricted_characters=>'US_ONLY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46402949118392636863)
,p_name=>'P121_PROJECT_URL'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(77297770087510425078)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(46402948174904636853)
,p_computation_sequence=>30
,p_computation_item=>'P121_APP_NAME'
,p_static_id=>'p121-app-name'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>'return sp_util.get_nomenclature(''STRATEGIC_PLANNER'');'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(46402949711412636869)
,p_computation_sequence=>20
,p_computation_item=>'P121_APPROVAL_TYPE'
,p_static_id=>'p121-approval-type'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select approval_type',
'  from sp_approval_types',
' where id = :P121_APPROVAL_TYPE_ID'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(46050541236834022839)
,p_computation_sequence=>10
,p_computation_item=>'P121_PROJECT'
,p_static_id=>'p121-project'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select project',
'from sp_projects',
'where id = :P121_PROJECT_ID'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(46402949229719636864)
,p_computation_sequence=>40
,p_computation_item=>'P121_PROJECT_URL'
,p_static_id=>'p121-project-url'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APEX_UTIL.HOST_URL(''SCRIPT'') || ''project-details?fi='' || friendly_identifier || ''&pn='' || project_url_name',
'  from sp_projects',
' where id = :P121_PROJECT_ID'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(48137805423652463174)
,p_name=>'change approval type'
,p_static_id=>'change-approval-type'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P121_APPROVAL_TYPE_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48137805891894463179)
,p_event_id=>wwv_flow_imp.id(48137805423652463174)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(48137805249268463172)
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P121_APPROVAL_TYPE_ID'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48137805515229463175)
,p_event_id=>wwv_flow_imp.id(48137805423652463174)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(48137805249268463172)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P121_APPROVAL_TYPE_ID'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48137805788677463178)
,p_event_id=>wwv_flow_imp.id(48137805423652463174)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(48137805249268463172)
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P121_APPROVAL_TYPE_ID'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46050542326174022841)
,p_name=>'close dialog'
,p_static_id=>'close-dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(46050540517423022838)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46050542784828022841)
,p_event_id=>wwv_flow_imp.id(46050542326174022841)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-dialog-close'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(47426608755942148054)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create Project Approval'
,p_static_id=>'create-project-approval'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_approvals.submit_for_approval (',
'    p_project_id          => :P121_PROJECT_ID,',
'    p_approval_type_id    => :P121_APPROVAL_TYPE_ID,',
'    p_team_member_id      => :APP_USER_ID,',
'    p_justification       => :P121_JUSTIFICATION,',
'    p_project_approval_id => :P121_PROJECT_APPROVAL_ID );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(46050540157499022838)
,p_internal_uid=>10528790472408238413
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(46050541534855022840)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'log'
,p_static_id=>'log'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_log.log_interaction(',
'    p_project_id => :P121_PROJECT_ID);'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>9152723251321113199
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(45693374201264923246)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_WORKFLOW'
,p_process_name=>'Start Workflow'
,p_static_id=>'start-workflow'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'details_primary_key_item', 'P121_PROJECT_APPROVAL_ID',
  'type', 'START',
  'workflow_definition_id', wwv_flow_imp.id(42764446875598090677))).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(46050540157499022838)
,p_process_success_message=>'Request Submitted.'
,p_internal_uid=>8795555917731013605
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(18395623469702786993)
,p_page_process_id=>wwv_flow_imp.id(45693374201264923246)
,p_workflow_variable_id=>wwv_flow_imp.id(17883469194758620743)
,p_page_id=>121
,p_value_type=>'ITEM'
,p_value=>'APP_USER_ID'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(46166425065828464429)
,p_page_process_id=>wwv_flow_imp.id(45693374201264923246)
,p_workflow_variable_id=>wwv_flow_imp.id(45693375124289923255)
,p_page_id=>121
,p_value_type=>'ITEM'
,p_value=>'P121_PROJECT_ID'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(46277381615168066618)
,p_page_process_id=>wwv_flow_imp.id(45693374201264923246)
,p_workflow_variable_id=>wwv_flow_imp.id(45693376925551923273)
,p_page_id=>121
,p_value_type=>'ITEM'
,p_value=>'NOMENCLATURE_PROJECT'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(46278117278983352399)
,p_page_process_id=>wwv_flow_imp.id(45693374201264923246)
,p_workflow_variable_id=>wwv_flow_imp.id(45693377270320923276)
,p_page_id=>121
,p_value_type=>'ITEM'
,p_value=>'P121_PROJECT_URL'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(46313279400971191476)
,p_page_process_id=>wwv_flow_imp.id(45693374201264923246)
,p_workflow_variable_id=>wwv_flow_imp.id(45693378256128923286)
,p_page_id=>121
,p_value_type=>'ITEM'
,p_value=>'P121_PROJECT'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(46405676162396888546)
,p_page_process_id=>wwv_flow_imp.id(45693374201264923246)
,p_workflow_variable_id=>wwv_flow_imp.id(46402947935770636851)
,p_page_id=>121
,p_value_type=>'ITEM'
,p_value=>'P121_APP_NAME'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(46506302828664718424)
,p_page_process_id=>wwv_flow_imp.id(45693374201264923246)
,p_workflow_variable_id=>wwv_flow_imp.id(46402949494585636867)
,p_page_id=>121
,p_value_type=>'ITEM'
,p_value=>'P121_APPROVAL_TYPE'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(47554445916887210083)
,p_page_process_id=>wwv_flow_imp.id(45693374201264923246)
,p_workflow_variable_id=>wwv_flow_imp.id(47426608996919148057)
,p_page_id=>121
,p_value_type=>'ITEM'
,p_value=>'P121_PROJECT_APPROVAL_ID'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(48267600441597922983)
,p_page_process_id=>wwv_flow_imp.id(45693374201264923246)
,p_workflow_variable_id=>wwv_flow_imp.id(48137803187228463152)
,p_page_id=>121
,p_value_type=>'ITEM'
,p_value=>'APP_ID'
);
wwv_flow_imp.component_end;
end;
/
