prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7150
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>12000886144631317
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18410630589029281911)
,p_group_name=>'About App'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(11644017704107501889)
,p_group_name=>'Activities'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(149555129009671630461)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(21588960939513359442)
,p_group_name=>'Administrative Utilities'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18399506822433429073)
,p_group_name=>'Areas'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18400614801515442522)
,p_group_name=>'Documents Cross-Project'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18416970058248872890)
,p_group_name=>'Feedback'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(20451008055968231273)
,p_group_name=>'Groups'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18399872655456009555)
,p_group_name=>'Home'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18399537521780429859)
,p_group_name=>'Initiatives'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18411083858081735011)
,p_group_name=>'Login'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18399541396899430452)
,p_group_name=>'Projects'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18407188506088608422)
,p_group_name=>'Releases'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(21101980498752155421)
,p_group_name=>'Reporting'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18399552986529430951)
,p_group_name=>'Users'
);
wwv_flow_imp.component_end;
end;
/
