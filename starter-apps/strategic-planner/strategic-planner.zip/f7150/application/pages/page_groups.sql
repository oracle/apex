prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7150
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>17600813780387514
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18416230516665038108)
,p_group_name=>'About App'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(11649617631743258086)
,p_group_name=>'Activities'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(149560728937307386658)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(21594560867149115639)
,p_group_name=>'Administrative Utilities'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18405106750069185270)
,p_group_name=>'Areas'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18406214729151198719)
,p_group_name=>'Documents Cross-Project'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18422569985884629087)
,p_group_name=>'Feedback'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(20456607983603987470)
,p_group_name=>'Groups'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18405472583091765752)
,p_group_name=>'Home'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18405137449416186056)
,p_group_name=>'Initiatives'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18416683785717491208)
,p_group_name=>'Login'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18405141324535186649)
,p_group_name=>'Projects'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18412788433724364619)
,p_group_name=>'Releases'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(21107580426387911618)
,p_group_name=>'Reporting'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18405152914165187148)
,p_group_name=>'Users'
);
wwv_flow_imp.component_end;
end;
/
