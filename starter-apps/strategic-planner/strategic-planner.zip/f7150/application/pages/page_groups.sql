prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7150
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>26954343551793662
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10071070995849020605)
,p_group_name=>'About App'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(3304458110927240583)
,p_group_name=>'Activities'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(141215569416491369155)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(13249401346333098136)
,p_group_name=>'Administrative Utilities'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10059947229253167767)
,p_group_name=>'Areas'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12761990674985869704)
,p_group_name=>'Countries and Maps'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10061055208335181216)
,p_group_name=>'Documents Cross-Project'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10077410465068611584)
,p_group_name=>'Feedback'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12111448462787969967)
,p_group_name=>'Groups'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10060313062275748249)
,p_group_name=>'Home'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10059977928600168553)
,p_group_name=>'Initiatives'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10060786114656757017)
,p_group_name=>'Links Cross-Project'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10071524264901473705)
,p_group_name=>'Login'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10059981803719169146)
,p_group_name=>'Projects'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10067628912908347116)
,p_group_name=>'Releases'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12762420905571894115)
,p_group_name=>'Reporting'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(11981771286381026966)
,p_group_name=>'Reviews'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10071262861627465214)
,p_group_name=>'Search'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10059993393349169645)
,p_group_name=>'Users'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10070068145620407911)
,p_group_name=>'Voting'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(3511423643738937910)
,p_group_name=>'contributor checklist'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10472400632526930913)
,p_group_name=>'sprints'
);
wwv_flow_imp.component_end;
end;
/
