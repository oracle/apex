prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7150
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10044116652297226943)
,p_group_name=>'About App'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(3277503767375446921)
,p_group_name=>'Activities'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(141188615072939575493)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(13222447002781304474)
,p_group_name=>'Administrative Utilities'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10032992885701374105)
,p_group_name=>'Areas'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12735036331434076042)
,p_group_name=>'Countries and Maps'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10034100864783387554)
,p_group_name=>'Documents Cross-Project'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10050456121516817922)
,p_group_name=>'Feedback'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12084494119236176305)
,p_group_name=>'Groups'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10033358718723954587)
,p_group_name=>'Home'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10033023585048374891)
,p_group_name=>'Initiatives'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10033831771104963355)
,p_group_name=>'Links Cross-Project'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10044569921349680043)
,p_group_name=>'Login'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10033027460167375484)
,p_group_name=>'Projects'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10040674569356553454)
,p_group_name=>'Releases'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12735466562020100453)
,p_group_name=>'Reporting'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(11954816942829233304)
,p_group_name=>'Reviews'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10044308518075671552)
,p_group_name=>'Search'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10033039049797375983)
,p_group_name=>'Users'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10043113802068614249)
,p_group_name=>'Voting'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(3484469300187144248)
,p_group_name=>'contributor checklist'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10445446288975137251)
,p_group_name=>'sprints'
);
wwv_flow_imp.component_end;
end;
/
