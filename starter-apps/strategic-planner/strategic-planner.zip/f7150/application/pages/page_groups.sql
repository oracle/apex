prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7150
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>6745509624802563
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18405375212509453157)
,p_group_name=>'About App'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(11638762327587673135)
,p_group_name=>'Activities'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(149549873633151801707)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(21583705562993530688)
,p_group_name=>'Administrative Utilities'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18394251445913600319)
,p_group_name=>'Areas'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18395359424995613768)
,p_group_name=>'Documents Cross-Project'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18411714681729044136)
,p_group_name=>'Feedback'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(20445752679448402519)
,p_group_name=>'Groups'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18394617278936180801)
,p_group_name=>'Home'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18394282145260601105)
,p_group_name=>'Initiatives'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18405828481561906257)
,p_group_name=>'Login'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18394286020379601698)
,p_group_name=>'Projects'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18401933129568779668)
,p_group_name=>'Releases'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(21096725122232326667)
,p_group_name=>'Reporting'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(18394297610009602197)
,p_group_name=>'Users'
);
wwv_flow_imp.component_end;
end;
/
