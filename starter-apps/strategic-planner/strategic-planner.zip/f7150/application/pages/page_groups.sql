prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7150
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>19055477148803894
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10090126472997824499)
,p_group_name=>'About App'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(3323513588076044477)
,p_group_name=>'Activities'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(141234624893640173049)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(13268456823481902030)
,p_group_name=>'Administrative Utilities'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10079002706401971661)
,p_group_name=>'Areas'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12781046152134673598)
,p_group_name=>'Countries and Maps'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10080110685483985110)
,p_group_name=>'Documents Cross-Project'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10096465942217415478)
,p_group_name=>'Feedback'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12130503939936773861)
,p_group_name=>'Groups'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10079368539424552143)
,p_group_name=>'Home'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10079033405748972447)
,p_group_name=>'Initiatives'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10079841591805560911)
,p_group_name=>'Links Cross-Project'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10090579742050277599)
,p_group_name=>'Login'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10079037280867973040)
,p_group_name=>'Projects'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10086684390057151010)
,p_group_name=>'Releases'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12781476382720698009)
,p_group_name=>'Reporting'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12000826763529830860)
,p_group_name=>'Reviews'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10090318338776269108)
,p_group_name=>'Search'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10079048870497973539)
,p_group_name=>'Users'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10089123622769211805)
,p_group_name=>'Voting'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(3530479120887741804)
,p_group_name=>'contributor checklist'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10491456109675734807)
,p_group_name=>'sprints'
);
wwv_flow_imp.component_end;
end;
/
