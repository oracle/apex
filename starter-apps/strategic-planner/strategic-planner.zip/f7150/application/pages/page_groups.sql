prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7150
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10035727931596086600)
,p_group_name=>'About App'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(3269115046674306578)
,p_group_name=>'Activities'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(141180226352238435150)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(13214058282080164131)
,p_group_name=>'Administrative Utilities'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10024604165000233762)
,p_group_name=>'Areas'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12726647610732935699)
,p_group_name=>'Countries and Maps'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10025712144082247211)
,p_group_name=>'Documents Cross-Project'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10042067400815677579)
,p_group_name=>'Feedback'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12076105398535035962)
,p_group_name=>'Groups'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10024969998022814244)
,p_group_name=>'Home'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10024634864347234548)
,p_group_name=>'Initiatives'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10025443050403823012)
,p_group_name=>'Links Cross-Project'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10036181200648539700)
,p_group_name=>'Login'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10024638739466235141)
,p_group_name=>'Projects'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10032285848655413111)
,p_group_name=>'Releases'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12727077841318960110)
,p_group_name=>'Reporting'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(11946428222128092961)
,p_group_name=>'Reviews'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10035919797374531209)
,p_group_name=>'Search'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10024650329096235640)
,p_group_name=>'Users'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10034725081367473906)
,p_group_name=>'Voting'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(3476080579486003905)
,p_group_name=>'contributor checklist'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(10437057568273996908)
,p_group_name=>'sprints'
);
wwv_flow_imp.component_end;
end;
/
