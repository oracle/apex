prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 7150
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>26954343551793662
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(33670785173428937)
,p_theme_id=>42
,p_name=>'Redwood Light'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#',
'#THEME_FILES#css/Redwood#MIN#.css?v=#APEX_VERSION#'))
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Redwood-Theme.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Redwood-Theme#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>2596426436825065489
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(33671128851428938)
,p_theme_id=>42
,p_name=>'Vita'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>2719875314571594493
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(33671565961428938)
,p_theme_id=>42
,p_name=>'Vita - Dark'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Dark.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Dark#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>3543348412015319650
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(33671974440428939)
,p_theme_id=>42
,p_name=>'Vita - Red'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Red.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Red#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>1938457712423918173
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(33672371833428939)
,p_theme_id=>42
,p_name=>'Vita - Slate'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita-Slate.less'
,p_theme_roller_output_file_url=>'#THEME_FILES#css/Vita-Slate#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>3291983347983194966
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(2954163932581032999)
,p_theme_id=>42
,p_name=>'Redwood Light (copy_1)'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#',
'#THEME_FILES#css/Redwood#MIN#.css?v=#APEX_VERSION#'))
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Redwood-Theme.less'
,p_theme_roller_config=>'{"classes":[],"vars":{},"customCSS":".no-item-ui {\n    --a-field-input-border-width: 0;\n    --a-field-input-background-color: transparent;\n}","useCustomLess":"N"}'
,p_theme_roller_read_only=>false
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(6157579438306159504)
,p_theme_id=>42
,p_name=>'Redwood Light SP'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#',
'#THEME_FILES#css/Redwood#MIN#.css?v=#APEX_VERSION#'))
,p_css_classes=>' rw-mode-body-header--dark rw-mode-header--dark'
,p_is_current=>true
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Redwood-Theme.less'
,p_theme_roller_config=>'{"classes":["rw-mode-body-header--dark","rw-mode-header--dark"],"vars":{},"customCSS":":root {\n  --ut-footer-padding-x: var(--ut-body-content-padding-x);\n}\n\n.header-actions {\n  margin-left: auto;\n}\n\n.header-actions .t-ContentRow-wrap {\n  pad'
||'ding: 0;\n  float: right;\n}\n\n.has-header-actions {\n  /* applied to breadcrumb */\n  display: inline-flex;\n}\n\n.header-actions .t-ContentRow-wrap button {\n  --a-button-background-color: transparent;\n}\n\n.t-BreadcrumbRegion--showBreadcrumb .t-'
||'BreadcrumbRegion-breadcrumb {\n  display: flex;\n  align-items: center;\n}\n\n/* Menu Grid Icon */\n.icon-menu-grid {\n  inline-size: var(--a-button-icon-size, 1rem);\n  block-size: var(--a-button-icon-size, 1rem);\n  display: grid;\n  align-items: c'
||'enter;\n  justify-content: center;\n}\n\n.icon-menu-grid::before {\n  content: \"\";\n  display: block;\n  inline-size: .1875rem;\n  block-size: .1875rem;\n  background-color: currentColor;\n  box-shadow:\n    -6px -6px 0,\n    0 -6px 0,\n    6px -6p'
||'x 0,\n    -6px 0 0,\n    6px 0 0,\n    -6px 6px 0,\n    0 6px 0,\n    6px 6px 0;\n  border-radius: 100%;\n}\n\n/* Clear the default fa-user icon for content row regions with the clear-avatar-icons class */\n.clear-avatar-icons .t-Avatar.t-Avatar--ico'
||'n.fa-user:before {\n    display: none;\n}\n\n/* adding initiative icon to the left of contextual info region */\n.initiative-icon {\n    margin: 0 -2rem .5rem 3rem;\n    max-width: 40px;\n}\n.t-PageBody--showLeft .initiative-icon {\n    margin: 0 0re'
||'m .5rem 1rem;\n    max-width: 40px;\n}","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#6157579438306159504.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp.component_end;
end;
/
