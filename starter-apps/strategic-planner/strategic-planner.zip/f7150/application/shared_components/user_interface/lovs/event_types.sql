prompt --application/shared_components/user_interface/lovs/event_types
begin
--   Manifest
--     EVENT_TYPES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(31822893872305727896)
,p_lov_name=>'EVENT_TYPES'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'SP_EVENT_TYPES'
,p_return_column_name=>'ID'
,p_display_column_name=>'EVENT_TYPE'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'EVENT_TYPE'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45859285107479
);
wwv_flow_imp.component_end;
end;
/
