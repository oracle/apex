prompt --application/shared_components/user_interface/lovs/sp_project_groups_group_name
begin
--   Manifest
--     SP_PROJECT_GROUPS.GROUP_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>2214566044257001599
,p_default_application_id=>9111
,p_default_id_offset=>11016538767572718
,p_default_owner=>'DBTOOLS_PROD'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(51904335494008049710)
,p_lov_name=>'SP_PROJECT_GROUPS.GROUP_NAME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'SP_PROJECT_GROUPS'
,p_return_column_name=>'ID'
,p_display_column_name=>'GROUP_NAME'
,p_default_sort_column_name=>'GROUP_NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44690069550085
);
wwv_flow_imp.component_end;
end;
/
