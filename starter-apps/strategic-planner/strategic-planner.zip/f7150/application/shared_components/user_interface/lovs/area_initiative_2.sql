prompt --application/shared_components/user_interface/lovs/area_initiative_2
begin
--   Manifest
--     AREA INITIATIVE 2
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(41717377286509025524)
,p_lov_name=>'AREA INITIATIVE 2'
,p_static_id=>'area-initiative'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select i.initiative, ',
'       a.area,',
'       i.id initiative_id',
'from sp_initiatives i, sp_areas a',
'where i.area_id = a.id',
'order by 2, 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_query_owner=>'APPDEV_COMMUNITY'
,p_return_column_name=>'INITIATIVE_ID'
,p_display_column_name=>'INITIATIVE'
,p_version_scn=>'41430208760493'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(41717456691970027348)
,p_query_column_name=>'AREA'
,p_heading=>'Area'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(41717457540289027349)
,p_query_column_name=>'INITIATIVE'
,p_heading=>'Initiative'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(41717457156781027349)
,p_query_column_name=>'INITIATIVE_ID'
,p_display_sequence=>20
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp.component_end;
end;
/
