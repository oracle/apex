prompt --application/shared_components/user_interface/lovs/sp_project_scales_scale_name
begin
--   Manifest
--     SP_PROJECT_SCALES.SCALE_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(51904325293854049697)
,p_lov_name=>'SP_PROJECT_SCALES.SCALE_NAME'
,p_static_id=>'sp-project-scales-scale-name'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'SP_PROJECT_SCALES'
,p_return_column_name=>'SCALE_LETTER'
,p_display_column_name=>'SCALE_NAME'
,p_default_sort_column_name=>'SCALE_NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'44690069548664'
);
wwv_flow_imp.component_end;
end;
/
