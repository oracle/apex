prompt --application/shared_components/user_interface/lovs/sp_tasks_description
begin
--   Manifest
--     SP_TASKS.DESCRIPTION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>2214566044257001599
,p_default_application_id=>9111
,p_default_id_offset=>11016538767572718
,p_default_owner=>'DBTOOLS_PROD'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(18062405282995832258)
,p_lov_name=>'SP_TASKS.DESCRIPTION'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'SP_TASKS'
,p_return_column_name=>'ID'
,p_display_column_name=>'DESCRIPTION'
,p_default_sort_column_name=>'DESCRIPTION'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44863548292621
);
wwv_flow_imp.component_end;
end;
/
