prompt --application/shared_components/user_interface/lovs/sp_focus_areas_focus_area
begin
--   Manifest
--     SP_FOCUS_AREAS.FOCUS_AREA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(141215862736075350605)
,p_lov_name=>'SP_FOCUS_AREAS.FOCUS_AREA'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'SP_FOCUS_AREAS'
,p_return_column_name=>'ID'
,p_display_column_name=>'FOCUS_AREA'
,p_default_sort_column_name=>'FOCUS_AREA'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
