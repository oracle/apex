prompt --application/shared_components/user_interface/lovs/sp_team_member_contribs_and_admins
begin
--   Manifest
--     SP_TEAM_MEMBER - CONTRIBS AND ADMINS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>2214566044257001599
,p_default_application_id=>9111
,p_default_id_offset=>11016538767572718
,p_default_owner=>'DBTOOLS_PROD'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(18838226041390486450)
,p_lov_name=>'SP_TEAM_MEMBER - CONTRIBS AND ADMINS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select last_name||'', ''||first_name||'' (''||lower(email)||'')'' d, id r',
'from SP_TEAM_MEMBERS',
'where upper(email) in (select user_name',
'                         from apex_appl_acl_user_roles',
'                        where application_id = :APP_ID',
'                          and role_static_id in (''ADMINISTRATOR'',''CONTRIBUTOR''))',
'order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>44895203160156
);
wwv_flow_imp.component_end;
end;
/
