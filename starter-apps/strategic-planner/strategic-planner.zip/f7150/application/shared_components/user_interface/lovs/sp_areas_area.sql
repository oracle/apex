prompt --application/shared_components/user_interface/lovs/sp_areas_area
begin
--   Manifest
--     SP_AREAS.AREA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(176256331971427755129)
,p_lov_name=>'SP_AREAS.AREA'
,p_static_id=>'sp-areas-area'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'SP_AREAS'
,p_return_column_name=>'ID'
,p_display_column_name=>'AREA'
,p_default_sort_column_name=>'AREA'
,p_default_sort_direction=>'ASC'
,p_version_scn=>'41430199627956'
);
wwv_flow_imp.component_end;
end;
/
