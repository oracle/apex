prompt --application/shared_components/user_interface/lovs/event_recurrence
begin
--   Manifest
--     EVENT RECURRENCE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(31823618676887615095)
,p_lov_name=>'EVENT RECURRENCE'
,p_static_id=>'event-recurrence'
,p_lov_query=>'.'||wwv_flow_imp.id(31823618676887615095)||'.'
,p_location=>'STATIC'
,p_version_scn=>'45859298822715'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(31823618985611615097)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Daily'
,p_lov_return_value=>'D'
,p_static_id=>'daily'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(31823620667704615483)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'Each Month (same date)'
,p_lov_return_value=>'M'
,p_static_id=>'each-month-same-date'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(31823620274955615482)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Every 2 Weeks (same day of week)'
,p_lov_return_value=>'2W'
,p_static_id=>'every-2-weeks-same-day-of-week'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(31823619813313615482)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Every Week (same day of week)'
,p_lov_return_value=>'W'
,p_static_id=>'every-week-same-day-of-week'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(31823619561892615482)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Every Weekday (M-F)'
,p_lov_return_value=>'WD'
,p_static_id=>'every-weekday-m-f'
);
wwv_flow_imp.component_end;
end;
/
