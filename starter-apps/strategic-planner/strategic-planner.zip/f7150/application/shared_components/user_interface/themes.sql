prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 7150
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(141188588314496575423)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(141188343001718575222)
,p_default_dialog_template=>wwv_flow_imp.id(141188341502283575220)
,p_error_template=>wwv_flow_imp.id(141188334901182575215)
,p_printer_friendly_template=>wwv_flow_imp.id(141188343001718575222)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(141188334901182575215)
,p_default_button_template=>wwv_flow_imp.id(141188585272816575387)
,p_default_region_template=>wwv_flow_imp.id(141188484312500575273)
,p_default_chart_template=>wwv_flow_imp.id(141188484312500575273)
,p_default_form_template=>wwv_flow_imp.id(141188484312500575273)
,p_default_reportr_template=>wwv_flow_imp.id(141188484312500575273)
,p_default_tabform_template=>wwv_flow_imp.id(141188484312500575273)
,p_default_wizard_template=>wwv_flow_imp.id(141188484312500575273)
,p_default_menur_template=>wwv_flow_imp.id(141188496742657575286)
,p_default_listr_template=>wwv_flow_imp.id(141188484312500575273)
,p_default_irr_template=>wwv_flow_imp.id(141188482213340575271)
,p_default_report_template=>wwv_flow_imp.id(141188543836701575328)
,p_default_label_template=>wwv_flow_imp.id(141188584476664575383)
,p_default_menu_template=>wwv_flow_imp.id(141188586951874575390)
,p_default_calendar_template=>wwv_flow_imp.id(141188586998882575394)
,p_default_list_template=>wwv_flow_imp.id(141188572622164575362)
,p_default_nav_list_template=>wwv_flow_imp.id(141188581431453575374)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(141188581431453575374)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(141188579634596575370)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(141188501912119575289)
,p_default_dialogr_template=>wwv_flow_imp.id(141188351742057575241)
,p_default_option_label=>wwv_flow_imp.id(141188584476664575383)
,p_default_required_label=>wwv_flow_imp.id(141188583993679575382)
,p_default_navbar_list_template=>wwv_flow_imp.id(141188579264468575370)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/23.2/')
,p_files_version=>70
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
