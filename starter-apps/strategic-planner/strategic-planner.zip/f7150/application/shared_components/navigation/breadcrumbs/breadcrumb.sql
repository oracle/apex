prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>2214566044257001599
,p_default_application_id=>9111
,p_default_id_offset=>11016538767572718
,p_default_owner=>'DBTOOLS_PROD'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(176220395320510839347)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(40989108788871328417)
,p_option_sequence=>1
,p_short_name=>'Team Member Default Tags'
,p_link=>'f?p=&APP_ID.:10520:&SESSION.::&DEBUG.:::'
,p_page_id=>10520
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(18062403973565832046)
,p_short_name=>'Team Member Notifications'
,p_link=>'f?p=&APP_ID.:10790:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10790
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(20623617267630027390)
,p_short_name=>'Weekly Summary for &P148_FIRST_NAME. &P148_LAST_NAME.'
,p_link=>'f?p=&APP_ID.:148:&SESSION.::&DEBUG.:::'
,p_page_id=>148
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(20626360560742225001)
,p_short_name=>'&NOMENCLATURE_PROJECT. Exceptions for &P153_FIRST_NAME. &P153_LAST_NAME.'
,p_link=>'f?p=&APP_ID.:153:&SESSION.::&DEBUG.:::'
,p_page_id=>153
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(23980684756038926741)
,p_short_name=>'Documents'
,p_link=>'f?p=&APP_ID.:156:&SESSION.::&DEBUG.:::'
,p_page_id=>156
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(24162375825083851182)
,p_short_name=>'Comments'
,p_link=>'f?p=&APP_ID.:158:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>158
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(24176529610798405858)
,p_short_name=>'&NOMENCLATURE_PROJECT. Contributors'
,p_link=>'f?p=&APP_ID.:159:&SESSION.::&DEBUG.:::'
,p_page_id=>159
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(24280268980627287484)
,p_short_name=>'Images in Comments'
,p_link=>'f?p=&APP_ID.:157:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>157
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(25084572430632264155)
,p_short_name=>'Change History: Release &P14_RELEASE.'
,p_link=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.:::'
,p_page_id=>14
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(27870966941753971469)
,p_short_name=>'AI Prompts'
,p_link=>'f?p=&APP_ID.:12135:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>12135
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(27872395433139032242)
,p_short_name=>'Edit Prompt'
,p_link=>'f?p=&APP_ID.:12136:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>12136
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(28203884649069822955)
,p_short_name=>'Error Log'
,p_link=>'f?p=&APP_ID.:16000:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>16000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(28635051743950762455)
,p_short_name=>'All &NOMENCLATURE_PROJECT. Summaries'
,p_link=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:::'
,p_page_id=>37
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(29012717096260727720)
,p_short_name=>'Interactive Report Catalog'
,p_link=>'f?p=&APP_ID.:10300:&SESSION.::&DEBUG.:::'
,p_page_id=>10300
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(29235883601129252472)
,p_short_name=>'Users that are not &NOMENCLATURE_USERS.'
,p_link=>'f?p=&APP_ID.:10015:&SESSION.::&DEBUG.:::'
,p_page_id=>10015
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(29236177167757380439)
,p_short_name=>'&NOMENCLATURE_USERS. that are not Users'
,p_link=>'f?p=&APP_ID.:10016:&SESSION.::&DEBUG.:::'
,p_page_id=>10016
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(29519038933174673057)
,p_short_name=>'Cross-Release Milestone Calendar'
,p_link=>'f?p=&APP_ID.:55:&SESSION.::&DEBUG.:::'
,p_page_id=>55
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(30774945403669300375)
,p_short_name=>'All Release Summaries'
,p_link=>'f?p=&APP_ID.:167:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>167
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(31284311659652594147)
,p_short_name=>'Release Milestone Default Tags'
,p_link=>'f?p=&APP_ID.:10515:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10515
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(31820068309055353225)
,p_short_name=>'All Events'
,p_link=>'f?p=&APP_ID.:710:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>710
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38092275415670765184)
,p_short_name=>'&P501_PAGE_NAME.'
,p_link=>'f?p=&APP_ID.:501:&SESSION.::&DEBUG.:::'
,p_page_id=>501
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38125939199823680373)
,p_short_name=>'&NOMENCLATURE_PROJECT. Groups'
,p_link=>'f?p=&APP_ID.:70:&SESSION.::&DEBUG.:::'
,p_page_id=>70
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38172324245098450668)
,p_short_name=>'Change History'
,p_link=>'f?p=&APP_ID.:64:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>64
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38286936132668073403)
,p_short_name=>'Add Project'
,p_link=>'f?p=&APP_ID.:104:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>104
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38309569433102705841)
,p_short_name=>'My &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:::'
,p_page_id=>113
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38702823787486358838)
,p_short_name=>'&P300_RELEASE. &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:::'
,p_page_id=>300
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(38889680780409528027)
,p_short_name=>'Developer Detail Views (31 Days)'
,p_link=>'f?p=&APP_ID.:129:&SESSION.::&DEBUG.:::'
,p_page_id=>129
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(39010844460022549214)
,p_short_name=>'&P29_PROJECT_NAME. - Images'
,p_link=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:::'
,p_page_id=>29
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(39189957781156255609)
,p_short_name=>'About Page Text'
,p_link=>'f?p=&APP_ID.:14000:&SESSION.::&DEBUG.:::'
,p_page_id=>14000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(39671252694907904852)
,p_short_name=>'&NOMENCLATURE_INITIATIVES. for &NOMENCLATURE_AREA. &P66_AREA.'
,p_link=>'f?p=&APP_ID.:66:&SESSION.::&DEBUG.:RP::'
,p_page_id=>66
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(39783512537192242478)
,p_short_name=>'&NOMENCLATURE_PROJECT. Related Current Activity'
,p_link=>'f?p=&APP_ID.:75:&SESSION.::&DEBUG.:::'
,p_page_id=>75
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(40286436937628161168)
,p_short_name=>'Resource Type Usage'
,p_link=>'f?p=&APP_ID.:10601:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10601
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(40290948187656886109)
,p_short_name=>'&NOMENCLATURE_INITIATIVE. Focus Areas'
,p_link=>'f?p=&APP_ID.:10150:&SESSION.::&DEBUG.:::'
,p_page_id=>10150
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(40430803268724145047)
,p_short_name=>'Page Views'
,p_link=>'f?p=&APP_ID.:39:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>39
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(40431787312455185258)
,p_short_name=>'Page Performance'
,p_link=>'f?p=&APP_ID.:71:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>71
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(40442435646041767326)
,p_short_name=>'Page Views by User'
,p_link=>'f?p=&APP_ID.:72:&SESSION.::&DEBUG.:::'
,p_page_id=>72
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(40477606672783267806)
,p_short_name=>'&P30_DOCUMENT_NAME.'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(40594239183481118189)
,p_short_name=>'&NOMENCLATURE_STRATEGIC_PLANNER.'
,p_link=>'f?p=&APP_ID.:10820:&SESSION.::&DEBUG.:::'
,p_page_id=>10820
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(40984766933364933239)
,p_short_name=>'Notifications'
,p_link=>'f?p=&APP_ID.:10074:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10074
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(40986581255618885833)
,p_short_name=>'My Subscriptions'
,p_link=>'f?p=&APP_ID.:139:&SESSION.::&DEBUG.:::'
,p_page_id=>139
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(40992522265540496171)
,p_short_name=>'Manage My Subscriptions'
,p_link=>'f?p=&APP_ID.:149:&SESSION.::&DEBUG.:::'
,p_page_id=>149
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(41270004933593089596)
,p_short_name=>'&NOMENCLATURE_USERS.'
,p_link=>'f?p=&APP_ID.:74:&SESSION.::&DEBUG.:::'
,p_page_id=>74
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(41371243019637043808)
,p_short_name=>'External &NOMENCLATURE_PROJECT. Links'
,p_link=>'f?p=&APP_ID.:10750:&SESSION.::&DEBUG.:::'
,p_page_id=>10750
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(41375054555584430221)
,p_short_name=>'Home Page Messages'
,p_link=>'f?p=&APP_ID.:10770:&SESSION.::&DEBUG.:::'
,p_page_id=>10770
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(41562848072379409360)
,p_short_name=>'&NOMENCLATURE_INITIATIVE.: &P94_INITIATIVE.'
,p_link=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP::'
,p_page_id=>94
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(41595763535302420082)
,p_short_name=>'Release: &P117_RELEASE.'
,p_link=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.:::'
,p_page_id=>117
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(41992152094519284117)
,p_short_name=>'Release Calendar: &P203_RELEASE.'
,p_link=>'f?p=&APP_ID.:203:&SESSION.::&DEBUG.:::'
,p_page_id=>203
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(42287846382391624161)
,p_short_name=>'&NOMENCLATURE_PROJECT. Completeness Scales'
,p_link=>'f?p=&APP_ID.:10200:&SESSION.::&DEBUG.:::'
,p_page_id=>10200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(42362476355849653406)
,p_short_name=>'Application Log'
,p_link=>'f?p=&APP_ID.:10050:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10050
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(42562540077767589092)
,p_short_name=>'Project Size'
,p_link=>'f?p=&APP_ID.:10100:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(43085386363763887040)
,p_short_name=>'Release Milestone Types'
,p_link=>'f?p=&APP_ID.:10090:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10090
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(43690437817807888830)
,p_short_name=>'Favorited &NOMENCLATURE_PROJECTS. by User'
,p_link=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:::'
,p_page_id=>15
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(43693402528026948000)
,p_short_name=>'Favorite &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:91:&SESSION.::&DEBUG.:::'
,p_page_id=>91
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(43857698260626653551)
,p_short_name=>'Project Milestone Calendar'
,p_link=>'f?p=&APP_ID.:111:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>111
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(44405569004379620377)
,p_short_name=>'&P119_PROJECT_GROUP. &NOMENCLATURE_PROJECT. Group'
,p_link=>'f?p=&APP_ID.:119:&SESSION.::&DEBUG.:::'
,p_page_id=>119
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(44863980437877240071)
,p_short_name=>'Nomenclature'
,p_link=>'f?p=&APP_ID.:10400:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10400
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(45090816473075882365)
,p_short_name=>'Feedback'
,p_link=>'f?p=&APP_ID.:12123:&SESSION.::&DEBUG.:::'
,p_page_id=>12123
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(45481225313309600822)
,p_short_name=>'&NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:86:&SESSION.::&DEBUG.:::'
,p_page_id=>86
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(45885325611451248373)
,p_short_name=>'Groups'
,p_link=>'f?p=&APP_ID.:103:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>103
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(45886959577795783802)
,p_short_name=>'&P151_GROUP_NAME.'
,p_link=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.:::'
,p_page_id=>151
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(46234022188262180067)
,p_short_name=>'Change History'
,p_link=>'f?p=&APP_ID.:79:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>79
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(46254229787228581635)
,p_short_name=>'Workflow Console'
,p_link=>'f?p=&APP_ID.:4000:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>4000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(46713794562152292345)
,p_short_name=>'Screen Names'
,p_link=>'f?p=&APP_ID.:122:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>122
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(46718404946250771989)
,p_short_name=>'Comments'
,p_link=>'f?p=&APP_ID.:7:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(46898892299316672069)
,p_short_name=>'APEX Bugs'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(46927653062547347813)
,p_short_name=>'&NOMENCLATURE_PROJECT. Default Tags'
,p_link=>'f?p=&APP_ID.:10500:&SESSION.::&DEBUG.:::'
,p_page_id=>10500
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(46941410572804788736)
,p_short_name=>'Configure Application Features'
,p_link=>'f?p=&APP_ID.:12130:&SESSION.::&DEBUG.:::'
,p_page_id=>12130
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(47013809904655987747)
,p_short_name=>'Reports'
,p_link=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:::'
,p_page_id=>41
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(47728785452917343525)
,p_short_name=>'Countries'
,p_link=>'f?p=&APP_ID.:43:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>43
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(47933585613692327511)
,p_short_name=>'Default Competencies'
,p_link=>'f?p=&APP_ID.:154:&SESSION.::&DEBUG.:::'
,p_page_id=>154
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(47993117693127128127)
,p_short_name=>'Job Reporting'
,p_link=>'f?p=&APP_ID.:16010:&SESSION.::&DEBUG.:::'
,p_page_id=>16010
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48023433617450080868)
,p_short_name=>'Subscriptions'
,p_link=>'f?p=&APP_ID.:16015:&SESSION.::&DEBUG.:::'
,p_page_id=>16015
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48129760350812245167)
,p_short_name=>'Settings'
,p_link=>'f?p=&APP_ID.:12150:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>12150
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48520120172736306656)
,p_short_name=>'Manage Archived &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:11300:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>11300
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48562639763819162526)
,p_short_name=>'Archived &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:45:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>45
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48573382978523870059)
,p_short_name=>'Duplicate &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.:::'
,p_page_id=>51
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48650746240916336389)
,p_short_name=>'Approval Types'
,p_link=>'f?p=&APP_ID.:4010:&SESSION.::&DEBUG.:::'
,p_page_id=>4010
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48652179842310517386)
,p_short_name=>'&NOMENCLATURE_INITIATIVE. Approval Types'
,p_link=>'f?p=&APP_ID.:4012:&SESSION.::&DEBUG.:::'
,p_page_id=>4012
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48654475815799991104)
,p_short_name=>'Initiative Approval Chain'
,p_link=>'f?p=&APP_ID.:4014:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>4014
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48771702276482206350)
,p_short_name=>'Email Reporting'
,p_link=>'f?p=&APP_ID.:16020:&SESSION.::&DEBUG.:::'
,p_page_id=>16020
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48855777513292789747)
,p_short_name=>'&NOMENCLATURE_PROJECT. Milestones, Reviews and Tasks'
,p_link=>'f?p=&APP_ID.:65:&SESSION.::&DEBUG.:::'
,p_page_id=>65
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48857194953425924332)
,p_short_name=>'Most Viewed Projects (90 Days)'
,p_link=>'f?p=&APP_ID.:97:&SESSION.::&DEBUG.:::'
,p_page_id=>97
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48907288168322335436)
,p_short_name=>'Image Gallery'
,p_link=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.:::'
,p_page_id=>46
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49171327214608074096)
,p_short_name=>'&NOMENCLATURE_PROJECT. Interactions'
,p_link=>'f?p=&APP_ID.:610:&SESSION.::&DEBUG.:::'
,p_page_id=>610
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(50488177654383728679)
,p_short_name=>'All &NOMENCLATURE_PROJECT. Approvals'
,p_link=>'f?p=&APP_ID.:134:&SESSION.::&DEBUG.:::'
,p_page_id=>134
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(50981905086826831390)
,p_short_name=>'Duplicate &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:11320:&SESSION.::&DEBUG.:::'
,p_page_id=>11320
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(51098779484931758000)
,p_short_name=>'Activity Types'
,p_link=>'f?p=&APP_ID.:10700:&SESSION.::&DEBUG.:RP::'
,p_page_id=>10700
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(51182315337167096751)
,p_short_name=>'Activities'
,p_link=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:::'
,p_page_id=>102
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(51363303692979750999)
,p_short_name=>'Release Dashboard: &P202_RELEASE.'
,p_link=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.:::'
,p_page_id=>202
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(51490977327761557598)
,p_short_name=>'Past Due Milestones, Reviews and Tasks'
,p_link=>'f?p=&APP_ID.:99:&SESSION.::&DEBUG.:RP::'
,p_page_id=>99
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(51679400609347118814)
,p_short_name=>'&P112_INITIATIVE. Milestones Report'
,p_link=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:RP::'
,p_page_id=>112
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(51781865772984229540)
,p_short_name=>'Release Gantt'
,p_link=>'f?p=&APP_ID.:133:&SESSION.::&DEBUG.:::'
,p_page_id=>133
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(51904381770199049758)
,p_short_name=>'Jira Sync Information'
,p_link=>'f?p=&APP_ID.:142:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>142
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(52279906481421119390)
,p_short_name=>'Kanban: &P160_INITIATIVE.'
,p_link=>'f?p=&APP_ID.:160:&SESSION.::&DEBUG.:::'
,p_page_id=>160
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(52344509593300138577)
,p_short_name=>'Planning Board: &P164_INITIATIVE.'
,p_link=>'f?p=&APP_ID.:164:&SESSION.::&DEBUG.:::'
,p_page_id=>164
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(52408207772274167586)
,p_short_name=>'Delete Sample Data'
,p_link=>'f?p=&APP_ID.:14010:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>14010
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(53085655390253101935)
,p_short_name=>'&NOMENCLATURE_PROJECT. Statuses'
,p_link=>'f?p=&APP_ID.:10110:&SESSION.::&DEBUG.:::'
,p_page_id=>10110
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(53549330060800887761)
,p_short_name=>'Links'
,p_link=>'f?p=&APP_ID.:146:&SESSION.::&DEBUG.:::'
,p_page_id=>146
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(53564761488075456605)
,p_short_name=>'&P42_DOCUMENT_NAME.'
,p_link=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:::'
,p_page_id=>42
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(53567695154213725959)
,p_short_name=>'&P53_DOCUMENT_NAME.'
,p_link=>'f?p=&APP_ID.:53:&SESSION.::&DEBUG.:::'
,p_page_id=>53
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(53808420759237431945)
,p_short_name=>'&NOMENCLATURE_INITIATIVE. Change History'
,p_link=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::'
,p_page_id=>11
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(53924173929739806402)
,p_short_name=>'&P33_INITIATIVE. - &P33_FOCUS_AREA.'
,p_link=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:::'
,p_page_id=>33
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(54021956385641030947)
,p_short_name=>'&P57_INIT_FOCUS_AREA.'
,p_link=>'f?p=&APP_ID.:57:&SESSION.::&DEBUG.:::'
,p_page_id=>57
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(54024243903959532535)
,p_short_name=>'&P59_DOCUMENT_NAME.'
,p_link=>'f?p=&APP_ID.:59:&SESSION.::&DEBUG.:::'
,p_page_id=>59
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(54392765722230484700)
,p_short_name=>'&P60_TASK_NAME. - Images'
,p_link=>'f?p=&APP_ID.:60:&SESSION.::&DEBUG.:::'
,p_page_id=>60
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(54427157580075388814)
,p_short_name=>'&P62_INITIATIVE_NAME. - Images'
,p_link=>'f?p=&APP_ID.:62:&SESSION.::&DEBUG.:::'
,p_page_id=>62
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(54491654014955707992)
,p_short_name=>'&P68_FOCUS_AREA. -  Images'
,p_link=>'f?p=&APP_ID.:68:&SESSION.::&DEBUG.:::'
,p_page_id=>68
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(54500191106450282606)
,p_short_name=>'&P69_RELEASE. - Images'
,p_link=>'f?p=&APP_ID.:69:&SESSION.::&DEBUG.:::'
,p_page_id=>69
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(55026935923257107167)
,p_short_name=>'&P502_TASK.'
,p_link=>'f?p=&APP_ID.:502:&SESSION.::&DEBUG.:::'
,p_page_id=>502
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(55058264321650685170)
,p_short_name=>'Task Document Details'
,p_link=>'f?p=&APP_ID.:505:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>505
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(55063080232297989073)
,p_short_name=>'Task Change History'
,p_link=>'f?p=&APP_ID.:507:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>507
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(55132840180438338214)
,p_short_name=>'Task Statuses'
,p_link=>'f?p=&APP_ID.:10061:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10061
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(55139414041791380506)
,p_short_name=>'Task Status'
,p_link=>'f?p=&APP_ID.:10062:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10062
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(55142648171247586483)
,p_short_name=>'Task Types'
,p_link=>'f?p=&APP_ID.:10064:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10064
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(55201224819035698795)
,p_short_name=>'&NOMENCLATURE_PROJECT. Views by User (90 days)'
,p_link=>'f?p=&APP_ID.:80:&SESSION.::&DEBUG.:::'
,p_page_id=>80
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(55202659860695945566)
,p_short_name=>'&NOMENCLATURE_INITIATIVE. Views (last 90 Days)'
,p_link=>'f?p=&APP_ID.:81:&SESSION.::&DEBUG.:::'
,p_page_id=>81
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(55204742118254013820)
,p_short_name=>'Project Views by User by Month'
,p_link=>'f?p=&APP_ID.:89:&SESSION.::&DEBUG.:::'
,p_page_id=>89
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(68514226803843158469)
,p_short_name=>'Releases'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(68813945983043463167)
,p_short_name=>'Release Train Gantt'
,p_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:RP::'
,p_page_id=>16
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(149175232623456772705)
,p_short_name=>'&P3_PROJECT_NAME.'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(151754536445626619859)
,p_short_name=>'&NOMENCLATURE_PROJECT. Priorities'
,p_link=>'f?p=&APP_ID.:10800:&SESSION.::&DEBUG.:::'
,p_page_id=>10800
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(151952948545971336804)
,p_short_name=>'&P5_FIRST_NAME. &P5_LAST_NAME.'
,p_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
,p_page_id=>5
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(176220395486720839347)
,p_short_name=>'&NOMENCLATURE_STRATEGIC_PLANNER.'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(176220758857626840366)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:::'
,p_page_id=>10000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(176239426493056065882)
,p_short_name=>'Contributor Roles'
,p_link=>'f?p=&APP_ID.:10600:&SESSION.::&DEBUG.:::'
,p_page_id=>10600
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(176240359351195515631)
,p_short_name=>'&NOMENCLATURE_AREAS.'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(176240632536434532933)
,p_short_name=>'&NOMENCLATURE_USERS. Details'
,p_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_page_id=>19
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(176256348860265755162)
,p_short_name=>'&NOMENCLATURE_INITIATIVES.'
,p_link=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:::'
,p_page_id=>21
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(176263365560578425969)
,p_short_name=>'&NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::'
,p_page_id=>23
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(41220906972124594894)
,p_option_sequence=>10011
,p_short_name=>'Users'
,p_link=>'f?p=&APP_ID.:10011:&SESSION.::&DEBUG.:::'
,p_page_id=>10011
);
wwv_flow_imp.component_end;
end;
/
