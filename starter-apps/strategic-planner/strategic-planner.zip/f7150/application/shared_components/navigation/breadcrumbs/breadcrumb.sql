prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(141188314805859575166)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5957028274220064236)
,p_option_sequence=>1
,p_short_name=>'Team Member Default Tags'
,p_link=>'f?p=&APP_ID.:10520:&SESSION.::&DEBUG.:::'
,p_page_id=>10520
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1930251151154710310)
,p_short_name=>'Documents'
,p_link=>'f?p=&APP_ID.:14:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>14
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3140243730447186487)
,p_short_name=>'Change History'
,p_link=>'f?p=&APP_ID.:64:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>64
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3254855618016809222)
,p_short_name=>'Add Project'
,p_link=>'f?p=&APP_ID.:104:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>104
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3275848276459192662)
,p_short_name=>'My Activities'
,p_link=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:::'
,p_page_id=>112
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3277488918451441660)
,p_short_name=>'My &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:::'
,p_page_id=>113
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3458313742770528702)
,p_short_name=>'Contributor Checklist'
,p_link=>'f?p=&APP_ID.:121:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>121
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3480803817145483232)
,p_short_name=>'Contributor Checklist Admin'
,p_link=>'f?p=&APP_ID.:13000:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>13000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3568232898978639406)
,p_short_name=>'Review Types'
,p_link=>'f?p=&APP_ID.:10063:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10063
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3670743272835094657)
,p_short_name=>'&P300_RELEASE. &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:::'
,p_page_id=>300
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3857600265758263846)
,p_short_name=>'Developer Detail Views (31 Days)'
,p_link=>'f?p=&APP_ID.:129:&SESSION.::&DEBUG.:::'
,p_page_id=>129
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3978763945371285033)
,p_short_name=>'&P29_PROJECT_NAME.'
,p_link=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:::'
,p_page_id=>29
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4157877266504991428)
,p_short_name=>'About Page Text'
,p_link=>'f?p=&APP_ID.:14000:&SESSION.::&DEBUG.:::'
,p_page_id=>14000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4639172180256640671)
,p_short_name=>'Initiatives for &NOMENCLATURE_AREA. &P66_AREA.'
,p_link=>'f?p=&APP_ID.:66:&SESSION.::&DEBUG.:RP::'
,p_page_id=>66
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4751432022540978297)
,p_short_name=>'&NOMENCLATURE_PROJECT. Related Current Activity'
,p_link=>'f?p=&APP_ID.:75:&SESSION.::&DEBUG.:::'
,p_page_id=>75
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5254356422976896987)
,p_short_name=>'Resource Type Usage'
,p_link=>'f?p=&APP_ID.:10601:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10601
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5398722754072880866)
,p_short_name=>'Page Views'
,p_link=>'f?p=&APP_ID.:39:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>39
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5399706797803921077)
,p_short_name=>'Page Performance'
,p_link=>'f?p=&APP_ID.:71:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>71
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5410355131390503145)
,p_short_name=>'Page Views by User'
,p_link=>'f?p=&APP_ID.:72:&SESSION.::&DEBUG.:::'
,p_page_id=>72
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5445526158132003625)
,p_short_name=>'&P30_DOCUMENT_NAME.'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5551566477961794500)
,p_short_name=>'Contributor Checklist'
,p_link=>'f?p=&APP_ID.:40:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>40
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5562158668829854008)
,p_short_name=>'Strategic Planner'
,p_link=>'f?p=&APP_ID.:10820:&SESSION.::&DEBUG.:::'
,p_page_id=>10820
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5952686418713669058)
,p_short_name=>'Notifications'
,p_link=>'f?p=&APP_ID.:10074:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10074
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5954500740967621652)
,p_short_name=>'My Subscriptions'
,p_link=>'f?p=&APP_ID.:139:&SESSION.::&DEBUG.:::'
,p_page_id=>139
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5955561678572839450)
,p_short_name=>'Change History'
,p_link=>'f?p=&APP_ID.:78:&SESSION.::&DEBUG.:::'
,p_page_id=>78
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5960441750889231990)
,p_short_name=>'Manage My Subscriptions'
,p_link=>'f?p=&APP_ID.:149:&SESSION.::&DEBUG.:::'
,p_page_id=>149
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6237924418941825415)
,p_short_name=>'&NOMENCLATURE_USERS.'
,p_link=>'f?p=&APP_ID.:74:&SESSION.::&DEBUG.:::'
,p_page_id=>74
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6339162504985779627)
,p_short_name=>'External &NOMENCLATURE_PROJECT. Links'
,p_link=>'f?p=&APP_ID.:10750:&SESSION.::&DEBUG.:::'
,p_page_id=>10750
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6342974040933166040)
,p_short_name=>'Home Page Messages'
,p_link=>'f?p=&APP_ID.:10770:&SESSION.::&DEBUG.:::'
,p_page_id=>10770
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6530767557728145179)
,p_short_name=>'&NOMENCLATURE_INITIATIVE.: &P94_INITIATIVE.'
,p_link=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP::'
,p_page_id=>94
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6563683020651155901)
,p_short_name=>'Release: &P117_RELEASE.'
,p_link=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.:::'
,p_page_id=>117
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(7255765867740359980)
,p_short_name=>'Project Percent Complete and Milestone Scales'
,p_link=>'f?p=&APP_ID.:10200:&SESSION.::&DEBUG.:::'
,p_page_id=>10200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(7530459563116324911)
,p_short_name=>'Project Size'
,p_link=>'f?p=&APP_ID.:10100:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(9831899923225975890)
,p_short_name=>'Nomenclature'
,p_link=>'f?p=&APP_ID.:10400:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10400
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(9993900909368922400)
,p_short_name=>'Application Pages'
,p_link=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:::'
,p_page_id=>37
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(10024502566804605900)
,p_short_name=>'Release Milestones'
,p_link=>'f?p=&APP_ID.:84:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>84
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(10058735958424618184)
,p_short_name=>'Feedback'
,p_link=>'f?p=&APP_ID.:12123:&SESSION.::&DEBUG.:::'
,p_page_id=>12123
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(10449144798658336641)
,p_short_name=>'&NOMENCLATURE_PROJECTS. Interactive Report'
,p_link=>'f?p=&APP_ID.:86:&SESSION.::&DEBUG.:::'
,p_page_id=>86
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(10853245096799984192)
,p_short_name=>'Groups'
,p_link=>'f?p=&APP_ID.:103:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>103
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(10854879063144519621)
,p_short_name=>'&P151_GROUP_NAME.'
,p_link=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.:::'
,p_page_id=>151
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11686324431599507808)
,p_short_name=>'Comments'
,p_link=>'f?p=&APP_ID.:7:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11895572547896083632)
,p_short_name=>'&NOMENCLATURE_PROJECT. Default Tags'
,p_link=>'f?p=&APP_ID.:10500:&SESSION.::&DEBUG.:::'
,p_page_id=>10500
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11909330058153524555)
,p_short_name=>'Configure Application Features'
,p_link=>'f?p=&APP_ID.:12130:&SESSION.::&DEBUG.:::'
,p_page_id=>12130
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11981729390004723566)
,p_short_name=>'Reports'
,p_link=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:::'
,p_page_id=>41
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12696704938266079344)
,p_short_name=>'Countries'
,p_link=>'f?p=&APP_ID.:43:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>43
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12901505099041063330)
,p_short_name=>'Default Competencies'
,p_link=>'f?p=&APP_ID.:154:&SESSION.::&DEBUG.:::'
,p_page_id=>154
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12961037178475863946)
,p_short_name=>'Job Reporting'
,p_link=>'f?p=&APP_ID.:16010:&SESSION.::&DEBUG.:::'
,p_page_id=>16010
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12991353102798816687)
,p_short_name=>'Subscriptions'
,p_link=>'f?p=&APP_ID.:16015:&SESSION.::&DEBUG.:::'
,p_page_id=>16015
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13097679836160980986)
,p_short_name=>'Settings'
,p_link=>'f?p=&APP_ID.:12150:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>12150
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13488039658085042475)
,p_short_name=>'Manage Archived &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:11300:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>11300
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13530559249167898345)
,p_short_name=>'Archived &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:45:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>45
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13541302463872605878)
,p_short_name=>'Duplicate &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.:::'
,p_page_id=>51
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13739621761830942169)
,p_short_name=>'Email Reporting'
,p_link=>'f?p=&APP_ID.:16020:&SESSION.::&DEBUG.:::'
,p_page_id=>16020
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13875207653671071255)
,p_short_name=>'Image Gallery'
,p_link=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.:::'
,p_page_id=>46
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14139246699956809915)
,p_short_name=>'Interactions'
,p_link=>'f?p=&APP_ID.:610:&SESSION.::&DEBUG.:::'
,p_page_id=>610
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(15949824572175567209)
,p_short_name=>'Duplicate &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:11320:&SESSION.::&DEBUG.:::'
,p_page_id=>11320
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16066698970280493819)
,p_short_name=>'Activity Types'
,p_link=>'f?p=&APP_ID.:10700:&SESSION.::&DEBUG.:RP::'
,p_page_id=>10700
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16119369031650603289)
,p_short_name=>'Description Change History'
,p_link=>'f?p=&APP_ID.:96:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>96
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16150234822515832570)
,p_short_name=>'Activity'
,p_link=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:::'
,p_page_id=>102
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16326256719520266028)
,p_short_name=>'Release History: &P200_RELEASE.'
,p_link=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:::'
,p_page_id=>200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16331223178328486818)
,p_short_name=>'Release Dashboard: &P202_RELEASE.'
,p_link=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.:::'
,p_page_id=>202
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16331230113842489811)
,p_short_name=>'Release Calendar: &P201_RELEASE.'
,p_link=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.:::'
,p_page_id=>201
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(17376127257622903405)
,p_short_name=>'Delete Sample Data'
,p_link=>'f?p=&APP_ID.:14010:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>14010
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(18532680973424192424)
,p_short_name=>'&P42_DOCUMENT_NAME.'
,p_link=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:::'
,p_page_id=>42
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(18535614639562461778)
,p_short_name=>'&P53_DOCUMENT_NAME.'
,p_link=>'f?p=&APP_ID.:53:&SESSION.::&DEBUG.:::'
,p_page_id=>53
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(18541349037951804127)
,p_short_name=>'Links'
,p_link=>'f?p=&APP_ID.:26:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>26
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(31464896539380555908)
,p_short_name=>'&NOMENCLATURE_PROJECT. Contributors'
,p_link=>'f?p=&APP_ID.:55:&SESSION.::&DEBUG.:::'
,p_page_id=>55
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(33482146289191894288)
,p_short_name=>'Releases'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(33781865468392198986)
,p_short_name=>'Releases'
,p_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:RP::'
,p_page_id=>16
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(114143152108805508524)
,p_short_name=>'&P3_PROJECT_NAME.'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(116722455930975355678)
,p_short_name=>'&NOMENCLATURE_PROJECT. Priorities'
,p_link=>'f?p=&APP_ID.:10800:&SESSION.::&DEBUG.:::'
,p_page_id=>10800
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(116920868031320072623)
,p_short_name=>'&P5_FIRST_NAME. &P5_LAST_NAME.'
,p_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
,p_page_id=>5
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141188314972069575166)
,p_short_name=>'Strategic Planner'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141188678342975576185)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:::'
,p_page_id=>10000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141207345978404801701)
,p_short_name=>'Contributor Roles'
,p_link=>'f?p=&APP_ID.:10600:&SESSION.::&DEBUG.:::'
,p_page_id=>10600
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141208278836544251450)
,p_short_name=>'&NOMENCLATURE_AREAS.'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141208552021783268752)
,p_short_name=>'&NOMENCLATURE_USERS. Details'
,p_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_page_id=>19
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141224268345614490981)
,p_short_name=>'&NOMENCLATURE_INITIATIVES.'
,p_link=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:::'
,p_page_id=>21
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141231285045927161788)
,p_short_name=>'&NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::'
,p_page_id=>23
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6188826457473330713)
,p_option_sequence=>10011
,p_short_name=>'Users'
,p_link=>'f?p=&APP_ID.:10011:&SESSION.::&DEBUG.:::'
,p_page_id=>10011
);
wwv_flow_imp.component_end;
end;
/
