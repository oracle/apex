prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(141179926085158434823)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5948639553518923893)
,p_option_sequence=>1
,p_short_name=>'Team Member Default Tags'
,p_link=>'f?p=&APP_ID.:10520:&SESSION.::&DEBUG.:::'
,p_page_id=>10520
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1921862430453569967)
,p_short_name=>'Documents'
,p_link=>'f?p=&APP_ID.:14:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>14
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3131855009746046144)
,p_short_name=>'Change History'
,p_link=>'f?p=&APP_ID.:64:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>64
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3246466897315668879)
,p_short_name=>'Add Project'
,p_link=>'f?p=&APP_ID.:104:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>104
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3267459555758052319)
,p_short_name=>'My Activities'
,p_link=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:::'
,p_page_id=>112
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3269100197750301317)
,p_short_name=>'My &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:::'
,p_page_id=>113
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3449925022069388359)
,p_short_name=>'Contributor Checklist'
,p_link=>'f?p=&APP_ID.:121:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>121
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3472415096444342889)
,p_short_name=>'Contributor Checklist Admin'
,p_link=>'f?p=&APP_ID.:13000:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>13000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3559844178277499063)
,p_short_name=>'Review Types'
,p_link=>'f?p=&APP_ID.:10063:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10063
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3662354552133954314)
,p_short_name=>'&P300_RELEASE. &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:::'
,p_page_id=>300
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3849211545057123503)
,p_short_name=>'Developer Detail Views (31 Days)'
,p_link=>'f?p=&APP_ID.:129:&SESSION.::&DEBUG.:::'
,p_page_id=>129
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3970375224670144690)
,p_short_name=>'&P29_PROJECT_NAME.'
,p_link=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:::'
,p_page_id=>29
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4149488545803851085)
,p_short_name=>'About Page Text'
,p_link=>'f?p=&APP_ID.:14000:&SESSION.::&DEBUG.:::'
,p_page_id=>14000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4630783459555500328)
,p_short_name=>'Initiatives for &NOMENCLATURE_AREA. &P66_AREA.'
,p_link=>'f?p=&APP_ID.:66:&SESSION.::&DEBUG.:RP::'
,p_page_id=>66
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4743043301839837954)
,p_short_name=>'&NOMENCLATURE_PROJECT. Related Current Activity'
,p_link=>'f?p=&APP_ID.:75:&SESSION.::&DEBUG.:::'
,p_page_id=>75
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5245967702275756644)
,p_short_name=>'Resource Type Usage'
,p_link=>'f?p=&APP_ID.:10601:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10601
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5390334033371740523)
,p_short_name=>'Page Views'
,p_link=>'f?p=&APP_ID.:39:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>39
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5391318077102780734)
,p_short_name=>'Page Performance'
,p_link=>'f?p=&APP_ID.:71:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>71
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5401966410689362802)
,p_short_name=>'Page Views by User'
,p_link=>'f?p=&APP_ID.:72:&SESSION.::&DEBUG.:::'
,p_page_id=>72
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5437137437430863282)
,p_short_name=>'&P30_DOCUMENT_NAME.'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5543177757260654157)
,p_short_name=>'Contributor Checklist'
,p_link=>'f?p=&APP_ID.:40:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>40
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5553769948128713665)
,p_short_name=>'Strategic Planner'
,p_link=>'f?p=&APP_ID.:10820:&SESSION.::&DEBUG.:::'
,p_page_id=>10820
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5944297698012528715)
,p_short_name=>'Notifications'
,p_link=>'f?p=&APP_ID.:10074:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10074
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5946112020266481309)
,p_short_name=>'My Subscriptions'
,p_link=>'f?p=&APP_ID.:139:&SESSION.::&DEBUG.:::'
,p_page_id=>139
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5947172957871699107)
,p_short_name=>'Change History'
,p_link=>'f?p=&APP_ID.:78:&SESSION.::&DEBUG.:::'
,p_page_id=>78
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5952053030188091647)
,p_short_name=>'Manage My Subscriptions'
,p_link=>'f?p=&APP_ID.:149:&SESSION.::&DEBUG.:::'
,p_page_id=>149
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6229535698240685072)
,p_short_name=>'&NOMENCLATURE_USERS.'
,p_link=>'f?p=&APP_ID.:74:&SESSION.::&DEBUG.:::'
,p_page_id=>74
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6330773784284639284)
,p_short_name=>'External &NOMENCLATURE_PROJECT. Links'
,p_link=>'f?p=&APP_ID.:10750:&SESSION.::&DEBUG.:::'
,p_page_id=>10750
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6334585320232025697)
,p_short_name=>'Home Page Messages'
,p_link=>'f?p=&APP_ID.:10770:&SESSION.::&DEBUG.:::'
,p_page_id=>10770
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6522378837027004836)
,p_short_name=>'&NOMENCLATURE_INITIATIVE.: &P94_INITIATIVE.'
,p_link=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP::'
,p_page_id=>94
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6555294299950015558)
,p_short_name=>'Release: &P117_RELEASE.'
,p_link=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.:::'
,p_page_id=>117
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(7247377147039219637)
,p_short_name=>'Project Percent Complete and Milestone Scales'
,p_link=>'f?p=&APP_ID.:10200:&SESSION.::&DEBUG.:::'
,p_page_id=>10200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(7522070842415184568)
,p_short_name=>'Project Size'
,p_link=>'f?p=&APP_ID.:10100:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(9823511202524835547)
,p_short_name=>'Nomenclature'
,p_link=>'f?p=&APP_ID.:10400:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10400
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(9985512188667782057)
,p_short_name=>'Application Pages'
,p_link=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:::'
,p_page_id=>37
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(10016113846103465557)
,p_short_name=>'Release Milestones'
,p_link=>'f?p=&APP_ID.:84:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>84
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(10050347237723477841)
,p_short_name=>'Feedback'
,p_link=>'f?p=&APP_ID.:12123:&SESSION.::&DEBUG.:::'
,p_page_id=>12123
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(10440756077957196298)
,p_short_name=>'&NOMENCLATURE_PROJECTS. Interactive Report'
,p_link=>'f?p=&APP_ID.:86:&SESSION.::&DEBUG.:::'
,p_page_id=>86
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(10844856376098843849)
,p_short_name=>'Groups'
,p_link=>'f?p=&APP_ID.:103:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>103
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(10846490342443379278)
,p_short_name=>'&P151_GROUP_NAME.'
,p_link=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.:::'
,p_page_id=>151
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11677935710898367465)
,p_short_name=>'Comments'
,p_link=>'f?p=&APP_ID.:7:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11887183827194943289)
,p_short_name=>'&NOMENCLATURE_PROJECT. Default Tags'
,p_link=>'f?p=&APP_ID.:10500:&SESSION.::&DEBUG.:::'
,p_page_id=>10500
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11900941337452384212)
,p_short_name=>'Configure Application Features'
,p_link=>'f?p=&APP_ID.:12130:&SESSION.::&DEBUG.:::'
,p_page_id=>12130
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11973340669303583223)
,p_short_name=>'Reports'
,p_link=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:::'
,p_page_id=>41
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12688316217564939001)
,p_short_name=>'Countries'
,p_link=>'f?p=&APP_ID.:43:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>43
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12893116378339922987)
,p_short_name=>'Default Competencies'
,p_link=>'f?p=&APP_ID.:154:&SESSION.::&DEBUG.:::'
,p_page_id=>154
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12952648457774723603)
,p_short_name=>'Job Reporting'
,p_link=>'f?p=&APP_ID.:16010:&SESSION.::&DEBUG.:::'
,p_page_id=>16010
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12982964382097676344)
,p_short_name=>'Subscriptions'
,p_link=>'f?p=&APP_ID.:16015:&SESSION.::&DEBUG.:::'
,p_page_id=>16015
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13089291115459840643)
,p_short_name=>'Settings'
,p_link=>'f?p=&APP_ID.:12150:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>12150
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13479650937383902132)
,p_short_name=>'Manage Archived &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:11300:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>11300
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13522170528466758002)
,p_short_name=>'Archived &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:45:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>45
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13532913743171465535)
,p_short_name=>'Duplicate &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.:::'
,p_page_id=>51
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13731233041129801826)
,p_short_name=>'Email Reporting'
,p_link=>'f?p=&APP_ID.:16020:&SESSION.::&DEBUG.:::'
,p_page_id=>16020
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13866818932969930912)
,p_short_name=>'Image Gallery'
,p_link=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.:::'
,p_page_id=>46
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14130857979255669572)
,p_short_name=>'Interactions'
,p_link=>'f?p=&APP_ID.:610:&SESSION.::&DEBUG.:::'
,p_page_id=>610
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(15941435851474426866)
,p_short_name=>'Duplicate &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:11320:&SESSION.::&DEBUG.:::'
,p_page_id=>11320
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16058310249579353476)
,p_short_name=>'Activity Types'
,p_link=>'f?p=&APP_ID.:10700:&SESSION.::&DEBUG.:RP::'
,p_page_id=>10700
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16110980310949462946)
,p_short_name=>'Description Change History'
,p_link=>'f?p=&APP_ID.:96:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>96
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16141846101814692227)
,p_short_name=>'Activity'
,p_link=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:::'
,p_page_id=>102
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16317867998819125685)
,p_short_name=>'Release History: &P200_RELEASE.'
,p_link=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:::'
,p_page_id=>200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16322834457627346475)
,p_short_name=>'Release Dashboard: &P202_RELEASE.'
,p_link=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.:::'
,p_page_id=>202
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16322841393141349468)
,p_short_name=>'Release Calendar: &P201_RELEASE.'
,p_link=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.:::'
,p_page_id=>201
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(17367738536921763062)
,p_short_name=>'Delete Sample Data'
,p_link=>'f?p=&APP_ID.:14010:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>14010
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(31456507818679415565)
,p_short_name=>'&NOMENCLATURE_PROJECT. Contributors'
,p_link=>'f?p=&APP_ID.:55:&SESSION.::&DEBUG.:::'
,p_page_id=>55
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(33473757568490753945)
,p_short_name=>'Releases'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(33773476747691058643)
,p_short_name=>'Releases'
,p_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:RP::'
,p_page_id=>16
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(114134763388104368181)
,p_short_name=>'&P3_PROJECT_NAME.'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(116714067210274215335)
,p_short_name=>'&NOMENCLATURE_PROJECT. Priorities'
,p_link=>'f?p=&APP_ID.:10800:&SESSION.::&DEBUG.:::'
,p_page_id=>10800
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(116912479310618932280)
,p_short_name=>'&P5_FIRST_NAME. &P5_LAST_NAME.'
,p_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
,p_page_id=>5
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141179926251368434823)
,p_short_name=>'Strategic Planner'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141180289622274435842)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:::'
,p_page_id=>10000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141198957257703661358)
,p_short_name=>'Contributor Roles'
,p_link=>'f?p=&APP_ID.:10600:&SESSION.::&DEBUG.:::'
,p_page_id=>10600
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141199890115843111107)
,p_short_name=>'&NOMENCLATURE_AREAS.'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141200163301082128409)
,p_short_name=>'&NOMENCLATURE_USERS. Details'
,p_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_page_id=>19
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141215879624913350638)
,p_short_name=>'&NOMENCLATURE_INITIATIVES.'
,p_link=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:::'
,p_page_id=>21
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141222896325226021445)
,p_short_name=>'&NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::'
,p_page_id=>23
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6180437736772190370)
,p_option_sequence=>10011
,p_short_name=>'Users'
,p_link=>'f?p=&APP_ID.:10011:&SESSION.::&DEBUG.:::'
,p_page_id=>10011
);
wwv_flow_imp.component_end;
end;
/
