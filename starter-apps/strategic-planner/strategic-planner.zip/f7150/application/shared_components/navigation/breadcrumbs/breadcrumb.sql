prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>15800832268207722
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(149558628688715206539)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14327342157075695609)
,p_option_sequence=>1
,p_short_name=>'Team Member Default Tags'
,p_link=>'f?p=&APP_ID.:10520:&SESSION.::&DEBUG.:::'
,p_page_id=>10520
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(10300565034010341683)
,p_short_name=>'Documents'
,p_link=>'f?p=&APP_ID.:14:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>14
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11430508783875132376)
,p_short_name=>'&P501_PAGE_NAME.'
,p_link=>'f?p=&APP_ID.:501:&SESSION.::&DEBUG.:::'
,p_page_id=>501
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11454311624041591425)
,p_short_name=>'Project Contributors'
,p_link=>'f?p=&APP_ID.:55:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>55
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11464172568028047565)
,p_short_name=>'&NOMENCLATURE_PROJECT. Groups'
,p_link=>'f?p=&APP_ID.:70:&SESSION.::&DEBUG.:::'
,p_page_id=>70
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11510557613302817860)
,p_short_name=>'Change History'
,p_link=>'f?p=&APP_ID.:64:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>64
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11625169500872440595)
,p_short_name=>'Add Project'
,p_link=>'f?p=&APP_ID.:104:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>104
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11647802801307073033)
,p_short_name=>'My &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:::'
,p_page_id=>113
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12041057155690726030)
,p_short_name=>'&P300_RELEASE. &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:::'
,p_page_id=>300
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12227914148613895219)
,p_short_name=>'Developer Detail Views (31 Days)'
,p_link=>'f?p=&APP_ID.:129:&SESSION.::&DEBUG.:::'
,p_page_id=>129
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12349077828226916406)
,p_short_name=>'&P29_PROJECT_NAME. - Images'
,p_link=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:::'
,p_page_id=>29
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12528191149360622801)
,p_short_name=>'About Page Text'
,p_link=>'f?p=&APP_ID.:14000:&SESSION.::&DEBUG.:::'
,p_page_id=>14000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13009486063112272044)
,p_short_name=>'&NOMENCLATURE_INITIATIVES. for &NOMENCLATURE_AREA. &P66_AREA.'
,p_link=>'f?p=&APP_ID.:66:&SESSION.::&DEBUG.:RP::'
,p_page_id=>66
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13121745905396609670)
,p_short_name=>'&NOMENCLATURE_PROJECT. Related Current Activity'
,p_link=>'f?p=&APP_ID.:75:&SESSION.::&DEBUG.:::'
,p_page_id=>75
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13624670305832528360)
,p_short_name=>'Resource Type Usage'
,p_link=>'f?p=&APP_ID.:10601:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10601
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13629181555861253301)
,p_short_name=>'&NOMENCLATURE_INITIATIVE. Focus Areas'
,p_link=>'f?p=&APP_ID.:10150:&SESSION.::&DEBUG.:::'
,p_page_id=>10150
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13769036636928512239)
,p_short_name=>'Page Views'
,p_link=>'f?p=&APP_ID.:39:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>39
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13770020680659552450)
,p_short_name=>'Page Performance'
,p_link=>'f?p=&APP_ID.:71:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>71
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13780669014246134518)
,p_short_name=>'Page Views by User'
,p_link=>'f?p=&APP_ID.:72:&SESSION.::&DEBUG.:::'
,p_page_id=>72
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13815840040987634998)
,p_short_name=>'&P30_DOCUMENT_NAME.'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13932472551685485381)
,p_short_name=>'&NOMENCLATURE_STRATEGIC_PLANNER.'
,p_link=>'f?p=&APP_ID.:10820:&SESSION.::&DEBUG.:::'
,p_page_id=>10820
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14323000301569300431)
,p_short_name=>'Notifications'
,p_link=>'f?p=&APP_ID.:10074:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10074
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14324814623823253025)
,p_short_name=>'My Subscriptions'
,p_link=>'f?p=&APP_ID.:139:&SESSION.::&DEBUG.:::'
,p_page_id=>139
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14325875561428470823)
,p_short_name=>'Change History'
,p_link=>'f?p=&APP_ID.:78:&SESSION.::&DEBUG.:::'
,p_page_id=>78
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14330755633744863363)
,p_short_name=>'Manage My Subscriptions'
,p_link=>'f?p=&APP_ID.:149:&SESSION.::&DEBUG.:::'
,p_page_id=>149
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14608238301797456788)
,p_short_name=>'&NOMENCLATURE_USERS.'
,p_link=>'f?p=&APP_ID.:74:&SESSION.::&DEBUG.:::'
,p_page_id=>74
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14709476387841411000)
,p_short_name=>'External &NOMENCLATURE_PROJECT. Links'
,p_link=>'f?p=&APP_ID.:10750:&SESSION.::&DEBUG.:::'
,p_page_id=>10750
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14713287923788797413)
,p_short_name=>'Home Page Messages'
,p_link=>'f?p=&APP_ID.:10770:&SESSION.::&DEBUG.:::'
,p_page_id=>10770
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14901081440583776552)
,p_short_name=>'&NOMENCLATURE_INITIATIVE.: &P94_INITIATIVE.'
,p_link=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP::'
,p_page_id=>94
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14933996903506787274)
,p_short_name=>'Release: &P117_RELEASE.'
,p_link=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.:::'
,p_page_id=>117
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(15330385462723651309)
,p_short_name=>'Release Calendar: &P203_RELEASE.'
,p_link=>'f?p=&APP_ID.:203:&SESSION.::&DEBUG.:::'
,p_page_id=>203
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(15626079750595991353)
,p_short_name=>'Project Completeness Scales'
,p_link=>'f?p=&APP_ID.:10200:&SESSION.::&DEBUG.:::'
,p_page_id=>10200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(15700709724054020598)
,p_short_name=>'Application Log'
,p_link=>'f?p=&APP_ID.:10050:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10050
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(15900773445971956284)
,p_short_name=>'Project Size'
,p_link=>'f?p=&APP_ID.:10100:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16423619731968254232)
,p_short_name=>'Release Milestone Types'
,p_link=>'f?p=&APP_ID.:10090:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10090
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(17028671186012256022)
,p_short_name=>'Favorited &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:::'
,p_page_id=>15
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(17031635896231315192)
,p_short_name=>'Favorite &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:91:&SESSION.::&DEBUG.:::'
,p_page_id=>91
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(17195931628831020743)
,p_short_name=>'Project Milestone Calendar'
,p_link=>'f?p=&APP_ID.:111:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>111
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(17743802372583987569)
,p_short_name=>'&P119_PROJECT_GROUP. &NOMENCLATURE_PROJECT. Group'
,p_link=>'f?p=&APP_ID.:119:&SESSION.::&DEBUG.:::'
,p_page_id=>119
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(18202213806081607263)
,p_short_name=>'Nomenclature'
,p_link=>'f?p=&APP_ID.:10400:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10400
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(18364214792224553773)
,p_short_name=>'Application Pages'
,p_link=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:::'
,p_page_id=>37
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(18394816449660237273)
,p_short_name=>'Release Milestones'
,p_link=>'f?p=&APP_ID.:84:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>84
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(18429049841280249557)
,p_short_name=>'Feedback'
,p_link=>'f?p=&APP_ID.:12123:&SESSION.::&DEBUG.:::'
,p_page_id=>12123
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(18819458681513968014)
,p_short_name=>'&NOMENCLATURE_PROJECTS. Interactive Report'
,p_link=>'f?p=&APP_ID.:86:&SESSION.::&DEBUG.:::'
,p_page_id=>86
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(19223558979655615565)
,p_short_name=>'Groups'
,p_link=>'f?p=&APP_ID.:103:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>103
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(19225192946000150994)
,p_short_name=>'&P151_GROUP_NAME.'
,p_link=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.:::'
,p_page_id=>151
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(19572255556466547259)
,p_short_name=>'Change History'
,p_link=>'f?p=&APP_ID.:79:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>79
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(19592463155432948827)
,p_short_name=>'Workflow Console'
,p_link=>'f?p=&APP_ID.:4000:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>4000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(19593283797614993692)
,p_short_name=>'My Tasks'
,p_link=>'f?p=&APP_ID.:5000:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>5000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(20052027930356659537)
,p_short_name=>'Screen Names'
,p_link=>'f?p=&APP_ID.:122:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>122
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(20056638314455139181)
,p_short_name=>'Comments'
,p_link=>'f?p=&APP_ID.:7:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(20237125667521039261)
,p_short_name=>'APEX Bugs'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(20265886430751715005)
,p_short_name=>'&NOMENCLATURE_PROJECT. Default Tags'
,p_link=>'f?p=&APP_ID.:10500:&SESSION.::&DEBUG.:::'
,p_page_id=>10500
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(20279643941009155928)
,p_short_name=>'Configure Application Features'
,p_link=>'f?p=&APP_ID.:12130:&SESSION.::&DEBUG.:::'
,p_page_id=>12130
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(20352043272860354939)
,p_short_name=>'Reports'
,p_link=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:::'
,p_page_id=>41
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(21067018821121710717)
,p_short_name=>'Countries'
,p_link=>'f?p=&APP_ID.:43:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>43
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(21271818981896694703)
,p_short_name=>'Default Competencies'
,p_link=>'f?p=&APP_ID.:154:&SESSION.::&DEBUG.:::'
,p_page_id=>154
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(21331351061331495319)
,p_short_name=>'Job Reporting'
,p_link=>'f?p=&APP_ID.:16010:&SESSION.::&DEBUG.:::'
,p_page_id=>16010
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(21361666985654448060)
,p_short_name=>'Subscriptions'
,p_link=>'f?p=&APP_ID.:16015:&SESSION.::&DEBUG.:::'
,p_page_id=>16015
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(21467993719016612359)
,p_short_name=>'Settings'
,p_link=>'f?p=&APP_ID.:12150:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>12150
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(21858353540940673848)
,p_short_name=>'Manage Archived &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:11300:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>11300
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(21900873132023529718)
,p_short_name=>'Archived &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:45:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>45
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(21911616346728237251)
,p_short_name=>'Duplicate &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.:::'
,p_page_id=>51
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(22109935644686573542)
,p_short_name=>'Email Reporting'
,p_link=>'f?p=&APP_ID.:16020:&SESSION.::&DEBUG.:::'
,p_page_id=>16020
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(22245521536526702628)
,p_short_name=>'Image Gallery'
,p_link=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.:::'
,p_page_id=>46
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(22509560582812441288)
,p_short_name=>'&NOMENCLATURE_PROJECT. Interactions'
,p_link=>'f?p=&APP_ID.:610:&SESSION.::&DEBUG.:::'
,p_page_id=>610
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(24320138455031198582)
,p_short_name=>'Duplicate &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:11320:&SESSION.::&DEBUG.:::'
,p_page_id=>11320
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(24437012853136125192)
,p_short_name=>'Activity Types'
,p_link=>'f?p=&APP_ID.:10700:&SESSION.::&DEBUG.:RP::'
,p_page_id=>10700
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(24520548705371463943)
,p_short_name=>'Activities'
,p_link=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:::'
,p_page_id=>102
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(24696570602375897401)
,p_short_name=>'Release History: &P200_RELEASE.'
,p_link=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:::'
,p_page_id=>200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(24701537061184118191)
,p_short_name=>'Release Dashboard: &P202_RELEASE.'
,p_link=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.:::'
,p_page_id=>202
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(25618139849625486582)
,p_short_name=>'Kanban: &P160_INITIATIVE.'
,p_link=>'f?p=&APP_ID.:160:&SESSION.::&DEBUG.:::'
,p_page_id=>160
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(25682742961504505769)
,p_short_name=>'Planning Board: &P164_INITIATIVE.'
,p_link=>'f?p=&APP_ID.:164:&SESSION.::&DEBUG.:::'
,p_page_id=>164
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(25746441140478534778)
,p_short_name=>'Delete Sample Data'
,p_link=>'f?p=&APP_ID.:14010:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>14010
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(26902994856279823797)
,p_short_name=>'&P42_DOCUMENT_NAME.'
,p_link=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:::'
,p_page_id=>42
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(26905928522418093151)
,p_short_name=>'&P53_DOCUMENT_NAME.'
,p_link=>'f?p=&APP_ID.:53:&SESSION.::&DEBUG.:::'
,p_page_id=>53
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(26911662920807435500)
,p_short_name=>'Links'
,p_link=>'f?p=&APP_ID.:26:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>26
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(27146654127441799137)
,p_short_name=>'&NOMENCLATURE_INITIATIVE. Change History'
,p_link=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::'
,p_page_id=>11
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(27262407297944173594)
,p_short_name=>'&P33_INITIATIVE. - &P33_FOCUS_AREA.'
,p_link=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:::'
,p_page_id=>33
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(27360189753845398139)
,p_short_name=>'&P57_INIT_FOCUS_AREA.'
,p_link=>'f?p=&APP_ID.:57:&SESSION.::&DEBUG.:::'
,p_page_id=>57
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(27362477272163899727)
,p_short_name=>'&P59_DOCUMENT_NAME.'
,p_link=>'f?p=&APP_ID.:59:&SESSION.::&DEBUG.:::'
,p_page_id=>59
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(27730999090434851892)
,p_short_name=>'&P60_TASK_NAME. - Images'
,p_link=>'f?p=&APP_ID.:60:&SESSION.::&DEBUG.:::'
,p_page_id=>60
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(27765390948279756006)
,p_short_name=>'&P62_INITIATIVE_NAME. - Images'
,p_link=>'f?p=&APP_ID.:62:&SESSION.::&DEBUG.:::'
,p_page_id=>62
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(27829887383160075184)
,p_short_name=>'&P68_FOCUS_AREA. -  Images'
,p_link=>'f?p=&APP_ID.:68:&SESSION.::&DEBUG.:::'
,p_page_id=>68
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(27838424474654649798)
,p_short_name=>'&P69_RELEASE. - Images'
,p_link=>'f?p=&APP_ID.:69:&SESSION.::&DEBUG.:::'
,p_page_id=>69
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(28365169291461474359)
,p_short_name=>'&P502_TASK.'
,p_link=>'f?p=&APP_ID.:502:&SESSION.::&DEBUG.:::'
,p_page_id=>502
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(28396497689855052362)
,p_short_name=>'Task Document Details'
,p_link=>'f?p=&APP_ID.:505:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>505
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(28401313600502356265)
,p_short_name=>'Task Change History'
,p_link=>'f?p=&APP_ID.:507:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>507
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(28471073548642705406)
,p_short_name=>'Task Statuses'
,p_link=>'f?p=&APP_ID.:10061:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10061
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(28477647409995747698)
,p_short_name=>'Task Status'
,p_link=>'f?p=&APP_ID.:10062:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10062
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(28480881539451953675)
,p_short_name=>'Task Types'
,p_link=>'f?p=&APP_ID.:10064:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10064
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(28539458187240065987)
,p_short_name=>'&NOMENCLATURE_PROJECT. Views (last 90 days)'
,p_link=>'f?p=&APP_ID.:80:&SESSION.::&DEBUG.:::'
,p_page_id=>80
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(28540893228900312758)
,p_short_name=>'&NOMENCLATURE_INITIATIVE. Views (last 90 Days)'
,p_link=>'f?p=&APP_ID.:81:&SESSION.::&DEBUG.:::'
,p_page_id=>81
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(28542975486458381012)
,p_short_name=>'Project Views by User (last 3 full months)'
,p_link=>'f?p=&APP_ID.:89:&SESSION.::&DEBUG.:::'
,p_page_id=>89
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(29011412866162573003)
,p_short_name=>'Tasks'
,p_link=>'f?p=&APP_ID.:500:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>500
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(41852460172047525661)
,p_short_name=>'Releases'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(42152179351247830359)
,p_short_name=>'Releases'
,p_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:RP::'
,p_page_id=>16
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(122513465991661139897)
,p_short_name=>'&P3_PROJECT_NAME.'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(125092769813830987051)
,p_short_name=>'&NOMENCLATURE_PROJECT. Priorities'
,p_link=>'f?p=&APP_ID.:10800:&SESSION.::&DEBUG.:::'
,p_page_id=>10800
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(125291181914175703996)
,p_short_name=>'&P5_FIRST_NAME. &P5_LAST_NAME.'
,p_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
,p_page_id=>5
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(149558628854925206539)
,p_short_name=>'&NOMENCLATURE_STRATEGIC_PLANNER.'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(149558992225831207558)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:::'
,p_page_id=>10000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(149577659861260433074)
,p_short_name=>'Contributor Roles'
,p_link=>'f?p=&APP_ID.:10600:&SESSION.::&DEBUG.:::'
,p_page_id=>10600
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(149578592719399882823)
,p_short_name=>'&NOMENCLATURE_AREAS.'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(149578865904638900125)
,p_short_name=>'&NOMENCLATURE_USERS. Details'
,p_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_page_id=>19
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(149594582228470122354)
,p_short_name=>'&NOMENCLATURE_INITIATIVES.'
,p_link=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:::'
,p_page_id=>21
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(149601598928782793161)
,p_short_name=>'&NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::'
,p_page_id=>23
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14559140340328962086)
,p_option_sequence=>10011
,p_short_name=>'Users'
,p_link=>'f?p=&APP_ID.:10011:&SESSION.::&DEBUG.:::'
,p_page_id=>10011
);
wwv_flow_imp.component_end;
end;
/
