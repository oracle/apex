prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>19055477148803894
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(141234324626560172722)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6003038094920661792)
,p_option_sequence=>1
,p_short_name=>'Team Member Default Tags'
,p_link=>'f?p=&APP_ID.:10520:&SESSION.::&DEBUG.:::'
,p_page_id=>10520
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1976260971855307866)
,p_short_name=>'Documents'
,p_link=>'f?p=&APP_ID.:14:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>14
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3186253551147784043)
,p_short_name=>'Change History'
,p_link=>'f?p=&APP_ID.:64:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>64
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3300865438717406778)
,p_short_name=>'Add Project'
,p_link=>'f?p=&APP_ID.:104:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>104
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3321858097159790218)
,p_short_name=>'My Activities'
,p_link=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:::'
,p_page_id=>112
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3323498739152039216)
,p_short_name=>'My &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:::'
,p_page_id=>113
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3504323563471126258)
,p_short_name=>'Contributor Checklist'
,p_link=>'f?p=&APP_ID.:121:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>121
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3526813637846080788)
,p_short_name=>'Contributor Checklist Admin'
,p_link=>'f?p=&APP_ID.:13000:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>13000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3614242719679236962)
,p_short_name=>'Review Types'
,p_link=>'f?p=&APP_ID.:10063:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10063
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3716753093535692213)
,p_short_name=>'&P300_RELEASE. &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.:::'
,p_page_id=>300
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3903610086458861402)
,p_short_name=>'Developer Detail Views (31 Days)'
,p_link=>'f?p=&APP_ID.:129:&SESSION.::&DEBUG.:::'
,p_page_id=>129
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4024773766071882589)
,p_short_name=>'&P29_PROJECT_NAME.'
,p_link=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:::'
,p_page_id=>29
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4203887087205588984)
,p_short_name=>'About Page Text'
,p_link=>'f?p=&APP_ID.:14000:&SESSION.::&DEBUG.:::'
,p_page_id=>14000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4685182000957238227)
,p_short_name=>'Initiatives for &NOMENCLATURE_AREA. &P66_AREA.'
,p_link=>'f?p=&APP_ID.:66:&SESSION.::&DEBUG.:RP::'
,p_page_id=>66
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4797441843241575853)
,p_short_name=>'&NOMENCLATURE_PROJECT. Related Current Activity'
,p_link=>'f?p=&APP_ID.:75:&SESSION.::&DEBUG.:::'
,p_page_id=>75
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5300366243677494543)
,p_short_name=>'Resource Type Usage'
,p_link=>'f?p=&APP_ID.:10601:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10601
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5444732574773478422)
,p_short_name=>'Page Views'
,p_link=>'f?p=&APP_ID.:39:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>39
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5445716618504518633)
,p_short_name=>'Page Performance'
,p_link=>'f?p=&APP_ID.:71:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>71
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5456364952091100701)
,p_short_name=>'Page Views by User'
,p_link=>'f?p=&APP_ID.:72:&SESSION.::&DEBUG.:::'
,p_page_id=>72
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5491535978832601181)
,p_short_name=>'&P30_DOCUMENT_NAME.'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5597576298662392056)
,p_short_name=>'Contributor Checklist'
,p_link=>'f?p=&APP_ID.:40:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>40
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5608168489530451564)
,p_short_name=>'Strategic Planner'
,p_link=>'f?p=&APP_ID.:10820:&SESSION.::&DEBUG.:::'
,p_page_id=>10820
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(5998696239414266614)
,p_short_name=>'Notifications'
,p_link=>'f?p=&APP_ID.:10074:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10074
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6000510561668219208)
,p_short_name=>'My Subscriptions'
,p_link=>'f?p=&APP_ID.:139:&SESSION.::&DEBUG.:::'
,p_page_id=>139
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6001571499273437006)
,p_short_name=>'Change History'
,p_link=>'f?p=&APP_ID.:78:&SESSION.::&DEBUG.:::'
,p_page_id=>78
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6006451571589829546)
,p_short_name=>'Manage My Subscriptions'
,p_link=>'f?p=&APP_ID.:149:&SESSION.::&DEBUG.:::'
,p_page_id=>149
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6283934239642422971)
,p_short_name=>'&NOMENCLATURE_USERS.'
,p_link=>'f?p=&APP_ID.:74:&SESSION.::&DEBUG.:::'
,p_page_id=>74
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6385172325686377183)
,p_short_name=>'External &NOMENCLATURE_PROJECT. Links'
,p_link=>'f?p=&APP_ID.:10750:&SESSION.::&DEBUG.:::'
,p_page_id=>10750
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6388983861633763596)
,p_short_name=>'Home Page Messages'
,p_link=>'f?p=&APP_ID.:10770:&SESSION.::&DEBUG.:::'
,p_page_id=>10770
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6576777378428742735)
,p_short_name=>'&NOMENCLATURE_INITIATIVE.: &P94_INITIATIVE.'
,p_link=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:RP::'
,p_page_id=>94
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6609692841351753457)
,p_short_name=>'Release: &P117_RELEASE.'
,p_link=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.:::'
,p_page_id=>117
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(7301775688440957536)
,p_short_name=>'Project Percent Complete and Milestone Scales'
,p_link=>'f?p=&APP_ID.:10200:&SESSION.::&DEBUG.:::'
,p_page_id=>10200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(7576469383816922467)
,p_short_name=>'Project Size'
,p_link=>'f?p=&APP_ID.:10100:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(9877909743926573446)
,p_short_name=>'Nomenclature'
,p_link=>'f?p=&APP_ID.:10400:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10400
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(10039910730069519956)
,p_short_name=>'Application Pages'
,p_link=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:::'
,p_page_id=>37
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(10070512387505203456)
,p_short_name=>'Release Milestones'
,p_link=>'f?p=&APP_ID.:84:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>84
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(10104745779125215740)
,p_short_name=>'Feedback'
,p_link=>'f?p=&APP_ID.:12123:&SESSION.::&DEBUG.:::'
,p_page_id=>12123
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(10495154619358934197)
,p_short_name=>'&NOMENCLATURE_PROJECTS. Interactive Report'
,p_link=>'f?p=&APP_ID.:86:&SESSION.::&DEBUG.:::'
,p_page_id=>86
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(10899254917500581748)
,p_short_name=>'Groups'
,p_link=>'f?p=&APP_ID.:103:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>103
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(10900888883845117177)
,p_short_name=>'&P151_GROUP_NAME.'
,p_link=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.:::'
,p_page_id=>151
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11732334252300105364)
,p_short_name=>'Comments'
,p_link=>'f?p=&APP_ID.:7:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11941582368596681188)
,p_short_name=>'&NOMENCLATURE_PROJECT. Default Tags'
,p_link=>'f?p=&APP_ID.:10500:&SESSION.::&DEBUG.:::'
,p_page_id=>10500
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11955339878854122111)
,p_short_name=>'Configure Application Features'
,p_link=>'f?p=&APP_ID.:12130:&SESSION.::&DEBUG.:::'
,p_page_id=>12130
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12027739210705321122)
,p_short_name=>'Reports'
,p_link=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:::'
,p_page_id=>41
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12742714758966676900)
,p_short_name=>'Countries'
,p_link=>'f?p=&APP_ID.:43:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>43
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(12947514919741660886)
,p_short_name=>'Default Competencies'
,p_link=>'f?p=&APP_ID.:154:&SESSION.::&DEBUG.:::'
,p_page_id=>154
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13007046999176461502)
,p_short_name=>'Job Reporting'
,p_link=>'f?p=&APP_ID.:16010:&SESSION.::&DEBUG.:::'
,p_page_id=>16010
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13037362923499414243)
,p_short_name=>'Subscriptions'
,p_link=>'f?p=&APP_ID.:16015:&SESSION.::&DEBUG.:::'
,p_page_id=>16015
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13143689656861578542)
,p_short_name=>'Settings'
,p_link=>'f?p=&APP_ID.:12150:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>12150
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13534049478785640031)
,p_short_name=>'Manage Archived &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:11300:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>11300
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13576569069868495901)
,p_short_name=>'Archived &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:45:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>45
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13587312284573203434)
,p_short_name=>'Duplicate &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.:::'
,p_page_id=>51
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13785631582531539725)
,p_short_name=>'Email Reporting'
,p_link=>'f?p=&APP_ID.:16020:&SESSION.::&DEBUG.:::'
,p_page_id=>16020
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(13921217474371668811)
,p_short_name=>'Image Gallery'
,p_link=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.:::'
,p_page_id=>46
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(14185256520657407471)
,p_short_name=>'Interactions'
,p_link=>'f?p=&APP_ID.:610:&SESSION.::&DEBUG.:::'
,p_page_id=>610
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(15995834392876164765)
,p_short_name=>'Duplicate &NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:11320:&SESSION.::&DEBUG.:::'
,p_page_id=>11320
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16112708790981091375)
,p_short_name=>'Activity Types'
,p_link=>'f?p=&APP_ID.:10700:&SESSION.::&DEBUG.:RP::'
,p_page_id=>10700
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16165378852351200845)
,p_short_name=>'Description Change History'
,p_link=>'f?p=&APP_ID.:96:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>96
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16196244643216430126)
,p_short_name=>'Activity'
,p_link=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:::'
,p_page_id=>102
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16372266540220863584)
,p_short_name=>'Release History: &P200_RELEASE.'
,p_link=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:::'
,p_page_id=>200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16377232999029084374)
,p_short_name=>'Release Dashboard: &P202_RELEASE.'
,p_link=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.:::'
,p_page_id=>202
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(16377239934543087367)
,p_short_name=>'Release Calendar: &P201_RELEASE.'
,p_link=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.:::'
,p_page_id=>201
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(17422137078323500961)
,p_short_name=>'Delete Sample Data'
,p_link=>'f?p=&APP_ID.:14010:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>14010
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(18578690794124789980)
,p_short_name=>'&P42_DOCUMENT_NAME.'
,p_link=>'f?p=&APP_ID.:42:&SESSION.::&DEBUG.:::'
,p_page_id=>42
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(18581624460263059334)
,p_short_name=>'&P53_DOCUMENT_NAME.'
,p_link=>'f?p=&APP_ID.:53:&SESSION.::&DEBUG.:::'
,p_page_id=>53
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(18587358858652401683)
,p_short_name=>'Links'
,p_link=>'f?p=&APP_ID.:26:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>26
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(31510906360081153464)
,p_short_name=>'&NOMENCLATURE_PROJECT. Contributors'
,p_link=>'f?p=&APP_ID.:55:&SESSION.::&DEBUG.:::'
,p_page_id=>55
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(33528156109892491844)
,p_short_name=>'Releases'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(33827875289092796542)
,p_short_name=>'Releases'
,p_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:RP::'
,p_page_id=>16
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(114189161929506106080)
,p_short_name=>'&P3_PROJECT_NAME.'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(116768465751675953234)
,p_short_name=>'&NOMENCLATURE_PROJECT. Priorities'
,p_link=>'f?p=&APP_ID.:10800:&SESSION.::&DEBUG.:::'
,p_page_id=>10800
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(116966877852020670179)
,p_short_name=>'&P5_FIRST_NAME. &P5_LAST_NAME.'
,p_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
,p_page_id=>5
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141234324792770172722)
,p_short_name=>'Strategic Planner'
,p_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141234688163676173741)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:::'
,p_page_id=>10000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141253355799105399257)
,p_short_name=>'Contributor Roles'
,p_link=>'f?p=&APP_ID.:10600:&SESSION.::&DEBUG.:::'
,p_page_id=>10600
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141254288657244849006)
,p_short_name=>'&NOMENCLATURE_AREAS.'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141254561842483866308)
,p_short_name=>'&NOMENCLATURE_USERS. Details'
,p_link=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_page_id=>19
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141270278166315088537)
,p_short_name=>'&NOMENCLATURE_INITIATIVES.'
,p_link=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:::'
,p_page_id=>21
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(141277294866627759344)
,p_short_name=>'&NOMENCLATURE_PROJECTS.'
,p_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::'
,p_page_id=>23
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6234836278173928269)
,p_option_sequence=>10011
,p_short_name=>'Users'
,p_link=>'f?p=&APP_ID.:10011:&SESSION.::&DEBUG.:::'
,p_page_id=>10011
);
wwv_flow_imp.component_end;
end;
/
