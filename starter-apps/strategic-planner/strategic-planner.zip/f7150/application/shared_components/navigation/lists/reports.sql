prompt --application/shared_components/navigation/lists/reports
begin
--   Manifest
--     LIST: Reports
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>26954343551793662
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(12156689744350165071)
,p_name=>'Reports'
,p_list_status=>'PUBLIC'
,p_version_scn=>37167711502259
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(12156892374525165079)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Documents'
,p_list_item_link_target=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'Documents added to the system.  '
,p_list_text_08=>'documents, images'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'14'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(18568857396165783232)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Links'
,p_list_item_link_target=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-link'
,p_list_text_01=>'Links added to the system.  '
,p_list_text_08=>'documents, images'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(13902347287662474549)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Image Gallery'
,p_list_item_link_target=>'f?p=&APP_ID.:46:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-photo'
,p_list_text_01=>'Images over all &NOMENCLATURE_PROJECTS..'
,p_list_text_08=>'images, documents, attachments'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'14'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5815717522455711338)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Change History'
,p_list_item_link_target=>'f?p=&APP_ID.:78:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-clock-o'
,p_list_text_01=>'Cross &NOMENCLATURE_PROJECT. change reporting.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15331484916920904212)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Comments'
,p_list_item_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-comment-o'
,p_list_text_01=>'All comments added to this system.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15331367057061877281)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'&NOMENCLATURE_PROJECT. Contributors'
,p_list_item_link_target=>'f?p=&APP_ID.:55:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user'
,p_list_text_01=>'Cross &NOMENCLATURE_PROJECT. Contributors report.'
,p_required_patch=>wwv_flow_imp.id(6237102873070537716)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15331692774506780530)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Archived &NOMENCLATURE_PROJECTS.'
,p_list_item_link_target=>'f?p=&APP_ID.:45:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-package'
,p_list_text_01=>'All &NOMENCLATURE_PROJECTS. that are archived.'
,p_required_patch=>wwv_flow_imp.id(6237102873070537716)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15331717218458784651)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Duplicate &NOMENCLATURE_PROJECTS.'
,p_list_item_link_target=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-copy'
,p_list_text_01=>'All &NOMENCLATURE_PROJECTS. that appear to be duplicates.'
,p_required_patch=>wwv_flow_imp.id(6237102873070537716)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10478530092360253251)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>'&NOMENCLATURE_PROJECTS. Interactive Report'
,p_list_item_link_target=>'f?p=&APP_ID.:86:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table-arrow-down'
,p_list_text_01=>'Interactive report of &NOMENCLATURE_PROJECTS. that supports download.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
