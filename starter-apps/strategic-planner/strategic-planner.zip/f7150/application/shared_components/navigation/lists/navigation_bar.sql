prompt --application/shared_components/navigation/lists/navigation_bar
begin
--   Manifest
--     LIST: Navigation Bar
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>19055477148803894
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(141234619675595173011)
,p_name=>'Navigation Bar'
,p_list_status=>'PUBLIC'
,p_version_scn=>37167711502259
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(141234685698159173734)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'&APP_USER.'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-user'
,p_list_text_02=>'has-username'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6351996741943064160)
,p_list_item_display_sequence=>12
,p_list_item_link_text=>'My Profile'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:RP:P5_ID:&APP_USER_ID.:'
,p_list_item_icon=>'fa-user'
,p_list_item_disp_cond_type=>'ITEM_IS_NOT_NULL'
,p_list_item_disp_condition=>'APP_USER_ID'
,p_parent_list_item_id=>wwv_flow_imp.id(141234685698159173734)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6000686864683586657)
,p_list_item_display_sequence=>12
,p_list_item_link_text=>'My Subscriptions'
,p_list_item_link_target=>'f?p=&APP_ID.:139:&SESSION.::&DEBUG.:139:::'
,p_list_item_icon=>'fa-sliders'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':APP_USER_ID is not null and',
'apex_util.get_build_option_status (',
'    p_application_id    => :APP_ID,',
'    p_build_option_name => ''Email Configured'') = ''INCLUDE'' and',
'apex_util.get_build_option_status (',
'    p_application_id    => :APP_ID,',
'    p_build_option_name => ''Subscriptions'') = ''INCLUDE'''))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(141234685698159173734)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(4042356674907160416)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'About this App'
,p_list_item_link_target=>'f?p=&APP_ID.:10820:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-info'
,p_parent_list_item_id=>wwv_flow_imp.id(141234685698159173734)
,p_required_patch=>wwv_flow_imp.id(4042145123089155106)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5584875165864369243)
,p_list_item_display_sequence=>75
,p_list_item_link_text=>'Administration'
,p_list_item_link_target=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-users'
,p_parent_list_item_id=>wwv_flow_imp.id(141234685698159173734)
,p_security_scheme=>wwv_flow_imp.id(141234623681567173040)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(141234686232242173735)
,p_list_item_display_sequence=>78
,p_list_item_link_text=>'---'
,p_list_item_link_target=>'separator'
,p_parent_list_item_id=>wwv_flow_imp.id(141234685698159173734)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(141234686666296173735)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Sign Out'
,p_list_item_link_target=>'&LOGOUT_URL.'
,p_list_item_icon=>'fa-sign-out'
,p_parent_list_item_id=>wwv_flow_imp.id(141234685698159173734)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10095942273310978928)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Feedback'
,p_list_item_link_target=>'f?p=&APP_ID.:12120:&SESSION.::&DEBUG.:12120:P12120_PAGE_ID:&APP_PAGE_ID.:'
,p_list_item_icon=>'fa-comment-o'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>'apex_util.feedback_enabled'
,p_list_item_disp_condition2=>'PLSQL'
,p_list_text_02=>'icon-only'
,p_security_scheme=>wwv_flow_imp.id(141234623733867173040)
,p_required_patch=>wwv_flow_imp.id(10095904552004978856)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
