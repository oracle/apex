prompt --application/shared_components/navigation/lists/navigation_bar
begin
--   Manifest
--     LIST: Navigation Bar
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(176220690369545839636)
,p_name=>'Navigation Bar'
,p_static_id=>'navigation-bar'
,p_version_scn=>'45775928669870'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(39028427368857827041)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'About this App'
,p_static_id=>'about-this-app'
,p_list_item_link_target=>'f?p=&APP_ID.:10820:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-info'
,p_parent_list_item_id=>wwv_flow_imp.id(176220756392109840359)
,p_required_patch=>wwv_flow_imp.id(39028215817039821731)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(40570945859815035868)
,p_list_item_display_sequence=>75
,p_list_item_link_text=>'Administration'
,p_static_id=>'administration'
,p_list_item_link_target=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-users'
,p_parent_list_item_id=>wwv_flow_imp.id(176220756392109840359)
,p_security_scheme=>wwv_flow_imp.id(176220694375517839665)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(40716092652765814679)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Alerts'
,p_static_id=>'alerts'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:2:::'
,p_list_item_icon=>'fa-bell'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from sp_team_member_notifications',
' where team_member_id = :APP_USER_ID',
'   and dismissed_yn = ''N''',
'   and instr('':''||notification_pref||'':'','':APP:'') > 0'))
,p_list_text_02=>'icon-only'
,p_list_text_04=>'Alerts'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(176220756392109840359)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'&APP_USER_FIRST_NAME.'
,p_static_id=>'app-user-first-name'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-user'
,p_list_text_02=>'has-username'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(53826135131353091604)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Approval Requests'
,p_static_id=>'approval-requests'
,p_list_item_link_target=>'f?p=&APP_ID.:132:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-workflow'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':APPROVALS_PENDING_CNT > 0 or',
':APPROVALS_MORE_INFO_CNT > 0'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_text_02=>'icon-only'
,p_list_text_04=>'Approval Requests'
,p_required_patch=>wwv_flow_imp.id(46253531127994752923)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(45082012967261645553)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Feedback'
,p_static_id=>'feedback'
,p_list_item_link_target=>'f?p=&APP_ID.:12120:&SESSION.::&DEBUG.:12120:P12120_PAGE_ID:&APP_PAGE_ID.:'
,p_list_item_icon=>'fa-comment-o'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>'apex_util.feedback_enabled'
,p_list_item_disp_condition2=>'PLSQL'
,p_list_text_02=>'icon-only'
,p_security_scheme=>wwv_flow_imp.id(176220694427817839665)
,p_required_patch=>wwv_flow_imp.id(45081975245955645481)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(30242334033642535909)
,p_list_item_display_sequence=>5
,p_list_item_link_text=>'---'
,p_static_id=>'list_item'
,p_list_item_link_target=>'separator'
,p_parent_list_item_id=>wwv_flow_imp.id(176220756392109840359)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(30241583246641414493)
,p_list_item_display_sequence=>45
,p_list_item_link_text=>'---'
,p_static_id=>'list_item-2'
,p_list_item_link_target=>'separator'
,p_parent_list_item_id=>wwv_flow_imp.id(176220756392109840359)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(176220756926192840360)
,p_list_item_display_sequence=>78
,p_list_item_link_text=>'---'
,p_static_id=>'list_item-3'
,p_list_item_link_target=>'separator'
,p_parent_list_item_id=>wwv_flow_imp.id(176220756392109840359)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(60480896025115786296)
,p_list_item_display_sequence=>4
,p_list_item_link_text=>'My Activities'
,p_static_id=>'my-activities'
,p_list_item_link_target=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:102:P102_PERSON:&APP_USER_FIRST_LAST_NAME.:'
,p_list_item_icon=>'fa-badge-check'
,p_parent_list_item_id=>wwv_flow_imp.id(176220756392109840359)
,p_required_patch=>wwv_flow_imp.id(51181142606315879163)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(18858546639620452538)
,p_list_item_display_sequence=>17
,p_list_item_link_text=>'My Approval Configuration'
,p_static_id=>'my-approval-configuration'
,p_list_item_link_target=>'f?p=&APP_ID.:147:&SESSION.::&DEBUG.:147:::'
,p_list_item_icon=>'fa-workflow'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from sp_initiative_approval_chain c,',
'       sp_initiative_approvals a',
' where a.id = c.initiative_approval_id',
'   and c.team_member_id = :APP_USER_ID',
'   and a.active_yn = ''Y'''))
,p_parent_list_item_id=>wwv_flow_imp.id(176220756392109840359)
,p_required_patch=>wwv_flow_imp.id(46253531127994752923)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(60480895166782786295)
,p_list_item_display_sequence=>2
,p_list_item_link_text=>'My Favorite &NOMENCLATURE_PROJECTS.'
,p_static_id=>'my-favorite-nomenclature-projects'
,p_list_item_link_target=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:23:P23_FAVORITE:Yes:'
,p_list_item_icon=>'fa-heart'
,p_parent_list_item_id=>wwv_flow_imp.id(176220756392109840359)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(60480894714515786295)
,p_list_item_display_sequence=>1
,p_list_item_link_text=>'My &NOMENCLATURE_PROJECTS.'
,p_static_id=>'my-nomenclature-projects'
,p_list_item_link_target=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:113:::'
,p_list_item_icon=>'fa-package'
,p_parent_list_item_id=>wwv_flow_imp.id(176220756392109840359)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(41338067435893730785)
,p_list_item_display_sequence=>12
,p_list_item_link_text=>'My Profile'
,p_static_id=>'my-profile'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:RP:P5_ID:&APP_USER_ID.:'
,p_list_item_icon=>'fa-user'
,p_list_item_disp_cond_type=>'ITEM_IS_NOT_NULL'
,p_list_item_disp_condition=>'APP_USER_ID'
,p_parent_list_item_id=>wwv_flow_imp.id(176220756392109840359)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(40986757558634253282)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'My Subscriptions'
,p_static_id=>'my-subscriptions'
,p_list_item_link_target=>'f?p=&APP_ID.:139:&SESSION.::&DEBUG.:139:::'
,p_list_item_icon=>'fa-sliders'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':APP_USER_ID is not null and',
'apex_util.get_build_option_status (',
'    p_application_id    => :APP_ID,',
'    p_build_option_name => ''Email Configured'') = ''INCLUDE'' and',
'apex_util.get_build_option_status (',
'    p_application_id    => :APP_ID,',
'    p_build_option_name => ''Subscriptions'') = ''INCLUDE'''))
,p_list_item_disp_condition2=>'PLSQL'
,p_parent_list_item_id=>wwv_flow_imp.id(176220756392109840359)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(60480895640906786296)
,p_list_item_display_sequence=>3
,p_list_item_link_text=>'My Tasks'
,p_static_id=>'my-tasks'
,p_list_item_link_target=>'f?p=&APP_ID.:65:&SESSION.::&DEBUG.:65,CIR,RIR:IR_ASSIGNED_TO_OWNER_ID: &APP_USER_ID.:'
,p_list_item_icon=>'fa-clipboard-list'
,p_parent_list_item_id=>wwv_flow_imp.id(176220756392109840359)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(43010625477009790887)
,p_list_item_display_sequence=>1
,p_list_item_link_text=>'Recent Projects'
,p_static_id=>'recent-projects'
,p_list_item_icon=>'fa-folder-clock'
,p_list_text_02=>'icon-only'
,p_list_text_04=>'Recent Projects'
,p_list_item_current_type=>'TARGET_PAGE'
,p_sub_list_id=>wwv_flow_imp.id(43010456180246093027)
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(176220757360246840360)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Sign Out'
,p_static_id=>'sign-out'
,p_list_item_link_target=>'&LOGOUT_URL.'
,p_list_item_icon=>'fa-sign-out'
,p_parent_list_item_id=>wwv_flow_imp.id(176220756392109840359)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
