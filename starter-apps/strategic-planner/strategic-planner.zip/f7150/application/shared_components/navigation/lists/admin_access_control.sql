prompt --application/shared_components/navigation/lists/admin_access_control
begin
--   Manifest
--     LIST: Admin - Access Control
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>2214566044257001599
,p_default_application_id=>9111
,p_default_id_offset=>11016538767572718
,p_default_owner=>'DBTOOLS_PROD'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(176220758985773840367)
,p_name=>'Admin - Access Control'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(176220692645987839661)
,p_version_scn=>45694116690961
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(176220759465369840367)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Users'
,p_list_item_link_target=>'f?p=&APP_ID.:10011:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-users'
,p_list_text_01=>'Access level for authenticated users of this application <br/>Currently &P10000_USER_COUNTS.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(176220759884419840368)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Access Control'
,p_list_item_link_target=>'f?p=&APP_ID.:10010:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-key'
,p_list_text_01=>'Change access control settings and disable access control'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
