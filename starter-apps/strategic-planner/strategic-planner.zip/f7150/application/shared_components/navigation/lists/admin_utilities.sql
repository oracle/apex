prompt --application/shared_components/navigation/lists/admin_utilities
begin
--   Manifest
--     LIST: Admin - Utilities
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(48252500624343512766)
,p_name=>'Admin - Utilities'
,p_static_id=>'admin-utilities'
,p_version_scn=>'45890284530493'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(48519776523915725606)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Manage Archived Projects'
,p_static_id=>'manage-archived-projects'
,p_list_item_link_target=>'f?p=&APP_ID.:11300:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-gear'
,p_list_text_01=>'All archived &NOMENCLATURE_PROJECTS., with the ability to permanently delete'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(50981942512597838230)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Manage Duplicate Projects'
,p_static_id=>'manage-duplicate-projects'
,p_list_item_link_target=>'f?p=&APP_ID.:11320:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-gear'
,p_list_text_01=>'All &NOMENCLATURE_PROJECTS. marked as duplicates, with the ability to permanently delete'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
