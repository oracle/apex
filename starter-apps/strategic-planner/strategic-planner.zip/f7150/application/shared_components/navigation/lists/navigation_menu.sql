prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(141179926616842434827)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(141180230739826435187)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(113821521283574539730)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'&NOMENCLATURE_AREAS. [&P1_AREAS.]'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-folder-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'17,9'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(113824433446295900639)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'&NOMENCLATURE_INITIATIVES. [&P1_INITIATIVES.]'
,p_list_item_link_target=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-lightbulb-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'21,66,94'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(113824561631437636726)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'&NOMENCLATURE_PROJECTS. [&P1_PROJECTS.]'
,p_list_item_link_target=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-package'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'3,23,300,113,64'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(16110979351751462940)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Activities [&P1_ACTIVITIES.]'
,p_list_item_link_target=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-badge-check'
,p_required_patch=>wwv_flow_imp.id(16140673370963474639)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'96,102,112'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(33756921335705936929)
,p_list_item_display_sequence=>77
,p_list_item_link_text=>'Releases [&P1_RELEASES.]'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-ship'
,p_required_patch=>wwv_flow_imp.id(6201759808817603711)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'63,77,38,81,76,8,117,200,201,202'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(141200154041486128396)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'&NOMENCLATURE_USERS. [&P1_PEOPLE.]'
,p_list_item_link_target=>'f?p=&APP_ID.:74:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-user'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'5,19,20,74'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10977920279780564215)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Groups [&P1_GROUPS.]'
,p_list_item_link_target=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-users'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'150,151,152,103'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(11973339663770583219)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Reports'
,p_list_item_link_target=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'41,14,46,31,78,7,55,45,51,610,86'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5543063086575312217)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>'Contributor Checklist'
,p_list_item_link_target=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-check'
,p_security_scheme=>wwv_flow_imp.id(141180225192465435141)
,p_required_patch=>wwv_flow_imp.id(3472559489660737107)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'40'
);
wwv_flow_imp.component_end;
end;
/
