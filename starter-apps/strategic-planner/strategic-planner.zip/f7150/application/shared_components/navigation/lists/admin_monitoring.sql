prompt --application/shared_components/navigation/lists/admin_monitoring
begin
--   Manifest
--     LIST: Admin - Monitoring
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>26954343551793662
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(10049958546893903989)
,p_name=>'Admin - Monitoring'
,p_list_status=>'PUBLIC'
,p_version_scn=>37167711502259
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5426393859792319624)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Page Views'
,p_list_item_link_target=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'Application page view details'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5426835531097755213)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Page Performance'
,p_list_item_link_target=>'f?p=&APP_ID.:71:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'Application page view details'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5438143865357384672)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Page Views by User'
,p_list_item_link_target=>'f?p=&APP_ID.:72:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'Application page view details'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15329919038168767382)
,p_list_item_display_sequence=>35
,p_list_item_link_text=>'Interactions by User'
,p_list_item_link_target=>'f?p=&APP_ID.:610:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-edit'
,p_list_text_01=>'Log of user interactions'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10049958749783903994)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Application Pages'
,p_list_item_link_target=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'Information about the pages and functionality of this application'
,p_required_patch=>wwv_flow_imp.id(11857425461918272267)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(25639914593851381333)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Email Reporting'
,p_list_item_link_target=>'f?p=&APP_ID.:16020:&SESSION.::&DEBUG.:16020:::'
,p_list_item_icon=>'fa-envelope-chart'
,p_list_text_01=>'Report of all email queued to be sent and those already sent'
,p_required_patch=>wwv_flow_imp.id(18721993490508994894)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24859615238030749538)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Job Reporting'
,p_list_item_link_target=>'f?p=&APP_ID.:16010:&SESSION.::&DEBUG.:16010:::'
,p_list_item_icon=>'fa-user-chart'
,p_list_text_01=>'View status and run details of jobs supporting this application'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
