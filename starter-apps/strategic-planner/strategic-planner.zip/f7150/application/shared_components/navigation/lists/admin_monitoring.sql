prompt --application/shared_components/navigation/lists/admin_monitoring
begin
--   Manifest
--     LIST: Admin - Monitoring
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(10023004203342110327)
,p_name=>'Admin - Monitoring'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5399439516240525962)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Page Views'
,p_list_item_link_target=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'Application page view details'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5399881187545961551)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Page Performance'
,p_list_item_link_target=>'f?p=&APP_ID.:71:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'Application page view details'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5411189521805591010)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Page Views by User'
,p_list_item_link_target=>'f?p=&APP_ID.:72:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'Application page view details'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(15302964694616973720)
,p_list_item_display_sequence=>35
,p_list_item_link_text=>'Interactions by User'
,p_list_item_link_target=>'f?p=&APP_ID.:610:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-edit'
,p_list_text_01=>'Log of user interactions'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(10023004406232110332)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Application Pages'
,p_list_item_link_target=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-o'
,p_list_text_01=>'Information about the pages and functionality of this application'
,p_required_patch=>wwv_flow_imp.id(11830471118366478605)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(25612960250299587671)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Email Reporting'
,p_list_item_link_target=>'f?p=&APP_ID.:16020:&SESSION.::&DEBUG.:16020:::'
,p_list_item_icon=>'fa-envelope-chart'
,p_list_text_01=>'Report of all email queued to be sent and those already sent'
,p_required_patch=>wwv_flow_imp.id(18695039146957201232)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(24832660894478955876)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Job Reporting'
,p_list_item_link_target=>'f?p=&APP_ID.:16010:&SESSION.::&DEBUG.:16010:::'
,p_list_item_icon=>'fa-user-chart'
,p_list_text_01=>'View status and run details of jobs supporting this application'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
