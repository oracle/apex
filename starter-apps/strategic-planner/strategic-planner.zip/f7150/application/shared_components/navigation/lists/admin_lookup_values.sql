prompt --application/shared_components/navigation/lists/admin_lookup_values
begin
--   Manifest
--     LIST: Admin - Lookup Values
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(40581912441924943520)
,p_name=>'Admin - Lookup Values'
,p_static_id=>'admin-lookup-values'
,p_version_scn=>'45890286576339'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(40581913422174943527)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Activity Types'
,p_static_id=>'activity-types'
,p_list_item_link_target=>'f?p=&APP_ID.:10700:&SESSION.::&DEBUG.:RP,10700:::'
,p_list_item_icon=>'fa-address-card-o'
,p_list_text_01=>'Used to further describe logged activities'
,p_list_text_02=>'&P10000_ACTIVITY_TYPES.'
,p_required_patch=>wwv_flow_imp.id(51181142606315879163)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(40581913024220943527)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Contributor Roles'
,p_static_id=>'contributor-roles'
,p_list_item_link_target=>'f?p=&APP_ID.:10600:&SESSION.::&DEBUG.:RP,10600:::'
,p_list_item_icon=>'fa-address-card-o'
,p_list_text_01=>'How a person can be associated with a &NOMENCLATURE_PROJECT.'
,p_list_text_02=>'&P10000_RESOURCE_TYPES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(62375662855919243091)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Countries'
,p_static_id=>'countries'
,p_list_item_link_target=>'f?p=&APP_ID.:43:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-globe'
,p_list_text_01=>'Configure default quick picks for tags'
,p_list_text_02=>'&P10000_COUNTRIES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(47933810261105336187)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Default Competencies'
,p_static_id=>'default-competencies'
,p_list_item_link_target=>'f?p=&APP_ID.:154:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-users-alt'
,p_list_text_01=>'Associated with people and displayed under their profile'
,p_list_text_02=>'&P10000_COMPETENCIES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(40320563069774210799)
,p_list_item_display_sequence=>115
,p_list_item_link_text=>'&NOMENCLATURE_INITIATIVE. Focus Areas'
,p_static_id=>'nomenclature-initiative-focus-areas'
,p_list_item_link_target=>'f?p=&APP_ID.:10150:&SESSION.::&DEBUG.:RP,10150:::'
,p_list_item_icon=>'fa-user-magnifying-glass'
,p_list_text_01=>'Focus Areas that can be associated with &NOMENCLATURE_PROJECTS. (selection is limited by &NOMENCLATURE_INITIATIVE.)'
,p_list_text_02=>'&P10000_FOCUS_AREAS.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(40581912648792943524)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'&NOMENCLATURE_PROJECT. Completeness Scales'
,p_static_id=>'nomenclature-project-completeness-scales'
,p_list_item_link_target=>'f?p=&APP_ID.:10200:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-badge-check'
,p_list_text_01=>'Details of available completeness scales (from 0% to 100% in 10% increments) used for &NOMENCLATURE_PROJECTS.'
,p_list_text_02=>'&P10000_PROJECT_STATUS_SCALES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(61572165415844994821)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'&NOMENCLATURE_PROJECT. Default Tags'
,p_static_id=>'nomenclature-project-default-tags'
,p_list_item_link_target=>'f?p=&APP_ID.:10500:&SESSION.::&DEBUG.:RP,10500:::'
,p_list_item_icon=>'fa-tag'
,p_list_text_01=>'Configure default quick picks for tags'
,p_list_text_02=>'&P10000_DEFAULT_TAGS.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(40581913802380943528)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'&NOMENCLATURE_PROJECT. Priorities'
,p_static_id=>'nomenclature-project-priorities'
,p_list_item_link_target=>'f?p=&APP_ID.:10800:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-arrows-v'
,p_list_text_01=>'Available &NOMENCLATURE_PROJECT. priorities'
,p_list_text_02=>'&P10000_PROJECT_PRIORITIES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(40581915054900943529)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'&NOMENCLATURE_PROJECT. Sizes'
,p_static_id=>'nomenclature-project-sizes'
,p_list_item_link_target=>'f?p=&APP_ID.:10100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-users-alt'
,p_list_text_01=>'Sizes for &NOMENCLATURE_PROJECTS. with associated level of effort'
,p_list_text_02=>'&P10000_PROJECT_SIZES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(53086952947989199885)
,p_list_item_display_sequence=>75
,p_list_item_link_text=>'&NOMENCLATURE_PROJECT. Statuses'
,p_static_id=>'nomenclature-project-statuses'
,p_list_item_link_target=>'f?p=&APP_ID.:10110:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-wizard'
,p_list_text_01=>'Available statuses for &NOMENCLATURE_PROJECTS., used when active (as defined by selected completeness scale) and not 100% complete'
,p_list_text_02=>'&P10000_PROJECT_STATUSES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(31284633732717624394)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Release Milestone Default Tags'
,p_static_id=>'release-milestone-default-tags'
,p_list_item_link_target=>'f?p=&APP_ID.:10515:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tag'
,p_list_text_01=>'Configure quick picks for release milestone tags'
,p_list_text_02=>'&P10000_RM_DEFAULT_TAGS.'
,p_required_patch=>wwv_flow_imp.id(41242229044170008235)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(43085701084062241238)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Release Milestone Types'
,p_static_id=>'release-milestone-types'
,p_list_item_link_target=>'f?p=&APP_ID.:10090:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-clipboard-check-alt'
,p_list_text_01=>'Used to describe Release Milestones'
,p_list_text_02=>'&P10000_REL_MILESTONE_TYPES.'
,p_required_patch=>wwv_flow_imp.id(41242229044170008235)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(55234247915259430928)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Task Statuses'
,p_static_id=>'task-statuses'
,p_list_item_link_target=>'f?p=&APP_ID.:10061:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-wizard'
,p_list_text_01=>'Available statuses for tasks'
,p_list_text_02=>'&P10000_TASK_STATUSES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(55233958576028411303)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Task Types'
,p_static_id=>'task-types'
,p_list_item_link_target=>'f?p=&APP_ID.:10064:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-clipboard-list'
,p_list_text_01=>'Available &NOMENCLATURE_PROJECT. task types'
,p_list_text_02=>'&P10000_TASK_TYPES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(55633013704193511793)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Team Member Default Tags'
,p_static_id=>'team-member-default-tags'
,p_list_item_link_target=>'f?p=&APP_ID.:10520:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-tag'
,p_list_text_01=>'Configure default quick picks for tags'
,p_list_text_02=>'&P10000_TEAM_MBR_DEFAULT_TAGS.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
