prompt --application/shared_components/navigation/lists/admin_lookup_values
begin
--   Manifest
--     LIST: Admin - Lookup Values
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>19055477148803894
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(5595841747974276895)
,p_name=>'Admin - Lookup Values'
,p_list_status=>'PUBLIC'
,p_version_scn=>37167711502259
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5595842728224276902)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Activity Types'
,p_list_item_link_target=>'f?p=&APP_ID.:10700:&SESSION.::&DEBUG.:RP,10700:::'
,p_list_item_icon=>'fa-address-card-o'
,p_list_text_01=>'Used to further describe logged activities'
,p_list_text_02=>'&P10000_ACTIVITY_TYPES.'
,p_required_patch=>wwv_flow_imp.id(16195071912365212538)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(12947739567154669562)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Default Competencies'
,p_list_item_link_target=>'f?p=&APP_ID.:154:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-users-alt'
,p_list_text_01=>'Associated with people and displayed under their profile'
,p_list_text_02=>'&P10000_COMPETENCIES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5595842330270276902)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Contributor Roles'
,p_list_item_link_target=>'f?p=&APP_ID.:10600:&SESSION.::&DEBUG.:RP,10600:::'
,p_list_item_icon=>'fa-address-card-o'
,p_list_text_01=>'How a person can be associated with a &NOMENCLATURE_PROJECT.'
,p_list_text_02=>'&P10000_RESOURCE_TYPES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(20646943010242845168)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Team Member Default Tags'
,p_list_item_link_target=>'f?p=&APP_ID.:10520:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-tag'
,p_list_text_01=>'Configure default quick picks for tags'
,p_list_text_02=>'&P10000_TEAM_MBR_DEFAULT_TAGS.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(27389592161968576466)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Countries'
,p_list_item_link_target=>'f?p=&APP_ID.:43:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-globe'
,p_list_text_01=>'Configure default quick picks for tags'
,p_list_text_02=>'&P10000_COUNTRIES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5595841954842276899)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'&NOMENCLATURE_PROJECT. Percent Complete and Milestone Scales'
,p_list_item_link_target=>'f?p=&APP_ID.:10200:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-badge-check'
,p_list_text_01=>'Details of available completeness scales (from 0% to 100% in 10% increments) and milestones used for &NOMENCLATURE_PROJECTS.'
,p_list_text_02=>'&P10000_PROJECT_STATUS_SCALES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5595843108430276903)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'&NOMENCLATURE_PROJECT. Priorities'
,p_list_item_link_target=>'f?p=&APP_ID.:10800:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-arrows-v'
,p_list_text_01=>'Available &NOMENCLATURE_PROJECT. priorities'
,p_list_text_02=>'&P10000_PROJECT_PRIORITIES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5595844360950276904)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'&NOMENCLATURE_PROJECT. Sizes'
,p_list_item_link_target=>'f?p=&APP_ID.:10100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-users-alt'
,p_list_text_01=>'Sizes for &NOMENCLATURE_PROJECTS. with associated level of effort'
,p_list_text_02=>'&P10000_PROJECT_SIZES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5595843575801276904)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Review Types'
,p_list_item_link_target=>'f?p=&APP_ID.:10063:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-external-link-square'
,p_list_text_01=>'Available &NOMENCLATURE_PROJECT. review types'
,p_list_text_02=>'&P10000_PROJECT_REVIEW_TYPES.'
,p_required_patch=>wwv_flow_imp.id(12000845173576836866)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(26586094721894328196)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'&NOMENCLATURE_PROJECT. Default Tags'
,p_list_item_link_target=>'f?p=&APP_ID.:10500:&SESSION.::&DEBUG.:RP,10500:::'
,p_list_item_icon=>'fa-tag'
,p_list_text_01=>'Configure default quick picks for tags'
,p_list_text_02=>'&P10000_DEFAULT_TAGS.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
