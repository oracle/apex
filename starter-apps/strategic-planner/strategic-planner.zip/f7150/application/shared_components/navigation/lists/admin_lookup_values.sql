prompt --application/shared_components/navigation/lists/admin_lookup_values
begin
--   Manifest
--     LIST: Admin - Lookup Values
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(5541443206572538996)
,p_name=>'Admin - Lookup Values'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5541444186822539003)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Activity Types'
,p_list_item_link_target=>'f?p=&APP_ID.:10700:&SESSION.::&DEBUG.:RP,10700:::'
,p_list_item_icon=>'fa-address-card-o'
,p_list_text_01=>'Used to further describe logged activities'
,p_list_text_02=>'&P10000_ACTIVITY_TYPES.'
,p_required_patch=>wwv_flow_imp.id(16140673370963474639)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(12893341025752931663)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Default Competencies'
,p_list_item_link_target=>'f?p=&APP_ID.:154:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-users-alt'
,p_list_text_01=>'Associated with people and displayed under their profile'
,p_list_text_02=>'&P10000_COMPETENCIES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5541443788868539003)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Contributor Roles'
,p_list_item_link_target=>'f?p=&APP_ID.:10600:&SESSION.::&DEBUG.:RP,10600:::'
,p_list_item_icon=>'fa-address-card-o'
,p_list_text_01=>'How a person can be associated with a &NOMENCLATURE_PROJECT.'
,p_list_text_02=>'&P10000_RESOURCE_TYPES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(20592544468841107269)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Team Member Default Tags'
,p_list_item_link_target=>'f?p=&APP_ID.:10520:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-tag'
,p_list_text_01=>'Configure default quick picks for tags'
,p_list_text_02=>'&P10000_TEAM_MBR_DEFAULT_TAGS.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(27335193620566838567)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Countries'
,p_list_item_link_target=>'f?p=&APP_ID.:43:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-globe'
,p_list_text_01=>'Configure default quick picks for tags'
,p_list_text_02=>'&P10000_COUNTRIES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5541443413440539000)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'&NOMENCLATURE_PROJECT. Percent Complete and Milestone Scales'
,p_list_item_link_target=>'f?p=&APP_ID.:10200:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-badge-check'
,p_list_text_01=>'Details of available completeness scales (from 0% to 100% in 10% increments) and milestones used for &NOMENCLATURE_PROJECTS.'
,p_list_text_02=>'&P10000_PROJECT_STATUS_SCALES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5541444567028539004)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'&NOMENCLATURE_PROJECT. Priorities'
,p_list_item_link_target=>'f?p=&APP_ID.:10800:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-arrows-v'
,p_list_text_01=>'Available &NOMENCLATURE_PROJECT. priorities'
,p_list_text_02=>'&P10000_PROJECT_PRIORITIES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5541445819548539005)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'&NOMENCLATURE_PROJECT. Sizes'
,p_list_item_link_target=>'f?p=&APP_ID.:10100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-users-alt'
,p_list_text_01=>'Sizes for &NOMENCLATURE_PROJECTS. with associated level of effort'
,p_list_text_02=>'&P10000_PROJECT_SIZES.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(5541445034399539005)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Review Types'
,p_list_item_link_target=>'f?p=&APP_ID.:10063:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-external-link-square'
,p_list_text_01=>'Available &NOMENCLATURE_PROJECT. review types'
,p_list_text_02=>'&P10000_PROJECT_REVIEW_TYPES.'
,p_required_patch=>wwv_flow_imp.id(11946446632175098967)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(26531696180492590297)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'&NOMENCLATURE_PROJECT. Default Tags'
,p_list_item_link_target=>'f?p=&APP_ID.:10500:&SESSION.::&DEBUG.:RP,10500:::'
,p_list_item_icon=>'fa-tag'
,p_list_text_01=>'Configure default quick picks for tags'
,p_list_text_02=>'&P10000_DEFAULT_TAGS.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
