prompt --application/shared_components/workflow/workflows/project_review
begin
--   Manifest
--     WORKFLOW: Project Review
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>2214566044257001599
,p_default_application_id=>9111
,p_default_id_offset=>11016538767572718
,p_default_owner=>'DBTOOLS_PROD'
);
wwv_flow_imp_shared.create_workflow(
 p_id=>wwv_flow_imp.id(42764446875598090677)
,p_name=>'Project Review'
,p_static_id=>'PROJECT-REVIEW'
,p_title=>'&P_APPROVAL_TYPE. Review for &P_NOMENCLATURE_PROJECT. "&P_PROJECT_NAME."'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(17883469194758620743)
,p_workflow_id=>wwv_flow_imp.id(42764446875598090677)
,p_label=>'P_SUBMITTER_TM_ID'
,p_static_id=>'P_SUBMITTER_TM_ID'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_is_required=>true
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(45693375124289923255)
,p_workflow_id=>wwv_flow_imp.id(42764446875598090677)
,p_label=>'P_PROJECT_ID'
,p_static_id=>'P_PROJECT_ID'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_is_required=>true
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(45693376925551923273)
,p_workflow_id=>wwv_flow_imp.id(42764446875598090677)
,p_label=>'P_NOMENCLATURE_PROJECT'
,p_static_id=>'P_NOMENCLATURE_PROJECT'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(45693377270320923276)
,p_workflow_id=>wwv_flow_imp.id(42764446875598090677)
,p_label=>'P_PROJECT_LINK'
,p_static_id=>'P_PROJECT_LINK'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(45693378256128923286)
,p_workflow_id=>wwv_flow_imp.id(42764446875598090677)
,p_label=>'P_PROJECT_NAME'
,p_static_id=>'P_PROJECT_NAME'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(46402947935770636851)
,p_workflow_id=>wwv_flow_imp.id(42764446875598090677)
,p_label=>'P_APP_NAME'
,p_static_id=>'P_APP_NAME'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(46402949494585636867)
,p_workflow_id=>wwv_flow_imp.id(42764446875598090677)
,p_label=>'P_APPROVAL_TYPE'
,p_static_id=>'P_APPROVAL_TYPE'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(47426608996919148057)
,p_workflow_id=>wwv_flow_imp.id(42764446875598090677)
,p_label=>'P_PROJECT_APPROVAL_ID'
,p_static_id=>'P_PROJECT_APPROVAL_ID'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_is_required=>true
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(48137803187228463152)
,p_workflow_id=>wwv_flow_imp.id(42764446875598090677)
,p_label=>'P_APP_ID'
,p_static_id=>'P_APP_ID'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_is_required=>true
);
wwv_flow_imp_shared.create_workflow_version(
 p_id=>wwv_flow_imp.id(17883469288528620744)
,p_workflow_id=>wwv_flow_imp.id(42764446875598090677)
,p_version=>'1.2'
,p_state=>'ACTIVE'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(18395661763812796437)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_label=>'Approver'
,p_static_id=>'APPROVER'
,p_direction=>'VARIABLE'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(18395661893304796438)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_label=>'TaskOutcome'
,p_static_id=>'TASK_OUTCOME'
,p_direction=>'VARIABLE'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(18395661909831796439)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_label=>'V_APPROVAL_STATUS'
,p_static_id=>'V_APPROVAL_STATUS'
,p_direction=>'VARIABLE'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(18395662060362796440)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_label=>'V_EMAIL_BODY'
,p_static_id=>'V_EMAIL_BODY'
,p_direction=>'VARIABLE'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(18395662119236796441)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_label=>'V_EMAIL_SUBJECT'
,p_static_id=>'V_EMAIL_SUBJECT'
,p_direction=>'VARIABLE'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(18395662251760796442)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_label=>'V_PROJECT_APPROVAL_CHAIN_ID'
,p_static_id=>'V_PROJECT_APPROVAL_CHAIN_ID'
,p_direction=>'VARIABLE'
,p_data_type=>'NUMBER'
,p_is_required=>false
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(18395662384528796443)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_label=>'V_REVIEWER_EMAIL'
,p_static_id=>'V_REVIEWER_EMAIL'
,p_direction=>'VARIABLE'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(18395662414980796444)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_label=>'V_REVIEWER_TM_ID'
,p_static_id=>'V_REVIEWER_TM_ID'
,p_direction=>'VARIABLE'
,p_data_type=>'NUMBER'
,p_is_required=>false
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(18395662787685796447)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_label=>'V_WORKFLOW_TASK_ID'
,p_static_id=>'V_WORKFLOW_TASK_ID'
,p_direction=>'VARIABLE'
,p_data_type=>'NUMBER'
,p_is_required=>false
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(17883469386498620745)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_name=>'Start'
,p_static_id=>'New'
,p_display_sequence=>10
,p_activity_type=>'NATIVE_WORKFLOW_START'
,p_diagram=>'{"position":{"x":70,"y":850},"z":1}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(17883469536366620747)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_name=>'Identify Next Reviewer'
,p_static_id=>'identify-next-reviewer'
,p_display_sequence=>20
,p_activity_type=>'NATIVE_INVOKE_API'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'SP_APPROVALS'
,p_attribute_04=>'IDENTIFY_NEXT_REVIEWER'
,p_diagram=>'{"position":{"x":250,"y":850},"z":2}'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(17883469711605620749)
,p_workflow_activity_id=>wwv_flow_imp.id(17883469536366620747)
,p_name=>'p_project_approval_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P_PROJECT_APPROVAL_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(17883469830261620750)
,p_workflow_activity_id=>wwv_flow_imp.id(17883469536366620747)
,p_name=>'p_project_approval_chain_id'
,p_direction=>'OUT'
,p_data_type=>'NUMBER'
,p_ignore_output=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'V_PROJECT_APPROVAL_CHAIN_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(18395658114407796401)
,p_workflow_activity_id=>wwv_flow_imp.id(17883469536366620747)
,p_name=>'p_reviewer_email'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'V_REVIEWER_EMAIL'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(18395658201902796402)
,p_workflow_activity_id=>wwv_flow_imp.id(17883469536366620747)
,p_name=>'p_reviewer_tm_id'
,p_direction=>'OUT'
,p_data_type=>'NUMBER'
,p_ignore_output=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'V_REVIEWER_TM_ID'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(18395658399551796403)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_name=>'Is there another Review?'
,p_static_id=>'another-review'
,p_display_sequence=>30
,p_activity_type=>'NATIVE_WORKFLOW_SWITCH'
,p_attribute_01=>'TRUE_FALSE_CHECK'
,p_attribute_03=>'ROWS_RETURNED'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 ',
'  from sp_project_approval_chain',
' where project_approval_id = :P_PROJECT_APPROVAL_ID',
'   and status = ''PENDING'''))
,p_diagram=>'{"position":{"x":250,"y":980},"z":3}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(18395658662930796406)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_name=>'Grab data for Reviewer Notif'
,p_static_id=>'grab-data-for-review-notif'
,p_display_sequence=>40
,p_activity_type=>'NATIVE_PLSQL'
,p_activity_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
':V_EMAIL_SUBJECT := ''Workflow Approval Request, ''||:P_APPROVAL_TYPE||'' review needed for ''||:P_NOMENCLATURE_PROJECT||'' ''||:P_PROJECT_NAME;',
'',
'for c1 in (',
'    select justification',
'      from sp_project_approvals',
'     where id = :P_PROJECT_APPROVAL_ID',
') loop',
'    :V_EMAIL_BODY := ''<strong>Workflow pending your approval</strong><br/><br/>''||:P_NOMENCLATURE_PROJECT||'' ''||:P_PROJECT_NAME||'' requires your review for ''||:P_APPROVAL_TYPE||''.<br/>''||',
'                     ''Justification: ''|| substr(c1.justification,1,3000);',
'end loop;'))
,p_activity_code_language=>'PLSQL'
,p_location=>'LOCAL'
,p_diagram=>'{"position":{"x":570,"y":980},"z":4}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(18395658821820796408)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_name=>'Request Review'
,p_static_id=>'request-review'
,p_display_sequence=>50
,p_activity_type=>'NATIVE_CREATE_TASK'
,p_attribute_01=>wwv_flow_imp.id(44926458293680136208)
,p_attribute_04=>'V_WORKFLOW_TASK_ID'
,p_attribute_05=>'V_PROJECT_APPROVAL_CHAIN_ID'
,p_attribute_08=>'V_APPROVAL_STATUS'
,p_diagram=>'{"position":{"x":850,"y":980},"z":5}'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(18395659079258796410)
,p_workflow_activity_id=>wwv_flow_imp.id(18395658821820796408)
,p_task_def_param_id=>wwv_flow_imp.id(48267584489946918661)
,p_value_type=>'ITEM'
,p_value=>'P_APP_ID'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(18395659121728796411)
,p_workflow_activity_id=>wwv_flow_imp.id(18395658821820796408)
,p_task_def_param_id=>wwv_flow_imp.id(46407522716358021606)
,p_value_type=>'ITEM'
,p_value=>'P_APP_NAME'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(18395659203614796412)
,p_workflow_activity_id=>wwv_flow_imp.id(18395658821820796408)
,p_task_def_param_id=>wwv_flow_imp.id(48153475817924317186)
,p_value_type=>'ITEM'
,p_value=>'P_APPROVAL_TYPE'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(18395659314795796413)
,p_workflow_activity_id=>wwv_flow_imp.id(18395658821820796408)
,p_task_def_param_id=>wwv_flow_imp.id(46405627601805877703)
,p_value_type=>'ITEM'
,p_value=>'V_EMAIL_BODY'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(18395659423965796414)
,p_workflow_activity_id=>wwv_flow_imp.id(18395658821820796408)
,p_task_def_param_id=>wwv_flow_imp.id(46405627218049877703)
,p_value_type=>'ITEM'
,p_value=>'V_EMAIL_SUBJECT'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(18395659535247796415)
,p_workflow_activity_id=>wwv_flow_imp.id(18395658821820796408)
,p_task_def_param_id=>wwv_flow_imp.id(48153475445721317185)
,p_value_type=>'ITEM'
,p_value=>'P_NOMENCLATURE_PROJECT'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(18395659632076796416)
,p_workflow_activity_id=>wwv_flow_imp.id(18395658821820796408)
,p_task_def_param_id=>wwv_flow_imp.id(46257842127691966557)
,p_value_type=>'ITEM'
,p_value=>'V_PROJECT_APPROVAL_CHAIN_ID'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(18395659765465796417)
,p_workflow_activity_id=>wwv_flow_imp.id(18395658821820796408)
,p_task_def_param_id=>wwv_flow_imp.id(48267584846626918663)
,p_value_type=>'ITEM'
,p_value=>'P_PROJECT_ID'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(18395659894257796418)
,p_workflow_activity_id=>wwv_flow_imp.id(18395658821820796408)
,p_task_def_param_id=>wwv_flow_imp.id(46405626441338877702)
,p_value_type=>'ITEM'
,p_value=>'P_PROJECT_LINK'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(18395659967087796419)
,p_workflow_activity_id=>wwv_flow_imp.id(18395658821820796408)
,p_task_def_param_id=>wwv_flow_imp.id(46405626180934877702)
,p_value_type=>'ITEM'
,p_value=>'P_PROJECT_NAME'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(18395660038098796420)
,p_workflow_activity_id=>wwv_flow_imp.id(18395658821820796408)
,p_task_def_param_id=>wwv_flow_imp.id(46148253018079989533)
,p_value_type=>'ITEM'
,p_value=>'V_REVIEWER_EMAIL'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(18395660122210796421)
,p_workflow_activity_id=>wwv_flow_imp.id(18395658821820796408)
,p_task_def_param_id=>wwv_flow_imp.id(46252370418585667315)
,p_value_type=>'ITEM'
,p_value=>'V_REVIEWER_TM_ID'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(18395660290108796422)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_name=>'Approve?'
,p_static_id=>'New_3'
,p_display_sequence=>60
,p_activity_type=>'NATIVE_WORKFLOW_SWITCH'
,p_attribute_01=>'CHECK_WF_VARIABLE'
,p_attribute_10=>'V_APPROVAL_STATUS'
,p_diagram=>'{"position":{"x":1140,"y":970},"z":6}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(18395660572785796425)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_name=>'Approve Request'
,p_static_id=>'approve-review'
,p_display_sequence=>70
,p_activity_type=>'NATIVE_INVOKE_API'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'SP_APPROVALS'
,p_attribute_04=>'APPROVE_REQUEST'
,p_diagram=>'{"position":{"x":250,"y":1130},"z":7}'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(18395660734130796427)
,p_workflow_activity_id=>wwv_flow_imp.id(18395660572785796425)
,p_name=>'p_project_approval_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P_PROJECT_APPROVAL_ID'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(18395660883483796428)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_name=>'Grab data for Approval Notif'
,p_static_id=>'grab-data-for-approval'
,p_display_sequence=>80
,p_activity_type=>'NATIVE_PLSQL'
,p_activity_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
':V_EMAIL_SUBJECT := :P_NOMENCLATURE_PROJECT||'' ''||:P_PROJECT_NAME||'' Approved for ''||:P_APPROVAL_TYPE;',
'',
':V_EMAIL_BODY := :P_NOMENCLATURE_PROJECT||'' ''||:P_PROJECT_NAME||'' was just approved for ''||:P_APPROVAL_TYPE;'))
,p_activity_code_language=>'PLSQL'
,p_location=>'LOCAL'
,p_diagram=>'{"position":{"x":250,"y":1250},"z":8}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(18395661094936796430)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_name=>'Notify Approval to Submitter (and project owner)'
,p_static_id=>'approval-notif'
,p_display_sequence=>90
,p_activity_type=>'NATIVE_PLSQL'
,p_activity_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_util.assignment_notification (',
'    p_team_member_id    => :P_SUBMITTER_TM_ID,',
'    p_app_name          => :P_APP_NAME,',
'    p_app_id            => :P_APP_ID,',
'    p_project_id        => :P_PROJECT_ID,',
'    p_link              => :P_PROJECT_LINK,',
'    p_view_what         => :P_NOMENCLATURE_PROJECT,',
'    p_title             => :V_EMAIL_SUBJECT,',
'    p_email_contents    => :V_EMAIL_BODY,',
'    p_notification_type => ''APPROVAL'' );',
'',
'for c1 in (',
'    select owner_id',
'      from sp_projects',
'     where id = :P_PROJECT_ID',
'       and owner_id is not null',
') loop',
'    if c1.owner_id != :P_SUBMITTER_TM_ID then',
'        sp_util.assignment_notification (',
'            p_team_member_id    => c1.owner_id,',
'            p_app_name          => :P_APP_NAME,',
'            p_app_id            => :P_APP_ID,',
'            p_project_id        => :P_PROJECT_ID,',
'            p_link              => :P_PROJECT_LINK,',
'            p_view_what         => :P_NOMENCLATURE_PROJECT,',
'            p_title             => :V_EMAIL_SUBJECT,',
'            p_email_contents    => :V_EMAIL_BODY,',
'            p_notification_type => ''APPROVAL'' );',
'    end if;',
'end loop;'))
,p_activity_code_language=>'PLSQL'
,p_location=>'LOCAL'
,p_diagram=>'{"position":{"x":250,"y":1370},"z":9}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(18395661211625796432)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_name=>'Grab data for Rejection Notif'
,p_static_id=>'grab-data-for-rejection'
,p_display_sequence=>100
,p_activity_type=>'NATIVE_PLSQL'
,p_activity_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
':V_EMAIL_SUBJECT := :P_NOMENCLATURE_PROJECT||'' ''||:P_PROJECT_NAME||'' Rejected for ''||:P_APPROVAL_TYPE;',
'',
'for c1 in (',
'    select comments',
'      from sp_project_approval_chain',
'     where project_approval_id = :P_PROJECT_APPROVAL_ID',
'       and status = ''REJECTED''',
'       and final_yn = ''Y''',
') loop',
'    :V_EMAIL_BODY := :P_NOMENCLATURE_PROJECT||'' ''||:P_PROJECT_NAME||'' was just rejected for ''||:P_APPROVAL_TYPE||''.<br/>''||',
'                      ''Comments: ''|| c1.comments;',
'end loop;'))
,p_activity_code_language=>'PLSQL'
,p_location=>'LOCAL'
,p_diagram=>'{"position":{"x":1130,"y":1110},"z":10}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(18395661475789796434)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_name=>'Notify about Rejection'
,p_static_id=>'rejection-notif'
,p_display_sequence=>110
,p_activity_type=>'NATIVE_PLSQL'
,p_activity_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_util.assignment_notification (',
'    p_team_member_id    => :P_SUBMITTER_TM_ID,',
'    p_app_name          => :P_APP_NAME,',
'    p_app_id            => :P_APP_ID,',
'    p_project_id        => :P_PROJECT_ID,',
'    p_link              => :P_PROJECT_LINK,',
'    p_view_what         => :P_NOMENCLATURE_PROJECT,',
'    p_title             => :V_EMAIL_SUBJECT,',
'    p_email_contents    => :V_EMAIL_BODY,',
'    p_notification_type => ''APPROVAL'' );'))
,p_activity_code_language=>'PLSQL'
,p_location=>'LOCAL'
,p_diagram=>'{"position":{"x":1140,"y":1240},"z":11}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(18395661676980796436)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_name=>'End'
,p_static_id=>'New_2'
,p_display_sequence=>120
,p_activity_type=>'NATIVE_WORKFLOW_END'
,p_attribute_01=>'COMPLETED'
,p_diagram=>'{"position":{"x":1210,"y":1370},"z":12}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(17883469499769620746)
,p_name=>'Submit Request'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(17883469386498620745)
,p_to_activity_id=>wwv_flow_imp.id(17883469536366620747)
,p_diagram=>'{"source":{"name":"topLeft","args":{"dx":"66.667%","dy":"50%","rotate":true}},"target":{},"vertices":[],"z":13,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(17883469695960620748)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(17883469536366620747)
,p_to_activity_id=>wwv_flow_imp.id(18395658399551796403)
,p_diagram=>'{"source":{},"target":{},"vertices":[],"z":14,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(18395658482728796404)
,p_name=>'another review'
,p_transition_type=>'BRANCH'
,p_from_activity_id=>wwv_flow_imp.id(18395658399551796403)
,p_to_activity_id=>wwv_flow_imp.id(18395658662930796406)
,p_condition_expr1=>'TRUE'
,p_diagram=>'{"source":{},"target":{},"vertices":[],"z":22,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(18395658593753796405)
,p_name=>'no more reviews'
,p_transition_type=>'BRANCH'
,p_from_activity_id=>wwv_flow_imp.id(18395658399551796403)
,p_to_activity_id=>wwv_flow_imp.id(18395660572785796425)
,p_condition_expr1=>'FALSE'
,p_diagram=>'{"source":{"name":"bottom","args":{"dx":0,"dy":-10}},"target":{"name":"topLeft","args":{"dx":"50%","dy":"50%","rotate":true}},"vertices":[],"z":23,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(18395658732207796407)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(18395658662930796406)
,p_to_activity_id=>wwv_flow_imp.id(18395658821820796408)
,p_diagram=>'{"source":{},"target":{},"vertices":[],"z":15,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(18395658957422796409)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(18395658821820796408)
,p_to_activity_id=>wwv_flow_imp.id(18395660290108796422)
,p_diagram=>'{"source":{},"target":{"name":"topLeft","args":{"dx":"50.003%","dy":"66.66%","rotate":true}},"vertices":[],"z":16,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(18395660365819796423)
,p_name=>'Rejected'
,p_transition_type=>'BRANCH'
,p_from_activity_id=>wwv_flow_imp.id(18395660290108796422)
,p_to_activity_id=>wwv_flow_imp.id(18395661211625796432)
,p_condition_type=>'EQUALS'
,p_condition_expr1=>'REJECTED'
,p_diagram=>'{"source":{"name":"bottom","args":{"dx":0,"dy":-10}},"target":{},"vertices":[],"z":24,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(18395660476925796424)
,p_name=>'Approved'
,p_transition_type=>'BRANCH'
,p_from_activity_id=>wwv_flow_imp.id(18395660290108796422)
,p_to_activity_id=>wwv_flow_imp.id(17883469536366620747)
,p_condition_type=>'EQUALS'
,p_condition_expr1=>'APPROVED'
,p_diagram=>'{"source":{"name":"topLeft","args":{"dx":"50.003%","dy":"0.019%","rotate":true}},"target":{"name":"topLeft","args":{"dx":"100%","dy":"33.333%","rotate":true}},"vertices":[{"x":1250,"y":870},{"x":530,"y":870}],"z":25,"label":{"distance":0.5,"offset":0'
||'}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(18395660619882796426)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(18395660572785796425)
,p_to_activity_id=>wwv_flow_imp.id(18395660883483796428)
,p_diagram=>'{"source":{"name":"topLeft","args":{"dx":"50%","dy":"83.333%","rotate":true}},"target":{},"vertices":[],"z":17,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(18395660989800796429)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(18395660883483796428)
,p_to_activity_id=>wwv_flow_imp.id(18395661094936796430)
,p_diagram=>'{"source":{"name":"bottom","args":{"dx":0,"dy":-10}},"target":{"name":"topLeft","args":{"dx":"50%","dy":"50%","rotate":true}},"vertices":[],"z":18,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(18395661135366796431)
,p_name=>'Send Approval'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(18395661094936796430)
,p_to_activity_id=>wwv_flow_imp.id(18395661676980796436)
,p_diagram=>'{"source":{},"target":{"name":"topLeft","args":{"dx":"16.667%","dy":"66.667%","rotate":true}},"vertices":[],"z":19,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(18395661366625796433)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(18395661211625796432)
,p_to_activity_id=>wwv_flow_imp.id(18395661475789796434)
,p_diagram=>'{"source":{},"target":{},"vertices":[],"z":20,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(18395661557325796435)
,p_name=>'Send Rejection Email'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(18395661475789796434)
,p_to_activity_id=>wwv_flow_imp.id(18395661676980796436)
,p_diagram=>'{"source":{},"target":{"name":"topLeft","args":{"dx":"66.667%","dy":"50%","rotate":true}},"vertices":[],"z":21,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_participant(
 p_id=>wwv_flow_imp.id(18395662883137796448)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_participant_type=>'ADMIN'
,p_name=>'admin query'
,p_identity_type=>'USER'
,p_value_type=>'SQL_QUERY'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select user_name_lc',
'  from APEX_APPL_ACL_USERS',
' where APPLICATION_ID = :APP_ID',
'   and role_names = ''Administrator'''))
);
wwv_flow_imp_shared.create_workflow_participant(
 p_id=>wwv_flow_imp.id(18395662907559796449)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_participant_type=>'OWNER'
,p_name=>'owner'
,p_identity_type=>'USER'
,p_value_type=>'STATIC'
,p_value=>'SHARON.KENNEDY@ORACLE.COM'
);
wwv_flow_imp_shared.create_workflow_participant(
 p_id=>wwv_flow_imp.id(20633257290748370010)
,p_workflow_version_id=>wwv_flow_imp.id(17883469288528620744)
,p_participant_type=>'ADMIN'
,p_name=>'admin query upper'
,p_identity_type=>'USER'
,p_value_type=>'SQL_QUERY'
,p_value=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select upper(user_name_lc)',
'  from APEX_APPL_ACL_USERS',
' where APPLICATION_ID = :APP_ID',
'   and role_names = ''Administrator'''))
);
wwv_flow_imp.component_end;
end;
/
