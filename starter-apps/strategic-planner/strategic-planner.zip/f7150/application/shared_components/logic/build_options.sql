prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 7150
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(3480948210361877450)
,p_build_option_name=>'Contributor Checklist'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>41300185620820
,p_build_option_comment=>'This feature provides a configurable list of actions visible to contributors of this application.  It outlines what is expected of each contributor.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(3996135302388557550)
,p_build_option_name=>'About Page'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>40760826019912
,p_feature_identifier=>'APPLICATION_ABOUT_PAGE'
,p_build_option_comment=>'This feature displays an "About this application" link and exposes a partially configurable about this application page.  If you don''t want to have a link to about this application disable this setting.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(6210148529518744054)
,p_build_option_name=>'Releases'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>40935286839364
,p_build_option_comment=>'Used to exclude the use of "Releases".'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(7620836838353896630)
,p_build_option_name=>'Show friendly identifier'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>40760828906055
,p_build_option_comment=>'Each project gets a friendly identifier by default.  Friendly identifiers are alternative primary keys that are human readable. For example "AA01" is a friendly identifier.  This setting controls if the identifiers are displayed in the UI of the appl'
||'ication.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(10049894731304381300)
,p_build_option_name=>'Feature: Feedback'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>41287209098302
,p_feature_identifier=>'APPLICATION_FEEDBACK'
,p_build_option_comment=>'Provide a mechanism for end users to post general comments back to the application administrators and developers.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(10096331413208874441)
,p_build_option_name=>'Configure Application Features'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>41300082518941
,p_feature_identifier=>'APPLICATION_CONFIGURATION'
,p_build_option_comment=>'Allow application administrators to enable or disable specific application features.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(11830471118366478605)
,p_build_option_name=>'Developer Audit Reports'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>41116367005658
,p_default_on_export=>'EXCLUDE'
,p_build_option_comment=>'Allows hiding functions appropriate for a development environment, but not to be displayed in a production environment.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(11954835352876239310)
,p_build_option_name=>'Reviews'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>1
,p_build_option_comment=>'This feature allows a project to be identified as being part of zero or more reviews.  Create a review than associate projects with the review.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(12074077457143011350)
,p_build_option_name=>'Groups'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>41300227453424
,p_build_option_comment=>'Groups allow you to organize contributors.  You define a group, then add &NOMENCLATURE_USERS. to the group.  When viewing  &NOMENCLATURE_USERS., you can filter by groups.  This reduces a large list to a smaller, more targeted, list.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(12987883795546475582)
,p_build_option_name=>'Subscriptions'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>41329529515893
,p_build_option_comment=>'Allows enable/disable of Notification Subscriptions, sent via email.  This should be disabled if email is not configured on this instance.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(16149062091664614982)
,p_build_option_name=>'Activity Planning'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>41300186139074
,p_build_option_comment=>'Allows a team member to plan activities; For example I am working on these activities (aka &NOMENCLATURE_PROJECTS.) for these dates.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(18695039146957201232)
,p_build_option_name=>'Email Configured'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>41331431166856
,p_build_option_comment=>'If email is not configured on your instance, use this to turn off the features that would send emails.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(19957512337871264807)
,p_build_option_name=>'Include Project Active Toggle'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>41300192584661
,p_build_option_comment=>'Identifies a &NOMENCLATURE_PROJECT. as being actively worked or not.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(141188612131336575480)
,p_build_option_name=>'Access Control'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>40760827840139
,p_feature_identifier=>'APPLICATION_ACCESS_CONTROL'
,p_build_option_comment=>'Incorporate role based user authentication within your application and manage username mappings to application roles.'
);
wwv_flow_imp.component_end;
end;
/
