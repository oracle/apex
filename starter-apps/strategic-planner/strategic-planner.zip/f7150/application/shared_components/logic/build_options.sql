prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 7150
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(3472559489660737107)
,p_build_option_name=>'Contributor Checklist'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>41300185620820
,p_build_option_comment=>'This feature provides a configurable list of actions visible to contributors of this application.  It outlines what is expected of each contributor.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(3987746581687417207)
,p_build_option_name=>'About Page'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>40760826019912
,p_feature_identifier=>'APPLICATION_ABOUT_PAGE'
,p_build_option_comment=>'This feature displays an "About this application" link and exposes a partially configurable about this application page.  If you don''t want to have a link to about this application disable this setting.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(6201759808817603711)
,p_build_option_name=>'Releases'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>40935286839364
,p_build_option_comment=>'Used to exclude the use of "Releases".'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(7612448117652756287)
,p_build_option_name=>'Show friendly identifier'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>40760828906055
,p_build_option_comment=>'Each project gets a friendly identifier by default.  Friendly identifiers are alternative primary keys that are human readable. For example "AA01" is a friendly identifier.  This setting controls if the identifiers are displayed in the UI of the appl'
||'ication.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(10041506010603240957)
,p_build_option_name=>'Feature: Feedback'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>41287209098302
,p_feature_identifier=>'APPLICATION_FEEDBACK'
,p_build_option_comment=>'Provide a mechanism for end users to post general comments back to the application administrators and developers.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(10087942692507734098)
,p_build_option_name=>'Configure Application Features'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>41300082518941
,p_feature_identifier=>'APPLICATION_CONFIGURATION'
,p_build_option_comment=>'Allow application administrators to enable or disable specific application features.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(11822082397665338262)
,p_build_option_name=>'Developer Audit Reports'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>41116367005658
,p_default_on_export=>'EXCLUDE'
,p_build_option_comment=>'Allows hiding functions appropriate for a development environment, but not to be displayed in a production environment.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(11946446632175098967)
,p_build_option_name=>'Reviews'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>1
,p_build_option_comment=>'This feature allows a project to be identified as being part of zero or more reviews.  Create a review than associate projects with the review.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(12065688736441871007)
,p_build_option_name=>'Groups'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>41300227453424
,p_build_option_comment=>'Groups allow you to organize contributors.  You define a group, then add &NOMENCLATURE_USERS. to the group.  When viewing  &NOMENCLATURE_USERS., you can filter by groups.  This reduces a large list to a smaller, more targeted, list.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(12979495074845335239)
,p_build_option_name=>'Subscriptions'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>41155699272672
,p_build_option_comment=>'Allows enable/disable of Notification Subscriptions, sent via email.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(16140673370963474639)
,p_build_option_name=>'Activity Planning'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>41300186139074
,p_build_option_comment=>'Allows a team member to plan activities; For example I am working on these activities (aka &NOMENCLATURE_PROJECTS.) for these dates.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(19949123617170124464)
,p_build_option_name=>'Include Project Active Toggle'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>41300192584661
,p_build_option_comment=>'Identifies a &NOMENCLATURE_PROJECT. as being actively worked or not.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(141180223410635435137)
,p_build_option_name=>'Access Control'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>40760827840139
,p_feature_identifier=>'APPLICATION_ACCESS_CONTROL'
,p_build_option_comment=>'Incorporate role based user authentication within your application and manage username mappings to application roles.'
);
wwv_flow_imp.component_end;
end;
/
