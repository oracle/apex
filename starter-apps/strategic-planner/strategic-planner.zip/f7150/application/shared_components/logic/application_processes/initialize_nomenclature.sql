prompt --application/shared_components/logic/application_processes/initialize_nomenclature
begin
--   Manifest
--     APPLICATION PROCESS: Initialize nomenclature
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(44807277144741662574)
,p_process_sequence=>1
,p_process_point=>'ON_NEW_INSTANCE'
,p_process_name=>'Initialize nomenclature'
,p_static_id=>'initialize-nomenclature'
,p_process_sql_clob=>'sp_util.set_nomenclature;'
,p_process_clob_language=>'PLSQL'
,p_version_scn=>'45188590803377'
);
wwv_flow_imp.component_end;
end;
/
