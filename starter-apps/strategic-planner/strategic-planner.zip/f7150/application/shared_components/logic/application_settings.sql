prompt --application/shared_components/logic/application_settings
begin
--   Manifest
--     APPLICATION SETTINGS: 7150
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>6745509624802563
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(14684306194652723400)
,p_name=>'EXTERNAL_PERSON_LINK'
,p_value=>'http://people.oracle.com/@#EMAIL#'
,p_is_required=>'N'
,p_comments=>'link with #EMAIL# substitution to provide a link to more details - only if the email domain matches that within EXTERNAL_PERSON_LINK_DOMAIN'
,p_version_scn=>41537612306125
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(14684327656405728085)
,p_name=>'EXTERNAL_PERSON_LINK_DOMAIN'
,p_value=>'oracle.com'
,p_is_required=>'N'
,p_comments=>'if the email of a "person" uses this domain, the EXTERNAL_PERSON_LINK will be used to show a link to more details'
,p_version_scn=>41537612306171
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(18411153584487607517)
,p_name=>'FEEDBACK_ATTACHMENTS_YN'
,p_value=>'Y'
,p_is_required=>'N'
,p_valid_values=>'Y, N'
,p_on_upgrade_keep_value=>true
,p_required_patch=>wwv_flow_imp.id(18411153291516607514)
,p_version_scn=>1
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(19663544075026407634)
,p_name=>'ACCESS_CONTROL_SCOPE'
,p_value=>'ACL_ONLY'
,p_is_required=>'N'
,p_valid_values=>'ACL_ONLY, ALL_USERS'
,p_on_upgrade_keep_value=>true
,p_required_patch=>wwv_flow_imp.id(149549870691548801694)
,p_comments=>'The default access level given to authenticated users who are not in the access control list'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
