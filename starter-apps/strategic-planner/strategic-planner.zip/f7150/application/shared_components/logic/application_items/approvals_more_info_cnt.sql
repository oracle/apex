prompt --application/shared_components/logic/application_items/approvals_more_info_cnt
begin
--   Manifest
--     APPLICATION ITEM: APPROVALS_MORE_INFO_CNT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(53825021695978290237)
,p_name=>'APPROVALS_MORE_INFO_CNT'
,p_protection_level=>'I'
,p_required_patch=>wwv_flow_imp.id(46253531127994752923)
,p_version_scn=>'44801038059551'
);
wwv_flow_imp.component_end;
end;
/
