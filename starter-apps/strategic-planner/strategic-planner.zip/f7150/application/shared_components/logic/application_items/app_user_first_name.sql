prompt --application/shared_components/logic/application_items/app_user_first_name
begin
--   Manifest
--     APPLICATION ITEM: APP_USER_FIRST_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(53850457351545309850)
,p_name=>'APP_USER_FIRST_NAME'
,p_protection_level=>'I'
,p_version_scn=>44801982047526
);
wwv_flow_imp.component_end;
end;
/
