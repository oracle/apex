prompt --application/shared_components/logic/application_items/last_proj_jump_pg
begin
--   Manifest
--     APPLICATION ITEM: LAST_PROJ_JUMP_PG
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>2214566044257001599
,p_default_application_id=>9111
,p_default_id_offset=>11016538767572718
,p_default_owner=>'DBTOOLS_PROD'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(38999289492284840232)
,p_name=>'LAST_PROJ_JUMP_PG'
,p_protection_level=>'I'
,p_version_scn=>40580934627511
);
wwv_flow_imp.component_end;
end;
/
