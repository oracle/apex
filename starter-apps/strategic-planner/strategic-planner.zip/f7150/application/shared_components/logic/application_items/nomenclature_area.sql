prompt --application/shared_components/logic/application_items/nomenclature_area
begin
--   Manifest
--     APPLICATION ITEM: NOMENCLATURE_AREA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>2214566044257001599
,p_default_application_id=>9111
,p_default_id_offset=>11016538767572718
,p_default_owner=>'DBTOOLS_PROD'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(148807607533775024749)
,p_name=>'NOMENCLATURE_AREA'
,p_protection_level=>'I'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
