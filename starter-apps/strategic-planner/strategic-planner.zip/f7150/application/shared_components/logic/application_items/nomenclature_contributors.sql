prompt --application/shared_components/logic/application_items/nomenclature_contributors
begin
--   Manifest
--     APPLICATION ITEM: NOMENCLATURE_CONTRIBUTORS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>2214566044257001599
,p_default_application_id=>9111
,p_default_id_offset=>11016538767572718
,p_default_owner=>'DBTOOLS_PROD'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(40791489646673327741)
,p_name=>'NOMENCLATURE_CONTRIBUTORS'
,p_protection_level=>'I'
,p_version_scn=>40767250615720
);
wwv_flow_imp.component_end;
end;
/
