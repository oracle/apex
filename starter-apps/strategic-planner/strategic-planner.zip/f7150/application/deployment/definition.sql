prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7150
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select 1 from user_scheduler_jobs'||wwv_flow.LF||
'         where job_name = ''SP_NOTIF_';
wwv_flow_imp.g_varchar2_table(2) := 'SUBSCRIPTIONS'''||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        sys.dbms_scheduler.drop_job(job_name => ''SP_NOTIF_SUBSCRIPTIONS'');';
wwv_flow_imp.g_varchar2_table(3) := ''||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select 1 from user_scheduler_jobs'||wwv_flow.LF||
'         where';
wwv_flow_imp.g_varchar2_table(4) := ' job_name = ''SP_GENERATE_AI_PROJECT_SUMMARIES_JOB'''||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        sys.dbms_scheduler.drop_job(jo';
wwv_flow_imp.g_varchar2_table(5) := 'b_name => ''SP_GENERATE_AI_PROJECT_SUMMARIES_JOB'');'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'drop sequence   sp_seq;'||wwv_flow.LF||
'dro';
wwv_flow_imp.g_varchar2_table(6) := 'p sequence   sp_kb_stack_rank_seq;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop package    sp_globals;'||wwv_flow.LF||
'drop package    sp_release_timeline;';
wwv_flow_imp.g_varchar2_table(7) := ''||wwv_flow.LF||
'drop package    sp_log;'||wwv_flow.LF||
'drop package    sp_util;'||wwv_flow.LF||
'drop package    sp_summary_util;'||wwv_flow.LF||
'drop package    s';
wwv_flow_imp.g_varchar2_table(8) := 'p_comment_util;'||wwv_flow.LF||
'drop package    sp_value_compare;'||wwv_flow.LF||
'drop package    sp_contributor_summary;'||wwv_flow.LF||
'drop packa';
wwv_flow_imp.g_varchar2_table(9) := 'ge    sp_approvals;'||wwv_flow.LF||
'drop procedure  sp_favorite_toggle;'||wwv_flow.LF||
'drop function   sp_date_range_pct_comp;'||wwv_flow.LF||
'drop';
wwv_flow_imp.g_varchar2_table(10) := ' function   sp_tag_diff;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop view sp_initiative_comments_v;'||wwv_flow.LF||
'drop view sp_init_focus_area_comments_';
wwv_flow_imp.g_varchar2_table(11) := 'v;'||wwv_flow.LF||
'drop view sp_project_comments_v;'||wwv_flow.LF||
'drop view sp_task_comments_v;'||wwv_flow.LF||
'drop view sp_release_comments_v;'||wwv_flow.LF||
'd';
wwv_flow_imp.g_varchar2_table(12) := 'rop view sp_documents_v;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table SP_APP_NOMENCLATURE           cascade constraints;'||wwv_flow.LF||
'drop table s';
wwv_flow_imp.g_varchar2_table(13) := 'p_app_settings               cascade constraints;'||wwv_flow.LF||
'drop table sp_app_log                    cascade c';
wwv_flow_imp.g_varchar2_table(14) := 'onstraints;'||wwv_flow.LF||
'drop table sp_error_log                  cascade constraints;'||wwv_flow.LF||
'drop table SP_DEFAULT_TAGS';
wwv_flow_imp.g_varchar2_table(15) := '               cascade constraints;'||wwv_flow.LF||
'drop table SP_RELEASE_MILESTONE_DEFAULT_TAGS cascade constraints';
wwv_flow_imp.g_varchar2_table(16) := ';'||wwv_flow.LF||
'drop table sp_countries                  cascade constraints;'||wwv_flow.LF||
'drop table sp_project_priorities    ';
wwv_flow_imp.g_varchar2_table(17) := '     cascade constraints;'||wwv_flow.LF||
'drop table sp_resource_types             cascade constraints;'||wwv_flow.LF||
'drop table s';
wwv_flow_imp.g_varchar2_table(18) := 'p_team_members               cascade constraints;'||wwv_flow.LF||
'drop table SP_TEAM_MEMBER_NOTIFICATIONS  cascade c';
wwv_flow_imp.g_varchar2_table(19) := 'onstraints;'||wwv_flow.LF||
'drop table sp_areas                      cascade constraints;'||wwv_flow.LF||
'drop table sp_initiatives ';
wwv_flow_imp.g_varchar2_table(20) := '               cascade constraints;'||wwv_flow.LF||
'drop table sp_initiative_history         cascade constraints;'||wwv_flow.LF||
'dr';
wwv_flow_imp.g_varchar2_table(21) := 'op table sp_initiative_documents       cascade constraints;'||wwv_flow.LF||
'drop table sp_initiative_comments       ';
wwv_flow_imp.g_varchar2_table(22) := ' cascade constraints;'||wwv_flow.LF||
'drop table sp_initiative_links           cascade constraints;'||wwv_flow.LF||
'drop table sp_in';
wwv_flow_imp.g_varchar2_table(23) := 'itiative_focus_areas     cascade constraints;'||wwv_flow.LF||
'drop table sp_init_focus_area_history    cascade const';
wwv_flow_imp.g_varchar2_table(24) := 'raints;'||wwv_flow.LF||
'drop table sp_init_focus_area_documents  cascade constraints;'||wwv_flow.LF||
'drop table sp_init_focus_area_';
wwv_flow_imp.g_varchar2_table(25) := 'comments   cascade constraints;'||wwv_flow.LF||
'drop table sp_init_focus_area_links      cascade constraints;'||wwv_flow.LF||
'drop t';
wwv_flow_imp.g_varchar2_table(26) := 'able sp_projects                   cascade constraints;'||wwv_flow.LF||
'drop table sp_project_history            cas';
wwv_flow_imp.g_varchar2_table(27) := 'cade constraints;'||wwv_flow.LF||
'drop table sp_project_contributors       cascade constraints;'||wwv_flow.LF||
'drop table sp_projec';
wwv_flow_imp.g_varchar2_table(28) := 't_comments           cascade constraints;'||wwv_flow.LF||
'drop table sp_project_documents          cascade constrain';
wwv_flow_imp.g_varchar2_table(29) := 'ts;'||wwv_flow.LF||
'drop table sp_project_links              cascade constraints;'||wwv_flow.LF||
'drop table sp_project_related     ';
wwv_flow_imp.g_varchar2_table(30) := '       cascade constraints;'||wwv_flow.LF||
'drop table sp_project_comments_emails    cascade constraints;'||wwv_flow.LF||
'drop table';
wwv_flow_imp.g_varchar2_table(31) := ' sp_project_sizes              cascade constraints;'||wwv_flow.LF||
'drop table sp_project_groups             cascade';
wwv_flow_imp.g_varchar2_table(32) := ' constraints;'||wwv_flow.LF||
'drop table sp_project_statuses           cascade constraints;'||wwv_flow.LF||
'drop table sp_release_tr';
wwv_flow_imp.g_varchar2_table(33) := 'ains             cascade constraints;'||wwv_flow.LF||
'drop table sp_release_comments           cascade constraints;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(34) := 'drop table sp_release_milestone_types    cascade constraints;'||wwv_flow.LF||
'drop table sp_release_milestones      ';
wwv_flow_imp.g_varchar2_table(35) := '   cascade constraints;'||wwv_flow.LF||
'drop table sp_release_documents          cascade constraints;'||wwv_flow.LF||
'drop table sp_';
wwv_flow_imp.g_varchar2_table(36) := 'release_history            cascade constraints;'||wwv_flow.LF||
'drop table SP_RELEASE_LINKS              cascade con';
wwv_flow_imp.g_varchar2_table(37) := 'straints;'||wwv_flow.LF||
'drop table sp_proj_interactions_log      cascade constraints;'||wwv_flow.LF||
'drop table sp_favorites     ';
wwv_flow_imp.g_varchar2_table(38) := '             cascade constraints;'||wwv_flow.LF||
'drop table sp_configurable_text          cascade constraints;'||wwv_flow.LF||
'drop';
wwv_flow_imp.g_varchar2_table(39) := ' table sp_project_scales             cascade constraints;'||wwv_flow.LF||
'drop table sp_activity_types             c';
wwv_flow_imp.g_varchar2_table(40) := 'ascade constraints;'||wwv_flow.LF||
'drop table sp_activities                 cascade constraints;'||wwv_flow.LF||
'drop table sp_noti';
wwv_flow_imp.g_varchar2_table(41) := 'fications              cascade constraints;'||wwv_flow.LF||
'drop table sp_notification_subscriptions cascade constra';
wwv_flow_imp.g_varchar2_table(42) := 'ints;'||wwv_flow.LF||
'drop table SP_GROUPS                     cascade constraints;'||wwv_flow.LF||
'drop table SP_GROUP_MEMBERS     ';
wwv_flow_imp.g_varchar2_table(43) := '         cascade constraints;'||wwv_flow.LF||
'drop table SP_DEFAULT_PEOPLE_TAGS        cascade constraints;'||wwv_flow.LF||
'drop tab';
wwv_flow_imp.g_varchar2_table(44) := 'le SP_EXTERNAL_TICKETING_SYSTEMS cascade constraints;'||wwv_flow.LF||
'drop table SP_APPLICATION_NOTIFICATIONS  casca';
wwv_flow_imp.g_varchar2_table(45) := 'de constraints;'||wwv_flow.LF||
'drop table sp_competencies               cascade constraints;'||wwv_flow.LF||
'drop table sp_task_com';
wwv_flow_imp.g_varchar2_table(46) := 'ments              cascade constraints;'||wwv_flow.LF||
'drop table sp_task_documents             cascade constraints';
wwv_flow_imp.g_varchar2_table(47) := ';'||wwv_flow.LF||
'drop table sp_task_links                 cascade constraints;'||wwv_flow.LF||
'drop table sp_task_history          ';
wwv_flow_imp.g_varchar2_table(48) := '     cascade constraints;'||wwv_flow.LF||
'drop table sp_tasks                      cascade constraints;'||wwv_flow.LF||
'drop table s';
wwv_flow_imp.g_varchar2_table(49) := 'p_task_statuses              cascade constraints;'||wwv_flow.LF||
'drop table sp_initiative_default_tasks   cascade c';
wwv_flow_imp.g_varchar2_table(50) := 'onstraints;'||wwv_flow.LF||
'drop table sp_task_types                 cascade constraints;'||wwv_flow.LF||
'drop table sp_comment_imag';
wwv_flow_imp.g_varchar2_table(51) := 'es             cascade constraints;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table sp_ai_prompts                 cascade constraints;'||wwv_flow.LF||
'd';
wwv_flow_imp.g_varchar2_table(52) := 'rop table sp_project_ai_summaries       cascade constraints;'||wwv_flow.LF||
'drop table sp_release_ai_summaries     ';
wwv_flow_imp.g_varchar2_table(53) := '  cascade constraints;'||wwv_flow.LF||
'drop table sp_report_questions           cascade constraints;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table sp_';
wwv_flow_imp.g_varchar2_table(54) := 'approval_types             cascade constraints;'||wwv_flow.LF||
'drop table sp_initiative_approvals       cascade con';
wwv_flow_imp.g_varchar2_table(55) := 'straints;'||wwv_flow.LF||
'drop table sp_initiative_approval_chain  cascade constraints;'||wwv_flow.LF||
'drop table sp_project_approv';
wwv_flow_imp.g_varchar2_table(56) := 'als          cascade constraints;'||wwv_flow.LF||
'drop table sp_project_approval_chain     cascade constraints;';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(176221033654625264606)
,p_welcome_message=>'This application installer will guide you through the process of creating your database objects and seed data.'
,p_configuration_message=>'You can configure the following attributes of your application.'
,p_build_options_message=>'You can choose to include the following build options.'
,p_validation_message=>'The following validations will be performed to ensure your system is compatible with this application.'
,p_install_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_message=>'The application installer has detected that this application''s supporting objects were previously installed.  This wizard will guide you through the process of upgrading these supporting objects.'
,p_upgrade_confirm_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_success_message=>'Your application''s supporting objects have been installed.'
,p_upgrade_failure_message=>'Installation of database objects and seed data has failed.'
,p_deinstall_success_message=>'Deinstallation complete.'
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
,p_required_names_available=>'SP_NOTIF_SUBSCRIPTIONS:SP_RELEASE_TIMELINE:SP_SEQ:SP_LOG:SP_VALUE_COMPARE:SP_PROJ_STATUS_UI:SP_CONTRIBUTOR_SUMMARY:SP_FAVORITE_TOGGLE:SP_DATE_RANGE_PCT_COMP:SP_TAG_DIFF:SP_PROJECT_PRIORITIES:SP_RESOURCE_TYPES:SP_TEAM_MEMBERS:SP_INITIATIVES:SP_INITIAT'
||'IVE_DOCUMENTS:SP_INITIATIVE_COMMENTS:SP_PROJECTS:SP_PROJECT_CONTRIBUTORS:SP_PROJECT_HISTORY:SP_PROJECT_COMMENTS:SP_PROJECT_DOCUMENTS:SP_PROJECT_LINKS:SP_PROJECT_RELATED:SP_APP_NOMENCLATURE:SP_APP_SETTINGS:SP_DEFAULT_TAGS:SP_COUNTRIES:SP_PROJECT_COMME'
||'NTS_EMAILS:SP_PROJECT_SIZES:SP_RELEASE_TRAINS:SP_RELEASE_COMMENTS:SP_RELEASE_MILESTONES:SP_RELEASE_DOCUMENTS:SP_RELEASE_HISTORY:SP_RELEASE_LINKS:SP_INITIATIVE_LINKS:SP_PROJ_INTERACTIONS_LOG:SP_FAVORITES:SP_CONFIGURABLE_TEXT:SP_PROJECT_SCALES:SP_ACTIV'
||'ITY_TYPES:SP_ACTIVITIES:SP_NOTIFICATIONS:SP_NOTIFICATION_SUBSCRIPTIONS:SP_GROUPS:SP_GROUP_MEMBERS:SP_DEFAULT_PEOPLE_TAGS:SP_EXTERNAL_TICKETING_SYSTEMS:SP_APPLICATION_NOTIFICATIONS:SP_COMPETENCIES:SP_TASK_TYPES:SP_INITIATIVE_DEFAULT_TASKS:SP_TASK_STAT'
||'USES:SP_TASKS:SP_TASK_HISTORY:SP_TASK_LINKS:SP_TASK_DOCUMENTS:SP_TASK_COMMENTS:SP_AREAS:SP_INITIATIVE_FOCUS_AREAS:SP_TEAM_MEMBER_NOTIFICATIONS:SP_APP_LOG:SP_GLOBALS:SP_APPROVAL_TYPES:SP_INITIATIVE_APPROVALS:SP_INITIATIVE_APPROVAL_CHAIN:SP_PROJECT_APP'
||'ROVALS:SP_PROJECT_APPROVAL_CHAIN:SP_COMMENT_IMAGES:SP_UTIL:SP_COMMENT_UTIL:SP_REPORT_QUESTIONS:SP_AI_PROMPTS:SP_PROJECT_AI_SUMMARIES:SP_RELEASE_AI_SUMMARIES:SP_DOCUMENTS_V:SP_ERROR_LOG'
);
wwv_flow_imp.component_end;
end;
/
