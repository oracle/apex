prompt --application/deployment/install/install_ai_prompts_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-ai_prompts table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_ai_prompts ('||wwv_flow.LF||
'    id                             number '||wwv_flow.LF||
'                            ';
wwv_flow_imp.g_varchar2_table(2) := '          default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(3) := '                       constraint sp_ai_prompts_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    static_id                ';
wwv_flow_imp.g_varchar2_table(4) := '      varchar2(255)  not null'||wwv_flow.LF||
'                                      constraint sp_ai_prompts_uk uniq';
wwv_flow_imp.g_varchar2_table(5) := 'ue,'||wwv_flow.LF||
'    description                    varchar2(4000) not null,'||wwv_flow.LF||
'    prompt                         c';
wwv_flow_imp.g_varchar2_table(6) := 'lob,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date            not null,'||wwv_flow.LF||
'    created_by             ';
wwv_flow_imp.g_varchar2_table(7) := '        varchar2(255)   not null,'||wwv_flow.LF||
'    updated                        date            not null,'||wwv_flow.LF||
'    u';
wwv_flow_imp.g_varchar2_table(8) := 'pdated_by                     varchar2(255)   not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_ai_prompts_b';
wwv_flow_imp.g_varchar2_table(9) := 'iu'||wwv_flow.LF||
'    before insert or update '||wwv_flow.LF||
'    on sp_ai_prompts'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(10) := '      :new.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_U';
wwv_flow_imp.g_varchar2_table(11) := 'SER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated    := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context';
wwv_flow_imp.g_varchar2_table(12) := '(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    :new.static_id  := upper(:new.static_id);'||wwv_flow.LF||
'end sp_ai_prompts_b';
wwv_flow_imp.g_varchar2_table(13) := 'iu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(27803469979374832386)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'ai_prompts table and trigger'
,p_sequence=>75
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
