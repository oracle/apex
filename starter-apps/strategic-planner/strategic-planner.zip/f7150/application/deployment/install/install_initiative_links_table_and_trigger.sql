prompt --application/deployment/install/install_initiative_links_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-INITIATIVE_LINKS table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table SP_INITIATIVE_LINKS ('||wwv_flow.LF||
'    id                             number default on null to_numb';
wwv_flow_imp.g_varchar2_table(2) := 'er(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint SP';
wwv_flow_imp.g_varchar2_table(3) := '_initiative_links_PK primary key,'||wwv_flow.LF||
'    initiative_id                  number '||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(4) := '            constraint sp_initiative_links_to_int_fk'||wwv_flow.LF||
'                                   references s';
wwv_flow_imp.g_varchar2_table(5) := 'p_initiatives (id)'||wwv_flow.LF||
'                                   on delete cascade,'||wwv_flow.LF||
'    link_name              ';
wwv_flow_imp.g_varchar2_table(6) := '        varchar2(255 char)   not null,'||wwv_flow.LF||
'    link_url                       varchar2(4000 char),'||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(7) := 'mportant_yn                   varchar2(1 char) default on null ''N'''||wwv_flow.LF||
'                                 ';
wwv_flow_imp.g_varchar2_table(8) := '  constraint sp_initiative_links_imp_ck'||wwv_flow.LF||
'                                   check (important_yn in (''';
wwv_flow_imp.g_varchar2_table(9) := 'Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by                   ';
wwv_flow_imp.g_varchar2_table(10) := '  varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by     ';
wwv_flow_imp.g_varchar2_table(11) := '                varchar2(255 char) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create index SP_INITIATIVE_LINKS_i1 on SP_INITIATIV';
wwv_flow_imp.g_varchar2_table(12) := 'E_LINKS(initiative_id);'||wwv_flow.LF||
'create unique index SP_INITIATIVE_LINKS_U1 on SP_INITIATIVE_LINKS(initiative';
wwv_flow_imp.g_varchar2_table(13) := '_id,link_name);'||wwv_flow.LF||
'create unique index SP_INITIATIVE_LINKS_U2 on SP_INITIATIVE_LINKS(initiative_id, LIN';
wwv_flow_imp.g_varchar2_table(14) := 'K_URL);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger SP_INITIATIVE_LINKS_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on SP_IN';
wwv_flow_imp.g_varchar2_table(15) := 'ITIATIVE_LINKS'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(16) := ' :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.upda';
wwv_flow_imp.g_varchar2_table(17) := 'ted := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(18) := '   -- touch parent table'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   update sp_initiatives set updated = sysdate, updated_by = :new.upd';
wwv_flow_imp.g_varchar2_table(19) := 'ated_by where id = :new.initiative_id;'||wwv_flow.LF||
'end SP_INITIATIVE_LINKS_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(41623252403342804822)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'INITIATIVE_LINKS table and trigger'
,p_sequence=>690
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
