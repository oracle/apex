prompt --application/deployment/install/install_proj_interactions_log_table
begin
--   Manifest
--     INSTALL: INSTALL-proj_interactions_log table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_proj_interactions_log ('||wwv_flow.LF||
'    id                             number default on null to';
wwv_flow_imp.g_varchar2_table(2) := '_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constrai';
wwv_flow_imp.g_varchar2_table(3) := 'nt sp_proj_interactions_log_pk primary key,'||wwv_flow.LF||
'    project_id                     number'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(4) := '                     constraint sp_proj_interactions_log_fk'||wwv_flow.LF||
'                                   refer';
wwv_flow_imp.g_varchar2_table(5) := 'ences sp_projects (id),'||wwv_flow.LF||
'    app_page                       number not null,'||wwv_flow.LF||
'    app_user            ';
wwv_flow_imp.g_varchar2_table(6) := '           varchar2(255 char) not null,'||wwv_flow.LF||
'    action                         varchar2(50 char) not nul';
wwv_flow_imp.g_varchar2_table(7) := 'l,'||wwv_flow.LF||
'    page_rendered                  date);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_proj_interactions_log_biu';
wwv_flow_imp.g_varchar2_table(8) := ''||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_proj_interactions_log'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    :new.page_re';
wwv_flow_imp.g_varchar2_table(9) := 'ndered := sysdate;'||wwv_flow.LF||
'    :new.app_user := lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user))';
wwv_flow_imp.g_varchar2_table(10) := ';'||wwv_flow.LF||
'end sp_proj_interactions_log_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create  index sp_proj_interactions_log_i1 on sp_proj_interact';
wwv_flow_imp.g_varchar2_table(11) := 'ions_log (project_id);'||wwv_flow.LF||
'create  index sp_proj_interactions_log_i2 on sp_proj_interactions_log (app_us';
wwv_flow_imp.g_varchar2_table(12) := 'er);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace package sp_log'||wwv_flow.LF||
'as '||wwv_flow.LF||
'procedure log_interaction (p_project_id in number);'||wwv_flow.LF||
'funct';
wwv_flow_imp.g_varchar2_table(13) := 'ion  log_and_summarize (p_project_id in number) return varchar2;'||wwv_flow.LF||
'end sp_log;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace pa';
wwv_flow_imp.g_varchar2_table(14) := 'ckage body sp_log '||wwv_flow.LF||
'as  '||wwv_flow.LF||
'procedure log_interaction ('||wwv_flow.LF||
'    p_project_id in number) '||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_action var';
wwv_flow_imp.g_varchar2_table(15) := 'char2(50) := null;'||wwv_flow.LF||
'    l_page   number := to_number(v(''APP_PAGE_ID''));'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- determin';
wwv_flow_imp.g_varchar2_table(16) := 'e action based on page'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if    l_page = 3   then l_action := ''detail view''; '||wwv_flow.LF||
'    elsif l_pa';
wwv_flow_imp.g_varchar2_table(17) := 'ge = 6   then l_action := ''edit link'';'||wwv_flow.LF||
'    elsif l_page = 9   then l_action := ''edit contributor'';'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(18) := '   elsif l_page = 10  then l_action := ''edit related'';'||wwv_flow.LF||
'    elsif l_page = 12  then l_action := ''add/';
wwv_flow_imp.g_varchar2_table(19) := 'edit document'';'||wwv_flow.LF||
'    elsif l_page = 24  then l_action := ''edit project'';'||wwv_flow.LF||
'    elsif l_page = 28  then ';
wwv_flow_imp.g_varchar2_table(20) := 'l_action := ''edit comment'';'||wwv_flow.LF||
'    elsif l_page = 32  then l_action := ''edit description'';'||wwv_flow.LF||
'    elsif l_';
wwv_flow_imp.g_varchar2_table(21) := 'page = 36  then l_action := ''quick look'';'||wwv_flow.LF||
'    elsif l_page = 47  then l_action := ''archive'';'||wwv_flow.LF||
'    els';
wwv_flow_imp.g_varchar2_table(22) := 'if l_page = 49  then l_action := ''mark as duplicate'';'||wwv_flow.LF||
'    elsif l_page = 64  then l_action := ''view ';
wwv_flow_imp.g_varchar2_table(23) := 'change history'';'||wwv_flow.LF||
'    elsif l_page = 82  then l_action := ''view tag history'';'||wwv_flow.LF||
'    elsif l_page = 96  ';
wwv_flow_imp.g_varchar2_table(24) := 'then l_action := ''view description history'';'||wwv_flow.LF||
'    elsif l_page = 101 then l_action := ''edit activity''';
wwv_flow_imp.g_varchar2_table(25) := ';    '||wwv_flow.LF||
'    elsif l_page = 136 then l_action := ''view description'';'||wwv_flow.LF||
'    elsif l_page = 501 then l_acti';
wwv_flow_imp.g_varchar2_table(26) := 'on := ''task'';'||wwv_flow.LF||
'    elsif l_page = 502 then l_action := ''task details'';'||wwv_flow.LF||
'    elsif l_page = 503 then l_';
wwv_flow_imp.g_varchar2_table(27) := 'action := ''edit task comment'';   '||wwv_flow.LF||
'    elsif l_page = 504 then l_action := ''edit task document''; '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(28) := ' elsif l_page = 506 then l_action := ''edit task link''; '||wwv_flow.LF||
'    elsif l_page = 507 then l_action := ''tas';
wwv_flow_imp.g_varchar2_table(29) := 'k history'';'||wwv_flow.LF||
'    elsif l_page = 508 then l_action := ''milestone'';'||wwv_flow.LF||
'    elsif l_page = 509 then l_actio';
wwv_flow_imp.g_varchar2_table(30) := 'n := ''review'';'||wwv_flow.LF||
'    else                    l_action := ''unknown'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- log pro';
wwv_flow_imp.g_varchar2_table(31) := 'ject interaction'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    insert into sp_proj_interactions_log (project_id, app_page, action) valu';
wwv_flow_imp.g_varchar2_table(32) := 'es (p_project_id, l_page, l_action);'||wwv_flow.LF||
'end log_interaction;'||wwv_flow.LF||
''||wwv_flow.LF||
'function log_and_summarize ('||wwv_flow.LF||
'    p_projec';
wwv_flow_imp.g_varchar2_table(33) := 't_id in number) '||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_return varchar2(50) := null;'||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- lo';
wwv_flow_imp.g_varchar2_table(34) := 'g interaction'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    log_interaction('||wwv_flow.LF||
'        p_project_id => p_project_id);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- retur';
wwv_flow_imp.g_varchar2_table(35) := 'n interaction summary'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for c1 in (select count(*) c, count(distinct(app_user)) u from sp_p';
wwv_flow_imp.g_varchar2_table(36) := 'roj_interactions_log where project_id = p_project_id) loop '||wwv_flow.LF||
'        l_return := trim(to_char(c1.c,''9';
wwv_flow_imp.g_varchar2_table(37) := '99G999G999G990''));'||wwv_flow.LF||
'        if c1.c = 1 then  '||wwv_flow.LF||
'            l_return := l_return||'' interaction by ''||';
wwv_flow_imp.g_varchar2_table(38) := 'trim(to_char(c1.u,''999G999G999G990''));'||wwv_flow.LF||
'        else '||wwv_flow.LF||
'            l_return := l_return||'' interaction';
wwv_flow_imp.g_varchar2_table(39) := 's by ''||trim(to_char(c1.u,''999G999G999G990''));'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if c1.u = 1 then '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(40) := ' l_return := l_return ||'' user'';'||wwv_flow.LF||
'        else '||wwv_flow.LF||
'            l_return := l_return ||'' users'';'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(41) := 'end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    return l_return;'||wwv_flow.LF||
'end log_and_summarize;'||wwv_flow.LF||
'end sp_log;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(48875414637661213707)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'proj_interactions_log table'
,p_sequence=>540
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
