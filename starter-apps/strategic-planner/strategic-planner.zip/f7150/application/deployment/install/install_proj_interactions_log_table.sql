prompt --application/deployment/install/install_proj_interactions_log_table
begin
--   Manifest
--     INSTALL: INSTALL-proj_interactions_log table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>26954343551793662
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13870288466561743188)
,p_install_id=>wwv_flow_imp.id(141215907483525794087)
,p_name=>'proj_interactions_log table'
,p_sequence=>580
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table sp_proj_interactions_log (',
'    id                             number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') ',
'                                   constraint sp_proj_interactions_log_pk primary key,',
'    project_id                     number',
'                                   constraint sp_proj_interactions_log_fk',
'                                   references sp_projects (id),',
'    app_page                       number not null,',
'    app_user                       varchar2(255 char) not null,',
'    action                         varchar2(50 char) not null,',
'    page_rendered                  date);',
'',
'create or replace trigger sp_proj_interactions_log_biu',
'    before insert or update',
'    on sp_proj_interactions_log',
'    for each row',
'begin',
'    :new.page_rendered := sysdate;',
'    :new.app_user := lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));',
'end sp_proj_interactions_log_biu;',
'/',
'',
'create  index sp_proj_interactions_log_i1 on sp_proj_interactions_log (project_id);',
'create  index sp_proj_interactions_log_i2 on sp_proj_interactions_log (app_user);',
'',
'create or replace package sp_log',
'as ',
'procedure log_interaction (p_project_id in number);',
'function  log_and_summarize (p_project_id in number) return varchar2;',
'end sp_log;',
'/',
'',
'create or replace package body sp_log ',
'as  ',
'procedure log_interaction (',
'    p_project_id in number) ',
'is',
'    l_action varchar2(50) := null;',
'    l_page   number := to_number(v(''APP_PAGE_ID''));',
'begin ',
'    --',
'    -- determine action based on page',
'    --',
'    if    l_page = 3  then l_action := ''detail view''; ',
'    elsif l_page = 24 then l_action := ''edit'';',
'    elsif l_page = 28 then l_action := ''edit comment'';',
'    elsif l_page = 32 then l_action := ''edit description'';',
'    elsif l_page = 9  then l_action := ''edit contributor'';',
'    elsif l_page = 26 then l_action := ''edit todo'';',
'    elsif l_page = 11 then l_action := ''edit review'';',
'    elsif l_page = 6  then l_action := ''edit link'';',
'    elsif l_page = 12 then l_action := ''add/edit document'';',
'    elsif l_page = 10 then l_action := ''edit related'';',
'    elsif l_page = 64 then l_action := ''view change history'';',
'    elsif l_page = 56 then l_action := ''map contributors'';',
'    elsif l_page = 57 then l_action := ''add people from comments'';',
'    elsif l_page = 49 then l_action := ''duplicate'';',
'    elsif l_page = 47 then l_action := ''archive'';',
'    elsif l_page = 33 then l_action := ''clone'';',
'    else                   l_action := ''unknown'';',
'    end if;',
'',
'    --',
'    -- log project interaction',
'    --',
'    insert into sp_proj_interactions_log (project_id, app_page, action) values (p_project_id, l_page, l_action);',
'end log_interaction;',
'',
'function log_and_summarize (',
'    p_project_id in number) ',
'    return varchar2',
'is ',
'    l_return varchar2(50) := null;',
'begin  ',
'    --',
'    -- log interaction',
'    --',
'    log_interaction(',
'        p_project_id => p_project_id);',
'    --',
'    -- return interaction summary',
'    --',
'    for c1 in (select count(*) c, count(distinct(app_user)) u from sp_proj_interactions_log where project_id = p_project_id) loop ',
'        l_return := trim(to_char(c1.c,''999G999G999G990''));',
'        if c1.c = 1 then  ',
'            l_return := l_return||'' interaction by ''||trim(to_char(c1.u,''999G999G999G990''));',
'        else ',
'            l_return := l_return||'' interactions by ''||trim(to_char(c1.u,''999G999G999G990''));',
'        end if;',
'        if c1.u = 1 then ',
'            l_return := l_return ||'' user'';',
'        else ',
'            l_return := l_return ||'' users'';',
'        end if;',
'    end loop;',
'    return l_return;',
'end log_and_summarize;',
'end sp_log;',
'/',
'',
'',
''))
);
wwv_flow_imp.component_end;
end;
/
