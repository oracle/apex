prompt --application/deployment/install/install_ai_summary_tables
begin
--   Manifest
--     INSTALL: INSTALL-ai summary tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_project_ai_summaries ('||wwv_flow.LF||
'   id                 number  default on null to_number(sys_g';
wwv_flow_imp.g_varchar2_table(2) := 'uid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                          constraint sp_project_ai_summa';
wwv_flow_imp.g_varchar2_table(3) := 'ries_pk primary key,'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   project_id         number constraint sp_project_ai_summaries_proj_fk'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(4) := '                                  references sp_projects on delete cascade,'||wwv_flow.LF||
'   summary_type       va';
wwv_flow_imp.g_varchar2_table(5) := 'rchar2(30),  -- full or update'||wwv_flow.LF||
'   prompt_sent        clob, '||wwv_flow.LF||
'   details_sent       clob,'||wwv_flow.LF||
'   data_rece';
wwv_flow_imp.g_varchar2_table(6) := 'ived      clob,'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   summary            clob,'||wwv_flow.LF||
'   risk               varchar2(100),'||wwv_flow.LF||
'   highlights';
wwv_flow_imp.g_varchar2_table(7) := '         varchar2(4000),'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   created            date  default on null sysdate'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create in';
wwv_flow_imp.g_varchar2_table(8) := 'dex sp_project_ai_summaries_i1 on sp_project_ai_summaries (project_id);'||wwv_flow.LF||
'create index sp_project_ai_s';
wwv_flow_imp.g_varchar2_table(9) := 'ummaries_i2 on sp_project_ai_summaries (created);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_release_ai_summaries ('||wwv_flow.LF||
'   id    ';
wwv_flow_imp.g_varchar2_table(10) := '             number  default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(11) := '                      constraint sp_release_ai_summaries_pk primary key,'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   release_id        ';
wwv_flow_imp.g_varchar2_table(12) := ' number constraint sp_release_ai_summaries_rel_fk'||wwv_flow.LF||
'                                   references sp_r';
wwv_flow_imp.g_varchar2_table(13) := 'elease_trains on delete cascade,'||wwv_flow.LF||
'   prompt_sent        clob, '||wwv_flow.LF||
'   details_sent       clob,'||wwv_flow.LF||
'   data_re';
wwv_flow_imp.g_varchar2_table(14) := 'ceived      clob,'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   summary            clob,'||wwv_flow.LF||
'   highlights         varchar2(4000),'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   c';
wwv_flow_imp.g_varchar2_table(15) := 'reated            date  default on null sysdate'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_release_ai_summaries_i1 on s';
wwv_flow_imp.g_varchar2_table(16) := 'p_release_ai_summaries (release_id);'||wwv_flow.LF||
'create index sp_release_ai_summaries_i2 on sp_release_ai_summar';
wwv_flow_imp.g_varchar2_table(17) := 'ies (created);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(31602680070441914502)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'ai summary tables'
,p_sequence=>735
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
