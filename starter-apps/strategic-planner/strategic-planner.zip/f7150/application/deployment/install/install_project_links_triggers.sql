prompt --application/deployment/install/install_project_links_triggers
begin
--   Manifest
--     INSTALL: INSTALL-project links triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_project_links_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_project_links'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(2) := '   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new.created_by';
wwv_flow_imp.g_varchar2_table(3) := ' := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(4) := '    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch pa';
wwv_flow_imp.g_varchar2_table(5) := 'rent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_projects set updated = sysdate, updated_by = :new.updated_by where i';
wwv_flow_imp.g_varchar2_table(6) := 'd = :new.project_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'       if :new.project_id is';
wwv_flow_imp.g_varchar2_table(7) := ' not null then'||wwv_flow.LF||
'           insert into sp_project_history'||wwv_flow.LF||
'               (project_id, attribute_colum';
wwv_flow_imp.g_varchar2_table(8) := 'n, change_type, new_value, changed_on, changed_by)'||wwv_flow.LF||
'           values'||wwv_flow.LF||
'               (:new.project_id';
wwv_flow_imp.g_varchar2_table(9) := ', ''LINK'', ''CREATE'', :new.link_url, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'       elsif updating then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(10) := '      if not sp_value_compare.is_equal(:old.link_url,:new.link_url) then'||wwv_flow.LF||
'              insert into s';
wwv_flow_imp.g_varchar2_table(11) := 'p_project_history'||wwv_flow.LF||
'                  (project_id, attribute_column, change_type, old_value, new_value';
wwv_flow_imp.g_varchar2_table(12) := ',changed_on, changed_by)'||wwv_flow.LF||
'              values'||wwv_flow.LF||
'                  (:new.project_id, ''LINK'', ''UPDATE'', ';
wwv_flow_imp.g_varchar2_table(13) := ':old.link_url, :new.link_url, sysdate, lower(:new.updated_by));'||wwv_flow.LF||
'          end if;'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(14) := ' end if;'||wwv_flow.LF||
'end sp_project_links_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_project_links_bd'||wwv_flow.LF||
'    before delet';
wwv_flow_imp.g_varchar2_table(15) := 'e'||wwv_flow.LF||
'    on sp_project_links'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :old.project_id is not null then'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(16) := '        -- touch parent table'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        update sp_projects set updated = sysdate, updated_b';
wwv_flow_imp.g_varchar2_table(17) := 'y = :old.updated_by where id = :old.project_id;'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        insert into sp_project_history'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(18) := '          (project_id, attribute_column, change_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'        val';
wwv_flow_imp.g_varchar2_table(19) := 'ues'||wwv_flow.LF||
'            (:old.project_id, ''LINK'', ''DELETE'', :old.link_url, sysdate, lower(coalesce(sys_conte';
wwv_flow_imp.g_varchar2_table(20) := 'xt(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_project_links_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38224458835426696105)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'project links triggers'
,p_sequence=>500
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
