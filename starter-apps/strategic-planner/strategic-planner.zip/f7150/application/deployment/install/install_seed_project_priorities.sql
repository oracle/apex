prompt --application/deployment/install/install_seed_project_priorities
begin
--   Manifest
--     INSTALL: INSTALL-seed project priorities
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(113804386844795074738)
,p_install_id=>wwv_flow_imp.id(141180564419272860082)
,p_name=>'seed project priorities'
,p_sequence=>1070
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into sp_project_priorities (id, priority, description, IS_DEFAULT_YN) values (1,1, ''P1 - Highest'',''N'');',
'insert into sp_project_priorities (id, priority, description, IS_DEFAULT_YN) values (2,2, ''P2 - High (Critical)'',''N'');',
'insert into sp_project_priorities (id, priority, description, IS_DEFAULT_YN) values (3,3, ''P3 - Medium'',''N'');',
'insert into sp_project_priorities (id, priority, description, IS_DEFAULT_YN) values (4,4, ''P4 - Low'',''N'');',
'insert into sp_project_priorities (id, priority, description, IS_DEFAULT_YN) values (5,5, ''P5 - Not Prioritized'',''Y'');',
'',
'',
'',
''))
);
wwv_flow_imp.component_end;
end;
/
