prompt --application/deployment/install/install_sp_project_statuses_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_project_statuses table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_project_statuses ('||wwv_flow.LF||
'    id                             number default on null to_numb';
wwv_flow_imp.g_varchar2_table(2) := 'er(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp';
wwv_flow_imp.g_varchar2_table(3) := '_project_statuses_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    status                         varchar2(100 char) not n';
wwv_flow_imp.g_varchar2_table(4) := 'ull,'||wwv_flow.LF||
'    static_id                      varchar2(30 char) not null,'||wwv_flow.LF||
'    display_seq                 ';
wwv_flow_imp.g_varchar2_table(5) := '   number,'||wwv_flow.LF||
'    include_yn                     varchar2(1 char) '||wwv_flow.LF||
'                                   d';
wwv_flow_imp.g_varchar2_table(6) := 'efault on null ''Y'''||wwv_flow.LF||
'                                   constraint sp_project_statuses_include_cc '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(7) := '                                check (include_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                 ';
wwv_flow_imp.g_varchar2_table(8) := '       date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated   ';
wwv_flow_imp.g_varchar2_table(9) := '                     date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
')';
wwv_flow_imp.g_varchar2_table(10) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index sp_project_statuses_u1 on sp_project_statuses (status);'||wwv_flow.LF||
'create unique index s';
wwv_flow_imp.g_varchar2_table(11) := 'p_project_statuses_u2 on sp_project_statuses (static_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_project_stat';
wwv_flow_imp.g_varchar2_table(12) := 'uses_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_project_statuses'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if insert';
wwv_flow_imp.g_varchar2_table(13) := 'ing then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESS';
wwv_flow_imp.g_varchar2_table(14) := 'ION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys';
wwv_flow_imp.g_varchar2_table(15) := '_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.static_id := upper(:new.static_id);'||wwv_flow.LF||
'end s';
wwv_flow_imp.g_varchar2_table(16) := 'p_project_statuses_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(53091262608071531342)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_project_statuses table'
,p_sequence=>215
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
