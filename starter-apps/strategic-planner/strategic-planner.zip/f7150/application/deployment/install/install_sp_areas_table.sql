prompt --application/deployment/install/install_sp_areas_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_areas table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_areas ('||wwv_flow.LF||
'    id                             number default on null to_number(sys_guid';
wwv_flow_imp.g_varchar2_table(2) := '(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_areas_id_p';
wwv_flow_imp.g_varchar2_table(3) := 'k primary key,'||wwv_flow.LF||
'    area                           varchar2(50 char) not null,'||wwv_flow.LF||
'    description       ';
wwv_flow_imp.g_varchar2_table(4) := '             varchar2(4000 char),'||wwv_flow.LF||
'    owner_id                       number'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(5) := '           constraint sp_areas_owner_fk'||wwv_flow.LF||
'                                   references sp_team_member';
wwv_flow_imp.g_varchar2_table(6) := 's on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    status_scale varchar2(1)       check (status_scale in (''A'',''B'',''C'',''';
wwv_flow_imp.g_varchar2_table(7) := 'D'',''E'',''F'',''G'')),'||wwv_flow.LF||
'    hidden_by_default_yn           varchar2(1 char),'||wwv_flow.LF||
'    tags                     ';
wwv_flow_imp.g_varchar2_table(8) := '      varchar2(4000 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    image                          blob,'||wwv_flow.LF||
'    image_name           ';
wwv_flow_imp.g_varchar2_table(9) := '          varchar2(512 char),'||wwv_flow.LF||
'    image_mimetype                 varchar2(512 char),'||wwv_flow.LF||
'    image_last_';
wwv_flow_imp.g_varchar2_table(10) := 'updated             date,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by   ';
wwv_flow_imp.g_varchar2_table(11) := '                  varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(12) := ' updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_areas_i1 on sp_area';
wwv_flow_imp.g_varchar2_table(13) := 's (owner_id);'||wwv_flow.LF||
'create unique index sp_areas_u1 on sp_areas (area);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38666446561248724477)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_areas table'
,p_sequence=>170
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
