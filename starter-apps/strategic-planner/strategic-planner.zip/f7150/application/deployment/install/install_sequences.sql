prompt --application/deployment/install/install_sequences
begin
--   Manifest
--     INSTALL: INSTALL-Sequences
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create sequence SP_SEQ;'||wwv_flow.LF||
''||wwv_flow.LF||
'create sequence sp_kb_stack_rank_seq'||wwv_flow.LF||
'start with 1'||wwv_flow.LF||
'increment by 1'||wwv_flow.LF||
'cache 20'||wwv_flow.LF||
'n';
wwv_flow_imp.g_varchar2_table(2) := 'ocycle;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(48835401215011553487)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'Sequences'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
