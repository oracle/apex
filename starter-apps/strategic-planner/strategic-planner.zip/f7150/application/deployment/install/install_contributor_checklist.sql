prompt --application/deployment/install/install_contributor_checklist
begin
--   Manifest
--     INSTALL: INSTALL-contributor checklist
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>19055477148803894
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3503272084137066569)
,p_install_id=>wwv_flow_imp.id(141234962960674597981)
,p_name=>'contributor checklist'
,p_sequence=>720
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  CREATE TABLE SP_CONTRIBUTOR_CHECKLIST ',
'   (',
'    ID NUMBER DEFAULT ON NULL to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') NOT NULL ENABLE, ',
'	DISPLAY_SEQUENCE            NUMBER DEFAULT 1, ',
'	CHECKLIST_ACTIVITY          VARCHAR2(255 CHAR) NOT NULL ENABLE, ',
'	WHY_IMPORTANT               VARCHAR2(500 CHAR), ',
'	HOW_TO_CHECK                VARCHAR2(500 CHAR), ',
'	LINK_TO_PAGE                NUMBER, ',
'	CREATED                     DATE NOT NULL ENABLE, ',
'	CREATED_BY                  VARCHAR2(255 CHAR) NOT NULL ENABLE, ',
'	UPDATED                     DATE NOT NULL ENABLE, ',
'	UPDATED_BY                  VARCHAR2(255 CHAR) NOT NULL ENABLE, ',
'	ACTIVE_YN                   VARCHAR2(1 CHAR), ',
'    BUILD_OPTION_NAME           varchar2(128 char),',
'	 CONSTRAINT SP_CONTRIBUTOR_CHECKLIST_PK PRIMARY KEY (ID)',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'  CREATE OR REPLACE EDITIONABLE TRIGGER SP_CONTRIBUTOR_CHECKLIST_BIU ',
'    before insert or update',
'    on sp_contributor_checklist',
'    for each row',
'begin',
'    if inserting then',
'        :new.created := sysdate;',
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'    end if;',
'    :new.updated := sysdate;',
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'end sp_contributor_checklist_biu;',
'/',
'',
'ALTER TRIGGER SP_CONTRIBUTOR_CHECKLIST_BIU ENABLE;'))
);
wwv_flow_imp.component_end;
end;
/
