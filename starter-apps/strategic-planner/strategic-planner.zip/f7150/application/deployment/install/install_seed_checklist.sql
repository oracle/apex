prompt --application/deployment/install/install_seed_checklist
begin
--   Manifest
--     INSTALL: INSTALL-seed checklist
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16834805079422672029)
,p_install_id=>wwv_flow_imp.id(141188953139974000425)
,p_name=>'seed checklist'
,p_sequence=>1100
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into SP_CONTRIBUTOR_CHECKLIST (ID, display_sequence, checklist_activity, why_important, how_to_check, active_yn, link_to_page) values (1, 1, ''My current activities have been recorded (typically in 2 week chunks)'', ''Software development is a te'
||'am effort. Awareness and coordination of resources is important. What you are doing now (in + or - 2 week windows) is the most accurate definition of #NOMENCLATURE_PROJECT#. Date targets frequently reflect aspiration. Current activity reflects the re'
||'ality.'', ''Navigate to the home page then click "View My Projects", click project, click "Activities" tab. Alternately navigate to the home page and click "My Current Activities" and edit or edit as needed.'', ''Y'', 112);',
'insert into SP_CONTRIBUTOR_CHECKLIST (ID, display_sequence, checklist_activity, why_important, how_to_check, active_yn, link_to_page) values (2, 2, ''My association with #NOMENCLATURE_PROJECTS# is up to date'', ''Knowing who and how contributors are ass'
||'ociated with a given #NOMENCLATURE_PROJECT# facilitates better prioritization and planning. Having a clear list of projects assigned can be helpful in prioritizing work.'', ''Navigate to the home page then click "View My #NOMENCLATURE_PROJECTS#". Find '
||'the #NOMENCLATURE_PROJECT# you are associated with and click on the title. Click the "Contributors" tab to associate yourself as a contributor. Click the "Reviewers" tab to associate yourself as a reviewer. Edit the #NOMENCLATURE_PROJECT# and identif'
||'y yourself as the owner of the #NOMENCLATURE_PROJECT# if in fact you are the person most responsible for delivery. Add a new #NOMENCLATURE_PROJECT# if needed.'', ''Y'', 113);',
'insert into SP_CONTRIBUTOR_CHECKLIST (ID, display_sequence, checklist_activity, why_important, how_to_check, active_yn, link_to_page) values (3, 3, ''Projects that I am leading have a clear motivation'', ''Defining the motivation for a given project is '
||'an effective way to express priority.'', ''Navigate to the home page then click "View My Projects", click project, click "Description" tab'', ''Y'', 113);',
'insert into SP_CONTRIBUTOR_CHECKLIST (ID, display_sequence, checklist_activity, why_important, how_to_check, active_yn, link_to_page) values (4, 4, ''My #NOMENCLATURE_PROJECT# milestones are up to date, pay specific attention to #NOMENCLATURE_PROJECTS'
||'# associated with releases'', ''Projects milestones are determined by the status scale selected for the Initiative. Most used are for software development and include spec complete, demonstrable, code complete and merged.'', ''Navigate to the home page t'
||'hen click "View My Projects", click project, click "Dates" tab.'', ''Y'', 113);',
'insert into SP_CONTRIBUTOR_CHECKLIST (ID, display_sequence, checklist_activity, why_important, how_to_check, active_yn, link_to_page) values (5, 5, ''I have recorded relevant project comments, links and documents'', ''Comments can reflect progress, can '
||'share interesting information, and can better facilitate understanding of the projects evolution from concept to reality. Links aid others in researching the project. And documents can provide screen shots, presentations and other types of documents.'
||' All aid in information sharing.'', ''Navigate to the home page then click "View My Projects", click project, click "Comments" or "Links" or "Documents" tab'', ''Y'', 113);'))
);
wwv_flow_imp.component_end;
end;
/
