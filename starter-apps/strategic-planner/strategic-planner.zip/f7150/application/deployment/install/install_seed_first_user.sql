prompt --application/deployment/install/install_seed_first_user
begin
--   Manifest
--     INSTALL: INSTALL-seed first user
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'declare'||wwv_flow.LF||
'    l_app_user  varchar2(255) := apex_custom_auth.get_username;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- get emai';
wwv_flow_imp.g_varchar2_table(2) := 'l of developer installing the app'||wwv_flow.LF||
'    -- if no email, see if app_user is an email'||wwv_flow.LF||
'    -- (first auto';
wwv_flow_imp.g_varchar2_table(3) := 'nomous user may not have an email)'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for u in ('||wwv_flow.LF||
'        select first_name, last_name,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(4) := '          case when email is null and regexp_like(l_app_user,''[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}';
wwv_flow_imp.g_varchar2_table(5) := ''')'||wwv_flow.LF||
'                    then l_app_user'||wwv_flow.LF||
'                    else email'||wwv_flow.LF||
'                    end email'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(6) := '          from apex_workspace_apex_users'||wwv_flow.LF||
'         where user_name = l_app_user'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'      if u';
wwv_flow_imp.g_varchar2_table(7) := '.email is not null then'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        -- most recent install of Strategic Planner'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(8) := '      for a in ('||wwv_flow.LF||
'            select application_id'||wwv_flow.LF||
'              from apex_applications'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(9) := ' where application_name = ''Strategic Planner'''||wwv_flow.LF||
'             order by last_updated_on desc'||wwv_flow.LF||
'        ) l';
wwv_flow_imp.g_varchar2_table(10) := 'oop'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            -- determine admin app role id'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            for r in ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(11) := '                select role_id'||wwv_flow.LF||
'                  from apex_appl_acl_roles'||wwv_flow.LF||
'                 where app';
wwv_flow_imp.g_varchar2_table(12) := 'lication_id = a.application_id '||wwv_flow.LF||
'                   and role_static_id = ''ADMINISTRATOR'''||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(13) := ') loop'||wwv_flow.LF||
'                --'||wwv_flow.LF||
'                -- make installer an app admin'||wwv_flow.LF||
'                --'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(14) := '        apex_acl.add_user_role ('||wwv_flow.LF||
'            	    p_application_id => a.application_id,'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(15) := '	    p_user_name      => u.email,'||wwv_flow.LF||
'           	    p_role_id        => r.role_id );'||wwv_flow.LF||
'                c';
wwv_flow_imp.g_varchar2_table(16) := 'ommit;'||wwv_flow.LF||
'                --'||wwv_flow.LF||
'                -- also add this first user as a Team Member'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(17) := '   --'||wwv_flow.LF||
'                insert into SP_TEAM_MEMBERS '||wwv_flow.LF||
'                    (email, first_name, last_name';
wwv_flow_imp.g_varchar2_table(18) := ') '||wwv_flow.LF||
'                values '||wwv_flow.LF||
'                    (u.email, u.first_name, u.last_name);'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(19) := ' commit;'||wwv_flow.LF||
'                exit;'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'            exit;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'      end i';
wwv_flow_imp.g_varchar2_table(20) := 'f;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(47697610704689532526)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed first user'
,p_sequence=>920
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
