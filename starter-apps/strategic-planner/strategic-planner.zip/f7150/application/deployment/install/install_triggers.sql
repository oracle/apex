prompt --application/deployment/install/install_triggers
begin
--   Manifest
--     INSTALL: INSTALL-triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- simple triggers'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_project_sizes_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(2) := ' on sp_project_sizes'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(3) := '       :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :ne';
wwv_flow_imp.g_varchar2_table(4) := 'w.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(5) := '    if :new.include_yn is null then'||wwv_flow.LF||
'       :new.include_yn := ''Y'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_project_sizes_';
wwv_flow_imp.g_varchar2_table(6) := 'biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger SP_DEFAULT_TAGS_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on SP_DEFAULT';
wwv_flow_imp.g_varchar2_table(7) := '_TAGS'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new.cre';
wwv_flow_imp.g_varchar2_table(8) := 'ated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sy';
wwv_flow_imp.g_varchar2_table(9) := 'sdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    :new.tag :=';
wwv_flow_imp.g_varchar2_table(10) := ' upper(:new.tag);'||wwv_flow.LF||
'end SP_DEFAULT_TAGS_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger SP_APP_NOMENCLATURE_biu'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(11) := 'before insert or update'||wwv_flow.LF||
'    on SP_APP_NOMENCLATURE'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(12) := '    :new.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USE';
wwv_flow_imp.g_varchar2_table(13) := 'R''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APE';
wwv_flow_imp.g_varchar2_table(14) := 'X$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    :new.static_id := upper(:new.static_id);'||wwv_flow.LF||
'end SP_APP_NOMENCLATURE_b';
wwv_flow_imp.g_varchar2_table(15) := 'iu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_project_priorities_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_pro';
wwv_flow_imp.g_varchar2_table(16) := 'ject_priorities'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(17) := '  :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.upd';
wwv_flow_imp.g_varchar2_table(18) := 'ated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'end s';
wwv_flow_imp.g_varchar2_table(19) := 'p_project_priorities_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_resource_types_biu'||wwv_flow.LF||
'    before insert o';
wwv_flow_imp.g_varchar2_table(20) := 'r update'||wwv_flow.LF||
'    on sp_resource_types'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created ';
wwv_flow_imp.g_varchar2_table(21) := ':= sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    en';
wwv_flow_imp.g_varchar2_table(22) := 'd if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_U';
wwv_flow_imp.g_varchar2_table(23) := 'SER''),user);'||wwv_flow.LF||
'    :new.upper_resource_type := upper(:new.resource_type);'||wwv_flow.LF||
'end sp_resource_types_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp.g_varchar2_table(24) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_project_scales_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_project_scal';
wwv_flow_imp.g_varchar2_table(25) := 'es'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new.create';
wwv_flow_imp.g_varchar2_table(26) := 'd_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysda';
wwv_flow_imp.g_varchar2_table(27) := 'te;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'end sp_project_sca';
wwv_flow_imp.g_varchar2_table(28) := 'les_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(148852711392936538371)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'triggers'
,p_sequence=>350
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
