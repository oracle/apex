prompt --application/deployment/install/install_seed_default_tags
begin
--   Manifest
--     INSTALL: INSTALL-seed default tags
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into SP_DEFAULT_TAGS (ID, DISPLAY_SEQUENCE, TAG) values (1, 10, ''COMMITTED'');'||wwv_flow.LF||
'insert into SP_';
wwv_flow_imp.g_varchar2_table(2) := 'DEFAULT_TAGS (ID, DISPLAY_SEQUENCE, TAG) values (2, 20, ''MVP'');'||wwv_flow.LF||
'insert into SP_DEFAULT_TAGS (ID, DIS';
wwv_flow_imp.g_varchar2_table(3) := 'PLAY_SEQUENCE, TAG) values (3, 30, ''URGENT'');'||wwv_flow.LF||
'insert into SP_DEFAULT_TAGS (ID, DISPLAY_SEQUENCE, TAG';
wwv_flow_imp.g_varchar2_table(4) := ') values (4, 40, ''CUSTOMER FACING'');'||wwv_flow.LF||
'insert into SP_DEFAULT_TAGS (ID, DISPLAY_SEQUENCE, TAG) values ';
wwv_flow_imp.g_varchar2_table(5) := '(5, 50, ''NEEDS REVIEW'');'||wwv_flow.LF||
'insert into SP_DEFAULT_TAGS (ID, DISPLAY_SEQUENCE, TAG) values (6, 60, ''IMP';
wwv_flow_imp.g_varchar2_table(6) := 'ORTANT'');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(46924437377495250186)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed default tags'
,p_sequence=>820
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
