prompt --application/deployment/install/install_sp_team_members_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_team_members table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_team_members ('||wwv_flow.LF||
'    id                             number default on null to_number(s';
wwv_flow_imp.g_varchar2_table(2) := 'ys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_tea';
wwv_flow_imp.g_varchar2_table(3) := 'm_members_id_pk primary key,'||wwv_flow.LF||
'    first_name                     varchar2(255 char) not null,'||wwv_flow.LF||
'    las';
wwv_flow_imp.g_varchar2_table(4) := 't_name                      varchar2(255 char) not null,'||wwv_flow.LF||
'    initials                       varchar2';
wwv_flow_imp.g_varchar2_table(5) := '(3 char)   not null,'||wwv_flow.LF||
'    screen_name                    varchar2(50 char),'||wwv_flow.LF||
'    email                ';
wwv_flow_imp.g_varchar2_table(6) := '          varchar2(255 char) not null,'||wwv_flow.LF||
'    email_domain                   varchar2(255 char),'||wwv_flow.LF||
'    no';
wwv_flow_imp.g_varchar2_table(7) := 'tification_pref              varchar2(255 char), -- colon separated list of APP, EMAIL, TEXT, SLACK'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(8) := '    comment_notif_pref             varchar2(255 char), -- colon separated list of APP, EMAIL, TEXT, ';
wwv_flow_imp.g_varchar2_table(9) := 'SLACK'||wwv_flow.LF||
'    tags                           varchar2(4000 char),'||wwv_flow.LF||
'    hash_tag_reference             var';
wwv_flow_imp.g_varchar2_table(10) := 'char2(30 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    photo                          blob,'||wwv_flow.LF||
'    photo_filename                 v';
wwv_flow_imp.g_varchar2_table(11) := 'archar2(512 char),'||wwv_flow.LF||
'    photo_mimetype                 varchar2(512 char),'||wwv_flow.LF||
'    photo_charset         ';
wwv_flow_imp.g_varchar2_table(12) := '         varchar2(512 char),'||wwv_flow.LF||
'    photo_lastupd                  date,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    is_current_yn      ';
wwv_flow_imp.g_varchar2_table(13) := '            varchar2(1 char) constraint sp_team_members_is_current_ck'||wwv_flow.LF||
'                              ';
wwv_flow_imp.g_varchar2_table(14) := '     check (is_current_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    auto_created_yn                varchar2(1 char) constra';
wwv_flow_imp.g_varchar2_table(15) := 'int sp_team_members_auto_cr_ck'||wwv_flow.LF||
'                                   check (auto_created_yn in (''Y'',''N''';
wwv_flow_imp.g_varchar2_table(16) := ')),'||wwv_flow.LF||
'    location                       varchar2(500 char),'||wwv_flow.LF||
'    country_id                     number';
wwv_flow_imp.g_varchar2_table(17) := ','||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    app_role                       varchar2(255 char), -- derived'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    competencies  ';
wwv_flow_imp.g_varchar2_table(18) := '                 varchar2(4000 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- audit columns'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                ';
wwv_flow_imp.g_varchar2_table(19) := '        date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated  ';
wwv_flow_imp.g_varchar2_table(20) := '                      date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(21) := ')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index sp_team_members_u1 on sp_team_members (email);'||wwv_flow.LF||
'create unique index sp_team_';
wwv_flow_imp.g_varchar2_table(22) := 'members_u2 on sp_team_members (hash_tag_reference);'||wwv_flow.LF||
'create unique index sp_team_members_u4 on sp_tea';
wwv_flow_imp.g_varchar2_table(23) := 'm_members (screen_name);'||wwv_flow.LF||
'create index sp_team_members_i1 on sp_team_members (country_id);'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38666281374522346821)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_team_members table'
,p_sequence=>130
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
