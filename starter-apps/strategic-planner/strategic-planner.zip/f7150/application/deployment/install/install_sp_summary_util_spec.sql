prompt --application/deployment/install/install_sp_summary_util_spec
begin
--   Manifest
--     INSTALL: INSTALL-sp_summary_util spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package sp_summary_util as'||wwv_flow.LF||
''||wwv_flow.LF||
'g_hrs_to_replace  number := 6;'||wwv_flow.LF||
''||wwv_flow.LF||
'function ai_summary_in';
wwv_flow_imp.g_varchar2_table(2) := 'fo ('||wwv_flow.LF||
'    p_type  in  varchar2 )'||wwv_flow.LF||
'    return clob;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- can be run from APEX App UI (not SQL Commands) ';
wwv_flow_imp.g_varchar2_table(3) := ''||wwv_flow.LF||
'--  or from within a job (if session context is set)'||wwv_flow.LF||
'procedure generate_project_summary ('||wwv_flow.LF||
'    p_pro';
wwv_flow_imp.g_varchar2_table(4) := 'ject_id    in   number,'||wwv_flow.LF||
'    p_summary_type  in   varchar2,'||wwv_flow.LF||
'    p_ai_id         out  number,'||wwv_flow.LF||
'    p_er';
wwv_flow_imp.g_varchar2_table(5) := 'ror_yn      out  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'-- run as a job, once a week (cannot be run via SQL Commands)'||wwv_flow.LF||
'procedur';
wwv_flow_imp.g_varchar2_table(6) := 'e generate_project_summaries;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- TEMP - WILL BE REMOVED'||wwv_flow.LF||
'procedure summarize_release ('||wwv_flow.LF||
'    p_release';
wwv_flow_imp.g_varchar2_table(7) := '_id  in   number,'||wwv_flow.LF||
'    p_summary     out  clob );'||wwv_flow.LF||
''||wwv_flow.LF||
'-- can be run from APEX App UI (not SQL Commands) ';
wwv_flow_imp.g_varchar2_table(8) := 'or from within a job (if session context is set)'||wwv_flow.LF||
'procedure generate_release_summary ('||wwv_flow.LF||
'    p_release_';
wwv_flow_imp.g_varchar2_table(9) := 'id    in   number,'||wwv_flow.LF||
'    p_error_yn      out  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_summary_util;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(27818825302399250916)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_summary_util spec'
,p_sequence=>57
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
