prompt --application/deployment/install/install_focus_areas_table
begin
--   Manifest
--     INSTALL: INSTALL-focus areas table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>26954343551793662
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3661320390149253958)
,p_install_id=>wwv_flow_imp.id(141215907483525794087)
,p_name=>'focus areas table'
,p_sequence=>160
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table sp_focus_areas (',
'    id                             number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') ',
'                                   constraint sp_focus_areas_id_pk primary key,',
'    focus_area                     varchar2(50 char) not null,',
'    description                    varchar2(4000 char),',
'    owner_ID                       number',
'                                   constraint sp_focus_areas_owner_fk',
'                                   references sp_team_members on delete cascade,',
'    --',
'    perma_link                     varchar2(4000 char),',
'    status_scale varchar2(1)       check (status_scale in (''A'',''B'',''C'',''D'',''E'',''F'',''G'')),',
'    hidden_by_default_yn           varchar2(1 char),',
'    tags                           varchar2(4000 char),',
'    --',
'    image                          blob,',
'    image_name                     varchar2(512 char),',
'    image_mimetype                 varchar2(512 char),',
'    image_last_updated             date,',
'    --',
'    created                        date not null,',
'    created_by                     varchar2(255 char) not null,',
'    updated                        date not null,',
'    updated_by                     varchar2(255 char) not null',
')',
';',
'',
'create index sp_focus_areas_i1 on sp_focus_areas (owner_id);',
'create unique index sp_focus_areas_u1 on sp_focus_areas (focus_area);'))
);
wwv_flow_imp.component_end;
end;
/
