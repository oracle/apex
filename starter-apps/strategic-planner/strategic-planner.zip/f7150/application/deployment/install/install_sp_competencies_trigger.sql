prompt --application/deployment/install/install_sp_competencies_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_competencies trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(12893049591461899515)
,p_install_id=>wwv_flow_imp.id(141180564419272860082)
,p_name=>'sp_competencies trigger'
,p_sequence=>420
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace trigger sp_competencies_biu',
'    before insert or update',
'    on sp_competencies',
'    for each row',
'begin',
'    if inserting then',
'        :new.created := sysdate;',
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'    end if;',
'    :new.updated := sysdate;',
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'end sp_competencies_biu;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
