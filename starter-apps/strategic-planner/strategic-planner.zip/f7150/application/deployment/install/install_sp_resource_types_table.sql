prompt --application/deployment/install/install_sp_resource_types_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_resource_types table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_resource_types ('||wwv_flow.LF||
'    id                             number default on null to_number';
wwv_flow_imp.g_varchar2_table(2) := '(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_r';
wwv_flow_imp.g_varchar2_table(3) := 'esource_types_id_pk primary key,'||wwv_flow.LF||
'    resource_type                  varchar2(50 char) not null,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(4) := 'upper_resource_type            varchar2(50 char) not null,'||wwv_flow.LF||
'    resource_description           varcha';
wwv_flow_imp.g_varchar2_table(5) := 'r2(4000 char),'||wwv_flow.LF||
'    is_default_yn                  varchar2(1 char)'||wwv_flow.LF||
'                                 ';
wwv_flow_imp.g_varchar2_table(6) := '  constraint sp_res_t_is_default_ck '||wwv_flow.LF||
'                                   check (is_default_yn in (''Y''';
wwv_flow_imp.g_varchar2_table(7) := ',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by                     ';
wwv_flow_imp.g_varchar2_table(8) := 'varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by       ';
wwv_flow_imp.g_varchar2_table(9) := '              varchar2(255 char) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index sp_resource_types_u1 on sp_resour';
wwv_flow_imp.g_varchar2_table(10) := 'ce_types (resource_type);'||wwv_flow.LF||
'create unique index sp_resource_types_u2 on sp_resource_types (upper_resou';
wwv_flow_imp.g_varchar2_table(11) := 'rce_type);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38666232472587336567)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_resource_types table'
,p_sequence=>100
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
