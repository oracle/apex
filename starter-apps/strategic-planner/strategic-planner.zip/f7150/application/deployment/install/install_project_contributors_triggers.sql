prompt --application/deployment/install/install_project_contributors_triggers
begin
--   Manifest
--     INSTALL: INSTALL-project_contributors triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_project_contributors_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_project_';
wwv_flow_imp.g_varchar2_table(2) := 'contributors'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_old_value   varchar2(4000) := null;'||wwv_flow.LF||
'    l_new_value   va';
wwv_flow_imp.g_varchar2_table(3) := 'rchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new.crea';
wwv_flow_imp.g_varchar2_table(4) := 'ted_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sys';
wwv_flow_imp.g_varchar2_table(5) := 'date;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    :new.tags :=';
wwv_flow_imp.g_varchar2_table(6) := ' trim(upper(:new.tags));'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_projects set updated ';
wwv_flow_imp.g_varchar2_table(7) := '= sysdate, updated_by = :new.updated_by where id = :new.project_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(8) := ' if inserting then'||wwv_flow.LF||
'          for c1 in (select first_name||'' ''||last_name||'' - ''||email x from SP_TE';
wwv_flow_imp.g_varchar2_table(9) := 'AM_MEMBERS t where t.id = :NEW.TEAM_MEMBER_ID) loop l_new_value := c1.x; end loop;'||wwv_flow.LF||
'          for c1 ';
wwv_flow_imp.g_varchar2_table(10) := 'in (select resource_type x from SP_RESOURCE_TYPES t where t.id = :NEW.RESPONSIBILITY_ID) loop l_new_';
wwv_flow_imp.g_varchar2_table(11) := 'value := l_new_value||'' - ''||c1.x; end loop;'||wwv_flow.LF||
'        insert into sp_project_history'||wwv_flow.LF||
'            (pro';
wwv_flow_imp.g_varchar2_table(12) := 'ject_id, attribute_column, change_type, new_value, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(13) := '  (:new.project_id, ''CONTRIBUTOR'', ''CREATE'', l_new_value, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'    elsi';
wwv_flow_imp.g_varchar2_table(14) := 'f updating then'||wwv_flow.LF||
'          for c1 in (select first_name||'' ''||last_name||'' - ''||email x from SP_TEAM_';
wwv_flow_imp.g_varchar2_table(15) := 'MEMBERS t where t.id = :OLD.TEAM_MEMBER_ID) loop l_old_value := c1.x; end loop;'||wwv_flow.LF||
'          for c1 in ';
wwv_flow_imp.g_varchar2_table(16) := '(select first_name||'' ''||last_name||'' - ''||email x from SP_TEAM_MEMBERS t where t.id = :NEW.TEAM_MEM';
wwv_flow_imp.g_varchar2_table(17) := 'BER_ID) loop l_new_value := c1.x; end loop;'||wwv_flow.LF||
'          for c1 in (select resource_type x from SP_RESO';
wwv_flow_imp.g_varchar2_table(18) := 'URCE_TYPES t where t.id = :OLD.RESPONSIBILITY_ID) loop l_old_value := l_old_value||'' - ''||c1.x; end ';
wwv_flow_imp.g_varchar2_table(19) := 'loop;'||wwv_flow.LF||
'          for c1 in (select resource_type x from SP_RESOURCE_TYPES t where t.id = :NEW.RESPONS';
wwv_flow_imp.g_varchar2_table(20) := 'IBILITY_ID) loop l_new_value := l_new_value||'' - ''||c1.x; end loop;'||wwv_flow.LF||
'          --'||wwv_flow.LF||
'          -- only l';
wwv_flow_imp.g_varchar2_table(21) := 'og updates that change values'||wwv_flow.LF||
'          --'||wwv_flow.LF||
'          if nvl(l_old_value,''x'') != nvl(l_new_value,''x'')';
wwv_flow_imp.g_varchar2_table(22) := ' then'||wwv_flow.LF||
'              insert into sp_project_history'||wwv_flow.LF||
'                  (project_id, attribute_column, ';
wwv_flow_imp.g_varchar2_table(23) := 'change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'              values'||wwv_flow.LF||
'                  (:';
wwv_flow_imp.g_varchar2_table(24) := 'new.project_id, ''CONTRIBUTOR'', ''UPDATE'', l_old_value, l_new_value, sysdate, lower(:new.updated_by));';
wwv_flow_imp.g_varchar2_table(25) := ''||wwv_flow.LF||
'          end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_project_contributors_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_pro';
wwv_flow_imp.g_varchar2_table(26) := 'ject_contributors_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_project_contributors'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    v';
wwv_flow_imp.g_varchar2_table(27) := '1   varchar2(255) := null;'||wwv_flow.LF||
'    v2   varchar2(255) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(28) := '  --'||wwv_flow.LF||
'    update sp_projects set updated = sysdate, updated_by = :old.updated_by where id = :old.proj';
wwv_flow_imp.g_varchar2_table(29) := 'ect_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for c1 in (select email from sp_team_members x where x.id = :old.team_member_id) ';
wwv_flow_imp.g_varchar2_table(30) := 'loop'||wwv_flow.LF||
'        v1 := c1.email;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    for c1 in (select resource_type from sp_resource_type';
wwv_flow_imp.g_varchar2_table(31) := 's x where x.id = :old.responsibility_id) loop '||wwv_flow.LF||
'        v2 := c1.resource_type;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    ins';
wwv_flow_imp.g_varchar2_table(32) := 'ert into sp_project_history'||wwv_flow.LF||
'        (project_id, attribute_column, change_type, old_value, changed_o';
wwv_flow_imp.g_varchar2_table(33) := 'n, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.project_id, ''CONTRIBUTOR'', ''DELETE'', v2||'': ''||v1, sysdate, ';
wwv_flow_imp.g_varchar2_table(34) := 'lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'end sp_project_contributors_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(44038547199966599573)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'project_contributors triggers'
,p_sequence=>470
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
