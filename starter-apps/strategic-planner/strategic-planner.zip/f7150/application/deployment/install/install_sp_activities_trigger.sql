prompt --application/deployment/install/install_sp_activities_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_activities trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_activities_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_activities'||wwv_flow.LF||
'    for';
wwv_flow_imp.g_varchar2_table(2) := ' each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_tags varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.create';
wwv_flow_imp.g_varchar2_table(3) := 'd := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(4) := 'end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP';
wwv_flow_imp.g_varchar2_table(5) := '_USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- validations'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.end_date < :new.start_date then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(6) := 'raise_application_error(-20111,''End date must be greater than start date'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(7) := '- adjust tags'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.tags is not null then'||wwv_flow.LF||
'        l_tags := trim(upper(:new.tags));'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(8) := '     -- remove multiple spaces'||wwv_flow.LF||
'        if instr(l_tags,''  '') > 0 then'||wwv_flow.LF||
'            for j in 1..10 loo';
wwv_flow_imp.g_varchar2_table(9) := 'p '||wwv_flow.LF||
'                l_tags := replace(l_tags,''  '','' ''); '||wwv_flow.LF||
'                if instr(l_tags,''  '') = 0 th';
wwv_flow_imp.g_varchar2_table(10) := 'en'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        f';
wwv_flow_imp.g_varchar2_table(11) := 'or i in 1..length(l_tags) loop'||wwv_flow.LF||
'            if i > 2 and substr(l_tags,i,1) = '' '' and substr(l_tags,i';
wwv_flow_imp.g_varchar2_table(12) := '-1,1) != '','' then'||wwv_flow.LF||
'               l_tags := substr(l_tags,1,i-1)||''-''||substr(l_tags,i+1);'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(13) := '  end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        :new.tags := l_tags;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(14) := '--'||wwv_flow.LF||
'    update sp_projects set updated = sysdate, updated_by = :new.updated_by where id = :new.projec';
wwv_flow_imp.g_varchar2_table(15) := 't_id;'||wwv_flow.LF||
'end sp_activities_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(50992170994909531180)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_activities trigger'
,p_sequence=>580
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
