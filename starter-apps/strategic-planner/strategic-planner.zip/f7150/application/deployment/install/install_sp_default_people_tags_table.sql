prompt --application/deployment/install/install_sp_default_people_tags_table
begin
--   Manifest
--     INSTALL: INSTALL-SP_DEFAULT_PEOPLE_TAGS table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table SP_DEFAULT_PEOPLE_TAGS ('||wwv_flow.LF||
'    id                             number default on null to_n';
wwv_flow_imp.g_varchar2_table(2) := 'umber(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint';
wwv_flow_imp.g_varchar2_table(3) := ' SP_DEFAULT_PEOPLE_TAGS_pk primary key,'||wwv_flow.LF||
'    display_sequence               number             not nu';
wwv_flow_imp.g_varchar2_table(4) := 'll,'||wwv_flow.LF||
'    tag                            varchar2(30 char)  not null,'||wwv_flow.LF||
'    description                 ';
wwv_flow_imp.g_varchar2_table(5) := '   varchar2(512 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by      ';
wwv_flow_imp.g_varchar2_table(6) := '               varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    up';
wwv_flow_imp.g_varchar2_table(7) := 'dated_by                     varchar2(255 char) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index SP_DEFAULT_PEOPLE_';
wwv_flow_imp.g_varchar2_table(8) := 'TAGS_u1 on SP_DEFAULT_PEOPLE_TAGS (tag);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(40988789672556621699)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'SP_DEFAULT_PEOPLE_TAGS table'
,p_sequence=>640
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
