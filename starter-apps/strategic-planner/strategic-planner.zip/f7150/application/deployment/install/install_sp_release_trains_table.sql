prompt --application/deployment/install/install_sp_release_trains_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_release_trains table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_release_trains ('||wwv_flow.LF||
'    id                             number default on null to_number';
wwv_flow_imp.g_varchar2_table(2) := '(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_r';
wwv_flow_imp.g_varchar2_table(3) := 'elease_trains_id_pk primary key,'||wwv_flow.LF||
'    release_train                  varchar2(50 char) not null,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(4) := 'release_owner_id               number'||wwv_flow.LF||
'                                   constraint sp_release_train';
wwv_flow_imp.g_varchar2_table(5) := 's_owner_fk'||wwv_flow.LF||
'                                   references sp_team_members,'||wwv_flow.LF||
'    release               ';
wwv_flow_imp.g_varchar2_table(6) := '         varchar2(30 char) not null,'||wwv_flow.LF||
'    release_target_date            date,'||wwv_flow.LF||
'    release_open_date ';
wwv_flow_imp.g_varchar2_table(7) := '             date,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    release_distribution_url       varchar2(4000 char),'||wwv_flow.LF||
'    release_manage';
wwv_flow_imp.g_varchar2_table(8) := 'ment_url         varchar2(4000 char),'||wwv_flow.LF||
'    description                    clob,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    release_op';
wwv_flow_imp.g_varchar2_table(9) := 'en_completed         varchar2(1 char)  default on null ''N'''||wwv_flow.LF||
'                                   constr';
wwv_flow_imp.g_varchar2_table(10) := 'aint sp_release_trains_open_ck'||wwv_flow.LF||
'                                   check (release_open_completed in (';
wwv_flow_imp.g_varchar2_table(11) := '''Y'',''N'')),'||wwv_flow.LF||
'    release_completed              varchar2(1 char)  default on null ''N'''||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(12) := '                   constraint sp_release_trains_completed_ck'||wwv_flow.LF||
'                                   chec';
wwv_flow_imp.g_varchar2_table(13) := 'k (release_completed in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    release_type                   varchar2(50 char)'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(14) := '                               constraint sp_valid_release_type'||wwv_flow.LF||
'                                   c';
wwv_flow_imp.g_varchar2_table(15) := 'heck (release_type in (''FULL'',''PATCH'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(16) := '  created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                        dat';
wwv_flow_imp.g_varchar2_table(17) := 'e not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_rele';
wwv_flow_imp.g_varchar2_table(18) := 'ase_trains_u1 on sp_release_trains (release_owner_id);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38666431824035721106)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_release_trains table'
,p_sequence=>150
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
