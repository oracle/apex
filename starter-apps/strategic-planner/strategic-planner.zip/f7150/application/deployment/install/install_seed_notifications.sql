prompt --application/deployment/install/install_seed_notifications
begin
--   Manifest
--     INSTALL: INSTALL-seed notifications
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into SP_NOTIFICATIONS ( ID, name, static_id, description, is_active_YN ) '||wwv_flow.LF||
'    values (1, ''My ';
wwv_flow_imp.g_varchar2_table(2) := 'Weekly Summary'', ''WEEKLY_SUMMARY'', ''Weekly user projects and activities summary.'',''Y'');'||wwv_flow.LF||
'insert into ';
wwv_flow_imp.g_varchar2_table(3) := 'SP_NOTIFICATIONS ( ID, name, static_id, description, is_active_YN ) '||wwv_flow.LF||
'    values (2, ''Release Excepti';
wwv_flow_imp.g_varchar2_table(4) := 'ons'', ''RELEASE_EXCEPTIONS'', ''Weekly review of exceptions for a selected release.'',''Y'');'||wwv_flow.LF||
'insert into ';
wwv_flow_imp.g_varchar2_table(5) := 'SP_NOTIFICATIONS ( ID, name, static_id, description, is_active_YN ) '||wwv_flow.LF||
'    values (3, ''My Project Exce';
wwv_flow_imp.g_varchar2_table(6) := 'ptions'', ''PROJECT_EXCEPTIONS'', ''Weekly report of exceptions within projects the user is associated w';
wwv_flow_imp.g_varchar2_table(7) := 'ith.'',''Y''); '||wwv_flow.LF||
'insert into SP_NOTIFICATIONS ( ID, name, static_id, description, is_active_YN ) '||wwv_flow.LF||
'    va';
wwv_flow_imp.g_varchar2_table(8) := 'lues (4, ''My Project Changes'', ''PROJECT_CHANGES'', ''Report of changes to projects you own or have fav';
wwv_flow_imp.g_varchar2_table(9) := 'orited.'',''Y''); ';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(40988965823743262584)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed notifications'
,p_sequence=>870
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
