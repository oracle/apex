prompt --application/deployment/install/install_sp_project_links_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_project_links table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_project_links ('||wwv_flow.LF||
'    id                             number default on null to_number(';
wwv_flow_imp.g_varchar2_table(2) := 'sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_pr';
wwv_flow_imp.g_varchar2_table(3) := 'oject_links_pk primary key,'||wwv_flow.LF||
'    project_id                     number'||wwv_flow.LF||
'                              ';
wwv_flow_imp.g_varchar2_table(4) := '     constraint sp_project_links_proj_fk'||wwv_flow.LF||
'                                   references sp_projects o';
wwv_flow_imp.g_varchar2_table(5) := 'n delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    link_name                      varchar2(255 char)   not null,'||wwv_flow.LF||
'    link_';
wwv_flow_imp.g_varchar2_table(6) := 'url                       varchar2(4000 char) not null,'||wwv_flow.LF||
'    important_yn                   varchar2(';
wwv_flow_imp.g_varchar2_table(7) := '1 char) default on null ''N'''||wwv_flow.LF||
'                                   constraint sp_project_links_imp_ck'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(8) := '                                 check (important_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created              ';
wwv_flow_imp.g_varchar2_table(9) := '          date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated';
wwv_flow_imp.g_varchar2_table(10) := '                        date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not nul';
wwv_flow_imp.g_varchar2_table(11) := 'l'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_project_links_i1 on sp_project_links (project_id);'||wwv_flow.LF||
'create index sp_project_lin';
wwv_flow_imp.g_varchar2_table(12) := 'ks_i2 on sp_project_links (updated);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38666518163513739888)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_project_links table'
,p_sequence=>260
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
