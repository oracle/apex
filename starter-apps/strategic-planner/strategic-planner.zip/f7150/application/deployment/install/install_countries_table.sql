prompt --application/deployment/install/install_countries_table
begin
--   Manifest
--     INSTALL: INSTALL-countries table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table  sp_countries ('||wwv_flow.LF||
'   id                 number default on null to_number(sys_guid(), ''XXX';
wwv_flow_imp.g_varchar2_table(2) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                      constraint sp_countries_pk primary key,'||wwv_flow.LF||
'   co';
wwv_flow_imp.g_varchar2_table(3) := 'untry_code       varchar2(2   char) not null enable, '||wwv_flow.LF||
'   COUNTRY_CODE3      varchar2(3   char),'||wwv_flow.LF||
'   c';
wwv_flow_imp.g_varchar2_table(4) := 'ountry_name       varchar2(255 char) not null enable, '||wwv_flow.LF||
'   region             varchar2(30  char) not ';
wwv_flow_imp.g_varchar2_table(5) := 'null enable, '||wwv_flow.LF||
'   display_yn         varchar2(1   char) not null enable, '||wwv_flow.LF||
'   quick_pick_yn      varch';
wwv_flow_imp.g_varchar2_table(6) := 'ar2(1   char) not null enable, '||wwv_flow.LF||
'   lat                number,'||wwv_flow.LF||
'   lon                number,'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(7) := ' created            date,'||wwv_flow.LF||
'   created_by         varchar2(255 char), '||wwv_flow.LF||
'   updated            date, '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(8) := ' updated_by         varchar2(255 char)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index  sp_countries_i1 on  sp_countries';
wwv_flow_imp.g_varchar2_table(9) := ' (country_code)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index  sp_countries_i2 on  sp_countries (country_name)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR';
wwv_flow_imp.g_varchar2_table(10) := ' REPLACE EDITIONABLE TRIGGER  sp_countries_biu'||wwv_flow.LF||
'   before insert or update on sp_countries '||wwv_flow.LF||
'   for ea';
wwv_flow_imp.g_varchar2_table(11) := 'ch row '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'   if inserting then '||wwv_flow.LF||
'       :new.created := localtimestamp; '||wwv_flow.LF||
'       :new.created_by ';
wwv_flow_imp.g_varchar2_table(12) := ':= nvl(wwv_flow.g_user,user); '||wwv_flow.LF||
'       :new.updated := localtimestamp; '||wwv_flow.LF||
'       :new.updated_by := nvl';
wwv_flow_imp.g_varchar2_table(13) := '(wwv_flow.g_user,user); '||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'   if inserting or updating then '||wwv_flow.LF||
'       :new.updated := localt';
wwv_flow_imp.g_varchar2_table(14) := 'imestamp; '||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user); '||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'   if :new.display_yn i';
wwv_flow_imp.g_varchar2_table(15) := 's null then  '||wwv_flow.LF||
'      :new.display_yn := ''Y''; '||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'   if :new.quick_pick_yn is null then  '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(16) := '   :new.quick_pick_yn := ''N''; '||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'end sp_countries_biu; '||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(47507423690668300256)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'countries table'
,p_sequence=>330
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
