prompt --application/deployment/install/install_project_reviews_sp_project_reviews
begin
--   Manifest
--     INSTALL: INSTALL-Project Reviews - sp_project_reviews
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(14377439619456620528)
,p_install_id=>wwv_flow_imp.id(141180564419272860082)
,p_name=>'Project Reviews - sp_project_reviews'
,p_sequence=>230
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table sp_project_reviews (',
'    id                             number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') ',
'                                   constraint sp_project_reviews_id_pk primary key,',
'    project_id                     number',
'                                   constraint sp_project_review_project_id_fk',
'                                   references sp_projects on delete cascade,',
'    --',
'    review_type_id                 number not null',
'                                   constraint sp_project_review_type_id_fk',
'                                   references sp_project_review_types,',
'    owner_id                       number ',
'                                   constraint sp_projects_review_owner_fk',
'                                   references sp_team_members,',
'    review_status                  varchar2(30 char) not null',
'                                   constraint sp_project_review_status_ck',
'                                   check (review_status in (''REQUESTED'',''PLANNED'',''IN-PROGRESS'',''MORE-INFORMATION-REQUESTED'',''COMPLETED'')),',
'    review_comments                varchar2(255 char),',
'    review_url                     varchar2(4000 char),',
'    review_date                    date,',
'    --',
'    created                        date not null,',
'    created_by                     varchar2(255 char) not null,',
'    updated                        date not null,',
'    updated_by                     varchar2(255 char) not null',
')',
';',
'',
'create index sp_project_reviews_i1 on sp_project_reviews (project_id);',
'create index sp_project_reviews_i2 on sp_project_reviews (review_type_id);',
'create index sp_project_reviews_i3 on sp_project_reviews (owner_id);',
'create index sp_project_reviews_i4 on sp_project_reviews (updated);',
'create unique index sp_project_reviews_u1 on sp_project_reviews (project_id, review_type_id, owner_id);'))
);
wwv_flow_imp.component_end;
end;
/
