prompt --application/deployment/install/install_configurable_text_table
begin
--   Manifest
--     INSTALL: INSTALL-configurable_text table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table SP_CONFIGURABLE_TEXT ('||wwv_flow.LF||
'    id                   number default on null to_number(sys_gu';
wwv_flow_imp.g_varchar2_table(2) := 'id(), ''xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'') not null, '||wwv_flow.LF||
'    config_ID            varchar2(50 char) not ';
wwv_flow_imp.g_varchar2_table(3) := 'null,'||wwv_flow.LF||
'    description          varchar2(4000 char) not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    configurable_content clob,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(4) := '   --'||wwv_flow.LF||
'    created              date not null, '||wwv_flow.LF||
'    created_by           varchar2(255 char) not null,';
wwv_flow_imp.g_varchar2_table(5) := ' '||wwv_flow.LF||
'    updated              date not null, '||wwv_flow.LF||
'    updated_by           varchar2(255 char) not null'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(6) := ') '||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_configurable_text_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on SP_CONFI';
wwv_flow_imp.g_varchar2_table(7) := 'GURABLE_TEXT'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :';
wwv_flow_imp.g_varchar2_table(8) := 'new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.update';
wwv_flow_imp.g_varchar2_table(9) := 'd := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'end sp_c';
wwv_flow_imp.g_varchar2_table(10) := 'onfigurable_text_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'insert into SP_CONFIGURABLE_TEXT (id, config_ID, description) values ';
wwv_flow_imp.g_varchar2_table(11) := '(1, ''ABOUT-PRIMARY-TEXT'',''Primary text displayed on application about page.'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(39187982706000043550)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'configurable_text table'
,p_sequence=>630
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
