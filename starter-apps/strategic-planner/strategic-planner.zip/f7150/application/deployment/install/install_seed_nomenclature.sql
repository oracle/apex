prompt --application/deployment/install/install_seed_nomenclature
begin
--   Manifest
--     INSTALL: INSTALL-seed nomenclature
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into SP_APP_NOMENCLATURE (static_ID, default_order, default_value) values (''STRATEGIC_PLANNER';
wwv_flow_imp.g_varchar2_table(2) := ''', 1, ''Our Strategic Planner'');'||wwv_flow.LF||
'insert into SP_APP_NOMENCLATURE (static_ID, default_order, default_v';
wwv_flow_imp.g_varchar2_table(3) := 'alue) values (''AREA'', 2, ''Area'');'||wwv_flow.LF||
'insert into SP_APP_NOMENCLATURE (static_ID, default_order, default';
wwv_flow_imp.g_varchar2_table(4) := '_value) values (''AREAS'', 3, ''Areas'');'||wwv_flow.LF||
'insert into SP_APP_NOMENCLATURE (static_ID, default_order, def';
wwv_flow_imp.g_varchar2_table(5) := 'ault_value) values (''INITIATIVE'', 4, ''Initiative'');'||wwv_flow.LF||
'insert into SP_APP_NOMENCLATURE (static_ID, defa';
wwv_flow_imp.g_varchar2_table(6) := 'ult_order, default_value) values (''INITIATIVES'', 5, ''Initiatives'');'||wwv_flow.LF||
'insert into SP_APP_NOMENCLATURE ';
wwv_flow_imp.g_varchar2_table(7) := '(static_ID, default_order, default_value) values (''PROJECT'', 6, ''Project'');'||wwv_flow.LF||
'insert into SP_APP_NOMEN';
wwv_flow_imp.g_varchar2_table(8) := 'CLATURE (static_ID, default_order, default_value) values (''PROJECTS'', 7, ''Projects'');'||wwv_flow.LF||
'insert into SP';
wwv_flow_imp.g_varchar2_table(9) := '_APP_NOMENCLATURE (static_ID, default_order, default_value) values (''USER'', 10, ''Person'');'||wwv_flow.LF||
'insert in';
wwv_flow_imp.g_varchar2_table(10) := 'to SP_APP_NOMENCLATURE (static_ID, default_order, default_value) values (''USERS'', 11, ''People'');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(44811840470515846857)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed nomenclature'
,p_sequence=>780
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
