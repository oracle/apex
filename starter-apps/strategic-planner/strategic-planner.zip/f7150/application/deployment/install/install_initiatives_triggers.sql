prompt --application/deployment/install/install_initiatives_triggers
begin
--   Manifest
--     INSTALL: INSTALL-Initiatives triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_initiatives_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_initiatives'||wwv_flow.LF||
'    f';
wwv_flow_imp.g_varchar2_table(2) := 'or each row'||wwv_flow.LF||
'declare '||wwv_flow.LF||
'    l_tags        varchar2(4000);'||wwv_flow.LF||
'    l_old_value   varchar2(4000) := null;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(3) := ' l_new_value   varchar2(4000) := null;'||wwv_flow.LF||
'    l_changed_by  varchar2(255)  := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if insert';
wwv_flow_imp.g_varchar2_table(4) := 'ing then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESS';
wwv_flow_imp.g_varchar2_table(5) := 'ION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys';
wwv_flow_imp.g_varchar2_table(6) := '_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    if :new.SPONSOR_ID is null then'||wwv_flow.LF||
'       for c1 in (sel';
wwv_flow_imp.g_varchar2_table(7) := 'ect OWNER_ID from SP_AREAS f where f.id = :new.AREA_ID and owner_id is not null) loop'||wwv_flow.LF||
'           :ne';
wwv_flow_imp.g_varchar2_table(8) := 'w.SPONSOR_ID := c1.owner_id;'||wwv_flow.LF||
'       end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- short ID used as an alternat';
wwv_flow_imp.g_varchar2_table(9) := 'ive to long numeric ID primary key column'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.friendly_identifier is null then'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(10) := ' :new.friendly_identifier := sp_util.compress_int(sp_seq.nextval);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- used to';
wwv_flow_imp.g_varchar2_table(11) := ' provide friendly URLs'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if not sp_value_compare.is_equal(:old.initiative,:new.initiative) ';
wwv_flow_imp.g_varchar2_table(12) := 'then'||wwv_flow.LF||
'       :new.initiative_url_name := ltrim(rtrim(replace(replace(REGEXP_REPLACE(translate(substr(';
wwv_flow_imp.g_varchar2_table(13) := ':new.initiative,1,80),''()+%$&^!@[];:"?/~!-+_.<>'',''                        ''),''\s+'', '' ''), '''''''', ''''),';
wwv_flow_imp.g_varchar2_table(14) := ''' '',''-''),''-''),''-'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- status scale'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.status_scale is null t';
wwv_flow_imp.g_varchar2_table(15) := 'hen'||wwv_flow.LF||
'       :new.status_scale := ''A'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- adjust tag data'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.ta';
wwv_flow_imp.g_varchar2_table(16) := 'gs is not null then'||wwv_flow.LF||
'        l_tags := trim(upper(:new.tags));'||wwv_flow.LF||
'        -- remove multiple spaces'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(17) := '    if instr(l_tags,''  '') > 0 then'||wwv_flow.LF||
'            for j in 1..10 loop '||wwv_flow.LF||
'                l_tags := replac';
wwv_flow_imp.g_varchar2_table(18) := 'e(l_tags,''  '','' ''); '||wwv_flow.LF||
'                if instr(l_tags,''  '') = 0 then'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(19) := '         end if;'||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        for i in 1..length(l_tags) loop'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(20) := '        if i > 2 and substr(l_tags,i,1) = '' '' and substr(l_tags,i-1,1) != '','' then'||wwv_flow.LF||
'               l_';
wwv_flow_imp.g_varchar2_table(21) := 'tags := substr(l_tags,1,i-1)||''-''||substr(l_tags,i+1);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(22) := ' :new.tags := l_tags;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   if :new.hidden_by_default_yn is null then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(23) := '  :new.hidden_by_default_yn := ''N'';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   -- touch parent table'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   update sp_are';
wwv_flow_imp.g_varchar2_table(24) := 'as set updated = sysdate, updated_by = :new.updated_by where id = :new.area_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- histor';
wwv_flow_imp.g_varchar2_table(25) := 'y'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        l_changed_by := lower(:new.updated_by);'||wwv_flow.LF||
''||wwv_flow.LF||
'        if not sp_val';
wwv_flow_imp.g_varchar2_table(26) := 'ue_compare.is_equal(:old.initiative,:new.initiative) then'||wwv_flow.LF||
'            insert into sp_initiative_hist';
wwv_flow_imp.g_varchar2_table(27) := 'ory'||wwv_flow.LF||
'                (initiative_id, attribute_column, change_type, old_value, new_value,changed_on, ';
wwv_flow_imp.g_varchar2_table(28) := 'changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.id, ''INITIATIVE'', ''UPDATE'', :old.initiative, :n';
wwv_flow_imp.g_varchar2_table(29) := 'ew.initiative, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old';
wwv_flow_imp.g_varchar2_table(30) := '.area_id,:new.area_id) then'||wwv_flow.LF||
'            for c1 in (select AREA r from SP_AREAS x where x.id = :old.A';
wwv_flow_imp.g_varchar2_table(31) := 'REA_ID) loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'            for c1 in (select AREA r from SP_AREAS x whe';
wwv_flow_imp.g_varchar2_table(32) := 're x.id = :new.AREA_ID) loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'            insert into sp_initiative_hi';
wwv_flow_imp.g_varchar2_table(33) := 'story'||wwv_flow.LF||
'                (initiative_id, attribute_column, change_type, old_value, new_value,changed_on';
wwv_flow_imp.g_varchar2_table(34) := ', changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.id, ''AREA'', ''UPDATE'', l_old_value, l_new_valu';
wwv_flow_imp.g_varchar2_table(35) := 'e, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.objective,:';
wwv_flow_imp.g_varchar2_table(36) := 'new.objective) then'||wwv_flow.LF||
'            insert into sp_initiative_history'||wwv_flow.LF||
'                (initiative_id, at';
wwv_flow_imp.g_varchar2_table(37) := 'tribute_column, change_type, old_value, new_value,changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(38) := '         (:new.id, ''OBJECTIVE'', ''UPDATE'', :old.objective, :new.objective, sysdate, l_changed_by);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(39) := '      end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.sponsor_id,:new.sponsor_id) then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(40) := '     for c1 in (select lower(email) r from SP_TEAM_MEMBERS x where x.id = :old.sponsor_id) loop l_ol';
wwv_flow_imp.g_varchar2_table(41) := 'd_value := c1.r; end loop;'||wwv_flow.LF||
'            for c1 in (select lower(email) r from SP_TEAM_MEMBERS x where';
wwv_flow_imp.g_varchar2_table(42) := ' x.id = :new.sponsor_id) loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'            insert into sp_initiative_h';
wwv_flow_imp.g_varchar2_table(43) := 'istory'||wwv_flow.LF||
'                (initiative_id, attribute_column, change_type, old_value, new_value,changed_o';
wwv_flow_imp.g_varchar2_table(44) := 'n, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.id, ''SPONSOR'', ''UPDATE'', l_old_value, l_new_';
wwv_flow_imp.g_varchar2_table(45) := 'value, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.status_';
wwv_flow_imp.g_varchar2_table(46) := 'scale,:new.status_scale) then'||wwv_flow.LF||
'            insert into sp_initiative_history'||wwv_flow.LF||
'                (initiat';
wwv_flow_imp.g_varchar2_table(47) := 'ive_id, attribute_column, change_type, old_value, new_value,changed_on, changed_by)'||wwv_flow.LF||
'            valu';
wwv_flow_imp.g_varchar2_table(48) := 'es'||wwv_flow.LF||
'                (:new.id, ''STATUS_SCALE'', ''UPDATE'', :old.status_scale, :new.status_scale, sysdate';
wwv_flow_imp.g_varchar2_table(49) := ', l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.tags,:new.tags) then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(50) := '            insert into sp_initiative_history'||wwv_flow.LF||
'                (initiative_id, attribute_column, chan';
wwv_flow_imp.g_varchar2_table(51) := 'ge_type, old_value, new_value,changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.id, ''';
wwv_flow_imp.g_varchar2_table(52) := 'TAGS'', ''UPDATE'', :old.tags, :new.tags, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_val';
wwv_flow_imp.g_varchar2_table(53) := 'ue_compare.is_equal(:old.archived_yn,:new.archived_yn) then'||wwv_flow.LF||
'            insert into sp_initiative_hi';
wwv_flow_imp.g_varchar2_table(54) := 'story'||wwv_flow.LF||
'                (initiative_id, attribute_column, change_type, old_value, new_value, changed_o';
wwv_flow_imp.g_varchar2_table(55) := 'n, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.id, ''ARCHIVED'', ''UPDATE'', :old.archived_yn, ';
wwv_flow_imp.g_varchar2_table(56) := ':new.archived_yn, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:';
wwv_flow_imp.g_varchar2_table(57) := 'old.hidden_by_default_yn,:new.hidden_by_default_yn) then'||wwv_flow.LF||
'            insert into sp_initiative_histo';
wwv_flow_imp.g_varchar2_table(58) := 'ry'||wwv_flow.LF||
'                (initiative_id, attribute_column, change_type, old_value, new_value, changed_on, ';
wwv_flow_imp.g_varchar2_table(59) := 'changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.id, ''HIDDEN_BY_DEFAULT'', ''UPDATE'', :old.hidden_';
wwv_flow_imp.g_varchar2_table(60) := 'by_default_yn, :new.hidden_by_default_yn, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp';
wwv_flow_imp.g_varchar2_table(61) := '_initiatives_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger sp_initiatives_ai'||wwv_flow.LF||
'    after insert'||wwv_flow.LF||
'    on sp_initiativ';
wwv_flow_imp.g_varchar2_table(62) := 'es'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_new_value   varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in (select AR';
wwv_flow_imp.g_varchar2_table(63) := 'EA r from SP_AREAS x where x.id = :new.AREA_ID) loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'    insert into ';
wwv_flow_imp.g_varchar2_table(64) := 'sp_initiative_history'||wwv_flow.LF||
'        (initiative_id, attribute_column, change_type, old_value, changed_on, ';
wwv_flow_imp.g_varchar2_table(65) := 'changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:new.id, ''INITIATIVE'', ''CREATE'', l_new_value||'': ''||:new.initiative,';
wwv_flow_imp.g_varchar2_table(66) := ' sysdate, lower(:new.created_by));'||wwv_flow.LF||
'end sp_initiatives_ai;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger sp_initiatives';
wwv_flow_imp.g_varchar2_table(67) := '_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_initiatives'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_old_value   varchar2(4000';
wwv_flow_imp.g_varchar2_table(68) := ') := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_areas set updated = sysdate, ';
wwv_flow_imp.g_varchar2_table(69) := 'updated_by = :old.updated_by where id = :old.area_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for c1 in (select AREA r from SP_AR';
wwv_flow_imp.g_varchar2_table(70) := 'EAS x where x.id = :old.AREA_ID) loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'    insert into sp_initiative_h';
wwv_flow_imp.g_varchar2_table(71) := 'istory'||wwv_flow.LF||
'        (initiative_id, attribute_column, change_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(72) := ' values'||wwv_flow.LF||
'        (:old.id, ''INITIATIVE'', ''DELETE'', l_old_value||'': ''||:old.initiative, sysdate, lower';
wwv_flow_imp.g_varchar2_table(73) := '(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'end sp_initiatives_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38175845302854070433)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'Initiatives triggers'
,p_sequence=>440
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
