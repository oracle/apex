prompt --application/deployment/install/install_seed_project_sizes
begin
--   Manifest
--     INSTALL: INSTALL-seed project sizes
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
'insert into sp_project_sizes (Project_size, size_description, effort_days) values (''S'',''Small''';
wwv_flow_imp.g_varchar2_table(2) := ',2);   -- 2 days'||wwv_flow.LF||
'insert into sp_project_sizes (Project_size, size_description, effort_days) values (';
wwv_flow_imp.g_varchar2_table(3) := '''M'',''Medium'',10); -- 2 weeks'||wwv_flow.LF||
'insert into sp_project_sizes (Project_size, size_description, effort_da';
wwv_flow_imp.g_varchar2_table(4) := 'ys) values (''L'',''Large'',40);  -- 2 months'||wwv_flow.LF||
'insert into sp_project_sizes (Project_size, size_descripti';
wwv_flow_imp.g_varchar2_table(5) := 'on, effort_days) values (''XL'',''Extra Large'',120); -- 6 months'||wwv_flow.LF||
'insert into sp_project_sizes (Project_';
wwv_flow_imp.g_varchar2_table(6) := 'size, size_description, effort_days) values (''2XL'',''2 Times Extra Large'',240);  -- 12 months, 1 year';
wwv_flow_imp.g_varchar2_table(7) := ''||wwv_flow.LF||
'insert into sp_project_sizes (Project_size, size_description, effort_days, include_yn) values (''3XL';
wwv_flow_imp.g_varchar2_table(8) := ''',''3 Times Extra Large'',360,''N'');  -- 18 months, 1.5 years'||wwv_flow.LF||
'insert into sp_project_sizes (Project_siz';
wwv_flow_imp.g_varchar2_table(9) := 'e, size_description, effort_days, include_yn) values (''4XL'',''4 Times Extra Large'',640,''N'');  -- 24 m';
wwv_flow_imp.g_varchar2_table(10) := 'onths, 2 years'||wwv_flow.LF||
'insert into sp_project_sizes (Project_size, size_description, effort_days, include_yn';
wwv_flow_imp.g_varchar2_table(11) := ') values (''8XL'',''8 Times Extra Large'',960,''N'');  -- 48 months, 4 years'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(42555625011022079597)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed project sizes'
,p_sequence=>840
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
