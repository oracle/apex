prompt --application/deployment/install/install_sp_comment_util_body
begin
--   Manifest
--     INSTALL: INSTALL-sp_comment_util body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body sp_comment_util as'||wwv_flow.LF||
''||wwv_flow.LF||
'g_session_placeholder constant varchar2(20) := ''~';
wwv_flow_imp.g_varchar2_table(2) := 'RTE*SESS~'';'||wwv_flow.LF||
''||wwv_flow.LF||
'-- this removes images from abandoned comments (ie. comments never created but images u';
wwv_flow_imp.g_varchar2_table(3) := 'ploaded)'||wwv_flow.LF||
'--   this is executed each time a comment is scanned to avoid the need for a job to do the ';
wwv_flow_imp.g_varchar2_table(4) := 'cleanup'||wwv_flow.LF||
'procedure cleanup_old_images'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    delete from sp_comment_images'||wwv_flow.LF||
'     where image_ref';
wwv_flow_imp.g_varchar2_table(5) := '_id not in '||wwv_flow.LF||
'           (select image_ref_id '||wwv_flow.LF||
'              from sp_initiative_comments'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(6) := 'where image_ref_id is not null'||wwv_flow.LF||
'             union all'||wwv_flow.LF||
'            select image_ref_id '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(7) := ' from sp_project_comments'||wwv_flow.LF||
'             where image_ref_id is not null'||wwv_flow.LF||
'             union all'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(8) := '     select image_ref_id '||wwv_flow.LF||
'              from sp_task_comments'||wwv_flow.LF||
'             where image_ref_id is not';
wwv_flow_imp.g_varchar2_table(9) := ' null'||wwv_flow.LF||
'             union all'||wwv_flow.LF||
'            select image_ref_id '||wwv_flow.LF||
'              from sp_release_comments';
wwv_flow_imp.g_varchar2_table(10) := ''||wwv_flow.LF||
'             where image_ref_id is not null'||wwv_flow.LF||
'             union all'||wwv_flow.LF||
'            select image_ref_id ';
wwv_flow_imp.g_varchar2_table(11) := ''||wwv_flow.LF||
'              from sp_init_focus_area_comments'||wwv_flow.LF||
'             where image_ref_id is not null )'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(12) := ' and created < sysdate-1;'||wwv_flow.LF||
'end cleanup_old_images;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- this finds all the names of images within a c';
wwv_flow_imp.g_varchar2_table(13) := 'lob'||wwv_flow.LF||
'function find_images ('||wwv_flow.LF||
'    p_clob  in  clob )'||wwv_flow.LF||
'    return varchar2 '||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_clob                ';
wwv_flow_imp.g_varchar2_table(14) := 'clob;'||wwv_flow.LF||
'    l_clob_length         integer;'||wwv_flow.LF||
'    l_image_prefix        varchar2(255)  := ''](''||sp_util.g';
wwv_flow_imp.g_varchar2_table(15) := 'et_setting(p_static_id => ''GET_COMMENT_IMAGE_PREFIX'')||''get-image?x01='';'||wwv_flow.LF||
'    l_prefix_length       n';
wwv_flow_imp.g_varchar2_table(16) := 'umber         := length(l_image_prefix);'||wwv_flow.LF||
'    l_image_list          varchar2(4000) := null;'||wwv_flow.LF||
'    l_sta';
wwv_flow_imp.g_varchar2_table(17) := 'rt               integer        := 1;'||wwv_flow.LF||
'    l_match               integer;'||wwv_flow.LF||
'    l_image_name          v';
wwv_flow_imp.g_varchar2_table(18) := 'archar2(255);'||wwv_flow.LF||
'    l_loop_count          integer        := 0;'||wwv_flow.LF||
'    l_max_loops           integer      ';
wwv_flow_imp.g_varchar2_table(19) := '  := 100;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- remove session placeholder (if it exists)'||wwv_flow.LF||
'    l_clob := replace(p_clob,''sessi';
wwv_flow_imp.g_varchar2_table(20) := 'on=''||g_session_placeholder||''&'','''');'||wwv_flow.LF||
'    -- Get the length of the input clob'||wwv_flow.LF||
'    l_clob_length := s';
wwv_flow_imp.g_varchar2_table(21) := 'ys.dbms_lob.getlength(l_clob);'||wwv_flow.LF||
'    -- Loop through the clob to extract image names'||wwv_flow.LF||
'    while l_start';
wwv_flow_imp.g_varchar2_table(22) := ' <= l_clob_length loop'||wwv_flow.LF||
'        if l_loop_count > l_max_loops then'||wwv_flow.LF||
'            exit; -- prevent infin';
wwv_flow_imp.g_varchar2_table(23) := 'ite loop'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        l_match := null;'||wwv_flow.LF||
'        -- will find the beginning of the image st';
wwv_flow_imp.g_varchar2_table(24) := 'ring'||wwv_flow.LF||
'        l_match := instr(l_clob, l_image_prefix, l_start, 1);'||wwv_flow.LF||
'        exit when l_match = 0;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(25) := '      -- extract the image name'||wwv_flow.LF||
'        l_image_name := substr(l_clob, l_match + l_prefix_length, 22';
wwv_flow_imp.g_varchar2_table(26) := ');'||wwv_flow.LF||
'        -- Append to the image list'||wwv_flow.LF||
'        if l_image_list is not null then'||wwv_flow.LF||
'            l_image_';
wwv_flow_imp.g_varchar2_table(27) := 'list := l_image_list || '':'' || l_image_name;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            l_image_list := l_image_name;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(28) := '        end if;'||wwv_flow.LF||
'        -- Move position forward to continue searching'||wwv_flow.LF||
'        l_start := l_start + ';
wwv_flow_imp.g_varchar2_table(29) := 'l_match + l_prefix_length + 22;'||wwv_flow.LF||
'        l_loop_count := l_loop_count + 1;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    ret';
wwv_flow_imp.g_varchar2_table(30) := 'urn l_image_list;'||wwv_flow.LF||
'end find_images;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- this finds all the image links in a clob and replaces with [';
wwv_flow_imp.g_varchar2_table(31) := 'image], for use in IRs and emails'||wwv_flow.LF||
'function replace_images ('||wwv_flow.LF||
'    p_clob  in  clob )'||wwv_flow.LF||
'    return clob '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(32) := 'is'||wwv_flow.LF||
'    l_clob_length         integer;'||wwv_flow.LF||
'    l_image_prefix        varchar2(255);'||wwv_flow.LF||
'    l_prefix_length  ';
wwv_flow_imp.g_varchar2_table(33) := '     number;'||wwv_flow.LF||
'    l_image_list          varchar2(4000) := null;'||wwv_flow.LF||
'    l_start               integer    ';
wwv_flow_imp.g_varchar2_table(34) := '    := 1;'||wwv_flow.LF||
'    l_match               integer;'||wwv_flow.LF||
'    l_begin               integer;'||wwv_flow.LF||
'    l_image_name    ';
wwv_flow_imp.g_varchar2_table(35) := '      varchar2(255);'||wwv_flow.LF||
'    l_alt_text            varchar2(4000);'||wwv_flow.LF||
'    l_filename            varchar2(25';
wwv_flow_imp.g_varchar2_table(36) := '5);'||wwv_flow.LF||
'    l_loop_count          integer        := 0;'||wwv_flow.LF||
'    l_max_loops           integer        := 100;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(37) := '    l_clob                clob           := p_clob;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- Get the length of the input clob'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(38) := '  l_clob_length := sys.dbms_lob.getlength(p_clob);'||wwv_flow.LF||
''||wwv_flow.LF||
'-- first check without session - if needed, a se';
wwv_flow_imp.g_varchar2_table(39) := 'cond loop using session'||wwv_flow.LF||
'    for i in 1..2 loop'||wwv_flow.LF||
'        if i = 1 then'||wwv_flow.LF||
'           l_image_prefix   := ';
wwv_flow_imp.g_varchar2_table(40) := '''](''||sp_util.get_setting(p_static_id => ''GET_COMMENT_IMAGE_PREFIX'')||''get-image?x01='';'||wwv_flow.LF||
'           l';
wwv_flow_imp.g_varchar2_table(41) := '_prefix_length  := length(l_image_prefix);'||wwv_flow.LF||
'           l_start          := 1;'||wwv_flow.LF||
'           l_loop_count';
wwv_flow_imp.g_varchar2_table(42) := '     := 0;    '||wwv_flow.LF||
'        else'||wwv_flow.LF||
'           -- Search again including session'||wwv_flow.LF||
'           l_image_prefix  ';
wwv_flow_imp.g_varchar2_table(43) := ' := ''](''||sp_util.get_setting(p_static_id => ''GET_COMMENT_IMAGE_PREFIX'')||''get-image?session=''||g_se';
wwv_flow_imp.g_varchar2_table(44) := 'ssion_placeholder||''&x01='';'||wwv_flow.LF||
'           l_prefix_length  := length(l_image_prefix);'||wwv_flow.LF||
'           l_star';
wwv_flow_imp.g_varchar2_table(45) := 't          := 1;'||wwv_flow.LF||
'           l_loop_count     := 0;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- Loop through the clob';
wwv_flow_imp.g_varchar2_table(46) := ' to find and replace image names'||wwv_flow.LF||
'        while l_start <= l_clob_length loop'||wwv_flow.LF||
'            if l_loop_c';
wwv_flow_imp.g_varchar2_table(47) := 'ount > l_max_loops then'||wwv_flow.LF||
'                exit; -- prevent infinite loop'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(48) := '   l_match := null;'||wwv_flow.LF||
'            -- will find the beginning of the image string'||wwv_flow.LF||
'            l_match :';
wwv_flow_imp.g_varchar2_table(49) := '= instr(p_clob, l_image_prefix, l_start, 1);'||wwv_flow.LF||
'            exit when l_match = 0;'||wwv_flow.LF||
'            -- extra';
wwv_flow_imp.g_varchar2_table(50) := 'ct the image name'||wwv_flow.LF||
'            l_image_name := substr(p_clob, l_match + l_prefix_length, 22);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(51) := '     -- if no alt text added, find image name'||wwv_flow.LF||
'            if substr(p_clob,l_match-2,2) = ''!['' then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(52) := '               -- find filename of image, if was file and not screensnap'||wwv_flow.LF||
'               -- if image ';
wwv_flow_imp.g_varchar2_table(53) := 'gets delete from images table, editing the content will fail to save'||wwv_flow.LF||
'               --    wrapping t';
wwv_flow_imp.g_varchar2_table(54) := 'his allows l_filename to be null, which is handled during replacement'||wwv_flow.LF||
'               begin'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(55) := '          select filename'||wwv_flow.LF||
'                     into l_filename'||wwv_flow.LF||
'                     from sp_comment_';
wwv_flow_imp.g_varchar2_table(56) := 'images'||wwv_flow.LF||
'                    where unique_filename = l_image_name;'||wwv_flow.LF||
'               exception'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(57) := '         when no_data_found then null;'||wwv_flow.LF||
'               end;'||wwv_flow.LF||
'               -- replace image link'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(58) := '           if nvl(l_filename,''image.png'') != ''image.png'' then'||wwv_flow.LF||
'                   -- if link was adde';
wwv_flow_imp.g_varchar2_table(59) := 'd to image, there will be extra square brackets'||wwv_flow.LF||
'                   l_clob := replace(l_clob,''[![''||l';
wwv_flow_imp.g_varchar2_table(60) := '_image_prefix||l_image_name||'')]'',''[''||l_filename||'']'');'||wwv_flow.LF||
'                   l_clob := replace(l_clob';
wwv_flow_imp.g_varchar2_table(61) := ',''![''||l_image_prefix||l_image_name||'')'',''[''||l_filename||'']'');'||wwv_flow.LF||
'               else'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(62) := '   -- if link was added to image, there will be extra square brackets'||wwv_flow.LF||
'                   l_clob := r';
wwv_flow_imp.g_varchar2_table(63) := 'eplace(l_clob,''[![''||l_image_prefix||l_image_name||'')]'',''[image]'');'||wwv_flow.LF||
'                   l_clob := rep';
wwv_flow_imp.g_varchar2_table(64) := 'lace(l_clob,''![''||l_image_prefix||l_image_name||'')'',''[image]'');'||wwv_flow.LF||
'               end if;'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(65) := '  l_filename := null;'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'                l_begin     := instr(p_clob, ''!['', -(l_clob_l';
wwv_flow_imp.g_varchar2_table(66) := 'ength-l_match), 1);'||wwv_flow.LF||
'                l_alt_text  := substr(p_clob, l_begin+2, l_match-l_begin-2);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(67) := '             -- if link was added to image, there will be extra square brackets'||wwv_flow.LF||
'                l_cl';
wwv_flow_imp.g_varchar2_table(68) := 'ob      := replace(l_clob,''[![''||l_alt_text||l_image_prefix||l_image_name||'')]'',''[''||l_alt_text||'']''';
wwv_flow_imp.g_varchar2_table(69) := ');'||wwv_flow.LF||
'                l_clob      := replace(l_clob,''![''||l_alt_text||l_image_prefix||l_image_name||'')''';
wwv_flow_imp.g_varchar2_table(70) := ',''[''||l_alt_text||'']'');'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- Move position forward to continue search';
wwv_flow_imp.g_varchar2_table(71) := 'ing'||wwv_flow.LF||
'            l_start := l_match + l_prefix_length + 22;'||wwv_flow.LF||
'            l_loop_count := l_loop_count ';
wwv_flow_imp.g_varchar2_table(72) := '+ 1;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- if any images replace then no need to check using session'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(73) := ' if l_image_name is not null then'||wwv_flow.LF||
'           return l_clob;'||wwv_flow.LF||
'        end if;  '||wwv_flow.LF||
''||wwv_flow.LF||
'    end loop; '||wwv_flow.LF||
''||wwv_flow.LF||
'    r';
wwv_flow_imp.g_varchar2_table(74) := 'eturn l_clob;'||wwv_flow.LF||
'end replace_images;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function replace_session_on_save ('||wwv_flow.LF||
'    p_body        in  clob )'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(75) := '    return clob'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    return regexp_replace(p_body, ''(\?|&)(session=)([[:digit:]]+)'', ''\1\2'' ';
wwv_flow_imp.g_varchar2_table(76) := '|| g_session_placeholder);'||wwv_flow.LF||
'end replace_session_on_save;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function replace_session_on_display ('||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(77) := 'p_body        in  clob,'||wwv_flow.LF||
'    p_session_id  in  number )'||wwv_flow.LF||
'    return clob'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    return replace(p';
wwv_flow_imp.g_varchar2_table(78) := '_body, ''session=''||g_session_placeholder, ''session='' || p_session_id);'||wwv_flow.LF||
'end replace_session_on_displa';
wwv_flow_imp.g_varchar2_table(79) := 'y;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- images can be removed during edit or pasted in and then removed before create'||wwv_flow.LF||
'--   this ensu';
wwv_flow_imp.g_varchar2_table(80) := 'res those are removed'||wwv_flow.LF||
'procedure remove_orphan_images ('||wwv_flow.LF||
'    p_comment_id    in  number,'||wwv_flow.LF||
'    p_comment';
wwv_flow_imp.g_varchar2_table(81) := '_type  in  varchar2 )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_image_ref_id  number;'||wwv_flow.LF||
'    l_body          clob;'||wwv_flow.LF||
'    l_image_list    v';
wwv_flow_imp.g_varchar2_table(82) := 'archar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if p_comment_type = ''INITIATIVE'' then'||wwv_flow.LF||
'        select image_ref_id, body'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(83) := '       into l_image_ref_id, l_body'||wwv_flow.LF||
'          from sp_initiative_comments'||wwv_flow.LF||
'         where id = p_comme';
wwv_flow_imp.g_varchar2_table(84) := 'nt_id;'||wwv_flow.LF||
'    elsif p_comment_type = ''PROJECT'' then'||wwv_flow.LF||
'        select image_ref_id, body'||wwv_flow.LF||
'          into l_';
wwv_flow_imp.g_varchar2_table(85) := 'image_ref_id, l_body'||wwv_flow.LF||
'          from sp_project_comments'||wwv_flow.LF||
'         where id = p_comment_id;'||wwv_flow.LF||
'    elsif ';
wwv_flow_imp.g_varchar2_table(86) := 'p_comment_type = ''TASK'' then'||wwv_flow.LF||
'        select image_ref_id, body'||wwv_flow.LF||
'          into l_image_ref_id, l_body';
wwv_flow_imp.g_varchar2_table(87) := ''||wwv_flow.LF||
'          from sp_task_comments'||wwv_flow.LF||
'         where id = p_comment_id;'||wwv_flow.LF||
'    elsif p_comment_type = ''RELEA';
wwv_flow_imp.g_varchar2_table(88) := 'SE'' then'||wwv_flow.LF||
'        select image_ref_id, body'||wwv_flow.LF||
'          into l_image_ref_id, l_body'||wwv_flow.LF||
'          from sp_r';
wwv_flow_imp.g_varchar2_table(89) := 'elease_comments'||wwv_flow.LF||
'         where id = p_comment_id;'||wwv_flow.LF||
'    elsif p_comment_type = ''INIT_FOCUS_AREA'' then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(90) := '        select image_ref_id, body'||wwv_flow.LF||
'          into l_image_ref_id, l_body'||wwv_flow.LF||
'          from sp_init_focus';
wwv_flow_imp.g_varchar2_table(91) := '_area_comments'||wwv_flow.LF||
'         where id = p_comment_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_image_ref_id is not null and ';
wwv_flow_imp.g_varchar2_table(92) := 'l_body is not null then'||wwv_flow.LF||
'        l_image_list := '':''||find_images(l_body)||'':'';'||wwv_flow.LF||
''||wwv_flow.LF||
'        delete from ';
wwv_flow_imp.g_varchar2_table(93) := 'sp_comment_images'||wwv_flow.LF||
'         where image_ref_id = l_image_ref_id '||wwv_flow.LF||
'           and instr(l_image_list,'':';
wwv_flow_imp.g_varchar2_table(94) := '''||unique_filename||'':'') = 0;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end remove_orphan_images;'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------------------------';
wwv_flow_imp.g_varchar2_table(95) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure set_comment_email_references ('||wwv_flow.LF||
'    p_comment_id in number)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_results  apex_t_var';
wwv_flow_imp.g_varchar2_table(96) := 'char2 := apex_t_varchar2();  '||wwv_flow.LF||
'    l_string   clob;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- remove emails associated with this p';
wwv_flow_imp.g_varchar2_table(97) := 'roject comment'||wwv_flow.LF||
'    delete from sp_project_comments_emails where comment_id = p_comment_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- a';
wwv_flow_imp.g_varchar2_table(98) := 'dd emails associated with this project comment'||wwv_flow.LF||
'    for c1 in (select body from sp_project_comments w';
wwv_flow_imp.g_varchar2_table(99) := 'here id = p_comment_id) loop'||wwv_flow.LF||
'        l_string := c1.body;'||wwv_flow.LF||
'        l_results := apex_string_util.find';
wwv_flow_imp.g_varchar2_table(100) := '_email_addresses(l_string);'||wwv_flow.LF||
'        for i in 1..l_results.count loop'||wwv_flow.LF||
'            insert into sp_proj';
wwv_flow_imp.g_varchar2_table(101) := 'ect_comments_emails ('||wwv_flow.LF||
'                comment_id, email) '||wwv_flow.LF||
'            values ('||wwv_flow.LF||
'                p_com';
wwv_flow_imp.g_varchar2_table(102) := 'ment_id, lower(l_results(i))'||wwv_flow.LF||
'            );'||wwv_flow.LF||
'        end loop; '||wwv_flow.LF||
'    end loop; '||wwv_flow.LF||
'end set_comment_email_';
wwv_flow_imp.g_varchar2_table(103) := 'references;'||wwv_flow.LF||
''||wwv_flow.LF||
'----------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_initiative_comment ('||wwv_flow.LF||
'    p_app_user_i';
wwv_flow_imp.g_varchar2_table(104) := 'd     in  number,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ''N''';
wwv_flow_imp.g_varchar2_table(105) := ','||wwv_flow.LF||
'    p_initiative_id   in  number,'||wwv_flow.LF||
'    p_image_ref_id    in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_comme';
wwv_flow_imp.g_varchar2_table(106) := 'nt_id         number;'||wwv_flow.LF||
'    l_comment            clob;'||wwv_flow.LF||
'    l_comment_no_images  clob;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
''||wwv_flow.LF||
'    l_co';
wwv_flow_imp.g_varchar2_table(107) := 'mment           := replace_session_on_save(p_comment);'||wwv_flow.LF||
'    l_comment_no_images := replace_images(l_c';
wwv_flow_imp.g_varchar2_table(108) := 'omment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_initiative_comments ('||wwv_flow.LF||
'        initiative_id, '||wwv_flow.LF||
'        author_id, '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(109) := '   body,'||wwv_flow.LF||
'        body_html, '||wwv_flow.LF||
'        body_no_images,'||wwv_flow.LF||
'        private_yn,'||wwv_flow.LF||
'        image_ref_id ) '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(110) := ' values ('||wwv_flow.LF||
'        p_initiative_id,'||wwv_flow.LF||
'        p_app_user_id,'||wwv_flow.LF||
'        l_comment,'||wwv_flow.LF||
'        apex_markdown.t';
wwv_flow_imp.g_varchar2_table(111) := 'o_html(l_comment),'||wwv_flow.LF||
'        l_comment_no_images,'||wwv_flow.LF||
'        p_private_yn,'||wwv_flow.LF||
'        p_image_ref_id )'||wwv_flow.LF||
'    r';
wwv_flow_imp.g_varchar2_table(112) := 'eturning id into l_comment_id;'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doing image cleanup'||wwv_flow.LF||
'    remove_orphan_images ('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(113) := '      p_comment_id   => l_comment_id,'||wwv_flow.LF||
'        p_comment_type => ''INITIATIVE'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'end add_initiative_';
wwv_flow_imp.g_varchar2_table(114) := 'comment;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_initiative_comment ('||wwv_flow.LF||
'    p_comment_id      in  number,'||wwv_flow.LF||
'    p_comment    ';
wwv_flow_imp.g_varchar2_table(115) := '     in  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_image_ref_id    in  number ';
wwv_flow_imp.g_varchar2_table(116) := '  default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_comment            clob;'||wwv_flow.LF||
'    l_comment_no_images  clob;'||wwv_flow.LF||
'    l_image_ref_id';
wwv_flow_imp.g_varchar2_table(117) := '       number;'||wwv_flow.LF||
'    l_image_list         varchar2(4000);'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_comment           := replace_se';
wwv_flow_imp.g_varchar2_table(118) := 'ssion_on_save(p_comment);'||wwv_flow.LF||
'    l_comment_no_images := replace_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- for existing';
wwv_flow_imp.g_varchar2_table(119) := ' content, there may be no image_ref_id, so need to add one'||wwv_flow.LF||
'    update sp_initiative_comments'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(120) := 'set body           = l_comment,'||wwv_flow.LF||
'           body_html      = apex_markdown.to_html(l_comment),'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(121) := '     body_no_images = l_comment_no_images,'||wwv_flow.LF||
'           private_yn     = p_private_yn,'||wwv_flow.LF||
'           imag';
wwv_flow_imp.g_varchar2_table(122) := 'e_ref_id   = nvl(image_ref_id,to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX''))'||wwv_flow.LF||
'     where ';
wwv_flow_imp.g_varchar2_table(123) := 'id = p_comment_id'||wwv_flow.LF||
'    returning image_ref_id into l_image_ref_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_image_list := find_images(l';
wwv_flow_imp.g_varchar2_table(124) := '_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- if no images found, no need to update references'||wwv_flow.LF||
'    if l_image_list is not null ';
wwv_flow_imp.g_varchar2_table(125) := 'then'||wwv_flow.LF||
'        -- updating image_ref_id to match that of the existing content'||wwv_flow.LF||
'        update sp_commen';
wwv_flow_imp.g_varchar2_table(126) := 't_images'||wwv_flow.LF||
'           set image_ref_id = l_image_ref_id '||wwv_flow.LF||
'         where instr('':''||l_image_list||'':'',''';
wwv_flow_imp.g_varchar2_table(127) := ':''||unique_filename||'':'') > 0'||wwv_flow.LF||
'           and image_ref_id = p_image_ref_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doin';
wwv_flow_imp.g_varchar2_table(128) := 'g image cleanup'||wwv_flow.LF||
'    remove_orphan_images ('||wwv_flow.LF||
'        p_comment_id   => p_comment_id,'||wwv_flow.LF||
'        p_comment';
wwv_flow_imp.g_varchar2_table(129) := '_type => ''INITIATIVE'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- cleaning up old images, only on update'||wwv_flow.LF||
'    cleanup_old_images;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(130) := 'end update_initiative_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_initiative_comment ('||wwv_flow.LF||
'    p_comment_id      in  num';
wwv_flow_imp.g_varchar2_table(131) := 'ber )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_image_ref_id  number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    select image_ref_id'||wwv_flow.LF||
'      into l_image_ref_id'||wwv_flow.LF||
'      f';
wwv_flow_imp.g_varchar2_table(132) := 'rom sp_initiative_comments'||wwv_flow.LF||
'     where id = p_comment_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_image_ref_id is not null then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(133) := '     delete from sp_comment_images'||wwv_flow.LF||
'         where image_ref_id = l_image_ref_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    de';
wwv_flow_imp.g_varchar2_table(134) := 'lete from sp_initiative_comments'||wwv_flow.LF||
'     where id = p_comment_id;'||wwv_flow.LF||
'end delete_initiative_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
'-----';
wwv_flow_imp.g_varchar2_table(135) := '----------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_project_comment ('||wwv_flow.LF||
'    p_app_user_id     in  number';
wwv_flow_imp.g_varchar2_table(136) := ','||wwv_flow.LF||
'    p_app_user        in  varchar2,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  ';
wwv_flow_imp.g_varchar2_table(137) := 'varchar2 default ''N'','||wwv_flow.LF||
'    p_project_id      in  number,'||wwv_flow.LF||
'    p_system_gen_yn   in  varchar2 default ''';
wwv_flow_imp.g_varchar2_table(138) := 'N'','||wwv_flow.LF||
'    p_app_id          in  number   default null,'||wwv_flow.LF||
'    p_permalink_pre   in  varchar2 default null';
wwv_flow_imp.g_varchar2_table(139) := ','||wwv_flow.LF||
'    p_nomen_sp        in  varchar2 default null,'||wwv_flow.LF||
'    p_nomen_project   in  varchar2 default null,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(140) := '    p_image_ref_id    in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_comment            clob;'||wwv_flow.LF||
'    l_comment_no';
wwv_flow_imp.g_varchar2_table(141) := '_images  clob;'||wwv_flow.LF||
'    l_comment_id         number;'||wwv_flow.LF||
'    l_email_comment      clob;'||wwv_flow.LF||
'    l_link           ';
wwv_flow_imp.g_varchar2_table(142) := '    varchar2(4000);'||wwv_flow.LF||
'    l_mentions           varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_comment           := replac';
wwv_flow_imp.g_varchar2_table(143) := 'e_session_on_save(p_comment);'||wwv_flow.LF||
'    l_comment_no_images := replace_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into';
wwv_flow_imp.g_varchar2_table(144) := ' SP_PROJECT_COMMENTS ('||wwv_flow.LF||
'        project_id, '||wwv_flow.LF||
'        author_id, '||wwv_flow.LF||
'        body,'||wwv_flow.LF||
'        body_html, '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(145) := '      body_no_images, '||wwv_flow.LF||
'        private_yn,'||wwv_flow.LF||
'        image_ref_id) '||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_project_id,';
wwv_flow_imp.g_varchar2_table(146) := ''||wwv_flow.LF||
'        p_app_user_id,'||wwv_flow.LF||
'        l_comment,'||wwv_flow.LF||
'        apex_markdown.to_html(l_comment),'||wwv_flow.LF||
'        l_comme';
wwv_flow_imp.g_varchar2_table(147) := 'nt_no_images,'||wwv_flow.LF||
'        p_private_yn,'||wwv_flow.LF||
'        p_image_ref_id)'||wwv_flow.LF||
'    returning id into l_comment_id;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(148) := 'commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doing image cleanup'||wwv_flow.LF||
'    remove_orphan_images ('||wwv_flow.LF||
'        p_comment_id   => l_comment_i';
wwv_flow_imp.g_varchar2_table(149) := 'd,'||wwv_flow.LF||
'        p_comment_type => ''PROJECT'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_private_yn = ''N'' and p_system_gen_yn = ''N'' then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(150) := ''||wwv_flow.LF||
'        set_comment_email_references(l_comment_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_email_comment := apex_markdown.to_ht';
wwv_flow_imp.g_varchar2_table(151) := 'ml(substr(l_comment_no_images,1,3000)||case when length(l_comment_no_images) > 3000 then '' ...'' end)';
wwv_flow_imp.g_varchar2_table(152) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            select p.project,'||wwv_flow.LF||
'                   apex_escape.html(p.project) ';
wwv_flow_imp.g_varchar2_table(153) := 'project_esc, '||wwv_flow.LF||
'                   p.friendly_identifier fi, apex_escape.html(p.project_url_name) proj';
wwv_flow_imp.g_varchar2_table(154) := 'ect_url_name, '||wwv_flow.LF||
'                   p.owner_id, apex_escape.html(t.first_name) first_name, t.screen_na';
wwv_flow_imp.g_varchar2_table(155) := 'me'||wwv_flow.LF||
'              from sp_projects p, '||wwv_flow.LF||
'                   sp_team_members t'||wwv_flow.LF||
'             where p.id =';
wwv_flow_imp.g_varchar2_table(156) := ' p_project_id '||wwv_flow.LF||
'               and p.owner_id = t.id (+)'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            l_link := p_perma';
wwv_flow_imp.g_varchar2_table(157) := 'link_pre||c1.fi||''&pn=''||c1.project_url_name;'||wwv_flow.LF||
'            if apex_util.get_build_option_status (p_ap';
wwv_flow_imp.g_varchar2_table(158) := 'plication_id => p_app_id, p_build_option_name => ''Comment Tagging'') = ''INCLUDE'' then'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(159) := ' l_mentions := sp_util.find_mentions(l_comment_no_images);'||wwv_flow.LF||
'                -- mentions (not current ';
wwv_flow_imp.g_varchar2_table(160) := 'user)'||wwv_flow.LF||
'                if l_mentions is not null then'||wwv_flow.LF||
'                    for c2 in ('||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(161) := '         select id, apex_escape.html(first_name) first_name'||wwv_flow.LF||
'                          from sp_team_m';
wwv_flow_imp.g_varchar2_table(162) := 'embers'||wwv_flow.LF||
'                         where instr('':''||l_mentions||'':'','':''||screen_name||'':'') > 0'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(163) := '                   and id != p_app_user_id and screen_name is not null'||wwv_flow.LF||
'                    ) loop'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(164) := '                      sp_util.comment_notification ('||wwv_flow.LF||
'                            p_team_member_id =>';
wwv_flow_imp.g_varchar2_table(165) := ' c2.id, '||wwv_flow.LF||
'                            p_app_name       => p_nomen_sp, '||wwv_flow.LF||
'                            p_';
wwv_flow_imp.g_varchar2_table(166) := 'app_id         => p_app_id,'||wwv_flow.LF||
'                            p_title          => ''You were mentioned in a';
wwv_flow_imp.g_varchar2_table(167) := ' comment added to ''||c1.project_esc,'||wwv_flow.LF||
'                            p_project_id     => p_project_id, '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(168) := '                            p_link           => l_link, '||wwv_flow.LF||
'                            p_view_what    ';
wwv_flow_imp.g_varchar2_table(169) := '  => p_nomen_project,'||wwv_flow.LF||
'                            p_email_contents => ''Hi ''||c2.first_name||''<br/><b';
wwv_flow_imp.g_varchar2_table(170) := 'r/>''||'||wwv_flow.LF||
'                                                ''You were mentioned in a new comment added to';
wwv_flow_imp.g_varchar2_table(171) := ' <a  style="font-weight:bold" href="''||l_link||''">''||c1.project_esc||''</a><br/>''||'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(172) := '                               ''Comment by: ''||apex_escape.html(lower(p_app_user))||''<br/>''||'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(173) := '                                          l_email_comment,'||wwv_flow.LF||
'                            p_notificatio';
wwv_flow_imp.g_varchar2_table(174) := 'n_type => ''MENTION'' );'||wwv_flow.LF||
'                    end loop;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(175) := '          -- owner (not current user and not tagged in comment)'||wwv_flow.LF||
'            if c1.owner_id is not nu';
wwv_flow_imp.g_varchar2_table(176) := 'll and '||wwv_flow.LF||
'               c1.owner_id != p_app_user_id and '||wwv_flow.LF||
'               instr('':''||l_mentions||'':'',''';
wwv_flow_imp.g_varchar2_table(177) := ':''||c1.screen_name||'':'') = 0 '||wwv_flow.LF||
'            then'||wwv_flow.LF||
'               sp_util.comment_notification ('||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(178) := '             p_team_member_id => c1.owner_id, '||wwv_flow.LF||
'                    p_app_name       => p_nomen_sp,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(179) := '                   p_app_id         => p_app_id,'||wwv_flow.LF||
'                    p_title          => ''New commen';
wwv_flow_imp.g_varchar2_table(180) := 't added to ''||c1.project_esc,'||wwv_flow.LF||
'                    p_project_id     => p_project_id, '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(181) := '     p_link           => l_link, '||wwv_flow.LF||
'                    p_view_what      => p_nomen_project,'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(182) := '           p_email_contents => ''Hi ''||c1.first_name||''<br/><br/>''||'||wwv_flow.LF||
'                                ';
wwv_flow_imp.g_varchar2_table(183) := '        ''A new comment was just added to <a  style="font-weight:bold" href="''||l_link||''">''||c1.proj';
wwv_flow_imp.g_varchar2_table(184) := 'ect_esc||''</a><br/>''||'||wwv_flow.LF||
'                                        ''Comment by: ''||apex_escape.html(lowe';
wwv_flow_imp.g_varchar2_table(185) := 'r(p_app_user))||''<br/>''||'||wwv_flow.LF||
'                                        l_email_comment,'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(186) := '   p_notification_type => ''COMMENT'' );'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- favorited (not owner, not';
wwv_flow_imp.g_varchar2_table(187) := ' current user and not tagged in comment)'||wwv_flow.LF||
'            for c2 in ('||wwv_flow.LF||
'                select f.team_membe';
wwv_flow_imp.g_varchar2_table(188) := 'r_id, apex_escape.html(t.first_name) first_name'||wwv_flow.LF||
'                  from sp_favorites f,'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(189) := '          sp_team_members t'||wwv_flow.LF||
'                 where f.project_id = p_project_id'||wwv_flow.LF||
'                   an';
wwv_flow_imp.g_varchar2_table(190) := 'd f.team_member_id = t.id'||wwv_flow.LF||
'                   and f.team_member_id != p_app_user_id'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(191) := '  and f.team_member_id != c1.owner_id'||wwv_flow.LF||
'                   and t.screen_name is not null'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(192) := '      and instr('':''||l_mentions||'':'','':''||t.screen_name||'':'') = 0'||wwv_flow.LF||
'            ) loop'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(193) := ' sp_util.comment_notification ('||wwv_flow.LF||
'                    p_team_member_id => c2.team_member_id, '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(194) := '            p_app_name       => p_nomen_sp,'||wwv_flow.LF||
'                    p_app_id         => p_app_id,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(195) := '              p_title          => ''New comment added to ''||c1.project_esc,'||wwv_flow.LF||
'                    p_pro';
wwv_flow_imp.g_varchar2_table(196) := 'ject_id     => p_project_id, '||wwv_flow.LF||
'                    p_link           => l_link, '||wwv_flow.LF||
'                    p';
wwv_flow_imp.g_varchar2_table(197) := '_view_what      => p_nomen_project,'||wwv_flow.LF||
'                    p_email_contents => ''Hi ''||c2.first_name||''<';
wwv_flow_imp.g_varchar2_table(198) := 'br/><br/>''||'||wwv_flow.LF||
'                                        ''A new comment was just added to <a  style="fon';
wwv_flow_imp.g_varchar2_table(199) := 't-weight:bold" href="''||l_link||''">''||c1.project_esc||''</a><br/>''||'||wwv_flow.LF||
'                                ';
wwv_flow_imp.g_varchar2_table(200) := '        ''Comment by: ''||apex_escape.html(lower(p_app_user))||''<br/>''||'||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(201) := '           l_email_comment,'||wwv_flow.LF||
'                    p_notification_type => ''COMMENT'' );'||wwv_flow.LF||
'            end ';
wwv_flow_imp.g_varchar2_table(202) := 'loop;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end add_project_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_project_comment ('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(203) := '  p_comment_id      in  number,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  varcha';
wwv_flow_imp.g_varchar2_table(204) := 'r2 default ''N'','||wwv_flow.LF||
'    p_image_ref_id    in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_comment            clob;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(205) := '    l_comment_no_images  clob;'||wwv_flow.LF||
'    l_image_ref_id       number;'||wwv_flow.LF||
'    l_image_list         varchar2(40';
wwv_flow_imp.g_varchar2_table(206) := '00);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_comment           := replace_session_on_save(p_comment);'||wwv_flow.LF||
'    l_comment_no_images :=';
wwv_flow_imp.g_varchar2_table(207) := ' replace_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- for existing content, there may be no image_ref_id, so need to a';
wwv_flow_imp.g_varchar2_table(208) := 'dd one'||wwv_flow.LF||
'    update sp_project_comments'||wwv_flow.LF||
'       set body           = l_comment,'||wwv_flow.LF||
'           body_html   ';
wwv_flow_imp.g_varchar2_table(209) := '   = apex_markdown.to_html(l_comment),'||wwv_flow.LF||
'           body_no_images = l_comment_no_images,'||wwv_flow.LF||
'           p';
wwv_flow_imp.g_varchar2_table(210) := 'rivate_yn     = p_private_yn,'||wwv_flow.LF||
'           image_ref_id   = nvl(image_ref_id,to_number(sys_guid(), ''XX';
wwv_flow_imp.g_varchar2_table(211) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX''))'||wwv_flow.LF||
'     where id = p_comment_id'||wwv_flow.LF||
'    returning image_ref_id into l_ima';
wwv_flow_imp.g_varchar2_table(212) := 'ge_ref_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_image_list := find_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_image_list is not null then'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(213) := '  -- updating image_ref_id to match that of the existing content'||wwv_flow.LF||
'        update sp_comment_images'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(214) := '         set image_ref_id = l_image_ref_id '||wwv_flow.LF||
'         where instr('':''||l_image_list||'':'','':''||unique_';
wwv_flow_imp.g_varchar2_table(215) := 'filename||'':'') > 0'||wwv_flow.LF||
'           and image_ref_id = p_image_ref_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doing image cle';
wwv_flow_imp.g_varchar2_table(216) := 'anup'||wwv_flow.LF||
'    remove_orphan_images ('||wwv_flow.LF||
'        p_comment_id   => p_comment_id,'||wwv_flow.LF||
'        p_comment_type => ''P';
wwv_flow_imp.g_varchar2_table(217) := 'ROJECT'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- cleaning up old images, only on update'||wwv_flow.LF||
'    cleanup_old_images;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_private_y';
wwv_flow_imp.g_varchar2_table(218) := 'n = ''N'' then'||wwv_flow.LF||
'        set_comment_email_references(p_comment_id);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end update_project_comm';
wwv_flow_imp.g_varchar2_table(219) := 'ent;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_project_comment ('||wwv_flow.LF||
'    p_comment_id      in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_image_ref_id  ';
wwv_flow_imp.g_varchar2_table(220) := 'number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    select image_ref_id'||wwv_flow.LF||
'      into l_image_ref_id'||wwv_flow.LF||
'      from sp_project_comments'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(221) := 'where id = p_comment_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_image_ref_id is not null then'||wwv_flow.LF||
'        delete from sp_comment_imag';
wwv_flow_imp.g_varchar2_table(222) := 'es'||wwv_flow.LF||
'         where image_ref_id = l_image_ref_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    delete from sp_project_comments'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(223) := '   where id = p_comment_id;'||wwv_flow.LF||
'end delete_project_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
'-----------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_task';
wwv_flow_imp.g_varchar2_table(224) := '_comment ('||wwv_flow.LF||
'    p_app_user_id     in  number,'||wwv_flow.LF||
'    p_app_user        in  varchar2,'||wwv_flow.LF||
'    p_comment      ';
wwv_flow_imp.g_varchar2_table(225) := '   in  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_project_id      in  number,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(226) := '   p_task_id         in  number,'||wwv_flow.LF||
'    p_app_id          in  number,'||wwv_flow.LF||
'    p_link            in  varchar';
wwv_flow_imp.g_varchar2_table(227) := '2,'||wwv_flow.LF||
'    p_nomen_sp        in  varchar2,'||wwv_flow.LF||
'    p_image_ref_id    in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_co';
wwv_flow_imp.g_varchar2_table(228) := 'mment            clob;'||wwv_flow.LF||
'    l_comment_no_images  clob;'||wwv_flow.LF||
'    l_comment_id         number;'||wwv_flow.LF||
'    l_email_c';
wwv_flow_imp.g_varchar2_table(229) := 'omment      clob;'||wwv_flow.LF||
'    l_mentions           varchar2(4000);'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    l_comment           := replace';
wwv_flow_imp.g_varchar2_table(230) := '_session_on_save(p_comment);'||wwv_flow.LF||
'    l_comment_no_images := replace_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into ';
wwv_flow_imp.g_varchar2_table(231) := 'sp_task_comments ('||wwv_flow.LF||
'        task_id, '||wwv_flow.LF||
'        author_id, '||wwv_flow.LF||
'        body,'||wwv_flow.LF||
'        body_html, '||wwv_flow.LF||
'        b';
wwv_flow_imp.g_varchar2_table(232) := 'ody_no_images,'||wwv_flow.LF||
'        private_yn,'||wwv_flow.LF||
'        image_ref_id ) '||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_task_id,'||wwv_flow.LF||
'        p';
wwv_flow_imp.g_varchar2_table(233) := '_app_user_id,'||wwv_flow.LF||
'        l_comment,'||wwv_flow.LF||
'        apex_markdown.to_html(l_comment),'||wwv_flow.LF||
'        l_comment_no_imag';
wwv_flow_imp.g_varchar2_table(234) := 'es,'||wwv_flow.LF||
'        p_private_yn,'||wwv_flow.LF||
'        p_image_ref_id )'||wwv_flow.LF||
'    returning id into l_comment_id;'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(235) := '    -- doing image cleanup'||wwv_flow.LF||
'    remove_orphan_images ('||wwv_flow.LF||
'        p_comment_id   => l_comment_id,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(236) := '  p_comment_type => ''TASK'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_private_yn = ''N'' then'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_email_comment := apex_markd';
wwv_flow_imp.g_varchar2_table(237) := 'own.to_html(substr(l_comment_no_images,1,3000)||case when length(l_comment_no_images) > 3000 then '' ';
wwv_flow_imp.g_varchar2_table(238) := '...'' end);'||wwv_flow.LF||
''||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            select p.project, '||wwv_flow.LF||
'                   apex_escape.html(p';
wwv_flow_imp.g_varchar2_table(239) := '.project) project_esc,'||wwv_flow.LF||
'                   apex_escape.html((select task_type from sp_task_types rt w';
wwv_flow_imp.g_varchar2_table(240) := 'here rt.id = a.task_type_id)||'||wwv_flow.LF||
'                                     case when a.task_sub_type_id is ';
wwv_flow_imp.g_varchar2_table(241) := 'not null then '': '' end ||'||wwv_flow.LF||
'                                     (select task_type from sp_task_types ';
wwv_flow_imp.g_varchar2_table(242) := 'rt where rt.id = a.task_sub_type_id) ||'||wwv_flow.LF||
'                                     case when a.task is not';
wwv_flow_imp.g_varchar2_table(243) := ' null then '' - ''||a.task end) task_name,'||wwv_flow.LF||
'                   apex_escape.html((select rt.task_type'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(244) := '                                     from sp_task_types rt'||wwv_flow.LF||
'                                      whe';
wwv_flow_imp.g_varchar2_table(245) := 're a.id = p_task_id'||wwv_flow.LF||
'                                        and rt.id = a.task_type_id)) parent_task';
wwv_flow_imp.g_varchar2_table(246) := '_type,'||wwv_flow.LF||
'                   p.owner_id, apex_escape.html(t.first_name) first_name, t.screen_name'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(247) := '         from sp_projects p, '||wwv_flow.LF||
'                   sp_tasks a,'||wwv_flow.LF||
'                   sp_team_members t'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(248) := '           where p.id = p_project_id '||wwv_flow.LF||
'               and a.id = p_task_id'||wwv_flow.LF||
'               and p.owner';
wwv_flow_imp.g_varchar2_table(249) := '_id = t.id (+)'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            if apex_util.get_build_option_status (p_application_id => ';
wwv_flow_imp.g_varchar2_table(250) := 'p_app_id, p_build_option_name => ''Comment Tagging'') = ''INCLUDE'' then'||wwv_flow.LF||
'                l_mentions := s';
wwv_flow_imp.g_varchar2_table(251) := 'p_util.find_mentions(l_comment_no_images);'||wwv_flow.LF||
'                -- mentions (not current user)'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(252) := '      if l_mentions is not null then'||wwv_flow.LF||
'                    for c2 in ('||wwv_flow.LF||
'                        select ';
wwv_flow_imp.g_varchar2_table(253) := 'id, first_name'||wwv_flow.LF||
'                          from sp_team_members'||wwv_flow.LF||
'                         where instr(''';
wwv_flow_imp.g_varchar2_table(254) := ':''||l_mentions||'':'','':''||screen_name||'':'') > 0'||wwv_flow.LF||
'                           and id != p_app_user_id '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(255) := '                          and screen_name is not null'||wwv_flow.LF||
'                    ) loop'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(256) := '     sp_util.comment_notification ('||wwv_flow.LF||
'                            p_team_member_id => c2.id, '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(257) := '                    p_app_name       => p_nomen_sp, '||wwv_flow.LF||
'                            p_app_id         =>';
wwv_flow_imp.g_varchar2_table(258) := ' p_app_id,'||wwv_flow.LF||
'                            p_title          => ''You were mentioned in a comment added to';
wwv_flow_imp.g_varchar2_table(259) := ' ''||c1.project_esc||'' - ''||c1.task_name,'||wwv_flow.LF||
'                            p_project_id     => p_project_i';
wwv_flow_imp.g_varchar2_table(260) := 'd, '||wwv_flow.LF||
'                            p_task_id        => p_task_id,'||wwv_flow.LF||
'                            p_link   ';
wwv_flow_imp.g_varchar2_table(261) := '        => p_link, '||wwv_flow.LF||
'                            p_view_what      => c1.parent_task_type,'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(262) := '                 p_email_contents => ''Hi ''||c2.first_name||''<br/><br/>''||'||wwv_flow.LF||
'                          ';
wwv_flow_imp.g_varchar2_table(263) := '                      ''You were mentioned in a new comment added to ''||c1.project_esc||'' - <a  style';
wwv_flow_imp.g_varchar2_table(264) := '="font-weight:bold" href="''||p_link||''">''||apex_escape.html(c1.task_name)||''</a><br/>''||'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(265) := '                                     ''Comment by: ''||apex_escape.html(lower(p_app_user))||''<br/>''||'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(266) := '                                                l_email_comment,'||wwv_flow.LF||
'                            p_notif';
wwv_flow_imp.g_varchar2_table(267) := 'ication_type => ''MENTION'' );'||wwv_flow.LF||
'                    end loop;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end i';
wwv_flow_imp.g_varchar2_table(268) := 'f;'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- owner (not current user and not tagged in comment)'||wwv_flow.LF||
'            if c1.owner_id is ';
wwv_flow_imp.g_varchar2_table(269) := 'not null and '||wwv_flow.LF||
'               c1.owner_id != p_app_user_id and '||wwv_flow.LF||
'               instr('':''||l_mentions|';
wwv_flow_imp.g_varchar2_table(270) := '|'':'','':''||c1.screen_name||'':'') = 0 '||wwv_flow.LF||
'            then'||wwv_flow.LF||
'               sp_util.comment_notification ('||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(271) := '                   p_team_member_id => c1.owner_id, '||wwv_flow.LF||
'                    p_app_name       => p_nomen';
wwv_flow_imp.g_varchar2_table(272) := '_sp,'||wwv_flow.LF||
'                    p_app_id         => p_app_id,'||wwv_flow.LF||
'                    p_title          => ''New ';
wwv_flow_imp.g_varchar2_table(273) := 'comment added to ''||c1.project_esc||'' - ''||c1.task_name,'||wwv_flow.LF||
'                    p_project_id     => p_p';
wwv_flow_imp.g_varchar2_table(274) := 'roject_id, '||wwv_flow.LF||
'                    p_task_id        => p_task_id,'||wwv_flow.LF||
'                    p_link           ';
wwv_flow_imp.g_varchar2_table(275) := '=> p_link, '||wwv_flow.LF||
'                    p_view_what      => c1.parent_task_type,'||wwv_flow.LF||
'                    p_email';
wwv_flow_imp.g_varchar2_table(276) := '_contents => ''Hi ''||c1.first_name||''<br/><br/>''||'||wwv_flow.LF||
'                                        ''A new com';
wwv_flow_imp.g_varchar2_table(277) := 'ment was just added to ''||c1.project_esc||'' - <a  style="font-weight:bold" href="''||p_link||''">''||ap';
wwv_flow_imp.g_varchar2_table(278) := 'ex_escape.html(c1.task_name)||''</a><br/>''||'||wwv_flow.LF||
'                                        ''Comment by: ''||';
wwv_flow_imp.g_varchar2_table(279) := 'apex_escape.html(lower(p_app_user))||''<br/>''||'||wwv_flow.LF||
'                                        l_email_comme';
wwv_flow_imp.g_varchar2_table(280) := 'nt,'||wwv_flow.LF||
'                    p_notification_type => ''COMMENT'' );'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- task';
wwv_flow_imp.g_varchar2_table(281) := ' owner (not project owner, current user and not tagged in comment)'||wwv_flow.LF||
'            for c2 in ('||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(282) := '       select a.owner_id team_member_id, apex_escape.html(t.first_name) first_name'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(283) := ' from sp_tasks a,'||wwv_flow.LF||
'                       sp_team_members t'||wwv_flow.LF||
'                 where a.id = p_task_id'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(284) := '                  and a.owner_id = t.id'||wwv_flow.LF||
'                   and a.owner_id != p_app_user_id'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(285) := '          and a.owner_id != c1.owner_id'||wwv_flow.LF||
'                   and instr('':''||l_mentions||'':'','':''||t.scr';
wwv_flow_imp.g_varchar2_table(286) := 'een_name||'':'') = 0'||wwv_flow.LF||
'            ) loop'||wwv_flow.LF||
'                sp_util.comment_notification ('||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(287) := '     p_team_member_id => c2.team_member_id, '||wwv_flow.LF||
'                    p_app_name       => p_nomen_sp,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(288) := '                 p_app_id         => p_app_id,'||wwv_flow.LF||
'                    p_title          => ''New comment ';
wwv_flow_imp.g_varchar2_table(289) := 'added to ''||c1.project_esc||'' - ''||c1.task_name,'||wwv_flow.LF||
'                    p_project_id     => p_project_i';
wwv_flow_imp.g_varchar2_table(290) := 'd, '||wwv_flow.LF||
'                    p_task_id        => p_task_id,'||wwv_flow.LF||
'                    p_link           => p_lin';
wwv_flow_imp.g_varchar2_table(291) := 'k, '||wwv_flow.LF||
'                    p_view_what      => c1.parent_task_type,'||wwv_flow.LF||
'                    p_email_content';
wwv_flow_imp.g_varchar2_table(292) := 's => ''Hi ''||c2.first_name||''<br/><br/>''||'||wwv_flow.LF||
'                                        ''A new comment was';
wwv_flow_imp.g_varchar2_table(293) := ' just added to ''||c1.project_esc||'' - <a  style="font-weight:bold" href="''||p_link||''">''||apex_escap';
wwv_flow_imp.g_varchar2_table(294) := 'e.html(c1.task_name)||''</a><br/>''||'||wwv_flow.LF||
'                                        ''Comment by: ''||apex_esc';
wwv_flow_imp.g_varchar2_table(295) := 'ape.html(lower(p_app_user))||''<br/>''||'||wwv_flow.LF||
'                                        l_email_comment,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(296) := '                p_notification_type => ''COMMENT'' );'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- favorited ';
wwv_flow_imp.g_varchar2_table(297) := '(not owner, not current user and not tagged in comment)'||wwv_flow.LF||
'            for c2 in ('||wwv_flow.LF||
'                sele';
wwv_flow_imp.g_varchar2_table(298) := 'ct f.team_member_id, apex_escape.html(t.first_name) first_name'||wwv_flow.LF||
'                  from sp_favorites f';
wwv_flow_imp.g_varchar2_table(299) := ','||wwv_flow.LF||
'                       sp_team_members t'||wwv_flow.LF||
'                 where f.project_id = p_project_id'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(300) := '             and f.team_member_id = t.id'||wwv_flow.LF||
'                   and f.team_member_id != p_app_user_id'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(301) := '                 and f.team_member_id != c1.owner_id'||wwv_flow.LF||
'                   and t.screen_name is not nul';
wwv_flow_imp.g_varchar2_table(302) := 'l'||wwv_flow.LF||
'                   and instr('':''||l_mentions||'':'','':''||t.screen_name||'':'') = 0'||wwv_flow.LF||
'            ) loop'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(303) := '                sp_util.comment_notification ('||wwv_flow.LF||
'                    p_team_member_id => c2.team_membe';
wwv_flow_imp.g_varchar2_table(304) := 'r_id, '||wwv_flow.LF||
'                    p_app_name       => p_nomen_sp,'||wwv_flow.LF||
'                    p_app_id         => p';
wwv_flow_imp.g_varchar2_table(305) := '_app_id,'||wwv_flow.LF||
'                    p_title          => ''New comment added to ''||c1.project_esc||'' - ''||c1.';
wwv_flow_imp.g_varchar2_table(306) := 'task_name,'||wwv_flow.LF||
'                    p_project_id     => p_project_id, '||wwv_flow.LF||
'                    p_task_id     ';
wwv_flow_imp.g_varchar2_table(307) := '   => p_task_id,'||wwv_flow.LF||
'                    p_link           => p_link, '||wwv_flow.LF||
'                    p_view_what   ';
wwv_flow_imp.g_varchar2_table(308) := '   => c1.parent_task_type,'||wwv_flow.LF||
'                    p_email_contents => ''Hi ''||c2.first_name||''<br/><br/>';
wwv_flow_imp.g_varchar2_table(309) := '''||'||wwv_flow.LF||
'                                        ''A new comment was just added to ''||c1.project_esc||'' - ';
wwv_flow_imp.g_varchar2_table(310) := '<a  style="font-weight:bold" href="''||p_link||''">''||apex_escape.html(c1.task_name)||''</a><br/>''||'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(311) := '                                      ''Comment by: ''||apex_escape.html(lower(p_app_user))||''<br/>''||';
wwv_flow_imp.g_varchar2_table(312) := ''||wwv_flow.LF||
'                                        l_email_comment,'||wwv_flow.LF||
'                    p_notification_type =>';
wwv_flow_imp.g_varchar2_table(313) := ' ''COMMENT'' );'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end add_task_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure ';
wwv_flow_imp.g_varchar2_table(314) := 'update_task_comment ('||wwv_flow.LF||
'    p_comment_id      in  number,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_pr';
wwv_flow_imp.g_varchar2_table(315) := 'ivate_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_image_ref_id    in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_c';
wwv_flow_imp.g_varchar2_table(316) := 'omment            clob;'||wwv_flow.LF||
'    l_comment_no_images  clob;'||wwv_flow.LF||
'    l_image_ref_id       number;'||wwv_flow.LF||
'    l_image_';
wwv_flow_imp.g_varchar2_table(317) := 'list         varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_comment           := replace_session_on_save(p_comment);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(318) := '  l_comment_no_images := replace_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- for existing content, there may be no im';
wwv_flow_imp.g_varchar2_table(319) := 'age_ref_id, so need to add one'||wwv_flow.LF||
'    update sp_task_comments'||wwv_flow.LF||
'       set body           = l_comment,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(320) := '         body_html      = apex_markdown.to_html(l_comment),'||wwv_flow.LF||
'           body_no_images = l_comment_no';
wwv_flow_imp.g_varchar2_table(321) := '_images,'||wwv_flow.LF||
'           private_yn     = p_private_yn,'||wwv_flow.LF||
'           image_ref_id   = nvl(image_ref_id,to_n';
wwv_flow_imp.g_varchar2_table(322) := 'umber(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX''))'||wwv_flow.LF||
'     where id = p_comment_id'||wwv_flow.LF||
'    returning im';
wwv_flow_imp.g_varchar2_table(323) := 'age_ref_id into l_image_ref_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_image_list := find_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_image_list is';
wwv_flow_imp.g_varchar2_table(324) := ' not null then'||wwv_flow.LF||
'        -- updating image_ref_id to match that of the existing content'||wwv_flow.LF||
'        update';
wwv_flow_imp.g_varchar2_table(325) := ' sp_comment_images'||wwv_flow.LF||
'           set image_ref_id = l_image_ref_id '||wwv_flow.LF||
'         where instr('':''||l_image_l';
wwv_flow_imp.g_varchar2_table(326) := 'ist||'':'','':''||unique_filename||'':'') > 0'||wwv_flow.LF||
'           and image_ref_id = p_image_ref_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(327) := '   -- doing image cleanup'||wwv_flow.LF||
'    remove_orphan_images ('||wwv_flow.LF||
'        p_comment_id   => p_comment_id,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(328) := ' p_comment_type => ''TASK'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- cleaning up old images, only on update'||wwv_flow.LF||
'    cleanup_old_images;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(329) := '   '||wwv_flow.LF||
'end update_task_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_task_comment ('||wwv_flow.LF||
'    p_comment_id      in  number )'||wwv_flow.LF||
'is';
wwv_flow_imp.g_varchar2_table(330) := ''||wwv_flow.LF||
'    l_image_ref_id  number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    select image_ref_id'||wwv_flow.LF||
'      into l_image_ref_id'||wwv_flow.LF||
'      from sp_t';
wwv_flow_imp.g_varchar2_table(331) := 'ask_comments'||wwv_flow.LF||
'     where id = p_comment_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_image_ref_id is not null then'||wwv_flow.LF||
'        delete fr';
wwv_flow_imp.g_varchar2_table(332) := 'om sp_comment_images'||wwv_flow.LF||
'         where image_ref_id = l_image_ref_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    delete from sp_t';
wwv_flow_imp.g_varchar2_table(333) := 'ask_comments'||wwv_flow.LF||
'     where id = p_comment_id;'||wwv_flow.LF||
'end delete_task_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'proc';
wwv_flow_imp.g_varchar2_table(334) := 'edure add_release_comment ('||wwv_flow.LF||
'    p_app_user_id     in  number,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(335) := '  p_release_id      in  number,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_image_ref_id  ';
wwv_flow_imp.g_varchar2_table(336) := '  in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_comment            clob;'||wwv_flow.LF||
'    l_comment_no_images  clob;'||wwv_flow.LF||
'    l';
wwv_flow_imp.g_varchar2_table(337) := '_comment_id         number;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    l_comment           := replace_session_on_save(p_comment);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(338) := '  l_comment_no_images := replace_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_release_comments ('||wwv_flow.LF||
'        r';
wwv_flow_imp.g_varchar2_table(339) := 'elease_id, '||wwv_flow.LF||
'        author_id, '||wwv_flow.LF||
'        body,'||wwv_flow.LF||
'        body_html, '||wwv_flow.LF||
'        body_no_images,'||wwv_flow.LF||
'        pr';
wwv_flow_imp.g_varchar2_table(340) := 'ivate_yn,'||wwv_flow.LF||
'        image_ref_id ) '||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_release_id,'||wwv_flow.LF||
'        p_app_user_id,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(341) := 'l_comment,'||wwv_flow.LF||
'        apex_markdown.to_html(l_comment),'||wwv_flow.LF||
'        l_comment_no_images,'||wwv_flow.LF||
'        p_private_';
wwv_flow_imp.g_varchar2_table(342) := 'yn,'||wwv_flow.LF||
'        p_image_ref_id )'||wwv_flow.LF||
'    returning id into l_comment_id;'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doing image cle';
wwv_flow_imp.g_varchar2_table(343) := 'anup'||wwv_flow.LF||
'    remove_orphan_images ('||wwv_flow.LF||
'        p_comment_id   => l_comment_id,'||wwv_flow.LF||
'        p_comment_type => ''R';
wwv_flow_imp.g_varchar2_table(344) := 'ELEASE'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'end add_release_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_release_comment ('||wwv_flow.LF||
'    p_comment_id      in  ';
wwv_flow_imp.g_varchar2_table(345) := 'number,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_im';
wwv_flow_imp.g_varchar2_table(346) := 'age_ref_id    in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_comment            clob;'||wwv_flow.LF||
'    l_comment_no_images ';
wwv_flow_imp.g_varchar2_table(347) := ' clob;'||wwv_flow.LF||
'    l_image_ref_id       number;'||wwv_flow.LF||
'    l_image_list         varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_comment';
wwv_flow_imp.g_varchar2_table(348) := '           := replace_session_on_save(p_comment);'||wwv_flow.LF||
'    l_comment_no_images := replace_images(l_commen';
wwv_flow_imp.g_varchar2_table(349) := 't);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- for existing content, there may be no image_ref_id, so need to add one'||wwv_flow.LF||
'    update sp_rel';
wwv_flow_imp.g_varchar2_table(350) := 'ease_comments'||wwv_flow.LF||
'       set body           = l_comment,'||wwv_flow.LF||
'           body_html      = apex_markdown.to_ht';
wwv_flow_imp.g_varchar2_table(351) := 'ml(l_comment),'||wwv_flow.LF||
'           body_no_images = l_comment_no_images,'||wwv_flow.LF||
'           private_yn     = p_privat';
wwv_flow_imp.g_varchar2_table(352) := 'e_yn,'||wwv_flow.LF||
'           image_ref_id   = nvl(image_ref_id,to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(353) := 'XXXXXX''))'||wwv_flow.LF||
'     where id = p_comment_id'||wwv_flow.LF||
'    returning image_ref_id into l_image_ref_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_image_';
wwv_flow_imp.g_varchar2_table(354) := 'list := find_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_image_list is not null then'||wwv_flow.LF||
'        -- updating image_ref_';
wwv_flow_imp.g_varchar2_table(355) := 'id to match that of the existing content'||wwv_flow.LF||
'        update sp_comment_images'||wwv_flow.LF||
'           set image_ref_i';
wwv_flow_imp.g_varchar2_table(356) := 'd = l_image_ref_id '||wwv_flow.LF||
'         where instr('':''||l_image_list||'':'','':''||unique_filename||'':'') > 0'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(357) := '      and image_ref_id = p_image_ref_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doing image cleanup'||wwv_flow.LF||
'    remove_orphan_i';
wwv_flow_imp.g_varchar2_table(358) := 'mages ('||wwv_flow.LF||
'        p_comment_id   => p_comment_id,'||wwv_flow.LF||
'        p_comment_type => ''RELEASE'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- cleani';
wwv_flow_imp.g_varchar2_table(359) := 'ng up old images, only on update'||wwv_flow.LF||
'    cleanup_old_images;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'end update_release_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedur';
wwv_flow_imp.g_varchar2_table(360) := 'e delete_release_comment ('||wwv_flow.LF||
'    p_comment_id      in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_image_ref_id  number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(361) := '   select image_ref_id'||wwv_flow.LF||
'      into l_image_ref_id'||wwv_flow.LF||
'      from sp_release_comments'||wwv_flow.LF||
'     where id = p_co';
wwv_flow_imp.g_varchar2_table(362) := 'mment_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_image_ref_id is not null then'||wwv_flow.LF||
'        delete from sp_comment_images'||wwv_flow.LF||
'         whe';
wwv_flow_imp.g_varchar2_table(363) := 're image_ref_id = l_image_ref_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    delete from sp_release_comments'||wwv_flow.LF||
'     where id = p';
wwv_flow_imp.g_varchar2_table(364) := '_comment_id;'||wwv_flow.LF||
'end delete_release_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_init_focus_area_c';
wwv_flow_imp.g_varchar2_table(365) := 'omment ('||wwv_flow.LF||
'    p_app_user_id         in  number,'||wwv_flow.LF||
'    p_comment             in  varchar2,'||wwv_flow.LF||
'    p_init_fo';
wwv_flow_imp.g_varchar2_table(366) := 'cus_area_id  in  number,'||wwv_flow.LF||
'    p_private_yn          in  varchar2 default ''N'','||wwv_flow.LF||
'    p_image_ref_id     ';
wwv_flow_imp.g_varchar2_table(367) := '   in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_comment            clob;'||wwv_flow.LF||
'    l_comment_no_images  clob;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(368) := 'l_comment_id         number;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    l_comment           := replace_session_on_save(p_comment);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(369) := '   l_comment_no_images := replace_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_init_focus_area_comments ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(370) := '        init_focus_area_id, '||wwv_flow.LF||
'        author_id, '||wwv_flow.LF||
'        body,'||wwv_flow.LF||
'        body_html, '||wwv_flow.LF||
'        body_no_i';
wwv_flow_imp.g_varchar2_table(371) := 'mages,'||wwv_flow.LF||
'        private_yn,'||wwv_flow.LF||
'        image_ref_id ) '||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_init_focus_area_id,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(372) := '  p_app_user_id,'||wwv_flow.LF||
'        l_comment,'||wwv_flow.LF||
'        apex_markdown.to_html(l_comment),'||wwv_flow.LF||
'        l_comment_no_i';
wwv_flow_imp.g_varchar2_table(373) := 'mages,'||wwv_flow.LF||
'        p_private_yn,'||wwv_flow.LF||
'        p_image_ref_id )'||wwv_flow.LF||
'    returning id into l_comment_id;'||wwv_flow.LF||
'    commit';
wwv_flow_imp.g_varchar2_table(374) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doing image cleanup'||wwv_flow.LF||
'    remove_orphan_images ('||wwv_flow.LF||
'        p_comment_id   => l_comment_id,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(375) := '     p_comment_type => ''INIT_FOCUS_AREA'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'end add_init_focus_area_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_ini';
wwv_flow_imp.g_varchar2_table(376) := 't_focus_area_comment ('||wwv_flow.LF||
'    p_comment_id      in  number,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_p';
wwv_flow_imp.g_varchar2_table(377) := 'rivate_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_image_ref_id    in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_';
wwv_flow_imp.g_varchar2_table(378) := 'comment            clob;'||wwv_flow.LF||
'    l_comment_no_images  clob;'||wwv_flow.LF||
'    l_image_ref_id       number;'||wwv_flow.LF||
'    l_image';
wwv_flow_imp.g_varchar2_table(379) := '_list         varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_comment           := replace_session_on_save(p_comment);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(380) := '   l_comment_no_images := replace_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- for existing content, there may be no i';
wwv_flow_imp.g_varchar2_table(381) := 'mage_ref_id, so need to add one'||wwv_flow.LF||
'    update sp_init_focus_area_comments'||wwv_flow.LF||
'       set body           = l';
wwv_flow_imp.g_varchar2_table(382) := '_comment,'||wwv_flow.LF||
'           body_html      = apex_markdown.to_html(l_comment),'||wwv_flow.LF||
'           body_no_images = ';
wwv_flow_imp.g_varchar2_table(383) := 'l_comment_no_images,'||wwv_flow.LF||
'           private_yn     = p_private_yn,'||wwv_flow.LF||
'           image_ref_id   = nvl(image';
wwv_flow_imp.g_varchar2_table(384) := '_ref_id,to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX''))'||wwv_flow.LF||
'     where id = p_comment_id'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(385) := 'returning image_ref_id into l_image_ref_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_image_list := find_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_i';
wwv_flow_imp.g_varchar2_table(386) := 'mage_list is not null then'||wwv_flow.LF||
'        -- updating image_ref_id to match that of the existing content'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(387) := '      update sp_comment_images'||wwv_flow.LF||
'           set image_ref_id = l_image_ref_id '||wwv_flow.LF||
'         where instr('':';
wwv_flow_imp.g_varchar2_table(388) := '''||l_image_list||'':'','':''||unique_filename||'':'') > 0'||wwv_flow.LF||
'           and image_ref_id = p_image_ref_id;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(389) := '  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doing image cleanup'||wwv_flow.LF||
'    remove_orphan_images ('||wwv_flow.LF||
'        p_comment_id   => p_comment';
wwv_flow_imp.g_varchar2_table(390) := '_id,'||wwv_flow.LF||
'        p_comment_type => ''INIT_FOCUS_AREA'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- cleaning up old images, only on update'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(391) := '  cleanup_old_images;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'end update_init_focus_area_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_init_focus_area_co';
wwv_flow_imp.g_varchar2_table(392) := 'mment ('||wwv_flow.LF||
'    p_comment_id      in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_image_ref_id  number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    select image_ref';
wwv_flow_imp.g_varchar2_table(393) := '_id'||wwv_flow.LF||
'      into l_image_ref_id'||wwv_flow.LF||
'      from sp_init_focus_area_comments'||wwv_flow.LF||
'     where id = p_comment_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(394) := '    if l_image_ref_id is not null then'||wwv_flow.LF||
'        delete from sp_comment_images'||wwv_flow.LF||
'         where image_re';
wwv_flow_imp.g_varchar2_table(395) := 'f_id = l_image_ref_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    delete from sp_init_focus_area_comments'||wwv_flow.LF||
'     where id = p_co';
wwv_flow_imp.g_varchar2_table(396) := 'mment_id;'||wwv_flow.LF||
'end delete_init_focus_area_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
'----------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure upload_image ('||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(397) := 'p_file_base64           in  clob,'||wwv_flow.LF||
'    p_filename              in  varchar2,'||wwv_flow.LF||
'    p_mimetype          ';
wwv_flow_imp.g_varchar2_table(398) := '    in  varchar2,'||wwv_flow.LF||
'    p_image_ref_id          in  number ) '||wwv_flow.LF||
'as'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_rte_file_types     varchar2(25';
wwv_flow_imp.g_varchar2_table(399) := '5) := ''jpeg|image/jpeg,jpg|image/jpg,gif|image/gif,png|image/png,webp|image/webp'';'||wwv_flow.LF||
'    l_unique_file';
wwv_flow_imp.g_varchar2_table(400) := 'name    sp_comment_images.unique_filename%type;'||wwv_flow.LF||
'    l_max_file_size_mb   pls_integer := 3;'||wwv_flow.LF||
'    l_fil';
wwv_flow_imp.g_varchar2_table(401) := 'e               blob;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- Exceptions'||wwv_flow.LF||
'    e_image_too_large    exception;'||wwv_flow.LF||
'    e_invalid_mime_type';
wwv_flow_imp.g_varchar2_table(402) := '  exception;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- Handles JSON message error handling'||wwv_flow.LF||
'    procedure send_error ('||wwv_flow.LF||
'        p_messag';
wwv_flow_imp.g_varchar2_table(403) := 'e in varchar2 )'||wwv_flow.LF||
'    as'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        apex_json.open_object;'||wwv_flow.LF||
'        apex_json.open_object(''error';
wwv_flow_imp.g_varchar2_table(404) := ''');'||wwv_flow.LF||
'        apex_json.write(''message'', p_message);'||wwv_flow.LF||
'        apex_json.close_object;'||wwv_flow.LF||
'        apex_json';
wwv_flow_imp.g_varchar2_table(405) := '.close_object;'||wwv_flow.LF||
'    end send_error;'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_file := apex_web_service.clobbase642blob(p_file_base';
wwv_flow_imp.g_varchar2_table(406) := '64);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- Validations'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- File not too big'||wwv_flow.LF||
'    if sys.dbms_lob.getlength(l_file) / ( power(10';
wwv_flow_imp.g_varchar2_table(407) := '24, 3) / 1024 ) > l_max_file_size_mb then'||wwv_flow.LF||
'        raise e_image_too_large;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- Valid';
wwv_flow_imp.g_varchar2_table(408) := ' mimetype'||wwv_flow.LF||
'    if instr(l_rte_file_types, ''|'' || lower(p_mimetype), 1) = 0 then'||wwv_flow.LF||
'        raise e_inval';
wwv_flow_imp.g_varchar2_table(409) := 'id_mime_type;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_unique_filename := sys.dbms_random.string(''a'',8) || ''-'' || substr(s';
wwv_flow_imp.g_varchar2_table(410) := 'ys.dbms_random.normal,-4) || ''-'' || sys.dbms_random.string(''a'',8);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_comment_image';
wwv_flow_imp.g_varchar2_table(411) := 's'||wwv_flow.LF||
'        (file_blob, unique_filename, filename, mimetype, blob_size, '||wwv_flow.LF||
'         created, created_by,';
wwv_flow_imp.g_varchar2_table(412) := ' image_ref_id)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (l_file, l_unique_filename, p_filename, p_mimetype, sys.dbms_lob.g';
wwv_flow_imp.g_varchar2_table(413) := 'etlength(l_file), '||wwv_flow.LF||
'         sysdate, apex_application.g_user, p_image_ref_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'    apex_json.open_o';
wwv_flow_imp.g_varchar2_table(414) := 'bject;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- P9000: Rejoin Sessions: Enabled for all sessions (where supported)'||wwv_flow.LF||
'    apex_json.writ';
wwv_flow_imp.g_varchar2_table(415) := 'e(''url'', '||wwv_flow.LF||
'        apex_page.get_url ('||wwv_flow.LF||
'            p_page => 9000,'||wwv_flow.LF||
'            p_plain_url => true,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(416) := '           p_x01  => l_unique_filename'||wwv_flow.LF||
'        )'||wwv_flow.LF||
'    );'||wwv_flow.LF||
' '||wwv_flow.LF||
'    apex_json.write(''mimetype'', p_mimetype';
wwv_flow_imp.g_varchar2_table(417) := ');'||wwv_flow.LF||
'    apex_json.close_object;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'        when e_image_too_large then'||wwv_flow.LF||
'            send_error';
wwv_flow_imp.g_varchar2_table(418) := ' ('||wwv_flow.LF||
'                p_message => apex_string.format('||wwv_flow.LF||
'                    p_message  => ''File too larg';
wwv_flow_imp.g_varchar2_table(419) := 'e must be less than %0MB'','||wwv_flow.LF||
'                    p0         => l_max_file_size_mb'||wwv_flow.LF||
'                )'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(420) := '          );'||wwv_flow.LF||
'        when e_invalid_mime_type then'||wwv_flow.LF||
'            send_error(p_message => ''Invalid mime';
wwv_flow_imp.g_varchar2_table(421) := 'type'');'||wwv_flow.LF||
'        when others then'||wwv_flow.LF||
'            send_error(p_message => ''Could not upload file: '' || sq';
wwv_flow_imp.g_varchar2_table(422) := 'lerrm );'||wwv_flow.LF||
'end upload_image;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure display_image ('||wwv_flow.LF||
'    p_unique_filename  in  varchar2 )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(423) := 'l_file_blob  sp_comment_images.file_blob%type;'||wwv_flow.LF||
'    l_mimetype   sp_comment_images.mimetype%type;'||wwv_flow.LF||
'beg';
wwv_flow_imp.g_varchar2_table(424) := 'in'||wwv_flow.LF||
''||wwv_flow.LF||
'    select file_blob, mimetype'||wwv_flow.LF||
'      into l_file_blob, l_mimetype'||wwv_flow.LF||
'      from sp_comment_images'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(425) := '    where unique_filename = apex_application.g_x01;'||wwv_flow.LF||
''||wwv_flow.LF||
'    apex_http.download ('||wwv_flow.LF||
'        p_blob        ';
wwv_flow_imp.g_varchar2_table(426) := ' => l_file_blob,'||wwv_flow.LF||
'        p_content_type => l_mimetype,'||wwv_flow.LF||
'        p_is_inline    => true );'||wwv_flow.LF||
''||wwv_flow.LF||
'end displa';
wwv_flow_imp.g_varchar2_table(427) := 'y_image;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_comment_util;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(22990085173248580272)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_comment_util body'
,p_sequence=>765
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
