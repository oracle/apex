prompt --application/deployment/install/install_seed_project_scales
begin
--   Manifest
--     INSTALL: INSTALL-seed project scales
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into sp_project_scales (scale_letter, scale_name, is_active_yn, min_pc_for_status,'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(2) := '                     pc0_label, pc0_desc, pc10_label, pc10_desc,'||wwv_flow.LF||
'                               pc20';
wwv_flow_imp.g_varchar2_table(3) := '_label, pc20_desc, pc30_label, pc30_desc,'||wwv_flow.LF||
'                               pc40_label, pc40_desc, pc50';
wwv_flow_imp.g_varchar2_table(4) := '_label, pc50_desc,'||wwv_flow.LF||
'                               pc60_label, pc60_desc, pc70_label, pc70_desc,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(5) := '                           pc80_label, pc80_desc, pc90_label, pc90_desc,'||wwv_flow.LF||
'                           ';
wwv_flow_imp.g_varchar2_table(6) := '    pc100_label, pc100_desc) '||wwv_flow.LF||
'                       values (''A'', ''Product Dev'',''Y'', 30,'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(7) := '                    ''Not Feasible'', ''Project is not possible or not desirable or is a duplicate'','||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(8) := '                             ''Identified'', ''A new project has been identified and formally proposed''';
wwv_flow_imp.g_varchar2_table(9) := ','||wwv_flow.LF||
'                               ''Desirable'', ''Project is determined to be worthy of consideration a';
wwv_flow_imp.g_varchar2_table(10) := 'nd is perceived as desirable'','||wwv_flow.LF||
'                               ''Architecting'', ''The implementation sp';
wwv_flow_imp.g_varchar2_table(11) := 'ecification is under development'','||wwv_flow.LF||
'                               ''Specification Approved'', ''The spe';
wwv_flow_imp.g_varchar2_table(12) := 'cification is sufficiently complete to begin development and has been formally reviewed'','||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(13) := '                     ''Active Development'', ''Project is assigned and currently in active development''';
wwv_flow_imp.g_varchar2_table(14) := ','||wwv_flow.LF||
'                               ''Demonstrable'', ''Project is partially functioning'','||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(15) := '                ''In Review'', ''Project is merged into the mainline'','||wwv_flow.LF||
'                               ''';
wwv_flow_imp.g_varchar2_table(16) := 'Merging'', ''Merging to the mainline'','||wwv_flow.LF||
'                               ''Verification'', ''Project has pas';
wwv_flow_imp.g_varchar2_table(17) := 'sed all testing and reviews and is ready for distribution'','||wwv_flow.LF||
'                               ''Complete';
wwv_flow_imp.g_varchar2_table(18) := ''', ''Project is complete and made generally available'');'||wwv_flow.LF||
'insert into sp_project_scales (scale_letter,';
wwv_flow_imp.g_varchar2_table(19) := ' scale_name, is_active_yn, min_pc_for_status,'||wwv_flow.LF||
'                               pc0_label, pc0_desc, pc';
wwv_flow_imp.g_varchar2_table(20) := '10_label, pc10_desc,'||wwv_flow.LF||
'                               pc20_label, pc20_desc, pc30_label, pc30_desc,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(21) := '                             pc40_label, pc40_desc, pc50_label, pc50_desc,'||wwv_flow.LF||
'                         ';
wwv_flow_imp.g_varchar2_table(22) := '      pc60_label, pc60_desc, pc70_label, pc70_desc,'||wwv_flow.LF||
'                               pc80_label, pc80_';
wwv_flow_imp.g_varchar2_table(23) := 'desc, pc90_label, pc90_desc,'||wwv_flow.LF||
'                               pc100_label, pc100_desc) '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(24) := '         values (''B'', ''Generic'',''Y'', 30,'||wwv_flow.LF||
'                               ''Canceled'', ''Canceled and or';
wwv_flow_imp.g_varchar2_table(25) := ' abandoned'','||wwv_flow.LF||
'                               ''Identified'', ''A new project has been identified'','||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(26) := '                          ''Desirable'', ''Determined to be worthy of consideration and is perceived as';
wwv_flow_imp.g_varchar2_table(27) := ' desirable'','||wwv_flow.LF||
'                               ''Planning has started'', ''Planning has started. Most of t';
wwv_flow_imp.g_varchar2_table(28) := 'he variables required for planning are known'','||wwv_flow.LF||
'                               ''Planning mostly compl';
wwv_flow_imp.g_varchar2_table(29) := 'ete'', ''Planning is mostly complete'','||wwv_flow.LF||
'                               ''Progressing - half done'', ''Prog';
wwv_flow_imp.g_varchar2_table(30) := 'ressing and about half complete'','||wwv_flow.LF||
'                               ''Progressing'', ''Progressing'','||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(31) := '                          ''Progressing'', ''Progressing'','||wwv_flow.LF||
'                               ''Progressing''';
wwv_flow_imp.g_varchar2_table(32) := ', ''Progressing well and getting close to complete'','||wwv_flow.LF||
'                               ''Substantially Co';
wwv_flow_imp.g_varchar2_table(33) := 'mplete'', ''Project is virtually complete with only small inconsequential issues outstanding.'','||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(34) := '                         ''Complete'', ''Project is complete'');'||wwv_flow.LF||
'insert into sp_project_scales (scale_le';
wwv_flow_imp.g_varchar2_table(35) := 'tter, scale_name, is_active_yn, min_pc_for_status,'||wwv_flow.LF||
'                               pc0_label, pc0_des';
wwv_flow_imp.g_varchar2_table(36) := 'c, pc10_label, pc10_desc,'||wwv_flow.LF||
'                               pc20_label, pc20_desc, pc30_label, pc30_des';
wwv_flow_imp.g_varchar2_table(37) := 'c,'||wwv_flow.LF||
'                               pc40_label, pc40_desc, pc50_label, pc50_desc,'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(38) := '           pc60_label, pc60_desc, pc70_label, pc70_desc,'||wwv_flow.LF||
'                               pc80_label, ';
wwv_flow_imp.g_varchar2_table(39) := 'pc80_desc, pc90_label, pc90_desc,'||wwv_flow.LF||
'                               pc100_label, pc100_desc) '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(40) := '              values (''C'', ''Sales Engagement'',''Y'', 20,'||wwv_flow.LF||
'                               ''Lost Opportun';
wwv_flow_imp.g_varchar2_table(41) := 'ity'', ''This opportunity has been lost'','||wwv_flow.LF||
'                               ''Lead Identified'', ''A lead wi';
wwv_flow_imp.g_varchar2_table(42) := 'th a customer has been identified'','||wwv_flow.LF||
'                               ''Connected with Lead'', ''A connect';
wwv_flow_imp.g_varchar2_table(43) := 'ion has been made with customer'','||wwv_flow.LF||
'                               ''Qualifying Opportunity'', ''The oppo';
wwv_flow_imp.g_varchar2_table(44) := 'rtunity is being qualified to see if it is a good fit'','||wwv_flow.LF||
'                               ''Presented to';
wwv_flow_imp.g_varchar2_table(45) := ' Customer'', ''A presentation has been performed for the customer'','||wwv_flow.LF||
'                               ''Re';
wwv_flow_imp.g_varchar2_table(46) := 'quirements Understood'', ''Customer requirements are well understood'','||wwv_flow.LF||
'                               ';
wwv_flow_imp.g_varchar2_table(47) := '''Solution Proposed'', ''A solution has been proposed'','||wwv_flow.LF||
'                               ''Objections Addr';
wwv_flow_imp.g_varchar2_table(48) := 'essed'', ''Any objections to the proposed implementation have been addressed'','||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(49) := '        ''Proposal Drafted'', ''A solution proposal has been drafted for internal review'','||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(50) := '                   ''Proposal Delivered'', ''The proposal has been delivered to the customer'','||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(51) := '                       ''Win'', ''Opportunity has been won and the customer has formally accepted the p';
wwv_flow_imp.g_varchar2_table(52) := 'roposal'');'||wwv_flow.LF||
'insert into sp_project_scales (scale_letter, scale_name, is_active_yn, min_pc_for_status,';
wwv_flow_imp.g_varchar2_table(53) := ''||wwv_flow.LF||
'                               pc0_label, pc0_desc, pc10_label, pc10_desc,'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(54) := '       pc20_label, pc20_desc, pc30_label, pc30_desc,'||wwv_flow.LF||
'                               pc40_label, pc40';
wwv_flow_imp.g_varchar2_table(55) := '_desc, pc50_label, pc50_desc,'||wwv_flow.LF||
'                               pc60_label, pc60_desc, pc70_label, pc70';
wwv_flow_imp.g_varchar2_table(56) := '_desc,'||wwv_flow.LF||
'                               pc80_label, pc80_desc, pc90_label, pc90_desc,'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(57) := '               pc100_label, pc100_desc) '||wwv_flow.LF||
'                       values (''D'', ''Project Mgt'',''Y'', 30,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(58) := '                               ''Not Feasible'', ''Project is not possible or not desirable or is a dup';
wwv_flow_imp.g_varchar2_table(59) := 'licate'','||wwv_flow.LF||
'                               ''Identified'', ''A new project has been identified and formall';
wwv_flow_imp.g_varchar2_table(60) := 'y proposed'','||wwv_flow.LF||
'                               ''Desirable'', ''Project is determined to be worthy of cons';
wwv_flow_imp.g_varchar2_table(61) := 'ideration and is perceived as desirable'','||wwv_flow.LF||
'                               ''Architecting'', ''The implem';
wwv_flow_imp.g_varchar2_table(62) := 'entation specification is under development'','||wwv_flow.LF||
'                               ''Specification Approved';
wwv_flow_imp.g_varchar2_table(63) := ''', ''The specification is sufficiently complete to begin development and has been formally reviewed'',';
wwv_flow_imp.g_varchar2_table(64) := ''||wwv_flow.LF||
'                               ''Active Development'', ''Project is assigned and currently in active d';
wwv_flow_imp.g_varchar2_table(65) := 'evelopment'','||wwv_flow.LF||
'                               ''Demonstrable'', ''Project is partially functioning'','||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(66) := '                           ''In Review'', ''Project is merged into the mainline'','||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(67) := '          ''Merging'', ''Merging to the mainline'','||wwv_flow.LF||
'                               ''Verification'', ''Proj';
wwv_flow_imp.g_varchar2_table(68) := 'ect has passed all testing and reviews and is ready for distribution'','||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(69) := '  ''Complete'', ''Project is complete and made generally available'');'||wwv_flow.LF||
'insert into sp_project_scales (sc';
wwv_flow_imp.g_varchar2_table(70) := 'ale_letter, scale_name, is_active_yn, min_pc_for_status,'||wwv_flow.LF||
'                               pc0_label, p';
wwv_flow_imp.g_varchar2_table(71) := 'c0_desc, pc10_label, pc10_desc,'||wwv_flow.LF||
'                               pc20_label, pc20_desc, pc30_label, pc';
wwv_flow_imp.g_varchar2_table(72) := '30_desc,'||wwv_flow.LF||
'                               pc40_label, pc40_desc, pc50_label, pc50_desc,'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(73) := '                 pc60_label, pc60_desc, pc70_label, pc70_desc,'||wwv_flow.LF||
'                               pc80_l';
wwv_flow_imp.g_varchar2_table(74) := 'abel, pc80_desc, pc90_label, pc90_desc,'||wwv_flow.LF||
'                               pc100_label, pc100_desc) '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(75) := '                    values (''E'', ''Sample App'',''Y'', 30,'||wwv_flow.LF||
'                               ''Not Feasible''';
wwv_flow_imp.g_varchar2_table(76) := ', ''Project is not possible or not desirable or is a duplicate'','||wwv_flow.LF||
'                               ''Iden';
wwv_flow_imp.g_varchar2_table(77) := 'tified'', ''A new project has been identified and formally proposed'','||wwv_flow.LF||
'                               ''';
wwv_flow_imp.g_varchar2_table(78) := 'Desirable'', ''Project is determined to be worthy of consideration and is perceived as desirable'','||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(79) := '                            ''Architecting'', ''The implementation specification is under development'',';
wwv_flow_imp.g_varchar2_table(80) := ''||wwv_flow.LF||
'                               ''Specification Approved'', ''The specification is sufficiently complet';
wwv_flow_imp.g_varchar2_table(81) := 'e to begin development and has been formally reviewed'','||wwv_flow.LF||
'                               ''Active Devel';
wwv_flow_imp.g_varchar2_table(82) := 'opment'', ''Project is assigned and currently in active development'','||wwv_flow.LF||
'                               ''';
wwv_flow_imp.g_varchar2_table(83) := 'Demonstrable'', ''Project is partially functioning'','||wwv_flow.LF||
'                               ''In Review'', ''Proj';
wwv_flow_imp.g_varchar2_table(84) := 'ect is being reviewed'','||wwv_flow.LF||
'                               ''Documented'', ''Sample App or Code has been do';
wwv_flow_imp.g_varchar2_table(85) := 'cumented'','||wwv_flow.LF||
'                               ''Verification'', ''Project has passed all testing and review';
wwv_flow_imp.g_varchar2_table(86) := 's and is ready for distribution'','||wwv_flow.LF||
'                               ''Hosted'', ''Sample App or Code is ho';
wwv_flow_imp.g_varchar2_table(87) := 'sted and available for download'');'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(148798956212673006836)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed project scales'
,p_sequence=>810
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
