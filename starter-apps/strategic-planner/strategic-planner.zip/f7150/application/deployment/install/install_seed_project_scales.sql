prompt --application/deployment/install/install_seed_project_scales
begin
--   Manifest
--     INSTALL: INSTALL-seed project scales
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>6745509624802563
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(122128134258233968869)
,p_install_id=>wwv_flow_imp.id(149550211700186226639)
,p_name=>'seed project scales'
,p_sequence=>810
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into sp_project_scales (scale_letter, scale_name, is_active_yn,',
'                               pc0_label, pc0_desc, pc10_label, pc10_desc,',
'                               pc20_label, pc20_desc, pc30_label, pc30_desc,',
'                               pc40_label, pc40_desc, pc50_label, pc50_desc,',
'                               pc60_label, pc60_desc, pc70_label, pc70_desc,',
'                               pc80_label, pc80_desc, pc90_label, pc90_desc,',
'                               pc100_label, pc100_desc) ',
'                       values (''A'', ''Product Dev'',''Y'',',
'                               ''Not Feasible'', ''Project is not possible or not desirable or is a duplicate'',',
'                               ''Identified'', ''A new project has been identified and formally proposed'',',
'                               ''Desirable'', ''Project is determined to be worthy of consideration and is perceived as desirable'',',
'                               ''Architecting'', ''The implementation specification is under development'',',
'                               ''Specification Approved'', ''The specification is sufficiently complete to begin development and has been formally reviewed'',',
'                               ''Active Development'', ''Project is assigned and currently in active development'',',
'                               ''Demonstrable'', ''Project is partially functioning'',',
'                               ''In Review'', ''Project is merged into the mainline'',',
'                               ''Merging'', ''Merging to the mainline'',',
'                               ''Verification'', ''Project has passed all testing and reviews and is ready for distribution'',',
'                               ''Complete'', ''Project is complete and made generally available'');',
'insert into sp_project_scales (scale_letter, scale_name, is_active_yn,',
'                               pc0_label, pc0_desc, pc10_label, pc10_desc,',
'                               pc20_label, pc20_desc, pc30_label, pc30_desc,',
'                               pc40_label, pc40_desc, pc50_label, pc50_desc,',
'                               pc60_label, pc60_desc, pc70_label, pc70_desc,',
'                               pc80_label, pc80_desc, pc90_label, pc90_desc,',
'                               pc100_label, pc100_desc) ',
'                       values (''B'', ''Generic'',''Y'',',
'                               ''Canceled'', ''Canceled and or abandoned'',',
'                               ''Identified'', ''A new project has been identified'',',
'                               ''Desirable'', ''Determined to be worthy of consideration and is perceived as desirable'',',
'                               ''Planning has started'', ''Planning has started. Most of the variables required for planning are known'',',
'                               ''Planning mostly complete'', ''Planning is mostly complete'',',
'                               ''Progressing - half done'', ''Progressing and about half complete'',',
'                               ''Progressing'', ''Progressing'',',
'                               ''Progressing'', ''Progressing'',',
'                               ''Progressing'', ''Progressing well and getting close to complete'',',
'                               ''Substantially Complete'', ''Project is virtually complete with only small inconsequential issues outstanding.'',',
'                               ''Complete'', ''Project is complete'');',
'insert into sp_project_scales (scale_letter, scale_name, is_active_yn,',
'                               pc0_label, pc0_desc, pc10_label, pc10_desc,',
'                               pc20_label, pc20_desc, pc30_label, pc30_desc,',
'                               pc40_label, pc40_desc, pc50_label, pc50_desc,',
'                               pc60_label, pc60_desc, pc70_label, pc70_desc,',
'                               pc80_label, pc80_desc, pc90_label, pc90_desc,',
'                               pc100_label, pc100_desc) ',
'                       values (''C'', ''Sales Engagement'',''Y'',',
'                               ''Lost Opportunity'', ''This opportunity has been lost'',',
'                               ''Lead Identified'', ''A lead with a customer has been identified'',',
'                               ''Connected with Lead'', ''A connection has been made with customer'',',
'                               ''Qualifying Opportunity'', ''The opportunity is being qualified to see if it is a good fit'',',
'                               ''Presented to Customer'', ''A presentation has been performed for the customer'',',
'                               ''Requirements Understood'', ''Customer requirements are well understood'',',
'                               ''Solution Proposed'', ''A solution has been proposed'',',
'                               ''Objections Addressed'', ''Any objections to the proposed implementation have been addressed'',',
'                               ''Proposal Drafted'', ''A solution proposal has been drafted for internal review'',',
'                               ''Proposal Delivered'', ''The proposal has been delivered to the customer'',',
'                               ''Win'', ''Opportunity has been won and the customer has formally accepted the proposal'');',
'insert into sp_project_scales (scale_letter, scale_name, is_active_yn,',
'                               pc0_label, pc0_desc, pc10_label, pc10_desc,',
'                               pc20_label, pc20_desc, pc30_label, pc30_desc,',
'                               pc40_label, pc40_desc, pc50_label, pc50_desc,',
'                               pc60_label, pc60_desc, pc70_label, pc70_desc,',
'                               pc80_label, pc80_desc, pc90_label, pc90_desc,',
'                               pc100_label, pc100_desc) ',
'                       values (''D'', ''Project Mgt'',''Y'',',
'                               ''Not Feasible'', ''Project is not possible or not desirable or is a duplicate'',',
'                               ''Identified'', ''A new project has been identified and formally proposed'',',
'                               ''Desirable'', ''Project is determined to be worthy of consideration and is perceived as desirable'',',
'                               ''Architecting'', ''The implementation specification is under development'',',
'                               ''Specification Approved'', ''The specification is sufficiently complete to begin development and has been formally reviewed'',',
'                               ''Active Development'', ''Project is assigned and currently in active development'',',
'                               ''Demonstrable'', ''Project is partially functioning'',',
'                               ''In Review'', ''Project is merged into the mainline'',',
'                               ''Merging'', ''Merging to the mainline'',',
'                               ''Verification'', ''Project has passed all testing and reviews and is ready for distribution'',',
'                               ''Complete'', ''Project is complete and made generally available'');',
'insert into sp_project_scales (scale_letter, scale_name, is_active_yn,',
'                               pc0_label, pc0_desc, pc10_label, pc10_desc,',
'                               pc20_label, pc20_desc, pc30_label, pc30_desc,',
'                               pc40_label, pc40_desc, pc50_label, pc50_desc,',
'                               pc60_label, pc60_desc, pc70_label, pc70_desc,',
'                               pc80_label, pc80_desc, pc90_label, pc90_desc,',
'                               pc100_label, pc100_desc) ',
'                       values (''E'', ''Sample App'',''Y'',',
'                               ''Not Feasible'', ''Project is not possible or not desirable or is a duplicate'',',
'                               ''Identified'', ''A new project has been identified and formally proposed'',',
'                               ''Desirable'', ''Project is determined to be worthy of consideration and is perceived as desirable'',',
'                               ''Architecting'', ''The implementation specification is under development'',',
'                               ''Specification Approved'', ''The specification is sufficiently complete to begin development and has been formally reviewed'',',
'                               ''Active Development'', ''Project is assigned and currently in active development'',',
'                               ''Demonstrable'', ''Project is partially functioning'',',
'                               ''In Review'', ''Project is being reviewed'',',
'                               ''Documented'', ''Sample App or Code has been documented'',',
'                               ''Verification'', ''Project has passed all testing and reviews and is ready for distribution'',',
'                               ''Hosted'', ''Sample App or Code is hosted and available for download'');',
''))
);
wwv_flow_imp.component_end;
end;
/
