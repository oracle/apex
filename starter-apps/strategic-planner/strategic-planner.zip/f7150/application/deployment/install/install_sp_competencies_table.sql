prompt --application/deployment/install/install_sp_competencies_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_competencies table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_competencies ('||wwv_flow.LF||
'    id                             number default on null to_number(s';
wwv_flow_imp.g_varchar2_table(2) := 'ys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_com';
wwv_flow_imp.g_varchar2_table(3) := 'petencies_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    competency                     varchar2(100  char) not null,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(4) := '  description                    varchar2(4000 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date';
wwv_flow_imp.g_varchar2_table(5) := ' not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated              ';
wwv_flow_imp.g_varchar2_table(6) := '          date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create ';
wwv_flow_imp.g_varchar2_table(7) := 'unique index sp_competencies_i1 on sp_competencies (competency);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(47933470283292286145)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_competencies table'
,p_sequence=>110
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
