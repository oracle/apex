prompt --application/deployment/install/install_activity_types_triggers
begin
--   Manifest
--     INSTALL: INSTALL-activity_types triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_activity_types_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_activity_types';
wwv_flow_imp.g_varchar2_table(2) := ''||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new.created_';
wwv_flow_imp.g_varchar2_table(3) := 'by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate';
wwv_flow_imp.g_varchar2_table(4) := ';'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.i';
wwv_flow_imp.g_varchar2_table(5) := 's_active_yn is null then'||wwv_flow.LF||
'       :new.is_active_yn := ''Y'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(6) := '   if inserting then'||wwv_flow.LF||
'        insert into sp_app_log'||wwv_flow.LF||
'            (activity, details)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(7) := '           (''Added Activity Type'' , :new.activity_type);'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        if not sp_v';
wwv_flow_imp.g_varchar2_table(8) := 'alue_compare.is_equal(:old.activity_type,:new.activity_type) then'||wwv_flow.LF||
'            insert into sp_app_log';
wwv_flow_imp.g_varchar2_table(9) := ''||wwv_flow.LF||
'                (activity, details)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (''Updated Activity Type'' , ''';
wwv_flow_imp.g_varchar2_table(10) := 'Changed "''||:old.activity_type ||''" to "''||:new.activity_type||''"'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not ';
wwv_flow_imp.g_varchar2_table(11) := 'sp_value_compare.is_equal(:old.STATIC_ID,:new.STATIC_ID) then'||wwv_flow.LF||
'            insert into sp_app_log'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(12) := '             (activity, details)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (''Updated Activity Type'' , :new.';
wwv_flow_imp.g_varchar2_table(13) := 'activity_type||'': changed STATIC_ID from "''||:old.STATIC_ID||''" to "''||:new.STATIC_ID||''"'');'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(14) := ' end if; '||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.IS_PROJECT_YN,:new.IS_PROJECT_YN) then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(15) := '       insert into sp_app_log'||wwv_flow.LF||
'                (activity, details)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(16) := ' (''Updated Activity Type'' , :new.activity_type||'': changed IS_PROJECT from "''||:old.IS_PROJECT_YN||''';
wwv_flow_imp.g_varchar2_table(17) := '" to "''||:new.IS_PROJECT_YN||''"'');'||wwv_flow.LF||
'        end if;        '||wwv_flow.LF||
'        if not sp_value_compare.is_equal(';
wwv_flow_imp.g_varchar2_table(18) := ':old.IS_DEFAULT_YN,:new.IS_DEFAULT_YN) then'||wwv_flow.LF||
'            insert into sp_app_log'||wwv_flow.LF||
'                (acti';
wwv_flow_imp.g_varchar2_table(19) := 'vity, details)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (''Updated Activity Type'' , :new.activity_type||'': ';
wwv_flow_imp.g_varchar2_table(20) := 'changed IS_DEFAULT from "''||:old.IS_DEFAULT_YN||''" to "''||:new.IS_DEFAULT_YN||''"'');'||wwv_flow.LF||
'        end if; ';
wwv_flow_imp.g_varchar2_table(21) := '  '||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.IS_ACTIVE_YN,:new.IS_ACTIVE_YN) then'||wwv_flow.LF||
'            in';
wwv_flow_imp.g_varchar2_table(22) := 'sert into sp_app_log'||wwv_flow.LF||
'                (activity, details)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (''Update';
wwv_flow_imp.g_varchar2_table(23) := 'd Activity Type'' , :new.activity_type||'': changed IS_ACTIVE from "''||:old.IS_ACTIVE_YN||''" to "''||:n';
wwv_flow_imp.g_varchar2_table(24) := 'ew.IS_ACTIVE_YN||''"'');'||wwv_flow.LF||
'        end if;       '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_activity_types_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or re';
wwv_flow_imp.g_varchar2_table(25) := 'place trigger sp_activity_types_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_activity_types'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin';
wwv_flow_imp.g_varchar2_table(26) := ''||wwv_flow.LF||
'    insert into sp_app_log'||wwv_flow.LF||
'        (activity, details)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (''Deleted Activity Type'',';
wwv_flow_imp.g_varchar2_table(27) := ' :old.activity_type);'||wwv_flow.LF||
'end sp_activity_types_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(50990981462053841129)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'activity_types triggers'
,p_sequence=>560
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
