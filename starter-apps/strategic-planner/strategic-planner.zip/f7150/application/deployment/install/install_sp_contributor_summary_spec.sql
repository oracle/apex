prompt --application/deployment/install/install_sp_contributor_summary_spec
begin
--   Manifest
--     INSTALL: INSTALL-sp_contributor_summary spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package sp_contributor_summary'||wwv_flow.LF||
'as'||wwv_flow.LF||
''||wwv_flow.LF||
'function generate ('||wwv_flow.LF||
'    p_team_member_id     in';
wwv_flow_imp.g_varchar2_table(2) := ' number,'||wwv_flow.LF||
'    p_show_activities    in varchar2 default ''Y'','||wwv_flow.LF||
'    p_show_projects      in varchar2 defa';
wwv_flow_imp.g_varchar2_table(3) := 'ult ''Y'','||wwv_flow.LF||
'    p_show_approvals     in varchar2 default ''N'',  -- based on build option in app'||wwv_flow.LF||
'    p_li';
wwv_flow_imp.g_varchar2_table(4) := 'nks              in varchar2 default ''NONE'','||wwv_flow.LF||
'    p_include_title_yn   in varchar2 default ''Y'','||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(5) := '_apex_session       in varchar2 default null )'||wwv_flow.LF||
'    return clob;'||wwv_flow.LF||
''||wwv_flow.LF||
'function project_exceptions ('||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(6) := '_team_member_id     in number,'||wwv_flow.LF||
'    p_links              in varchar2 default ''NONE'','||wwv_flow.LF||
'    p_include_ti';
wwv_flow_imp.g_varchar2_table(7) := 'tle_yn   in varchar2 default ''Y'','||wwv_flow.LF||
'    p_apex_session       in varchar2 default null )'||wwv_flow.LF||
'    return clo';
wwv_flow_imp.g_varchar2_table(8) := 'b;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure project_changes ('||wwv_flow.LF||
'    p_team_member_id     in number,'||wwv_flow.LF||
'    p_frequency          in varc';
wwv_flow_imp.g_varchar2_table(9) := 'har2, -- WEEKLY, WEEKDAYS'||wwv_flow.LF||
'    p_links              in varchar2 default ''NONE'','||wwv_flow.LF||
'    p_apex_session   ';
wwv_flow_imp.g_varchar2_table(10) := '    in varchar2 default null,'||wwv_flow.LF||
'    p_exclude_user_yn    in varchar2 default ''N'','||wwv_flow.LF||
'    p_changes_yn    ';
wwv_flow_imp.g_varchar2_table(11) := '     out  varchar2,  -- if N changes, no email'||wwv_flow.LF||
'    p_change_summary     out  clob );'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_contrib';
wwv_flow_imp.g_varchar2_table(12) := 'utor_summary;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(40921987895253299497)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_contributor_summary spec'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
