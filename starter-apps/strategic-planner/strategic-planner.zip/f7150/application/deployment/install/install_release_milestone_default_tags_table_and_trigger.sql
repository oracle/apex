prompt --application/deployment/install/install_release_milestone_default_tags_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-release_milestone_default_tags table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_release_milestone_default_tags ('||wwv_flow.LF||
'    id                             number default o';
wwv_flow_imp.g_varchar2_table(2) := 'n null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                  ';
wwv_flow_imp.g_varchar2_table(3) := ' constraint sp_release_milestone_default_tags_pk primary key,'||wwv_flow.LF||
'    display_sequence               num';
wwv_flow_imp.g_varchar2_table(4) := 'ber            not null,'||wwv_flow.LF||
'    tag                            varchar2(30 char) not null,'||wwv_flow.LF||
'    descript';
wwv_flow_imp.g_varchar2_table(5) := 'ion                    varchar2(512 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(6) := '    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                        d';
wwv_flow_imp.g_varchar2_table(7) := 'ate not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table sp_rele';
wwv_flow_imp.g_varchar2_table(8) := 'ase_milestone_default_tags '||wwv_flow.LF||
'    add constraint sp_release_milestone_default_tags_uk unique(tag);'||wwv_flow.LF||
''||wwv_flow.LF||
'cr';
wwv_flow_imp.g_varchar2_table(9) := 'eate or replace trigger sp_release_milestone_default_tags_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_';
wwv_flow_imp.g_varchar2_table(10) := 'release_milestone_default_tags'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := ';
wwv_flow_imp.g_varchar2_table(11) := 'sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end i';
wwv_flow_imp.g_varchar2_table(12) := 'f;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER';
wwv_flow_imp.g_varchar2_table(13) := '''),user);'||wwv_flow.LF||
'    :new.tag := upper(:new.tag);'||wwv_flow.LF||
'end sp_release_milestone_default_tags_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(31284215977697515396)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'release_milestone_default_tags table and trigger'
,p_sequence=>305
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
