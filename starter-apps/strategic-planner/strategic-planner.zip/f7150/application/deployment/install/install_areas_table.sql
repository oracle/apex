prompt --application/deployment/install/install_areas_table
begin
--   Manifest
--     INSTALL: INSTALL-areas table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>12000886144631317
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(12000879983329515264)
,p_install_id=>wwv_flow_imp.id(149555467076706055393)
,p_name=>'areas table'
,p_sequence=>170
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table sp_areas (',
'    id                             number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') ',
'                                   constraint sp_areas_id_pk primary key,',
'    area                           varchar2(50 char) not null,',
'    description                    varchar2(4000 char),',
'    owner_id                       number',
'                                   constraint sp_areas_owner_fk',
'                                   references sp_team_members on delete cascade,',
'    --',
'    status_scale varchar2(1)       check (status_scale in (''A'',''B'',''C'',''D'',''E'',''F'',''G'')),',
'    hidden_by_default_yn           varchar2(1 char),',
'    tags                           varchar2(4000 char),',
'    --',
'    image                          blob,',
'    image_name                     varchar2(512 char),',
'    image_mimetype                 varchar2(512 char),',
'    image_last_updated             date,',
'    --',
'    created                        date not null,',
'    created_by                     varchar2(255 char) not null,',
'    updated                        date not null,',
'    updated_by                     varchar2(255 char) not null',
')',
';',
'',
'create index sp_areas_i1 on sp_areas (owner_id);',
'create unique index sp_areas_u1 on sp_areas (area);'))
);
wwv_flow_imp.component_end;
end;
/
