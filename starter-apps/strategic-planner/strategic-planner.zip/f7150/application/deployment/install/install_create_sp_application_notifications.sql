prompt --application/deployment/install/install_create_sp_application_notifications
begin
--   Manifest
--     INSTALL: INSTALL-create SP_APPLICATION_NOTIFICATIONS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table SP_APPLICATION_NOTIFICATIONS ('||wwv_flow.LF||
'    id                             number default on nul';
wwv_flow_imp.g_varchar2_table(2) := 'l to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   cons';
wwv_flow_imp.g_varchar2_table(3) := 'traint SP_APPLICATION_NOTIFICATIONS_PK primary key,'||wwv_flow.LF||
'    notification_name              varchar2(128 ';
wwv_flow_imp.g_varchar2_table(4) := 'char)   not null,'||wwv_flow.LF||
'    notification_description       varchar2(4000 char),'||wwv_flow.LF||
'    is_active_yn          ';
wwv_flow_imp.g_varchar2_table(5) := '         varchar2(1 char)    not null,'||wwv_flow.LF||
'    required_user_tag              varchar2(30 char),'||wwv_flow.LF||
'    fro';
wwv_flow_imp.g_varchar2_table(6) := 'm_date                      date,'||wwv_flow.LF||
'    to_date                        date,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created       ';
wwv_flow_imp.g_varchar2_table(7) := '                 date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(8) := 'updated                        date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) ';
wwv_flow_imp.g_varchar2_table(9) := 'not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index SP_APPLICATION_NOTIFICATIONS_U1 on SP_APPLICATION_NOTIFICATIONS(no';
wwv_flow_imp.g_varchar2_table(10) := 'tification_name);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger SP_APPLICATION_NOTIFICATIONS_biu'||wwv_flow.LF||
'    before insert or ';
wwv_flow_imp.g_varchar2_table(11) := 'update'||wwv_flow.LF||
'    on SP_APPLICATION_NOTIFICATIONS'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new';
wwv_flow_imp.g_varchar2_table(12) := '.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user';
wwv_flow_imp.g_varchar2_table(13) := ');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSIO';
wwv_flow_imp.g_varchar2_table(14) := 'N'',''APP_USER''),user);'||wwv_flow.LF||
'end SP_APPLICATION_NOTIFICATIONS_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(41353261951098898629)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'create SP_APPLICATION_NOTIFICATIONS'
,p_sequence=>660
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
