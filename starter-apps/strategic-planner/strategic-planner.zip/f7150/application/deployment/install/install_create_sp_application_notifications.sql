prompt --application/deployment/install/install_create_sp_application_notifications
begin
--   Manifest
--     INSTALL: INSTALL-create SP_APPLICATION_NOTIFICATIONS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6312792715746494105)
,p_install_id=>wwv_flow_imp.id(141180564419272860082)
,p_name=>'create SP_APPLICATION_NOTIFICATIONS'
,p_sequence=>800
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table SP_APPLICATION_NOTIFICATIONS (',
'    id                             number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') ',
'                                   constraint SP_APPLICATION_NOTIFICATIONS_PK primary key,',
'    notification_name              varchar2(128 char)   not null,',
'    notification_description       varchar2(4000 char),',
'    is_active_yn                   varchar2(1 char)    not null,',
'    required_user_tag              varchar2(30 char),',
'    from_date                      date,',
'    to_date                        date,',
'    --',
'    created                        date not null,',
'    created_by                     varchar2(255 char) not null,',
'    updated                        date not null,',
'    updated_by                     varchar2(255 char) not null',
')',
';',
'',
'create unique index SP_APPLICATION_NOTIFICATIONS_U1 on SP_APPLICATION_NOTIFICATIONS(notification_name);',
'',
'',
'create or replace trigger SP_APPLICATION_NOTIFICATIONS_biu',
'    before insert or update',
'    on SP_APPLICATION_NOTIFICATIONS',
'    for each row',
'begin',
'    if inserting then',
'        :new.created := sysdate;',
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'    end if;',
'    :new.updated := sysdate;',
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'end SP_APPLICATION_NOTIFICATIONS_biu;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
