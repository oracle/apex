prompt --application/deployment/install/install_seed_activity_types
begin
--   Manifest
--     INSTALL: INSTALL-seed activity_types
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into SP_ACTIVITY_TYPES (ID, DISPLAY_SEQUENCE, ACTIVITY_TYPE, ACTIVITY_TYPE_DESCRIPTION, is_de';
wwv_flow_imp.g_varchar2_table(2) := 'fault_yn, static_id ) values ( 1, 1, ''Development'', '''', ''Y'', ''DEV'');'||wwv_flow.LF||
'insert into SP_ACTIVITY_TYPES (';
wwv_flow_imp.g_varchar2_table(3) := 'ID, DISPLAY_SEQUENCE, ACTIVITY_TYPE, ACTIVITY_TYPE_DESCRIPTION, is_default_yn, static_id ) values ( ';
wwv_flow_imp.g_varchar2_table(4) := '2, 2, ''Prod Mgt'', ''Product Management'', ''N'', ''PM'');'||wwv_flow.LF||
'insert into SP_ACTIVITY_TYPES (ID, DISPLAY_SEQUE';
wwv_flow_imp.g_varchar2_table(5) := 'NCE, ACTIVITY_TYPE, ACTIVITY_TYPE_DESCRIPTION, is_default_yn, static_id ) values ( 3, 3, ''Review'', ''';
wwv_flow_imp.g_varchar2_table(6) := ''', ''N'', ''REVIEW'');'||wwv_flow.LF||
'insert into SP_ACTIVITY_TYPES (ID, DISPLAY_SEQUENCE, ACTIVITY_TYPE, ACTIVITY_TYPE';
wwv_flow_imp.g_varchar2_table(7) := '_DESCRIPTION, is_default_yn, static_id ) values ( 4, 4, ''Conference'', ''Conference preparation, trave';
wwv_flow_imp.g_varchar2_table(8) := 'l, attendance or other related work'', ''N'', ''CONF'');'||wwv_flow.LF||
'insert into SP_ACTIVITY_TYPES (ID, DISPLAY_SEQUE';
wwv_flow_imp.g_varchar2_table(9) := 'NCE, ACTIVITY_TYPE, ACTIVITY_TYPE_DESCRIPTION, is_default_yn, static_id ) values ( 5, 5, ''Customer E';
wwv_flow_imp.g_varchar2_table(10) := 'ngagement'', '''', ''N'', ''CUSTOMER'');'||wwv_flow.LF||
'insert into SP_ACTIVITY_TYPES (ID, DISPLAY_SEQUENCE, ACTIVITY_TYPE';
wwv_flow_imp.g_varchar2_table(11) := ', ACTIVITY_TYPE_DESCRIPTION, is_default_yn, static_id ) values ( 6, 6, ''Out of Office'', '''', ''N'', ''OO';
wwv_flow_imp.g_varchar2_table(12) := 'O'');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(50990987510949843030)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed activity_types'
,p_sequence=>850
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
