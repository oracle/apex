prompt --application/deployment/install/install_create_sp_team_members_trigger
begin
--   Manifest
--     INSTALL: INSTALL-create sp_team_members trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_team_members_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_team_members'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(2) := ' for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    b integer := 0; -- first dot occurrance'||wwv_flow.LF||
'    e integer := 0; -- first at si';
wwv_flow_imp.g_varchar2_table(3) := 'gn occurrance'||wwv_flow.LF||
'    l integer := 0; -- length between dot and at sign'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(4) := '    :new.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USE';
wwv_flow_imp.g_varchar2_table(5) := 'R''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APE';
wwv_flow_imp.g_varchar2_table(6) := 'X$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    :new.email := lower(:new.email);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.screen_name := lo';
wwv_flow_imp.g_varchar2_table(7) := 'wer(:new.screen_name);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.is_current_yn is null then'||wwv_flow.LF||
'       :new.is_current_yn := ''Y';
wwv_flow_imp.g_varchar2_table(8) := ''';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    b := instr(:new.email,''.'');'||wwv_flow.LF||
'    e := instr(:new.email,''@'');'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.email';
wwv_flow_imp.g_varchar2_table(9) := '_domain := substr(:new.email,e+1);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if e > 2 and b > 1 and :new.first_name is null and :ne';
wwv_flow_imp.g_varchar2_table(10) := 'w.last_name is null then'||wwv_flow.LF||
'       l := (e - b) - 1;'||wwv_flow.LF||
'       if b < e and l > 0 then'||wwv_flow.LF||
'           :new.fir';
wwv_flow_imp.g_varchar2_table(11) := 'st_name := initcap(substr(:new.email,1,b-1));'||wwv_flow.LF||
'           :new.last_name  := initcap(substr(:new.emai';
wwv_flow_imp.g_varchar2_table(12) := 'l,b+1,l));'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.initials is null and :new.first_name is not null a';
wwv_flow_imp.g_varchar2_table(13) := 'nd :new.last_name is not null then'||wwv_flow.LF||
'        :new.initials := nvl(substr(:new.first_name,1,1)||substr(';
wwv_flow_imp.g_varchar2_table(14) := ':new.last_name,1,1),''X'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.initials is null then'||wwv_flow.LF||
'       :new.initials := ''AA''';
wwv_flow_imp.g_varchar2_table(15) := ';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.first_name is null then '||wwv_flow.LF||
'       :new.first_name := ''unknown'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(16) := '    if :new.last_name is null then'||wwv_flow.LF||
'       :new.last_name := ''unknown'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- tag';
wwv_flow_imp.g_varchar2_table(17) := 's'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.tags := upper(:new.tags);'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_team_members_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(41435377846911228647)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'create sp_team_members trigger'
,p_sequence=>400
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
