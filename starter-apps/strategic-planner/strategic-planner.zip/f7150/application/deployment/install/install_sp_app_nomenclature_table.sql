prompt --application/deployment/install/install_sp_app_nomenclature_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_app_nomenclature table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table SP_APP_NOMENCLATURE ('||wwv_flow.LF||
'    id                             number default on null to_numb';
wwv_flow_imp.g_varchar2_table(2) := 'er(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint SP';
wwv_flow_imp.g_varchar2_table(3) := '_APP_NOMENCLATURE_pk primary key,'||wwv_flow.LF||
'    static_id                      varchar2(50 char),'||wwv_flow.LF||
'    default_';
wwv_flow_imp.g_varchar2_table(4) := 'order                  number,'||wwv_flow.LF||
'    custom_value                   varchar2(50 char),'||wwv_flow.LF||
'    default_val';
wwv_flow_imp.g_varchar2_table(5) := 'ue                  varchar2(50 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    description                    varchar2(4000 char)';
wwv_flow_imp.g_varchar2_table(6) := ','||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by                     varcha';
wwv_flow_imp.g_varchar2_table(7) := 'r2(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by             ';
wwv_flow_imp.g_varchar2_table(8) := '        varchar2(255 char) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index SP_APP_NOMENCLATURE_u1 on SP_APP_NOMENC';
wwv_flow_imp.g_varchar2_table(9) := 'LATURE (static_id);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38666223530644333316)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_app_nomenclature table'
,p_sequence=>90
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
