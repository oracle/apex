prompt --application/deployment/install/install_sp_report_questions_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_report_questions table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_report_questions ('||wwv_flow.LF||
'    id                             number '||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(2) := '                default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(3) := '                             constraint sp_report_questions_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    page_id      ';
wwv_flow_imp.g_varchar2_table(4) := '                  number  not null, -- fk to apex_application_pages.page_id'||wwv_flow.LF||
'    question            ';
wwv_flow_imp.g_varchar2_table(5) := '           varchar2(4000)  not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date            not n';
wwv_flow_imp.g_varchar2_table(6) := 'ull,'||wwv_flow.LF||
'    created_by                     varchar2(255)   not null,'||wwv_flow.LF||
'    updated                       ';
wwv_flow_imp.g_varchar2_table(7) := ' date            not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255)   not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create or';
wwv_flow_imp.g_varchar2_table(8) := ' replace trigger sp_report_questions_biu'||wwv_flow.LF||
'    before insert or update '||wwv_flow.LF||
'    on sp_report_questions'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(9) := ' for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new.created_by :';
wwv_flow_imp.g_varchar2_table(10) := '= coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated    := sysdate;';
wwv_flow_imp.g_varchar2_table(11) := ''||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'end sp_report_questio';
wwv_flow_imp.g_varchar2_table(12) := 'ns_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(29701040598697067628)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_report_questions table and trigger'
,p_sequence=>77
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
