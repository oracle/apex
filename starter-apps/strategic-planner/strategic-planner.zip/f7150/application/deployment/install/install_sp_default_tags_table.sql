prompt --application/deployment/install/install_sp_default_tags_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_default_tags table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table SP_DEFAULT_TAGS ('||wwv_flow.LF||
'    id                             number default on null to_number(s';
wwv_flow_imp.g_varchar2_table(2) := 'ys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint SP_DEF';
wwv_flow_imp.g_varchar2_table(3) := 'AULT_TAGS_pk primary key,'||wwv_flow.LF||
'    display_sequence               number            not null,'||wwv_flow.LF||
'    tag    ';
wwv_flow_imp.g_varchar2_table(4) := '                        varchar2(30 char) not null,'||wwv_flow.LF||
'    description                    varchar2(512 ';
wwv_flow_imp.g_varchar2_table(5) := 'char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by                     v';
wwv_flow_imp.g_varchar2_table(6) := 'archar2(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by        ';
wwv_flow_imp.g_varchar2_table(7) := '             varchar2(255 char) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index SP_DEFAULT_TAGS_u1 on SP_DEFAULT_T';
wwv_flow_imp.g_varchar2_table(8) := 'AGS (tag);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38666200808385329694)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_default_tags table'
,p_sequence=>80
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
