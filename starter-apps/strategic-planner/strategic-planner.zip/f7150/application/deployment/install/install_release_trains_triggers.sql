prompt --application/deployment/install/install_release_trains_triggers
begin
--   Manifest
--     INSTALL: INSTALL-release trains triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_release_trains_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_release_trains';
wwv_flow_imp.g_varchar2_table(2) := ''||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_old_value   varchar2(4000) := null;'||wwv_flow.LF||
'    l_new_value   varchar2(4000)';
wwv_flow_imp.g_varchar2_table(3) := ' := null;'||wwv_flow.LF||
'    l_changed_by  varchar2(255)  := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created';
wwv_flow_imp.g_varchar2_table(4) := ' := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(5) := 'nd if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_';
wwv_flow_imp.g_varchar2_table(6) := 'USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- defaults'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.release_completed is null then '||wwv_flow.LF||
'       :new.';
wwv_flow_imp.g_varchar2_table(7) := 'release_completed := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.RELEASE_OPEN_COMPLETED is null then'||wwv_flow.LF||
'       :new.RE';
wwv_flow_imp.g_varchar2_table(8) := 'LEASE_OPEN_COMPLETED := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- change history tracking'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updatin';
wwv_flow_imp.g_varchar2_table(9) := 'g then'||wwv_flow.LF||
'        l_changed_by := lower(:new.updated_by);'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        if not sp_value_compare.is';
wwv_flow_imp.g_varchar2_table(10) := '_equal(:old.release_train,:new.release_train) then'||wwv_flow.LF||
'           insert into sp_release_history'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(11) := '        (release_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(12) := '         values'||wwv_flow.LF||
'               (:new.id, ''RELEASE_TRAIN'', ''UPDATE'', :old.release_train, :new.release';
wwv_flow_imp.g_varchar2_table(13) := '_train, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.releas';
wwv_flow_imp.g_varchar2_table(14) := 'e,:new.release) then'||wwv_flow.LF||
'           insert into sp_release_history'||wwv_flow.LF||
'               (release_id, attribute';
wwv_flow_imp.g_varchar2_table(15) := '_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'           values'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(16) := ' (:new.id, ''RELEASE'', ''UPDATE'', :old.release, :new.release, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(17) := '        if not sp_value_compare.is_equal(:old.RELEASE_OWNER_ID,:new.RELEASE_OWNER_ID) then'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(18) := '  for c1 in (select email v from sp_team_members x where x.id = :old.RELEASE_OWNER_ID) loop l_old_va';
wwv_flow_imp.g_varchar2_table(19) := 'lue := c1.v; end loop;'||wwv_flow.LF||
'           for c1 in (select email v from sp_team_members x where x.id = :new';
wwv_flow_imp.g_varchar2_table(20) := '.RELEASE_OWNER_ID) loop l_new_value := c1.v; end loop;'||wwv_flow.LF||
'           insert into sp_release_history'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(21) := '            (release_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by';
wwv_flow_imp.g_varchar2_table(22) := ')'||wwv_flow.LF||
'           values'||wwv_flow.LF||
'               (:new.id, ''RELEASE_OWNER'', ''UPDATE'', l_old_value, l_new_value, sy';
wwv_flow_imp.g_varchar2_table(23) := 'sdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:o';
wwv_flow_imp.g_varchar2_table(24) := 'ld.RELEASE_OPEN_DATE,:new.RELEASE_OPEN_DATE) then'||wwv_flow.LF||
'          insert into sp_release_history'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(25) := '     (release_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(26) := '     values'||wwv_flow.LF||
'              (:new.id, ''RELEASE_OPEN_DATE'', ''UPDATE'', to_char(:old.RELEASE_OPEN_DATE,''D';
wwv_flow_imp.g_varchar2_table(27) := 'D-MON-YYYY''), to_char(:new.RELEASE_OPEN_DATE,''DD-MON-YYYY''), sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(28) := '       if not sp_value_compare.is_equal(:old.RELEASE_OPEN_COMPLETED,:new.RELEASE_OPEN_COMPLETED) the';
wwv_flow_imp.g_varchar2_table(29) := 'n'||wwv_flow.LF||
'          insert into sp_release_history'||wwv_flow.LF||
'              (release_id, attribute_column, change_type,';
wwv_flow_imp.g_varchar2_table(30) := ' old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''RELEASE_OPE';
wwv_flow_imp.g_varchar2_table(31) := 'N_COMPLETED'', ''UPDATE'', :old.RELEASE_OPEN_COMPLETED, :new.RELEASE_OPEN_COMPLETED, sysdate, l_changed';
wwv_flow_imp.g_varchar2_table(32) := '_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.RELEASE_TARGET_DATE,:new';
wwv_flow_imp.g_varchar2_table(33) := '.RELEASE_TARGET_DATE) then'||wwv_flow.LF||
'          insert into sp_release_history'||wwv_flow.LF||
'              (release_id, attri';
wwv_flow_imp.g_varchar2_table(34) := 'bute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(35) := '   (:new.id, ''RELEASE_TARGET_DATE'', ''UPDATE'', to_char(:old.RELEASE_TARGET_DATE,''DD-MON-YYYY''), to_ch';
wwv_flow_imp.g_varchar2_table(36) := 'ar(:new.RELEASE_TARGET_DATE,''DD-MON-YYYY''), sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       if not sp_';
wwv_flow_imp.g_varchar2_table(37) := 'value_compare.is_equal(:old.RELEASE_COMPLETED,:new.RELEASE_COMPLETED) then'||wwv_flow.LF||
'          insert into sp_';
wwv_flow_imp.g_varchar2_table(38) := 'release_history'||wwv_flow.LF||
'              (release_id, attribute_column, change_type, old_value, new_value, chan';
wwv_flow_imp.g_varchar2_table(39) := 'ged_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''RELEASE_COMPLETED'', ''UPDATE'', :old.REL';
wwv_flow_imp.g_varchar2_table(40) := 'EASE_COMPLETED, :new.RELEASE_COMPLETED, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_re';
wwv_flow_imp.g_varchar2_table(41) := 'lease_trains_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_release_trains_ai'||wwv_flow.LF||
'    after insert'||wwv_flow.LF||
'    on sp_relea';
wwv_flow_imp.g_varchar2_table(42) := 'se_trains'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_release_history'||wwv_flow.LF||
'        (release_id, attribute_c';
wwv_flow_imp.g_varchar2_table(43) := 'olumn, change_type, new_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:new.id, ''RELEASE'', ''CREA';
wwv_flow_imp.g_varchar2_table(44) := 'TE'', :new.release_train || '' '' ||:new.release, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'end sp_release_trai';
wwv_flow_imp.g_varchar2_table(45) := 'ns_ai;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_release_trains_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_release_trains'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(46) := '    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_release_history'||wwv_flow.LF||
'        (release_id, attribute_column, cha';
wwv_flow_imp.g_varchar2_table(47) := 'nge_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.id, ''RELEASE'', ''DELETE'', :old.';
wwv_flow_imp.g_varchar2_table(48) := 'release_train || '' '' ||:old.release, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),';
wwv_flow_imp.g_varchar2_table(49) := 'user)));'||wwv_flow.LF||
'end sp_release_trains_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(39232704596824323245)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'release trains triggers'
,p_sequence=>390
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
