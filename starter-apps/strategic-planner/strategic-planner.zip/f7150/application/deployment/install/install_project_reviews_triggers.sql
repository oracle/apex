prompt --application/deployment/install/install_project_reviews_triggers
begin
--   Manifest
--     INSTALL: INSTALL-project reviews triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>19055477148803894
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3614411729090932986)
,p_install_id=>wwv_flow_imp.id(141234962960674597981)
,p_name=>'project reviews triggers'
,p_sequence=>540
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace trigger sp_project_reviews_biu',
'    before insert or update',
'    on sp_project_reviews',
'    for each row',
'declare',
'    v1   varchar2(255) := null;',
'    v2   varchar2(255) := null;',
'    nv1  varchar2(255) := null;',
'    nv2  varchar2(255) := null;',
'begin',
'    if inserting then',
'        :new.created := sysdate;',
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'    end if;',
'    :new.updated := sysdate;',
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'    if :new.review_status is null then ',
'       :new.review_status := ''REQUESTED'';',
'    end if;',
'    if :new.review_type_id is null then',
'       for c1 in (select id from sp_project_review_types order by display_seq fetch first 1 rows only ) loop',
'          :new.review_type_id := c1.id;',
'       end loop;',
'    end if;',
'',
'    --',
'    -- touch parent table',
'    --',
'    update sp_projects set updated = sysdate, updated_by = :new.updated_by where id = :new.project_id;',
'',
'    --',
'    -- history',
'    --',
'    for c1 in (select email from sp_team_members x where x.id = :new.owner_id) loop',
'        nv1 := c1.email;',
'    end loop;',
'    for c1 in (select review_type from sp_project_review_types x where x.id = :new.review_type_id) loop',
'        nv2 := c1.review_type;',
'    end loop;',
'',
'    if inserting then',
'        insert into sp_project_history',
'            (project_id, attribute_column, change_type, new_value, changed_on, changed_by)',
'        values',
'            (:new.project_id, ''REVIEW'', ''CREATE'', nv2||'': ''||nv1||'', ''||:new.review_status||'', review_date=''||to_char(:new.review_date,''DD-MON-YYYY''), sysdate, lower(:new.created_by));',
'    elsif updating then',
'        for c1 in (select email from sp_team_members x where x.id = :old.owner_id) loop',
'            v1 := c1.email;',
'        end loop;',
'        for c1 in (select review_type from sp_project_review_types x where x.id = :old.review_type_id) loop',
'            v2 := c1.review_type;',
'        end loop;',
'        insert into sp_project_history',
'            (project_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)',
'        values',
'            (:new.project_id, ''REVIEW'', ''UPDATE'', ',
'             v2||'': ''||v1||'', ''||:old.review_status||'', review_date=''||to_char(:old.review_date,''DD-MON-YYYY''), ',
'             nv2||'': ''||nv1||'', ''||:new.review_status||'', review_date=''||to_char(:new.review_date,''DD-MON-YYYY''), ',
'             sysdate, lower(:new.updated_by));',
'    end if;',
'end sp_project_reviews_biu;',
'/',
'',
'create or replace trigger sp_project_reviews_bd',
'    before delete',
'    on sp_project_reviews',
'    for each row',
'declare',
'    v1   varchar2(255) := null;',
'    v2   varchar2(255) := null;',
'begin',
'    for c1 in (select email from sp_team_members x where x.id = :old.owner_id) loop',
'        v1 := c1.email;',
'    end loop;',
'    for c1 in (select review_type from sp_project_review_types x where x.id = :old.review_type_id) loop',
'        v2 := c1.review_type;',
'    end loop;',
'    insert into sp_project_history',
'        (project_id, attribute_column, change_type, old_value, changed_on, changed_by)',
'    values',
'        (:old.project_id, ''REVIEW'', ''DELETE'', v2||'': ''||v1||'', ''||:old.review_status||'', review_date=''||to_char(:old.review_date,''DD-MON-YYYY''), sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));',
'end sp_project_reviews_bd;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
