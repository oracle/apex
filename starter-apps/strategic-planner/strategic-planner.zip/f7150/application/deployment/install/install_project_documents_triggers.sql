prompt --application/deployment/install/install_project_documents_triggers
begin
--   Manifest
--     INSTALL: INSTALL-project documents triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_project_documents_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_project_doc';
wwv_flow_imp.g_varchar2_table(2) := 'uments'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_tags varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(3) := '   :new.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER';
wwv_flow_imp.g_varchar2_table(4) := '''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX';
wwv_flow_imp.g_varchar2_table(5) := '$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.tags := upper(:new.tags);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- t';
wwv_flow_imp.g_varchar2_table(6) := 'ouch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_projects set updated = sysdate, updated_by = :new.updated_by ';
wwv_flow_imp.g_varchar2_table(7) := 'where id = :new.project_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- adjust tag data'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.tags is not null then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(8) := '       l_tags := trim(upper(:new.tags));'||wwv_flow.LF||
'        -- remove multiple spaces'||wwv_flow.LF||
'        if instr(l_tags,''';
wwv_flow_imp.g_varchar2_table(9) := '  '') > 0 then'||wwv_flow.LF||
'            for j in 1..10 loop '||wwv_flow.LF||
'                l_tags := replace(l_tags,''  '','' ''); '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(10) := '                if instr(l_tags,''  '') = 0 then'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(11) := '        end loop; '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        for i in 1..length(l_tags) loop'||wwv_flow.LF||
'            if i > 2 and ';
wwv_flow_imp.g_varchar2_table(12) := 'substr(l_tags,i,1) = '' '' and substr(l_tags,i-1,1) != '','' then'||wwv_flow.LF||
'               l_tags := substr(l_tags';
wwv_flow_imp.g_varchar2_table(13) := ',1,i-1)||''-''||substr(l_tags,i+1);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        :new.tags := l_tags;';
wwv_flow_imp.g_varchar2_table(14) := ''||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        insert into sp_project_histor';
wwv_flow_imp.g_varchar2_table(15) := 'y'||wwv_flow.LF||
'            (project_id, attribute_column, change_type, new_value, changed_on, changed_by)'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(16) := ' values'||wwv_flow.LF||
'            (:new.project_id, ''DOCUMENT'', ''CREATE'', :new.DOCUMENT_FILENAME, sysdate, lower(:';
wwv_flow_imp.g_varchar2_table(17) := 'new.created_by));'||wwv_flow.LF||
'    elsif updating then '||wwv_flow.LF||
'        insert into sp_project_history'||wwv_flow.LF||
'            (proje';
wwv_flow_imp.g_varchar2_table(18) := 'ct_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(19) := '           (:new.project_id, ''DOCUMENT'', ''UPDATE'', :old.DOCUMENT_FILENAME, :new.DOCUMENT_FILENAME, s';
wwv_flow_imp.g_varchar2_table(20) := 'ysdate, lower(:new.updated_by));'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_project_documents_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trig';
wwv_flow_imp.g_varchar2_table(21) := 'ger sp_project_documents_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_project_documents'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(22) := ' --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_projects set updated = sysdate, updated_by = :old';
wwv_flow_imp.g_varchar2_table(23) := '.updated_by where id = :old.project_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    insert into sp_project_history'||wwv_flow.LF||
'        (project_i';
wwv_flow_imp.g_varchar2_table(24) := 'd, attribute_column, change_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.projec';
wwv_flow_imp.g_varchar2_table(25) := 't_id, ''DOCUMENT'', ''DELETE'', :old.document_filename, sysdate, lower(coalesce(sys_context(''APEX$SESSIO';
wwv_flow_imp.g_varchar2_table(26) := 'N'',''APP_USER''),user)));'||wwv_flow.LF||
'end sp_project_documents_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38224367776755673880)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'project documents triggers'
,p_sequence=>490
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
