prompt --application/deployment/install/install_initiative_focus_area_triggers
begin
--   Manifest
--     INSTALL: INSTALL-Initiative Focus Area triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_initiative_focus_areas_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_initia';
wwv_flow_imp.g_varchar2_table(2) := 'tive_focus_areas'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare '||wwv_flow.LF||
'    l_old_value   varchar2(4000) := null;'||wwv_flow.LF||
'    l_new_value';
wwv_flow_imp.g_varchar2_table(3) := '   varchar2(4000) := null;'||wwv_flow.LF||
'    l_changed_by  varchar2(255)  := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(4) := '     :new.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_US';
wwv_flow_imp.g_varchar2_table(5) := 'ER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''AP';
wwv_flow_imp.g_varchar2_table(6) := 'EX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        l_changed_b';
wwv_flow_imp.g_varchar2_table(7) := 'y := lower(:new.updated_by);'||wwv_flow.LF||
''||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.focus_area,:new.focus_ar';
wwv_flow_imp.g_varchar2_table(8) := 'ea) then'||wwv_flow.LF||
'            insert into sp_init_focus_area_history'||wwv_flow.LF||
'                (init_focus_area_id, att';
wwv_flow_imp.g_varchar2_table(9) := 'ribute_column, change_type, old_value, new_value,changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(10) := '        (:new.id, ''INITIATIVE_FOCUS_AREA'', ''UPDATE'', :old.focus_area, :new.focus_area, sysdate, l_ch';
wwv_flow_imp.g_varchar2_table(11) := 'anged_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.development_owner_id,:new.d';
wwv_flow_imp.g_varchar2_table(12) := 'evelopment_owner_id) then'||wwv_flow.LF||
'            for c1 in (select lower(email) r from SP_TEAM_MEMBERS x where ';
wwv_flow_imp.g_varchar2_table(13) := 'x.id = :old.development_owner_id) loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'            for c1 in (select ';
wwv_flow_imp.g_varchar2_table(14) := 'lower(email) r from SP_TEAM_MEMBERS x where x.id = :new.development_owner_id) loop l_new_value := c1';
wwv_flow_imp.g_varchar2_table(15) := '.r; end loop;'||wwv_flow.LF||
'            insert into sp_init_focus_area_history'||wwv_flow.LF||
'                (init_focus_area_id';
wwv_flow_imp.g_varchar2_table(16) := ', attribute_column, change_type, old_value, new_value,changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(17) := '             (:new.id, ''DEVELOPMENT_OWNER'', ''UPDATE'', l_old_value, l_new_value, sysdate, l_changed_b';
wwv_flow_imp.g_varchar2_table(18) := 'y);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.description,:new.description) then';
wwv_flow_imp.g_varchar2_table(19) := ''||wwv_flow.LF||
'            insert into sp_init_focus_area_history'||wwv_flow.LF||
'                (init_focus_area_id, attribute_c';
wwv_flow_imp.g_varchar2_table(20) := 'olumn, change_type, old_value, new_value,changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(21) := '(:new.id, ''DESCRIPTION'', ''UPDATE'', :old.description, :new.description, sysdate, l_changed_by);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(22) := '   end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.active_yn,:new.active_yn) then'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(23) := 'insert into sp_init_focus_area_history'||wwv_flow.LF||
'                (init_focus_area_id, attribute_column, change';
wwv_flow_imp.g_varchar2_table(24) := '_type, old_value, new_value,changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.id, ''AC';
wwv_flow_imp.g_varchar2_table(25) := 'TIVE'', ''UPDATE'', :old.active_yn, :new.active_yn, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if ';
wwv_flow_imp.g_varchar2_table(26) := 'not sp_value_compare.is_equal(:old.display_sequence,:new.display_sequence) then'||wwv_flow.LF||
'            insert i';
wwv_flow_imp.g_varchar2_table(27) := 'nto sp_init_focus_area_history'||wwv_flow.LF||
'                (init_focus_area_id, attribute_column, change_type, o';
wwv_flow_imp.g_varchar2_table(28) := 'ld_value, new_value,changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.id, ''DISPLAY_SE';
wwv_flow_imp.g_varchar2_table(29) := 'QUENCE'', ''UPDATE'', :old.display_sequence, :new.display_sequence, sysdate, l_changed_by);'||wwv_flow.LF||
'        end';
wwv_flow_imp.g_varchar2_table(30) := ' if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_initiative_focus_areas_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger sp_initiative_focus_';
wwv_flow_imp.g_varchar2_table(31) := 'areas_ai'||wwv_flow.LF||
'    after insert'||wwv_flow.LF||
'    on sp_initiative_focus_areas'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp';
wwv_flow_imp.g_varchar2_table(32) := '_init_focus_area_history'||wwv_flow.LF||
'        (init_focus_area_id, attribute_column, change_type, new_value, chan';
wwv_flow_imp.g_varchar2_table(33) := 'ged_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:new.id, ''INITIATIVE_FOCUS_AREA'', ''CREATE'', :new.focus_area,';
wwv_flow_imp.g_varchar2_table(34) := ' sysdate, lower(:new.created_by));'||wwv_flow.LF||
'end sp_initiative_focus_areas_ai;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger sp_';
wwv_flow_imp.g_varchar2_table(35) := 'initiative_focus_areas_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_initiative_focus_areas'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(36) := '    insert into sp_init_focus_area_history'||wwv_flow.LF||
'        (init_focus_area_id, attribute_column, change_typ';
wwv_flow_imp.g_varchar2_table(37) := 'e, old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.id, ''INITIATIVE_FOCUS_AREA'', ''DELETE''';
wwv_flow_imp.g_varchar2_table(38) := ', :old.focus_area, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'end sp_in';
wwv_flow_imp.g_varchar2_table(39) := 'itiative_focus_areas_bd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_init_focus_area_links_biu'||wwv_flow.LF||
'    before inser';
wwv_flow_imp.g_varchar2_table(40) := 't or update'||wwv_flow.LF||
'    on sp_init_focus_area_links'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :ne';
wwv_flow_imp.g_varchar2_table(41) := 'w.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),use';
wwv_flow_imp.g_varchar2_table(42) := 'r);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSI';
wwv_flow_imp.g_varchar2_table(43) := 'ON'',''APP_USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_initiative_focus_areas ';
wwv_flow_imp.g_varchar2_table(44) := 'set updated = sysdate, updated_by = :new.updated_by where id = :new.init_focus_area_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(45) := '- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        insert into sp_init_focus_area_history'||wwv_flow.LF||
'            (i';
wwv_flow_imp.g_varchar2_table(46) := 'nit_focus_area_id, attribute_column, change_type, new_value, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(47) := '            (:new.init_focus_area_id, ''LINK'', ''CREATE'', :new.link_url, sysdate, lower(:new.created_b';
wwv_flow_imp.g_varchar2_table(48) := 'y));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.link_url,:new.link_url) t';
wwv_flow_imp.g_varchar2_table(49) := 'hen'||wwv_flow.LF||
'            insert into sp_init_focus_area_history'||wwv_flow.LF||
'                (init_focus_area_id, attribut';
wwv_flow_imp.g_varchar2_table(50) := 'e_column, change_type, old_value, new_value,changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(51) := '   (:new.init_focus_area_id, ''LINK'', ''UPDATE'', :old.link_url, :new.link_url, sysdate, lower(:new.upd';
wwv_flow_imp.g_varchar2_table(52) := 'ated_by));'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_init_focus_area_links_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigg';
wwv_flow_imp.g_varchar2_table(53) := 'er sp_init_focus_area_links_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_init_focus_area_links'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'be';
wwv_flow_imp.g_varchar2_table(54) := 'gin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_initiative_focus_areas set updated = sysda';
wwv_flow_imp.g_varchar2_table(55) := 'te, updated_by = :old.updated_by where id = :old.init_focus_area_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    insert into sp_init_';
wwv_flow_imp.g_varchar2_table(56) := 'focus_area_history'||wwv_flow.LF||
'        (init_focus_area_id, attribute_column, change_type, old_value, changed_on';
wwv_flow_imp.g_varchar2_table(57) := ', changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.init_focus_area_id, ''LINK'', ''DELETE'', :old.link_url, sysdate,';
wwv_flow_imp.g_varchar2_table(58) := ' lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'end sp_init_focus_area_links_bd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(59) := '	'||wwv_flow.LF||
'create or replace trigger sp_init_focus_area_documents_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_i';
wwv_flow_imp.g_varchar2_table(60) := 'nit_focus_area_documents'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_tags varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if in';
wwv_flow_imp.g_varchar2_table(61) := 'serting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$';
wwv_flow_imp.g_varchar2_table(62) := 'SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce';
wwv_flow_imp.g_varchar2_table(63) := '(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.tags := upper(:new.tags';
wwv_flow_imp.g_varchar2_table(64) := ');'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_initiative_focus_areas set updated = sysdat';
wwv_flow_imp.g_varchar2_table(65) := 'e, updated_by = :new.updated_by where id = :new.init_focus_area_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- adjust tag data'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(66) := '  --'||wwv_flow.LF||
'    if :new.tags is not null then'||wwv_flow.LF||
'        l_tags := trim(upper(:new.tags));'||wwv_flow.LF||
'        -- remove m';
wwv_flow_imp.g_varchar2_table(67) := 'ultiple spaces'||wwv_flow.LF||
'        if instr(l_tags,''  '') > 0 then'||wwv_flow.LF||
'            for j in 1..10 loop '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(68) := '   l_tags := replace(l_tags,''  '','' ''); '||wwv_flow.LF||
'                if instr(l_tags,''  '') = 0 then'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(69) := '      exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        for i in 1..lengt';
wwv_flow_imp.g_varchar2_table(70) := 'h(l_tags) loop'||wwv_flow.LF||
'            if i > 2 and substr(l_tags,i,1) = '' '' and substr(l_tags,i-1,1) != '','' the';
wwv_flow_imp.g_varchar2_table(71) := 'n'||wwv_flow.LF||
'               l_tags := substr(l_tags,1,i-1)||''-''||substr(l_tags,i+1);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(72) := '  end loop;'||wwv_flow.LF||
'        :new.tags := l_tags;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting th';
wwv_flow_imp.g_varchar2_table(73) := 'en'||wwv_flow.LF||
'        insert into sp_init_focus_area_history'||wwv_flow.LF||
'            (init_focus_area_id, attribute_column,';
wwv_flow_imp.g_varchar2_table(74) := ' change_type, new_value, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.init_focus_area_id';
wwv_flow_imp.g_varchar2_table(75) := ', ''DOCUMENT'', ''CREATE'', :new.DOCUMENT_FILENAME, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'    elsif updating';
wwv_flow_imp.g_varchar2_table(76) := ' then '||wwv_flow.LF||
'        insert into sp_init_focus_area_history'||wwv_flow.LF||
'            (init_focus_area_id, attribute_col';
wwv_flow_imp.g_varchar2_table(77) := 'umn, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.ini';
wwv_flow_imp.g_varchar2_table(78) := 't_focus_area_id, ''DOCUMENT'', ''UPDATE'', :old.DOCUMENT_FILENAME, :new.DOCUMENT_FILENAME, sysdate, lowe';
wwv_flow_imp.g_varchar2_table(79) := 'r(:new.updated_by));'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_init_focus_area_documents_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger ';
wwv_flow_imp.g_varchar2_table(80) := 'sp_init_focus_area_documents_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_init_focus_area_documents'||wwv_flow.LF||
'    for each r';
wwv_flow_imp.g_varchar2_table(81) := 'ow'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_initiative_focus_areas set updated = ';
wwv_flow_imp.g_varchar2_table(82) := 'sysdate, updated_by = :old.updated_by where id = :old.init_focus_area_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    insert into sp_';
wwv_flow_imp.g_varchar2_table(83) := 'init_focus_area_history'||wwv_flow.LF||
'        (init_focus_area_id, attribute_column, change_type, old_value, chang';
wwv_flow_imp.g_varchar2_table(84) := 'ed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.init_focus_area_id, ''DOCUMENT'', ''DELETE'', :old.document_';
wwv_flow_imp.g_varchar2_table(85) := 'filename, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'end sp_init_focus_';
wwv_flow_imp.g_varchar2_table(86) := 'area_documents_bd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_init_focus_area_comments_biu'||wwv_flow.LF||
'    before insert o';
wwv_flow_imp.g_varchar2_table(87) := 'r update'||wwv_flow.LF||
'    on sp_init_focus_area_comments'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :ne';
wwv_flow_imp.g_varchar2_table(88) := 'w.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),use';
wwv_flow_imp.g_varchar2_table(89) := 'r);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSI';
wwv_flow_imp.g_varchar2_table(90) := 'ON'',''APP_USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.private_yn is null then '||wwv_flow.LF||
'        :new.privat';
wwv_flow_imp.g_varchar2_table(91) := 'e_yn := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_initiative_focus_area';
wwv_flow_imp.g_varchar2_table(92) := 's set updated = sysdate, updated_by = :new.updated_by where id = :new.init_focus_area_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(93) := ' -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting and :new.private_yn = ''N'' then'||wwv_flow.LF||
'        insert into sp_init_focus';
wwv_flow_imp.g_varchar2_table(94) := '_area_history'||wwv_flow.LF||
'            (init_focus_area_id, attribute_column, change_type, new_value, new_value_c';
wwv_flow_imp.g_varchar2_table(95) := 'lob, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.init_focus_area_id, ''COMMENT'', ''CREATE';
wwv_flow_imp.g_varchar2_table(96) := ''', dbms_lob.substr(:new.body_no_images,500,1), :new.body_no_images, sysdate, lower(:new.created_by))';
wwv_flow_imp.g_varchar2_table(97) := ';'||wwv_flow.LF||
'    elsif updating and :old.private_yn = ''N'' and :new.private_yn = ''N'' then'||wwv_flow.LF||
'        if not sp_valu';
wwv_flow_imp.g_varchar2_table(98) := 'e_compare.is_equal(:old.body_no_images,:new.body_no_images) then'||wwv_flow.LF||
'            insert into sp_init_foc';
wwv_flow_imp.g_varchar2_table(99) := 'us_area_history'||wwv_flow.LF||
'                (init_focus_area_id, attribute_column, change_type, old_value, new_v';
wwv_flow_imp.g_varchar2_table(100) := 'alue, old_value_clob, new_value_clob, changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:n';
wwv_flow_imp.g_varchar2_table(101) := 'ew.init_focus_area_id, ''COMMENT'', ''UPDATE'', dbms_lob.substr(:old.body_no_images,500,1), dbms_lob.sub';
wwv_flow_imp.g_varchar2_table(102) := 'str(:new.body_no_images,500,1), :old.body_no_images, :new.body_no_images, sysdate, lower(:new.update';
wwv_flow_imp.g_varchar2_table(103) := 'd_by));'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_init_focus_area_comments_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger';
wwv_flow_imp.g_varchar2_table(104) := ' sp_init_focus_area_comments_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_init_focus_area_comments'||wwv_flow.LF||
'    for each ro';
wwv_flow_imp.g_varchar2_table(105) := 'w'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :old.private_yn = ''N'' then'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_init';
wwv_flow_imp.g_varchar2_table(106) := 'iative_focus_areas set updated = sysdate, updated_by = :old.updated_by where id = :old.init_focus_ar';
wwv_flow_imp.g_varchar2_table(107) := 'ea_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    insert into sp_init_focus_area_history'||wwv_flow.LF||
'        (init_focus_area_id, attribute_colu';
wwv_flow_imp.g_varchar2_table(108) := 'mn, change_type, old_value, old_value_clob, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.init_fo';
wwv_flow_imp.g_varchar2_table(109) := 'cus_area_id, ''COMMENT'', ''DELETE'', dbms_lob.substr(:old.body_no_images,500,1), :old.body_no_images, s';
wwv_flow_imp.g_varchar2_table(110) := 'ysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_init_focus';
wwv_flow_imp.g_varchar2_table(111) := '_area_comments_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(53804463742521797528)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'Initiative Focus Area triggers'
,p_sequence=>450
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
