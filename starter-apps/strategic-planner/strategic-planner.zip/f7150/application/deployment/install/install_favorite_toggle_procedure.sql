prompt --application/deployment/install/install_favorite_toggle_procedure
begin
--   Manifest
--     INSTALL: INSTALL-favorite_toggle procedure
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace procedure sp_favorite_toggle ('||wwv_flow.LF||
'   p_project_id  in number,'||wwv_flow.LF||
'   p_app_user_id in num';
wwv_flow_imp.g_varchar2_table(2) := 'ber)'||wwv_flow.LF||
'is  '||wwv_flow.LF||
'   is_favorite  boolean := false;'||wwv_flow.LF||
'   l_count      int;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if p_project_id is null t';
wwv_flow_imp.g_varchar2_table(3) := 'hen '||wwv_flow.LF||
'        raise_application_error(-20001,''p_project_id is null'');'||wwv_flow.LF||
'    elsif p_app_user_id is null';
wwv_flow_imp.g_varchar2_table(4) := ' then'||wwv_flow.LF||
'        raise_application_error(-20001,''p_app_user_id is null'');'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        select count';
wwv_flow_imp.g_varchar2_table(5) := ' (*) into l_count from sp_projects where id = p_project_id;'||wwv_flow.LF||
'        if l_count = 0 then'||wwv_flow.LF||
'           r';
wwv_flow_imp.g_varchar2_table(6) := 'aise_application_error(-20001,''p_project_id ''||p_project_id||'' not found'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end ';
wwv_flow_imp.g_varchar2_table(7) := 'if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- If a row is returned then this project is a favorate of the user identified'||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(8) := '-'||wwv_flow.LF||
'    for c1 in (select 1 from SP_FAVORITES where team_member_id = p_app_user_id and project_id = p_';
wwv_flow_imp.g_varchar2_table(9) := 'project_id) loop'||wwv_flow.LF||
'        is_favorite := true;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- toggle current setting'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(10) := '  -- if is currently favorite then unfavorite by deleting row'||wwv_flow.LF||
'    -- if not currently a favorite the';
wwv_flow_imp.g_varchar2_table(11) := 'n favorate by inserting a row'||wwv_flow.LF||
'    --'||wwv_flow.LF||
''||wwv_flow.LF||
'    if is_favorite then'||wwv_flow.LF||
'        delete from SP_FAVORITES where';
wwv_flow_imp.g_varchar2_table(12) := ' team_member_id = p_app_user_id and project_id = p_project_id;'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        insert into SP_FAVOR';
wwv_flow_imp.g_varchar2_table(13) := 'ITES (team_member_id, PROJECT_ID) values (p_app_user_id, p_project_id);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_favorite';
wwv_flow_imp.g_varchar2_table(14) := '_toggle;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38980248163073557642)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'favorite_toggle procedure'
,p_sequence=>620
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
