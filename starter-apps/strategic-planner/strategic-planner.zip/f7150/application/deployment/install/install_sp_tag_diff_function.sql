prompt --application/deployment/install/install_sp_tag_diff_function
begin
--   Manifest
--     INSTALL: INSTALL-sp_tag_diff function
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace function sp_tag_diff ('||wwv_flow.LF||
'    p_old_tags in varchar2,'||wwv_flow.LF||
'    p_new_tags in varchar2)'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(2) := ' return varchar2 '||wwv_flow.LF||
'is'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- Example:'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- begin dbms_output.put_line(sp_tag_diff (p_';
wwv_flow_imp.g_varchar2_table(3) := 'old_tags => ''A,C'',p_new_tags => ''B,C,D'')); end;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    l_return        varchar2(32767);'||wwv_flow.LF||
'    l_vc';
wwv_flow_imp.g_varchar2_table(4) := '_arr_old    APEX_APPLICATION_GLOBAL.VC_ARR2;'||wwv_flow.LF||
'    l_vc_arr_new    APEX_APPLICATION_GLOBAL.VC_ARR2;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(5) := '  l_plus_string   varchar2(32767);'||wwv_flow.LF||
'    l_minus_string  varchar2(32767);'||wwv_flow.LF||
'    l_old_tags      varchar2';
wwv_flow_imp.g_varchar2_table(6) := '(32767) := upper('',''||replace(p_old_tags,'' '','''')||'','');'||wwv_flow.LF||
'    l_new_tags      varchar2(32767) := upper';
wwv_flow_imp.g_varchar2_table(7) := '('',''||replace(p_new_tags,'' '','''')||'','');'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_vc_arr_old := APEX_UTIL.STRING_TO_TABLE(upper(re';
wwv_flow_imp.g_varchar2_table(8) := 'place(p_old_tags,'' '',null)),'','');'||wwv_flow.LF||
'    l_vc_arr_new := APEX_UTIL.STRING_TO_TABLE(upper(replace(p_new_';
wwv_flow_imp.g_varchar2_table(9) := 'tags,'' '',null)),'','');'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- look for removed tags'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for i in 1..l_vc_arr_old.count ';
wwv_flow_imp.g_varchar2_table(10) := 'loop'||wwv_flow.LF||
'        if instr(l_new_tags,'',''||l_vc_arr_old(i)||'','') = 0 then'||wwv_flow.LF||
'            l_return := l_retur';
wwv_flow_imp.g_varchar2_table(11) := 'n||''<span class="t-Badge u-danger">''||apex_escape.html(l_vc_arr_old(i))||''</span> '';'||wwv_flow.LF||
'        end if;';
wwv_flow_imp.g_varchar2_table(12) := ''||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- look for new tags'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for i in 1..l_vc_arr_new.count loop'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(13) := '  if instr(l_old_tags,'',''||l_vc_arr_new(i)||'','') = 0 then'||wwv_flow.LF||
'            l_return := l_return||''<span c';
wwv_flow_imp.g_varchar2_table(14) := 'lass="t-Badge u-success">''||apex_escape.html(l_vc_arr_new(i))||''</span> '';'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end l';
wwv_flow_imp.g_varchar2_table(15) := 'oop;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    return l_return;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38134887016916507321)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_tag_diff function'
,p_sequence=>600
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
