prompt --application/deployment/install/install_project_review_types_sp_project_review_types
begin
--   Manifest
--     INSTALL: INSTALL-project review types - sp_project_review_types
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3626330236286350767)
,p_install_id=>wwv_flow_imp.id(141180564419272860082)
,p_name=>'project review types - sp_project_review_types'
,p_sequence=>220
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table sp_project_review_types (',
'    id                             number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') ',
'                                   constraint sp_project_rev_type_id_pk primary key,',
'    --',
'    review_type                    varchar2(100 char) not null,',
'    static_id                      varchar2(30 char)  not null,',
'    description                    varchar2(4000 char),',
'    display_seq                    number,',
'    include_yn                     varchar2(1 char),',
'    --',
'    created                        date not null,',
'    created_by                     varchar2(255 char) not null,',
'    updated                        date not null,',
'    updated_by                     varchar2(255 char) not null',
')',
';',
'',
'create unique index sp_project_review_types_u1 on sp_project_review_types (review_type);',
'create unique index sp_project_review_types_u2 on sp_project_review_types (display_seq);',
'create unique index sp_project_review_types_u3 on sp_project_review_types (static_id);',
'',
''))
);
wwv_flow_imp.component_end;
end;
/
