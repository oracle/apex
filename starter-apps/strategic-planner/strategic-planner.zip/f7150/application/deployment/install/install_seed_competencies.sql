prompt --application/deployment/install/install_seed_competencies
begin
--   Manifest
--     INSTALL: INSTALL-seed competencies
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into SP_COMPETENCIES'||wwv_flow.LF||
'    (ID, COMPETENCY, DESCRIPTION) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (1, ''JavaScript (Adva';
wwv_flow_imp.g_varchar2_table(2) := 'nced)'', '''');'||wwv_flow.LF||
'insert into SP_COMPETENCIES'||wwv_flow.LF||
'    (ID, COMPETENCY, DESCRIPTION) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (2, ''Jav';
wwv_flow_imp.g_varchar2_table(3) := 'aScript (Intermediate)'', '''');'||wwv_flow.LF||
'insert into SP_COMPETENCIES'||wwv_flow.LF||
'    (ID, COMPETENCY, DESCRIPTION) '||wwv_flow.LF||
'    val';
wwv_flow_imp.g_varchar2_table(4) := 'ues '||wwv_flow.LF||
'    (3, ''CSS (Advanced)'', '''');'||wwv_flow.LF||
'insert into SP_COMPETENCIES'||wwv_flow.LF||
'    (ID, COMPETENCY, DESCRIPTION) '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(5) := '   values '||wwv_flow.LF||
'    (4, ''PL/SQL (Advanced)'', ''Demonstrated expertise in writing and optimizing advanced P';
wwv_flow_imp.g_varchar2_table(6) := 'L/SQL code, including complex stored procedures, functions, packages, and triggers. Strong performan';
wwv_flow_imp.g_varchar2_table(7) := 'ce tuning. Strong debugging skills.'');'||wwv_flow.LF||
'insert into SP_COMPETENCIES'||wwv_flow.LF||
'    (ID, COMPETENCY, DESCRIPTION)';
wwv_flow_imp.g_varchar2_table(8) := ' '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (5, ''PL/SQL (Intermediate)'', ''Ability to write efficient, complex queries and stor';
wwv_flow_imp.g_varchar2_table(9) := 'ed procedures. Demonstrates a solid understanding of PL/SQL programming constructs. Someone who is a';
wwv_flow_imp.g_varchar2_table(10) := ' profesional PL/SQL programmer whose code is used by others.'');'||wwv_flow.LF||
'insert into SP_COMPETENCIES'||wwv_flow.LF||
'    (ID,';
wwv_flow_imp.g_varchar2_table(11) := ' COMPETENCY, DESCRIPTION) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (6, ''APEX App Development (Advanced)'', ''Comfortable build';
wwv_flow_imp.g_varchar2_table(12) := 'ing and deploying applications used by hundreds or thousands of people.'');'||wwv_flow.LF||
'insert into SP_COMPETENCI';
wwv_flow_imp.g_varchar2_table(13) := 'ES'||wwv_flow.LF||
'    (ID, COMPETENCY, DESCRIPTION) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (7, ''Graphics Design'', '''');'||wwv_flow.LF||
'insert into SP_COM';
wwv_flow_imp.g_varchar2_table(14) := 'PETENCIES'||wwv_flow.LF||
'    (ID, COMPETENCY, DESCRIPTION) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (8, ''Accessibility'', '''');'||wwv_flow.LF||
'insert into S';
wwv_flow_imp.g_varchar2_table(15) := 'P_COMPETENCIES'||wwv_flow.LF||
'    (ID, COMPETENCY, DESCRIPTION) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (9, ''UI Design'', '''');'||wwv_flow.LF||
'insert into ';
wwv_flow_imp.g_varchar2_table(16) := 'SP_COMPETENCIES'||wwv_flow.LF||
'    (ID, COMPETENCY, DESCRIPTION) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (10, ''CSS (Intermediate)'', ''A hig';
wwv_flow_imp.g_varchar2_table(17) := 'h level of proficiency and experience in front-end development. Ability to create responsive and ada';
wwv_flow_imp.g_varchar2_table(18) := 'ptive designs that work across various devices and screen sizes.'');'||wwv_flow.LF||
'insert into SP_COMPETENCIES'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(19) := '(ID, COMPETENCY, DESCRIPTION) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (11, ''Database Design'', '''');'||wwv_flow.LF||
'insert into SP_COMPETENC';
wwv_flow_imp.g_varchar2_table(20) := 'IES'||wwv_flow.LF||
'    (ID, COMPETENCY, DESCRIPTION) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (12, ''DevOps'', ''Build tools, automations, etc';
wwv_flow_imp.g_varchar2_table(21) := '.'');'||wwv_flow.LF||
'insert into SP_COMPETENCIES'||wwv_flow.LF||
'    (ID, COMPETENCY, DESCRIPTION) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (13, ''Performanc';
wwv_flow_imp.g_varchar2_table(22) := 'e Tuning'', ''Comfortable performance tuning SQL and PL/SQL. Can get to the root of a performance prob';
wwv_flow_imp.g_varchar2_table(23) := 'lem.'');'||wwv_flow.LF||
'insert into SP_COMPETENCIES'||wwv_flow.LF||
'    (ID, COMPETENCY, DESCRIPTION) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (14, ''APEX Ap';
wwv_flow_imp.g_varchar2_table(24) := 'p Development (Intermediate)'', ''Comfortable building APEX applications with moderate complexity and ';
wwv_flow_imp.g_varchar2_table(25) := 'quality UI and usability.'');'||wwv_flow.LF||
'insert into SP_COMPETENCIES'||wwv_flow.LF||
'    (ID, COMPETENCY, DESCRIPTION) '||wwv_flow.LF||
'    valu';
wwv_flow_imp.g_varchar2_table(26) := 'es '||wwv_flow.LF||
'    (15, ''Multimedia Production'', ''Video, motion, and other multimedia production'');'||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(27) := ' SP_COMPETENCIES'||wwv_flow.LF||
'    (ID, COMPETENCY, DESCRIPTION) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (16, ''Product Management'', '''');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(28) := 'insert into SP_COMPETENCIES'||wwv_flow.LF||
'    (ID, COMPETENCY, DESCRIPTION) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (17, ''Testing'', '''');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(29) := 'insert into SP_COMPETENCIES'||wwv_flow.LF||
'    (ID, COMPETENCY, DESCRIPTION) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (18, ''Security'', '''');';
wwv_flow_imp.g_varchar2_table(30) := ''||wwv_flow.LF||
'insert into SP_COMPETENCIES'||wwv_flow.LF||
'    (ID, COMPETENCY, DESCRIPTION) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (19, ''SQL (Advanced)';
wwv_flow_imp.g_varchar2_table(31) := ''', ''Advanced SQL skills including strong understanding of performance and syntax. Goto person for SQ';
wwv_flow_imp.g_varchar2_table(32) := 'L.'');'||wwv_flow.LF||
'insert into SP_COMPETENCIES'||wwv_flow.LF||
'    (ID, COMPETENCY, DESCRIPTION) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (20, ''Program M';
wwv_flow_imp.g_varchar2_table(33) := 'anagement'', '''');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(52441260576615193686)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed competencies'
,p_sequence=>880
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
