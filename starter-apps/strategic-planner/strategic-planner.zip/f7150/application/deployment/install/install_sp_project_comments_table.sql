prompt --application/deployment/install/install_sp_project_comments_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_project_comments table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_project_comments ('||wwv_flow.LF||
'    id                             number default on null to_numb';
wwv_flow_imp.g_varchar2_table(2) := 'er(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp';
wwv_flow_imp.g_varchar2_table(3) := '_project_comments_id_pk primary key,'||wwv_flow.LF||
'    project_id                     number'||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(4) := '              constraint sp_project_comm_proj_id_fk'||wwv_flow.LF||
'                                   references sp';
wwv_flow_imp.g_varchar2_table(5) := '_projects on delete cascade,'||wwv_flow.LF||
'    body                           clob,'||wwv_flow.LF||
'    body_html                 ';
wwv_flow_imp.g_varchar2_table(6) := '     clob,'||wwv_flow.LF||
'    body_no_images                 clob,'||wwv_flow.LF||
'    image_ref_id                   number,'||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(7) := 'rivate_yn                     varchar2(1 char)'||wwv_flow.LF||
'                                   default on null ''Y';
wwv_flow_imp.g_varchar2_table(8) := ''''||wwv_flow.LF||
'                                   constraint sp_project_comm_private_ck'||wwv_flow.LF||
'                         ';
wwv_flow_imp.g_varchar2_table(9) := '          check (private_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    author_id                      number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    cre';
wwv_flow_imp.g_varchar2_table(10) := 'ated                        date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not';
wwv_flow_imp.g_varchar2_table(11) := ' null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by                     varchar2';
wwv_flow_imp.g_varchar2_table(12) := '(255 char) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_project_comments_i1 on sp_project_comments (project_id);'||wwv_flow.LF||
'cr';
wwv_flow_imp.g_varchar2_table(13) := 'eate index sp_project_comments_i2 on sp_project_comments (author_id);'||wwv_flow.LF||
'create index sp_project_commen';
wwv_flow_imp.g_varchar2_table(14) := 'ts_i3 on sp_project_comments (updated);'||wwv_flow.LF||
'create index sp_project_comments_i4 on sp_project_comments (';
wwv_flow_imp.g_varchar2_table(15) := 'image_ref_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_project_comments_emails ('||wwv_flow.LF||
'    id                             number ';
wwv_flow_imp.g_varchar2_table(16) := 'default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                         ';
wwv_flow_imp.g_varchar2_table(17) := '          constraint sp_proj_comment_em_id_pk primary key,'||wwv_flow.LF||
'    comment_id                     number';
wwv_flow_imp.g_varchar2_table(18) := ''||wwv_flow.LF||
'                                   constraint sp_proj_comment_em_id_fk'||wwv_flow.LF||
'                            ';
wwv_flow_imp.g_varchar2_table(19) := '       references sp_project_comments (id)'||wwv_flow.LF||
'                                   on delete cascade,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(20) := ' email                          varchar2(255 char)'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_project_comm_emails_i1 on sp_';
wwv_flow_imp.g_varchar2_table(21) := 'project_comments_emails (comment_id);'||wwv_flow.LF||
'create index sp_project_comm_emails_i2 on sp_project_comments_';
wwv_flow_imp.g_varchar2_table(22) := 'emails (email);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38667683472379490690)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_project_comments table'
,p_sequence=>270
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
