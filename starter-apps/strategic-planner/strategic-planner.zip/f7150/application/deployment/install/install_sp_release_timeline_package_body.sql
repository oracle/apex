prompt --application/deployment/install/install_sp_release_timeline_package_body
begin
--   Manifest
--     INSTALL: INSTALL-sp_release_timeline package body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body sp_release_timeline'||wwv_flow.LF||
'as'||wwv_flow.LF||
'function show_week ('||wwv_flow.LF||
'    p_release_id         ';
wwv_flow_imp.g_varchar2_table(2) := '  in number,'||wwv_flow.LF||
'    p_show_past_yn         in varchar2 default ''N'','||wwv_flow.LF||
'    p_exclude_complete_yn  in varch';
wwv_flow_imp.g_varchar2_table(3) := 'ar2 default ''N'')'||wwv_flow.LF||
'    return clob'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_first_day_of_week    date;'||wwv_flow.LF||
'    l_last_day_of_week     date';
wwv_flow_imp.g_varchar2_table(4) := ';'||wwv_flow.LF||
'    x                      clob := null;'||wwv_flow.LF||
'    x2                     clob := null;'||wwv_flow.LF||
'    l_row_count ';
wwv_flow_imp.g_varchar2_table(5) := '           int := 0;'||wwv_flow.LF||
'    e                      varchar2(1) := chr(10);'||wwv_flow.LF||
'    l_proj_max_length      i';
wwv_flow_imp.g_varchar2_table(6) := 'nt := 45;'||wwv_flow.LF||
'    l_the_metric           varchar2(255);'||wwv_flow.LF||
'    l_dt_fmt_short         varchar2(10) := ''FMMo';
wwv_flow_imp.g_varchar2_table(7) := 'nth DD'';'||wwv_flow.LF||
'    l_weeks_to_show        int;'||wwv_flow.LF||
'    l_release_end_date     date;'||wwv_flow.LF||
'    l_release_start_date  ';
wwv_flow_imp.g_varchar2_table(8) := ' date;'||wwv_flow.LF||
'    l_release_start_monday date;'||wwv_flow.LF||
'    l_sysdate              date := trunc(sysdate);'||wwv_flow.LF||
'    h    ';
wwv_flow_imp.g_varchar2_table(9) := '                  varchar2(4000) := null;'||wwv_flow.LF||
'    l_start_date           date;'||wwv_flow.LF||
'    l_end_date           ';
wwv_flow_imp.g_varchar2_table(10) := '  date;'||wwv_flow.LF||
'    week                   int;'||wwv_flow.LF||
'    post_hr                varchar2(1) := ''n'';'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    fo';
wwv_flow_imp.g_varchar2_table(11) := 'r c1 in ('||wwv_flow.LF||
'        select id release_id, '||wwv_flow.LF||
'               trunc(release_open_date) release_open_date,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(12) := '               to_char(release_open_date,''Day Month FMDD, YYYY'') release_open,'||wwv_flow.LF||
'               nvl(re';
wwv_flow_imp.g_varchar2_table(13) := 'lease_open_completed,''N'') release_open_yn,'||wwv_flow.LF||
'               trunc(release_target_date) release_target_';
wwv_flow_imp.g_varchar2_table(14) := 'date, '||wwv_flow.LF||
'               to_char(release_target_date,''Day Month FMDD, YYYY'') release_target,'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(15) := '     nvl(release_completed,''N'') release_completed_yn,'||wwv_flow.LF||
'               release_train||'' ''||release as ';
wwv_flow_imp.g_varchar2_table(16) := 'release,'||wwv_flow.LF||
'               (select min(milestone_date) from sp_release_milestones'||wwv_flow.LF||
'                 wher';
wwv_flow_imp.g_varchar2_table(17) := 'e release_id = r.id'||wwv_flow.LF||
'                   and milestone_date is not null) min_milestone,'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(18) := ' (select max(milestone_date) from sp_release_milestones'||wwv_flow.LF||
'                 where release_id = r.id'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(19) := '                and milestone_date is not null) max_milestone,'||wwv_flow.LF||
'               (select min(nvl(nvl(t.';
wwv_flow_imp.g_varchar2_table(20) := 'target_complete,t.start_date),r.release_open_date))'||wwv_flow.LF||
'                  from sp_projects p,'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(21) := '             sp_tasks t'||wwv_flow.LF||
'                 where p.release_id = r.id'||wwv_flow.LF||
'                   and p.id = t.p';
wwv_flow_imp.g_varchar2_table(22) := 'roject_id'||wwv_flow.LF||
'                   and nvl(p.archived_yn,''N'') = ''N'''||wwv_flow.LF||
'                   and p.duplicate_of_';
wwv_flow_imp.g_varchar2_table(23) := 'project_id is null) min_task,'||wwv_flow.LF||
'               (select max(nvl(nvl(t.target_complete,t.start_date),r.r';
wwv_flow_imp.g_varchar2_table(24) := 'elease_open_date))'||wwv_flow.LF||
'                  from sp_projects p,'||wwv_flow.LF||
'                       sp_tasks t'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(25) := '        where p.release_id = r.id'||wwv_flow.LF||
'                   and p.id = t.project_id'||wwv_flow.LF||
'                   and ';
wwv_flow_imp.g_varchar2_table(26) := 'nvl(p.archived_yn,''N'') = ''N'''||wwv_flow.LF||
'                   and p.duplicate_of_project_id is null) max_task'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(27) := '     from sp_release_trains  r'||wwv_flow.LF||
'        where id = p_release_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        if p_show_past_yn ';
wwv_flow_imp.g_varchar2_table(28) := '= ''Y'' then'||wwv_flow.LF||
'            l_start_date := least(nvl(c1.min_milestone,c1.release_open_date),'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(29) := '                       nvl(c1.min_task,c1.release_open_date));'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            l_start_date';
wwv_flow_imp.g_varchar2_table(30) := ' := sysdate;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        l_end_date := greatest(nvl(c1.max_milestone,c1.release_target_d';
wwv_flow_imp.g_varchar2_table(31) := 'ate),'||wwv_flow.LF||
'                               nvl(c1.max_task,c1.release_target_date));'||wwv_flow.LF||
'        l_weeks_to_sh';
wwv_flow_imp.g_varchar2_table(32) := 'ow := nvl(ceil((l_end_date - l_start_date)/7) + 1,12); -- to ensure never getting 0'||wwv_flow.LF||
'        l_first_';
wwv_flow_imp.g_varchar2_table(33) := 'day_of_week := trunc(l_start_date,''D'') +1;'||wwv_flow.LF||
'        l_last_day_of_week  := trunc(l_start_date,''D'') +7';
wwv_flow_imp.g_varchar2_table(34) := ';'||wwv_flow.LF||
'        l_release_end_date   := c1.release_target_date;'||wwv_flow.LF||
'        l_release_start_date := c1.release';
wwv_flow_imp.g_varchar2_table(35) := '_open_date;'||wwv_flow.LF||
'        l_release_start_monday := trunc(c1.release_open_date,''D'')+1;'||wwv_flow.LF||
''||wwv_flow.LF||
'        x2 := ''<h3';
wwv_flow_imp.g_varchar2_table(36) := '>''||apex_escape.html(c1.release)||'' Release Timeline</h3>''||e;'||wwv_flow.LF||
'        x2 := x2||case when c1.releas';
wwv_flow_imp.g_varchar2_table(37) := 'e_open_date < l_sysdate or'||wwv_flow.LF||
'                            c1.release_open_yn = ''Y'''||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(38) := '   then ''Release '' ||'||wwv_flow.LF||
'                          case when c1.release_open_yn = ''Y'' '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(39) := '               then ''opened '''||wwv_flow.LF||
'                               else ''was targeted to open '' '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(40) := '                      end ||'||wwv_flow.LF||
'                          c1.release_open'||wwv_flow.LF||
'                     when c1.';
wwv_flow_imp.g_varchar2_table(41) := 'release_open_date = l_sysdate '||wwv_flow.LF||
'                     then ''Release opens today'''||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(42) := 'else ''Release opens on ''|| c1.release_open'||wwv_flow.LF||
'                     end ||'||wwv_flow.LF||
'                '' and ''||'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(43) := '             case when c1.release_target_date < l_sysdate or'||wwv_flow.LF||
'                          c1.release_co';
wwv_flow_imp.g_varchar2_table(44) := 'mpleted_yn = ''Y'''||wwv_flow.LF||
'                     then case when c1.release_completed_yn = ''Y'' '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(45) := '               then ''completed '''||wwv_flow.LF||
'                               else ''was targeted to complete '' '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(46) := '                             end ||'||wwv_flow.LF||
'                          c1.release_target'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(47) := ' when c1.release_target_date = l_sysdate '||wwv_flow.LF||
'                     then ''completes today'''||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(48) := '       else ''completes on ''|| c1.release_target'||wwv_flow.LF||
'                     end ||''.<br>''||e;'||wwv_flow.LF||
''||wwv_flow.LF||
'    end loop';
wwv_flow_imp.g_varchar2_table(49) := ';'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    if l_weeks_to_show is not null and l_weeks_to_show > 0 then'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- Release week'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(50) := '  --'||wwv_flow.LF||
'    for w in 1..l_weeks_to_show loop'||wwv_flow.LF||
''||wwv_flow.LF||
'        if l_first_day_of_week > l_end_date then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(51) := '   exit;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- before release start'||wwv_flow.LF||
'        if l_last_day_of_week < l_release_';
wwv_flow_imp.g_varchar2_table(52) := 'start_date then'||wwv_flow.LF||
'            week := (l_release_start_monday - l_first_day_of_week)/7;'||wwv_flow.LF||
'            h ';
wwv_flow_imp.g_varchar2_table(53) := ':= ''<h3><i>Week -''||week||'': ''||to_char(l_first_day_of_week,''FMDay Month DD'')||'' to ''||'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(54) := '     to_char(l_last_day_of_week,''FMDay Month DD, YYYY'')||''</i></h3>''||e;'||wwv_flow.LF||
'        -- after release en';
wwv_flow_imp.g_varchar2_table(55) := 'd'||wwv_flow.LF||
'        elsif l_first_day_of_week > l_release_end_date then'||wwv_flow.LF||
'            week := ceil((l_first_day_';
wwv_flow_imp.g_varchar2_table(56) := 'of_week - l_release_end_date)/7);'||wwv_flow.LF||
'            h := ''<h3><i>Week +''||week||'': ''||to_char(l_first_day_';
wwv_flow_imp.g_varchar2_table(57) := 'of_week,''FMDay Month DD'')||'' to ''||'||wwv_flow.LF||
'                 to_char(l_last_day_of_week,''FMDay Month DD, YYY';
wwv_flow_imp.g_varchar2_table(58) := 'Y'')||''</i></h3>''||e;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            week := ((l_first_day_of_week - l_release_start_monday';
wwv_flow_imp.g_varchar2_table(59) := ')/7)+1;'||wwv_flow.LF||
'            h := case when week = 1 and w != 1 and p_show_past_yn = ''Y'''||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(60) := '  then ''<div style="background-color: DarkGray; text-align: left; width: 50%; height: 2px;"></div>'' ';
wwv_flow_imp.g_varchar2_table(61) := 'end ||'||wwv_flow.LF||
'                 ''<h3>Week ''||week||'': ''||to_char(l_first_day_of_week,''FMDay Month DD'')||'' to';
wwv_flow_imp.g_varchar2_table(62) := ' ''||'||wwv_flow.LF||
'                 to_char(l_last_day_of_week,''FMDay Month DD, YYYY'')||''</h3>''||e;'||wwv_flow.LF||
'        end if';
wwv_flow_imp.g_varchar2_table(63) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        -- PROJECT MILESTONES'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        l_the_metric := ''Project Milestones'';';
wwv_flow_imp.g_varchar2_table(64) := ''||wwv_flow.LF||
'        l_row_count := 0;'||wwv_flow.LF||
'        for c2 in ('||wwv_flow.LF||
'            select p.id, '||wwv_flow.LF||
'                   decode(g';
wwv_flow_imp.g_varchar2_table(65) := 'reatest(length(p.project),l_proj_max_length),l_proj_max_length,p.PROJECT,substr(p.project,1,l_proj_m';
wwv_flow_imp.g_varchar2_table(66) := 'ax_length)||''...'') as project, '||wwv_flow.LF||
'                   tt.task_type label,'||wwv_flow.LF||
'                   case when ';
wwv_flow_imp.g_varchar2_table(67) := 't.start_date is not null then to_char(t.start_date,l_dt_fmt_short) ||'' - '' end ||'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(68) := '      to_char(t.target_complete,l_dt_fmt_short) as the_date, '||wwv_flow.LF||
'                   trunc(t.target_comp';
wwv_flow_imp.g_varchar2_table(69) := 'lete) target_complete,'||wwv_flow.LF||
'                   s.indicates_complete_yn,'||wwv_flow.LF||
'                   s.status,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(70) := '               tm.first_name||'' ''||tm.last_name as owner'||wwv_flow.LF||
'            from  sp_tasks t,'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(71) := '     sp_task_types tt,'||wwv_flow.LF||
'                  sp_task_statuses s,'||wwv_flow.LF||
'                  sp_projects p,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(72) := '            sp_team_members tm'||wwv_flow.LF||
'            where t.project_id = p.id and'||wwv_flow.LF||
'                  nvl(t.tas';
wwv_flow_imp.g_varchar2_table(73) := 'k_sub_type_id,t.task_type_id) = tt.id and'||wwv_flow.LF||
'                  tt.static_id like ''MILESTONE%'' and'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(74) := '             t.owner_id = tm.id and '||wwv_flow.LF||
'                  t.status_id = s.id and'||wwv_flow.LF||
'                  p.ar';
wwv_flow_imp.g_varchar2_table(75) := 'chived_yn = ''N'' and'||wwv_flow.LF||
'                  p.DUPLICATE_OF_PROJECT_ID is null and '||wwv_flow.LF||
'                  p.rel';
wwv_flow_imp.g_varchar2_table(76) := 'ease_id = p_release_id and '||wwv_flow.LF||
'                  (t.start_date is not null or t.target_complete is not ';
wwv_flow_imp.g_varchar2_table(77) := 'null) and'||wwv_flow.LF||
'                  (t.start_date between l_first_day_of_week and l_last_day_of_week or'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(78) := '               t.target_complete between l_first_day_of_week and l_last_day_of_week) and'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(79) := '       ((s.indicates_complete_yn = ''N'' and p_exclude_complete_yn = ''Y'') or p_exclude_complete_yn = ''';
wwv_flow_imp.g_varchar2_table(80) := 'N'')'||wwv_flow.LF||
'            order by t.target_complete, t.start_date, tt.display_seq'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(81) := 'l_row_count := l_row_count + 1;'||wwv_flow.LF||
'            if l_row_count = 1 then'||wwv_flow.LF||
'               x := x||''''||l_the';
wwv_flow_imp.g_varchar2_table(82) := '_metric||''<br>''||e;'||wwv_flow.LF||
'               x := x||''<ul>''||e;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            x := x||''<li>''';
wwv_flow_imp.g_varchar2_table(83) := '||apex_escape.html(c2.project)||'' - ''||apex_escape.html(c2.label)||'' - ''||apex_escape.html(c2.owner)';
wwv_flow_imp.g_varchar2_table(84) := '||'' - '';'||wwv_flow.LF||
'            if c2.target_complete is not null and c2.target_complete < trunc(sysdate) and c';
wwv_flow_imp.g_varchar2_table(85) := '2.indicates_complete_yn = ''N'' then '||wwv_flow.LF||
'               x := x||'' <strong>''||c2.the_date || '' Past Due</s';
wwv_flow_imp.g_varchar2_table(86) := 'trong>'';'||wwv_flow.LF||
'            elsif c2.indicates_complete_yn = ''Y'' then '||wwv_flow.LF||
'               x := x||''<strong>Comp';
wwv_flow_imp.g_varchar2_table(87) := 'lete</strong>'';'||wwv_flow.LF||
'            else '||wwv_flow.LF||
'               x := x||''<strong>''||c2.the_date ||'' ''||apex_escape.';
wwv_flow_imp.g_varchar2_table(88) := 'html(c2.status)||''</strong>'';'||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'            x := x||''</li>''||e;'||wwv_flow.LF||
'        end loop;';
wwv_flow_imp.g_varchar2_table(89) := ' -- c2'||wwv_flow.LF||
'        if l_row_count > 0 then '||wwv_flow.LF||
'            x := x||''</ul>''||e;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        --'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(90) := '        -- REVIEWS'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        l_the_metric := ''Reviews'';'||wwv_flow.LF||
'        l_row_count := 0;'||wwv_flow.LF||
'        f';
wwv_flow_imp.g_varchar2_table(91) := 'or c2 in ('||wwv_flow.LF||
'            select p.id, '||wwv_flow.LF||
'                   decode(greatest(length(p.project),l_proj_max';
wwv_flow_imp.g_varchar2_table(92) := '_length),l_proj_max_length,p.PROJECT,substr(p.project,1,l_proj_max_length)||''...'') as project, '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(93) := '               tt.task_type label,'||wwv_flow.LF||
'                   case when t.start_date is not null then to_cha';
wwv_flow_imp.g_varchar2_table(94) := 'r(t.start_date,l_dt_fmt_short) ||'' - '' end ||'||wwv_flow.LF||
'                        to_char(t.target_complete,l_dt';
wwv_flow_imp.g_varchar2_table(95) := '_fmt_short) as the_date, '||wwv_flow.LF||
'                   trunc(t.target_complete) target_complete,'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(96) := '      s.indicates_complete_yn,'||wwv_flow.LF||
'                   s.status,'||wwv_flow.LF||
'                   tm.first_name||'' ''||t';
wwv_flow_imp.g_varchar2_table(97) := 'm.last_name as owner'||wwv_flow.LF||
'            from  sp_tasks t,'||wwv_flow.LF||
'                  sp_task_types tt,'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(98) := '     sp_task_statuses s,'||wwv_flow.LF||
'                  sp_projects p,'||wwv_flow.LF||
'                  sp_team_members tm'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(99) := '       where t.project_id = p.id and'||wwv_flow.LF||
'                  nvl(t.task_sub_type_id,t.task_type_id) = tt.i';
wwv_flow_imp.g_varchar2_table(100) := 'd and'||wwv_flow.LF||
'                  tt.static_id like ''REVIEW%'' and'||wwv_flow.LF||
'                  t.owner_id = tm.id and '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(101) := '                t.status_id = s.id and'||wwv_flow.LF||
'                  p.archived_yn = ''N'' and'||wwv_flow.LF||
'                  p';
wwv_flow_imp.g_varchar2_table(102) := '.DUPLICATE_OF_PROJECT_ID is null and '||wwv_flow.LF||
'                  p.release_id = p_release_id and '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(103) := '       (t.start_date is not null or t.target_complete is not null) and'||wwv_flow.LF||
'                  (t.start_da';
wwv_flow_imp.g_varchar2_table(104) := 'te between l_first_day_of_week and l_last_day_of_week or'||wwv_flow.LF||
'                   t.target_complete betwee';
wwv_flow_imp.g_varchar2_table(105) := 'n l_first_day_of_week and l_last_day_of_week) and'||wwv_flow.LF||
'                  ((s.indicates_complete_yn = ''N'' ';
wwv_flow_imp.g_varchar2_table(106) := 'and p_exclude_complete_yn = ''Y'') or p_exclude_complete_yn = ''N'')'||wwv_flow.LF||
'            order by t.target_compl';
wwv_flow_imp.g_varchar2_table(107) := 'ete, t.start_date, tt.display_seq'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            l_row_count := l_row_count + 1;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(108) := '     if l_row_count = 1 then'||wwv_flow.LF||
'               x := x||''''||l_the_metric||''<br>''||e;'||wwv_flow.LF||
'               x :=';
wwv_flow_imp.g_varchar2_table(109) := ' x||''<ul>''||e;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            x := x||''<li>''||apex_escape.html(c2.project)||'' - ''||';
wwv_flow_imp.g_varchar2_table(110) := 'apex_escape.html(c2.label)||'' - ''||apex_escape.html(c2.owner)||'' - '';'||wwv_flow.LF||
'            if c2.target_compl';
wwv_flow_imp.g_varchar2_table(111) := 'ete is not null and c2.target_complete < trunc(sysdate) and c2.indicates_complete_yn = ''N'' then '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(112) := '            x := x||'' <strong>''||c2.the_date || '' Past Due</strong>'';'||wwv_flow.LF||
'            elsif c2.indicates';
wwv_flow_imp.g_varchar2_table(113) := '_complete_yn = ''Y'' then '||wwv_flow.LF||
'               x := x||''<strong>Complete</strong>'';'||wwv_flow.LF||
'            else '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(114) := '          x := x||''<strong>''||c2.the_date ||'' ''||apex_escape.html(c2.status)||''</strong>'';'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(115) := '   end if; '||wwv_flow.LF||
'            x := x||''</li>''||e;'||wwv_flow.LF||
'        end loop; -- c2'||wwv_flow.LF||
'        if l_row_count > 0 then ';
wwv_flow_imp.g_varchar2_table(116) := ''||wwv_flow.LF||
'            x := x||''</ul>''||e;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        -- OTHER TASKS'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(117) := '   l_the_metric := ''Other Tasks'';'||wwv_flow.LF||
'        l_row_count := 0;'||wwv_flow.LF||
'        for c2 in ('||wwv_flow.LF||
'            select p';
wwv_flow_imp.g_varchar2_table(118) := '.id, '||wwv_flow.LF||
'                   decode(greatest(length(p.project),l_proj_max_length),l_proj_max_length,p.PR';
wwv_flow_imp.g_varchar2_table(119) := 'OJECT,substr(p.project,1,l_proj_max_length)||''...'') as project, '||wwv_flow.LF||
'                   tt.task_type || ';
wwv_flow_imp.g_varchar2_table(120) := 'case when t.task is not null then '' - ''||t.task end label,'||wwv_flow.LF||
'                   case when t.start_date';
wwv_flow_imp.g_varchar2_table(121) := ' is not null then to_char(t.start_date,l_dt_fmt_short) ||'' - '' end ||'||wwv_flow.LF||
'                        to_cha';
wwv_flow_imp.g_varchar2_table(122) := 'r(t.target_complete,l_dt_fmt_short) as the_date, '||wwv_flow.LF||
'                   trunc(t.target_complete) target';
wwv_flow_imp.g_varchar2_table(123) := '_complete,'||wwv_flow.LF||
'                   s.indicates_complete_yn,'||wwv_flow.LF||
'                   s.status,'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(124) := '   tm.first_name||'' ''||tm.last_name as owner'||wwv_flow.LF||
'            from  sp_tasks t,'||wwv_flow.LF||
'                  sp_task';
wwv_flow_imp.g_varchar2_table(125) := '_types tt,'||wwv_flow.LF||
'                  sp_task_statuses s,'||wwv_flow.LF||
'                  sp_projects p,'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(126) := 'sp_team_members tm'||wwv_flow.LF||
'            where t.project_id = p.id and'||wwv_flow.LF||
'                  nvl(t.task_sub_type_i';
wwv_flow_imp.g_varchar2_table(127) := 'd,t.task_type_id) = tt.id and'||wwv_flow.LF||
'                  tt.static_id not like ''REVIEW%'' and'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(128) := '  tt.static_id not like ''MILESTONE%'' and'||wwv_flow.LF||
'                  t.owner_id = tm.id and '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(129) := ' t.status_id = s.id and'||wwv_flow.LF||
'                  p.archived_yn = ''N'' and'||wwv_flow.LF||
'                  p.DUPLICATE_OF_P';
wwv_flow_imp.g_varchar2_table(130) := 'ROJECT_ID is null and '||wwv_flow.LF||
'                  p.release_id = p_release_id and '||wwv_flow.LF||
'                  (t.start';
wwv_flow_imp.g_varchar2_table(131) := '_date is not null or t.target_complete is not null) and'||wwv_flow.LF||
'                  (t.start_date between l_fi';
wwv_flow_imp.g_varchar2_table(132) := 'rst_day_of_week and l_last_day_of_week or'||wwv_flow.LF||
'                   t.target_complete between l_first_day_o';
wwv_flow_imp.g_varchar2_table(133) := 'f_week and l_last_day_of_week) and'||wwv_flow.LF||
'                  ((s.indicates_complete_yn = ''N'' and p_exclude_c';
wwv_flow_imp.g_varchar2_table(134) := 'omplete_yn = ''Y'') or p_exclude_complete_yn = ''N'')'||wwv_flow.LF||
'            order by t.target_complete, t.start_da';
wwv_flow_imp.g_varchar2_table(135) := 'te, tt.display_seq'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            l_row_count := l_row_count + 1;'||wwv_flow.LF||
'            if l_row_c';
wwv_flow_imp.g_varchar2_table(136) := 'ount = 1 then'||wwv_flow.LF||
'               x := x||''''||l_the_metric||''<br>''||e;'||wwv_flow.LF||
'               x := x||''<ul>''||e;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(137) := '            end if;'||wwv_flow.LF||
'            x := x||''<li>''||apex_escape.html(c2.project)||'' - ''||apex_escape.htm';
wwv_flow_imp.g_varchar2_table(138) := 'l(c2.label)||'' - ''||apex_escape.html(c2.owner)||'' - '';'||wwv_flow.LF||
'            if c2.target_complete is not null';
wwv_flow_imp.g_varchar2_table(139) := ' and c2.target_complete < trunc(sysdate) and c2.indicates_complete_yn = ''N'' then '||wwv_flow.LF||
'               x :';
wwv_flow_imp.g_varchar2_table(140) := '= x||'' <strong>''||c2.the_date || '' Past Due</strong>'';'||wwv_flow.LF||
'            elsif c2.indicates_complete_yn = ';
wwv_flow_imp.g_varchar2_table(141) := '''Y'' then '||wwv_flow.LF||
'               x := x||''<strong>Complete</strong>'';'||wwv_flow.LF||
'            else '||wwv_flow.LF||
'               x := ';
wwv_flow_imp.g_varchar2_table(142) := 'x||''<strong>''||c2.the_date ||'' ''||apex_escape.html(c2.status)||''</strong>'';'||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(143) := '         x := x||''</li>''||e;'||wwv_flow.LF||
'        end loop; -- c2'||wwv_flow.LF||
'        if l_row_count > 0 then '||wwv_flow.LF||
'            x ';
wwv_flow_imp.g_varchar2_table(144) := ':= x||''</ul>''||e;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        -- activity'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        l_the_metric :=';
wwv_flow_imp.g_varchar2_table(145) := ' ''Activity'';'||wwv_flow.LF||
'        l_row_count := 0;'||wwv_flow.LF||
''||wwv_flow.LF||
'        for c2 in ('||wwv_flow.LF||
'            select p.id, '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(146) := '     decode(greatest(length(p.project),l_proj_max_length),'||wwv_flow.LF||
'                       l_proj_max_length,';
wwv_flow_imp.g_varchar2_table(147) := 'p.PROJECT,'||wwv_flow.LF||
'                       substr(p.project,1,l_proj_max_length)||''...'') as project, '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(148) := '            a.START_DATE,'||wwv_flow.LF||
'                   a.END_DATE,'||wwv_flow.LF||
'                   tm.first_name||'' ''||tm.l';
wwv_flow_imp.g_varchar2_table(149) := 'ast_name as owner,'||wwv_flow.LF||
'                   decode(greatest(length(a.COMMENTS),l_proj_max_length),'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(150) := '                l_proj_max_length,a.COMMENTS,'||wwv_flow.LF||
'                       substr(a.COMMENTS,1,l_proj_max_';
wwv_flow_imp.g_varchar2_table(151) := 'length)||''...'') as COMMENTS, '||wwv_flow.LF||
'                   a.url,'||wwv_flow.LF||
'                   a.ACTIVITY_TYPE_ID,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(152) := '              at.ACTIVITY_TYPE'||wwv_flow.LF||
'            from  sp_projects p,'||wwv_flow.LF||
'                  SP_ACTIVITIES a,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(153) := '                 sp_team_members tm,'||wwv_flow.LF||
'                  SP_ACTIVITY_TYPES at'||wwv_flow.LF||
'            where a.TEAM';
wwv_flow_imp.g_varchar2_table(154) := '_MEMBER_ID = tm.id and '||wwv_flow.LF||
'                  a.ACTIVITY_TYPE_ID = at.id and'||wwv_flow.LF||
'                  a.project';
wwv_flow_imp.g_varchar2_table(155) := '_id = p.id and '||wwv_flow.LF||
'                  p.archived_yn = ''N'' and'||wwv_flow.LF||
'                  p.DUPLICATE_OF_PROJECT_I';
wwv_flow_imp.g_varchar2_table(156) := 'D is null and '||wwv_flow.LF||
'                  p.release_id = p_release_id and '||wwv_flow.LF||
'                  a.comments is no';
wwv_flow_imp.g_varchar2_table(157) := 't null and'||wwv_flow.LF||
'                  a.start_date is not null and '||wwv_flow.LF||
'                  a.end_date is not null ';
wwv_flow_imp.g_varchar2_table(158) := 'and'||wwv_flow.LF||
'                  ('||wwv_flow.LF||
'                    a.start_date between l_first_day_of_week and l_last_day_';
wwv_flow_imp.g_varchar2_table(159) := 'of_week or '||wwv_flow.LF||
'                    a.end_date   between l_first_day_of_week and l_last_day_of_week or '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(160) := '                    (a.start_date < l_first_day_of_week and a.end_date > l_last_day_of_week)'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(161) := '           )'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            l_row_count := l_row_count + 1;'||wwv_flow.LF||
'                '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(162) := ' if l_row_count = 1 then'||wwv_flow.LF||
'               x := x||''''||l_the_metric||''<br>''||e;'||wwv_flow.LF||
'               x := x||';
wwv_flow_imp.g_varchar2_table(163) := '''<ul>''||e;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            x := x||''<li>''||apex_escape.html(c2.project)||'' - <b>''||a';
wwv_flow_imp.g_varchar2_table(164) := 'pex_escape.html(c2.owner)||''</b> ('';'||wwv_flow.LF||
'            if to_char(c2.start_date,l_dt_fmt_short) = to_char(';
wwv_flow_imp.g_varchar2_table(165) := 'c2.end_date,l_dt_fmt_short) then '||wwv_flow.LF||
'                x := x||to_char(c2.end_date,l_dt_fmt_short);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(166) := '       else '||wwv_flow.LF||
'                x := x||to_char(c2.start_date,l_dt_fmt_short)||'' - ''||to_char(c2.end_da';
wwv_flow_imp.g_varchar2_table(167) := 'te,l_dt_fmt_short);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            x := x||'')</li>''||e;'||wwv_flow.LF||
'        end loop; -- c2'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(168) := '     if l_row_count > 0 then '||wwv_flow.LF||
'            x := x||''</ul>''||e;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        --';
wwv_flow_imp.g_varchar2_table(169) := ' release dates'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        l_the_metric := ''Release Milestones'';'||wwv_flow.LF||
'        l_row_count := 0;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(170) := '      for c2 in ('||wwv_flow.LF||
'            select m.id,'||wwv_flow.LF||
'                   (select milestone_type from sp_release';
wwv_flow_imp.g_varchar2_table(171) := '_milestone_types'||wwv_flow.LF||
'                     where id = m.milestone_type_id) milestone_type,'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(172) := '     m.milestone_name, '||wwv_flow.LF||
'                   m.milestone_date, '||wwv_flow.LF||
'                   decode (MILESTONE_C';
wwv_flow_imp.g_varchar2_table(173) := 'OMPLETED_YN,''Y'',''Complete'',''N'',''Open'') as milestone_status'||wwv_flow.LF||
'            from   SP_RELEASE_MILESTONES ';
wwv_flow_imp.g_varchar2_table(174) := 'M  '||wwv_flow.LF||
'            where  m.RELEASE_ID = p_release_id and '||wwv_flow.LF||
'                   m.milestone_date between ';
wwv_flow_imp.g_varchar2_table(175) := 'l_first_day_of_week and l_last_day_of_week and'||wwv_flow.LF||
'                   ((milestone_completed_yn = ''N'' and';
wwv_flow_imp.g_varchar2_table(176) := ' p_exclude_complete_yn = ''Y'') or p_exclude_complete_yn = ''N'')'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            l_row_count';
wwv_flow_imp.g_varchar2_table(177) := ' := l_row_count + 1;'||wwv_flow.LF||
'                '||wwv_flow.LF||
'            if l_row_count = 1 then'||wwv_flow.LF||
'               x := x||''''|';
wwv_flow_imp.g_varchar2_table(178) := '|l_the_metric||''<br>''||e;'||wwv_flow.LF||
'               x := x||''<ul>''||e;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            x := x||';
wwv_flow_imp.g_varchar2_table(179) := '''<li>''||case when c2.milestone_type is not null then c2.milestone_type||'': '' end ||'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(180) := '            apex_escape.html(c2.milestone_name)||'' - ''||'||wwv_flow.LF||
'                            to_char(c2.mile';
wwv_flow_imp.g_varchar2_table(181) := 'stone_date,''FM Day Month DD'')||'||wwv_flow.LF||
'                            '' (<b>''||apex_escape.html(c2.milestone_s';
wwv_flow_imp.g_varchar2_table(182) := 'tatus)||''</b>)</li>''||e;'||wwv_flow.LF||
'                '||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        if l_row_count > 0 then '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(183) := '     x := x||''</ul>''||e;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        -- show week before/after release open ';
wwv_flow_imp.g_varchar2_table(184) := 'only if activities, show all weeks during release'||wwv_flow.LF||
'        if dbms_lob.getlength(x) > 0 then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(185) := '   if post_hr = ''n'' and l_release_end_date < l_first_day_of_week then'||wwv_flow.LF||
'              h := ''<div style';
wwv_flow_imp.g_varchar2_table(186) := '="background-color: DarkGray; text-align: left; width: 50%; height: 2px;"></div>''||h;'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(187) := 'post_hr := ''y'';'||wwv_flow.LF||
'           end if;'||wwv_flow.LF||
'           dbms_lob.append(x2, h);'||wwv_flow.LF||
'           dbms_lob.append(x2,';
wwv_flow_imp.g_varchar2_table(188) := ' x);'||wwv_flow.LF||
'        elsif (l_release_start_date <= l_first_day_of_week and l_release_end_date >= l_last_day';
wwv_flow_imp.g_varchar2_table(189) := '_of_week) or'||wwv_flow.LF||
'              (l_release_start_date > l_first_day_of_week and l_release_start_date <= l';
wwv_flow_imp.g_varchar2_table(190) := '_last_day_of_week) or'||wwv_flow.LF||
'              (l_release_end_date > l_first_day_of_week and l_release_end_date';
wwv_flow_imp.g_varchar2_table(191) := ' <= l_last_day_of_week) then'||wwv_flow.LF||
'           dbms_lob.append(x2, h);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        x := '''';'||wwv_flow.LF||
''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(192) := '       l_first_day_of_week := l_first_day_of_week +  7;'||wwv_flow.LF||
'        l_last_day_of_week  := l_last_day_of';
wwv_flow_imp.g_varchar2_table(193) := '_week  +  7;'||wwv_flow.LF||
''||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return x2;'||wwv_flow.LF||
'end show_week;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function release_exceptions';
wwv_flow_imp.g_varchar2_table(194) := ' ('||wwv_flow.LF||
'    p_release_id               in number,'||wwv_flow.LF||
'    p_links                    in varchar2 default ''NON';
wwv_flow_imp.g_varchar2_table(195) := 'E'','||wwv_flow.LF||
'    p_apex_session             in varchar2 default null )'||wwv_flow.LF||
'    return clob'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    x              ';
wwv_flow_imp.g_varchar2_table(196) := '        clob;'||wwv_flow.LF||
'    l_exceptions_yn        varchar2(1) := ''N'';'||wwv_flow.LF||
'    l_proj_content         clob;'||wwv_flow.LF||
'    l_';
wwv_flow_imp.g_varchar2_table(197) := 'reviews_yn           varchar2(1);'||wwv_flow.LF||
'    l_approvals_yn         varchar2(1);'||wwv_flow.LF||
'    l_date_fm             ';
wwv_flow_imp.g_varchar2_table(198) := ' varchar2(255) := ''FMDay DD-MON'';'||wwv_flow.LF||
'    l_date_fm2             varchar2(255) := ''FMDay DD-MON-YYYY'';'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(199) := '   l_row_count            int := 0;'||wwv_flow.LF||
'    l_link_type            varchar2(30);'||wwv_flow.LF||
'    l_project_label    ';
wwv_flow_imp.g_varchar2_table(200) := '    varchar2(255);'||wwv_flow.LF||
'    l_sysdate              date := trunc(sysdate);'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- support for lin';
wwv_flow_imp.g_varchar2_table(201) := 'ks'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    l_release_url          varchar2(4000);'||wwv_flow.LF||
'    l_project              varchar2(4000);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(202) := 'l_url                  varchar2(4000);'||wwv_flow.LF||
'    l_app_id               varchar2(4000);'||wwv_flow.LF||
'    l_app_prefix_u';
wwv_flow_imp.g_varchar2_table(203) := 'rl       varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- get settings'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    l_project_label     := sp_util.';
wwv_flow_imp.g_varchar2_table(204) := 'get_nomenclature(''PROJECT'');'||wwv_flow.LF||
'    l_app_id            := sp_util.get_setting(''APP_ID'');'||wwv_flow.LF||
'    l_app_pre';
wwv_flow_imp.g_varchar2_table(205) := 'fix_url    := sp_util.get_setting(''APP_PREFIX_URL'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    if apex_util.get_build_option_status ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(206) := '        p_application_id    => l_app_id,'||wwv_flow.LF||
'           p_build_option_name => ''Reviews'') = ''INCLUDE'''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(207) := '  then'||wwv_flow.LF||
'        l_reviews_yn := ''Y'';'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        l_reviews_yn := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if apex_u';
wwv_flow_imp.g_varchar2_table(208) := 'til.get_build_option_status ('||wwv_flow.LF||
'           p_application_id    => l_app_id,'||wwv_flow.LF||
'           p_build_option_';
wwv_flow_imp.g_varchar2_table(209) := 'name => ''Approvals'') = ''INCLUDE'''||wwv_flow.LF||
'    then'||wwv_flow.LF||
'        l_approvals_yn := ''Y'';'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        l_approval';
wwv_flow_imp.g_varchar2_table(210) := 's_yn := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- determine link type'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- APP: generate links from w';
wwv_flow_imp.g_varchar2_table(211) := 'ithin the current app requires p_apex_session'||wwv_flow.LF||
'    -- EMAIL: generate fully qualified links'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(212) := '  if p_links = ''APP'' and p_apex_session is not null and l_app_id is not null then'||wwv_flow.LF||
'       l_link_type';
wwv_flow_imp.g_varchar2_table(213) := ' := ''APP'';'||wwv_flow.LF||
'    elsif p_links = ''EMAIL'' and l_app_id is not null then'||wwv_flow.LF||
'       l_link_type := ''EMAIL'';'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(214) := '    elsif p_links = ''JOB'' and l_app_id is not null then'||wwv_flow.LF||
'       l_link_type := ''JOB'';'||wwv_flow.LF||
'    elsif p_lin';
wwv_flow_imp.g_varchar2_table(215) := 'ks is null then'||wwv_flow.LF||
'       l_link_type := ''NONE'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- HEADING'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if l_lin';
wwv_flow_imp.g_varchar2_table(216) := 'k_type in (''EMAIL'',''JOB'',''NONE'') then'||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            select release_train ||'' ''|| r';
wwv_flow_imp.g_varchar2_table(217) := 'elease name,'||wwv_flow.LF||
'                   trunc(release_open_date) release_open_date,'||wwv_flow.LF||
'                   to_ch';
wwv_flow_imp.g_varchar2_table(218) := 'ar(release_open_date,''Day Month FMDD, YYYY'') release_open,'||wwv_flow.LF||
'                   nvl(release_open_compl';
wwv_flow_imp.g_varchar2_table(219) := 'eted,''N'') release_open_yn,'||wwv_flow.LF||
'                   trunc(release_target_date) release_target_date, '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(220) := '              to_char(release_target_date,''Day Month FMDD, YYYY'') release_target,'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(221) := ' nvl(release_completed,''N'') release_completed_yn'||wwv_flow.LF||
'              from sp_release_trains '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(222) := 'where id = p_release_id'||wwv_flow.LF||
'        ) loop '||wwv_flow.LF||
'            if l_link_type in (''EMAIL'',''JOB'') then'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(223) := '      l_url := apex_page.get_url('||wwv_flow.LF||
'                          p_application => l_app_id,'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(224) := '             p_page        => 117,'||wwv_flow.LF||
'                          p_session     => null,'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(225) := '          p_items       => ''P117_RELEASE_ID'','||wwv_flow.LF||
'                          p_values      => p_release_i';
wwv_flow_imp.g_varchar2_table(226) := 'd,'||wwv_flow.LF||
'                          p_plain_url   => TRUE );'||wwv_flow.LF||
'               if l_link_type = ''EMAIL'' then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(227) := '                 l_url := l_app_prefix_url || l_url; '||wwv_flow.LF||
'               end if;'||wwv_flow.LF||
'               l_releas';
wwv_flow_imp.g_varchar2_table(228) := 'e_url := ''<a href="''||l_url||''">''||apex_escape.html(c1.name)||''</a>'';'||wwv_flow.LF||
'               x := ''<h3>Excep';
wwv_flow_imp.g_varchar2_table(229) := 'tion Report for Release ''||l_release_url||''</h3>''||chr(10);'||wwv_flow.LF||
'            elsif l_link_type = ''NONE'' t';
wwv_flow_imp.g_varchar2_table(230) := 'hen'||wwv_flow.LF||
'                x := ''<h3>Exception Report for Release ''||apex_escape.html(c1.name)||''</h3>''||ch';
wwv_flow_imp.g_varchar2_table(231) := 'r(10);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            x := x||''<strong>As of</strong>: ''||to_char(sysdate,l_date_fm';
wwv_flow_imp.g_varchar2_table(232) := '2)||''<br><br>'';'||wwv_flow.LF||
''||wwv_flow.LF||
'            if c1.release_open_date < l_sysdate or'||wwv_flow.LF||
'               c1.release_open_y';
wwv_flow_imp.g_varchar2_table(233) := 'n = ''Y'''||wwv_flow.LF||
'            then x := x||''<strong>Release '' ||'||wwv_flow.LF||
'                         case when c1.release';
wwv_flow_imp.g_varchar2_table(234) := '_open_yn = ''Y'' '||wwv_flow.LF||
'                              then ''opened:</strong> '''||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(235) := ' else ''was targeted to open:</strong> '' '||wwv_flow.LF||
'                              end;'||wwv_flow.LF||
'            else x := x|';
wwv_flow_imp.g_varchar2_table(236) := '|''<strong>Release opens:</strong> '';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            x := x|| c1.release_open ||''<br';
wwv_flow_imp.g_varchar2_table(237) := '>''||chr(10);'||wwv_flow.LF||
''||wwv_flow.LF||
'            if c1.release_target_date < l_sysdate or'||wwv_flow.LF||
'               c1.release_complet';
wwv_flow_imp.g_varchar2_table(238) := 'ed_yn = ''Y'''||wwv_flow.LF||
'            then x := x||''<strong>Release '' ||'||wwv_flow.LF||
'                         case when c1.rel';
wwv_flow_imp.g_varchar2_table(239) := 'ease_completed_yn = ''Y'' '||wwv_flow.LF||
'                                   then ''completed:</strong> '''||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(240) := '                       else ''was targeted to complete:</strong> '' '||wwv_flow.LF||
'                                 ';
wwv_flow_imp.g_varchar2_table(241) := '  end;'||wwv_flow.LF||
'            else x := x||''<strong>Release completes:</strong> '';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(242) := '    x := x|| c1.release_target ||''<br><br>''||chr(10);'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'       x := '''';'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(243) := ' end if;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --  RELEASE MISSING OWNER'||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select 1'||wwv_flow.LF||
'          f';
wwv_flow_imp.g_varchar2_table(244) := 'rom sp_release_trains'||wwv_flow.LF||
'         where id = p_release_id'||wwv_flow.LF||
'           and release_owner_id is null'||wwv_flow.LF||
'    )';
wwv_flow_imp.g_varchar2_table(245) := ' loop'||wwv_flow.LF||
'        if l_exceptions_yn = ''N'' then'||wwv_flow.LF||
'            x := x||chr(10)||''<h3>Release Issues</h3><ul';
wwv_flow_imp.g_varchar2_table(246) := '>'';'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        l_exceptions_yn := ''Y'';'||wwv_flow.LF||
'        x := x||chr(10)||''<li>Release has no own';
wwv_flow_imp.g_varchar2_table(247) := 'er</li>'';'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --  OPEN DATE PAST BUT RELEASE NOT OPEN'||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(248) := '        select 1'||wwv_flow.LF||
'          from sp_release_trains'||wwv_flow.LF||
'         where id = p_release_id'||wwv_flow.LF||
'           and tr';
wwv_flow_imp.g_varchar2_table(249) := 'unc(release_open_date) < l_sysdate'||wwv_flow.LF||
'           and nvl(release_open_completed,''N'') = ''N'''||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(250) := '       if l_exceptions_yn = ''N'' then'||wwv_flow.LF||
'            x := x||chr(10)||''<h3>Release Issues</h3><ul>'';'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(251) := '     end if;'||wwv_flow.LF||
'        l_exceptions_yn := ''Y'';'||wwv_flow.LF||
'        x := x||chr(10)||''<li>Release past due to Open<';
wwv_flow_imp.g_varchar2_table(252) := '/li>'';'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --  CLOSED DATE PAST BUT RELEASE NOT CLOSED'||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    for c1 in (';
wwv_flow_imp.g_varchar2_table(253) := ''||wwv_flow.LF||
'        select 1'||wwv_flow.LF||
'          from sp_release_trains'||wwv_flow.LF||
'         where id = p_release_id'||wwv_flow.LF||
'           and t';
wwv_flow_imp.g_varchar2_table(254) := 'runc(release_target_date) < l_sysdate'||wwv_flow.LF||
'           and nvl(release_completed,''N'') = ''N'''||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(255) := '     if l_exceptions_yn = ''N'' then'||wwv_flow.LF||
'            x := x||chr(10)||''<h3>Release Issues</h3><ul>'';'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(256) := '   end if;'||wwv_flow.LF||
'        l_exceptions_yn := ''Y'';'||wwv_flow.LF||
'        x := x||chr(10)||''<li>Release past due to Close</';
wwv_flow_imp.g_varchar2_table(257) := 'li>'';'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --  NO MILESTONES DEFINED'||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select cou';
wwv_flow_imp.g_varchar2_table(258) := 'nt(*) cnt'||wwv_flow.LF||
'          from sp_release_milestones'||wwv_flow.LF||
'         where release_id = p_release_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(259) := '       if c1.cnt = 0 then'||wwv_flow.LF||
'            if l_exceptions_yn = ''N'' then'||wwv_flow.LF||
'                x := x||chr(10)|';
wwv_flow_imp.g_varchar2_table(260) := '|''<h3>Release Issues</h3><ul>'';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            l_exceptions_yn := ''Y'';'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(261) := 'x := x||chr(10)||''<li>No Milestones defined</li>'';'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- OVER';
wwv_flow_imp.g_varchar2_table(262) := 'DUE MILESTONES'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    l_row_count := 0;'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select milestone_name, '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(263) := '       milestone_date'||wwv_flow.LF||
'          from sp_release_milestones'||wwv_flow.LF||
'         where release_id = p_release_id'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(264) := '           and trunc(milestone_date) < l_sysdate'||wwv_flow.LF||
'           and milestone_completed_yn = ''N'''||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(265) := '  order by milestone_date'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        if l_exceptions_yn = ''N'' then'||wwv_flow.LF||
'            x := x||chr(1';
wwv_flow_imp.g_varchar2_table(266) := '0)||''<h3>Release Issues</h3><ul>'';'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        l_exceptions_yn := ''Y'';'||wwv_flow.LF||
'        l_row_cou';
wwv_flow_imp.g_varchar2_table(267) := 'nt := l_row_count + 1;'||wwv_flow.LF||
'        if l_row_count = 1 then'||wwv_flow.LF||
'            x := x||chr(10)||''<li><strong>Ove';
wwv_flow_imp.g_varchar2_table(268) := 'rdue Milestones</strong></li><ul>'';'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        x := x||''<li>''||apex_escape.html(c1.mil';
wwv_flow_imp.g_varchar2_table(269) := 'estone_name)||'' was due ''||to_char(c1.milestone_date,l_date_fm)||''</li>'';'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- CLOS';
wwv_flow_imp.g_varchar2_table(270) := 'ING MILESTONES'||wwv_flow.LF||
'    if l_row_count > 0 then '||wwv_flow.LF||
'        x := x||''</ul>'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- CLOSING REL';
wwv_flow_imp.g_varchar2_table(271) := 'EASE ISSUES'||wwv_flow.LF||
'    if l_exceptions_yn = ''Y'' then'||wwv_flow.LF||
'        x := x||''</ul>'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- PR';
wwv_flow_imp.g_varchar2_table(272) := 'OJECT ISSUES'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select p.id'||wwv_flow.LF||
'          from sp_projects p,'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(273) := ' sp_project_priorities r'||wwv_flow.LF||
'         where p.release_id = p_release_id'||wwv_flow.LF||
'           and p.duplicate_of_pr';
wwv_flow_imp.g_varchar2_table(274) := 'oject_id is null'||wwv_flow.LF||
'           and p.archived_yn = ''N'''||wwv_flow.LF||
'           and p.pct_complete > 20'||wwv_flow.LF||
'           an';
wwv_flow_imp.g_varchar2_table(275) := 'd p.pct_complete < 100'||wwv_flow.LF||
'           and p.priority_id = r.id'||wwv_flow.LF||
'         order by r.priority, p.project'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(276) := '   ) loop'||wwv_flow.LF||
'        l_proj_content := null;'||wwv_flow.LF||
'        l_proj_content := sp_util.exceptions_for_project (';
wwv_flow_imp.g_varchar2_table(277) := ''||wwv_flow.LF||
'                              p_project_id      => c1.id,'||wwv_flow.LF||
'                              p_one_proje';
wwv_flow_imp.g_varchar2_table(278) := 'ct_yn  => ''N'','||wwv_flow.LF||
'                              p_team_member_id  => null,'||wwv_flow.LF||
'                            ';
wwv_flow_imp.g_varchar2_table(279) := '  p_link_type       => l_link_type,'||wwv_flow.LF||
'                              p_app_prefix_url  => l_app_prefix_';
wwv_flow_imp.g_varchar2_table(280) := 'url,'||wwv_flow.LF||
'                              p_app_id          => l_app_id,'||wwv_flow.LF||
'                              p_ap';
wwv_flow_imp.g_varchar2_table(281) := 'ex_session    => p_apex_session,'||wwv_flow.LF||
'                              p_reviews_yn      => l_reviews_yn,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(282) := '                            p_approvals_yn    => l_approvals_yn );'||wwv_flow.LF||
''||wwv_flow.LF||
'        if dbms_lob.getlength(l_';
wwv_flow_imp.g_varchar2_table(283) := 'proj_content) != 0 then'||wwv_flow.LF||
'            l_exceptions_yn := ''Y'';'||wwv_flow.LF||
'            x := x||l_proj_content;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(284) := '    end if;   '||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- END'||wwv_flow.LF||
'    if l_exceptions_yn = ''N'' then'||wwv_flow.LF||
'       x := x||chr(10)||''';
wwv_flow_imp.g_varchar2_table(285) := 'No exceptions found'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return x;'||wwv_flow.LF||
'end release_exceptions;'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_release_timeline;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(41457371400811507866)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_release_timeline package body'
,p_sequence=>750
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
