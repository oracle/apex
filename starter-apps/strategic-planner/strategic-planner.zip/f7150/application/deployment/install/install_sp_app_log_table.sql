prompt --application/deployment/install/install_sp_app_log_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_app_log table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_app_log ('||wwv_flow.LF||
'    id                     number default on null to_number(sys_guid(), ''X';
wwv_flow_imp.g_varchar2_table(2) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                           constraint sp_app_log_pk primary key,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(3) := '    --'||wwv_flow.LF||
'    activity               varchar2(255 char)  not null,'||wwv_flow.LF||
'    details                varchar2(';
wwv_flow_imp.g_varchar2_table(4) := '4000 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                date not null,'||wwv_flow.LF||
'    created_trunc          date not nul';
wwv_flow_imp.g_varchar2_table(5) := 'l,'||wwv_flow.LF||
'    created_by             varchar2(255 char) not null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create index sp_app_log_i1'||wwv_flow.LF||
'   on sp';
wwv_flow_imp.g_varchar2_table(6) := '_app_log (created_trunc);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_app_log_bi'||wwv_flow.LF||
'   before insert on sp_app_log'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(7) := ' for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   :new.created       := sysdate;'||wwv_flow.LF||
'   :new.created_trunc := trunc(sysdate);'||wwv_flow.LF||
'   :n';
wwv_flow_imp.g_varchar2_table(8) := 'ew.created_by    := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'end sp_app_log_bi;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(42147960809891575216)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_app_log table'
,p_sequence=>60
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
