prompt --application/deployment/install/install_sp_groups_trigger
begin
--   Manifest
--     INSTALL: INSTALL-SP_GROUPS trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>2214566044257001599
,p_default_application_id=>9111
,p_default_id_offset=>11016538767572718
,p_default_owner=>'DBTOOLS_PROD'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(45805087232376888224)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'SP_GROUPS trigger'
,p_sequence=>430
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace trigger SP_GROUPS_biu',
'    before insert or update',
'    on SP_GROUPS',
'    for each row',
'begin',
'    if inserting then',
'        :new.created := sysdate;',
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'    end if;',
'    :new.updated := sysdate;',
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'    --',
'    -- set organization_name_upper',
'    --',
'    :new.group_name_upper := upper(:new.group_name);',
'    :new.group_tag := upper(replace(trim(:new.group_tag),'' '',''-''));',
'end SP_GROUPS_biu;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
