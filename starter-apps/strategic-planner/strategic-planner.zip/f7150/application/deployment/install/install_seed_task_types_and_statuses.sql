prompt --application/deployment/install/install_seed_task_types_and_statuses
begin
--   Manifest
--     INSTALL: INSTALL-Seed Task Types and Statuses
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ) values (1, ''REVIEW'', ';
wwv_flow_imp.g_varchar2_table(2) := '''Review'', ''Reviews'', 10);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_';
wwv_flow_imp.g_varchar2_table(3) := 'SEQ, PARENT_TYPE_ID) values (2, ''REVIEW-FUNCSPEC'', ''Functional Spec Review'', ''A review of the functi';
wwv_flow_imp.g_varchar2_table(4) := 'onal specification document'', 11, 1);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTI';
wwv_flow_imp.g_varchar2_table(5) := 'ON, DISPLAY_SEQ, PARENT_TYPE_ID) values (3, ''REVIEW-SPEC'', ''Spec Review'', ''A review of the implement';
wwv_flow_imp.g_varchar2_table(6) := 'ation designed to implement a functional specification document'', 12, 1);'||wwv_flow.LF||
'insert into sp_task_types ';
wwv_flow_imp.g_varchar2_table(7) := '(ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (4, ''REVIEW-PEER'', ''Peer';
wwv_flow_imp.g_varchar2_table(8) := ' Review'', ''Review of the implementation by your fellow developer'', 13, 1);'||wwv_flow.LF||
'insert into sp_task_types';
wwv_flow_imp.g_varchar2_table(9) := ' (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (5, ''REVIEW-SECURITY'', ';
wwv_flow_imp.g_varchar2_table(10) := '''Security Review'', ''Review of the security exposure, remediations, and risk of this implementation'',';
wwv_flow_imp.g_varchar2_table(11) := ' 14, 1);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_';
wwv_flow_imp.g_varchar2_table(12) := 'ID) values (6, ''REVIEW-ACCESSIBILITY'', ''Accessibility Review'', ''Review web accessibility'', 15, 1);'||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(13) := 'nsert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values';
wwv_flow_imp.g_varchar2_table(14) := ' (7, ''REVIEW-PM'', ''Product Management Review'', ''Project Management (PM) team review'', 16, 1);'||wwv_flow.LF||
'insert';
wwv_flow_imp.g_varchar2_table(15) := ' into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (8, ';
wwv_flow_imp.g_varchar2_table(16) := '''REVIEW-DOC'', ''Documentation Review'', ''Review of the documentation'', 17, 1);'||wwv_flow.LF||
'insert into sp_task_typ';
wwv_flow_imp.g_varchar2_table(17) := 'es (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (9, ''REVIEW-TESTING'',';
wwv_flow_imp.g_varchar2_table(18) := ' ''Functional Testing Review'', ''Review of the testing plan'', 18, 1);'||wwv_flow.LF||
'insert into sp_task_types (ID, S';
wwv_flow_imp.g_varchar2_table(19) := 'TATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (10, ''REVIEW-UX'', ''User Experi';
wwv_flow_imp.g_varchar2_table(20) := 'ence Review'', ''Review of end-user experience'', 19, 1);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TAS';
wwv_flow_imp.g_varchar2_table(21) := 'K_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (11, ''REVIEW-IMPLEMENTATION'', ''Implementati';
wwv_flow_imp.g_varchar2_table(22) := 'on Review'', ''An implementation review is typically performed before merge'', 20, 1);'||wwv_flow.LF||
'insert into sp_t';
wwv_flow_imp.g_varchar2_table(23) := 'ask_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (12, ''REVIEW-O';
wwv_flow_imp.g_varchar2_table(24) := 'THER'', ''Other Review'', ''A review that does not fall into any other category'', 21, 1);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into s';
wwv_flow_imp.g_varchar2_table(25) := 'p_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ) values (20, ''MILESTONE'', ''Mileston';
wwv_flow_imp.g_varchar2_table(26) := 'e'', ''Milestones'', 1);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ,';
wwv_flow_imp.g_varchar2_table(27) := ' PARENT_TYPE_ID) values (21, ''MILESTONE-SPEC'', ''Spec'', ''Specification is complete and ready for revi';
wwv_flow_imp.g_varchar2_table(28) := 'ew'', 2, 20);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_T';
wwv_flow_imp.g_varchar2_table(29) := 'YPE_ID) values (22, ''MILESTONE-DEMO'', ''Demonstration'', ''Code has been successfully demonstrated'', 3,';
wwv_flow_imp.g_varchar2_table(30) := ' 20);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID)';
wwv_flow_imp.g_varchar2_table(31) := ' values (23, ''MILESTONE-CODE'', ''Code Complete'', ''Code is complete'', 4, 20);'||wwv_flow.LF||
'insert into sp_task_type';
wwv_flow_imp.g_varchar2_table(32) := 's (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (24, ''MILESTONE-MERGED';
wwv_flow_imp.g_varchar2_table(33) := ''', ''Merged'', ''Code has been merged'', 5, 20);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DE';
wwv_flow_imp.g_varchar2_table(34) := 'SCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (25, ''MILESTONE-HOSTED'', ''Hosted'', ''Code has been hos';
wwv_flow_imp.g_varchar2_table(35) := 'ted'', 6, 20);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_';
wwv_flow_imp.g_varchar2_table(36) := 'TYPE_ID) values (26, ''MILESTONE-COMPLETE'', ''Fully Completed'', ''The task is now fully complete'', 7, 2';
wwv_flow_imp.g_varchar2_table(37) := '0);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ) values (30, ''PM''';
wwv_flow_imp.g_varchar2_table(38) := ', ''PM'', ''Project Management'', 30);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION,';
wwv_flow_imp.g_varchar2_table(39) := ' DISPLAY_SEQ, PARENT_TYPE_ID) values (31, ''PM-CUST-ISSUE'', ''Customer Issue Identified'', ''Customer Is';
wwv_flow_imp.g_varchar2_table(40) := 'sue has been identified'', 31, 30);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION,';
wwv_flow_imp.g_varchar2_table(41) := ' DISPLAY_SEQ, PARENT_TYPE_ID) values (32, ''PM-RES-IDENTIFIED'', ''Resolution Identified'', ''Resolution ';
wwv_flow_imp.g_varchar2_table(42) := 'has been identified'', 32, 30);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DIS';
wwv_flow_imp.g_varchar2_table(43) := 'PLAY_SEQ, PARENT_TYPE_ID) values (33, ''PM-PROVIDED'', ''Provided to Customer'', ''Resolution Provided to';
wwv_flow_imp.g_varchar2_table(44) := ' Customer'', 33, 30);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, ';
wwv_flow_imp.g_varchar2_table(45) := 'PARENT_TYPE_ID) values (34, ''PM-IMPLEMENTED'', ''Implemented by Customer'', ''Resolution implemented by ';
wwv_flow_imp.g_varchar2_table(46) := 'Customer'', 44, 30);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ) ';
wwv_flow_imp.g_varchar2_table(47) := 'values (40, ''SALES'', ''Sales'', ''Sales Engagement'', 40);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TAS';
wwv_flow_imp.g_varchar2_table(48) := 'K_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (41, ''SALES-OPP-QUALIFIED'', ''Opportunity Qu';
wwv_flow_imp.g_varchar2_table(49) := 'alified'', ''Opportunity has been qualified'', 41, 40);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_';
wwv_flow_imp.g_varchar2_table(50) := 'TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (42, ''SALES-PRESENT'', ''Presented to Customer''';
wwv_flow_imp.g_varchar2_table(51) := ', ''Presented to Customer'', 42, 40);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION';
wwv_flow_imp.g_varchar2_table(52) := ', DISPLAY_SEQ, PARENT_TYPE_ID) values (43, ''SALES-PROPOSAL-DRAFT'', ''Proposal Drafted'', ''Proposal Dra';
wwv_flow_imp.g_varchar2_table(53) := 'fted'', 43, 40);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PAREN';
wwv_flow_imp.g_varchar2_table(54) := 'T_TYPE_ID) values (44, ''SALES-PROPOSAL-DEL'', ''Proposal Delivered'', ''Proposal Delivered'', 44, 40);'||wwv_flow.LF||
''||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(55) := 'nsert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, TASK_NAME_REQ_YN) valu';
wwv_flow_imp.g_varchar2_table(56) := 'es (50, ''DEVELOPMENT'', ''Development'', ''Development Activities'', 50, ''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_task_statu';
wwv_flow_imp.g_varchar2_table(57) := 'ses (id, task_type_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_complete';
wwv_flow_imp.g_varchar2_table(58) := '_yn) values (1, 1, ''Identified'', ''IDENTIFIED'', 1, ''Y'', ''Y'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, ';
wwv_flow_imp.g_varchar2_table(59) := 'task_type_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) valu';
wwv_flow_imp.g_varchar2_table(60) := 'es (2, 1, ''Assigned'', ''ASSIGNED'', 2, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id,';
wwv_flow_imp.g_varchar2_table(61) := ' status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (4, 1, ''In';
wwv_flow_imp.g_varchar2_table(62) := ' Progress'', ''IN-PROGRESS'', 4, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status';
wwv_flow_imp.g_varchar2_table(63) := ', static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (5, 1, ''More Info';
wwv_flow_imp.g_varchar2_table(64) := 'rmation Requested'', ''MORE-INFO'', 5, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, ';
wwv_flow_imp.g_varchar2_table(65) := 'status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (6, 1, ''Pau';
wwv_flow_imp.g_varchar2_table(66) := 'sed'', ''PAUSED'', 6, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, static_id';
wwv_flow_imp.g_varchar2_table(67) := ', display_seq, include_yn, is_default_yn, indicates_complete_yn) values (7, 1, ''Blocked'', ''BLOCKED'',';
wwv_flow_imp.g_varchar2_table(68) := ' 7, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, static_id, display_seq, ';
wwv_flow_imp.g_varchar2_table(69) := 'include_yn, is_default_yn, indicates_complete_yn) values (8, 1, ''Completed'', ''COMPLETED'', 8, ''Y'', ''N';
wwv_flow_imp.g_varchar2_table(70) := ''', ''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, static_id, display_seq, include_yn';
wwv_flow_imp.g_varchar2_table(71) := ', is_default_yn, indicates_complete_yn) values (10, 20, ''Identified'', ''IDENTIFIED'', 1, ''Y'', ''Y'', ''N''';
wwv_flow_imp.g_varchar2_table(72) := ');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, static_id, display_seq, include_yn, is_de';
wwv_flow_imp.g_varchar2_table(73) := 'fault_yn, indicates_complete_yn) values (11, 20, ''In Progress'', ''IN-PROGRESS'', 4, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'in';
wwv_flow_imp.g_varchar2_table(74) := 'sert into sp_task_statuses (id, task_type_id, status, static_id, display_seq, include_yn, is_default';
wwv_flow_imp.g_varchar2_table(75) := '_yn, indicates_complete_yn) values (12, 20, ''Paused'', ''PAUSED'', 6, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_ta';
wwv_flow_imp.g_varchar2_table(76) := 'sk_statuses (id, task_type_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_';
wwv_flow_imp.g_varchar2_table(77) := 'complete_yn) values (13, 20, ''Blocked'', ''BLOCKED'', 7, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (';
wwv_flow_imp.g_varchar2_table(78) := 'id, task_type_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) ';
wwv_flow_imp.g_varchar2_table(79) := 'values (14, 20, ''Completed'', ''COMPLETED'', 8, ''Y'', ''N'', ''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_task_statuses (id, task';
wwv_flow_imp.g_varchar2_table(80) := '_type_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (';
wwv_flow_imp.g_varchar2_table(81) := '21, 30, ''Identified'', ''IDENTIFIED'', 1, ''Y'', ''Y'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_i';
wwv_flow_imp.g_varchar2_table(82) := 'd, status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (22, 30,';
wwv_flow_imp.g_varchar2_table(83) := ' ''Assigned'', ''ASSIGNED'', 2, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, ';
wwv_flow_imp.g_varchar2_table(84) := 'static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (23, 30, ''In Progre';
wwv_flow_imp.g_varchar2_table(85) := 'ss'', ''IN-PROGRESS'', 4, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, stati';
wwv_flow_imp.g_varchar2_table(86) := 'c_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (24, 30, ''More Informati';
wwv_flow_imp.g_varchar2_table(87) := 'on Requested'', ''MORE-INFO'', 5, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, statu';
wwv_flow_imp.g_varchar2_table(88) := 's, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (25, 30, ''Paused';
wwv_flow_imp.g_varchar2_table(89) := ''', ''PAUSED'', 6, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, static_id, d';
wwv_flow_imp.g_varchar2_table(90) := 'isplay_seq, include_yn, is_default_yn, indicates_complete_yn) values (26, 30, ''Blocked'', ''BLOCKED'', ';
wwv_flow_imp.g_varchar2_table(91) := '7, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, static_id, display_seq, i';
wwv_flow_imp.g_varchar2_table(92) := 'nclude_yn, is_default_yn, indicates_complete_yn) values (27, 30, ''Completed'', ''COMPLETED'', 8, ''Y'', ''';
wwv_flow_imp.g_varchar2_table(93) := 'N'', ''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, static_id, display_seq, include_y';
wwv_flow_imp.g_varchar2_table(94) := 'n, is_default_yn, indicates_complete_yn) values (31, 40, ''Identified'', ''IDENTIFIED'', 1, ''Y'', ''Y'', ''N';
wwv_flow_imp.g_varchar2_table(95) := ''');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, static_id, display_seq, include_yn, is_d';
wwv_flow_imp.g_varchar2_table(96) := 'efault_yn, indicates_complete_yn) values (32, 40, ''Assigned'', ''ASSIGNED'', 2, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert ';
wwv_flow_imp.g_varchar2_table(97) := 'into sp_task_statuses (id, task_type_id, status, static_id, display_seq, include_yn, is_default_yn, ';
wwv_flow_imp.g_varchar2_table(98) := 'indicates_complete_yn) values (33, 40, ''In Progress'', ''IN-PROGRESS'', 4, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into ';
wwv_flow_imp.g_varchar2_table(99) := 'sp_task_statuses (id, task_type_id, status, static_id, display_seq, include_yn, is_default_yn, indic';
wwv_flow_imp.g_varchar2_table(100) := 'ates_complete_yn) values (34, 40, ''Completed'', ''COMPLETED'', 8, ''Y'', ''N'', ''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_task_';
wwv_flow_imp.g_varchar2_table(101) := 'statuses (id, task_type_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_com';
wwv_flow_imp.g_varchar2_table(102) := 'plete_yn) values (41, 50, ''Identified'', ''IDENTIFIED'', 1, ''Y'', ''Y'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuse';
wwv_flow_imp.g_varchar2_table(103) := 's (id, task_type_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_y';
wwv_flow_imp.g_varchar2_table(104) := 'n) values (42, 50, ''Assigned'', ''ASSIGNED'', 2, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task';
wwv_flow_imp.g_varchar2_table(105) := '_type_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (';
wwv_flow_imp.g_varchar2_table(106) := '43, 50, ''In Progress'', ''IN-PROGRESS'', 4, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type';
wwv_flow_imp.g_varchar2_table(107) := '_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (44, 5';
wwv_flow_imp.g_varchar2_table(108) := '0, ''More Information Requested'', ''MORE-INFO'', 5, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, t';
wwv_flow_imp.g_varchar2_table(109) := 'ask_type_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) value';
wwv_flow_imp.g_varchar2_table(110) := 's (45, 50, ''Paused'', ''PAUSED'', 6, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, st';
wwv_flow_imp.g_varchar2_table(111) := 'atus, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (46, 50, ''Blo';
wwv_flow_imp.g_varchar2_table(112) := 'cked'', ''BLOCKED'', 7, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, static_';
wwv_flow_imp.g_varchar2_table(113) := 'id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (47, 50, ''Completed'', ''COM';
wwv_flow_imp.g_varchar2_table(114) := 'PLETED'', 8, ''Y'', ''N'', ''Y'');'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38218326152049015885)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'Seed Task Types and Statuses'
,p_sequence=>890
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
