prompt --application/deployment/install/install_seed_countries
begin
--   Manifest
--     INSTALL: INSTALL-seed countries
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LO';
wwv_flow_imp.g_varchar2_table(2) := 'N, COUNTRY_CODE3) values (1, ''AF'', ''Afghanistan'', ''EMEA'', ''Y'', ''N'', null, null, ''AFG'');'||wwv_flow.LF||
'insert into ';
wwv_flow_imp.g_varchar2_table(3) := 'SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_C';
wwv_flow_imp.g_varchar2_table(4) := 'ODE3) values (2, ''AL'', ''Albania'', ''EMEA'', ''Y'', ''N'', null, null, ''ALB'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID';
wwv_flow_imp.g_varchar2_table(5) := ', COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (3,';
wwv_flow_imp.g_varchar2_table(6) := ' ''DZ'', ''Algeria'', ''EMEA'', ''Y'', ''N'', 28.0505583782702, 2.65803648781882, ''DZA'');'||wwv_flow.LF||
'insert into SP_COUNT';
wwv_flow_imp.g_varchar2_table(7) := 'RIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) va';
wwv_flow_imp.g_varchar2_table(8) := 'lues (4, ''AS'', ''American Samoa'', ''Asia Pacific'', ''Y'', ''N'', null, null, ''ASM'');'||wwv_flow.LF||
'insert into SP_COUNTR';
wwv_flow_imp.g_varchar2_table(9) := 'IES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) val';
wwv_flow_imp.g_varchar2_table(10) := 'ues (5, ''AD'', ''Andorra'', ''EMEA'', ''Y'', ''N'', null, null, ''AND'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY';
wwv_flow_imp.g_varchar2_table(11) := '_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (6, ''AO'', ''A';
wwv_flow_imp.g_varchar2_table(12) := 'ngola'', ''EMEA'', ''Y'', ''N'', null, null, ''AGO'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NA';
wwv_flow_imp.g_varchar2_table(13) := 'ME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (7, ''AG'', ''Antigua and Barbud';
wwv_flow_imp.g_varchar2_table(14) := 'a'', ''North America'', ''Y'', ''N'', null, null, ''ATG'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNT';
wwv_flow_imp.g_varchar2_table(15) := 'RY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (8, ''AR'', ''Argentina'', ''';
wwv_flow_imp.g_varchar2_table(16) := 'South America'', ''Y'', ''N'', -34.749827181579, -64.7396264761603, ''ARG'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID,';
wwv_flow_imp.g_varchar2_table(17) := ' COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (9, ';
wwv_flow_imp.g_varchar2_table(18) := '''AM'', ''Armenia'', ''EMEA'', ''Y'', ''N'', 40.2860257920532, 44.9406270034667, ''ARM'');'||wwv_flow.LF||
'insert into SP_COUNTR';
wwv_flow_imp.g_varchar2_table(19) := 'IES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) val';
wwv_flow_imp.g_varchar2_table(20) := 'ues (10, ''AW'', ''Aruba'', ''North America'', ''Y'', ''N'', null, null, ''ABW'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID,';
wwv_flow_imp.g_varchar2_table(21) := ' COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (11,';
wwv_flow_imp.g_varchar2_table(22) := ' ''AU'', ''Australia'', ''Asia Pacific'', ''Y'', ''N'', -25.9525329514233, 134.471201485241, ''AUS'');'||wwv_flow.LF||
'insert in';
wwv_flow_imp.g_varchar2_table(23) := 'to SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTR';
wwv_flow_imp.g_varchar2_table(24) := 'Y_CODE3) values (12, ''AT'', ''Austria'', ''EMEA'', ''Y'', ''Y'', 47.5925608197967, 14.1144710431191, ''AUT'');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(25) := 'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LO';
wwv_flow_imp.g_varchar2_table(26) := 'N, COUNTRY_CODE3) values (13, ''AZ'', ''Azerbaijan'', ''EMEA'', ''Y'', ''N'', 40.2876406168275, 47.54382093624';
wwv_flow_imp.g_varchar2_table(27) := '41, ''AZE'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK';
wwv_flow_imp.g_varchar2_table(28) := '_YN, LAT, LON, COUNTRY_CODE3) values (14, ''BS'', ''Bahamas'', ''North America'', ''Y'', ''N'', null, null, ''B';
wwv_flow_imp.g_varchar2_table(29) := 'HS'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, L';
wwv_flow_imp.g_varchar2_table(30) := 'AT, LON, COUNTRY_CODE3) values (15, ''BH'', ''Bahrain'', ''EMEA'', ''Y'', ''N'', 26.0526927146835, 50.54663831';
wwv_flow_imp.g_varchar2_table(31) := '16253, ''BHR'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_P';
wwv_flow_imp.g_varchar2_table(32) := 'ICK_YN, LAT, LON, COUNTRY_CODE3) values (16, ''BD'', ''Bangladesh'', ''Asia Pacific'', ''Y'', ''N'', null, nul';
wwv_flow_imp.g_varchar2_table(33) := 'l, ''BGD'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_';
wwv_flow_imp.g_varchar2_table(34) := 'YN, LAT, LON, COUNTRY_CODE3) values (17, ''BB'', ''Barbados'', ''North America'', ''Y'', ''N'', null, null, ''B';
wwv_flow_imp.g_varchar2_table(35) := 'RB'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, L';
wwv_flow_imp.g_varchar2_table(36) := 'AT, LON, COUNTRY_CODE3) values (18, ''BY'', ''Belarus'', ''EMEA'', ''Y'', ''N'', 53.5204591224913, 28.01640776';
wwv_flow_imp.g_varchar2_table(37) := '27553, ''BLR'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_P';
wwv_flow_imp.g_varchar2_table(38) := 'ICK_YN, LAT, LON, COUNTRY_CODE3) values (19, ''BE'', ''Belgium'', ''EMEA'', ''Y'', ''N'', 50.636807234233, 4.6';
wwv_flow_imp.g_varchar2_table(39) := '4712606207158, ''BEL'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN,';
wwv_flow_imp.g_varchar2_table(40) := ' QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (20, ''BZ'', ''Belize'', ''North America'', ''Y'', ''N'', null';
wwv_flow_imp.g_varchar2_table(41) := ', null, ''BLZ'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_';
wwv_flow_imp.g_varchar2_table(42) := 'PICK_YN, LAT, LON, COUNTRY_CODE3) values (21, ''BJ'', ''Benin'', ''EMEA'', ''Y'', ''N'', null, null, ''BEN'');'||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(43) := 'nsert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON';
wwv_flow_imp.g_varchar2_table(44) := ', COUNTRY_CODE3) values (22, ''BM'', ''Bermuda'', ''North America'', ''Y'', ''N'', null, null, ''BMU'');'||wwv_flow.LF||
'insert ';
wwv_flow_imp.g_varchar2_table(45) := 'into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUN';
wwv_flow_imp.g_varchar2_table(46) := 'TRY_CODE3) values (23, ''BT'', ''Bhutan'', ''Asia Pacific'', ''Y'', ''N'', null, null, ''BTN'');'||wwv_flow.LF||
'insert into SP_';
wwv_flow_imp.g_varchar2_table(47) := 'COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE';
wwv_flow_imp.g_varchar2_table(48) := '3) values (24, ''BO'', ''Bolivia'', ''South America'', ''Y'', ''N'', null, null, ''BOL'');'||wwv_flow.LF||
'insert into SP_COUNTR';
wwv_flow_imp.g_varchar2_table(49) := 'IES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) val';
wwv_flow_imp.g_varchar2_table(50) := 'ues (25, ''BA'', ''Bosnia and Herzegovina'', ''EMEA'', ''Y'', ''N'', 44.1687700204018, 17.7794261662736, ''BIH''';
wwv_flow_imp.g_varchar2_table(51) := ');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT,';
wwv_flow_imp.g_varchar2_table(52) := ' LON, COUNTRY_CODE3) values (26, ''BW'', ''Botswana'', ''EMEA'', ''Y'', ''N'', null, null, ''BWA'');'||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(53) := ' SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_';
wwv_flow_imp.g_varchar2_table(54) := 'CODE3) values (27, ''BR'', ''Brazil'', ''South America'', ''Y'', ''N'', -10.7897128871259, -53.0625058302629, ';
wwv_flow_imp.g_varchar2_table(55) := '''BRA'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN,';
wwv_flow_imp.g_varchar2_table(56) := ' LAT, LON, COUNTRY_CODE3) values (28, ''BN'', ''Brunei Darussalam'', ''Asia Pacific'', ''Y'', ''N'', null, nul';
wwv_flow_imp.g_varchar2_table(57) := 'l, ''BRN'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_';
wwv_flow_imp.g_varchar2_table(58) := 'YN, LAT, LON, COUNTRY_CODE3) values (29, ''BG'', ''Bulgaria'', ''EMEA'', ''Y'', ''N'', 42.7710163382631, 25.21';
wwv_flow_imp.g_varchar2_table(59) := '11454916013, ''BGR'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, Q';
wwv_flow_imp.g_varchar2_table(60) := 'UICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (30, ''BF'', ''Burkina Faso'', ''EMEA'', ''Y'', ''N'', null, nul';
wwv_flow_imp.g_varchar2_table(61) := 'l, ''BFA'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_';
wwv_flow_imp.g_varchar2_table(62) := 'YN, LAT, LON, COUNTRY_CODE3) values (31, ''BI'', ''Burundi'', ''EMEA'', ''Y'', ''N'', null, null, ''BDI'');'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(63) := 'rt into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, C';
wwv_flow_imp.g_varchar2_table(64) := 'OUNTRY_CODE3) values (32, ''KH'', ''Cambodia'', ''Asia Pacific'', ''Y'', ''N'', null, null, ''KHM'');'||wwv_flow.LF||
'insert int';
wwv_flow_imp.g_varchar2_table(65) := 'o SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY';
wwv_flow_imp.g_varchar2_table(66) := '_CODE3) values (33, ''CM'', ''Cameroon'', ''EMEA'', ''Y'', ''N'', null, null, ''CMR'');'||wwv_flow.LF||
'insert into SP_COUNTRIES';
wwv_flow_imp.g_varchar2_table(67) := ' (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values';
wwv_flow_imp.g_varchar2_table(68) := ' (34, ''CA'', ''Canada'', ''North America'', ''Y'', ''N'', 60.545577443515, -96.2833441420418, ''CAN'');'||wwv_flow.LF||
'insert ';
wwv_flow_imp.g_varchar2_table(69) := 'into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUN';
wwv_flow_imp.g_varchar2_table(70) := 'TRY_CODE3) values (35, ''IC'', ''Canary Islands'', ''EMEA'', ''Y'', ''N'', null, null, '''');'||wwv_flow.LF||
'insert into SP_COU';
wwv_flow_imp.g_varchar2_table(71) := 'NTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) ';
wwv_flow_imp.g_varchar2_table(72) := 'values (36, ''CV'', ''Cape Verde'', ''North America'', ''Y'', ''N'', null, null, ''CPV'');'||wwv_flow.LF||
'insert into SP_COUNTR';
wwv_flow_imp.g_varchar2_table(73) := 'IES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) val';
wwv_flow_imp.g_varchar2_table(74) := 'ues (37, ''KY'', ''Cayman Islands'', ''EMEA'', ''Y'', ''N'', null, null, ''CYM'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID,';
wwv_flow_imp.g_varchar2_table(75) := ' COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (38,';
wwv_flow_imp.g_varchar2_table(76) := ' ''CF'', ''Central African Republic'', ''EMEA'', ''Y'', ''N'', null, null, ''CAF'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (I';
wwv_flow_imp.g_varchar2_table(77) := 'D, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (3';
wwv_flow_imp.g_varchar2_table(78) := '9, ''TD'', ''Chad'', ''EMEA'', ''Y'', ''N'', null, null, ''TCD'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, C';
wwv_flow_imp.g_varchar2_table(79) := 'OUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (40, ''CL'', ''Chile'', ';
wwv_flow_imp.g_varchar2_table(80) := '''South America'', ''Y'', ''N'', -36.3436063353845, -71.3772836093728, ''CHL'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (I';
wwv_flow_imp.g_varchar2_table(81) := 'D, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (4';
wwv_flow_imp.g_varchar2_table(82) := '1, ''CN'', ''China'', ''Asia Pacific'', ''Y'', ''N'', 36.6777277688864, 103.2272858186, ''CHN'');'||wwv_flow.LF||
'insert into SP';
wwv_flow_imp.g_varchar2_table(83) := '_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_COD';
wwv_flow_imp.g_varchar2_table(84) := 'E3) values (42, ''CO'', ''Colombia'', ''South America'', ''Y'', ''N'', 3.90406268648937, -73.0865398553309, ''C';
wwv_flow_imp.g_varchar2_table(85) := 'OL'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, L';
wwv_flow_imp.g_varchar2_table(86) := 'AT, LON, COUNTRY_CODE3) values (43, ''KM'', ''Comoros'', ''EMEA'', ''Y'', ''N'', null, null, ''COM'');'||wwv_flow.LF||
'insert in';
wwv_flow_imp.g_varchar2_table(87) := 'to SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTR';
wwv_flow_imp.g_varchar2_table(88) := 'Y_CODE3) values (44, ''CG'', ''Congo'', ''EMEA'', ''Y'', ''N'', null, null, ''COG'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (';
wwv_flow_imp.g_varchar2_table(89) := 'ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (';
wwv_flow_imp.g_varchar2_table(90) := '45, ''CR'', ''Costa Rica'', ''South America'', ''Y'', ''N'', 9.97274931092909, -84.1915245024165, ''CRI'');'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(91) := 'rt into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, C';
wwv_flow_imp.g_varchar2_table(92) := 'OUNTRY_CODE3) values (46, ''HR'', ''Croatia'', ''EMEA'', ''Y'', ''N'', 45.0629969941661, 16.3952369947082, ''HR';
wwv_flow_imp.g_varchar2_table(93) := 'V'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LA';
wwv_flow_imp.g_varchar2_table(94) := 'T, LON, COUNTRY_CODE3) values (47, ''CY'', ''Cyprus'', ''EMEA'', ''Y'', ''N'', 34.9156521226288, 32.9898847263';
wwv_flow_imp.g_varchar2_table(95) := '562, ''CYP'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PIC';
wwv_flow_imp.g_varchar2_table(96) := 'K_YN, LAT, LON, COUNTRY_CODE3) values (48, ''CZ'', ''Czech Republic'', ''EMEA'', ''Y'', ''N'', 49.737131739025';
wwv_flow_imp.g_varchar2_table(97) := '3, 15.3210867930983, ''CZE'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPL';
wwv_flow_imp.g_varchar2_table(98) := 'AY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (49, ''CD'', ''Democratic Republic of the Congo'',';
wwv_flow_imp.g_varchar2_table(99) := ' ''EMEA'', ''Y'', ''N'', null, null, ''COD'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REG';
wwv_flow_imp.g_varchar2_table(100) := 'ION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (50, ''DK'', ''Denmark'', ''EMEA'', ''Y'', ''';
wwv_flow_imp.g_varchar2_table(101) := 'N'', 55.9589501119306, 10.0681059452285, ''DNK'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_';
wwv_flow_imp.g_varchar2_table(102) := 'NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (51, ''DJ'', ''Djibouti'', ''EME';
wwv_flow_imp.g_varchar2_table(103) := 'A'', ''Y'', ''N'', null, null, ''DJI'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, ';
wwv_flow_imp.g_varchar2_table(104) := 'DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (52, ''DM'', ''Dominica'', ''North America'', ''';
wwv_flow_imp.g_varchar2_table(105) := 'Y'', ''N'', null, null, ''DMA'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPL';
wwv_flow_imp.g_varchar2_table(106) := 'AY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (53, ''DO'', ''Dominican Republic'', ''South Americ';
wwv_flow_imp.g_varchar2_table(107) := 'a'', ''Y'', ''N'', null, null, ''DOM'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, ';
wwv_flow_imp.g_varchar2_table(108) := 'DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (54, ''EC'', ''Ecuador'', ''South America'', ''Y';
wwv_flow_imp.g_varchar2_table(109) := ''', ''N'', null, null, ''ECU'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLA';
wwv_flow_imp.g_varchar2_table(110) := 'Y_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (55, ''EG'', ''Egypt'', ''EMEA'', ''Y'', ''N'', 26.459388';
wwv_flow_imp.g_varchar2_table(111) := '687411, 29.8800800216717, ''EGY'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, ';
wwv_flow_imp.g_varchar2_table(112) := 'DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (56, ''SV'', ''El Salvador'', ''North America''';
wwv_flow_imp.g_varchar2_table(113) := ', ''Y'', ''N'', null, null, ''SLV'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DI';
wwv_flow_imp.g_varchar2_table(114) := 'SPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (57, ''GQ'', ''Equatorial Guinea'', ''EMEA'', ''Y''';
wwv_flow_imp.g_varchar2_table(115) := ', ''N'', null, null, ''GNQ'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY';
wwv_flow_imp.g_varchar2_table(116) := '_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (58, ''EE'', ''Estonia'', ''EMEA'', ''Y'', ''N'', 58.67205';
wwv_flow_imp.g_varchar2_table(117) := '76799641, 25.5383130586335, ''EST'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION';
wwv_flow_imp.g_varchar2_table(118) := ', DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (59, ''ET'', ''Ethiopia'', ''EMEA'', ''Y'', ''N''';
wwv_flow_imp.g_varchar2_table(119) := ', null, null, ''ETH'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, ';
wwv_flow_imp.g_varchar2_table(120) := 'QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (60, ''FO'', ''Faroe Islands'', ''EMEA'', ''Y'', ''N'', null, n';
wwv_flow_imp.g_varchar2_table(121) := 'ull, ''FRO'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PIC';
wwv_flow_imp.g_varchar2_table(122) := 'K_YN, LAT, LON, COUNTRY_CODE3) values (61, ''FJ'', ''Fiji'', ''Asia Pacific'', ''Y'', ''N'', null, null, ''FJI''';
wwv_flow_imp.g_varchar2_table(123) := ');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT,';
wwv_flow_imp.g_varchar2_table(124) := ' LON, COUNTRY_CODE3) values (62, ''FI'', ''Finland'', ''EMEA'', ''Y'', ''N'', 64.2542670593351, 26.19081562006';
wwv_flow_imp.g_varchar2_table(125) := '91, ''FIN'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK';
wwv_flow_imp.g_varchar2_table(126) := '_YN, LAT, LON, COUNTRY_CODE3) values (63, ''FR'', ''France'', ''EMEA'', ''Y'', ''N'', 46.3, 2.35, ''FRA'');'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(127) := 'rt into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, C';
wwv_flow_imp.g_varchar2_table(128) := 'OUNTRY_CODE3) values (64, ''GF'', ''French Guiana'', ''South America'', ''Y'', ''N'', null, null, ''GUF'');'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(129) := 'rt into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, C';
wwv_flow_imp.g_varchar2_table(130) := 'OUNTRY_CODE3) values (65, ''PF'', ''French Polynesia'', ''Asia Pacific'', ''Y'', ''N'', null, null, ''PYF'');'||wwv_flow.LF||
'in';
wwv_flow_imp.g_varchar2_table(131) := 'sert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON,';
wwv_flow_imp.g_varchar2_table(132) := ' COUNTRY_CODE3) values (66, ''GA'', ''Gabon'', ''EMEA'', ''Y'', ''N'', null, null, ''GAB'');'||wwv_flow.LF||
'insert into SP_COUN';
wwv_flow_imp.g_varchar2_table(133) := 'TRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) v';
wwv_flow_imp.g_varchar2_table(134) := 'alues (67, ''GM'', ''Gambia'', ''EMEA'', ''Y'', ''N'', null, null, ''GMB'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNT';
wwv_flow_imp.g_varchar2_table(135) := 'RY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (68, ''GE'',';
wwv_flow_imp.g_varchar2_table(136) := ' ''Georgia'', ''EMEA'', ''Y'', ''N'', null, null, ''GEO'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTR';
wwv_flow_imp.g_varchar2_table(137) := 'Y_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (69, ''DE'', ''Germany'', ''EM';
wwv_flow_imp.g_varchar2_table(138) := 'EA'', ''Y'', ''Y'', 51.0515299009581, 10.3623688098981, ''DEU'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_COD';
wwv_flow_imp.g_varchar2_table(139) := 'E, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (70, ''GH'', ''Ghan';
wwv_flow_imp.g_varchar2_table(140) := 'a'', ''EMEA'', ''Y'', ''N'', 7.9484206013734, -1.21654631168427, ''GHA'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUN';
wwv_flow_imp.g_varchar2_table(141) := 'TRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (71, ''GI''';
wwv_flow_imp.g_varchar2_table(142) := ', ''Gibraltar'', ''EMEA'', ''Y'', ''N'', null, null, ''GIB'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COU';
wwv_flow_imp.g_varchar2_table(143) := 'NTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (72, ''GR'', ''Greece'', ''';
wwv_flow_imp.g_varchar2_table(144) := 'EMEA'', ''Y'', ''N'', 39.0249771332278, 22.9853392654736, ''GRC'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_C';
wwv_flow_imp.g_varchar2_table(145) := 'ODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (73, ''GL'', ''Gr';
wwv_flow_imp.g_varchar2_table(146) := 'eenland'', ''EMEA'', ''Y'', ''N'', null, null, ''GRL'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_';
wwv_flow_imp.g_varchar2_table(147) := 'NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (74, ''GD'', ''Grenada'', ''Nort';
wwv_flow_imp.g_varchar2_table(148) := 'h America'', ''Y'', ''N'', null, null, ''GRD'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, ';
wwv_flow_imp.g_varchar2_table(149) := 'REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (75, ''GP'', ''Guadeloupe'', ''North A';
wwv_flow_imp.g_varchar2_table(150) := 'merica'', ''Y'', ''N'', null, null, ''GLP'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REG';
wwv_flow_imp.g_varchar2_table(151) := 'ION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (76, ''GT'', ''Guatemala'', ''North Ameri';
wwv_flow_imp.g_varchar2_table(152) := 'ca'', ''Y'', ''N'', null, null, ''GTM'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION,';
wwv_flow_imp.g_varchar2_table(153) := ' DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (77, ''GG'', ''Guernsey'', ''EMEA'', ''Y'', ''N'',';
wwv_flow_imp.g_varchar2_table(154) := ' null, null, ''GGY'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, Q';
wwv_flow_imp.g_varchar2_table(155) := 'UICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (78, ''GN'', ''Guinea'', ''EMEA'', ''Y'', ''N'', null, null, ''GI';
wwv_flow_imp.g_varchar2_table(156) := 'N'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LA';
wwv_flow_imp.g_varchar2_table(157) := 'T, LON, COUNTRY_CODE3) values (79, ''GW'', ''Guinea Bissau'', ''EMEA'', ''Y'', ''N'', null, null, ''GNB'');'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(158) := 'rt into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, C';
wwv_flow_imp.g_varchar2_table(159) := 'OUNTRY_CODE3) values (80, ''GY'', ''Guyana'', ''South America'', ''Y'', ''N'', null, null, ''GUY'');'||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(160) := ' SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_';
wwv_flow_imp.g_varchar2_table(161) := 'CODE3) values (81, ''HT'', ''Haiti'', ''North America'', ''Y'', ''N'', null, null, ''HTI'');'||wwv_flow.LF||
'insert into SP_COUN';
wwv_flow_imp.g_varchar2_table(162) := 'TRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) v';
wwv_flow_imp.g_varchar2_table(163) := 'alues (82, ''HN'', ''Honduras'', ''North America'', ''Y'', ''N'', null, null, ''HND'');'||wwv_flow.LF||
'insert into SP_COUNTRIES';
wwv_flow_imp.g_varchar2_table(164) := ' (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values';
wwv_flow_imp.g_varchar2_table(165) := ' (83, ''HK'', ''Hong Kong'', ''Asia Pacific'', ''Y'', ''N'', 22.3840226008677, 114.131830902761, ''HKG'');'||wwv_flow.LF||
'inser';
wwv_flow_imp.g_varchar2_table(166) := 't into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, CO';
wwv_flow_imp.g_varchar2_table(167) := 'UNTRY_CODE3) values (84, ''HU'', ''Hungary'', ''EMEA'', ''Y'', ''N'', 47.1665440842287, 19.3805755323318, ''HUN';
wwv_flow_imp.g_varchar2_table(168) := ''');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT';
wwv_flow_imp.g_varchar2_table(169) := ', LON, COUNTRY_CODE3) values (85, ''IS'', ''Iceland'', ''EMEA'', ''Y'', ''N'', null, null, ''ISL'');'||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(170) := ' SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_';
wwv_flow_imp.g_varchar2_table(171) := 'CODE3) values (86, ''IN'', ''India'', ''Asia Pacific'', ''Y'', ''Y'', 22.7617383835867, 79.6047525485952, ''IND';
wwv_flow_imp.g_varchar2_table(172) := ''');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT';
wwv_flow_imp.g_varchar2_table(173) := ', LON, COUNTRY_CODE3) values (87, ''ID'', ''Indonesia'', ''Asia Pacific'', ''Y'', ''N'', -2.28016763022542, 11';
wwv_flow_imp.g_varchar2_table(174) := '7.159522844253, ''IDN'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN';
wwv_flow_imp.g_varchar2_table(175) := ', QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (88, ''IQ'', ''Iraq'', ''EMEA'', ''Y'', ''N'', null, null, ''I';
wwv_flow_imp.g_varchar2_table(176) := 'RQ'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, L';
wwv_flow_imp.g_varchar2_table(177) := 'AT, LON, COUNTRY_CODE3) values (89, ''IE'', ''Ireland'', ''EMEA'', ''Y'', ''Y'', 53.1655400036239, -8.15269941';
wwv_flow_imp.g_varchar2_table(178) := '873606, ''IRL'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_';
wwv_flow_imp.g_varchar2_table(179) := 'PICK_YN, LAT, LON, COUNTRY_CODE3) values (90, ''IM'', ''Isle of Man'', ''EMEA'', ''Y'', ''N'', null, null, ''IM';
wwv_flow_imp.g_varchar2_table(180) := 'N'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LA';
wwv_flow_imp.g_varchar2_table(181) := 'T, LON, COUNTRY_CODE3) values (91, ''IL'', ''Israel'', ''EMEA'', ''Y'', ''N'', 31.4345676456433, 34.9919400131';
wwv_flow_imp.g_varchar2_table(182) := '368, ''ISR'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PIC';
wwv_flow_imp.g_varchar2_table(183) := 'K_YN, LAT, LON, COUNTRY_CODE3) values (92, ''IT'', ''Italy'', ''EMEA'', ''Y'', ''N'', 42.7035691994324, 12.203';
wwv_flow_imp.g_varchar2_table(184) := '6276805693, ''ITA'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QU';
wwv_flow_imp.g_varchar2_table(185) := 'ICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (93, ''CI'', ''Ivory Coast'', ''EMEA'', ''Y'', ''N'', 7.625502820';
wwv_flow_imp.g_varchar2_table(186) := '92241, -5.56889039182287, ''CIV'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, ';
wwv_flow_imp.g_varchar2_table(187) := 'DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (94, ''JM'', ''Jamaica'', ''North America'', ''Y';
wwv_flow_imp.g_varchar2_table(188) := ''', ''N'', null, null, ''JAM'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLA';
wwv_flow_imp.g_varchar2_table(189) := 'Y_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (95, ''JP'', ''Japan'', ''Japan'', ''Y'', ''N'', 37.38540';
wwv_flow_imp.g_varchar2_table(190) := '17876606, 137.598609181384, ''JPN'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION';
wwv_flow_imp.g_varchar2_table(191) := ', DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (96, ''JE'', ''Jersey'', ''EMEA'', ''Y'', ''N'', ';
wwv_flow_imp.g_varchar2_table(192) := 'null, null, ''JEY'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QU';
wwv_flow_imp.g_varchar2_table(193) := 'ICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (97, ''JO'', ''Jordan'', ''EMEA'', ''Y'', ''N'', 31.2387907978558';
wwv_flow_imp.g_varchar2_table(194) := ', 36.757422903456, ''JOR'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY';
wwv_flow_imp.g_varchar2_table(195) := '_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (98, ''KZ'', ''Kazakhstan'', ''EMEA'', ''Y'', ''N'', 48.37';
wwv_flow_imp.g_varchar2_table(196) := '41037629595, 67.2739888798585, ''KAZ'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REG';
wwv_flow_imp.g_varchar2_table(197) := 'ION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (99, ''KE'', ''Kenya'', ''EMEA'', ''Y'', ''N''';
wwv_flow_imp.g_varchar2_table(198) := ', .549356244899326, 37.8228067783801, ''KEN'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NA';
wwv_flow_imp.g_varchar2_table(199) := 'ME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (100, ''KR'', ''Korea'', ''Asia Pa';
wwv_flow_imp.g_varchar2_table(200) := 'cific'', ''Y'', ''N'', 36.3615090498173, 127.814668142768, ''KOR'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_';
wwv_flow_imp.g_varchar2_table(201) := 'CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (101, ''KW'', ''';
wwv_flow_imp.g_varchar2_table(202) := 'Kuwait'', ''EMEA'', ''Y'', ''N'', 29.3390585728182, 47.5953428640136, ''KWT'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID,';
wwv_flow_imp.g_varchar2_table(203) := ' COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (102';
wwv_flow_imp.g_varchar2_table(204) := ', ''KG'', ''Kyrgyzstan'', ''EMEA'', ''Y'', ''N'', null, null, ''KGZ'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CO';
wwv_flow_imp.g_varchar2_table(205) := 'DE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (103, ''LA'', ''La';
wwv_flow_imp.g_varchar2_table(206) := 'os'', ''Asia Pacific'', ''Y'', ''N'', null, null, ''LAO'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNT';
wwv_flow_imp.g_varchar2_table(207) := 'RY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (104, ''LV'', ''Latvia'', ''E';
wwv_flow_imp.g_varchar2_table(208) := 'MEA'', ''Y'', ''N'', 56.8605748612679, 24.9167110690882, ''LVA'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CO';
wwv_flow_imp.g_varchar2_table(209) := 'DE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (105, ''LB'', ''Le';
wwv_flow_imp.g_varchar2_table(210) := 'banon'', ''EMEA'', ''Y'', ''N'', 33.9189311218277, 35.8775083865965, ''LBN'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, ';
wwv_flow_imp.g_varchar2_table(211) := 'COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (106,';
wwv_flow_imp.g_varchar2_table(212) := ' ''LS'', ''Lesotho'', ''EMEA'', ''Y'', ''N'', null, null, ''LSO'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, ';
wwv_flow_imp.g_varchar2_table(213) := 'COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (107, ''LR'', ''Liberi';
wwv_flow_imp.g_varchar2_table(214) := 'a'', ''EMEA'', ''Y'', ''N'', null, null, ''LBR'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, ';
wwv_flow_imp.g_varchar2_table(215) := 'REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (108, ''LY'', ''Libyan Arab Jamahiri';
wwv_flow_imp.g_varchar2_table(216) := 'ya'', ''EMEA'', ''Y'', ''N'', 27.0173636214085, 18.0652845251555, ''LBY'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COU';
wwv_flow_imp.g_varchar2_table(217) := 'NTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (109, ''L';
wwv_flow_imp.g_varchar2_table(218) := 'I'', ''Liechtenstein'', ''EMEA'', ''Y'', ''N'', null, null, ''LIE'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_COD';
wwv_flow_imp.g_varchar2_table(219) := 'E, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (110, ''LT'', ''Lit';
wwv_flow_imp.g_varchar2_table(220) := 'huania'', ''EMEA'', ''Y'', ''N'', 55.3247451169032, 23.8980884988308, ''LTU'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID,';
wwv_flow_imp.g_varchar2_table(221) := ' COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (111';
wwv_flow_imp.g_varchar2_table(222) := ', ''LU'', ''Luxembourg'', ''EMEA'', ''Y'', ''N'', 49.7663570584619, 6.0720991960439, ''LUX'');'||wwv_flow.LF||
'insert into SP_CO';
wwv_flow_imp.g_varchar2_table(223) := 'UNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3)';
wwv_flow_imp.g_varchar2_table(224) := ' values (112, ''MO'', ''Macau'', ''Asia Pacific'', ''Y'', ''N'', 22.1604025427249, 113.555599557989, ''MAC'');'||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(225) := 'nsert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON';
wwv_flow_imp.g_varchar2_table(226) := ', COUNTRY_CODE3) values (113, ''MK'', ''Macedonia'', ''EMEA'', ''Y'', ''N'', null, null, ''MKD'');'||wwv_flow.LF||
'insert into S';
wwv_flow_imp.g_varchar2_table(227) := 'P_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CO';
wwv_flow_imp.g_varchar2_table(228) := 'DE3) values (114, ''MG'', ''Madagascar'', ''EMEA'', ''Y'', ''N'', null, null, ''MDG'');'||wwv_flow.LF||
'insert into SP_COUNTRIES';
wwv_flow_imp.g_varchar2_table(229) := ' (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values';
wwv_flow_imp.g_varchar2_table(230) := ' (115, ''MW'', ''Malawi'', ''EMEA'', ''Y'', ''N'', null, null, ''MWI'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_C';
wwv_flow_imp.g_varchar2_table(231) := 'ODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (116, ''MY'', ''M';
wwv_flow_imp.g_varchar2_table(232) := 'alaysia'', ''Asia Pacific'', ''Y'', ''N'', 3.81262745268228, 109.704476286832, ''MYS'');'||wwv_flow.LF||
'insert into SP_COUNT';
wwv_flow_imp.g_varchar2_table(233) := 'RIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) va';
wwv_flow_imp.g_varchar2_table(234) := 'lues (117, ''MV'', ''Maldives'', ''Asia Pacific'', ''Y'', ''N'', null, null, ''MDV'');'||wwv_flow.LF||
'insert into SP_COUNTRIES ';
wwv_flow_imp.g_varchar2_table(235) := '(ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values ';
wwv_flow_imp.g_varchar2_table(236) := '(118, ''ML'', ''Mali'', ''EMEA'', ''Y'', ''N'', null, null, ''MLI'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE';
wwv_flow_imp.g_varchar2_table(237) := ', COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (119, ''MT'', ''Malt';
wwv_flow_imp.g_varchar2_table(238) := 'a'', ''EMEA'', ''Y'', ''N'', null, null, ''MLT'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, ';
wwv_flow_imp.g_varchar2_table(239) := 'REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (120, ''MQ'', ''Martinique'', ''North ';
wwv_flow_imp.g_varchar2_table(240) := 'America'', ''Y'', ''N'', null, null, ''MTQ'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, RE';
wwv_flow_imp.g_varchar2_table(241) := 'GION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (121, ''MR'', ''Mauritania'', ''EMEA'', ''';
wwv_flow_imp.g_varchar2_table(242) := 'Y'', ''N'', null, null, ''MRT'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPL';
wwv_flow_imp.g_varchar2_table(243) := 'AY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (122, ''MU'', ''Mauritius'', ''EMEA'', ''Y'', ''N'', -20';
wwv_flow_imp.g_varchar2_table(244) := '.1857973956282, 57.850751797212, ''MUS'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, R';
wwv_flow_imp.g_varchar2_table(245) := 'EGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (123, ''MX'', ''Mexico'', ''North Ameri';
wwv_flow_imp.g_varchar2_table(246) := 'ca'', ''Y'', ''Y'', 23.934601892696, -102.188323856767, ''MEX'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_COD';
wwv_flow_imp.g_varchar2_table(247) := 'E, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (124, ''MC'', ''Mon';
wwv_flow_imp.g_varchar2_table(248) := 'aco'', ''EMEA'', ''Y'', ''N'', null, null, ''MCO'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME';
wwv_flow_imp.g_varchar2_table(249) := ', REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (125, ''MN'', ''Mongolia'', ''Asia P';
wwv_flow_imp.g_varchar2_table(250) := 'acific'', ''Y'', ''N'', null, null, ''MNG'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REG';
wwv_flow_imp.g_varchar2_table(251) := 'ION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (126, ''ME'', ''Montenegro'', ''EMEA'', ''Y';
wwv_flow_imp.g_varchar2_table(252) := ''', ''N'', null, null, ''MNE'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLA';
wwv_flow_imp.g_varchar2_table(253) := 'Y_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (127, ''MA'', ''Morocco'', ''EMEA'', ''Y'', ''N'', 29.773';
wwv_flow_imp.g_varchar2_table(254) := '7368231434, -8.66420532956332, ''MAR'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REG';
wwv_flow_imp.g_varchar2_table(255) := 'ION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (128, ''MZ'', ''Mozambique'', ''EMEA'', ''Y';
wwv_flow_imp.g_varchar2_table(256) := ''', ''N'', null, null, ''MOZ'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLA';
wwv_flow_imp.g_varchar2_table(257) := 'Y_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (129, ''MM'', ''Myanmar'', ''Asia Pacific'', ''Y'', ''N''';
wwv_flow_imp.g_varchar2_table(258) := ', null, null, ''MMR'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, ';
wwv_flow_imp.g_varchar2_table(259) := 'QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (130, ''NA'', ''Namibia'', ''EMEA'', ''Y'', ''N'', null, null, ';
wwv_flow_imp.g_varchar2_table(260) := '''NAM'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN,';
wwv_flow_imp.g_varchar2_table(261) := ' LAT, LON, COUNTRY_CODE3) values (131, ''NP'', ''Nepal'', ''Asia Pacific'', ''Y'', ''N'', null, null, ''NPL'');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(262) := 'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LO';
wwv_flow_imp.g_varchar2_table(263) := 'N, COUNTRY_CODE3) values (132, ''NL'', ''Netherlands'', ''EMEA'', ''Y'', ''N'', 52.199145001095, 4.58034198309';
wwv_flow_imp.g_varchar2_table(264) := '38, ''NLD'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK';
wwv_flow_imp.g_varchar2_table(265) := '_YN, LAT, LON, COUNTRY_CODE3) values (133, ''AN'', ''Netherlands Antilles'', ''North America'', ''Y'', ''N'', ';
wwv_flow_imp.g_varchar2_table(266) := 'null, null, '''');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK';
wwv_flow_imp.g_varchar2_table(267) := '_PICK_YN, LAT, LON, COUNTRY_CODE3) values (134, ''NC'', ''New Caledonia'', ''Asia Pacific'', ''Y'', ''N'', nul';
wwv_flow_imp.g_varchar2_table(268) := 'l, null, ''NCL'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK';
wwv_flow_imp.g_varchar2_table(269) := '_PICK_YN, LAT, LON, COUNTRY_CODE3) values (135, ''NZ'', ''New Zealand'', ''Asia Pacific'', ''Y'', ''N'', -41.6';
wwv_flow_imp.g_varchar2_table(270) := '542404444822, 172.961752075767, ''NZL'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, RE';
wwv_flow_imp.g_varchar2_table(271) := 'GION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (136, ''NI'', ''Nicaragua'', ''North Ame';
wwv_flow_imp.g_varchar2_table(272) := 'rica'', ''Y'', ''N'', null, null, ''NIC'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGIO';
wwv_flow_imp.g_varchar2_table(273) := 'N, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (137, ''NE'', ''Niger'', ''EMEA'', ''Y'', ''N'',';
wwv_flow_imp.g_varchar2_table(274) := ' null, null, ''NER'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, Q';
wwv_flow_imp.g_varchar2_table(275) := 'UICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (138, ''NG'', ''Nigeria'', ''EMEA'', ''Y'', ''N'', 9.59100569493';
wwv_flow_imp.g_varchar2_table(276) := '586, 8.08315743469892, ''NGA'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DIS';
wwv_flow_imp.g_varchar2_table(277) := 'PLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (139, ''KP'', ''North Korea'', ''Asia Pacific'', ''';
wwv_flow_imp.g_varchar2_table(278) := 'Y'', ''N'', null, null, ''PRK'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPL';
wwv_flow_imp.g_varchar2_table(279) := 'AY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (140, ''NO'', ''Norway'', ''EMEA'', ''Y'', ''N'', 64.774';
wwv_flow_imp.g_varchar2_table(280) := '5889670849, 12.1397373014976, ''NOR'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGI';
wwv_flow_imp.g_varchar2_table(281) := 'ON, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (141, ''OM'', ''Oman'', ''EMEA'', ''Y'', ''N'',';
wwv_flow_imp.g_varchar2_table(282) := ' 20.585156386594, 56.0643275591226, ''OMN'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME';
wwv_flow_imp.g_varchar2_table(283) := ', REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (142, ''PK'', ''Pakistan'', ''Asia P';
wwv_flow_imp.g_varchar2_table(284) := 'acific'', ''Y'', ''N'', 29.8848480415832, 69.1722252971392, ''PAK'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY';
wwv_flow_imp.g_varchar2_table(285) := '_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (143, ''PS'', ';
wwv_flow_imp.g_varchar2_table(286) := '''Palestine'', ''EMEA'', ''Y'', ''N'', null, null, ''PSE'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNT';
wwv_flow_imp.g_varchar2_table(287) := 'RY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (144, ''PA'', ''Panama'', ''N';
wwv_flow_imp.g_varchar2_table(288) := 'orth America'', ''Y'', ''N'', null, null, ''PAN'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAM';
wwv_flow_imp.g_varchar2_table(289) := 'E, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (145, ''PG'', ''Papua New Guinea''';
wwv_flow_imp.g_varchar2_table(290) := ', ''Asia Pacific'', ''Y'', ''N'', null, null, ''PNG'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_';
wwv_flow_imp.g_varchar2_table(291) := 'NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (146, ''PY'', ''Paraguay'', ''So';
wwv_flow_imp.g_varchar2_table(292) := 'uth America'', ''Y'', ''N'', null, null, ''PRY'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME';
wwv_flow_imp.g_varchar2_table(293) := ', REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (147, ''PE'', ''Peru'', ''South Amer';
wwv_flow_imp.g_varchar2_table(294) := 'ica'', ''Y'', ''N'', -9.10985299364425, -74.4211662037691, ''PER'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_';
wwv_flow_imp.g_varchar2_table(295) := 'CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (148, ''PH'', ''';
wwv_flow_imp.g_varchar2_table(296) := 'Philippines'', ''Asia Pacific'', ''Y'', ''N'', 11.7253180109993, 122.903980724002, ''PHL'');'||wwv_flow.LF||
'insert into SP_C';
wwv_flow_imp.g_varchar2_table(297) := 'OUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3';
wwv_flow_imp.g_varchar2_table(298) := ') values (149, ''PL'', ''Poland'', ''EMEA'', ''Y'', ''N'', 52.1100009466317, 19.4252217465339, ''POL'');'||wwv_flow.LF||
'insert ';
wwv_flow_imp.g_varchar2_table(299) := 'into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUN';
wwv_flow_imp.g_varchar2_table(300) := 'TRY_CODE3) values (150, ''PT'', ''Portugal'', ''EMEA'', ''Y'', ''N'', 39.5996085377487, -8.63556904373474, ''PR';
wwv_flow_imp.g_varchar2_table(301) := 'T'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LA';
wwv_flow_imp.g_varchar2_table(302) := 'T, LON, COUNTRY_CODE3) values (151, ''PR'', ''Puerto Rico'', ''North America'', ''Y'', ''N'', 18.2242458704844';
wwv_flow_imp.g_varchar2_table(303) := ', -66.4676018452658, ''PRI'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPL';
wwv_flow_imp.g_varchar2_table(304) := 'AY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (152, ''QA'', ''Qatar'', ''EMEA'', ''Y'', ''N'', 25.3119';
wwv_flow_imp.g_varchar2_table(305) := '459175758, 51.1866764830129, ''QAT'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGIO';
wwv_flow_imp.g_varchar2_table(306) := 'N, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (153, ''RE'', ''Reunion'', ''EMEA'', ''Y'', ''N';
wwv_flow_imp.g_varchar2_table(307) := ''', null, null, ''REU'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN,';
wwv_flow_imp.g_varchar2_table(308) := ' QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (154, ''RO'', ''Romania'', ''EMEA'', ''Y'', ''N'', 45.84998056';
wwv_flow_imp.g_varchar2_table(309) := '7324, 24.9831513397535, ''ROU'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DI';
wwv_flow_imp.g_varchar2_table(310) := 'SPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (155, ''RU'', ''Russia'', ''EMEA'', ''Y'', ''N'', 66.';
wwv_flow_imp.g_varchar2_table(311) := '296506322509, 95.8772843432938, ''RUS'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, RE';
wwv_flow_imp.g_varchar2_table(312) := 'GION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (156, ''RW'', ''Rwanda'', ''EMEA'', ''Y'', ';
wwv_flow_imp.g_varchar2_table(313) := '''N'', null, null, ''RWA'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_Y';
wwv_flow_imp.g_varchar2_table(314) := 'N, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (157, ''ST'', ''Sao Tome and Principe'', ''EMEA'', ''Y'', ';
wwv_flow_imp.g_varchar2_table(315) := '''N'', null, null, ''STP'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_Y';
wwv_flow_imp.g_varchar2_table(316) := 'N, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (158, ''SA'', ''Saudi Arabia'', ''EMEA'', ''Y'', ''N'', 24.0';
wwv_flow_imp.g_varchar2_table(317) := '911030338015, 44.666975315864, ''SAU'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REG';
wwv_flow_imp.g_varchar2_table(318) := 'ION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (159, ''SN'', ''Senegal'', ''EMEA'', ''Y'', ';
wwv_flow_imp.g_varchar2_table(319) := '''N'', 14.3667239515782, -14.4673427052342, ''SEN'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTR';
wwv_flow_imp.g_varchar2_table(320) := 'Y_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (160, ''RS'', ''Serbia'', ''EM';
wwv_flow_imp.g_varchar2_table(321) := 'EA'', ''Y'', ''N'', 44.2114387597226, 20.8073008517722, ''SRB'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_COD';
wwv_flow_imp.g_varchar2_table(322) := 'E, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (161, ''SC'', ''Sey';
wwv_flow_imp.g_varchar2_table(323) := 'chelles'', ''EMEA'', ''Y'', ''N'', null, null, ''SYC'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_';
wwv_flow_imp.g_varchar2_table(324) := 'NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (162, ''SL'', ''Sierra Leone'',';
wwv_flow_imp.g_varchar2_table(325) := ' ''EMEA'', ''Y'', ''N'', null, null, ''SLE'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REG';
wwv_flow_imp.g_varchar2_table(326) := 'ION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (163, ''SG'', ''Singapore'', ''Asia Pacif';
wwv_flow_imp.g_varchar2_table(327) := 'ic'', ''Y'', ''N'', 1.35892187535271, 103.81346764985, ''SGP'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE';
wwv_flow_imp.g_varchar2_table(328) := ', COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (164, ''SK'', ''Slov';
wwv_flow_imp.g_varchar2_table(329) := 'akia'', ''EMEA'', ''Y'', ''N'', 48.7108056163336, 19.4703672420141, ''SVK'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, C';
wwv_flow_imp.g_varchar2_table(330) := 'OUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (165, ';
wwv_flow_imp.g_varchar2_table(331) := '''SI'', ''Slovenia'', ''EMEA'', ''Y'', ''N'', 46.1164702078935, 14.8041784046189, ''SVN'');'||wwv_flow.LF||
'insert into SP_COUNT';
wwv_flow_imp.g_varchar2_table(332) := 'RIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) va';
wwv_flow_imp.g_varchar2_table(333) := 'lues (166, ''SO'', ''Somalia'', ''EMEA'', ''Y'', ''N'', null, null, ''SOM'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUN';
wwv_flow_imp.g_varchar2_table(334) := 'TRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (167, ''ZA';
wwv_flow_imp.g_varchar2_table(335) := ''', ''South Africa'', ''EMEA'', ''Y'', ''N'', -29.0109136114449, 25.1997255202127, ''ZAF'');'||wwv_flow.LF||
'insert into SP_COU';
wwv_flow_imp.g_varchar2_table(336) := 'NTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) ';
wwv_flow_imp.g_varchar2_table(337) := 'values (168, ''ES'', ''Spain'', ''EMEA'', ''Y'', ''N'', 40.1816336827982, -3.72112968155382, ''ESP'');'||wwv_flow.LF||
'insert in';
wwv_flow_imp.g_varchar2_table(338) := 'to SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTR';
wwv_flow_imp.g_varchar2_table(339) := 'Y_CODE3) values (169, ''LK'', ''Sri Lanka'', ''Asia Pacific'', ''Y'', ''N'', 7.61439796471554, 80.703730353103';
wwv_flow_imp.g_varchar2_table(340) := '6, ''LKA'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_';
wwv_flow_imp.g_varchar2_table(341) := 'YN, LAT, LON, COUNTRY_CODE3) values (170, ''SR'', ''Suriname'', ''South America'', ''Y'', ''N'', null, null, ''';
wwv_flow_imp.g_varchar2_table(342) := 'SUR'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, ';
wwv_flow_imp.g_varchar2_table(343) := 'LAT, LON, COUNTRY_CODE3) values (171, ''SZ'', ''Swaziland'', ''EMEA'', ''Y'', ''N'', null, null, ''SWZ'');'||wwv_flow.LF||
'inser';
wwv_flow_imp.g_varchar2_table(344) := 't into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, CO';
wwv_flow_imp.g_varchar2_table(345) := 'UNTRY_CODE3) values (172, ''SE'', ''Sweden'', ''EMEA'', ''Y'', ''N'', 62.3829414476636, 16.2787691655521, ''SWE';
wwv_flow_imp.g_varchar2_table(346) := ''');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT';
wwv_flow_imp.g_varchar2_table(347) := ', LON, COUNTRY_CODE3) values (173, ''CH'', ''Switzerland'', ''EMEA'', ''Y'', ''N'', 46.7999696363917, 8.212872';
wwv_flow_imp.g_varchar2_table(348) := '95709836, ''CHE'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUIC';
wwv_flow_imp.g_varchar2_table(349) := 'K_PICK_YN, LAT, LON, COUNTRY_CODE3) values (174, ''TW'', ''Taiwan'', ''Asia Pacific'', ''Y'', ''N'', 23.749272';
wwv_flow_imp.g_varchar2_table(350) := '8197723, 120.947106156346, ''TWN'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION,';
wwv_flow_imp.g_varchar2_table(351) := ' DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (175, ''TJ'', ''Tajikistan'', ''EMEA'', ''Y'', ''';
wwv_flow_imp.g_varchar2_table(352) := 'N'', null, null, ''TJK'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN';
wwv_flow_imp.g_varchar2_table(353) := ', QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (176, ''TZ'', ''Tanzania'', ''EMEA'', ''Y'', ''N'', null, nul';
wwv_flow_imp.g_varchar2_table(354) := 'l, ''TZA'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_';
wwv_flow_imp.g_varchar2_table(355) := 'YN, LAT, LON, COUNTRY_CODE3) values (177, ''TH'', ''Thailand'', ''Asia Pacific'', ''Y'', ''N'', 15.07467822659';
wwv_flow_imp.g_varchar2_table(356) := '49, 101.002713288589, ''THA'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISP';
wwv_flow_imp.g_varchar2_table(357) := 'LAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (178, ''TL'', ''Timor Leste'', ''Asia Pacific'', ''Y';
wwv_flow_imp.g_varchar2_table(358) := ''', ''N'', null, null, ''TLS'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLA';
wwv_flow_imp.g_varchar2_table(359) := 'Y_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (179, ''TG'', ''Togo'', ''EMEA'', ''Y'', ''N'', null, nul';
wwv_flow_imp.g_varchar2_table(360) := 'l, ''TGO'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_';
wwv_flow_imp.g_varchar2_table(361) := 'YN, LAT, LON, COUNTRY_CODE3) values (180, ''TT'', ''Trinidad and Tobago'', ''North America'', ''Y'', ''N'', nu';
wwv_flow_imp.g_varchar2_table(362) := 'll, null, ''TTO'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUIC';
wwv_flow_imp.g_varchar2_table(363) := 'K_PICK_YN, LAT, LON, COUNTRY_CODE3) values (181, ''TN'', ''Tunisia'', ''EMEA'', ''Y'', ''N'', null, null, ''TUN';
wwv_flow_imp.g_varchar2_table(364) := ''');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT';
wwv_flow_imp.g_varchar2_table(365) := ', LON, COUNTRY_CODE3) values (182, ''TR'', ''Turkey'', ''EMEA'', ''Y'', ''N'', 39.137265788256, 35.17175030837';
wwv_flow_imp.g_varchar2_table(366) := '75, ''TUR'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK';
wwv_flow_imp.g_varchar2_table(367) := '_YN, LAT, LON, COUNTRY_CODE3) values (183, ''UG'', ''Uganda'', ''EMEA'', ''Y'', ''N'', null, null, ''UGA'');'||wwv_flow.LF||
'ins';
wwv_flow_imp.g_varchar2_table(368) := 'ert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, ';
wwv_flow_imp.g_varchar2_table(369) := 'COUNTRY_CODE3) values (184, ''UA'', ''Ukraine'', ''EMEA'', ''Y'', ''N'', 49.0232495291592, 31.4648092208537, ''';
wwv_flow_imp.g_varchar2_table(370) := 'UKR'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, ';
wwv_flow_imp.g_varchar2_table(371) := 'LAT, LON, COUNTRY_CODE3) values (185, ''AE'', ''United Arab Emirates'', ''EMEA'', ''Y'', ''N'', 23.90601099636';
wwv_flow_imp.g_varchar2_table(372) := '45, 54.2933528390184, ''ARE'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISP';
wwv_flow_imp.g_varchar2_table(373) := 'LAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (186, ''GB'', ''United Kingdom'', ''EMEA'', ''Y'', ''Y';
wwv_flow_imp.g_varchar2_table(374) := ''', 54.0387673071189, -2.78272189148275, ''GBR'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_';
wwv_flow_imp.g_varchar2_table(375) := 'NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (187, ''US'', ''United States''';
wwv_flow_imp.g_varchar2_table(376) := ', ''North America'', ''Y'', ''Y'', 37.1, -95.7, ''USA'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTR';
wwv_flow_imp.g_varchar2_table(377) := 'Y_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (188, ''UY'', ''Uruguay'', ''S';
wwv_flow_imp.g_varchar2_table(378) := 'outh America'', ''Y'', ''N'', null, null, ''URY'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAM';
wwv_flow_imp.g_varchar2_table(379) := 'E, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (189, ''UZ'', ''Uzbekistan'', ''EME';
wwv_flow_imp.g_varchar2_table(380) := 'A'', ''Y'', ''N'', null, null, ''UZB'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, ';
wwv_flow_imp.g_varchar2_table(381) := 'DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (190, ''VE'', ''Venezuela'', ''South America'',';
wwv_flow_imp.g_varchar2_table(382) := ' ''Y'', ''N'', 7.13090263242316, -66.1594861155562, ''VEN'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, ';
wwv_flow_imp.g_varchar2_table(383) := 'COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (191, ''VN'', ''Vietna';
wwv_flow_imp.g_varchar2_table(384) := 'm'', ''Asia Pacific'', ''Y'', ''N'', 16.5394021305517, 106.347176042478, ''VNM'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (';
wwv_flow_imp.g_varchar2_table(385) := 'ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (';
wwv_flow_imp.g_varchar2_table(386) := '192, ''VG'', ''Virgin Islands, British'', ''North America'', ''Y'', ''N'', null, null, ''VGB'');'||wwv_flow.LF||
'insert into SP_';
wwv_flow_imp.g_varchar2_table(387) := 'COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE';
wwv_flow_imp.g_varchar2_table(388) := '3) values (193, ''VI'', ''Virgin Islands, U.S.'', ''North America'', ''Y'', ''N'', null, null, ''VIR'');'||wwv_flow.LF||
'insert ';
wwv_flow_imp.g_varchar2_table(389) := 'into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUN';
wwv_flow_imp.g_varchar2_table(390) := 'TRY_CODE3) values (194, ''EH'', ''Western Sahara'', ''EMEA'', ''Y'', ''N'', null, null, ''ESH'');'||wwv_flow.LF||
'insert into SP';
wwv_flow_imp.g_varchar2_table(391) := '_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_COD';
wwv_flow_imp.g_varchar2_table(392) := 'E3) values (195, ''YE'', ''Yemen'', ''EMEA'', ''Y'', ''N'', null, null, ''YEM'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, ';
wwv_flow_imp.g_varchar2_table(393) := 'COUNTRY_CODE, COUNTRY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (196,';
wwv_flow_imp.g_varchar2_table(394) := ' ''ZR'', ''Zaire'', ''EMEA'', ''Y'', ''N'', null, null, '''');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNT';
wwv_flow_imp.g_varchar2_table(395) := 'RY_NAME, REGION, DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (197, ''ZM'', ''Zambia'', ''E';
wwv_flow_imp.g_varchar2_table(396) := 'MEA'', ''Y'', ''N'', null, null, ''ZMB'');'||wwv_flow.LF||
'insert into SP_COUNTRIES (ID, COUNTRY_CODE, COUNTRY_NAME, REGION';
wwv_flow_imp.g_varchar2_table(397) := ', DISPLAY_YN, QUICK_PICK_YN, LAT, LON, COUNTRY_CODE3) values (198, ''ZW'', ''Zimbabwe'', ''EMEA'', ''Y'', ''N';
wwv_flow_imp.g_varchar2_table(398) := ''', null, null, ''ZWE'');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(37356206943941807274)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed countries'
,p_sequence=>770
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
