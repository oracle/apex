prompt --application/deployment/install/install_project_task_tables
begin
--   Manifest
--     INSTALL: INSTALL-Project Task tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- recursive but allowed only one level deep via application'||wwv_flow.LF||
'create table sp_task_types ('||wwv_flow.LF||
'    id    ';
wwv_flow_imp.g_varchar2_table(2) := '                         number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(3) := 'XXX'') '||wwv_flow.LF||
'                                   constraint sp_task_types_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    task_t';
wwv_flow_imp.g_varchar2_table(4) := 'ype                      varchar2(100 char) not null,'||wwv_flow.LF||
'    static_id                      varchar2(30';
wwv_flow_imp.g_varchar2_table(5) := ' char),'||wwv_flow.LF||
'    description                    varchar2(4000 char),'||wwv_flow.LF||
'    display_seq                    n';
wwv_flow_imp.g_varchar2_table(6) := 'umber,'||wwv_flow.LF||
'    include_yn                     varchar2(1 char) '||wwv_flow.LF||
'                                   defau';
wwv_flow_imp.g_varchar2_table(7) := 'lt on null ''Y'''||wwv_flow.LF||
'                                   constraint sp_task_types_include_ck '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(8) := '                      check (include_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    task_name_req_yn               varchar2(1';
wwv_flow_imp.g_varchar2_table(9) := ' char) '||wwv_flow.LF||
'                                   default on null ''N'''||wwv_flow.LF||
'                                   co';
wwv_flow_imp.g_varchar2_table(10) := 'nstraint sp_task_types_task_name_req_ck '||wwv_flow.LF||
'                                   check (task_name_req_yn ';
wwv_flow_imp.g_varchar2_table(11) := 'in (''Y'',''N'')),'||wwv_flow.LF||
'    parent_type_id                 number'||wwv_flow.LF||
'                                   constrai';
wwv_flow_imp.g_varchar2_table(12) := 'nt sp_tasks_type_parent_fk'||wwv_flow.LF||
'                                   references sp_task_types on delete set';
wwv_flow_imp.g_varchar2_table(13) := ' null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by                     v';
wwv_flow_imp.g_varchar2_table(14) := 'archar2(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by        ';
wwv_flow_imp.g_varchar2_table(15) := '             varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index sp_task_types_u1 on sp_task_types (';
wwv_flow_imp.g_varchar2_table(16) := 'parent_type_id,task_type);'||wwv_flow.LF||
'create unique index sp_task_types_u2 on sp_task_types (static_id);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'crea';
wwv_flow_imp.g_varchar2_table(17) := 'te table sp_initiative_default_tasks ('||wwv_flow.LF||
'    id                             number default on null to_';
wwv_flow_imp.g_varchar2_table(18) := 'number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constrain';
wwv_flow_imp.g_varchar2_table(19) := 't sp_ini_def_tasks_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    initiative_id                  number  not null'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(20) := '                             constraint sp_ini_def_tasks_ini_fk'||wwv_flow.LF||
'                                   r';
wwv_flow_imp.g_varchar2_table(21) := 'eferences sp_initiatives on delete cascade,'||wwv_flow.LF||
'    type_id                        number  not null'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(22) := '                               constraint sp_ini_def_tasks_task_fk'||wwv_flow.LF||
'                                 ';
wwv_flow_imp.g_varchar2_table(23) := '  references sp_task_types on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not nul';
wwv_flow_imp.g_varchar2_table(24) := 'l,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                      ';
wwv_flow_imp.g_varchar2_table(25) := '  date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique in';
wwv_flow_imp.g_varchar2_table(26) := 'dex sp_initiative_default_tasks_u1 on sp_initiative_default_tasks (initiative_id, type_id);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create';
wwv_flow_imp.g_varchar2_table(27) := ' table sp_task_statuses ('||wwv_flow.LF||
'    id                             number default on null to_number(sys_gu';
wwv_flow_imp.g_varchar2_table(28) := 'id(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_task_sta';
wwv_flow_imp.g_varchar2_table(29) := 'tuses_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    task_type_id                   number not null'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(30) := '               constraint sp_task_statuses_type_fk'||wwv_flow.LF||
'                                   references sp_';
wwv_flow_imp.g_varchar2_table(31) := 'task_types,'||wwv_flow.LF||
'    status                         varchar2(100 char) not null,'||wwv_flow.LF||
'    static_id           ';
wwv_flow_imp.g_varchar2_table(32) := '           varchar2(30 char)  not null,'||wwv_flow.LF||
'    display_seq                    number,'||wwv_flow.LF||
'    include_yn   ';
wwv_flow_imp.g_varchar2_table(33) := '                  varchar2(1 char) '||wwv_flow.LF||
'                                   default on null ''Y'''||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(34) := '                          constraint sp_task_statuses_include_ck '||wwv_flow.LF||
'                                  ';
wwv_flow_imp.g_varchar2_table(35) := ' check (include_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    is_default_yn                  varchar2(1 char) '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(36) := '                      default on null ''N'''||wwv_flow.LF||
'                                   constraint sp_task_stat';
wwv_flow_imp.g_varchar2_table(37) := 'uses_default_ck '||wwv_flow.LF||
'                                   check (is_default_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    indicate';
wwv_flow_imp.g_varchar2_table(38) := 's_complete_yn          varchar2(1 char) '||wwv_flow.LF||
'                                   default on null ''N'''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(39) := '                               constraint sp_task_statuses_ind_complete_ck '||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(40) := '           check (indicates_complete_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        dat';
wwv_flow_imp.g_varchar2_table(41) := 'e not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated             ';
wwv_flow_imp.g_varchar2_table(42) := '           date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create ';
wwv_flow_imp.g_varchar2_table(43) := 'unique index sp_task_statuses_u1 on sp_task_statuses (task_type_id,status);'||wwv_flow.LF||
'create unique index sp_t';
wwv_flow_imp.g_varchar2_table(44) := 'ask_statuses_u2 on sp_task_statuses (task_type_id,static_id);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_tasks ('||wwv_flow.LF||
'    id      ';
wwv_flow_imp.g_varchar2_table(45) := '                       number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(46) := 'X'') '||wwv_flow.LF||
'                                   constraint sp_tasks_id_pk primary key,'||wwv_flow.LF||
'    project_id       ';
wwv_flow_imp.g_varchar2_table(47) := '              number not null'||wwv_flow.LF||
'                                   constraint sp_tasks_project_fk'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(48) := '                               references sp_projects on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    task            ';
wwv_flow_imp.g_varchar2_table(49) := '               varchar2(255 char),'||wwv_flow.LF||
'    task_type_id                   number not null'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(50) := '                     constraint sp_tasks_type_fk'||wwv_flow.LF||
'                                   references sp_ta';
wwv_flow_imp.g_varchar2_table(51) := 'sk_types,'||wwv_flow.LF||
'    task_sub_type_id               number'||wwv_flow.LF||
'                                   constraint sp';
wwv_flow_imp.g_varchar2_table(52) := '_tasks_sub_type_fk'||wwv_flow.LF||
'                                   references sp_task_types,'||wwv_flow.LF||
'    owner_id        ';
wwv_flow_imp.g_varchar2_table(53) := '               number'||wwv_flow.LF||
'                                   constraint sp_tasks_owner_fk'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(54) := '                     references sp_team_members,'||wwv_flow.LF||
'    start_date                     date,'||wwv_flow.LF||
'    target';
wwv_flow_imp.g_varchar2_table(55) := '_complete                date,   '||wwv_flow.LF||
'    status_id                      number not null'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(56) := '                    constraint sp_tasks_status_fk'||wwv_flow.LF||
'                                   references sp_t';
wwv_flow_imp.g_varchar2_table(57) := 'ask_statuses,   '||wwv_flow.LF||
'    status_last_changed_on         date,         '||wwv_flow.LF||
'    description                  ';
wwv_flow_imp.g_varchar2_table(58) := '  varchar2(4000 char),'||wwv_flow.LF||
'    tags                           varchar2(4000 char),'||wwv_flow.LF||
'    -- impact current';
wwv_flow_imp.g_varchar2_table(59) := 'ly just used for Reviews'||wwv_flow.LF||
'    impact                         varchar2(30 char)  '||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(60) := '               constraint sp_task_impact_cc'||wwv_flow.LF||
'                                   check (impact in (''No';
wwv_flow_imp.g_varchar2_table(61) := 't Identified'',''None'',''Low'',''Medium'',''High'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- Standard auditing columns'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    cre';
wwv_flow_imp.g_varchar2_table(62) := 'ated                        date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not';
wwv_flow_imp.g_varchar2_table(63) := ' null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by                     varchar2';
wwv_flow_imp.g_varchar2_table(64) := '(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_tasks_i1 on sp_tasks (project_id);'||wwv_flow.LF||
'create index sp_tasks_i2 ';
wwv_flow_imp.g_varchar2_table(65) := 'on sp_tasks (task_type_id);'||wwv_flow.LF||
'create index sp_tasks_i3 on sp_tasks (task_sub_type_id);'||wwv_flow.LF||
'create index sp';
wwv_flow_imp.g_varchar2_table(66) := '_tasks_i4 on sp_tasks (owner_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_task_history ('||wwv_flow.LF||
'    id                            ';
wwv_flow_imp.g_varchar2_table(67) := ' number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(68) := '                  constraint sp_task_history_pk primary key,'||wwv_flow.LF||
'    task_id                        numb';
wwv_flow_imp.g_varchar2_table(69) := 'er  not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    attribute_column               varchar2(255 char) not null, '||wwv_flow.LF||
'    change_typ';
wwv_flow_imp.g_varchar2_table(70) := 'e                    varchar2(30 char)  not null'||wwv_flow.LF||
'                                   constraint sp_ta';
wwv_flow_imp.g_varchar2_table(71) := 'sk_history_type_cc '||wwv_flow.LF||
'                                   check (change_type in (''CREATE'',''UPDATE'',''DEL';
wwv_flow_imp.g_varchar2_table(72) := 'ETE'')),'||wwv_flow.LF||
'    old_value                      varchar2(4000 char),'||wwv_flow.LF||
'    new_value                      v';
wwv_flow_imp.g_varchar2_table(73) := 'archar2(4000 char),'||wwv_flow.LF||
'    old_value_clob                 clob,'||wwv_flow.LF||
'    new_value_clob                 clob';
wwv_flow_imp.g_varchar2_table(74) := ','||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    changed_on                     date  not null,'||wwv_flow.LF||
'    changed_by                     varch';
wwv_flow_imp.g_varchar2_table(75) := 'ar2(255 char)'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_task_history_i1 on sp_task_history (task_id);'||wwv_flow.LF||
'create index sp_task';
wwv_flow_imp.g_varchar2_table(76) := '_history_i2 on sp_task_history (changed_by);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_task_links ('||wwv_flow.LF||
'    id                  ';
wwv_flow_imp.g_varchar2_table(77) := '           number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(78) := '                            constraint sp_task_links_pk primary key,'||wwv_flow.LF||
'    task_id                    ';
wwv_flow_imp.g_varchar2_table(79) := '    number  not null'||wwv_flow.LF||
'                                   constraint sp_task_links_fk'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(80) := '                   references sp_tasks on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    link_name                      ';
wwv_flow_imp.g_varchar2_table(81) := 'varchar2(255 char)   not null,'||wwv_flow.LF||
'    link_url                       varchar2(4000 char) not null,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(82) := 'important_yn                   varchar2(1 char) default on null ''N'''||wwv_flow.LF||
'                                ';
wwv_flow_imp.g_varchar2_table(83) := '   constraint sp_task_links_imp_ck'||wwv_flow.LF||
'                                   check (important_yn in (''Y'',''N';
wwv_flow_imp.g_varchar2_table(84) := ''')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by                     var';
wwv_flow_imp.g_varchar2_table(85) := 'char2(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by          ';
wwv_flow_imp.g_varchar2_table(86) := '           varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_task_links_i1 on sp_task_links (task_id);';
wwv_flow_imp.g_varchar2_table(87) := ''||wwv_flow.LF||
'create index sp_task_links_i2 on sp_task_links (updated);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_task_documents ('||wwv_flow.LF||
'    id';
wwv_flow_imp.g_varchar2_table(88) := '                             number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(89) := 'XXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_task_documents_pk primary key,'||wwv_flow.LF||
'    task_';
wwv_flow_imp.g_varchar2_table(90) := 'id                        number  not null'||wwv_flow.LF||
'                                   constraint sp_task_doc';
wwv_flow_imp.g_varchar2_table(91) := 'ument_fk'||wwv_flow.LF||
'                                   references sp_tasks on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    docume';
wwv_flow_imp.g_varchar2_table(92) := 'nt_blob                  blob,'||wwv_flow.LF||
'    document_filename              varchar2(512 char),'||wwv_flow.LF||
'    document_m';
wwv_flow_imp.g_varchar2_table(93) := 'imetype              varchar2(512 char),'||wwv_flow.LF||
'    document_charset               varchar2(512 char),'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(94) := 'document_lastupd               date,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    important_yn                   varchar2(1 char),'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(95) := ' doc_description                varchar2(4000 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    tags                           varch';
wwv_flow_imp.g_varchar2_table(96) := 'ar2(4000 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by             ';
wwv_flow_imp.g_varchar2_table(97) := '        varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_b';
wwv_flow_imp.g_varchar2_table(98) := 'y                     varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_task_documents_i1 on sp_task_d';
wwv_flow_imp.g_varchar2_table(99) := 'ocuments (task_id);'||wwv_flow.LF||
'create index sp_task_documents_i2 on sp_task_documents (updated);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table';
wwv_flow_imp.g_varchar2_table(100) := ' sp_task_comments ('||wwv_flow.LF||
'    id                             number default on null to_number(sys_guid(), ';
wwv_flow_imp.g_varchar2_table(101) := '''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_task_comments_';
wwv_flow_imp.g_varchar2_table(102) := 'pk primary key,'||wwv_flow.LF||
'    task_id                        number  not null'||wwv_flow.LF||
'                                ';
wwv_flow_imp.g_varchar2_table(103) := '   constraint sp_task_comments_task_fk'||wwv_flow.LF||
'                                   references sp_tasks on del';
wwv_flow_imp.g_varchar2_table(104) := 'ete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    body                           clob,'||wwv_flow.LF||
'    body_html                      clob';
wwv_flow_imp.g_varchar2_table(105) := ','||wwv_flow.LF||
'    body_no_images                 clob,'||wwv_flow.LF||
'    image_ref_id                   number,'||wwv_flow.LF||
'    author_id ';
wwv_flow_imp.g_varchar2_table(106) := '                     number,'||wwv_flow.LF||
'    private_yn                     varchar2(1 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created';
wwv_flow_imp.g_varchar2_table(107) := '                        date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not nul';
wwv_flow_imp.g_varchar2_table(108) := 'l,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255';
wwv_flow_imp.g_varchar2_table(109) := ' char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_task_comments_i1 on sp_task_comments (task_id);'||wwv_flow.LF||
'create index sp_';
wwv_flow_imp.g_varchar2_table(110) := 'task_comments_i2 on sp_task_comments (author_id);'||wwv_flow.LF||
'create index sp_task_comments_i3 on sp_task_commen';
wwv_flow_imp.g_varchar2_table(111) := 'ts (image_ref_id);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38218165634431996391)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'Project Task tables'
,p_sequence=>710
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
