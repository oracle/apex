prompt --application/deployment/install/install_initiative_documents_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-initiative_documents table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_initiative_documents ('||wwv_flow.LF||
'    id                             number default on null to_';
wwv_flow_imp.g_varchar2_table(2) := 'number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constrain';
wwv_flow_imp.g_varchar2_table(3) := 't sp_initiative_documents_pk primary key,'||wwv_flow.LF||
'    initiative_id                     number'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(4) := '                      constraint sp_initiative_doc_ini_id_fk'||wwv_flow.LF||
'                                   refe';
wwv_flow_imp.g_varchar2_table(5) := 'rences sp_initiatives on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    document_blob                  blob,'||wwv_flow.LF||
'    documen';
wwv_flow_imp.g_varchar2_table(6) := 't_filename              varchar2(512 char),'||wwv_flow.LF||
'    document_mimetype              varchar2(512 char),'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(7) := '   document_charset               varchar2(512 char),'||wwv_flow.LF||
'    document_lastupd               date,'||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(8) := '-'||wwv_flow.LF||
'    important_yn                   varchar2(1 char),'||wwv_flow.LF||
'    doc_description                varchar2(4';
wwv_flow_imp.g_varchar2_table(9) := '000 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    tags                           varchar2(4000 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created        ';
wwv_flow_imp.g_varchar2_table(10) := '                date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    u';
wwv_flow_imp.g_varchar2_table(11) := 'pdated                        date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) n';
wwv_flow_imp.g_varchar2_table(12) := 'ot null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_initiative_documents_i1 on sp_initiative_documents (initiative_id);'||wwv_flow.LF||
'cre';
wwv_flow_imp.g_varchar2_table(13) := 'ate index sp_initiative_documents_i2 on sp_initiative_documents (updated);'||wwv_flow.LF||
''||wwv_flow.LF||
'	'||wwv_flow.LF||
'create or replace trig';
wwv_flow_imp.g_varchar2_table(14) := 'ger sp_initiative_documents_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_initiative_documents'||wwv_flow.LF||
'    for e';
wwv_flow_imp.g_varchar2_table(15) := 'ach row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_tags varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created ';
wwv_flow_imp.g_varchar2_table(16) := ':= sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    en';
wwv_flow_imp.g_varchar2_table(17) := 'd if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_U';
wwv_flow_imp.g_varchar2_table(18) := 'SER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.tags := upper(:new.tags);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent tabl';
wwv_flow_imp.g_varchar2_table(19) := 'e'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_initiatives set updated = sysdate, updated_by = :new.updated_by where id = :n';
wwv_flow_imp.g_varchar2_table(20) := 'ew.initiative_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- adjust tag data'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.tags is not null then'||wwv_flow.LF||
'        l_t';
wwv_flow_imp.g_varchar2_table(21) := 'ags := trim(upper(:new.tags));'||wwv_flow.LF||
'        -- remove multiple spaces'||wwv_flow.LF||
'        if instr(l_tags,''  '') > 0 t';
wwv_flow_imp.g_varchar2_table(22) := 'hen'||wwv_flow.LF||
'            for j in 1..10 loop '||wwv_flow.LF||
'                l_tags := replace(l_tags,''  '','' ''); '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(23) := '      if instr(l_tags,''  '') = 0 then'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            en';
wwv_flow_imp.g_varchar2_table(24) := 'd loop; '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        for i in 1..length(l_tags) loop'||wwv_flow.LF||
'            if i > 2 and substr(l_t';
wwv_flow_imp.g_varchar2_table(25) := 'ags,i,1) = '' '' and substr(l_tags,i-1,1) != '','' then'||wwv_flow.LF||
'               l_tags := substr(l_tags,1,i-1)||''';
wwv_flow_imp.g_varchar2_table(26) := '-''||substr(l_tags,i+1);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        :new.tags := l_tags;'||wwv_flow.LF||
'   end if';
wwv_flow_imp.g_varchar2_table(27) := ';'||wwv_flow.LF||
'end sp_initiative_documents_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(52335537571388741597)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'initiative_documents table and trigger'
,p_sequence=>700
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
