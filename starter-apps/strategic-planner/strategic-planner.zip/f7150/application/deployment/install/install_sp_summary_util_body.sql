prompt --application/deployment/install/install_sp_summary_util_body
begin
--   Manifest
--     INSTALL: INSTALL-sp_summary_util body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body sp_summary_util as'||wwv_flow.LF||
''||wwv_flow.LF||
'-- will enhance as necessary, escaping all markdo';
wwv_flow_imp.g_varchar2_table(2) := 'wn results in unreadable content'||wwv_flow.LF||
'function escape_markdown ('||wwv_flow.LF||
'    p_markdown  in  clob'||wwv_flow.LF||
') return clob'||wwv_flow.LF||
'I';
wwv_flow_imp.g_varchar2_table(3) := 'S'||wwv_flow.LF||
'    v_output  clob;'||wwv_flow.LF||
'BEGIN'||wwv_flow.LF||
'    v_output := p_markdown;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if v_output is null then'||wwv_flow.LF||
'        return';
wwv_flow_imp.g_varchar2_table(4) := ' null;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    v_output := REPLACE(v_output, ''`'', ''\`'');      -- Code'||wwv_flow.LF||
'/*'||wwv_flow.LF||
'    -- Escape back';
wwv_flow_imp.g_varchar2_table(5) := 'slash FIRST to avoid double-escaping'||wwv_flow.LF||
'    v_output := REPLACE(v_output, ''\'', ''\\'');'||wwv_flow.LF||
'    -- Escape mar';
wwv_flow_imp.g_varchar2_table(6) := 'kdown special characters'||wwv_flow.LF||
'    v_output := REPLACE(v_output, ''*'', ''\*'');      -- Bold/Italic'||wwv_flow.LF||
'    v_out';
wwv_flow_imp.g_varchar2_table(7) := 'put := REPLACE(v_output, ''_'', ''\_'');      -- Italic/Bold'||wwv_flow.LF||
'    v_output := REPLACE(v_output, ''#'', ''\#''';
wwv_flow_imp.g_varchar2_table(8) := ');      -- Headers'||wwv_flow.LF||
'    v_output := REPLACE(v_output, ''['', ''\['');      -- Links/Images'||wwv_flow.LF||
'    v_output :';
wwv_flow_imp.g_varchar2_table(9) := '= REPLACE(v_output, '']'', ''\]'');      -- Links/Images'||wwv_flow.LF||
'    v_output := REPLACE(v_output, ''('', ''\('');  ';
wwv_flow_imp.g_varchar2_table(10) := '    -- Links/Images'||wwv_flow.LF||
'    v_output := REPLACE(v_output, '')'', ''\)'');      -- Links/Images'||wwv_flow.LF||
'    v_output ';
wwv_flow_imp.g_varchar2_table(11) := ':= REPLACE(v_output, ''>'', ''\>'');      -- Blockquotes'||wwv_flow.LF||
'    v_output := REPLACE(v_output, ''`'', ''\`'');  ';
wwv_flow_imp.g_varchar2_table(12) := '    -- Code'||wwv_flow.LF||
'    v_output := REPLACE(v_output, ''+'', ''\+'');      -- Lists'||wwv_flow.LF||
'    v_output := REPLACE(v_ou';
wwv_flow_imp.g_varchar2_table(13) := 'tput, ''-'', ''\-'');      -- Lists/Horizontal rules'||wwv_flow.LF||
'    v_output := REPLACE(v_output, ''!'', ''\!'');      ';
wwv_flow_imp.g_varchar2_table(14) := '-- Images'||wwv_flow.LF||
'    v_output := REPLACE(v_output, ''|'', ''\|'');      -- Tables'||wwv_flow.LF||
'    v_output := REPLACE(v_out';
wwv_flow_imp.g_varchar2_table(15) := 'put, ''~'', ''\~'');      -- Strikethrough'||wwv_flow.LF||
'    v_output := REPLACE(v_output, ''{'', ''\{'');      -- Code bl';
wwv_flow_imp.g_varchar2_table(16) := 'ocks'||wwv_flow.LF||
'    v_output := REPLACE(v_output, ''}'', ''\}'');      -- Code blocks'||wwv_flow.LF||
'    v_output := REPLACE(v_out';
wwv_flow_imp.g_varchar2_table(17) := 'put, ''.'', ''\.'');      -- Ordered lists'||wwv_flow.LF||
'*/'||wwv_flow.LF||
'    return v_output;'||wwv_flow.LF||
'end escape_markdown;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function ai_su';
wwv_flow_imp.g_varchar2_table(18) := 'mmary_info ('||wwv_flow.LF||
'    p_type  in  varchar2 )'||wwv_flow.LF||
'    return clob'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_info  clob := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p';
wwv_flow_imp.g_varchar2_table(19) := '_type = ''PROJECT'' then'||wwv_flow.LF||
'        l_info := ''**What goes into the AI Summary?**'||wwv_flow.LF||
''||wwv_flow.LF||
'The AI Summaries are g';
wwv_flow_imp.g_varchar2_table(20) := 'enerated by passing &NOMENCLATURE_PROJECT. Details and a Prompt to an AI Service.  There are two typ';
wwv_flow_imp.g_varchar2_table(21) := 'es of summaries available, full summary and summary update, each with their own prompt.  The prompts';
wwv_flow_imp.g_varchar2_table(22) := ' ask for a summary, a risk assessment, and highlights.  The AI Service to use is configured by the A';
wwv_flow_imp.g_varchar2_table(23) := 'pplication Administrators.  Administrators also have the ability to modify the prompts.  '||wwv_flow.LF||
''||wwv_flow.LF||
'The &NOME';
wwv_flow_imp.g_varchar2_table(24) := 'NCLATURE_PROJECT. Details include all the details about a &NOMENCLATURE_PROJECT. (e.g. name, descrip';
wwv_flow_imp.g_varchar2_table(25) := 'tion, priority, percent complete, status, ...).  The full summary includes comments from the last 90';
wwv_flow_imp.g_varchar2_table(26) := unistr(' days, the summary update contains just the data that has changed since the last summary \2013 and the p');
wwv_flow_imp.g_varchar2_table(27) := 'revious summary is included for reference.'||wwv_flow.LF||
''';'||wwv_flow.LF||
'    elsif p_type = ''RELEASE'' then'||wwv_flow.LF||
'        l_info := ''*';
wwv_flow_imp.g_varchar2_table(28) := '*What goes into the AI Summary?**'||wwv_flow.LF||
''||wwv_flow.LF||
'The AI Summary is generated by passing Release and &NOMENCLATURE_';
wwv_flow_imp.g_varchar2_table(29) := 'PROJECT. Details, grouped by Focus Area, and a Prompt to an AI Service.  The prompt asks for a summa';
wwv_flow_imp.g_varchar2_table(30) := 'ry of the release along with highlights.  The AI Service to use is configured by the Application Adm';
wwv_flow_imp.g_varchar2_table(31) := 'inistrators.  Administrators also have the ability to modify the prompts.  '||wwv_flow.LF||
''||wwv_flow.LF||
'The Release Details inc';
wwv_flow_imp.g_varchar2_table(32) := 'lude the Release Train, release type and date range.  The &NOMENCLATURE_PROJECT. Details include &NO';
wwv_flow_imp.g_varchar2_table(33) := 'MENCLATURE_PROJECT. Name, description, priority, and size.'||wwv_flow.LF||
''';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return sp_util.replac';
wwv_flow_imp.g_varchar2_table(34) := 'e_nomenclature(l_info);'||wwv_flow.LF||
''||wwv_flow.LF||
'end ai_summary_info;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure summarize_project ('||wwv_flow.LF||
'    p_project_id      ';
wwv_flow_imp.g_varchar2_table(35) := '     in  number,'||wwv_flow.LF||
'    p_summary_type         in  varchar2,'||wwv_flow.LF||
'    p_summary              out clob,'||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(36) := '_id_to_replace        out number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_last_priority        varchar2(4000);'||wwv_flow.LF||
'    l_last_pct_comp';
wwv_flow_imp.g_varchar2_table(37) := 'lete    varchar2(4000);'||wwv_flow.LF||
'    l_last_status          varchar2(4000);'||wwv_flow.LF||
'    l_last_target_date     varcha';
wwv_flow_imp.g_varchar2_table(38) := 'r2(4000);'||wwv_flow.LF||
'    l_future_reviewer_cnt  number;'||wwv_flow.LF||
'    x                      clob        := null;'||wwv_flow.LF||
'    x2 ';
wwv_flow_imp.g_varchar2_table(39) := '                    clob        := null;'||wwv_flow.LF||
'    l_id_to_replace        number;'||wwv_flow.LF||
'    l_last_summary      ';
wwv_flow_imp.g_varchar2_table(40) := '   date;'||wwv_flow.LF||
'    l_first_yn             varchar2(1) := ''Y'';'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'for c1 in ('||wwv_flow.LF||
'    select p.id project_i';
wwv_flow_imp.g_varchar2_table(41) := 'd,'||wwv_flow.LF||
'           p.project name,'||wwv_flow.LF||
'           p.description,'||wwv_flow.LF||
'           a.area||'' / ''||i.initiative area_';
wwv_flow_imp.g_varchar2_table(42) := 'initiative,'||wwv_flow.LF||
'           case when tm.id is null then ''No Owner'' else tm.first_name||'' ''||tm.last_name';
wwv_flow_imp.g_varchar2_table(43) := ' end owner,'||wwv_flow.LF||
'           p.project_size,'||wwv_flow.LF||
'           nvl((select ''P''||priority from sp_project_prioriti';
wwv_flow_imp.g_varchar2_table(44) := 'es pp where pp.id = p.priority_id),''Not Prioritized'') priority,'||wwv_flow.LF||
'           (select max(changed_on) '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(45) := '              from sp_project_history'||wwv_flow.LF||
'             where project_id = p.id'||wwv_flow.LF||
'               and attrib';
wwv_flow_imp.g_varchar2_table(46) := 'ute_column = ''PRIORITY'''||wwv_flow.LF||
'               and change_type = ''UPDATE'') last_priority_update,'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(47) := 'p.PCT_COMPLETE||''%'' percent_complete,'||wwv_flow.LF||
'           (select max(changed_on) '||wwv_flow.LF||
'              from sp_proj';
wwv_flow_imp.g_varchar2_table(48) := 'ect_history'||wwv_flow.LF||
'             where project_id = p.id'||wwv_flow.LF||
'               and attribute_column = ''PCT_COMPLETE';
wwv_flow_imp.g_varchar2_table(49) := ''''||wwv_flow.LF||
'               and change_type = ''UPDATE'') last_pct_complete_update,'||wwv_flow.LF||
'           case when p.pct_co';
wwv_flow_imp.g_varchar2_table(50) := 'mplete >= s.min_pc_for_status '||wwv_flow.LF||
'                 and p.pct_complete != 100'||wwv_flow.LF||
'                then nvl((';
wwv_flow_imp.g_varchar2_table(51) := 'select status from sp_project_statuses where id = p.status_id),''Not Set'')'||wwv_flow.LF||
'                else ''NA'''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(52) := '                end status,'||wwv_flow.LF||
'           (select max(changed_on) '||wwv_flow.LF||
'              from sp_project_histor';
wwv_flow_imp.g_varchar2_table(53) := 'y'||wwv_flow.LF||
'             where project_id = p.id'||wwv_flow.LF||
'               and attribute_column = ''STATUS'''||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(54) := ' and change_type = ''UPDATE'') last_status_update,'||wwv_flow.LF||
'           lower(p.tags) tags,'||wwv_flow.LF||
'           nvl((sele';
wwv_flow_imp.g_varchar2_table(55) := 'ct focus_area from sp_initiative_focus_areas where id = p.focus_area_id),''Not Identified'') focus_are';
wwv_flow_imp.g_varchar2_table(56) := 'a,'||wwv_flow.LF||
'           case when p.target_complete is null then ''Not Set'''||wwv_flow.LF||
'                else to_char(p.targ';
wwv_flow_imp.g_varchar2_table(57) := 'et_complete,''DD-Mon-YYYY'')'||wwv_flow.LF||
'                end target_completion_date,'||wwv_flow.LF||
'           (select max(change';
wwv_flow_imp.g_varchar2_table(58) := 'd_on) '||wwv_flow.LF||
'              from sp_project_history'||wwv_flow.LF||
'             where project_id = p.id'||wwv_flow.LF||
'               and';
wwv_flow_imp.g_varchar2_table(59) := ' attribute_column = ''TARGET_COMPLETE'''||wwv_flow.LF||
'                and change_type = ''UPDATE'') last_target_comple';
wwv_flow_imp.g_varchar2_table(60) := 'te_update,'||wwv_flow.LF||
'           (select count(distinct app_user)'||wwv_flow.LF||
'              from sp_proj_interactions_log'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(61) := '            where project_id = p.id'||wwv_flow.LF||
'               and page_rendered >= sysdate-30) views_last_30_da';
wwv_flow_imp.g_varchar2_table(62) := 'ys,'||wwv_flow.LF||
'           (select count(distinct app_user)'||wwv_flow.LF||
'              from sp_proj_interactions_log'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(63) := '     where page_rendered >= sysdate-30) overall_views_last_30_days,'||wwv_flow.LF||
'           p.requires_reviews_yn';
wwv_flow_imp.g_varchar2_table(64) := ','||wwv_flow.LF||
'           p.initiative_id'||wwv_flow.LF||
'      from sp_projects p,'||wwv_flow.LF||
'           sp_initiatives i,'||wwv_flow.LF||
'           sp_ar';
wwv_flow_imp.g_varchar2_table(65) := 'eas a,'||wwv_flow.LF||
'           sp_project_scales s,'||wwv_flow.LF||
'           sp_team_members tm'||wwv_flow.LF||
'     where p.id = p_project_id'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(66) := '       and p.archived_yn = ''N'''||wwv_flow.LF||
'       and p.duplicate_of_project_id is null'||wwv_flow.LF||
'       and p.initiative_';
wwv_flow_imp.g_varchar2_table(67) := 'id = i.id'||wwv_flow.LF||
'       and i.area_id = a.id'||wwv_flow.LF||
'       and i.status_scale = s.scale_letter'||wwv_flow.LF||
'       and p.owner_';
wwv_flow_imp.g_varchar2_table(68) := 'id = tm.id (+)'||wwv_flow.LF||
') loop'||wwv_flow.LF||
''||wwv_flow.LF||
'    if c1.last_priority_update is not null then'||wwv_flow.LF||
'       select old_value'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(69) := '    into l_last_priority'||wwv_flow.LF||
'         from sp_project_history'||wwv_flow.LF||
'        where project_id = p_project_id'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(70) := '        and attribute_column = ''PRIORITY'''||wwv_flow.LF||
'          and change_type = ''UPDATE'''||wwv_flow.LF||
'          and changed';
wwv_flow_imp.g_varchar2_table(71) := '_on = c1.last_priority_update;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if c1.last_pct_complete_update is not null then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(72) := '   select old_value'||wwv_flow.LF||
'         into l_last_pct_complete'||wwv_flow.LF||
'         from sp_project_history'||wwv_flow.LF||
'        where';
wwv_flow_imp.g_varchar2_table(73) := ' project_id = p_project_id'||wwv_flow.LF||
'          and attribute_column = ''PCT_COMPLETE'''||wwv_flow.LF||
'          and change_type';
wwv_flow_imp.g_varchar2_table(74) := ' = ''UPDATE'''||wwv_flow.LF||
'          and changed_on = c1.last_pct_complete_update;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if c1.last_stat';
wwv_flow_imp.g_varchar2_table(75) := 'us_update is not null then'||wwv_flow.LF||
'       select old_value'||wwv_flow.LF||
'         into l_last_status'||wwv_flow.LF||
'         from sp_proj';
wwv_flow_imp.g_varchar2_table(76) := 'ect_history'||wwv_flow.LF||
'        where project_id = p_project_id'||wwv_flow.LF||
'          and attribute_column = ''STATUS'''||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(77) := '    and change_type = ''UPDATE'''||wwv_flow.LF||
'          and changed_on = c1.last_status_update;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if';
wwv_flow_imp.g_varchar2_table(78) := ' c1.last_target_complete_update is not null then'||wwv_flow.LF||
'       select old_value'||wwv_flow.LF||
'         into l_last_target';
wwv_flow_imp.g_varchar2_table(79) := '_date'||wwv_flow.LF||
'         from sp_project_history'||wwv_flow.LF||
'        where project_id = p_project_id'||wwv_flow.LF||
'          and attribu';
wwv_flow_imp.g_varchar2_table(80) := 'te_column = ''TARGET_COMPLETE'''||wwv_flow.LF||
'          and change_type = ''UPDATE'''||wwv_flow.LF||
'          and changed_on = c1.las';
wwv_flow_imp.g_varchar2_table(81) := 't_target_complete_update;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    x := ''#### Project ''||c1.name||chr(10)||'||wwv_flow.LF||
'            ''des';
wwv_flow_imp.g_varchar2_table(82) := 'cription: ''||chr(10)||c1.description||chr(10)||'||wwv_flow.LF||
'            case when c1.area_initiative is not null';
wwv_flow_imp.g_varchar2_table(83) := ' then'||wwv_flow.LF||
'                ''area initiative: ''||c1.area_initiative||chr(10) end ||'||wwv_flow.LF||
'            ''owner: ''|';
wwv_flow_imp.g_varchar2_table(84) := '|c1.owner||chr(10)||'||wwv_flow.LF||
'            ''size: ''||c1.project_size||chr(10)||'||wwv_flow.LF||
'            ''priority: ''||c1.p';
wwv_flow_imp.g_varchar2_table(85) := 'riority||case when c1.last_priority_update is not null '||wwv_flow.LF||
'                                            ';
wwv_flow_imp.g_varchar2_table(86) := 'then '', set ''||to_char(c1.last_priority_update,''DD-Mon-YYYY'')'||wwv_flow.LF||
'                                      ';
wwv_flow_imp.g_varchar2_table(87) := '      end ||'||wwv_flow.LF||
'                                       case when l_last_priority is not null'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(88) := '                                  then '', prior value was ''||l_last_priority'||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(89) := '                     end ||chr(10)||'||wwv_flow.LF||
'            ''percent complete: ''||c1.percent_complete||case whe';
wwv_flow_imp.g_varchar2_table(90) := 'n c1.last_pct_complete_update is not null '||wwv_flow.LF||
'                                                         ';
wwv_flow_imp.g_varchar2_table(91) := '   then '', set ''||to_char(c1.last_pct_complete_update,''DD-Mon-YYYY'')'||wwv_flow.LF||
'                               ';
wwv_flow_imp.g_varchar2_table(92) := '                             end ||'||wwv_flow.LF||
'                                                       case when';
wwv_flow_imp.g_varchar2_table(93) := ' l_last_pct_complete is not null'||wwv_flow.LF||
'                                                            then '',';
wwv_flow_imp.g_varchar2_table(94) := ' prior value was ''||l_last_pct_complete'||wwv_flow.LF||
'                                                            ';
wwv_flow_imp.g_varchar2_table(95) := 'end ||chr(10)||'||wwv_flow.LF||
'            case when c1.status != ''NA'' '||wwv_flow.LF||
'                 then ''status: ''||c1.status';
wwv_flow_imp.g_varchar2_table(96) := '||case when c1.last_status_update is not null '||wwv_flow.LF||
'                                                  the';
wwv_flow_imp.g_varchar2_table(97) := 'n '', set ''||to_char(c1.last_status_update,''DD-Mon-YYYY'')'||wwv_flow.LF||
'                                           ';
wwv_flow_imp.g_varchar2_table(98) := '       end ||'||wwv_flow.LF||
'                                             case when l_last_status is not null'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(99) := '                                             then '', prior value was ''||l_last_status'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(100) := '                                    end ||chr(10)'||wwv_flow.LF||
'                 end ||'||wwv_flow.LF||
'            case when c1.t';
wwv_flow_imp.g_varchar2_table(101) := 'ags is not null then'||wwv_flow.LF||
'                ''tags: ''||c1.tags||chr(10) end ||'||wwv_flow.LF||
'            case when c1.focu';
wwv_flow_imp.g_varchar2_table(102) := 's_area is not null then'||wwv_flow.LF||
'                ''focus area: ''||c1.focus_area||chr(10) end ||'||wwv_flow.LF||
'            ''t';
wwv_flow_imp.g_varchar2_table(103) := 'arget completion date: ''||c1.target_completion_date||case when c1.last_target_complete_update is not';
wwv_flow_imp.g_varchar2_table(104) := ' null '||wwv_flow.LF||
'                                                                        then '', set ''||to_cha';
wwv_flow_imp.g_varchar2_table(105) := 'r(c1.last_target_complete_update,''DD-Mon-YYYY'')'||wwv_flow.LF||
'                                                    ';
wwv_flow_imp.g_varchar2_table(106) := '                    end ||'||wwv_flow.LF||
'                                                                   case w';
wwv_flow_imp.g_varchar2_table(107) := 'hen l_last_target_date is not null'||wwv_flow.LF||
'                                                                 ';
wwv_flow_imp.g_varchar2_table(108) := '       then '', prior value was ''||l_last_target_date'||wwv_flow.LF||
'                                               ';
wwv_flow_imp.g_varchar2_table(109) := '                         end ||chr(10)||'||wwv_flow.LF||
'            ''distinct user views: ''||c1.views_last_30_days|';
wwv_flow_imp.g_varchar2_table(110) := '|'' users viewed in the last 30 days (out of ''||c1.overall_views_last_30_days||'' total)''||chr(10);'||wwv_flow.LF||
''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(111) := '   -- if last summary is of the same type and within the threshold to replace'||wwv_flow.LF||
'    --    set p_id_to_';
wwv_flow_imp.g_varchar2_table(112) := 'replace so it can be removed and pass the summary before that (only for update) '||wwv_flow.LF||
'    for c2 in ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(113) := '     select id, created, summary_type, risk, summary,'||wwv_flow.LF||
'               case when p_summary_type = ''upd';
wwv_flow_imp.g_varchar2_table(114) := 'ate'''||wwv_flow.LF||
'                    then (select max(created)'||wwv_flow.LF||
'                            from sp_project_ai_su';
wwv_flow_imp.g_varchar2_table(115) := 'mmaries'||wwv_flow.LF||
'                           where project_id = p_project_id'||wwv_flow.LF||
'                             and ';
wwv_flow_imp.g_varchar2_table(116) := 'summary is not null'||wwv_flow.LF||
'                             and created < s.created)'||wwv_flow.LF||
'                    end pr';
wwv_flow_imp.g_varchar2_table(117) := 'evious_created'||wwv_flow.LF||
'          from sp_project_ai_summaries s'||wwv_flow.LF||
'         where project_id = p_project_id'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(118) := '        and summary is not null  -- excludes those ending in error'||wwv_flow.LF||
'         order by created desc'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(119) := '  ) loop'||wwv_flow.LF||
'        if p_summary_type = c2.summary_type and'||wwv_flow.LF||
'           c2.created > sysdate - g_hrs_to_';
wwv_flow_imp.g_varchar2_table(120) := 'replace/24 '||wwv_flow.LF||
'        then'||wwv_flow.LF||
'            p_id_to_replace := c2.id;'||wwv_flow.LF||
''||wwv_flow.LF||
'            for c3 in ('||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(121) := '    select created, summary_type, risk, summary'||wwv_flow.LF||
'                  from sp_project_ai_summaries s'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(122) := '              where project_id = p_project_id'||wwv_flow.LF||
'                   and created = c2.previous_created'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(123) := '           ) loop'||wwv_flow.LF||
'                   l_last_summary := c3.created;'||wwv_flow.LF||
'                   x2 := ''##### L';
wwv_flow_imp.g_varchar2_table(124) := 'ast Summary''||chr(10);'||wwv_flow.LF||
'                   x2 := x2||''risk was ''||c3.risk||chr(10)||'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(125) := '             c3.summary ||chr(10);'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            l_last_summary := ';
wwv_flow_imp.g_varchar2_table(126) := 'c2.created;'||wwv_flow.LF||
'            x2 := ''##### Last Summary''||chr(10);'||wwv_flow.LF||
'            x2 := x2||''risk was ''||c2.r';
wwv_flow_imp.g_varchar2_table(127) := 'isk||chr(10)||'||wwv_flow.LF||
'                      c2.summary ||chr(10);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        exit;  -- to get';
wwv_flow_imp.g_varchar2_table(128) := ' just the latest'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if x2 is not null then'||wwv_flow.LF||
'        sys.dbms_lob.append(x, x2);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(129) := '   x2 := null;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- CONTRIBUTORS'||wwv_flow.LF||
'    for c2 in ('||wwv_flow.LF||
'        select t.first_name||'' ''||t.';
wwv_flow_imp.g_varchar2_table(130) := 'last_name name,'||wwv_flow.LF||
'               (select resource_type from SP_RESOURCE_TYPES r where r.id = c.respons';
wwv_flow_imp.g_varchar2_table(131) := 'ibility_id) responsibility,'||wwv_flow.LF||
'               c.responsibility comments,'||wwv_flow.LF||
'               c.tags'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(132) := '  from sp_project_contributors c,'||wwv_flow.LF||
'               sp_team_members t'||wwv_flow.LF||
'         where c.project_id = c1.';
wwv_flow_imp.g_varchar2_table(133) := 'project_id'||wwv_flow.LF||
'           and c.team_member_id = t.id'||wwv_flow.LF||
'           and ( (p_summary_type = ''update'' and c.';
wwv_flow_imp.g_varchar2_table(134) := 'updated > nvl(l_last_summary,c.updated-1)) or'||wwv_flow.LF||
'                  p_summary_type = ''full'')'||wwv_flow.LF||
'         or';
wwv_flow_imp.g_varchar2_table(135) := 'der by 2'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'      if l_first_yn = ''Y'' and p_summary_type = ''full'' then'||wwv_flow.LF||
'         x2 := ''####';
wwv_flow_imp.g_varchar2_table(136) := '# Contributors''||chr(10);'||wwv_flow.LF||
'      elsif l_first_yn = ''Y'' and p_summary_type = ''update'' then'||wwv_flow.LF||
'         x';
wwv_flow_imp.g_varchar2_table(137) := '2 := ''##### Contributor Changes''||chr(10);'||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
''||wwv_flow.LF||
'      x2 := x2||''* ''||c2.name||'', ''||c2.r';
wwv_flow_imp.g_varchar2_table(138) := 'esponsibility||'||wwv_flow.LF||
'                      case when c2.comments is not null'||wwv_flow.LF||
'                           t';
wwv_flow_imp.g_varchar2_table(139) := 'hen ''(''||c2.comments||'')'' end ||'||wwv_flow.LF||
'                      case when c2.tags is not null '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(140) := '             then ''-''||c2.tags end ||chr(10);'||wwv_flow.LF||
''||wwv_flow.LF||
'      l_first_yn := ''N'';'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if x2 is ';
wwv_flow_imp.g_varchar2_table(141) := 'not null then'||wwv_flow.LF||
'       x2 := x2||chr(10);'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'       if p_summary_type = ''full'' then'||wwv_flow.LF||
'           x';
wwv_flow_imp.g_varchar2_table(142) := '2 := ''##### Contributors''||chr(10)||''* None''||chr(10);'||wwv_flow.LF||
'       elsif p_summary_type = ''update'' then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(143) := '          x2 := ''##### Contributor Changes''||chr(10)||''* None''||chr(10);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(144) := ''||wwv_flow.LF||
'    sys.dbms_lob.append(x, x2);'||wwv_flow.LF||
'    x2 := null;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_yn := ''Y'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- MILESTONES'||wwv_flow.LF||
'    for ';
wwv_flow_imp.g_varchar2_table(145) := 'c2 in ('||wwv_flow.LF||
'        select r.id milestone_id,'||wwv_flow.LF||
'               t.task_type name,'||wwv_flow.LF||
'               nvl((selec';
wwv_flow_imp.g_varchar2_table(146) := 't case when first_name is not null or last_name is not null'||wwv_flow.LF||
'                                then fir';
wwv_flow_imp.g_varchar2_table(147) := 'st_name||'' ''||last_name'||wwv_flow.LF||
'                                else email'||wwv_flow.LF||
'                                e';
wwv_flow_imp.g_varchar2_table(148) := 'nd'||wwv_flow.LF||
'                      from sp_team_members t where t.id = r.owner_id),''None'') owner,'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(149) := '   case when length(r.description) > 500'||wwv_flow.LF||
'                    then substr(r.description,1,500)||''...''';
wwv_flow_imp.g_varchar2_table(150) := ''||wwv_flow.LF||
'                    else r.description'||wwv_flow.LF||
'                    end description,'||wwv_flow.LF||
'               (select ';
wwv_flow_imp.g_varchar2_table(151) := 'status from sp_task_statuses where id = r.status_id) status,'||wwv_flow.LF||
'               to_char(r.start_date,''DD';
wwv_flow_imp.g_varchar2_table(152) := '-Mon-YYYY'') start_date,'||wwv_flow.LF||
'               to_char(r.target_complete,''DD-Mon-YYYY'') target_complete'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(153) := '      from sp_tasks r,'||wwv_flow.LF||
'               sp_task_types t'||wwv_flow.LF||
'         where project_id = c1.project_id'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(154) := '       and nvl(r.task_sub_type_id,r.task_type_id) = t.id'||wwv_flow.LF||
'           and t.static_id like ''MILESTONE%';
wwv_flow_imp.g_varchar2_table(155) := ''''||wwv_flow.LF||
'           and ( (p_summary_type = ''update'' and r.updated > nvl(l_last_summary,r.updated-1)) or'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(156) := '                p_summary_type = ''full'')'||wwv_flow.LF||
'         order by t.display_seq'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'      if l_firs';
wwv_flow_imp.g_varchar2_table(157) := 't_yn = ''Y'' and p_summary_type = ''full'' then'||wwv_flow.LF||
'         x2 := ''##### Milestones''||chr(10);'||wwv_flow.LF||
'      elsif ';
wwv_flow_imp.g_varchar2_table(158) := 'l_first_yn = ''Y'' and p_summary_type = ''update'' then'||wwv_flow.LF||
'         x2 := ''##### Milestone Changes''||chr(10';
wwv_flow_imp.g_varchar2_table(159) := ');'||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
''||wwv_flow.LF||
'      x2 := x2||''* **''||c2.name||''**''||'', owner: ''||c2.owner||'', status of ''||c2.';
wwv_flow_imp.g_varchar2_table(160) := 'status||'||wwv_flow.LF||
'            case when c2.description is not null'||wwv_flow.LF||
'                 then '' (''||c2.description';
wwv_flow_imp.g_varchar2_table(161) := '||''), '''||wwv_flow.LF||
'                 else '', '''||wwv_flow.LF||
'                 end ||'||wwv_flow.LF||
'            case when c2.start_date is no';
wwv_flow_imp.g_varchar2_table(162) := 't null and c2.target_complete is not null'||wwv_flow.LF||
'                 then c2.start_date||''-''||c2.target_comple';
wwv_flow_imp.g_varchar2_table(163) := 'te'||wwv_flow.LF||
'                 when c2.start_date is not null'||wwv_flow.LF||
'                 then ''start of ''||c2.start_date|';
wwv_flow_imp.g_varchar2_table(164) := '|'' with no target completion'''||wwv_flow.LF||
'                 when c2.target_complete is not null'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(165) := 'then ''target complete of ''||c2.target_complete'||wwv_flow.LF||
'                 else ''no target date provided'''||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(166) := '            end ||chr(10);'||wwv_flow.LF||
''||wwv_flow.LF||
'      -- MILESTONE COMMENTS'||wwv_flow.LF||
'      for c3 in ('||wwv_flow.LF||
'          select * from'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(167) := '        ('||wwv_flow.LF||
'            select tm.first_name || '' '' || tm.last_name user_name,'||wwv_flow.LF||
'                   pc.b';
wwv_flow_imp.g_varchar2_table(168) := 'ody_no_images comment_text,'||wwv_flow.LF||
'                   pc.created,'||wwv_flow.LF||
'                   row_number( ) over (pa';
wwv_flow_imp.g_varchar2_table(169) := 'rtition by pc.task_id order by pc.created desc) last_added'||wwv_flow.LF||
'              from sp_task_comments pc, '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(170) := '                   sp_team_members tm'||wwv_flow.LF||
'            where pc.author_id = tm.id (+)'||wwv_flow.LF||
'              and p';
wwv_flow_imp.g_varchar2_table(171) := 'c.task_id = c2.milestone_id'||wwv_flow.LF||
'              and nvl(pc.private_yn,''N'') = ''N'''||wwv_flow.LF||
'              and ( (p_su';
wwv_flow_imp.g_varchar2_table(172) := 'mmary_type = ''full'' and pc.created > sysdate-90) or'||wwv_flow.LF||
'                     pc.created >= nvl(l_last_su';
wwv_flow_imp.g_varchar2_table(173) := 'mmary,pc.updated-1) )'||wwv_flow.LF||
'          )'||wwv_flow.LF||
'          where last_added <= 3'||wwv_flow.LF||
'          order by created desc'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(174) := '    ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'        x2 := x2||''    * comment added by ''||c3.user_name||'' on ''||to_char(c3.created,''D';
wwv_flow_imp.g_varchar2_table(175) := 'D-Mon-YYYY'')||chr(10)||'||wwv_flow.LF||
'                         c3.comment_text||chr(10);'||wwv_flow.LF||
''||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'      l';
wwv_flow_imp.g_varchar2_table(176) := '_first_yn := ''N'';'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if x2 is not null then'||wwv_flow.LF||
'       x2 := x2||chr(10);'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(177) := '  if p_summary_type = ''full'' then'||wwv_flow.LF||
'          x2 := ''##### Milestones''||chr(10)||''* None''||chr(10);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(178) := '     elsif p_summary_type = ''update'' then'||wwv_flow.LF||
'          x2 := ''##### Milestone Changes''||chr(10)||''* Non';
wwv_flow_imp.g_varchar2_table(179) := 'e''||chr(10);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    sys.dbms_lob.append(x, x2);'||wwv_flow.LF||
'    x2 := null;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_firs';
wwv_flow_imp.g_varchar2_table(180) := 't_yn := ''Y'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- REVIEWS'||wwv_flow.LF||
'    for c2 in ('||wwv_flow.LF||
'        select r.id review_id,'||wwv_flow.LF||
'               t.task_ty';
wwv_flow_imp.g_varchar2_table(181) := 'pe name,'||wwv_flow.LF||
'               nvl((select case when first_name is not null or last_name is not null'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(182) := '                          then first_name||'' ''||last_name'||wwv_flow.LF||
'                                else email';
wwv_flow_imp.g_varchar2_table(183) := ''||wwv_flow.LF||
'                                end'||wwv_flow.LF||
'                      from sp_team_members t where t.id = r.own';
wwv_flow_imp.g_varchar2_table(184) := 'er_id),''None'') owner,'||wwv_flow.LF||
'               case when length(r.description) > 500'||wwv_flow.LF||
'                    then ';
wwv_flow_imp.g_varchar2_table(185) := 'substr(r.description,1,500)||''...'''||wwv_flow.LF||
'                    else r.description'||wwv_flow.LF||
'                    end de';
wwv_flow_imp.g_varchar2_table(186) := 'scription,'||wwv_flow.LF||
'               (select status from sp_task_statuses where id = r.status_id) status,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(187) := '          r.impact,'||wwv_flow.LF||
'               r.start_date,'||wwv_flow.LF||
'               r.target_complete'||wwv_flow.LF||
'          from sp_';
wwv_flow_imp.g_varchar2_table(188) := 'tasks r,'||wwv_flow.LF||
'               sp_task_types t'||wwv_flow.LF||
'         where project_id = c1.project_id'||wwv_flow.LF||
'           and nvl';
wwv_flow_imp.g_varchar2_table(189) := '(r.task_sub_type_id,r.task_type_id) = t.id'||wwv_flow.LF||
'           and t.static_id like ''REVIEW%'''||wwv_flow.LF||
'           and ';
wwv_flow_imp.g_varchar2_table(190) := '( (p_summary_type = ''update'' and r.updated > nvl(l_last_summary,r.updated-1)) or'||wwv_flow.LF||
'                  p';
wwv_flow_imp.g_varchar2_table(191) := '_summary_type = ''full'')'||wwv_flow.LF||
'         order by t.display_seq'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'      if l_first_yn = ''Y'' and p_';
wwv_flow_imp.g_varchar2_table(192) := 'summary_type = ''full'' then'||wwv_flow.LF||
'         x2 := ''##### Reviews''||chr(10);'||wwv_flow.LF||
'      elsif l_first_yn = ''Y'' and';
wwv_flow_imp.g_varchar2_table(193) := ' p_summary_type = ''update'' then'||wwv_flow.LF||
'         x2 := ''##### Review Changes''||chr(10);'||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(194) := '  x2 := x2||''* **''||c2.name||''**''||'||wwv_flow.LF||
'            case when c2.impact is not null'||wwv_flow.LF||
'                 the';
wwv_flow_imp.g_varchar2_table(195) := 'n '', ''|| c2.impact ||'' impact'''||wwv_flow.LF||
'                 end ||'||wwv_flow.LF||
'            '', owner: ''||c2.owner||'', status ';
wwv_flow_imp.g_varchar2_table(196) := 'of ''||c2.status||'||wwv_flow.LF||
'            case when c2.description is not null'||wwv_flow.LF||
'                 then '' (''||c2.de';
wwv_flow_imp.g_varchar2_table(197) := 'scription||''), '''||wwv_flow.LF||
'                 else '', '''||wwv_flow.LF||
'                 end ||'||wwv_flow.LF||
'            case when c2.start_d';
wwv_flow_imp.g_varchar2_table(198) := 'ate is not null and c2.target_complete is not null'||wwv_flow.LF||
'                 then c2.start_date||''-''||c2.targ';
wwv_flow_imp.g_varchar2_table(199) := 'et_complete'||wwv_flow.LF||
'                 when c2.start_date is not null'||wwv_flow.LF||
'                 then ''start of ''||c2.st';
wwv_flow_imp.g_varchar2_table(200) := 'art_date||'' with no target completion'''||wwv_flow.LF||
'                 when c2.target_complete is not null'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(201) := '         then ''target complete of ''||c2.target_complete'||wwv_flow.LF||
'                 else ''no target date provid';
wwv_flow_imp.g_varchar2_table(202) := 'ed'''||wwv_flow.LF||
'                 end ||chr(10);'||wwv_flow.LF||
''||wwv_flow.LF||
'      -- REVIEW COMMENTS'||wwv_flow.LF||
'      for c3 in ('||wwv_flow.LF||
'          select * f';
wwv_flow_imp.g_varchar2_table(203) := 'rom'||wwv_flow.LF||
'          ('||wwv_flow.LF||
'            select tm.first_name || '' '' || tm.last_name user_name,'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(204) := '  pc.body_no_images comment_text,'||wwv_flow.LF||
'                   pc.created,'||wwv_flow.LF||
'                   row_number( ) ov';
wwv_flow_imp.g_varchar2_table(205) := 'er (partition by pc.task_id order by pc.created desc) last_added'||wwv_flow.LF||
'              from sp_task_comments';
wwv_flow_imp.g_varchar2_table(206) := ' pc, '||wwv_flow.LF||
'                   sp_team_members tm'||wwv_flow.LF||
'            where pc.author_id = tm.id (+)'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(207) := ' and pc.task_id = c2.review_id'||wwv_flow.LF||
'              and nvl(pc.private_yn,''N'') = ''N'''||wwv_flow.LF||
'              and ( (p';
wwv_flow_imp.g_varchar2_table(208) := '_summary_type = ''full'' and pc.created > sysdate-90) or'||wwv_flow.LF||
'                     pc.created >= nvl(l_last';
wwv_flow_imp.g_varchar2_table(209) := '_summary,pc.created-1) )'||wwv_flow.LF||
'          )'||wwv_flow.LF||
'          where last_added <= 3'||wwv_flow.LF||
'          order by created desc';
wwv_flow_imp.g_varchar2_table(210) := ''||wwv_flow.LF||
'      ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'        x2 := x2||''    * comment added by ''||c3.user_name||'' on ''||to_char(c3.created';
wwv_flow_imp.g_varchar2_table(211) := ',''DD-Mon-YYYY'')||chr(10)||'||wwv_flow.LF||
'                         c3.comment_text||chr(10);'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(212) := ' l_first_yn := ''N'';'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if x2 is not null then'||wwv_flow.LF||
'       x2 := x2||chr(10);'||wwv_flow.LF||
'    elsif nv';
wwv_flow_imp.g_varchar2_table(213) := 'l(c1.requires_reviews_yn,''Y'') = ''Y'' then'||wwv_flow.LF||
'       if p_summary_type = ''full'' then'||wwv_flow.LF||
'          x2 := ''###';
wwv_flow_imp.g_varchar2_table(214) := '## Reviews''||chr(10)||''* None''||chr(10);'||wwv_flow.LF||
'       elsif p_summary_type = ''update'' then'||wwv_flow.LF||
'         x2 := ';
wwv_flow_imp.g_varchar2_table(215) := '''##### Review Changes''||chr(10)||''* None''||chr(10);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if x2 is not nul';
wwv_flow_imp.g_varchar2_table(216) := 'l then'||wwv_flow.LF||
'       sys.dbms_lob.append(x, x2);'||wwv_flow.LF||
'       x2 := null;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_yn := ''Y'';'||wwv_flow.LF||
''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(217) := '  -- TASKS'||wwv_flow.LF||
'    for c2 in ('||wwv_flow.LF||
'        select r.id task_id,'||wwv_flow.LF||
'               (select task_type from sp_tas';
wwv_flow_imp.g_varchar2_table(218) := 'k_types rt where rt.id = r.task_type_id)||'||wwv_flow.LF||
'                case when r.task_sub_type_id is not null ';
wwv_flow_imp.g_varchar2_table(219) := 'then '': '' end ||'||wwv_flow.LF||
'               (select task_type from sp_task_types rt where rt.id = r.task_sub_typ';
wwv_flow_imp.g_varchar2_table(220) := 'e_id) ||'||wwv_flow.LF||
'                case when r.task is not null then '' - ''||r.task end name,'||wwv_flow.LF||
'               nv';
wwv_flow_imp.g_varchar2_table(221) := 'l((select case when first_name is not null or last_name is not null'||wwv_flow.LF||
'                                ';
wwv_flow_imp.g_varchar2_table(222) := 'then first_name||'' ''||last_name'||wwv_flow.LF||
'                                else email'||wwv_flow.LF||
'                         ';
wwv_flow_imp.g_varchar2_table(223) := '       end'||wwv_flow.LF||
'                      from sp_team_members t where t.id = r.owner_id),''None'') owner,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(224) := '           case when length(r.description) > 500'||wwv_flow.LF||
'                    then substr(r.description,1,500';
wwv_flow_imp.g_varchar2_table(225) := ')||''...'''||wwv_flow.LF||
'                    else r.description'||wwv_flow.LF||
'                    end description,'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(226) := '(select status from sp_task_statuses where id = r.status_id) status,'||wwv_flow.LF||
'               r.start_date,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(227) := '             r.target_complete'||wwv_flow.LF||
'          from sp_tasks r,'||wwv_flow.LF||
'               sp_task_types t'||wwv_flow.LF||
'         wh';
wwv_flow_imp.g_varchar2_table(228) := 'ere project_id = c1.project_id'||wwv_flow.LF||
'           and nvl(r.task_sub_type_id,r.task_type_id) = t.id'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(229) := '   and t.static_id not like ''MILESTONE%'''||wwv_flow.LF||
'           and t.static_id not like ''REVIEW%'''||wwv_flow.LF||
'           an';
wwv_flow_imp.g_varchar2_table(230) := 'd ( (p_summary_type = ''update'' and r.updated > nvl(l_last_summary,r.updated-1)) or'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(231) := ' p_summary_type = ''full'')'||wwv_flow.LF||
'         order by t.display_seq'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'      if l_first_yn = ''Y'' and ';
wwv_flow_imp.g_varchar2_table(232) := 'p_summary_type = ''full'' then'||wwv_flow.LF||
'         x2 := ''##### Tasks''||chr(10);'||wwv_flow.LF||
'      elsif l_first_yn = ''Y'' and';
wwv_flow_imp.g_varchar2_table(233) := ' p_summary_type = ''update'' then'||wwv_flow.LF||
'         x2 := ''##### Task Changes''||chr(10);'||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
''||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(234) := 'x2 := x2||''* **''||c2.name||''**''||'', owner: ''||c2.owner||'', status of ''||c2.status||'||wwv_flow.LF||
'            case';
wwv_flow_imp.g_varchar2_table(235) := ' when c2.description is not null'||wwv_flow.LF||
'                 then '' (''||c2.description||''), '''||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(236) := 'else '', '''||wwv_flow.LF||
'                 end ||'||wwv_flow.LF||
'            case when c2.start_date is not null and c2.target_comp';
wwv_flow_imp.g_varchar2_table(237) := 'lete is not null'||wwv_flow.LF||
'                 then c2.start_date||''-''||c2.target_complete'||wwv_flow.LF||
'                 when ';
wwv_flow_imp.g_varchar2_table(238) := 'c2.start_date is not null'||wwv_flow.LF||
'                 then ''start of ''||c2.start_date||'' with no target complet';
wwv_flow_imp.g_varchar2_table(239) := 'ion'''||wwv_flow.LF||
'                 when c2.target_complete is not null'||wwv_flow.LF||
'                 then ''target complete of ';
wwv_flow_imp.g_varchar2_table(240) := '''||c2.target_complete'||wwv_flow.LF||
'                 else ''no target date provided'''||wwv_flow.LF||
'                 end ||chr(10)';
wwv_flow_imp.g_varchar2_table(241) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'      -- TASK COMMENTS'||wwv_flow.LF||
'      for c3 in ('||wwv_flow.LF||
'          select * from'||wwv_flow.LF||
'          ('||wwv_flow.LF||
'            select t';
wwv_flow_imp.g_varchar2_table(242) := 'm.first_name || '' '' || tm.last_name user_name,'||wwv_flow.LF||
'                   pc.body_no_images comment_text,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(243) := '                 pc.created,'||wwv_flow.LF||
'                   row_number( ) over (partition by pc.task_id order by';
wwv_flow_imp.g_varchar2_table(244) := ' pc.created desc) last_added'||wwv_flow.LF||
'              from sp_task_comments pc, '||wwv_flow.LF||
'                   sp_team_mem';
wwv_flow_imp.g_varchar2_table(245) := 'bers tm'||wwv_flow.LF||
'            where pc.author_id = tm.id (+)'||wwv_flow.LF||
'              and pc.task_id = c2.task_id'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(246) := '       and nvl(pc.private_yn,''N'') = ''N'''||wwv_flow.LF||
'              and ( (p_summary_type = ''full'' and pc.created ';
wwv_flow_imp.g_varchar2_table(247) := '> sysdate-90) or'||wwv_flow.LF||
'                     pc.created >= nvl(l_last_summary,pc.updated-1) )'||wwv_flow.LF||
'          )'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(248) := '         where last_added <= 3'||wwv_flow.LF||
'          order by created desc'||wwv_flow.LF||
'      ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'        x2 := x2||''    ';
wwv_flow_imp.g_varchar2_table(249) := '* comment added by ''||c3.user_name||'' on ''||to_char(c3.created,''DD-Mon-YYYY'')||chr(10)||'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(250) := '              c3.comment_text||chr(10);'||wwv_flow.LF||
''||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'      l_first_yn := ''N'';'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(251) := '  if x2 is not null then'||wwv_flow.LF||
'       x2 := x2||chr(10);'||wwv_flow.LF||
'       sys.dbms_lob.append(x, x2);'||wwv_flow.LF||
'       x2 := n';
wwv_flow_imp.g_varchar2_table(252) := 'ull;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_yn := ''Y'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- APPROVALS'||wwv_flow.LF||
'    for c2 in ('||wwv_flow.LF||
'        select a.id appro';
wwv_flow_imp.g_varchar2_table(253) := 'val_id,'||wwv_flow.LF||
'               t.approval_type,'||wwv_flow.LF||
'               m.first_name||'' ''||m.last_name submitted_by,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(254) := '               to_char(a.submitted,''DD-Mon-YYYY'') submitted_on_display,'||wwv_flow.LF||
'               initcap(repla';
wwv_flow_imp.g_varchar2_table(255) := 'ce(case when a.status = ''CLARIFICATION-REQUESTED'' '||wwv_flow.LF||
'                                    then ''Needs C';
wwv_flow_imp.g_varchar2_table(256) := 'larification'' '||wwv_flow.LF||
'                                    when a.status = ''PENDING'''||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(257) := '             then ''Approval Pending'''||wwv_flow.LF||
'                                    else a.status '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(258) := '                        end,''-'','' '')) status_display,'||wwv_flow.LF||
'               a.status,'||wwv_flow.LF||
'               case w';
wwv_flow_imp.g_varchar2_table(259) := 'hen a.status = ''PENDING'' then ''Justification: ''||a.justification'||wwv_flow.LF||
'                    when a.status i';
wwv_flow_imp.g_varchar2_table(260) := 'n (''CLARIFICATION-REQUESTED'',''REJECTED'')'||wwv_flow.LF||
'                    then (select comments from '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(261) := '                      (select comments, created, max(created) over (partition by project_approval_id';
wwv_flow_imp.g_varchar2_table(262) := ') last_created'||wwv_flow.LF||
'                                    from sp_project_approval_chain'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(263) := '                 where a.id = project_approval_id)'||wwv_flow.LF||
'                            where last_created = ';
wwv_flow_imp.g_varchar2_table(264) := 'created)'||wwv_flow.LF||
'                    end justification,'||wwv_flow.LF||
'               to_char(a.updated,''DD-Mon-YYYY'') last';
wwv_flow_imp.g_varchar2_table(265) := '_update_display,'||wwv_flow.LF||
'               case when p_summary_type = ''update'' '||wwv_flow.LF||
'                    then nvl((s';
wwv_flow_imp.g_varchar2_table(266) := 'elect max(last_status_on) '||wwv_flow.LF||
'                                from sp_project_approval_chain'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(267) := '                     where project_approval_id = a.id),a.submitted)'||wwv_flow.LF||
'                    end last_act';
wwv_flow_imp.g_varchar2_table(268) := 'ion'||wwv_flow.LF||
'          from sp_project_approvals a,'||wwv_flow.LF||
'               sp_approval_types t,'||wwv_flow.LF||
'               sp_tea';
wwv_flow_imp.g_varchar2_table(269) := 'm_members m'||wwv_flow.LF||
'         where a.project_id = c1.project_id'||wwv_flow.LF||
'           and a.approval_type_id = t.id    ';
wwv_flow_imp.g_varchar2_table(270) := ''||wwv_flow.LF||
'           and a.submitted_by_team_member_id = m.id'||wwv_flow.LF||
'         order by a.submitted desc'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(271) := '      if p_summary_type = ''full'' or'||wwv_flow.LF||
'         (p_summary_type = ''update'' and c2.last_action > nvl(l_l';
wwv_flow_imp.g_varchar2_table(272) := 'ast_summary,c2.last_action-1))'||wwv_flow.LF||
'      then'||wwv_flow.LF||
''||wwv_flow.LF||
'         if l_first_yn = ''Y'' and p_summary_type = ''full'' ';
wwv_flow_imp.g_varchar2_table(273) := 'then'||wwv_flow.LF||
'            x2 := ''##### Approvals''||chr(10);'||wwv_flow.LF||
'         elsif l_first_yn = ''Y'' and p_summary_typ';
wwv_flow_imp.g_varchar2_table(274) := 'e = ''update'' then'||wwv_flow.LF||
'            x2 := ''##### Approval Changes''||chr(10);'||wwv_flow.LF||
'         end if; '||wwv_flow.LF||
''||wwv_flow.LF||
'         x';
wwv_flow_imp.g_varchar2_table(275) := '2 := x2||''* **''||c2.approval_type||''**''||'', submitted by ''||c2.submitted_by||'' on ''||c2.submitted_on';
wwv_flow_imp.g_varchar2_table(276) := '_display;'||wwv_flow.LF||
'         if c2.status = ''APPROVED'' then'||wwv_flow.LF||
'             x2 := x2||'', Received Final Approval ';
wwv_flow_imp.g_varchar2_table(277) := 'on ''||c2.last_update_display||chr(10);'||wwv_flow.LF||
'         elsif c2.status = ''WITHDRAWN'' then'||wwv_flow.LF||
'             x2 :';
wwv_flow_imp.g_varchar2_table(278) := '= x2||'', Withdrawn on ''||c2.last_update_display||chr(10);'||wwv_flow.LF||
'         elsif c2.status = ''REJECTED'' then';
wwv_flow_imp.g_varchar2_table(279) := ''||wwv_flow.LF||
'             x2 := x2||'', Rejected on ''||c2.last_update_display||chr(10);'||wwv_flow.LF||
'         else'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(280) := '  x2 := x2||'', status is ''||c2.status_display||chr(10);'||wwv_flow.LF||
'             x2 := x2||''    * ''||c2.justific';
wwv_flow_imp.g_varchar2_table(281) := 'ation||chr(10);'||wwv_flow.LF||
''||wwv_flow.LF||
'             -- current and past approvers'||wwv_flow.LF||
'             for c3 in ('||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(282) := '  select to_char(c.last_status_on,''DD-Mon-YYYY'') comment_date,'||wwv_flow.LF||
'                        t.first_name ';
wwv_flow_imp.g_varchar2_table(283) := '||'' ''|| t.last_name user_name,'||wwv_flow.LF||
'                        initcap(replace(decode(c.status,''PENDING'',''Pe';
wwv_flow_imp.g_varchar2_table(284) := 'nding Approval''),''-'','' '')) status,'||wwv_flow.LF||
'                        c.comments,'||wwv_flow.LF||
'                        case ';
wwv_flow_imp.g_varchar2_table(285) := 'when c.response_by_team_member_id is not null'||wwv_flow.LF||
'                             then c.response||chr(10)|';
wwv_flow_imp.g_varchar2_table(286) := '|''By: ''||(select first_name ||'' ''|| last_name from sp_team_members'||wwv_flow.LF||
'                                 ';
wwv_flow_imp.g_varchar2_table(287) := '                                where id = c.response_by_team_member_id) ||'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(288) := '          '', ''|| to_char(c.responded_on,''DD-Mon-YYYY'')'||wwv_flow.LF||
'                             end response,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(289) := '                      c.last_status_on ob_date'||wwv_flow.LF||
'                   from sp_project_approval_chain c,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(290) := '                        sp_team_members t'||wwv_flow.LF||
'                  where c.project_approval_id = c2.approva';
wwv_flow_imp.g_varchar2_table(291) := 'l_id'||wwv_flow.LF||
'                    and c.team_member_id = t.id'||wwv_flow.LF||
'                 order by ob_date asc'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(292) := '    ) loop'||wwv_flow.LF||
'                 x2 := x2||''    * ''|| c3.user_name ||'' ''|| c3.status ||'', ''|| c3.comment_';
wwv_flow_imp.g_varchar2_table(293) := 'date ||chr(10);'||wwv_flow.LF||
'                 if c3.comments is not null then'||wwv_flow.LF||
'                    x2 := x2||''    ';
wwv_flow_imp.g_varchar2_table(294) := '  Comments: ''||c3.comments||chr(10);'||wwv_flow.LF||
'                 end if;'||wwv_flow.LF||
'                 if c3.response is not';
wwv_flow_imp.g_varchar2_table(295) := ' null then'||wwv_flow.LF||
'                    x2 := x2||''      Response: ''||c3.response||chr(10);'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(296) := 'end if;'||wwv_flow.LF||
'             end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'             -- future approvers'||wwv_flow.LF||
'             select count(*)'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(297) := '         into l_future_reviewer_cnt'||wwv_flow.LF||
'               from sp_initiative_approval_chain c,'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(298) := '        sp_project_approvals a'||wwv_flow.LF||
'              where a.id = c2.approval_id'||wwv_flow.LF||
'                and a.initi';
wwv_flow_imp.g_varchar2_table(299) := 'ative_approval_id = c.initiative_approval_id'||wwv_flow.LF||
'                and c.id not in (select initiative_appr';
wwv_flow_imp.g_varchar2_table(300) := 'oval_chain_id'||wwv_flow.LF||
'                                   from sp_project_approval_chain'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(301) := '              where project_approval_id = c2.approval_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'             for c3 in ('||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(302) := '  select rownum, reviewer'||wwv_flow.LF||
'                   from ('||wwv_flow.LF||
'                 select case when c.alternate_te';
wwv_flow_imp.g_varchar2_table(303) := 'am_member_id is not null and   '||wwv_flow.LF||
'                                  (c.alternate_start_date <= sysdate';
wwv_flow_imp.g_varchar2_table(304) := ' or c.alternate_start_date is null) and '||wwv_flow.LF||
'                                  (c.alternate_end_date+1 >';
wwv_flow_imp.g_varchar2_table(305) := ' sysdate or c.alternate_end_date is null)'||wwv_flow.LF||
'                             then ''Alternate - ''||'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(306) := '                           (select last_name||'', ''||first_name'||wwv_flow.LF||
'                                     ';
wwv_flow_imp.g_varchar2_table(307) := 'from sp_team_members'||wwv_flow.LF||
'                                    where id = c.alternate_team_member_id)'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(308) := '                         else t.last_name||'', ''||t.first_name '||wwv_flow.LF||
'                             end revi';
wwv_flow_imp.g_varchar2_table(309) := 'ewer'||wwv_flow.LF||
'                   from sp_initiative_approval_chain c,'||wwv_flow.LF||
'                        sp_project_appr';
wwv_flow_imp.g_varchar2_table(310) := 'ovals a,'||wwv_flow.LF||
'                        sp_team_members t'||wwv_flow.LF||
'                  where a.id = c2.approval_id'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(311) := '                 and a.initiative_approval_id = c.initiative_approval_id'||wwv_flow.LF||
'                    and c.t';
wwv_flow_imp.g_varchar2_table(312) := 'eam_member_id = t.id'||wwv_flow.LF||
'                    and c.id not in (select initiative_approval_chain_id'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(313) := '                                 from sp_project_approval_chain'||wwv_flow.LF||
'                                    ';
wwv_flow_imp.g_varchar2_table(314) := '  where project_approval_id = c2.approval_id)'||wwv_flow.LF||
'                  order by c.approval_seq'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(315) := '      )'||wwv_flow.LF||
'             ) loop'||wwv_flow.LF||
'                 x2 := x2||''    * ''|| c3.reviewer;'||wwv_flow.LF||
'                 if c';
wwv_flow_imp.g_varchar2_table(316) := '3.rownum = l_future_reviewer_cnt then'||wwv_flow.LF||
'                    x2 := x2||'', final reviewer''||chr(10);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(317) := '              elsif c3.rownum = 1 then'||wwv_flow.LF||
'                    x2 := x2||'', next reviewer''||chr(10);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(318) := '              else'||wwv_flow.LF||
'                    x2 := x2||chr(10);'||wwv_flow.LF||
'                 end if;'||wwv_flow.LF||
'              '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(319) := '           end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'      '||wwv_flow.LF||
'         l_first_yn := ''N'';'||wwv_flow.LF||
''||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    end l';
wwv_flow_imp.g_varchar2_table(320) := 'oop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- APPROVALS NOT YET REQUESTED'||wwv_flow.LF||
'    for c2 in ('||wwv_flow.LF||
'        select t.approval_type'||wwv_flow.LF||
'          fr';
wwv_flow_imp.g_varchar2_table(321) := 'om SP_INITIATIVE_APPROVALS a,'||wwv_flow.LF||
'               sp_approval_types t'||wwv_flow.LF||
'         where a.initiative_id = c1';
wwv_flow_imp.g_varchar2_table(322) := '.initiative_id'||wwv_flow.LF||
'           and a.approval_type_id = t.id'||wwv_flow.LF||
'           and a.active_yn = ''Y'''||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(323) := 'and t.active_yn = ''Y'''||wwv_flow.LF||
'           and a.id not in (select initiative_approval_id'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(324) := '          from sp_project_approvals'||wwv_flow.LF||
'                             where project_id = c1.project_id)'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(325) := '       order by t.display_seq'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        -- if no approvals yet, need to include the heading';
wwv_flow_imp.g_varchar2_table(326) := ''||wwv_flow.LF||
'        if l_first_yn = ''Y'' then'||wwv_flow.LF||
'            x2 := x2||''##### Approvals''||chr(10);'||wwv_flow.LF||
'            l_fi';
wwv_flow_imp.g_varchar2_table(327) := 'rst_yn := ''N'';'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        x2 := x2||''* **''||c2.approval_type||''**''||'', not yet requeste';
wwv_flow_imp.g_varchar2_table(328) := 'd''||chr(10);'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if x2 is not null then'||wwv_flow.LF||
'       x2 := x2||chr(10);'||wwv_flow.LF||
'       sys.dbms_lob';
wwv_flow_imp.g_varchar2_table(329) := '.append(x, x2);'||wwv_flow.LF||
'       x2 := null;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_yn := ''Y'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- COMMENTS'||wwv_flow.LF||
'    for c2 ';
wwv_flow_imp.g_varchar2_table(330) := 'in ('||wwv_flow.LF||
'        select * from'||wwv_flow.LF||
'        ('||wwv_flow.LF||
'        select tm.first_name || '' '' || tm.last_name user_name,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(331) := '               pc.body_no_images comment_text,'||wwv_flow.LF||
'               pc.created,'||wwv_flow.LF||
'               row_number(';
wwv_flow_imp.g_varchar2_table(332) := ' ) over (partition by pc.project_id order by pc.created desc) last_added'||wwv_flow.LF||
'          from sp_project_c';
wwv_flow_imp.g_varchar2_table(333) := 'omments pc, '||wwv_flow.LF||
'               sp_team_members tm'||wwv_flow.LF||
'        where pc.author_id = tm.id (+)'||wwv_flow.LF||
'          and ';
wwv_flow_imp.g_varchar2_table(334) := 'pc.project_id = c1.project_id'||wwv_flow.LF||
'          and nvl(pc.private_yn,''N'') = ''N'''||wwv_flow.LF||
'          and ( (p_summary_';
wwv_flow_imp.g_varchar2_table(335) := 'type = ''full'' and pc.created > sysdate-90) or'||wwv_flow.LF||
'                 pc.created >=  nvl(l_last_summary,pc.';
wwv_flow_imp.g_varchar2_table(336) := 'updated-1) )'||wwv_flow.LF||
'        )'||wwv_flow.LF||
'        where last_added <= 10'||wwv_flow.LF||
'        order by created desc'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(337) := '  if l_first_yn = ''Y'' then'||wwv_flow.LF||
'         x2 := ''##### Most Recent Comments''||chr(10);'||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
''||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(338) := '   x2 := x2||''* comment added by ''||c2.user_name||'' on ''||to_char(c2.created,''DD-Mon-YYYY'')||chr(10)';
wwv_flow_imp.g_varchar2_table(339) := '||'||wwv_flow.LF||
'                   c2.comment_text||chr(10);'||wwv_flow.LF||
''||wwv_flow.LF||
'      l_first_yn := ''N'';'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if x2 i';
wwv_flow_imp.g_varchar2_table(340) := 's not null then'||wwv_flow.LF||
'       x2 := x2||chr(10);'||wwv_flow.LF||
'       sys.dbms_lob.append(x, x2);'||wwv_flow.LF||
'       x2 := null;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(341) := 'end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_first_yn := ''Y'';'||wwv_flow.LF||
''||wwv_flow.LF||
'end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'p_summary := x;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(342) := 'sp_util.add_error_log ('||wwv_flow.LF||
'            p_package_name   => ''sp_summary_util'','||wwv_flow.LF||
'            p_procedure_n';
wwv_flow_imp.g_varchar2_table(343) := 'ame => ''summarize_project'', '||wwv_flow.LF||
'            p_error          => sqlerrm, '||wwv_flow.LF||
'            p_arg1_name      ';
wwv_flow_imp.g_varchar2_table(344) := '=> ''p_project_id'',   p_arg1_val => p_project_id, '||wwv_flow.LF||
'            p_arg2_name      => ''p_summary_type'', ';
wwv_flow_imp.g_varchar2_table(345) := 'p_arg2_val => p_summary_type );'||wwv_flow.LF||
'end summarize_project;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- can be run from APEX App UI (not SQL Com';
wwv_flow_imp.g_varchar2_table(346) := 'mands) or from within a job (if session context is set)'||wwv_flow.LF||
'procedure generate_project_summary ('||wwv_flow.LF||
'    p_p';
wwv_flow_imp.g_varchar2_table(347) := 'roject_id    in   number,'||wwv_flow.LF||
'    p_summary_type  in   varchar2,'||wwv_flow.LF||
'    p_ai_id         out  number,'||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(348) := 'error_yn      out  varchar2 )'||wwv_flow.LF||
'as'||wwv_flow.LF||
'    l_system_prompt    clob;'||wwv_flow.LF||
'    l_project_details  clob;'||wwv_flow.LF||
'    l_id_';
wwv_flow_imp.g_varchar2_table(349) := 'to_replace    number;'||wwv_flow.LF||
'    l_ai_service       varchar2(60);'||wwv_flow.LF||
'    l_ai_sum           clob;'||wwv_flow.LF||
'    l_json_v';
wwv_flow_imp.g_varchar2_table(350) := 'alues      apex_json.t_values;'||wwv_flow.LF||
'    l_summary          clob;'||wwv_flow.LF||
'    l_highlights       varchar2(4000);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(351) := '   l_risk             varchar2(100);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    p_error_yn := ''N'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- add in today''s date'||wwv_flow.LF||
'    l';
wwv_flow_imp.g_varchar2_table(352) := '_system_prompt := ''Today is ''|| to_char(sysdate,''DD-Mon-YYYY'')||chr(10);'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_summary_type = ''f';
wwv_flow_imp.g_varchar2_table(353) := 'ull'' then'||wwv_flow.LF||
'       l_system_prompt := l_system_prompt||chr(10)||sp_util.get_ai_prompt (p_static_id => ';
wwv_flow_imp.g_varchar2_table(354) := '''PROJECT_FULL_SUMMARY'');'||wwv_flow.LF||
'    elsif p_summary_type = ''update'' then'||wwv_flow.LF||
'       l_system_prompt := l_system';
wwv_flow_imp.g_varchar2_table(355) := '_prompt||chr(10)||sp_util.get_ai_prompt (p_static_id => ''PROJECT_UPDATE_SUMMARY'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(356) := 'summarize_project ('||wwv_flow.LF||
'        p_project_id    => p_project_id,'||wwv_flow.LF||
'        p_summary_type  => p_summary_ty';
wwv_flow_imp.g_varchar2_table(357) := 'pe,'||wwv_flow.LF||
'        p_summary       => l_project_details,'||wwv_flow.LF||
'        p_id_to_replace => l_id_to_replace );'||wwv_flow.LF||
''||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(358) := ' if l_project_details is not null then'||wwv_flow.LF||
''||wwv_flow.LF||
'        insert into sp_project_ai_summaries'||wwv_flow.LF||
'            (pro';
wwv_flow_imp.g_varchar2_table(359) := 'ject_id, summary_type, prompt_sent, details_sent)'||wwv_flow.LF||
'        values '||wwv_flow.LF||
'            (p_project_id, p_summa';
wwv_flow_imp.g_varchar2_table(360) := 'ry_type, l_system_prompt, l_project_details)'||wwv_flow.LF||
'        returning id into p_ai_id;'||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(361) := '     l_ai_service := sp_util.get_setting (p_static_id => ''SUMMARY_AI_SERVICE'');'||wwv_flow.LF||
''||wwv_flow.LF||
'        if l_ai_ser';
wwv_flow_imp.g_varchar2_table(362) := 'vice is not null and'||wwv_flow.LF||
'           apex_application_admin.get_build_option_status ('||wwv_flow.LF||
'               p_ap';
wwv_flow_imp.g_varchar2_table(363) := 'plication_id    => sp_util.get_setting (p_static_id => ''APP_ID''),'||wwv_flow.LF||
'               p_build_option_name';
wwv_flow_imp.g_varchar2_table(364) := ' => ''AI Project Summaries'' ) = ''INCLUDE'''||wwv_flow.LF||
'        then'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- wrapping to continue if ai err';
wwv_flow_imp.g_varchar2_table(365) := 'or'||wwv_flow.LF||
'            begin'||wwv_flow.LF||
'                l_ai_sum := apex_ai.generate ('||wwv_flow.LF||
'                                ';
wwv_flow_imp.g_varchar2_table(366) := 'p_prompt            => ''Summarize the following project updates: '' || escape_markdown(l_project_deta';
wwv_flow_imp.g_varchar2_table(367) := 'ils),'||wwv_flow.LF||
'                                p_system_prompt     => l_system_prompt,'||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(368) := '          p_service_static_id => l_ai_service ); '||wwv_flow.LF||
''||wwv_flow.LF||
'                -- store date_received in case th';
wwv_flow_imp.g_varchar2_table(369) := 'e json parse fails'||wwv_flow.LF||
'                update sp_project_ai_summaries'||wwv_flow.LF||
'                   set data_receiv';
wwv_flow_imp.g_varchar2_table(370) := 'ed = l_ai_sum'||wwv_flow.LF||
'                 where id = p_ai_id;'||wwv_flow.LF||
'                 commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'                apex_js';
wwv_flow_imp.g_varchar2_table(371) := 'on.parse(p_values => l_json_values, p_source => l_ai_sum);'||wwv_flow.LF||
'                l_summary    := apex_json';
wwv_flow_imp.g_varchar2_table(372) := '.get_clob(p_values => l_json_values, p_path => ''summary'');'||wwv_flow.LF||
'                l_risk       := apex_json';
wwv_flow_imp.g_varchar2_table(373) := '.get_varchar2(p_values => l_json_values, p_path => ''risk'');'||wwv_flow.LF||
''||wwv_flow.LF||
'                -- extract the highligh';
wwv_flow_imp.g_varchar2_table(374) := 'ts as a list'||wwv_flow.LF||
'                for c2 in ('||wwv_flow.LF||
'                    select highlights.*'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(375) := '   from dual, '||wwv_flow.LF||
'                           json_table (l_ai_sum, ''$.highlights[*]'' '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(376) := '                      columns (highlight varchar2(1000) path ''$'')) highlights'||wwv_flow.LF||
'                ) loop';
wwv_flow_imp.g_varchar2_table(377) := ''||wwv_flow.LF||
'                    l_highlights := l_highlights || ''<li>'' || c2.highlight || ''</li>'';'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(378) := '    end loop;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'                update sp_project_ai_summaries'||wwv_flow.LF||
'                   set summary = l';
wwv_flow_imp.g_varchar2_table(379) := '_summary,'||wwv_flow.LF||
'                       risk = l_risk,'||wwv_flow.LF||
'                       highlights = ''<ul>''||l_highli';
wwv_flow_imp.g_varchar2_table(380) := 'ghts||''</ul>'''||wwv_flow.LF||
'                 where id = p_ai_id;'||wwv_flow.LF||
'                 commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'                -- remo';
wwv_flow_imp.g_varchar2_table(381) := 've previous summary as it is being replaced (generated within the g_hrs_to_replace window)'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(382) := '       if l_id_to_replace is not null then'||wwv_flow.LF||
'                   delete from sp_project_ai_summaries'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(383) := '                  where id = l_id_to_replace;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'            exception '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(384) := '          when others then '||wwv_flow.LF||
'                    p_error_yn := ''Y'';'||wwv_flow.LF||
'                    sp_util.add_e';
wwv_flow_imp.g_varchar2_table(385) := 'rror_log ('||wwv_flow.LF||
'                        p_package_name   => ''sp_summary_util'','||wwv_flow.LF||
'                        p_';
wwv_flow_imp.g_varchar2_table(386) := 'procedure_name => ''generate_project_summary'', '||wwv_flow.LF||
'                        p_error          => sqlerrm, ';
wwv_flow_imp.g_varchar2_table(387) := ''||wwv_flow.LF||
'                        p_arg1_name      => ''p_project_id'',   p_arg1_val => p_project_id, '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(388) := '                p_arg2_name      => ''p_summary_type'', p_arg2_val => p_summary_type, '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(389) := '         p_arg3_name      => ''p_ai_id'', p_arg3_val => p_ai_id );'||wwv_flow.LF||
'            end;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(390) := '  else'||wwv_flow.LF||
'        sp_util.add_error_log ('||wwv_flow.LF||
'            p_package_name   => ''sp_summary_util'','||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(391) := '  p_procedure_name => ''generate_project_summary'', '||wwv_flow.LF||
'            p_error          => ''summarize_projec';
wwv_flow_imp.g_varchar2_table(392) := 't_project returned without summary'', '||wwv_flow.LF||
'            p_arg1_name      => ''p_project_id'',   p_arg1_val =';
wwv_flow_imp.g_varchar2_table(393) := '> p_project_id, '||wwv_flow.LF||
'            p_arg2_name      => ''p_summary_type'', p_arg2_val => p_summary_type );'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(394) := '   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'end generate_project_summary;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- run as a job, once a week'||wwv_flow.LF||
'procedure generate_project';
wwv_flow_imp.g_varchar2_table(395) := '_summaries as'||wwv_flow.LF||
'    l_app_id           number;'||wwv_flow.LF||
'    l_summary_type     varchar2(30);'||wwv_flow.LF||
'    l_ai_id       ';
wwv_flow_imp.g_varchar2_table(396) := '     number;'||wwv_flow.LF||
'    l_error_yn         varchar2(1);'||wwv_flow.LF||
'    l_ai_error_cnt     number := 0;'||wwv_flow.LF||
'    l_summary_c';
wwv_flow_imp.g_varchar2_table(397) := 'nt      number := 0;'||wwv_flow.LF||
'    l_max_errors       number := 3;  -- exit when this many errors '||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(398) := 'l_app_id := sp_util.get_setting (p_static_id => ''APP_ID'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- when run from a job, need a sessi';
wwv_flow_imp.g_varchar2_table(399) := 'on'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select workspace, workspace_id'||wwv_flow.LF||
'          from apex_applications'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(400) := 'where application_id = l_app_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        apex_util.set_workspace (p_workspace => c1.worksp';
wwv_flow_imp.g_varchar2_table(401) := 'ace );'||wwv_flow.LF||
'        apex_util.set_security_group_id(p_security_group_id => c1.workspace_id );'||wwv_flow.LF||
'    end loo';
wwv_flow_imp.g_varchar2_table(402) := 'p;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- if build not not enabled, nothing will be run (careful to not update build option names)'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(403) := '    if apex_util.get_build_option_status ('||wwv_flow.LF||
'           p_application_id    => l_app_id, '||wwv_flow.LF||
'           p';
wwv_flow_imp.g_varchar2_table(404) := '_build_option_name => ''AI Project Summaries'') = ''INCLUDE'''||wwv_flow.LF||
'    then'||wwv_flow.LF||
'        apex_session.create_sessi';
wwv_flow_imp.g_varchar2_table(405) := 'on ('||wwv_flow.LF||
'           p_app_id   => l_app_id,'||wwv_flow.LF||
'           p_page_id  => 1,'||wwv_flow.LF||
'           p_username => ''AI'' );';
wwv_flow_imp.g_varchar2_table(406) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'        -- get count of projects that should be summarized'||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            select ';
wwv_flow_imp.g_varchar2_table(407) := 'count(*) cnt'||wwv_flow.LF||
'              from'||wwv_flow.LF||
'            ('||wwv_flow.LF||
'            select updated,'||wwv_flow.LF||
'                   (select';
wwv_flow_imp.g_varchar2_table(408) := ' max(created) from sp_project_ai_summaries'||wwv_flow.LF||
'                     where project_id = p.id) last_summar';
wwv_flow_imp.g_varchar2_table(409) := 'y'||wwv_flow.LF||
'              from sp_projects p'||wwv_flow.LF||
'             where pct_complete > 10'||wwv_flow.LF||
'               and updated >';
wwv_flow_imp.g_varchar2_table(410) := ' sysdate-90'||wwv_flow.LF||
'               and archived_yn = ''N'''||wwv_flow.LF||
'               and duplicate_of_project_id is null'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(411) := '            )'||wwv_flow.LF||
'             where last_summary is null or updated > last_summary'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(412) := '       sp_util.add_app_log ('||wwv_flow.LF||
'                p_activity => ''sp_summary_util.generate_project_summari';
wwv_flow_imp.g_varchar2_table(413) := 'es'', '||wwv_flow.LF||
'                p_details  => ''Should create ''||c1.cnt||'' project summaries'');'||wwv_flow.LF||
'        end loo';
wwv_flow_imp.g_varchar2_table(414) := 'p;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- only check projects updated in the last 90 days that are more than 10% complete'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(415) := '   for c1 in ('||wwv_flow.LF||
'            select id, updated, pct_complete,'||wwv_flow.LF||
'                   (select max(created)';
wwv_flow_imp.g_varchar2_table(416) := ' from sp_project_ai_summaries'||wwv_flow.LF||
'                     where project_id = p.id) last_summary'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(417) := '   from sp_projects p'||wwv_flow.LF||
'             where pct_complete > 10'||wwv_flow.LF||
'               and updated > sysdate-90'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(418) := '              and archived_yn = ''N'''||wwv_flow.LF||
'               and duplicate_of_project_id is null'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(419) := 'order by updated desc'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- only summarize if no summary yet or there has b';
wwv_flow_imp.g_varchar2_table(420) := 'een an update since the last summary'||wwv_flow.LF||
'            if c1.last_summary is null or c1.updated > c1.last_';
wwv_flow_imp.g_varchar2_table(421) := 'summary then'||wwv_flow.LF||
''||wwv_flow.LF||
'                l_summary_type := case when c1.pct_complete = 100'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(422) := '                   then ''full'''||wwv_flow.LF||
'                                       when c1.last_summary is null'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(423) := '                                      then ''full'''||wwv_flow.LF||
'                                       else ''updat';
wwv_flow_imp.g_varchar2_table(424) := 'e'''||wwv_flow.LF||
'                                       end;'||wwv_flow.LF||
''||wwv_flow.LF||
'                generate_project_summary ('||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(425) := '           p_project_id   => c1.id,'||wwv_flow.LF||
'                    p_summary_type => l_summary_type,'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(426) := '          p_ai_id        => l_ai_id,'||wwv_flow.LF||
'                    p_error_yn     => l_error_yn );'||wwv_flow.LF||
''||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(427) := '      if l_error_yn = ''Y'' then'||wwv_flow.LF||
'                   l_ai_error_cnt := l_ai_error_cnt + 1;'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(428) := '    else'||wwv_flow.LF||
'                   l_summary_cnt := l_summary_cnt + 1;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(429) := '     exit when l_ai_error_cnt = l_max_errors;'||wwv_flow.LF||
''||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'        sp_ut';
wwv_flow_imp.g_varchar2_table(430) := 'il.add_app_log ('||wwv_flow.LF||
'            p_activity => ''sp_summary_util.generate_project_summaries'', '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(431) := '  p_details  => ''Created ''||l_summary_cnt||'' project summaries'');'||wwv_flow.LF||
''||wwv_flow.LF||
'        apex_session.delete_sessi';
wwv_flow_imp.g_varchar2_table(432) := 'on;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        sp_util.add_error_log ('||wwv_flow.LF||
'            p_packag';
wwv_flow_imp.g_varchar2_table(433) := 'e_name   => ''sp_summary_util'','||wwv_flow.LF||
'            p_procedure_name => ''generate_project_summaries'', '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(434) := '      p_error          => sqlerrm );'||wwv_flow.LF||
'end generate_project_summaries;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure summarize_release ';
wwv_flow_imp.g_varchar2_table(435) := '('||wwv_flow.LF||
'    p_release_id  in   number,'||wwv_flow.LF||
'    p_summary     out  clob )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    x             clob        := n';
wwv_flow_imp.g_varchar2_table(436) := 'ull;'||wwv_flow.LF||
'    x2            clob        := null;'||wwv_flow.LF||
'    l_focus_area  varchar2(60);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'for c1 in ('||wwv_flow.LF||
'    s';
wwv_flow_imp.g_varchar2_table(437) := 'elect r.id release_id,'||wwv_flow.LF||
'           r.release_train||'' - ''||r.release release,'||wwv_flow.LF||
'           r.release_ty';
wwv_flow_imp.g_varchar2_table(438) := 'pe,'||wwv_flow.LF||
'           r.release_open_date, '||wwv_flow.LF||
'           r.release_target_date'||wwv_flow.LF||
'      from sp_release_trains r';
wwv_flow_imp.g_varchar2_table(439) := ''||wwv_flow.LF||
'     where r.id = p_release_id'||wwv_flow.LF||
') loop'||wwv_flow.LF||
''||wwv_flow.LF||
'    x := ''### Release ''||c1.release||chr(10)||'||wwv_flow.LF||
'            ''';
wwv_flow_imp.g_varchar2_table(440) := 'type: ''||initcap(c1.release_type)||chr(10)||'||wwv_flow.LF||
'            ''date range: ''||to_char(c1.release_open_dat';
wwv_flow_imp.g_varchar2_table(441) := 'e,''DD-Mon-YYYY'')||'' to ''||to_char(c1.release_target_date,''DD-Mon-YYYY'')||chr(10)||'||wwv_flow.LF||
'            ''####';
wwv_flow_imp.g_varchar2_table(442) := ' Features Included''||chr(10);'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c2 in ('||wwv_flow.LF||
'        select a.focus_area, '||wwv_flow.LF||
'               p.projec';
wwv_flow_imp.g_varchar2_table(443) := 't, '||wwv_flow.LF||
'               p.project_size, '||wwv_flow.LF||
'               pp.description project_priority,'||wwv_flow.LF||
'               d';
wwv_flow_imp.g_varchar2_table(444) := 'bms_lob.substr(p.description,400,1) project_desc,'||wwv_flow.LF||
'               dbms_lob.getlength(p.description) d';
wwv_flow_imp.g_varchar2_table(445) := 'esc_length'||wwv_flow.LF||
'          from sp_projects p,'||wwv_flow.LF||
'               sp_project_priorities pp,'||wwv_flow.LF||
'               sp_';
wwv_flow_imp.g_varchar2_table(446) := 'initiative_focus_areas a'||wwv_flow.LF||
'         where p.release_id = c1.release_id'||wwv_flow.LF||
'           and p.archived_yn = ';
wwv_flow_imp.g_varchar2_table(447) := '''N'''||wwv_flow.LF||
'           and p.duplicate_of_project_id is null'||wwv_flow.LF||
'           and p.focus_area_id = a.id (+)'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(448) := '      and p.priority_id = pp.id (+)'||wwv_flow.LF||
'         order by a.display_sequence nulls last, a.focus_area nu';
wwv_flow_imp.g_varchar2_table(449) := 'lls last, pp.description, p.project'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        if nvl(c2.focus_area,''~'') != nvl(l_focus_area';
wwv_flow_imp.g_varchar2_table(450) := ',''~'') then'||wwv_flow.LF||
'           if c2.focus_area is not null then'||wwv_flow.LF||
'              x2 := ''##### Focus Area: ''||c2';
wwv_flow_imp.g_varchar2_table(451) := '.focus_area||chr(10);'||wwv_flow.LF||
'           else'||wwv_flow.LF||
'              x2 := ''##### No Focus Area''||chr(10);'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(452) := ' end if;'||wwv_flow.LF||
'           l_focus_area := c2.focus_area;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        x2 := x2||''######  ''||c2';
wwv_flow_imp.g_varchar2_table(453) := '.project||chr(10)||'||wwv_flow.LF||
'                        ''  Size: ''||c2.project_size||chr(10)||'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(454) := '       case when c2.project_priority is not null '||wwv_flow.LF||
'                             then ''  Priority: ''||';
wwv_flow_imp.g_varchar2_table(455) := 'c2.project_priority||chr(10)'||wwv_flow.LF||
'                             end ||'||wwv_flow.LF||
'                        case when c';
wwv_flow_imp.g_varchar2_table(456) := '2.desc_length > 0'||wwv_flow.LF||
'                             then ''  ''||c2.project_desc||'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(457) := '          case when c2.desc_length > 400 then '' ...'' end ||'||wwv_flow.LF||
'                                  chr(10';
wwv_flow_imp.g_varchar2_table(458) := ')'||wwv_flow.LF||
'                             end;'||wwv_flow.LF||
''||wwv_flow.LF||
'        sys.dbms_lob.append(x, x2);'||wwv_flow.LF||
'        x2 := null;'||wwv_flow.LF||
'    end';
wwv_flow_imp.g_varchar2_table(459) := ' loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'p_summary := x;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        sp_util.add_error_log ('||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(460) := '           p_package_name   => ''sp_summary_util'','||wwv_flow.LF||
'            p_procedure_name => ''summarize_release';
wwv_flow_imp.g_varchar2_table(461) := ''', '||wwv_flow.LF||
'            p_error          => sqlerrm, '||wwv_flow.LF||
'            p_arg1_name      => ''p_release_id'', p_arg1';
wwv_flow_imp.g_varchar2_table(462) := '_val => p_release_id );'||wwv_flow.LF||
'end summarize_release;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- can be run from APEX App UI (not SQL Commands) o';
wwv_flow_imp.g_varchar2_table(463) := 'r from within a job (if session context is set)'||wwv_flow.LF||
'procedure generate_release_summary ('||wwv_flow.LF||
'    p_release_i';
wwv_flow_imp.g_varchar2_table(464) := 'd    in   number,'||wwv_flow.LF||
'    p_error_yn      out  varchar2 )'||wwv_flow.LF||
'as'||wwv_flow.LF||
'    l_system_prompt    clob;'||wwv_flow.LF||
'    l_release_';
wwv_flow_imp.g_varchar2_table(465) := 'details  clob;'||wwv_flow.LF||
'    l_id_to_remove     number;'||wwv_flow.LF||
'    l_ai_service       varchar2(60);'||wwv_flow.LF||
'    l_ai_id      ';
wwv_flow_imp.g_varchar2_table(466) := '      number;'||wwv_flow.LF||
'    l_ai_sum           clob;'||wwv_flow.LF||
'    l_json_values      apex_json.t_values;'||wwv_flow.LF||
'    l_summary ';
wwv_flow_imp.g_varchar2_table(467) := '         clob;'||wwv_flow.LF||
'    l_highlights       varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    p_error_yn := ''N'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- add in t';
wwv_flow_imp.g_varchar2_table(468) := 'oday''s date'||wwv_flow.LF||
'    l_system_prompt := ''Today is ''|| to_char(sysdate,''DD-Mon-YYYY'')||chr(10)||'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(469) := '               sp_util.get_ai_prompt (p_static_id => ''RELEASE_SUMMARY'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    summarize_release ('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(470) := '      p_release_id    => p_release_id,'||wwv_flow.LF||
'        p_summary       => l_release_details);'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_rele';
wwv_flow_imp.g_varchar2_table(471) := 'ase_details is not null then'||wwv_flow.LF||
''||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            select id'||wwv_flow.LF||
'              from sp_releas';
wwv_flow_imp.g_varchar2_table(472) := 'e_ai_summaries'||wwv_flow.LF||
'             where release_id = p_release_id'||wwv_flow.LF||
'               and created > sysdate - g';
wwv_flow_imp.g_varchar2_table(473) := '_hrs_to_replace/24'||wwv_flow.LF||
'             order by created desc'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            l_id_to_remove := c';
wwv_flow_imp.g_varchar2_table(474) := '1.id;'||wwv_flow.LF||
'            exit;  -- exit to just get the last one, in case more than one in the delete range';
wwv_flow_imp.g_varchar2_table(475) := ''||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'        insert into sp_release_ai_summaries'||wwv_flow.LF||
'            (release_id, prompt_sent';
wwv_flow_imp.g_varchar2_table(476) := ', details_sent)'||wwv_flow.LF||
'        values '||wwv_flow.LF||
'            (p_release_id, l_system_prompt, l_release_details)'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(477) := '   returning id into l_ai_id;'||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_ai_service := sp_util.get_setting (p_static';
wwv_flow_imp.g_varchar2_table(478) := '_id => ''SUMMARY_AI_SERVICE'');'||wwv_flow.LF||
''||wwv_flow.LF||
'        if l_ai_service is not null and'||wwv_flow.LF||
'           apex_application_a';
wwv_flow_imp.g_varchar2_table(479) := 'dmin.get_build_option_status ('||wwv_flow.LF||
'               p_application_id    => sp_util.get_setting (p_static_i';
wwv_flow_imp.g_varchar2_table(480) := 'd => ''APP_ID''),'||wwv_flow.LF||
'               p_build_option_name => ''AI Release Summaries'' ) = ''INCLUDE'''||wwv_flow.LF||
'        t';
wwv_flow_imp.g_varchar2_table(481) := 'hen'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- wrapping to continue if ai error'||wwv_flow.LF||
'            begin'||wwv_flow.LF||
'                l_ai_sum := a';
wwv_flow_imp.g_varchar2_table(482) := 'pex_ai.generate ('||wwv_flow.LF||
'                                p_prompt            => ''Summarize the following pr';
wwv_flow_imp.g_varchar2_table(483) := 'oduct release: '' || escape_markdown(l_release_details),'||wwv_flow.LF||
'                                p_system_pro';
wwv_flow_imp.g_varchar2_table(484) := 'mpt     => l_system_prompt,'||wwv_flow.LF||
'                                p_service_static_id => l_ai_service ); '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(485) := ''||wwv_flow.LF||
'                -- save data_received, in case the json parse fails'||wwv_flow.LF||
'                update sp_relea';
wwv_flow_imp.g_varchar2_table(486) := 'se_ai_summaries'||wwv_flow.LF||
'                   set data_received = l_ai_sum'||wwv_flow.LF||
'                 where id = l_ai_id;';
wwv_flow_imp.g_varchar2_table(487) := ''||wwv_flow.LF||
'                 commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'                apex_json.parse(p_values => l_json_values, p_source => l_';
wwv_flow_imp.g_varchar2_table(488) := 'ai_sum);'||wwv_flow.LF||
'                l_summary    := apex_json.get_clob(p_values => l_json_values, p_path => ''su';
wwv_flow_imp.g_varchar2_table(489) := 'mmary'');'||wwv_flow.LF||
''||wwv_flow.LF||
'                -- extract the highlights as a list'||wwv_flow.LF||
'                for c2 in ('||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(490) := '          select highlights.*'||wwv_flow.LF||
'                      from dual, '||wwv_flow.LF||
'                           json_tabl';
wwv_flow_imp.g_varchar2_table(491) := 'e (l_ai_sum, ''$.highlights[*]'' '||wwv_flow.LF||
'                                       columns (highlight varchar2(1';
wwv_flow_imp.g_varchar2_table(492) := '000) path ''$'')) highlights'||wwv_flow.LF||
'                ) loop'||wwv_flow.LF||
'                    l_highlights := l_highlights |';
wwv_flow_imp.g_varchar2_table(493) := '| ''<li>'' || c2.highlight || ''</li>'';'||wwv_flow.LF||
'                end loop;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'                update sp_releas';
wwv_flow_imp.g_varchar2_table(494) := 'e_ai_summaries'||wwv_flow.LF||
'                   set summary = l_summary,'||wwv_flow.LF||
'                       highlights = ''<ul>';
wwv_flow_imp.g_varchar2_table(495) := '''||l_highlights||''</ul>'''||wwv_flow.LF||
'                 where id = l_ai_id;'||wwv_flow.LF||
'                 commit;'||wwv_flow.LF||
'/*'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(496) := '      -- remove previous summary as it is being replaced (generated within the g_hrs_to_replace wind';
wwv_flow_imp.g_varchar2_table(497) := 'ow)'||wwv_flow.LF||
'                if l_id_to_remove is not null then'||wwv_flow.LF||
'                   delete from sp_project_ai_';
wwv_flow_imp.g_varchar2_table(498) := 'summaries'||wwv_flow.LF||
'                    where id = l_id_to_remove;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'*/'||wwv_flow.LF||
'            exce';
wwv_flow_imp.g_varchar2_table(499) := 'ption '||wwv_flow.LF||
'                when others then '||wwv_flow.LF||
'                    p_error_yn := ''Y'';'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(500) := 'sp_util.add_error_log ('||wwv_flow.LF||
'                        p_package_name   => ''sp_summary_util'','||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(501) := '           p_procedure_name => ''generate_release_summary'', '||wwv_flow.LF||
'                        p_error         ';
wwv_flow_imp.g_varchar2_table(502) := ' => sqlerrm, '||wwv_flow.LF||
'                        p_arg1_name      => ''p_release_id'', p_arg1_val => p_release_id';
wwv_flow_imp.g_varchar2_table(503) := ', '||wwv_flow.LF||
'                        p_arg2_name      => ''l_ai_id'',      p_arg2_val => l_ai_id );'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(504) := 'end;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        sp_util.add_error_log ('||wwv_flow.LF||
'            p_package_name   => ''sp_s';
wwv_flow_imp.g_varchar2_table(505) := 'ummary_util'','||wwv_flow.LF||
'            p_procedure_name => ''generate_release_summary'', '||wwv_flow.LF||
'            p_error      ';
wwv_flow_imp.g_varchar2_table(506) := '    => ''summarize_release_project returned without summary'', '||wwv_flow.LF||
'            p_arg1_name      => ''p_rel';
wwv_flow_imp.g_varchar2_table(507) := 'ease_id'', p_arg1_val => p_release_id );'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'end generate_release_summary;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_summary_';
wwv_flow_imp.g_varchar2_table(508) := 'util;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(27818815207337246833)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_summary_util body'
,p_sequence=>768
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
