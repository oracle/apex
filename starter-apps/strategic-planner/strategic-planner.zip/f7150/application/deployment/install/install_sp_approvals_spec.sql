prompt --application/deployment/install/install_sp_approvals_spec
begin
--   Manifest
--     INSTALL: INSTALL-sp_approvals spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package sp_approvals'||wwv_flow.LF||
'as'||wwv_flow.LF||
''||wwv_flow.LF||
'------------------'||wwv_flow.LF||
'-- called by UI'||wwv_flow.LF||
'------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'pr';
wwv_flow_imp.g_varchar2_table(2) := 'ocedure submit_for_approval ('||wwv_flow.LF||
'    p_project_id           in  number,'||wwv_flow.LF||
'    p_approval_type_id     in  ';
wwv_flow_imp.g_varchar2_table(3) := 'number,'||wwv_flow.LF||
'    p_team_member_id       in  number,'||wwv_flow.LF||
'    p_justification        in  varchar2,'||wwv_flow.LF||
'    p_projec';
wwv_flow_imp.g_varchar2_table(4) := 't_approval_id  out number );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure clarify ('||wwv_flow.LF||
'    p_project_approval_chain_id  number,'||wwv_flow.LF||
'    p_tea';
wwv_flow_imp.g_varchar2_table(5) := 'm_member_id             number,'||wwv_flow.LF||
'    p_response                   varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure withdraw ('||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(6) := '   p_project_approval_id  in  number,'||wwv_flow.LF||
'    p_team_member_id       in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
'function approval_pe';
wwv_flow_imp.g_varchar2_table(7) := 'nding ('||wwv_flow.LF||
'    p_project_id      in  number,'||wwv_flow.LF||
'    p_team_member_id  in  number'||wwv_flow.LF||
') return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'functio';
wwv_flow_imp.g_varchar2_table(8) := 'n more_info_pending ('||wwv_flow.LF||
'    p_project_id      in  number,'||wwv_flow.LF||
'    p_team_member_id  in  number'||wwv_flow.LF||
') return nu';
wwv_flow_imp.g_varchar2_table(9) := 'mber;'||wwv_flow.LF||
''||wwv_flow.LF||
'function approval_pending_cnt ('||wwv_flow.LF||
'    p_team_member_id  in  number'||wwv_flow.LF||
') return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'function m';
wwv_flow_imp.g_varchar2_table(10) := 'ore_info_pending_cnt ('||wwv_flow.LF||
'    p_team_member_id  in  number'||wwv_flow.LF||
') return number;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-------------------------';
wwv_flow_imp.g_varchar2_table(11) := '--------'||wwv_flow.LF||
'-- only used within workflow'||wwv_flow.LF||
'---------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure identify_next_rev';
wwv_flow_imp.g_varchar2_table(12) := 'iewer ('||wwv_flow.LF||
'    p_project_approval_id        in   number,'||wwv_flow.LF||
'    p_project_approval_chain_id  out  number,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(13) := '    p_reviewer_email             out  varchar2,'||wwv_flow.LF||
'    p_reviewer_tm_id             out  number );'||wwv_flow.LF||
''||wwv_flow.LF||
'pro';
wwv_flow_imp.g_varchar2_table(14) := 'cedure approve ('||wwv_flow.LF||
'    p_project_approval_chain_id  in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure reject ('||wwv_flow.LF||
'    p_project_ap';
wwv_flow_imp.g_varchar2_table(15) := 'proval_chain_id  in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
'-- for approve and reject, the comments are not available to the tas';
wwv_flow_imp.g_varchar2_table(16) := 'k until after the action'||wwv_flow.LF||
'procedure add_comments ('||wwv_flow.LF||
'    p_project_approval_chain_id  in  number,'||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(17) := '_comments                   in  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure request_clarification ('||wwv_flow.LF||
'    p_project_approva';
wwv_flow_imp.g_varchar2_table(18) := 'l_chain_id  in  number,'||wwv_flow.LF||
'    p_comments                   in  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure approve_request ';
wwv_flow_imp.g_varchar2_table(19) := '('||wwv_flow.LF||
'    p_project_approval_id  in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_approvals;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(52070539179268451956)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_approvals spec'
,p_sequence=>55
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
