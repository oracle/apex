prompt --application/deployment/install/install_release_documents_table_and_triggr
begin
--   Manifest
--     INSTALL: INSTALL-release_documents table and triggr
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_release_documents ('||wwv_flow.LF||
'    id                             number default on null to_num';
wwv_flow_imp.g_varchar2_table(2) := 'ber(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint s';
wwv_flow_imp.g_varchar2_table(3) := 'p_release_documents_pk primary key,'||wwv_flow.LF||
'    release_id                     number'||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(4) := '             constraint sp_release_doc_ini_id_fk'||wwv_flow.LF||
'                                   references sp_re';
wwv_flow_imp.g_varchar2_table(5) := 'lease_trains on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    document_blob                  blob,'||wwv_flow.LF||
'    document_filenam';
wwv_flow_imp.g_varchar2_table(6) := 'e              varchar2(512 char),'||wwv_flow.LF||
'    document_mimetype              varchar2(512 char),'||wwv_flow.LF||
'    docume';
wwv_flow_imp.g_varchar2_table(7) := 'nt_charset               varchar2(512 char),'||wwv_flow.LF||
'    document_lastupd               date,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    imp';
wwv_flow_imp.g_varchar2_table(8) := 'ortant_yn                   varchar2(1 char),'||wwv_flow.LF||
'    doc_description                varchar2(4000 char)';
wwv_flow_imp.g_varchar2_table(9) := ','||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    tags                           varchar2(4000 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                 ';
wwv_flow_imp.g_varchar2_table(10) := '       date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated   ';
wwv_flow_imp.g_varchar2_table(11) := '                     date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
')';
wwv_flow_imp.g_varchar2_table(12) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_release_documents_i1 on sp_release_documents (release_id);'||wwv_flow.LF||
'create index sp_releas';
wwv_flow_imp.g_varchar2_table(13) := 'e_documents_i2 on sp_release_documents (updated);'||wwv_flow.LF||
''||wwv_flow.LF||
'	'||wwv_flow.LF||
'create or replace trigger sp_release_documents_';
wwv_flow_imp.g_varchar2_table(14) := 'biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_release_documents'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_tags varc';
wwv_flow_imp.g_varchar2_table(15) := 'har2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new.create';
wwv_flow_imp.g_varchar2_table(16) := 'd_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysda';
wwv_flow_imp.g_varchar2_table(17) := 'te;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(18) := '--'||wwv_flow.LF||
'    :new.tags := upper(:new.tags);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_release_';
wwv_flow_imp.g_varchar2_table(19) := 'trains set updated = sysdate, updated_by = :new.updated_by where id = :new.release_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(20) := ' adjust tag data'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.tags is not null then'||wwv_flow.LF||
'        l_tags := trim(upper(:new.tags));'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(21) := '        -- remove multiple spaces'||wwv_flow.LF||
'        if instr(l_tags,''  '') > 0 then'||wwv_flow.LF||
'            for j in 1..10 ';
wwv_flow_imp.g_varchar2_table(22) := 'loop '||wwv_flow.LF||
'                l_tags := replace(l_tags,''  '','' ''); '||wwv_flow.LF||
'                if instr(l_tags,''  '') = 0';
wwv_flow_imp.g_varchar2_table(23) := ' then'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(24) := '  for i in 1..length(l_tags) loop'||wwv_flow.LF||
'            if i > 2 and substr(l_tags,i,1) = '' '' and substr(l_tag';
wwv_flow_imp.g_varchar2_table(25) := 's,i-1,1) != '','' then'||wwv_flow.LF||
'               l_tags := substr(l_tags,1,i-1)||''-''||substr(l_tags,i+1);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(26) := '     end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        :new.tags := l_tags;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(27) := '    if inserting then'||wwv_flow.LF||
'        insert into sp_release_history'||wwv_flow.LF||
'            (release_id, attribute_colu';
wwv_flow_imp.g_varchar2_table(28) := 'mn, change_type, new_value, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.release_id, ''DO';
wwv_flow_imp.g_varchar2_table(29) := 'CUMENT'', ''CREATE'', :new.DOCUMENT_FILENAME, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'    elsif updating then';
wwv_flow_imp.g_varchar2_table(30) := ' '||wwv_flow.LF||
'        insert into sp_release_history'||wwv_flow.LF||
'            (release_id, attribute_column, change_type, old';
wwv_flow_imp.g_varchar2_table(31) := '_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.release_id, ''DOCUMENT'', ';
wwv_flow_imp.g_varchar2_table(32) := '''UPDATE'', :old.DOCUMENT_FILENAME, :new.DOCUMENT_FILENAME, sysdate, lower(:new.updated_by));'||wwv_flow.LF||
'    end ';
wwv_flow_imp.g_varchar2_table(33) := 'if;'||wwv_flow.LF||
'end sp_release_documents_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_release_documents_bd'||wwv_flow.LF||
'    before de';
wwv_flow_imp.g_varchar2_table(34) := 'lete'||wwv_flow.LF||
'    on sp_release_documents'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_release_history'||wwv_flow.LF||
'        (';
wwv_flow_imp.g_varchar2_table(35) := 'release_id, attribute_column, change_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:o';
wwv_flow_imp.g_varchar2_table(36) := 'ld.release_id, ''DOCUMENT'', ''DELETE'', :old.document_filename, sysdate, lower(coalesce(sys_context(''AP';
wwv_flow_imp.g_varchar2_table(37) := 'EX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'end sp_release_documents_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(52335513652047733071)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'release_documents table and triggr'
,p_sequence=>310
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
