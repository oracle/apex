prompt --application/deployment/install/install_sp_comment_util_spec
begin
--   Manifest
--     INSTALL: INSTALL-sp_comment_util spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package sp_comment_util as'||wwv_flow.LF||
''||wwv_flow.LF||
'-- used in the views to swap in current user''s session';
wwv_flow_imp.g_varchar2_table(2) := ' id'||wwv_flow.LF||
'function replace_session_on_display ('||wwv_flow.LF||
'    p_body        in  clob,'||wwv_flow.LF||
'    p_session_id  in  number )';
wwv_flow_imp.g_varchar2_table(3) := ''||wwv_flow.LF||
'    return clob;'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_initiative_comment ('||wwv_flow.LF||
'    p_app_use';
wwv_flow_imp.g_varchar2_table(4) := 'r_id     in  number,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ';
wwv_flow_imp.g_varchar2_table(5) := '''N'','||wwv_flow.LF||
'    p_initiative_id   in  number,'||wwv_flow.LF||
'    p_image_ref_id    in  number   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure';
wwv_flow_imp.g_varchar2_table(6) := ' update_initiative_comment ('||wwv_flow.LF||
'    p_comment_id      in  number,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(7) := '   p_private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_image_ref_id    in  number   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'p';
wwv_flow_imp.g_varchar2_table(8) := 'rocedure delete_initiative_comment ('||wwv_flow.LF||
'    p_comment_id      in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_project_com';
wwv_flow_imp.g_varchar2_table(9) := 'ment ('||wwv_flow.LF||
'    p_app_user_id     in  number,'||wwv_flow.LF||
'    p_app_user        in  varchar2,'||wwv_flow.LF||
'    p_comment         i';
wwv_flow_imp.g_varchar2_table(10) := 'n  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_project_id      in  number,'||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(11) := '_system_gen_yn   in  varchar2 default ''N'','||wwv_flow.LF||
'    p_app_id          in  number   default null,'||wwv_flow.LF||
'    p_pe';
wwv_flow_imp.g_varchar2_table(12) := 'rmalink_pre   in  varchar2 default null,'||wwv_flow.LF||
'    p_nomen_sp        in  varchar2 default null,'||wwv_flow.LF||
'    p_nome';
wwv_flow_imp.g_varchar2_table(13) := 'n_project   in  varchar2 default null,'||wwv_flow.LF||
'    p_image_ref_id    in  number   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure';
wwv_flow_imp.g_varchar2_table(14) := ' update_project_comment ('||wwv_flow.LF||
'    p_comment_id      in  number,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(15) := 'p_private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_image_ref_id    in  number   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'proc';
wwv_flow_imp.g_varchar2_table(16) := 'edure delete_project_comment ('||wwv_flow.LF||
'    p_comment_id      in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_task_comment ('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(17) := '  p_app_user_id     in  number,'||wwv_flow.LF||
'    p_app_user        in  varchar2,'||wwv_flow.LF||
'    p_comment         in  varcha';
wwv_flow_imp.g_varchar2_table(18) := 'r2,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_project_id      in  number,'||wwv_flow.LF||
'    p_task_id ';
wwv_flow_imp.g_varchar2_table(19) := '        in  number,'||wwv_flow.LF||
'    p_app_id          in  number,'||wwv_flow.LF||
'    p_link            in  varchar2,'||wwv_flow.LF||
'    p_nome';
wwv_flow_imp.g_varchar2_table(20) := 'n_sp        in  varchar2,'||wwv_flow.LF||
'    p_image_ref_id    in  number   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_task_';
wwv_flow_imp.g_varchar2_table(21) := 'comment ('||wwv_flow.LF||
'    p_comment_id      in  number,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_private_yn    ';
wwv_flow_imp.g_varchar2_table(22) := '  in  varchar2 default ''N'','||wwv_flow.LF||
'    p_image_ref_id    in  number   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_tas';
wwv_flow_imp.g_varchar2_table(23) := 'k_comment ('||wwv_flow.LF||
'    p_comment_id      in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_release_comment ('||wwv_flow.LF||
'    p_app_user_id ';
wwv_flow_imp.g_varchar2_table(24) := '    in  number,'||wwv_flow.LF||
'    p_comment         in varchar2,'||wwv_flow.LF||
'    p_release_id      in number,'||wwv_flow.LF||
'    p_private_yn';
wwv_flow_imp.g_varchar2_table(25) := '      in varchar2 default ''N'','||wwv_flow.LF||
'    p_image_ref_id    in  number   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_';
wwv_flow_imp.g_varchar2_table(26) := 'release_comment ('||wwv_flow.LF||
'    p_comment_id      in  number,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_privat';
wwv_flow_imp.g_varchar2_table(27) := 'e_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_image_ref_id    in  number   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure de';
wwv_flow_imp.g_varchar2_table(28) := 'lete_release_comment ('||wwv_flow.LF||
'    p_comment_id      in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
' procedure add_init_focus_area_comment ';
wwv_flow_imp.g_varchar2_table(29) := '('||wwv_flow.LF||
'    p_app_user_id         in  number,'||wwv_flow.LF||
'    p_comment             in  varchar2,'||wwv_flow.LF||
'    p_init_focus_are';
wwv_flow_imp.g_varchar2_table(30) := 'a_id  in  number,'||wwv_flow.LF||
'    p_private_yn          in  varchar2 default ''N'','||wwv_flow.LF||
'    p_image_ref_id        in  ';
wwv_flow_imp.g_varchar2_table(31) := 'number   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_init_focus_area_comment ('||wwv_flow.LF||
'    p_comment_id      in  numbe';
wwv_flow_imp.g_varchar2_table(32) := 'r,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_image_r';
wwv_flow_imp.g_varchar2_table(33) := 'ef_id    in  number   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_init_focus_area_comment ('||wwv_flow.LF||
'    p_comment_id  ';
wwv_flow_imp.g_varchar2_table(34) := '    in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
'----------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure upload_image ('||wwv_flow.LF||
'    p_file_base64           in  ';
wwv_flow_imp.g_varchar2_table(35) := 'clob,'||wwv_flow.LF||
'    p_filename              in  varchar2,'||wwv_flow.LF||
'    p_mimetype              in  varchar2,'||wwv_flow.LF||
'    p_imag';
wwv_flow_imp.g_varchar2_table(36) := 'e_ref_id          in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure display_image ('||wwv_flow.LF||
'    p_unique_filename  in  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'e';
wwv_flow_imp.g_varchar2_table(37) := 'nd sp_comment_util;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(22990218013336819424)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_comment_util spec'
,p_sequence=>35
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
