prompt --application/deployment/install/install_sp_documents_v_view
begin
--   Manifest
--     INSTALL: INSTALL-sp_documents_v view
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace view sp_documents_v as'||wwv_flow.LF||
'select ''Project'' doc_type,'||wwv_flow.LF||
'       apex_page.get_url ('||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(2) := '      p_page   => 30,'||wwv_flow.LF||
'           p_items  => ''P30_ID,P30_PREV_PAGE'','||wwv_flow.LF||
'           p_values => d.ID||'',';
wwv_flow_imp.g_varchar2_table(3) := '156'') link,'||wwv_flow.LF||
'       p.project name,'||wwv_flow.LF||
'       p.project project,'||wwv_flow.LF||
'       d.DOCUMENT_FILENAME,'||wwv_flow.LF||
'       d.UP';
wwv_flow_imp.g_varchar2_table(4) := 'DATED,'||wwv_flow.LF||
'       d.created,'||wwv_flow.LF||
'       substr(d.doc_description,1,200)||case when length(d.doc_description)';
wwv_flow_imp.g_varchar2_table(5) := ' > 200 then ''...'' end doc_description,'||wwv_flow.LF||
'       lower(d.created_by) added_by,'||wwv_flow.LF||
'       dbms_lob.getlengt';
wwv_flow_imp.g_varchar2_table(6) := 'h(document_BLOB) filesize,'||wwv_flow.LF||
'       lower(substr(DOCUMENT_FILENAME,instr(DOCUMENT_FILENAME,''.'',-1)+1,l';
wwv_flow_imp.g_varchar2_table(7) := 'ength(DOCUMENT_FILENAME)-instr(DOCUMENT_FILENAME,''.'',-1))) file_extension,'||wwv_flow.LF||
'       d.tags,'||wwv_flow.LF||
'       nvl';
wwv_flow_imp.g_varchar2_table(8) := '((select release_train||'' ''||release from sp_release_trains'||wwv_flow.LF||
'             where id = p.release_id),''N';
wwv_flow_imp.g_varchar2_table(9) := 'ot Targeted'') release,'||wwv_flow.LF||
'       decode(d.important_yn,''Y'', ''Yes'',''No'') important,'||wwv_flow.LF||
'       -- for downlo';
wwv_flow_imp.g_varchar2_table(10) := 'ad'||wwv_flow.LF||
'       d.id document_id,'||wwv_flow.LF||
'       d.document_BLOB,'||wwv_flow.LF||
'       d.document_mimetype,'||wwv_flow.LF||
'       d.document_la';
wwv_flow_imp.g_varchar2_table(11) := 'stupd,'||wwv_flow.LF||
'       d.document_charset,'||wwv_flow.LF||
'       p.id project_id,'||wwv_flow.LF||
'       null release_id,'||wwv_flow.LF||
'       null task_i';
wwv_flow_imp.g_varchar2_table(12) := 'd,'||wwv_flow.LF||
'       null initiative_id,'||wwv_flow.LF||
'       null initiative_focus_area_id'||wwv_flow.LF||
'  from SP_PROJECT_DOCUMENTS d,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(13) := '     sp_projects p'||wwv_flow.LF||
' where project_id = p.id and'||wwv_flow.LF||
'       p.ARCHIVED_YN = ''N'' and '||wwv_flow.LF||
'       p.DUPLICATE_O';
wwv_flow_imp.g_varchar2_table(14) := 'F_PROJECT_ID is null'||wwv_flow.LF||
'union all'||wwv_flow.LF||
'select ''Release'' doc_type,'||wwv_flow.LF||
'       apex_page.get_url ('||wwv_flow.LF||
'           p_pa';
wwv_flow_imp.g_varchar2_table(15) := 'ge   => 42,'||wwv_flow.LF||
'           p_items  => ''P42_ID,P42_PREV_PAGE'','||wwv_flow.LF||
'           p_values => d.ID||'',156'') link';
wwv_flow_imp.g_varchar2_table(16) := ','||wwv_flow.LF||
'       r.release_train ||'' '' ||r.release name,'||wwv_flow.LF||
'       null project,'||wwv_flow.LF||
'       d.DOCUMENT_FILENAME,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(17) := '     d.UPDATED,'||wwv_flow.LF||
'       d.created,'||wwv_flow.LF||
'       substr(d.doc_description,1,200)||case when length(d.doc_des';
wwv_flow_imp.g_varchar2_table(18) := 'cription) > 200 then ''...'' end doc_description,'||wwv_flow.LF||
'       lower(d.created_by) added_by,'||wwv_flow.LF||
'       dbms_lob';
wwv_flow_imp.g_varchar2_table(19) := '.getlength(document_BLOB) filesize,'||wwv_flow.LF||
'       lower(substr(DOCUMENT_FILENAME,instr(DOCUMENT_FILENAME,''.';
wwv_flow_imp.g_varchar2_table(20) := ''',-1)+1,length(DOCUMENT_FILENAME)-instr(DOCUMENT_FILENAME,''.'',-1))) file_extension,'||wwv_flow.LF||
'       d.tags,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(21) := '      release_train||'' ''||release release,'||wwv_flow.LF||
'       decode(d.important_yn,''Y'', ''Yes'',''No'') important,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(22) := '       -- for download'||wwv_flow.LF||
'       d.id document_id,'||wwv_flow.LF||
'       d.document_BLOB,'||wwv_flow.LF||
'       d.document_mimetype,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(23) := '       d.document_lastupd,'||wwv_flow.LF||
'       d.document_charset,'||wwv_flow.LF||
'       null project_id,'||wwv_flow.LF||
'       r.id release_id';
wwv_flow_imp.g_varchar2_table(24) := ','||wwv_flow.LF||
'       null task_id,'||wwv_flow.LF||
'       null initiative_id,'||wwv_flow.LF||
'       null initiative_focus_area_id'||wwv_flow.LF||
'  from SP_REL';
wwv_flow_imp.g_varchar2_table(25) := 'EASE_DOCUMENTS d,'||wwv_flow.LF||
'       sp_release_trains r'||wwv_flow.LF||
' where r.id = d.release_id'||wwv_flow.LF||
'union all'||wwv_flow.LF||
'select ''Initiative';
wwv_flow_imp.g_varchar2_table(26) := ''' doc_type,'||wwv_flow.LF||
'       apex_page.get_url ('||wwv_flow.LF||
'           p_page   => 53,'||wwv_flow.LF||
'           p_items  => ''P53_ID,P53';
wwv_flow_imp.g_varchar2_table(27) := '_PREV_PAGE'','||wwv_flow.LF||
'           p_values => d.ID||'',156'') link,'||wwv_flow.LF||
'       a.area || '' / '' ||initiative name,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(28) := '     null project,'||wwv_flow.LF||
'       d.DOCUMENT_FILENAME,'||wwv_flow.LF||
'       d.UPDATED,'||wwv_flow.LF||
'       d.created,'||wwv_flow.LF||
'       substr(d.d';
wwv_flow_imp.g_varchar2_table(29) := 'oc_description,1,200)||case when length(d.doc_description) > 200 then ''...'' end doc_description,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(30) := '    lower(d.created_by) added_by,'||wwv_flow.LF||
'       dbms_lob.getlength(document_BLOB) filesize,'||wwv_flow.LF||
'       lower(su';
wwv_flow_imp.g_varchar2_table(31) := 'bstr(DOCUMENT_FILENAME,instr(DOCUMENT_FILENAME,''.'',-1)+1,length(DOCUMENT_FILENAME)-instr(DOCUMENT_FI';
wwv_flow_imp.g_varchar2_table(32) := 'LENAME,''.'',-1))) file_extension,'||wwv_flow.LF||
'       d.tags,'||wwv_flow.LF||
'       null release,'||wwv_flow.LF||
'       decode(d.important_yn,''Y';
wwv_flow_imp.g_varchar2_table(33) := ''', ''Yes'',''No'') important,'||wwv_flow.LF||
'       -- for download'||wwv_flow.LF||
'       d.id document_id,'||wwv_flow.LF||
'       d.document_BLOB,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(34) := '     d.document_mimetype,'||wwv_flow.LF||
'       d.document_lastupd,'||wwv_flow.LF||
'       d.document_charset,'||wwv_flow.LF||
'       null project_';
wwv_flow_imp.g_varchar2_table(35) := 'id,'||wwv_flow.LF||
'       null release_id,'||wwv_flow.LF||
'       null task_id,'||wwv_flow.LF||
'       i.id initiative_id,'||wwv_flow.LF||
'       null initiative_f';
wwv_flow_imp.g_varchar2_table(36) := 'ocus_area_id'||wwv_flow.LF||
'  from SP_INITIATIVE_DOCUMENTS d,'||wwv_flow.LF||
'       sp_initiatives i,'||wwv_flow.LF||
'       sp_areas a'||wwv_flow.LF||
' where d.i';
wwv_flow_imp.g_varchar2_table(37) := 'nitiative_id = i.id'||wwv_flow.LF||
'   and i.area_id = a.id'||wwv_flow.LF||
'union all'||wwv_flow.LF||
'select ''Initiative Focus Area'' doc_type,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(38) := '  apex_page.get_url ('||wwv_flow.LF||
'           p_page   => 59,'||wwv_flow.LF||
'           p_items  => ''P59_ID,P59_PREV_PAGE'','||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(39) := '       p_values => d.ID||'',156'') link,'||wwv_flow.LF||
'       i.initiative ||'' - ''|| f.focus_area name,'||wwv_flow.LF||
'       null ';
wwv_flow_imp.g_varchar2_table(40) := 'project,'||wwv_flow.LF||
'       d.DOCUMENT_FILENAME,'||wwv_flow.LF||
'       d.UPDATED,'||wwv_flow.LF||
'       d.created,'||wwv_flow.LF||
'       substr(d.doc_descrip';
wwv_flow_imp.g_varchar2_table(41) := 'tion,1,200)||case when length(d.doc_description) > 200 then ''...'' end doc_description,'||wwv_flow.LF||
'       lower(';
wwv_flow_imp.g_varchar2_table(42) := 'd.created_by) added_by,'||wwv_flow.LF||
'       dbms_lob.getlength(document_BLOB) filesize,'||wwv_flow.LF||
'       lower(substr(DOCUM';
wwv_flow_imp.g_varchar2_table(43) := 'ENT_FILENAME,instr(DOCUMENT_FILENAME,''.'',-1)+1,length(DOCUMENT_FILENAME)-instr(DOCUMENT_FILENAME,''.''';
wwv_flow_imp.g_varchar2_table(44) := ',-1))) file_extension,'||wwv_flow.LF||
'       d.tags,'||wwv_flow.LF||
'       null release,'||wwv_flow.LF||
'       decode(d.important_yn,''Y'', ''Yes'',''';
wwv_flow_imp.g_varchar2_table(45) := 'No'') important,'||wwv_flow.LF||
'       -- for download'||wwv_flow.LF||
'       d.id document_id,'||wwv_flow.LF||
'       d.document_BLOB,'||wwv_flow.LF||
'       d.doc';
wwv_flow_imp.g_varchar2_table(46) := 'ument_mimetype,'||wwv_flow.LF||
'       d.document_lastupd,'||wwv_flow.LF||
'       d.document_charset,'||wwv_flow.LF||
'       null project_id,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(47) := ' null release_id,'||wwv_flow.LF||
'       null task_id,'||wwv_flow.LF||
'       i.id initiative_id,'||wwv_flow.LF||
'       f.id initiative_focus_area_';
wwv_flow_imp.g_varchar2_table(48) := 'id'||wwv_flow.LF||
'  from SP_INIT_FOCUS_AREA_DOCUMENTS d,'||wwv_flow.LF||
'       sp_initiative_focus_areas f,'||wwv_flow.LF||
'       sp_initiatives ';
wwv_flow_imp.g_varchar2_table(49) := 'i'||wwv_flow.LF||
' where d.init_focus_area_id = f.id'||wwv_flow.LF||
'   and f.initiative_id = i.id'||wwv_flow.LF||
'union all'||wwv_flow.LF||
'select ''Task'' doc_type,';
wwv_flow_imp.g_varchar2_table(50) := ''||wwv_flow.LF||
'       apex_page.get_url ('||wwv_flow.LF||
'           p_page   => 505,'||wwv_flow.LF||
'           p_items  => ''P505_ID,P505_PREV_PA';
wwv_flow_imp.g_varchar2_table(51) := 'GE'','||wwv_flow.LF||
'           p_values => d.ID||'',156'') link,'||wwv_flow.LF||
'       case when t.task_sub_type_id is not null'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(52) := '        then (select task_type from sp_task_types'||wwv_flow.LF||
'                   where id = t.task_type_id)||'': ';
wwv_flow_imp.g_varchar2_table(53) := ''''||wwv_flow.LF||
'            end || tt.task_type || case when t.task is not null then '' - ''||t.task end name,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(54) := '  p.project,'||wwv_flow.LF||
'       d.DOCUMENT_FILENAME,'||wwv_flow.LF||
'       d.UPDATED,'||wwv_flow.LF||
'       d.created,'||wwv_flow.LF||
'       substr(d.doc_des';
wwv_flow_imp.g_varchar2_table(55) := 'cription,1,200)||case when length(d.doc_description) > 200 then ''...'' end doc_description,'||wwv_flow.LF||
'       lo';
wwv_flow_imp.g_varchar2_table(56) := 'wer(d.created_by) added_by,'||wwv_flow.LF||
'       dbms_lob.getlength(document_BLOB) filesize,'||wwv_flow.LF||
'       lower(substr(D';
wwv_flow_imp.g_varchar2_table(57) := 'OCUMENT_FILENAME,instr(DOCUMENT_FILENAME,''.'',-1)+1,length(DOCUMENT_FILENAME)-instr(DOCUMENT_FILENAME';
wwv_flow_imp.g_varchar2_table(58) := ',''.'',-1))) file_extension,'||wwv_flow.LF||
'       d.tags,'||wwv_flow.LF||
'       nvl((select release_train||'' ''||release from sp_rel';
wwv_flow_imp.g_varchar2_table(59) := 'ease_trains'||wwv_flow.LF||
'             where id = p.release_id),''Not Targeted'') release,'||wwv_flow.LF||
'       decode(d.important';
wwv_flow_imp.g_varchar2_table(60) := '_yn,''Y'', ''Yes'',''No'') important,'||wwv_flow.LF||
'       -- for download'||wwv_flow.LF||
'       d.id document_id,'||wwv_flow.LF||
'       d.document_BL';
wwv_flow_imp.g_varchar2_table(61) := 'OB,'||wwv_flow.LF||
'       d.document_mimetype,'||wwv_flow.LF||
'       d.document_lastupd,'||wwv_flow.LF||
'       d.document_charset,'||wwv_flow.LF||
'       p.id pr';
wwv_flow_imp.g_varchar2_table(62) := 'oject_id,'||wwv_flow.LF||
'       null release_id,'||wwv_flow.LF||
'       t.id task_id,'||wwv_flow.LF||
'       null initiative_id,'||wwv_flow.LF||
'       null initia';
wwv_flow_imp.g_varchar2_table(63) := 'tive_focus_area_id'||wwv_flow.LF||
'  from SP_TASK_DOCUMENTS d,'||wwv_flow.LF||
'       sp_tasks t,'||wwv_flow.LF||
'       sp_task_types tt,'||wwv_flow.LF||
'       sp';
wwv_flow_imp.g_varchar2_table(64) := '_projects p'||wwv_flow.LF||
' where d.task_id = t.id'||wwv_flow.LF||
'   and nvl(t.task_sub_type_id,t.task_type_id) = tt.id'||wwv_flow.LF||
'   and t.p';
wwv_flow_imp.g_varchar2_table(65) := 'roject_id = p.id;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(30934223342583470523)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_documents_v view'
,p_sequence=>738
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
