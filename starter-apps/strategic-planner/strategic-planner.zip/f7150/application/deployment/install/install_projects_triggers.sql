prompt --application/deployment/install/install_projects_triggers
begin
--   Manifest
--     INSTALL: INSTALL-projects triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_projects_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_projects'||wwv_flow.LF||
'    for eac';
wwv_flow_imp.g_varchar2_table(2) := 'h row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_old_value   varchar2(4000) := null;'||wwv_flow.LF||
'    l_new_value   varchar2(4000) := null;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(3) := '  l_changed_by  varchar2(255)  := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    l_old_c';
wwv_flow_imp.g_varchar2_table(4) := 'lob    clob;'||wwv_flow.LF||
'    l_new_clob    clob;'||wwv_flow.LF||
'    l_tags        varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- m';
wwv_flow_imp.g_varchar2_table(5) := 'aintain tracking columns'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(6) := ':new.created_by := l_changed_by;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if sp_globals.g_audit_this then'||wwv_flow.LF||
'        :new.update';
wwv_flow_imp.g_varchar2_table(7) := 'd := sysdate;'||wwv_flow.LF||
'        :new.updated_by := l_changed_by;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- upper project name'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(8) := '    --'||wwv_flow.LF||
'    :new.upper_project_name := upper(:new.project);'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- set external_ticket_identi';
wwv_flow_imp.g_varchar2_table(9) := 'fier and EXTERNAL_TICKET_SYSTEM and external_system_link'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.external_ticket_system     ';
wwv_flow_imp.g_varchar2_table(10) := ':= null;'||wwv_flow.LF||
'    :new.external_ticket_identifier := null;'||wwv_flow.LF||
'    :new.external_system_link       := null;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(11) := '   for c1 in ('||wwv_flow.LF||
'        select EXTERNAL_SYSTEM_NAME, '||wwv_flow.LF||
'               LINK_PATTERN, '||wwv_flow.LF||
'               TI';
wwv_flow_imp.g_varchar2_table(12) := 'CKET_ID_REGEX,'||wwv_flow.LF||
'               REQUIRED_INITIATIVE_ID,'||wwv_flow.LF||
'               replace(replace(replace(replace';
wwv_flow_imp.g_varchar2_table(13) := '(regexp_substr(:new.project,ticket_id_regex),'':'',''-''),'' '',''-''),''<'',''-''),''>'',''-'') ext_id'||wwv_flow.LF||
'          fr';
wwv_flow_imp.g_varchar2_table(14) := 'om SP_EXTERNAL_TICKETING_SYSTEMS'||wwv_flow.LF||
'         where nvl(IS_ACTIVE_YN,''N'') = ''Y'''||wwv_flow.LF||
'           and regexp_su';
wwv_flow_imp.g_varchar2_table(15) := 'bstr(:new.project,ticket_id_regex) is not null'||wwv_flow.LF||
'           and (required_initiative_id is null or req';
wwv_flow_imp.g_varchar2_table(16) := 'uired_initiative_id = :new.initiative_id)'||wwv_flow.LF||
'         order by evaulation_sequence'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(17) := '  :new.EXTERNAL_TICKET_SYSTEM := c1.EXTERNAL_SYSTEM_NAME;'||wwv_flow.LF||
'           if instr(c1.LINK_PATTERN,''#TICK';
wwv_flow_imp.g_varchar2_table(18) := 'ET_NUMERIC#'') > 0 then'||wwv_flow.LF||
'              :new.external_ticket_identifier := c1.ext_id;'||wwv_flow.LF||
'              :ne';
wwv_flow_imp.g_varchar2_table(19) := 'w.external_system_link       := replace(c1.LINK_PATTERN,''#TICKET_NUMERIC#'',regexp_replace(c1.ext_id,';
wwv_flow_imp.g_varchar2_table(20) := '''[^0-9]'',''''));'||wwv_flow.LF||
'           elsif instr(c1.LINK_PATTERN,''#TICKET#'') > 0 then'||wwv_flow.LF||
'              :new.extern';
wwv_flow_imp.g_varchar2_table(21) := 'al_ticket_identifier := c1.ext_id;'||wwv_flow.LF||
'              :new.external_system_link       := replace(c1.LINK_';
wwv_flow_imp.g_varchar2_table(22) := 'PATTERN,''#TICKET#'',:new.external_ticket_identifier);'||wwv_flow.LF||
'           else'||wwv_flow.LF||
'              :new.external_tic';
wwv_flow_imp.g_varchar2_table(23) := 'ket_identifier := null;'||wwv_flow.LF||
'              :new.external_system_link       := c1.LINK_PATTERN;'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(24) := ' end if;'||wwv_flow.LF||
'           exit;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- adjust tag data'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.tags is no';
wwv_flow_imp.g_varchar2_table(25) := 't null then'||wwv_flow.LF||
'        l_tags := trim(upper(:new.tags));'||wwv_flow.LF||
'        -- remove multiple spaces'||wwv_flow.LF||
'        if i';
wwv_flow_imp.g_varchar2_table(26) := 'nstr(l_tags,''  '') > 0 then'||wwv_flow.LF||
'            for j in 1..10 loop '||wwv_flow.LF||
'                l_tags := replace(l_tags';
wwv_flow_imp.g_varchar2_table(27) := ',''  '','' ''); '||wwv_flow.LF||
'                if instr(l_tags,''  '') = 0 then'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(28) := ' end if;'||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        for i in 1..length(l_tags) loop'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(29) := 'if i > 2 and substr(l_tags,i,1) = '' '' and substr(l_tags,i-1,1) != '','' then'||wwv_flow.LF||
'               l_tags := ';
wwv_flow_imp.g_varchar2_table(30) := 'substr(l_tags,1,i-1)||''-''||substr(l_tags,i+1);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        :new.ta';
wwv_flow_imp.g_varchar2_table(31) := 'gs := l_tags;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- defaults'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.STATUS_SCALE is null then'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(32) := ' :new.STATUS_SCALE := ''A'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.ARCHIVED_YN is null then'||wwv_flow.LF||
'       :new.ARCHI';
wwv_flow_imp.g_varchar2_table(33) := 'VED_YN := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- short project ID used as an alturnative to long numeric ID ';
wwv_flow_imp.g_varchar2_table(34) := 'primary key column'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.friendly_identifier is null then'||wwv_flow.LF||
'       :new.friendly_identifi';
wwv_flow_imp.g_varchar2_table(35) := 'er := sp_util.compress_int(sp_seq.nextval);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- used to provide friendly URLs'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(36) := '    --'||wwv_flow.LF||
'    if not sp_value_compare.is_equal(:old.project,:new.project) then'||wwv_flow.LF||
'       :new.project_url_';
wwv_flow_imp.g_varchar2_table(37) := 'name := ltrim(rtrim(replace(replace(REGEXP_REPLACE(translate(substr(:new.project,1,80),''()+%$&^!@[];';
wwv_flow_imp.g_varchar2_table(38) := ':"?/~!-+_.<>'',''                        ''),''\s+'', '' ''), '''''''', ''''),'' '',''-''),''-''),''-'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(39) := '  --'||wwv_flow.LF||
'    -- change history tracking'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'       l_changed_by := lower(l_chang';
wwv_flow_imp.g_varchar2_table(40) := 'ed_by);'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- INITIATIVE_ID'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.INI';
wwv_flow_imp.g_varchar2_table(41) := 'TIATIVE_ID,:new.INITIATIVE_ID) then'||wwv_flow.LF||
'          for c1 in (select INITIATIVE r from SP_INITIATIVES x w';
wwv_flow_imp.g_varchar2_table(42) := 'here x.id = :old.INITIATIVE_ID) loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'          for c1 in (select INIT';
wwv_flow_imp.g_varchar2_table(43) := 'IATIVE r from SP_INITIATIVES x where x.id = :new.INITIATIVE_ID) loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(44) := '          insert into sp_project_history'||wwv_flow.LF||
'              (project_id, attribute_column, change_type, o';
wwv_flow_imp.g_varchar2_table(45) := 'ld_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''INITIATIVE'', ';
wwv_flow_imp.g_varchar2_table(46) := '''UPDATE'', l_old_value, l_new_value, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- PROJE';
wwv_flow_imp.g_varchar2_table(47) := 'CT '||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.PROJECT,:new.PROJECT) then'||wwv_flow.LF||
'          inse';
wwv_flow_imp.g_varchar2_table(48) := 'rt into sp_project_history'||wwv_flow.LF||
'              (project_id, attribute_column, change_type, old_value, new_';
wwv_flow_imp.g_varchar2_table(49) := 'value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''PROJECT'', ''UPDATE'', :old.PR';
wwv_flow_imp.g_varchar2_table(50) := 'OJECT, :new.PROJECT, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- DESCRIPTION '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(51) := '--'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.DESCRIPTION,:new.DESCRIPTION) then'||wwv_flow.LF||
'          l_old_c';
wwv_flow_imp.g_varchar2_table(52) := 'lob := :old.DESCRIPTION;'||wwv_flow.LF||
'          l_new_clob := :new.DESCRIPTION;'||wwv_flow.LF||
'          insert into sp_project_';
wwv_flow_imp.g_varchar2_table(53) := 'history'||wwv_flow.LF||
'              (project_id, attribute_column, change_type, old_value, new_value, old_value_cl';
wwv_flow_imp.g_varchar2_table(54) := 'ob, new_value_clob, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''DESCRIPTION'', ';
wwv_flow_imp.g_varchar2_table(55) := '''UPDATE'', dbms_lob.substr(:old.DESCRIPTION,500,1), dbms_lob.substr(:new.DESCRIPTION,500,1), l_old_cl';
wwv_flow_imp.g_varchar2_table(56) := 'ob, l_new_clob, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- OWNER_ID'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(57) := ' if not sp_value_compare.is_equal(:old.OWNER_ID,:new.OWNER_ID) then'||wwv_flow.LF||
'          for c1 in (select lowe';
wwv_flow_imp.g_varchar2_table(58) := 'r(email) r from SP_TEAM_MEMBERS x where x.id = :old.owner_id) loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(59) := '        for c1 in (select lower(email) r from SP_TEAM_MEMBERS x where x.id = :new.owner_id) loop l_n';
wwv_flow_imp.g_varchar2_table(60) := 'ew_value := c1.r; end loop;'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'              (project_id, attr';
wwv_flow_imp.g_varchar2_table(61) := 'ibute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(62) := '    (:new.id, ''OWNER'', ''UPDATE'', l_old_value, l_new_value, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(63) := '     --'||wwv_flow.LF||
'       -- TARGET_COMPLETE'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.TARGET_COMP';
wwv_flow_imp.g_varchar2_table(64) := 'LETE,:new.TARGET_COMPLETE) then'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'              (project_id, ';
wwv_flow_imp.g_varchar2_table(65) := 'attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(66) := '        (:new.id, ''TARGET_COMPLETE'', ''UPDATE'', to_char(:old.TARGET_COMPLETE,''DD-MON-YYYY''), to_char(';
wwv_flow_imp.g_varchar2_table(67) := ':new.TARGET_COMPLETE,''DD-MON-YYYY''), sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- STAT';
wwv_flow_imp.g_varchar2_table(68) := 'US_SCALE'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.status_scale,:new.status_scale) then';
wwv_flow_imp.g_varchar2_table(69) := ''||wwv_flow.LF||
'          for c1 in (select scale_name from sp_project_scales where :old.status_scale = scale_lette';
wwv_flow_imp.g_varchar2_table(70) := 'r) loop l_old_value := c1.scale_name; end loop;'||wwv_flow.LF||
'          for c1 in (select scale_name from sp_proje';
wwv_flow_imp.g_varchar2_table(71) := 'ct_scales where :new.status_scale = scale_letter) loop l_new_value := c1.scale_name; end loop;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(72) := '     insert into sp_project_history'||wwv_flow.LF||
'              (project_id, attribute_column, change_type, old_va';
wwv_flow_imp.g_varchar2_table(73) := 'lue, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''STATUS_SCALE'', ''UP';
wwv_flow_imp.g_varchar2_table(74) := 'DATE'', l_old_value, l_new_value, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;       '||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- P';
wwv_flow_imp.g_varchar2_table(75) := 'CT_COMPLETE'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.pct_complete,:new.pct_complete) t';
wwv_flow_imp.g_varchar2_table(76) := 'hen'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'              (project_id, attribute_column, change_typ';
wwv_flow_imp.g_varchar2_table(77) := 'e, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''PCT_COMPL';
wwv_flow_imp.g_varchar2_table(78) := 'ETE'', ''UPDATE'', :old.pct_complete, :new.pct_complete, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(79) := '-- STATUS'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.status_id,:new.status_id) then'||wwv_flow.LF||
'          for ';
wwv_flow_imp.g_varchar2_table(80) := 'c1 in (select status from sp_project_statuses where :old.status_id = id) loop l_old_value := c1.stat';
wwv_flow_imp.g_varchar2_table(81) := 'us; end loop;'||wwv_flow.LF||
'          for c1 in (select status from sp_project_statuses where :new.status_id = id)';
wwv_flow_imp.g_varchar2_table(82) := ' loop l_new_value := c1.status; end loop;'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'              (pr';
wwv_flow_imp.g_varchar2_table(83) := 'oject_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          val';
wwv_flow_imp.g_varchar2_table(84) := 'ues'||wwv_flow.LF||
'              (:new.id, ''STATUS'', ''UPDATE'', l_old_value, l_new_value, sysdate, l_changed_by);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(85) := '     end if;  '||wwv_flow.LF||
'       -- REQUIRES_REVIEWS_YN'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.requires_r';
wwv_flow_imp.g_varchar2_table(86) := 'eviews_yn,:new.requires_reviews_yn) then'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'              (pro';
wwv_flow_imp.g_varchar2_table(87) := 'ject_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          valu';
wwv_flow_imp.g_varchar2_table(88) := 'es'||wwv_flow.LF||
'              (:new.id, ''REQUIRES_REVIEWS'', ''UPDATE'', :old.requires_reviews_yn, :new.requires_rev';
wwv_flow_imp.g_varchar2_table(89) := 'iews_yn, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       -- DUPLICATE_OF_PROJECT_ID'||wwv_flow.LF||
'       if not sp_v';
wwv_flow_imp.g_varchar2_table(90) := 'alue_compare.is_equal(:old.duplicate_of_project_id,:new.duplicate_of_project_id) then'||wwv_flow.LF||
'          inse';
wwv_flow_imp.g_varchar2_table(91) := 'rt into sp_project_history'||wwv_flow.LF||
'              (project_id, attribute_column, change_type, old_value, new_';
wwv_flow_imp.g_varchar2_table(92) := 'value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''DUPLICATE_OF_PROJECT_ID'', ''';
wwv_flow_imp.g_varchar2_table(93) := 'UPDATE'', :old.duplicate_of_project_id, :new.duplicate_of_project_id, sysdate, l_changed_by);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(94) := 'end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'       -- PRIORITY_ID'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.priority_id,:new.priorit';
wwv_flow_imp.g_varchar2_table(95) := 'y_id) then'||wwv_flow.LF||
'          for c1 in (select ''P''||PRIORITY r from SP_PROJECT_PRIORITIES x where x.id = :ol';
wwv_flow_imp.g_varchar2_table(96) := 'd.PRIORITY_ID) loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'          for c1 in (select ''P''||PRIORITY r from ';
wwv_flow_imp.g_varchar2_table(97) := 'SP_PROJECT_PRIORITIES x where x.id = :new.PRIORITY_ID) loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(98) := ' insert into sp_project_history'||wwv_flow.LF||
'              (project_id, attribute_column, change_type, old_value,';
wwv_flow_imp.g_varchar2_table(99) := ' new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''PRIORITY'', ''UPDATE'', l';
wwv_flow_imp.g_varchar2_table(100) := '_old_value, l_new_value, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       -- RELEASE_ID'||wwv_flow.LF||
'       if not s';
wwv_flow_imp.g_varchar2_table(101) := 'p_value_compare.is_equal(:old.RELEASE_ID,:new.RELEASE_ID) then'||wwv_flow.LF||
'          for c1 in (select RELEASE_T';
wwv_flow_imp.g_varchar2_table(102) := 'RAIN||'' ''||RELEASE r from SP_RELEASE_TRAINS x where x.id = :old.RELEASE_ID) loop l_old_value := c1.r';
wwv_flow_imp.g_varchar2_table(103) := '; end loop;'||wwv_flow.LF||
'          for c1 in (select RELEASE_TRAIN||'' ''||RELEASE r from SP_RELEASE_TRAINS x where';
wwv_flow_imp.g_varchar2_table(104) := ' x.id = :new.RELEASE_ID) loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'          insert into sp_project_histor';
wwv_flow_imp.g_varchar2_table(105) := 'y'||wwv_flow.LF||
'              (project_id, attribute_column, change_type, old_value, new_value, changed_on, change';
wwv_flow_imp.g_varchar2_table(106) := 'd_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''RELEASE'', ''UPDATE'', l_old_value, l_new_value, sysdat';
wwv_flow_imp.g_varchar2_table(107) := 'e, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       -- TAGS'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.tags,:n';
wwv_flow_imp.g_varchar2_table(108) := 'ew.tags) then'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'              (project_id, attribute_column, ';
wwv_flow_imp.g_varchar2_table(109) := 'change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ';
wwv_flow_imp.g_varchar2_table(110) := '''TAGS'', ''UPDATE'', :old.tags, :new.tags, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       -- PROJECT_GRO';
wwv_flow_imp.g_varchar2_table(111) := 'UP'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.PROJECT_GROUP_ID,:new.PROJECT_GROUP_ID) then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(112) := '   for c1 in (select GROUP_NAME r from SP_PROJECT_GROUPS x where x.id = :old.PROJECT_GROUP_ID) loop ';
wwv_flow_imp.g_varchar2_table(113) := 'l_old_value := c1.r; end loop;'||wwv_flow.LF||
'          for c1 in (select GROUP_NAME r from SP_PROJECT_GROUPS x whe';
wwv_flow_imp.g_varchar2_table(114) := 're x.id = :new.PROJECT_GROUP_ID) loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'          insert into sp_projec';
wwv_flow_imp.g_varchar2_table(115) := 't_history'||wwv_flow.LF||
'              (project_id, attribute_column, change_type, old_value, new_value, changed_on';
wwv_flow_imp.g_varchar2_table(116) := ', changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''PROJECT_GROUP'', ''UPDATE'', l_old_value, l_new';
wwv_flow_imp.g_varchar2_table(117) := '_value, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       -- PROJECT_SIZE'||wwv_flow.LF||
'       if not sp_value_compare';
wwv_flow_imp.g_varchar2_table(118) := '.is_equal(:old.project_size,:new.project_size) then'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(119) := '       (project_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(120) := '       values'||wwv_flow.LF||
'              (:new.id, ''PROJECT_SIZE'', ''UPDATE'', :old.project_size, :new.project_size';
wwv_flow_imp.g_varchar2_table(121) := ', sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       -- KB_STACK_RANK'||wwv_flow.LF||
'       if not sp_value_compare.is_e';
wwv_flow_imp.g_varchar2_table(122) := 'qual(:old.kb_stack_rank,:new.kb_stack_rank) then'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(123) := '    (project_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(124) := '    values'||wwv_flow.LF||
'              (:new.id, ''KB_STACK_RANK'', ''UPDATE'', :old.kb_stack_rank, :new.kb_stack_rank';
wwv_flow_imp.g_varchar2_table(125) := ', sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       -- FOCUS_AREA_ID'||wwv_flow.LF||
'       if not sp_value_compare.is_e';
wwv_flow_imp.g_varchar2_table(126) := 'qual(:old.focus_area_id,:new.focus_area_id) then'||wwv_flow.LF||
'          for c1 in (select focus_area r from SP_IN';
wwv_flow_imp.g_varchar2_table(127) := 'ITIATIVE_FOCUS_AREAS x where x.id = :old.FOCUS_AREA_ID) loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(128) := '  for c1 in (select focus_area r from SP_INITIATIVE_FOCUS_AREAS x where x.id = :new.FOCUS_AREA_ID) l';
wwv_flow_imp.g_varchar2_table(129) := 'oop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'              (project_i';
wwv_flow_imp.g_varchar2_table(130) := 'd, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(131) := '           (:new.id, ''FOCUS_AREA'', ''UPDATE'', l_old_value, l_new_value, sysdate, l_changed_by);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(132) := '  end if;'||wwv_flow.LF||
'       -- ACTIVE_YN'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.active_yn,:new.active_yn)';
wwv_flow_imp.g_varchar2_table(133) := ' then'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'              (project_id, attribute_column, change_t';
wwv_flow_imp.g_varchar2_table(134) := 'ype, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''ACTIVE''';
wwv_flow_imp.g_varchar2_table(135) := ', ''UPDATE'', :old.active_yn, :new.active_yn, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       -- ARCHIVE';
wwv_flow_imp.g_varchar2_table(136) := 'D_YN'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.archived_yn,:new.archived_yn) then'||wwv_flow.LF||
'          inser';
wwv_flow_imp.g_varchar2_table(137) := 't into sp_project_history'||wwv_flow.LF||
'              (project_id, attribute_column, change_type, old_value, new_v';
wwv_flow_imp.g_varchar2_table(138) := 'alue, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''ARCHIVED'', ''UPDATE'', :old.ar';
wwv_flow_imp.g_varchar2_table(139) := 'chived_yn, :new.archived_yn, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'end sp_project';
wwv_flow_imp.g_varchar2_table(140) := 's_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_projects_ai'||wwv_flow.LF||
'    after insert'||wwv_flow.LF||
'    on sp_projects'||wwv_flow.LF||
'    for each ';
wwv_flow_imp.g_varchar2_table(141) := 'row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_project_history'||wwv_flow.LF||
'        (project_id, attribute_column, change_type, new';
wwv_flow_imp.g_varchar2_table(142) := '_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:new.id, ''PROJECT'', ''CREATE'', :new.PROJECT, sysd';
wwv_flow_imp.g_varchar2_table(143) := 'ate, lower(:new.created_by));'||wwv_flow.LF||
'end sp_projects_ai;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_projects_bd'||wwv_flow.LF||
'    be';
wwv_flow_imp.g_varchar2_table(144) := 'fore delete'||wwv_flow.LF||
'    on sp_projects'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_project_history'||wwv_flow.LF||
'        (pr';
wwv_flow_imp.g_varchar2_table(145) := 'oject_id, attribute_column, change_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old';
wwv_flow_imp.g_varchar2_table(146) := '.id, ''PROJECT'', ''DELETE'', :old.PROJECT, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER';
wwv_flow_imp.g_varchar2_table(147) := '''),user)));'||wwv_flow.LF||
'end sp_projects_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(68245429853897984834)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'projects triggers'
,p_sequence=>520
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
