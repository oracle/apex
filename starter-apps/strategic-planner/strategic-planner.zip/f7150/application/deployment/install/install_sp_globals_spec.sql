prompt --application/deployment/install/install_sp_globals_spec
begin
--   Manifest
--     INSTALL: INSTALL-sp_globals spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>2214566044257001599
,p_default_application_id=>9111
,p_default_id_offset=>11016538767572718
,p_default_owner=>'DBTOOLS_PROD'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(44070487095579120720)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_globals spec'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package sp_globals',
'as',
'    g_audit_this  boolean := TRUE;',
'end sp_globals;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
