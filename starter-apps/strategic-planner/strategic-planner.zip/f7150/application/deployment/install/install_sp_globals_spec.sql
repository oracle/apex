prompt --application/deployment/install/install_sp_globals_spec
begin
--   Manifest
--     INSTALL: INSTALL-sp_globals spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package sp_globals'||wwv_flow.LF||
'as'||wwv_flow.LF||
'    g_audit_this  boolean := TRUE;'||wwv_flow.LF||
'end sp_globals;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(44070487095579120720)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_globals spec'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
