prompt --application/deployment/install/install_create_table_sp_release_links
begin
--   Manifest
--     INSTALL: INSTALL-create table sp_release_links
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table SP_release_links ('||wwv_flow.LF||
'    id                             number default on null to_number(';
wwv_flow_imp.g_varchar2_table(2) := 'sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint SP_re';
wwv_flow_imp.g_varchar2_table(3) := 'lease_links_PK primary key,'||wwv_flow.LF||
'    release_id                     number '||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(4) := '      constraint sp_release_links_to_rel_fk'||wwv_flow.LF||
'                                   references sp_release';
wwv_flow_imp.g_varchar2_table(5) := '_trains (id)'||wwv_flow.LF||
'                                   on delete cascade,'||wwv_flow.LF||
'    link_name                    ';
wwv_flow_imp.g_varchar2_table(6) := '  varchar2(255 char)   not null,'||wwv_flow.LF||
'    link_url                       varchar2(4000 char),'||wwv_flow.LF||
'    importa';
wwv_flow_imp.g_varchar2_table(7) := 'nt_yn                   varchar2(1 char)    default on null ''N'''||wwv_flow.LF||
'                                   c';
wwv_flow_imp.g_varchar2_table(8) := 'onstraint sp_release_links_imp_cc'||wwv_flow.LF||
'                                   check (important_yn in (''Y'',''N''';
wwv_flow_imp.g_varchar2_table(9) := ')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by                     varc';
wwv_flow_imp.g_varchar2_table(10) := 'har2(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by           ';
wwv_flow_imp.g_varchar2_table(11) := '          varchar2(255 char) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create index SP_release_links_i1 on SP_release_links(rele';
wwv_flow_imp.g_varchar2_table(12) := 'ase_id);'||wwv_flow.LF||
'create unique index SP_release_links_U1 on SP_release_links(release_id,link_name);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create';
wwv_flow_imp.g_varchar2_table(13) := ' or replace trigger sp_release_links_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_release_links'||wwv_flow.LF||
'    for';
wwv_flow_imp.g_varchar2_table(14) := ' each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_changed_by  varchar2(255)  := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new';
wwv_flow_imp.g_varchar2_table(15) := '.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user';
wwv_flow_imp.g_varchar2_table(16) := ');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSIO';
wwv_flow_imp.g_varchar2_table(17) := 'N'',''APP_USER''),user);'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_release_trains set upda';
wwv_flow_imp.g_varchar2_table(18) := 'ted = sysdate, updated_by = :new.updated_by where id = :new.release_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- change histor';
wwv_flow_imp.g_varchar2_table(19) := 'y tracking'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        insert into sp_release_history'||wwv_flow.LF||
'            (release_';
wwv_flow_imp.g_varchar2_table(20) := 'id, attribute_column, change_type, new_value, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:n';
wwv_flow_imp.g_varchar2_table(21) := 'ew.release_id, ''RELEASE_LINK'', ''CREATE'', :new.link_name, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'    elsif';
wwv_flow_imp.g_varchar2_table(22) := ' updating then'||wwv_flow.LF||
'        l_changed_by := lower(:new.updated_by);'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        if not sp_value_co';
wwv_flow_imp.g_varchar2_table(23) := 'mpare.is_equal(:old.link_name,:new.link_name) then'||wwv_flow.LF||
'           insert into sp_release_history'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(24) := '        (release_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(25) := '         values'||wwv_flow.LF||
'               (:new.release_id, ''RELEASE_LINK'', ''UPDATE'', :old.link_name, :new.link';
wwv_flow_imp.g_varchar2_table(26) := '_name, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:';
wwv_flow_imp.g_varchar2_table(27) := 'old.link_url,:new.link_url) then'||wwv_flow.LF||
'           insert into sp_release_history'||wwv_flow.LF||
'               (release_i';
wwv_flow_imp.g_varchar2_table(28) := 'd, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'           values'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(29) := '             (:new.release_id, ''RELEASE_LINK_URL'', ''UPDATE'', :new.link_name||'' - '' ||:old.link_url, ';
wwv_flow_imp.g_varchar2_table(30) := ':new.link_name||'' - '' ||:new.link_url, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        if';
wwv_flow_imp.g_varchar2_table(31) := ' not sp_value_compare.is_equal(:old.important_yn,:new.important_yn) then'||wwv_flow.LF||
'           insert into sp_r';
wwv_flow_imp.g_varchar2_table(32) := 'elease_history'||wwv_flow.LF||
'               (release_id, attribute_column, change_type, old_value, new_value, chan';
wwv_flow_imp.g_varchar2_table(33) := 'ged_on, changed_by)'||wwv_flow.LF||
'           values'||wwv_flow.LF||
'               (:new.release_id, ''RELEASE_LINK_IMPORTANT'', ''UP';
wwv_flow_imp.g_varchar2_table(34) := 'DATE'', :new.link_name||'' - '' ||:old.important_yn, :new.link_name||'' - '' ||:new.important_yn, sysdate';
wwv_flow_imp.g_varchar2_table(35) := ', l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_release_links_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger ';
wwv_flow_imp.g_varchar2_table(36) := 'sp_release_links_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_release_links'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into';
wwv_flow_imp.g_varchar2_table(37) := ' sp_release_history'||wwv_flow.LF||
'        (release_id, attribute_column, change_type, old_value, changed_on, chang';
wwv_flow_imp.g_varchar2_table(38) := 'ed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.release_id, ''RELEASE_LINK'', ''DELETE'', :old.link_name, sysdate, lower';
wwv_flow_imp.g_varchar2_table(39) := '(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'end sp_release_links_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(41622171835643709859)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'create table sp_release_links'
,p_sequence=>680
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
