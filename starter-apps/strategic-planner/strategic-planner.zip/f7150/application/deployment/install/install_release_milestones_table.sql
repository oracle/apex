prompt --application/deployment/install/install_release_milestones_table
begin
--   Manifest
--     INSTALL: INSTALL-release milestones table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_release_milestones ('||wwv_flow.LF||
'    id                             number default on null to_nu';
wwv_flow_imp.g_varchar2_table(2) := 'mber(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint ';
wwv_flow_imp.g_varchar2_table(3) := 'sp_release_milestone_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    release_id                     number not null'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(4) := '                              constraint sp_rel_milestone_to_release_fk '||wwv_flow.LF||
'                           ';
wwv_flow_imp.g_varchar2_table(5) := '        references SP_RELEASE_TRAINS (id)'||wwv_flow.LF||
'                                   on delete cascade,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(6) := 'milestone_name                 varchar2(255 char) not null,'||wwv_flow.LF||
'    upper_milestone_name           varch';
wwv_flow_imp.g_varchar2_table(7) := 'ar2(255 char) not null,'||wwv_flow.LF||
'    milestone_type_id              number '||wwv_flow.LF||
'                                 ';
wwv_flow_imp.g_varchar2_table(8) := '  constraint sp_rel_milestones_type_fk '||wwv_flow.LF||
'                                   references sp_release_mil';
wwv_flow_imp.g_varchar2_table(9) := 'estone_types (id),'||wwv_flow.LF||
'    milestone_start_date           date,'||wwv_flow.LF||
'    milestone_date                 date ';
wwv_flow_imp.g_varchar2_table(10) := 'not null,'||wwv_flow.LF||
'    original_milestone_date        date,'||wwv_flow.LF||
'    milestone_completed_yn         varchar2(1 cha';
wwv_flow_imp.g_varchar2_table(11) := 'r) default on null ''N'','||wwv_flow.LF||
'    milestone_description          varchar2(4000 char),'||wwv_flow.LF||
'    tags            ';
wwv_flow_imp.g_varchar2_table(12) := '               varchar2(4000),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_';
wwv_flow_imp.g_varchar2_table(13) := 'by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null';
wwv_flow_imp.g_varchar2_table(14) := ','||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index sp_release_';
wwv_flow_imp.g_varchar2_table(15) := 'milestones_i1 on sp_release_milestones (upper_milestone_name, release_id, milestone_type_id);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(45056431695059844714)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'release milestones table'
,p_sequence=>300
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
