prompt --application/deployment/install/install_create_table_sp_initiative_comments
begin
--   Manifest
--     INSTALL: INSTALL-create table sp_initiative_comments
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>26954343551793662
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6589931838413316327)
,p_install_id=>wwv_flow_imp.id(141215907483525794087)
,p_name=>'create table sp_initiative_comments'
,p_sequence=>810
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table sp_initiative_comments (',
'    id                             number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') ',
'                                   constraint sp_initiative_comments_pk primary key,',
'    row_version                    integer',
'                                   default 1,',
'    initiative_id                  number',
'                                   constraint sp_initiative_commments_fk',
'                                   references sp_initiatives (id)',
'                                   on delete cascade,',
'    --',
'    body                           clob,',
'    body_html                      clob,',
'    author_id                      number,',
'    private_yn                     varchar2(1 char),',
'    --',
'    created                        date not null,',
'    created_by                     varchar2(255 char) not null,',
'    updated                        date not null,',
'    updated_by                     varchar2(255 char) not null',
')',
';',
'',
'create index sp_initiative_comments_i1 on sp_initiative_comments (initiative_id);',
'create index sp_initiative_comments_i2 on sp_initiative_comments (author_id);',
'',
'create or replace trigger sp_initiative_comments_biu',
'    before insert or update',
'    on sp_initiative_comments',
'    for each row',
'begin',
'    if inserting then',
'        :new.created := sysdate;',
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'        if :new.row_version is null then :new.row_version := 1; end if;',
'    end if;',
'    :new.updated := sysdate;',
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'    if updating then',
'       :new.row_version := :new.row_version + 1;',
'    end if;',
'    --',
'    --',
'    --',
'    if :new.private_yn is null then ',
'        :new.private_yn := ''N'';',
'    end if;',
'    --',
'    -- set body_html',
'    --',
'    :new.body_html := apex_markdown.to_html(:new.body);',
'    --',
'    -- touch parent table',
'    --',
'   update sp_initiatives set updated = sysdate, updated_by = :new.updated_by where id = :new.initiative_id;',
'end sp_initiative_comments_biu;',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
