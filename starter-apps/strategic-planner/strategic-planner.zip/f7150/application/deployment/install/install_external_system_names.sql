prompt --application/deployment/install/install_external_system_names
begin
--   Manifest
--     INSTALL: INSTALL-external system names
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table SP_EXTERNAL_TICKETING_SYSTEMS ('||wwv_flow.LF||
'    id                             number default on nu';
wwv_flow_imp.g_varchar2_table(2) := 'll to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   con';
wwv_flow_imp.g_varchar2_table(3) := 'straint SP_EXTERNAL_TICKETING_SYS_PK primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    external_system_name           varchar2';
wwv_flow_imp.g_varchar2_table(4) := '(30 char)   not null,'||wwv_flow.LF||
'    description                    varchar2(4000 char),'||wwv_flow.LF||
'    is_active_yn      ';
wwv_flow_imp.g_varchar2_table(5) := '             varchar2(1 char)    not null,'||wwv_flow.LF||
'    link_pattern                   varchar2(4000 char) no';
wwv_flow_imp.g_varchar2_table(6) := 't null,'||wwv_flow.LF||
'    min_id_length                  integer,'||wwv_flow.LF||
'    max_id_length                  integer,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(7) := '--'||wwv_flow.LF||
'    must_contain                   varchar2(255 char),'||wwv_flow.LF||
'    ticket_id_regex                varchar';
wwv_flow_imp.g_varchar2_table(8) := '2(255 char) not null,'||wwv_flow.LF||
'    evaulation_sequence            number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    required_initiative_id  ';
wwv_flow_imp.g_varchar2_table(9) := '       number'||wwv_flow.LF||
'                                   constraint sp_external_ticketing_system_ini_fk '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(10) := '                                references sp_initiatives (id)'||wwv_flow.LF||
'                                   on';
wwv_flow_imp.g_varchar2_table(11) := ' delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by            ';
wwv_flow_imp.g_varchar2_table(12) := '         varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_';
wwv_flow_imp.g_varchar2_table(13) := 'by                     varchar2(255 char) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger SP_EXTERNAL_TICKE';
wwv_flow_imp.g_varchar2_table(14) := 'TING_SYSTEMS_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on SP_EXTERNAL_TICKETING_SYSTEMS'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'b';
wwv_flow_imp.g_varchar2_table(15) := 'egin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_';
wwv_flow_imp.g_varchar2_table(16) := 'context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_';
wwv_flow_imp.g_varchar2_table(17) := 'by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- default values'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(18) := ' if :new.evaulation_sequence is null then'||wwv_flow.LF||
'       :new.evaulation_sequence := 100;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if';
wwv_flow_imp.g_varchar2_table(19) := ' :new.is_active_yn is null then'||wwv_flow.LF||
'       :new.is_active_yn := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end SP_EXTERNAL_TICKETI';
wwv_flow_imp.g_varchar2_table(20) := 'NG_SYSTEMS_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(41353364325581523273)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'external system names'
,p_sequence=>340
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
