prompt --application/deployment/install/install_sp_util_spec
begin
--   Manifest
--     INSTALL: INSTALL-sp_util spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package sp_util as'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_error_log ( '||wwv_flow.LF||
'    p_package_name    in varchar2,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(2) := '    p_procedure_name  in varchar2, '||wwv_flow.LF||
'    p_error           in varchar2, '||wwv_flow.LF||
'    p_arg1_name       in var';
wwv_flow_imp.g_varchar2_table(3) := 'char2 default null, '||wwv_flow.LF||
'    p_arg1_val        in varchar2 default null, '||wwv_flow.LF||
'    p_arg2_name       in varch';
wwv_flow_imp.g_varchar2_table(4) := 'ar2 default null, '||wwv_flow.LF||
'    p_arg2_val        in varchar2 default null, '||wwv_flow.LF||
'    p_arg3_name       in varchar';
wwv_flow_imp.g_varchar2_table(5) := '2 default null, '||wwv_flow.LF||
'    p_arg3_val        in varchar2 default null, '||wwv_flow.LF||
'    p_arg4_name       in varchar2 ';
wwv_flow_imp.g_varchar2_table(6) := 'default null, '||wwv_flow.LF||
'    p_arg4_val        in varchar2 default null, '||wwv_flow.LF||
'    p_arg5_name       in varchar2 de';
wwv_flow_imp.g_varchar2_table(7) := 'fault null, '||wwv_flow.LF||
'    p_arg5_val        in varchar2 default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_app_log ( '||wwv_flow.LF||
'    p_activ';
wwv_flow_imp.g_varchar2_table(8) := 'ity   in varchar2,'||wwv_flow.LF||
'    p_details    in varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'-- create APIs'||wwv_flow.LF||
'function create_area ('||wwv_flow.LF||
'    p_area';
wwv_flow_imp.g_varchar2_table(9) := '                     in varchar2,'||wwv_flow.LF||
'    p_description              in varchar2 default null,'||wwv_flow.LF||
'    p_own';
wwv_flow_imp.g_varchar2_table(10) := 'er_id                 in number   default null )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'function create_initiative ('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(11) := '  p_area_id                  in number,'||wwv_flow.LF||
'    p_initiative               in varchar2,'||wwv_flow.LF||
'    p_objective ';
wwv_flow_imp.g_varchar2_table(12) := '               in varchar2 default null,'||wwv_flow.LF||
'    p_owner_id                 in number   default null )'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(13) := '   return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'function create_release ('||wwv_flow.LF||
'    p_release_train                  in varchar2,'||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(14) := '_release_owner_id               in number,'||wwv_flow.LF||
'    p_release                        in varchar2,'||wwv_flow.LF||
'    p_r';
wwv_flow_imp.g_varchar2_table(15) := 'elease_target_date            in date,'||wwv_flow.LF||
'    p_release_open_date              in date )'||wwv_flow.LF||
'    return num';
wwv_flow_imp.g_varchar2_table(16) := 'ber;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure copy_release ('||wwv_flow.LF||
'    p_copy_from_release_id  in  number,'||wwv_flow.LF||
'    p_new_release           i';
wwv_flow_imp.g_varchar2_table(17) := 'n  varchar2,'||wwv_flow.LF||
'    p_push_days             in  number,'||wwv_flow.LF||
'    p_new_release_id        out number );'||wwv_flow.LF||
''||wwv_flow.LF||
'func';
wwv_flow_imp.g_varchar2_table(18) := 'tion create_team_member ('||wwv_flow.LF||
'    p_first_name                     in varchar2,'||wwv_flow.LF||
'    p_last_name         ';
wwv_flow_imp.g_varchar2_table(19) := '             in varchar2,'||wwv_flow.LF||
'    p_email                          in varchar2,'||wwv_flow.LF||
'    p_tags              ';
wwv_flow_imp.g_varchar2_table(20) := '             in varchar2 default null,'||wwv_flow.LF||
'    p_is_current_yn                  in varchar2 default ''Y'' ';
wwv_flow_imp.g_varchar2_table(21) := ')'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'function create_project ('||wwv_flow.LF||
'    p_initiative_id                  in number,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(22) := 'p_project                        in varchar2,'||wwv_flow.LF||
'    p_owner_id                       in number,'||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(23) := 'status_scale                   in varchar2 default ''A'','||wwv_flow.LF||
'    p_pct_complete                   in numb';
wwv_flow_imp.g_varchar2_table(24) := 'er default 10,'||wwv_flow.LF||
'    p_priority_id                    in number default 4,'||wwv_flow.LF||
'    p_target_complete      ';
wwv_flow_imp.g_varchar2_table(25) := '          in date default null,'||wwv_flow.LF||
'    p_release_id                     in number default null,'||wwv_flow.LF||
'    p_p';
wwv_flow_imp.g_varchar2_table(26) := 'roject_size                   in varchar2 default ''M'','||wwv_flow.LF||
'    p_description                    in varch';
wwv_flow_imp.g_varchar2_table(27) := 'ar2 default null,'||wwv_flow.LF||
'    p_tags                           in varchar2 default null ) '||wwv_flow.LF||
'    return number';
wwv_flow_imp.g_varchar2_table(28) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'function copy_project ('||wwv_flow.LF||
'    p_project_id                     in number,'||wwv_flow.LF||
'    p_new_project_name   ';
wwv_flow_imp.g_varchar2_table(29) := '            in varchar2 ) '||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_related_project ('||wwv_flow.LF||
'    p_related_project';
wwv_flow_imp.g_varchar2_table(30) := '_id in number,'||wwv_flow.LF||
'    p_project_id         in number );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_project_link ('||wwv_flow.LF||
'    p_project_id ';
wwv_flow_imp.g_varchar2_table(31) := '     in number,'||wwv_flow.LF||
'    p_link_name       in varchar2,'||wwv_flow.LF||
'    p_link_url        in varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure d';
wwv_flow_imp.g_varchar2_table(32) := 'efault_project_tasks ('||wwv_flow.LF||
'    p_project_id      in number );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure archive_project ('||wwv_flow.LF||
'    p_project';
wwv_flow_imp.g_varchar2_table(33) := '_id      in number,'||wwv_flow.LF||
'    p_app_user        in varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure un_archive_project ('||wwv_flow.LF||
'    p_proje';
wwv_flow_imp.g_varchar2_table(34) := 'ct_id      in number );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure mark_proj_as_duplidate ('||wwv_flow.LF||
'    p_project_id        in number,'||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(35) := '_dup_of_project    in number );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure unmark_proj_as_duplicate ('||wwv_flow.LF||
'    p_project_id        in num';
wwv_flow_imp.g_varchar2_table(36) := 'ber );'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------------'||wwv_flow.LF||
'-- additional APIs'||wwv_flow.LF||
'--'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_user_email ('||wwv_flow.LF||
'    p_app_user     in  ';
wwv_flow_imp.g_varchar2_table(37) := 'varchar2  default null,'||wwv_flow.LF||
'    p_user_id      in  number    default null )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'functi';
wwv_flow_imp.g_varchar2_table(38) := 'on get_user_id ('||wwv_flow.LF||
'    p_app_user     in varchar2   default null,'||wwv_flow.LF||
'    p_screen_name  in  varchar2  def';
wwv_flow_imp.g_varchar2_table(39) := 'ault null )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_area_name ('||wwv_flow.LF||
'    p_id              in number )'||wwv_flow.LF||
'    retur';
wwv_flow_imp.g_varchar2_table(40) := 'n varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_initiative_name ('||wwv_flow.LF||
'    p_id              in number )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(41) := 'function get_project_name ('||wwv_flow.LF||
'    p_id              in number )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_pr';
wwv_flow_imp.g_varchar2_table(42) := 'oject_contributor ('||wwv_flow.LF||
'    P_TEAM_MEMBER_ID    in number,'||wwv_flow.LF||
'    p_RESPONSIBILITY_ID in number,'||wwv_flow.LF||
'    p_proj';
wwv_flow_imp.g_varchar2_table(43) := 'ect_id        in number );'||wwv_flow.LF||
'    '||wwv_flow.LF||
'procedure add_project_tag ('||wwv_flow.LF||
'    p_project_id        in number,'||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(44) := '_tag               in varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure remove_project_tag ('||wwv_flow.LF||
'    p_project_id        in number,';
wwv_flow_imp.g_varchar2_table(45) := ''||wwv_flow.LF||
'    p_tag               in varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure set_nomenclature;'||wwv_flow.LF||
''||wwv_flow.LF||
'function show_nomenclature ret';
wwv_flow_imp.g_varchar2_table(46) := 'urn clob;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_nomenclature ('||wwv_flow.LF||
'    p_static_id  in  varchar2 )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedu';
wwv_flow_imp.g_varchar2_table(47) := 're add_setting (  '||wwv_flow.LF||
'    p_static_id      in  varchar2,   '||wwv_flow.LF||
'    p_description    in  varchar2, '||wwv_flow.LF||
'    p_s';
wwv_flow_imp.g_varchar2_table(48) := 'etting_value  in  varchar2, '||wwv_flow.LF||
'    p_is_numeric_yn  in  varchar2, '||wwv_flow.LF||
'    p_is_yn          in  varchar2 )';
wwv_flow_imp.g_varchar2_table(49) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure set_setting (  '||wwv_flow.LF||
'    p_static_id      in  varchar2,   '||wwv_flow.LF||
'    p_setting_value  in  varchar2';
wwv_flow_imp.g_varchar2_table(50) := ' );'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_setting ('||wwv_flow.LF||
'    p_static_id  in  varchar2 )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_ai_p';
wwv_flow_imp.g_varchar2_table(51) := 'rompt (  '||wwv_flow.LF||
'    p_static_id      in  varchar2,   '||wwv_flow.LF||
'    p_description    in  varchar2, '||wwv_flow.LF||
'    p_prompt    ';
wwv_flow_imp.g_varchar2_table(52) := '     in  clob );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure set_ai_prompt (  '||wwv_flow.LF||
'    p_static_id      in  varchar2,   '||wwv_flow.LF||
'    p_prompt    ';
wwv_flow_imp.g_varchar2_table(53) := '     in  clob );'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_ai_prompt ('||wwv_flow.LF||
'    p_static_id  in  varchar2 )'||wwv_flow.LF||
'    return clob;'||wwv_flow.LF||
''||wwv_flow.LF||
'functio';
wwv_flow_imp.g_varchar2_table(54) := 'n get_notification_id ('||wwv_flow.LF||
'    p_static_id   in  varchar2 )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure notification_';
wwv_flow_imp.g_varchar2_table(55) := 'opt_in ('||wwv_flow.LF||
'    p_team_member_id   in  number,'||wwv_flow.LF||
'    p_notification_id  in  number,'||wwv_flow.LF||
'    p_frequency      ';
wwv_flow_imp.g_varchar2_table(56) := '  in  varchar2 default ''WEEKLY'','||wwv_flow.LF||
'    p_release_id       in  number   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure noti';
wwv_flow_imp.g_varchar2_table(57) := 'fication_opt_out ('||wwv_flow.LF||
'    p_team_member_id   in  number,'||wwv_flow.LF||
'    p_notification_id  in  number,'||wwv_flow.LF||
'    p_relea';
wwv_flow_imp.g_varchar2_table(58) := 'se_id       in  number default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure get_create_project_qp ('||wwv_flow.LF||
'    p_app_user         in ';
wwv_flow_imp.g_varchar2_table(59) := 'varchar2,'||wwv_flow.LF||
'    p_quick_pick_id_1  out number,'||wwv_flow.LF||
'    p_quick_pick_1     out varchar2,'||wwv_flow.LF||
'    p_quick_pick_i';
wwv_flow_imp.g_varchar2_table(60) := 'd_2  out number,'||wwv_flow.LF||
'    p_quick_pick_2     out varchar2,'||wwv_flow.LF||
'    p_quick_pick_id_3  out number,'||wwv_flow.LF||
'    p_quick';
wwv_flow_imp.g_varchar2_table(61) := '_pick_3     out varchar2,'||wwv_flow.LF||
'    p_quick_pick_id_4  out number,'||wwv_flow.LF||
'    p_quick_pick_4     out varchar2 );'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(62) := ''||wwv_flow.LF||
'procedure get_current_username_and_id ('||wwv_flow.LF||
'    p_app_user         in varchar2,'||wwv_flow.LF||
'    p_users_name       ';
wwv_flow_imp.g_varchar2_table(63) := 'out varchar2,'||wwv_flow.LF||
'    p_users_id         out number );'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------'||wwv_flow.LF||
'-- data sync'||wwv_flow.LF||
'--'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure sync_te';
wwv_flow_imp.g_varchar2_table(64) := 'am_members_app_role ('||wwv_flow.LF||
'    p_app_id in number );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure sync_team_member_app_role ('||wwv_flow.LF||
'    p_app_id ';
wwv_flow_imp.g_varchar2_table(65) := 'in number,'||wwv_flow.LF||
'    p_email  in varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------'||wwv_flow.LF||
'-- Tags'||wwv_flow.LF||
'--'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_default_tag ('||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(66) := 'tag        in varchar2,'||wwv_flow.LF||
'    p_sequence   in number default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure get_default_tags ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(67) := ' p_tag_1      out varchar2,'||wwv_flow.LF||
'    p_tag_2      out varchar2,'||wwv_flow.LF||
'    p_tag_3      out varchar2,'||wwv_flow.LF||
'    p_tag_';
wwv_flow_imp.g_varchar2_table(68) := '4      out varchar2,'||wwv_flow.LF||
'    p_tag_5      out varchar2,'||wwv_flow.LF||
'    p_tag_6      out varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'function count';
wwv_flow_imp.g_varchar2_table(69) := '_project_tags ('||wwv_flow.LF||
'    p_project_id in number )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_project_id ('||wwv_flow.LF||
'    p_fri';
wwv_flow_imp.g_varchar2_table(70) := 'endly_identifier in varchar2,'||wwv_flow.LF||
'    p_project_url_name    in varchar2 )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
' function ';
wwv_flow_imp.g_varchar2_table(71) := 'get_initiative_id ('||wwv_flow.LF||
'    p_friendly_identifier    in varchar2,'||wwv_flow.LF||
'    p_initiative_url_name    in varcha';
wwv_flow_imp.g_varchar2_table(72) := 'r2 )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'--------------------'||wwv_flow.LF||
'-- utility functions'||wwv_flow.LF||
'--'||wwv_flow.LF||
''||wwv_flow.LF||
'function compress_int ('||wwv_flow.LF||
'    n';
wwv_flow_imp.g_varchar2_table(73) := ' in integer ) '||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function find_mentions ('||wwv_flow.LF||
'    p_clob in clob )'||wwv_flow.LF||
'    return varcha';
wwv_flow_imp.g_varchar2_table(74) := 'r2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function list_change ('||wwv_flow.LF||
'    p_old_list   in varchar2 default null, '||wwv_flow.LF||
'    p_new_list   in varchar2';
wwv_flow_imp.g_varchar2_table(75) := ' default null, '||wwv_flow.LF||
'    p_delim      in varchar2 default '','' )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------------';
wwv_flow_imp.g_varchar2_table(76) := '-'||wwv_flow.LF||
'-- for Notification Subscriptions'||wwv_flow.LF||
'--'||wwv_flow.LF||
'procedure send_notif_subscriptions;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure assignment_not';
wwv_flow_imp.g_varchar2_table(77) := 'ification ('||wwv_flow.LF||
'    p_team_member_id     in  number,'||wwv_flow.LF||
'    p_app_name           in  varchar2,'||wwv_flow.LF||
'    p_app_id';
wwv_flow_imp.g_varchar2_table(78) := '             in  number,'||wwv_flow.LF||
'    p_project_id         in  number  default null,'||wwv_flow.LF||
'    p_task_id           ';
wwv_flow_imp.g_varchar2_table(79) := ' in  number  default null,'||wwv_flow.LF||
'    p_link               in  varchar2,'||wwv_flow.LF||
'    p_view_what          in  varch';
wwv_flow_imp.g_varchar2_table(80) := 'ar2,'||wwv_flow.LF||
'    p_title              in  varchar2,'||wwv_flow.LF||
'    p_email_contents     in  varchar2,'||wwv_flow.LF||
'    p_notificatio';
wwv_flow_imp.g_varchar2_table(81) := 'n_type  in  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure comment_notification ('||wwv_flow.LF||
'    p_team_member_id     in  number,'||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(82) := '_app_name           in  varchar2,'||wwv_flow.LF||
'    p_app_id             in  number,'||wwv_flow.LF||
'    p_project_id         in  ';
wwv_flow_imp.g_varchar2_table(83) := 'number  default null,'||wwv_flow.LF||
'    p_task_id            in  number  default null,'||wwv_flow.LF||
'    p_link               in';
wwv_flow_imp.g_varchar2_table(84) := '  varchar2,'||wwv_flow.LF||
'    p_view_what          in  varchar2,'||wwv_flow.LF||
'    p_title              in  varchar2,'||wwv_flow.LF||
'    p_emai';
wwv_flow_imp.g_varchar2_table(85) := 'l_contents     in  varchar2,'||wwv_flow.LF||
'    p_notification_type  in  varchar2 default ''COMMENT'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'-- used by ';
wwv_flow_imp.g_varchar2_table(86) := 'SP_CONTRIBUTOR_SUMMARY, SP_RELEASE_TIMELINE and with app'||wwv_flow.LF||
'function exceptions_for_project ('||wwv_flow.LF||
'    p_pro';
wwv_flow_imp.g_varchar2_table(87) := 'ject_id      in  number,'||wwv_flow.LF||
'    p_one_project_yn  in  varchar2 default ''N'','||wwv_flow.LF||
'    p_team_member_id  in  n';
wwv_flow_imp.g_varchar2_table(88) := 'umber   default null,'||wwv_flow.LF||
'    p_link_type       in  varchar2,'||wwv_flow.LF||
'    p_app_prefix_url  in  varchar2,'||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(89) := 'app_id          in  number,'||wwv_flow.LF||
'    p_apex_session    in  number   default null,'||wwv_flow.LF||
'    p_reviews_yn      i';
wwv_flow_imp.g_varchar2_table(90) := 'n  varchar2 default ''N'','||wwv_flow.LF||
'    p_approvals_yn    in  varchar2 default ''N'' )'||wwv_flow.LF||
'    return clob;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- used ';
wwv_flow_imp.g_varchar2_table(91) := 'for build option display within Admin'||wwv_flow.LF||
'function replace_nomenclature ('||wwv_flow.LF||
'    p_contents  in  varchar2 )';
wwv_flow_imp.g_varchar2_table(92) := ''||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_util;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(151732874807142016689)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_util spec'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
