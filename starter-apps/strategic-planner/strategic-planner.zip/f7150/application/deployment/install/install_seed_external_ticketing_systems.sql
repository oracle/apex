prompt --application/deployment/install/install_seed_external_ticketing_systems
begin
--   Manifest
--     INSTALL: INSTALL-seed external_ticketing_systems
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(17078434577725205776)
,p_install_id=>wwv_flow_imp.id(141188953139974000425)
,p_name=>'seed external_ticketing_systems'
,p_sequence=>1020
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into SP_EXTERNAL_TICKETING_SYSTEMS ',
'    ( ID, EVAULATION_SEQUENCE, EXTERNAL_SYSTEM_NAME, IS_ACTIVE_YN, LINK_PATTERN, description, TICKET_ID_REGEX) ',
'    values ',
'    (1, 10, ''Jira'', ''Y'', ''https://jira.myorg.com/jira/browse/#TICKET#'', ''Our Jira'', ''[Jj][Ii][Rr][Aa][-: ]\d{3,5}'');'))
);
wwv_flow_imp.component_end;
end;
/
