prompt --application/deployment/install/install_seed_external_ticketing_systems
begin
--   Manifest
--     INSTALL: INSTALL-seed external_ticketing_systems
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into SP_EXTERNAL_TICKETING_SYSTEMS '||wwv_flow.LF||
'    ( ID, EVAULATION_SEQUENCE, EXTERNAL_SYSTEM_NAME, IS_A';
wwv_flow_imp.g_varchar2_table(2) := 'CTIVE_YN, LINK_PATTERN, description, TICKET_ID_REGEX) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (1, 10, ''Jira'', ''Y'', ''https:/';
wwv_flow_imp.g_varchar2_table(3) := '/jira.myorg.com/jira/browse/#TICKET#'', ''Our Jira'', ''[Jj][Ii][Rr][Aa][-: ]\d{3,5}'');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(52110515092376469957)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed external_ticketing_systems'
,p_sequence=>790
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
