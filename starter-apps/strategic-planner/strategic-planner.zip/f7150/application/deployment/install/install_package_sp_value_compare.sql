prompt --application/deployment/install/install_package_sp_value_compare
begin
--   Manifest
--     INSTALL: INSTALL-package sp_value_compare
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package sp_value_compare'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Determine if two values are equal or not regardless o';
wwv_flow_imp.g_varchar2_table(2) := 'f their nullness'||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- In Oracle, to handle comparison with NULL values, you need to use the followi';
wwv_flow_imp.g_varchar2_table(3) := 'ng Oracle operators: '||wwv_flow.LF||
'-- IS NULL     the logical operation = NULL'||wwv_flow.LF||
'-- IS NOT NULL the logical operati';
wwv_flow_imp.g_varchar2_table(4) := 'on != NULL'||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- for use in database triggers for columns that can be null'||wwv_flow.LF||
'-- you can ue is_equal to';
wwv_flow_imp.g_varchar2_table(5) := ' compare two columns regardless of null values'||wwv_flow.LF||
'--'||wwv_flow.LF||
'as'||wwv_flow.LF||
''||wwv_flow.LF||
'function is_equal ('||wwv_flow.LF||
'   p_value1     in varchar';
wwv_flow_imp.g_varchar2_table(6) := '2 default null,'||wwv_flow.LF||
'   p_value2     in varchar2 default null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return boolean;'||wwv_flow.LF||
''||wwv_flow.LF||
'function is_equal ';
wwv_flow_imp.g_varchar2_table(7) := '('||wwv_flow.LF||
'   p_value1     in date default null,'||wwv_flow.LF||
'   p_value2     in date default null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return boolean;';
wwv_flow_imp.g_varchar2_table(8) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'function is_equal ('||wwv_flow.LF||
'   p_value1     in timestamp default null,'||wwv_flow.LF||
'   p_value2     in timestamp defaul';
wwv_flow_imp.g_varchar2_table(9) := 't null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return boolean;'||wwv_flow.LF||
''||wwv_flow.LF||
'function is_equal ('||wwv_flow.LF||
'   p_value1     in clob default null,'||wwv_flow.LF||
'   p_value';
wwv_flow_imp.g_varchar2_table(10) := '2     in clob default null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return boolean;'||wwv_flow.LF||
''||wwv_flow.LF||
'--function is_equal ('||wwv_flow.LF||
'--   p_value1     in blob ';
wwv_flow_imp.g_varchar2_table(11) := 'default null,'||wwv_flow.LF||
'--   p_value2     in blob default null'||wwv_flow.LF||
'--   )'||wwv_flow.LF||
'--   return boolean;'||wwv_flow.LF||
''||wwv_flow.LF||
'function is_equal ';
wwv_flow_imp.g_varchar2_table(12) := '('||wwv_flow.LF||
'   p_value1     in number default null,'||wwv_flow.LF||
'   p_value2     in number default null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return bool';
wwv_flow_imp.g_varchar2_table(13) := 'ean;'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_value_compare;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace package body sp_value_compare'||wwv_flow.LF||
'as'||wwv_flow.LF||
''||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- string'||wwv_flow.LF||
'--'||wwv_flow.LF||
'f';
wwv_flow_imp.g_varchar2_table(14) := 'unction is_equal ('||wwv_flow.LF||
'   p_value1     in varchar2 default null,'||wwv_flow.LF||
'   p_value2     in varchar2 default nul';
wwv_flow_imp.g_varchar2_table(15) := 'l'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return boolean'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if p_value1 is null then'||wwv_flow.LF||
'      if p_value2 is null then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(16) := '  return true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         return false;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   elsif p_value2 is null then'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(17) := 'return false;'||wwv_flow.LF||
'   else'||wwv_flow.LF||
'      if p_value1 = p_value2 then'||wwv_flow.LF||
'         return true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         re';
wwv_flow_imp.g_varchar2_table(18) := 'turn false;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end is_equal;'||wwv_flow.LF||
''||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- date'||wwv_flow.LF||
'--'||wwv_flow.LF||
'function is_equal ('||wwv_flow.LF||
'   p_value1   ';
wwv_flow_imp.g_varchar2_table(19) := '  in date default null,'||wwv_flow.LF||
'   p_value2     in date default null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return boolean'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if p';
wwv_flow_imp.g_varchar2_table(20) := '_value1 is null then'||wwv_flow.LF||
'      if p_value2 is null then'||wwv_flow.LF||
'         return true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         return';
wwv_flow_imp.g_varchar2_table(21) := ' false;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   elsif p_value2 is null then'||wwv_flow.LF||
'      return false;'||wwv_flow.LF||
'   else'||wwv_flow.LF||
'      if p_value1 =';
wwv_flow_imp.g_varchar2_table(22) := ' p_value2 then'||wwv_flow.LF||
'         return true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         return false;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end ';
wwv_flow_imp.g_varchar2_table(23) := 'is_equal;'||wwv_flow.LF||
''||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- date'||wwv_flow.LF||
'--'||wwv_flow.LF||
'function is_equal ('||wwv_flow.LF||
'   p_value1     in timestamp default null,'||wwv_flow.LF||
'   p_value2 ';
wwv_flow_imp.g_varchar2_table(24) := '    in timestamp default null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return boolean'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if p_value1 is null then'||wwv_flow.LF||
'      if p';
wwv_flow_imp.g_varchar2_table(25) := '_value2 is null then'||wwv_flow.LF||
'         return true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         return false;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   elsif ';
wwv_flow_imp.g_varchar2_table(26) := 'p_value2 is null then'||wwv_flow.LF||
'      return false;'||wwv_flow.LF||
'   else'||wwv_flow.LF||
'      if p_value1 = p_value2 then'||wwv_flow.LF||
'         return ';
wwv_flow_imp.g_varchar2_table(27) := 'true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         return false;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end is_equal;'||wwv_flow.LF||
''||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- CLOB'||wwv_flow.LF||
'--'||wwv_flow.LF||
'functi';
wwv_flow_imp.g_varchar2_table(28) := 'on is_equal ('||wwv_flow.LF||
'   p_value1     in clob default null,'||wwv_flow.LF||
'   p_value2     in clob default null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   ret';
wwv_flow_imp.g_varchar2_table(29) := 'urn boolean'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if p_value1 is null then'||wwv_flow.LF||
'      if p_value2 is null then'||wwv_flow.LF||
'         return true';
wwv_flow_imp.g_varchar2_table(30) := ';'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         return false;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   elsif p_value2 is null then'||wwv_flow.LF||
'      return false;';
wwv_flow_imp.g_varchar2_table(31) := ''||wwv_flow.LF||
'   else'||wwv_flow.LF||
'      if DBMS_LOB.COMPARE(p_value1,p_value2) = 0 then'||wwv_flow.LF||
'         return true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(32) := '     return false;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end is_equal;'||wwv_flow.LF||
''||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- BLOB'||wwv_flow.LF||
'--'||wwv_flow.LF||
'/*'||wwv_flow.LF||
'function is_equal ('||wwv_flow.LF||
'   p';
wwv_flow_imp.g_varchar2_table(33) := '_value1     in blob default null,'||wwv_flow.LF||
'   p_value2     in blob default null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return boolean'||wwv_flow.LF||
'is'||wwv_flow.LF||
'beg';
wwv_flow_imp.g_varchar2_table(34) := 'in'||wwv_flow.LF||
'   if p_value1 is null then'||wwv_flow.LF||
'      if p_value2 is null then'||wwv_flow.LF||
'         return true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(35) := '    return false;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   elsif p_value2 is null then'||wwv_flow.LF||
'      return false;'||wwv_flow.LF||
'   else'||wwv_flow.LF||
'      if ';
wwv_flow_imp.g_varchar2_table(36) := 'DBMS_LOB.COMPARE(p_value1,p_value2) = 0 then'||wwv_flow.LF||
'         return true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         return false;';
wwv_flow_imp.g_varchar2_table(37) := ''||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end is_equal;'||wwv_flow.LF||
'*/'||wwv_flow.LF||
''||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- number'||wwv_flow.LF||
'--'||wwv_flow.LF||
'function is_equal ('||wwv_flow.LF||
'   p_value1     in n';
wwv_flow_imp.g_varchar2_table(38) := 'umber default null,'||wwv_flow.LF||
'   p_value2     in number default null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return boolean'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if p_v';
wwv_flow_imp.g_varchar2_table(39) := 'alue1 is null then'||wwv_flow.LF||
'      if p_value2 is null then'||wwv_flow.LF||
'         return true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         return f';
wwv_flow_imp.g_varchar2_table(40) := 'alse;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   elsif p_value2 is null then'||wwv_flow.LF||
'      return false;'||wwv_flow.LF||
'   else'||wwv_flow.LF||
'      if p_value1 = p';
wwv_flow_imp.g_varchar2_table(41) := '_value2 then'||wwv_flow.LF||
'         return true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         return false;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end is';
wwv_flow_imp.g_varchar2_table(42) := '_equal;'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_value_compare;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(63884275154837728713)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'package sp_value_compare'
,p_sequence=>320
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
