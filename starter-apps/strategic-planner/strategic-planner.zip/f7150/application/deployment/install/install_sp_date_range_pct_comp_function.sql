prompt --application/deployment/install/install_sp_date_range_pct_comp_function
begin
--   Manifest
--     INSTALL: INSTALL-sp_date_range_pct_comp function
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16206954959961131824)
,p_install_id=>wwv_flow_imp.id(141180564419272860082)
,p_name=>'sp_date_range_pct_comp function'
,p_sequence=>700
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace function sp_date_range_pct_comp (',
'    p_start_date in date,',
'    p_end_date   in date)',
'    return number',
'is',
'    l_pct_complete number := 0;',
'    l_days         number := null;',
'    l_days_elapsed number := null;',
'begin',
'    --',
'    -- this function return 0, 10, 20 .. 100 based days elapsed between two dates',
'    --',
'    if p_start_date is null or p_end_date is null then',
'       l_pct_complete := 0; -- required both dates be not null',
'    else',
'       if p_start_date > p_end_date then ',
'           l_pct_complete := 0; -- invalid condition',
'       elsif p_start_date > sysdate then ',
'           l_pct_complete := 0; ',
'       elsif p_start_date = p_end_date then ',
'           l_pct_complete := 100;',
'       else ',
'           l_days := p_end_date - p_start_date; ',
'           if l_days > 0 then ',
'               l_days_elapsed := p_end_date - trunc(sysdate);',
'               l_pct_complete := 100 * l_days_elapsed / l_days;',
'               l_pct_complete := round(l_pct_complete,-1);',
'           end if;',
'       end if;',
'    end if;',
'    return l_pct_complete;',
'end sp_date_range_pct_comp;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
