prompt --application/deployment/install/install_sp_date_range_pct_comp_function
begin
--   Manifest
--     INSTALL: INSTALL-sp_date_range_pct_comp function
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace function sp_date_range_pct_comp ('||wwv_flow.LF||
'    p_start_date in date,'||wwv_flow.LF||
'    p_end_date   in da';
wwv_flow_imp.g_varchar2_table(2) := 'te)'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_pct_complete number := 0;'||wwv_flow.LF||
'    l_days         number := null;'||wwv_flow.LF||
'    l_da';
wwv_flow_imp.g_varchar2_table(3) := 'ys_elapsed number := null;'||wwv_flow.LF||
'    l_sysdate      date   := trunc(sysdate);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- this fun';
wwv_flow_imp.g_varchar2_table(4) := 'ction return 0, 10, 20 .. 100 based days elapsed between two dates'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if p_start_date is nul';
wwv_flow_imp.g_varchar2_table(5) := 'l or p_end_date is null then'||wwv_flow.LF||
'       l_pct_complete := 0; -- required both dates be not null'||wwv_flow.LF||
'    else';
wwv_flow_imp.g_varchar2_table(6) := ''||wwv_flow.LF||
'       if p_start_date > p_end_date then '||wwv_flow.LF||
'           l_pct_complete := 0; -- invalid condition'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(7) := '   elsif p_start_date > l_sysdate then '||wwv_flow.LF||
'           l_pct_complete := 0; '||wwv_flow.LF||
'       elsif p_start_date =';
wwv_flow_imp.g_varchar2_table(8) := ' p_end_date then '||wwv_flow.LF||
'           l_pct_complete := 100;'||wwv_flow.LF||
'       elsif l_sysdate > p_end_date then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(9) := '    l_pct_complete := 100;'||wwv_flow.LF||
'       else '||wwv_flow.LF||
'           l_days := p_end_date - p_start_date; '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(10) := 'if l_days > 0 then '||wwv_flow.LF||
'               l_days_elapsed := p_end_date - l_sysdate;'||wwv_flow.LF||
'               l_pct_co';
wwv_flow_imp.g_varchar2_table(11) := 'mplete := 100 * l_days_elapsed / l_days;'||wwv_flow.LF||
'               l_pct_complete := round(l_pct_complete,-1);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(12) := '               l_pct_complete := 100 - l_pct_complete;'||wwv_flow.LF||
'           end if;'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'    end if;';
wwv_flow_imp.g_varchar2_table(13) := ''||wwv_flow.LF||
'    return l_pct_complete;'||wwv_flow.LF||
'end sp_date_range_pct_comp;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(51247424195313536348)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_date_range_pct_comp function'
,p_sequence=>590
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
