prompt --application/deployment/install/install_sp_contributor_summary_body
begin
--   Manifest
--     INSTALL: INSTALL-sp_contributor_summary body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body sp_contributor_summary'||wwv_flow.LF||
'as'||wwv_flow.LF||
''||wwv_flow.LF||
'function generate ('||wwv_flow.LF||
'    p_team_member_id  ';
wwv_flow_imp.g_varchar2_table(2) := '   in number,'||wwv_flow.LF||
'    p_show_activities    in varchar2 default ''Y'','||wwv_flow.LF||
'    p_show_projects      in varchar2';
wwv_flow_imp.g_varchar2_table(3) := ' default ''Y'','||wwv_flow.LF||
'    p_show_approvals     in varchar2 default ''N'',  -- based on build option in app'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(4) := ' p_links              in varchar2 default ''NONE'','||wwv_flow.LF||
'    p_include_title_yn   in varchar2 default ''Y'','||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(5) := '    p_apex_session       in varchar2 default null )'||wwv_flow.LF||
'    return clob'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    x                      cl';
wwv_flow_imp.g_varchar2_table(6) := 'ob := null;'||wwv_flow.LF||
'    x2                     clob := null;'||wwv_flow.LF||
'    x3                     clob := null;'||wwv_flow.LF||
'    x4';
wwv_flow_imp.g_varchar2_table(7) := '                     clob := null;'||wwv_flow.LF||
'    x5                     clob := null;'||wwv_flow.LF||
'    x6                  ';
wwv_flow_imp.g_varchar2_table(8) := '   clob := null;'||wwv_flow.LF||
'    x7                     clob := null;'||wwv_flow.LF||
'    l_date_from            date := trunc(s';
wwv_flow_imp.g_varchar2_table(9) := 'ysdate) - 6;'||wwv_flow.LF||
'    l_date_to              date := sysdate;'||wwv_flow.LF||
'    l_person               varchar2(255);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(10) := '   l_email                varchar2(255);'||wwv_flow.LF||
'    l_team_member_id       number;'||wwv_flow.LF||
'    l_lower_app_user    ';
wwv_flow_imp.g_varchar2_table(11) := '   varchar2(255) := null;'||wwv_flow.LF||
'    l_date_fm              varchar2(255) := ''FMDay DD-MON'';'||wwv_flow.LF||
'    l_date_fm2';
wwv_flow_imp.g_varchar2_table(12) := '             varchar2(255) := ''FMDay DD-MON-YYYY'';'||wwv_flow.LF||
'    l_day_fm               varchar2(255) := ''FMDa';
wwv_flow_imp.g_varchar2_table(13) := 'y'';'||wwv_flow.LF||
'    l_days                 number;'||wwv_flow.LF||
'    l_last_heading         varchar2(500);'||wwv_flow.LF||
'    l_row_count    ';
wwv_flow_imp.g_varchar2_table(14) := '        int := 0;'||wwv_flow.LF||
'    l_activity_count       int := 0;'||wwv_flow.LF||
'    l_release_count        int := 0;'||wwv_flow.LF||
'    l_ma';
wwv_flow_imp.g_varchar2_table(15) := 'x_text_length      int := 120;'||wwv_flow.LF||
'    l_project_max_count    int := 20;'||wwv_flow.LF||
'    l_link_type            varc';
wwv_flow_imp.g_varchar2_table(16) := 'har2(30);'||wwv_flow.LF||
'    l_project_label        varchar2(255);'||wwv_flow.LF||
'    l_initiative_label     varchar2(255);'||wwv_flow.LF||
'    l_';
wwv_flow_imp.g_varchar2_table(17) := 'projects_label       varchar2(255);'||wwv_flow.LF||
'    l_initiatives_label    varchar2(255);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- support ';
wwv_flow_imp.g_varchar2_table(18) := 'for links'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    l_project              varchar2(4000);'||wwv_flow.LF||
'    l_role                 varchar2(4000';
wwv_flow_imp.g_varchar2_table(19) := ');'||wwv_flow.LF||
'    l_url                  varchar2(4000);'||wwv_flow.LF||
'    l_app_id               varchar2(4000);'||wwv_flow.LF||
'    l_app_p';
wwv_flow_imp.g_varchar2_table(20) := 'refix_url       varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- get settings'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    l_project_label     := s';
wwv_flow_imp.g_varchar2_table(21) := 'p_util.get_nomenclature(''PROJECT'');'||wwv_flow.LF||
'    l_initiative_label  := sp_util.get_nomenclature(''INITIATIVE''';
wwv_flow_imp.g_varchar2_table(22) := ');'||wwv_flow.LF||
'    l_projects_label    := sp_util.get_nomenclature(''PROJECTS'');'||wwv_flow.LF||
'    l_initiatives_label := sp_ut';
wwv_flow_imp.g_varchar2_table(23) := 'il.get_nomenclature(''INITIATIVES'');'||wwv_flow.LF||
'    l_app_id            := sp_util.get_setting(''APP_ID'');'||wwv_flow.LF||
'    l_';
wwv_flow_imp.g_varchar2_table(24) := 'app_prefix_url    := sp_util.get_setting(''APP_PREFIX_URL'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- determine link type'||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(25) := '-'||wwv_flow.LF||
'    -- APP: generate links from within the current app requires p_apex_session'||wwv_flow.LF||
'    -- EMAIL: gener';
wwv_flow_imp.g_varchar2_table(26) := 'ate fully qualified links'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if p_links = ''APP'' and p_apex_session is not null and l_app_id ';
wwv_flow_imp.g_varchar2_table(27) := 'is not null then'||wwv_flow.LF||
'       l_link_type := ''APP'';'||wwv_flow.LF||
'    elsif p_links = ''EMAIL'' and l_app_id is not null t';
wwv_flow_imp.g_varchar2_table(28) := 'hen'||wwv_flow.LF||
'       l_link_type := ''EMAIL'';'||wwv_flow.LF||
'    elsif p_links = ''JOB'' and l_app_id is not null then'||wwv_flow.LF||
'       l_';
wwv_flow_imp.g_varchar2_table(29) := 'link_type := ''JOB'';'||wwv_flow.LF||
'    elsif p_links is null then'||wwv_flow.LF||
'       l_link_type := ''NONE'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(30) := '-'||wwv_flow.LF||
'    -- name'||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select first_Name||'' ''||last_name name, email, id '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(31) := '       from sp_team_members tm '||wwv_flow.LF||
'         where id = p_team_member_id'||wwv_flow.LF||
'    ) loop '||wwv_flow.LF||
'        l_person :=';
wwv_flow_imp.g_varchar2_table(32) := ' apex_escape.html(c1.name);'||wwv_flow.LF||
'        l_email  := lower(apex_escape.html(c1.email));'||wwv_flow.LF||
'        l_lower_a';
wwv_flow_imp.g_varchar2_table(33) := 'pp_user := lower(c1.email);'||wwv_flow.LF||
'        l_team_member_id := c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- heading'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(34) := '    --'||wwv_flow.LF||
'    if p_include_title_yn = ''Y'' then'||wwv_flow.LF||
'       x := ''<h3>Weekly report for ''||l_person||''</h3>''|';
wwv_flow_imp.g_varchar2_table(35) := '|chr(10);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if l_link_type != ''APP'' then'||wwv_flow.LF||
'        x := x||''<span><strong>email</strong>';
wwv_flow_imp.g_varchar2_table(36) := ': ''||l_email||''</span><br>'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    x := x||''<span><strong>timeframe</strong>: ''||to_char(l';
wwv_flow_imp.g_varchar2_table(37) := '_date_from,l_date_fm)||'' - ''||to_char(l_date_to,l_date_fm2)||''</span><br><br><p style="border-bottom';
wwv_flow_imp.g_varchar2_table(38) := ': 1px solid #E0DEDD;"></p>'';'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --  ######################################################';
wwv_flow_imp.g_varchar2_table(39) := '#########'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --  A C T I V I T I E S'||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --  current'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if p_show_act';
wwv_flow_imp.g_varchar2_table(40) := 'ivities = ''Y'' then'||wwv_flow.LF||
'    '||wwv_flow.LF||
'        x2 := x2||''<h3>Activities</h3>''||chr(10);'||wwv_flow.LF||
'        l_row_count := 0;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(41) := '        for c1 in ('||wwv_flow.LF||
'            select ap.id, '||wwv_flow.LF||
'                   ap.project_id,'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(42) := '--'||wwv_flow.LF||
'                   -- activity core information'||wwv_flow.LF||
'                   --'||wwv_flow.LF||
'                   at.activ';
wwv_flow_imp.g_varchar2_table(43) := 'ity_type,'||wwv_flow.LF||
'                   decode(greatest(length(ap.comments),l_max_text_length),l_max_text_lengt';
wwv_flow_imp.g_varchar2_table(44) := 'h,ap.comments,substr(ap.comments,1,l_max_text_length)||''...'') comments,'||wwv_flow.LF||
'                   --'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(45) := '             to_char(ap.start_date,''DD-MON'')||'' to ''||to_char(ap.end_date,''DD-MON-YYYY'') TIMELINE,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(46) := '                  --'||wwv_flow.LF||
'                   decode(ap.project_id,null,null,('||wwv_flow.LF||
'                       sele';
wwv_flow_imp.g_varchar2_table(47) := 'ct decode(greatest(length(p.project),l_max_text_length),l_max_text_length,p.PROJECT,substr(p.project';
wwv_flow_imp.g_varchar2_table(48) := ',1,l_max_text_length)||''...'') project '||wwv_flow.LF||
'                       from sp_projects p '||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(49) := '     where p.id = ap.project_id and '||wwv_flow.LF||
'                             p.DUPLICATE_OF_PROJECT_ID is null ';
wwv_flow_imp.g_varchar2_table(50) := 'and'||wwv_flow.LF||
'                             p.ARCHIVED_YN = ''N'')'||wwv_flow.LF||
'                       ) project,'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(51) := '        --'||wwv_flow.LF||
'                    -- initiative'||wwv_flow.LF||
'                    --'||wwv_flow.LF||
'                    decode(ap.in';
wwv_flow_imp.g_varchar2_table(52) := 'itiative_id,null,null,('||wwv_flow.LF||
'                        select i.initiative from sp_initiatives i where i.id';
wwv_flow_imp.g_varchar2_table(53) := ' = ap.initiative_id)) initiative,'||wwv_flow.LF||
'                    ap.initiative_id,'||wwv_flow.LF||
'                    --'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(54) := '               (select FRIENDLY_IDENTIFIER '||wwv_flow.LF||
'                        from sp_projects p '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(55) := '           where p.id = ap.project_id and '||wwv_flow.LF||
'                             p.DUPLICATE_OF_PROJECT_ID is';
wwv_flow_imp.g_varchar2_table(56) := ' null and'||wwv_flow.LF||
'                             p.ARCHIVED_YN = ''N'') friendly_identifier'||wwv_flow.LF||
'            from sp_';
wwv_flow_imp.g_varchar2_table(57) := 'activities ap,'||wwv_flow.LF||
'                 sp_activity_types at,'||wwv_flow.LF||
'                 sp_team_members tm'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(58) := '  where '||wwv_flow.LF||
'                  ap.activity_type_id = at.id and'||wwv_flow.LF||
'                  tm.id = l_team_member_i';
wwv_flow_imp.g_varchar2_table(59) := 'd and'||wwv_flow.LF||
'                  ap.team_member_id = tm.id and'||wwv_flow.LF||
'                  trunc(sysdate) <= ap.end_dat';
wwv_flow_imp.g_varchar2_table(60) := 'e and'||wwv_flow.LF||
'                  ap.start_date <= trunc(sysdate)'||wwv_flow.LF||
'                  order by ap.end_date'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(61) := '   ) loop'||wwv_flow.LF||
'            l_row_count := l_row_count + 1;'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            -- determine projec';
wwv_flow_imp.g_varchar2_table(62) := 't link'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            l_project  := apex_escape.html(c1.project);'||wwv_flow.LF||
'            if c1.proj';
wwv_flow_imp.g_varchar2_table(63) := 'ect is not null then '||wwv_flow.LF||
'                if l_link_type = ''APP'' then'||wwv_flow.LF||
'                   l_url := apex_u';
wwv_flow_imp.g_varchar2_table(64) := 'til.prepare_url(''f?p=''||l_app_id||'':3:''||p_apex_session||''::NO:3:FI:''||c1.FRIENDLY_IDENTIFIER);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(65) := '               l_project := ''<a href="''||l_url||''">''||l_project||''</a>'';'||wwv_flow.LF||
'                elsif l_lin';
wwv_flow_imp.g_varchar2_table(66) := 'k_type in (''EMAIL'',''JOB'') then'||wwv_flow.LF||
'                   l_url := apex_page.get_url('||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(67) := '        p_application => l_app_id,'||wwv_flow.LF||
'                              p_page        => 3,'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(68) := '               p_session     => null,'||wwv_flow.LF||
'                              p_items       => ''FI'','||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(69) := '                     p_values      => c1.FRIENDLY_IDENTIFIER,'||wwv_flow.LF||
'                              p_plain_';
wwv_flow_imp.g_varchar2_table(70) := 'url   => TRUE );'||wwv_flow.LF||
'                   if l_link_type = ''EMAIL'' then'||wwv_flow.LF||
'                      l_url := l_a';
wwv_flow_imp.g_varchar2_table(71) := 'pp_prefix_url || l_url; '||wwv_flow.LF||
'                   end if;'||wwv_flow.LF||
'                   l_project := ''<a href="''||l_u';
wwv_flow_imp.g_varchar2_table(72) := 'rl||''">''||l_project||''</a>'';'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(73) := '-- generate HTML for activities'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            if l_row_count = 1 then '||wwv_flow.LF||
'              x2';
wwv_flow_imp.g_varchar2_table(74) := ' := x2||chr(10)||''<h4>Current</h4>''||chr(10)||''<ul>'';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            x2 := x2||''<li';
wwv_flow_imp.g_varchar2_table(75) := '>''||'||wwv_flow.LF||
'                  '' ''||apex_escape.html(c1.TIMELINE)||'||wwv_flow.LF||
'                  '' (<strong>''||apex_esc';
wwv_flow_imp.g_varchar2_table(76) := 'ape.html(c1.activity_type)||''</strong>) - ''||'||wwv_flow.LF||
'                  apex_escape.html(c1.comments);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(77) := '       if c1.project is not null then '||wwv_flow.LF||
'                x2 := x2||''<br>''||nvl(l_project_label,''Projec';
wwv_flow_imp.g_varchar2_table(78) := 't'')||'': ''||l_project;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            if c1.initiative is not null then '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(79) := '     x2 := x2||''<br>''||nvl(l_initiative_label,''Initiative'')||'': ''||apex_escape.html(c1.initiative);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(80) := '            end if;        '||wwv_flow.LF||
'            x2 := x2||''</li>'';'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'        if l_row_count';
wwv_flow_imp.g_varchar2_table(81) := ' > 0 then'||wwv_flow.LF||
'            x2 := x2||chr(10)||''</ul>'';'||wwv_flow.LF||
'            l_activity_count := l_row_count;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(82) := '   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        -- FUTURE'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        l_row_count := 0;'||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(83) := '          select ap.id, '||wwv_flow.LF||
'                   ap.project_id,'||wwv_flow.LF||
'                   --'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(84) := '-- activity core information'||wwv_flow.LF||
'                   --'||wwv_flow.LF||
'                   at.activity_type,'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(85) := '       decode(greatest(length(ap.comments),l_max_text_length),l_max_text_length,ap.comments,substr(a';
wwv_flow_imp.g_varchar2_table(86) := 'p.comments,1,l_max_text_length)||''...'') comments,'||wwv_flow.LF||
'                   --'||wwv_flow.LF||
'                   to_char(a';
wwv_flow_imp.g_varchar2_table(87) := 'p.start_date,''DD-MON-YYYY'')||'' to ''||to_char(ap.end_date,''DD-MON-YYYY'') TIMELINE,'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(88) := ' --'||wwv_flow.LF||
'                   decode(ap.project_id,null,null,('||wwv_flow.LF||
'                       select decode(greates';
wwv_flow_imp.g_varchar2_table(89) := 't(length(p.project),l_max_text_length),l_max_text_length,p.PROJECT,substr(p.project,1,l_max_text_len';
wwv_flow_imp.g_varchar2_table(90) := 'gth)||''...'') project '||wwv_flow.LF||
'                       from sp_projects p '||wwv_flow.LF||
'                       where p.id =';
wwv_flow_imp.g_varchar2_table(91) := ' ap.project_id and '||wwv_flow.LF||
'                             p.DUPLICATE_OF_PROJECT_ID is null and'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(92) := '                p.ARCHIVED_YN = ''N'')'||wwv_flow.LF||
'                       ) project,'||wwv_flow.LF||
'                    --'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(93) := '              -- initiative'||wwv_flow.LF||
'                    --'||wwv_flow.LF||
'                    decode(ap.initiative_id,null,';
wwv_flow_imp.g_varchar2_table(94) := 'null,('||wwv_flow.LF||
'                        select i.initiative from sp_initiatives i where i.id = ap.initiative_';
wwv_flow_imp.g_varchar2_table(95) := 'id)) initiative,'||wwv_flow.LF||
'                    ap.initiative_id,'||wwv_flow.LF||
'                    (select FRIENDLY_IDENTIFI';
wwv_flow_imp.g_varchar2_table(96) := 'ER '||wwv_flow.LF||
'                        from sp_projects p '||wwv_flow.LF||
'                       where p.id = ap.project_id an';
wwv_flow_imp.g_varchar2_table(97) := 'd '||wwv_flow.LF||
'                             p.DUPLICATE_OF_PROJECT_ID is null and'||wwv_flow.LF||
'                             p';
wwv_flow_imp.g_varchar2_table(98) := '.ARCHIVED_YN = ''N'') friendly_identifier'||wwv_flow.LF||
'            from sp_activities ap,'||wwv_flow.LF||
'                 sp_activ';
wwv_flow_imp.g_varchar2_table(99) := 'ity_types at,'||wwv_flow.LF||
'                 sp_team_members tm'||wwv_flow.LF||
'            where '||wwv_flow.LF||
'                  ap.activity_t';
wwv_flow_imp.g_varchar2_table(100) := 'ype_id = at.id and'||wwv_flow.LF||
'                  tm.id = l_team_member_id and'||wwv_flow.LF||
'                  ap.team_member_i';
wwv_flow_imp.g_varchar2_table(101) := 'd = tm.id and'||wwv_flow.LF||
'                  ap.start_date > trunc(sysdate)'||wwv_flow.LF||
'            order by ap.end_date'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(102) := '    ) loop'||wwv_flow.LF||
'            l_row_count := l_row_count + 1;'||wwv_flow.LF||
'           '||wwv_flow.LF||
'            if l_row_count = 1 th';
wwv_flow_imp.g_varchar2_table(103) := 'en   '||wwv_flow.LF||
'               x3 := x3||''<h4>Future</h4><ul>'';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'            --'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(104) := '  -- determine project link'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            l_project  := apex_escape.html(c1.project);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(105) := '           if c1.project is not null then '||wwv_flow.LF||
'                if l_link_type = ''APP'' then'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(106) := '      l_url := apex_util.prepare_url(''f?p=''||l_app_id||'':3:''||p_apex_session||''::NO:3:FI:''||c1.FRIEN';
wwv_flow_imp.g_varchar2_table(107) := 'DLY_IDENTIFIER);'||wwv_flow.LF||
'                   l_project := ''<a href="''||l_url||''">''||l_project||''</a>'';'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(108) := '          elsif l_link_type in (''EMAIL'',''JOB'') then'||wwv_flow.LF||
'                   l_url := apex_page.get_url('||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(109) := '                             p_application => l_app_id,'||wwv_flow.LF||
'                              p_page        ';
wwv_flow_imp.g_varchar2_table(110) := '=> 3,'||wwv_flow.LF||
'                              p_session     => null,'||wwv_flow.LF||
'                              p_items    ';
wwv_flow_imp.g_varchar2_table(111) := '   => ''FI'','||wwv_flow.LF||
'                              p_values      => c1.FRIENDLY_IDENTIFIER,'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(112) := '             p_plain_url   => TRUE );'||wwv_flow.LF||
'                   if l_link_type = ''EMAIL'' then'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(113) := '         l_url := l_app_prefix_url || l_url; '||wwv_flow.LF||
'                   end if;'||wwv_flow.LF||
'                   l_projec';
wwv_flow_imp.g_varchar2_table(114) := 't := ''<a href="''||l_url||''">''||l_project||''</a>'';'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(115) := '       x3 := x3||''<li>''||'||wwv_flow.LF||
'                  '' ''||apex_escape.html(c1.TIMELINE)||'||wwv_flow.LF||
'                  ''';
wwv_flow_imp.g_varchar2_table(116) := ' (<strong>''||apex_escape.html(c1.activity_type)||''</strong>) - ''||'||wwv_flow.LF||
'                  apex_escape.htm';
wwv_flow_imp.g_varchar2_table(117) := 'l(c1.comments);'||wwv_flow.LF||
'            if c1.project is not null then '||wwv_flow.LF||
'               x3 := x3||''<br>''||nvl(l_p';
wwv_flow_imp.g_varchar2_table(118) := 'roject_label,''Project'')||'': ''||l_project;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            if c1.initiative is not nu';
wwv_flow_imp.g_varchar2_table(119) := 'll then '||wwv_flow.LF||
'               x3 := x3||''<br>''||nvl(l_initiative_label,''Initiative'')||'': ''||apex_escape.ht';
wwv_flow_imp.g_varchar2_table(120) := 'ml(c1.initiative);'||wwv_flow.LF||
'            end if;    '||wwv_flow.LF||
'            x3 := x3||''</li>'';'||wwv_flow.LF||
'           '||wwv_flow.LF||
'        end lo';
wwv_flow_imp.g_varchar2_table(121) := 'op;'||wwv_flow.LF||
''||wwv_flow.LF||
'        if l_row_count > 0 then '||wwv_flow.LF||
'           x3 := x3||''</ul>'';'||wwv_flow.LF||
'           l_activity_count := l';
wwv_flow_imp.g_varchar2_table(122) := '_activity_count + l_row_count;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        -- LAST WEEK'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        l';
wwv_flow_imp.g_varchar2_table(123) := '_row_count := 0;'||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            select ap.id, '||wwv_flow.LF||
'                   ap.project_id,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(124) := '                 --'||wwv_flow.LF||
'                   -- activity core information'||wwv_flow.LF||
'                   --'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(125) := '         at.activity_type,'||wwv_flow.LF||
'                   decode(greatest(length(ap.comments),l_max_text_length)';
wwv_flow_imp.g_varchar2_table(126) := ',l_max_text_length,ap.comments,substr(ap.comments,1,l_max_text_length)||''...'') comments,'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(127) := '        --'||wwv_flow.LF||
'                   to_char(ap.start_date,''DD-MON-YYYY'')||'' to ''||to_char(ap.end_date,''DD-';
wwv_flow_imp.g_varchar2_table(128) := 'MON-YYYY'') TIMELINE,'||wwv_flow.LF||
'                   --'||wwv_flow.LF||
'                   decode(ap.project_id,null,null,('||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(129) := '                     select decode(greatest(length(p.project),l_max_text_length),l_max_text_length,p';
wwv_flow_imp.g_varchar2_table(130) := '.PROJECT,substr(p.project,1,l_max_text_length)||''...'') project '||wwv_flow.LF||
'                            from sp_';
wwv_flow_imp.g_varchar2_table(131) := 'projects p '||wwv_flow.LF||
'                           where p.id = ap.project_id and '||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(132) := '    p.DUPLICATE_OF_PROJECT_ID is null and'||wwv_flow.LF||
'                                 p.ARCHIVED_YN = ''N'')'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(133) := '                      ) project,'||wwv_flow.LF||
'                    --'||wwv_flow.LF||
'                    -- initiative'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(134) := '          --'||wwv_flow.LF||
'                    decode(ap.initiative_id,null,null,('||wwv_flow.LF||
'                           sele';
wwv_flow_imp.g_varchar2_table(135) := 'ct i.initiative from sp_initiatives i where i.id = ap.initiative_id)) initiative,'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(136) := '  ap.initiative_id'||wwv_flow.LF||
'            from sp_activities ap,'||wwv_flow.LF||
'                 sp_activity_types at,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(137) := '          sp_team_members tm'||wwv_flow.LF||
'            where '||wwv_flow.LF||
'                  ap.activity_type_id = at.id and'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(138) := '                tm.id = l_team_member_id and'||wwv_flow.LF||
'                  ap.team_member_id = tm.id and'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(139) := '           ap.end_date > trunc(sysdate) - 7 and'||wwv_flow.LF||
'                  ap.end_date < trunc(sysdate)'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(140) := '       order by ap.end_date '||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            l_row_count := l_row_count + 1;'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(141) := 'if l_row_count = 1 then '||wwv_flow.LF||
'               x3 := x3||''<h4>Last week</h4>''||chr(10)||''<ul>'';'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(142) := ' end if;'||wwv_flow.LF||
'            x3 := x3||chr(10)||''<li>''||'||wwv_flow.LF||
'                 '' ''||apex_escape.html(c1.TIMELINE)';
wwv_flow_imp.g_varchar2_table(143) := '||'||wwv_flow.LF||
'                 '' (<strong>''||apex_escape.html(c1.activity_type)||''</strong>) - ''||'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(144) := '     apex_escape.html(c1.comments);'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            if c1.project is not null then '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(145) := '          x3 := x3||''<br>''||nvl(l_project_label,''Project'')||'': ''||apex_escape.html(c1.project);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(146) := '        end if;'||wwv_flow.LF||
'            if c1.initiative is not null then '||wwv_flow.LF||
'               x3 := x3||''<br>''||nvl(';
wwv_flow_imp.g_varchar2_table(147) := 'l_initiative_label,''Initiative'')||'': ''||apex_escape.html(c1.initiative);'||wwv_flow.LF||
'            end if;    '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(148) := '         x3 := x3||''</li>'';'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        if l_row_count > 0 then '||wwv_flow.LF||
'           x3 := x3||';
wwv_flow_imp.g_varchar2_table(149) := '''</ul>''||chr(10);'||wwv_flow.LF||
'           l_activity_count := l_activity_count + l_row_count;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(150) := '     -- end of activity reporting'||wwv_flow.LF||
'        x3 := x3||chr(10);'||wwv_flow.LF||
''||wwv_flow.LF||
'        x3 := x3||''<p><i>Activities li';
wwv_flow_imp.g_varchar2_table(151) := 'sted include activities for the past week, current and future planned.</i></p>'';'||wwv_flow.LF||
''||wwv_flow.LF||
'        if l_activ';
wwv_flow_imp.g_varchar2_table(152) := 'ity_count = 0 then'||wwv_flow.LF||
'           x3 := x3||''<p>No Activities found.</p>'';'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(153) := '     '||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --  ###############################################################'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- ';
wwv_flow_imp.g_varchar2_table(154) := 'P R O J E C T S'||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    if p_show_projects = ''Y'' then'||wwv_flow.LF||
'        l_row_count := 0;'||wwv_flow.LF||
'        x4 := ''<';
wwv_flow_imp.g_varchar2_table(155) := 'h3>''||apex_escape.html(nvl(l_projects_label,''Projects'')) ||''</h3>'';'||wwv_flow.LF||
'        x4 := x4||''<i>Only above';
wwv_flow_imp.g_varchar2_table(156) := ' 20% complete are included.</i>'';'||wwv_flow.LF||
'        l_row_count := 0;'||wwv_flow.LF||
'        l_release_count := 0;'||wwv_flow.LF||
''||wwv_flow.LF||
'        f';
wwv_flow_imp.g_varchar2_table(157) := 'or c1 in ('||wwv_flow.LF||
'            select case when p.release_id is not null then 1 '||wwv_flow.LF||
'                        whe';
wwv_flow_imp.g_varchar2_table(158) := 'n p.target_complete is null then 3'||wwv_flow.LF||
'                        else 2 end sort_order_1,'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(159) := '   case when p.target_complete is null and p.release_id is not null'||wwv_flow.LF||
'                        then (se';
wwv_flow_imp.g_varchar2_table(160) := 'lect release_target_date from sp_release_trains where id = p.release_id)'||wwv_flow.LF||
'                        els';
wwv_flow_imp.g_varchar2_table(161) := 'e p.target_complete end sort_order_2,'||wwv_flow.LF||
'                   pp.priority sort_order_3,'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(162) := '  case when p.release_id is not null '||wwv_flow.LF||
'                             then (select release_train||'': ''|';
wwv_flow_imp.g_varchar2_table(163) := '|release from SP_RELEASE_TRAINS t where t.id = p.release_id)'||wwv_flow.LF||
'                        when p.target_c';
wwv_flow_imp.g_varchar2_table(164) := 'omplete is null'||wwv_flow.LF||
'                        then ''No Target'''||wwv_flow.LF||
'                        else to_char(p.targ';
wwv_flow_imp.g_varchar2_table(165) := 'et_complete,''Mon-YYYY'')'||wwv_flow.LF||
'                        end heading,'||wwv_flow.LF||
'                   p.project, '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(166) := '           p.pct_complete, '||wwv_flow.LF||
'                   p.project_size,'||wwv_flow.LF||
'                   pp.priority,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(167) := '              p.id project_id,'||wwv_flow.LF||
'                   p.FRIENDLY_IDENTIFIER,'||wwv_flow.LF||
'                   p.owner_';
wwv_flow_imp.g_varchar2_table(168) := 'id,'||wwv_flow.LF||
'                   (select count(*) cnt'||wwv_flow.LF||
'                      from sp_tasks t,'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(169) := '          sp_task_types tt'||wwv_flow.LF||
'                     where t.owner_id = l_team_member_id '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(170) := '        and t.project_id = p.id'||wwv_flow.LF||
'                       and t.task_type_id = tt.id'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(171) := '     and tt.static_id like ''REVIEW%'') review_cnt,'||wwv_flow.LF||
'                   (select count(*) cnt'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(172) := '            from sp_tasks t,'||wwv_flow.LF||
'                           sp_task_types tt'||wwv_flow.LF||
'                     where ';
wwv_flow_imp.g_varchar2_table(173) := 't.owner_id = l_team_member_id '||wwv_flow.LF||
'                       and t.project_id = p.id'||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(174) := ' and t.task_type_id = tt.id'||wwv_flow.LF||
'                       and tt.static_id like ''MILESTONE%'') milestone_cnt';
wwv_flow_imp.g_varchar2_table(175) := ','||wwv_flow.LF||
'                   (select count(*) cnt'||wwv_flow.LF||
'                      from sp_tasks t,'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(176) := '        sp_task_types tt'||wwv_flow.LF||
'                     where t.owner_id = l_team_member_id '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(177) := '      and t.project_id = p.id'||wwv_flow.LF||
'                       and t.task_type_id = tt.id'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(178) := '   and tt.static_id not like ''REVIEW%'''||wwv_flow.LF||
'                       and tt.static_id not like ''MILESTONE%''';
wwv_flow_imp.g_varchar2_table(179) := ') other_task_cnt'||wwv_flow.LF||
'              from sp_projects p, '||wwv_flow.LF||
'                   SP_PROJECT_PRIORITIES pp'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(180) := '         where p.priority_id = pp.id and '||wwv_flow.LF||
'                   p.pct_complete > 20 and'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(181) := '    p.pct_complete != 100 and'||wwv_flow.LF||
'                   p.ARCHIVED_YN = ''N'' and'||wwv_flow.LF||
'                   p.DUPLIC';
wwv_flow_imp.g_varchar2_table(182) := 'ATE_OF_PROJECT_ID is null and '||wwv_flow.LF||
'                   ('||wwv_flow.LF||
'                      p.release_id is null or '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(183) := '                      p.release_id in (select t.id from SP_RELEASE_TRAINS t where nvl(t.RELEASE_OPEN';
wwv_flow_imp.g_varchar2_table(184) := '_COMPLETED,''Y'') = ''Y'' and nvl(RELEASE_COMPLETED,''N'') = ''N'')'||wwv_flow.LF||
'                   ) and'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(185) := '    (p.owner_id = l_team_member_id or '||wwv_flow.LF||
'                    exists (select 1'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(186) := '      from sp_tasks'||wwv_flow.LF||
'                             where owner_id = l_team_member_id '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(187) := '               and project_id = p.id) or '||wwv_flow.LF||
'                    exists (select 1'||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(188) := '         from sp_project_contributors'||wwv_flow.LF||
'                             where team_member_id = l_team_mem';
wwv_flow_imp.g_varchar2_table(189) := 'ber_id '||wwv_flow.LF||
'                               and project_id = p.id) )'||wwv_flow.LF||
'            order by 1, 2, 3 asc, 4'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(190) := '        ) loop'||wwv_flow.LF||
'            l_row_count := l_row_count + 1;'||wwv_flow.LF||
'            l_project := apex_escape.html';
wwv_flow_imp.g_varchar2_table(191) := '(c1.project);'||wwv_flow.LF||
'            -- broken out to avoid bulk bind error'||wwv_flow.LF||
'            if c1.owner_id = l_team';
wwv_flow_imp.g_varchar2_table(192) := '_member_id then l_role := ''Owner'';'||wwv_flow.LF||
'            elsif c1.review_cnt > 0 then l_role := ''Reviewer'';'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(193) := '          elsif c1.milestone_cnt > 0 then l_role := ''Milestone Owner'';'||wwv_flow.LF||
'            elsif c1.other_ta';
wwv_flow_imp.g_varchar2_table(194) := 'sk_cnt > 0 then l_role := ''Task Owner'';'||wwv_flow.LF||
'            else select listagg(rt.resource_type, '', '') with';
wwv_flow_imp.g_varchar2_table(195) := 'in group (order by rt.resource_type)'||wwv_flow.LF||
'                   into l_role'||wwv_flow.LF||
'                   from sp_proje';
wwv_flow_imp.g_varchar2_table(196) := 'ct_contributors c,'||wwv_flow.LF||
'                        sp_resource_types rt'||wwv_flow.LF||
'                  where c.project_id';
wwv_flow_imp.g_varchar2_table(197) := ' = c1.project_id'||wwv_flow.LF||
'                    and c.team_member_id = l_team_member_id'||wwv_flow.LF||
'                    and';
wwv_flow_imp.g_varchar2_table(198) := ' c.responsibility_id = rt.id;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            if l_link_type = ''APP'' then'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(199) := '     l_url := apex_util.prepare_url(''f?p=''||l_app_id||'':3:''||p_apex_session||''::NO:3:FI:''||c1.FRIEND';
wwv_flow_imp.g_varchar2_table(200) := 'LY_IDENTIFIER);'||wwv_flow.LF||
'               l_project := ''<a href="''||l_url||''">''||l_project||''</a>'';'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(201) := ' elsif l_link_type in (''EMAIL'',''JOB'') then'||wwv_flow.LF||
'               l_url := apex_page.get_url('||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(202) := '            p_application => l_app_id,'||wwv_flow.LF||
'                          p_page        => 3,'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(203) := '           p_session     => null,'||wwv_flow.LF||
'                          p_items       => ''FI'','||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(204) := '         p_values      => c1.FRIENDLY_IDENTIFIER,'||wwv_flow.LF||
'                          p_plain_url   => TRUE );';
wwv_flow_imp.g_varchar2_table(205) := ''||wwv_flow.LF||
'               if l_link_type = ''EMAIL'' then'||wwv_flow.LF||
'                  l_url := l_app_prefix_url || l_url; ';
wwv_flow_imp.g_varchar2_table(206) := ''||wwv_flow.LF||
'               end if;'||wwv_flow.LF||
'               l_project := ''<a href="''||l_url||''">''||l_project||''</a>'';'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(207) := '         end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'            if c1.heading != l_last_heading or l_last_heading is null then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(208) := '         if l_row_count > 1 then'||wwv_flow.LF||
'                   x4 := x4||''</ul>'';'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(209) := '           x4 := x4||''<h4>''||apex_escape.html(c1.heading)||''</h4>'';'||wwv_flow.LF||
'                x4 := x4||''<ul>''';
wwv_flow_imp.g_varchar2_table(210) := ';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            x4 := x4||''<li> ''||l_project||'||wwv_flow.LF||
'                      '' (<strong>''|';
wwv_flow_imp.g_varchar2_table(211) := '|apex_escape.html(l_role)||''</strong>) - ''||'||wwv_flow.LF||
'                      to_char(c1.pct_complete)||''% ''||a';
wwv_flow_imp.g_varchar2_table(212) := 'pex_escape.html(c1.project_size)||'' ''||  '||wwv_flow.LF||
'                      ''P''||to_char(c1.priority)||''</li>'';'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(213) := '            l_last_heading := c1.heading;'||wwv_flow.LF||
''||wwv_flow.LF||
'            if p_links in (''EMAIL'',''JOB'') and l_row_count';
wwv_flow_imp.g_varchar2_table(214) := ' = l_project_max_count then'||wwv_flow.LF||
'               x4 := x4||''View more in application...'';'||wwv_flow.LF||
'               e';
wwv_flow_imp.g_varchar2_table(215) := 'xit;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'       '||wwv_flow.LF||
'         end loop;'||wwv_flow.LF||
'         if l_row_count = 0 then'||wwv_flow.LF||
'            -- ';
wwv_flow_imp.g_varchar2_table(216) := 'x4 := x4||''</ul>'';'||wwv_flow.LF||
'            x4 := x4||''No ''||l_projects_label||'' found'';'||wwv_flow.LF||
'         else'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(217) := '  x4 := x4||''</ul>'';'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'         --'||wwv_flow.LF||
'         -- APPROVALS'||wwv_flow.LF||
'         --'||wwv_flow.LF||
'         if p_';
wwv_flow_imp.g_varchar2_table(218) := 'show_approvals = ''Y'' then'||wwv_flow.LF||
'             l_row_count := 0;'||wwv_flow.LF||
'             x5 := ''<h3>''||apex_escape.html';
wwv_flow_imp.g_varchar2_table(219) := '(nvl(l_project_label,''Project'')) ||'' Approvals</h3> <ul>'';'||wwv_flow.LF||
'             for c1 in ('||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(220) := ' select p.project, p.friendly_identifier, '||wwv_flow.LF||
'                        t.approval_type,'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(221) := '        case when a.submitted_by_team_member_id = p_team_member_id'||wwv_flow.LF||
'                             then';
wwv_flow_imp.g_varchar2_table(222) := ' ''Submitter'''||wwv_flow.LF||
'                             else  (select case when status = ''PENDING'' then ''Pending R';
wwv_flow_imp.g_varchar2_table(223) := 'eview'''||wwv_flow.LF||
'                                                else initcap(replace(status,''-'','' ''))'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(224) := '                                         end'||wwv_flow.LF||
'                                      from'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(225) := '                           (select status,'||wwv_flow.LF||
'                                               updated,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(226) := '                                              max(updated) over (partition by team_member_id) last_u';
wwv_flow_imp.g_varchar2_table(227) := 'pdated'||wwv_flow.LF||
'                                          from sp_project_approval_chain'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(228) := '                     where project_approval_id = a.id'||wwv_flow.LF||
'                                           and';
wwv_flow_imp.g_varchar2_table(229) := ' team_member_id = p_team_member_id)'||wwv_flow.LF||
'                                     where last_updated = update';
wwv_flow_imp.g_varchar2_table(230) := 'd)'||wwv_flow.LF||
'                             end role,'||wwv_flow.LF||
'                        initcap(replace(a.status,''-'','' ''))';
wwv_flow_imp.g_varchar2_table(231) := ' current_status'||wwv_flow.LF||
'                   from sp_projects p, '||wwv_flow.LF||
'                        sp_project_approvals';
wwv_flow_imp.g_varchar2_table(232) := ' a,'||wwv_flow.LF||
'                        sp_approval_types t'||wwv_flow.LF||
'                  where p.id = a.project_id'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(233) := '            and p.ARCHIVED_YN = ''N'''||wwv_flow.LF||
'                    and p.DUPLICATE_OF_PROJECT_ID is null'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(234) := '              and a.approval_type_id = t.id'||wwv_flow.LF||
'                    and ( (a.submitted_by_team_member_id';
wwv_flow_imp.g_varchar2_table(235) := ' = p_team_member_id and'||wwv_flow.LF||
'                           a.submitted between l_date_from and l_date_to)'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(236) := '                        or'||wwv_flow.LF||
'                          exists (select 1 from sp_project_approval_chain';
wwv_flow_imp.g_varchar2_table(237) := ''||wwv_flow.LF||
'                                   where project_approval_id = a.id'||wwv_flow.LF||
'                               ';
wwv_flow_imp.g_varchar2_table(238) := '      and team_member_id = p_team_member_id'||wwv_flow.LF||
'                                     and updated between';
wwv_flow_imp.g_varchar2_table(239) := ' l_date_from and l_date_to) )'||wwv_flow.LF||
'                  order by p.project, t.approval_type'||wwv_flow.LF||
'            ) lo';
wwv_flow_imp.g_varchar2_table(240) := 'op'||wwv_flow.LF||
'                l_row_count := l_row_count + 1;'||wwv_flow.LF||
'                l_project := apex_escape.html(c1.';
wwv_flow_imp.g_varchar2_table(241) := 'project);'||wwv_flow.LF||
'                if l_link_type = ''APP'' then'||wwv_flow.LF||
'                   l_url := apex_util.prepare_';
wwv_flow_imp.g_varchar2_table(242) := 'url(''f?p=''||l_app_id||'':3:''||p_apex_session||''::NO:3:FI:''||c1.friendly_identifier);'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(243) := '   l_project := ''<a href="''||l_url||''">''||l_project||''</a>'';'||wwv_flow.LF||
'                elsif l_Link_type in (''';
wwv_flow_imp.g_varchar2_table(244) := 'EMAIL'',''JOB'') then'||wwv_flow.LF||
'                   l_url := apex_page.get_url('||wwv_flow.LF||
'                         p_applica';
wwv_flow_imp.g_varchar2_table(245) := 'tion => l_app_id,'||wwv_flow.LF||
'                         p_page        => 3,'||wwv_flow.LF||
'                         p_session   ';
wwv_flow_imp.g_varchar2_table(246) := '  => null,'||wwv_flow.LF||
'                         p_items       => ''FI'','||wwv_flow.LF||
'                         p_values      =>';
wwv_flow_imp.g_varchar2_table(247) := ' c1.FRIENDLY_IDENTIFIER,'||wwv_flow.LF||
'                         p_plain_url   => TRUE );'||wwv_flow.LF||
'                   if l_l';
wwv_flow_imp.g_varchar2_table(248) := 'ink_type = ''EMAIL'' then'||wwv_flow.LF||
'                      l_url := l_app_prefix_url || l_url; '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(249) := '  end if;'||wwv_flow.LF||
'                   l_project := ''<a href="''||l_url||''">''||l_project||''</a>'';'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(250) := '   end if;'||wwv_flow.LF||
'                x5 := x5||''<li>''||l_project||'' - ''||apex_escape.html(c1.approval_type)||''';
wwv_flow_imp.g_varchar2_table(251) := ' - ''||apex_escape.html(c1.role);'||wwv_flow.LF||
'                x5 := x5||'' (Current Status: ''||apex_escape.html(c1';
wwv_flow_imp.g_varchar2_table(252) := '.current_status)||'')''; '||wwv_flow.LF||
'                x5 := x5||''</li>'';'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'            x5 := x';
wwv_flow_imp.g_varchar2_table(253) := '5||''</ul>'';'||wwv_flow.LF||
'            if l_row_count = 0 then'||wwv_flow.LF||
'               x5 := x5||''No Approvals found'';'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(254) := '       end if;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'         --'||wwv_flow.LF||
'         -- PROJECTS COMMENTED'||wwv_flow.LF||
'         --'||wwv_flow.LF||
'         l_r';
wwv_flow_imp.g_varchar2_table(255) := 'ow_count := 0;'||wwv_flow.LF||
'         x6 := ''<h3>''||apex_escape.html(nvl(l_projects_label,''Projects'')) ||'' Comment';
wwv_flow_imp.g_varchar2_table(256) := 'ed On''||''</h3> <ul>'';'||wwv_flow.LF||
'         for c1 in ('||wwv_flow.LF||
'             select p.project, max(p.friendly_identifier)';
wwv_flow_imp.g_varchar2_table(257) := ' friendly_identifier, min(c.created) min_created, max(c.created) max_created, Count(*) comments'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(258) := '           from sp_projects p, '||wwv_flow.LF||
'                    sp_project_comments c'||wwv_flow.LF||
'              where lower(';
wwv_flow_imp.g_varchar2_table(259) := 'c.created_by) = l_lower_app_user and '||wwv_flow.LF||
'                    p.id = c.project_id and'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(260) := '  c.created between l_date_from and l_date_to and'||wwv_flow.LF||
'                    p.ARCHIVED_YN = ''N'' and'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(261) := '              p.DUPLICATE_OF_PROJECT_ID is null'||wwv_flow.LF||
'              group by p.project'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(262) := '        l_row_count := l_row_count + 1;'||wwv_flow.LF||
'            l_project := apex_escape.html(c1.project);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(263) := '       if l_link_type = ''APP'' then'||wwv_flow.LF||
'               l_url := apex_util.prepare_url(''f?p=''||l_app_id||''';
wwv_flow_imp.g_varchar2_table(264) := ':3:''||p_apex_session||''::NO:3:FI:''||c1.friendly_identifier);'||wwv_flow.LF||
'               l_project := ''<a href="''';
wwv_flow_imp.g_varchar2_table(265) := '||l_url||''">''||l_project||''</a>'';'||wwv_flow.LF||
'            elsif l_Link_type in (''EMAIL'',''JOB'') then'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(266) := '   l_url := apex_page.get_url('||wwv_flow.LF||
'                     p_application => l_app_id,'||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(267) := 'p_page        => 3,'||wwv_flow.LF||
'                     p_session     => null,'||wwv_flow.LF||
'                     p_items       =';
wwv_flow_imp.g_varchar2_table(268) := '> ''FI'','||wwv_flow.LF||
'                     p_values      => c1.FRIENDLY_IDENTIFIER,'||wwv_flow.LF||
'                     p_plain_u';
wwv_flow_imp.g_varchar2_table(269) := 'rl   => TRUE );'||wwv_flow.LF||
'               if l_link_type = ''EMAIL'' then'||wwv_flow.LF||
'                  l_url := l_app_prefix';
wwv_flow_imp.g_varchar2_table(270) := '_url || l_url; '||wwv_flow.LF||
'               end if;'||wwv_flow.LF||
'               l_project := ''<a href="''||l_url||''">''||l_proje';
wwv_flow_imp.g_varchar2_table(271) := 'ct||''</a>'';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            x6 := x6||''<li>''||l_project||'' - ''||to_char(c1.min_creat';
wwv_flow_imp.g_varchar2_table(272) := 'ed,l_day_fm);'||wwv_flow.LF||
'            if c1.comments > 1 then '||wwv_flow.LF||
'                if trunc(c1.min_created) != trunc';
wwv_flow_imp.g_varchar2_table(273) := '(c1.max_created) then'||wwv_flow.LF||
'                   x6 := x6||'' to ''||to_char(c1.max_created,l_day_fm);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(274) := '         end if;'||wwv_flow.LF||
'                x6 := x6||'' (''||apex_escape.html(c1.comments)||'' comments)''; '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(275) := '       end if;'||wwv_flow.LF||
'            x6 := x6||''</li>'';'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        x6 := x6||''</ul>'';'||wwv_flow.LF||
'        i';
wwv_flow_imp.g_varchar2_table(276) := 'f l_row_count = 0 then'||wwv_flow.LF||
'           x6 := x6||''No ''||l_projects_label||'' found'';'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(277) := '     --'||wwv_flow.LF||
'        -- PROJECTS ADDED'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        l_row_count := 0;'||wwv_flow.LF||
'        x7 := ''<h3>''||apex_es';
wwv_flow_imp.g_varchar2_table(278) := 'cape.html(nvl(l_projects_label,''Projects'')) ||'' Created''||''</h3> <ul>'';'||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(279) := '    select p.project, p.FRIENDLY_IDENTIFIER, to_char(p.created,l_day_fm) created'||wwv_flow.LF||
'              from ';
wwv_flow_imp.g_varchar2_table(280) := 'sp_projects p'||wwv_flow.LF||
'             where lower(p.created_by) = l_lower_app_user and '||wwv_flow.LF||
'                   p.cr';
wwv_flow_imp.g_varchar2_table(281) := 'eated between l_date_from and l_date_to and'||wwv_flow.LF||
'                   p.ARCHIVED_YN = ''N'' and'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(282) := '      p.DUPLICATE_OF_PROJECT_ID is null'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            l_row_count := l_row_count + 1;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(283) := '           l_project := apex_escape.html(c1.project);'||wwv_flow.LF||
'            if l_link_type = ''APP'' then'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(284) := '         l_url := apex_util.prepare_url(''f?p=''||l_app_id||'':3:''||p_apex_session||''::NO:3:FI:''||c1.fr';
wwv_flow_imp.g_varchar2_table(285) := 'iendly_identifier);'||wwv_flow.LF||
'               l_project := ''<a href="''||l_url||''">''||l_project||''</a>'';'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(286) := '     elsif l_Link_type in (''EMAIL'',''JOB'') then'||wwv_flow.LF||
'               l_url := apex_page.get_url('||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(287) := '           p_application => l_app_id,'||wwv_flow.LF||
'                     p_page        => 3,'||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(288) := 'p_session     => null,'||wwv_flow.LF||
'                     p_items       => ''FI'','||wwv_flow.LF||
'                     p_values    ';
wwv_flow_imp.g_varchar2_table(289) := '  => c1.FRIENDLY_IDENTIFIER,'||wwv_flow.LF||
'                     p_plain_url   => TRUE );'||wwv_flow.LF||
'               if l_link_';
wwv_flow_imp.g_varchar2_table(290) := 'type = ''EMAIL'' then'||wwv_flow.LF||
'                  l_url := l_app_prefix_url || l_url; '||wwv_flow.LF||
'               end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(291) := '             l_project := ''<a href="''||l_url||''">''||l_project||''</a>'';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(292) := '   x7 := x7||''<li>''||l_project||'' - ''||c1.created||'' </li>'';'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        x7 := x7||''</';
wwv_flow_imp.g_varchar2_table(293) := 'ul>'';'||wwv_flow.LF||
'        if l_row_count = 0 then'||wwv_flow.LF||
'           x7 := x7||''No ''||l_projects_label||'' found'';'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(294) := '  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- END CHECKING P_SHOW_PROJECTS'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_show_activities = ''Y'' then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(295) := '   sys.dbms_lob.append(x, x2);'||wwv_flow.LF||
'       sys.dbms_lob.append(x, x3);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if p_show_projects';
wwv_flow_imp.g_varchar2_table(296) := ' = ''Y'' then'||wwv_flow.LF||
'       sys.dbms_lob.append(x, x4);'||wwv_flow.LF||
'       if p_show_approvals = ''Y'' then'||wwv_flow.LF||
'           sys.';
wwv_flow_imp.g_varchar2_table(297) := 'dbms_lob.append(x, x5);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       sys.dbms_lob.append(x, x6);'||wwv_flow.LF||
'       sys.dbms_lob.append';
wwv_flow_imp.g_varchar2_table(298) := '(x, x7);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    return x;'||wwv_flow.LF||
''||wwv_flow.LF||
'end generate;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function project_exceptions ('||wwv_flow.LF||
'    p_team_member_';
wwv_flow_imp.g_varchar2_table(299) := 'id     in number,'||wwv_flow.LF||
'    p_links              in varchar2 default ''NONE'','||wwv_flow.LF||
'    p_include_title_yn   in v';
wwv_flow_imp.g_varchar2_table(300) := 'archar2 default ''Y'','||wwv_flow.LF||
'    p_apex_session       in varchar2 default null )'||wwv_flow.LF||
'    return clob'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_he';
wwv_flow_imp.g_varchar2_table(301) := 'ader               clob := null;'||wwv_flow.LF||
'    l_proj_content         clob := null;'||wwv_flow.LF||
'    x                     ';
wwv_flow_imp.g_varchar2_table(302) := ' clob := null;'||wwv_flow.LF||
'    l_person               varchar2(255);'||wwv_flow.LF||
'    l_email                varchar2(255);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(303) := '   l_team_member_id       number;'||wwv_flow.LF||
'    l_link_type            varchar2(30);'||wwv_flow.LF||
'    l_project_label      ';
wwv_flow_imp.g_varchar2_table(304) := '  varchar2(255);'||wwv_flow.LF||
'    l_exceptions_yn        varchar2(1) := ''N'';'||wwv_flow.LF||
'    l_reviews_yn           varchar2(';
wwv_flow_imp.g_varchar2_table(305) := '1);'||wwv_flow.LF||
'    l_approvals_yn         varchar2(1);'||wwv_flow.LF||
'    l_proj_except_count    int := 0;'||wwv_flow.LF||
'    l_project_max_c';
wwv_flow_imp.g_varchar2_table(306) := 'ount    int := 20;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- support for links'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    l_project              varchar2(4000);';
wwv_flow_imp.g_varchar2_table(307) := ''||wwv_flow.LF||
'    l_role                 varchar2(4000);'||wwv_flow.LF||
'    l_url                  varchar2(4000);'||wwv_flow.LF||
'    l_app_id ';
wwv_flow_imp.g_varchar2_table(308) := '              varchar2(4000);'||wwv_flow.LF||
'    l_app_prefix_url       varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- get set';
wwv_flow_imp.g_varchar2_table(309) := 'tings'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    l_project_label     := sp_util.get_nomenclature(''PROJECT'');'||wwv_flow.LF||
'    l_app_id           ';
wwv_flow_imp.g_varchar2_table(310) := ' := sp_util.get_setting(''APP_ID'');'||wwv_flow.LF||
'    l_app_prefix_url    := sp_util.get_setting(''APP_PREFIX_URL'');';
wwv_flow_imp.g_varchar2_table(311) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'    if apex_util.get_build_option_status ('||wwv_flow.LF||
'           p_application_id    => l_app_id,'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(312) := 'p_build_option_name => ''Reviews'') = ''INCLUDE'''||wwv_flow.LF||
'    then'||wwv_flow.LF||
'         l_reviews_yn := ''Y'';'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(313) := '   l_reviews_yn := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if apex_util.get_build_option_status ('||wwv_flow.LF||
'           p_applica';
wwv_flow_imp.g_varchar2_table(314) := 'tion_id    => l_app_id,'||wwv_flow.LF||
'           p_build_option_name => ''Approvals'') = ''INCLUDE'''||wwv_flow.LF||
'    then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(315) := ' l_approvals_yn := ''Y'';'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'         l_approvals_yn := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- determin';
wwv_flow_imp.g_varchar2_table(316) := 'e link type'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- APP: generate links from within the current app requires p_apex_session'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(317) := '  -- EMAIL: generate fully qualified links'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if p_links = ''APP'' and p_apex_session is not n';
wwv_flow_imp.g_varchar2_table(318) := 'ull and l_app_id is not null then'||wwv_flow.LF||
'       l_link_type := ''APP'';'||wwv_flow.LF||
'    elsif p_links = ''EMAIL'' and l_app';
wwv_flow_imp.g_varchar2_table(319) := '_id is not null then'||wwv_flow.LF||
'       l_link_type := ''EMAIL'';'||wwv_flow.LF||
'    elsif p_links = ''JOB'' and l_app_id is not nu';
wwv_flow_imp.g_varchar2_table(320) := 'll then'||wwv_flow.LF||
'       l_link_type := ''JOB'';'||wwv_flow.LF||
'    elsif p_links is null then'||wwv_flow.LF||
'       l_link_type := ''NONE'';'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(321) := '  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- name'||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select first_Name||'' ''||last_name name';
wwv_flow_imp.g_varchar2_table(322) := ', email, id '||wwv_flow.LF||
'          from sp_team_members tm '||wwv_flow.LF||
'         where id = p_team_member_id'||wwv_flow.LF||
'    ) loop '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(323) := '     l_person := apex_escape.html(c1.name);'||wwv_flow.LF||
'        l_email  := lower(apex_escape.html(c1.email));'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(324) := '       l_team_member_id := c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- heading'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if p_include_title';
wwv_flow_imp.g_varchar2_table(325) := '_yn = ''Y'' then'||wwv_flow.LF||
'       l_header := ''<h3>''||nvl(l_project_label,''Project'')||'' Exception report for ''||';
wwv_flow_imp.g_varchar2_table(326) := 'l_person||''</h3>''||chr(10);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    if l_link_type != ''APP'' then'||wwv_flow.LF||
'        l_header := l_';
wwv_flow_imp.g_varchar2_table(327) := 'header||''<strong>email</strong>: ''||l_email||''<br>'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    l_header := l_header||''<i>Only ';
wwv_flow_imp.g_varchar2_table(328) := 'above 20% complete are included.</i><br><br>'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- PROJECT ISSUES'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(329) := '        select p.id'||wwv_flow.LF||
'          from sp_projects p,'||wwv_flow.LF||
'               sp_project_priorities r'||wwv_flow.LF||
'         wh';
wwv_flow_imp.g_varchar2_table(330) := 'ere p.duplicate_of_project_id is null'||wwv_flow.LF||
'           and p.archived_yn = ''N'''||wwv_flow.LF||
'           and p.priority_i';
wwv_flow_imp.g_varchar2_table(331) := 'd = r.id'||wwv_flow.LF||
'           and p.pct_complete > 20'||wwv_flow.LF||
'           and p.pct_complete < 100'||wwv_flow.LF||
'           and (p.ow';
wwv_flow_imp.g_varchar2_table(332) := 'ner_id = l_team_member_id or '||wwv_flow.LF||
'                exists (select 1'||wwv_flow.LF||
'                          from sp_pro';
wwv_flow_imp.g_varchar2_table(333) := 'ject_contributors'||wwv_flow.LF||
'                         where team_member_id = l_team_member_id '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(334) := '           and project_id = p.id) )'||wwv_flow.LF||
'         order by r.priority, p.project'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        l_pro';
wwv_flow_imp.g_varchar2_table(335) := 'j_content := null;'||wwv_flow.LF||
'        l_proj_content := sp_util.exceptions_for_project ('||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(336) := '        p_project_id      => c1.id,'||wwv_flow.LF||
'                              p_one_project_yn  => ''N'','||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(337) := '                      p_team_member_id  => l_team_member_id,'||wwv_flow.LF||
'                              p_link_ty';
wwv_flow_imp.g_varchar2_table(338) := 'pe       => l_link_type,'||wwv_flow.LF||
'                              p_app_prefix_url  => l_app_prefix_url,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(339) := '                        p_app_id          => l_app_id,'||wwv_flow.LF||
'                              p_apex_session ';
wwv_flow_imp.g_varchar2_table(340) := '   => p_apex_session,'||wwv_flow.LF||
'                              p_reviews_yn      => l_reviews_yn,'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(341) := '                 p_approvals_yn    => l_approvals_yn );'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'        if dbms_lob.getlength(l_proj_conte';
wwv_flow_imp.g_varchar2_table(342) := 'nt) != 0 then'||wwv_flow.LF||
'            l_proj_except_count := l_proj_except_count + 1;'||wwv_flow.LF||
'            x := x||l_proj';
wwv_flow_imp.g_varchar2_table(343) := '_content;'||wwv_flow.LF||
'        end if; '||wwv_flow.LF||
'        '||wwv_flow.LF||
'        if l_proj_except_count = l_project_max_count and p_links';
wwv_flow_imp.g_varchar2_table(344) := ' in (''EMAIL'',''JOB'') then'||wwv_flow.LF||
'            x := x||''View more in application...'';'||wwv_flow.LF||
'            exit;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(345) := '  end if; '||wwv_flow.LF||
''||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- END PROJECT EXCEPTIONS'||wwv_flow.LF||
'    if dbms_lob.getlength(x) = 0 then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(346) := '  x := l_header||''No exceptions found'';'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'       x := l_header||x;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return x;';
wwv_flow_imp.g_varchar2_table(347) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'end project_exceptions;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure project_changes ('||wwv_flow.LF||
'    p_team_member_id     in number,'||wwv_flow.LF||
'    p_fr';
wwv_flow_imp.g_varchar2_table(348) := 'equency          in varchar2, -- WEEKLY, WEEKDAYS'||wwv_flow.LF||
'    p_links              in varchar2 default ''NONE';
wwv_flow_imp.g_varchar2_table(349) := ''','||wwv_flow.LF||
'    p_apex_session       in varchar2 default null,'||wwv_flow.LF||
'    p_exclude_user_yn    in varchar2 default ''';
wwv_flow_imp.g_varchar2_table(350) := 'N'','||wwv_flow.LF||
'    p_changes_yn         out  varchar2,  -- if N changes, no email'||wwv_flow.LF||
'    p_change_summary     out ';
wwv_flow_imp.g_varchar2_table(351) := ' clob ) '||wwv_flow.LF||
'is'||wwv_flow.LF||
'    x                      clob := null;'||wwv_flow.LF||
'    l_person               varchar2(255);'||wwv_flow.LF||
'    l';
wwv_flow_imp.g_varchar2_table(352) := '_email                varchar2(255);'||wwv_flow.LF||
'    l_team_member_id       number;'||wwv_flow.LF||
'    l_exclude_user_yn      v';
wwv_flow_imp.g_varchar2_table(353) := 'archar2(1);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_day                  varchar2(3) := to_char(sysdate,''DY'');'||wwv_flow.LF||
'    l_tsysdate        ';
wwv_flow_imp.g_varchar2_table(354) := '     date        := trunc(sysdate);'||wwv_flow.LF||
'    l_date_from            date;'||wwv_flow.LF||
'    l_row_count            int ';
wwv_flow_imp.g_varchar2_table(355) := ':= 0;'||wwv_flow.LF||
'    l_last_project_id      number;'||wwv_flow.LF||
'    l_proj_yn              varchar2(1) := ''N'';'||wwv_flow.LF||
'    l_max_ch';
wwv_flow_imp.g_varchar2_table(356) := 'ange_count     int := 30;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- support for links'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    l_project_label        varchar2';
wwv_flow_imp.g_varchar2_table(357) := '(255);'||wwv_flow.LF||
'    l_link_type            varchar2(30);'||wwv_flow.LF||
'    l_project              varchar2(4000);'||wwv_flow.LF||
'    l_url';
wwv_flow_imp.g_varchar2_table(358) := '                  varchar2(4000);'||wwv_flow.LF||
'    l_app_id               varchar2(4000);'||wwv_flow.LF||
'    l_app_prefix_url   ';
wwv_flow_imp.g_varchar2_table(359) := '    varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- get settings'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    l_app_id            := sp_util.get_s';
wwv_flow_imp.g_varchar2_table(360) := 'etting(''APP_ID'');'||wwv_flow.LF||
'    l_app_prefix_url    := sp_util.get_setting(''APP_PREFIX_URL'');'||wwv_flow.LF||
'    l_project_la';
wwv_flow_imp.g_varchar2_table(361) := 'bel     := sp_util.get_nomenclature(''PROJECT'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- LINK TYPE'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- APP: generate';
wwv_flow_imp.g_varchar2_table(362) := ' links from within the current app requires p_apex_session'||wwv_flow.LF||
'    -- EMAIL: generate fully qualified li';
wwv_flow_imp.g_varchar2_table(363) := 'nks'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if p_links = ''APP'' and p_apex_session is not null and l_app_id is not null then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(364) := '  l_link_type := ''APP'';'||wwv_flow.LF||
'    elsif p_links = ''EMAIL'' and l_app_id is not null then'||wwv_flow.LF||
'       l_link_type';
wwv_flow_imp.g_varchar2_table(365) := ' := ''EMAIL'';'||wwv_flow.LF||
'    elsif p_links = ''JOB'' and l_app_id is not null then'||wwv_flow.LF||
'       l_link_type := ''JOB'';'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(366) := '  elsif p_links is null then'||wwv_flow.LF||
'       l_link_type := ''NONE'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- TIMESPAN'||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(367) := '-'||wwv_flow.LF||
'    if p_frequency = ''WEEKDAYS'' and l_day != ''MON'' '||wwv_flow.LF||
'       then l_date_from := l_tsysdate - 1;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(368) := ' elsif p_frequency = ''WEEKDAYS'' and l_day = ''MON'''||wwv_flow.LF||
'       then l_date_from := l_tsysdate - 3;'||wwv_flow.LF||
'    els';
wwv_flow_imp.g_varchar2_table(369) := 'if p_frequency = ''WEEKLY'' '||wwv_flow.LF||
'       then l_date_from := l_tsysdate - 7;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- NAM';
wwv_flow_imp.g_varchar2_table(370) := 'E'||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select first_Name||'' ''||last_name name, email, id '||wwv_flow.LF||
'          from ';
wwv_flow_imp.g_varchar2_table(371) := 'sp_team_members tm '||wwv_flow.LF||
'         where id = p_team_member_id'||wwv_flow.LF||
'    ) loop '||wwv_flow.LF||
'        l_person := apex_escape';
wwv_flow_imp.g_varchar2_table(372) := '.html(c1.name);'||wwv_flow.LF||
'        l_email  := lower(c1.email);'||wwv_flow.LF||
'        l_team_member_id := c1.id;'||wwv_flow.LF||
'    end loop';
wwv_flow_imp.g_varchar2_table(373) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_link_type in (''EMAIL'',''JOB'') then'||wwv_flow.LF||
'        l_exclude_user_yn := nvl(apex_util.GET_prefere';
wwv_flow_imp.g_varchar2_table(374) := 'nce ('||wwv_flow.LF||
'                                 p_preference => ''P5_PROJ_CHANGE_EXCLUDE_USER_YN'','||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(375) := '                      p_user       => upper(l_email) ),''N'');'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        l_exclude_user_yn := p';
wwv_flow_imp.g_varchar2_table(376) := '_exclude_user_yn;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- HEADING'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    x := ''<h3>''||l_project_label||'' Chan';
wwv_flow_imp.g_varchar2_table(377) := 'ge report for ''||l_person||''</h3>''||chr(10);'||wwv_flow.LF||
'    x := x||''<i>Changes for projects you own or have fa';
wwv_flow_imp.g_varchar2_table(378) := 'vorited</i><br/>''||chr(10);'||wwv_flow.LF||
'    if l_link_type in (''EMAIL'',''JOB'') and l_exclude_user_yn = ''Y'' then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(379) := '      x := x||''<i>(changes made by current user are excluded)</i><br/>'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    x := x||''<';
wwv_flow_imp.g_varchar2_table(380) := 'strong>timeframe</strong>: ''||case when p_frequency = ''WEEKDAYS'' and l_day != ''MON'''||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(381) := '                                     then ''last day'''||wwv_flow.LF||
'                                               ';
wwv_flow_imp.g_varchar2_table(382) := '  when p_frequency = ''WEEKDAYS'' and l_day = ''MON'''||wwv_flow.LF||
'                                                  ';
wwv_flow_imp.g_varchar2_table(383) := '   then ''last 3 days'''||wwv_flow.LF||
'                                                 when p_frequency = ''WEEKLY'''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(384) := '                                                    then ''last 7 days'''||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(385) := '                    end ||''<br><br>'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ( '||wwv_flow.LF||
'        with fav as (select project_id from ';
wwv_flow_imp.g_varchar2_table(386) := 'sp_favorites'||wwv_flow.LF||
'                      where team_member_id = l_team_member_id)'||wwv_flow.LF||
'        select pc.projec';
wwv_flow_imp.g_varchar2_table(387) := 't_id,'||wwv_flow.LF||
'               p.project,'||wwv_flow.LF||
'               p.friendly_identifier,'||wwv_flow.LF||
'               '' - ''|| to_char';
wwv_flow_imp.g_varchar2_table(388) := '(p.pct_complete) ||''% ''|| p.project_size ||'' P''||to_char(pp.priority) quick_summary,'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(389) := 'case when p.owner_id is not null then '' - ''||(select first_name ||'' ''||last_name from sp_team_member';
wwv_flow_imp.g_varchar2_table(390) := 's where id = p.owner_id) end owner,'||wwv_flow.LF||
'               --'||wwv_flow.LF||
'               case when pc.attribute_column =';
wwv_flow_imp.g_varchar2_table(391) := ' ''TAGS'' and pc.change_type = ''UPDATE'''||wwv_flow.LF||
'                    then ''Tags, ''||sp_util.list_change ('||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(392) := '                                   p_old_list => pc.old_value, '||wwv_flow.LF||
'                                    ';
wwv_flow_imp.g_varchar2_table(393) := '    p_new_list => pc.new_value )||'' '''||wwv_flow.LF||
'                    when pc.change_type = ''CREATE'''||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(394) := '         then initcap(replace(pc.attribute_column,''_'','' ''))||'' ''||case when pc.attribute_column in (';
wwv_flow_imp.g_varchar2_table(395) := '''COMMENT'',''LINK'') then ''"'' end||'||wwv_flow.LF||
'                            case when pc.attribute_column = ''COMMEN';
wwv_flow_imp.g_varchar2_table(396) := 'T'''||wwv_flow.LF||
'                                 then substr(pc.new_value,1,40)||case when length(pc.new_value) >';
wwv_flow_imp.g_varchar2_table(397) := ' 40 then ''...'' end'||wwv_flow.LF||
'                                 else decode(pc.new_value,''Y'',''Yes'',''N'',''No'',pc.n';
wwv_flow_imp.g_varchar2_table(398) := 'ew_value)'||wwv_flow.LF||
'                                 end ||'||wwv_flow.LF||
'                            case when pc.attribute';
wwv_flow_imp.g_varchar2_table(399) := '_column in (''COMMENT'',''LINK'') then ''"'' end||'' added '''||wwv_flow.LF||
'                    when pc.change_type = ''DEL';
wwv_flow_imp.g_varchar2_table(400) := 'ETE'''||wwv_flow.LF||
'                    then initcap(replace(pc.attribute_column,''_'','' ''))||'' ''||case when pc.attri';
wwv_flow_imp.g_varchar2_table(401) := 'bute_column in (''COMMENT'',''LINK'') then ''"'' end||'||wwv_flow.LF||
'                             decode(pc.old_value,''Y';
wwv_flow_imp.g_varchar2_table(402) := ''',''Yes'',''N'',''No'',pc.old_value)||case when pc.attribute_column in (''COMMENT'',''LINK'') then ''"'' end||'' ';
wwv_flow_imp.g_varchar2_table(403) := 'deleted '''||wwv_flow.LF||
'                    when pc.attribute_column = ''OWNER'' and pc.old_value is null and pc.new';
wwv_flow_imp.g_varchar2_table(404) := '_value is not null'||wwv_flow.LF||
'                      then ''Owner added "''||pc.new_value||''" '''||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(405) := '  when pc.attribute_column = ''RELEASE'' and pc.old_value is null and pc.new_value is not null'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(406) := '               then ''Release added "''||pc.new_value||''" '''||wwv_flow.LF||
'                    when pc.attribute_colu';
wwv_flow_imp.g_varchar2_table(407) := 'mn = ''COMMENT'''||wwv_flow.LF||
'                      then ''Comment changed from "''||substr(pc.old_value,1,40)||case ';
wwv_flow_imp.g_varchar2_table(408) := 'when length(pc.old_value) > 40 then ''...'' end||''" to "''||'||wwv_flow.LF||
'                                          ';
wwv_flow_imp.g_varchar2_table(409) := '      substr(pc.new_value,1,40)||case when length(pc.new_value) > 40 then ''...'' end||''" '''||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(410) := '          else initcap(replace(pc.attribute_column,''_'','' ''))||'||wwv_flow.LF||
'                             '' change';
wwv_flow_imp.g_varchar2_table(411) := 'd from "''||nvl(decode(pc.old_value,''Y'',''Yes'',''N'',''No'',pc.old_value),''NULL'')||''" to "''||'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(412) := '                                    nvl(decode(pc.new_value,''Y'',''Yes'',''N'',''No'',pc.new_value),''NULL'')';
wwv_flow_imp.g_varchar2_table(413) := '||''" '''||wwv_flow.LF||
'                    end ||'||wwv_flow.LF||
'                    apex_util.get_since(pc.changed_on) || '' by '' |';
wwv_flow_imp.g_varchar2_table(414) := '| lower(pc.changed_by) change,'||wwv_flow.LF||
'               --'||wwv_flow.LF||
'               case when p.owner_id = l_team_member';
wwv_flow_imp.g_varchar2_table(415) := '_id then 1 else 0 end ob1,'||wwv_flow.LF||
'               pp.priority ob2,'||wwv_flow.LF||
'               p.pct_complete ob3,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(416) := '         pc.project_id ob4,'||wwv_flow.LF||
'               pc.changed_on ob5'||wwv_flow.LF||
'          from sp_project_history pc,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(417) := '              sp_projects p, '||wwv_flow.LF||
'               sp_project_priorities pp'||wwv_flow.LF||
'         where pc.project_id =';
wwv_flow_imp.g_varchar2_table(418) := ' p.id'||wwv_flow.LF||
'           and p.priority_id = pp.id'||wwv_flow.LF||
'           and (p.owner_id = l_team_member_id or '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(419) := '         p.id in (select project_id from fav) )'||wwv_flow.LF||
'           and pc.changed_on > l_date_from'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(420) := '  and (l_exclude_user_yn = ''N'' or pc.changed_by != l_email)'||wwv_flow.LF||
'           and pc.changed_by != ''nobody''';
wwv_flow_imp.g_varchar2_table(421) := ''||wwv_flow.LF||
'        union all'||wwv_flow.LF||
'        select p.id project_id,'||wwv_flow.LF||
'               p.project,'||wwv_flow.LF||
'               p.friend';
wwv_flow_imp.g_varchar2_table(422) := 'ly_identifier,'||wwv_flow.LF||
'               '' - ''|| to_char(p.pct_complete) ||''% ''|| p.project_size ||'' P''||to_cha';
wwv_flow_imp.g_varchar2_table(423) := 'r(pp.priority) quick_summary,'||wwv_flow.LF||
'               case when p.owner_id is not null then '' - ''||(select fi';
wwv_flow_imp.g_varchar2_table(424) := 'rst_name ||'' ''||last_name from sp_team_members where id = p.owner_id) end owner,'||wwv_flow.LF||
'               --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(425) := '              tt.task_type || case when t.task is not null then '' - ''||t.task end ||'' ''||'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(426) := '     case when pc.attribute_column = ''TAGS'' and pc.change_type = ''UPDATE'''||wwv_flow.LF||
'                      then';
wwv_flow_imp.g_varchar2_table(427) := ' ''Tags, ''||sp_util.list_change ('||wwv_flow.LF||
'                                        p_old_list => pc.old_value,';
wwv_flow_imp.g_varchar2_table(428) := ' '||wwv_flow.LF||
'                                        p_new_list => pc.new_value )||'' '''||wwv_flow.LF||
'                    when';
wwv_flow_imp.g_varchar2_table(429) := ' pc.change_type = ''CREATE'''||wwv_flow.LF||
'                      then initcap(replace(pc.attribute_column,''_'','' ''))|';
wwv_flow_imp.g_varchar2_table(430) := '|'' ''||case when pc.attribute_column in (''COMMENT'',''LINK'') then ''"'' end||'||wwv_flow.LF||
'                           ';
wwv_flow_imp.g_varchar2_table(431) := 'case when pc.attribute_column = ''COMMENT'''||wwv_flow.LF||
'                                then substr(pc.new_value,1';
wwv_flow_imp.g_varchar2_table(432) := ',40)||case when length(pc.new_value) > 40 then ''...'' end'||wwv_flow.LF||
'                                else decode';
wwv_flow_imp.g_varchar2_table(433) := '(pc.new_value,''Y'',''Yes'',''N'',''No'',pc.new_value)'||wwv_flow.LF||
'                                end ||'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(434) := '             case when pc.attribute_column in (''COMMENT'',''LINK'') then ''"'' end||'' added '''||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(435) := '         when pc.change_type = ''DELETE'''||wwv_flow.LF||
'                      then initcap(replace(pc.attribute_colu';
wwv_flow_imp.g_varchar2_table(436) := 'mn,''_'','' ''))||'' ''||case when pc.attribute_column in (''COMMENT'',''LINK'') then ''"'' end||'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(437) := '               decode(pc.old_value,''Y'',''Yes'',''N'',''No'',pc.old_value)||case when pc.attribute_column i';
wwv_flow_imp.g_varchar2_table(438) := 'n (''COMMENT'',''LINK'') then ''"'' end||'' deleted '''||wwv_flow.LF||
'                    when pc.attribute_column = ''OWNER';
wwv_flow_imp.g_varchar2_table(439) := ''' and pc.old_value is null and pc.new_value is not null'||wwv_flow.LF||
'                      then ''Owner added "''||';
wwv_flow_imp.g_varchar2_table(440) := 'pc.new_value||''" '''||wwv_flow.LF||
'                    when pc.attribute_column = ''COMMENT'''||wwv_flow.LF||
'                      th';
wwv_flow_imp.g_varchar2_table(441) := 'en ''Comment changed from "''||substr(pc.old_value,1,40)||case when length(pc.old_value) > 40 then ''..';
wwv_flow_imp.g_varchar2_table(442) := '.'' end||''" to "''||'||wwv_flow.LF||
'                                                substr(pc.new_value,1,40)||case w';
wwv_flow_imp.g_varchar2_table(443) := 'hen length(pc.new_value) > 40 then ''...'' end||''" '''||wwv_flow.LF||
'                    else initcap(replace(pc.attri';
wwv_flow_imp.g_varchar2_table(444) := 'bute_column,''_'','' ''))||'||wwv_flow.LF||
'                             '' changed from "''||nvl(decode(pc.old_value,''Y'',';
wwv_flow_imp.g_varchar2_table(445) := '''Yes'',''N'',''No'',pc.old_value),''NULL'')||''" to "''||'||wwv_flow.LF||
'                                                nvl';
wwv_flow_imp.g_varchar2_table(446) := '(decode(pc.new_value,''Y'',''Yes'',''N'',''No'',pc.new_value),''NULL'')||''" '''||wwv_flow.LF||
'                    end ||'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(447) := '               apex_util.get_since(pc.changed_on) || '' by '' || lower(pc.changed_by) change,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(448) := '       --'||wwv_flow.LF||
'               case when p.owner_id = l_team_member_id then 1 else 0 end ob1,'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(449) := '   pp.priority ob2,'||wwv_flow.LF||
'               p.pct_complete ob3,'||wwv_flow.LF||
'               p.id ob4,'||wwv_flow.LF||
'               pc.ch';
wwv_flow_imp.g_varchar2_table(450) := 'anged_on ob5'||wwv_flow.LF||
'          from sp_task_history pc,'||wwv_flow.LF||
'               sp_tasks t,'||wwv_flow.LF||
'               sp_project';
wwv_flow_imp.g_varchar2_table(451) := 's p, '||wwv_flow.LF||
'               sp_project_priorities pp,'||wwv_flow.LF||
'               sp_task_types tt'||wwv_flow.LF||
'         where p.id =';
wwv_flow_imp.g_varchar2_table(452) := ' t.project_id'||wwv_flow.LF||
'           and pc.task_id = t.id'||wwv_flow.LF||
'           and p.priority_id = pp.id'||wwv_flow.LF||
'           and n';
wwv_flow_imp.g_varchar2_table(453) := 'vl(t.task_sub_type_id,t.task_type_id) = tt.id'||wwv_flow.LF||
'           and p.owner_id = l_team_member_id'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(454) := '  and pc.changed_on > l_date_from'||wwv_flow.LF||
'           and (l_exclude_user_yn = ''N'' or pc.changed_by != l_emai';
wwv_flow_imp.g_varchar2_table(455) := 'l)'||wwv_flow.LF||
'         order by ob1, ob2, ob3 desc, ob4, ob5 desc'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'        if l_last_project_id is n';
wwv_flow_imp.g_varchar2_table(456) := 'ull or l_last_project_id != c1.project_id then'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- CREATE PROJECT HEADER TO BREAK ON'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(457) := '         if l_link_type = ''APP'' then'||wwv_flow.LF||
'               l_url := apex_util.prepare_url(''f?p=''||l_app_id|';
wwv_flow_imp.g_varchar2_table(458) := '|'':3:''||p_apex_session||''::NO:3:FI:''||apex_escape.html(c1.friendly_identifier));'||wwv_flow.LF||
'               l_pr';
wwv_flow_imp.g_varchar2_table(459) := 'oject := ''<a href="''||l_url||''"><strong>''||apex_escape.html(c1.project)||''</strong></a>'';'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(460) := '  elsif l_link_type in (''EMAIL'',''JOB'') then'||wwv_flow.LF||
'               l_url := apex_page.get_url('||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(461) := '               p_application => l_app_id,'||wwv_flow.LF||
'                            p_page        => 3,'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(462) := '                  p_session     => null,'||wwv_flow.LF||
'                            p_items       => ''FI'','||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(463) := '                    p_values      => c1.friendly_identifier,'||wwv_flow.LF||
'                            p_plain_url';
wwv_flow_imp.g_varchar2_table(464) := '   => TRUE );'||wwv_flow.LF||
'               if l_link_type = ''EMAIL'' then'||wwv_flow.LF||
'                  l_url := l_app_prefix_u';
wwv_flow_imp.g_varchar2_table(465) := 'rl || l_url; '||wwv_flow.LF||
'               end if;'||wwv_flow.LF||
'               l_project := ''<a href="''||l_url||''"><strong>''||a';
wwv_flow_imp.g_varchar2_table(466) := 'pex_escape.html(c1.project)||''</strong></a>'';'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'               l_project := ''<strong>';
wwv_flow_imp.g_varchar2_table(467) := '''||apex_escape.html(c1.project)||''</strong>'';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'            if l_row_count = 0 th';
wwv_flow_imp.g_varchar2_table(468) := 'en'||wwv_flow.LF||
'                x := x|| l_project || apex_escape.html(c1.owner) || apex_escape.html(c1.quick_sum';
wwv_flow_imp.g_varchar2_table(469) := 'mary) ||''<ul>''||chr(10);'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'                x := x||''</ul>''|| l_project || apex_escape';
wwv_flow_imp.g_varchar2_table(470) := '.html(c1.owner) || apex_escape.html(c1.quick_summary) ||''<ul>''||chr(10);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(471) := ' end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        x := x||''<li>''||apex_escape.html(c1.change)||''</li>''||chr(10);'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_last_pro';
wwv_flow_imp.g_varchar2_table(472) := 'ject_id := c1.project_id;'||wwv_flow.LF||
'        l_row_count := l_row_count + 1;'||wwv_flow.LF||
''||wwv_flow.LF||
'        if p_links in (''EMAIL'',''J';
wwv_flow_imp.g_varchar2_table(473) := 'OB'') and l_row_count = l_max_change_count then'||wwv_flow.LF||
'           x := x||''View more in application...'';'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(474) := '        exit;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_row_count = 0 then'||wwv_flow.LF||
'       p_changes_yn := ''N''';
wwv_flow_imp.g_varchar2_table(475) := ';'||wwv_flow.LF||
'       p_change_summary := null;'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'       x := x||''</ul>'';'||wwv_flow.LF||
'       p_changes_yn := ''Y'';'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(476) := '   p_change_summary := x;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'end project_changes;'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_contributor_summary;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(40922002279481301958)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_contributor_summary body'
,p_sequence=>740
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
