prompt --application/deployment/install/install_sequence
begin
--   Manifest
--     INSTALL: INSTALL-Sequence
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>19055477148803894
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13849330521060886862)
,p_install_id=>wwv_flow_imp.id(141234962960674597981)
,p_name=>'Sequence'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>'create sequence SP_SEQ;'
);
wwv_flow_imp.component_end;
end;
/
