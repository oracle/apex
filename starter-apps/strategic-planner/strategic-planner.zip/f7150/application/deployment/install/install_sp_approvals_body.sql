prompt --application/deployment/install/install_sp_approvals_body
begin
--   Manifest
--     INSTALL: INSTALL-sp_approvals body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body sp_approvals'||wwv_flow.LF||
'as'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure submit_for_approval ('||wwv_flow.LF||
'    p_project_id    ';
wwv_flow_imp.g_varchar2_table(2) := '       in  number,'||wwv_flow.LF||
'    p_approval_type_id     in  number,'||wwv_flow.LF||
'    p_team_member_id       in  number,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(3) := ' p_justification        in  varchar2,'||wwv_flow.LF||
'    p_project_approval_id  out number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in';
wwv_flow_imp.g_varchar2_table(4) := ' ('||wwv_flow.LF||
'        select i.id initiative_approval_id,'||wwv_flow.LF||
'               (select count(*) from sp_initiative_ap';
wwv_flow_imp.g_varchar2_table(5) := 'proval_chain'||wwv_flow.LF||
'                 where initiative_approval_id = i.id'||wwv_flow.LF||
'                   and active_yn =';
wwv_flow_imp.g_varchar2_table(6) := ' ''Y'') approvers_cnt'||wwv_flow.LF||
'          from sp_projects p,'||wwv_flow.LF||
'               sp_initiative_approvals i'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(7) := 'where p.id = p_project_id'||wwv_flow.LF||
'           and p.initiative_id = i.initiative_id'||wwv_flow.LF||
'           and i.approval';
wwv_flow_imp.g_varchar2_table(8) := '_type_id = p_approval_type_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        insert into sp_project_approvals'||wwv_flow.LF||
'            (appro';
wwv_flow_imp.g_varchar2_table(9) := 'val_type_id, project_id, submitted_by_team_member_id, justification, initiative_approval_id)'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(10) := ' values'||wwv_flow.LF||
'            (p_approval_type_id, p_project_id, p_team_member_id, p_justification, c1.initiat';
wwv_flow_imp.g_varchar2_table(11) := 'ive_approval_id)'||wwv_flow.LF||
'        returning id into p_project_approval_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'        if c1.in';
wwv_flow_imp.g_varchar2_table(12) := 'itiative_approval_id is null then '||wwv_flow.LF||
'            -- no approval chain'||wwv_flow.LF||
'            update sp_project_ap';
wwv_flow_imp.g_varchar2_table(13) := 'provals'||wwv_flow.LF||
'               set status = ''NO-APPROVAL'''||wwv_flow.LF||
'             where id = p_project_approval_id;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(14) := '     elsif c1.approvers_cnt = 0 then '||wwv_flow.LF||
'            -- no approvers'||wwv_flow.LF||
'            update sp_project_appr';
wwv_flow_imp.g_varchar2_table(15) := 'ovals'||wwv_flow.LF||
'               set status = ''NO-APPROVERS'''||wwv_flow.LF||
'             where id = p_project_approval_id;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(16) := '    else '||wwv_flow.LF||
'            -- if submittor is in approval chain, start after that person'||wwv_flow.LF||
'            for ';
wwv_flow_imp.g_varchar2_table(17) := 'c2 in ('||wwv_flow.LF||
'                select id'||wwv_flow.LF||
'                  from sp_initiative_approval_chain'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(18) := '   where initiative_approval_id = c1.initiative_approval_id'||wwv_flow.LF||
'                   and (team_member_id =';
wwv_flow_imp.g_varchar2_table(19) := ' p_team_member_id or '||wwv_flow.LF||
'                        (alternate_team_member_id = p_team_member_id and'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(20) := '                    nvl(alternate_start_date,sysdate) <= sysdate and'||wwv_flow.LF||
'                         nvl(al';
wwv_flow_imp.g_varchar2_table(21) := 'ternate_end_date,sysdate)+1 > sysdate) )'||wwv_flow.LF||
'                   and active_yn = ''Y'''||wwv_flow.LF||
'            ) loop'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(22) := '               insert into sp_project_approval_chain'||wwv_flow.LF||
'                    (project_approval_id, initi';
wwv_flow_imp.g_varchar2_table(23) := 'ative_approval_chain_id, team_member_id, status)'||wwv_flow.LF||
'                values'||wwv_flow.LF||
'                    (p_proje';
wwv_flow_imp.g_varchar2_table(24) := 'ct_approval_id, c2.id, p_team_member_id, ''APPROVED'');'||wwv_flow.LF||
'                commit;'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(25) := '        end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end submit_for_approval;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure clarify ('||wwv_flow.LF||
'    p_project_approval_';
wwv_flow_imp.g_varchar2_table(26) := 'chain_id  number,'||wwv_flow.LF||
'    p_team_member_id             number,'||wwv_flow.LF||
'    p_response                   varchar2';
wwv_flow_imp.g_varchar2_table(27) := ' )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_project_approval_id  number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_project_approval_chain'||wwv_flow.LF||
'        (pr';
wwv_flow_imp.g_varchar2_table(28) := 'oject_approval_id, initiative_approval_chain_id, '||wwv_flow.LF||
'         team_member_id, comments,'||wwv_flow.LF||
'         respon';
wwv_flow_imp.g_varchar2_table(29) := 'se, response_by_team_member_id,'||wwv_flow.LF||
'         status, last_status_on,'||wwv_flow.LF||
'         final_yn)'||wwv_flow.LF||
'    select proje';
wwv_flow_imp.g_varchar2_table(30) := 'ct_approval_id, initiative_approval_chain_id,  '||wwv_flow.LF||
'           team_member_id, comments, '||wwv_flow.LF||
'           p_r';
wwv_flow_imp.g_varchar2_table(31) := 'esponse, p_team_member_id,'||wwv_flow.LF||
'           ''CLARIFICATION-REQUESTED'', sysdate,'||wwv_flow.LF||
'           ''N'''||wwv_flow.LF||
'      from ';
wwv_flow_imp.g_varchar2_table(32) := 'sp_project_approval_chain'||wwv_flow.LF||
'     where id = p_project_approval_chain_id;  '||wwv_flow.LF||
''||wwv_flow.LF||
'    update sp_project_appr';
wwv_flow_imp.g_varchar2_table(33) := 'oval_chain'||wwv_flow.LF||
'       set status = ''PENDING'','||wwv_flow.LF||
'           last_status_on = sysdate,'||wwv_flow.LF||
'           comments =';
wwv_flow_imp.g_varchar2_table(34) := ' null'||wwv_flow.LF||
'     where id = p_project_approval_chain_id'||wwv_flow.LF||
'     returning project_approval_id into l_project_';
wwv_flow_imp.g_varchar2_table(35) := 'approval_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'     update sp_project_approvals'||wwv_flow.LF||
'        set status = ''PENDING'''||wwv_flow.LF||
'      where id = l_pro';
wwv_flow_imp.g_varchar2_table(36) := 'ject_approval_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'end clarify;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure withdraw ('||wwv_flow.LF||
'    p_project_approval_id  in  number,'||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(37) := 'team_member_id       in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_project_approval_id  number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    update sp_project_';
wwv_flow_imp.g_varchar2_table(38) := 'approvals'||wwv_flow.LF||
'       set status = ''WITHDRAWN'','||wwv_flow.LF||
'           withdrawn_by_team_member_id = p_team_member_id';
wwv_flow_imp.g_varchar2_table(39) := ''||wwv_flow.LF||
'     where id = p_project_approval_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    update sp_project_approval_chain'||wwv_flow.LF||
'       set final_yn = ';
wwv_flow_imp.g_varchar2_table(40) := '''N'''||wwv_flow.LF||
'     where project_approval_id = p_project_approval_id'||wwv_flow.LF||
'       and final_yn != ''N'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- remov';
wwv_flow_imp.g_varchar2_table(41) := 'ing fk to allow for approval chain changes over time (team_member is always known)'||wwv_flow.LF||
'    update sp_pro';
wwv_flow_imp.g_varchar2_table(42) := 'ject_approval_chain'||wwv_flow.LF||
'       set initiative_approval_chain_id = null'||wwv_flow.LF||
'     where project_approval_id = ';
wwv_flow_imp.g_varchar2_table(43) := 'p_project_approval_id'||wwv_flow.LF||
'       and initiative_approval_chain_id is not null;'||wwv_flow.LF||
''||wwv_flow.LF||
'end withdraw;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function';
wwv_flow_imp.g_varchar2_table(44) := ' approval_pending ('||wwv_flow.LF||
'    p_project_id      in  number,'||wwv_flow.LF||
'    p_team_member_id  in  number'||wwv_flow.LF||
') return numb';
wwv_flow_imp.g_varchar2_table(45) := 'er'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select c.id'||wwv_flow.LF||
'          from sp_project_approval_chain c,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(46) := '       sp_project_approvals a'||wwv_flow.LF||
'         where a.id = c.project_approval_id'||wwv_flow.LF||
'           and a.project_i';
wwv_flow_imp.g_varchar2_table(47) := 'd = p_project_id'||wwv_flow.LF||
'           and c.team_member_id = p_team_member_id'||wwv_flow.LF||
'           and c.status = ''PENDI';
wwv_flow_imp.g_varchar2_table(48) := 'NG'''||wwv_flow.LF||
'           and c.final_yn = ''Y'''||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return null;';
wwv_flow_imp.g_varchar2_table(49) := ''||wwv_flow.LF||
'end approval_pending;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function more_info_pending ('||wwv_flow.LF||
'    p_project_id      in  number,'||wwv_flow.LF||
'    p_team_m';
wwv_flow_imp.g_varchar2_table(50) := 'ember_id  in  number'||wwv_flow.LF||
') return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select c.id'||wwv_flow.LF||
'          from sp_';
wwv_flow_imp.g_varchar2_table(51) := 'project_approval_chain c,'||wwv_flow.LF||
'               sp_project_approvals a'||wwv_flow.LF||
'         where a.id = c.project_appr';
wwv_flow_imp.g_varchar2_table(52) := 'oval_id'||wwv_flow.LF||
'           and a.project_id = p_project_id'||wwv_flow.LF||
'           and c.status = ''CLARIFICATION-REQUESTE';
wwv_flow_imp.g_varchar2_table(53) := 'D'''||wwv_flow.LF||
'           and a.status = ''CLARIFICATION-REQUESTED'''||wwv_flow.LF||
'           and c.final_yn = ''Y'''||wwv_flow.LF||
'           an';
wwv_flow_imp.g_varchar2_table(54) := 'd a.submitted_by_team_member_id = p_team_member_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(55) := '   return null;'||wwv_flow.LF||
'end more_info_pending;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function approval_pending_cnt ('||wwv_flow.LF||
'    p_team_member_id  in  n';
wwv_flow_imp.g_varchar2_table(56) := 'umber'||wwv_flow.LF||
') return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select count(*) cnt'||wwv_flow.LF||
'          from sp_project';
wwv_flow_imp.g_varchar2_table(57) := '_approval_chain c,'||wwv_flow.LF||
'               sp_project_approvals a'||wwv_flow.LF||
'         where a.id = c.project_approval_id';
wwv_flow_imp.g_varchar2_table(58) := ''||wwv_flow.LF||
'           and c.team_member_id = p_team_member_id'||wwv_flow.LF||
'           and c.status = ''PENDING'''||wwv_flow.LF||
'           a';
wwv_flow_imp.g_varchar2_table(59) := 'nd c.final_yn = ''Y'''||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return c1.cnt;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end approval_pending_cnt;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'func';
wwv_flow_imp.g_varchar2_table(60) := 'tion more_info_pending_cnt ('||wwv_flow.LF||
'    p_team_member_id  in  number'||wwv_flow.LF||
') return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in';
wwv_flow_imp.g_varchar2_table(61) := ' ('||wwv_flow.LF||
'        select count(*) cnt'||wwv_flow.LF||
'          from sp_project_approval_chain c,'||wwv_flow.LF||
'               sp_project';
wwv_flow_imp.g_varchar2_table(62) := '_approvals a'||wwv_flow.LF||
'         where a.id = c.project_approval_id'||wwv_flow.LF||
'           and c.status = ''CLARIFICATION-RE';
wwv_flow_imp.g_varchar2_table(63) := 'QUESTED'''||wwv_flow.LF||
'           and a.status = ''CLARIFICATION-REQUESTED'''||wwv_flow.LF||
'           and c.final_yn = ''Y'''||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(64) := '    and a.submitted_by_team_member_id = p_team_member_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return c1.cnt;'||wwv_flow.LF||
'    end l';
wwv_flow_imp.g_varchar2_table(65) := 'oop;'||wwv_flow.LF||
'end more_info_pending_cnt;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-----------------------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure identif';
wwv_flow_imp.g_varchar2_table(66) := 'y_next_reviewer ('||wwv_flow.LF||
'    p_project_approval_id        in   number,'||wwv_flow.LF||
'    p_project_approval_chain_id  out';
wwv_flow_imp.g_varchar2_table(67) := '  number,'||wwv_flow.LF||
'    p_reviewer_email             out  varchar2,'||wwv_flow.LF||
'    p_reviewer_tm_id             out  numb';
wwv_flow_imp.g_varchar2_table(68) := 'er )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_project_approval_chain_id  number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select initiative_app';
wwv_flow_imp.g_varchar2_table(69) := 'roval_chain_id, team_member_id,'||wwv_flow.LF||
'               (select email from sp_team_members where id = team_me';
wwv_flow_imp.g_varchar2_table(70) := 'mber_id) reviewer_email'||wwv_flow.LF||
'          from ('||wwv_flow.LF||
'        select iac.id initiative_approval_chain_id, '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(71) := '         case when iac.alternate_team_member_id is not null and '||wwv_flow.LF||
'                         nvl(iac.al';
wwv_flow_imp.g_varchar2_table(72) := 'ternate_start_date,sysdate) <= sysdate and '||wwv_flow.LF||
'                         nvl(iac.alternate_end_date+1,sy';
wwv_flow_imp.g_varchar2_table(73) := 'sdate) > sysdate'||wwv_flow.LF||
'                    then iac.alternate_team_member_id'||wwv_flow.LF||
'                    else iac.';
wwv_flow_imp.g_varchar2_table(74) := 'team_member_id'||wwv_flow.LF||
'                    end team_member_id'||wwv_flow.LF||
'          from sp_project_approvals pa,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(75) := '         sp_initiative_approval_chain iac'||wwv_flow.LF||
'         where pa.id =  p_project_approval_id'||wwv_flow.LF||
'           a';
wwv_flow_imp.g_varchar2_table(76) := 'nd pa.initiative_approval_id = iac.initiative_approval_id'||wwv_flow.LF||
'           and iac.active_yn = ''Y'''||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(77) := '    and iac.id not in (select initiative_approval_chain_id'||wwv_flow.LF||
'                                from sp_p';
wwv_flow_imp.g_varchar2_table(78) := 'roject_approval_chain'||wwv_flow.LF||
'                               where project_approval_id = pa.id'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(79) := '                    and status = ''APPROVED'''||wwv_flow.LF||
'                                 and final_yn = ''Y'')'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(80) := '        and iac.approval_seq > nvl((select max(iac2.approval_seq)'||wwv_flow.LF||
'                                  ';
wwv_flow_imp.g_varchar2_table(81) := '       from sp_project_approval_chain pac,'||wwv_flow.LF||
'                                              sp_initiati';
wwv_flow_imp.g_varchar2_table(82) := 've_approval_chain iac2'||wwv_flow.LF||
'                                        where pac.initiative_approval_chain_i';
wwv_flow_imp.g_varchar2_table(83) := 'd = iac2.id'||wwv_flow.LF||
'                                          and pac.project_approval_id = pa.id'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(84) := '                                and pac.status = ''APPROVED'''||wwv_flow.LF||
'                                        ';
wwv_flow_imp.g_varchar2_table(85) := '  and pac.final_yn = ''Y''),-100)'||wwv_flow.LF||
'         order by iac.approval_seq'||wwv_flow.LF||
'         )'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        ins';
wwv_flow_imp.g_varchar2_table(86) := 'ert into sp_project_approval_chain (project_approval_id, initiative_approval_chain_id, team_member_i';
wwv_flow_imp.g_varchar2_table(87) := 'd)'||wwv_flow.LF||
'        values (p_project_approval_id, c1.initiative_approval_chain_id, c1.team_member_id)'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(88) := '  returning id into l_project_approval_chain_id;'||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'        p_project_approval_chain_i';
wwv_flow_imp.g_varchar2_table(89) := 'd := l_project_approval_chain_id;'||wwv_flow.LF||
'        p_reviewer_email := c1.reviewer_email;'||wwv_flow.LF||
'        p_reviewer_';
wwv_flow_imp.g_varchar2_table(90) := 'tm_id := c1.team_member_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'        exit;  -- to just get the next stop'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end identify_';
wwv_flow_imp.g_varchar2_table(91) := 'next_reviewer;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure approve ('||wwv_flow.LF||
'    p_project_approval_chain_id  in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    upda';
wwv_flow_imp.g_varchar2_table(92) := 'te sp_project_approval_chain'||wwv_flow.LF||
'       set status = ''APPROVED'','||wwv_flow.LF||
'           last_status_on = sysdate'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(93) := '  where id = p_project_approval_chain_id;'||wwv_flow.LF||
'end approve;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure reject ('||wwv_flow.LF||
'    p_project_approval_c';
wwv_flow_imp.g_varchar2_table(94) := 'hain_id  in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_project_approval_id  number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    update sp_project_approval_cha';
wwv_flow_imp.g_varchar2_table(95) := 'in'||wwv_flow.LF||
'       set status = ''REJECTED'','||wwv_flow.LF||
'           last_status_on = sysdate'||wwv_flow.LF||
'     where id = p_project_app';
wwv_flow_imp.g_varchar2_table(96) := 'roval_chain_id'||wwv_flow.LF||
' returning project_approval_id into l_project_approval_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    update sp_project_app';
wwv_flow_imp.g_varchar2_table(97) := 'rovals'||wwv_flow.LF||
'       set status = ''REJECTED'''||wwv_flow.LF||
'     where id = l_project_approval_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- removing fk to ';
wwv_flow_imp.g_varchar2_table(98) := 'allow for approval chain changes over time (team_member is always known)'||wwv_flow.LF||
'    update sp_project_appro';
wwv_flow_imp.g_varchar2_table(99) := 'val_chain'||wwv_flow.LF||
'       set initiative_approval_chain_id = null'||wwv_flow.LF||
'     where project_approval_id = l_project_';
wwv_flow_imp.g_varchar2_table(100) := 'approval_id'||wwv_flow.LF||
'       and initiative_approval_chain_id is not null;'||wwv_flow.LF||
'end reject;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_comment';
wwv_flow_imp.g_varchar2_table(101) := 's ('||wwv_flow.LF||
'    p_project_approval_chain_id  in  number,'||wwv_flow.LF||
'    p_comments                   in  varchar2 )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(102) := 'begin'||wwv_flow.LF||
'    update sp_project_approval_chain'||wwv_flow.LF||
'       set comments = p_comments'||wwv_flow.LF||
'     where id = p_projec';
wwv_flow_imp.g_varchar2_table(103) := 't_approval_chain_id;'||wwv_flow.LF||
'end add_comments;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure request_clarification ('||wwv_flow.LF||
'    p_project_approval_ch';
wwv_flow_imp.g_varchar2_table(104) := 'ain_id  in  number,'||wwv_flow.LF||
'    p_comments                   in  varchar2 )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_project_approval_id  nu';
wwv_flow_imp.g_varchar2_table(105) := 'mber;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    update sp_project_approval_chain'||wwv_flow.LF||
'       set status = ''CLARIFICATION-REQUESTED'','||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(106) := '       comments = p_comments,'||wwv_flow.LF||
'           last_status_on = sysdate'||wwv_flow.LF||
'     where id = p_project_approval';
wwv_flow_imp.g_varchar2_table(107) := '_chain_id'||wwv_flow.LF||
'     returning project_approval_id into l_project_approval_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    update sp_project_appr';
wwv_flow_imp.g_varchar2_table(108) := 'ovals'||wwv_flow.LF||
'       set status = ''CLARIFICATION-REQUESTED'''||wwv_flow.LF||
'     where id = l_project_approval_id;'||wwv_flow.LF||
'end reque';
wwv_flow_imp.g_varchar2_table(109) := 'st_clarification;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure approve_request ('||wwv_flow.LF||
'    p_project_approval_id  in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(110) := ' update sp_project_approvals '||wwv_flow.LF||
'       set status = ''APPROVED'''||wwv_flow.LF||
'     where id = p_project_approval_id;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(111) := ''||wwv_flow.LF||
'    -- removing fk to allow for approval chain changes over time (team_member is always known)'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(112) := 'update sp_project_approval_chain'||wwv_flow.LF||
'       set initiative_approval_chain_id = null'||wwv_flow.LF||
'     where project_a';
wwv_flow_imp.g_varchar2_table(113) := 'pproval_id = p_project_approval_id'||wwv_flow.LF||
'       and initiative_approval_chain_id is not null;'||wwv_flow.LF||
'end approve_';
wwv_flow_imp.g_varchar2_table(114) := 'request;'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_approvals;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(52070496458467448394)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_approvals body'
,p_sequence=>765
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
