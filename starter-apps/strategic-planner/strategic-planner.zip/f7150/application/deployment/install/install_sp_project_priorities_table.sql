prompt --application/deployment/install/install_sp_project_priorities_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_project_priorities table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_project_priorities ('||wwv_flow.LF||
'    id                             number default on null to_nu';
wwv_flow_imp.g_varchar2_table(2) := 'mber(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint ';
wwv_flow_imp.g_varchar2_table(3) := 'sp_project_priority_id_pk primary key,'||wwv_flow.LF||
'    priority                       number not null,'||wwv_flow.LF||
'    descr';
wwv_flow_imp.g_varchar2_table(4) := 'iption                    varchar2(40 char) not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    is_default_yn                  varc';
wwv_flow_imp.g_varchar2_table(5) := 'har2(1 char)'||wwv_flow.LF||
'                                   constraint sp_is_default_ck '||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(6) := '            check (is_default_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not n';
wwv_flow_imp.g_varchar2_table(7) := 'ull,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                    ';
wwv_flow_imp.g_varchar2_table(8) := '    date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create uniqu';
wwv_flow_imp.g_varchar2_table(9) := 'e index sp_project_priorities_u1 on sp_project_priorities (priority);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(45802020496899497401)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_project_priorities table'
,p_sequence=>200
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
