prompt --application/deployment/install/install_initiatives_trigger
begin
--   Manifest
--     INSTALL: INSTALL-Initiatives trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3135376067501665909)
,p_install_id=>wwv_flow_imp.id(141180564419272860082)
,p_name=>'Initiatives trigger'
,p_sequence=>460
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace trigger sp_initiatives_biu',
'    before insert or update',
'    on sp_initiatives',
'    for each row',
'declare ',
'    l_tags varchar2(4000);',
'begin',
'    if inserting then',
'        :new.created := sysdate;',
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'    end if;',
'    :new.updated := sysdate;',
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'    if :new.SPONSOR_ID is null then',
'       for c1 in (select OWNER_ID from SP_FOCUS_AREAS f where f.id = :new.FOCUS_AREA_ID and owner_id is not null) loop',
'           :new.SPONSOR_ID := c1.owner_id;',
'       end loop;',
'    end if;',
'    --',
'    -- status scale',
'    --',
'    if :new.status_scale is null then',
'       :new.status_scale := ''A'';',
'    end if;',
'    --',
'    -- adjust tag data',
'    --',
'    if :new.tags is not null then',
'        l_tags := trim(upper(:new.tags));',
'        -- remove multiple spaces',
'        if instr(l_tags,''  '') > 0 then',
'            for j in 1..10 loop ',
'                l_tags := replace(l_tags,''  '','' ''); ',
'                if instr(l_tags,''  '') = 0 then',
'                   exit;',
'                end if;',
'            end loop; ',
'        end if;',
'        for i in 1..length(l_tags) loop',
'            if i > 2 and substr(l_tags,i,1) = '' '' and substr(l_tags,i-1,1) != '','' then',
'               l_tags := substr(l_tags,1,i-1)||''-''||substr(l_tags,i+1);',
'            end if;',
'        end loop;',
'        :new.tags := l_tags;',
'   end if;',
'   --',
'   --',
'   --',
'   if :new.hidden_by_default_yn is null then',
'      :new.hidden_by_default_yn := ''N'';',
'   end if;',
'   --',
'   -- touch parent table',
'   --',
'   update sp_focus_areas set updated = sysdate, updated_by = :new.updated_by where id = :new.focus_area_id;',
'end sp_initiatives_biu;',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
