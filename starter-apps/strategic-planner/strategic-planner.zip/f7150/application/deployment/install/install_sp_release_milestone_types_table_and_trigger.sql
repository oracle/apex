prompt --application/deployment/install/install_sp_release_milestone_types_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_release_milestone_types table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_release_milestone_types ('||wwv_flow.LF||
'    id                             number default on null ';
wwv_flow_imp.g_varchar2_table(2) := 'to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constr';
wwv_flow_imp.g_varchar2_table(3) := 'aint sp_release_milestone_types_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    milestone_type                 varchar2(6';
wwv_flow_imp.g_varchar2_table(4) := '0 char) not null,'||wwv_flow.LF||
'    include_yn                     varchar2(1 char) default on null ''Y'','||wwv_flow.LF||
'    displ';
wwv_flow_imp.g_varchar2_table(5) := 'ay_seq                    number,'||wwv_flow.LF||
'    calendar_event_color           varchar2(30),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    create';
wwv_flow_imp.g_varchar2_table(6) := 'd                        date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not nu';
wwv_flow_imp.g_varchar2_table(7) := 'll,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(25';
wwv_flow_imp.g_varchar2_table(8) := '5 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
'alter table sp_release_milestone_types add constraint sp_release_milestone_types';
wwv_flow_imp.g_varchar2_table(9) := '_uk'||wwv_flow.LF||
'    unique (milestone_type);'||wwv_flow.LF||
'alter table sp_release_milestone_types add constraint sp_release_mi';
wwv_flow_imp.g_varchar2_table(10) := 'lestone_types_include_cc'||wwv_flow.LF||
'    check (include_yn in (''Y'',''N''));'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_release_';
wwv_flow_imp.g_varchar2_table(11) := 'milestone_types_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_release_milestone_types'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'b';
wwv_flow_imp.g_varchar2_table(12) := 'egin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_';
wwv_flow_imp.g_varchar2_table(13) := 'context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_';
wwv_flow_imp.g_varchar2_table(14) := 'by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'end sp_release_milestone_types_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(43084730595172854575)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_release_milestone_types table and trigger'
,p_sequence=>295
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
