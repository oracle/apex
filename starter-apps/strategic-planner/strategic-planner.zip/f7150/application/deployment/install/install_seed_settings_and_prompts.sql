prompt --application/deployment/install/install_seed_settings_and_prompts
begin
--   Manifest
--     INSTALL: INSTALL-seed settings and prompts
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
'    sp_util.add_setting (  '||wwv_flow.LF||
'        p_static_id     => ''APP_ID'',   '||wwv_flow.LF||
'        p_description   =>';
wwv_flow_imp.g_varchar2_table(2) := ' ''Application ID of the application.  Used by summary jobs.'', '||wwv_flow.LF||
'        p_setting_value => null, '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(3) := '     p_is_numeric_yn => ''Y'', '||wwv_flow.LF||
'        p_is_yn         => ''N'' );'||wwv_flow.LF||
'    sp_util.add_setting (  '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(4) := 'p_static_id     => ''APP_PREFIX_URL'',   '||wwv_flow.LF||
'        p_description   => ''Prefix URL of the application.  ';
wwv_flow_imp.g_varchar2_table(5) := 'Used for link creation in summary jobs.'', '||wwv_flow.LF||
'        p_setting_value => null, '||wwv_flow.LF||
'        p_is_numeric_yn';
wwv_flow_imp.g_varchar2_table(6) := ' => ''N'', '||wwv_flow.LF||
'        p_is_yn         => ''N'' );'||wwv_flow.LF||
'    sp_util.add_setting (  '||wwv_flow.LF||
'        p_static_id     => ''';
wwv_flow_imp.g_varchar2_table(7) := 'APP_HOME_URL'',   '||wwv_flow.LF||
'        p_description   => ''Full URL to the home page of the application.  Used fo';
wwv_flow_imp.g_varchar2_table(8) := 'r home link in summary emails.'', '||wwv_flow.LF||
'        p_setting_value => null, '||wwv_flow.LF||
'        p_is_numeric_yn => ''N'', ';
wwv_flow_imp.g_varchar2_table(9) := ''||wwv_flow.LF||
'        p_is_yn         => ''N'' );'||wwv_flow.LF||
'    sp_util.add_setting (  '||wwv_flow.LF||
'        p_static_id     => ''GET_COMME';
wwv_flow_imp.g_varchar2_table(10) := 'NT_IMAGE_PREFIX'',   '||wwv_flow.LF||
'        p_description   => ''Path to displacy images within comments, set by pro';
wwv_flow_imp.g_varchar2_table(11) := 'cess, do not edit'', '||wwv_flow.LF||
'        p_setting_value => null, '||wwv_flow.LF||
'        p_is_numeric_yn => ''N'', '||wwv_flow.LF||
'        p_is';
wwv_flow_imp.g_varchar2_table(12) := '_yn         => ''N'');'||wwv_flow.LF||
'    sp_util.add_setting (  '||wwv_flow.LF||
'        p_static_id     => ''SUMMARY_AI_SERVICE'',   ';
wwv_flow_imp.g_varchar2_table(13) := ''||wwv_flow.LF||
'        p_description   => ''Name of AI Service used for generating summaries. Must be configured un';
wwv_flow_imp.g_varchar2_table(14) := 'der Generative AI Services of the application.'', '||wwv_flow.LF||
'        p_setting_value => null, '||wwv_flow.LF||
'        p_is_num';
wwv_flow_imp.g_varchar2_table(15) := 'eric_yn => ''N'', '||wwv_flow.LF||
'        p_is_yn         => ''N'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- most recent install of Strategic Planner'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(16) := '    --'||wwv_flow.LF||
'    for a in ('||wwv_flow.LF||
'        select application_id'||wwv_flow.LF||
'          from apex_applications'||wwv_flow.LF||
'         where ';
wwv_flow_imp.g_varchar2_table(17) := 'application_name = ''Strategic Planner'''||wwv_flow.LF||
'         order by last_updated_on desc'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        sp_';
wwv_flow_imp.g_varchar2_table(18) := 'util.set_setting (p_static_id     => ''APP_ID'',   '||wwv_flow.LF||
'                             p_setting_value => a.';
wwv_flow_imp.g_varchar2_table(19) := 'application_id); '||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    sp_util.set_setting (p_static_id     => ''APP_PREFIX_URL'',   '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(20) := '                       p_setting_value => APEX_UTIL.HOST_URL); '||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    sp_util.add_ai_pro';
wwv_flow_imp.g_varchar2_table(21) := 'mpt (  '||wwv_flow.LF||
'        p_static_id     => ''FULL_PROJECT_SUMMARY'',   '||wwv_flow.LF||
'        p_description   => ''Used for g';
wwv_flow_imp.g_varchar2_table(22) := 'enerating a full project summary.'', '||wwv_flow.LF||
'        p_prompt        => ''You are given details for a softwar';
wwv_flow_imp.g_varchar2_table(23) := 'e development project, in markdown format, including the most recent comments from the last 90 days.';
wwv_flow_imp.g_varchar2_table(24) := ' Please return the following:'||wwv_flow.LF||
''||wwv_flow.LF||
'Concise Summary: Extract key points to create a brief but accurate su';
wwv_flow_imp.g_varchar2_table(25) := 'mmary of the overall progress, tasks completed, any issues or blockers, and any milestones achieved ';
wwv_flow_imp.g_varchar2_table(26) := 'or reviews completed.  Also include any concerns, such as having no Contributors or Milestones defin';
wwv_flow_imp.g_varchar2_table(27) := 'ed or dates being past due.  This can be 1 or 2 paragraphs depending on the size of the input.'||wwv_flow.LF||
''||wwv_flow.LF||
'Risk';
wwv_flow_imp.g_varchar2_table(28) := ' Assessment: Analyze for signs of potential project risks (e.g., delays, unaddressed issues, lack of';
wwv_flow_imp.g_varchar2_table(29) := ' progress, etc.). Based on this analysis, assign a risk level to the project as follows:'||wwv_flow.LF||
''||wwv_flow.LF||
'None: No r';
wwv_flow_imp.g_varchar2_table(30) := 'isk, assign to all projects with percent complete of 100% (and only those).'||wwv_flow.LF||
''||wwv_flow.LF||
'Low: No immediate conce';
wwv_flow_imp.g_varchar2_table(31) := 'rns; project is progressing smoothly with no major issues.'||wwv_flow.LF||
''||wwv_flow.LF||
'Moderate: Some concerns or blockers are ';
wwv_flow_imp.g_varchar2_table(32) := 'present but can be addressed; risk to the timeline or scope is possible.'||wwv_flow.LF||
''||wwv_flow.LF||
'High: Major issues or bloc';
wwv_flow_imp.g_varchar2_table(33) := 'kers that significantly affect the progress; there is a real danger to the timeline, scope, or quali';
wwv_flow_imp.g_varchar2_table(34) := 'ty.'||wwv_flow.LF||
''||wwv_flow.LF||
'Additionally, list any project highlight achievements, percent complete or status changes, comp';
wwv_flow_imp.g_varchar2_table(35) := 'leted reviews, approvals received, or anything significant about the project in the highlights secti';
wwv_flow_imp.g_varchar2_table(36) := 'on of the JSON.  Always include them in a JSON array.  If there are no highlights, simply add a sing';
wwv_flow_imp.g_varchar2_table(37) := 'le element called "No Highlights".'||wwv_flow.LF||
''||wwv_flow.LF||
'Return using a JSON document with the following structure:'||wwv_flow.LF||
''||wwv_flow.LF||
'{'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(38) := '"summary": "Concise summary of the project progress and key highlights.",'||wwv_flow.LF||
'  "highlights" : "List pro';
wwv_flow_imp.g_varchar2_table(39) := 'ject highlights",'||wwv_flow.LF||
'  "risk": "None | Low | Moderate | High"'||wwv_flow.LF||
'}'||wwv_flow.LF||
''||wwv_flow.LF||
'Make sure to accurately assess the pro';
wwv_flow_imp.g_varchar2_table(40) := 'ject risk and provide a clear, easy-to-understand summary.  Do not include any prefix or suffix char';
wwv_flow_imp.g_varchar2_table(41) := 'acters - only a JSON document.'' );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    sp_util.add_ai_prompt (  '||wwv_flow.LF||
'        p_static_id ';
wwv_flow_imp.g_varchar2_table(42) := '    => ''UPDATE_PROJECT_SUMMARY'',   '||wwv_flow.LF||
'        p_description   => ''Used for generating an updated proje';
wwv_flow_imp.g_varchar2_table(43) := 'ct summary.'', '||wwv_flow.LF||
'        p_prompt        => ''You are given details for a software development project,';
wwv_flow_imp.g_varchar2_table(44) := ' in markdown format, and the last summary generated along with any data that has changed since the l';
wwv_flow_imp.g_varchar2_table(45) := 'ast summary. Please return the following:'||wwv_flow.LF||
''||wwv_flow.LF||
'Concise Summary: Extract key points to create a brief but';
wwv_flow_imp.g_varchar2_table(46) := ' accurate summary of the overall progress since the last summary, tasks completed, any issues or blo';
wwv_flow_imp.g_varchar2_table(47) := 'ckers, and any milestones achieved or reviews completed.  Also include any concerns, such as having ';
wwv_flow_imp.g_varchar2_table(48) := 'no Contributors or Milestones defined or dates being past due.  This can be 1 or 2 paragraphs depend';
wwv_flow_imp.g_varchar2_table(49) := 'ing on the size of the input.'||wwv_flow.LF||
''||wwv_flow.LF||
'Risk Assessment: Analyze for signs of potential project risks (e.g., ';
wwv_flow_imp.g_varchar2_table(50) := 'delays, unaddressed issues, lack of progress, etc.). Based on this analysis, assign a risk level to ';
wwv_flow_imp.g_varchar2_table(51) := 'the project as follows:'||wwv_flow.LF||
''||wwv_flow.LF||
'None: No risk, assign to all projects with percent complete of 100% (and on';
wwv_flow_imp.g_varchar2_table(52) := 'ly those).'||wwv_flow.LF||
''||wwv_flow.LF||
'Low: No immediate concerns; project is progressing smoothly with no major issues.'||wwv_flow.LF||
''||wwv_flow.LF||
'Moder';
wwv_flow_imp.g_varchar2_table(53) := 'ate: Some concerns or blockers are present but can be addressed; risk to the timeline or scope is po';
wwv_flow_imp.g_varchar2_table(54) := 'ssible.'||wwv_flow.LF||
''||wwv_flow.LF||
'High: Major issues or blockers that significantly affect the progress; there is a real dang';
wwv_flow_imp.g_varchar2_table(55) := 'er to the timeline, scope, or quality.'||wwv_flow.LF||
''||wwv_flow.LF||
'Additionally, list any project highlight achievements, perce';
wwv_flow_imp.g_varchar2_table(56) := 'nt complete or status changes, completed reviews, approvals received, or anything significant about ';
wwv_flow_imp.g_varchar2_table(57) := 'the project in the highlights section of the JSON.  Always include them in a JSON array.  If there a';
wwv_flow_imp.g_varchar2_table(58) := 're no highlights, simply add a single element called "No Highlights".'||wwv_flow.LF||
''||wwv_flow.LF||
'Return using a JSON document ';
wwv_flow_imp.g_varchar2_table(59) := 'with the following structure:'||wwv_flow.LF||
''||wwv_flow.LF||
'{'||wwv_flow.LF||
'  "summary": "Concise summary of the project progress and key highl';
wwv_flow_imp.g_varchar2_table(60) := 'ights.",'||wwv_flow.LF||
'  "highlights" : "List project highlights",'||wwv_flow.LF||
'  "risk": "None | Low | Moderate | High"'||wwv_flow.LF||
'}'||wwv_flow.LF||
''||wwv_flow.LF||
'Mak';
wwv_flow_imp.g_varchar2_table(61) := 'e sure to accurately assess the project risk and provide a clear, easy-to-understand summary.  Do no';
wwv_flow_imp.g_varchar2_table(62) := 't include any prefix or suffix characters - only a JSON document.'' );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    sp_util.add';
wwv_flow_imp.g_varchar2_table(63) := '_ai_prompt (  '||wwv_flow.LF||
'        p_static_id     => ''RELEASE_SUMMARY'',   '||wwv_flow.LF||
'        p_description   => ''Used for';
wwv_flow_imp.g_varchar2_table(64) := ' generating a release summary.'', '||wwv_flow.LF||
'        p_prompt        => ''You are given details for a software d';
wwv_flow_imp.g_varchar2_table(65) := 'evelopment product release, in markdown format.  This includes basic release details along with all ';
wwv_flow_imp.g_varchar2_table(66) := 'the features included in the release, grouped by focus area. Please return a JSON document with the ';
wwv_flow_imp.g_varchar2_table(67) := 'following structure:'||wwv_flow.LF||
''||wwv_flow.LF||
'{'||wwv_flow.LF||
'  "summary": "Concise summary of the release",'||wwv_flow.LF||
'  "highlights": "List release';
wwv_flow_imp.g_varchar2_table(68) := ' highlights"'||wwv_flow.LF||
'}'||wwv_flow.LF||
''||wwv_flow.LF||
'Make sure to provide a clear, easy-to-understand summary.  Do not include any prefix';
wwv_flow_imp.g_varchar2_table(69) := ' or suffix characters - only a JSON document.'||wwv_flow.LF||
''||wwv_flow.LF||
'Summary: Extract key points to create a brief but acc';
wwv_flow_imp.g_varchar2_table(70) := 'urate summary of the release.  This can be 1 or 2 paragraphs depending on the size of the input.'||wwv_flow.LF||
''||wwv_flow.LF||
'Hi';
wwv_flow_imp.g_varchar2_table(71) := 'ghlights: List any release highlights, such as important features in the highlights section of the J';
wwv_flow_imp.g_varchar2_table(72) := 'SON.  Always include them in a JSON array.  If there are no highlights, simply add a single element ';
wwv_flow_imp.g_varchar2_table(73) := 'called "No Highlights".'' );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(47919416495201664618)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed settings and prompts'
,p_sequence=>860
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
