prompt --application/deployment/install/install_seed_resource_types
begin
--   Manifest
--     INSTALL: INSTALL-seed resource types
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into SP_RESOURCE_TYPES (ID, RESOURCE_TYPE, RESOURCE_DESCRIPTION, IS_DEFAULT_YN) values (1, ''M';
wwv_flow_imp.g_varchar2_table(2) := 'ain Developer'', ''Developer most responsible for the implementation, actual coding, of the project. T';
wwv_flow_imp.g_varchar2_table(3) := 'he main developer typically contributes the most code and coordinates other developer contributions.';
wwv_flow_imp.g_varchar2_table(4) := ''', ''N'');'||wwv_flow.LF||
'insert into SP_RESOURCE_TYPES (ID, RESOURCE_TYPE, RESOURCE_DESCRIPTION, IS_DEFAULT_YN) valu';
wwv_flow_imp.g_varchar2_table(5) := 'es (3, ''Project Manager'', ''Develops, maintains, and revises proposals for assigned projects includin';
wwv_flow_imp.g_varchar2_table(6) := 'g project objectives, technologies, systems, information specifications, timelines, funding, and sta';
wwv_flow_imp.g_varchar2_table(7) := 'ffing. Sets and tracks project milestones; manages and accounts for unforeseen delays, then realigns';
wwv_flow_imp.g_varchar2_table(8) := ' schedules and expectations as needed.'', ''N'');'||wwv_flow.LF||
'insert into SP_RESOURCE_TYPES (ID, RESOURCE_TYPE, RES';
wwv_flow_imp.g_varchar2_table(9) := 'OURCE_DESCRIPTION, IS_DEFAULT_YN) values (4, ''Requestor'', ''The customer or the person who is asking ';
wwv_flow_imp.g_varchar2_table(10) := 'for the feature or capability. The project is being performed at the request of this person.'', ''N'');';
wwv_flow_imp.g_varchar2_table(11) := ''||wwv_flow.LF||
'insert into SP_RESOURCE_TYPES (ID, RESOURCE_TYPE, RESOURCE_DESCRIPTION, IS_DEFAULT_YN) values (2, ''';
wwv_flow_imp.g_varchar2_table(12) := 'Architect'', ''A software architect is a computer programmer who makes project-specific software desig';
wwv_flow_imp.g_varchar2_table(13) := 'n choices, coordinates technical teams and selects and enforces technical coding standards when crea';
wwv_flow_imp.g_varchar2_table(14) := 'ting new programs or software to fulfill business goals.'', ''N'');'||wwv_flow.LF||
'insert into SP_RESOURCE_TYPES (ID, ';
wwv_flow_imp.g_varchar2_table(15) := 'RESOURCE_TYPE, RESOURCE_DESCRIPTION, IS_DEFAULT_YN) values (5, ''Functional Tester'', ''A functional te';
wwv_flow_imp.g_varchar2_table(16) := 'ster is someone who measures and monitors progress during each test to ensure that the application i';
wwv_flow_imp.g_varchar2_table(17) := 's tested, validated, and piloted on time and within budget, and that it meets or exceeds expectation';
wwv_flow_imp.g_varchar2_table(18) := 's. Review test, validation, and pilot results to ensure that they meet the entry and exit criteria.''';
wwv_flow_imp.g_varchar2_table(19) := ', ''N'');'||wwv_flow.LF||
'insert into SP_RESOURCE_TYPES (ID, RESOURCE_TYPE, RESOURCE_DESCRIPTION, IS_DEFAULT_YN) value';
wwv_flow_imp.g_varchar2_table(20) := 's (6, ''Contributing Developer'', ''A developer who is not the main developer but is contributing to th';
wwv_flow_imp.g_varchar2_table(21) := 'e development process for a specific project.'', ''N'');'||wwv_flow.LF||
'insert into SP_RESOURCE_TYPES (ID, RESOURCE_TY';
wwv_flow_imp.g_varchar2_table(22) := 'PE, RESOURCE_DESCRIPTION, IS_DEFAULT_YN) values (7, ''Researcher'', ''The Research Software Engineer wo';
wwv_flow_imp.g_varchar2_table(23) := 'rks with researchers to gain an understanding of the problems they face, and then develops, maintain';
wwv_flow_imp.g_varchar2_table(24) := 's and extends software to provide the answers.'', ''N'');'||wwv_flow.LF||
'insert into SP_RESOURCE_TYPES (ID, RESOURCE_T';
wwv_flow_imp.g_varchar2_table(25) := 'YPE, RESOURCE_DESCRIPTION, IS_DEFAULT_YN) values (8, ''UI Designer'', ''A user interface designer, UI d';
wwv_flow_imp.g_varchar2_table(26) := 'esigner, is someone who designs the graphical user interface of an app, website, or device that a hu';
wwv_flow_imp.g_varchar2_table(27) := 'man interacts with. For example, when you access a website or an app on your phone, there''''s usually';
wwv_flow_imp.g_varchar2_table(28) := ' a graphical interface that allows you to navigate and achieve your goal.'', ''N'');'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(152258629280967951203)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed resource types'
,p_sequence=>800
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
