prompt --application/deployment/install/install_sp_release_comments_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_release_comments table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_release_comments ('||wwv_flow.LF||
'    id                             number default on null to_numb';
wwv_flow_imp.g_varchar2_table(2) := 'er(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp';
wwv_flow_imp.g_varchar2_table(3) := '_release_comments_id_pk primary key,'||wwv_flow.LF||
'    release_id                     number'||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(4) := '              constraint sp_release_comm_proj_id_fk'||wwv_flow.LF||
'                                   references SP';
wwv_flow_imp.g_varchar2_table(5) := '_RELEASE_TRAINS on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    body                           clob,'||wwv_flow.LF||
'    body_html    ';
wwv_flow_imp.g_varchar2_table(6) := '                  clob,'||wwv_flow.LF||
'    body_no_images                 clob,'||wwv_flow.LF||
'    image_ref_id                   ';
wwv_flow_imp.g_varchar2_table(7) := 'number, '||wwv_flow.LF||
'    author_id                      number,'||wwv_flow.LF||
'    PRIVATE_YN                     varchar2(1 ch';
wwv_flow_imp.g_varchar2_table(8) := 'ar),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by                     var';
wwv_flow_imp.g_varchar2_table(9) := 'char2(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by          ';
wwv_flow_imp.g_varchar2_table(10) := '           varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_release_comments_i1 on sp_release_comment';
wwv_flow_imp.g_varchar2_table(11) := 's (release_id);'||wwv_flow.LF||
'create index sp_release_comments_i2 on sp_release_comments (author_id);'||wwv_flow.LF||
'create index';
wwv_flow_imp.g_varchar2_table(12) := ' sp_release_comments_i3 on sp_release_comments (image_ref_id);'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(44986834484223245076)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_release_comments table'
,p_sequence=>280
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
