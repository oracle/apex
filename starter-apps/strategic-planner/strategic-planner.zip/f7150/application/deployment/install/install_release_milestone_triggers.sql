prompt --application/deployment/install/install_release_milestone_triggers
begin
--   Manifest
--     INSTALL: INSTALL-release milestone triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_release_milestones_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_release_mi';
wwv_flow_imp.g_varchar2_table(2) := 'lestones'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_tags        varchar2(4000) := null;'||wwv_flow.LF||
'    l_changed_by  varcha';
wwv_flow_imp.g_varchar2_table(3) := 'r2(255)  := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new.created_';
wwv_flow_imp.g_varchar2_table(4) := 'by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'        if :new.original_milestone_date';
wwv_flow_imp.g_varchar2_table(5) := ' is null then'||wwv_flow.LF||
'            :new.original_milestone_date := :new.milestone_date;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(6) := 'nd if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_';
wwv_flow_imp.g_varchar2_table(7) := 'USER''),user);'||wwv_flow.LF||
'    :new.upper_milestone_name := upper(:new.milestone_name);'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- adjust tag';
wwv_flow_imp.g_varchar2_table(8) := ' data'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.tags is not null then'||wwv_flow.LF||
'        l_tags := trim(upper(:new.tags));'||wwv_flow.LF||
'        -- ';
wwv_flow_imp.g_varchar2_table(9) := 'remove multiple spaces'||wwv_flow.LF||
'        if instr(l_tags,''  '') > 0 then'||wwv_flow.LF||
'            for j in 1..10 loop '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(10) := '           l_tags := replace(l_tags,''  '','' ''); '||wwv_flow.LF||
'                if instr(l_tags,''  '') = 0 then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(11) := '              exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        for i in ';
wwv_flow_imp.g_varchar2_table(12) := '1..length(l_tags) loop'||wwv_flow.LF||
'            if i > 2 and substr(l_tags,i,1) = '' '' and substr(l_tags,i-1,1) !=';
wwv_flow_imp.g_varchar2_table(13) := ' '','' then'||wwv_flow.LF||
'               l_tags := substr(l_tags,1,i-1)||''-''||substr(l_tags,i+1);'||wwv_flow.LF||
'            end if';
wwv_flow_imp.g_varchar2_table(14) := ';'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        :new.tags := l_tags;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(15) := ''||wwv_flow.LF||
'    update sp_release_trains set updated = sysdate, updated_by = :new.updated_by where id = :new.re';
wwv_flow_imp.g_varchar2_table(16) := 'lease_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- change history tracking'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        insert into sp';
wwv_flow_imp.g_varchar2_table(17) := '_release_history'||wwv_flow.LF||
'            (release_id, attribute_column, change_type, new_value, changed_on, chan';
wwv_flow_imp.g_varchar2_table(18) := 'ged_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.release_id, ''RELEASE_MILESTONE'', ''CREATE'', :new.milestone_n';
wwv_flow_imp.g_varchar2_table(19) := 'ame, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        l_changed_by := lower(:new.up';
wwv_flow_imp.g_varchar2_table(20) := 'dated_by);'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.milestone_name,:new.milestone_na';
wwv_flow_imp.g_varchar2_table(21) := 'me) then'||wwv_flow.LF||
'           insert into sp_release_history'||wwv_flow.LF||
'               (release_id, attribute_column, cha';
wwv_flow_imp.g_varchar2_table(22) := 'nge_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'           values'||wwv_flow.LF||
'               (:new.relea';
wwv_flow_imp.g_varchar2_table(23) := 'se_id, ''RELEASE_MILESTONE'', ''UPDATE'', :old.milestone_name, :new.milestone_name, sysdate, l_changed_b';
wwv_flow_imp.g_varchar2_table(24) := 'y);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.milestone_start_date,:n';
wwv_flow_imp.g_varchar2_table(25) := 'ew.milestone_start_date) then'||wwv_flow.LF||
'           insert into sp_release_history'||wwv_flow.LF||
'               (release_id, ';
wwv_flow_imp.g_varchar2_table(26) := 'attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'           values'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(27) := '          (:new.release_id, ''RELEASE_MILESTONE_''||substr(:new.milestone_name,1,200)||''_START'', ''UPDA';
wwv_flow_imp.g_varchar2_table(28) := 'TE'', to_char(:old.milestone_start_date,''DD-MON-YYYY''), to_char(:new.milestone_start_date,''DD-MON-YYY';
wwv_flow_imp.g_varchar2_table(29) := 'Y''), sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:ol';
wwv_flow_imp.g_varchar2_table(30) := 'd.milestone_date,:new.milestone_date) then'||wwv_flow.LF||
'           insert into sp_release_history'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(31) := '(release_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(32) := ' values'||wwv_flow.LF||
'               (:new.release_id, ''RELEASE_MILESTONE_''||substr(:new.milestone_name,1,235), ''U';
wwv_flow_imp.g_varchar2_table(33) := 'PDATE'', to_char(:old.milestone_date,''DD-MON-YYYY''), to_char(:new.milestone_date,''DD-MON-YYYY''), sysd';
wwv_flow_imp.g_varchar2_table(34) := 'ate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.MIL';
wwv_flow_imp.g_varchar2_table(35) := 'ESTONE_COMPLETED_YN,:new.MILESTONE_COMPLETED_YN) then'||wwv_flow.LF||
'           insert into sp_release_history'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(36) := '           (release_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)';
wwv_flow_imp.g_varchar2_table(37) := ''||wwv_flow.LF||
'           values'||wwv_flow.LF||
'               (:new.release_id, ''RELEASE_MILESTONE_''||substr(:new.milestone_name';
wwv_flow_imp.g_varchar2_table(38) := ',1,225)||''_COMPLETED'', ''UPDATE'', :old.MILESTONE_COMPLETED_YN, :new.MILESTONE_COMPLETED_YN, sysdate, ';
wwv_flow_imp.g_varchar2_table(39) := 'l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- '||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.tags,:new.t';
wwv_flow_imp.g_varchar2_table(40) := 'ags) then'||wwv_flow.LF||
'           insert into sp_release_history'||wwv_flow.LF||
'               (release_id, attribute_column, ch';
wwv_flow_imp.g_varchar2_table(41) := 'ange_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'           values'||wwv_flow.LF||
'               (:new.rele';
wwv_flow_imp.g_varchar2_table(42) := 'ase_id, ''RELEASE_MILESTONE_''||substr(:new.milestone_name,1,225)||''_TAGS'', ''UPDATE'', :old.TAGS, :new.';
wwv_flow_imp.g_varchar2_table(43) := 'TAGS, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_release_milestones_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create o';
wwv_flow_imp.g_varchar2_table(44) := 'r replace trigger sp_release_milestones_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_release_milestones'||wwv_flow.LF||
'    for ea';
wwv_flow_imp.g_varchar2_table(45) := 'ch row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_release_history'||wwv_flow.LF||
'        (release_id, attribute_column, change_type, ';
wwv_flow_imp.g_varchar2_table(46) := 'old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.release_id, ''RELEASE_MILESTONE'', ''DELETE';
wwv_flow_imp.g_varchar2_table(47) := ''', :old.milestone_name, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'end ';
wwv_flow_imp.g_varchar2_table(48) := 'sp_release_milestones_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(45056630421329478925)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'release milestone triggers'
,p_sequence=>530
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
