prompt --application/deployment/install/install_sp_notification_subscriptions
begin
--   Manifest
--     INSTALL: INSTALL-sp_notification_subscriptions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_notification_subscriptions ('||wwv_flow.LF||
'    id                             number default on nu';
wwv_flow_imp.g_varchar2_table(2) := 'll to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   con';
wwv_flow_imp.g_varchar2_table(3) := 'straint sp_notification_subscriptions_pk primary key,'||wwv_flow.LF||
''||wwv_flow.LF||
'    team_member_id                 number not';
wwv_flow_imp.g_varchar2_table(4) := ' null'||wwv_flow.LF||
'                                   constraint sp_notification_sub_tm_fk'||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(5) := '             references sp_team_members (id)'||wwv_flow.LF||
'                                   on delete cascade,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(6) := '   notification_id                number not null'||wwv_flow.LF||
'                                   constraint sp_n';
wwv_flow_imp.g_varchar2_table(7) := 'otification_sub_notif_fk'||wwv_flow.LF||
'                                   references sp_notifications (id)'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(8) := '                            on delete cascade,'||wwv_flow.LF||
'    release_id                     number'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(9) := '                        constraint sp_notification_sub_release_fk'||wwv_flow.LF||
'                                  ';
wwv_flow_imp.g_varchar2_table(10) := ' references sp_release_trains (id)'||wwv_flow.LF||
'                                   on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(11) := 'opted_in_yn                    varchar2(1)    not null'||wwv_flow.LF||
'                                      constra';
wwv_flow_imp.g_varchar2_table(12) := 'int sp_notification_sub_opt_in_cc'||wwv_flow.LF||
'                                      check (opted_in_yn in (''Y'',''';
wwv_flow_imp.g_varchar2_table(13) := 'N'')),'||wwv_flow.LF||
'    frequency                      varchar2(30)   not null'||wwv_flow.LF||
'                                   ';
wwv_flow_imp.g_varchar2_table(14) := '   constraint sp_notification_sub_freq_cc'||wwv_flow.LF||
'                                      check (frequency in ';
wwv_flow_imp.g_varchar2_table(15) := '(''WEEKDAYS'',''WEEKLY'')),'||wwv_flow.LF||
'    last_sent                      date,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                 ';
wwv_flow_imp.g_varchar2_table(16) := '       date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated   ';
wwv_flow_imp.g_varchar2_table(17) := '                     date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
')';
wwv_flow_imp.g_varchar2_table(18) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index sp_notification_subscriptions_u1 on sp_notification_subscriptions (team_membe';
wwv_flow_imp.g_varchar2_table(19) := 'r_id, notification_id, nullif(release_id,1));'||wwv_flow.LF||
'create index sp_notification_subscriptions_i1 on sp_no';
wwv_flow_imp.g_varchar2_table(20) := 'tification_subscriptions (notification_id);'||wwv_flow.LF||
'create index sp_notification_subscriptions_i2 on sp_noti';
wwv_flow_imp.g_varchar2_table(21) := 'fication_subscriptions (release_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_notification_subscriptions_biu'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(22) := '  before insert or update'||wwv_flow.LF||
'    on sp_notification_subscriptions'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserti';
wwv_flow_imp.g_varchar2_table(23) := 'ng then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSI';
wwv_flow_imp.g_varchar2_table(24) := 'ON'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_';
wwv_flow_imp.g_varchar2_table(25) := 'context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'end sp_notification_subscriptions_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(40984554112249551753)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_notification_subscriptions'
,p_sequence=>370
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
