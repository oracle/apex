prompt --application/deployment/install/install_sp_comment_images_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_comment_images table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_comment_images ('||wwv_flow.LF||
'    id                 number default on null to_number(sys_guid(),';
wwv_flow_imp.g_varchar2_table(2) := ' ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                           constraint sp_comment_images_pk pri';
wwv_flow_imp.g_varchar2_table(3) := 'mary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    file_blob          blob               not null,'||wwv_flow.LF||
'    unique_filename    varchar2';
wwv_flow_imp.g_varchar2_table(4) := '(512 char) not null,'||wwv_flow.LF||
'    filename           varchar2(512 char), -- image.png for screensnaps'||wwv_flow.LF||
'    mim';
wwv_flow_imp.g_varchar2_table(5) := 'etype           varchar2(512 char),'||wwv_flow.LF||
'    blob_size          number,'||wwv_flow.LF||
'    image_ref_id       number    ';
wwv_flow_imp.g_varchar2_table(6) := '         not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created            date not null,'||wwv_flow.LF||
'    created_by         varchar2(255 ';
wwv_flow_imp.g_varchar2_table(7) := 'char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table sp_comment_images add constraint sp_comment_images_uk '||wwv_flow.LF||
'    unique (un';
wwv_flow_imp.g_varchar2_table(8) := 'ique_filename);'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_comment_images_i1 on sp_comment_images (image_ref_id);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(22327830867972846452)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_comment_images table and trigger'
,p_sequence=>285
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
