prompt --application/deployment/install/install_initiatives_table
begin
--   Manifest
--     INSTALL: INSTALL-initiatives table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3625873079247954169)
,p_install_id=>wwv_flow_imp.id(141180564419272860082)
,p_name=>'initiatives table'
,p_sequence=>180
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table sp_initiatives (',
'    id                             number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') ',
'                                   constraint sp_initiatives_id_pk primary key,',
'    focus_area_id                  number not null',
'                                   constraint sp_initiatives_focus_area_i_fk',
'                                   references sp_focus_areas on delete cascade,',
'    initiative                     varchar2(255 char) not null,',
'    objective                      varchar2(4000 char),',
'    sponsor_ID                     number',
'                                   constraint sp_initiatives_sponsor_fk',
'                                   references sp_team_members,',
'    --',
'    perma_link                     varchar2(4000 char),',
'    PRIMARY_URL                    varchar2(4000 char),',
'    status_scale                   varchar2(1) ',
'                                   constraint sp_initiative_status_scale_ck',
'                                   check (status_scale in (''A'',''B'',''C'',''D'',''E'')),',
'    --',
'    tags                           varchar2(4000 char),',
'    hidden_by_default_yn           varchar2(1 char),',
'    --',
'    image                          blob,',
'    image_name                     varchar2(512 char),',
'    image_mimetype                 varchar2(512 char),',
'    image_last_updated             date,',
'    --',
'    -- Archived, soft delete',
'    --',
'    archived_yn                    varchar2(1 char)',
'                                   constraint sp_initiatives_archived_ck',
'                                   check (archived_yn in (''Y'',''N'')),',
'    archived_date                  date,',
'    archived_by                    varchar2(255 char),',
'    --',
'    created                        date not null,',
'    created_by                     varchar2(255 char) not null,',
'    updated                        date not null,',
'    updated_by                     varchar2(255 char) not null',
')',
';',
'',
'create index sp_initiatives_i1 on sp_initiatives (focus_area_id);',
'create index sp_initiatives_i2 on sp_initiatives (sponsor_ID);',
'create index sp_initiatives_i3 on sp_initiatives (status_scale);',
'create unique index sp_initiatives_u1 on sp_initiatives (focus_area_id, initiative);',
'',
'alter table sp_initiatives add constraint sp_initiatives_scale_fk ',
'            foreign key (status_scale) references sp_project_scales;',
''))
);
wwv_flow_imp.component_end;
end;
/
