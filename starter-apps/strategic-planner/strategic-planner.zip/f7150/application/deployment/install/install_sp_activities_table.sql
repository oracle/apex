prompt --application/deployment/install/install_sp_activities_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_activities table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_activities ('||wwv_flow.LF||
'    id                             number default on null to_number(sys';
wwv_flow_imp.g_varchar2_table(2) := '_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_activ';
wwv_flow_imp.g_varchar2_table(3) := 'ities_pk '||wwv_flow.LF||
'                                   primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    activity_type_id               ';
wwv_flow_imp.g_varchar2_table(4) := 'number '||wwv_flow.LF||
'                                   constraint sp_activities_type_fk'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(5) := '           references sp_activity_types (id),'||wwv_flow.LF||
'    project_id                     number '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(6) := '                        constraint sp_activities_project_fk'||wwv_flow.LF||
'                                   refer';
wwv_flow_imp.g_varchar2_table(7) := 'ences sp_projects (id),'||wwv_flow.LF||
'    team_member_id                 number'||wwv_flow.LF||
'                                  ';
wwv_flow_imp.g_varchar2_table(8) := ' constraint sp_activities_person_fk'||wwv_flow.LF||
'                                   references sp_team_members (i';
wwv_flow_imp.g_varchar2_table(9) := 'd),'||wwv_flow.LF||
'    initiative_id                  number'||wwv_flow.LF||
'                                   constraint sp_activ';
wwv_flow_imp.g_varchar2_table(10) := 'ities_initiative_fk'||wwv_flow.LF||
'                                   references sp_initiatives (id),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    st';
wwv_flow_imp.g_varchar2_table(11) := 'art_date                     date not null,'||wwv_flow.LF||
'    end_date                       date not null,'||wwv_flow.LF||
'    co';
wwv_flow_imp.g_varchar2_table(12) := 'mments                       varchar2(4000 char),'||wwv_flow.LF||
'    ticket_number                  varchar2(50 cha';
wwv_flow_imp.g_varchar2_table(13) := 'r),'||wwv_flow.LF||
'    url                            varchar2(500 char),'||wwv_flow.LF||
'    activity_status                varcha';
wwv_flow_imp.g_varchar2_table(14) := 'r2(30 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    tags                           varchar2(4000 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created      ';
wwv_flow_imp.g_varchar2_table(15) := '                  date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(16) := ' updated                        date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char)';
wwv_flow_imp.g_varchar2_table(17) := ' not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_activities_i1 on sp_activities (activity_type_id);'||wwv_flow.LF||
'create index sp_ac';
wwv_flow_imp.g_varchar2_table(18) := 'tivities_i2 on sp_activities (project_id);'||wwv_flow.LF||
'create index sp_activities_i3 on sp_activities (team_memb';
wwv_flow_imp.g_varchar2_table(19) := 'er_id);'||wwv_flow.LF||
'create index sp_activities_i4 on sp_activities (end_date);'||wwv_flow.LF||
'create index sp_activities_i5 on ';
wwv_flow_imp.g_varchar2_table(20) := 'sp_activities (start_date);'||wwv_flow.LF||
'create index sp_activities_i6 on sp_activities (initiative_id);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(50991133439765885511)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_activities table'
,p_sequence=>570
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
