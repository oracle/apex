prompt --application/deployment/install/install_sp_project_sizes_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_project_sizes table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_project_sizes ('||wwv_flow.LF||
'    id                             number default on null to_numbe';
wwv_flow_imp.g_varchar2_table(2) := 'r(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_';
wwv_flow_imp.g_varchar2_table(3) := 'project_size_id_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    project_size                   varchar2(30 char) not null';
wwv_flow_imp.g_varchar2_table(4) := ','||wwv_flow.LF||
'    size_description               varchar2(100 char) not null,'||wwv_flow.LF||
'    effort_days                   ';
wwv_flow_imp.g_varchar2_table(5) := ' number not null,'||wwv_flow.LF||
'    include_yn                     varchar2(1 char) not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created  ';
wwv_flow_imp.g_varchar2_table(6) := '                      date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,';
wwv_flow_imp.g_varchar2_table(7) := ''||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 c';
wwv_flow_imp.g_varchar2_table(8) := 'har) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index sp_project_sizes_u1 on sp_project_sizes (project_size);'||wwv_flow.LF||
'creat';
wwv_flow_imp.g_varchar2_table(9) := 'e unique index sp_project_sizes_u2 on sp_project_sizes(EFFORT_DAYS);'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(45802041970265502712)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_project_sizes table'
,p_sequence=>210
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
