prompt --application/deployment/install/install_comment_views
begin
--   Manifest
--     INSTALL: INSTALL-comment views
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace view sp_initiative_comments_v as'||wwv_flow.LF||
'select id, '||wwv_flow.LF||
'       initiative_id,'||wwv_flow.LF||
'       sp_comme';
wwv_flow_imp.g_varchar2_table(2) := 'nt_util.replace_session_on_display(body, sys_context(''APEX$SESSION'', ''APP_SESSION'') ) body,'||wwv_flow.LF||
'       s';
wwv_flow_imp.g_varchar2_table(3) := 'p_comment_util.replace_session_on_display(body_html, sys_context(''APEX$SESSION'', ''APP_SESSION'') ) bo';
wwv_flow_imp.g_varchar2_table(4) := 'dy_html,'||wwv_flow.LF||
'       body_no_images, '||wwv_flow.LF||
'       author_id, private_yn,'||wwv_flow.LF||
'       image_ref_id,'||wwv_flow.LF||
'       created, ';
wwv_flow_imp.g_varchar2_table(5) := 'created_by, updated, updated_by'||wwv_flow.LF||
'  from sp_initiative_comments;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace view sp_init_focu';
wwv_flow_imp.g_varchar2_table(6) := 's_area_comments_v as'||wwv_flow.LF||
'select id, '||wwv_flow.LF||
'       init_focus_area_id,'||wwv_flow.LF||
'       sp_comment_util.replace_session_o';
wwv_flow_imp.g_varchar2_table(7) := 'n_display(body, sys_context(''APEX$SESSION'', ''APP_SESSION'') ) body,'||wwv_flow.LF||
'       sp_comment_util.replace_se';
wwv_flow_imp.g_varchar2_table(8) := 'ssion_on_display(body_html, sys_context(''APEX$SESSION'', ''APP_SESSION'') ) body_html,'||wwv_flow.LF||
'       body_no_i';
wwv_flow_imp.g_varchar2_table(9) := 'mages, '||wwv_flow.LF||
'       author_id, private_yn,'||wwv_flow.LF||
'       image_ref_id,'||wwv_flow.LF||
'       created, created_by, updated, upda';
wwv_flow_imp.g_varchar2_table(10) := 'ted_by'||wwv_flow.LF||
'  from sp_init_focus_area_comments;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace view sp_project_comments_v as'||wwv_flow.LF||
'select ';
wwv_flow_imp.g_varchar2_table(11) := 'id, '||wwv_flow.LF||
'       project_id,'||wwv_flow.LF||
'       sp_comment_util.replace_session_on_display(body, sys_context(''APEX$SE';
wwv_flow_imp.g_varchar2_table(12) := 'SSION'', ''APP_SESSION'') ) body,'||wwv_flow.LF||
'       sp_comment_util.replace_session_on_display(body_html, sys_cont';
wwv_flow_imp.g_varchar2_table(13) := 'ext(''APEX$SESSION'', ''APP_SESSION'') ) body_html,'||wwv_flow.LF||
'       body_no_images, '||wwv_flow.LF||
'       author_id, private_yn';
wwv_flow_imp.g_varchar2_table(14) := ','||wwv_flow.LF||
'       image_ref_id,'||wwv_flow.LF||
'       created, created_by, updated, updated_by'||wwv_flow.LF||
'  from sp_project_comments;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(15) := ''||wwv_flow.LF||
'create or replace view sp_task_comments_v as'||wwv_flow.LF||
'select id, '||wwv_flow.LF||
'       task_id,'||wwv_flow.LF||
'       sp_comment_util.rep';
wwv_flow_imp.g_varchar2_table(16) := 'lace_session_on_display(body, sys_context(''APEX$SESSION'', ''APP_SESSION'') ) body,'||wwv_flow.LF||
'       sp_comment_u';
wwv_flow_imp.g_varchar2_table(17) := 'til.replace_session_on_display(body_html, sys_context(''APEX$SESSION'', ''APP_SESSION'') ) body_html,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(18) := '     body_no_images, '||wwv_flow.LF||
'       author_id, private_yn,'||wwv_flow.LF||
'       image_ref_id,'||wwv_flow.LF||
'       created, created_by,';
wwv_flow_imp.g_varchar2_table(19) := ' updated, updated_by'||wwv_flow.LF||
'  from sp_task_comments;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace view sp_release_comments_v as'||wwv_flow.LF||
'sele';
wwv_flow_imp.g_varchar2_table(20) := 'ct id, '||wwv_flow.LF||
'       release_id,'||wwv_flow.LF||
'       sp_comment_util.replace_session_on_display(body, sys_context(''APEX';
wwv_flow_imp.g_varchar2_table(21) := '$SESSION'', ''APP_SESSION'') ) body,'||wwv_flow.LF||
'       sp_comment_util.replace_session_on_display(body_html, sys_c';
wwv_flow_imp.g_varchar2_table(22) := 'ontext(''APEX$SESSION'', ''APP_SESSION'') ) body_html,'||wwv_flow.LF||
'       body_no_images, '||wwv_flow.LF||
'       author_id, private';
wwv_flow_imp.g_varchar2_table(23) := '_yn,'||wwv_flow.LF||
'       image_ref_id,'||wwv_flow.LF||
'       created, created_by, updated, updated_by'||wwv_flow.LF||
'  from sp_release_comments';
wwv_flow_imp.g_varchar2_table(24) := ';';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(23777722229995146087)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'comment views'
,p_sequence=>736
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
