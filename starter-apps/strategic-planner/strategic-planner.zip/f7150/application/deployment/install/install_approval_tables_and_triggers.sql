prompt --application/deployment/install/install_approval_tables_and_triggers
begin
--   Manifest
--     INSTALL: INSTALL-Approval tables and triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_approval_types ('||wwv_flow.LF||
'    id                             number default on null to_number';
wwv_flow_imp.g_varchar2_table(2) := '(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_a';
wwv_flow_imp.g_varchar2_table(3) := 'pproval_types_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    display_seq                    number             not null,';
wwv_flow_imp.g_varchar2_table(4) := ''||wwv_flow.LF||
'    approval_type                  varchar2(30 char)  not null, -- DEVELOPMENT, RELEASE INCLUSION '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(5) := '    description                    varchar2(4000 char),'||wwv_flow.LF||
'    active_yn                      varchar2(';
wwv_flow_imp.g_varchar2_table(6) := '1 char) default on null ''Y'''||wwv_flow.LF||
'                                   constraint sp_approval_types_active_c';
wwv_flow_imp.g_varchar2_table(7) := 'c'||wwv_flow.LF||
'                                   check (active_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created             ';
wwv_flow_imp.g_varchar2_table(8) := '           date                not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char)  not ';
wwv_flow_imp.g_varchar2_table(9) := 'null,'||wwv_flow.LF||
'    updated                        date                not null,'||wwv_flow.LF||
'    updated_by               ';
wwv_flow_imp.g_varchar2_table(10) := '      varchar2(255 char)  not null'||wwv_flow.LF||
');'||wwv_flow.LF||
'alter table sp_approval_types add constraint sp_approval_types';
wwv_flow_imp.g_varchar2_table(11) := '_uk'||wwv_flow.LF||
'    unique (approval_type);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_approval_types_biu'||wwv_flow.LF||
'    before insert o';
wwv_flow_imp.g_varchar2_table(12) := 'r update'||wwv_flow.LF||
'    on sp_approval_types'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created ';
wwv_flow_imp.g_varchar2_table(13) := ':= sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    en';
wwv_flow_imp.g_varchar2_table(14) := 'd if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_U';
wwv_flow_imp.g_varchar2_table(15) := 'SER''),user);'||wwv_flow.LF||
'end sp_approval_types_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_initiative_approvals ('||wwv_flow.LF||
'    id           ';
wwv_flow_imp.g_varchar2_table(16) := '                  number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(17) := '                                   constraint sp_initiative_approvals_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    ini';
wwv_flow_imp.g_varchar2_table(18) := 'tiative_id                  number'||wwv_flow.LF||
'                                   constraint sp_initiative_appro';
wwv_flow_imp.g_varchar2_table(19) := 'vals_init_fk'||wwv_flow.LF||
'                                   references sp_initiatives on delete cascade,'||wwv_flow.LF||
'    app';
wwv_flow_imp.g_varchar2_table(20) := 'roval_type_id               number  not null'||wwv_flow.LF||
'                                   constraint sp_initia';
wwv_flow_imp.g_varchar2_table(21) := 'tive_approvals_apptype_fk'||wwv_flow.LF||
'                                   references sp_approval_types,   '||wwv_flow.LF||
'    ac';
wwv_flow_imp.g_varchar2_table(22) := 'tive_yn                      varchar2(1 char) default on null ''Y'''||wwv_flow.LF||
'                                  ';
wwv_flow_imp.g_varchar2_table(23) := ' constraint sp_initiative_approvals_active_cc'||wwv_flow.LF||
'                                   check (active_yn in';
wwv_flow_imp.g_varchar2_table(24) := ' (''Y'',''N'')),           '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date                not null,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(25) := 'created_by                     varchar2(255 char)  not null,'||wwv_flow.LF||
'    updated                        date';
wwv_flow_imp.g_varchar2_table(26) := '                not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char)  not null'||wwv_flow.LF||
');'||wwv_flow.LF||
'alter t';
wwv_flow_imp.g_varchar2_table(27) := 'able sp_initiative_approvals add constraint sp_initiative_approvals_uk'||wwv_flow.LF||
'    unique (initiative_id, ap';
wwv_flow_imp.g_varchar2_table(28) := 'proval_type_id);'||wwv_flow.LF||
'create index sp_initiative_approvals_i1 on sp_initiative_approvals (approval_type_i';
wwv_flow_imp.g_varchar2_table(29) := 'd);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_initiative_approvals_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_ini';
wwv_flow_imp.g_varchar2_table(30) := 'tiative_approvals'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_old_value   varchar2(4000) := null;'||wwv_flow.LF||
'    l_new_value';
wwv_flow_imp.g_varchar2_table(31) := '   varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new';
wwv_flow_imp.g_varchar2_table(32) := '.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated :';
wwv_flow_imp.g_varchar2_table(33) := '= sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(34) := '-- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_initiatives set updated = sysdate, updated_by = :new.upda';
wwv_flow_imp.g_varchar2_table(35) := 'ted_by where id = :new.initiative_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        for';
wwv_flow_imp.g_varchar2_table(36) := ' c1 in (select approval_type r from sp_approval_types x where x.id = :new.approval_type_id) loop l_n';
wwv_flow_imp.g_varchar2_table(37) := 'ew_value := c1.r; end loop; '||wwv_flow.LF||
'        insert into sp_initiative_history '||wwv_flow.LF||
'            (initiative_id, ';
wwv_flow_imp.g_varchar2_table(38) := 'attribute_column, change_type, new_value, changed_on, changed_by) '||wwv_flow.LF||
'        values '||wwv_flow.LF||
'            (:new';
wwv_flow_imp.g_varchar2_table(39) := '.initiative_id, ''INITIATIVE_APPROVAL'', ''CREATE'', l_new_value||'' (''||case when :new.active_yn = ''Y'' t';
wwv_flow_imp.g_varchar2_table(40) := 'hen ''Active'' else ''Inactive'' end||'')'', sysdate, lower(:new.created_by)); '||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(41) := '      if not sp_value_compare.is_equal(:old.approval_type_id,:new.approval_type_id) or'||wwv_flow.LF||
'           no';
wwv_flow_imp.g_varchar2_table(42) := 't sp_value_compare.is_equal(:old.active_yn,:new.active_yn) then'||wwv_flow.LF||
'            for c1 in (select approv';
wwv_flow_imp.g_varchar2_table(43) := 'al_type r from sp_approval_types x where x.id = :old.approval_type_id) loop l_old_value := c1.r; end';
wwv_flow_imp.g_varchar2_table(44) := ' loop;'||wwv_flow.LF||
'            for c1 in (select approval_type r from sp_approval_types x where x.id = :new.appr';
wwv_flow_imp.g_varchar2_table(45) := 'oval_type_id) loop l_new_value := c1.r; end loop; '||wwv_flow.LF||
'            insert into sp_initiative_history'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(46) := '             (initiative_id, attribute_column, change_type, old_value, new_value,changed_on, changed';
wwv_flow_imp.g_varchar2_table(47) := '_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.initiative_id, ''INITIATIVE_APPROVAL'', ''UPDATE'', '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(48) := '            l_old_value||'' (''||case when :old.active_yn = ''Y'' then ''Active'' else ''Inactive'' end||'')''';
wwv_flow_imp.g_varchar2_table(49) := ', '||wwv_flow.LF||
'                 l_new_value||'' (''||case when :new.active_yn = ''Y'' then ''Active'' else ''Inactive'' ';
wwv_flow_imp.g_varchar2_table(50) := 'end||'')'', '||wwv_flow.LF||
'                 sysdate, lower(:new.updated_by));'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_ini';
wwv_flow_imp.g_varchar2_table(51) := 'tiative_approvals_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger sp_initiative_approvals_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(52) := 'on sp_initiative_approvals'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_old_value   varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(53) := '    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_initiatives set updated = sysdate, updated_by ';
wwv_flow_imp.g_varchar2_table(54) := '= :old.updated_by where id = :old.initiative_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for c1 in (select approval_type r from s';
wwv_flow_imp.g_varchar2_table(55) := 'p_approval_types x where x.id = :old.approval_type_id) loop l_old_value := c1.r; end loop; '||wwv_flow.LF||
'    inse';
wwv_flow_imp.g_varchar2_table(56) := 'rt into sp_initiative_history'||wwv_flow.LF||
'        (initiative_id, attribute_column, change_type, old_value, chan';
wwv_flow_imp.g_varchar2_table(57) := 'ged_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.initiative_id, ''INITIATIVE_APPROVAL'', ''DELETE'', '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(58) := '   l_old_value||'' (''||case when :old.active_yn = ''Y'' then ''Active'' else ''Inactive'' end||'')'', sysdate';
wwv_flow_imp.g_varchar2_table(59) := ', lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'end sp_initiative_approvals_bd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(60) := ''||wwv_flow.LF||
'create table sp_initiative_approval_chain ('||wwv_flow.LF||
'    id                             number default on nu';
wwv_flow_imp.g_varchar2_table(61) := 'll to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   con';
wwv_flow_imp.g_varchar2_table(62) := 'straint sp_initiative_approval_chain_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    initiative_approval_id         numbe';
wwv_flow_imp.g_varchar2_table(63) := 'r  not null'||wwv_flow.LF||
'                                   constraint sp_initiative_approval_chain_apptype_fk'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(64) := '                                 references sp_initiative_approvals,              '||wwv_flow.LF||
'    team_member_i';
wwv_flow_imp.g_varchar2_table(65) := 'd                 number'||wwv_flow.LF||
'                                   constraint sp_initiative_approval_chain_';
wwv_flow_imp.g_varchar2_table(66) := 'tm_fk'||wwv_flow.LF||
'                                   references sp_team_members,'||wwv_flow.LF||
'    approval_seq               ';
wwv_flow_imp.g_varchar2_table(67) := '    number not null,'||wwv_flow.LF||
'    active_yn                      varchar2(1 char) default on null ''Y'''||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(68) := '                            constraint sp_initiative_approval_chain_active_cc'||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(69) := '             check (active_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    alternate_team_member_id       number'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(70) := '                      constraint sp_project_approval_chain_alt_tm_fk'||wwv_flow.LF||
'                               ';
wwv_flow_imp.g_varchar2_table(71) := '    references sp_team_members,'||wwv_flow.LF||
'    alternate_start_date           date,'||wwv_flow.LF||
'    alternate_end_date     ';
wwv_flow_imp.g_varchar2_table(72) := '        date,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date                not null,'||wwv_flow.LF||
'    created_by';
wwv_flow_imp.g_varchar2_table(73) := '                     varchar2(255 char)  not null,'||wwv_flow.LF||
'    updated                        date          ';
wwv_flow_imp.g_varchar2_table(74) := '      not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char)  not null'||wwv_flow.LF||
');'||wwv_flow.LF||
'alter table sp_in';
wwv_flow_imp.g_varchar2_table(75) := 'itiative_approval_chain add constraint sp_initiative_approval_chain_uk1'||wwv_flow.LF||
'    unique (initiative_appro';
wwv_flow_imp.g_varchar2_table(76) := 'val_id, team_member_id);'||wwv_flow.LF||
'alter table sp_initiative_approval_chain add constraint sp_initiative_appro';
wwv_flow_imp.g_varchar2_table(77) := 'val_chain_uk2'||wwv_flow.LF||
'    unique (initiative_approval_id, approval_seq);'||wwv_flow.LF||
'create index sp_initiative_approval';
wwv_flow_imp.g_varchar2_table(78) := '_chain_i1 on sp_initiative_approval_chain (team_member_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_initiative';
wwv_flow_imp.g_varchar2_table(79) := '_approval_chain_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_initiative_approval_chain'||wwv_flow.LF||
'    for each row';
wwv_flow_imp.g_varchar2_table(80) := ''||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_initiative_id  number;'||wwv_flow.LF||
'    l_approval_type  varchar2(4000) := null;'||wwv_flow.LF||
'    l_old_value  ';
wwv_flow_imp.g_varchar2_table(81) := '    varchar2(4000) := null;'||wwv_flow.LF||
'    l_new_value      varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then';
wwv_flow_imp.g_varchar2_table(82) := ''||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''AP';
wwv_flow_imp.g_varchar2_table(83) := 'P_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context';
wwv_flow_imp.g_varchar2_table(84) := '(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.alternate_start_date := trunc(:new.alternate_star';
wwv_flow_imp.g_varchar2_table(85) := 't_date);'||wwv_flow.LF||
'    :new.alternate_end_date   := trunc(:new.alternate_end_date);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent';
wwv_flow_imp.g_varchar2_table(86) := ' table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_initiative_approvals set updated = sysdate, updated_by = :old.updated_by';
wwv_flow_imp.g_varchar2_table(87) := ' where id = :old.initiative_approval_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(88) := 'for c1 in (select x.initiative_id, t.approval_type '||wwv_flow.LF||
'                     from sp_initiative_approval';
wwv_flow_imp.g_varchar2_table(89) := 's x, sp_approval_types t '||wwv_flow.LF||
'                    where x.id = :new.initiative_approval_id'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(90) := '         and x.approval_type_id = t.id'||wwv_flow.LF||
'                  ) loop l_initiative_id := c1.initiative_id;';
wwv_flow_imp.g_varchar2_table(91) := ' l_approval_type := c1.approval_type; end loop;     '||wwv_flow.LF||
'        for c1 in (select lower(email) r from S';
wwv_flow_imp.g_varchar2_table(92) := 'P_TEAM_MEMBERS x where x.id = :new.team_member_id) loop l_new_value := :new.approval_seq||''-''||c1.r;';
wwv_flow_imp.g_varchar2_table(93) := ' end loop;'||wwv_flow.LF||
'        insert into sp_initiative_history '||wwv_flow.LF||
'            (initiative_id, attribute_column, ';
wwv_flow_imp.g_varchar2_table(94) := 'change_type, new_value, changed_on, changed_by) '||wwv_flow.LF||
'        values '||wwv_flow.LF||
'            (l_initiative_id, ''INIT';
wwv_flow_imp.g_varchar2_table(95) := 'IATIVE_APPROVAL_CHAIN'', ''CREATE'', l_approval_type||'' - ''||l_new_value, sysdate, lower(:new.created_b';
wwv_flow_imp.g_varchar2_table(96) := 'y)); '||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.team_member_id,:new.team';
wwv_flow_imp.g_varchar2_table(97) := '_member_id) or'||wwv_flow.LF||
'               sp_value_compare.is_equal(:old.approval_seq,:new.approval_seq) or'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(98) := '           sp_value_compare.is_equal(:old.active_yn,:new.active_yn) or'||wwv_flow.LF||
'               sp_value_compa';
wwv_flow_imp.g_varchar2_table(99) := 're.is_equal(:old.alternate_team_member_id,:new.alternate_team_member_id) or'||wwv_flow.LF||
'               sp_value_';
wwv_flow_imp.g_varchar2_table(100) := 'compare.is_equal(:old.alternate_start_date,:new.alternate_start_date) or'||wwv_flow.LF||
'               sp_value_com';
wwv_flow_imp.g_varchar2_table(101) := 'pare.is_equal(:old.alternate_end_date,:new.alternate_end_date)'||wwv_flow.LF||
'        then'||wwv_flow.LF||
'            for c1 in (s';
wwv_flow_imp.g_varchar2_table(102) := 'elect x.initiative_id, t.approval_type '||wwv_flow.LF||
'                         from sp_initiative_approvals x, sp_';
wwv_flow_imp.g_varchar2_table(103) := 'approval_types t '||wwv_flow.LF||
'                        where x.id = :new.initiative_approval_id'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(104) := '         and x.approval_type_id = t.id'||wwv_flow.LF||
'                      ) loop l_initiative_id := c1.initiative';
wwv_flow_imp.g_varchar2_table(105) := '_id; l_approval_type := c1.approval_type; end loop;   '||wwv_flow.LF||
'            for c1 in (select lower(email) r ';
wwv_flow_imp.g_varchar2_table(106) := 'from SP_TEAM_MEMBERS x where x.id = :old.team_member_id) loop l_old_value := :old.approval_seq||''-''|';
wwv_flow_imp.g_varchar2_table(107) := '|c1.r; end loop;'||wwv_flow.LF||
'            for c1 in (select lower(email) r from SP_TEAM_MEMBERS x where x.id = :n';
wwv_flow_imp.g_varchar2_table(108) := 'ew.team_member_id) loop l_new_value := :new.approval_seq||''-''||c1.r; end loop;'||wwv_flow.LF||
'            if sp_val';
wwv_flow_imp.g_varchar2_table(109) := 'ue_compare.is_equal(:old.alternate_team_member_id,:new.alternate_team_member_id) then'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(110) := '  for c1 in (select lower(email) r from SP_TEAM_MEMBERS x where x.id = :old.alternate_team_member_id';
wwv_flow_imp.g_varchar2_table(111) := ') loop '||wwv_flow.LF||
'                           l_old_value := l_old_value || '' [alternate ''||c1.r||'' ''||case whe';
wwv_flow_imp.g_varchar2_table(112) := 'n :old.alternate_start_date is not null then :old.alternate_start_date||'' thru '' end|| '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(113) := '                                                                        case when :old.alternate_end';
wwv_flow_imp.g_varchar2_table(114) := '_date is not null then :old.alternate_end_date end||'']''; end loop;'||wwv_flow.LF||
'                for c1 in (select';
wwv_flow_imp.g_varchar2_table(115) := ' lower(email) r from SP_TEAM_MEMBERS x where x.id = :new.alternate_team_member_id) loop '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(116) := '                l_new_value := l_new_value || '' [alternate ''||c1.r||'' ''||case when :new.alternate_st';
wwv_flow_imp.g_varchar2_table(117) := 'art_date is not null then :new.alternate_start_date||'' thru '' end|| '||wwv_flow.LF||
'                               ';
wwv_flow_imp.g_varchar2_table(118) := '                                                     case when :new.alternate_end_date is not null t';
wwv_flow_imp.g_varchar2_table(119) := 'hen :new.alternate_end_date end||'']''; end loop;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            insert into sp_initi';
wwv_flow_imp.g_varchar2_table(120) := 'ative_history'||wwv_flow.LF||
'                (initiative_id, attribute_column, change_type, old_value, new_value,ch';
wwv_flow_imp.g_varchar2_table(121) := 'anged_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (l_initiative_id, ''INITIATIVE_APPROVAL_CHAI';
wwv_flow_imp.g_varchar2_table(122) := 'N'', ''UPDATE'', '||wwv_flow.LF||
'                 l_approval_type||'' - ''||l_old_value||'' (''||decode(:old.active_yn,''Y''';
wwv_flow_imp.g_varchar2_table(123) := ',''Active'',''Inactive'')||'')'', '||wwv_flow.LF||
'                 l_approval_type||'' - ''||l_new_value||'' (''||decode(:new';
wwv_flow_imp.g_varchar2_table(124) := '.active_yn,''Y'',''Active'',''Inactive'')||'')'', '||wwv_flow.LF||
'                 sysdate, lower(:new.updated_by));'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(125) := '  end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_initiative_approval_chain_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger sp_initiativ';
wwv_flow_imp.g_varchar2_table(126) := 'e_approval_chain_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_initiative_approval_chain'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(127) := '   l_initiative_id  number;'||wwv_flow.LF||
'    l_approval_type  varchar2(4000) := null;'||wwv_flow.LF||
'    l_old_value      varcha';
wwv_flow_imp.g_varchar2_table(128) := 'r2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_initiative_approvals s';
wwv_flow_imp.g_varchar2_table(129) := 'et updated = sysdate, updated_by = :old.updated_by where id = :old.initiative_approval_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(130) := '  -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for c1 in (select x.initiative_id, t.approval_type '||wwv_flow.LF||
'                 from sp';
wwv_flow_imp.g_varchar2_table(131) := '_initiative_approvals x, sp_approval_types t '||wwv_flow.LF||
'                where x.id = :old.initiative_approval_';
wwv_flow_imp.g_varchar2_table(132) := 'id'||wwv_flow.LF||
'                  and x.approval_type_id = t.id'||wwv_flow.LF||
'              ) loop l_initiative_id := c1.initia';
wwv_flow_imp.g_varchar2_table(133) := 'tive_id; l_approval_type := c1.approval_type; end loop; '||wwv_flow.LF||
'    for c1 in (select lower(email) r from S';
wwv_flow_imp.g_varchar2_table(134) := 'P_TEAM_MEMBERS x where x.id = :old.team_member_id) loop l_old_value := :old.approval_seq||''-''||c1.r;';
wwv_flow_imp.g_varchar2_table(135) := ' end loop;'||wwv_flow.LF||
'    insert into sp_initiative_history'||wwv_flow.LF||
'        (initiative_id, attribute_column, change_ty';
wwv_flow_imp.g_varchar2_table(136) := 'pe, old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (l_initiative_id, ''INITIATIVE_APPROVAL'', ''';
wwv_flow_imp.g_varchar2_table(137) := 'DELETE'', '||wwv_flow.LF||
'         l_approval_type||'' - ''||l_old_value||'' (''||decode(:old.active_yn,''Y'',''Active'',''In';
wwv_flow_imp.g_varchar2_table(138) := 'active'')||'')'', '||wwv_flow.LF||
'         sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'end';
wwv_flow_imp.g_varchar2_table(139) := ' sp_initiative_approval_chain_bd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_project_approvals ('||wwv_flow.LF||
'    id                    ';
wwv_flow_imp.g_varchar2_table(140) := '         number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(141) := '                          constraint sp_project_approvals_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    approval_type_i';
wwv_flow_imp.g_varchar2_table(142) := 'd               number  not null'||wwv_flow.LF||
'                                   constraint sp_project_approvals_';
wwv_flow_imp.g_varchar2_table(143) := 'apptype_fk'||wwv_flow.LF||
'                                   references sp_approval_types, '||wwv_flow.LF||
'    project_id         ';
wwv_flow_imp.g_varchar2_table(144) := '            number  not null'||wwv_flow.LF||
'                                   constraint sp_project_approvals_proj';
wwv_flow_imp.g_varchar2_table(145) := '_fk'||wwv_flow.LF||
'                                   references sp_projects on delete cascade,'||wwv_flow.LF||
'    submitted_by_te';
wwv_flow_imp.g_varchar2_table(146) := 'am_member_id    number  not null'||wwv_flow.LF||
'                                   constraint sp_project_approvals_';
wwv_flow_imp.g_varchar2_table(147) := 'subm_fk'||wwv_flow.LF||
'                                   references sp_team_members,'||wwv_flow.LF||
'    justification            ';
wwv_flow_imp.g_varchar2_table(148) := '      varchar2(4000)  not null,'||wwv_flow.LF||
'    submitted                      date  not null,'||wwv_flow.LF||
'    initiative_ap';
wwv_flow_imp.g_varchar2_table(149) := 'proval_id         number'||wwv_flow.LF||
'                                   constraint sp_project_approvals_chain_fk';
wwv_flow_imp.g_varchar2_table(150) := ''||wwv_flow.LF||
'                                   references sp_initiative_approvals,'||wwv_flow.LF||
'    status                  ';
wwv_flow_imp.g_varchar2_table(151) := '       varchar2(30)  default on null ''PENDING'', -- Pending, Withdrawn, Clarification Requested, Appr';
wwv_flow_imp.g_varchar2_table(152) := 'oved, Rejected'||wwv_flow.LF||
'    withdrawn_by_team_member_id    number'||wwv_flow.LF||
'                                   constrai';
wwv_flow_imp.g_varchar2_table(153) := 'nt sp_project_approvals_withd_fk'||wwv_flow.LF||
'                                   references sp_team_members,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(154) := '--'||wwv_flow.LF||
'    updated                        date                not null,'||wwv_flow.LF||
'    updated_by                  ';
wwv_flow_imp.g_varchar2_table(155) := '   varchar2(255 char)  not null'||wwv_flow.LF||
');'||wwv_flow.LF||
'create index sp_project_approvals_i1 on sp_project_approvals (app';
wwv_flow_imp.g_varchar2_table(156) := 'roval_type_id);'||wwv_flow.LF||
'create index sp_project_approvals_i2 on sp_project_approvals (project_id);'||wwv_flow.LF||
'create in';
wwv_flow_imp.g_varchar2_table(157) := 'dex sp_project_approvals_i3 on sp_project_approvals (submitted_by_team_member_id);'||wwv_flow.LF||
'create index sp_p';
wwv_flow_imp.g_varchar2_table(158) := 'roject_approvals_i4 on sp_project_approvals (initiative_approval_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_';
wwv_flow_imp.g_varchar2_table(159) := 'project_approvals_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_project_approvals'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'decla';
wwv_flow_imp.g_varchar2_table(160) := 're'||wwv_flow.LF||
'    l_old_value   varchar2(4000) := null;'||wwv_flow.LF||
'    l_new_value   varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if ';
wwv_flow_imp.g_varchar2_table(161) := 'inserting then'||wwv_flow.LF||
'        :new.submitted := sysdate;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.';
wwv_flow_imp.g_varchar2_table(162) := 'updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent tabl';
wwv_flow_imp.g_varchar2_table(163) := 'e'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_projects set updated = sysdate, updated_by = :new.updated_by where id = :new.';
wwv_flow_imp.g_varchar2_table(164) := 'project_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        for c1 in (select approval_t';
wwv_flow_imp.g_varchar2_table(165) := 'ype x from sp_approval_types t where t.id = :new.approval_type_id) loop l_new_value := c1.x; end loo';
wwv_flow_imp.g_varchar2_table(166) := 'p;'||wwv_flow.LF||
'        insert into sp_project_history'||wwv_flow.LF||
'            (project_id, attribute_column, change_type, ne';
wwv_flow_imp.g_varchar2_table(167) := 'w_value, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.project_id, ''APPROVAL'', ''CREATE'', ';
wwv_flow_imp.g_varchar2_table(168) := 'l_new_value, sysdate, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating the';
wwv_flow_imp.g_varchar2_table(169) := 'n'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.status,:new.status) then'||wwv_flow.LF||
'            for c1 in (sele';
wwv_flow_imp.g_varchar2_table(170) := 'ct approval_type x from sp_approval_types t where t.id = :new.approval_type_id) loop l_new_value := ';
wwv_flow_imp.g_varchar2_table(171) := 'c1.x; end loop;'||wwv_flow.LF||
'            insert into sp_project_history'||wwv_flow.LF||
'                (project_id, attribute_co';
wwv_flow_imp.g_varchar2_table(172) := 'lumn, change_type, new_value, changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.proje';
wwv_flow_imp.g_varchar2_table(173) := 'ct_id, ''APPROVAL'', ''UPDATE'', l_new_value||'' - ''||:new.status, sysdate, coalesce(sys_context(''APEX$SE';
wwv_flow_imp.g_varchar2_table(174) := 'SSION'',''APP_USER''),user));'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_project_approvals_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or rep';
wwv_flow_imp.g_varchar2_table(175) := 'lace trigger sp_project_approvals_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_project_approvals'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(176) := 'declare'||wwv_flow.LF||
'    l_old_value   varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(177) := 'update sp_projects set updated = sysdate, updated_by = :old.updated_by where id = :old.project_id;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(178) := '   --'||wwv_flow.LF||
'    for c1 in (select approval_type x from sp_approval_types t where t.id = :old.approval_type';
wwv_flow_imp.g_varchar2_table(179) := '_id) loop l_old_value := c1.x; end loop;'||wwv_flow.LF||
'    insert into sp_project_history'||wwv_flow.LF||
'        (project_id, att';
wwv_flow_imp.g_varchar2_table(180) := 'ribute_column, change_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.project_id, ';
wwv_flow_imp.g_varchar2_table(181) := '''APPROVAL'', ''DELETE'', l_old_value, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),us';
wwv_flow_imp.g_varchar2_table(182) := 'er)));'||wwv_flow.LF||
'end sp_project_approvals_bd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_project_approval_chain ('||wwv_flow.LF||
'    id              ';
wwv_flow_imp.g_varchar2_table(183) := '               number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(184) := '                                constraint sp_project_approval_chain_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    proj';
wwv_flow_imp.g_varchar2_table(185) := 'ect_approval_id            number  not null'||wwv_flow.LF||
'                                   constraint sp_project';
wwv_flow_imp.g_varchar2_table(186) := '_approval_chain_projapp_fk'||wwv_flow.LF||
'                                   references sp_project_approvals on del';
wwv_flow_imp.g_varchar2_table(187) := 'ete cascade,'||wwv_flow.LF||
'    initiative_approval_chain_id   number'||wwv_flow.LF||
'                                   constraint';
wwv_flow_imp.g_varchar2_table(188) := ' sp_project_approval_chain_iac_fk'||wwv_flow.LF||
'                                   references sp_initiative_approv';
wwv_flow_imp.g_varchar2_table(189) := 'al_chain,'||wwv_flow.LF||
'    team_member_id                 number  not null'||wwv_flow.LF||
'                                   con';
wwv_flow_imp.g_varchar2_table(190) := 'straint sp_project_approval_chain_tm_fk'||wwv_flow.LF||
'                                   references sp_team_member';
wwv_flow_imp.g_varchar2_table(191) := 's,'||wwv_flow.LF||
'    status                         varchar2(30 char)  default on null ''PENDING'', -- Pending, With';
wwv_flow_imp.g_varchar2_table(192) := 'drawn, Clarification Requested, Approved, Rejected'||wwv_flow.LF||
'    last_status_on                 date          ';
wwv_flow_imp.g_varchar2_table(193) := '     default on null sysdate,'||wwv_flow.LF||
'    comments                       varchar2(4000),  -- not null if cla';
wwv_flow_imp.g_varchar2_table(194) := 'rification or rejected'||wwv_flow.LF||
'    response                       varchar2(4000),'||wwv_flow.LF||
'    response_by_team_membe';
wwv_flow_imp.g_varchar2_table(195) := 'r_id     number'||wwv_flow.LF||
'                                   constraint sp_project_approval_chain_resp_fk'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(196) := '                               references sp_team_members,'||wwv_flow.LF||
'    responded_on                   date,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(197) := '    final_yn                       varchar2(1 char)'||wwv_flow.LF||
'                                      default on';
wwv_flow_imp.g_varchar2_table(198) := ' null ''Y'''||wwv_flow.LF||
'                                      constraint sp_project_approval_chain_final_cc'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(199) := '                                check (final_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                   ';
wwv_flow_imp.g_varchar2_table(200) := '     date                not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char)  not null,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(201) := '    updated                        date                not null,'||wwv_flow.LF||
'    updated_by                     ';
wwv_flow_imp.g_varchar2_table(202) := 'varchar2(255 char)  not null'||wwv_flow.LF||
');'||wwv_flow.LF||
'create index sp_project_approval_chain_i1 on sp_project_approval_cha';
wwv_flow_imp.g_varchar2_table(203) := 'in (project_approval_id);'||wwv_flow.LF||
'create index sp_project_approval_chain_i2 on sp_project_approval_chain (in';
wwv_flow_imp.g_varchar2_table(204) := 'itiative_approval_chain_id);'||wwv_flow.LF||
'create index sp_project_approval_chain_i3 on sp_project_approval_chain ';
wwv_flow_imp.g_varchar2_table(205) := '(team_member_id);'||wwv_flow.LF||
'create index sp_project_approval_chain_i4 on sp_project_approval_chain (response_b';
wwv_flow_imp.g_varchar2_table(206) := 'y_team_member_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_project_approval_chain_biu'||wwv_flow.LF||
'    before insert or upd';
wwv_flow_imp.g_varchar2_table(207) := 'ate'||wwv_flow.LF||
'    on sp_project_approval_chain'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.creat';
wwv_flow_imp.g_varchar2_table(208) := 'ed := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(209) := ' end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''AP';
wwv_flow_imp.g_varchar2_table(210) := 'P_USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- no need to update project table nor history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'end sp_project_appr';
wwv_flow_imp.g_varchar2_table(211) := 'oval_chain_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(51780881287912418571)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'Approval tables and triggers'
,p_sequence=>732
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
