prompt --application/deployment/install/install_seed_release_milestone_types
begin
--   Manifest
--     INSTALL: INSTALL-seed release_milestone_types
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into sp_release_milestone_types (id, milestone_type, display_seq)'||wwv_flow.LF||
'    values (1, ''Build'', 1);';
wwv_flow_imp.g_varchar2_table(2) := ''||wwv_flow.LF||
'insert into sp_release_milestone_types (id, milestone_type, display_seq)'||wwv_flow.LF||
'    values (2, ''Doc'', 2);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(3) := 'insert into sp_release_milestone_types (id, milestone_type, display_seq)'||wwv_flow.LF||
'    values (3, ''Merge'', 3);';
wwv_flow_imp.g_varchar2_table(4) := ''||wwv_flow.LF||
'insert into sp_release_milestone_types (id, milestone_type, display_seq)'||wwv_flow.LF||
'    values (4, ''Milestone''';
wwv_flow_imp.g_varchar2_table(5) := ', 4);'||wwv_flow.LF||
'insert into sp_release_milestone_types (id, milestone_type, display_seq)'||wwv_flow.LF||
'    values (6, ''Trans';
wwv_flow_imp.g_varchar2_table(6) := 'lation Drop'', 6);'||wwv_flow.LF||
'insert into sp_release_milestone_types (id, milestone_type, display_seq)'||wwv_flow.LF||
'    value';
wwv_flow_imp.g_varchar2_table(7) := 's (7, ''Upgrade'', 7);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(43085096754055875745)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed release_milestone_types'
,p_sequence=>855
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
