prompt --application/deployment/install/install_sp_group_members_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_group_members table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table SP_GROUP_MEMBERS ('||wwv_flow.LF||
'    id                             number default on null to_number(';
wwv_flow_imp.g_varchar2_table(2) := 'sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint SP_GR';
wwv_flow_imp.g_varchar2_table(3) := 'OUP_MEMBERS_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    group_id                       number not null'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(4) := '                     constraint SP_GROUPS_FK'||wwv_flow.LF||
'                                   references SP_GROUPS';
wwv_flow_imp.g_varchar2_table(5) := ' (id),'||wwv_flow.LF||
'    team_member_id                 number not null'||wwv_flow.LF||
'                                   constra';
wwv_flow_imp.g_varchar2_table(6) := 'int sp_team_group_members_tmfk'||wwv_flow.LF||
'                                   references sp_team_members(id),'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(7) := '  assignment                     varchar2(255 char),'||wwv_flow.LF||
'    full_time_yn                   varchar2(1 c';
wwv_flow_imp.g_varchar2_table(8) := 'har),'||wwv_flow.LF||
'    group_leader_yn                varchar2(1 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                       ';
wwv_flow_imp.g_varchar2_table(9) := ' date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated         ';
wwv_flow_imp.g_varchar2_table(10) := '               date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'cr';
wwv_flow_imp.g_varchar2_table(11) := 'eate index SP_GROUP_MEMBERS_i1 on SP_GROUP_MEMBERS (group_id);'||wwv_flow.LF||
'create unique index SP_GROUP_MEMBERS_';
wwv_flow_imp.g_varchar2_table(12) := 'u1 on SP_GROUP_MEMBERS (team_member_id, group_id);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(45886425754417726505)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_group_members table'
,p_sequence=>140
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
