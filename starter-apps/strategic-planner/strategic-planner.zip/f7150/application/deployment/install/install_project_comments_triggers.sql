prompt --application/deployment/install/install_project_comments_triggers
begin
--   Manifest
--     INSTALL: INSTALL-project comments triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_project_comments_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_project_comm';
wwv_flow_imp.g_varchar2_table(2) := 'ents'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new.crea';
wwv_flow_imp.g_varchar2_table(3) := 'ted_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sys';
wwv_flow_imp.g_varchar2_table(4) := 'date;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- p';
wwv_flow_imp.g_varchar2_table(5) := 'rivate'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.private_yn is null then '||wwv_flow.LF||
'       :new.private_yn := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(6) := '-'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_projects set updated = sysdate, updated_by = :new.u';
wwv_flow_imp.g_varchar2_table(7) := 'pdated_by where id = :new.project_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting and :new.private';
wwv_flow_imp.g_varchar2_table(8) := '_yn = ''N'' then'||wwv_flow.LF||
'        insert into sp_project_history'||wwv_flow.LF||
'            (project_id, attribute_column, cha';
wwv_flow_imp.g_varchar2_table(9) := 'nge_type, new_value, new_value_clob, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.projec';
wwv_flow_imp.g_varchar2_table(10) := 't_id, ''COMMENT'', ''CREATE'', dbms_lob.substr(:new.body_no_images,500,1), :new.body_no_images, sysdate,';
wwv_flow_imp.g_varchar2_table(11) := ' lower(:new.created_by));'||wwv_flow.LF||
'    elsif updating and :old.private_yn = ''N'' and :new.private_yn = ''N'' the';
wwv_flow_imp.g_varchar2_table(12) := 'n'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.body_no_images,:new.body_no_images) then'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(13) := ' insert into sp_project_history'||wwv_flow.LF||
'                (project_id, attribute_column, change_type, old_valu';
wwv_flow_imp.g_varchar2_table(14) := 'e, new_value, old_value_clob, new_value_clob, changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(15) := '     (:new.project_id, ''COMMENT'', ''UPDATE'', dbms_lob.substr(:old.body_no_images,500,1), dbms_lob.sub';
wwv_flow_imp.g_varchar2_table(16) := 'str(:new.body_no_images,500,1), :old.body_no_images, :new.body_no_images, sysdate, lower(:new.update';
wwv_flow_imp.g_varchar2_table(17) := 'd_by));'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_project_comments_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_pro';
wwv_flow_imp.g_varchar2_table(18) := 'ject_comments_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_project_comments'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :old.pri';
wwv_flow_imp.g_varchar2_table(19) := 'vate_yn = ''N'' then'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_projects set updated = sysd';
wwv_flow_imp.g_varchar2_table(20) := 'ate, updated_by = :old.updated_by where id = :old.project_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    inser';
wwv_flow_imp.g_varchar2_table(21) := 't into sp_project_history'||wwv_flow.LF||
'        (project_id, attribute_column, change_type, old_value, old_value_c';
wwv_flow_imp.g_varchar2_table(22) := 'lob, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.project_id, ''COMMENT'', ''DELETE'', dbms_lob.subs';
wwv_flow_imp.g_varchar2_table(23) := 'tr(:old.body_no_images,500,1), :old.body_no_images, sysdate, lower(coalesce(sys_context(''APEX$SESSIO';
wwv_flow_imp.g_varchar2_table(24) := 'N'',''APP_USER''),user)));'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_project_comments_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38223893616558653385)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'project comments triggers'
,p_sequence=>460
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
