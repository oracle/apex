prompt --application/deployment/install/install_create_sample_data
begin
--   Manifest
--     INSTALL: INSTALL-create sample data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into SP_TEAM_MEMBERS ('||wwv_flow.LF||
'    id, first_name, last_name, country_id, email, hash_tag_reference) ';
wwv_flow_imp.g_varchar2_table(2) := ''||wwv_flow.LF||
'    values (1,  ''John'', ''Doe'', 187, ''john.doe@acme.com'', ''John'');'||wwv_flow.LF||
'insert into SP_TEAM_MEMBERS ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(3) := ' id, first_name, last_name, country_id, email, hash_tag_reference) '||wwv_flow.LF||
'    values (2,  ''Jane'', ''Doe'', 1';
wwv_flow_imp.g_varchar2_table(4) := '87, ''jane.doe@acme.com'', ''Jane'');'||wwv_flow.LF||
'insert into SP_TEAM_MEMBERS ('||wwv_flow.LF||
'    id, first_name, last_name, count';
wwv_flow_imp.g_varchar2_table(5) := 'ry_id, email, hash_tag_reference) '||wwv_flow.LF||
'    values (3,  ''Scott'', ''Tiger'', 187, ''scott.tiger@acme.com'', ''S';
wwv_flow_imp.g_varchar2_table(6) := 'cott'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into SP_AREAS'||wwv_flow.LF||
'    (ID, AREA, DESCRIPTION, owner_id) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (1, ''Alpha'', ''P';
wwv_flow_imp.g_varchar2_table(7) := 'rimary focus of our organization'', 1);'||wwv_flow.LF||
'insert into SP_AREAS'||wwv_flow.LF||
'    (ID, AREA, DESCRIPTION, owner_id) '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(8) := '   values '||wwv_flow.LF||
'    (2, ''Beta'', ''Secondary focus area of our organization'', 1);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into SP_INITIATIV';
wwv_flow_imp.g_varchar2_table(9) := 'ES'||wwv_flow.LF||
'    (ID, AREA_ID, INITIATIVE, status_scale) '||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (1, 1, ''Initiative 1'', ''A'');'||wwv_flow.LF||
'insert i';
wwv_flow_imp.g_varchar2_table(10) := 'nto SP_INITIATIVES'||wwv_flow.LF||
'    (ID, AREA_ID, INITIATIVE, status_scale) '||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (2, 1, ''Initiative 2''';
wwv_flow_imp.g_varchar2_table(11) := ', ''C'');'||wwv_flow.LF||
'insert into SP_INITIATIVES'||wwv_flow.LF||
'    (ID, AREA_ID, INITIATIVE, status_scale) '||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (3, 2';
wwv_flow_imp.g_varchar2_table(12) := ', ''Initiative 3'', ''A'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_initiative_links'||wwv_flow.LF||
'    (id, initiative_id, link_name, link_url';
wwv_flow_imp.g_varchar2_table(13) := ', important_yn)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (1, 1, ''Fav development platform'',''https://apex.oracle.com'', ''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(14) := 'nsert into sp_release_trains'||wwv_flow.LF||
'    (id, release_train, release_owner_id, release, release_open_date, R';
wwv_flow_imp.g_varchar2_table(15) := 'ELEASE_TARGET_DATE, release_open_completed) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (1, ''Alpha R1'', 3, ''1.0'', sysdate - 45,';
wwv_flow_imp.g_varchar2_table(16) := ' sysdate + 45, ''Y'');'||wwv_flow.LF||
'insert into sp_release_trains'||wwv_flow.LF||
'    (id, release_train, release_owner_id, release';
wwv_flow_imp.g_varchar2_table(17) := ', release_open_date, RELEASE_TARGET_DATE, release_open_completed, release_completed) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(18) := '  (2, ''Gamma'', 1, ''2.1'', sysdate - 90, sysdate -5, ''Y'', ''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
' insert into SP_PROJECTS'||wwv_flow.LF||
'    (id, INI';
wwv_flow_imp.g_varchar2_table(19) := 'TIATIVE_ID, PROJECT, release_id, owner_id, priority_id, project_size, pct_complete, '||wwv_flow.LF||
'     descriptio';
wwv_flow_imp.g_varchar2_table(20) := 'n) '||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (1, 1, ''Project 1'', 1, 1, 2, ''M'', 70,'||wwv_flow.LF||
'     ''This is a very important project'');'||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(21) := 'nsert into SP_PROJECTS'||wwv_flow.LF||
'    (id, INITIATIVE_ID, PROJECT, owner_id, priority_id, project_size, tags, p';
wwv_flow_imp.g_varchar2_table(22) := 'ct_complete,'||wwv_flow.LF||
'     display_external_link_yn) '||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (2, 1, ''Jira-1234 We need to fix somethi';
wwv_flow_imp.g_varchar2_table(23) := 'ng'', 2, 1, ''S'', ''URGENT'', 30, ''Y'');'||wwv_flow.LF||
'insert into SP_PROJECTS'||wwv_flow.LF||
'    (id, INITIATIVE_ID, PROJECT, owner_i';
wwv_flow_imp.g_varchar2_table(24) := 'd, priority_id, project_size, pct_complete) '||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (3, 2, ''Sales Blitz 1'', 3, 1, ''L'', 10);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(25) := 'insert into SP_PROJECTS'||wwv_flow.LF||
'    (id, INITIATIVE_ID, PROJECT, owner_id, priority_id, project_size, pct_co';
wwv_flow_imp.g_varchar2_table(26) := 'mplete) '||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (4, 2, ''Sales Blitz 2'', 3, 3, ''M'', 20);'||wwv_flow.LF||
'insert into SP_PROJECTS'||wwv_flow.LF||
'    (id, INI';
wwv_flow_imp.g_varchar2_table(27) := 'TIATIVE_ID, PROJECT, owner_id, priority_id, project_size, pct_complete) '||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (5, 1, ''Proj';
wwv_flow_imp.g_varchar2_table(28) := 'ect 4'', 2, 4, ''XL'', 20);'||wwv_flow.LF||
'insert into SP_PROJECTS'||wwv_flow.LF||
'    (id, INITIATIVE_ID, PROJECT, owner_id, priority';
wwv_flow_imp.g_varchar2_table(29) := '_id, project_size, pct_complete) '||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (6, 3, ''Project 5'', 2, 4, ''S'', 50);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp';
wwv_flow_imp.g_varchar2_table(30) := '_project_contributors'||wwv_flow.LF||
'    (id, project_id, team_member_id, responsibility_id)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (1, 1, ';
wwv_flow_imp.g_varchar2_table(31) := '1, 1);'||wwv_flow.LF||
'insert into sp_project_contributors'||wwv_flow.LF||
'    (id, project_id, team_member_id, responsibility_id)'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(32) := '   values'||wwv_flow.LF||
'    (2, 1, 3, 4);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_project_links'||wwv_flow.LF||
'    (id, project_id, link_name, link_url, ';
wwv_flow_imp.g_varchar2_table(33) := 'important_yn)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (1, 1, ''Fav development platform'',''https://apex.oracle.com'', ''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
'ins';
wwv_flow_imp.g_varchar2_table(34) := 'ert into sp_project_comments'||wwv_flow.LF||
'    (id, project_id, body, private_yn, author_id)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (1, 1,';
wwv_flow_imp.g_varchar2_table(35) := ' ''Wow, APEX is so easy to use, the UI is looking great!'', ''N'', 1);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_activities'||wwv_flow.LF||
'    (i';
wwv_flow_imp.g_varchar2_table(36) := 'd, activity_type_id, project_id, team_member_id, start_date, end_date, activity_status, comments)'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(37) := '  values'||wwv_flow.LF||
'    (1, 1, 1, 1, sysdate-42, sysdate-10, ''CLOSED'',''Active development'');'||wwv_flow.LF||
'insert into sp_act';
wwv_flow_imp.g_varchar2_table(38) := 'ivities'||wwv_flow.LF||
'    (id, activity_type_id, project_id, team_member_id, start_date, end_date, activity_status';
wwv_flow_imp.g_varchar2_table(39) := ', comments)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (2, 1, 1, 1, sysdate-12, sysdate-10, ''CLOSED'',''Demo prep'');'||wwv_flow.LF||
'insert into s';
wwv_flow_imp.g_varchar2_table(40) := 'p_activities'||wwv_flow.LF||
'    (id, activity_type_id, project_id, team_member_id, start_date, end_date, activity_s';
wwv_flow_imp.g_varchar2_table(41) := 'tatus, comments)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (3, 3, 1, 2, sysdate-8, sysdate-8, ''CLOSED'',''Review'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into ';
wwv_flow_imp.g_varchar2_table(42) := 'sp_tasks'||wwv_flow.LF||
'    (id, project_id, task_type_id, task_sub_type_id, owner_id,'||wwv_flow.LF||
'     start_date, target_comp';
wwv_flow_imp.g_varchar2_table(43) := 'lete, status_id)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'    (1, 1, 20, 21, 1,'||wwv_flow.LF||
'     sysdate-60, sysdate-40, 14);'||wwv_flow.LF||
'insert into sp_tasks';
wwv_flow_imp.g_varchar2_table(44) := ''||wwv_flow.LF||
'    (id, project_id, task_type_id, task_sub_type_id, owner_id,'||wwv_flow.LF||
'     start_date, target_complete, st';
wwv_flow_imp.g_varchar2_table(45) := 'atus_id)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'    (2, 1, 20, 22, 1,'||wwv_flow.LF||
'     null, sysdate-10, 14);'||wwv_flow.LF||
'insert into sp_tasks'||wwv_flow.LF||
'    (id, proj';
wwv_flow_imp.g_varchar2_table(46) := 'ect_id, task_type_id, task_sub_type_id, owner_id,'||wwv_flow.LF||
'     start_date, target_complete, status_id)'||wwv_flow.LF||
'value';
wwv_flow_imp.g_varchar2_table(47) := 's'||wwv_flow.LF||
'    (3, 1, 20, 23, 1,'||wwv_flow.LF||
'     null, sysdate-1, 14);'||wwv_flow.LF||
'insert into sp_tasks'||wwv_flow.LF||
'    (id, project_id, task_ty';
wwv_flow_imp.g_varchar2_table(48) := 'pe_id, task_sub_type_id, owner_id,'||wwv_flow.LF||
'     start_date, target_complete, status_id)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'    (4, 1, 20';
wwv_flow_imp.g_varchar2_table(49) := ', 24, 1,'||wwv_flow.LF||
'     null, sysdate+5, 11);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_tasks'||wwv_flow.LF||
'    (id, project_id, task_type_id, task_su';
wwv_flow_imp.g_varchar2_table(50) := 'b_type_id, owner_id,'||wwv_flow.LF||
'     start_date, target_complete, status_id)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'    (5, 1, 1, 2, 2,'||wwv_flow.LF||
'     nu';
wwv_flow_imp.g_varchar2_table(51) := 'll, sysdate-40, 8);'||wwv_flow.LF||
'insert into sp_tasks'||wwv_flow.LF||
'    (id, project_id, task_type_id, task_sub_type_id, owner_';
wwv_flow_imp.g_varchar2_table(52) := 'id,'||wwv_flow.LF||
'     start_date, target_complete, status_id)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'    (6, 1, 1, 4, 2,'||wwv_flow.LF||
'     null, sysdate-3, 8)';
wwv_flow_imp.g_varchar2_table(53) := ';'||wwv_flow.LF||
'insert into sp_tasks'||wwv_flow.LF||
'    (id, project_id, task_type_id, task_sub_type_id, owner_id,'||wwv_flow.LF||
'     start_dat';
wwv_flow_imp.g_varchar2_table(54) := 'e, target_complete, status_id)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'    (7, 1, 1, 10, 2,'||wwv_flow.LF||
'     null, sysdate+2, 1);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(148801735575490129097)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'create sample data'
,p_sequence=>900
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
