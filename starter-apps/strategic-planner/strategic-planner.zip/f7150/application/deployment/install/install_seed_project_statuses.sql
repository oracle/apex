prompt --application/deployment/install/install_seed_project_statuses
begin
--   Manifest
--     INSTALL: INSTALL-seed project statuses
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into sp_project_statuses (ID, STATUS, STATIC_ID, INCLUDE_YN, DISPLAY_SEQ) '||wwv_flow.LF||
'    values (1, ''On';
wwv_flow_imp.g_varchar2_table(2) := ' Track'', ''ON-TRACK'', ''Y'', 1);'||wwv_flow.LF||
'insert into sp_project_statuses (ID, STATUS, STATIC_ID, INCLUDE_YN, DI';
wwv_flow_imp.g_varchar2_table(3) := 'SPLAY_SEQ) '||wwv_flow.LF||
'    values (2, ''At Risk'', ''AT-RISK'', ''Y'', 2);'||wwv_flow.LF||
'insert into sp_project_statuses (ID, STATU';
wwv_flow_imp.g_varchar2_table(4) := 'S, STATIC_ID, INCLUDE_YN, DISPLAY_SEQ) '||wwv_flow.LF||
'    values (4, ''Paused'', ''PAUSED'', ''Y'', 4);'||wwv_flow.LF||
'insert into sp_p';
wwv_flow_imp.g_varchar2_table(5) := 'roject_statuses (ID, STATUS, STATIC_ID, INCLUDE_YN, DISPLAY_SEQ) '||wwv_flow.LF||
'    values (5, ''Blocked'', ''BLOCKED';
wwv_flow_imp.g_varchar2_table(6) := ''', ''Y'', 5);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(26239863626484008125)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed project statuses'
,p_sequence=>815
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
