prompt --application/deployment/install/install_project_review_types_trigger
begin
--   Manifest
--     INSTALL: INSTALL-project review types trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1865737768882645460
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3568604075138702173)
,p_install_id=>wwv_flow_imp.id(141188953139974000425)
,p_name=>'project review types trigger'
,p_sequence=>530
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace trigger sp_project_review_types_biu',
'    before insert or update',
'    on sp_project_review_types',
'    for each row',
'begin',
'    if inserting then',
'        :new.created := sysdate;',
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'    end if;',
'    :new.updated := sysdate;',
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'    --',
'    --',
'    --',
'    :new.static_id := upper(:new.static_id);',
'    --',
'    --',
'    --',
'    if :new.include_yn is null then',
'       :new.include_yn := ''Y'';',
'    end if;',
'end SP_DEFAULT_TAGS_biu;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
