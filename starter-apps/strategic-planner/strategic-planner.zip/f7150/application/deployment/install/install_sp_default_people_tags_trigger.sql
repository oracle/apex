prompt --application/deployment/install/install_sp_default_people_tags_trigger
begin
--   Manifest
--     INSTALL: INSTALL-SP_DEFAULT_PEOPLE_TAGS trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger SP_DEFAULT_PEOPLE_TAGS_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on SP_DEFAULT_P';
wwv_flow_imp.g_varchar2_table(2) := 'EOPLE_TAGS'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :ne';
wwv_flow_imp.g_varchar2_table(3) := 'w.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated ';
wwv_flow_imp.g_varchar2_table(4) := ':= sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    :new.t';
wwv_flow_imp.g_varchar2_table(5) := 'ag := upper(:new.tag);'||wwv_flow.LF||
'    :new.tag := replace(trim(:new.tag),'' '',''-'');'||wwv_flow.LF||
'    :new.tag := replace(trim';
wwv_flow_imp.g_varchar2_table(6) := '(:new.tag),''_'',''-'');'||wwv_flow.LF||
'end SP_DEFAULT_PEOPLE_TAGS_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(40988980366855270001)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'SP_DEFAULT_PEOPLE_TAGS trigger'
,p_sequence=>650
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
