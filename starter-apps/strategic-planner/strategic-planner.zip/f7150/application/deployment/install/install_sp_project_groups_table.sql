prompt --application/deployment/install/install_sp_project_groups_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_project_groups table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_project_groups ('||wwv_flow.LF||
'   id                 number default on null to_number(sys_guid(), ';
wwv_flow_imp.g_varchar2_table(2) := '''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                      constraint sp_project_groups_pk primary k';
wwv_flow_imp.g_varchar2_table(3) := 'ey,'||wwv_flow.LF||
'   group_name         varchar2(255   char) not null enable, '||wwv_flow.LF||
'   group_description  varchar2(4000';
wwv_flow_imp.g_varchar2_table(4) := '  char),'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   is_active_yn       varchar2(1 char)'||wwv_flow.LF||
'                      default on null ''Y'''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(5) := '                  constraint sp_project_groups_active_yn '||wwv_flow.LF||
'                      check (is_active_yn ';
wwv_flow_imp.g_varchar2_table(6) := 'in (''Y'',''N'')),'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   created            date,'||wwv_flow.LF||
'   created_by         varchar2(255 char), '||wwv_flow.LF||
'   updat';
wwv_flow_imp.g_varchar2_table(7) := 'ed            date, '||wwv_flow.LF||
'   updated_by         varchar2(255 char)'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index  sp_projec';
wwv_flow_imp.g_varchar2_table(8) := 't_groups_i1 on  sp_project_groups (upper(group_name))'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE EDITIONABLE TRIGGER  sp_';
wwv_flow_imp.g_varchar2_table(9) := 'project_groups_biu'||wwv_flow.LF||
'   before insert or update on sp_project_groups '||wwv_flow.LF||
'   for each row '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'   if in';
wwv_flow_imp.g_varchar2_table(10) := 'serting then '||wwv_flow.LF||
'       :new.created := localtimestamp; '||wwv_flow.LF||
'       :new.created_by := coalesce(sys_context';
wwv_flow_imp.g_varchar2_table(11) := '(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'   if inserting or updating then '||wwv_flow.LF||
'       :new.updated';
wwv_flow_imp.g_varchar2_table(12) := ' := localtimestamp; '||wwv_flow.LF||
'       :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)';
wwv_flow_imp.g_varchar2_table(13) := ';'||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'end sp_project_groups_biu; '||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38061496884262018065)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_project_groups table'
,p_sequence=>220
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
