prompt --application/deployment/install/install_sp_project_history_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_project_history table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_project_history ('||wwv_flow.LF||
'    id                             number default on null to_numbe';
wwv_flow_imp.g_varchar2_table(2) := 'r(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_';
wwv_flow_imp.g_varchar2_table(3) := 'project_history_pk primary key,'||wwv_flow.LF||
'    project_id                     number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    attribute_colu';
wwv_flow_imp.g_varchar2_table(4) := 'mn               varchar2(255 char) not null, '||wwv_flow.LF||
'    change_type                    varchar2(30 char) ';
wwv_flow_imp.g_varchar2_table(5) := ' not null'||wwv_flow.LF||
'                                   constraint sp_project_history_type_cc '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(6) := '                   check (change_type in (''CREATE'',''UPDATE'',''DELETE'')),'||wwv_flow.LF||
'    old_value               ';
wwv_flow_imp.g_varchar2_table(7) := '       varchar2(4000 char),'||wwv_flow.LF||
'    new_value                      varchar2(4000 char),'||wwv_flow.LF||
'    old_value_cl';
wwv_flow_imp.g_varchar2_table(8) := 'ob                 clob,'||wwv_flow.LF||
'    new_value_clob                 clob,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    changed_on             ';
wwv_flow_imp.g_varchar2_table(9) := '        date  not null,'||wwv_flow.LF||
'    changed_by                     varchar2(255 char)'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_pr';
wwv_flow_imp.g_varchar2_table(10) := 'oject_history_i1 on sp_project_history (project_id);'||wwv_flow.LF||
'create index sp_project_history_i2 on sp_projec';
wwv_flow_imp.g_varchar2_table(11) := 't_history (changed_by);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(50779622264010056119)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_project_history table'
,p_sequence=>250
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
