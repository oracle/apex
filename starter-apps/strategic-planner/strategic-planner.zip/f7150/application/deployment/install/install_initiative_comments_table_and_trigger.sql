prompt --application/deployment/install/install_initiative_comments_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-initiative_comments table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_initiative_comments ('||wwv_flow.LF||
'    id                             number default on null to_n';
wwv_flow_imp.g_varchar2_table(2) := 'umber(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint';
wwv_flow_imp.g_varchar2_table(3) := ' sp_initiative_comments_pk primary key,'||wwv_flow.LF||
'    initiative_id                  number'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(4) := '                 constraint sp_initiative_commments_fk'||wwv_flow.LF||
'                                   references';
wwv_flow_imp.g_varchar2_table(5) := ' sp_initiatives (id)'||wwv_flow.LF||
'                                   on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    body          ';
wwv_flow_imp.g_varchar2_table(6) := '                 clob,'||wwv_flow.LF||
'    body_html                      clob,'||wwv_flow.LF||
'    body_no_images                 c';
wwv_flow_imp.g_varchar2_table(7) := 'lob,'||wwv_flow.LF||
'    image_ref_id                   number,'||wwv_flow.LF||
'    author_id                      number,'||wwv_flow.LF||
'    priva';
wwv_flow_imp.g_varchar2_table(8) := 'te_yn                     varchar2(1 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,';
wwv_flow_imp.g_varchar2_table(9) := ''||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                        ';
wwv_flow_imp.g_varchar2_table(10) := 'date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_in';
wwv_flow_imp.g_varchar2_table(11) := 'itiative_comments_i1 on sp_initiative_comments (initiative_id);'||wwv_flow.LF||
'create index sp_initiative_comments_';
wwv_flow_imp.g_varchar2_table(12) := 'i2 on sp_initiative_comments (author_id);'||wwv_flow.LF||
'create index sp_initiative_comments_i3 on sp_initiative_co';
wwv_flow_imp.g_varchar2_table(13) := 'mments (image_ref_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_initiative_comments_biu'||wwv_flow.LF||
'    before insert or up';
wwv_flow_imp.g_varchar2_table(14) := 'date'||wwv_flow.LF||
'    on sp_initiative_comments'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created';
wwv_flow_imp.g_varchar2_table(15) := ' := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(16) := 'nd if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_';
wwv_flow_imp.g_varchar2_table(17) := 'USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.private_yn is null then '||wwv_flow.LF||
'        :new.private_yn := ''';
wwv_flow_imp.g_varchar2_table(18) := 'N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_initiatives set updated = sysd';
wwv_flow_imp.g_varchar2_table(19) := 'ate, updated_by = :new.updated_by where id = :new.initiative_id;'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    if inserting and';
wwv_flow_imp.g_varchar2_table(20) := ' :new.private_yn = ''N'' then'||wwv_flow.LF||
'        insert into sp_initiative_history'||wwv_flow.LF||
'            (initiative_id, at';
wwv_flow_imp.g_varchar2_table(21) := 'tribute_column, change_type, new_value, new_value_clob, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(22) := '       (:new.initiative_id, ''COMMENT'', ''CREATE'', dbms_lob.substr(:new.body_no_images,500,1), :new.bo';
wwv_flow_imp.g_varchar2_table(23) := 'dy_no_images, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'     elsif updating and :old.private_yn = ''N'' and :n';
wwv_flow_imp.g_varchar2_table(24) := 'ew.private_yn = ''N'' then'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.body_no_images,:new.body_no_i';
wwv_flow_imp.g_varchar2_table(25) := 'mages) then'||wwv_flow.LF||
'            insert into sp_initiative_history'||wwv_flow.LF||
'                (initiative_id, attribute_';
wwv_flow_imp.g_varchar2_table(26) := 'column, change_type, old_value, new_value, old_value_clob, new_value_clob, changed_on, changed_by)'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(27) := '           values'||wwv_flow.LF||
'                (:new.initiative_id, ''COMMENT'', ''UPDATE'', dbms_lob.substr(:old.bod';
wwv_flow_imp.g_varchar2_table(28) := 'y_no_images,500,1), dbms_lob.substr(:new.body_no_images,1), :old.body_no_images, :new.body_no_images';
wwv_flow_imp.g_varchar2_table(29) := ', sysdate, lower(:new.updated_by));'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_initiative_comments_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'cr';
wwv_flow_imp.g_varchar2_table(30) := 'eate or replace trigger sp_initiative_comments_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_initiative_comments'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(31) := '  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :old.private_yn = ''N'' then'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    u';
wwv_flow_imp.g_varchar2_table(32) := 'pdate sp_initiatives set updated = sysdate, updated_by = :old.updated_by where id = :old.initiative_';
wwv_flow_imp.g_varchar2_table(33) := 'id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    insert into sp_initiative_history'||wwv_flow.LF||
'        (initiative_id, attribute_column, change_ty';
wwv_flow_imp.g_varchar2_table(34) := 'pe, old_value, old_value_clob, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.initiative_id, ''COMM';
wwv_flow_imp.g_varchar2_table(35) := 'ENT'', ''DELETE'', dbms_lob.substr(:old.body_no_images,500,1), :old.body_no_images, sysdate, lower(coal';
wwv_flow_imp.g_varchar2_table(36) := 'esce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_initiative_comments_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(41595058009512786846)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'initiative_comments table and trigger'
,p_sequence=>670
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
