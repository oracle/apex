prompt --application/deployment/install/install_sp_initiatives_tables
begin
--   Manifest
--     INSTALL: INSTALL-sp_initiatives tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_initiatives ('||wwv_flow.LF||
'    id                             number default on null to_number(sy';
wwv_flow_imp.g_varchar2_table(2) := 's_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_init';
wwv_flow_imp.g_varchar2_table(3) := 'iatives_id_pk primary key,'||wwv_flow.LF||
'    area_id                        number not null'||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(4) := '             constraint sp_initiatives_focus_area_i_fk'||wwv_flow.LF||
'                                   references';
wwv_flow_imp.g_varchar2_table(5) := ' sp_areas on delete cascade,'||wwv_flow.LF||
'    initiative                     varchar2(255 char) not null,'||wwv_flow.LF||
'    obj';
wwv_flow_imp.g_varchar2_table(6) := 'ective                      varchar2(4000 char),'||wwv_flow.LF||
'    sponsor_ID                     number'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(7) := '                          constraint sp_initiatives_sponsor_fk'||wwv_flow.LF||
'                                   re';
wwv_flow_imp.g_varchar2_table(8) := 'ferences sp_team_members,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    friendly_identifier            varchar2(30), '||wwv_flow.LF||
'    initiative_ur';
wwv_flow_imp.g_varchar2_table(9) := 'l_name            varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    status_scale                   varchar2(1) '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(10) := '                       constraint sp_initiative_status_scale_ck'||wwv_flow.LF||
'                                   c';
wwv_flow_imp.g_varchar2_table(11) := 'heck (status_scale in (''A'',''B'',''C'',''D'',''E'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    tags                           varchar2(400';
wwv_flow_imp.g_varchar2_table(12) := '0 char),'||wwv_flow.LF||
'    hidden_by_default_yn           varchar2(1 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    image                      ';
wwv_flow_imp.g_varchar2_table(13) := '    blob,'||wwv_flow.LF||
'    image_name                     varchar2(512 char),'||wwv_flow.LF||
'    image_mimetype                 ';
wwv_flow_imp.g_varchar2_table(14) := 'varchar2(512 char),'||wwv_flow.LF||
'    image_last_updated             date,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- Archived, soft delete'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(15) := ' --'||wwv_flow.LF||
'    archived_yn                    varchar2(1 char)'||wwv_flow.LF||
'                                   constrain';
wwv_flow_imp.g_varchar2_table(16) := 't sp_initiatives_archived_ck'||wwv_flow.LF||
'                                   check (archived_yn in (''Y'',''N'')),'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(17) := '  archived_date                  date,'||wwv_flow.LF||
'    archived_by                    varchar2(255 char),'||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(18) := ''||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 c';
wwv_flow_imp.g_varchar2_table(19) := 'har) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by                     ';
wwv_flow_imp.g_varchar2_table(20) := 'varchar2(255 char) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_initiatives_i1 on sp_initiatives (area_id);'||wwv_flow.LF||
'create ';
wwv_flow_imp.g_varchar2_table(21) := 'index sp_initiatives_i2 on sp_initiatives (sponsor_ID);'||wwv_flow.LF||
'create index sp_initiatives_i3 on sp_initiat';
wwv_flow_imp.g_varchar2_table(22) := 'ives (status_scale);'||wwv_flow.LF||
'create unique index sp_initiatives_u1 on sp_initiatives (area_id, initiative);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(23) := ''||wwv_flow.LF||
'alter table sp_initiatives add constraint sp_initiatives_scale_fk '||wwv_flow.LF||
'            foreign key (status_';
wwv_flow_imp.g_varchar2_table(24) := 'scale) references sp_project_scales;'||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_initiative_history ('||wwv_flow.LF||
'    id                   ';
wwv_flow_imp.g_varchar2_table(25) := '          number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(26) := '                           constraint sp_initiative_history_pk primary key,'||wwv_flow.LF||
'    initiative_id       ';
wwv_flow_imp.g_varchar2_table(27) := '           number  not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    attribute_column               varchar2(255 char) not null, ';
wwv_flow_imp.g_varchar2_table(28) := ''||wwv_flow.LF||
'    change_type                    varchar2(30 char)  not null'||wwv_flow.LF||
'                                   c';
wwv_flow_imp.g_varchar2_table(29) := 'onstraint sp_initiative_history_type_cc '||wwv_flow.LF||
'                                   check (change_type in (''';
wwv_flow_imp.g_varchar2_table(30) := 'CREATE'',''UPDATE'',''DELETE'')),'||wwv_flow.LF||
'    old_value                      varchar2(4000 char),'||wwv_flow.LF||
'    new_value  ';
wwv_flow_imp.g_varchar2_table(31) := '                    varchar2(4000 char),'||wwv_flow.LF||
'    old_value_clob                 clob,'||wwv_flow.LF||
'    new_value_clob';
wwv_flow_imp.g_varchar2_table(32) := '                 clob,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    changed_on                     date  not null,'||wwv_flow.LF||
'    changed_by     ';
wwv_flow_imp.g_varchar2_table(33) := '                varchar2(255 char)'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_initiative_history_i1 on sp_initiative_histor';
wwv_flow_imp.g_varchar2_table(34) := 'y (initiative_id);'||wwv_flow.LF||
'create index sp_initiative_history_i2 on sp_initiative_history (changed_by);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38666342314600358693)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_initiatives tables'
,p_sequence=>190
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
