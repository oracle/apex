prompt --application/deployment/install/install_sp_projects_tables
begin
--   Manifest
--     INSTALL: INSTALL-sp_projects tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_projects ('||wwv_flow.LF||
'    id                             number default on null to_number(sys_g';
wwv_flow_imp.g_varchar2_table(2) := 'uid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_project';
wwv_flow_imp.g_varchar2_table(3) := 's_id_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    friendly_identifier            varchar2(30 char),'||wwv_flow.LF||
'    project_url_na';
wwv_flow_imp.g_varchar2_table(4) := 'me               varchar2(255 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- parent foreign key, each project is part of an in';
wwv_flow_imp.g_varchar2_table(5) := 'itiative'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    initiative_id                  number constraint sp_projects_initiative_fk'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(6) := '                              references sp_initiatives on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(7) := 'project                        varchar2(255 char) not null,'||wwv_flow.LF||
'    upper_project_name             varch';
wwv_flow_imp.g_varchar2_table(8) := 'ar2(255 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- foreign keys'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    owner_id                       number'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(9) := '                          constraint sp_projects_owner_fk'||wwv_flow.LF||
'                                   referen';
wwv_flow_imp.g_varchar2_table(10) := 'ces sp_team_members,'||wwv_flow.LF||
'    active_yn                      varchar2(1 char) '||wwv_flow.LF||
'                          ';
wwv_flow_imp.g_varchar2_table(11) := '         default on null ''Y'''||wwv_flow.LF||
'                                   constraint sp_projects_active_ck '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(12) := '                                 check (active_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    priority_id                    ';
wwv_flow_imp.g_varchar2_table(13) := 'number '||wwv_flow.LF||
'                                   default 4'||wwv_flow.LF||
'                                   constraint s';
wwv_flow_imp.g_varchar2_table(14) := 'p_projects_priority_fk'||wwv_flow.LF||
'                                   references sp_project_priorities,'||wwv_flow.LF||
''||wwv_flow.LF||
'    rel';
wwv_flow_imp.g_varchar2_table(15) := 'ease_id                     number'||wwv_flow.LF||
'                                   constraint sp_projects_release';
wwv_flow_imp.g_varchar2_table(16) := '_fk'||wwv_flow.LF||
'                                   references SP_RELEASE_TRAINS,'||wwv_flow.LF||
''||wwv_flow.LF||
'    project_group_id          ';
wwv_flow_imp.g_varchar2_table(17) := '     number'||wwv_flow.LF||
'                                   constraint sp_projects_group_fk'||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(18) := '              references SP_PROJECT_GROUPS,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- project attributes'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    release     ';
wwv_flow_imp.g_varchar2_table(19) := '                   varchar2(30 char),'||wwv_flow.LF||
'    target_complete                date,'||wwv_flow.LF||
'    pct_complete     ';
wwv_flow_imp.g_varchar2_table(20) := '              number '||wwv_flow.LF||
'                                   default 10 '||wwv_flow.LF||
'                               ';
wwv_flow_imp.g_varchar2_table(21) := '    constraint sp_projects_pct_complete_ck'||wwv_flow.LF||
'                                   check (pct_complete in';
wwv_flow_imp.g_varchar2_table(22) := ' (0,10,20,30,40,50,60,70,80,90,100)),'||wwv_flow.LF||
'    status_id                      number'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(23) := '               constraint sp_projects_status_fk'||wwv_flow.LF||
'                                   references SP_PRO';
wwv_flow_imp.g_varchar2_table(24) := 'JECT_STATUSES,'||wwv_flow.LF||
'    project_size                   varchar2(10 char) '||wwv_flow.LF||
'                               ';
wwv_flow_imp.g_varchar2_table(25) := '    constraint sp_projects_size_ck '||wwv_flow.LF||
'                                   check (project_size in (''S'',''';
wwv_flow_imp.g_varchar2_table(26) := 'M'',''L'',''XL'',''2XL'',''3XL'',''4XL'',''8XL'')),'||wwv_flow.LF||
'    status_scale                   varchar2(1) not null'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(27) := '                              constraint sp_projects_scale_fk '||wwv_flow.LF||
'                                   re';
wwv_flow_imp.g_varchar2_table(28) := 'ferences sp_project_scales,'||wwv_flow.LF||
'    requires_reviews_yn            varchar2(1)  default on null ''Y'''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(29) := '                               constraint sp_projects_req_rev_ck '||wwv_flow.LF||
'                                  ';
wwv_flow_imp.g_varchar2_table(30) := ' check (requires_reviews_yn in (''Y'',''N'')),       '||wwv_flow.LF||
'    doc_impact_yn                  varchar2(1 char';
wwv_flow_imp.g_varchar2_table(31) := ') default on null ''N'''||wwv_flow.LF||
'                                   constraint sp_projects_doc_impact_cc'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(32) := '                             check (doc_impact_yn in (''Y'',''N'')),           '||wwv_flow.LF||
'    description         ';
wwv_flow_imp.g_varchar2_table(33) := '           clob,'||wwv_flow.LF||
'    kb_stack_rank                  number default on null sp_kb_stack_rank_seq.next';
wwv_flow_imp.g_varchar2_table(34) := 'val,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- counts, should remove these, not used'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    comments                       i';
wwv_flow_imp.g_varchar2_table(35) := 'nteger default 0, -- computed'||wwv_flow.LF||
'    links                          integer default 0, -- computed'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(36) := 'documents                      integer default 0, -- computed'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- comma seperated tags'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(37) := ' --'||wwv_flow.LF||
'    tags                           varchar2(4000 char),'||wwv_flow.LF||
'    focus_area_id                  numbe';
wwv_flow_imp.g_varchar2_table(38) := 'r constraint sp_projects_focus_area_fk'||wwv_flow.LF||
'                                   references sp_initiative_f';
wwv_flow_imp.g_varchar2_table(39) := 'ocus_areas on delete set null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    display_external_link_yn       varchar2(1 ch';
wwv_flow_imp.g_varchar2_table(40) := 'ar) constraint sp_projects_disp_ext_link_yn '||wwv_flow.LF||
'                                   check (display_exter';
wwv_flow_imp.g_varchar2_table(41) := 'nal_link_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    external_ticket_identifier     varchar2(128 char),'||wwv_flow.LF||
'    external_ticke';
wwv_flow_imp.g_varchar2_table(42) := 't_system         varchar2(30 char),'||wwv_flow.LF||
'    external_system_link           varchar2(4000 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(43) := '   -- Duplicate'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    duplicate_of_project_id        number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- Archived, soft delet';
wwv_flow_imp.g_varchar2_table(44) := 'e'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    archived_yn                    varchar2(1 char)'||wwv_flow.LF||
'                                   cons';
wwv_flow_imp.g_varchar2_table(45) := 'traint sp_project_archived_ck'||wwv_flow.LF||
'                                   check (archived_yn in (''Y'',''N'')),'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(46) := '   archived_date                  date,'||wwv_flow.LF||
'    archived_by                    varchar2(255 char),'||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(47) := '-'||wwv_flow.LF||
'    -- blocking'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    blocked_by_yn                  varchar2(1 char)'||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(48) := '            constraint sp_project_blocked_ck'||wwv_flow.LF||
'                                   check (blocked_by_yn';
wwv_flow_imp.g_varchar2_table(49) := ' in (''Y'',''N'')),'||wwv_flow.LF||
'    blocked_by_project_id          number,'||wwv_flow.LF||
'    blocked_by_comment             varcha';
wwv_flow_imp.g_varchar2_table(50) := 'r2(4000 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- Standard auditing columns'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        dat';
wwv_flow_imp.g_varchar2_table(51) := 'e not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated             ';
wwv_flow_imp.g_varchar2_table(52) := '           date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create ';
wwv_flow_imp.g_varchar2_table(53) := 'index        sp_projects_i1 on  sp_projects (owner_id);'||wwv_flow.LF||
'create index        sp_projects_i2 on  sp_pr';
wwv_flow_imp.g_varchar2_table(54) := 'ojects (initiative_id);'||wwv_flow.LF||
'create index        sp_projects_i3 on  sp_projects (status_scale);'||wwv_flow.LF||
'create in';
wwv_flow_imp.g_varchar2_table(55) := 'dex        sp_projects_i4 on  sp_projects (priority_id);'||wwv_flow.LF||
'create index        sp_projects_i5 on  sp_p';
wwv_flow_imp.g_varchar2_table(56) := 'rojects (updated);'||wwv_flow.LF||
'create index        sp_projects_i6 on  sp_projects (release_id);'||wwv_flow.LF||
'create index    ';
wwv_flow_imp.g_varchar2_table(57) := '    sp_projects_i7 on  sp_projects (DUPLICATE_OF_PROJECT_ID);'||wwv_flow.LF||
'create index        sp_projects_i8 on ';
wwv_flow_imp.g_varchar2_table(58) := ' sp_projects (pct_complete);'||wwv_flow.LF||
'create unique index sp_projects_u1 on sp_projects (upper_project_name);';
wwv_flow_imp.g_varchar2_table(59) := ''||wwv_flow.LF||
'create unique index sp_projects_u2 on  sp_projects (friendly_identifier);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'---'||wwv_flow.LF||
'--- Related Project';
wwv_flow_imp.g_varchar2_table(60) := 's'||wwv_flow.LF||
'---'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_project_related ('||wwv_flow.LF||
'    id                             number default on null ';
wwv_flow_imp.g_varchar2_table(61) := 'to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constr';
wwv_flow_imp.g_varchar2_table(62) := 'aint sp_project_related_id_pk primary key,'||wwv_flow.LF||
'    project_id                     number not null'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(63) := '                             constraint sp_project_relate_project_id_fk'||wwv_flow.LF||
'                            ';
wwv_flow_imp.g_varchar2_table(64) := '       references sp_projects on delete cascade,'||wwv_flow.LF||
'    related_project_id             number not null'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(65) := '                                   constraint sp_project_relto_project_id_fk'||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(66) := '            references sp_projects on delete cascade,'||wwv_flow.LF||
'    project_relation               varchar2(40';
wwv_flow_imp.g_varchar2_table(67) := '00 char),'||wwv_flow.LF||
'    relation_type                  varchar2(30 char)'||wwv_flow.LF||
'                                   co';
wwv_flow_imp.g_varchar2_table(68) := 'nstraint sp_project_relation_type_ck'||wwv_flow.LF||
'                                   check (relation_type in (''DU';
wwv_flow_imp.g_varchar2_table(69) := 'PLICATE_OF'',''RELATED'',''SUBPROJECT'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    c';
wwv_flow_imp.g_varchar2_table(70) := 'reated_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                        date n';
wwv_flow_imp.g_varchar2_table(71) := 'ot null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_project_';
wwv_flow_imp.g_varchar2_table(72) := 'related_i1 on sp_project_related (project_id);'||wwv_flow.LF||
'create index sp_project_related_i2 on sp_project_rela';
wwv_flow_imp.g_varchar2_table(73) := 'ted (related_project_id);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'---'||wwv_flow.LF||
'--- Project Contributors'||wwv_flow.LF||
'---'||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_project_contributors (';
wwv_flow_imp.g_varchar2_table(74) := ''||wwv_flow.LF||
'    id                             number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(75) := 'XXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_project_contrib_id_pk primary key';
wwv_flow_imp.g_varchar2_table(76) := ','||wwv_flow.LF||
'    project_id                     number'||wwv_flow.LF||
'                                   constraint sp_project';
wwv_flow_imp.g_varchar2_table(77) := '_cont_project_id_fk'||wwv_flow.LF||
'                                   references sp_projects on delete cascade,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(78) := ' team_member_id                 number'||wwv_flow.LF||
'                                   constraint sp_project_cont';
wwv_flow_imp.g_varchar2_table(79) := '_team_member_fk'||wwv_flow.LF||
'                                   references sp_team_members on delete cascade,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(80) := ' responsibility_id              number'||wwv_flow.LF||
'                                   constraint sp_project_cont';
wwv_flow_imp.g_varchar2_table(81) := '_to_resp_fk'||wwv_flow.LF||
'                                   references SP_RESOURCE_TYPES,'||wwv_flow.LF||
'    responsibility     ';
wwv_flow_imp.g_varchar2_table(82) := '            varchar2(4000 char),'||wwv_flow.LF||
'    tags                           varchar2(4000 char),'||wwv_flow.LF||
'    created';
wwv_flow_imp.g_varchar2_table(83) := '                        date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not nul';
wwv_flow_imp.g_varchar2_table(84) := 'l,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255';
wwv_flow_imp.g_varchar2_table(85) := ' char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
'comment on table sp_project_contributors is ''Identifies resources working on a gi';
wwv_flow_imp.g_varchar2_table(86) := 'ven project'';'||wwv_flow.LF||
'create index sp_project_contrib_i1 on sp_project_contributors (project_id);'||wwv_flow.LF||
'create ind';
wwv_flow_imp.g_varchar2_table(87) := 'ex sp_project_contrib_i2 on sp_project_contributors (team_member_id);'||wwv_flow.LF||
'create index sp_project_contri';
wwv_flow_imp.g_varchar2_table(88) := 'b_i3 on sp_project_contributors (responsibility_id);'||wwv_flow.LF||
'create index SP_PROJECT_CONTRIBUTORS_i4 on SP_P';
wwv_flow_imp.g_varchar2_table(89) := 'ROJECT_CONTRIBUTORS(updated);'||wwv_flow.LF||
'create unique index SP_PROJECT_CONTRIBUTORS_u1 on SP_PROJECT_CONTRIBUT';
wwv_flow_imp.g_varchar2_table(90) := 'ORS (TEAM_MEMBER_ID, PROJECT_ID);'||wwv_flow.LF||
''||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- Project Documents'||wwv_flow.LF||
'--'||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_project_documents ('||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(91) := '   id                             number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(92) := 'XXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_project_documents_id_pk primary key';
wwv_flow_imp.g_varchar2_table(93) := ','||wwv_flow.LF||
'    project_id                     number'||wwv_flow.LF||
'                                   constraint sp_project';
wwv_flow_imp.g_varchar2_table(94) := '_doc_proj_id_fk'||wwv_flow.LF||
'                                   references sp_projects on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(95) := '    document_blob                  blob,'||wwv_flow.LF||
'    document_filename              varchar2(512 char),'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(96) := 'document_mimetype              varchar2(512 char),'||wwv_flow.LF||
'    document_charset               varchar2(512 c';
wwv_flow_imp.g_varchar2_table(97) := 'har),'||wwv_flow.LF||
'    document_lastupd               date,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    important_yn                   varchar2(1 ';
wwv_flow_imp.g_varchar2_table(98) := 'char),'||wwv_flow.LF||
'    doc_description                varchar2(4000 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    tags                      ';
wwv_flow_imp.g_varchar2_table(99) := '     varchar2(4000 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by   ';
wwv_flow_imp.g_varchar2_table(100) := '                  varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(101) := ' updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_project_documents_i1';
wwv_flow_imp.g_varchar2_table(102) := ' on sp_project_documents (project_id);'||wwv_flow.LF||
'create index sp_project_documents_i2 on sp_project_documents ';
wwv_flow_imp.g_varchar2_table(103) := '(updated);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38666573044640365522)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_projects tables'
,p_sequence=>240
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
