prompt --application/deployment/install/install_sp_generate_ai_project_summaries_job
begin
--   Manifest
--     INSTALL: INSTALL-SP_GENERATE_AI_PROJECT_SUMMARIES_JOB
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- weekly, Sunday morning at 5am'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    dbms_scheduler.create_job ('||wwv_flow.LF||
'        job_name   => ''SP_GEN';
wwv_flow_imp.g_varchar2_table(2) := 'ERATE_AI_PROJECT_SUMMARIES_JOB'','||wwv_flow.LF||
'        job_type   => ''STORED_PROCEDURE'','||wwv_flow.LF||
'        job_action => ''sp';
wwv_flow_imp.g_varchar2_table(3) := '_summary_util.generate_project_summaries'','||wwv_flow.LF||
'        start_date => null,'||wwv_flow.LF||
'        repeat_interval => ''F';
wwv_flow_imp.g_varchar2_table(4) := 'REQ=WEEKLY; BYTIME=050000; BYDAY=SUN'','||wwv_flow.LF||
'        enabled    => TRUE,'||wwv_flow.LF||
'        auto_drop  => FALSE,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(5) := '    comments   => ''Creates AI Summaries of active projects once a week'' );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(31602464608612834399)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'SP_GENERATE_AI_PROJECT_SUMMARIES_JOB'
,p_sequence=>915
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
