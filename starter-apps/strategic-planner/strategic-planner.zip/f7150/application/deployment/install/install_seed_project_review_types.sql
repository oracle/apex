prompt --application/deployment/install/install_seed_project_review_types
begin
--   Manifest
--     INSTALL: INSTALL-seed project review types
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>1857349048181505117
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3560040948323209796)
,p_install_id=>wwv_flow_imp.id(141180564419272860082)
,p_name=>'seed project review types'
,p_sequence=>1060
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into sp_project_review_types (ID, STATIC_ID, REVIEW_TYPE, DESCRIPTION, DISPLAY_SEQ) values (1, ''FUNCSPEC'', ''Functional Spec'', ''A review of the functional specification document.'', 10);',
'insert into sp_project_review_types (ID, STATIC_ID, REVIEW_TYPE, DESCRIPTION, DISPLAY_SEQ) values (2, ''IMPSPEC'', ''Implementation Spec'', ''A review of the implementation designed to implement a functional specification document.'', 20);',
'insert into sp_project_review_types (ID, STATIC_ID, REVIEW_TYPE, DESCRIPTION, DISPLAY_SEQ) values (3, ''PEER'', ''Peer'', ''Review of the implementation  by your fellow developer.'', 30);',
'insert into sp_project_review_types (ID, STATIC_ID, REVIEW_TYPE, DESCRIPTION, DISPLAY_SEQ) values (4, ''SEC'', ''Security'', ''Review of the security exposure, remediations, and risk of this implementation.'', 40);',
'insert into sp_project_review_types (ID, STATIC_ID, REVIEW_TYPE, DESCRIPTION, DISPLAY_SEQ) values (5, ''ACCESSS'', ''Accessibility'', ''Review web accessibility'', 50);',
'insert into sp_project_review_types (ID, STATIC_ID, REVIEW_TYPE, DESCRIPTION, DISPLAY_SEQ) values (6, ''PM'', ''Product Management'', ''Project Management (PM) team review'', 60);',
'insert into sp_project_review_types (ID, STATIC_ID, REVIEW_TYPE, DESCRIPTION, DISPLAY_SEQ) values (7, ''DOC'', ''Documentation'', ''Review of the documentation'', 70);',
'insert into sp_project_review_types (ID, STATIC_ID, REVIEW_TYPE, DESCRIPTION, DISPLAY_SEQ) values (8, ''TESTING'', ''Functional Testing'', ''Review of the testing plan'', 80);',
'insert into sp_project_review_types (ID, STATIC_ID, REVIEW_TYPE, DESCRIPTION, DISPLAY_SEQ) values (9, ''UX'', ''User Experience'', ''Review of end-user experience'', 90);',
'insert into sp_project_review_types (ID, STATIC_ID, REVIEW_TYPE, DESCRIPTION, DISPLAY_SEQ) values (10, ''IMPLEMENTATION'', ''Implementation'', ''An implementation review is typically performed before merge'', 100);',
'insert into sp_project_review_types (ID, STATIC_ID, REVIEW_TYPE, DESCRIPTION, DISPLAY_SEQ) values (11, ''OTHER'', ''Other'', '''', 110);'))
);
wwv_flow_imp.component_end;
end;
/
