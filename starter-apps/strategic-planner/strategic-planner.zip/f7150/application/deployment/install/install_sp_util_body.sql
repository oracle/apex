prompt --application/deployment/install/install_sp_util_body
begin
--   Manifest
--     INSTALL: INSTALL-sp_util body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body sp_util as'||wwv_flow.LF||
''||wwv_flow.LF||
'g_error_retention_in_days  number := 21;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_e';
wwv_flow_imp.g_varchar2_table(2) := 'rror_log ( '||wwv_flow.LF||
'    p_package_name    in varchar2,'||wwv_flow.LF||
'    p_procedure_name  in varchar2, '||wwv_flow.LF||
'    p_error      ';
wwv_flow_imp.g_varchar2_table(3) := '     in varchar2, '||wwv_flow.LF||
'    p_arg1_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg1_val        in varchar';
wwv_flow_imp.g_varchar2_table(4) := '2 default null, '||wwv_flow.LF||
'    p_arg2_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg2_val        in varchar2 ';
wwv_flow_imp.g_varchar2_table(5) := 'default null, '||wwv_flow.LF||
'    p_arg3_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg3_val        in varchar2 de';
wwv_flow_imp.g_varchar2_table(6) := 'fault null, '||wwv_flow.LF||
'    p_arg4_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg4_val        in varchar2 defa';
wwv_flow_imp.g_varchar2_table(7) := 'ult null, '||wwv_flow.LF||
'    p_arg5_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg5_val        in varchar2 defaul';
wwv_flow_imp.g_varchar2_table(8) := 't null ) '||wwv_flow.LF||
'as '||wwv_flow.LF||
'    pragma       autonomous_transaction; '||wwv_flow.LF||
'begin '||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_error_log '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(9) := ' (package_name, procedure_name, error, '||wwv_flow.LF||
'        arg1_name, arg1_val, arg2_name, arg2_val, arg3_name,';
wwv_flow_imp.g_varchar2_table(10) := ' arg3_val, '||wwv_flow.LF||
'        arg4_name, arg4_val, arg5_name, arg5_val ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'       (substr(p_package';
wwv_flow_imp.g_varchar2_table(11) := '_name,1,255), substr(p_procedure_name,1,500), substr(p_error,1,4000), '||wwv_flow.LF||
'        substr(p_arg1_name,1,';
wwv_flow_imp.g_varchar2_table(12) := '255), substr(p_arg1_val,1,4000), substr(p_arg2_name,1,255), substr(p_arg2_val,1,4000), '||wwv_flow.LF||
'        subs';
wwv_flow_imp.g_varchar2_table(13) := 'tr(p_arg3_name,1,255), substr(p_arg3_val,1,4000), substr(p_arg4_name,1,255), substr(p_arg4_val,1,400';
wwv_flow_imp.g_varchar2_table(14) := '0), '||wwv_flow.LF||
'        substr(p_arg5_name,1,255), substr(p_arg5_val,1,4000) );'||wwv_flow.LF||
'    commit; '||wwv_flow.LF||
''||wwv_flow.LF||
'    -- g_error_re';
wwv_flow_imp.g_varchar2_table(15) := 'tention_in_days is in the spec'||wwv_flow.LF||
'    delete from sp_error_log'||wwv_flow.LF||
'     where created_trunc < sysdate - g_e';
wwv_flow_imp.g_varchar2_table(16) := 'rror_retention_in_days;'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'end add_error_log;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_app_log ( '||wwv_flow.LF||
'    p_activity   ';
wwv_flow_imp.g_varchar2_table(17) := 'in varchar2,'||wwv_flow.LF||
'    p_details    in varchar2 ) '||wwv_flow.LF||
'as '||wwv_flow.LF||
'begin '||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_app_log '||wwv_flow.LF||
'       (activit';
wwv_flow_imp.g_varchar2_table(18) := 'y, details) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'       (substr(p_activity,1,255), substr(p_details,1,4000) );'||wwv_flow.LF||
'    commit; '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(19) := ''||wwv_flow.LF||
'end add_app_log;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function create_area ('||wwv_flow.LF||
'    p_area                     in varchar2,'||wwv_flow.LF||
'    p_descrip';
wwv_flow_imp.g_varchar2_table(20) := 'tion              in varchar2 default null,'||wwv_flow.LF||
'    p_owner_id                 in number   default null'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(21) := '    )'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_area_id number := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_areas ('||wwv_flow.LF||
'        A';
wwv_flow_imp.g_varchar2_table(22) := 'REA,'||wwv_flow.LF||
'        description,'||wwv_flow.LF||
'        OWNER_ID)'||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_area,'||wwv_flow.LF||
'        p_description,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(23) := '    p_owner_id'||wwv_flow.LF||
'        )'||wwv_flow.LF||
'        returning id into l_area_id;'||wwv_flow.LF||
'    return l_area_id;'||wwv_flow.LF||
'end create_area;';
wwv_flow_imp.g_varchar2_table(24) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'function create_initiative ('||wwv_flow.LF||
'    p_area_id                  in number,'||wwv_flow.LF||
'    p_initiative           ';
wwv_flow_imp.g_varchar2_table(25) := '    in varchar2,'||wwv_flow.LF||
'    p_objective                in varchar2 default null,'||wwv_flow.LF||
'    P_OWNER_ID            ';
wwv_flow_imp.g_varchar2_table(26) := '     in number   default null'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_initiative_id number := null;'||wwv_flow.LF||
'begin ';
wwv_flow_imp.g_varchar2_table(27) := ''||wwv_flow.LF||
'    insert into sp_initiatives ('||wwv_flow.LF||
'        area_id,'||wwv_flow.LF||
'        initiative,'||wwv_flow.LF||
'        objective,'||wwv_flow.LF||
'        SP';
wwv_flow_imp.g_varchar2_table(28) := 'ONSOR_ID) '||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_area_id,'||wwv_flow.LF||
'        p_initiative,'||wwv_flow.LF||
'        p_objective,'||wwv_flow.LF||
'        p_owne';
wwv_flow_imp.g_varchar2_table(29) := 'r_ID'||wwv_flow.LF||
'        )'||wwv_flow.LF||
'    returning id into l_initiative_id ;'||wwv_flow.LF||
'    return l_initiative_id;'||wwv_flow.LF||
'end create_initia';
wwv_flow_imp.g_varchar2_table(30) := 'tive;'||wwv_flow.LF||
''||wwv_flow.LF||
'function create_release ('||wwv_flow.LF||
'    p_release_train                  in varchar2,'||wwv_flow.LF||
'    p_release_own';
wwv_flow_imp.g_varchar2_table(31) := 'er_id               in number,'||wwv_flow.LF||
'    p_release                        in varchar2,'||wwv_flow.LF||
'    p_release_targe';
wwv_flow_imp.g_varchar2_table(32) := 't_date            in date,'||wwv_flow.LF||
'    p_release_open_date              in date'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(33) := '    l_release_id  number := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_release_trains ('||wwv_flow.LF||
'        release_train,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(34) := '       release_owner_id,'||wwv_flow.LF||
'        release,'||wwv_flow.LF||
'        release_target_date,'||wwv_flow.LF||
'        release_open_date'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(35) := '     )'||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_release_train,'||wwv_flow.LF||
'        p_release_owner_id,'||wwv_flow.LF||
'        p_release,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(36) := 'p_release_target_date,'||wwv_flow.LF||
'        p_release_open_date'||wwv_flow.LF||
'        )'||wwv_flow.LF||
'        returning id into l_release_id;';
wwv_flow_imp.g_varchar2_table(37) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_release_id;'||wwv_flow.LF||
'end create_release;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure copy_release ('||wwv_flow.LF||
'    p_copy_from_release_id ';
wwv_flow_imp.g_varchar2_table(38) := ' in  number,'||wwv_flow.LF||
'    p_new_release           in  varchar2,'||wwv_flow.LF||
'    p_push_days             in  number,'||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(39) := '_new_release_id        out number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select release_train, release_o';
wwv_flow_imp.g_varchar2_table(40) := 'wner_id,'||wwv_flow.LF||
'               release_target_date, release_open_date,'||wwv_flow.LF||
'               description'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(41) := ' from sp_release_trains'||wwv_flow.LF||
'         where id = p_copy_from_release_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        insert into sp';
wwv_flow_imp.g_varchar2_table(42) := '_release_trains'||wwv_flow.LF||
'            (release_train, release_owner_id, release, '||wwv_flow.LF||
'             release_target_';
wwv_flow_imp.g_varchar2_table(43) := 'date, release_open_date,'||wwv_flow.LF||
'             description)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (c1.release_train, c1.';
wwv_flow_imp.g_varchar2_table(44) := 'release_owner_id, p_new_release, '||wwv_flow.LF||
'             c1.release_target_date + p_push_days, c1.release_open';
wwv_flow_imp.g_varchar2_table(45) := '_date + p_push_days,'||wwv_flow.LF||
'             c1.description)'||wwv_flow.LF||
'            returning id into p_new_release_id;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(46) := '  end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_release_milestones'||wwv_flow.LF||
'       (release_id, milestone_name, upper_milesto';
wwv_flow_imp.g_varchar2_table(47) := 'ne_name, '||wwv_flow.LF||
'        milestone_date, milestone_description)'||wwv_flow.LF||
'    select p_new_release_id, milestone_name';
wwv_flow_imp.g_varchar2_table(48) := ', upper_milestone_name, '||wwv_flow.LF||
'           milestone_date + p_push_days, milestone_description'||wwv_flow.LF||
'      from s';
wwv_flow_imp.g_varchar2_table(49) := 'p_release_milestones'||wwv_flow.LF||
'     where release_id = p_copy_from_release_id;'||wwv_flow.LF||
'end copy_release;'||wwv_flow.LF||
''||wwv_flow.LF||
'function cre';
wwv_flow_imp.g_varchar2_table(50) := 'ate_team_member ('||wwv_flow.LF||
'    p_first_name                     in varchar2,'||wwv_flow.LF||
'    p_last_name                 ';
wwv_flow_imp.g_varchar2_table(51) := '     in varchar2,'||wwv_flow.LF||
'    p_email                          in varchar2,'||wwv_flow.LF||
'    p_tags                      ';
wwv_flow_imp.g_varchar2_table(52) := '     in varchar2 default null,'||wwv_flow.LF||
'    p_is_current_yn                  in varchar2 default ''Y'''||wwv_flow.LF||
'    )'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(53) := '  return number'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_team_member_id number := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_team_members ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(54) := '     first_name,'||wwv_flow.LF||
'        last_name,'||wwv_flow.LF||
'        email,'||wwv_flow.LF||
'        tags,'||wwv_flow.LF||
'        is_current_yn'||wwv_flow.LF||
'        )'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(55) := ' values ('||wwv_flow.LF||
'        p_first_name,'||wwv_flow.LF||
'        p_last_name,'||wwv_flow.LF||
'        p_email,'||wwv_flow.LF||
'        p_tags,'||wwv_flow.LF||
'        p_is_c';
wwv_flow_imp.g_varchar2_table(56) := 'urrent_yn'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'    returning id into l_team_member_id;'||wwv_flow.LF||
'    return l_team_member_id;'||wwv_flow.LF||
'end create_team';
wwv_flow_imp.g_varchar2_table(57) := '_member;'||wwv_flow.LF||
''||wwv_flow.LF||
'function create_project ('||wwv_flow.LF||
'    p_initiative_id                  in number,'||wwv_flow.LF||
'    p_project   ';
wwv_flow_imp.g_varchar2_table(58) := '                     in varchar2,'||wwv_flow.LF||
'    p_owner_id                       in number,'||wwv_flow.LF||
'    p_status_scale';
wwv_flow_imp.g_varchar2_table(59) := '                   in varchar2  default ''A'','||wwv_flow.LF||
'    p_pct_complete                   in number    defau';
wwv_flow_imp.g_varchar2_table(60) := 'lt 10,'||wwv_flow.LF||
'    p_priority_id                    in number    default 4,'||wwv_flow.LF||
'    p_target_complete           ';
wwv_flow_imp.g_varchar2_table(61) := '     in date      default null,'||wwv_flow.LF||
'    p_release_id                     in number    default null,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(62) := 'p_project_size                   in varchar2  default ''M'','||wwv_flow.LF||
'    p_description                    in v';
wwv_flow_imp.g_varchar2_table(63) := 'archar2  default null,'||wwv_flow.LF||
'    p_tags                           in varchar2  default null'||wwv_flow.LF||
'    ) '||wwv_flow.LF||
'    ret';
wwv_flow_imp.g_varchar2_table(64) := 'urn number'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_project_id           number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_projects ('||wwv_flow.LF||
'        initi';
wwv_flow_imp.g_varchar2_table(65) := 'ative_id,'||wwv_flow.LF||
'        project,'||wwv_flow.LF||
'        owner_id,'||wwv_flow.LF||
'        status_scale,'||wwv_flow.LF||
'        pct_complete,'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(66) := '        priority_id,'||wwv_flow.LF||
'        release_id,'||wwv_flow.LF||
'        project_size,'||wwv_flow.LF||
'        description,'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(67) := '   tags) '||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_initiative_id,'||wwv_flow.LF||
'        p_project,'||wwv_flow.LF||
'        p_owner_id,'||wwv_flow.LF||
'        p_sta';
wwv_flow_imp.g_varchar2_table(68) := 'tus_scale,'||wwv_flow.LF||
'        p_pct_complete,'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        p_priority_id,'||wwv_flow.LF||
'        p_release_id,'||wwv_flow.LF||
'        p';
wwv_flow_imp.g_varchar2_table(69) := '_project_size,'||wwv_flow.LF||
'        p_description,'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        p_tags) '||wwv_flow.LF||
'    returning id into l_project_id';
wwv_flow_imp.g_varchar2_table(70) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_project_id;'||wwv_flow.LF||
'end create_project;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function copy_project ('||wwv_flow.LF||
'    p_project_id          ';
wwv_flow_imp.g_varchar2_table(71) := '           in number,'||wwv_flow.LF||
'    p_new_project_name               in varchar2'||wwv_flow.LF||
'    ) '||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(72) := '    l_project_id           number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- forced to use cursor to do insert into select retur';
wwv_flow_imp.g_varchar2_table(73) := 'ning'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select initiative_id,'||wwv_flow.LF||
'               owner_id,'||wwv_flow.LF||
'               status_sc';
wwv_flow_imp.g_varchar2_table(74) := 'ale,'||wwv_flow.LF||
'               priority_id,'||wwv_flow.LF||
'               project_size,'||wwv_flow.LF||
'               description,'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(75) := '     requires_reviews_yn,'||wwv_flow.LF||
'               doc_impact_yn,'||wwv_flow.LF||
'               focus_area_id,'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(76) := ' project_group_id,'||wwv_flow.LF||
'               tags'||wwv_flow.LF||
'          from sp_projects'||wwv_flow.LF||
'         where id = p_project_id'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(77) := '   ) loop'||wwv_flow.LF||
'        insert into sp_projects ('||wwv_flow.LF||
'               initiative_id,'||wwv_flow.LF||
'               project,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(78) := '             owner_id,'||wwv_flow.LF||
'               status_scale,'||wwv_flow.LF||
'               pct_complete,'||wwv_flow.LF||
'               --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(79) := '              priority_id,'||wwv_flow.LF||
'               project_size,'||wwv_flow.LF||
'               description,'||wwv_flow.LF||
'               -';
wwv_flow_imp.g_varchar2_table(80) := '-'||wwv_flow.LF||
'               requires_reviews_yn,'||wwv_flow.LF||
'               doc_impact_yn,'||wwv_flow.LF||
'               focus_area_id,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(81) := '             project_group_id,'||wwv_flow.LF||
'               tags ) '||wwv_flow.LF||
'        values ('||wwv_flow.LF||
'               c1.initiative_';
wwv_flow_imp.g_varchar2_table(82) := 'id,'||wwv_flow.LF||
'               p_new_project_name,'||wwv_flow.LF||
'               c1.owner_id,'||wwv_flow.LF||
'               c1.status_scale,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(83) := '              10,'||wwv_flow.LF||
'               --'||wwv_flow.LF||
'               c1.priority_id,'||wwv_flow.LF||
'               c1.project_size,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(84) := '              c1.description,'||wwv_flow.LF||
'               --'||wwv_flow.LF||
'               c1.requires_reviews_yn,'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(85) := '  c1.doc_impact_yn,'||wwv_flow.LF||
'               c1.focus_area_id,'||wwv_flow.LF||
'               c1.project_group_id,'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(86) := '    c1.tags )'||wwv_flow.LF||
'        returning id into l_project_id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    default_project_tasks (p_pr';
wwv_flow_imp.g_varchar2_table(87) := 'oject_id => l_project_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_project_contributors ('||wwv_flow.LF||
'           project_id,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(88) := '    team_member_id,'||wwv_flow.LF||
'           responsibility_id,'||wwv_flow.LF||
'           responsibility, '||wwv_flow.LF||
'           tags )'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(89) := 'select l_project_id,'||wwv_flow.LF||
'           team_member_id,'||wwv_flow.LF||
'           responsibility_id,'||wwv_flow.LF||
'           responsibil';
wwv_flow_imp.g_varchar2_table(90) := 'ity, '||wwv_flow.LF||
'           tags'||wwv_flow.LF||
'      from sp_project_contributors'||wwv_flow.LF||
'     where project_id = p_project_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(91) := 'return l_project_id;'||wwv_flow.LF||
'end copy_project;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_related_project ('||wwv_flow.LF||
'    p_related_project_id in';
wwv_flow_imp.g_varchar2_table(92) := ' number,'||wwv_flow.LF||
'    p_project_id         in number)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    insert into SP_PROJECT_RELATED ('||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(93) := ' PROJECT_ID,'||wwv_flow.LF||
'        RELATED_PROJECT_ID)'||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_project_id,'||wwv_flow.LF||
'        p_related_projec';
wwv_flow_imp.g_varchar2_table(94) := 't_id);'||wwv_flow.LF||
'end add_related_project;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_project_contributor ('||wwv_flow.LF||
'    P_TEAM_MEMBER_ID    in num';
wwv_flow_imp.g_varchar2_table(95) := 'ber,'||wwv_flow.LF||
'    p_RESPONSIBILITY_ID in number,'||wwv_flow.LF||
'    p_project_id        in number)'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_team_member_id n';
wwv_flow_imp.g_varchar2_table(96) := 'umber;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into SP_PROJECT_CONTRIBUTORS ('||wwv_flow.LF||
'        TEAM_MEMBER_ID, '||wwv_flow.LF||
'        RESPONSIBILI';
wwv_flow_imp.g_varchar2_table(97) := 'TY_ID, '||wwv_flow.LF||
'        project_id) '||wwv_flow.LF||
'        values ('||wwv_flow.LF||
'        P_TEAM_MEMBER_ID,'||wwv_flow.LF||
'        p_RESPONSIBILITY_ID,';
wwv_flow_imp.g_varchar2_table(98) := ''||wwv_flow.LF||
'        p_project_id);'||wwv_flow.LF||
'    '||wwv_flow.LF||
'end add_project_contributor;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_project_link ('||wwv_flow.LF||
'    p_proje';
wwv_flow_imp.g_varchar2_table(99) := 'ct_id      in number,'||wwv_flow.LF||
'    p_link_name       in varchar2,'||wwv_flow.LF||
'    p_link_url        in varchar2)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begi';
wwv_flow_imp.g_varchar2_table(100) := 'n'||wwv_flow.LF||
'    insert into SP_PROJECT_LINKS (PROJECT_ID, link_name, LINK_URL) '||wwv_flow.LF||
'    values (p_project_id, p_li';
wwv_flow_imp.g_varchar2_table(101) := 'nk_name, p_link_url);'||wwv_flow.LF||
'end add_project_link;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure default_project_tasks ('||wwv_flow.LF||
'    p_project_id    ';
wwv_flow_imp.g_varchar2_table(102) := '  in number)'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_tasks'||wwv_flow.LF||
'        (project_id, task_type_id, task_sub_type_id, ';
wwv_flow_imp.g_varchar2_table(103) := 'status_id)'||wwv_flow.LF||
'    select p.id,'||wwv_flow.LF||
'           nvl(tt.parent_type_id,tt.id),'||wwv_flow.LF||
'           case when tt.parent_';
wwv_flow_imp.g_varchar2_table(104) := 'type_id is not null then tt.id end,'||wwv_flow.LF||
'           (select min(id) from sp_task_statuses'||wwv_flow.LF||
'             wh';
wwv_flow_imp.g_varchar2_table(105) := 'ere is_default_yn = ''Y'''||wwv_flow.LF||
'               and task_type_id = tt.parent_type_id)'||wwv_flow.LF||
'      from sp_projects ';
wwv_flow_imp.g_varchar2_table(106) := 'p,'||wwv_flow.LF||
'           sp_initiatives i,'||wwv_flow.LF||
'           sp_initiative_default_tasks dt,'||wwv_flow.LF||
'           sp_task_types ';
wwv_flow_imp.g_varchar2_table(107) := 'tt'||wwv_flow.LF||
'     where p.id = p_project_id'||wwv_flow.LF||
'       and p.initiative_id = i.id'||wwv_flow.LF||
'       and i.id = dt.initiative_';
wwv_flow_imp.g_varchar2_table(108) := 'id'||wwv_flow.LF||
'       and dt.type_id = tt.id'||wwv_flow.LF||
'       and tt.include_yn = ''Y'';'||wwv_flow.LF||
'end default_project_tasks;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'proced';
wwv_flow_imp.g_varchar2_table(109) := 'ure archive_project ('||wwv_flow.LF||
'    p_project_id      in number,'||wwv_flow.LF||
'    p_app_user        in varchar2)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(110) := '   update sp_projects set archived_yn = ''Y'', archived_date = sysdate, archived_by = p_app_user where';
wwv_flow_imp.g_varchar2_table(111) := ' id = p_project_id;'||wwv_flow.LF||
'end archive_project;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure un_archive_project ('||wwv_flow.LF||
'    p_project_id      in nu';
wwv_flow_imp.g_varchar2_table(112) := 'mber)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   update sp_projects set archived_yn = ''N'', archived_date = null where id = p_proje';
wwv_flow_imp.g_varchar2_table(113) := 'ct_id;'||wwv_flow.LF||
'end un_archive_project;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure mark_proj_as_duplidate ('||wwv_flow.LF||
'    p_project_id        in number';
wwv_flow_imp.g_varchar2_table(114) := ','||wwv_flow.LF||
'    p_dup_of_project    in number)'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    update sp_projects set DUPLICATE_OF_PROJECT_ID = p';
wwv_flow_imp.g_varchar2_table(115) := '_dup_of_project where id = p_project_id;'||wwv_flow.LF||
'end mark_proj_as_duplidate;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure unmark_proj_as_dupli';
wwv_flow_imp.g_varchar2_table(116) := 'cate ('||wwv_flow.LF||
'    p_project_id        in number)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    update sp_projects set DUPLICATE_OF_PROJECT_';
wwv_flow_imp.g_varchar2_table(117) := 'ID = null where id = p_project_id;'||wwv_flow.LF||
'end unmark_proj_as_duplicate;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- additional APIs'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_';
wwv_flow_imp.g_varchar2_table(118) := 'user_email ('||wwv_flow.LF||
'    p_app_user     in  varchar2  default null,'||wwv_flow.LF||
'    p_user_id      in  number    default';
wwv_flow_imp.g_varchar2_table(119) := ' null )'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_email varchar(255) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        selec';
wwv_flow_imp.g_varchar2_table(120) := 't email '||wwv_flow.LF||
'          from sp_team_members '||wwv_flow.LF||
'         where email = lower(p_app_user)'||wwv_flow.LF||
'            or id ';
wwv_flow_imp.g_varchar2_table(121) := '= p_user_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        l_email := c1.email;'||wwv_flow.LF||
'        exit;'||wwv_flow.LF||
'    end loop;     '||wwv_flow.LF||
'    return l_em';
wwv_flow_imp.g_varchar2_table(122) := 'ail;'||wwv_flow.LF||
'end get_user_email;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_user_id ('||wwv_flow.LF||
'    p_app_user     in  varchar2  default null,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(123) := 'p_screen_name  in  varchar2  default null)'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_id number := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    f';
wwv_flow_imp.g_varchar2_table(124) := 'or c1 in ('||wwv_flow.LF||
'        select id '||wwv_flow.LF||
'          from sp_team_members '||wwv_flow.LF||
'         where email = lower(p_app_use';
wwv_flow_imp.g_varchar2_table(125) := 'r)'||wwv_flow.LF||
'            or screen_name = lower(p_screen_name)'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        l_id := c1.id;'||wwv_flow.LF||
'        exit;';
wwv_flow_imp.g_varchar2_table(126) := ''||wwv_flow.LF||
'    end loop;     '||wwv_flow.LF||
'    return l_id;'||wwv_flow.LF||
'end get_user_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_area_name ('||wwv_flow.LF||
'    p_id            ';
wwv_flow_imp.g_varchar2_table(127) := '  in number)'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_name varchar2(255) := null;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    for c1 in (select a';
wwv_flow_imp.g_varchar2_table(128) := 'rea from SP_AREAS where id = p_id) loop'||wwv_flow.LF||
'        l_name := c1.area;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    return l_name;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(129) := 'end get_area_name;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_initiative_name ('||wwv_flow.LF||
'    p_id              in number)'||wwv_flow.LF||
'    return varch';
wwv_flow_imp.g_varchar2_table(130) := 'ar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_name varchar2(255) := null;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    for c1 in (select INITIATIVE from SP_INITIATIVES';
wwv_flow_imp.g_varchar2_table(131) := ' where id = p_id) loop'||wwv_flow.LF||
'        l_name := c1.INITIATIVE;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    return l_name;'||wwv_flow.LF||
'end get_ini';
wwv_flow_imp.g_varchar2_table(132) := 'tiative_name;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_project_name ('||wwv_flow.LF||
'    p_id              in number)'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(133) := '   l_name varchar2(255) := null;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    for c1 in (select PROJECT from SP_PROJECTS where id = p_';
wwv_flow_imp.g_varchar2_table(134) := 'id) loop'||wwv_flow.LF||
'        l_name := c1.PROJECT;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    return l_name;'||wwv_flow.LF||
'end get_project_name;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'proc';
wwv_flow_imp.g_varchar2_table(135) := 'edure add_project_tag ('||wwv_flow.LF||
'    p_project_id        in number,'||wwv_flow.LF||
'    p_tag               in varchar2)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(136) := '    l_tags varchar2(4000) := null;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    if trim(p_tag) is not null then'||wwv_flow.LF||
'       for c1 in (sele';
wwv_flow_imp.g_varchar2_table(137) := 'ct tags from sp_projects where id = p_project_id) loop'||wwv_flow.LF||
'          l_tags := c1.tags;'||wwv_flow.LF||
'          if c1.';
wwv_flow_imp.g_varchar2_table(138) := 'tags is null then'||wwv_flow.LF||
'             update sp_projects set tags = upper(p_tag) where id = p_project_id;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(139) := '         elsif instr('',''||c1.tags||'','', '',''||upper(p_tag)||'','') = 0 then'||wwv_flow.LF||
'             l_tags := rtri';
wwv_flow_imp.g_varchar2_table(140) := 'm(l_tags,'', '');'||wwv_flow.LF||
'             l_tags := ltrim(l_tags,'','');'||wwv_flow.LF||
'             l_tags := l_tags||'',''||upper(';
wwv_flow_imp.g_varchar2_table(141) := 'p_tag);'||wwv_flow.LF||
'             update sp_projects set tags = l_tags where id = p_project_id;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(142) := '       end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end add_project_tag;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure remove_project_tag ('||wwv_flow.LF||
'    p_project_id  ';
wwv_flow_imp.g_varchar2_table(143) := '      in number,'||wwv_flow.LF||
'    p_tag               in varchar2)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_tags varchar(4000) := null;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(144) := '   update sp_projects set tags = replace(tags,'', '','','') where id = p_project_id;'||wwv_flow.LF||
'    update sp_proje';
wwv_flow_imp.g_varchar2_table(145) := 'cts set tags = rtrim(rtrim(tags,'',''),'' '') where id = p_project_id;'||wwv_flow.LF||
'    update sp_projects set tags =';
wwv_flow_imp.g_varchar2_table(146) := ' ltrim(ltrim(tags,'',''),'' '') where id = p_project_id;'||wwv_flow.LF||
'    for c1 in (select tags from sp_projects whe';
wwv_flow_imp.g_varchar2_table(147) := 're id = p_project_id) loop'||wwv_flow.LF||
'       if c1.tags = upper(p_tag) then'||wwv_flow.LF||
'           update sp_projects set t';
wwv_flow_imp.g_varchar2_table(148) := 'ags = null where id = p_project_id;'||wwv_flow.LF||
'       elsif instr(c1.tags, '',''||upper(p_tag)||'','') > 0 then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(149) := '        update sp_projects set tags = replace(tags,upper(p_tag)||'','',null) where id = p_project_id;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(150) := '       elsif instr(c1.tags, '',''||upper(p_tag)) > 0 then'||wwv_flow.LF||
'           update sp_projects set tags = rep';
wwv_flow_imp.g_varchar2_table(151) := 'lace(tags,'',''||upper(p_tag),null) where id = p_project_id;'||wwv_flow.LF||
'       elsif instr(c1.tags, upper(p_tag))';
wwv_flow_imp.g_varchar2_table(152) := ' > 0 then'||wwv_flow.LF||
'           update sp_projects set tags = replace(tags,upper(p_tag),null) where id = p_proj';
wwv_flow_imp.g_varchar2_table(153) := 'ect_id;'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    update sp_projects set tags = rtrim(tags,'', '') where id = p';
wwv_flow_imp.g_varchar2_table(154) := '_project_id;'||wwv_flow.LF||
'end remove_project_tag;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure set_nomenclature'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(155) := 'select static_id, '||wwv_flow.LF||
'               nvl(custom_value, default_value) nomenclature'||wwv_flow.LF||
'        from SP_APP_';
wwv_flow_imp.g_varchar2_table(156) := 'NOMENCLATURE'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'    '||wwv_flow.LF||
'        if    c1.static_id = ''PROJECTS''    then APEX_UTIL.SET_SESSI';
wwv_flow_imp.g_varchar2_table(157) := 'ON_STATE(''NOMENCLATURE_PROJECTS'',   c1.nomenclature); '||wwv_flow.LF||
'        elsif c1.static_id = ''PROJECT''     th';
wwv_flow_imp.g_varchar2_table(158) := 'en APEX_UTIL.SET_SESSION_STATE(''NOMENCLATURE_PROJECT'',    c1.nomenclature); '||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        elsi';
wwv_flow_imp.g_varchar2_table(159) := 'f c1.static_id = ''AREAS''       then APEX_UTIL.SET_SESSION_STATE(''NOMENCLATURE_AREAS'',      c1.nomenc';
wwv_flow_imp.g_varchar2_table(160) := 'lature);'||wwv_flow.LF||
'        elsif c1.static_id = ''AREA''        then APEX_UTIL.SET_SESSION_STATE(''NOMENCLATURE_A';
wwv_flow_imp.g_varchar2_table(161) := 'REA'',       c1.nomenclature); '||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        elsif c1.static_id = ''INITIATIVES'' then APEX_UTIL.';
wwv_flow_imp.g_varchar2_table(162) := 'SET_SESSION_STATE(''NOMENCLATURE_INITIATIVES'', c1.nomenclature); '||wwv_flow.LF||
'        elsif c1.static_id = ''INITI';
wwv_flow_imp.g_varchar2_table(163) := 'ATIVE''  then APEX_UTIL.SET_SESSION_STATE(''NOMENCLATURE_INITIATIVE'',  c1.nomenclature); '||wwv_flow.LF||
'        --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(164) := '       elsif c1.static_id = ''CONTRIBUTOR''   then APEX_UTIL.SET_SESSION_STATE(''NOMENCLATURE_CONTRIBUT';
wwv_flow_imp.g_varchar2_table(165) := 'OR'',  c1.nomenclature); '||wwv_flow.LF||
'        elsif c1.static_id = ''CONTRIBUTORS''  then APEX_UTIL.SET_SESSION_STA';
wwv_flow_imp.g_varchar2_table(166) := 'TE(''NOMENCLATURE_CONTRIBUTORS'', c1.nomenclature); '||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        elsif c1.static_id ';
wwv_flow_imp.g_varchar2_table(167) := '= ''USERS''       then APEX_UTIL.SET_SESSION_STATE(''NOMENCLATURE_USERS'',       c1.nomenclature); '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(168) := '    elsif c1.static_id = ''USER''        then APEX_UTIL.SET_SESSION_STATE(''NOMENCLATURE_USER'',        ';
wwv_flow_imp.g_varchar2_table(169) := 'c1.nomenclature); '||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        elsif c1.static_id = ''STRATEGIC_PLANNER'' then APEX_UTIL.SET_SE';
wwv_flow_imp.g_varchar2_table(170) := 'SSION_STATE(''NOMENCLATURE_STRATEGIC_PLANNER'', c1.nomenclature); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end s';
wwv_flow_imp.g_varchar2_table(171) := 'et_nomenclature;'||wwv_flow.LF||
''||wwv_flow.LF||
'function show_nomenclature return clob'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'return ''Area:        <strong>''||a';
wwv_flow_imp.g_varchar2_table(172) := 'pex_util.get_session_state(''NOMENCLATURE_AREA'')||''</strong><br>'||wwv_flow.LF||
'Areas:       <strong>''||apex_util.ge';
wwv_flow_imp.g_varchar2_table(173) := 't_session_state(''NOMENCLATURE_AREAS'')||''</strong><br>'||wwv_flow.LF||
'Initiative:  <strong>''||apex_util.get_session_';
wwv_flow_imp.g_varchar2_table(174) := 'state(''NOMENCLATURE_INITIATIVE'')||''</strong><br>'||wwv_flow.LF||
'Initiatives: <strong>''||apex_util.get_session_state';
wwv_flow_imp.g_varchar2_table(175) := '(''NOMENCLATURE_INITIATIVES'')||''</strong><br>'||wwv_flow.LF||
'Projects:    <strong>''||apex_util.get_session_state(''NO';
wwv_flow_imp.g_varchar2_table(176) := 'MENCLATURE_PROJECTS'')||''</strong><br>'||wwv_flow.LF||
'Project:     <strong>''||apex_util.get_session_state(''NOMENCLAT';
wwv_flow_imp.g_varchar2_table(177) := 'URE_PROJECT'')||''</strong><br>'||wwv_flow.LF||
'Contributors:<strong>''||apex_util.get_session_state(''NOMENCLATURE_CONT';
wwv_flow_imp.g_varchar2_table(178) := 'RIBUTORS'')||''</strong><br>'||wwv_flow.LF||
'Contributor: <strong>''||apex_util.get_session_state(''NOMENCLATURE_CONTRIB';
wwv_flow_imp.g_varchar2_table(179) := 'UTOR'')||''</strong><br>'';'||wwv_flow.LF||
'end show_nomenclature;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_nomenclature ('||wwv_flow.LF||
'    p_static_id  in  va';
wwv_flow_imp.g_varchar2_table(180) := 'rchar2 )'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select nvl(custom_value, default_value';
wwv_flow_imp.g_varchar2_table(181) := ') nomenclature'||wwv_flow.LF||
'          from sp_app_nomenclature'||wwv_flow.LF||
'         where static_id = upper(p_static_id)'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(182) := ') loop'||wwv_flow.LF||
'        return c1.nomenclature;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return null;'||wwv_flow.LF||
'end get_nomenclature;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'proce';
wwv_flow_imp.g_varchar2_table(183) := 'dure add_setting (  '||wwv_flow.LF||
'    p_static_id      in  varchar2,   '||wwv_flow.LF||
'    p_description    in  varchar2, '||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(184) := '_setting_value  in  varchar2, '||wwv_flow.LF||
'    p_is_numeric_yn  in  varchar2, '||wwv_flow.LF||
'    p_is_yn          in  varchar2';
wwv_flow_imp.g_varchar2_table(185) := ' ) '||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_is_numeric_yn = ''Y'' and p_is_yn = ''Y'' then '||wwv_flow.LF||
'        raise_application_error(-';
wwv_flow_imp.g_varchar2_table(186) := '20111,''Setting cannot be both numeric and YN.''); '||wwv_flow.LF||
'    end if; '||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_app_settings  '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(187) := '      (static_id, description, is_numeric_yn, is_yn) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'        (p_static_id, p_descriptio';
wwv_flow_imp.g_varchar2_table(188) := 'n, p_is_numeric_yn, p_is_yn); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    set_setting(p_static_id => p_static_id, p_setting_value => p_se';
wwv_flow_imp.g_varchar2_table(189) := 'tting_value); '||wwv_flow.LF||
''||wwv_flow.LF||
'end add_setting;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure set_setting (  '||wwv_flow.LF||
'    p_static_id      in  varchar2,   '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(190) := '   p_setting_value  in  varchar2 ) '||wwv_flow.LF||
'is  '||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'  '||wwv_flow.LF||
'    for c1 in ( '||wwv_flow.LF||
'        select id, '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(191) := '    setting_value,'||wwv_flow.LF||
'               is_numeric_yn, '||wwv_flow.LF||
'               is_yn '||wwv_flow.LF||
'          from sp_app_settin';
wwv_flow_imp.g_varchar2_table(192) := 'gs  '||wwv_flow.LF||
'         where static_id = upper(p_static_id) '||wwv_flow.LF||
'    ) loop '||wwv_flow.LF||
'        if c1.is_numeric_yn = ''Y'' an';
wwv_flow_imp.g_varchar2_table(193) := 'd validate_conversion(p_setting_value as NUMBER) = 0 then '||wwv_flow.LF||
'                raise_application_error(-';
wwv_flow_imp.g_varchar2_table(194) := '20111,''Value must be numeric.''); '||wwv_flow.LF||
'        elsif c1.is_yn = ''Y'' and p_setting_value not in (''Y'',''N'') ';
wwv_flow_imp.g_varchar2_table(195) := 'then  '||wwv_flow.LF||
'            raise_application_error(-20111,''Value must be Y or N.''); '||wwv_flow.LF||
'        end if; '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(196) := '  update sp_app_settings  '||wwv_flow.LF||
'           set setting_value = p_setting_value  '||wwv_flow.LF||
'         where id = c1.i';
wwv_flow_imp.g_varchar2_table(197) := 'd'||wwv_flow.LF||
'           and (p_setting_value != c1.setting_value or c1.setting_value is null or p_setting_value';
wwv_flow_imp.g_varchar2_table(198) := ' is null);  '||wwv_flow.LF||
'    end loop; '||wwv_flow.LF||
''||wwv_flow.LF||
'end set_setting;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_setting ('||wwv_flow.LF||
'    p_static_id  in  varchar2';
wwv_flow_imp.g_varchar2_table(199) := ' )'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select setting_value'||wwv_flow.LF||
'          from sp_app_';
wwv_flow_imp.g_varchar2_table(200) := 'settings'||wwv_flow.LF||
'         where static_id = upper(p_static_id)'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return c1.setting_value;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(201) := '   end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return null;'||wwv_flow.LF||
''||wwv_flow.LF||
'end get_setting;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_ai_prompt (  '||wwv_flow.LF||
'    p_static_id      ';
wwv_flow_imp.g_varchar2_table(202) := 'in  varchar2,   '||wwv_flow.LF||
'    p_description    in  varchar2, '||wwv_flow.LF||
'    p_prompt         in  clob ) '||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(203) := 'insert into sp_ai_prompts  '||wwv_flow.LF||
'        (static_id, description) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'        (p_static_id, p_de';
wwv_flow_imp.g_varchar2_table(204) := 'scription); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    set_ai_prompt(p_static_id => p_static_id, p_prompt => p_prompt); '||wwv_flow.LF||
''||wwv_flow.LF||
'end add_ai_pro';
wwv_flow_imp.g_varchar2_table(205) := 'mpt;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure set_ai_prompt (  '||wwv_flow.LF||
'    p_static_id   in  varchar2,   '||wwv_flow.LF||
'    p_prompt      in  clob ) '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(206) := 'is  '||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'  '||wwv_flow.LF||
'    for c1 in ( '||wwv_flow.LF||
'        select id, prompt '||wwv_flow.LF||
'          from sp_ai_prompts  '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(207) := 'where static_id = upper(p_static_id) '||wwv_flow.LF||
'    ) loop '||wwv_flow.LF||
'        if (c1.prompt is null and p_prompt is not ';
wwv_flow_imp.g_varchar2_table(208) := 'null) or '||wwv_flow.LF||
'           (c1.prompt is not null and p_prompt is null) or'||wwv_flow.LF||
'           c1.prompt != p_promp';
wwv_flow_imp.g_varchar2_table(209) := 't'||wwv_flow.LF||
'        then '||wwv_flow.LF||
'            update sp_ai_prompts '||wwv_flow.LF||
'               set prompt = p_prompt  '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(210) := '  where id = c1.id;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'end set_ai_prompt;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_ai_prompt ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(211) := ' p_static_id  in  varchar2 )'||wwv_flow.LF||
'    return clob'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select prompt'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(212) := '   from sp_ai_prompts'||wwv_flow.LF||
'         where static_id = upper(p_static_id)'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return c1.pro';
wwv_flow_imp.g_varchar2_table(213) := 'mpt;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return null;'||wwv_flow.LF||
''||wwv_flow.LF||
'end get_ai_prompt;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_notification_id ('||wwv_flow.LF||
'    p_stat';
wwv_flow_imp.g_varchar2_table(214) := 'ic_id   in  varchar2 )'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select id'||wwv_flow.LF||
'          from ';
wwv_flow_imp.g_varchar2_table(215) := 'sp_notifications'||wwv_flow.LF||
'         where static_id = upper(p_static_id)'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return c1.id;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(216) := 'end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return null;'||wwv_flow.LF||
''||wwv_flow.LF||
'end get_notification_id;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure notification_opt_in ('||wwv_flow.LF||
'    p_team_m';
wwv_flow_imp.g_varchar2_table(217) := 'ember_id   in  number,'||wwv_flow.LF||
'    p_notification_id  in  number,'||wwv_flow.LF||
'    p_frequency        in  varchar2 defaul';
wwv_flow_imp.g_varchar2_table(218) := 't ''WEEKLY'','||wwv_flow.LF||
'    p_release_id       in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        sele';
wwv_flow_imp.g_varchar2_table(219) := 'ct count(*) cnt'||wwv_flow.LF||
'          from sp_notification_subscriptions'||wwv_flow.LF||
'         where team_member_id = p_team_';
wwv_flow_imp.g_varchar2_table(220) := 'member_id'||wwv_flow.LF||
'           and notification_id = p_notification_id'||wwv_flow.LF||
'           and (release_id = p_release_';
wwv_flow_imp.g_varchar2_table(221) := 'id or p_release_id is null)'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        if c1.cnt = 0 then'||wwv_flow.LF||
'            insert into sp_notific';
wwv_flow_imp.g_varchar2_table(222) := 'ation_subscriptions'||wwv_flow.LF||
'                (team_member_id, notification_id, frequency, release_id, opted_i';
wwv_flow_imp.g_varchar2_table(223) := 'n_yn)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (p_team_member_id, p_notification_id, p_frequency, p_releas';
wwv_flow_imp.g_varchar2_table(224) := 'e_id, ''Y'');'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            update sp_notification_subscriptions'||wwv_flow.LF||
'               set opted_i';
wwv_flow_imp.g_varchar2_table(225) := 'n_yn = ''Y'''||wwv_flow.LF||
'             where team_member_id = p_team_member_id'||wwv_flow.LF||
'               and notification_id =';
wwv_flow_imp.g_varchar2_table(226) := ' p_notification_id'||wwv_flow.LF||
'               and (release_id = p_release_id or p_release_id is null);'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(227) := '   update sp_notification_subscriptions'||wwv_flow.LF||
'               set frequency = p_frequency'||wwv_flow.LF||
'             wher';
wwv_flow_imp.g_varchar2_table(228) := 'e team_member_id = p_team_member_id'||wwv_flow.LF||
'               and notification_id = p_notification_id'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(229) := '      and (release_id = p_release_id or p_release_id is null)'||wwv_flow.LF||
'               and frequency != p_freq';
wwv_flow_imp.g_varchar2_table(230) := 'uency;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end notification_opt_in;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure notification_opt_out ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(231) := ' p_team_member_id   in  number,'||wwv_flow.LF||
'    p_notification_id  in  number,'||wwv_flow.LF||
'    p_release_id       in  number';
wwv_flow_imp.g_varchar2_table(232) := ' default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select id'||wwv_flow.LF||
'          from sp_notification_subscripti';
wwv_flow_imp.g_varchar2_table(233) := 'ons'||wwv_flow.LF||
'         where team_member_id = p_team_member_id'||wwv_flow.LF||
'           and notification_id = p_notification';
wwv_flow_imp.g_varchar2_table(234) := '_id'||wwv_flow.LF||
'           and (release_id = p_release_id or p_release_id is null)'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        update sp_';
wwv_flow_imp.g_varchar2_table(235) := 'notification_subscriptions'||wwv_flow.LF||
'           set opted_in_yn = ''N'''||wwv_flow.LF||
'         where id = c1.id'||wwv_flow.LF||
'           and';
wwv_flow_imp.g_varchar2_table(236) := ' opted_in_yn != ''N'';'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end notification_opt_out;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure get_create_project_qp ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(237) := ' p_app_user         in varchar2,'||wwv_flow.LF||
'    p_quick_pick_id_1  out number,'||wwv_flow.LF||
'    p_quick_pick_1     out varch';
wwv_flow_imp.g_varchar2_table(238) := 'ar2,'||wwv_flow.LF||
'    p_quick_pick_id_2  out number,'||wwv_flow.LF||
'    p_quick_pick_2     out varchar2,'||wwv_flow.LF||
'    p_quick_pick_id_3  ';
wwv_flow_imp.g_varchar2_table(239) := 'out number,'||wwv_flow.LF||
'    p_quick_pick_3     out varchar2,'||wwv_flow.LF||
'    p_quick_pick_id_4  out number,'||wwv_flow.LF||
'    p_quick_pick';
wwv_flow_imp.g_varchar2_table(240) := '_4     out varchar2'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    c int := 0;'||wwv_flow.LF||
'    l_quick_pick_id_1   number        := null;'||wwv_flow.LF||
'    l_q';
wwv_flow_imp.g_varchar2_table(241) := 'uick_pick_1      varchar2(255) := null;'||wwv_flow.LF||
'    l_quick_pick_id_2   number        := null;'||wwv_flow.LF||
'    l_quick_p';
wwv_flow_imp.g_varchar2_table(242) := 'ick_2      varchar2(255) := null;'||wwv_flow.LF||
'    l_quick_pick_id_3   number        := null;'||wwv_flow.LF||
'    l_quick_pick_3 ';
wwv_flow_imp.g_varchar2_table(243) := '     varchar2(255) := null;'||wwv_flow.LF||
'    l_quick_pick_id_4   number        := null;'||wwv_flow.LF||
'    l_quick_pick_4      v';
wwv_flow_imp.g_varchar2_table(244) := 'archar2(255) := null;'||wwv_flow.LF||
'    l_app_user_id       number        := null;'||wwv_flow.LF||
'    l_app_user          varchar';
wwv_flow_imp.g_varchar2_table(245) := '2(255) := null;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    -- get top 4 project owners'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select t.first_name||';
wwv_flow_imp.g_varchar2_table(246) := ''' ''||t.last_name||'' (''||t.email||'')'' n, p.owner_id, count(*) c '||wwv_flow.LF||
'        from sp_projects p, sp_team_';
wwv_flow_imp.g_varchar2_table(247) := 'members t '||wwv_flow.LF||
'        where p.owner_id = t.id '||wwv_flow.LF||
'        group by t.first_name||'' ''||t.last_name||'' (''||t';
wwv_flow_imp.g_varchar2_table(248) := '.email||'')'', p.owner_id '||wwv_flow.LF||
'        order by 3 desc '||wwv_flow.LF||
'        fetch first 5 rows only) loop'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(249) := 'c := c + 1;'||wwv_flow.LF||
'            if c = 1 then '||wwv_flow.LF||
'                l_quick_pick_id_1 := c1.owner_id; '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(250) := '      l_quick_pick_1    := c1.n;'||wwv_flow.LF||
'            elsif c = 2 then '||wwv_flow.LF||
'                l_quick_pick_id_2 := ';
wwv_flow_imp.g_varchar2_table(251) := 'c1.owner_id; '||wwv_flow.LF||
'                l_quick_pick_2    := c1.n;'||wwv_flow.LF||
'            elsif c = 3 then '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(252) := '   l_quick_pick_id_3 := c1.owner_id; '||wwv_flow.LF||
'                l_quick_pick_3    := c1.n;'||wwv_flow.LF||
'            elsif c';
wwv_flow_imp.g_varchar2_table(253) := ' = 4 then '||wwv_flow.LF||
'                l_quick_pick_id_4 := c1.owner_id; '||wwv_flow.LF||
'                l_quick_pick_4    := c';
wwv_flow_imp.g_varchar2_table(254) := '1.n;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- make sure the current user is on the list'||wwv_flow.LF||
'    for c1 ';
wwv_flow_imp.g_varchar2_table(255) := 'in (select id, t.first_name||'' ''||t.last_name||'' (''||t.email||'')'' n from SP_TEAM_MEMBERS t where t.e';
wwv_flow_imp.g_varchar2_table(256) := 'mail = lower(p_app_user)) loop'||wwv_flow.LF||
'        l_app_user_id := c1.id;'||wwv_flow.LF||
'        l_app_user := c1.n;'||wwv_flow.LF||
'    end l';
wwv_flow_imp.g_varchar2_table(257) := 'oop;'||wwv_flow.LF||
'    if l_app_user_id = l_quick_pick_id_1 or '||wwv_flow.LF||
'       l_app_user_id = l_quick_pick_id_2 or '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(258) := '  l_app_user_id = l_quick_pick_id_3 or '||wwv_flow.LF||
'       l_app_user_id = l_quick_pick_id_4 then'||wwv_flow.LF||
'        null;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(259) := '    else'||wwv_flow.LF||
'       l_quick_pick_id_4 := l_app_user_id;'||wwv_flow.LF||
'       l_quick_pick_4 := l_app_user;'||wwv_flow.LF||
'    end if;';
wwv_flow_imp.g_varchar2_table(260) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'    -- set return values'||wwv_flow.LF||
'    p_quick_pick_id_1  := l_quick_pick_id_1 ;'||wwv_flow.LF||
'    p_quick_pick_1     := l';
wwv_flow_imp.g_varchar2_table(261) := '_quick_pick_1    ;'||wwv_flow.LF||
'    p_quick_pick_id_2  := l_quick_pick_id_2 ;'||wwv_flow.LF||
'    p_quick_pick_2     := l_quick_p';
wwv_flow_imp.g_varchar2_table(262) := 'ick_2   ;'||wwv_flow.LF||
'    p_quick_pick_id_3  := l_quick_pick_id_3 ;'||wwv_flow.LF||
'    p_quick_pick_3     := l_quick_pick_3   ;';
wwv_flow_imp.g_varchar2_table(263) := ''||wwv_flow.LF||
'    p_quick_pick_id_4  := l_quick_pick_id_4 ;'||wwv_flow.LF||
'    p_quick_pick_4     := l_quick_pick_4    ;'||wwv_flow.LF||
'end get';
wwv_flow_imp.g_varchar2_table(264) := '_create_project_qp;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure get_current_username_and_id ('||wwv_flow.LF||
'    p_app_user         in varchar2,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(265) := ' p_users_name       out varchar2,'||wwv_flow.LF||
'    p_users_id         out number'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_users_name varch';
wwv_flow_imp.g_varchar2_table(266) := 'ar(255) := null;'||wwv_flow.LF||
'    l_users_id   number := null;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    for c1 in (select first_name, last_name';
wwv_flow_imp.g_varchar2_table(267) := ', id from SP_TEAM_MEMBERS where email = lower(p_app_user)) loop '||wwv_flow.LF||
'        l_users_name := c1.first_na';
wwv_flow_imp.g_varchar2_table(268) := 'me || '' '' || c1.last_name;'||wwv_flow.LF||
'        l_users_id := c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    p_users_name := l_users_na';
wwv_flow_imp.g_varchar2_table(269) := 'me;'||wwv_flow.LF||
'    p_users_id := p_users_id;'||wwv_flow.LF||
'end get_current_username_and_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------'||wwv_flow.LF||
'-- data sync'||wwv_flow.LF||
'--'||wwv_flow.LF||
''||wwv_flow.LF||
'p';
wwv_flow_imp.g_varchar2_table(270) := 'rocedure sync_team_members_app_role ('||wwv_flow.LF||
'    p_app_id in number)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'       selec';
wwv_flow_imp.g_varchar2_table(271) := 't '||wwv_flow.LF||
'           t.id,'||wwv_flow.LF||
'           t.first_name,'||wwv_flow.LF||
'           t.last_name,'||wwv_flow.LF||
'           t.email,'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(272) := 'nvl(t.APP_ROLE,''Unknown'') current_app_role,'||wwv_flow.LF||
'           nvl(('||wwv_flow.LF||
'            select'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(273) := 'decode(instr(role_names,''Administrator''),0,'||wwv_flow.LF||
'                    decode(instr(role_names,''Contributor';
wwv_flow_imp.g_varchar2_table(274) := '''),0,'||wwv_flow.LF||
'                    decode(instr(role_names,''Reader''),0,''No Access'',''Reader''),'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(275) := '     ''Contributor''),'||wwv_flow.LF||
'                    ''Administrator'') role_names'||wwv_flow.LF||
'             from   APEX_APPL_A';
wwv_flow_imp.g_varchar2_table(276) := 'CL_USERS u '||wwv_flow.LF||
'             where  u.APPLICATION_ID = p_app_id and '||wwv_flow.LF||
'                    u.user_name_lc ';
wwv_flow_imp.g_varchar2_table(277) := '= t.email'||wwv_flow.LF||
'             ),'||wwv_flow.LF||
'             ''No Access'') app_role'||wwv_flow.LF||
'        from sp_team_members t'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(278) := 'where nvl(('||wwv_flow.LF||
'            select'||wwv_flow.LF||
'                    decode(instr(role_names,''Administrator''),0,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(279) := '               decode(instr(role_names,''Contributor''),0,'||wwv_flow.LF||
'                    decode(instr(role_names';
wwv_flow_imp.g_varchar2_table(280) := ',''Reader''),0,''No Access'',''Reader''),'||wwv_flow.LF||
'                    ''Contributor''),'||wwv_flow.LF||
'                    ''Adminis';
wwv_flow_imp.g_varchar2_table(281) := 'trator'') role_names'||wwv_flow.LF||
'             from   APEX_APPL_ACL_USERS u '||wwv_flow.LF||
'             where  u.APPLICATION_ID ';
wwv_flow_imp.g_varchar2_table(282) := '= p_app_id and '||wwv_flow.LF||
'                    u.user_name_lc = t.email),'||wwv_flow.LF||
'             ''No Access'') != nvl(t.AP';
wwv_flow_imp.g_varchar2_table(283) := 'P_ROLE,''Unknown'')'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            update sp_team_members'||wwv_flow.LF||
'            set app_role = c1.ap';
wwv_flow_imp.g_varchar2_table(284) := 'p_role'||wwv_flow.LF||
'            where id = c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end sync_team_members_app_role;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure sync_t';
wwv_flow_imp.g_varchar2_table(285) := 'eam_member_app_role ('||wwv_flow.LF||
'    p_app_id in number,'||wwv_flow.LF||
'    p_email  in varchar2)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(286) := '     select '||wwv_flow.LF||
'           t.id,'||wwv_flow.LF||
'           t.first_name,'||wwv_flow.LF||
'           t.last_name,'||wwv_flow.LF||
'           t.email,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(287) := '          nvl(t.APP_ROLE,''Unknown'') current_app_role,'||wwv_flow.LF||
'           nvl(('||wwv_flow.LF||
'            select'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(288) := '          decode(instr(role_names,''Administrator''),0,'||wwv_flow.LF||
'                    decode(instr(role_names,''C';
wwv_flow_imp.g_varchar2_table(289) := 'ontributor''),0,'||wwv_flow.LF||
'                    decode(instr(role_names,''Reader''),0,''No Access'',''Reader''),'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(290) := '               ''Contributor''),'||wwv_flow.LF||
'                    ''Administrator'') role_names'||wwv_flow.LF||
'             from   A';
wwv_flow_imp.g_varchar2_table(291) := 'PEX_APPL_ACL_USERS u '||wwv_flow.LF||
'             where  u.APPLICATION_ID = p_app_id and '||wwv_flow.LF||
'                    u.use';
wwv_flow_imp.g_varchar2_table(292) := 'r_name_lc = t.email'||wwv_flow.LF||
'             ),'||wwv_flow.LF||
'             ''No Access'') app_role'||wwv_flow.LF||
'        from sp_team_members ';
wwv_flow_imp.g_varchar2_table(293) := 't'||wwv_flow.LF||
'        where nvl(('||wwv_flow.LF||
'            select'||wwv_flow.LF||
'                    decode(instr(role_names,''Administrator''';
wwv_flow_imp.g_varchar2_table(294) := '),0,'||wwv_flow.LF||
'                    decode(instr(role_names,''Contributor''),0,'||wwv_flow.LF||
'                    decode(instr(';
wwv_flow_imp.g_varchar2_table(295) := 'role_names,''Reader''),0,''No Access'',''Reader''),'||wwv_flow.LF||
'                    ''Contributor''),'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(296) := '  ''Administrator'') role_names'||wwv_flow.LF||
'             from   APEX_APPL_ACL_USERS u '||wwv_flow.LF||
'             where  u.APPLI';
wwv_flow_imp.g_varchar2_table(297) := 'CATION_ID = p_app_id and USER_NAME_LC = lower(p_email)),'||wwv_flow.LF||
'             ''No Access'') != nvl(t.APP_ROLE';
wwv_flow_imp.g_varchar2_table(298) := ',''Unknown'')'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            update sp_team_members'||wwv_flow.LF||
'            set app_role = c1.app_role';
wwv_flow_imp.g_varchar2_table(299) := ''||wwv_flow.LF||
'            where id = c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end sync_team_member_app_role;'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------'||wwv_flow.LF||
'-- Tags'||wwv_flow.LF||
'-';
wwv_flow_imp.g_varchar2_table(300) := '-'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_default_tag ('||wwv_flow.LF||
'    p_tag        in varchar2,'||wwv_flow.LF||
'    p_sequence   in number default null';
wwv_flow_imp.g_varchar2_table(301) := ')'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_seq number := p_sequence;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if l_seq is null then '||wwv_flow.LF||
'        for c1 in (select max';
wwv_flow_imp.g_varchar2_table(302) := '(DISPLAY_SEQUENCE) mds from SP_DEFAULT_TAGS) loop'||wwv_flow.LF||
'            l_seq := c1.mds + 10;'||wwv_flow.LF||
'        end loop';
wwv_flow_imp.g_varchar2_table(303) := ';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    insert into SP_DEFAULT_TAGS (DISPLAY_SEQUENCE, tag) values (l_seq, upper(p_tag));'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(304) := 'end add_default_tag;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure get_default_tags ('||wwv_flow.LF||
'    p_tag_1      out varchar2,'||wwv_flow.LF||
'    p_tag_2      o';
wwv_flow_imp.g_varchar2_table(305) := 'ut varchar2,'||wwv_flow.LF||
'    p_tag_3      out varchar2,'||wwv_flow.LF||
'    p_tag_4      out varchar2,'||wwv_flow.LF||
'    p_tag_5      out varc';
wwv_flow_imp.g_varchar2_table(306) := 'har2,'||wwv_flow.LF||
'    p_tag_6      out varchar2)'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    c int := 0;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    p_tag_1 := null;'||wwv_flow.LF||
'    p_tag_2 := nu';
wwv_flow_imp.g_varchar2_table(307) := 'll;'||wwv_flow.LF||
'    p_tag_3 := null;'||wwv_flow.LF||
'    p_tag_4 := null;'||wwv_flow.LF||
'    p_tag_5 := null;'||wwv_flow.LF||
'    p_tag_6 := null;'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 ';
wwv_flow_imp.g_varchar2_table(308) := 'in (select tag from SP_DEFAULT_TAGS order by display_sequence, tag) loop'||wwv_flow.LF||
'        c := c + 1;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(309) := ' if    c = 1 then p_tag_1 := c1.tag;'||wwv_flow.LF||
'        elsif c = 2 then p_tag_2 := c1.tag;'||wwv_flow.LF||
'        elsif c = 3';
wwv_flow_imp.g_varchar2_table(310) := ' then p_tag_3 := c1.tag;'||wwv_flow.LF||
'        elsif c = 4 then p_tag_4 := c1.tag;'||wwv_flow.LF||
'        elsif c = 5 then p_tag_';
wwv_flow_imp.g_varchar2_table(311) := '5 := c1.tag;'||wwv_flow.LF||
'        elsif c = 6 then p_tag_6 := c1.tag;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end get_defau';
wwv_flow_imp.g_varchar2_table(312) := 'lt_tags;'||wwv_flow.LF||
''||wwv_flow.LF||
'function prepare_tags ('||wwv_flow.LF||
'    p_tags in varchar2)'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_tags  varcha';
wwv_flow_imp.g_varchar2_table(313) := 'r2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- remove whitespace, have leading and trailing commas to facilitate ins';
wwv_flow_imp.g_varchar2_table(314) := 'tr'||wwv_flow.LF||
'    l_tags := trim(upper(p_tags));'||wwv_flow.LF||
'    l_tags := '',''||l_tags||'','';'||wwv_flow.LF||
'    l_tags := replace(l_tags,c';
wwv_flow_imp.g_varchar2_table(315) := 'hr(9),'' '');'||wwv_flow.LF||
'    for i in 1..5 loop '||wwv_flow.LF||
'        l_tags := replace(l_tags,'', '','',''); '||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    l';
wwv_flow_imp.g_varchar2_table(316) := '_tags := replace(l_tags,'',,'','','');'||wwv_flow.LF||
'    return l_tags;'||wwv_flow.LF||
'end prepare_tags;'||wwv_flow.LF||
''||wwv_flow.LF||
'function reformat_tags ('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(317) := '  p_tags in varchar2) '||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_tags varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- call ';
wwv_flow_imp.g_varchar2_table(318) := 'this after calling prepare tags to reformat to friendly format'||wwv_flow.LF||
'    l_tags := ltrim(p_tags,'','');'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(319) := 'l_tags := rtrim(l_tags,'','');'||wwv_flow.LF||
'    l_tags := replace(l_tags,'','','', '');'||wwv_flow.LF||
'    return l_tags;'||wwv_flow.LF||
'end reformat';
wwv_flow_imp.g_varchar2_table(320) := '_tags;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function count_project_tags ('||wwv_flow.LF||
'    p_project_id in number)'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_tag_c';
wwv_flow_imp.g_varchar2_table(321) := 'ount number := 0;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    for c1 in (select tags from sp_projects where id = p_project_id and tag';
wwv_flow_imp.g_varchar2_table(322) := 's is not null) loop'||wwv_flow.LF||
'       l_tag_count := 1 + length(c1.tags) - length(replace(c1.tags,'','',null));'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(323) := '   end loop;'||wwv_flow.LF||
'    return l_tag_count;'||wwv_flow.LF||
'end count_project_tags;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_project_id ('||wwv_flow.LF||
'    p_frien';
wwv_flow_imp.g_varchar2_table(324) := 'dly_identifier in varchar2,'||wwv_flow.LF||
'    p_project_url_name    in varchar2)'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_id num';
wwv_flow_imp.g_varchar2_table(325) := 'ber := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if p_friendly_identifier is not null then'||wwv_flow.LF||
'       for c1 in (select id from sp';
wwv_flow_imp.g_varchar2_table(326) := '_projects where FRIENDLY_IDENTIFIER = p_friendly_identifier) loop'||wwv_flow.LF||
'            l_id := c1.id;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(327) := '     exit;'||wwv_flow.LF||
'       end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if l_id is null and p_project_url_name is not null then ';
wwv_flow_imp.g_varchar2_table(328) := ''||wwv_flow.LF||
'       for c1 in (select id from sp_projects where PROJECT_URL_NAME = p_project_url_name) loop'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(329) := '        l_id := c1.id;'||wwv_flow.LF||
'            exit;'||wwv_flow.LF||
'       end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    return l_id;'||wwv_flow.LF||
'end get_proje';
wwv_flow_imp.g_varchar2_table(330) := 'ct_id;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_initiative_id ('||wwv_flow.LF||
'    p_friendly_identifier    in varchar2,'||wwv_flow.LF||
'    p_initiative_url';
wwv_flow_imp.g_varchar2_table(331) := '_name    in varchar2)'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_id number := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if p_friendly_identifi';
wwv_flow_imp.g_varchar2_table(332) := 'er is not null then'||wwv_flow.LF||
'       for c1 in (select id from sp_initiatives where FRIENDLY_IDENTIFIER = p_fr';
wwv_flow_imp.g_varchar2_table(333) := 'iendly_identifier) loop'||wwv_flow.LF||
'            l_id := c1.id;'||wwv_flow.LF||
'            exit;'||wwv_flow.LF||
'       end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(334) := '  if l_id is null and p_initiative_url_name is not null then '||wwv_flow.LF||
'       for c1 in (select id from sp_in';
wwv_flow_imp.g_varchar2_table(335) := 'itiatives where INITIATIVE_URL_NAME = p_initiative_url_name) loop'||wwv_flow.LF||
'            l_id := c1.id;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(336) := '     exit;'||wwv_flow.LF||
'       end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    return l_id;'||wwv_flow.LF||
'end get_initiative_id;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'------------------';
wwv_flow_imp.g_varchar2_table(337) := '--'||wwv_flow.LF||
'-- Utility Functions'||wwv_flow.LF||
'--'||wwv_flow.LF||
''||wwv_flow.LF||
'function compress_int (n in integer ) return varchar2'||wwv_flow.LF||
'as'||wwv_flow.LF||
'   ret       va';
wwv_flow_imp.g_varchar2_table(338) := 'rchar2(30);'||wwv_flow.LF||
'   quotient  integer;'||wwv_flow.LF||
'   remainder integer;'||wwv_flow.LF||
'   digit     char(1);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   ret := null; ';
wwv_flow_imp.g_varchar2_table(339) := 'quotient := n;'||wwv_flow.LF||
'   while quotient > 0'||wwv_flow.LF||
'   loop'||wwv_flow.LF||
'       remainder := mod(quotient, 10 + 26);'||wwv_flow.LF||
'       quot';
wwv_flow_imp.g_varchar2_table(340) := 'ient := floor(quotient  / (10 + 26));'||wwv_flow.LF||
'       if remainder < 26 then'||wwv_flow.LF||
'           digit := chr(ascii(''A';
wwv_flow_imp.g_varchar2_table(341) := ''') + remainder);'||wwv_flow.LF||
'       else'||wwv_flow.LF||
'           digit := chr(ascii(''0'') + remainder - 26);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(342) := '     ret := digit || ret;'||wwv_flow.LF||
'   end loop ;'||wwv_flow.LF||
'   if length(ret) < 5 then ret := lpad(ret, 4, ''A''); end if ';
wwv_flow_imp.g_varchar2_table(343) := ';'||wwv_flow.LF||
'   return upper(ret);'||wwv_flow.LF||
'end compress_int;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- mostly used in comments but could be helpful elsewher';
wwv_flow_imp.g_varchar2_table(344) := 'e'||wwv_flow.LF||
'function find_mentions ('||wwv_flow.LF||
'    p_clob in clob )'||wwv_flow.LF||
'    return varchar2 '||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_clob               clo';
wwv_flow_imp.g_varchar2_table(345) := 'b;'||wwv_flow.LF||
'    l_mention_list       varchar2(4000) := null;'||wwv_flow.LF||
'    l_pos                integer := 1;'||wwv_flow.LF||
'    l_mat';
wwv_flow_imp.g_varchar2_table(346) := 'ch              varchar2(320);'||wwv_flow.LF||
'    l_clob_length        integer;'||wwv_flow.LF||
'    l_screen_name_exists boolean :=';
wwv_flow_imp.g_varchar2_table(347) := ' false;'||wwv_flow.LF||
'    l_user_id            number;'||wwv_flow.LF||
'    l_loop_count         integer := 0;'||wwv_flow.LF||
'    l_max_loops     ';
wwv_flow_imp.g_varchar2_table(348) := '     integer := 100;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- remove characters considered trailing white space'||wwv_flow.LF||
'    l_clob := re';
wwv_flow_imp.g_varchar2_table(349) := 'place(p_clob, ''+'', '' ''); -- remove all plus'||wwv_flow.LF||
'    l_clob := replace(l_clob, ''.'', '' ''); -- remove all d';
wwv_flow_imp.g_varchar2_table(350) := 'ots'||wwv_flow.LF||
'    l_clob := replace(l_clob, '','', '' ''); -- remove all commas'||wwv_flow.LF||
'    l_clob := replace(l_clob, ''@'',';
wwv_flow_imp.g_varchar2_table(351) := ' '' @''); -- prefix at sign with white space'||wwv_flow.LF||
'    -- Get the length of the input CLOB'||wwv_flow.LF||
'    l_clob_length';
wwv_flow_imp.g_varchar2_table(352) := ' := DBMS_LOB.GETLENGTH(l_clob);'||wwv_flow.LF||
'    -- Loop through the CLOB to extract mentions using regex'||wwv_flow.LF||
'    WHI';
wwv_flow_imp.g_varchar2_table(353) := 'LE l_pos <= l_clob_length loop'||wwv_flow.LF||
'        if l_loop_count > l_max_loops then'||wwv_flow.LF||
'            exit; -- preve';
wwv_flow_imp.g_varchar2_table(354) := 'nt infinite loop'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        l_match := null;'||wwv_flow.LF||
'        l_match := REGEXP_SUBSTR(l_clob,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(355) := '                                ''@\S+'',  -- Match "@" followed by non-whitespace characters'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(356) := '                         l_pos, 1);'||wwv_flow.LF||
'        EXIT WHEN l_match IS NULL;'||wwv_flow.LF||
'        -- clean l_match'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(357) := '    l_match := lower(trim(l_match));'||wwv_flow.LF||
'        l_match := ltrim(l_match,''@''); -- remove leading at sig';
wwv_flow_imp.g_varchar2_table(358) := 'ns'||wwv_flow.LF||
'        l_match := rtrim(l_match,''.,;:"''''\/-|!#$%^&*()[]'');'||wwv_flow.LF||
'        -- locate screen name in team';
wwv_flow_imp.g_varchar2_table(359) := ' members table'||wwv_flow.LF||
'        l_screen_name_exists := false;'||wwv_flow.LF||
'        -- see if screen name exists in databa';
wwv_flow_imp.g_varchar2_table(360) := 'se, note stored as lower case'||wwv_flow.LF||
'        for c1 in (select id from sp_team_members tm where tm.screen_n';
wwv_flow_imp.g_varchar2_table(361) := 'ame = l_match) loop'||wwv_flow.LF||
'            l_screen_name_exists := true;'||wwv_flow.LF||
'            exit;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(362) := '      -- see if name already exists in string, e.g. avoid returning duplicate names'||wwv_flow.LF||
'        if l_scr';
wwv_flow_imp.g_varchar2_table(363) := 'een_name_exists and'||wwv_flow.LF||
'           instr('':''||l_mention_list||'':'','':''||l_match||'':'') > 0 then'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(364) := ' l_screen_name_exists := false;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- Append to the mention list'||wwv_flow.LF||
'        if l_s';
wwv_flow_imp.g_varchar2_table(365) := 'creen_name_exists then'||wwv_flow.LF||
'            if l_mention_list is not null then'||wwv_flow.LF||
'                l_mention_list';
wwv_flow_imp.g_varchar2_table(366) := ' := l_mention_list || '':'' || l_match;'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'                l_mention_list := l_match;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(367) := '          end if;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- Move position forward to continue searching'||wwv_flow.LF||
'        l_p';
wwv_flow_imp.g_varchar2_table(368) := 'os := INSTR(l_clob, l_match, l_pos) + LENGTH(l_match);'||wwv_flow.LF||
'        l_loop_count := l_loop_count + 1;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(369) := ' end loop;'||wwv_flow.LF||
'    return l_mention_list;'||wwv_flow.LF||
'end find_mentions;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function list_change ('||wwv_flow.LF||
'    p_old_list   i';
wwv_flow_imp.g_varchar2_table(370) := 'n varchar2 default null, '||wwv_flow.LF||
'    p_new_list   in varchar2 default null, '||wwv_flow.LF||
'    p_delim      in varchar2 d';
wwv_flow_imp.g_varchar2_table(371) := 'efault '','')'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'as'||wwv_flow.LF||
'    l_old_array           apex_t_varchar2;'||wwv_flow.LF||
'    l_new_array       ';
wwv_flow_imp.g_varchar2_table(372) := '    apex_t_varchar2;'||wwv_flow.LF||
'    l_added               varchar2(4000) := null;'||wwv_flow.LF||
'    l_removed             var';
wwv_flow_imp.g_varchar2_table(373) := 'char2(4000) := null;'||wwv_flow.LF||
'    l_found               boolean := false;'||wwv_flow.LF||
'    l_action              varchar2(';
wwv_flow_imp.g_varchar2_table(374) := '32767) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- determine list changes including nulls'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if p_old_list ';
wwv_flow_imp.g_varchar2_table(375) := 'is null and p_new_list is null then'||wwv_flow.LF||
'        l_action := ''No Values'';'||wwv_flow.LF||
'    elsif p_old_list is not nul';
wwv_flow_imp.g_varchar2_table(376) := 'l and p_new_list is null then '||wwv_flow.LF||
'        l_removed := p_old_list;'||wwv_flow.LF||
'        l_action := ''All values remo';
wwv_flow_imp.g_varchar2_table(377) := 'ved'';'||wwv_flow.LF||
'    elsif p_old_list is null and p_new_list is not null then '||wwv_flow.LF||
'        l_added := ''"''||p_new_li';
wwv_flow_imp.g_varchar2_table(378) := 'st||''"'';'||wwv_flow.LF||
'        l_action := ''First values added'';'||wwv_flow.LF||
'    elsif p_old_list = p_new_list then'||wwv_flow.LF||
'        l_';
wwv_flow_imp.g_varchar2_table(379) := 'action := ''No change'';'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        l_action := ''Values changed'';'||wwv_flow.LF||
'       l_old_array := apex_str';
wwv_flow_imp.g_varchar2_table(380) := 'ing.split(p_str => p_old_list, p_sep => nvl(p_delim,'',''));'||wwv_flow.LF||
'       l_new_array := apex_string.split(p';
wwv_flow_imp.g_varchar2_table(381) := '_str => p_new_list, p_sep => nvl(p_delim,'',''));'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- added'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       for i in ';
wwv_flow_imp.g_varchar2_table(382) := '1..l_new_array.count loop '||wwv_flow.LF||
'           l_found := false;'||wwv_flow.LF||
'           for j in 1..l_old_array.count loo';
wwv_flow_imp.g_varchar2_table(383) := 'p'||wwv_flow.LF||
'                if trim(l_new_array(i)) = trim(l_old_array(j)) then '||wwv_flow.LF||
'                   l_found :=';
wwv_flow_imp.g_varchar2_table(384) := ' true;'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'           end loop;'||wwv_flow.LF||
'           if not l_fou';
wwv_flow_imp.g_varchar2_table(385) := 'nd then '||wwv_flow.LF||
'               l_added := l_added||''"''||trim(l_new_array(i))||''", '';'||wwv_flow.LF||
'           end if;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(386) := '    end loop;'||wwv_flow.LF||
'       l_added := rtrim(l_added,'', '');'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- removed'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       fo';
wwv_flow_imp.g_varchar2_table(387) := 'r i in 1..l_old_array.count loop '||wwv_flow.LF||
'           l_found := false;'||wwv_flow.LF||
'           for j in 1..l_new_array.co';
wwv_flow_imp.g_varchar2_table(388) := 'unt loop'||wwv_flow.LF||
'                if trim(l_old_array(i)) = trim(l_new_array(j)) then '||wwv_flow.LF||
'                   l_f';
wwv_flow_imp.g_varchar2_table(389) := 'ound := true;'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'           end loop;'||wwv_flow.LF||
'           if no';
wwv_flow_imp.g_varchar2_table(390) := 't l_found then '||wwv_flow.LF||
'               l_removed := l_removed||''"''||trim(l_old_array(i))||''", '';'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(391) := 'end if;'||wwv_flow.LF||
'       end loop;'||wwv_flow.LF||
'       l_removed := rtrim(l_removed,'', '');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if l_added is no';
wwv_flow_imp.g_varchar2_table(392) := 't null and l_removed is null then'||wwv_flow.LF||
'       l_action := ''added ''||trim(l_added);'||wwv_flow.LF||
'    elsif l_added is n';
wwv_flow_imp.g_varchar2_table(393) := 'ull and l_removed is not null then '||wwv_flow.LF||
'       l_action := ''removed ''||trim(l_removed);'||wwv_flow.LF||
'    elsif l_adde';
wwv_flow_imp.g_varchar2_table(394) := 'd is not null and l_added is not null then '||wwv_flow.LF||
'       l_action := ''added ''||trim(l_added)||'' and remove';
wwv_flow_imp.g_varchar2_table(395) := 'd ''||trim(l_removed);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    return l_action;'||wwv_flow.LF||
'end list_change;'||wwv_flow.LF||
''||wwv_flow.LF||
'--------------------'||wwv_flow.LF||
'-- for';
wwv_flow_imp.g_varchar2_table(396) := ' Notification Subscriptions'||wwv_flow.LF||
'--'||wwv_flow.LF||
'procedure send_notif_subscriptions'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_app_id         varchar2(3';
wwv_flow_imp.g_varchar2_table(397) := '0);'||wwv_flow.LF||
'    l_app_url        varchar2(4000);'||wwv_flow.LF||
'    l_app_name       varchar2(4000);'||wwv_flow.LF||
'    l_opt_out_url    v';
wwv_flow_imp.g_varchar2_table(398) := 'archar2(4000);'||wwv_flow.LF||
'    l_gen_date       varchar2(30);'||wwv_flow.LF||
'    l_summary        clob;'||wwv_flow.LF||
'    l_day            va';
wwv_flow_imp.g_varchar2_table(399) := 'rchar2(3) := to_char(sysdate,''DY'');'||wwv_flow.LF||
'    l_sysdate        date        := sysdate;'||wwv_flow.LF||
'    l_tsysdate     ';
wwv_flow_imp.g_varchar2_table(400) := '  date        := trunc(sysdate);'||wwv_flow.LF||
'    l_project_label  varchar2(255);'||wwv_flow.LF||
'    l_changes_yn     varchar2(1';
wwv_flow_imp.g_varchar2_table(401) := ');'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- need to fetch app_id because this is being run by a db job so has no knowledge of t';
wwv_flow_imp.g_varchar2_table(402) := 'he app'||wwv_flow.LF||
'    l_app_id := get_setting(p_static_id => ''APP_ID'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- the app_id is used to get the w';
wwv_flow_imp.g_varchar2_table(403) := 'orkspace, workspace must be set in order to use other apex apis (like apex_mail.send - without sgid,';
wwv_flow_imp.g_varchar2_table(404) := ' email template will not be found)'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select workspace_id'||wwv_flow.LF||
'         from apex_ap';
wwv_flow_imp.g_varchar2_table(405) := 'plications'||wwv_flow.LF||
'        where application_id = l_app_id '||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        apex_util.set_security_group_';
wwv_flow_imp.g_varchar2_table(406) := 'id(p_security_group_id => c1.workspace_id);'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- if build not not enabled, nothing ';
wwv_flow_imp.g_varchar2_table(407) := 'will be run (careful to not update the build option name in the UI without editing this)'||wwv_flow.LF||
'    if apex';
wwv_flow_imp.g_varchar2_table(408) := '_util.get_build_option_status('||wwv_flow.LF||
'           p_application_id    => l_app_id, '||wwv_flow.LF||
'           p_build_optio';
wwv_flow_imp.g_varchar2_table(409) := 'n_name => ''Subscriptions'') = ''INCLUDE'' and'||wwv_flow.LF||
'       apex_util.get_build_option_status ('||wwv_flow.LF||
'           p_a';
wwv_flow_imp.g_varchar2_table(410) := 'pplication_id    => l_app_id,'||wwv_flow.LF||
'           p_build_option_name => ''Email Configured'') = ''INCLUDE'''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(411) := 'then'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_app_url       := get_setting(p_static_id => ''APP_HOME_URL'');'||wwv_flow.LF||
'        l_project_label';
wwv_flow_imp.g_varchar2_table(412) := ' := get_nomenclature(''PROJECT'');'||wwv_flow.LF||
'        l_app_name      := get_nomenclature(''STRATEGIC_PLANNER'');'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(413) := '       l_gen_date      := to_char(l_sysdate,''DD-Mon-YYYY'');'||wwv_flow.LF||
'        l_opt_out_url   := get_setting(p';
wwv_flow_imp.g_varchar2_table(414) := '_static_id => ''APP_PREFIX_URL'')||'||wwv_flow.LF||
'                               apex_page.get_url('||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(415) := '                   p_application => l_app_id,'||wwv_flow.LF||
'                                   p_page        => 13';
wwv_flow_imp.g_varchar2_table(416) := '9,'||wwv_flow.LF||
'                                   p_session     => null,'||wwv_flow.LF||
'                                   p_pl';
wwv_flow_imp.g_varchar2_table(417) := 'ain_url   => TRUE );'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- WEEKLY_SUMMARY'||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            select tm.id team_me';
wwv_flow_imp.g_varchar2_table(418) := 'mber_id, '||wwv_flow.LF||
'                   tm.email, '||wwv_flow.LF||
'                   s.id subscription_id'||wwv_flow.LF||
'              from s';
wwv_flow_imp.g_varchar2_table(419) := 'p_team_members tm,'||wwv_flow.LF||
'                   sp_notification_subscriptions s,'||wwv_flow.LF||
'                   sp_notific';
wwv_flow_imp.g_varchar2_table(420) := 'ations n'||wwv_flow.LF||
'             where tm.id = s.team_member_id'||wwv_flow.LF||
'               and s.notification_id = n.id'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(421) := '            and n.static_id = ''WEEKLY_SUMMARY'''||wwv_flow.LF||
'               and n.is_active_yn = ''Y'''||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(422) := '  and s.opted_in_yn = ''Y'''||wwv_flow.LF||
'               and ( (s.frequency = ''WEEKDAYS'' and '||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(423) := 'l_day in (''MON'',''TUES'',''WED'',''THU'',''FRI'') and'||wwv_flow.LF||
'                      (s.last_sent < l_sysdate - 1/2 o';
wwv_flow_imp.g_varchar2_table(424) := 'r s.last_sent is null) )'||wwv_flow.LF||
'                     or'||wwv_flow.LF||
'                     (s.frequency = ''WEEKLY'' and '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(425) := '                     l_day = ''MON'' and'||wwv_flow.LF||
'                      (s.last_sent < l_sysdate - 6 or s.last_';
wwv_flow_imp.g_varchar2_table(426) := 'sent is null) ) )'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'            l_summary := sp_contributor_summary.generate ('||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(427) := '                      p_team_member_id  => c1.team_member_id,'||wwv_flow.LF||
'                             p_show_ac';
wwv_flow_imp.g_varchar2_table(428) := 'tivities => ''Y'','||wwv_flow.LF||
'                             p_show_projects   => ''Y'','||wwv_flow.LF||
'                            ';
wwv_flow_imp.g_varchar2_table(429) := ' p_links           => ''JOB'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'            apex_mail.send ( '||wwv_flow.LF||
'                p_to                 =';
wwv_flow_imp.g_varchar2_table(430) := '> c1.email,   '||wwv_flow.LF||
'                p_from               => c1.email,  '||wwv_flow.LF||
'                p_application_id ';
wwv_flow_imp.g_varchar2_table(431) := '    => l_app_id,  '||wwv_flow.LF||
'                p_template_static_id => ''NOTIF_SUBSCRIPTIONS_JOB'',  '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(432) := '    p_placeholders       => ''{'' || ''"APPLICATION_LINK": "'' || l_app_url ||''", ''|| '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(433) := '                              ''"OPT_OUT_URL": "''      || l_opt_out_url ||''", ''||'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(434) := '                            ''"APP_NAME": ''          || apex_json.stringify( l_app_name ) ||'', ''||'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(435) := '                                             ''"SUBJECT": ''           || apex_json.stringify( l_app_n';
wwv_flow_imp.g_varchar2_table(436) := 'ame||'' Weekly Summary - ''||to_char(l_sysdate,''Month DD, YYYY'' ) )||'', ''||'||wwv_flow.LF||
'                          ';
wwv_flow_imp.g_varchar2_table(437) := '                     ''"SUMMARY": ''           || apex_json.stringify( l_summary ) ||'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(438) := '                         ''}'' ); '||wwv_flow.LF||
''||wwv_flow.LF||
'            -- this allows job to be restarted without duplicate e';
wwv_flow_imp.g_varchar2_table(439) := 'mails going out'||wwv_flow.LF||
'            -- this marks that an email was queued to be sent, but the sending could';
wwv_flow_imp.g_varchar2_table(440) := ' ultimately fail'||wwv_flow.LF||
'            update sp_notification_subscriptions'||wwv_flow.LF||
'               set last_sent = sys';
wwv_flow_imp.g_varchar2_table(441) := 'date'||wwv_flow.LF||
'             where id = c1.subscription_id;'||wwv_flow.LF||
'        end loop; '||wwv_flow.LF||
''||wwv_flow.LF||
'        -- PROJECT_EXCEPTIONS'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(442) := '       for c1 in ('||wwv_flow.LF||
'            select tm.id team_member_id, '||wwv_flow.LF||
'                   tm.email, '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(443) := '          s.id subscription_id'||wwv_flow.LF||
'              from sp_team_members tm,'||wwv_flow.LF||
'                   sp_notifica';
wwv_flow_imp.g_varchar2_table(444) := 'tion_subscriptions s,'||wwv_flow.LF||
'                   sp_notifications n'||wwv_flow.LF||
'             where tm.id = s.team_member';
wwv_flow_imp.g_varchar2_table(445) := '_id'||wwv_flow.LF||
'               and s.notification_id = n.id'||wwv_flow.LF||
'               and n.static_id = ''PROJECT_EXCEPTIONS';
wwv_flow_imp.g_varchar2_table(446) := ''''||wwv_flow.LF||
'               and n.is_active_yn = ''Y'''||wwv_flow.LF||
'               and s.opted_in_yn = ''Y'''||wwv_flow.LF||
'               and ';
wwv_flow_imp.g_varchar2_table(447) := '( (s.frequency = ''WEEKDAYS'' and '||wwv_flow.LF||
'                      l_day in (''MON'',''TUES'',''WED'',''THU'',''FRI'') and';
wwv_flow_imp.g_varchar2_table(448) := ''||wwv_flow.LF||
'                      (s.last_sent < l_sysdate - 1/2 or s.last_sent is null) )'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(449) := ' or'||wwv_flow.LF||
'                     (s.frequency = ''WEEKLY'' and '||wwv_flow.LF||
'                      l_day = ''MON'' and'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(450) := '                (s.last_sent < l_sysdate - 6 or s.last_sent is null) ) )'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(451) := ' l_summary := sp_contributor_summary.project_exceptions ('||wwv_flow.LF||
'                             p_team_member';
wwv_flow_imp.g_varchar2_table(452) := '_id  => c1.team_member_id,'||wwv_flow.LF||
'                             p_links           => ''JOB'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'            a';
wwv_flow_imp.g_varchar2_table(453) := 'pex_mail.send ( '||wwv_flow.LF||
'                p_to                 => c1.email,   '||wwv_flow.LF||
'                p_from        ';
wwv_flow_imp.g_varchar2_table(454) := '       => c1.email,  '||wwv_flow.LF||
'                p_application_id     => l_app_id,  '||wwv_flow.LF||
'                p_template';
wwv_flow_imp.g_varchar2_table(455) := '_static_id => ''NOTIF_SUBSCRIPTIONS_JOB'',  '||wwv_flow.LF||
'                p_placeholders       => ''{'' || ''"APPLICAT';
wwv_flow_imp.g_varchar2_table(456) := 'ION_LINK": "'' || l_app_url ||''", ''|| '||wwv_flow.LF||
'                                               ''"OPT_OUT_URL":';
wwv_flow_imp.g_varchar2_table(457) := ' "''      || l_opt_out_url ||''", ''||'||wwv_flow.LF||
'                                               ''"APP_NAME": ''   ';
wwv_flow_imp.g_varchar2_table(458) := '       || apex_json.stringify( l_app_name ) ||'', ''||'||wwv_flow.LF||
'                                               ';
wwv_flow_imp.g_varchar2_table(459) := '''"SUBJECT": ''           || apex_json.stringify( l_app_name||'' ''||l_project_label||'' Exceptions - ''||';
wwv_flow_imp.g_varchar2_table(460) := 'to_char(l_sysdate,''Month DD, YYYY'' ) )||'', ''||'||wwv_flow.LF||
'                                               ''"SUMM';
wwv_flow_imp.g_varchar2_table(461) := 'ARY": ''           || apex_json.stringify( l_summary ) ||'||wwv_flow.LF||
'                                         ''}';
wwv_flow_imp.g_varchar2_table(462) := ''' ); '||wwv_flow.LF||
''||wwv_flow.LF||
'            -- this allows job to be restarted without duplicate emails going out'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(463) := ' -- this marks that an email was queued to be sent, but the sending could ultimately fail'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(464) := '  update sp_notification_subscriptions'||wwv_flow.LF||
'               set last_sent = sysdate'||wwv_flow.LF||
'             where id ';
wwv_flow_imp.g_varchar2_table(465) := '= c1.subscription_id;'||wwv_flow.LF||
'        end loop; '||wwv_flow.LF||
''||wwv_flow.LF||
'        -- RELEASE_EXCEPTIONS'||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(466) := '    select tm.id team_member_id, '||wwv_flow.LF||
'                   tm.email, '||wwv_flow.LF||
'                   s.id subscription';
wwv_flow_imp.g_varchar2_table(467) := '_id,'||wwv_flow.LF||
'                   r.release_train||'' ''||r.release release,'||wwv_flow.LF||
'                   r.id release_id'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(468) := '              from sp_team_members tm,'||wwv_flow.LF||
'                   sp_notification_subscriptions s,'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(469) := '          sp_notifications n,'||wwv_flow.LF||
'                   sp_release_trains r'||wwv_flow.LF||
'             where tm.id = s.te';
wwv_flow_imp.g_varchar2_table(470) := 'am_member_id'||wwv_flow.LF||
'               and s.notification_id = n.id'||wwv_flow.LF||
'               and n.static_id = ''RELEASE_E';
wwv_flow_imp.g_varchar2_table(471) := 'XCEPTIONS'''||wwv_flow.LF||
'               and n.is_active_yn = ''Y'''||wwv_flow.LF||
'               and s.release_id = r.id'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(472) := '     and nvl(r.release_completed,''N'') != ''Y'''||wwv_flow.LF||
'               and s.opted_in_yn = ''Y'''||wwv_flow.LF||
'               a';
wwv_flow_imp.g_varchar2_table(473) := 'nd ( (s.frequency = ''WEEKDAYS'' and '||wwv_flow.LF||
'                      l_day in (''MON'',''TUES'',''WED'',''THU'',''FRI'') ';
wwv_flow_imp.g_varchar2_table(474) := 'and'||wwv_flow.LF||
'                      (s.last_sent < l_sysdate - 1/2 or s.last_sent is null) )'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(475) := '    or'||wwv_flow.LF||
'                     (s.frequency = ''WEEKLY'' and '||wwv_flow.LF||
'                      l_day = ''MON'' and'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(476) := '                   (s.last_sent < l_sysdate - 6 or s.last_sent is null) ) )'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(477) := '    l_summary := sp_release_timeline.release_exceptions ('||wwv_flow.LF||
'                             p_release_id ';
wwv_flow_imp.g_varchar2_table(478) := '=> c1.release_id,'||wwv_flow.LF||
'                             p_links      => ''JOB'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'            apex_mail.send ';
wwv_flow_imp.g_varchar2_table(479) := '( '||wwv_flow.LF||
'                p_to                 => c1.email,   '||wwv_flow.LF||
'                p_from               => c1.e';
wwv_flow_imp.g_varchar2_table(480) := 'mail,  '||wwv_flow.LF||
'                p_application_id     => l_app_id,  '||wwv_flow.LF||
'                p_template_static_id => ';
wwv_flow_imp.g_varchar2_table(481) := '''NOTIF_SUBSCRIPTIONS_JOB'',  '||wwv_flow.LF||
'                p_placeholders       => ''{'' || ''"APPLICATION_LINK": "'' ';
wwv_flow_imp.g_varchar2_table(482) := '|| l_app_url ||''", ''|| '||wwv_flow.LF||
'                                               ''"OPT_OUT_URL": "''      || l_';
wwv_flow_imp.g_varchar2_table(483) := 'opt_out_url ||''", ''||'||wwv_flow.LF||
'                                               ''"APP_NAME": ''          || apex';
wwv_flow_imp.g_varchar2_table(484) := '_json.stringify( l_app_name ) ||'', ''||'||wwv_flow.LF||
'                                               ''"SUBJECT": '' ';
wwv_flow_imp.g_varchar2_table(485) := '          || apex_json.stringify( l_app_name||'' ''||c1.release||'' Release Exceptions - ''||to_char(l_s';
wwv_flow_imp.g_varchar2_table(486) := 'ysdate,''Month DD, YYYY'') )||'', ''||'||wwv_flow.LF||
'                                               ''"SUMMARY": ''     ';
wwv_flow_imp.g_varchar2_table(487) := '      || apex_json.stringify( l_summary ) ||'||wwv_flow.LF||
'                                         ''}'' ); '||wwv_flow.LF||
''||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(488) := '       -- this allows job to be restarted without duplicate emails going out'||wwv_flow.LF||
'            -- this mar';
wwv_flow_imp.g_varchar2_table(489) := 'ks that an email was queued to be sent, but the sending could ultimately fail'||wwv_flow.LF||
'            update sp_';
wwv_flow_imp.g_varchar2_table(490) := 'notification_subscriptions'||wwv_flow.LF||
'               set last_sent = sysdate'||wwv_flow.LF||
'             where id = c1.subscri';
wwv_flow_imp.g_varchar2_table(491) := 'ption_id;'||wwv_flow.LF||
'        end loop; '||wwv_flow.LF||
''||wwv_flow.LF||
'        -- PROJECT_CHANGES'||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            select tm.i';
wwv_flow_imp.g_varchar2_table(492) := 'd team_member_id, '||wwv_flow.LF||
'                   tm.email, '||wwv_flow.LF||
'                   s.id subscription_id,'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(493) := '         s.frequency'||wwv_flow.LF||
'              from sp_team_members tm,'||wwv_flow.LF||
'                   sp_notification_subsc';
wwv_flow_imp.g_varchar2_table(494) := 'riptions s,'||wwv_flow.LF||
'                   sp_notifications n'||wwv_flow.LF||
'             where tm.id = s.team_member_id'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(495) := '         and s.notification_id = n.id'||wwv_flow.LF||
'               and n.static_id = ''PROJECT_CHANGES'''||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(496) := '    and n.is_active_yn = ''Y'''||wwv_flow.LF||
'               and s.opted_in_yn = ''Y'''||wwv_flow.LF||
'               and ( (s.frequenc';
wwv_flow_imp.g_varchar2_table(497) := 'y = ''WEEKDAYS'' and '||wwv_flow.LF||
'                      l_day in (''MON'',''TUES'',''WED'',''THU'',''FRI'') and'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(498) := '          (s.last_sent < l_sysdate - 1/2 or s.last_sent is null) )'||wwv_flow.LF||
'                     or'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(499) := '            (s.frequency = ''WEEKLY'' and '||wwv_flow.LF||
'                      l_day = ''MON'' and'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(500) := '   (s.last_sent < l_sysdate - 6 or s.last_sent is null) ) )'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'            sp_contribut';
wwv_flow_imp.g_varchar2_table(501) := 'or_summary.project_changes ('||wwv_flow.LF||
'                p_team_member_id => c1.team_member_id,'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(502) := 'p_frequency      => c1.frequency,'||wwv_flow.LF||
'                p_links          => ''JOB'','||wwv_flow.LF||
'                p_chang';
wwv_flow_imp.g_varchar2_table(503) := 'es_yn     => l_changes_yn,'||wwv_flow.LF||
'                p_change_summary => l_summary );'||wwv_flow.LF||
''||wwv_flow.LF||
'            if l_change';
wwv_flow_imp.g_varchar2_table(504) := 's_yn = ''Y'' then'||wwv_flow.LF||
''||wwv_flow.LF||
'                apex_mail.send ( '||wwv_flow.LF||
'                    p_to                 => c1.em';
wwv_flow_imp.g_varchar2_table(505) := 'ail,   '||wwv_flow.LF||
'                    p_from               => c1.email,  '||wwv_flow.LF||
'                    p_application_id';
wwv_flow_imp.g_varchar2_table(506) := '     => l_app_id,  '||wwv_flow.LF||
'                    p_template_static_id => ''NOTIF_SUBSCRIPTIONS_JOB'',  '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(507) := '             p_placeholders       => ''{'' || ''"APPLICATION_LINK": "'' || l_app_url ||''", ''|| '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(508) := '                                           ''"OPT_OUT_URL": "''      || l_opt_out_url ||''", ''||'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(509) := '                                             ''"APP_NAME": ''          || apex_json.stringify( l_app_n';
wwv_flow_imp.g_varchar2_table(510) := 'ame ) ||'', ''||'||wwv_flow.LF||
'                                                   ''"SUBJECT": ''           || apex_js';
wwv_flow_imp.g_varchar2_table(511) := 'on.stringify( l_app_name||'' ''||l_project_label||'' Changes - ''||to_char(l_sysdate,''Month DD, YYYY'' ) ';
wwv_flow_imp.g_varchar2_table(512) := ')||'', ''||'||wwv_flow.LF||
'                                                   ''"SUMMARY": ''           || apex_json.st';
wwv_flow_imp.g_varchar2_table(513) := 'ringify( l_summary ) ||'||wwv_flow.LF||
'                                             ''}'' ); '||wwv_flow.LF||
''||wwv_flow.LF||
'                -- thi';
wwv_flow_imp.g_varchar2_table(514) := 's allows job to be restarted without duplicate emails going out'||wwv_flow.LF||
'                -- this marks that a';
wwv_flow_imp.g_varchar2_table(515) := 'n email was queued to be sent, but the sending could ultimately fail'||wwv_flow.LF||
'                update sp_notif';
wwv_flow_imp.g_varchar2_table(516) := 'ication_subscriptions'||wwv_flow.LF||
'                   set last_sent = sysdate'||wwv_flow.LF||
'                 where id = c1.subs';
wwv_flow_imp.g_varchar2_table(517) := 'cription_id;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end loop; '||wwv_flow.LF||
''||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'end send_notif_subscriptions;'||wwv_flow.LF||
''||wwv_flow.LF||
'pro';
wwv_flow_imp.g_varchar2_table(518) := 'cedure assignment_notification ('||wwv_flow.LF||
'    p_team_member_id     in  number,'||wwv_flow.LF||
'    p_app_name           in  v';
wwv_flow_imp.g_varchar2_table(519) := 'archar2,'||wwv_flow.LF||
'    p_app_id             in  number,'||wwv_flow.LF||
'    p_project_id         in  number  default null,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(520) := ' p_task_id            in  number  default null,'||wwv_flow.LF||
'    p_link               in  varchar2,'||wwv_flow.LF||
'    p_view_wh';
wwv_flow_imp.g_varchar2_table(521) := 'at          in  varchar2,'||wwv_flow.LF||
'    p_title              in  varchar2,'||wwv_flow.LF||
'    p_email_contents     in  varcha';
wwv_flow_imp.g_varchar2_table(522) := 'r2,'||wwv_flow.LF||
'    p_notification_type  in  varchar2 )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- only send if person is also a user (proj';
wwv_flow_imp.g_varchar2_table(523) := 'ect owners may not be users)'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select email, '||wwv_flow.LF||
'               nvl(notification_';
wwv_flow_imp.g_varchar2_table(524) := 'pref,''APP:EMAIL'') notification_pref'||wwv_flow.LF||
'          from sp_team_members t'||wwv_flow.LF||
'         where id = p_team_memb';
wwv_flow_imp.g_varchar2_table(525) := 'er_id'||wwv_flow.LF||
'           and exists (select 1'||wwv_flow.LF||
'                         from APEX_APPL_ACL_USERS'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(526) := '            where application_id = p_app_id'||wwv_flow.LF||
'                          and user_name_lc = t.email)'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(527) := '  ) loop'||wwv_flow.LF||
'        insert into sp_team_member_notifications'||wwv_flow.LF||
'            (team_member_id, project_id, t';
wwv_flow_imp.g_varchar2_table(528) := 'ask_id, title, email_contents, notification_pref, notification_type)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (p_t';
wwv_flow_imp.g_varchar2_table(529) := 'eam_member_id, p_project_id, p_task_id, p_title, p_email_contents, c1.notification_pref, p_notificat';
wwv_flow_imp.g_varchar2_table(530) := 'ion_type);'||wwv_flow.LF||
''||wwv_flow.LF||
'        if instr('':''||c1.notification_pref||'':'','':EMAIL:'') > 0 and'||wwv_flow.LF||
'           apex_util.';
wwv_flow_imp.g_varchar2_table(531) := 'get_build_option_status ('||wwv_flow.LF||
'               p_application_id    => p_app_id,'||wwv_flow.LF||
'               p_build_opt';
wwv_flow_imp.g_varchar2_table(532) := 'ion_name => ''Email Configured'') = ''INCLUDE'''||wwv_flow.LF||
'        then'||wwv_flow.LF||
'            apex_mail.send ( '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(533) := '   p_to                 => c1.email,   '||wwv_flow.LF||
'                p_from               => c1.email,  '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(534) := '        p_application_id     => p_app_id,  '||wwv_flow.LF||
'                p_template_static_id => ''PROJECT_RELATED';
wwv_flow_imp.g_varchar2_table(535) := ''',  '||wwv_flow.LF||
'                p_placeholders       => ''{'' || ''"VIEW_LINK": "'' || p_link ||''", ''|| '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(536) := '                                     ''"APP_NAME": ''   || apex_json.stringify( p_app_name ) ||'', ''||'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(537) := '                                               ''"SUBJECT": ''    || apex_json.stringify( p_title ) ||';
wwv_flow_imp.g_varchar2_table(538) := ''', ''||'||wwv_flow.LF||
'                                               ''"VIEW_WHAT": ''  || apex_json.stringify( p_vie';
wwv_flow_imp.g_varchar2_table(539) := 'w_what ) ||'', ''||'||wwv_flow.LF||
'                                               ''"SUMMARY": ''    || apex_json.strin';
wwv_flow_imp.g_varchar2_table(540) := 'gify( p_email_contents ) ||'||wwv_flow.LF||
'                                         ''}'' ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end';
wwv_flow_imp.g_varchar2_table(541) := ' loop;'||wwv_flow.LF||
'end assignment_notification;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure comment_notification ('||wwv_flow.LF||
'    p_team_member_id     in  ';
wwv_flow_imp.g_varchar2_table(542) := 'number,'||wwv_flow.LF||
'    p_app_name           in  varchar2,'||wwv_flow.LF||
'    p_app_id             in  number,'||wwv_flow.LF||
'    p_project_id';
wwv_flow_imp.g_varchar2_table(543) := '         in  number  default null,'||wwv_flow.LF||
'    p_task_id            in  number  default null,'||wwv_flow.LF||
'    p_link    ';
wwv_flow_imp.g_varchar2_table(544) := '           in  varchar2,'||wwv_flow.LF||
'    p_view_what          in  varchar2,'||wwv_flow.LF||
'    p_title              in  varchar';
wwv_flow_imp.g_varchar2_table(545) := '2,'||wwv_flow.LF||
'    p_email_contents     in  varchar2,'||wwv_flow.LF||
'    p_notification_type  in  varchar2 default ''COMMENT'' )'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(546) := 'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- only send if person is also a user (project owners may not be users)'||wwv_flow.LF||
'    for c1 in (';
wwv_flow_imp.g_varchar2_table(547) := ''||wwv_flow.LF||
'        select email, '||wwv_flow.LF||
'               nvl(comment_notif_pref,''APP:EMAIL'') comment_pref'||wwv_flow.LF||
'          fr';
wwv_flow_imp.g_varchar2_table(548) := 'om sp_team_members t'||wwv_flow.LF||
'         where id = p_team_member_id'||wwv_flow.LF||
'           and (instr('':''||nvl(comment_not';
wwv_flow_imp.g_varchar2_table(549) := 'if_pref,''APP:EMAIL'')||'':'','':APP:'') > 0 or'||wwv_flow.LF||
'                instr('':''||nvl(comment_notif_pref,''APP:EMA';
wwv_flow_imp.g_varchar2_table(550) := 'IL'')||'':'','':EMAIL:'') > 0)'||wwv_flow.LF||
'           and exists (select 1'||wwv_flow.LF||
'                         from APEX_APPL_AC';
wwv_flow_imp.g_varchar2_table(551) := 'L_USERS'||wwv_flow.LF||
'                        where application_id = p_app_id'||wwv_flow.LF||
'                          and user_n';
wwv_flow_imp.g_varchar2_table(552) := 'ame_lc = t.email)'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        insert into sp_team_member_notifications'||wwv_flow.LF||
'            (team_memb';
wwv_flow_imp.g_varchar2_table(553) := 'er_id, project_id, title, email_contents, notification_pref, notification_type)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(554) := '       (p_team_member_id, p_project_id, p_title, substr(p_email_contents,1,4000), c1.comment_pref, p';
wwv_flow_imp.g_varchar2_table(555) := '_notification_type);'||wwv_flow.LF||
''||wwv_flow.LF||
'        if instr('':''||c1.comment_pref||'':'','':EMAIL:'') > 0 and'||wwv_flow.LF||
'           apex_';
wwv_flow_imp.g_varchar2_table(556) := 'util.get_build_option_status ('||wwv_flow.LF||
'               p_application_id    => p_app_id,'||wwv_flow.LF||
'               p_buil';
wwv_flow_imp.g_varchar2_table(557) := 'd_option_name => ''Email Configured'') = ''INCLUDE'''||wwv_flow.LF||
'        then'||wwv_flow.LF||
'            apex_mail.send ( '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(558) := '        p_to                 => c1.email,   '||wwv_flow.LF||
'                p_from               => c1.email,  '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(559) := '             p_application_id     => p_app_id,  '||wwv_flow.LF||
'                p_template_static_id => ''PROJECT_RE';
wwv_flow_imp.g_varchar2_table(560) := 'LATED'',  '||wwv_flow.LF||
'                p_placeholders       => ''{'' || ''"VIEW_LINK": "'' || p_link ||''", ''|| '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(561) := '                                          ''"APP_NAME": ''   || apex_json.stringify( p_app_name ) ||'',';
wwv_flow_imp.g_varchar2_table(562) := ' ''||'||wwv_flow.LF||
'                                               ''"SUBJECT": ''    || apex_json.stringify( p_title';
wwv_flow_imp.g_varchar2_table(563) := ' ) ||'', ''||'||wwv_flow.LF||
'                                               ''"VIEW_WHAT": ''  || apex_json.stringify( ';
wwv_flow_imp.g_varchar2_table(564) := 'p_view_what ) ||'', ''||'||wwv_flow.LF||
'                                               ''"SUMMARY": ''    || apex_json.';
wwv_flow_imp.g_varchar2_table(565) := 'stringify( p_email_contents ) ||'||wwv_flow.LF||
'                                         ''}'' ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(566) := '  end loop;'||wwv_flow.LF||
'end comment_notification;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- used by SP_CONTRIBUTOR_SUMMARY, SP_RELEASE_TIMELINE and w';
wwv_flow_imp.g_varchar2_table(567) := 'ith app'||wwv_flow.LF||
'function exceptions_for_project ('||wwv_flow.LF||
'    p_project_id      in  number,'||wwv_flow.LF||
'    p_one_project_yn  in';
wwv_flow_imp.g_varchar2_table(568) := '  varchar2 default ''N'','||wwv_flow.LF||
'    p_team_member_id  in  number   default null,'||wwv_flow.LF||
'    p_link_type       in  v';
wwv_flow_imp.g_varchar2_table(569) := 'archar2,'||wwv_flow.LF||
'    p_app_prefix_url  in  varchar2,'||wwv_flow.LF||
'    p_app_id          in  number,'||wwv_flow.LF||
'    p_apex_session   ';
wwv_flow_imp.g_varchar2_table(570) := ' in  number   default null,'||wwv_flow.LF||
'    p_reviews_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_approvals_yn    in';
wwv_flow_imp.g_varchar2_table(571) := '  varchar2 default ''N'' )'||wwv_flow.LF||
'    return clob'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_proj_yn              varchar2(1) := ''N'';'||wwv_flow.LF||
'    l_exc';
wwv_flow_imp.g_varchar2_table(572) := 'eptions_yn        varchar2(1) := ''N'';'||wwv_flow.LF||
'    l_sysdate              date := trunc(sysdate);'||wwv_flow.LF||
'    l_date_';
wwv_flow_imp.g_varchar2_table(573) := 'fm              varchar2(255) := ''FMDay DD-MON'';'||wwv_flow.LF||
'    l_project              varchar2(4000);'||wwv_flow.LF||
'    l_ro';
wwv_flow_imp.g_varchar2_table(574) := 'le                 varchar2(4000);'||wwv_flow.LF||
'    l_url                  varchar2(4000);'||wwv_flow.LF||
'    l_activity        ';
wwv_flow_imp.g_varchar2_table(575) := '     varchar2(4000);'||wwv_flow.LF||
'    x                      clob := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select p';
wwv_flow_imp.g_varchar2_table(576) := '.id,'||wwv_flow.LF||
'               p.friendly_identifier,'||wwv_flow.LF||
'               p.project,'||wwv_flow.LF||
'               p.owner_id,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(577) := '           p.requires_reviews_yn,'||wwv_flow.LF||
'               p.pct_complete,'||wwv_flow.LF||
'               '' - ''|| to_char(p.pc';
wwv_flow_imp.g_varchar2_table(578) := 't_complete) ||''% ''|| p.project_size ||'' P''||to_char(r.priority) quick_summary,'||wwv_flow.LF||
'               case w';
wwv_flow_imp.g_varchar2_table(579) := 'hen p.owner_id is not null then '' - ''||(select first_name ||'' ''||last_name from sp_team_members wher';
wwv_flow_imp.g_varchar2_table(580) := 'e id = p.owner_id) end owner,'||wwv_flow.LF||
'               case when p.pct_complete >= s.min_pc_for_status and'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(581) := '                      p.pct_complete != 100 and '||wwv_flow.LF||
'                         p.status_id is null'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(582) := '              then ''Y'''||wwv_flow.LF||
'                    end status_not_set'||wwv_flow.LF||
'          from sp_projects p,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(583) := '       sp_initiatives i,'||wwv_flow.LF||
'               sp_project_priorities r,'||wwv_flow.LF||
'               sp_project_scales s'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(584) := '         where p.id = p_project_id'||wwv_flow.LF||
'           and p.initiative_id = i.id'||wwv_flow.LF||
'           and p.priority_i';
wwv_flow_imp.g_varchar2_table(585) := 'd = r.id'||wwv_flow.LF||
'           and i.status_scale = s.scale_letter'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_proj_yn := ''N'';'||wwv_flow.LF||
''||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(586) := '   -- if for just one project, no need to include the project header'||wwv_flow.LF||
'        if p_one_project_yn = ''';
wwv_flow_imp.g_varchar2_table(587) := 'N'' then'||wwv_flow.LF||
'            l_project := ''<strong>''||apex_escape.html(c1.project)||''</strong>'';'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(588) := '-- broken out to avoid bulk bind error'||wwv_flow.LF||
'            if c1.owner_id = p_team_member_id then l_role := ';
wwv_flow_imp.g_varchar2_table(589) := ''' (Owner)'';'||wwv_flow.LF||
'            else select '' (''||listagg(rt.resource_type, '', '') within group (order by rt.';
wwv_flow_imp.g_varchar2_table(590) := 'resource_type) ||'')'''||wwv_flow.LF||
'                   into l_role'||wwv_flow.LF||
'                   from sp_project_contributors ';
wwv_flow_imp.g_varchar2_table(591) := 'c,'||wwv_flow.LF||
'                        sp_resource_types rt'||wwv_flow.LF||
'                  where c.project_id = c1.id'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(592) := '             and c.team_member_id = p_team_member_id'||wwv_flow.LF||
'                    and c.responsibility_id = r';
wwv_flow_imp.g_varchar2_table(593) := 't.id;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'            if p_link_type = ''APP'' then'||wwv_flow.LF||
'               l_url := apex_util';
wwv_flow_imp.g_varchar2_table(594) := '.prepare_url(''f?p=''||p_app_id||'':3:''||p_apex_session||''::NO:3:FI:''||apex_escape.html(c1.friendly_ide';
wwv_flow_imp.g_varchar2_table(595) := 'ntifier));'||wwv_flow.LF||
'               l_project := ''<a href="''||l_url||''">''||l_project||''</a>'' || apex_escape.ht';
wwv_flow_imp.g_varchar2_table(596) := 'ml(l_role) || apex_escape.html(c1.owner) || apex_escape.html(c1.quick_summary);'||wwv_flow.LF||
'            elsif p_';
wwv_flow_imp.g_varchar2_table(597) := 'link_type in (''EMAIL'',''JOB'') then'||wwv_flow.LF||
'               l_url := apex_page.get_url('||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(598) := '     p_application => p_app_id,'||wwv_flow.LF||
'                            p_page        => 3,'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(599) := '        p_session     => null,'||wwv_flow.LF||
'                            p_items       => ''FI'','||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(600) := '          p_values      => c1.friendly_identifier,'||wwv_flow.LF||
'                            p_plain_url   => TRUE';
wwv_flow_imp.g_varchar2_table(601) := ' );'||wwv_flow.LF||
'               if p_link_type = ''EMAIL'' then'||wwv_flow.LF||
'                  l_url := p_app_prefix_url || l_ur';
wwv_flow_imp.g_varchar2_table(602) := 'l; '||wwv_flow.LF||
'               end if;'||wwv_flow.LF||
'               l_project := ''<a href="''||l_url||''">''||l_project||''</a>'' |';
wwv_flow_imp.g_varchar2_table(603) := '| apex_escape.html(l_role) || apex_escape.html(c1.owner) || apex_escape.html(c1.quick_summary);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(604) := '        else'||wwv_flow.LF||
'               l_project := l_project || apex_escape.html(l_role) || apex_escape.html(c';
wwv_flow_imp.g_varchar2_table(605) := '1.owner) || apex_escape.html(c1.quick_summary);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- NO P';
wwv_flow_imp.g_varchar2_table(606) := 'ROJECT OWNER'||wwv_flow.LF||
'        if c1.owner_id is null then'||wwv_flow.LF||
'            l_exceptions_yn := ''Y'';'||wwv_flow.LF||
'            x :';
wwv_flow_imp.g_varchar2_table(607) := '= x||l_project||chr(10)||''<ul>'';'||wwv_flow.LF||
'            l_proj_yn := ''Y'';'||wwv_flow.LF||
'            x := x||''<li>No Owner</li';
wwv_flow_imp.g_varchar2_table(608) := '>''||chr(10);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- STATUS NOT SET'||wwv_flow.LF||
'        if c1.status_not_set = ''Y'' then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(609) := '        if l_proj_yn = ''N'' then'||wwv_flow.LF||
'               x := x||l_project||chr(10)||''<ul>'';'||wwv_flow.LF||
'               l_';
wwv_flow_imp.g_varchar2_table(610) := 'proj_yn := ''Y'';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            l_exceptions_yn := ''Y'';'||wwv_flow.LF||
'            x := x||''<li>Sta';
wwv_flow_imp.g_varchar2_table(611) := 'tus not set</li>''||chr(10);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- NO PROJECT REVIEWERS'||wwv_flow.LF||
'        if c1.requires_';
wwv_flow_imp.g_varchar2_table(612) := 'reviews_yn = ''Y'' and'||wwv_flow.LF||
'           c1.pct_complete >= 50 and'||wwv_flow.LF||
'           p_reviews_yn = ''Y'' then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(613) := '     for c2 in ('||wwv_flow.LF||
'                select count(*) cnt'||wwv_flow.LF||
'                  from sp_tasks t,'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(614) := '           sp_task_types tt'||wwv_flow.LF||
'                 where t.project_id = c1.id'||wwv_flow.LF||
'                   and nvl(t';
wwv_flow_imp.g_varchar2_table(615) := '.task_sub_type_id,t.task_type_id) = tt.id'||wwv_flow.LF||
'                   and tt.static_id like ''REVIEW%'''||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(616) := '            and t.owner_id is not null'||wwv_flow.LF||
'            ) loop'||wwv_flow.LF||
'                if c2.cnt = 0 then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(617) := '             if l_proj_yn = ''N'' then'||wwv_flow.LF||
'                        x := x||l_project||chr(10)||''<ul>'';'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(618) := '                     l_proj_yn := ''Y'';'||wwv_flow.LF||
'                    end if;'||wwv_flow.LF||
'                    l_exceptions_';
wwv_flow_imp.g_varchar2_table(619) := 'yn := ''Y'';'||wwv_flow.LF||
'                    x := x||''<li>No Reviewers</li>''||chr(10);'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(620) := '         end loop;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- OVERDUE PROJECT MILESTONES'||wwv_flow.LF||
'        for c2 in ('||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(621) := '      select (select first_name||'' ''||last_name from sp_team_members tm where tm.id = t.owner_id) ow';
wwv_flow_imp.g_varchar2_table(622) := 'ner,'||wwv_flow.LF||
'                   tt.task_type type,'||wwv_flow.LF||
'                   s.status,'||wwv_flow.LF||
'                   trunc(t.t';
wwv_flow_imp.g_varchar2_table(623) := 'arget_complete) target_complete'||wwv_flow.LF||
'              from sp_tasks t,'||wwv_flow.LF||
'                   sp_task_types tt,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(624) := '                   sp_task_statuses s'||wwv_flow.LF||
'             where t.project_id = c1.id'||wwv_flow.LF||
'               and nvl';
wwv_flow_imp.g_varchar2_table(625) := '(t.task_sub_type_id,t.task_type_id) = tt.id'||wwv_flow.LF||
'               and tt.static_id like ''MILESTONE%'''||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(626) := '         and t.status_id = s.id'||wwv_flow.LF||
'               and s.indicates_complete_yn = ''N'''||wwv_flow.LF||
'               and ';
wwv_flow_imp.g_varchar2_table(627) := 'trunc(t.target_complete) < l_sysdate'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'             if l_proj_yn = ''N'' then'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(628) := '      x := x||l_project||chr(10)||''<ul>'';'||wwv_flow.LF||
'                 l_proj_yn := ''Y'';'||wwv_flow.LF||
'             end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(629) := '           l_exceptions_yn := ''Y'';'||wwv_flow.LF||
'             x := x||''<li>''|| apex_escape.html(c2.type)||'' assign';
wwv_flow_imp.g_varchar2_table(630) := 'ed to ''||apex_escape.html(c2.owner) ||'' was due ''|| to_char(c2.target_complete,l_date_fm)||''  (''||ap';
wwv_flow_imp.g_varchar2_table(631) := 'ex_escape.html(c2.status)||'')</li>''||chr(10);'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- OVERDUE REVIEWS'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(632) := 'if c1.requires_reviews_yn = ''Y'' and'||wwv_flow.LF||
'           p_reviews_yn = ''Y'' then'||wwv_flow.LF||
'            for c2 in ('||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(633) := '           select (select first_name||'' ''||last_name from sp_team_members tm where tm.id = t.owner_i';
wwv_flow_imp.g_varchar2_table(634) := 'd) reviewer,'||wwv_flow.LF||
'                       tt.task_type type,'||wwv_flow.LF||
'                       s.status,'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(635) := '           trunc(t.target_complete) review_date'||wwv_flow.LF||
'                  from sp_tasks t,'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(636) := '      sp_task_types tt,'||wwv_flow.LF||
'                       sp_task_statuses s'||wwv_flow.LF||
'                 where t.project_i';
wwv_flow_imp.g_varchar2_table(637) := 'd = c1.id'||wwv_flow.LF||
'                   and nvl(t.task_sub_type_id,t.task_type_id) = tt.id'||wwv_flow.LF||
'                   a';
wwv_flow_imp.g_varchar2_table(638) := 'nd tt.static_id like ''REVIEW%'''||wwv_flow.LF||
'                   and t.status_id = s.id'||wwv_flow.LF||
'                   and s.in';
wwv_flow_imp.g_varchar2_table(639) := 'dicates_complete_yn = ''N'''||wwv_flow.LF||
'                   and trunc(t.target_complete) < l_sysdate'||wwv_flow.LF||
'            ) ';
wwv_flow_imp.g_varchar2_table(640) := 'loop'||wwv_flow.LF||
'                if l_proj_yn = ''N'' then'||wwv_flow.LF||
'                    x := x||l_project||chr(10)||''<ul>'';';
wwv_flow_imp.g_varchar2_table(641) := ''||wwv_flow.LF||
'                    l_proj_yn := ''Y'';'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'                l_exceptions_yn := ''Y';
wwv_flow_imp.g_varchar2_table(642) := ''';'||wwv_flow.LF||
'                x := x||''<li>''||apex_escape.html(c2.type)||'' by ''||apex_escape.html(c2.reviewer)|';
wwv_flow_imp.g_varchar2_table(643) := '|'' was targeted for ''||to_char(c2.review_date,l_date_fm)||''  (''||apex_escape.html(c2.status)||'')</li';
wwv_flow_imp.g_varchar2_table(644) := '>''||chr(10);'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- REVIEWS WITHOUT DATES'||wwv_flow.LF||
'            for c2 in ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(645) := '             select (select first_name||'' ''||last_name from sp_team_members tm where tm.id = t.owner';
wwv_flow_imp.g_varchar2_table(646) := '_id) reviewer,'||wwv_flow.LF||
'                       tt.task_type type,'||wwv_flow.LF||
'                       s.status'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(647) := '       from sp_tasks t,'||wwv_flow.LF||
'                       sp_task_types tt,'||wwv_flow.LF||
'                       sp_task_stat';
wwv_flow_imp.g_varchar2_table(648) := 'uses s'||wwv_flow.LF||
'                 where t.project_id = c1.id'||wwv_flow.LF||
'                   and nvl(t.task_sub_type_id,t.t';
wwv_flow_imp.g_varchar2_table(649) := 'ask_type_id) = tt.id'||wwv_flow.LF||
'                   and tt.static_id like ''REVIEW%'''||wwv_flow.LF||
'                   and t.sta';
wwv_flow_imp.g_varchar2_table(650) := 'tus_id = s.id'||wwv_flow.LF||
'                   and s.indicates_complete_yn = ''N'''||wwv_flow.LF||
'                   and t.target_c';
wwv_flow_imp.g_varchar2_table(651) := 'omplete is null'||wwv_flow.LF||
'            ) loop'||wwv_flow.LF||
'                if l_proj_yn = ''N'' then'||wwv_flow.LF||
'                    x := ';
wwv_flow_imp.g_varchar2_table(652) := 'x||l_project||chr(10)||''<ul>'';'||wwv_flow.LF||
'                    l_proj_yn := ''Y'';'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(653) := '         l_exceptions_yn := ''Y'';'||wwv_flow.LF||
'                x := x||''<li>''||apex_escape.html(c2.type)||'' by ''||';
wwv_flow_imp.g_varchar2_table(654) := 'apex_escape.html(c2.reviewer)||'' has no target date (''||apex_escape.html(c2.status)||'')</li>''||chr(1';
wwv_flow_imp.g_varchar2_table(655) := '0);'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- PENDING APPROVALS'||wwv_flow.LF||
'        if p_approvals_yn = ';
wwv_flow_imp.g_varchar2_table(656) := '''Y'' then'||wwv_flow.LF||
'            for c2 in ('||wwv_flow.LF||
'                select (select first_name||'' ''||last_name from sp_t';
wwv_flow_imp.g_varchar2_table(657) := 'eam_members tm where tm.id = a.submitted_by_team_member_id) owner,'||wwv_flow.LF||
'                       t.approval';
wwv_flow_imp.g_varchar2_table(658) := '_type ||'' Review'' type,'||wwv_flow.LF||
'                       case when a.status = ''PENDING'''||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(659) := '      then ''Pending Review'''||wwv_flow.LF||
'                            when a.status = ''CLARIFICATION-REQUESTED'''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(660) := '                          then ''Clarification Requested'''||wwv_flow.LF||
'                            end status,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(661) := '                    trunc(a.updated) target_complete'||wwv_flow.LF||
'                  from sp_project_approvals a,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(662) := '                       sp_approval_types t'||wwv_flow.LF||
'                 where a.project_id = c1.id'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(663) := '      and a.approval_type_id = t.id'||wwv_flow.LF||
'                   and a.status in (''PENDING'',''CLARIFICATION-REQ';
wwv_flow_imp.g_varchar2_table(664) := 'UESTED'')'||wwv_flow.LF||
'            ) loop'||wwv_flow.LF||
'                 if l_proj_yn = ''N'' then'||wwv_flow.LF||
'                     x := x||l_';
wwv_flow_imp.g_varchar2_table(665) := 'project||chr(10)||''<ul>'';'||wwv_flow.LF||
'                     l_proj_yn := ''Y'';'||wwv_flow.LF||
'                 end if;'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(666) := '       l_exceptions_yn := ''Y'';'||wwv_flow.LF||
'                 x := x||''<li>''|| apex_escape.html(c2.type)||'' submit';
wwv_flow_imp.g_varchar2_table(667) := 'ted by ''||apex_escape.html(c2.owner) ||'' is currently ''||apex_escape.html(c2.status)||''</li>''||chr(1';
wwv_flow_imp.g_varchar2_table(668) := '0);'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        if l_proj_yn = ''Y'' then'||wwv_flow.LF||
'            x := x||''</ul';
wwv_flow_imp.g_varchar2_table(669) := '>'';'||wwv_flow.LF||
'        end if;    '||wwv_flow.LF||
'  '||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return x;'||wwv_flow.LF||
''||wwv_flow.LF||
'end exceptions_for_project;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function repl';
wwv_flow_imp.g_varchar2_table(670) := 'ace_nomenclature ('||wwv_flow.LF||
'    p_contents  in  varchar2'||wwv_flow.LF||
') return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_new_contents  varchar2(40';
wwv_flow_imp.g_varchar2_table(671) := '00);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_new_contents := p_contents;'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select static_id, custom_value';
wwv_flow_imp.g_varchar2_table(672) := ''||wwv_flow.LF||
'          from sp_app_nomenclature'||wwv_flow.LF||
'         order by static_id desc'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        l_new_conten';
wwv_flow_imp.g_varchar2_table(673) := 'ts := replace(l_new_contents,''&NOMENCLATURE_''||c1.static_id||''.'',c1.custom_value);'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(674) := '  for c1 in ('||wwv_flow.LF||
'        select static_id, custom_value'||wwv_flow.LF||
'          from sp_app_nomenclature'||wwv_flow.LF||
'         ord';
wwv_flow_imp.g_varchar2_table(675) := 'er by static_id desc'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        l_new_contents := replace(l_new_contents,''NOMENCLATURE_''||c1';
wwv_flow_imp.g_varchar2_table(676) := '.static_id,c1.custom_value);'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_new_contents;'||wwv_flow.LF||
''||wwv_flow.LF||
'end replace_nomenclature;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(677) := 'end sp_util;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(151732928632544295777)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_util body'
,p_sequence=>760
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
