prompt --application/deployment/install/install_create_sp_areas_trigger
begin
--   Manifest
--     INSTALL: INSTALL-create sp_areas trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_areas_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_areas'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(2) := 'declare'||wwv_flow.LF||
'    l_tags varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysda';
wwv_flow_imp.g_varchar2_table(3) := 'te;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(4) := '  :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),us';
wwv_flow_imp.g_varchar2_table(5) := 'er);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.hidden_by_default_yn is null then'||wwv_flow.LF||
'      :new.hidden_by_default';
wwv_flow_imp.g_varchar2_table(6) := '_yn := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- adjust tag data'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.tags is not null then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(7) := '   l_tags := trim(upper(:new.tags));'||wwv_flow.LF||
'        -- remove multiple spaces'||wwv_flow.LF||
'        if instr(l_tags,''  '')';
wwv_flow_imp.g_varchar2_table(8) := ' > 0 then'||wwv_flow.LF||
'            for j in 1..10 loop '||wwv_flow.LF||
'                l_tags := replace(l_tags,''  '','' ''); '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(9) := '            if instr(l_tags,''  '') = 0 then'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(10) := '    end loop; '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        for i in 1..length(l_tags) loop'||wwv_flow.LF||
'            if i > 2 and subs';
wwv_flow_imp.g_varchar2_table(11) := 'tr(l_tags,i,1) = '' '' and substr(l_tags,i-1,1) != '','' then'||wwv_flow.LF||
'               l_tags := substr(l_tags,1,i';
wwv_flow_imp.g_varchar2_table(12) := '-1)||''-''||substr(l_tags,i+1);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        :new.tags := l_tags;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(13) := 'end if;'||wwv_flow.LF||
'end sp_areas_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(42307995341673022746)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'create sp_areas trigger'
,p_sequence=>380
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
