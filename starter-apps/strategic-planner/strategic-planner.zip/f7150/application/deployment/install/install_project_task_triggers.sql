prompt --application/deployment/install/install_project_task_triggers
begin
--   Manifest
--     INSTALL: INSTALL-Project Task triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_task_types_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_task_types'||wwv_flow.LF||
'    for';
wwv_flow_imp.g_varchar2_table(2) := ' each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := co';
wwv_flow_imp.g_varchar2_table(3) := 'alesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :n';
wwv_flow_imp.g_varchar2_table(4) := 'ew.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :ne';
wwv_flow_imp.g_varchar2_table(5) := 'w.static_id := upper(:new.static_id);'||wwv_flow.LF||
'end sp_task_types_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_initia';
wwv_flow_imp.g_varchar2_table(6) := 'tive_def_tasks_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_initiative_default_tasks'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'b';
wwv_flow_imp.g_varchar2_table(7) := 'egin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_';
wwv_flow_imp.g_varchar2_table(8) := 'context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_';
wwv_flow_imp.g_varchar2_table(9) := 'by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(10) := ''||wwv_flow.LF||
'    update sp_initiatives set updated = sysdate, updated_by = :new.updated_by where id = :new.initi';
wwv_flow_imp.g_varchar2_table(11) := 'ative_id;'||wwv_flow.LF||
'end sp_initiative_def_tasks_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_task_statuses_biu'||wwv_flow.LF||
'    be';
wwv_flow_imp.g_varchar2_table(12) := 'fore insert or update'||wwv_flow.LF||
'    on sp_task_statuses'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :';
wwv_flow_imp.g_varchar2_table(13) := 'new.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),u';
wwv_flow_imp.g_varchar2_table(14) := 'ser);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SES';
wwv_flow_imp.g_varchar2_table(15) := 'SION'',''APP_USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.static_id := upper(:new.static_id);'||wwv_flow.LF||
'end sp_task_statuses_bi';
wwv_flow_imp.g_varchar2_table(16) := 'u;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_tasks_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_tasks'||wwv_flow.LF||
'    for ea';
wwv_flow_imp.g_varchar2_table(17) := 'ch row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_old_value   varchar2(4000) := null;'||wwv_flow.LF||
'    l_new_value   varchar2(4000) := null;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(18) := '   l_changed_by  varchar2(255)  := null;'||wwv_flow.LF||
'    l_tags        varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(19) := '-- maintain tracking columns'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(20) := '    :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.u';
wwv_flow_imp.g_varchar2_table(21) := 'pdated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(22) := '  -- maintain status_last_changed'||wwv_flow.LF||
'    if not sp_value_compare.is_equal(:old.status_id,:new.status_id';
wwv_flow_imp.g_varchar2_table(23) := ') then'||wwv_flow.LF||
'       :new.status_last_changed_on := sysdate;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- adjust tag data'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(24) := ' --'||wwv_flow.LF||
'    if :new.tags is not null then'||wwv_flow.LF||
'        l_tags := trim(upper(:new.tags));'||wwv_flow.LF||
'        -- remove mu';
wwv_flow_imp.g_varchar2_table(25) := 'ltiple spaces'||wwv_flow.LF||
'        if instr(l_tags,''  '') > 0 then'||wwv_flow.LF||
'            for j in 1..10 loop '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(26) := '  l_tags := replace(l_tags,''  '','' ''); '||wwv_flow.LF||
'                if instr(l_tags,''  '') = 0 then'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(27) := '     exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        for i in 1..length';
wwv_flow_imp.g_varchar2_table(28) := '(l_tags) loop'||wwv_flow.LF||
'            if i > 2 and substr(l_tags,i,1) = '' '' and substr(l_tags,i-1,1) != '','' then';
wwv_flow_imp.g_varchar2_table(29) := ''||wwv_flow.LF||
'               l_tags := substr(l_tags,1,i-1)||''-''||substr(l_tags,i+1);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(30) := ' end loop;'||wwv_flow.LF||
'        :new.tags := l_tags;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    upda';
wwv_flow_imp.g_varchar2_table(31) := 'te sp_projects set updated = sysdate, updated_by = :new.updated_by where id = :new.project_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(32) := '--'||wwv_flow.LF||
'    -- change history tracking'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'       l_changed_by := lower(:new.upda';
wwv_flow_imp.g_varchar2_table(33) := 'ted_by);'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- PROJECT_ID'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.PROJE';
wwv_flow_imp.g_varchar2_table(34) := 'CT_ID,:new.PROJECT_ID) then'||wwv_flow.LF||
'          for c1 in (select PROJECT r from SP_PROJECTS x where x.id = :o';
wwv_flow_imp.g_varchar2_table(35) := 'ld.PROJECT_ID) loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'          for c1 in (select PROJECT r from SP_PRO';
wwv_flow_imp.g_varchar2_table(36) := 'JECTS x where x.id = :new.PROJECT_ID) loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'          insert into sp_t';
wwv_flow_imp.g_varchar2_table(37) := 'ask_history'||wwv_flow.LF||
'              (task_id, attribute_column, change_type, old_value, new_value, changed_on,';
wwv_flow_imp.g_varchar2_table(38) := ' changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''PROJECT'', ''UPDATE'', l_old_value, l_new_value,';
wwv_flow_imp.g_varchar2_table(39) := ' sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- TASK_TYPE '||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_va';
wwv_flow_imp.g_varchar2_table(40) := 'lue_compare.is_equal(:old.TASK_TYPE_ID,:new.TASK_TYPE_ID) then'||wwv_flow.LF||
'          for c1 in (select TASK_TYPE';
wwv_flow_imp.g_varchar2_table(41) := ' r from SP_TASK_TYPES x where x.id = :old.TASK_TYPE_ID) loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(42) := '  for c1 in (select TASK_TYPE r from SP_TASK_TYPES x where x.id = :new.TASK_TYPE_ID) loop l_new_valu';
wwv_flow_imp.g_varchar2_table(43) := 'e := c1.r; end loop;'||wwv_flow.LF||
'          insert into sp_task_history'||wwv_flow.LF||
'              (task_id, attribute_column,';
wwv_flow_imp.g_varchar2_table(44) := ' change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id,';
wwv_flow_imp.g_varchar2_table(45) := ' ''TASK_TYPE'', ''UPDATE'', l_old_value, l_new_value, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(46) := '      -- TASK_SUB_TYPE '||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.TASK_SUB_TYPE_ID,:new';
wwv_flow_imp.g_varchar2_table(47) := '.TASK_SUB_TYPE_ID) then'||wwv_flow.LF||
'          for c1 in (select TASK_TYPE r from SP_TASK_TYPES x where x.id = :o';
wwv_flow_imp.g_varchar2_table(48) := 'ld.TASK_SUB_TYPE_ID) loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'          for c1 in (select TASK_TYPE r fro';
wwv_flow_imp.g_varchar2_table(49) := 'm SP_TASK_TYPES x where x.id = :new.TASK_SUB_TYPE_ID) loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(50) := 'insert into sp_task_history'||wwv_flow.LF||
'              (task_id, attribute_column, change_type, old_value, new_va';
wwv_flow_imp.g_varchar2_table(51) := 'lue, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''TASK_SUB_TYPE'', ''UPDATE'', l_o';
wwv_flow_imp.g_varchar2_table(52) := 'ld_value, l_new_value, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- TASK'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(53) := '    if not sp_value_compare.is_equal(:old.TASK,:new.TASK) then'||wwv_flow.LF||
'          insert into sp_task_history';
wwv_flow_imp.g_varchar2_table(54) := ''||wwv_flow.LF||
'              (task_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by';
wwv_flow_imp.g_varchar2_table(55) := ')'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''TASK'', ''UPDATE'', :old.TASK, :new.TASK, sysdate, l_change';
wwv_flow_imp.g_varchar2_table(56) := 'd_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- OWNER_ID'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal';
wwv_flow_imp.g_varchar2_table(57) := '(:old.OWNER_ID,:new.OWNER_ID) then'||wwv_flow.LF||
'          for c1 in (select lower(email) r from SP_TEAM_MEMBERS x';
wwv_flow_imp.g_varchar2_table(58) := ' where x.id = :old.owner_id) loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'          for c1 in (select lower(e';
wwv_flow_imp.g_varchar2_table(59) := 'mail) r from SP_TEAM_MEMBERS x where x.id = :new.owner_id) loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(60) := '     insert into sp_task_history'||wwv_flow.LF||
'              (task_id, attribute_column, change_type, old_value, n';
wwv_flow_imp.g_varchar2_table(61) := 'ew_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''OWNER'', ''UPDATE'', l_old_';
wwv_flow_imp.g_varchar2_table(62) := 'value, l_new_value, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- START_DATE'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(63) := '       if not sp_value_compare.is_equal(:old.START_DATE,:new.START_DATE) then'||wwv_flow.LF||
'          insert into ';
wwv_flow_imp.g_varchar2_table(64) := 'sp_task_history'||wwv_flow.LF||
'              (task_id, attribute_column, change_type, old_value, new_value, changed';
wwv_flow_imp.g_varchar2_table(65) := '_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''START_DATE'', ''UPDATE'', to_char(:old.START';
wwv_flow_imp.g_varchar2_table(66) := '_DATE,''DD-MON-YYYY''), to_char(:new.START_DATE,''DD-MON-YYYY''), sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;';
wwv_flow_imp.g_varchar2_table(67) := ''||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- TARGET_COMPLETE'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.TARGET_C';
wwv_flow_imp.g_varchar2_table(68) := 'OMPLETE,:new.TARGET_COMPLETE) then'||wwv_flow.LF||
'          insert into sp_task_history'||wwv_flow.LF||
'              (task_id, att';
wwv_flow_imp.g_varchar2_table(69) := 'ribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(70) := '     (:new.id, ''TARGET_COMPLETE'', ''UPDATE'', to_char(:old.TARGET_COMPLETE,''DD-MON-YYYY''), to_char(:ne';
wwv_flow_imp.g_varchar2_table(71) := 'w.TARGET_COMPLETE,''DD-MON-YYYY''), sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- STATUS'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(72) := '       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.status_id,:new.status_id) then'||wwv_flow.LF||
'          for ';
wwv_flow_imp.g_varchar2_table(73) := 'c1 in (select status r from SP_TASK_STATUSES x where x.id = :old.status_id) loop l_old_value := c1.r';
wwv_flow_imp.g_varchar2_table(74) := '; end loop;'||wwv_flow.LF||
'          for c1 in (select status r from SP_TASK_STATUSES x where x.id = :new.status_id';
wwv_flow_imp.g_varchar2_table(75) := ') loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'          insert into sp_task_history'||wwv_flow.LF||
'              (task_id, ';
wwv_flow_imp.g_varchar2_table(76) := 'attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(77) := '        (:new.id, ''STATUS'', ''UPDATE'', l_old_value, l_new_value, sysdate, l_changed_by);'||wwv_flow.LF||
'       end i';
wwv_flow_imp.g_varchar2_table(78) := 'f;  '||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- DESCRIPTION '||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.DESCRIP';
wwv_flow_imp.g_varchar2_table(79) := 'TION,:new.DESCRIPTION) then'||wwv_flow.LF||
'          insert into sp_task_history'||wwv_flow.LF||
'              (task_id, attribute_';
wwv_flow_imp.g_varchar2_table(80) := 'column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:';
wwv_flow_imp.g_varchar2_table(81) := 'new.id, ''DESCRIPTION'', ''UPDATE'', :old.DESCRIPTION, :new.DESCRIPTION, sysdate, l_changed_by);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(82) := 'end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- TAGS'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.tags,:new.ta';
wwv_flow_imp.g_varchar2_table(83) := 'gs) then'||wwv_flow.LF||
'          insert into sp_task_history'||wwv_flow.LF||
'              (task_id, attribute_column, change_type';
wwv_flow_imp.g_varchar2_table(84) := ', old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''TAGS'', ''UP';
wwv_flow_imp.g_varchar2_table(85) := 'DATE'', :old.tags, :new.tags, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- IMPACT'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(86) := '  --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.impact,:new.impact) then'||wwv_flow.LF||
'          insert into sp_';
wwv_flow_imp.g_varchar2_table(87) := 'task_history'||wwv_flow.LF||
'              (task_id, attribute_column, change_type, old_value, new_value, changed_on';
wwv_flow_imp.g_varchar2_table(88) := ', changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''IMPACT'', ''UPDATE'', :old.impact, :new.impact,';
wwv_flow_imp.g_varchar2_table(89) := ' sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'end sp_tasks_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trig';
wwv_flow_imp.g_varchar2_table(90) := 'ger sp_tasks_ai'||wwv_flow.LF||
'    after insert'||wwv_flow.LF||
'    on sp_tasks'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_type  varchar2(5000)';
wwv_flow_imp.g_varchar2_table(91) := ' := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select TASK_TYPE || case when :new.TASK_SUB_TYPE_ID is not n';
wwv_flow_imp.g_varchar2_table(92) := 'ull'||wwv_flow.LF||
'                                 then '': ''||(select task_type from sp_task_types'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(93) := '                               where id = :new.task_sub_type_id)'||wwv_flow.LF||
'                                 en';
wwv_flow_imp.g_varchar2_table(94) := 'd ||'||wwv_flow.LF||
'                            case when :new.task is not null '||wwv_flow.LF||
'                                 t';
wwv_flow_imp.g_varchar2_table(95) := 'hen '' - ''||:new.task'||wwv_flow.LF||
'                                 end  r'||wwv_flow.LF||
'          from SP_TASK_TYPES x '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(96) := '  where x.id = :new.TASK_TYPE_ID'||wwv_flow.LF||
'    ) loop l_type := substr(c1.r,1,4000); end loop;'||wwv_flow.LF||
'    insert into';
wwv_flow_imp.g_varchar2_table(97) := ' sp_task_history'||wwv_flow.LF||
'        (task_id, attribute_column, change_type, new_value, changed_on, changed_by)';
wwv_flow_imp.g_varchar2_table(98) := ''||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:new.id, ''TASK'', ''CREATE'', l_type, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'end sp_tas';
wwv_flow_imp.g_varchar2_table(99) := 'ks_ai;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_tasks_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_tasks'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'd';
wwv_flow_imp.g_varchar2_table(100) := 'eclare'||wwv_flow.LF||
'    l_type  varchar2(5000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update ';
wwv_flow_imp.g_varchar2_table(101) := 'sp_projects set updated = sysdate, updated_by = :old.updated_by where id = :old.project_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(102) := '   for c1 in ('||wwv_flow.LF||
'        select TASK_TYPE || case when :old.TASK_SUB_TYPE_ID is not null'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(103) := '                    then '': ''||(select task_type from sp_task_types'||wwv_flow.LF||
'                                ';
wwv_flow_imp.g_varchar2_table(104) := '              where id = :old.task_sub_type_id)'||wwv_flow.LF||
'                                 end ||'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(105) := '                case when :old.task is not null '||wwv_flow.LF||
'                                 then '' - ''||:new.t';
wwv_flow_imp.g_varchar2_table(106) := 'ask'||wwv_flow.LF||
'                                 end r'||wwv_flow.LF||
'          from SP_TASK_TYPES x '||wwv_flow.LF||
'         where x.id = :ol';
wwv_flow_imp.g_varchar2_table(107) := 'd.TASK_TYPE_ID'||wwv_flow.LF||
'    ) loop l_type := substr(c1.r,1,4000); end loop;'||wwv_flow.LF||
'    insert into sp_task_history'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(108) := '       (task_id, attribute_column, change_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(109) := '  (:old.id, ''TASK'', ''DELETE'', l_type, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER'')';
wwv_flow_imp.g_varchar2_table(110) := ',user)));'||wwv_flow.LF||
'end sp_tasks_bd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_task_links_biu'||wwv_flow.LF||
'    before insert or updat';
wwv_flow_imp.g_varchar2_table(111) := 'e'||wwv_flow.LF||
'    on sp_task_links'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;';
wwv_flow_imp.g_varchar2_table(112) := ''||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :';
wwv_flow_imp.g_varchar2_table(113) := 'new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)';
wwv_flow_imp.g_varchar2_table(114) := ';'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_tasks set updated = sysdate, updated_by = :n';
wwv_flow_imp.g_varchar2_table(115) := 'ew.updated_by where id = :new.task_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'       if ';
wwv_flow_imp.g_varchar2_table(116) := ':new.task_id is not null then'||wwv_flow.LF||
'           insert into sp_task_history'||wwv_flow.LF||
'               (task_id, attrib';
wwv_flow_imp.g_varchar2_table(117) := 'ute_column, change_type, new_value, changed_on, changed_by)'||wwv_flow.LF||
'           values'||wwv_flow.LF||
'               (:new.t';
wwv_flow_imp.g_varchar2_table(118) := 'ask_id, ''LINK'', ''CREATE'', :new.link_url, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'       elsif updating the';
wwv_flow_imp.g_varchar2_table(119) := 'n'||wwv_flow.LF||
'          if not sp_value_compare.is_equal(:old.link_url,:new.link_url) then'||wwv_flow.LF||
'              insert ';
wwv_flow_imp.g_varchar2_table(120) := 'into sp_task_history'||wwv_flow.LF||
'                  (task_id, attribute_column, change_type, old_value, new_value';
wwv_flow_imp.g_varchar2_table(121) := ',changed_on, changed_by)'||wwv_flow.LF||
'              values'||wwv_flow.LF||
'                  (:new.task_id, ''LINK'', ''UPDATE'', :ol';
wwv_flow_imp.g_varchar2_table(122) := 'd.link_url, :new.link_url, sysdate, lower(:new.updated_by));'||wwv_flow.LF||
'          end if;'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'    en';
wwv_flow_imp.g_varchar2_table(123) := 'd if;'||wwv_flow.LF||
'end sp_task_links_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_task_links_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on ';
wwv_flow_imp.g_varchar2_table(124) := 'sp_task_links'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :old.task_id is not null then'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        -- touc';
wwv_flow_imp.g_varchar2_table(125) := 'h parent table'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        update sp_tasks set updated = sysdate, updated_by = :old.updated_b';
wwv_flow_imp.g_varchar2_table(126) := 'y where id = :old.task_id;'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        insert into sp_task_history'||wwv_flow.LF||
'            (task_id, attr';
wwv_flow_imp.g_varchar2_table(127) := 'ibute_column, change_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:old.task_';
wwv_flow_imp.g_varchar2_table(128) := 'id, ''LINK'', ''DELETE'', :old.link_url, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),';
wwv_flow_imp.g_varchar2_table(129) := 'user)));'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_task_links_bd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'	'||wwv_flow.LF||
'create or replace trigger sp_task_documents_biu'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(130) := 'before insert or update'||wwv_flow.LF||
'    on sp_task_documents'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_tags varchar2(4000) ';
wwv_flow_imp.g_varchar2_table(131) := ':= null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coa';
wwv_flow_imp.g_varchar2_table(132) := 'lesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :ne';
wwv_flow_imp.g_varchar2_table(133) := 'w.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new';
wwv_flow_imp.g_varchar2_table(134) := '.tags := upper(:new.tags);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_tasks set updated =';
wwv_flow_imp.g_varchar2_table(135) := ' sysdate, updated_by = :new.updated_by where id = :new.task_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- adjust tag data'||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(136) := ''||wwv_flow.LF||
'    if :new.tags is not null then'||wwv_flow.LF||
'        l_tags := trim(upper(:new.tags));'||wwv_flow.LF||
'        -- remove multi';
wwv_flow_imp.g_varchar2_table(137) := 'ple spaces'||wwv_flow.LF||
'        if instr(l_tags,''  '') > 0 then'||wwv_flow.LF||
'            for j in 1..10 loop '||wwv_flow.LF||
'                l';
wwv_flow_imp.g_varchar2_table(138) := '_tags := replace(l_tags,''  '','' ''); '||wwv_flow.LF||
'                if instr(l_tags,''  '') = 0 then'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(139) := '  exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        for i in 1..length(l_';
wwv_flow_imp.g_varchar2_table(140) := 'tags) loop'||wwv_flow.LF||
'            if i > 2 and substr(l_tags,i,1) = '' '' and substr(l_tags,i-1,1) != '','' then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(141) := '             l_tags := substr(l_tags,1,i-1)||''-''||substr(l_tags,i+1);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        en';
wwv_flow_imp.g_varchar2_table(142) := 'd loop;'||wwv_flow.LF||
'        :new.tags := l_tags;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(143) := '       insert into sp_task_history'||wwv_flow.LF||
'            (task_id, attribute_column, change_type, new_value, c';
wwv_flow_imp.g_varchar2_table(144) := 'hanged_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.task_id, ''DOCUMENT'', ''CREATE'', :new.DOCUMENT';
wwv_flow_imp.g_varchar2_table(145) := '_FILENAME, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'    elsif updating then '||wwv_flow.LF||
'        insert into sp_task_hi';
wwv_flow_imp.g_varchar2_table(146) := 'story'||wwv_flow.LF||
'            (task_id, attribute_column, change_type, old_value, new_value, changed_on, changed';
wwv_flow_imp.g_varchar2_table(147) := '_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.task_id, ''DOCUMENT'', ''UPDATE'', :old.DOCUMENT_FILENAME, :new.DO';
wwv_flow_imp.g_varchar2_table(148) := 'CUMENT_FILENAME, sysdate, lower(:new.updated_by));'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_task_documents_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create ';
wwv_flow_imp.g_varchar2_table(149) := 'or replace trigger sp_task_documents_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_task_documents'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(150) := 'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_tasks set updated = sysdate, updated_by ';
wwv_flow_imp.g_varchar2_table(151) := '= :old.updated_by where id = :old.task_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    insert into sp_task_history'||wwv_flow.LF||
'        (task_id, ';
wwv_flow_imp.g_varchar2_table(152) := 'attribute_column, change_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.task_id, ';
wwv_flow_imp.g_varchar2_table(153) := '''DOCUMENT'', ''DELETE'', :old.document_filename, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''AP';
wwv_flow_imp.g_varchar2_table(154) := 'P_USER''),user)));'||wwv_flow.LF||
'end sp_task_documents_bd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_task_comments_biu'||wwv_flow.LF||
'    b';
wwv_flow_imp.g_varchar2_table(155) := 'efore insert or update'||wwv_flow.LF||
'    on sp_task_comments'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(156) := ':new.created := sysdate;'||wwv_flow.LF||
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),';
wwv_flow_imp.g_varchar2_table(157) := 'user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sysdate;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SE';
wwv_flow_imp.g_varchar2_table(158) := 'SSION'',''APP_USER''),user);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.private_yn is null then '||wwv_flow.LF||
'        :new.pri';
wwv_flow_imp.g_varchar2_table(159) := 'vate_yn := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_tasks set updated ';
wwv_flow_imp.g_varchar2_table(160) := '= sysdate, updated_by = :new.updated_by where id = :new.task_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if';
wwv_flow_imp.g_varchar2_table(161) := ' inserting and :new.private_yn = ''N'' then'||wwv_flow.LF||
'        insert into sp_task_history'||wwv_flow.LF||
'            (task_id, ';
wwv_flow_imp.g_varchar2_table(162) := 'attribute_column, change_type, new_value, new_value_clob, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(163) := '         (:new.task_id, ''COMMENT'', ''CREATE'', dbms_lob.substr(:new.body_no_images,500,1), :new.body_n';
wwv_flow_imp.g_varchar2_table(164) := 'o_images, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'    elsif updating and :old.private_yn = ''N'' and :new.pr';
wwv_flow_imp.g_varchar2_table(165) := 'ivate_yn = ''N'' then'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.body_no_images,:new.body_no_images';
wwv_flow_imp.g_varchar2_table(166) := ') then'||wwv_flow.LF||
'            insert into sp_task_history'||wwv_flow.LF||
'                (task_id, attribute_column, change_ty';
wwv_flow_imp.g_varchar2_table(167) := 'pe, old_value, new_value, old_value_clob, new_value_clob, changed_on, changed_by)'||wwv_flow.LF||
'            values';
wwv_flow_imp.g_varchar2_table(168) := ''||wwv_flow.LF||
'                (:new.task_id, ''COMMENT'', ''UPDATE'', dbms_lob.substr(:old.body_no_images,500,1), dbm';
wwv_flow_imp.g_varchar2_table(169) := 's_lob.substr(:new.body_no_images,1), :old.body_no_images, :new.body_no_images, sysdate, lower(:new.u';
wwv_flow_imp.g_varchar2_table(170) := 'pdated_by));'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_task_comments_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_t';
wwv_flow_imp.g_varchar2_table(171) := 'ask_comments_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_task_comments'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :old.private';
wwv_flow_imp.g_varchar2_table(172) := '_yn = ''N'' then'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        -- touch parent table'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        update sp_tasks set updat';
wwv_flow_imp.g_varchar2_table(173) := 'ed = sysdate, updated_by = :old.updated_by where id = :old.task_id;'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        insert into s';
wwv_flow_imp.g_varchar2_table(174) := 'p_task_history'||wwv_flow.LF||
'            (task_id, attribute_column, change_type, old_value, old_value_clob, chang';
wwv_flow_imp.g_varchar2_table(175) := 'ed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:old.task_id, ''COMMENT'', ''DELETE'', dbms_lob.substr(:o';
wwv_flow_imp.g_varchar2_table(176) := 'ld.body_no_images,500,1), :old.body_no_images, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''A';
wwv_flow_imp.g_varchar2_table(177) := 'PP_USER''),user)));'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_task_comments_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38218220673520999286)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'Project Task triggers'
,p_sequence=>720
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
