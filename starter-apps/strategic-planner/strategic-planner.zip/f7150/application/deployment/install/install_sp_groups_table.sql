prompt --application/deployment/install/install_sp_groups_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_groups table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table SP_GROUPS ('||wwv_flow.LF||
'    id                             number default on null to_number(sys_gui';
wwv_flow_imp.g_varchar2_table(2) := 'd(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint SP_GROUPS_pk';
wwv_flow_imp.g_varchar2_table(3) := ' primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    group_name                     varchar2(100  char) not null,'||wwv_flow.LF||
'    group_name';
wwv_flow_imp.g_varchar2_table(4) := '_upper               varchar2(100  char) not null,'||wwv_flow.LF||
'    description                    varchar2(4000 ';
wwv_flow_imp.g_varchar2_table(5) := 'char),'||wwv_flow.LF||
'    group_tag                      varchar2(100 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                    ';
wwv_flow_imp.g_varchar2_table(6) := '    date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated      ';
wwv_flow_imp.g_varchar2_table(7) := '                  date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(8) := ''||wwv_flow.LF||
'create unique index SP_GROUPS_i1 on SP_GROUPS (group_name_upper);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(45805078863290884367)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_groups table'
,p_sequence=>120
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
