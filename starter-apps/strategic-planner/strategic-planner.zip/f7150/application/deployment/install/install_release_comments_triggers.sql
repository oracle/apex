prompt --application/deployment/install/install_release_comments_triggers
begin
--   Manifest
--     INSTALL: INSTALL-release comments triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7150
,p_default_id_offset=>11016538767572718
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_release_comments_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_release_comm';
wwv_flow_imp.g_varchar2_table(2) := 'ents'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created := sysdate;'||wwv_flow.LF||
'        :new.crea';
wwv_flow_imp.g_varchar2_table(3) := 'ted_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated := sys';
wwv_flow_imp.g_varchar2_table(4) := 'date;'||wwv_flow.LF||
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- p';
wwv_flow_imp.g_varchar2_table(5) := 'rivate'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.private_yn is null then '||wwv_flow.LF||
'       :new.private_yn := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(6) := '-'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_release_trains set updated = sysdate, updated_by = ';
wwv_flow_imp.g_varchar2_table(7) := ':new.updated_by where id = :new.release_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting and :new.p';
wwv_flow_imp.g_varchar2_table(8) := 'rivate_yn = ''N'' then'||wwv_flow.LF||
'        insert into sp_release_history'||wwv_flow.LF||
'            (release_id, attribute_colum';
wwv_flow_imp.g_varchar2_table(9) := 'n, change_type, new_value, new_value_clob, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.';
wwv_flow_imp.g_varchar2_table(10) := 'release_id, ''RELEASE_COMMENT'', ''CREATE'', dbms_lob.substr(:new.body_no_images,500,1), :new.body_no_im';
wwv_flow_imp.g_varchar2_table(11) := 'ages, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'    elsif updating and :old.private_yn = ''N'' and :new.privat';
wwv_flow_imp.g_varchar2_table(12) := 'e_yn = ''N'' then'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.body_no_images,:new.body_no_images) th';
wwv_flow_imp.g_varchar2_table(13) := 'en'||wwv_flow.LF||
'            insert into sp_release_history'||wwv_flow.LF||
'                (release_id, attribute_column, change_';
wwv_flow_imp.g_varchar2_table(14) := 'type, old_value, new_value, old_value_clob, new_value_clob, changed_on, changed_by)'||wwv_flow.LF||
'            valu';
wwv_flow_imp.g_varchar2_table(15) := 'es'||wwv_flow.LF||
'                (:new.release_id, ''RELEASE_COMMENT'', ''UPDATE'', dbms_lob.substr(:old.body_no_image';
wwv_flow_imp.g_varchar2_table(16) := 's,500,1), dbms_lob.substr(:new.body_no_images,500,1), :old.body_no_images, :new.body_no_images, sysd';
wwv_flow_imp.g_varchar2_table(17) := 'ate, lower(:new.updated_by));'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_release_comments_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or';
wwv_flow_imp.g_varchar2_table(18) := ' replace trigger sp_release_comments_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_release_comments'||wwv_flow.LF||
'    for each ro';
wwv_flow_imp.g_varchar2_table(19) := 'w'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :old.private_yn = ''N'' then'||wwv_flow.LF||
'    insert into sp_release_history'||wwv_flow.LF||
'        (release_id, at';
wwv_flow_imp.g_varchar2_table(20) := 'tribute_column, change_type, old_value, old_value_clob, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (';
wwv_flow_imp.g_varchar2_table(21) := ':old.release_id, ''RELEASE_COMMENT'', ''DELETE'', dbms_lob.substr(:old.body_no_images,500,1), :old.body_';
wwv_flow_imp.g_varchar2_table(22) := 'no_images, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end s';
wwv_flow_imp.g_varchar2_table(23) := 'p_release_comments_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(44986715404784619295)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'release comments triggers'
,p_sequence=>480
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
