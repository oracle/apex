prompt --application/pages/page_00705
begin
--   Manifest
--     PAGE: 00705
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>705
,p_name=>'Update Out of Office Details'
,p_alias=>'UPDATE-OOO-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Update Out of Office Details'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>1664614232864994871
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_required_patch=>wwv_flow_imp.id(31743638170417552010)
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(97167546644778433691)
,p_plug_name=>'Buttons'
,p_static_id=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_plug_template=>2129856781885180476
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(97185889389451282449)
,p_plug_name=>'Event Details'
,p_static_id=>'event-details'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(97185889430964282450)
,p_plug_name=>'Update Affects'
,p_static_id=>'update-affects'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_plug_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P704_RECURS = ''Y'' and',
'(:P705_EVENT_TYPE != :P705_NEW_EVENT_TYPE or',
' nvl(:P705_EVENT_NAME,''~'') != nvl(:P705_NEW_EVENT_NAME,''~'') or',
' nvl(:P705_EVENT_DETAILS,''~'') != nvl(:P705_NEW_EVENT_DETAILS,''~'') )'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32729369350662020150)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(97167546644778433691)
,p_button_name=>'APPLY_CHANGES'
,p_static_id=>'apply-changes'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32729368915930020149)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(97167546644778433691)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64571885925878746992)
,p_name=>'P705_EVENT_DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(97185889389451282449)
,p_prompt=>'Event Date'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P705_EVENT_DATE'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64571886239169746995)
,p_name=>'P705_EVENT_DETAILS'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(97185889389451282449)
,p_prompt=>'Event Details'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P705_EVENT_DETAILS'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64571885671334746990)
,p_name=>'P705_EVENT_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(97185889389451282449)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64571885959016746993)
,p_name=>'P705_EVENT_NAME'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(97185889389451282449)
,p_prompt=>'Event Name'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P705_EVENT_NAME'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64571885746162746991)
,p_name=>'P705_EVENT_TYPE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(97185889389451282449)
,p_prompt=>'Event Type'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P705_EVENT_TYPE'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64571886068415746994)
,p_name=>'P705_FOR_USER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(97185889389451282449)
,p_prompt=>'For User'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P705_FOR_USER'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31842516044521726849)
,p_name=>'P705_NEW_EVENT_DETAILS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(97185889389451282449)
,p_prompt=>'New Event Details'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P705_NEW_EVENT_DETAILS'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--boldDisplay'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31842516152310726850)
,p_name=>'P705_NEW_EVENT_NAME'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(97185889389451282449)
,p_prompt=>'New Event Name'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P705_NEW_EVENT_NAME'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--boldDisplay'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31842515914374726848)
,p_name=>'P705_NEW_EVENT_TYPE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(97185889389451282449)
,p_prompt=>'New Event Type'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P705_NEW_EVENT_TYPE'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--boldDisplay'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32733524158335472601)
,p_name=>'P705_NEW_REPEATS'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(97185889389451282449)
,p_prompt=>'New Repeats'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P705_NEW_REPEATS'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--boldDisplay'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64571886275029746996)
,p_name=>'P705_REPEATS'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(97185889389451282449)
,p_prompt=>'Repeats'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P705_REPEATS'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(97185891940792282463)
,p_name=>'P705_UPDATE_AFFECTS'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(97185889430964282450)
,p_prompt=>'Update Affects'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'P705_UPDATE_AFFECTS'
,p_field_template=>1612549789555753698
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(32729374335323020161)
,p_name=>'close'
,p_static_id=>'close'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(32729368915930020149)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(32729374825497020161)
,p_event_id=>wwv_flow_imp.id(32729374335323020161)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-dialog-cancel'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32729373531585020160)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'close'
,p_static_id=>'close'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_success_messages', 'Y')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(32729369350662020150)
,p_internal_uid=>32729373531585020160
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(34862771998169242135)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'reload OOO Summary, if necessary'
,p_static_id=>'reload-ooo-summary-if-necessary'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_for_user_id  number;',
'    l_updated_yn   varchar2(1);',
'begin',
'',
'l_for_user_id := case :P704_EVENT_FOR when ''E'' ',
'                                      then :P704_FOR_USER_ID',
'                                      when ''M''',
'                                      then :APP_USER_ID',
'                                      end;',
'',
'if :P704_PREVIOUS_FOR_USER_ID != l_for_user_id then',
'    sp_event_util.load_one_ooo (',
'        p_team_member_id => :P704_PREVIOUS_FOR_USER_ID,',
'        p_updated_yn     => l_updated_yn );',
'end if;',
'',
'if l_for_user_id is not null then',
'    sp_event_util.load_one_ooo (',
'        p_team_member_id => l_for_user_id,',
'        p_updated_yn     => l_updated_yn );',
'end if;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>34862771998169242135
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32729373122415020159)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save Changes'
,p_static_id=>'save-changes'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_event_util.update_event ( ',
'    p_event_id       => :P705_EVENT_ID, ',
'    p_event_type_id  => :P704_EVENT_TYPE_ID, ',
'    p_event_date     => to_date(:P704_START_DATE,''DD-Mon-YYYY''), ',
'    p_event_name     => :P704_EVENT_NAME, ',
'    p_for_user_id    => case :P704_EVENT_FOR when ''E'' ',
'                                      then :P704_FOR_USER_ID',
'                                      when ''M''',
'                                      then :APP_USER_ID',
'                                      end,',
'    p_event_details  => :P704_EVENT_DETAILS, ',
'    p_recur_freq     => :P704_RECUR_FREQ, ',
'    p_recur_end_date => to_date(:P704_END_DATE,''DD-Mon-YYYY''), ',
'    p_update_type    => :P705_UPDATE_AFFECTS',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(32729369350662020150)
,p_process_success_message=>'Event(s) updated.'
,p_internal_uid=>32729373122415020159
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32729373910206020160)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set values'
,p_static_id=>'set-values'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_start_date  date := to_date(:P704_START_DATE,''DD-Mon-YYYY'');',
'    l_end_date    date := to_date(:P704_END_DATE,''DD-Mon-YYYY'');',
'begin',
'',
'for c1 in (',
'    select (select event_type from sp_event_types',
'             where id = e.event_type_id) event_type,',
'           event_type_id,',
'           event_date,',
'           event_name event_name,',
'           event_details event_details,',
'           (select first_name||'' ''||last_name',
'              from sp_team_members',
'             where id = e.for_user_id) for_user,',
'           series_id',
'      from sp_events e',
'     where id = :P705_EVENT_ID',
') loop',
'    :P705_EVENT_TYPE := c1.event_type;',
'    if :P704_EVENT_TYPE_ID != c1.event_type_id then',
'        for c2 in (',
'            select event_type from sp_event_types',
'             where id = :P704_EVENT_TYPE_ID',
'        ) loop',
'            :P705_NEW_EVENT_TYPE := c2.event_type;',
'        end loop;',
'    end if;',
'',
'    :P705_EVENT_DATE := to_char(c1.event_date,''Mon fmDD, YYYY'');',
'',
'    :P705_EVENT_NAME := c1.event_name;',
'    if :P704_EVENT_NAME != :P705_EVENT_NAME then',
'        :P705_NEW_EVENT_NAME := :P704_EVENT_NAME;',
'    end if;',
'',
'    :P705_FOR_USER := c1.for_user;',
'    :P705_EVENT_DETAILS := c1.event_details;',
'    if nvl(:P704_EVENT_DETAILS,''~'') != nvl(c1.event_details,''~'') then',
'        :P705_NEW_EVENT_DETAILS := :P704_EVENT_DETAILS;',
'    end if;',
'',
'    for c2 in (',
'        select recur_freq,',
'               decode(recur_freq, ''D'', ''Daily'', ''WD'', ''Weekdays'', ''W'', ''Weekly'', ',
'                                  ''2W'', ''Every 2 Weeks'', ''M'', ''Monthly'', recur_freq) recur_freq_display,',
'               start_date, end_date',
'          from sp_event_series',
'         where id = c1.series_id',
'    ) loop',
'        :P705_REPEATS := c2.recur_freq_display||'', ''||',
'                         case when to_char(c2.start_date,''MONYYYY'') = to_char(c2.end_date,''MONYYYY'') ',
'                              then to_char(c2.start_date,''Mon fmDD'')||''-''||to_char(c2.end_date,''fmDD, YYYY'')',
'                              when to_char(c2.start_date,''YYYY'') = to_char(c2.end_date,''YYYY'') ',
'                              then to_char(c2.start_date,''Mon fmDD'')||'' until ''||to_char(c2.end_date,''Mon fmDD, YYYY'')',
'                              else to_char(c2.start_date,''Mon fmDD, YYYY'')||'' until ''||to_char(c2.end_date,''Mon fmDD YYYY'')',
'                              end;',
'',
'        if :P704_RECURS = ''N'' then',
'            :P705_NEW_REPEATS := ''No recurrence'';',
'        elsif :P704_RECUR_FREQ != c2.recur_freq or',
'           l_start_date != c2.start_date or',
'           l_end_date != c2.end_date',
'        then',
'            :P705_NEW_REPEATS := case :P704_RECUR_FREQ',
'                                      when ''D''  then ''Daily''',
'                                      when ''WD'' then ''Weekdays'' when ''W'' then ''Weekly''',
'                                      when ''2W'' then ''Every 2 Weeks'' when ''M'' then ''Monthly''',
'                                      end ||'', ''||',
'                         case when to_char(l_start_date,''MONYYYY'') = to_char(l_end_date,''MONYYYY'') ',
'                              then to_char(l_start_date,''Mon fmDD'')||''-''||to_char(l_end_date,''fmDD, YYYY'')',
'                              when to_char(l_start_date,''YYYY'') = to_char(l_end_date,''YYYY'') ',
'                              then to_char(l_start_date,''Mon fmDD'')||'' until ''||to_char(l_end_date,''Mon fmDD, YYYY'')',
'                              else to_char(l_start_date,''Mon fmDD, YYYY'')||'' until ''||to_char(l_end_date,''Mon fmDD YYYY'')',
'                              end;',
'        end if;',
'',
'    end loop;',
'end loop;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>32729373910206020160
);
wwv_flow_imp.component_end;
end;
/
