prompt --application/pages/page_14010
begin
--   Manifest
--     PAGE: 14010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>14010
,p_name=>'Delete Sample Data'
,p_alias=>'DELETE-SAMPLE-DATA'
,p_step_title=>'Delete Sample Data'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4075783602716660119
,p_page_css_classes=>'rw-pillar--sienna'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(176220694375517839665)
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(185441118340532428725)
,p_plug_name=>'breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>5
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_menu_id=>wwv_flow_imp.id(176220395320510839347)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(79789862761960937515)
,p_name=>'Sample Data'
,p_static_id=>'delete-sample-data'
,p_template=>4504868307683981366
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--noBorders'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select label, cnt, details',
'  from ',
'(',
'select 1 ob, :NOMENCLATURE_AREAS label, count(*) cnt,',
'       listagg(area,'', '' on overflow truncate with count) within group (order by id) details',
'  from SP_AREAS',
' where id in (1,2,3)',
'union all',
'select 2 ob, :NOMENCLATURE_INITIATIVES label, count(*) cnt,',
'       listagg(initiative,'', '' on overflow truncate with count) within group (order by id) details',
'  from SP_INITIATIVES',
' where id in (1,2,3,4,5,6)',
'union all',
'select 8 ob, :NOMENCLATURE_PROJECTS label, count(*) cnt,',
'       listagg(project,'', '' on overflow truncate with count) within group (order by id) details',
'  from SP_PROJECTS',
' where id in (1001,1002,1003,1004,1005,1006,1007,1008,1009,1010,6001,6002,6003,6004,6005,6006,6007,6008,6009,6010,8001,8002,8003,8004,8005,8006,8007,8008,8009,8010,8201,8202,8203,8204,8205,8206,8501,8502,8503,8504,8505,8506,8507,8508,8509,8510,8511,8'
||'512)',
'union all',
'select 4 ob, ''Activities'' label, count(*) cnt,',
'       listagg(comments,'', '' on overflow truncate with count) within group (order by id) details',
'  from sp_activities',
' where id in (1)',
'union all',
'select 5 ob, ''Releases'' label, count(*) cnt,',
'       listagg(release_train||'' '' ||release,'', '' on overflow truncate with count) within group (order by id) details',
'  from sp_release_trains',
' where id in (1,2,3,7,8)',
'union all',
'select 7 ob, :NOMENCLATURE_USERS label, count(*) cnt,',
'       listagg(first_name||'' ''||last_name,'', '' on overflow truncate with count) within group (order by id) details',
'  from SP_TEAM_MEMBERS',
' where id >= 1 and id <= 21',
')',
'where cnt > 0',
'order by ob'))
,p_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This application installed with some sample data to help illustrate it''s use.  ',
'    Once deleted, this data cannot be installed again.',
'    Only the main attributes listed below will be deleted, not any of the Look Up Values.</p>',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2542081983073888486
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'Sample data has all been removed.'
,p_query_num_rows_type=>'SHOW_ALL'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51823990972522291161)
,p_query_column_id=>2
,p_column_alias=>'CNT'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51823991073326291162)
,p_query_column_id=>3
,p_column_alias=>'DETAILS'
,p_column_display_sequence=>40
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51823990803299291160)
,p_query_column_id=>1
,p_column_alias=>'LABEL'
,p_column_display_sequence=>20
,p_column_heading=>'Label'
,p_column_html_expression=>'#CNT# #LABEL# (#DETAILS#)'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(52408206288609167585)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(185441118340532428725)
,p_button_name=>'DELETE'
,p_static_id=>'delete'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Delete'
,p_button_position=>'NEXT'
,p_confirm_message=>'Do you really want to remove the sample data?'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from SP_AREAS',
' where id in (1,2)',
'union all',
'select 1',
'  from SP_INITIATIVES',
' where id in (1,2,3)',
'union all',
'select 1',
'  from SP_PROJECTS',
' where id in (1,2,3,4,5,6)',
'union all',
'select 1',
'  from sp_activities',
' where id in (1,2,3)',
'union all',
'select 1',
'  from sp_release_trains',
' where id in (1,2)',
'union all',
'select 1',
'  from SP_TEAM_MEMBERS',
' where id in (1,2,3)'))
,p_button_condition_type=>'EXISTS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(52408206780055167585)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(185441118340532428725)
,p_button_name=>'Up'
,p_static_id=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2352535364915922073
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(52408207987002167587)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'delete sample data'
,p_static_id=>'delete-sample-data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_project_ids      varchar2(4000);',
'    l_release_ids      varchar2(4000);',
'    l_initiative_ids   varchar2(4000);',
'    l_area_ids         varchar2(4000);',
'    l_team_member_ids  varchar2(4000);',
'begin',
'',
'l_project_ids     := '':1001:1002:1003:1004:1005:1006:1007:1008:1009:1010:6001:6002:6003:6004:6005:6006:6007:6008:6009:6010:8001:8002:8003:8004:8005:8006:8007:8008:8009:8010:8201:8202:8203:8204:8205:8206:8501:8502:8503:8504:8505:8506:8507:8508:8509:85'
||'10:8511:8512:'';',
'l_release_ids     := '':1:2:3:7:8:'';',
'l_initiative_ids  := '':1:2:3:4:5:6:'';',
'l_area_ids        := '':1:2:3:'';',
'l_team_member_ids := '':1:2:3:4:5:6:7:8:9:10:11:12:13:14:15:16:17:18:19:20:21:'';',
'',
'delete from sp_activities',
' where id = 1;',
'delete from sp_activities',
' where instr(l_project_ids,'':''||project_id||'':'') > 0;',
'',
'delete from sp_project_comments',
' where instr(l_project_ids,'':''||project_id||'':'') > 0;',
'',
'delete from sp_project_documents',
' where instr(l_project_ids,'':''||project_id||'':'') > 0;',
'',
'delete from sp_tasks',
' where instr(l_project_ids,'':''||project_id||'':'') > 0;',
'',
'delete from sp_project_contributors',
' where instr(l_project_ids,'':''||project_id||'':'') > 0;',
'',
'delete from sp_project_links',
' where instr(l_project_ids,'':''||project_id||'':'') > 0;',
'',
'delete from sp_project_related',
' where instr(l_project_ids,'':''||project_id||'':'') > 0',
'    or instr(l_project_ids,'':''||related_project_id||'':'') > 0;',
'',
'delete from sp_project_approvals',
' where instr(l_project_ids,'':''||project_id||'':'') > 0;',
'',
'delete from sp_project_history',
' where instr(l_project_ids,'':''||project_id||'':'') > 0;',
'',
'delete from SP_PROJ_INTERACTIONS_LOG ',
' where instr(l_project_ids,'':''||project_id||'':'') > 0;',
'',
'delete from SP_PROJECTS',
' where instr(l_project_ids,'':''||id||'':'') > 0;',
'',
'',
'delete from sp_release_comments',
' where instr(l_release_ids,'':''||release_id||'':'') > 0;',
'',
'delete from sp_release_documents',
' where instr(l_release_ids,'':''||release_id||'':'') > 0;',
'',
'delete from sp_release_links',
' where instr(l_release_ids,'':''||release_id||'':'') > 0;',
'',
'delete from sp_release_milestones',
' where instr(l_release_ids,'':''||release_id||'':'') > 0;',
'',
'delete from sp_release_history',
' where instr(l_release_ids,'':''||release_id||'':'') > 0;',
'',
'delete from sp_release_trains',
' where instr(l_release_ids,'':''||id||'':'') > 0;',
'',
'',
'delete from sp_initiative_links',
' where instr(l_initiative_ids,'':''||initiative_id||'':'') > 0;',
'',
'delete from sp_initiative_comments',
' where instr(l_initiative_ids,'':''||initiative_id||'':'') > 0;',
'',
'delete from sp_initiative_documents',
' where instr(l_initiative_ids,'':''||initiative_id||'':'') > 0;',
'',
'delete from sp_initiative_default_tasks',
' where instr(l_initiative_ids,'':''||initiative_id||'':'') > 0;',
'',
'delete from sp_initiative_focus_areas',
' where instr(l_initiative_ids,'':''||initiative_id||'':'') > 0;',
'',
'delete from sp_initiative_approval_chain',
' where initiative_approval_id in (select id from sp_initiative_approvals',
'                                   where instr(l_initiative_ids,'':''||id||'':''));',
'',
'delete from sp_initiative_approvals',
' where instr(l_initiative_ids,'':''||initiative_id||'':'') > 0;',
'',
'delete from SP_INITIATIVES',
' where instr(l_initiative_ids,'':''||id||'':'') > 0;',
'',
'',
'delete from SP_AREAS',
' where instr(l_area_ids,'':''||id||'':'') > 0;',
'',
'',
'delete from SP_TEAM_MEMBERS',
' where instr(l_team_member_ids,'':''||id||'':'') > 0;',
'',
'',
'delete from sp_approval_types',
' where id = 1;',
'',
'',
'sp_util.add_app_log (',
'    p_activity => ''Sample Data Deleted'', ',
'    p_details  => null );',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Sample data failed to be deleted.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(52408206288609167585)
,p_process_success_message=>'Sample data deleted.'
,p_internal_uid=>15510389703468257946
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(51823991346626291165)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'recalculate counts'
,p_static_id=>'recalculate-counts'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (select count(*) c from sp_areas) loop',
'    :P1_AREAS := to_char(c1.c,''FM999G999G990''); ',
'end loop;',
'',
'for c1 in (select count(*) c from sp_initiatives)  loop',
'    :P1_INITIATIVES := to_char(c1.c,''FM999G999G990''); ',
'end loop;',
'',
'for c1 in (select count(*)  c',
'             from sp_projects p',
'            where p.ARCHIVED_YN = ''N'' and ',
'                  p.DUPLICATE_OF_PROJECT_ID is null',
') loop',
'    :P1_PROJECTS := to_char(c1.c,''FM999G999G990''); ',
'end loop;',
'',
'for c1 in (select count(*) c ',
'             from sp_activities ap, sp_projects p',
'            where (nvl(ap.private_yn,''N'') = ''N'' or lower(ap.created_by) = lower(:APP_USER)) and',
'                  ap.project_id = p.id(+) and',
'                  p.DUPLICATE_OF_PROJECT_ID is null and',
'                  (p.ARCHIVED_YN = ''N'' or p.archived_yn is null) -- need the is null to accomodate the outer join',
') loop',
'    :P1_ACTIVITIES := to_char(c1.c,''FM999G999G990''); ',
'end loop;',
'',
'for c1 in (select count(*) c from SP_RELEASE_TRAINS) loop',
'    :P1_RELEASES := to_char(c1.c,''FM999G999G990''); ',
'end loop;',
'',
'for c1 in (select count(*) c from SP_TEAM_MEMBERS) loop',
'    :P1_PEOPLE := to_char(c1.c,''FM999G999G990''); ',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(52408206288609167585)
,p_internal_uid=>14926173063092381524
);
wwv_flow_imp.component_end;
end;
/
