prompt --application/pages/page_10400
begin
--   Manifest
--     PAGE: 10400
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10400
,p_name=>'Nomenclature'
,p_alias=>'NOMENCLATURE'
,p_step_title=>'Nomenclature'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(176220695587590839674)
,p_step_template=>4075783602716660119
,p_page_css_classes=>'rw-pillar--sienna'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(176220694375517839665)
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44863980593872240071)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_menu_id=>wwv_flow_imp.id(176220395320510839347)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44863975436501240066)
,p_plug_name=>'Nomenclature'
,p_static_id=>'nomenclature'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_plug_template=>2103954283454391425
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       static_id,',
'       default_order,',
'       DEFAULT_VALUE,',
'       --',
'       v(''NOMENCLATURE_''||STATIC_ID) current_label,',
'       CREATED,',
'       CREATED_BY,',
'       UPDATED,',
'       UPDATED_BY',
'  from SP_APP_NOMENCLATURE'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
,p_prn_page_header=>'Nomenclature'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Customize the application name and select primary attribute names to conform to your organization''s terminology.</p>',
'<p>Edit any of the attributes, changing the draft value.  ',
'    Once all changes have been made, use the Publish Draft Labels button to apply the changes to the application.</p>'))
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(44863975574884240066)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:10410:&APP_SESSION.::&DEBUG.:RP:P10410_ID:\#ID#\'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_internal_uid=>7966157291350330425
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44863977483677240069)
,p_db_column_name=>'CREATED'
,p_display_order=>102
,p_column_identifier=>'E'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44863977917317240069)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>112
,p_column_identifier=>'F'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66425791945549064450)
,p_db_column_name=>'CURRENT_LABEL'
,p_display_order=>12
,p_column_identifier=>'O'
,p_column_label=>'Current Label'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66425791700914064448)
,p_db_column_name=>'DEFAULT_ORDER'
,p_display_order=>92
,p_column_identifier=>'N'
,p_column_label=>'Order'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44863977101735240068)
,p_db_column_name=>'DEFAULT_VALUE'
,p_display_order=>22
,p_column_identifier=>'D'
,p_column_label=>'Draft Label'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44863975904615240067)
,p_db_column_name=>'ID'
,p_display_order=>0
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44863976336423240068)
,p_db_column_name=>'STATIC_ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Static ID'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44863978351884240069)
,p_db_column_name=>'UPDATED'
,p_display_order=>122
,p_column_identifier=>'G'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE_SHORT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44863978766794240070)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>132
,p_column_identifier=>'H'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(44863991920106260952)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'79661737'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DEFAULT_ORDER:CURRENT_LABEL:DEFAULT_VALUE:UPDATED'
,p_sort_column_1=>'DEFAULT_ORDER'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'STATIC_ID'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'UPDATED'
,p_sort_direction_3=>'DESC'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(66425795720327064488)
,p_name=>'SQL'
,p_static_id=>'sql'
,p_template=>2667762537863948531
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''insert into SP_APP_NOMENCLATURE (static_ID, default_order, default_value) values (''||',
'       ''''''''||static_id||'''''', ''||',
'       default_order||'', ''||',
'       ''''''''||replace(default_value,'''''''','''''''''''')||''''''''||',
'       '');'' sql',
'  from SP_APP_NOMENCLATURE n'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2542081983073888486
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66425795864352064489)
,p_query_column_id=>1
,p_column_alias=>'SQL'
,p_column_display_sequence=>10
,p_column_heading=>'SQL'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8975947615088749329)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(44863980593872240071)
,p_button_name=>'publish'
,p_static_id=>'publish'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Publish Draft Labels'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:10400:&SESSION.:PUBLISH:&DEBUG.:::'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(44863365400447686912)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(44863980593872240071)
,p_button_name=>'UP'
,p_static_id=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2352535364915922073
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(44863979579326240070)
,p_name=>'Edit Report - Dialog Closed'
,p_static_id=>'edit-report-dialog-closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(44863975436501240066)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44863980064004240071)
,p_event_id=>wwv_flow_imp.id(44863979579326240070)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(44863975436501240066)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(44567954059614783268)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set_draft'
,p_static_id=>'set-draft'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update SP_APP_NOMENCLATURE',
'   set CUSTOM_VALUE = DEFAULT_VALUE;',
'   ',
'sp_util.set_nomenclature;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'PUBLISH'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>'Application Nomenclature reset to Draft Values'
,p_internal_uid=>7670135776080873627
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(44567954159011783269)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set_nomenclature'
,p_static_id=>'set-nomenclature'
,p_process_sql_clob=>'sp_util.set_nomenclature;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>7670135875477873628
);
wwv_flow_imp.component_end;
end;
/
