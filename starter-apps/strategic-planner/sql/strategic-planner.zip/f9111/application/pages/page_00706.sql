prompt --application/pages/page_00706
begin
--   Manifest
--     PAGE: 00706
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>706
,p_name=>'Delete Out of Office Event'
,p_alias=>'DELETE-OOO-EVENT'
,p_page_mode=>'MODAL'
,p_step_title=>'Delete Out of Office Event'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>1664614232864994871
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_required_patch=>wwv_flow_imp.id(31743638170417552010)
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64438178293763413547)
,p_plug_name=>'Buttons'
,p_static_id=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_plug_template=>2129856781885180476
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64456521079949262306)
,p_plug_name=>'Delete Affects'
,p_static_id=>'delete-affects'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64456521038436262305)
,p_plug_name=>'Event Details'
,p_static_id=>'event-details'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32615276980475685647)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(64438178293763413547)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(32615277314575685648)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(64438178293763413547)
,p_button_name=>'DELETE'
,p_static_id=>'delete'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Delete'
,p_button_position=>'NEXT'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64456521781578262312)
,p_name=>'P706_DELETE_AFFECTS'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(64456521079949262306)
,p_prompt=>'Delete Affects'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'P706_DELETE_AFFECTS'
,p_field_template=>1612549789555753698
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31842515085242726839)
,p_name=>'P706_EVENT_DATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(64456521038436262305)
,p_prompt=>'Event Date'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P706_EVENT_DATE'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31842515398533726842)
,p_name=>'P706_EVENT_DETAILS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(64456521038436262305)
,p_prompt=>'Event Details'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P706_EVENT_DETAILS'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31842514830698726837)
,p_name=>'P706_EVENT_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(64456521038436262305)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31842515118380726840)
,p_name=>'P706_EVENT_NAME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(64456521038436262305)
,p_prompt=>'Event Name'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P706_EVENT_NAME'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31842514905526726838)
,p_name=>'P706_EVENT_TYPE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(64456521038436262305)
,p_prompt=>'Event Type'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P706_EVENT_TYPE'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31842515227779726841)
,p_name=>'P706_FOR_USER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(64456521038436262305)
,p_prompt=>'For User'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P706_FOR_USER'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31842515434393726843)
,p_name=>'P706_REPEATS'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(64456521038436262305)
,p_prompt=>'Repeats'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P706_REPEATS'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(31842514345869726832)
,p_name=>'close'
,p_static_id=>'close'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(32615276980475685647)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31842514485206726833)
,p_event_id=>wwv_flow_imp.id(31842514345869726832)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-dialog-cancel'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(31842514238990726831)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'close'
,p_static_id=>'close'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_success_messages', 'Y')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(32615277314575685648)
,p_internal_uid=>31842514238990726831
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(31842514169231726830)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete'
,p_static_id=>'delete'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_event_util.delete_event ( ',
'    p_event_id    => :P706_EVENT_ID, ',
'    p_delete_type => :P706_DELETE_AFFECTS );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(32615277314575685648)
,p_process_success_message=>'Event(s) deleted.'
,p_internal_uid=>31842514169231726830
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(33518813767076200427)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'reload OOO, if necessary'
,p_static_id=>'reload-ooo-if-necessary'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_updated_yn  varchar2(1);',
'begin',
'',
'if :P704_PREVIOUS_FOR_USER_ID is not null then',
'    sp_event_util.load_one_ooo (',
'        p_team_member_id => :P704_PREVIOUS_FOR_USER_ID,',
'        p_updated_yn     => l_updated_yn );',
'end if;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(32615277314575685648)
,p_internal_uid=>33518813767076200427
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(31842515522774726844)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set values'
,p_static_id=>'set-values'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'    select (select event_type from sp_event_types',
'             where id = e.event_type_id) event_type,',
'           event_date,',
'           event_name event_name,',
'           event_details event_details,',
'           (select first_name||'' ''||last_name',
'              from sp_team_members',
'             where id = e.for_user_id) for_user,',
'           series_id',
'      from sp_events e',
'     where id = :P706_EVENT_ID',
') loop',
'    :P706_EVENT_TYPE := c1.event_type;',
'    :P706_EVENT_DATE := to_char(c1.event_date,''Mon fmDD, YYYY'');',
'    :P706_EVENT_NAME := c1.event_name;',
'    :P706_FOR_USER := c1.for_user;',
'    :P706_EVENT_DETAILS := c1.event_details;',
'',
'    for c2 in (',
'        select decode(recur_freq, ''D'', ''Daily'', ''WD'', ''Weekdays'', ''W'', ''Weekly'', ',
'                                  ''2W'', ''Every 2 Weeks'', ''M'', ''Monthly'', recur_freq) recur_freq,',
'               start_date, end_date',
'          from sp_event_series',
'         where id = c1.series_id',
'    ) loop',
'        :P706_REPEATS := c2.recur_freq||'', ''||',
'                         case when to_char(c2.start_date,''MONYYYY'') = to_char(c2.end_date,''MONYYYY'') ',
'                              then to_char(c2.start_date,''Mon fmDD'')||''-''||to_char(c2.end_date,''fmDD, YYYY'')',
'                              when to_char(c2.start_date,''YYYY'') = to_char(c2.end_date,''YYYY'') ',
'                              then to_char(c2.start_date,''Mon fmDD'')||'' until ''||to_char(c2.end_date,''Mon fmDD, YYYY'')',
'                              else to_char(c2.start_date,''Mon fmDD, YYYY'')||'' until ''||to_char(c2.end_date,''Mon fmDD YYYY'')',
'                              end;',
'',
'    end loop;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>31842515522774726844
);
wwv_flow_imp.component_end;
end;
/
