prompt --application/pages/page_00164
begin
--   Manifest
--     PAGE: 00164
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>164
,p_name=>'Releases'
,p_alias=>'RELEASES-IR'
,p_step_title=>'Releases Interactive Report'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(47767547076671364634)
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(41242229044170008235)
,p_protection_level=>'C'
,p_help_text=>'All Releases.  Includes owner, start and end date, whether full release or patch and list of milestones and &NOMENCLATURE_PROJECTS..'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(89322208653129764013)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_sub_css_classes=>'has-header-actions'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(176220395320510839347)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(84703919124081126762)
,p_plug_name=>'Releases Interactive Report'
,p_static_id=>'releases-interactive-report'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton'
,p_plug_template=>2103954283454391425
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.ID release_id,',
'       r.RELEASE_TRAIN,',
'       r.RELEASE,',
'       initcap(nvl(r.release_type,''FULL'')) release_type,',
'       --',
'       -- details',
'       --',
'       r.RELEASE_OPEN_DATE,',
'       r.RELEASE_TARGET_DATE,',
'       case when release_open_completed = ''Y'' and nvl(release_completed,''N'') = ''N'' then',
'           ''Open''',
'           when nvl(release_open_completed,''N'') = ''N'' then',
'           ''Future''',
'           else',
'           ''Closed'' end release_status,',
'       r.RELEASE_TARGET_DATE - r.RELEASE_OPEN_DATE duration_in_days,',
'       case when r.RELEASE_TARGET_DATE >= trunc(sysdate) ',
'            then trunc(r.RELEASE_TARGET_DATE) - trunc(sysdate) ',
'            end days_remaining,',
'       --',
'       -- release owner',
'       --',
'       r.RELEASE_OWNER_ID owner_id,',
'       (select first_Name||'' ''||last_name from sp_team_members tm where tm.id =  r.RELEASE_OWNER_ID) owner_name,',
'       (select email from sp_team_members tm where tm.id =  r.RELEASE_OWNER_ID) owner_email,',
'       --',
'       -- project counts',
'       --',
'       (select count(*) ',
'          from sp_projects p ',
'         where p.release_id = r.id and ',
'               p.ARCHIVED_YN = ''N'' and ',
'               p.duplicate_of_project_id is null) project_count,',
'       --',
'       (select count(*) c ',
'          from sp_projects p ',
'         where p.release_id = r.id and ',
'               p.pct_complete != 100 and ',
'               p.ARCHIVED_YN = ''N'' and ',
'               p.duplicate_of_project_id is null) open_project_count,',
'       --',
'       (select count(*) c ',
'       from sp_projects p ',
'       where p.release_id = r.id and',
'             p.pct_complete = 100 and ',
'             p.ARCHIVED_YN = ''N'' and ',
'             p.duplicate_of_project_id is null) completed_project_count,',
'       --',
'       (select listagg(project, '', '' on overflow truncate with count) within group (order by project)',
'         from sp_projects p,',
'              sp_project_priorities pp',
'        where p.release_id = r.id and',
'              p.ARCHIVED_YN = ''N'' and ',
'              p.priority_id = pp.id and ',
'              pp.priority = 1) p1_projects,',
'       --',
'       (select count(distinct OWNER_ID)',
'          from SP_TASKS c ',
'         where c.PROJECT_ID in (select id ',
'                                  from sp_projects p',
'                                 where p.release_id  = r.id and ',
'                                       p.ARCHIVED_YN = ''N'' and ',
'                                       p.duplicate_of_project_id is null)) project_contributor_count,',
'       --',
'       nvl((select round(avg(p.PCT_COMPLETE))',
'              from sp_projects p ',
'             where p.release_id = r.id and ',
'                   p.ARCHIVED_YN = ''N'' and ',
'                   p.duplicate_of_project_id is null), 0) avg_project_pct_complete,',
'       --',
'       -- last project update',
'       --',
'       (select max(updated) ',
'          from sp_projects p ',
'         where p.release_id = r.id and ',
'               p.ARCHIVED_YN = ''N'' and ',
'               p.duplicate_of_project_id is null) last_project_update,',
'       --',
'       -- milestone counts',
'       --',
'       (select count(*) from SP_RELEASE_MILESTONES m where m.RELEASE_ID = r.id) milestone_count,',
'       (select count(*) from SP_RELEASE_MILESTONES m where m.RELEASE_ID = r.id and m.MILESTONE_COMPLETED_YN = ''Y'') completed_milestone_count,',
'',
'       --',
'       -- audit info',
'       --',
'       r.created created_date,',
'       lower(r.created_by) created_by_app_username,',
'       r.updated last_updated_date,',
'       lower(r.updated_by) last_updated_by_app_username',
'  from SP_RELEASE_TRAINS r'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
,p_prn_page_header=>'Projects Interactive Report'
,p_ai_enabled=>true
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(84703919269987126762)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_save_rpt_public_auth_scheme=>wwv_flow_imp.id(176220694375517839665)
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.:RP,117:P117_RELEASE_ID:#RELEASE_ID#'
,p_detail_link_text=>'<img src="#APEX_FILES#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_internal_uid=>84703919269987126762
,p_ai_search_mode=>'A'
,p_ai_report_hint=>'All Releases.  Includes owner, start and end date, whether full release or patch and list of milestones and projects.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222945358728272910)
,p_db_column_name=>'AVG_PROJECT_PCT_COMPLETE'
,p_display_order=>424
,p_column_identifier=>'CI'
,p_column_label=>'Avg Project Pct Complete'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222945664241272913)
,p_db_column_name=>'COMPLETED_MILESTONE_COUNT'
,p_display_order=>454
,p_column_identifier=>'CL'
,p_column_label=>'Completed Milestone Count'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222945158827272908)
,p_db_column_name=>'COMPLETED_PROJECT_COUNT'
,p_display_order=>404
,p_column_identifier=>'CG'
,p_column_label=>'Completed Project Count'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222945855680272915)
,p_db_column_name=>'CREATED_BY_APP_USERNAME'
,p_display_order=>474
,p_column_identifier=>'CN'
,p_column_label=>'Created By App Username'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222945729096272914)
,p_db_column_name=>'CREATED_DATE'
,p_display_order=>464
,p_column_identifier=>'CM'
,p_column_label=>'Created Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222944563591272902)
,p_db_column_name=>'DAYS_REMAINING'
,p_display_order=>344
,p_column_identifier=>'CA'
,p_column_label=>'Days Remaining'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222944422290272901)
,p_db_column_name=>'DURATION_IN_DAYS'
,p_display_order=>334
,p_column_identifier=>'BZ'
,p_column_label=>'Duration In Days'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222945471628272911)
,p_db_column_name=>'LAST_PROJECT_UPDATE'
,p_display_order=>434
,p_column_identifier=>'CJ'
,p_column_label=>'Last Project Update'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222946093411272917)
,p_db_column_name=>'LAST_UPDATED_BY_APP_USERNAME'
,p_display_order=>494
,p_column_identifier=>'CP'
,p_column_label=>'Last Updated By App Username'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222945920512272916)
,p_db_column_name=>'LAST_UPDATED_DATE'
,p_display_order=>484
,p_column_identifier=>'CO'
,p_column_label=>'Last Updated Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222945533385272912)
,p_db_column_name=>'MILESTONE_COUNT'
,p_display_order=>444
,p_column_identifier=>'CK'
,p_column_label=>'Milestone Count'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222945003950272907)
,p_db_column_name=>'OPEN_PROJECT_COUNT'
,p_display_order=>394
,p_column_identifier=>'CF'
,p_column_label=>'Open Project Count'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222944863487272905)
,p_db_column_name=>'OWNER_EMAIL'
,p_display_order=>374
,p_column_identifier=>'CD'
,p_column_label=>'Owner Email'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222944613649272903)
,p_db_column_name=>'OWNER_ID'
,p_display_order=>354
,p_column_identifier=>'CB'
,p_column_label=>'Owner ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222944747418272904)
,p_db_column_name=>'OWNER_NAME'
,p_display_order=>364
,p_column_identifier=>'CC'
,p_column_label=>'Owner'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222946161332272918)
,p_db_column_name=>'P1_PROJECTS'
,p_display_order=>504
,p_column_identifier=>'CQ'
,p_column_label=>'P1 Projects'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222945225753272909)
,p_db_column_name=>'PROJECT_CONTRIBUTOR_COUNT'
,p_display_order=>414
,p_column_identifier=>'CH'
,p_column_label=>'Project Contributor Count'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222944933832272906)
,p_db_column_name=>'PROJECT_COUNT'
,p_display_order=>384
,p_column_identifier=>'CE'
,p_column_label=>'Project Count'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(84703927802450126800)
,p_db_column_name=>'RELEASE'
,p_display_order=>74
,p_column_identifier=>'T'
,p_column_label=>'Release'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_required_patch=>wwv_flow_imp.id(41242229044170008235)
,p_ai_column_hint=>'Release Number'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38831890520276231249)
,p_db_column_name=>'RELEASE_ID'
,p_display_order=>314
,p_column_identifier=>'BX'
,p_column_label=>'Release ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38831889793864231241)
,p_db_column_name=>'RELEASE_OPEN_DATE'
,p_display_order=>234
,p_column_identifier=>'BP'
,p_column_label=>'Open Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-Mon-YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38831890661951231250)
,p_db_column_name=>'RELEASE_STATUS'
,p_display_order=>324
,p_column_identifier=>'BY'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_ai_column_hint=>'Identifies if Release is Closed (completed), Open or Future (not yet begun)'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38831889660977231240)
,p_db_column_name=>'RELEASE_TARGET_DATE'
,p_display_order=>224
,p_column_identifier=>'BO'
,p_column_label=>'Target Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-Mon-YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38831889489490231238)
,p_db_column_name=>'RELEASE_TRAIN'
,p_display_order=>204
,p_column_identifier=>'BM'
,p_column_label=>'Release Train'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_ai_column_hint=>'Identifies the Product'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38831890471134231248)
,p_db_column_name=>'RELEASE_TYPE'
,p_display_order=>304
,p_column_identifier=>'BW'
,p_column_label=>'Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_ai_column_hint=>'Identifies if Release is a Full or Patch (set) release.'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(84703732242496483711)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'85832204'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'RELEASE_TRAIN:RELEASE:OWNER_NAME:RELEASE_TYPE:RELEASE_STATUS:RELEASE_OPEN_DATE:RELEASE_TARGET_DATE:DURATION_IN_DAYS:DAYS_REMAINING:PROJECT_COUNT:LAST_UPDATED_DATE'
,p_sort_column_1=>'RELEASE_TRAIN'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'RELEASE'
,p_sort_direction_2=>'ASC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8975947183858749324)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(89322208653129764013)
,p_button_name=>'actions'
,p_static_id=>'actions'
,p_show_as_disabled=>false
,p_button_type=>'MENU'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2352535364915922073
,p_button_image_alt=>'Actions'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-ellipsis-v'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(8975947498872749327)
,p_button_id=>wwv_flow_imp.id(8975947183858749324)
,p_menu_entry_type=>'ENTRY'
,p_label=>'About Releases'
,p_static_id=>'about-releases'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:108:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-info'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(8975947211299749325)
,p_button_id=>wwv_flow_imp.id(8975947183858749324)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Releases Primary Report'
,p_static_id=>'releases-primary-report'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-ship'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(8975947548438749328)
,p_button_id=>wwv_flow_imp.id(8975947183858749324)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Reset'
,p_static_id=>'reset'
,p_display_sequence=>40
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:164:&SESSION.::&DEBUG.:RP,CIR,RIR,164::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(8975947350264749326)
,p_button_id=>wwv_flow_imp.id(8975947183858749324)
,p_menu_entry_type=>'SEPARATOR'
,p_static_id=>'sep'
,p_display_sequence=>20
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(39222710563049525999)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(89322208653129764013)
,p_button_name=>'UP'
,p_static_id=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2352535364915922073
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:&LAST_PROJ_JUMP_PG.:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(39222715086655526023)
,p_computation_sequence=>10
,p_computation_item=>'LAST_PROJECT_VIEW'
,p_static_id=>'last-project-view'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'86'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(39222715351379526024)
,p_name=>'refresh on dc'
,p_static_id=>'refresh-on-dc'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(89322208653129764013)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39222715898138526024)
,p_event_id=>wwv_flow_imp.id(39222715351379526024)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(84703919124081126762)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(39222716238023526025)
,p_name=>'refresh on dc from report'
,p_static_id=>'refresh-on-dc-from-report'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(84703919124081126762)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(39222716778570526026)
,p_event_id=>wwv_flow_imp.id(39222716238023526025)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(84703919124081126762)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
