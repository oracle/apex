prompt --application/pages/page_00702
begin
--   Manifest
--     PAGE: 00702
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>702
,p_name=>'Out of the Office Today'
,p_alias=>'OUT-OF-THE-OFFICE-TODAY'
,p_step_title=>'Out of the Office Today'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(31743638170417552010)
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33454071834926241869)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_menu_id=>wwv_flow_imp.id(176220395320510839347)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33454072590132241871)
,p_plug_name=>'Out of the Office Today'
,p_static_id=>'out-of-the-office-today'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2076152157930740558
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.id,',
'       case when e.event_name is not null',
'            then e.event_name',
'            else case when e.for_user_id is not null',
'                      then (select first_name||'' ''||last_name',
'                              from sp_team_members',
'                             where id = e.for_user_id) ',
'                       end',
'            end ||',
'       '' - ''|| t.event_type name,',
'       t.calendar_event_color,',
'       t.icon_class,',
'       case when e.for_user_id is null then 0 else 1 end main_ob',
'  from sp_events e,',
'       sp_event_types t',
' where e.event_type_id = t.id',
'   and cast(e.event_date as date) = :P702_DATE',
' order by main_ob, name'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_no_data_found=>'No events found'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(33454073043541241872)
,p_region_id=>wwv_flow_imp.id(33454072590132241871)
,p_layout_type=>'FLOAT'
,p_title_adv_formatting=>false
,p_title_column_name=>'NAME'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'DYNAMIC_CLASS'
,p_icon_class_column_name=>'ICON_CLASS'
,p_icon_css_classes=>'fa'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18381732308732536645)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(33454071834926241869)
,p_button_name=>'add-event'
,p_static_id=>'add-event'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Event'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:704:&SESSION.::&DEBUG.:704:P704_EVENT_DATE:&P702_DATE.'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(176220694531802839665)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(33518269526830312681)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(33454071834926241869)
,p_button_name=>'UP'
,p_static_id=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2352535364915922073
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:700:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33518814389551200433)
,p_name=>'P702_DATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(33454071834926241869)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35903691249700405443)
,p_name=>'P702_DISPLAY_DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(33454071834926241869)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(35903691393092405444)
,p_computation_sequence=>10
,p_computation_item=>'P702_DATE'
,p_static_id=>'p702-date'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'to_date(:APP_SYSDATE,''DD-MON-YYYY'')'
,p_compute_when=>'NOT_TODAY'
,p_compute_when_type=>'REQUEST_NOT_EQUAL_CONDITION'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(33518814476064200434)
,p_computation_sequence=>20
,p_computation_item=>'P702_DISPLAY_DATE'
,p_static_id=>'p702-display-date'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>''' Today, ''||to_char(to_date(:APP_SYSDATE,''DD-MON-YYYY''),''FMMonth DD, YYYY'')'
,p_compute_when=>'NOT_TODAY'
,p_compute_when_type=>'REQUEST_NOT_EQUAL_CONDITION'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(35903691414493405445)
,p_computation_sequence=>50
,p_computation_item=>'P702_DISPLAY_DATE'
,p_static_id=>'p702-display-date-2'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'to_char(to_date(:P702_DATE,''MM/DD/YYYY''),'', FMMonth DD, YYYY'')'
,p_compute_when=>'NOT_TODAY'
,p_compute_when_type=>'REQUEST_EQUALS_CONDITION'
);
wwv_flow_imp.component_end;
end;
/
