prompt --application/pages/page_00134
begin
--   Manifest
--     PAGE: 00134
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>134
,p_name=>'All Project Approvals'
,p_alias=>'ALL-NOMENCLATURE-PROJECT-APPROVALS'
,p_step_title=>'All &NOMENCLATURE_PROJECT. Approvals'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(45066181379434651735)
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'All Approvals, regardless of status.  Includes &NOMENCLATURE_PROJECT., approval type, status, justification, list of approvers, and submitter.'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(50488177844562728679)
,p_plug_name=>'All Project Approvals'
,p_static_id=>'all-project-approvals'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2103954283454391425
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.id project_id,',
'       i.initiative,',
'       p.project,',
'       t.approval_type,',
'       m.first_name||'' ''||m.last_name submitted_by,',
'       a.submitted,',
'       initcap(replace(a.status,''-'','' '')) status,',
'       case when a.status in (''PENDING'',''CLARIFICATION-REQUESTED'') then ''Active'' else ''Complete'' end state,',
'       a.justification,',
'       case when a.status in (''CLARIFICATION-REQUESTED'',''REJECTED'')',
'            then (select comments from ',
'                         (select comments, created, max(created) over (partition by project_approval_id) last_created',
'                            from sp_project_approval_chain',
'                           where a.id = project_approval_id)',
'                    where last_created = created)',
'            end last_comment,',
'       (select max(updated) from sp_project_approval_chain',
'         where project_approval_id = a.id) last_action,',
'       i.id initiative_id,',
'       (select listagg(t.first_name||'' ''||t.last_name,'', '' on overflow truncate with count)',
'               within group (order by c.last_status_on)',
'         from sp_project_approval_chain c,',
'              sp_team_members t',
'        where c.project_approval_id = a.id',
'          and c.team_member_id = t.id',
'          and c.final_yn = ''Y'') approvers',
'  from sp_project_approvals a,',
'       sp_approval_types t,',
'       sp_team_members m,',
'       sp_projects p,',
'       sp_initiatives i',
' where a.project_id = p.id',
'   and a.approval_type_id = t.id    ',
'   and a.submitted_by_team_member_id = m.id',
'   and p.initiative_id = i.id'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
,p_prn_page_header=>'All &NOMENCLATURE_PROJECT. Approvals'
,p_ai_enabled=>true
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(50488177977480728679)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_internal_uid=>13590359693946819038
,p_ai_search_mode=>'A'
,p_ai_report_hint=>'All Approvals, regardless of status.  Includes Project, approval type, status, justification, list of approvers, and submitter.  There is a default filter to only include those approvals which are active.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50488214652570736442)
,p_db_column_name=>'APPROVAL_TYPE'
,p_display_order=>31
,p_column_identifier=>'M'
,p_column_label=>'Approval Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(51904150305585790748)
,p_db_column_name=>'APPROVERS'
,p_display_order=>141
,p_column_identifier=>'U'
,p_column_label=>'Approvers'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_ai_column_hint=>'List of approvers, if status is Pending, the last approver listed is who it is pending for'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50488217299403736469)
,p_db_column_name=>'INITIATIVE'
,p_display_order=>11
,p_column_identifier=>'P'
,p_column_label=>'Initiative'
,p_column_link=>'f?p=&APP_ID.:94:&SESSION.::&DEBUG.:94:P94_INITIATIVE_ID:#INITIATIVE_ID##ID#'
,p_column_linktext=>'#INITIATIVE#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50488217614469736472)
,p_db_column_name=>'INITIATIVE_ID'
,p_display_order=>121
,p_column_identifier=>'S'
,p_column_label=>'Initiative Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50488180224623728684)
,p_db_column_name=>'JUSTIFICATION'
,p_display_order=>41
,p_column_identifier=>'E'
,p_column_label=>'Justification'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50488214851260736444)
,p_db_column_name=>'LAST_ACTION'
,p_display_order=>81
,p_column_identifier=>'O'
,p_column_label=>'Last Action'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(53716247672292995751)
,p_db_column_name=>'LAST_COMMENT'
,p_display_order=>161
,p_column_identifier=>'W'
,p_column_label=>'Last Comment'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50132385175191598991)
,p_db_column_name=>'PROJECT'
,p_display_order=>21
,p_column_identifier=>'L'
,p_column_label=>'Project'
,p_column_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:3:P3_PROJECT_ID:#PROJECT_ID#'
,p_column_linktext=>'#PROJECT#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50488217777108736473)
,p_db_column_name=>'PROJECT_ID'
,p_display_order=>131
,p_column_identifier=>'T'
,p_column_label=>'Project Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(53086778771961948886)
,p_db_column_name=>'STATE'
,p_display_order=>151
,p_column_identifier=>'V'
,p_column_label=>'State'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50488181463470728686)
,p_db_column_name=>'STATUS'
,p_display_order=>51
,p_column_identifier=>'H'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50488180640304728685)
,p_db_column_name=>'SUBMITTED'
,p_display_order=>61
,p_column_identifier=>'F'
,p_column_label=>'Submitted'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(50488214700478736443)
,p_db_column_name=>'SUBMITTED_BY'
,p_display_order=>71
,p_column_identifier=>'N'
,p_column_label=>'Submitted By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(50488317284281771379)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'135904991'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'INITIATIVE:PROJECT:APPROVAL_TYPE:STATUS:JUSTIFICATION:APPROVERS:LAST_COMMENT:SUBMITTED_BY:SUBMITTED:LAST_ACTION'
,p_sort_column_1=>'LAST_ACTION'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(53947749883006326232)
,p_report_id=>wwv_flow_imp.id(50488317284281771379)
,p_static_id=>'ir-condition'
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'STATE'
,p_operator=>'='
,p_expr=>'Active'
,p_condition_sql=>'"STATE" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Active''  '
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(50488177158395728678)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_menu_id=>wwv_flow_imp.id(176220395320510839347)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(50488352652086779422)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(50488177158395728678)
,p_button_name=>'RESET'
,p_static_id=>'reset'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:134:&SESSION.::&DEBUG.:RR,134,CIR,RIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(50488349335614778447)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(50488177158395728678)
,p_button_name=>'UP'
,p_static_id=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2352535364915922073
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp.component_end;
end;
/
