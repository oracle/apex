prompt --application/pages/page_00176
begin
--   Manifest
--     PAGE: 00176
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>176
,p_name=>'Search Comments'
,p_alias=>'SEARCH-COMMENTS'
,p_page_mode=>'MODAL'
,p_step_title=>'Search Comments'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(45065107974818639665)
,p_step_template=>1664614232864994871
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(83539466019748992874)
,p_name=>' Comments'
,p_static_id=>'comments'
,p_region_name=>'COMMENTS'
,p_template=>2103954283454391425
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Comments--chat:t-Comments--iconsRounded'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'       initials user_icon,',
'       created comment_date,',
'       '''' user_name,',
'       '''' attribute_1,',
'       '''' attribute_2,',
'       '''' attribute_3,',
'       '''' attribute_4,',
'       --',
'       comment_nbr,',
'       body_html comment_text,',
'       decode(private_yn,''Yes'','' Private Comment'',null) private_comment_label,',
'       action actions,',
'       private_yn,',
'       body,',
'       just_project,',
'       author,',
'       ''<a href="''||apex_util.prepare_url (',
'                            p_url => ''f?p=''||:APP_ID||'':176:''||:APP_SESSION||''::NO::P176_SEARCH:''||apex_escape.html(author),',
'                            p_checksum_type => ''3'')||''">''||apex_escape.html(author)||''</a>'' author_link',
'from (',
'select ''Just Project Comments'' just_project,',
'       c.comment_nbr,',
'       c.body_no_images body,',
'       c.body_html,',
'       nvl((select first_name||'' ''||last_name from sp_team_members tm where tm.id = c.author_id),''system'') author,',
'       (select initials from sp_team_members tm where tm.id = c.author_id) initials,',
'       c.CREATED,',
'       to_char(c.created,''YYYY.MM'') created_yyyyMM,',
'       decode(nvl(c.private_yn,''N''),''N'',''No'',''Y'',''Yes'',''Unknown'') private_yn,',
'       case when lower(c.created_by) = lower(:app_user)',
'            then ''<a href="''||apex_util.prepare_url (',
'                            p_url => ''f?p=''||:APP_ID||'':28:''||:APP_SESSION||''::NO:28:P28_ID:''||c.id,',
'                            p_checksum_type => ''3'')||''">edit</a>'' ',
'            end action',
'  from SP_PROJECT_COMMENTS_V c,',
'       sp_projects p,',
'       sp_initiatives i,',
'       sp_areas a ',
' where c.author_id is not null and',
'       p.id = c.project_id and',
'       p.initiative_id = i.id and',
'       i.area_id = a.id and',
'       p.DUPLICATE_OF_PROJECT_ID is null and',
'       p.ARCHIVED_YN = ''N'' and ',
'       (nvl(c.private_yn,''N'') = ''N'' or lower(c.created_by) = lower(:app_user) ) and',
'       p.id = :P176_PROJECT_ID',
'union all',
'select null just_project,',
'       c.comment_nbr,',
'       c.body_no_images body,',
'       c.body_html,',
'       (select first_name||'' ''||last_name from sp_team_members tm where tm.id = c.author_id) author,',
'       (select initials from sp_team_members tm where tm.id = c.author_id) initials,',
'       c.CREATED,',
'       to_char(c.created,''YYYY.MM'') created_yyyyMM,',
'       decode(nvl(c.private_yn,''N''),''N'',''No'',''Y'',''Yes'',''Unknown'') private_yn,',
'       ''<a href="''||apex_util.prepare_url (',
'                            p_url => ''f?p=''||:APP_ID||'':502:''||:APP_SESSION||''::NO:502:P502_PREV_PAGE,P502_PROJECT_ID,P502_TASK_ID:3,''||p.id||'',''||t.id,',
'                            p_checksum_type => ''3'')||''">View ''||',
'           (select apex_escape.html(task_type) from sp_task_types rt where rt.id = t.task_type_id)||',
'           case when t.task_sub_type_id is not null then '': '' end ||',
'           (select apex_escape.html(task_type) from sp_task_types rt where rt.id = t.task_sub_type_id) ||',
'           case when t.task is not null then '' - ''||apex_escape.html(t.task) end ||''</a>'' action',
'  from SP_TASK_COMMENTS_V c,',
'       sp_tasks t,',
'       sp_projects p',
' where c.author_id is not null and',
'       t.id = c.task_id and',
'       t.project_id = p.id and',
'       p.DUPLICATE_OF_PROJECT_ID is null and',
'       p.ARCHIVED_YN = ''N'' and ',
'       (nvl(c.private_yn,''N'') = ''N'' or lower(c.created_by) = lower(:app_user) ) and',
'       p.id = :P176_PROJECT_ID',
') order by comment_date desc'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2616596457966365047
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No Comments'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41403667465161799836)
,p_query_column_id=>11
,p_column_alias=>'ACTIONS'
,p_column_display_sequence=>60
,p_column_heading=>'Actions'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41403664865430799833)
,p_query_column_id=>4
,p_column_alias=>'ATTRIBUTE_1'
,p_column_display_sequence=>40
,p_column_heading=>'Attribute 1'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41403665280717799833)
,p_query_column_id=>5
,p_column_alias=>'ATTRIBUTE_2'
,p_column_display_sequence=>70
,p_column_heading=>'Attribute 2'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41403665782990799834)
,p_query_column_id=>6
,p_column_alias=>'ATTRIBUTE_3'
,p_column_display_sequence=>80
,p_column_heading=>'Attribute 3'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41403666281274799834)
,p_query_column_id=>7
,p_column_alias=>'ATTRIBUTE_4'
,p_column_display_sequence=>90
,p_column_heading=>'Attribute 4'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41403669485088799839)
,p_query_column_id=>15
,p_column_alias=>'AUTHOR'
,p_column_display_sequence=>130
,p_column_heading=>'Author'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41402830997984657115)
,p_query_column_id=>16
,p_column_alias=>'AUTHOR_LINK'
,p_column_display_sequence=>230
,p_column_heading=>'Author Link'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41403671039339799841)
,p_query_column_id=>13
,p_column_alias=>'BODY'
,p_column_display_sequence=>200
,p_column_heading=>'Body'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41403664031552799832)
,p_query_column_id=>2
,p_column_alias=>'COMMENT_DATE'
,p_column_display_sequence=>20
,p_column_heading=>'Comment Date'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41403671494192799842)
,p_query_column_id=>8
,p_column_alias=>'COMMENT_NBR'
,p_column_display_sequence=>210
,p_column_heading=>'Comment Nbr'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41403666637489799835)
,p_query_column_id=>9
,p_column_alias=>'COMMENT_TEXT'
,p_column_display_sequence=>50
,p_column_heading=>'Comment Text'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="is-markdownified">',
'{if PRIVATE_COMMENT_LABEL/}<strong class="u-danger-text">#PRIVATE_COMMENT_LABEL#</strong><br />{endif/}',
'#COMMENT_TEXT#',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41402830779491657113)
,p_query_column_id=>14
,p_column_alias=>'JUST_PROJECT'
,p_column_display_sequence=>220
,p_column_heading=>'Just Project'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41403667007302799836)
,p_query_column_id=>10
,p_column_alias=>'PRIVATE_COMMENT_LABEL'
,p_column_display_sequence=>180
,p_column_heading=>'Private Comment Label'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41403669811661799839)
,p_query_column_id=>12
,p_column_alias=>'PRIVATE_YN'
,p_column_display_sequence=>140
,p_column_heading=>'Private Yn'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41403663697931799831)
,p_query_column_id=>1
,p_column_alias=>'USER_ICON'
,p_column_display_sequence=>10
,p_column_heading=>'User Icon'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(41403664445105799832)
,p_query_column_id=>3
,p_column_alias=>'USER_NAME'
,p_column_display_sequence=>30
,p_column_heading=>'User Name'
,p_column_html_expression=>'Comment #COMMENT_NBR#, #USER_NAME# #AUTHOR_LINK#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(88122329021585582370)
,p_plug_name=>'Facets'
,p_static_id=>'facets'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(83539466019748992874)
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'N',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82309273493156720285)
,p_name=>'P176_JUST_PROJECT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(88122329021585582370)
,p_prompt=>' '
,p_source=>'JUST_PROJECT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from SP_TASK_COMMENTS_V',
' where task_id in (select id from sp_tasks',
'                    where project_id = :P176_PROJECT_ID)'))
,p_display_when_type=>'EXISTS'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>false
,p_fc_collapsible=>false
,p_fc_compute_counts=>false
,p_fc_show_more_count=>1
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_actions_filter=>false
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(88122338597250582387)
,p_name=>'P176_SEARCH'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(88122329021585582370)
,p_prompt=>'Search'
,p_source=>'AUTHOR,BODY'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41402830607519657112)
,p_name=>'P176_PROJECT_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(88122329021585582370)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(41403676663815799850)
,p_name=>'links in comments in new tab'
,p_static_id=>'links-in-comments-in-new-tab'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17534188590425303809)
,p_event_id=>wwv_flow_imp.id(41403676663815799850)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', '$(''#COMMENTS a'').attr(''target'',''_blank'');')).to_clob
);
wwv_flow_imp.component_end;
end;
/
