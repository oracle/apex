prompt --application/pages/page_00202
begin
--   Manifest
--     PAGE: 00202
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>202
,p_name=>'Release Dashboard'
,p_alias=>'RELEASE-DASHBOARD'
,p_step_title=>'Release Dashboard'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.resize-region {',
'  resize: vertical;',
'  overflow: auto;',
'}',
'',
'.project-rds-region {',
'    background-color: rgb(219 204 175 / 20%);',
'}',
'.t-Body-title {',
'    --ut-palette-warning-shade: rgba(var(--oj-palette-neutral-rgb-160));',
'    --ut-component-background-color: rgba(var(--oj-palette-neutral-rgb-170)); ',
'    --ut-alert-horizontal-border-radius: 0;',
'}',
'',
'/* Percent Chart Styles */',
':root {',
'  --a-percent-chart-border-radius: 0.125rem;',
'  --a-percent-chart-bar-border-radius: 0.125rem;',
'  --a-percent-chart-bar-background-color: var(--rw-palette-slate-100);',
'  --ut-report-cell-hover-background-color: rgba(0, 0, 0, 0.025);',
'}',
'',
'/* Report Overrides */',
'.a-IRR-header {',
'  box-shadow: inset 0 -1px 0 var(--a-gv-header-cell-border-color);',
'}',
'',
'.t-Report {',
'  background-color: var(--rw-palette-neutral-0);',
'}',
'',
'.t-Report th {',
'  font-size: .6875rem;',
'}',
'',
'.t-Report th,',
'.t-Report td {',
'  border-inline-width: 0;',
'  transition: none;',
'}',
'',
'/* Group borders */',
'th#PCT_10,',
'td[headers="PCT_10"],',
'th#EFFORT_DAYS,',
'td[headers="EFFORT_DAYS"],',
'th#MOST_RECENT_COMMENT,',
'td[headers="MOST_RECENT_COMMENT"],',
'th#SPECS_COMPLETED,',
'td[headers="SPECS_COMPLETED"],',
'th#P1,',
'td[headers="P1"],',
'th#INCOMPLETE_CNT,',
'td[headers="INCOMPLETE_CNT"] {',
'  border-inline-start-width: 2px;',
'}',
'',
'th#P1,',
'th#P2,',
'th#P3,',
'th#P4,',
'th#P5,',
'[headers="P1"],',
'[headers="P2"],',
'[headers="P3"],',
'[headers="P4"],',
'[headers="P5"] {',
'  background-color: var(--rw-palette-red-10);',
'}',
'',
'tr:hover th#P1,',
'tr:hover th#P2,',
'tr:hover th#P3,',
'tr:hover th#P4,',
'tr:hover th#P5,',
'tr:hover [headers="P1"],',
'tr:hover [headers="P2"],',
'tr:hover [headers="P3"],',
'tr:hover [headers="P4"],',
'tr:hover [headers="P5"] {',
'  background-color: var(--rw-palette-red-20);',
'}',
'',
'th#PCT_0,',
'th#PCT_10,',
'th#PCT_20,',
'th#PCT_30,',
'th#PCT_40,',
'th#PCT_50,',
'th#PCT_60,',
'th#PCT_70,',
'th#PCT_80,',
'th#PCT_90,',
'th#PCT_100,',
'th#PCT_COMPLETE,',
'[headers="PCT_0"],',
'[headers="PCT_10"],',
'[headers="PCT_20"],',
'[headers="PCT_30"],',
'[headers="PCT_40"],',
'[headers="PCT_50"],',
'[headers="PCT_60"],',
'[headers="PCT_70"],',
'[headers="PCT_80"],',
'[headers="PCT_90"],',
'[headers="PCT_100"],',
'[headers="PCT_COMPLETE"] {',
'  background-color: var(--rw-palette-green-10);',
'}',
'',
'tr:hover th#PCT_0,',
'tr:hover th#PCT_10,',
'tr:hover th#PCT_20,',
'tr:hover th#PCT_30,',
'tr:hover th#PCT_40,',
'tr:hover th#PCT_50,',
'tr:hover th#PCT_60,',
'tr:hover th#PCT_70,',
'tr:hover th#PCT_80,',
'tr:hover th#PCT_90,',
'tr:hover th#PCT_100,',
'tr:hover th#PCT_COMPLETE,',
'tr:hover [headers="PCT_0"],',
'tr:hover [headers="PCT_10"],',
'tr:hover [headers="PCT_20"],',
'tr:hover [headers="PCT_30"],',
'tr:hover [headers="PCT_40"],',
'tr:hover [headers="PCT_50"],',
'tr:hover [headers="PCT_60"],',
'tr:hover [headers="PCT_70"],',
'tr:hover [headers="PCT_80"],',
'tr:hover [headers="PCT_90"],',
'tr:hover [headers="PCT_100"],',
'tr:hover [headers="PCT_COMPLETE"] {',
'  background-color: var(--rw-palette-green-20);',
'}',
'',
'th#EFFORT_DAYS,',
'th#DAYS_COMPLETED,',
'th#DAYS_OUTSTANDING,',
'[headers="EFFORT_DAYS"],',
'[headers="DAYS_COMPLETED"],',
'[headers="DAYS_OUTSTANDING"] {',
'  background-color: var(--rw-palette-blue-10);',
'}',
'',
'tr:hover th#EFFORT_DAYS,',
'tr:hover th#DAYS_COMPLETED,',
'tr:hover th#DAYS_OUTSTANDING,',
'tr:hover [headers="EFFORT_DAYS"],',
'tr:hover [headers="DAYS_COMPLETED"],',
'tr:hover [headers="DAYS_OUTSTANDING"] {',
'  background-color: var(--rw-palette-blue-20);',
'}',
'',
'th#MOST_RECENT_COMMENT,',
'[headers="MOST_RECENT_COMMENT"] {',
'  background-color: var(--rw-palette-plum-10);',
'}',
'',
'tr:hover th#MOST_RECENT_COMMENT,',
'tr:hover [headers="MOST_RECENT_COMMENT"] {',
'  background-color: var(--rw-palette-plum-20);',
'}',
'',
'h3:first-of-type { margin-top: 0; }',
'',
'th#INCOMPLETE_CNT,',
'th#TOTAL_CNT,',
'[headers="INCOMPLETE_CNT"],',
'[headers="TOTAL_CNT"] {',
'  background-color: var(--rw-palette-red-10);',
'}',
'',
'tr:hover th#INCOMPLETE_CNT,',
'tr:hover th#TOTAL_CNT,',
'tr:hover [headers="INCOMPLETE_CNT"],',
'tr:hover [headers="TOTAL_CNT"] {',
'  background-color: var(--rw-palette-red-20);',
'}'))
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(41242229044170008235)
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(82809294668688744040)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_sub_css_classes=>'has-header-actions'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(176220395320510839347)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23052858675815072243)
,p_plug_name=>'&NOMENCLATURE_PROJECTS. by Focus Area'
,p_static_id=>'by-focus-area'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(22016579179533845822)
,p_name=>'Reviews'
,p_static_id=>'by-reviewer'
,p_parent_plug_id=>wwv_flow_imp.id(56059296290563148479)
,p_template=>4075786578761660127
,p_display_sequence=>100
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select reviewer_id,',
'       (select tm.first_Name||'' ''||tm.last_name ',
'          from sp_team_members tm',
'         where tm.id = x.reviewer_id) ob,',
'       nvl((select tm.first_Name||'' ''||tm.last_name ',
'              from sp_team_members tm',
'             where tm.id = x.reviewer_id),''Unknown'') reviewer,',
'       listagg(cnt||'' ''||review_type||'' ''||status,'', '') within group (order by t_seq, s_seq, review_type, status) details,',
'       sum(incomplete) incomplete_cnt,',
'       sum(cnt) total_cnt',
'  from',
'(',
'select r.owner_id reviewer_id,',
'       t.task_type review_type,',
'       t.display_seq t_seq,',
'       s.status,',
'       s.display_seq s_seq,',
'       case when s.indicates_complete_yn = ''N'' then 1 else 0 end incomplete,',
'       count(*) cnt',
'  from sp_projects p,',
'       sp_tasks r,',
'       sp_task_types t,',
'       sp_task_statuses s',
' where p.release_id = :P202_RELEASE_ID',
'   and nvl(p.archived_yn,''N'') = ''N''',
'   and p.duplicate_of_project_id is null',
'   and r.project_id = p.id',
'   and nvl(r.task_sub_type_id,r.task_type_id) = t.id',
'   and t.static_id like ''REVIEW%''',
'   and s.id = r.status_id',
' group by r.owner_id, t.task_type, t.display_seq, s.status, s.display_seq, s.indicates_complete_yn',
') x',
' group by reviewer_id'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P202_RELEASE_ID'
,p_lazy_loading=>false
,p_query_row_template=>2542081983073888486
,p_query_num_rows=>150
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No Reviews found'
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_report_total_text_format=>'&nbsp;'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(22016581959496845850)
,p_query_column_id=>4
,p_column_alias=>'DETAILS'
,p_column_display_sequence=>30
,p_column_heading=>'Review Details'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(22474439412360238006)
,p_query_column_id=>5
,p_column_alias=>'INCOMPLETE_CNT'
,p_column_display_sequence=>40
,p_column_heading=>'Incomplete Reviews'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(22474439137122238003)
,p_query_column_id=>2
,p_column_alias=>'OB'
,p_column_display_sequence=>60
,p_default_sort_column_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(22016581896116845849)
,p_query_column_id=>3
,p_column_alias=>'REVIEWER'
,p_column_display_sequence=>20
,p_column_heading=>'Reviewer'
,p_column_css_class=>'nowrap;'
,p_column_link=>'f?p=&APP_ID.:73:&SESSION.::&DEBUG.:73:P73_TEAM_MEMBER_ID:#REVIEWER_ID#'
,p_column_linktext=>'#REVIEWER#'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(22474439295314238004)
,p_query_column_id=>1
,p_column_alias=>'REVIEWER_ID'
,p_column_display_sequence=>70
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(22474438949396238001)
,p_query_column_id=>6
,p_column_alias=>'TOTAL_CNT'
,p_column_display_sequence=>50
,p_column_heading=>'Total Reviews'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(56059296290563148479)
,p_plug_name=>'Grid Reports'
,p_static_id=>'dashboard'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23025236153438424109)
,p_plug_name=>'project count'
,p_static_id=>'fa-by-count'
,p_parent_plug_id=>wwv_flow_imp.id(23052858675815072243)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(23025236265840424110)
,p_region_id=>wwv_flow_imp.id(23025236153438424109)
,p_chart_type=>'bar'
,p_height=>'400'
,p_lazy_loading=>true
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options) {',
'',
'    options.valueFormats.series = {',
'        tooltipLabel: "Priority"',
'    };',
'',
'    options.valueFormats.group = {',
'        tooltipLabel: "Focus Area"',
'    };',
'',
'    options.valueFormats.value.tooltipLabel = "&NOMENCLATURE_PROJECT. Count";',
'',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(23025236304102424111)
,p_chart_id=>wwv_flow_imp.id(23025236265840424110)
,p_static_id=>'data'
,p_seq=>10
,p_name=>'data'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(f.focus_area,''{None Assigned}'') label,',
'       ''P''||r.priority series, ',
'       count(*) value',
'  from sp_projects p,',
'       sp_release_trains t,',
'       sp_project_priorities r,',
'       sp_initiative_focus_areas f',
' where t.id = :P202_RELEASE_ID',
'   and p.release_id = t.id',
'   and nvl(p.archived_yn,''N'') = ''N''',
'   and p.duplicate_of_project_id is null',
'   and p.priority_id = r.id',
'   and p.focus_area_id = f.id (+)',
'group by f.focus_area, r.priority',
'order by f.focus_area nulls last'))
,p_series_type=>'bar'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_group_short_desc_column_name=>'LABEL'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(23025236409133424112)
,p_chart_id=>wwv_flow_imp.id(23025236265840424110)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(23025236552740424113)
,p_chart_id=>wwv_flow_imp.id(23025236265840424110)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'&NOMENCLATURE_PROJECT. Count'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23052858758546072244)
,p_plug_name=>'estimated days'
,p_static_id=>'fa-by-est-days'
,p_parent_plug_id=>wwv_flow_imp.id(23052858675815072243)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_footer=>'Weighted count multiplies each &NOMENCLATURE_PROJECT. by the effort in days associated with its identified size.'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(23052858815622072245)
,p_region_id=>wwv_flow_imp.id(23052858758546072244)
,p_chart_type=>'bar'
,p_height=>'400'
,p_lazy_loading=>true
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options) {',
'',
'    options.valueFormats.series = {',
'        tooltipLabel: "Priority"',
'    };',
'',
'    options.valueFormats.group = {',
'        tooltipLabel: "Focus Area"',
'    };',
'',
'    options.valueFormats.value.tooltipLabel = "Estimated Effort in Days";',
'',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(23052858967202072246)
,p_chart_id=>wwv_flow_imp.id(23052858815622072245)
,p_static_id=>'data'
,p_seq=>10
,p_name=>'data'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select label, series, sum(effort_days) value',
'  from',
'(',
'with min_size as',
'    (select min(effort_days) min_days',
'       from sp_project_sizes',
'      where include_yn = ''Y'')',
'select f.focus_area,',
'       nvl(f.focus_area,''{None Assigned}'') label,',
'       ''P''||r.priority series, ',
'       nvl(s.effort_days,m.min_days) effort_days',
'  from sp_projects p,',
'       sp_release_trains t,',
'       sp_project_priorities r,',
'       sp_initiative_focus_areas f,',
'       sp_project_sizes s,',
'       min_size m',
' where t.id = :P202_RELEASE_ID',
'   and p.release_id = t.id',
'   and nvl(p.archived_yn,''N'') = ''N''',
'   and p.duplicate_of_project_id is null',
'   and p.priority_id = r.id',
'   and p.project_size = s.project_size (+)',
'   and p.focus_area_id = f.id (+)',
')',
'group by focus_area, label, series',
'order by focus_area nulls last'))
,p_series_type=>'bar'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_group_short_desc_column_name=>'LABEL'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(23052859057813072247)
,p_chart_id=>wwv_flow_imp.id(23052858815622072245)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(23052859197122072248)
,p_chart_id=>wwv_flow_imp.id(23052858815622072245)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Estimated Days'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23977946447240757006)
,p_plug_name=>'RDS'
,p_static_id=>'new'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23977946355485757005)
,p_plug_name=>'Pie Charts'
,p_static_id=>'pie-charts'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(58476781160179128712)
,p_name=>'&NOMENCLATURE_PROJECTS. by Owner'
,p_static_id=>'projects-by-owner'
,p_parent_plug_id=>wwv_flow_imp.id(56059296290563148479)
,p_template=>4075786578761660127
,p_display_sequence=>90
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    decode(owner_id,0,''Unknown'',(select first_Name||'' ''||last_name from sp_team_members tm where tm.id = x.owner_id)) project_owner,',
'    nvl((select id from sp_team_members tm where tm.id = x.owner_id),0) team_member_id,',
'    project_count project_count_graph,',
'    project_count,',
'    effort_days,',
'    days_completed,',
'    effort_days - days_completed as days_outstanding,',
'    round(sum_pct_complete / project_count) pct_complete,',
'    100 - round(sum_pct_complete / project_count) pct_outstanding,',
'    --',
'    -- most recent comment',
'    --',
'    (select max(c.created) ',
'       from SP_PROJECT_COMMENTS c, sp_projects p ',
'      where c.project_id = p.id and ',
'            p.ARCHIVED_YN = ''N'' and ',
'            p.DUPLICATE_OF_PROJECT_ID is null and ',
'            p.release_id = :P202_RELEASE_ID and',
'            x.owner_id = p.owner_id) most_recent_comment,',
'    --',
'    -- project distribution by pct complete',
'    --',
'    pct_0, pct_10, pct_20, pct_30, pct_40, pct_50, pct_60, pct_70, pct_80, pct_90, pct_100,',
'    --',
'    -- Priorities',
'    --',
'    p1, p2, p3, p4, p5',
'from (',
'select nvl(p.owner_id,0) owner_id,',
'       count(*) project_count,',
'       sum(effort_days) effort_days,',
'       sum(p.pct_complete * EFFORT_DAYS * .01) days_completed,',
'       sum(p.pct_complete) sum_pct_complete,',
'       --',
'       --',
'       --',
'       sum(decode(p.pct_complete,0,1,0)) pct_0,',
'       sum(decode(p.pct_complete,10,1,0)) pct_10,',
'       sum(decode(p.pct_complete,20,1,0)) pct_20,',
'       sum(decode(p.pct_complete,30,1,0)) pct_30,',
'       sum(decode(p.pct_complete,40,1,0)) pct_40,',
'       sum(decode(p.pct_complete,50,1,0)) pct_50,',
'       sum(decode(p.pct_complete,60,1,0)) pct_60,',
'       sum(decode(p.pct_complete,70,1,0)) pct_70,',
'       sum(decode(p.pct_complete,80,1,0)) pct_80,',
'       sum(decode(p.pct_complete,90,1,0)) pct_90,',
'       sum(decode(p.pct_complete,100,1,0)) pct_100,',
'       --',
'       -- priority distribution',
'       --',
'       sum(decode(pp.PRIORITY,1,1,0)) p1,',
'       sum(decode(pp.PRIORITY,2,1,0)) p2,',
'       sum(decode(pp.PRIORITY,3,1,0)) p3,',
'       sum(decode(pp.PRIORITY,4,1,0)) p4,',
'       sum(decode(pp.PRIORITY,5,1,0)) p5',
'     from sp_projects p, ',
'          SP_PROJECT_SIZES s,',
'          SP_RELEASE_TRAINS r,',
'          SP_PROJECT_PRIORITIES pp',
'     where p.release_id = r.id and ',
'           p.PROJECT_SIZE = s.PROJECT_SIZE and',
'           r.id = :P202_RELEASE_ID and',
'           p.ARCHIVED_YN = ''N'' and',
'           p.DUPLICATE_OF_PROJECT_ID is null and',
'           p.priority_id = pp.id',
'group by  ',
'    nvl(p.owner_id,0)) x',
''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P202_RELEASE_ID'
,p_lazy_loading=>false
,p_query_row_template=>2542081983073888486
,p_query_num_rows=>150
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_report_total_text_format=>'&nbsp;'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361540029158736494)
,p_query_column_id=>6
,p_column_alias=>'DAYS_COMPLETED'
,p_column_display_sequence=>230
,p_column_heading=>'Days Completed'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361540442702736494)
,p_query_column_id=>7
,p_column_alias=>'DAYS_OUTSTANDING'
,p_column_display_sequence=>240
,p_column_heading=>'Days Outstanding'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361538832038736493)
,p_query_column_id=>5
,p_column_alias=>'EFFORT_DAYS'
,p_column_display_sequence=>220
,p_column_heading=>'Budgeted Days of Effort'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361531607619736485)
,p_query_column_id=>10
,p_column_alias=>'MOST_RECENT_COMMENT'
,p_column_display_sequence=>260
,p_column_heading=>'Last Comment'
,p_column_format=>'SINCE_SHORT'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361536437900736490)
,p_query_column_id=>22
,p_column_alias=>'P1'
,p_column_display_sequence=>50
,p_column_heading=>'P1'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361536801167736491)
,p_query_column_id=>23
,p_column_alias=>'P2'
,p_column_display_sequence=>60
,p_column_heading=>'P2'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361537194227736491)
,p_query_column_id=>24
,p_column_alias=>'P3'
,p_column_display_sequence=>70
,p_column_heading=>'P3'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361537626537736491)
,p_query_column_id=>25
,p_column_alias=>'P4'
,p_column_display_sequence=>80
,p_column_heading=>'P4'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361538012207736492)
,p_query_column_id=>26
,p_column_alias=>'P5'
,p_column_display_sequence=>90
,p_column_heading=>'P5'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361532081022736486)
,p_query_column_id=>11
,p_column_alias=>'PCT_0'
,p_column_display_sequence=>100
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361532393493736486)
,p_query_column_id=>12
,p_column_alias=>'PCT_10'
,p_column_display_sequence=>110
,p_column_heading=>'10%'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361535983814736490)
,p_query_column_id=>21
,p_column_alias=>'PCT_100'
,p_column_display_sequence=>200
,p_column_heading=>'100%'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361532841183736486)
,p_query_column_id=>13
,p_column_alias=>'PCT_20'
,p_column_display_sequence=>120
,p_column_heading=>'20%'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361533238784736487)
,p_query_column_id=>14
,p_column_alias=>'PCT_30'
,p_column_display_sequence=>130
,p_column_heading=>'30%'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361533614807736487)
,p_query_column_id=>15
,p_column_alias=>'PCT_40'
,p_column_display_sequence=>140
,p_column_heading=>'40%'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361534080928736488)
,p_query_column_id=>16
,p_column_alias=>'PCT_50'
,p_column_display_sequence=>150
,p_column_heading=>'50%'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361534401949736488)
,p_query_column_id=>17
,p_column_alias=>'PCT_60'
,p_column_display_sequence=>160
,p_column_heading=>'60%'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361534810474736489)
,p_query_column_id=>18
,p_column_alias=>'PCT_70'
,p_column_display_sequence=>170
,p_column_heading=>'70%'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361535246390736489)
,p_query_column_id=>19
,p_column_alias=>'PCT_80'
,p_column_display_sequence=>180
,p_column_heading=>'80%'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361535601063736490)
,p_query_column_id=>20
,p_column_alias=>'PCT_90'
,p_column_display_sequence=>190
,p_column_heading=>'90%'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361540835927736495)
,p_query_column_id=>8
,p_column_alias=>'PCT_COMPLETE'
,p_column_display_sequence=>210
,p_column_heading=>'Complete'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_html_expression=>'#PCT_COMPLETE#%'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361541185610736495)
,p_query_column_id=>9
,p_column_alias=>'PCT_OUTSTANDING'
,p_column_display_sequence=>250
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361539628730736493)
,p_query_column_id=>4
,p_column_alias=>'PROJECT_COUNT'
,p_column_display_sequence=>30
,p_column_heading=>'&NOMENCLATURE_PROJECT. Count'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361541638231736495)
,p_query_column_id=>3
,p_column_alias=>'PROJECT_COUNT_GRAPH'
,p_column_display_sequence=>40
,p_column_heading=>'Count Graph'
,p_column_format=>'PCT_GRAPH:::'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361539245332736493)
,p_query_column_id=>1
,p_column_alias=>'PROJECT_OWNER'
,p_column_display_sequence=>10
,p_column_heading=>'Owner'
,p_column_link=>'f?p=&APP_ID.:73:&SESSION.::&DEBUG.:RP,73:P73_TEAM_MEMBER_ID:#TEAM_MEMBER_ID#'
,p_column_linktext=>'#PROJECT_OWNER#'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361538407331736492)
,p_query_column_id=>2
,p_column_alias=>'TEAM_MEMBER_ID'
,p_column_display_sequence=>330
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64121527078935399681)
,p_plug_name=>'&NOMENCLATURE_PROJECTS. by Percent Complete Chart'
,p_static_id=>'projects-by-percent-complete'
,p_parent_plug_id=>wwv_flow_imp.id(23977946355485757005)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(22206487090611910111)
,p_region_id=>wwv_flow_imp.id(64121527078935399681)
,p_chart_type=>'pie'
,p_lazy_loading=>true
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options) {',
'',
'    options.valueFormats.series = {',
'        tooltipLabel: "Percent Complete"',
'    };',
'',
'    options.valueFormats.value = {',
'        tooltipLabel: "&NOMENCLATURE_PROJECT. Count",',
'        scaling: "none",',
'        converter: {',
'            format: function (value) {',
'                return apex.locale.formatNumber(value, "FM9999999990");',
'            }',
'        }',
'    };',
'',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(22206487573005910112)
,p_chart_id=>wwv_flow_imp.id(22206487090611910111)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Series'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pct_complete||''%'' label, count(*) value',
'  from sp_projects',
' where nvl(archived_yn,''N'') = ''N''',
'   and duplicate_of_project_id is null',
'   and release_id = :P202_RELEASE_ID',
' group by pct_complete'))
,p_max_row_count=>20
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'1'
,p_series_type=>'pie'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(58475790024141696306)
,p_name=>'&NOMENCLATURE_PROJECTS. by Priority'
,p_static_id=>'projects-by-priority'
,p_parent_plug_id=>wwv_flow_imp.id(56059296290563148479)
,p_template=>4075786578761660127
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    ''P''||PRIORITY_ID priority,',
'    project_count,',
'    project_count project_count_chart,',
'    effort_days,',
'    round(sum_pct_complete / project_count) * EFFORT_DAYS * .01 days_completed,',
'    effort_days - round(sum_pct_complete / project_count) * EFFORT_DAYS * .01 as days_outstanding,',
'    round(sum_pct_complete / project_count) pct_complete,',
'    100 - round(sum_pct_complete / project_count) pct_outstanding,',
'    --',
'    -- most recent comment',
'    --',
'    (select max(c.created) ',
'    from SP_PROJECT_COMMENTS c, sp_projects p ',
'    where c.project_id = p.id and ',
'          p.ARCHIVED_YN = ''N'' and ',
'          p.DUPLICATE_OF_PROJECT_ID is null and ',
'          p.release_id = :P202_RELEASE_ID and',
'          p.priority_id = x.PRIORITY_ID',
'    ) most_recent_comment,',
'    pct_0, pct_10, pct_20, pct_30, pct_40, pct_50, pct_60, pct_70, pct_80, pct_90, pct_100',
'--',
'--',
'--',
'from (',
'select p.PRIORITY_ID,',
'       count(*) project_count,',
'       sum(s.effort_days) effort_days,',
'       sum(p.pct_complete) sum_pct_complete,',
'       sum(decode(p.pct_complete,0,1,0)) pct_0,',
'       sum(decode(p.pct_complete,10,1,0)) pct_10,',
'       sum(decode(p.pct_complete,20,1,0)) pct_20,',
'       sum(decode(p.pct_complete,30,1,0)) pct_30,',
'       sum(decode(p.pct_complete,40,1,0)) pct_40,',
'       sum(decode(p.pct_complete,50,1,0)) pct_50,',
'       sum(decode(p.pct_complete,60,1,0)) pct_60,',
'       sum(decode(p.pct_complete,70,1,0)) pct_70,',
'       sum(decode(p.pct_complete,80,1,0)) pct_80,',
'       sum(decode(p.pct_complete,90,1,0)) pct_90,',
'       sum(decode(p.pct_complete,100,1,0)) pct_100',
'     from sp_projects p, ',
'          SP_PROJECT_SIZES s,',
'          SP_RELEASE_TRAINS r',
'     where p.release_id = r.id and ',
'           p.PROJECT_SIZE = s.PROJECT_SIZE and',
'           r.id = :P202_RELEASE_ID and',
'           p.ARCHIVED_YN = ''N'' and',
'           p.DUPLICATE_OF_PROJECT_ID is null',
'group by ',
'    p.PRIORITY_ID) x',
'order by 1'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P202_RELEASE_ID'
,p_lazy_loading=>false
,p_query_row_template=>2542081983073888486
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'SHOW_ALL'
,p_report_total_text_format=>'&nbsp;'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361513792606736464)
,p_query_column_id=>5
,p_column_alias=>'DAYS_COMPLETED'
,p_column_display_sequence=>190
,p_column_heading=>'Days Completed'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361507062769736457)
,p_query_column_id=>6
,p_column_alias=>'DAYS_OUTSTANDING'
,p_column_display_sequence=>200
,p_column_heading=>'Days Outstanding'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361512669749736463)
,p_query_column_id=>4
,p_column_alias=>'EFFORT_DAYS'
,p_column_display_sequence=>180
,p_column_heading=>'Budgeted Days of Effort'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361513025091736464)
,p_query_column_id=>9
,p_column_alias=>'MOST_RECENT_COMMENT'
,p_column_display_sequence=>210
,p_column_heading=>'Last Comment'
,p_column_format=>'SINCE_SHORT'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361511444883736462)
,p_query_column_id=>10
,p_column_alias=>'PCT_0'
,p_column_display_sequence=>50
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361507799406736458)
,p_query_column_id=>11
,p_column_alias=>'PCT_10'
,p_column_display_sequence=>60
,p_column_heading=>'10%'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361511001978736461)
,p_query_column_id=>20
,p_column_alias=>'PCT_100'
,p_column_display_sequence=>150
,p_column_heading=>'100%'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361508213521736458)
,p_query_column_id=>12
,p_column_alias=>'PCT_20'
,p_column_display_sequence=>70
,p_column_heading=>'20%'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361508614191736459)
,p_query_column_id=>13
,p_column_alias=>'PCT_30'
,p_column_display_sequence=>80
,p_column_heading=>'30%'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361506611395736457)
,p_query_column_id=>14
,p_column_alias=>'PCT_40'
,p_column_display_sequence=>90
,p_column_heading=>'40%'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361509001779736459)
,p_query_column_id=>15
,p_column_alias=>'PCT_50'
,p_column_display_sequence=>100
,p_column_heading=>'50%'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361509457607736460)
,p_query_column_id=>16
,p_column_alias=>'PCT_60'
,p_column_display_sequence=>110
,p_column_heading=>'60%'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361509854535736460)
,p_query_column_id=>17
,p_column_alias=>'PCT_70'
,p_column_display_sequence=>120
,p_column_heading=>'70%'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361510280787736460)
,p_query_column_id=>18
,p_column_alias=>'PCT_80'
,p_column_display_sequence=>130
,p_column_heading=>'80%'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361510673698736461)
,p_query_column_id=>19
,p_column_alias=>'PCT_90'
,p_column_display_sequence=>140
,p_column_heading=>'90%'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361514208879736465)
,p_query_column_id=>7
,p_column_alias=>'PCT_COMPLETE'
,p_column_display_sequence=>160
,p_column_heading=>'Complete'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_html_expression=>'#PCT_COMPLETE#%'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361512270088736463)
,p_query_column_id=>8
,p_column_alias=>'PCT_OUTSTANDING'
,p_column_display_sequence=>170
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361506231000736456)
,p_query_column_id=>1
,p_column_alias=>'PRIORITY'
,p_column_display_sequence=>10
,p_column_heading=>'Priority'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361513395695736464)
,p_query_column_id=>2
,p_column_alias=>'PROJECT_COUNT'
,p_column_display_sequence=>30
,p_column_heading=>'Project Count'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361511814109736462)
,p_query_column_id=>3
,p_column_alias=>'PROJECT_COUNT_CHART'
,p_column_display_sequence=>40
,p_column_heading=>'Count Graph'
,p_column_format=>'PCT_GRAPH:::'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(87905335590503730628)
,p_plug_name=>'&NOMENCLATURE_PROJECTS. by Priority Chart'
,p_static_id=>'projects-by-priority-chart'
,p_parent_plug_id=>wwv_flow_imp.id(23977946355485757005)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(22199912739352602677)
,p_region_id=>wwv_flow_imp.id(87905335590503730628)
,p_chart_type=>'donut'
,p_lazy_loading=>true
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_overview_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options) {',
'',
'options.valueFormats.series = {',
'    tooltipLabel: "Priority"',
'};',
'',
'options.valueFormats.value = {',
'    tooltipLabel: "&NOMENCLATURE_PROJECT. Count",',
'    scaling: "none",',
'    converter: {',
'        format: function (value) {',
'            return apex.locale.formatNumber(value, "FM9999999990");',
'        }',
'    }',
'};',
'',
'var total = apex.item("P202_PROJECT_TOTAL").getValue();',
'',
'options.pieCenter = {',
'    renderer: function(context) {',
'',
'        var div = document.createElement("div");',
'',
'        div.innerHTML =',
'            ''<div class="u-bold" style="font-size: 1.5em; line-height: 0.9; text-align: center;">'' +',
'            apex.util.escapeHTML(total) +',
'            ''</div>'' +',
'            ''<div style="font-size: 0.8em; margin-top:2px; line-height: 0.9; text-align: center;">'' +',
'            ''Total'' +',
'            ''</div>'';',
'',
'        /*',
'         * Size and position the content inside the donut hole.',
'         */',
'        div.style.position = "absolute";',
'        div.style.left = context.innerBounds.x + "px";',
'        div.style.top = context.innerBounds.y + "px";',
'        div.style.width = context.innerBounds.width + "px";',
'        div.style.height = context.innerBounds.height + "px";',
'',
'        div.style.display = "flex";',
'        div.style.flexDirection = "column";',
'        div.style.alignItems = "center";',
'        div.style.justifyContent = "center";',
'',
'        div.style.pointerEvents = "none";',
'',
'        return div;',
'    }',
'};',
'',
'return options;',
'',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(22199913214796602678)
,p_chart_id=>wwv_flow_imp.id(22199912739352602677)
,p_static_id=>'series-1'
,p_seq=>10
,p_name=>'Series'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''P''||r.priority label, count(*) value',
'  from sp_projects p,',
'       sp_project_priorities r',
' where p.priority_id = r.id',
'   and nvl(p.archived_yn,''N'') = ''N''',
'   and p.duplicate_of_project_id is null',
'   and p.release_id = :P202_RELEASE_ID',
' group by r.priority'))
,p_max_row_count=>20
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'1'
,p_series_type=>'donut'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_label_rendered=>true
,p_items_label_position=>'center'
,p_items_label_display_as=>'LABEL'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(58476030633996717753)
,p_name=>'&NOMENCLATURE_PROJECTS. by Size'
,p_static_id=>'projects-by-size'
,p_parent_plug_id=>wwv_flow_imp.id(56059296290563148479)
,p_template=>4075786578761660127
,p_display_sequence=>80
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    PROJECT_SIZE,',
'    EFFORT_DAYS,   -- budgeted days of effort',
'    SIZE_DESCRIPTION,',
'    effort_days_per_proj,',
'    project_count,',
'    project_count project_count_pct_graph,',
'    round(sum_pct_complete / project_count) pct_complete,',
'    100 - round(sum_pct_complete / project_count) pct_outstanding,',
'    --',
'    round(((sum_pct_complete / project_count) * EFFORT_DAYS) * .01) days_completed,',
'    EFFORT_DAYS - round(((sum_pct_complete / project_count) * EFFORT_DAYS) * .01) days_outstanding,',
'    --',
'    -- most recent comment',
'    --',
'    (select max(c.created) ',
'    from SP_PROJECT_COMMENTS c, sp_projects p ',
'    where c.project_id = p.id and ',
'          p.ARCHIVED_YN = ''N'' and ',
'          p.DUPLICATE_OF_PROJECT_ID is null and ',
'          p.release_id = :P202_RELEASE_ID and',
'          x.project_size = p.project_size) most_recent_comment,',
'    --',
'    -- project distribution by percent complete',
'    --',
'    pct_0, pct_10, pct_20, pct_30, pct_40, pct_50, pct_60, pct_70, pct_80, pct_90, pct_100,',
'    --',
'    -- project priorities',
'    --',
'    p1, p2, p3, p4, p5',
'--',
'--',
'--',
'from (',
'select s.PROJECT_SIZE,',
'       sum(s.EFFORT_DAYS) effort_days,',
'       s.SIZE_DESCRIPTION,',
'       s.effort_days effort_days_per_proj,',
'       count(*) project_count,',
'       sum(p.pct_complete * EFFORT_DAYS * .01) days_completed,',
'       sum(p.pct_complete) sum_pct_complete,',
'       --',
'       -- percent complete distribution',
'       --',
'       sum(decode(p.pct_complete,0,1,0)) pct_0,',
'       sum(decode(p.pct_complete,10,1,0)) pct_10,',
'       sum(decode(p.pct_complete,20,1,0)) pct_20,',
'       sum(decode(p.pct_complete,30,1,0)) pct_30,',
'       sum(decode(p.pct_complete,40,1,0)) pct_40,',
'       sum(decode(p.pct_complete,50,1,0)) pct_50,',
'       sum(decode(p.pct_complete,60,1,0)) pct_60,',
'       sum(decode(p.pct_complete,70,1,0)) pct_70,',
'       sum(decode(p.pct_complete,80,1,0)) pct_80,',
'       sum(decode(p.pct_complete,90,1,0)) pct_90,',
'       sum(decode(p.pct_complete,100,1,0)) pct_100,',
'       --',
'       -- priority distribution',
'       --',
'       sum(decode(pp.PRIORITY,1,1,0)) p1,',
'       sum(decode(pp.PRIORITY,2,1,0)) p2,',
'       sum(decode(pp.PRIORITY,3,1,0)) p3,',
'       sum(decode(pp.PRIORITY,4,1,0)) p4,',
'       sum(decode(pp.PRIORITY,5,1,0)) p5',
'     from sp_projects p, ',
'          SP_PROJECT_PRIORITIES pp,',
'          SP_PROJECT_SIZES s,',
'          SP_RELEASE_TRAINS r',
'     where p.release_id = r.id and ',
'           p.PRIORITY_ID = pp.id and',
'           p.PROJECT_SIZE = s.PROJECT_SIZE and',
'           r.id = :P202_RELEASE_ID and',
'           p.ARCHIVED_YN = ''N'' and',
'           p.DUPLICATE_OF_PROJECT_ID is null',
'group by ',
'    s.PROJECT_SIZE,',
'    s.SIZE_DESCRIPTION,',
'    s.effort_days) x',
'order by 5 desc'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P202_RELEASE_ID'
,p_lazy_loading=>false
,p_query_row_template=>2542081983073888486
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'SHOW_ALL'
,p_report_total_text_format=>'&nbsp;'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361516895931736468)
,p_query_column_id=>9
,p_column_alias=>'DAYS_COMPLETED'
,p_column_display_sequence=>270
,p_column_heading=>'Days Completed'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361526951658736478)
,p_query_column_id=>10
,p_column_alias=>'DAYS_OUTSTANDING'
,p_column_display_sequence=>280
,p_column_heading=>'Days Outstanding'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361525365016736477)
,p_query_column_id=>2
,p_column_alias=>'EFFORT_DAYS'
,p_column_display_sequence=>260
,p_column_heading=>'Budgeted Days of Effort'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361527309557736479)
,p_query_column_id=>4
,p_column_alias=>'EFFORT_DAYS_PER_PROJ'
,p_column_display_sequence=>40
,p_column_heading=>'Days per &NOMENCLATURE_PROJECT.'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361516552976736468)
,p_query_column_id=>11
,p_column_alias=>'MOST_RECENT_COMMENT'
,p_column_display_sequence=>290
,p_column_heading=>'Last Comment'
,p_column_format=>'SINCE_SHORT'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361522933895736474)
,p_query_column_id=>23
,p_column_alias=>'P1'
,p_column_display_sequence=>80
,p_column_heading=>'P1'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361523313819736474)
,p_query_column_id=>24
,p_column_alias=>'P2'
,p_column_display_sequence=>90
,p_column_heading=>'P2'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361523697129736475)
,p_query_column_id=>25
,p_column_alias=>'P3'
,p_column_display_sequence=>100
,p_column_heading=>'P3'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361524111578736475)
,p_query_column_id=>26
,p_column_alias=>'P4'
,p_column_display_sequence=>110
,p_column_heading=>'P4'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361524521743736476)
,p_query_column_id=>27
,p_column_alias=>'P5'
,p_column_display_sequence=>120
,p_column_heading=>'P5'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361517365471736469)
,p_query_column_id=>12
,p_column_alias=>'PCT_0'
,p_column_display_sequence=>130
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361517742544736469)
,p_query_column_id=>13
,p_column_alias=>'PCT_10'
,p_column_display_sequence=>140
,p_column_heading=>'10%'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361521311382736472)
,p_query_column_id=>22
,p_column_alias=>'PCT_100'
,p_column_display_sequence=>230
,p_column_heading=>'100%'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361518139026736469)
,p_query_column_id=>14
,p_column_alias=>'PCT_20'
,p_column_display_sequence=>150
,p_column_heading=>'20%'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361518580406736470)
,p_query_column_id=>15
,p_column_alias=>'PCT_30'
,p_column_display_sequence=>160
,p_column_heading=>'30%'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361518953763736470)
,p_query_column_id=>16
,p_column_alias=>'PCT_40'
,p_column_display_sequence=>170
,p_column_heading=>'40%'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361519342777736471)
,p_query_column_id=>17
,p_column_alias=>'PCT_50'
,p_column_display_sequence=>180
,p_column_heading=>'50%'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361519744175736471)
,p_query_column_id=>18
,p_column_alias=>'PCT_60'
,p_column_display_sequence=>190
,p_column_heading=>'60%'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361520101401736471)
,p_query_column_id=>19
,p_column_alias=>'PCT_70'
,p_column_display_sequence=>200
,p_column_heading=>'70%'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361520504539736472)
,p_query_column_id=>20
,p_column_alias=>'PCT_80'
,p_column_display_sequence=>210
,p_column_heading=>'80%'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361520980497736472)
,p_query_column_id=>21
,p_column_alias=>'PCT_90'
,p_column_display_sequence=>220
,p_column_heading=>'90%'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361522142415736473)
,p_query_column_id=>7
,p_column_alias=>'PCT_COMPLETE'
,p_column_display_sequence=>240
,p_column_heading=>'Complete'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_html_expression=>'#PCT_COMPLETE#%'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361526575968736478)
,p_query_column_id=>8
,p_column_alias=>'PCT_OUTSTANDING'
,p_column_display_sequence=>250
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361526168166736477)
,p_query_column_id=>5
,p_column_alias=>'PROJECT_COUNT'
,p_column_display_sequence=>60
,p_column_heading=>'&NOMENCLATURE_PROJECT. Count'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361522569913736474)
,p_query_column_id=>6
,p_column_alias=>'PROJECT_COUNT_PCT_GRAPH'
,p_column_display_sequence=>70
,p_column_heading=>'Count Graph'
,p_column_format=>'PCT_GRAPH:::'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361524903897736476)
,p_query_column_id=>1
,p_column_alias=>'PROJECT_SIZE'
,p_column_display_sequence=>10
,p_column_heading=>'Size'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51361525757414736477)
,p_query_column_id=>3
,p_column_alias=>'SIZE_DESCRIPTION'
,p_column_display_sequence=>30
,p_column_heading=>'Description'
,p_heading_alignment=>'LEFT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(103058269477720789763)
,p_name=>'Release'
,p_static_id=>'release'
,p_template=>4075786578761660127
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:t-Region--scrollBody:t-Region-orderBy--end:margin-left-md'
,p_component_template_options=>'#DEFAULT#:t-ContextualInfo-label--stacked'
,p_display_point=>'REGION_POSITION_01'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.ID,',
'       r.RELEASE_TRAIN||'' ''||r.RELEASE release,',
'       decode(r.RELEASE_TARGET_DATE,null,    ''No Date'',to_char(r.RELEASE_TARGET_DATE,   ''DD-MON-YY'')) RELEASE_TARGET_DATE,',
'       decode(r.RELEASE_OPEN_DATE,null,      ''No Date'',to_char(r.RELEASE_OPEN_DATE,     ''DD-MON-YY'')) RELEASE_OPEN_DATE,',
'       greatest(round(r.RELEASE_TARGET_DATE - sysdate),0) days_remaining,',
'       --',
'       -- projects',
'       --',
'       (select count(*) ',
'          from sp_projects p ',
'         where p.release_id = r.id and ',
'               p.ARCHIVED_YN = ''N'' and ',
'               p.DUPLICATE_OF_PROJECT_ID is null) projects,',
'       --',
'       --',
'       --',
'       round(r.RELEASE_TARGET_DATE - r.RELEASE_OPEN_DATE) release_length,',
'       --',
'       -- owner',
'       --',
'       t.first_name||'' ''||t.last_name owner,',
'       --',
'       -- release open and close',
'       --',
'       decode(r.RELEASE_OPEN_COMPLETED,''Y'',''Yes'',''N'',''No'',''Unknown'') release_opened,',
'       decode(r.RELEASE_COMPLETED,''Y'',''Yes'',''N'',''No'',''Unknown'') release_completed',
'  from SP_RELEASE_TRAINS r,',
'       SP_TEAM_MEMBERS t',
' where r.id = :P202_RELEASE_ID and ',
'       r.RELEASE_OWNER_ID = t.id(+)'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2119200326351924400
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'SHOW_ALL'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51360813977199595743)
,p_query_column_id=>5
,p_column_alias=>'DAYS_REMAINING'
,p_column_display_sequence=>90
,p_column_heading=>'Remaining'
,p_column_format=>'99999'
,p_column_html_expression=>'#DAYS_REMAINING# days'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51360813169731595742)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51360814298030595743)
,p_query_column_id=>8
,p_column_alias=>'OWNER'
,p_column_display_sequence=>150
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51360811914781595740)
,p_query_column_id=>6
,p_column_alias=>'PROJECTS'
,p_column_display_sequence=>100
,p_column_heading=>'&NOMENCLATURE_PROJECTS.'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51360813548818595742)
,p_query_column_id=>2
,p_column_alias=>'RELEASE'
,p_column_display_sequence=>40
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51360809926006595736)
,p_query_column_id=>10
,p_column_alias=>'RELEASE_COMPLETED'
,p_column_display_sequence=>170
,p_column_heading=>'Release Completed'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51360812295107595740)
,p_query_column_id=>7
,p_column_alias=>'RELEASE_LENGTH'
,p_column_display_sequence=>80
,p_column_heading=>'Length'
,p_column_html_expression=>'#RELEASE_LENGTH# days'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51360815175698595745)
,p_query_column_id=>9
,p_column_alias=>'RELEASE_OPENED'
,p_column_display_sequence=>180
,p_column_heading=>'Release Opened'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51360811549784595739)
,p_query_column_id=>4
,p_column_alias=>'RELEASE_OPEN_DATE'
,p_column_display_sequence=>60
,p_column_heading=>'Open'
,p_column_format=>'DD-MON-YY'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(51360810771034595738)
,p_query_column_id=>3
,p_column_alias=>'RELEASE_TARGET_DATE'
,p_column_display_sequence=>70
,p_column_heading=>'Target Complete'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44223054144470754289)
,p_plug_name=>'&NOMENCLATURE_PROJECT. Target Complete'
,p_static_id=>'target-complete-by'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_footer=>'* indicates target dates outside the identified release window'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44392173716724047139)
,p_plug_name=>'Target Complete by Month'
,p_static_id=>'target-complete-by-month'
,p_parent_plug_id=>wwv_flow_imp.id(44223054144470754289)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(22206479814127908488)
,p_region_id=>wwv_flow_imp.id(44392173716724047139)
,p_chart_type=>'bar'
,p_height=>'400'
,p_lazy_loading=>true
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options) {',
'',
'    options.valueFormats.series = {',
'        tooltipLabel: "Priority"',
'    };',
'',
'    options.valueFormats.group = {',
'        tooltipLabel: "Close Month"',
'    };',
'',
'    options.valueFormats.value.tooltipLabel = "&NOMENCLATURE_PROJECT. Count";',
'',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(22206481579667908490)
,p_chart_id=>wwv_flow_imp.id(22206479814127908488)
,p_static_id=>'data'
,p_seq=>10
,p_name=>'data'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(to_char(close_month,''YYYY-MM''),''No Date'')||flag label, ',
'--       nvl(to_char(close_month,''Mon YYYY''),''No Date Given'') label, ',
'       priority series, ',
'       sum(cnt) value',
'  from',
'(',
'select trunc(p.target_complete,''MM'') close_month, ',
'       case when p.target_complete < nvl(t.release_open_date,p.target_complete) or',
'                 p.target_complete > nvl(t.release_target_date,p.target_complete)',
'            then '' *''',
'            end flag,',
'       ''P''||r.priority priority, 1 cnt',
'  from sp_projects p,',
'       sp_release_trains t,',
'       sp_project_priorities r',
' where t.id = :P202_RELEASE_ID',
'   and p.release_id = t.id',
'   and p.priority_id = r.id',
'   and nvl(p.archived_yn,''N'') = ''N''',
'   and p.duplicate_of_project_id is null',
'union all',
'select add_months(trunc(r.release_open_date,''MM''),d.i-1) close_month, ',
'       null flag,',
'       ''P1'' priority, 0 cnt',
'  from sp_release_trains r,',
'       wwv_flow_dual100 d',
' where r.id = :P202_RELEASE_ID',
'   and d.i <= ceil(months_between(r.release_target_date,r.release_open_date)) --+ 1',
')',
'group by close_month, priority, flag',
'order by 1, 2'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'LABEL ASC, SERIES'
,p_series_type=>'bar'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_group_short_desc_column_name=>'LABEL'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(22206480369694908488)
,p_chart_id=>wwv_flow_imp.id(22206479814127908488)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(22206480980106908489)
,p_chart_id=>wwv_flow_imp.id(22206479814127908488)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44223053416431754282)
,p_plug_name=>'Target Complete by Week'
,p_static_id=>'target-complete-by-week'
,p_parent_plug_id=>wwv_flow_imp.id(44223054144470754289)
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--noUI:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(22206477162585908483)
,p_region_id=>wwv_flow_imp.id(44223053416431754282)
,p_chart_type=>'bar'
,p_height=>'400'
,p_lazy_loading=>true
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'on'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options) {',
'',
'    options.valueFormats.series = {',
'        tooltipLabel: "Priority"',
'    };',
'',
'    options.valueFormats.group = {',
'        tooltipLabel: "Close Week"',
'    };',
'',
'    options.valueFormats.value.tooltipLabel = "&NOMENCLATURE_PROJECT. Count";',
'',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(22206478811809908485)
,p_chart_id=>wwv_flow_imp.id(22206477162585908483)
,p_static_id=>'data'
,p_seq=>10
,p_name=>'data'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(to_char(close_week,''YYYY MM-DD''),''No Date'')||flag label,',
'--       nvl(to_char(close_week,''Mon DD, YYYY''),''No Date Given'') label, ',
'       priority series, sum(cnt) value',
'  from',
'(',
'select trunc(p.target_complete,''IW'') close_week, ',
'       case when p.target_complete < nvl(r.release_open_date,p.target_complete) or',
'                 p.target_complete > nvl(r.release_target_date,p.target_complete)',
'            then '' *''',
'            end flag,',
'       ''P''||pp.priority priority, 1 cnt',
'  from sp_projects p,',
'       sp_project_priorities pp,',
'       sp_release_trains r',
' where p.priority_id = pp.id',
'   and nvl(p.archived_yn,''N'') = ''N''',
'   and p.duplicate_of_project_id is null',
'   and p.release_id = r.id  ',
'   and r.id = :P202_RELEASE_ID',
'union all',
'select add_months(trunc(r.release_open_date,''MM''),d.i-1) close_month, ',
'       null flag, ',
'       ''P1'' priority, 0 cnt',
'  from sp_release_trains r,',
'       wwv_flow_dual100 d',
' where r.id = :P202_RELEASE_ID',
'   and d.i <= ceil(months_between(r.release_target_date,r.release_open_date)) --+ 1',
')',
'group by close_week, priority, flag',
'order by 1'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'LABEL ASC, SERIES'
,p_series_type=>'bar'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(22206477641852908484)
,p_chart_id=>wwv_flow_imp.id(22206477162585908483)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(22206478292047908485)
,p_chart_id=>wwv_flow_imp.id(22206477162585908483)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6740715073542193836)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(82809294668688744040)
,p_button_name=>'actions'
,p_static_id=>'actions'
,p_show_as_disabled=>false
,p_button_type=>'MENU'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2352535364915922073
,p_button_image_alt=>'Actions'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-ellipsis-v'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(6740715616507193842)
,p_button_id=>wwv_flow_imp.id(6740715073542193836)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Refresh'
,p_static_id=>'refresh'
,p_display_sequence=>60
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(6740715303732193839)
,p_button_id=>wwv_flow_imp.id(6740715073542193836)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Release Calendar'
,p_static_id=>'release-calendar'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:203:&SESSION.::&DEBUG.:RP,203:P203_RELEASE_ID:&P202_RELEASE_ID.'
,p_icon_css_classes=>'fa-calendar-o'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(6740715125671193837)
,p_button_id=>wwv_flow_imp.id(6740715073542193836)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Release Home'
,p_static_id=>'release-home'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.:RP,:P117_RELEASE_ID:&P202_RELEASE_ID.'
,p_icon_css_classes=>'fa-ship'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(6740715774760193843)
,p_button_id=>wwv_flow_imp.id(6740715073542193836)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Reset'
,p_static_id=>'reset'
,p_display_sequence=>70
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.:RR,202:P202_RELEASE_ID:&P202_RELEASE_ID.'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(6740715217090193838)
,p_button_id=>wwv_flow_imp.id(6740715073542193836)
,p_menu_entry_type=>'SEPARATOR'
,p_static_id=>'sep1'
,p_display_sequence=>20
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(6740715526452193841)
,p_button_id=>wwv_flow_imp.id(6740715073542193836)
,p_menu_entry_type=>'SEPARATOR'
,p_static_id=>'sep2'
,p_display_sequence=>50
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(6740715429134193840)
,p_button_id=>wwv_flow_imp.id(6740715073542193836)
,p_menu_entry_type=>'ENTRY'
,p_label=>'View History'
,p_static_id=>'view-history'
,p_display_sequence=>40
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.:RP,14:P14_RELEASE_ID:&P202_RELEASE_ID.'
,p_icon_css_classes=>'fa-clock-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(51360780083426589373)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(82809294668688744040)
,p_button_name=>'UP'
,p_static_id=>'up'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2352535364915922073
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.:RP,117:P117_RELEASE_ID:&P202_RELEASE_ID.'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23052859257634072249)
,p_name=>'P202_FOCUS_AREA_BY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(23052858675815072243)
,p_item_default=>'P'
,p_prompt=>'Show By'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:&NOMENCLATURE_PROJECT. Count;P,Estimated Days;E'
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(22016579072091845821)
,p_name=>'P202_PROJECT_TOTAL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(103058269477720789763)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(count(*),''999G999G999G999G999G999G990'') cnt',
'  from sp_projects',
' where nvl(archived_yn,''N'') = ''N''',
'   and duplicate_of_project_id is null',
'   and release_id = :P202_RELEASE_ID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65822351482756133133)
,p_name=>'P202_RELEASE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(103058269477720789763)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64843467519560994476)
,p_name=>'P202_RELEASE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(103058269477720789763)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_restricted_characters=>'US_ONLY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44223054314303754290)
,p_name=>'P202_TARGET_COMPLETE_BY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(44223054144470754289)
,p_item_default=>'M'
,p_prompt=>'Show By'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Month;M,Week;W'
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(51363333500357761595)
,p_computation_sequence=>30
,p_computation_item=>'P202_RELEASE'
,p_static_id=>'p202-release'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>'select release_train||'' ''||release d from sp_release_trains where id = :P202_RELEASE_ID'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(23052859379801072250)
,p_name=>'when change focus area'
,p_static_id=>'when-change-focus-area'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P202_FOCUS_AREA_BY'
,p_condition_element=>'P202_FOCUS_AREA_BY'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'P'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23977946107231757003)
,p_event_id=>wwv_flow_imp.id(23052859379801072250)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(23052858758546072244)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23977946222300757004)
,p_event_id=>wwv_flow_imp.id(23052859379801072250)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide_1'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(23025236153438424109)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23977945953881757001)
,p_event_id=>wwv_flow_imp.id(23052859379801072250)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(23025236153438424109)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23977946049330757002)
,p_event_id=>wwv_flow_imp.id(23052859379801072250)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show_1'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(23052858758546072244)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(22016578538191845816)
,p_name=>'when change merge by'
,p_static_id=>'when-change-merge-by'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P202_TARGET_COMPLETE_BY'
,p_condition_element=>'P202_TARGET_COMPLETE_BY'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'M'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22016578736731845818)
,p_event_id=>wwv_flow_imp.id(22016578538191845816)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(44223053416431754282)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22016578885961845819)
,p_event_id=>wwv_flow_imp.id(22016578538191845816)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide_1'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(44392173716724047139)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22016578694677845817)
,p_event_id=>wwv_flow_imp.id(22016578538191845816)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(44392173716724047139)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22016578985536845820)
,p_event_id=>wwv_flow_imp.id(22016578538191845816)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show_1'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(44223053416431754282)
);
wwv_flow_imp.component_end;
end;
/
