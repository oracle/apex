prompt --application/pages/page_00123
begin
--   Manifest
--     PAGE: 00123
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>123
,p_name=>'&NOMENCLATURE_PROJECT. Markdown'
,p_alias=>'PROJECT-MARKDOWN'
,p_page_mode=>'MODAL'
,p_step_title=>'&NOMENCLATURE_PROJECT. Markdown'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>1664614232864994871
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54376550012815635134)
,p_plug_name=>'buttons'
,p_static_id=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2129856781885180476
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(23977947514491757017)
,p_plug_name=>'Display Markdown'
,p_static_id=>'display-markdown'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>'sys.htp.p(apex_markdown.to_html(:P123_PROJECT_MD));'
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>':P123_PROJECT_MD'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54374133602422622162)
,p_plug_name=>'hidden items'
,p_static_id=>'hidden-items'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_translate_title=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(23977947676238757018)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(54376550012815635134)
,p_button_name=>'copy'
,p_static_id=>'copy'
,p_show_as_disabled=>false
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_image_alt=>'Copy'
,p_button_position=>'NEXT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P123_PROJECT_MD'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(23977946878250757010)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(54376550012815635134)
,p_button_name=>'download'
,p_static_id=>'download'
,p_show_as_disabled=>false
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Download'
,p_button_position=>'NEXT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P123_PROJECT_MD'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(53362036391148704689)
,p_name=>'P123_PROJECT_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(54374133602422622162)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(23977946674686757008)
,p_name=>'P123_PROJECT_MD'
,p_data_type=>'CLOB'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(54374133602422622162)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(23977947776813757019)
,p_name=>'copy markdown'
,p_static_id=>'copy-markdown'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(23977947676238757018)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23977947830115757020)
,p_event_id=>wwv_flow_imp.id(23977947776813757019)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    '(async () => {',
    '    const value = apex.item("P123_PROJECT_MD").getValue();',
    '',
    '    try {',
    '        if (navigator.clipboard && window.isSecureContext) {',
    '            await navigator.clipboard.writeText(value);',
    '        } else {',
    '            const textarea = document.createElement("textarea");',
    '            textarea.value = value;',
    '            textarea.style.position = "fixed";',
    '            textarea.style.opacity = "0";',
    '            document.body.appendChild(textarea);',
    '            textarea.select();',
    '',
    '            if (!document.execCommand("copy")) {',
    '                throw new Error("Copy failed");',
    '            }',
    '',
    '            textarea.remove();',
    '        }',
    '',
    '        apex.message.showPageSuccess("Copied to clipboard.");',
    '    } catch (error) {',
    '        apex.message.alert("Unable to copy the item value.");',
    '    }',
    '})();')))).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(23977946942882757011)
,p_name=>'download'
,p_static_id=>'download'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(23977946878250757010)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23977947053054757012)
,p_event_id=>wwv_flow_imp.id(23977946942882757011)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'const text = apex.item("P123_PROJECT_MD").getValue() || "";',
    '',
    'const blob = new Blob([text], {',
    '  type: "text/plain;charset=utf-8"',
    '});',
    '',
    'const url = URL.createObjectURL(blob);',
    'const link = document.createElement("a");',
    '',
    'link.href = url;',
    'link.download = "markdown.txt";',
    'document.body.appendChild(link);',
    'link.click();',
    'link.remove();',
    '',
    'setTimeout(() => URL.revokeObjectURL(url), 1000);')))).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(26246334088160998143)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'create markdown'
,p_static_id=>'full-summary'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P123_PROJECT_MD := sp_summary_util.generate_project_high_level (p_project_id => :P123_PROJECT_ID );',
''))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P123_PROJECT_ID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>26246334088160998143
);
wwv_flow_imp.component_end;
end;
/
