prompt --application/pages/page_00710
begin
--   Manifest
--     PAGE: 00710
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>710
,p_name=>'Out of Office Events'
,p_alias=>'OOO-EVENTS'
,p_step_title=>'Out of Office Events'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(47767547076671364634)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.no-item-ui {',
'    --a-field-input-border-width: 0;',
'    --a-field-input-background-color: transparent;',
'}',
'.overline {',
'  color: var(--ut-region-text-color,var(--ut-component-text-default-color));',
'}',
'',
'.a-FS-facetsDashboard {--a-fs-chart-grid-gap: 0;',
'       --a-fs-chart-border-width: 0;',
'       --a-fs-chart-shadow: none;',
'}',
''))
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(31743638170417552010)
,p_protection_level=>'C'
,p_help_text=>'All Events that can affect Team Member availability.  There is a default filter on the report to only include events for today and the future.'
,p_page_comment=>'Events include a type (e.g. Public Holiday, Personal Time Off), the name of the event, if relevant and the repeat frequency (e.g. Repeats Daily, Jan 27-30).'
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(94112651860227983251)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_menu_id=>wwv_flow_imp.id(176220395320510839347)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(94112652494232983253)
,p_plug_name=>'Search Results'
,p_static_id=>'search-results'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2103954283454391425
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.id event_id,',
'       t.event_type, ',
'       e.event_date, e.event_name,',
'       case when s.recur_freq is not null',
'            then ''Repeats ''||decode(s.recur_freq, ''D'', ''Daily'', ''WD'', ''Weekdays'', ''W'', ''Weekly'', ',
'                                            ''2W'', ''Every 2 Weeks'', ''M'', ''Montly'', s.recur_freq)||'', ''||',
'            case when to_char(s.start_date,''MONYYYY'') = to_char(s.end_date,''MONYYYY'') ',
'                 then to_char(s.start_date,''Mon fmDD'')||''-''||to_char(s.end_date,''fmDD'')',
'                    when to_char(s.start_date,''YYYY'') = to_char(s.end_date,''YYYY'') ',
'                 then to_char(s.start_date,''Mon fmDD'')||'' until ''||to_char(s.end_date,''Mon fmDD'')',
'                    else to_char(s.start_date,''Mon fmDD YYYY'')||'' until ''||to_char(s.end_date,''Mon fmDD YYYY'')',
'                    end',
'            end recur_frequency,',
'       case when e.for_user_id is not null',
'            then (select first_name||'' ''||last_name',
'                    from sp_team_members',
'                   where id = e.for_user_id) ',
'            end for_user,',
'       e.event_details,',
'       lower(e.created_by) created_by,',
'       e.created,',
'       lower(e.updated_by) updated_by,',
'       e.updated,',
'       case when e.for_user_id is not null',
'            then apex_page.get_url(',
'                     p_page => 73, ',
'                     p_items  => ''P73_TEAM_MEMBER_ID'',',
'                     p_values => e.for_user_id )',
'            else null',
'            end view_link',
'  from sp_events e,',
'       sp_event_types t,',
'       sp_event_series s',
' where e.event_type_id = t.id',
'   and e.series_id = s.id (+)'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>true
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(55979024624030384436)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:704:&SESSION.::&DEBUG.:704,705,706:P704_ID:#EVENT_ID#'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_detail_link_auth_scheme=>wwv_flow_imp.id(176220694531802839665)
,p_internal_uid=>55979024624030384436
,p_ai_search_mode=>'A'
,p_ai_report_hint=>'All Events that can affect Team Member availability.  There is a default filter on the report to only include events for today and the future.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31820571356458549702)
,p_db_column_name=>'CREATED'
,p_display_order=>220
,p_column_identifier=>'AK'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31820571266753549701)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>210
,p_column_identifier=>'AJ'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(30942740492387078745)
,p_db_column_name=>'EVENT_DATE'
,p_display_order=>150
,p_column_identifier=>'AD'
,p_column_label=>'Event Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-Mon-YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(30942740913036078750)
,p_db_column_name=>'EVENT_DETAILS'
,p_display_order=>200
,p_column_identifier=>'AI'
,p_column_label=>'Event Details'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31842514690801726835)
,p_db_column_name=>'EVENT_ID'
,p_display_order=>250
,p_column_identifier=>'AO'
,p_column_label=>'Event Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(30942740575444078746)
,p_db_column_name=>'EVENT_NAME'
,p_display_order=>170
,p_column_identifier=>'AE'
,p_column_label=>'Event Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(30942740359140078744)
,p_db_column_name=>'EVENT_TYPE'
,p_display_order=>140
,p_column_identifier=>'AC'
,p_column_label=>'Event Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31842511658506726805)
,p_db_column_name=>'FOR_USER'
,p_display_order=>190
,p_column_identifier=>'AM'
,p_column_label=>'For User'
,p_column_link=>'#VIEW_LINK#'
,p_column_linktext=>'#FOR_USER#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31842511734673726806)
,p_db_column_name=>'RECUR_FREQUENCY'
,p_display_order=>180
,p_column_identifier=>'AN'
,p_column_label=>'Repeat Frequency'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55979025789564384448)
,p_db_column_name=>'UPDATED'
,p_display_order=>240
,p_column_identifier=>'L'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(31820571496358549703)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>230
,p_column_identifier=>'AL'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(33518811840921200408)
,p_db_column_name=>'VIEW_LINK'
,p_display_order=>260
,p_column_identifier=>'AP'
,p_column_label=>'View Link'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(56000543712336790152)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'241804837'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'EVENT_TYPE:FOR_USER:EVENT_DATE:EVENT_NAME:RECUR_FREQUENCY:CREATED'
,p_sort_column_1=>'EVENT_DATE'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'NAME'
,p_sort_direction_2=>'ASC'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(31843527685993859067)
,p_report_id=>wwv_flow_imp.id(56000543712336790152)
,p_static_id=>'ir-condition'
,p_name=>'today forward'
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_expr_type=>'ROW'
,p_expr=>'AD >= trunc(sysdate)'
,p_condition_sql=>'"EVENT_DATE" >= TRUNC ( SYSDATE )'
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105141512101243874655)
,p_plug_name=>'user timezone'
,p_static_id=>'user-timezone'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'    select nvl(timezone,''UTC'') user_timezone',
'      from sp_team_members',
'     where id = :APP_USER_ID',
') loop',
'    sys.htp.p(''Your timezone is ''||apex_escape.html(c1.user_timezone)||''. This is set under your profile.'');',
'end loop;',
'',
'return null;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(31820060965366353212)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(94112651860227983251)
,p_button_name=>'RESET'
,p_static_id=>'reset'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:710:&SESSION.::&DEBUG.:RR,710,CIR,RIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(31820061320525353213)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(94112651860227983251)
,p_button_name=>'UP'
,p_static_id=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2352535364915922073
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(31842511214826726801)
,p_name=>'create closed'
,p_static_id=>'create-closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(94112651860227983251)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31842511374743726802)
,p_event_id=>wwv_flow_imp.id(31842511214826726801)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(94112652494232983253)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(31842511473086726803)
,p_name=>'update closed'
,p_static_id=>'update-closed'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(94112652494232983253)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31842511579187726804)
,p_event_id=>wwv_flow_imp.id(31842511473086726803)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(94112652494232983253)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
