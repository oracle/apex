prompt --application/pages/page_00160
begin
--   Manifest
--     PAGE: 00160
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>160
,p_name=>'Team Member Photo'
,p_alias=>'TEAM-MEMBER-PHOTO'
,p_step_title=>'Team Member Photo'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38593520046415791837)
,p_plug_name=>'for id'
,p_static_id=>'for-id'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38593520148120791838)
,p_name=>'P160_TM_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(38593520046415791837)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38593520213831791839)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'get photo'
,p_static_id=>'get-photo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_file           blob;',
'    l_content_type   varchar2( 4000 );',
'    l_filename       varchar2( 4000 );',
'BEGIN',
'',
'    SELECT photo,',
'           nvl(photo_mimetype,''image/png'') photo_mimtype,',
'           nvl(photo_filename,''profile.png'') photo_filename',
'      INTO l_file,',
'           l_content_type,',
'           l_filename',
'      FROM sp_team_members',
'     WHERE id = :P160_TM_ID;',
'',
'    apex_http.download(',
'        p_blob           => l_file,',
'        p_content_type   => l_content_type,',
'        p_filename       => l_filename );',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>38593520213831791839
);
wwv_flow_imp.component_end;
end;
/
