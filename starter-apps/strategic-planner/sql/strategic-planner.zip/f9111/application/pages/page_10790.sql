prompt --application/pages/page_10790
begin
--   Manifest
--     PAGE: 10790
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10790
,p_name=>'Team Member Notifications'
,p_alias=>'TEAM-MEMBER-NOTIFICATIONS'
,p_step_title=>'Team Member Notifications'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4075783602716660119
,p_page_css_classes=>'rw-pillar--sienna'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(176220694375517839665)
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18062403425221832044)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_menu_id=>wwv_flow_imp.id(176220395320510839347)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18062404147577832046)
,p_plug_name=>'Team Member Notifications'
,p_static_id=>'team-member-notifications'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2103954283454391425
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       TEAM_MEMBER_ID,',
'       (select first_name||'' ''||last_name',
'          from sp_team_members',
'         where id = n.team_member_id) team_member,',
'       length(EMAIL_CONTENTS) view_email,',
'       case when project_id is not null',
'            then :NOMENCLATURE_PROJECT',
'            when release_id is not null',
'            then ''Release''',
'            when initiative_id is not null',
'            then :NOMENCLATURE_INITIATIVE',
'            when init_focus_area_id is not null',
'            then :NOMENCLATURE_INITIATIVE||'' Focus Area''',
'            when task_id is not null',
'            then ''Milestone/Review/Task''',
'            end notif_about_type,',
'       case when project_id is not null',
'            then (select project',
'                    from sp_projects',
'                   where id = n.project_id)',
'            when release_id is not null',
'            then (select release_train ||release ',
'                    from sp_release_trains',
'                   where id = n.release_id)',
'            when initiative_id is not null',
'            then (select initiative',
'                    from sp_initiatives',
'                   where id = n.initiative_id) ',
'            when init_focus_area_id is not null',
'            then (select i.initiative||'' - ''||fa.focus_area',
'                    from sp_initiatives i,',
'                         sp_initiative_focus_areas fa',
'                   where fa.initiative_id = i.id',
'                     and fa.id = n.init_focus_area_id)',
'            when task_id is not null',
'            then (select (select task_type from sp_task_types rt where rt.id = task_type_id)||',
'                         case when task_sub_type_id is not null then '': '' end ||',
'                         (select task_type from sp_task_types rt where rt.id = task_sub_type_id) ||',
'                         case when task is not null then '' - ''||task end',
'                    from sp_tasks',
'                   where id = n.task_id)',
'            end notif_about,',
'       PROJECT_ID,',
'       task_id,',
'       release_id,',
'       initiative_id,',
'       init_focus_area_id,',
'       NOTIFICATION_PREF,',
'       TITLE,',
'       NOTIFICATION_TYPE,',
'       DISMISSED_YN,',
'       CREATED,',
'       CREATED_BY,',
'       UPDATED,',
'       UPDATED_BY',
'  from SP_TEAM_MEMBER_NOTIFICATIONS n'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
,p_prn_page_header=>'Team Member Notifications'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(18062404262974832046)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_internal_uid=>18062404262974832046
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18062408057457832264)
,p_db_column_name=>'CREATED'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18062408424347832264)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18062407651204832263)
,p_db_column_name=>'DISMISSED_YN'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Dismissed '
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18062406002296832261)
,p_db_column_name=>'ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17883467711997620729)
,p_db_column_name=>'INITIATIVE_ID'
,p_display_order=>55
,p_column_identifier=>'S'
,p_column_label=>'Initiative ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222948509975272942)
,p_db_column_name=>'INIT_FOCUS_AREA_ID'
,p_display_order=>125
,p_column_identifier=>'AC'
,p_column_label=>'Init Focus Area ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18062409609818832265)
,p_db_column_name=>'NOTIFICATION_PREF'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Notification Pref'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18062411683952832267)
,p_db_column_name=>'NOTIFICATION_TYPE'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Notification Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222948441302272941)
,p_db_column_name=>'NOTIF_ABOUT'
,p_display_order=>115
,p_column_identifier=>'AB'
,p_column_label=>'In Reference To'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(39222948398662272940)
,p_db_column_name=>'NOTIF_ABOUT_TYPE'
,p_display_order=>105
,p_column_identifier=>'AA'
,p_column_label=>'Object Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17883467595865620727)
,p_db_column_name=>'PROJECT_ID'
,p_display_order=>35
,p_column_identifier=>'Q'
,p_column_label=>'Project ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17883467652553620728)
,p_db_column_name=>'RELEASE_ID'
,p_display_order=>45
,p_column_identifier=>'R'
,p_column_label=>'Release ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17883467840126620730)
,p_db_column_name=>'TASK_ID'
,p_display_order=>65
,p_column_identifier=>'T'
,p_column_label=>'Task ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17883467946024620731)
,p_db_column_name=>'TEAM_MEMBER'
,p_display_order=>75
,p_column_identifier=>'U'
,p_column_label=>'Team Member'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17883467455945620726)
,p_db_column_name=>'TEAM_MEMBER_ID'
,p_display_order=>25
,p_column_identifier=>'P'
,p_column_label=>'Team Member ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18062410007731832265)
,p_db_column_name=>'TITLE'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Title'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18062408821916832264)
,p_db_column_name=>'UPDATED'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(18062409224952832265)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17883468261842620734)
,p_db_column_name=>'VIEW_EMAIL'
,p_display_order=>95
,p_column_identifier=>'W'
,p_column_label=>'Email Length'
,p_column_link=>'f?p=&APP_ID.:10791:&SESSION.::&DEBUG.:10791:P10791_ID:#ID#'
,p_column_linktext=>'#VIEW_EMAIL#'
,p_column_link_attr=>'title="View Email"'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(18062560645592087242)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'180625607'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TEAM_MEMBER:NOTIFICATION_PREF:NOTIFICATION_TYPE:TITLE:NOTIF_ABOUT_TYPE:NOTIF_ABOUT:VIEW_EMAIL:DISMISSED_YN:UPDATED'
,p_sort_column_1=>'UPDATED'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(18062799285464858437)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(18062403425221832044)
,p_button_name=>'UP'
,p_static_id=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2352535364915922073
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp.component_end;
end;
/
