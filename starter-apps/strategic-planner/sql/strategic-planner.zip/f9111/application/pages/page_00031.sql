prompt --application/pages/page_00031
begin
--   Manifest
--     PAGE: 00031
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>31
,p_name=>'Activities Report'
,p_alias=>'ACTIVITIES-REPORT'
,p_step_title=>'Activities'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(47767547076671364634)
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(51181142606315879163)
,p_protection_level=>'C'
,p_help_text=>'All Activities with this application.  Activities can be optionally associated with &NOMENCLATURE_INITIATIVES. or &NOMENCLATURE_PROJECTS. and typically describe work done or to be done. '
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4022581940671773846)
,p_plug_name=>'Activities'
,p_static_id=>'activities-report'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2103954283454391425
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ap.id, ',
'       ap.project_id,',
'       at.activity_type,',
'       ap.activity,',
'       ap.comments details,',
'       ap.start_date,',
'       ap.end_date,',
'       to_char(ap.start_date,''Day DD-Mon-YYYY'')||'' to ''||to_char(ap.end_date,''Day DD-Mon-YYYY'') TIMELINE,',
'       ap.end_date - ap.start_date days,',
'       round(ap.end_date - sysdate) days_remaining,',
'       ap.url,',
'       tm.first_name||'' ''||tm.last_name owner,',
'       tm.id team_member_id,',
'       decode(ap.private_yn,''Y'',''Yes'',''No'') private,',
'       --',
'       --',
'       apex_util.get_since(ap.updated) last_updated,',
'       (select count(*) from sp_activity_comments ',
'         where activity_id = ap.id',
'           and (nvl(private_yn,''N'') = ''N'' or author_id = :APP_USER_ID)) comment_cnt,',
'       --',
'       -- project related',
'       --',
'       decode(ap.project_id,null,null,(select project              from sp_projects p where p.id = ap.project_id and p.ARCHIVED_YN = ''N'' and p.DUPLICATE_OF_PROJECT_ID is null)) project,',
'       decode(ap.project_id,null,null,(select PROJECT_SIZE         from sp_projects p where p.id = ap.project_id and p.ARCHIVED_YN = ''N'' and p.DUPLICATE_OF_PROJECT_ID is null)) PROJECT_SIZE,',
'       decode(ap.project_id,null,null,(select friendly_identifier  from sp_projects p where p.id = ap.project_id and p.ARCHIVED_YN = ''N'' and p.DUPLICATE_OF_PROJECT_ID is null)) friendly_identifier,',
'       decode(ap.project_id,null,null,(select PROJECT_URL_NAME     from sp_projects p where p.id = ap.project_id and p.ARCHIVED_YN = ''N'' and p.DUPLICATE_OF_PROJECT_ID is null)) PROJECT_URL_NAME,',
'       --',
'       -- release',
'       --',
'       case when ap.project_id is null',
'            then null',
'            else (select RELEASE_TRAIN||'' ''||RELEASE',
'                    from SP_RELEASE_TRAINS rt ',
'                   where rt.id = (select release_id ',
'                                    from sp_projects p ',
'                                   where p.id = ap.project_id))',
'            end release,',
'       --',
'       -- optional initiative',
'       --',
'       decode(ap.initiative_id,null,null,',
'                               (select initiative from sp_initiatives where id = ap.initiative_id)) initiative,',
'       --',
'       -- tags',
'       --',
'       tm.tags team_member_tags,',
'       ap.tags activity_tags,',
'       decode(ap.project_id,null,null,(select tags from sp_projects p where p.id = ap.project_id and p.ARCHIVED_YN = ''N'')) project_tags,',
'       --',
'       -- timeframe',
'       --',
'       decode(trunc(sysdate),trunc(ap.end_date),''Current'',',
'       decode(trunc(sysdate),trunc(ap.start_date),''Current'',',
'           decode(',
'               greatest( trunc(sysdate), ap.start_date ),',
'               ap.start_date,',
'               ''Future'',',
'               decode(greatest( trunc(sysdate), ap.end_date), ap.end_date, ''Current'',''Past'')))) timeframe,',
'       --',
'        ap.updated,',
'        ap.created',
'from sp_activities ap,',
'     sp_activity_types at,',
'     sp_team_members tm',
'where ',
'      (nvl(ap.private_yn,''N'') = ''N'' or ap.team_member_id = :APP_USER_ID) and',
'      ap.activity_type_id = at.id and',
'      ap.team_member_id = tm.id',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>true
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(4022582097328773846)
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_flashback=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_internal_uid=>4022582097328773846
,p_ai_search_mode=>'A'
,p_ai_report_hint=>'All Activities, along with the owner, timeframe and Project and Release, if appropriate.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(23977950313294757045)
,p_db_column_name=>'ACTIVITY'
,p_display_order=>46
,p_column_identifier=>'AB'
,p_column_label=>'Activity'
,p_column_link=>'f?p=&APP_ID.:140:&SESSION.::&DEBUG.:RP,140:P140_ID:#ID#'
,p_column_linktext=>'#ACTIVITY#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022591605511773906)
,p_db_column_name=>'ACTIVITY_TAGS'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Activity Tags'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022584433104773865)
,p_db_column_name=>'ACTIVITY_TYPE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Activity Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(23977948210381757024)
,p_db_column_name=>'COMMENT_CNT'
,p_display_order=>36
,p_column_identifier=>'AA'
,p_column_label=>'Comments'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022593269530773914)
,p_db_column_name=>'CREATED'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022586411083773876)
,p_db_column_name=>'DAYS'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Days'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022586850016773878)
,p_db_column_name=>'DAYS_REMAINING'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Days Remaining'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(23977950461399757046)
,p_db_column_name=>'DETAILS'
,p_display_order=>56
,p_column_identifier=>'AC'
,p_column_label=>'Details'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022585629016773873)
,p_db_column_name=>'END_DATE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'End Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-Mon-YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022589689087773895)
,p_db_column_name=>'FRIENDLY_IDENTIFIER'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Friendly Identifier'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022583368020773857)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022590891800773902)
,p_db_column_name=>'INITIATIVE'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Initiative'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022588465803773889)
,p_db_column_name=>'LAST_UPDATED'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Last Updated'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(23977950515176757047)
,p_db_column_name=>'OWNER'
,p_display_order=>66
,p_column_identifier=>'AD'
,p_column_label=>'Owner'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(2683443116683761418)
,p_db_column_name=>'PRIVATE'
,p_display_order=>76
,p_column_identifier=>'AE'
,p_column_label=>'Private'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022588809316773891)
,p_db_column_name=>'PROJECT'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Project'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022583787245773861)
,p_db_column_name=>'PROJECT_ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Project Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022589217685773893)
,p_db_column_name=>'PROJECT_SIZE'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Project Size'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022592002824773908)
,p_db_column_name=>'PROJECT_TAGS'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Project Tags'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022590045679773898)
,p_db_column_name=>'PROJECT_URL_NAME'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Project Url Name'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022590476986773900)
,p_db_column_name=>'RELEASE'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Release'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022585287207773871)
,p_db_column_name=>'START_DATE'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Start Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-Mon-YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022588073920773886)
,p_db_column_name=>'TEAM_MEMBER_ID'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Team Member Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022591299861773904)
,p_db_column_name=>'TEAM_MEMBER_TAGS'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Team Member Tags'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022592498926773910)
,p_db_column_name=>'TIMEFRAME'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Timeframe'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022586063523773875)
,p_db_column_name=>'TIMELINE'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Timeline'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022592885223773912)
,p_db_column_name=>'UPDATED'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(4022587231720773881)
,p_db_column_name=>'URL'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'URL'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(4022357352226444152)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'primary'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ACTIVITY_TYPE:ACTIVITY:OWNER:START_DATE:END_DATE:INITIATIVE:PROJECT:RELEASE:UPDATED'
,p_sort_column_1=>'UPDATED'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4022580812732773676)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_menu_id=>wwv_flow_imp.id(176220395320510839347)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4025191290204668495)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(4022580812732773676)
,p_button_name=>'RESET'
,p_static_id=>'reset'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:RR,CIR,RIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4025196492380669716)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4022580812732773676)
,p_button_name=>'UP'
,p_static_id=>'up'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2352535364915922073
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp.component_end;
end;
/
