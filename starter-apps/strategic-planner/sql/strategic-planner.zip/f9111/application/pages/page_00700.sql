prompt --application/pages/page_00700
begin
--   Manifest
--     PAGE: 00700
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>700
,p_name=>'Team Calendar'
,p_alias=>'TEAM-CAL'
,p_step_title=>'Team Calendar'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var calendar = apex.region("eventscal").widget().data("fullCalendar");',
'calendar.setOption(''contentHeight'', "auto");'))
,p_step_template=>2530071015796209513
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(31743638170417552010)
,p_protection_level=>'C'
,p_help_text=>'Calendar showing all Events that can affect Team Member availability.'
,p_page_comment=>'Filterable by Event Type, whether or not the user has Open Reviews, User tags and who the event is for (useful when looking for events affecting a single user versus those affecting all, such as holidays).'
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33456105766262616273)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_menu_id=>wwv_flow_imp.id(176220395320510839347)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33456106478080616275)
,p_plug_name=>'Events'
,p_static_id=>'events'
,p_region_name=>'eventscal'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.id event_id,',
'       case when e.for_user_id is not null',
'            then tm.first_name||'' ''||tm.last_name||'' - ''',
'            end || ',
'            t.event_type ||',
'            case when e.event_name is not null',
'                 then '' (''||e.event_name',
'                 end ||',
'            case when t.general_event_yn = ''Y'' and e.event_details is not null',
'                 then '' - ''|| e.event_details',
'                 end ||',
'             case when e.event_name is not null',
'                  then '')''',
'                  end name,',
'       e.event_date,',
'       e.event_date end_date,',
'       null recur_frequency,',
'       e.event_details,',
'       case when t.calendar_event_color is not null',
'            then ''apex-cal-''||t.calendar_event_color',
'            end icon_color,',
'       t.icon_class,',
'       t.event_type,',
'       lower(tm.tags) person_tags,',
'       case when e.for_user_id is not null',
'            then (select decode(count(*),0,0,1)',
'                    from sp_tasks r, sp_task_types tt, sp_task_statuses s',
'                   where r.owner_id = tm.id ',
'                     and nvl(r.task_sub_type_id,r.task_type_id) = tt.id',
'                     and tt.static_id like ''REVIEW%''',
'                     and r.status_id = s.id',
'                     and s.indicates_complete_yn != ''Y'')',
'            end open_review_cnt,',
'       case when :IS_CONTRIBUTOR = ''Y''',
'            then apex_page.get_url(',
'                     p_page => 704, ',
'                     p_clear_cache => ''704'',',
'                     p_items  => ''P704_ID'',',
'                     p_values => e.id )',
'            else null',
'            end edit_link,',
'       case when e.for_user_id is null then 0 ',
'            when e.for_user_id = :APP_USER_ID then 1',
'            else 2 ',
'            end main_ob,',
'       e.for_user_id event_for,',
'       case when e.event_date < trunc(to_date(:APP_SYSDATE,''DD-MON-YYYY'') + 1, ''IW'') - 1',
'            then ''past''',
'            else ''present''',
'            end past_or_present',
'  from sp_events e,',
'       sp_event_types t,',
'       sp_team_members tm',
' where e.event_type_id = t.id',
'   and e.series_id is null',
'   and e.for_user_id = tm.id (+)',
'union all',
'select e.id event_id,',
'       case when e.for_user_id is not null',
'            then tm.first_name||'' ''||tm.last_name||'' - ''',
'            end || ',
'            t.event_type ||',
'            case when e.event_name is not null',
'                 then '' (''||e.event_name',
'                 end ||',
'            case when t.general_event_yn = ''Y'' and e.event_details is not null',
'                 then '' - ''|| e.event_details',
'                 end ||',
'             case when e.event_name is not null',
'                  then '')''',
'                  end name,',
'       e.event_date,',
'       case when s.recur_freq = ''D''',
'            then s.end_date',
'            end end_date,',
'       case when s.recur_freq is not null',
'            then ''Repeats ''||decode(s.recur_freq, ''D'', ''Daily'', ''WD'', ''Weekdays'', ''W'', ''Weekly'', ',
'                                            ''2W'', ''Every 2 Weeks'', ''M'', ''Montly'', s.recur_freq)',
'            end recur_frequency,',
'       e.event_details,',
'       case when t.calendar_event_color is not null',
'            then ''apex-cal-''||t.calendar_event_color',
'            end icon_color,',
'       t.icon_class,',
'       t.event_type,',
'       lower(tm.tags) person_tags,',
'       case when e.for_user_id is not null',
'            then (select decode(count(*),0,0,1)',
'                    from sp_tasks r, sp_task_types tt, sp_task_statuses s',
'                   where r.owner_id = tm.id ',
'                     and nvl(r.task_sub_type_id,r.task_type_id) = tt.id',
'                     and tt.static_id like ''REVIEW%''',
'                     and r.status_id = s.id',
'                     and s.indicates_complete_yn != ''Y'')',
'            end open_review_cnt,',
'       case when :IS_CONTRIBUTOR = ''Y''',
'            then apex_page.get_url(',
'                     p_page => 704, ',
'                     p_clear_cache => ''704'',',
'                     p_items  => ''P704_ID'',',
'                     p_values => e.id )',
'            else null',
'            end edit_link,',
'       case when e.for_user_id is null then 0 ',
'            when e.for_user_id = :APP_USER_ID then 1',
'            else 2 ',
'            end main_ob,',
'       e.for_user_id event_for,',
'       case when s.end_date < trunc(to_date(:APP_SYSDATE,''DD-MON-YYYY'') + 1, ''IW'') - 1',
'            then ''past''',
'            else ''present''',
'            end past_or_present',
'  from sp_events e,',
'       sp_event_types t,',
'       sp_team_members tm,',
'       sp_event_series s',
' where e.event_type_id = t.id',
'   and e.series_id = s.id',
'   and e.for_user_id = tm.id (+)',
'   and s.recur_freq = ''D''',
'   and e.event_date = s.start_date',
'union all',
'select e.id event_id,',
'       case when e.for_user_id is not null',
'            then tm.first_name||'' ''||tm.last_name||'' - ''',
'            end || ',
'            t.event_type ||',
'            case when e.event_name is not null',
'                 then '' (''||e.event_name',
'                 end ||',
'            case when t.general_event_yn = ''Y'' and e.event_details is not null',
'                 then '' - ''|| e.event_details',
'                 end ||',
'             case when e.event_name is not null',
'                  then '')''',
'                  end name,',
'       e.event_date,',
'       e.event_date end_date,',
'       ''Repeats ''||decode(s.recur_freq, ''D'', ''Daily'', ''WD'', ''Weekdays'', ''W'', ''Weekly'', ',
'                                            ''2W'', ''Every 2 Weeks'', ''M'', ''Montly'', s.recur_freq) recur_frequency,',
'       e.event_details,',
'       case when t.calendar_event_color is not null',
'            then ''apex-cal-''||t.calendar_event_color',
'            end icon_color,',
'       t.icon_class,',
'       t.event_type,',
'       lower(tm.tags) person_tags,',
'       case when e.for_user_id is not null',
'            then (select decode(count(*),0,0,1)',
'                    from sp_tasks r, sp_task_types tt, sp_task_statuses s',
'                   where r.owner_id = tm.id ',
'                     and nvl(r.task_sub_type_id,r.task_type_id) = tt.id',
'                     and tt.static_id like ''REVIEW%''',
'                     and r.status_id = s.id',
'                     and s.indicates_complete_yn != ''Y'')',
'            end open_review_cnt,',
'       case when :IS_CONTRIBUTOR = ''Y''',
'            then apex_page.get_url(',
'                     p_page => 704, ',
'                     p_clear_cache => ''704'',',
'                     p_items  => ''P704_ID'',',
'                     p_values => e.id )',
'            else null',
'            end edit_link,',
'       case when e.for_user_id is null then 0 ',
'            when e.for_user_id = :APP_USER_ID then 1',
'            else 2 ',
'            end main_ob,',
'       e.for_user_id event_for,',
'       case when e.event_date < trunc(to_date(:APP_SYSDATE,''DD-MON-YYYY'') + 1, ''IW'') - 1',
'            then ''past''',
'            else ''present''',
'            end past_or_present',
'  from sp_events e,',
'       sp_event_types t,',
'       sp_team_members tm,',
'       sp_event_series s',
' where e.event_type_id = t.id',
'   and e.series_id = s.id',
'   and e.for_user_id = tm.id (+)',
'   and s.recur_freq != ''D''',
' order by main_ob, name'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (pOptions) {   ',
'',
'    //If you like to know what pOptions contains, uncomment below',
'    console.log(pOptions);',
'',
'    pOptions.contentHeight = 500;',
'    //return pOptions',
'    return pOptions;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'additional_calendar_views', 'list:navigation',
  'create_link', 'f?p=&APP_ID.:702:&SESSION.:NOT_TODAY:&DEBUG.:702:P702_DATE:&APEX$NEW_START_DATE.',
  'css_class', 'ICON_COLOR',
  'display_column', 'NAME',
  'drag_and_drop', 'N',
  'end_date_column', 'END_DATE',
  'event_sorting', 'REGION_SOURCE',
  'maximum_events_day', '50',
  'multiple_line_event', 'Y',
  'primary_key_column', 'EVENT_ID',
  'responsive_list_view', 'Y',
  'show_time', 'N',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'EVENT_DATE',
  'view_edit_link', '&EDIT_LINK.')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(32733524734993472607)
,p_plug_name=>'Filters'
,p_static_id=>'filters'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(33456106478080616275)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'N',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(36435159936777209648)
,p_name=>'P700_EVENT_FOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(32733524734993472607)
,p_prompt=>'Event For'
,p_source=>'EVENT_FOR'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d, r',
'  from',
'(',
'select ''For Me'' d,',
'       to_number(:APP_USER_ID) r,',
'       1 ob',
'  from dual',
' where :APP_USER_ID is not null',
'union all',
'select ''For All'' d,',
'       null r,',
'       2 ob',
'  from dual',
'union all',
'select unique tm.first_name||'' ''||tm.last_name d,',
'       tm.id r,',
'       3 ob',
'  from sp_events e,',
'       sp_team_members tm',
' where e.for_user_id = tm.id',
') order by ob, d'))
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_fc_show_label=>true
,p_fc_collapsible=>true
,p_fc_initial_collapsed=>true
,p_fc_compute_counts=>false
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32733529082944472650)
,p_name=>'P700_EVENT_TYPES'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(32733524734993472607)
,p_prompt=>'Event Types'
,p_source=>'EVENT_TYPE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select event_type d, event_type r',
'  from sp_event_types',
' where active_yn = ''Y''',
'    or id in (select event_type_id from sp_events',
'               where event_date > sysdate-90)'))
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33518811373396200403)
,p_name=>'P700_OPEN_REVIEWS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(32733524734993472607)
,p_prompt=>'User has Open Reviews'
,p_source=>'OPEN_REVIEW_CNT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Yes;1,No;0'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>false
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41402832821512657134)
,p_name=>'P700_PAST_OR_PRESENT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(32733524734993472607)
,p_item_default=>'present'
,p_prompt=>'Exclude Past'
,p_source=>'PAST_OR_PRESENT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC2:Yes;present'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>false
,p_fc_show_more_count=>2
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_actions_filter=>false
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(32733528908881472649)
,p_name=>'P700_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(32733524734993472607)
,p_prompt=>'Search'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33518811290630200402)
,p_name=>'P700_TAGS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(32733524734993472607)
,p_prompt=>'User Tags'
,p_source=>'PERSON_TAGS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>false
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>','
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33518814554038200435)
,p_plug_name=>'user timezone'
,p_static_id=>'user-timezone'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'    select nvl(timezone,''UTC'') user_timezone',
'      from sp_team_members',
'     where id = :APP_USER_ID',
') loop',
'    sys.htp.p(''Your timezone is ''||apex_escape.html(c1.user_timezone)||''. This is set under your profile.'');',
'end loop;',
'',
'return null;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8975945553612749308)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(33456105766262616273)
,p_button_name=>'actions'
,p_static_id=>'actions'
,p_show_as_disabled=>false
,p_button_type=>'MENU'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2352535364915922073
,p_button_image_alt=>'Actions'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-ellipsis-v'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(8975945822121749311)
,p_button_id=>wwv_flow_imp.id(8975945553612749308)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Add Multiple Team Calendar Events'
,p_static_id=>'add-multiple-team-calendar-events'
,p_display_sequence=>30
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:709:&SESSION.::&DEBUG.:RP,709::'
,p_icon_css_classes=>'fa-calendar-wrench'
,p_authorization_scheme=>wwv_flow_imp.id(176220694531802839665)
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(8975945912735749312)
,p_button_id=>wwv_flow_imp.id(8975945553612749308)
,p_menu_entry_type=>'SEPARATOR'
,p_static_id=>'new'
,p_display_sequence=>40
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(8975945792364749310)
,p_button_id=>wwv_flow_imp.id(8975945553612749308)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Out of Office Interactive Report'
,p_static_id=>'out-of-office-interactive-report'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:710:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-file-text-o'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(8975945607347749309)
,p_button_id=>wwv_flow_imp.id(8975945553612749308)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Out Today'
,p_static_id=>'out-today'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:702:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-calendar-day'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(8975946006578749313)
,p_button_id=>wwv_flow_imp.id(8975945553612749308)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Refresh'
,p_static_id=>'refresh'
,p_display_sequence=>50
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:700:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(8975946137352749314)
,p_button_id=>wwv_flow_imp.id(8975945553612749308)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Reset'
,p_static_id=>'reset'
,p_display_sequence=>60
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:700:&SESSION.::&DEBUG.:RP,700::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8975945462775749307)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(33456105766262616273)
,p_button_name=>'add-event'
,p_static_id=>'add-event'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Event'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:704:&SESSION.::&DEBUG.:704::'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus'
,p_security_scheme=>wwv_flow_imp.id(176220694531802839665)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(33518136682634277961)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(33456105766262616273)
,p_button_name=>'UP'
,p_static_id=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2352535364915922073
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(33518812018301200410)
,p_name=>'refresh after create'
,p_static_id=>'refresh-after-create'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(33456105766262616273)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33518812198880200411)
,p_event_id=>wwv_flow_imp.id(33518812018301200410)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(33456106478080616275)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(33518812755024200417)
,p_name=>'refresh after update'
,p_static_id=>'refresh-after-update'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(33456106478080616275)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33518812841738200418)
,p_event_id=>wwv_flow_imp.id(33518812755024200417)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(33456106478080616275)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
