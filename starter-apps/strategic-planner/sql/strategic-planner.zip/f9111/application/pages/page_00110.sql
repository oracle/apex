prompt --application/pages/page_00110
begin
--   Manifest
--     PAGE: 00110
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>110
,p_name=>'Activity'
,p_alias=>'ACTIVITY-HELP'
,p_page_mode=>'MODAL'
,p_step_title=>'Activity'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(38309584282026711102)
,p_step_template=>2103835248774687739
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(51181142606315879163)
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43852009109430080382)
,p_plug_name=>'About'
,p_static_id=>'about'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'An activity is something that consumes the time.  ',
'Typically, but not always, an activity is work relating to a specific &NOMENCLATURE_PROJECT. or &NOMENCLATURE_INITIATIVE.. ',
'</P>',
'<p>',
'Activity is time bound, activity starts at a given day and is estimated to complete by an end date.',
'</p>',
'<p>',
'    Activity Attributes:',
'    <ul>',
'        <li><strong>Type</strong>: Type of activity performed, see list below for types of activities defined for this application.</li>',
'        <li><strong>Activity</strong>: Short description, up to 255 characters, of the activity.</li>',
'        <li><strong>Details</strong>: More (optional) details about the activity.</li>',
'        <li><strong>Private</strong>: If activity is private, it will only be displayed to the Owner (and Owner is forced to be the current user).</li>',
'        <li><strong>Start Date</strong>: Date activity started or is planned to start</li>',
'        <li><strong>End Date</strong>: Date activity was completed or is planned to be completed.</li>',
'        <li><strong>Optional &NOMENCLATURE_PROJECT.:</strong>: Defines related &NOMENCLATURE_PROJECT. if work is in support of a specific &NOMENCLATURE_PROJECT..</li>',
'        <li><strong>Optional &NOMENCLATURE_INITIATIVE.:</strong>: Defines related &NOMENCLATURE_INITIATIVE. if work is in support of a specific &NOMENCLATURE_INITIATIVE..</li>',
'        <li><strong>Owner:</strong>: Defines who is doing the activity.</li>',
'        <li><strong>Tags</strong>: Comma seperated list of tags to help filter activities.</li>',
'        <li><strong>URL</strong>: Optional URL relating to the activity.</li>',
'    </ul>',
'</p>',
'<p>',
'    Organization of Activities Associated with &NOMENCLATURE_PROJECTS.:',
'    <p>',
'        &NOMENCLATURE_AREA. > &NOMENCLATURE_INITIATIVE. > &NOMENCLATURE_PROJECT. > <strong>Activity</strong>',
'    </p>',
'</p>',
'<p>',
'    Organization of Activities Associated with &NOMENCLATURE_USER. and not a &NOMENCLATURE_PROJECT.:',
'    <p>',
'        &NOMENCLATURE_USER. > <strong>Activity</strong>',
'    </p>',
'</p>',
'<br />',
'<br />'))
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(39710858182436918784)
,p_plug_name=>'button container'
,p_static_id=>'button-container'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38304877925335124988)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(39710858182436918784)
,p_button_name=>'what_is_a_project'
,p_static_id=>'what-is-a-project'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'About &NOMENCLATURE_PROJECTS.'
,p_button_redirect_url=>'f?p=&APP_ID.:107:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa=info'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38304877541790124987)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(39710858182436918784)
,p_button_name=>'what_is_a_user'
,p_static_id=>'what-is-a-user'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'About &NOMENCLATURE_USERS.'
,p_button_redirect_url=>'f?p=&APP_ID.:109:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa=info'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38303800490504703453)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(39710858182436918784)
,p_button_name=>'what_is_an_area'
,p_static_id=>'what-is-an-area'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'About &NOMENCLATURE_AREAS.'
,p_button_redirect_url=>'f?p=&APP_ID.:105:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa=info'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38303800410265703452)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(39710858182436918784)
,p_button_name=>'what_is_an_initiative'
,p_static_id=>'what-is-an-initiative'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'About &NOMENCLATURE_INITIATIVES.'
,p_button_redirect_url=>'f?p=&APP_ID.:106:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa=info'
);
wwv_flow_imp.component_end;
end;
/
