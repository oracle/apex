prompt --application/pages/page_00075
begin
--   Manifest
--     PAGE: 00075
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>75
,p_name=>'test - Focus Areas by Release'
,p_alias=>'TEST-FOCUS-AREAS-BY-RELEASE'
,p_step_title=>'test - Focus Areas by Release'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(45065119564448640164)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.no-item-ui {',
'  --a-field-input-border-width: 0px;',
'  --a-field-input-background-color: transparent;',
'}',
'',
'.overline {',
'  color: var(--ut-region-text-color, var(--ut-component-text-default-color));',
'}',
'',
'.hide-report-total td[headers="FOCUS_AREA"] > strong {',
'    display: none;',
'}'))
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46904002389737280473)
,p_plug_name=>'Chart'
,p_static_id=>'chart'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_ajax_items_to_submit=>'P75_INITIATIVE_ID'
,p_plug_footer=>'* indicates the current Release'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(23878767222888856386)
,p_region_id=>wwv_flow_imp.id(46904002389737280473)
,p_chart_type=>'bar'
,p_height=>'400'
,p_lazy_loading=>true
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_no_data_found_message=>'No data found'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function(options) {',
'',
'    options.valueFormats.series = {',
'        tooltipLabel: "Focus Area"',
'    };',
'',
'    options.valueFormats.group = {',
'        tooltipLabel: "Release"',
'    };',
'',
'    options.valueFormats.value.tooltipLabel = "&NOMENCLATURE_PROJECT. Count";',
'',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(23878768813687856394)
,p_chart_id=>wwv_flow_imp.id(23878767222888856386)
,p_static_id=>'data'
,p_seq=>10
,p_name=>'data'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(f.focus_area,''None Assigned'') series,',
'       t.release|| case when t.id = :P75_CURRENT_ID ',
'                        then '' *''',
'                        end label,',
'       count(*) value',
'  from sp_projects p,',
'       sp_release_trains t,',
'       sp_initiative_focus_areas f',
' where t.release_train = :P75_RELEASE',
'   and p.release_id = t.id',
'   and nvl(p.archived_yn,''N'') = ''N''',
'   and p.duplicate_of_project_id is null',
'   and p.focus_area_id = f.id (+)',
'   and t.release_type = ''FULL''',
'   and t.id in (:P75_CURRENT_ID,:P75_N1_ID,:P75_P1_ID,:P75_P2_ID,:P75_P3_ID)',
'   and p.initiative_id = nvl(:P75_INITIATIVE_ID,p.initiative_id)',
'group by t.id, t.release, f.focus_area',
'order by t.release, f.focus_area nulls last'))
,p_ajax_items_to_submit=>'P75_RELEASE,P75_INITIATIVE_ID'
,p_series_type=>'bar'
,p_series_name_column_name=>'SERIES'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(23878767682954856389)
,p_chart_id=>wwv_flow_imp.id(23878767222888856386)
,p_static_id=>'x'
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(23878768271576856390)
,p_chart_id=>wwv_flow_imp.id(23878767222888856386)
,p_static_id=>'y'
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(46931619812020928556)
,p_name=>'Pivot Table'
,p_static_id=>'classic'
,p_template=>4075786578761660127
,p_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_sub_css_classes=>'hide-report-total'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select f.focus_area ob,',
'       f.focus_area,',
'       (select count(*)',
'          from sp_projects',
'         where nvl(archived_yn,''N'') = ''N''',
'           and duplicate_of_project_id is null',
'           and release_id = :P75_P3_ID',
'           and focus_area_id = f.id',
'           and initiative_id = nvl(:P75_INITIATIVE_ID,initiative_id)) p3_cnt,',
'       (select count(*)',
'          from sp_projects',
'         where nvl(archived_yn,''N'') = ''N''',
'           and duplicate_of_project_id is null',
'           and release_id = :P75_P2_ID',
'           and focus_area_id = f.id',
'           and initiative_id = nvl(:P75_INITIATIVE_ID,initiative_id)) p2_cnt,',
'       (select count(*)',
'          from sp_projects',
'         where nvl(archived_yn,''N'') = ''N''',
'           and duplicate_of_project_id is null',
'           and release_id = :P75_P1_ID',
'           and focus_area_id = f.id',
'           and initiative_id = nvl(:P75_INITIATIVE_ID,initiative_id)) p1_cnt,',
'       (select count(*)',
'          from sp_projects',
'         where nvl(archived_yn,''N'') = ''N''',
'           and duplicate_of_project_id is null',
'           and release_id = :P75_CURRENT_ID',
'           and focus_area_id = f.id',
'           and initiative_id = nvl(:P75_INITIATIVE_ID,initiative_id)) current_cnt,',
'       (select count(*)',
'          from sp_projects',
'         where nvl(archived_yn,''N'') = ''N''',
'           and duplicate_of_project_id is null',
'           and release_id = :P75_N1_ID',
'           and focus_area_id = f.id',
'           and initiative_id = nvl(:P75_INITIATIVE_ID,initiative_id)) next_cnt',
'  from sp_initiative_focus_areas f',
' where f.id in (select focus_area_id ',
'                  from sp_projects',
'                 where nvl(archived_yn,''N'') = ''N''',
'                   and duplicate_of_project_id is null',
'                   and release_id in (:P75_CURRENT_ID, :P75_N1_ID, :P75_P1_ID, :P75_P2_ID, :P75_P3_ID)',
'                   and initiative_id = nvl(:P75_INITIATIVE_ID,initiative_id))',
'union all',
'select null ob,',
'       ''None Assigned'' focus_area,',
'       (select count(*)',
'          from sp_projects',
'         where nvl(archived_yn,''N'') = ''N''',
'           and duplicate_of_project_id is null',
'           and release_id = :P75_P3_ID',
'           and focus_area_id is null',
'           and initiative_id = nvl(:P75_INITIATIVE_ID,initiative_id)) p3_cnt,',
'       (select count(*)',
'          from sp_projects',
'         where nvl(archived_yn,''N'') = ''N''',
'           and duplicate_of_project_id is null',
'           and release_id = :P75_P2_ID',
'           and focus_area_id is null',
'           and initiative_id = nvl(:P75_INITIATIVE_ID,initiative_id)) p2_cnt,',
'       (select count(*)',
'          from sp_projects',
'         where nvl(archived_yn,''N'') = ''N''',
'           and duplicate_of_project_id is null',
'           and release_id = :P75_P1_ID',
'           and focus_area_id is null',
'           and initiative_id = nvl(:P75_INITIATIVE_ID,initiative_id)) p1_cnt,',
'       (select count(*)',
'          from sp_projects',
'         where nvl(archived_yn,''N'') = ''N''',
'           and duplicate_of_project_id is null',
'           and release_id = :P75_CURRENT_ID',
'           and focus_area_id is null',
'           and initiative_id = nvl(:P75_INITIATIVE_ID,initiative_id)) current_cnt,',
'       (select count(*)',
'          from sp_projects',
'         where nvl(archived_yn,''N'') = ''N''',
'           and duplicate_of_project_id is null',
'           and release_id = :P75_N1_ID',
'           and focus_area_id is null',
'           and initiative_id = nvl(:P75_INITIATIVE_ID,initiative_id)) next_cnt',
'  from dual'))
,p_footer=>'* indicates the current Release'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P75_INITIATIVE_ID'
,p_lazy_loading=>false
,p_query_row_template=>2542081983073888486
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'ROW_RANGES_WITH_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23878771575835856404)
,p_query_column_id=>6
,p_column_alias=>'CURRENT_CNT'
,p_column_display_sequence=>50
,p_column_heading=>'&P66_CURRENT_NAME. *'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P75_CURRENT_ID'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23878769904760856400)
,p_query_column_id=>2
,p_column_alias=>'FOCUS_AREA'
,p_column_display_sequence=>10
,p_column_heading=>'Focus Area'
,p_heading_alignment=>'LEFT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23878771974033856404)
,p_query_column_id=>7
,p_column_alias=>'NEXT_CNT'
,p_column_display_sequence=>60
,p_column_heading=>'&P66_N1_NAME.'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P75_N1_ID'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23878772341812856405)
,p_query_column_id=>1
,p_column_alias=>'OB'
,p_column_display_sequence=>70
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23878771195664856403)
,p_query_column_id=>5
,p_column_alias=>'P1_CNT'
,p_column_display_sequence=>40
,p_column_heading=>'&P66_P1_NAME.'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P75_P1_ID'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23878770702780856402)
,p_query_column_id=>4
,p_column_alias=>'P2_CNT'
,p_column_display_sequence=>30
,p_column_heading=>'&P66_P2_NAME.'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P75_P2_ID'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(23878770389080856402)
,p_query_column_id=>3
,p_column_alias=>'P3_CNT'
,p_column_display_sequence=>20
,p_column_heading=>'&P66_P3_NAME.'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_sum_column=>'Y'
,p_display_when_cond_type=>'ITEM_IS_NOT_NULL'
,p_display_when_condition=>'P75_P3_ID'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46931621306834928571)
,p_plug_name=>'RDS'
,p_static_id=>'rds'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46904002200779280471)
,p_plug_name=>'Select Release Train'
,p_static_id=>'select-release'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_header=>'Select Release Train to show Focus Areas for current, next and previous 3 Releases.  Optionally, select an Initiative to limit Focus Areas to just one Initiative.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(23878766099957856365)
,p_button_sequence=>20
,p_button_name=>'RESET'
,p_static_id=>'reset'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:75:&SESSION.::&DEBUG.:RR,66::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(23878766467030856366)
,p_button_sequence=>10
,p_button_name=>'UP'
,p_static_id=>'up'
,p_show_as_disabled=>false
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2352535364915922073
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46904013321559280550)
,p_name=>'P75_CURRENT_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(46904002200779280471)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46904013451580280551)
,p_name=>'P75_CURRENT_NAME'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(46904002200779280471)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46931631229316928638)
,p_name=>'P75_INITIATIVE_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(46904002200779280471)
,p_prompt=>'Initiative'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_ONE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select initiative d, id r   ',
'  from sp_initiatives i   ',
' where i.id in (select p.initiative_id',
'                  from sp_projects p,',
'                       sp_release_trains r',
'                 where p.release_id = r.id',
'                   and r.release_train = :P75_RELEASE',
'                   and nvl(p.archived_yn,''N'') = ''N''',
'                   and p.duplicate_of_project_id is null)',
' order by 1'))
,p_lov_cascade_parent_items=>'P75_RELEASE'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'fetch_on_search', 'N',
  'infinite_scroll', 'Y',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46904013527925280552)
,p_name=>'P75_N1_ID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(46904002200779280471)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46904013619388280553)
,p_name=>'P75_N1_NAME'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(46904002200779280471)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46904013748555280554)
,p_name=>'P75_P1_ID'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(46904002200779280471)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46904013822224280555)
,p_name=>'P75_P1_NAME'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(46904002200779280471)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46904013944623280556)
,p_name=>'P75_P2_ID'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(46904002200779280471)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46904014016117280557)
,p_name=>'P75_P2_NAME'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(46904002200779280471)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46904014091451280558)
,p_name=>'P75_P3_ID'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(46904002200779280471)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46931628343834928609)
,p_name=>'P75_P3_NAME'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(46904002200779280471)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46904010510127280522)
,p_name=>'P75_RELEASE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(46904002200779280471)
,p_prompt=>'Release Train'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select unique release_train d, release_train r   ',
'  from sp_release_trains r',
' where release_type = ''FULL''',
'   and exists (select 1 from sp_projects',
'               where release_id = r.id',
'                 and nvl(archived_yn,''N'') = ''N''',
'                 and duplicate_of_project_id is null)',
'  order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Test Empty ---'
,p_cHeight=>1
,p_field_template=>1612549789555753698
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(23878778624790856443)
,p_name=>'when change initiative'
,p_static_id=>'when-change-initiative'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P75_INITIATIVE_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23878779094991856447)
,p_event_id=>wwv_flow_imp.id(23878778624790856443)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(46904002389737280473)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23878779544192856448)
,p_event_id=>wwv_flow_imp.id(23878778624790856443)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh_1'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(46931619812020928556)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(23878780542753856449)
,p_name=>'when no release selected'
,p_static_id=>'when-no-release-selected'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P75_RELEASE'
,p_condition_element=>'P75_RELEASE'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23878780998724856450)
,p_event_id=>wwv_flow_imp.id(23878780542753856449)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(46904002389737280473)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23878781432336856450)
,p_event_id=>wwv_flow_imp.id(23878780542753856449)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide_1'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(46931619812020928556)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23878781907347856451)
,p_event_id=>wwv_flow_imp.id(23878780542753856449)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide_1_1_1'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(46931621306834928571)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23878782485351856451)
,p_event_id=>wwv_flow_imp.id(23878780542753856449)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-set-value'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P75_INITIATIVE_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'suppress_change_event', 'Y',
  'type', 'STATIC_ASSIGNMENT')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23878782988595856451)
,p_event_id=>wwv_flow_imp.id(23878780542753856449)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(46931621306834928571)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23878783452380856452)
,p_event_id=>wwv_flow_imp.id(23878780542753856449)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show_1'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(46904002389737280473)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23878783917316856453)
,p_event_id=>wwv_flow_imp.id(23878780542753856449)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show_2'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(46931619812020928556)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(23878784485987856453)
,p_name=>'when select release'
,p_static_id=>'when-select-release'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P75_RELEASE'
,p_condition_element=>'P75_RELEASE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23878785889040856456)
,p_event_id=>wwv_flow_imp.id(23878784485987856453)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-execute-plsql-code'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'items_to_return', 'P75_CURRENT_ID,P75_CURRENT_NAME,P75_N1_ID,P75_N1_NAME,P75_P1_ID,P75_P1_NAME,P75_P2_ID,P75_P2_NAME,P75_P3_ID,P75_P3_NAME,P75_INITIATIVE_ID',
  'items_to_submit', 'P75_RELEASE',
  'language', 'PLSQL',
  'plsql_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    ':P75_CURRENT_ID   := null;',
    ':P75_CURRENT_NAME := null;',
    '',
    ':P75_N1_ID   := null;',
    ':P75_N1_NAME := null;',
    '',
    ':P75_P1_ID   := null;',
    ':P75_P1_NAME := null;',
    ':P75_P2_ID   := null;',
    ':P75_P2_NAME := null;',
    ':P75_P3_ID   := null;',
    ':P75_P3_NAME := null;',
    '',
    ':P75_INITIATIVE_ID := null;',
    '',
    'for c1 in (',
    '    select id, release, release_target_date, release_open_date',
    '      from sp_release_trains',
    '     where release_type = ''FULL''',
    '       and release_train = :P75_RELEASE',
    '       and release_open_completed = ''Y''',
    '       and release_completed = ''N''',
    '    union all                       -- added to catch no currently open',
    '    select null, null, null, null',
    '      from dual',
    '     order by release_target_date nulls last, release_open_date nulls last',
    ') loop',
    '    :P75_CURRENT_ID := c1.id;',
    '    :P75_CURRENT_NAME := c1.release;',
    '',
    '    for c2 in (',
    '        select id, release',
    '          from sp_release_trains',
    '         where release_type = ''FULL''',
    '           and release_train = :P75_RELEASE',
    '           and release_completed = ''N''',
    '           and (id != c1.id or c1.id is null)',
    '           and nvl(c1.release_target_date,trunc(sysdate)) <= release_target_date',
    '         order by release_target_date nulls last, release_open_date nulls last',
    '    ) loop',
    '        :P75_N1_ID := c2.id;',
    '        :P75_N1_NAME := c2.release;',
    '        exit;',
    '    end loop;',
    '',
    '    for c2 in (',
    '        select rownum, id, release',
    '          from (',
    '          select id, release',
    '            from sp_release_trains',
    '           where release_type = ''FULL''',
    '             and release_train = :P75_RELEASE',
    '             and release_open_completed = ''Y''',
    '             and release_completed = ''Y''',
    '             and (id != c1.id or c1.id is null)',
    '           order by release_target_date desc',
    '          )',
    '    ) loop',
    '        if c2.rownum = 1 then',
    '            :P75_P1_ID := c2.id;',
    '            :P75_P1_NAME := c2.release;',
    '        elsif c2.rownum = 2 then',
    '            :P75_P2_ID := c2.id;',
    '            :P75_P2_NAME := c2.release;',
    '        elsif c2.rownum = 3 then',
    '            :P75_P3_ID := c2.id;',
    '            :P75_P3_NAME := c2.release;',
    '        else exit;',
    '        end if;',
    '    end loop;',
    '',
    '    exit;',
    'end loop;')),
  'show_processing', 'N',
  'suppress_change_event', 'N')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23878784878273856454)
,p_event_id=>wwv_flow_imp.id(23878784485987856453)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(46904002389737280473)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(23878785323448856455)
,p_event_id=>wwv_flow_imp.id(23878784485987856453)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh_1'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(46931619812020928556)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
