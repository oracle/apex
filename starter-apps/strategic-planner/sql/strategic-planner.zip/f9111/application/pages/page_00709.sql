prompt --application/pages/page_00709
begin
--   Manifest
--     PAGE: 00709
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>709
,p_name=>'Add Multiple Team Calendar Events'
,p_alias=>'ADD-MULTIPLE-TEAM-CALENDAR-EVENTS'
,p_step_title=>'Add Multiple Team Calendar Events'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(48254527517432568655)
,p_step_template=>4075783602716660119
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(176220694375517839665)
,p_required_patch=>wwv_flow_imp.id(31743638170417552010)
,p_protection_level=>'C'
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(87794752092542198183)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_menu_id=>wwv_flow_imp.id(176220395320510839347)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(33518814892684200438)
,p_plug_name=>'Events'
,p_static_id=>'events'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4075786578761660127
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_header=>'This allows Administrators to add multiple, single-day events (such as holidays).'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(35903688399144405414)
,p_name=>'Events Recently Created'
,p_static_id=>'events-recently-created'
,p_template=>4075786578761660127
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--horizontalBorders'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select t.event_type, ',
'       e.event_date, ',
'       e.event_name,',
'       e.event_details,',
'       e.created',
'  from sp_events e,',
'       sp_event_types t',
' where e.event_type_id = t.id',
'   and e.created_by = :APP_USER',
'   and e.created > sysdate-1',
' order by e.created desc'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2542081983073888486
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(35903688894241405419)
,p_query_column_id=>5
,p_column_alias=>'CREATED'
,p_column_display_sequence=>50
,p_column_heading=>'Created'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(35903688553051405416)
,p_query_column_id=>2
,p_column_alias=>'EVENT_DATE'
,p_column_display_sequence=>20
,p_column_heading=>'Date'
,p_column_format=>'DD-Mon-YYYY'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(35903688722023405418)
,p_query_column_id=>4
,p_column_alias=>'EVENT_DETAILS'
,p_column_display_sequence=>40
,p_column_heading=>'Details'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(35903688626908405417)
,p_query_column_id=>3
,p_column_alias=>'EVENT_NAME'
,p_column_display_sequence=>30
,p_column_heading=>'Name'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(35903688471556405415)
,p_query_column_id=>1
,p_column_alias=>'EVENT_TYPE'
,p_column_display_sequence=>10
,p_column_heading=>'Type'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(67756963152731441496)
,p_plug_name=>'quick picks'
,p_static_id=>'quick-picks'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_landmark_type=>'exclude_landmark'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(141050652098356075717)
,p_plug_name=>'user timezone'
,p_static_id=>'user-timezone'
,p_parent_plug_id=>wwv_flow_imp.id(33518814892684200438)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>15
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'    select nvl(timezone,''UTC'') user_timezone',
'      from sp_team_members',
'     where id = :APP_USER_ID',
') loop',
'    sys.htp.p(''Your timezone is ''||apex_escape.html(c1.user_timezone)||''. This is set under your profile.'');',
'end loop;',
'',
'return null;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(35903687627614405407)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(87794752092542198183)
,p_button_name=>'CREATE_EVENTS'
,p_static_id=>'create-events'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Events'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(35890376063545148438)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(87794752092542198183)
,p_button_name=>'UP'
,p_static_id=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2352535364915922073
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:700:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(35903688266082405413)
,p_branch_name=>'Go To Page 709'
,p_branch_action=>'f?p=&APP_ID.:709:&SESSION.::&DEBUG.:709:P709_EVENT_TYPE:&P709_EVENT_TYPE.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35892851055967740255)
,p_name=>'P709_EVENT_DATE_1'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(33518814892684200438)
,p_prompt=>'Event Date'
,p_format_mask=>'DD-Mon-YYYY'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>15
,p_cMaxlength=>255
,p_field_template=>3034989574680570928
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33518815174472200441)
,p_name=>'P709_EVENT_DATE_2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(33518814892684200438)
,p_format_mask=>'DD-Mon-YYYY'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>15
,p_cMaxlength=>255
,p_field_template=>3034989309240569219
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33518815522549200445)
,p_name=>'P709_EVENT_DATE_3'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(33518814892684200438)
,p_prompt=>' '
,p_format_mask=>'DD-Mon-YYYY'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>15
,p_cMaxlength=>255
,p_field_template=>3034989309240569219
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33518815910209200449)
,p_name=>'P709_EVENT_DATE_4'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(33518814892684200438)
,p_prompt=>' '
,p_format_mask=>'DD-Mon-YYYY'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>15
,p_cMaxlength=>255
,p_field_template=>3034989309240569219
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35903687299801405403)
,p_name=>'P709_EVENT_DATE_5'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_imp.id(33518814892684200438)
,p_prompt=>' '
,p_format_mask=>'DD-Mon-YYYY'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>15
,p_cMaxlength=>255
,p_field_template=>3034989309240569219
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35893027753687396991)
,p_name=>'P709_EVENT_DETAILS_1'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(33518814892684200438)
,p_prompt=>'Details'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>3034989309240569219
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33518815356861200443)
,p_name=>'P709_EVENT_DETAILS_2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(33518814892684200438)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>3034989309240569219
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33518815766060200447)
,p_name=>'P709_EVENT_DETAILS_3'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(33518814892684200438)
,p_prompt=>' '
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>3034989309240569219
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35903687046177405401)
,p_name=>'P709_EVENT_DETAILS_4'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(33518814892684200438)
,p_prompt=>' '
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>3034989309240569219
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35903687449364405405)
,p_name=>'P709_EVENT_DETAILS_5'
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_imp.id(33518814892684200438)
,p_prompt=>' '
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_begin_on_new_line=>'N'
,p_field_template=>3034989309240569219
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35893019654817395271)
,p_name=>'P709_EVENT_NAME_1'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(33518814892684200438)
,p_prompt=>'Name'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>3034989574680570928
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33518815220287200442)
,p_name=>'P709_EVENT_NAME_2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(33518814892684200438)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>3034989309240569219
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33518815643589200446)
,p_name=>'P709_EVENT_NAME_3'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(33518814892684200438)
,p_prompt=>' '
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>3034989309240569219
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33518816091117200450)
,p_name=>'P709_EVENT_NAME_4'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(33518814892684200438)
,p_prompt=>' '
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>3034989309240569219
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35903687338163405404)
,p_name=>'P709_EVENT_NAME_5'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_imp.id(33518814892684200438)
,p_prompt=>' '
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>3034989309240569219
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35892845846367738280)
,p_name=>'P709_EVENT_TYPE'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(33518814892684200438)
,p_prompt=>'Type'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select event_type d, id r',
'  from sp_event_types',
' where general_event_yn = ''Y''',
'   and active_yn = ''Y''',
' order by event_type'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>3034989574680570928
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_quick_pick_type=>'STATIC'
,p_quick_pick_label_01=>'&P709_QP1.'
,p_quick_pick_value_01=>'&P709_QP1_ID.'
,p_quick_pick_label_02=>'&P709_QP2.'
,p_quick_pick_value_02=>'&P709_QP2_ID.'
,p_quick_pick_label_03=>'&P709_QP3.'
,p_quick_pick_value_03=>'&P709_QP3_ID.'
,p_quick_pick_label_04=>'&P709_QP4.'
,p_quick_pick_value_04=>'&P709_QP4_ID.'
,p_quick_pick_label_05=>'&P709_QP5.'
,p_quick_pick_value_05=>'&P709_QP5_ID.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71837759384197119028)
,p_name=>'P709_QP1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(67756963152731441496)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71837759558065119029)
,p_name=>'P709_QP1_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(67756963152731441496)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71837759716882119031)
,p_name=>'P709_QP2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(67756963152731441496)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71837759850647119032)
,p_name=>'P709_QP2_ID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(67756963152731441496)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71837759894443119033)
,p_name=>'P709_QP3'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(67756963152731441496)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71837759981475119034)
,p_name=>'P709_QP3_ID'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(67756963152731441496)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71837760152713119035)
,p_name=>'P709_QP4'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(67756963152731441496)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71837760195917119036)
,p_name=>'P709_QP4_ID'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(67756963152731441496)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71837760360901119037)
,p_name=>'P709_QP5'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(67756963152731441496)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(71837760433524119038)
,p_name=>'P709_QP5_ID'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(67756963152731441496)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(35890377089304148440)
,p_computation_sequence=>10
,p_computation_item=>'LAST_PROJECT_VIEW'
,p_static_id=>'last-project-view'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'142'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(35903688065992405411)
,p_validation_name=>'fifth'
,p_static_id=>'fifth'
,p_validation_sequence=>40
,p_validation=>':P709_EVENT_DATE_5 is not null and :P709_EVENT_NAME_5 is not null'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Must provide both date and name.'
,p_validation_condition=>':P709_EVENT_DATE_5 is not null or :P709_EVENT_NAME_5 is not null or :P709_EVENT_DETAILS_5 is not null'
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(35903687627614405407)
,p_associated_item=>wwv_flow_imp.id(35903687299801405403)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(35903687915954405410)
,p_validation_name=>'fourth event'
,p_static_id=>'fourth-event'
,p_validation_sequence=>30
,p_validation=>':P709_EVENT_DATE_4 is not null and :P709_EVENT_NAME_4 is not null'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Must provide both date and name.'
,p_validation_condition=>':P709_EVENT_DATE_4 is not null or :P709_EVENT_NAME_4 is not null or :P709_EVENT_DETAILS_4 is not null'
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(35903687627614405407)
,p_associated_item=>wwv_flow_imp.id(33518815910209200449)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(35903687759961405408)
,p_validation_name=>'second event'
,p_static_id=>'second-event'
,p_validation_sequence=>10
,p_validation=>':P709_EVENT_DATE_2 is not null and :P709_EVENT_NAME_2 is not null'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Must provide both date and name.'
,p_validation_condition=>':P709_EVENT_DATE_2 is not null or :P709_EVENT_NAME_2 is not null or :P709_EVENT_DETAILS_2 is not null'
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(35903687627614405407)
,p_associated_item=>wwv_flow_imp.id(33518815174472200441)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(35903687840906405409)
,p_validation_name=>'third event'
,p_static_id=>'third-event'
,p_validation_sequence=>20
,p_validation=>':P709_EVENT_DATE_3 is not null and :P709_EVENT_NAME_3 is not null'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Must provide both date and name.'
,p_validation_condition=>':P709_EVENT_DATE_3 is not null or :P709_EVENT_NAME_3 is not null or :P709_EVENT_DETAILS_3 is not null'
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(35903687627614405407)
,p_associated_item=>wwv_flow_imp.id(33518815522549200445)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(35903687522841405406)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'create'
,p_static_id=>'create'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P709_EVENT_DATE_1 is not null and',
'   :P709_EVENT_NAME_1 is not null',
'then',
'    sp_event_util.create_event ( ',
'        p_event_type_id  => :P709_EVENT_TYPE, ',
'        p_event_date     => to_date(:P709_EVENT_DATE_1,''DD-Mon-YYYY''), ',
'        p_event_name     => :P709_EVENT_NAME_1, ',
'        p_for_user_id    => null,',
'        p_event_details  => :P709_EVENT_DETAILS_1, ',
'        p_recur_freq     => null, ',
'        p_recur_end_date => null ); ',
'end if;',
'',
'if :P709_EVENT_DATE_2 is not null and',
'   :P709_EVENT_NAME_2 is not null',
'then',
'    sp_event_util.create_event ( ',
'        p_event_type_id  => :P709_EVENT_TYPE, ',
'        p_event_date     => to_date(:P709_EVENT_DATE_2,''DD-Mon-YYYY''), ',
'        p_event_name     => :P709_EVENT_NAME_2, ',
'        p_for_user_id    => null,',
'        p_event_details  => :P709_EVENT_DETAILS_2, ',
'        p_recur_freq     => null, ',
'        p_recur_end_date => null ); ',
'end if;',
'',
'if :P709_EVENT_DATE_3 is not null and',
'   :P709_EVENT_NAME_3 is not null',
'then',
'    sp_event_util.create_event ( ',
'        p_event_type_id  => :P709_EVENT_TYPE, ',
'        p_event_date     => to_date(:P709_EVENT_DATE_3,''DD-Mon-YYYY''), ',
'        p_event_name     => :P709_EVENT_NAME_3, ',
'        p_for_user_id    => null,',
'        p_event_details  => :P709_EVENT_DETAILS_3, ',
'        p_recur_freq     => null, ',
'        p_recur_end_date => null ); ',
'end if;',
'',
'if :P709_EVENT_DATE_4 is not null and',
'   :P709_EVENT_NAME_4 is not null',
'then',
'    sp_event_util.create_event ( ',
'        p_event_type_id  => :P709_EVENT_TYPE, ',
'        p_event_date     => to_date(:P709_EVENT_DATE_4,''DD-Mon-YYYY''), ',
'        p_event_name     => :P709_EVENT_NAME_4, ',
'        p_for_user_id    => null,',
'        p_event_details  => :P709_EVENT_DETAILS_4, ',
'        p_recur_freq     => null, ',
'        p_recur_end_date => null ); ',
'end if;',
'',
'if :P709_EVENT_DATE_5 is not null and',
'   :P709_EVENT_NAME_5 is not null',
'then',
'    sp_event_util.create_event ( ',
'        p_event_type_id  => :P709_EVENT_TYPE, ',
'        p_event_date     => to_date(:P709_EVENT_DATE_5,''DD-Mon-YYYY''), ',
'        p_event_name     => :P709_EVENT_NAME_5, ',
'        p_for_user_id    => null,',
'        p_event_details  => :P709_EVENT_DETAILS_5, ',
'        p_recur_freq     => null, ',
'        p_recur_end_date => null ); ',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(35903687627614405407)
,p_process_when=>'P709_EVENT_TYPE'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>'Event(s) created.'
,p_internal_uid=>35903687522841405406
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(35933891040384364379)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Quick Picks'
,p_static_id=>'load-quick-picks'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_cnt  number := 1;',
'begin',
'',
'for c1 in (',
'    select event_type, id',
'      from sp_event_types',
'     where active_yn = ''Y''',
'       and general_event_yn = ''Y''',
'       and quick_pick_yn = ''Y''',
'      order by event_type desc',
') loop',
'    if l_cnt = 1 then',
'        :P709_QP1    := c1.event_type;',
'        :P709_QP1_ID := c1.id;',
'    elsif l_cnt = 2 then',
'        :P709_QP2    := c1.event_type;',
'        :P709_QP2_ID := c1.id;',
'    elsif l_cnt = 3 then',
'        :P709_QP3    := c1.event_type;',
'        :P709_QP3_ID := c1.id;',
'    elsif l_cnt = 4 then',
'        :P709_QP4    := c1.event_type;',
'        :P709_QP4_ID := c1.id;',
'    elsif l_cnt = 5 then',
'        :P709_QP5    := c1.event_type;',
'        :P709_QP5_ID := c1.id;',
'    end if;',
'',
'    l_cnt := l_cnt + 1;',
'end loop;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>35933891040384364379
);
wwv_flow_imp.component_end;
end;
/
