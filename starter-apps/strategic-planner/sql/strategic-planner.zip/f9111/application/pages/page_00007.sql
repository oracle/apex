prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Comments Filter Report'
,p_alias=>'COMMENTS-FILTER-REPORT'
,p_step_title=>'Comments Filter Report'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(45065119564448640164)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.no-item-ui {',
'  --a-field-input-border-width: 0px;',
'  --a-field-input-background-color: transparent;',
'}',
'',
'.overline {',
'  color: var(--ut-region-text-color, var(--ut-component-text-default-color));',
'}',
'',
'.t-Comments-comment img {',
'  max-width: 750px; ',
'  height: auto;',
'}'))
,p_step_template=>2530071015796209513
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'22'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(161773482140284199025)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_plug_template=>2534890969069732905
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_menu_id=>wwv_flow_imp.id(176220395320510839347)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4075790987805660140
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(46718666254238782543)
,p_plug_name=>'Facets'
,p_static_id=>'facets'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>810
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(42135803252402193047)
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'batch_facet_search', 'N',
  'compact_numbers_threshold', '10000',
  'display_chart_for_top_n_values', '10',
  'show_charts', 'Y',
  'show_current_facets', 'N',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46718666426871782545)
,p_name=>'P7_AREA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(46718666254238782543)
,p_prompt=>'&NOMENCLATURE_AREA.'
,p_source=>'AREA'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46718666877725782549)
,p_name=>'P7_AUTHOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(46718666254238782543)
,p_prompt=>'Author'
,p_source=>'AUTHOR'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42496120728745588542)
,p_name=>'P7_COMMENT_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(46718666254238782543)
,p_prompt=>'Comment Type'
,p_source=>'COMMENT_TYPE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46718667073354782551)
,p_name=>'P7_CREATED_YYYYMM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(46718666254238782543)
,p_prompt=>'Month'
,p_source=>'CREATED_YYYYMM'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'DESC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46718666530745782546)
,p_name=>'P7_INITIATIVE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(46718666254238782543)
,p_prompt=>'&NOMENCLATURE_INITIATIVE.'
,p_source=>'INITIATIVE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>5
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>true
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40905601199992920442)
,p_name=>'P7_PRIVATE_YN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(46718666254238782543)
,p_prompt=>'My Private'
,p_source=>'PRIVATE_YN'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_display_as=>'INLINE'
,p_fc_exclude_allowed=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46718666304086782544)
,p_name=>'P7_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(46718666254238782543)
,p_prompt=>'Search'
,p_source=>'CONTEXT,BODY'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'input_field', 'FACET',
  'search_type', 'ROW')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(42135803252402193047)
,p_name=>'&NOMENCLATURE_PROJECT. Comments'
,p_static_id=>'nomenclature-project-comments'
,p_region_name=>'COMMENTS'
,p_template=>2103954283454391425
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Comments--chat:t-Comments--iconsRounded'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'       initials user_icon,',
'       created comment_date,',
'       author user_name,',
'       '''' attribute_1,',
'       '''' attribute_2,',
'       '''' attribute_3,',
'       '''' attribute_4,',
'       --',
'       comment_nbr,',
'       body_html comment_text,',
'       case when private_act_yn = ''Y'' then '' Private Activity''',
'            else decode(private_yn,''Yes'','' Private Comment'',null) ',
'            end private_comment_label,',
'       action actions,',
'       comment_type,',
'       area,',
'       initiative,',
'       release,',
'       author,',
'       private_yn,',
'       created_yyyyMM,',
'       context,',
'       body',
'from (',
'select :NOMENCLATURE_PROJECT comment_type,',
'       ''project'' internal_type,',
'       a.area,',
'       i.id initiative_id,',
'       i.initiative,',
'       null release_id,',
'       '''' Release,',
'       c.PROJECT_ID,',
'       p.project,',
'       null task_id,',
'       p.project context,',
'       c.comment_nbr,',
'       c.body_no_images body,',
'       c.body_html,',
'       nvl((select first_name||'' ''||last_name from sp_team_members tm where tm.id = c.author_id),''system'') author,',
'       (select initials from sp_team_members tm where tm.id = c.author_id) initials,',
'       c.AUTHOR_ID,',
'       c.CREATED,',
'       to_char(c.created,''YYYY.MM'') created_yyyyMM,',
'       decode(nvl(c.private_yn,''N''),''N'',''No'',''Y'',''Yes'',''Unknown'') private_yn,',
'       null private_act_yn,',
'       :NOMENCLATURE_PROJECT||'': ''||',
'           ''<a href="''|| apex_page.get_url (',
'                             p_page   => 3,',
'                             p_clear_cache => 3,',
'                             p_items  => ''P3_PROJECT_ID'',',
'                             p_values => p.id ) || ''">''||apex_escape.html(p.project)||''</a>'' action',
'  from SP_PROJECT_COMMENTS_V c,',
'       sp_projects p,',
'       sp_initiatives i,',
'       sp_areas a ',
' where c.author_id is not null and',
'       p.id = c.project_id and',
'       p.initiative_id = i.id and',
'       i.area_id = a.id and',
'       p.DUPLICATE_OF_PROJECT_ID is null and',
'       p.ARCHIVED_YN = ''N'' and ',
'       (nvl(c.private_yn,''N'') = ''N'' or lower(c.created_by) = lower(:app_user) )',
' union all',
'select :NOMENCLATURE_INITIATIVE comment_type,',
'       ''initiative'' internal_type,',
'       a.area,',
'       i.id initiative_id,',
'       i.initiative,',
'       null release_id,',
'       '''' Release,',
'       null PROJECT_ID,',
'       '''' project,',
'       null task_id,',
'       i.initiative context,',
'       c.comment_nbr,',
'       c.body_no_images body,',
'       c.body_html,',
'       (select first_name||'' ''||last_name from sp_team_members tm where tm.id = c.author_id) author,',
'       (select initials from sp_team_members tm where tm.id = c.author_id) initials,',
'       c.AUTHOR_ID,',
'       c.CREATED,',
'       to_char(c.created,''YYYY.MM'') created_yyyyMM,',
'       decode(nvl(c.private_yn,''N''),''N'',''No'',''Y'',''Yes'',''Unknown'') private_yn,',
'       null private_act_yn,',
'       :NOMENCLATURE_INITIATIVE||'': ''||',
'           ''<a href="''|| apex_page.get_url (',
'                             p_page   => 94,',
'                             p_clear_cache => 94,',
'                             p_items  => ''P94_INITIATIVE_ID'',',
'                             p_values => i.id ) || ''">''||apex_escape.html(i.initiative)||''</a>'' action',
'from SP_INITIATIVE_COMMENTS_V c,',
'     sp_initiatives i,',
'     sp_areas a ',
' where c.author_id is not null and',
'       c.initiative_id = i.id and',
'       i.area_id = a.id and',
'       (nvl(c.private_yn,''N'') = ''N'' or lower(c.created_by) = lower(:app_user) )',
'union all',
'select ''Release'' comment_type,',
'       ''release'' internal_type,',
'       '''' area,',
'       null initiative_id,',
'       '''' initiative,',
'       r.id release_id,',
'       r.release_train||'' ''||r.release release,',
'       null PROJECT_ID,',
'       '''' project,',
'       null task_id,',
'       r.release_train||'' ''||r.release context,',
'       c.comment_nbr,',
'       c.body_no_images body,',
'       c.body_html,',
'       (select first_name||'' ''||last_name from sp_team_members tm where tm.id = c.author_id) author,',
'       (select initials from sp_team_members tm where tm.id = c.author_id) initials,',
'       c.AUTHOR_ID,',
'       c.CREATED,',
'       to_char(c.created,''YYYY.MM'') created_yyyyMM,',
'       decode(nvl(c.private_yn,''N''),''N'',''No'',''Y'',''Yes'',''Unknown'') private_yn,',
'       null private_act_yn,',
'       ''Release: ''||',
'           ''<a href="''||apex_page.get_url (',
'                             p_page   => 117,',
'                             p_clear_cache => 117,',
'                             p_items  => ''P117_RELEASE_ID'',',
'                             p_values => r.id ) ||''">''||apex_escape.html(r.release_train||'' ''||release)||''</a>'' action',
'  from SP_RELEASE_COMMENTS_V c,',
'       sp_release_trains r',
' where c.release_id = r.id and',
'       c.author_id is not null and',
'       (nvl(c.private_yn,''N'') = ''N'' or lower(c.created_by) = lower(:app_user) )',
'union all',
'select ''Task'' comment_type,',
'       ''task'' internal_type,',
'       a.area,',
'       i.id initiative_id,',
'       i.initiative,',
'       p.release_id release_id,',
'       case when p.release_id is not null',
'            then (select release_train||'' ''|| release from sp_release_trains where id = p.release_id)',
'            end Release,',
'       t.PROJECT_ID,',
'       p.project,',
'       t.id task_id,',
'       (select task_type from sp_task_types rt where rt.id = t.task_type_id)||',
'           case when t.task_sub_type_id is not null then '': '' end ||',
'           (select task_type from sp_task_types rt where rt.id = t.task_sub_type_id) ||',
'           case when t.task is not null then '' - ''||t.task end context,',
'       c.comment_nbr,',
'       c.body_no_images body,',
'       c.body_html,',
'       (select first_name||'' ''||last_name from sp_team_members tm where tm.id = c.author_id) author,',
'       (select initials from sp_team_members tm where tm.id = c.author_id) initials,',
'       c.AUTHOR_ID,',
'       c.CREATED,',
'       to_char(c.created,''YYYY.MM'') created_yyyyMM,',
'       decode(nvl(c.private_yn,''N''),''N'',''No'',''Y'',''Yes'',''Unknown'') private_yn,',
'       null private_act_yn,',
'       ''<a href="''||apex_page.get_url (',
'                             p_page   => 502,',
'                             p_clear_cache => 502,',
'                             p_items  => ''P502_PREV_PAGE,P502_PROJECT_ID,P502_TASK_ID'',',
'                             p_values => ''3,''||p.id||'',''||t.id )||''">''||',
'           (select apex_escape.html(task_type) from sp_task_types rt where rt.id = t.task_type_id)||',
'           case when t.task_sub_type_id is not null then '': '' end ||',
'           (select apex_escape.html(task_type) from sp_task_types rt where rt.id = t.task_sub_type_id) ||',
'           case when t.task is not null then '' - ''||apex_escape.html(t.task) end ||''</a>'' action',
'  from SP_TASK_COMMENTS_V c,',
'       sp_tasks t,',
'       sp_projects p,',
'       sp_initiatives i,',
'       sp_areas a ',
' where c.author_id is not null and',
'       t.id = c.task_id and',
'       t.project_id = p.id and',
'       p.initiative_id = i.id and',
'       i.area_id = a.id and',
'       p.DUPLICATE_OF_PROJECT_ID is null and',
'       p.ARCHIVED_YN = ''N'' and ',
'       (nvl(c.private_yn,''N'') = ''N'' or lower(c.created_by) = lower(:APP_USER) )',
'union all',
'select ''Activity'' comment_type,',
'       ''activity'' internal_type,',
'       case when t.initiative_id is not null',
'            then (select a2.area from sp_areas a2, sp_initiatives i2 where i2.id = t.initiative_id and i2.area_id = a2.id)',
'            else a.area',
'            end area,',
'       nvl(i.id,t.initiative_id) initiative_id,',
'       case when t.initiative_id is not null',
'            then (select initiative from sp_initiatives where id = t.initiative_id)',
'            else i.initiative',
'            end initiative,',
'       p.release_id,',
'       case when p.release_id is not null',
'            then (select release_train||'' ''|| release from sp_release_trains where id = p.release_id)',
'            end Release,',
'       t.PROJECT_ID,',
'       p.project,',
'       null task_id,',
'       t.activity context,',
'       c.comment_nbr,',
'       c.body_no_images body,',
'       c.body_html,',
'       (select first_name||'' ''||last_name from sp_team_members tm where tm.id = c.author_id) author,',
'       (select initials from sp_team_members tm where tm.id = c.author_id) initials,',
'       c.AUTHOR_ID,',
'       c.CREATED,',
'       to_char(c.created,''YYYY.MM'') created_yyyyMM,',
'       decode(nvl(c.private_yn,''N''),''N'',''No'',''Y'',''Yes'',''Unknown'') private_yn,',
'       t.private_yn private_act_yn,',
'       ''<a href="''||apex_page.get_url (',
'                             p_page   => 129, ',
'                             p_clear_cache => 129,',
'                             p_items  => ''P129_ACTIVITY_ID'',',
'                             p_values => t.id )||''">''||',
'           apex_escape.html(t.activity) ||''</a>'' action',
'  from SP_ACTIVITY_COMMENTS c,',
'       sp_activities t,',
'       sp_projects p,',
'       sp_initiatives i,',
'       sp_areas a ',
' where t.id = c.activity_id and',
'       (nvl(t.private_yn,''N'') = ''N'' or t.team_member_id = :APP_USER_ID) and',
'       c.author_id is not null and',
'       t.project_id = p.id (+) and',
'       p.initiative_id = i.id (+) and',
'       i.area_id = a.id (+) and',
'       p.DUPLICATE_OF_PROJECT_ID is null and',
'       nvl(p.ARCHIVED_YN,''N'') = ''N'' and ',
'       (nvl(c.private_yn,''N'') = ''N'' or lower(c.created_by) = lower(:APP_USER) )',
') order by comment_date desc'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2616596457966365047
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No Comments'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42135805390691193069)
,p_query_column_id=>11
,p_column_alias=>'ACTIONS'
,p_column_display_sequence=>60
,p_column_heading=>'Actions'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42135805832720193073)
,p_query_column_id=>13
,p_column_alias=>'AREA'
,p_column_display_sequence=>100
,p_column_heading=>'Area'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42135805191954193067)
,p_query_column_id=>4
,p_column_alias=>'ATTRIBUTE_1'
,p_column_display_sequence=>40
,p_column_heading=>'Attribute 1'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42135805554549193070)
,p_query_column_id=>5
,p_column_alias=>'ATTRIBUTE_2'
,p_column_display_sequence=>70
,p_column_heading=>'Attribute 2'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42135805639222193071)
,p_query_column_id=>6
,p_column_alias=>'ATTRIBUTE_3'
,p_column_display_sequence=>80
,p_column_heading=>'Attribute 3'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42135805717342193072)
,p_query_column_id=>7
,p_column_alias=>'ATTRIBUTE_4'
,p_column_display_sequence=>90
,p_column_heading=>'Attribute 4'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42135806136518193076)
,p_query_column_id=>16
,p_column_alias=>'AUTHOR'
,p_column_display_sequence=>130
,p_column_heading=>'Author'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42135806839540193083)
,p_query_column_id=>20
,p_column_alias=>'BODY'
,p_column_display_sequence=>200
,p_column_heading=>'Body'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42135805042312193065)
,p_query_column_id=>2
,p_column_alias=>'COMMENT_DATE'
,p_column_display_sequence=>20
,p_column_heading=>'Comment Date'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(39222946417013272921)
,p_query_column_id=>8
,p_column_alias=>'COMMENT_NBR'
,p_column_display_sequence=>210
,p_column_heading=>'Comment Nbr'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42135805350691193068)
,p_query_column_id=>9
,p_column_alias=>'COMMENT_TEXT'
,p_column_display_sequence=>50
,p_column_heading=>'Comment Text'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="is-markdownified">',
'{if PRIVATE_COMMENT_LABEL/}<strong class="u-danger-text">#PRIVATE_COMMENT_LABEL#</strong><br />{endif/}',
'#COMMENT_TEXT#',
'</div>'))
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42135806469609193079)
,p_query_column_id=>12
,p_column_alias=>'COMMENT_TYPE'
,p_column_display_sequence=>160
,p_column_heading=>'Comment Type'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42135806735944193082)
,p_query_column_id=>19
,p_column_alias=>'CONTEXT'
,p_column_display_sequence=>190
,p_column_heading=>'Context'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42135806580691193080)
,p_query_column_id=>18
,p_column_alias=>'CREATED_YYYYMM'
,p_column_display_sequence=>170
,p_column_heading=>'Created Yyyymm'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42135805889772193074)
,p_query_column_id=>14
,p_column_alias=>'INITIATIVE'
,p_column_display_sequence=>110
,p_column_heading=>'Initiative'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42135806662137193081)
,p_query_column_id=>10
,p_column_alias=>'PRIVATE_COMMENT_LABEL'
,p_column_display_sequence=>180
,p_column_heading=>'Private Comment Label'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42135806199605193077)
,p_query_column_id=>17
,p_column_alias=>'PRIVATE_YN'
,p_column_display_sequence=>140
,p_column_heading=>'Private Yn'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42135806042062193075)
,p_query_column_id=>15
,p_column_alias=>'RELEASE'
,p_column_display_sequence=>120
,p_column_heading=>'Release'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42135804894505193064)
,p_query_column_id=>1
,p_column_alias=>'USER_ICON'
,p_column_display_sequence=>10
,p_column_heading=>'User Icon'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(42135805105760193066)
,p_query_column_id=>3
,p_column_alias=>'USER_NAME'
,p_column_display_sequence=>30
,p_column_heading=>'User Name'
,p_column_html_expression=>'Comment #COMMENT_NBR#, #USER_NAME#'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(24164215684678003584)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(161773482140284199025)
,p_button_name=>'Reset'
,p_static_id=>'reset'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2086257187394300437
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:7::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46718363795370771931)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(161773482140284199025)
,p_button_name=>'UP'
,p_static_id=>'up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2352535364915922073
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(25422422059101485343)
,p_name=>'links in comments in new tab'
,p_static_id=>'links-in-comments-in-new-tab'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(25422422179259485344)
,p_event_id=>wwv_flow_imp.id(25422422059101485343)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    '$(''#COMMENTS a'')',
    '  .not(''[href*="#action$a-dialog-open"]'')',
    '  .attr(''target'', ''_blank'');')))).to_clob
,p_da_action_comment=>'$(''#COMMENTS a'').attr(''target'',''_blank'');'
);
wwv_flow_imp.component_end;
end;
/
