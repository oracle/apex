prompt --application/pages/page_00704
begin
--   Manifest
--     PAGE: 00704
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>704
,p_name=>'Out of Office Details'
,p_alias=>'OOO-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Out of Office Details'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>1664614232864994871
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_required_patch=>wwv_flow_imp.id(31743638170417552010)
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(36435158931680209638)
,p_plug_name=>'audit info'
,p_static_id=>'audit-info'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>60
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sys.htp.p(''<br/>created by ''||apex_escape.html(lower(:P704_CREATED_BY))||'' ''||apex_escape.html(:P704_CREATED_SINCE));',
'',
'if :P704_CREATED_SINCE != :P704_UPDATED_SINCE then',
'    sys.htp.p(''<br/>last updated by ''||apex_escape.html(lower(:P704_UPDATED_BY))||'' ''||apex_escape.html(:P704_UPDATED_SINCE));',
'end if;',
'',
'return null;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P704_ID is not null and',
'(:P704_CREATED_BY != :APP_USER or',
' :P704_UPDATED_BY != :APP_USER)'))
,p_plug_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31822901655391727904)
,p_plug_name=>'Buttons'
,p_static_id=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_plug_template=>2129856781885180476
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31822893083391727893)
,p_plug_name=>'Event Details'
,p_static_id=>'event-details'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'N'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'TABLE'
,p_query_table=>'SP_EVENTS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_headings_type=>'COLON_DELMITED_LIST'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31820573427083549723)
,p_plug_name=>'recurrence'
,p_static_id=>'recurrence'
,p_parent_plug_id=>wwv_flow_imp.id(31822893083391727893)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31820573324316549722)
,p_plug_name=>'region 1'
,p_static_id=>'region'
,p_parent_plug_id=>wwv_flow_imp.id(31822893083391727893)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31820573539444549724)
,p_plug_name=>'region 4'
,p_static_id=>'region-2'
,p_parent_plug_id=>wwv_flow_imp.id(31822893083391727893)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(69330154808598035094)
,p_plug_name=>'user timezone'
,p_static_id=>'user-timezone'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3374665444246510938
,p_plug_display_sequence=>50
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'    select nvl(timezone,''UTC'') user_timezone',
'      from sp_team_members',
'     where id = :APP_USER_ID',
') loop',
'    sys.htp.p(''Your timezone is ''||apex_escape.html(c1.user_timezone)||''. This is set under your profile.'');',
'end loop;',
'',
'return null;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(31822902040631727905)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(31822901655391727904)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(31822904494297727908)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(31822901655391727904)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P704_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(31842514739655726836)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(31822901655391727904)
,p_button_name=>'DELETE_RECUR'
,p_static_id=>'delete-recur'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_redirect_url=>'f?p=&APP_ID.:706:&SESSION.::&DEBUG.:706:P706_EVENT_ID:&P704_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P704_ID is not null and',
':P704_SERIES_ID is not null'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(31822903501771727907)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(31822901655391727904)
,p_button_name=>'DELETE_SINGLE'
,p_static_id=>'delete-single'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P704_ID is not null and',
':P704_SERIES_ID is null'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(31842515772070726846)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(31822901655391727904)
,p_button_name=>'SAVE_RECUR'
,p_static_id=>'save-recur'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P704_ID is not null and',
':P704_SERIES_ID is not null'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(31822904023316727908)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(31822901655391727904)
,p_button_name=>'SAVE_SINGLE'
,p_static_id=>'save-single'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P704_ID is not null and',
':P704_SERIES_ID is null'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(31842515807548726847)
,p_branch_name=>'Update, recurring, other than just date change'
,p_branch_action=>'f?p=&APP_ID.:705:&SESSION.::&DEBUG.:705:P705_EVENT_ID:&P704_ID.'
,p_branch_point=>'BEFORE_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(31842515772070726846)
,p_branch_sequence=>10
,p_branch_condition_type=>'EXISTS'
,p_branch_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from sp_events e,',
'       sp_event_series s',
' where e.id = :P704_ID',
'   and e.series_id = s.id',
'   and :P704_RECURS = ''Y''',
'   and --( e.event_type_id != :P704_EVENT_TYPE_ID or',
'        -- nvl(e.event_name,''~'') != nvl(:P704_EVENT_NAME,''~'') or',
'        -- nvl(e.event_details,''~'') != nvl(:P704_EVENT_DETAILS,''~'') or',
'         s.recur_freq != nvl(:P704_RECUR_FREQ,''~'') --)'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31822897165476727900)
,p_name=>'P704_CREATED_BY'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(31820573539444549724)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31822896771393727900)
,p_name=>'P704_CREATED_SINCE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(31820573539444549724)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31820571656566549705)
,p_name=>'P704_END_DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(31820573427083549723)
,p_prompt=>'End Date'
,p_format_mask=>'DD-Mon-YYYY'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>1612549789555753698
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'ITEM',
  'min_item', 'P704_START_DATE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31822894445821727897)
,p_name=>'P704_EVENT_DATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(31820573324316549722)
,p_prompt=>'Event Date'
,p_format_mask=>'DD-Mon-YYYY'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>1612549789555753698
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31822895669035727899)
,p_name=>'P704_EVENT_DETAILS'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(31820573539444549724)
,p_prompt=>'Event Details'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31820575441014549743)
,p_name=>'P704_EVENT_FOR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(31820573539444549724)
,p_item_default=>'M'
,p_prompt=>'Event For'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'P704_EVENT_FOR'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31822894809247727898)
,p_name=>'P704_EVENT_NAME'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(31820573539444549724)
,p_prompt=>'Event Name'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31822893727326727894)
,p_name=>'P704_EVENT_TYPE_ID'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(31820573324316549722)
,p_prompt=>'Event Type'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select event_type d, id r   ',
'  from sp_event_types',
' where active_yn = ''Y''',
'    or :P704_EVENT_TYPE_ID = id    ',
' order by event_type'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1612549789555753698
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_quick_pick_type=>'STATIC'
,p_quick_pick_label_01=>'&P704_QP1.'
,p_quick_pick_value_01=>'&P704_QP1_ID.'
,p_quick_pick_label_02=>'&P704_QP2.'
,p_quick_pick_value_02=>'&P704_QP2_ID.'
,p_quick_pick_label_03=>'&P704_QP3.'
,p_quick_pick_value_03=>'&P704_QP3_ID.'
,p_quick_pick_label_04=>'&P704_QP4.'
,p_quick_pick_value_04=>'&P704_QP4_ID.'
,p_quick_pick_label_05=>'&P704_QP5.'
,p_quick_pick_value_05=>'&P704_QP5_ID.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31822895274622727898)
,p_name=>'P704_FOR_USER_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(31820573539444549724)
,p_prompt=>'For Team Member'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_ONE'
,p_named_lov=>'SP_TEAM_MEMBERS - CURRENT ONLY'
,p_cSize=>30
,p_read_only_when=>'not apex_authorization.is_authorized(''Contribution Rights'')'
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'fetch_on_search', 'N',
  'infinite_scroll', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31820574982022549738)
,p_name=>'P704_GENERAL_EVENT_YN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(31820573324316549722)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31822893377356727893)
,p_name=>'P704_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(31820573324316549722)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(33518813545603200425)
,p_name=>'P704_PREVIOUS_FOR_USER_ID'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(31820573539444549724)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35903689006147405421)
,p_name=>'P704_QP1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(31822893083391727893)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35903689180015405422)
,p_name=>'P704_QP1_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(31822893083391727893)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35903689338832405424)
,p_name=>'P704_QP2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(31822893083391727893)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35903689472597405425)
,p_name=>'P704_QP2_ID'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(31822893083391727893)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35903689516393405426)
,p_name=>'P704_QP3'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(31822893083391727893)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35903689603425405427)
,p_name=>'P704_QP3_ID'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(31822893083391727893)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35903689774663405428)
,p_name=>'P704_QP4'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(31822893083391727893)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35903689817867405429)
,p_name=>'P704_QP4_ID'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(31822893083391727893)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35903689982851405430)
,p_name=>'P704_QP5'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(31822893083391727893)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(35903690055474405431)
,p_name=>'P704_QP5_ID'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(31822893083391727893)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31820573678799549725)
,p_name=>'P704_RECURS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(31820573324316549722)
,p_prompt=>'Repeats?'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31820571546707549704)
,p_name=>'P704_RECUR_FREQ'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(31820573427083549723)
,p_prompt=>'Repeats'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'EVENT RECURRENCE'
,p_cHeight=>1
,p_field_template=>1612549609962752680
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31822896039744727899)
,p_name=>'P704_SERIES_ID'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(31820573539444549724)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31820573279565549721)
,p_name=>'P704_START_DATE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(31820573427083549723)
,p_prompt=>'Start Date'
,p_format_mask=>'DD-Mon-YYYY'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>1612549789555753698
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31822897987174727901)
,p_name=>'P704_UPDATED_BY'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(31820573539444549724)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(31822897507891727901)
,p_name=>'P704_UPDATED_SINCE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(31820573539444549724)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(31842511859492726807)
,p_validation_name=>'end date when not recur'
,p_static_id=>'end-date-when-not-recur'
,p_validation_sequence=>30
,p_validation=>'P704_EVENT_DATE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Event date must be provided.'
,p_validation_condition=>'P704_RECURS'
,p_validation_condition2=>'N'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_associated_item=>wwv_flow_imp.id(31822894445821727897)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(31820572155634549710)
,p_validation_name=>'if event_for E (someone else), must select person'
,p_static_id=>'if-event-for-e-someone-else-must-select-person'
,p_validation_sequence=>10
,p_validation=>'P704_FOR_USER_ID'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Must provide user for this event.'
,p_validation_condition=>'P704_EVENT_FOR'
,p_validation_condition2=>'E'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_associated_item=>wwv_flow_imp.id(31822895274622727898)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(39222947783878272934)
,p_validation_name=>'if general event and for all - must enter event name'
,p_static_id=>'if-general-event-and-for-all-must-enter-event-name'
,p_validation_sequence=>40
,p_validation=>'P704_EVENT_NAME'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Must provide Event Name for this type of event'
,p_validation_condition=>':P704_GENERAL_EVENT_YN = ''Y'' and :P704_EVENT_FOR = ''A'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_associated_item=>wwv_flow_imp.id(31822894809247727898)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(31820576150953549750)
,p_validation_name=>'start and end for recur'
,p_static_id=>'start-and-end-for-recur'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P704_START_DATE is not null and',
':P704_END_DATE is not null'))
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Start and End Dates must be provided for recurring events.'
,p_validation_condition=>'P704_RECURS'
,p_validation_condition2=>'Y'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(31822902126530727905)
,p_name=>'Cancel Dialog'
,p_static_id=>'cancel-dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(31822902040631727905)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31822903012349727906)
,p_event_id=>wwv_flow_imp.id(31822902126530727905)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-dialog-cancel'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(31820574697787549735)
,p_name=>'change event type'
,p_static_id=>'change-event-type'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P704_EVENT_TYPE_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31820574834986549737)
,p_event_id=>wwv_flow_imp.id(31820574697787549735)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'fetch GENERAL_YN'
,p_static_id=>'fetch-general-yn'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P704_GENERAL_EVENT_YN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'escape_special_characters', 'Y',
  'items_to_submit', 'P704_EVENT_TYPE_ID',
  'sql_query', wwv_flow_string.join(wwv_flow_t_varchar2(
    'select general_event_yn',
    '  from sp_event_types',
    ' where id = :P704_EVENT_TYPE_ID')),
  'suppress_change_event', 'N',
  'type', 'SQL_STATEMENT')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31820575031646549739)
,p_event_id=>wwv_flow_imp.id(31820574697787549735)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'Y'
,p_name=>'hide event name when not general'
,p_static_id=>'hide-event-name-when-not-general'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P704_EVENT_NAME'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P704_GENERAL_EVENT_YN'
,p_client_condition_expression=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33518813102820200421)
,p_event_id=>wwv_flow_imp.id(31820574697787549735)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_name=>'refresh for (to refresh lov)'
,p_static_id=>'refresh-for-to-refresh-lov'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P704_EVENT_FOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(33518813284814200422)
,p_event_id=>wwv_flow_imp.id(31820574697787549735)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'set P704_GENERAL_EVENT_YN on server'
,p_static_id=>'set-p704-general-event-yn-on-server'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'items_to_submit', 'P704_GENERAL_EVENT_YN',
  'language', 'PLSQL',
  'plsql_code', 'null;',
  'show_processing', 'N')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31820575818044549747)
,p_event_id=>wwv_flow_imp.id(31820574697787549735)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'Y'
,p_name=>'show event_for, if event_for O'
,p_static_id=>'show-event-for-if-event-for-o'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P704_EVENT_FOR'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P704_EVENT_TYPE_ID'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31820574735232549736)
,p_event_id=>wwv_flow_imp.id(31820574697787549735)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'Y'
,p_name=>'show event name for general'
,p_static_id=>'show-event-name-for-general'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P704_EVENT_NAME'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P704_GENERAL_EVENT_YN'
,p_client_condition_expression=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(31820573909474549728)
,p_name=>'change recur'
,p_static_id=>'change-recur'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P704_RECURS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31820574218384549731)
,p_event_id=>wwv_flow_imp.id(31820573909474549728)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_name=>'hide event date for recur'
,p_static_id=>'hide-event-date-for-recur'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P704_EVENT_DATE'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P704_RECURS'
,p_client_condition_expression=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31820574163682549730)
,p_event_id=>wwv_flow_imp.id(31820573909474549728)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_name=>'hide recurrence when not recur'
,p_static_id=>'hide-recurrence-when-not-recur'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(31820573427083549723)
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P704_RECURS'
,p_client_condition_expression=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31842513568076726824)
,p_event_id=>wwv_flow_imp.id(31820573909474549728)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_name=>'set event date when not recur'
,p_static_id=>'set-event-date-when-not-recur'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P704_EVENT_DATE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'escape_special_characters', 'Y',
  'items_to_submit', 'P704_EVENT_DATE,P704_START_DATE',
  'plsql_expression', 'nvl(v(''P704_EVENT_DATE''),v(''P704_START_DATE''))',
  'suppress_change_event', 'N',
  'type', 'PLSQL_EXPRESSION')).to_clob
,p_wait_for_result=>'Y'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P704_RECURS'
,p_client_condition_expression=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31842513286818726821)
,p_event_id=>wwv_flow_imp.id(31820573909474549728)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_name=>'set start date for recur'
,p_static_id=>'set-start-date-for-recur'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P704_START_DATE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'escape_special_characters', 'Y',
  'items_to_submit', 'P704_START_DATE,P704_EVENT_DATE',
  'plsql_expression', 'nvl(v(''P704_START_DATE''),v(''P704_EVENT_DATE''))',
  'suppress_change_event', 'N',
  'type', 'PLSQL_EXPRESSION')).to_clob
,p_wait_for_result=>'Y'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P704_RECURS'
,p_client_condition_expression=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31820574365525549732)
,p_event_id=>wwv_flow_imp.id(31820573909474549728)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_name=>'show event date when not recur'
,p_static_id=>'show-event-date-when-not-recur'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P704_EVENT_DATE'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P704_RECURS'
,p_client_condition_expression=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31820574041080549729)
,p_event_id=>wwv_flow_imp.id(31820573909474549728)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'show recurrence details for recur'
,p_static_id=>'show-recurrence-details-for-recur'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(31820573427083549723)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P704_RECURS'
,p_client_condition_expression=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(31820573770090549726)
,p_name=>'hide by default'
,p_static_id=>'hide-by-default'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31820573808098549727)
,p_event_id=>wwv_flow_imp.id(31820573770090549726)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(31820573427083549723)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31820575105580549740)
,p_event_id=>wwv_flow_imp.id(31820573770090549726)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_static_id=>'native-hide-2'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P704_EVENT_NAME'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31820576032520549749)
,p_event_id=>wwv_flow_imp.id(31820573770090549726)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_static_id=>'native-hide-3'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P704_EVENT_FOR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31842513373513726822)
,p_event_id=>wwv_flow_imp.id(31820573770090549726)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_static_id=>'native-hide-4'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P704_FOR_USER_ID'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(36435159208048209641)
,p_name=>'when event_for E, show for_user_id'
,p_static_id=>'when-event-for-e-show-for-user-id'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P704_EVENT_FOR'
,p_condition_element=>'P704_EVENT_FOR'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'E'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(36435159480221209643)
,p_event_id=>wwv_flow_imp.id(36435159208048209641)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P704_FOR_USER_ID'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(36435159394249209642)
,p_event_id=>wwv_flow_imp.id(36435159208048209641)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P704_FOR_USER_ID'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(31822905641288727910)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_static_id=>'close-dialog'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_success_messages', 'Y')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>31822905641288727910
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(31820575230609549741)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create'
,p_static_id=>'create'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_event_util.create_event ( ',
'    p_event_type_id  => :P704_EVENT_TYPE_ID, ',
'    p_event_date     => case when :P704_RECURS = ''N'' then to_date(:P704_EVENT_DATE,''DD-Mon-YYYY'') else to_date(:P704_START_DATE,''DD-Mon-YYYY'') end, ',
'    p_event_name     => case when :P704_GENERAL_EVENT_YN = ''Y'' then :P704_EVENT_NAME end, ',
'    p_for_user_id    => case :P704_EVENT_FOR when ''E'' ',
'                                             then :P704_FOR_USER_ID',
'                                             when ''M''',
'                                             then :APP_USER_ID',
'                                             end,',
'    p_event_details  => :P704_EVENT_DETAILS, ',
'    p_recur_freq     => case when :P704_RECURS = ''Y'' then :P704_RECUR_FREQ end, ',
'    p_recur_end_date => case when :P704_RECURS = ''Y'' then to_date(:P704_END_DATE,''DD-Mon-YYYY'') end ); '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(31822904494297727908)
,p_process_success_message=>'Event(s) created.'
,p_internal_uid=>31820575230609549741
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(31842513700530726826)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete, no recur'
,p_static_id=>'delete-no-recur'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_event_util.delete_event (',
'    p_event_id => :P704_ID,',
'    p_delete_type => ''ONLY'' );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(31822903501771727907)
,p_process_when=>'P704_SERIES_ID'
,p_process_when_type=>'ITEM_IS_NULL'
,p_process_success_message=>'Event deleted.'
,p_internal_uid=>31842513700530726826
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(31842513680999726825)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load data for edit'
,p_static_id=>'load-data-for-edit'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'    select event_type_id,',
'           (select general_event_yn from sp_event_types',
'             where id = e.event_type_id) general_event_yn,',
'           event_date,',
'           event_name,',
'           event_details,',
'           for_user_id,',
'           series_id,',
'           created_by,',
'           apex_util.get_since(created) created_since,',
'           updated_by,',
'           apex_util.get_since(updated) updated_since',
'      from sp_events e',
'     where id = :P704_ID',
') loop',
'    :P704_EVENT_TYPE_ID    := c1.event_type_id;',
'    :P704_GENERAL_EVENT_YN := c1.general_event_yn;',
'    :P704_EVENT_DETAILS    := c1.event_details;',
'    :P704_EVENT_NAME       := c1.event_name;',
'    :P704_CREATED_BY       := c1.created_by;',
'    :P704_CREATED_SINCE    := c1.created_since;',
'    :P704_UPDATED_BY       := c1.updated_by;',
'    :P704_UPDATED_SINCE    := c1.updated_since;',
'',
'    if c1.for_user_id is null then',
'       :P704_EVENT_FOR := ''A'';',
'    elsif sp_util.get_user_id(c1.created_by) = c1.for_user_id then',
'        :P704_EVENT_FOR := ''M'';',
'    else   ',
'        :P704_EVENT_FOR := ''E'';    ',
'    end if;',
'',
'    if c1.for_user_id is not null then',
'        :P704_FOR_USER_ID := c1.for_user_id;',
'        :P704_PREVIOUS_FOR_USER_ID := c1.for_user_id;',
'    end if;',
'',
'    :P704_EVENT_DATE := c1.event_date;',
'',
'    if c1.series_id is not null then',
'        for c2 in (',
'            select recur_freq, start_date, end_date',
'              from sp_event_series',
'             where id = c1.series_id',
'        ) loop',
'            :P704_RECURS     := ''Y'';',
'            :P704_RECUR_FREQ := c2.recur_freq;',
'            :P704_START_DATE := c2.start_date;',
'            :P704_END_DATE   := c2.end_date;',
'            :P704_SERIES_ID  := c1.series_id;',
'        end loop;',
'    end if;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P704_ID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>31842513680999726825
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(35903689271131405423)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Quick Picks'
,p_static_id=>'load-quick-picks'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_cnt  number := 1;',
'begin',
'',
'for c1 in (',
'    select event_type, id',
'      from sp_event_types',
'     where active_yn = ''Y''',
' --      and general_event_yn = ''N''',
'       and quick_pick_yn = ''Y''',
'      order by event_type desc',
') loop',
'    if l_cnt = 1 then',
'        :P704_QP1    := c1.event_type;',
'        :P704_QP1_ID := c1.id;',
'    elsif l_cnt = 2 then',
'        :P704_QP2    := c1.event_type;',
'        :P704_QP2_ID := c1.id;',
'    elsif l_cnt = 3 then',
'        :P704_QP3    := c1.event_type;',
'        :P704_QP3_ID := c1.id;',
'    elsif l_cnt = 4 then',
'        :P704_QP4    := c1.event_type;',
'        :P704_QP4_ID := c1.id;',
'    elsif l_cnt = 5 then',
'        :P704_QP5    := c1.event_type;',
'        :P704_QP5_ID := c1.id;',
'    end if;',
'',
'    l_cnt := l_cnt + 1;',
'end loop;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>35903689271131405423
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(33518813618354200426)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'reload OOO Summary, if necessary'
,p_static_id=>'reload-ooo-summary-if-necessary'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_for_user_id  number;',
'    l_updated_yn   varchar2(1);',
'begin',
'',
'l_for_user_id := case :P704_EVENT_FOR when ''E'' ',
'                                      then :P704_FOR_USER_ID',
'                                      when ''M''',
'                                      then :APP_USER_ID',
'                                      end;',
'',
'if :P704_PREVIOUS_FOR_USER_ID != l_for_user_id then',
'    sp_event_util.load_one_ooo (',
'        p_team_member_id => :P704_PREVIOUS_FOR_USER_ID,',
'        p_updated_yn     => l_updated_yn );',
'end if;',
'',
'if l_for_user_id is not null then',
'    sp_event_util.load_one_ooo (',
'        p_team_member_id => l_for_user_id,',
'        p_updated_yn     => l_updated_yn );',
'end if;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>33518813618354200426
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32733524255181472602)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update, no recur'
,p_static_id=>'update-no-recur'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_event_util.update_event ( ',
'    p_event_id       => :P704_ID, ',
'    p_event_type_id  => :P704_EVENT_TYPE_ID, ',
'    p_event_date     => to_date(:P704_EVENT_DATE,''DD-Mon-YYYY''), ',
'    p_event_name     => :P704_EVENT_NAME, ',
'    p_for_user_id    => case :P704_EVENT_FOR when ''E'' ',
'                                             then :P704_FOR_USER_ID',
'                                             when ''M''',
'                                             then :APP_USER_ID',
'                                             end,',
'    p_event_details  => :P704_EVENT_DETAILS, ',
'    p_recur_freq     => case when :P704_RECURS = ''N''',
'                             then null',
'                             else :P704_RECUR_FREQ',
'                             end, ',
'    p_recur_end_date => case when :P704_RECURS = ''N''',
'                             then null',
'                             else to_date(:P704_END_DATE,''DD-Mon-YYYY'')',
'                             end, ',
'    p_update_type    => ''ONLY'' ',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(31822904023316727908)
,p_process_success_message=>'Event(s) updated.'
,p_internal_uid=>32733524255181472602
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(32733524352278472603)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update recur, no recur change'
,p_static_id=>'update-recur-no-recur-change'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sp_event_util.update_event ( ',
'    p_event_id       => :P704_ID, ',
'    p_event_type_id  => :P704_EVENT_TYPE_ID, ',
'    p_event_date     => to_date(:P704_START_DATE,''DD-Mon-YYYY''), ',
'    p_event_name     => :P704_EVENT_NAME, ',
'    p_for_user_id    => case :P704_EVENT_FOR when ''E'' ',
'                                             then :P704_FOR_USER_ID',
'                                             when ''M''',
'                                             then :APP_USER_ID',
'                                             end,',
'    p_event_details  => :P704_EVENT_DETAILS, ',
'    p_recur_freq     => case when :P704_RECURS = ''N''',
'                             then null',
'                             else :P704_RECUR_FREQ',
'                             end, ',
'    p_recur_end_date => case when :P704_RECURS = ''N''',
'                             then null',
'                             else to_date(:P704_END_DATE,''DD-Mon-YYYY'')',
'                             end, ',
'    p_update_type    => ''ALL'' ',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(31842515772070726846)
,p_process_success_message=>'Event(s) updated.'
,p_internal_uid=>32733524352278472603
);
wwv_flow_imp.component_end;
end;
/
