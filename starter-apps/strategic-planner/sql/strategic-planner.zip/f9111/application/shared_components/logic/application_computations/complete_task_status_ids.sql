prompt --application/shared_components/logic/application_computations/complete_task_status_ids
begin
--   Manifest
--     APPLICATION COMPUTATION: COMPLETE_TASK_STATUS_IDS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(55376814336321485355)
,p_computation_sequence=>10
,p_computation_item=>'COMPLETE_TASK_STATUS_IDS'
,p_static_id=>'complete-task-status-ids'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'QUERY'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select '':''||listagg(id, '':'' on overflow truncate '''' without count)||'':''',
'  from sp_task_statuses',
' where indicates_complete_yn = ''Y'''))
,p_computation_comment=>'should never have enough task statuses to need the overflow, but in place to avoid error - just in case'
,p_version_scn=>'SH256:uUgRY1b9UeQiCS4ukUrYz_rcVD-sSWVomh7w2bzbqA8'
);
wwv_flow_imp.component_end;
end;
/
