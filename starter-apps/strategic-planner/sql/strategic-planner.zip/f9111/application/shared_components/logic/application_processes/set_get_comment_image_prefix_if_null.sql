prompt --application/shared_components/logic/application_processes/set_get_comment_image_prefix_if_null
begin
--   Manifest
--     APPLICATION PROCESS: set GET_COMMENT_IMAGE_PREFIX (if null)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(21934179230239695494)
,p_process_sequence=>1
,p_process_point=>'ON_NEW_INSTANCE'
,p_process_name=>'set GET_COMMENT_IMAGE_PREFIX (if null)'
,p_static_id=>'set-get-comment-image-prefix-if-null'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if sp_util.get_setting(p_static_id => ''GET_COMMENT_IMAGE_PREFIX'') is null then',
'   sp_util.set_setting (p_static_id     => ''GET_COMMENT_IMAGE_PREFIX'',   ',
'                        p_setting_value => substr(APEX_UTIL.HOST_URL(''SCRIPT''),length(APEX_UTIL.HOST_URL())+1)); ',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_version_scn=>'45188590627481'
);
wwv_flow_imp.component_end;
end;
/
