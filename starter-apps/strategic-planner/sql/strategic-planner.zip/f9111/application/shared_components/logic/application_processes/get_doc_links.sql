prompt --application/shared_components/logic/application_processes/get_doc_links
begin
--   Manifest
--     APPLICATION PROCESS: get_doc_links
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(41015967681966450876)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_name=>'get_doc_links'
,p_static_id=>'get-doc-links'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'sys.htp.p (',
'    sp_comment_util.get_doc_links (',
'        p_search          => apex_application.g_x01,',
'        p_scope           => apex_application.g_x02,',
'        p_object_id       => apex_application.g_x03 ) );'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>'SH256:BZj6cC-EuucYLhAnFwt93LxSIqGQcm0FpvLVYsXVP2Y'
);
wwv_flow_imp.component_end;
end;
/
