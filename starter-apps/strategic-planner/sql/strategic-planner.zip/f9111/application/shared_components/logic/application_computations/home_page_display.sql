prompt --application/shared_components/logic/application_computations/home_page_display
begin
--   Manifest
--     APPLICATION COMPUTATION: HOME_PAGE_DISPLAY
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(38831933699057931118)
,p_computation_sequence=>10
,p_computation_item=>'HOME_PAGE_DISPLAY'
,p_static_id=>'home-page-display'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_display  varchar2(255) := '':ACT:INIT:PROJ:REL:'';',
'begin',
'    for c1 in (',
'        select '':''||',
'               case when hp_my_activities_yn = ''Y'' then ''ACT:'' end ||',
'               case when hp_my_initiatives_yn = ''Y'' then ''INIT:'' end ||',
'               case when hp_my_projects_yn = ''Y'' then ''PROJ:'' end ||',
'               case when hp_my_fav_projects_yn = ''Y'' then ''FAV:'' end ||',
'               case when hp_my_open_releases_yn = ''Y'' then ''REL:'' end display',
'          from sp_team_members',
'         where id = :APP_USER_ID',
'    ) loop',
'        l_display := c1.display;',
'    end loop;',
'',
'    return l_display;',
'end;'))
,p_compute_when=>'HOME_PAGE_DISPLAY'
,p_compute_when_type=>'ITEM_IS_NULL'
,p_version_scn=>'46466650579502'
);
wwv_flow_imp.component_end;
end;
/
