prompt --application/shared_components/logic/application_processes/get_edit_project_url
begin
--   Manifest
--     APPLICATION PROCESS: get_edit_project_url
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(8329464074282818048)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_name=>'get_edit_project_url'
,p_static_id=>'get-edit-project-url'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  l_url VARCHAR2(32767);',
'BEGIN',
'  l_url := apex_util.prepare_url(',
'             apex_page.get_url(',
'               p_page        => 24,',
'               p_clear_cache => ''24'',',
'               p_items       => ''P24_ID'',',
'               p_values      => :P3_PROJECT_ID',
'             )',
'           );',
'',
'  apex_json.initialize_clob_output;',
'  apex_json.open_object;',
'  apex_json.write(''url'', l_url);',
'  apex_json.close_object;',
'  htp.p(apex_json.get_clob_output);',
'  apex_json.free_output;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>'SH256:DTmhgsbawmtEJRYN5zEyos-7FrMoz0UJ1DG9uh8g-AY'
);
wwv_flow_imp.component_end;
end;
/
