prompt --application/shared_components/logic/application_processes/set_user_timezone
begin
--   Manifest
--     APPLICATION PROCESS: set user timezone
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(35737662504430933442)
,p_process_sequence=>30
,p_process_point=>'AFTER_LOGIN'
,p_process_name=>'set user timezone'
,p_static_id=>'set-user-timezone'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'    select timezone',
'      from sp_team_members',
'     where (id = :APP_USER_ID or email = lower(:APP_USER))',
'       and timezone is not null',
') loop',
'    apex_util.set_session_time_zone (p_time_zone => c1.timezone);',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_version_scn=>'46178672806404'
);
wwv_flow_imp.component_end;
end;
/
