prompt --application/shared_components/logic/application_computations/is_contributor
begin
--   Manifest
--     APPLICATION COMPUTATION: IS_CONTRIBUTOR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(36952749581026509118)
,p_computation_sequence=>10
,p_computation_item=>'IS_CONTRIBUTOR'
,p_static_id=>'is-contributor'
,p_computation_point=>'AFTER_LOGIN'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if APEX_AUTHORIZATION.IS_AUTHORIZED (p_authorization_name => ''Contribution Rights'') then',
'   return ''Y'';',
'else return ''N'';',
'end if;'))
,p_version_scn=>'46280417972947'
);
wwv_flow_imp.component_end;
end;
/
