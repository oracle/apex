prompt --application/shared_components/logic/application_items/last_count_refresh
begin
--   Manifest
--     APPLICATION ITEM: LAST_COUNT_REFRESH
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(48060242162647984928)
,p_name=>'LAST_COUNT_REFRESH'
,p_protection_level=>'I'
,p_version_scn=>'44506434329690'
);
wwv_flow_imp.component_end;
end;
/
