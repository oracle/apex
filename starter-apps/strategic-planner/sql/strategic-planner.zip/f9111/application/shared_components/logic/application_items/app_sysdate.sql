prompt --application/shared_components/logic/application_items/app_sysdate
begin
--   Manifest
--     APPLICATION ITEM: APP_SYSDATE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(33626747456070497355)
,p_name=>'APP_SYSDATE'
,p_protection_level=>'I'
,p_item_comment=>'use as "to_date(:APP_SYSDATE,''DD-MON-YYYY'')"'
,p_version_scn=>'45963209374232'
);
wwv_flow_imp.component_end;
end;
/
