prompt --application/shared_components/logic/application_computations/app_sysdate
begin
--   Manifest
--     APPLICATION COMPUTATION: APP_SYSDATE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(33627662550856573344)
,p_computation_sequence=>20
,p_computation_item=>'APP_SYSDATE'
,p_static_id=>'app-sysdate'
,p_computation_point=>'AFTER_LOGIN'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_systimestamp  timestamp with local time zone  := trunc(systimestamp at time zone ''UTC'');',
'begin',
'    for c1 in (',
'        select systimestamp at time zone timezone user_sysdate',
'          from sp_team_members',
'         where email = lower(:APP_USER)',
'           and timezone is not null',
'    ) loop',
'        l_systimestamp := c1.user_sysdate;',
'    end loop;',
'',
'    return to_char(l_systimestamp, ''DD-MON-YYYY'');',
'end;'))
,p_version_scn=>'46184976541496'
);
wwv_flow_imp.component_end;
end;
/
