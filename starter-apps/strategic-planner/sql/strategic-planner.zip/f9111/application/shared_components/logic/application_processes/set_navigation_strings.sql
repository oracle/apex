prompt --application/shared_components/logic/application_processes/set_navigation_strings
begin
--   Manifest
--     APPLICATION PROCESS: set navigation strings
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(151946612209800923618)
,p_process_sequence=>1
,p_process_point=>'BEFORE_HEADER'
,p_process_name=>'set navigation strings'
,p_static_id=>'set-navigation-strings'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':FOCUS_AREA := ''Focus Areas'';',
':INITIATIVE := ''Initiatives'';',
':PROJECT := ''Projects'';'))
,p_process_clob_language=>'PLSQL'
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
