prompt --application/shared_components/ai_agent/project_agent
begin
--   Manifest
--     AI AGENT: Project Agent
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_ai_agent(
 p_id=>wwv_flow_imp.id(5219621413798547839)
,p_name=>'Project Agent'
,p_static_id=>'project-agent'
,p_system_prompt=>wwv_flow_string.join(wwv_flow_t_varchar2(
'You are a data analyst, you will answer questions about a selected project from the details provided.',
'',
'For quantitative questions, do not make guesses, do full counts.',
'',
'The current user is &APP_USER_FIRST_LAST_NAME..',
'',
'The current date is &APP_SYSDATE..',
'',
'All the details of the current project are available in markdown format by calling the ''get_project_details'' tool.',
'If the user asks to edit the &NOMENCLATURE_PROJECT. and the ''edit_project'' tool is NOT accessible, let the user know that Only Contributors or Administrators can edit.'))
,p_welcome_message=>'What is your question related to this project?'
,p_version_scn=>'SH256:5ST5kTMFZRTgiUBKxT_hgE9GEpjGNSWAPzM4cZyzVU0'
);
wwv_flow_imp_shared.create_ai_agent_tool(
 p_id=>wwv_flow_imp.id(8328648144227513064)
,p_tool_name=>'edit_project'
,p_static_id=>'edit-project'
,p_tool_type=>'NATIVE_EXECUTE_CLIENT_SIDE_CODE'
,p_execution_point=>'ON_DEMAND'
,p_description=>'Use this tool if a user wants to edit the &NOMENCLATURE_PROJECT. details (such as name, priority, size, target date)'
,p_requires_confirmation=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'apex.server.process(',
    '  "get_edit_project_url",',
    '  { pageItems: "#P3_PROJECT_ID" },',
    '  {',
    '    dataType: "json",',
    '    success: function (data) {',
    '      apex.navigation.redirect(data.url);',
    '    }',
    '  }',
    ');',
    'return {earlyExit:true};')))).to_clob
,p_authorization_scheme=>wwv_flow_imp.id(176220694531802839665)
);
wwv_flow_imp_shared.create_ai_agent_tool(
 p_id=>wwv_flow_imp.id(8332401889814580259)
,p_tool_name=>'get_project_details'
,p_static_id=>'get-project-details'
,p_tool_type=>'NATIVE_RETRIEVE_DATA'
,p_execution_point=>'ON_DEMAND'
,p_description=>'This tool returns the details, in markdown format, of the current &NOMENCLATURE_PROJECT..'
,p_requires_confirmation=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'language', 'PLSQL',
  'plsql_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'return sp_summary_util.generate_project_md ( ',
    '           p_project_id => :P3_PROJECT_ID,',
    '           p_app_user_id => :APP_USER_ID );')),
  'type', 'FUNCTION_BODY')).to_clob
);
wwv_flow_imp_shared.create_ai_agent_tool(
 p_id=>wwv_flow_imp.id(6833543893219426236)
,p_tool_name=>'navigate_to_favorite'
,p_static_id=>'navigate-to-favorite'
,p_tool_type=>'NATIVE_EXECUTE_CLIENT_SIDE_CODE'
,p_execution_point=>'ON_DEMAND'
,p_description=>'Use this tool if the user wants to favorite (or unfavorite) the current &NOMENCLATURE_PROJECT.'
,p_requires_confirmation=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'apex.server.process(',
    '  "get_favorite_project_url",',
    '  { pageItems: "#P3_PROJECT_ID" },',
    '  {',
    '    dataType: "json",',
    '    success: function (data) {',
    '      apex.navigation.redirect(data.url);',
    '    }',
    '  }',
    ');',
    'return {earlyExit:true};')))).to_clob
);
wwv_flow_imp.component_end;
end;
/
