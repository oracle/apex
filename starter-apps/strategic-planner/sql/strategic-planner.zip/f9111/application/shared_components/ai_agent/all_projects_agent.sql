prompt --application/shared_components/ai_agent/all_projects_agent
begin
--   Manifest
--     AI AGENT: All Projects Agent
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_ai_agent(
 p_id=>wwv_flow_imp.id(4799546815801473125)
,p_name=>'All Projects Agent'
,p_static_id=>'all-projects-agent'
,p_system_prompt=>wwv_flow_string.join(wwv_flow_t_varchar2(
'You are a data analyst, you will answer questions about projects and the area and initiative they belong to plus the owner and many other details listed within.',
'',
'The current user is &APP_USER_FIRST_LAST_NAME..',
'',
'The current date is &APP_SYSDATE..',
'',
'You can use the following tools:',
'',
'1) get_projects',
'    - Optionally pass parameters to filter the list of projects.',
'    - Call the tool again each time you need filter by different values.',
'    - Never depend on the results from full list for detailed analysis, as it may be too large to process.',
'    - Do not call this tool multiple times if you have already called it with the same values.'))
,p_welcome_message=>'What is your project related question?'
,p_version_scn=>'SH256:TwviXc7gG35_DH4NY-WqjUJhrmi_4GJJ5NMfGe--q_g'
);
wwv_flow_imp_shared.create_ai_agent_tool(
 p_id=>wwv_flow_imp.id(5506720521773312823)
,p_tool_name=>'get_projects'
,p_static_id=>'get-projects'
,p_tool_type=>'PLUGIN_RETRIEVE_DATA_ADVANCED'
,p_execution_point=>'ON_DEMAND'
,p_description=>'Returns the list of projects'
,p_requires_confirmation=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'sql_query', wwv_flow_string.join(wwv_flow_t_varchar2(
    'select project,',
    '       area || '' - '' || initiative area_initiative,',
    '       nvl(release,''Not Targeted'') release,',
    '       nvl(focus_area,''None'') focus_area,',
    '       nvl(owner_name,''None'') owner_name,',
    '       priority, ',
    '       pct_complete || ''% '' percent_complete,',
    '       project_size,',
    '       status,',
    '       nvl(to_char(target_complete,''DD-MON-YYYY''),''Not Specified'') target_complete,',
    '       nvl(contributor_names,''None Identified'') contributors,',
    '       nvl(reviews,''None Identified'') reviews,',
    '       nvl(milestones,''None Identified'') milestones,',
    '       nvl(approvals,''None Yet'') approvals,',
    '       last_updated_date',
    '  from sp_project_details_v',
    ' where nvl(:OWNER_NAME, owner_name) = owner_name',
    '   and nvl(:PRIORITY, priority) =  priority',
    '   and nvl(:RELEASE, release) = release',
    '   and nvl(:PROJECT_SIZE, project_size) = project_size',
    '   and nvl(:PERCENT_COMPLETE, pct_complete) = pct_complete')))).to_clob
);
wwv_flow_imp_shared.create_ai_agent_tool_param(
 p_id=>wwv_flow_imp.id(5508790373468436150)
,p_param_name=>'OWNER_NAME'
,p_description=>'Optional filter for the exact owner name'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_ai_agent_tool_param(
 p_id=>wwv_flow_imp.id(10388085529398324530)
,p_param_name=>'PERCENT_COMPLETE'
,p_description=>'Optional filter for percent complete - a number between 0 and 100, in increments of 10, that corresponds to how complete the &NOMENCLATURE_PROJECT. is'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_ai_agent_tool_param(
 p_id=>wwv_flow_imp.id(10336744293743153737)
,p_param_name=>'PRIORITY'
,p_description=>'Optional filter for the priority of the &NOMENCLATURE_PROJECT. (P1-P5, where P1 is the highest)'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_ai_agent_tool_param(
 p_id=>wwv_flow_imp.id(10388085072891324528)
,p_param_name=>'PROJECT_SIZE'
,p_description=>'Optional filter for the size of &NOMENCLATURE_PROJECT., usually S through 2XL'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_ai_agent_tool_param(
 p_id=>wwv_flow_imp.id(10336842338394165544)
,p_param_name=>'RELEASE'
,p_description=>'Optional filter for the release the &NOMENCLATURE_PROJECT. is associated with (e.g. "OCI 22.1")'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp.component_end;
end;
/
