prompt --application/shared_components/ai_agent/all_reports
begin
--   Manifest
--     AI AGENT: All Reports
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_ai_agent(
 p_id=>wwv_flow_imp.id(5819838238335251380)
,p_name=>'All Reports'
,p_static_id=>'all-interactive-reports'
,p_system_prompt=>wwv_flow_string.join(wwv_flow_t_varchar2(
'You are a data analyst.',
'',
'Help users navigate to the appropriate reports. You may use the `get_reports` to retrieve a list of reports.',
'Analyze the descriptions of the reports provided and decide which report would best answer the question asked.',
'If there is not a clear winner, you can return more than one result.',
'Keep your answers concise. Ideally, answer only with the list of related reports.',
'Do not use bullet points.',
'',
'The current application ID: &APP_ID.'))
,p_welcome_message=>'Ask a question about the data within this application, I will find the report that I believe will provide your answer.'
,p_version_scn=>'SH256:OTge9SobFC1OR2mGV9upFHoHor2eUxBrvIrkzI1FKlM'
,p_agent_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'removd this',
'There may be an Interactive Report and Faceted Search (per the Report Type) that would address the same question.  If so, return both.',
''))
);
wwv_flow_imp_shared.create_ai_agent_tool(
 p_id=>wwv_flow_imp.id(5820071813879257862)
,p_tool_name=>'get_reports'
,p_static_id=>'get-reports'
,p_tool_type=>'PLUGIN_RETRIEVE_DATA_ADVANCED'
,p_execution_point=>'ON_DEMAND'
,p_description=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Returns the list of available reports for a specific application.',
'Returns a JSON array containing [{page_number, page_title, description, additional_details, report_type, url}]',
'When presenting a report to the user, format it as:',
'',
'"""',
'**Page Title** (Report Type)',
'Description',
'[Access Report](url)',
'"""',
'',
'- Bold the page title',
'- Keep the description as is, word for word. Do not change it, do not extend it.',
'- Include only the description. Never include data from "additional_details"! This internal information is for ranking the reports only!'))
,p_requires_confirmation=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'sql_query', wwv_flow_string.join(wwv_flow_t_varchar2(
    'select ''Page '' || page_id                           page_number,',
    '       sp_util.replace_nomenclature(page_title)     page_title,',
    '       sp_util.replace_nomenclature(help_text)      description,',
    '       sp_util.replace_nomenclature(page_comment)   additional_details,',
    '       case when page_id = 710 then ''Interactive Report''',
    '            else page_function',
    '            end report_type,',
    '       apex_page.get_url(:APP_ID,page_id) url',
    '  from APEX_APPLICATION_PAGES p',
    ' where application_id = :APP_ID',
    '   and page_mode = ''Normal''',
    '   and ( page_function = ''Interactive Report'' or',
    '         page_id = 710 or',
    '         (page_function = ''Faceted Search'' and page_id in (8, 17, 19, 21, 23, 55, 74, 102, 700)) )',
    '   and nvl(authorization_scheme,''Reader Rights'') = ''Reader Rights''  ',
    '--   and (authorization_scheme is null or',
    '--        apex_authorization.is_authorized (p_authorization_name => authorization_scheme))',
    '   and (build_option is null or ',
    '        apex_util.get_build_option_status (',
    '            p_application_id    => :APP_ID,',
    '            p_build_option_name => build_option) = ''INCLUDE'')')))).to_clob
);
wwv_flow_imp_shared.create_ai_agent_tool_param(
 p_id=>wwv_flow_imp.id(5820348720228949638)
,p_param_name=>'APP_ID'
,p_description=>'ID of the current application, provided in the prompt'
,p_data_type=>'NUMBER'
,p_is_required=>true
);
wwv_flow_imp.component_end;
end;
/
