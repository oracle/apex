prompt --application/deployment/install/install_seed_event_types
begin
--   Manifest
--     INSTALL: INSTALL-seed event_types
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into SP_EVENT_TYPES (ID, EVENT_TYPE, GENERAL_EVENT_YN, QUICK_PICK_YN, CALENDAR_EVENT_COLOR, I';
wwv_flow_imp.g_varchar2_table(2) := 'CON_CLASS, ACTIVE_YN ) values ( 1, ''Conference'', ''Y'', ''Y'', ''orange'', ''fa-users-chat'', ''Y'');'||wwv_flow.LF||
'insert i';
wwv_flow_imp.g_varchar2_table(3) := 'nto SP_EVENT_TYPES (ID, EVENT_TYPE, GENERAL_EVENT_YN, QUICK_PICK_YN, CALENDAR_EVENT_COLOR, ICON_CLAS';
wwv_flow_imp.g_varchar2_table(4) := 'S, ACTIVE_YN ) values ( 2, ''Customer Meeting'', ''Y'', ''Y'', ''red'', ''fa-users'', ''Y'');'||wwv_flow.LF||
'insert into SP_EVE';
wwv_flow_imp.g_varchar2_table(5) := 'NT_TYPES (ID, EVENT_TYPE, GENERAL_EVENT_YN, QUICK_PICK_YN, CALENDAR_EVENT_COLOR, ICON_CLASS, ACTIVE_';
wwv_flow_imp.g_varchar2_table(6) := 'YN ) values ( 3, ''Internal Meeting'', ''Y'', ''N'', ''brown'', ''fa-users-alt'', ''Y'');'||wwv_flow.LF||
'insert into SP_EVENT_T';
wwv_flow_imp.g_varchar2_table(7) := 'YPES (ID, EVENT_TYPE, GENERAL_EVENT_YN, QUICK_PICK_YN, CALENDAR_EVENT_COLOR, ICON_CLASS, ACTIVE_YN )';
wwv_flow_imp.g_varchar2_table(8) := ' values ( 4, ''Personal Time Off'', ''N'', ''Y'', ''bluesky'', ''fa-calendar-ban'', ''Y'');'||wwv_flow.LF||
'insert into SP_EVENT';
wwv_flow_imp.g_varchar2_table(9) := '_TYPES (ID, EVENT_TYPE, GENERAL_EVENT_YN, QUICK_PICK_YN, CALENDAR_EVENT_COLOR, ICON_CLASS, ACTIVE_YN';
wwv_flow_imp.g_varchar2_table(10) := ' ) values ( 5, ''Public Holiday'', ''Y'', ''Y'', ''blue'', ''fa-tree'', ''Y'');'||wwv_flow.LF||
'insert into SP_EVENT_TYPES (ID, ';
wwv_flow_imp.g_varchar2_table(11) := 'EVENT_TYPE, GENERAL_EVENT_YN, QUICK_PICK_YN, CALENDAR_EVENT_COLOR, ICON_CLASS, ACTIVE_YN ) values ( ';
wwv_flow_imp.g_varchar2_table(12) := '6, ''Sick Leave'', ''N'', ''Y'', ''gray'', ''fa-user-md'', ''Y'');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(35719711161219272516)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed event_types'
,p_sequence=>9150
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
