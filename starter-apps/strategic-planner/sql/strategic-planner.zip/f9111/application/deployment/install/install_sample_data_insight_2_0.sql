prompt --application/deployment/install/install_sample_data_insight_2_0
begin
--   Manifest
--     INSTALL: INSTALL-sample data - insight 2.0
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'sp_globals.g_audit_this := FALSE;'||wwv_flow.LF||
''||wwv_flow.LF||
'insert all'||wwv_flow.LF||
' into sp_projects (id,initiative_id,project,own';
wwv_flow_imp.g_varchar2_table(2) := 'er_id,active_yn,priority_id,release_id,target_complete,pct_complete,status_id,project_size,status_sc';
wwv_flow_imp.g_varchar2_table(3) := 'ale,description,tags,focus_area_id,created,created_by,updated,updated_by) values (8501,3,''Real-Time ';
wwv_flow_imp.g_varchar2_table(4) := 'Recommendation Events'',1,''Y'',1,3,sp_util.fix_demo_dates(sysdate+24),80,1,''XL'',''A'',''New real-time rec';
wwv_flow_imp.g_varchar2_table(5) := 'ommendation event processing.'',''insightiq,ai,recommendations,realtime'',30,sp_util.fix_demo_dates(sys';
wwv_flow_imp.g_varchar2_table(6) := 'date-55),''SCOTT.TIGER@ACME.COM'',sp_util.fix_demo_dates(sysdate-2),''SCOTT.TIGER@ACME.COM'')'||wwv_flow.LF||
' into sp_p';
wwv_flow_imp.g_varchar2_table(7) := 'rojects (id,initiative_id,project,owner_id,active_yn,priority_id,release_id,target_complete,pct_comp';
wwv_flow_imp.g_varchar2_table(8) := 'lete,status_id,project_size,status_scale,description,tags,focus_area_id,created,created_by,updated,u';
wwv_flow_imp.g_varchar2_table(9) := 'pdated_by) values (8502,3,''Recommendation Explanation Service'',3,''Y'',2,3,sp_util.fix_demo_dates(sysd';
wwv_flow_imp.g_varchar2_table(10) := 'ate+22),70,1,''L'',''A'',''New customer-facing recommendation explanations.'',''insightiq,ai,recommendation';
wwv_flow_imp.g_varchar2_table(11) := 's'',30,sp_util.fix_demo_dates(sysdate-54),''ELENA.VARGAS@ACME.COM'',sp_util.fix_demo_dates(sysdate-3),''';
wwv_flow_imp.g_varchar2_table(12) := 'ELENA.VARGAS@ACME.COM'')'||wwv_flow.LF||
' into sp_projects (id,initiative_id,project,owner_id,active_yn,priority_id,r';
wwv_flow_imp.g_varchar2_table(13) := 'elease_id,target_complete,pct_complete,status_id,project_size,status_scale,description,tags,focus_ar';
wwv_flow_imp.g_varchar2_table(14) := 'ea_id,created,created_by,updated,updated_by) values (8503,3,''Forecast Scenario Planning'',5,''Y'',2,3,s';
wwv_flow_imp.g_varchar2_table(15) := 'p_util.fix_demo_dates(sysdate+25),70,1,''XL'',''A'',''Expands demand forecasting with scenario planning.''';
wwv_flow_imp.g_varchar2_table(16) := ',''insightiq,ai,forecasting'',30,sp_util.fix_demo_dates(sysdate-52),''NAOMI.CHEN@ACME.COM'',sp_util.fix_';
wwv_flow_imp.g_varchar2_table(17) := 'demo_dates(sysdate-4),''NAOMI.CHEN@ACME.COM'')'||wwv_flow.LF||
' into sp_projects (id,initiative_id,project,owner_id,ac';
wwv_flow_imp.g_varchar2_table(18) := 'tive_yn,priority_id,release_id,target_complete,pct_complete,status_id,project_size,status_scale,desc';
wwv_flow_imp.g_varchar2_table(19) := 'ription,tags,focus_area_id,created,created_by,updated,updated_by) values (8504,1,''Customer Journey F';
wwv_flow_imp.g_varchar2_table(20) := 'unnel Builder'',7,''Y'',2,3,sp_util.fix_demo_dates(sysdate+21),80,1,''L'',''A'',''New self-service journey f';
wwv_flow_imp.g_varchar2_table(21) := 'unnel configuration.'',''insightiq,customer-systems,journey'',1,sp_util.fix_demo_dates(sysdate-50),''CAL';
wwv_flow_imp.g_varchar2_table(22) := 'EB.FOSTER@ACME.COM'',sp_util.fix_demo_dates(sysdate-1),''CALEB.FOSTER@ACME.COM'')'||wwv_flow.LF||
' into sp_projects (id';
wwv_flow_imp.g_varchar2_table(23) := ',initiative_id,project,owner_id,active_yn,priority_id,release_id,target_complete,pct_complete,status';
wwv_flow_imp.g_varchar2_table(24) := '_id,project_size,status_scale,description,tags,focus_area_id,created,created_by,updated,updated_by) ';
wwv_flow_imp.g_varchar2_table(25) := 'values (8505,3,''Support Intent Model Expansion'',9,''Y'',1,3,sp_util.fix_demo_dates(sysdate+26),60,2,''X';
wwv_flow_imp.g_varchar2_table(26) := 'L'',''A'',''Expands supported intents and routing confidence.'',''insightiq,ai,support'',30,sp_util.fix_dem';
wwv_flow_imp.g_varchar2_table(27) := 'o_dates(sysdate-48),''ANDRE.COLLINS@ACME.COM'',sp_util.fix_demo_dates(sysdate-5),''ANDRE.COLLINS@ACME.C';
wwv_flow_imp.g_varchar2_table(28) := 'OM'')'||wwv_flow.LF||
' into sp_projects (id,initiative_id,project,owner_id,active_yn,priority_id,release_id,target_co';
wwv_flow_imp.g_varchar2_table(29) := 'mplete,pct_complete,status_id,project_size,status_scale,description,tags,focus_area_id,created,creat';
wwv_flow_imp.g_varchar2_table(30) := 'ed_by,updated,updated_by) values (8506,1,''Data Quality Remediation Workflow'',11,''Y'',2,3,sp_util.fix_';
wwv_flow_imp.g_varchar2_table(31) := 'demo_dates(sysdate+19),70,1,''L'',''A'',''Adds remediation assignments for data-quality alerts.'',''insight';
wwv_flow_imp.g_varchar2_table(32) := 'iq,analytics,data-quality,workflow'',6,sp_util.fix_demo_dates(sysdate-46),''VICTOR.RAMIREZ@ACME.COM'',s';
wwv_flow_imp.g_varchar2_table(33) := 'p_util.fix_demo_dates(sysdate-2),''VICTOR.RAMIREZ@ACME.COM'')'||wwv_flow.LF||
' into sp_projects (id,initiative_id,proj';
wwv_flow_imp.g_varchar2_table(34) := 'ect,owner_id,active_yn,priority_id,release_id,target_complete,pct_complete,status_id,project_size,st';
wwv_flow_imp.g_varchar2_table(35) := 'atus_scale,description,tags,focus_area_id,created,created_by,updated,updated_by) values (8507,1,''Exe';
wwv_flow_imp.g_varchar2_table(36) := 'cutive Dashboard Drill Through'',13,''Y'',3,3,sp_util.fix_demo_dates(sysdate+18),90,1,''M'',''A'',''Expands ';
wwv_flow_imp.g_varchar2_table(37) := 'executive dashboards with detail drill-through.'',''insightiq,analytics,dashboards'',6,sp_util.fix_demo';
wwv_flow_imp.g_varchar2_table(38) := '_dates(sysdate-44),''ISAAC.TURNER@ACME.COM'',sp_util.fix_demo_dates(sysdate-1),''ISAAC.TURNER@ACME.COM''';
wwv_flow_imp.g_varchar2_table(39) := ')'||wwv_flow.LF||
' into sp_projects (id,initiative_id,project,owner_id,active_yn,priority_id,release_id,target_compl';
wwv_flow_imp.g_varchar2_table(40) := 'ete,pct_complete,status_id,project_size,status_scale,description,tags,focus_area_id,created,created_';
wwv_flow_imp.g_varchar2_table(41) := 'by,updated,updated_by) values (8508,3,''Segmentation Model Governance'',15,''Y'',2,3,sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(42) := 'tes(sysdate+23),60,2,''L'',''A'',''New governance controls for segmentation models.'',''insightiq,ai,segmen';
wwv_flow_imp.g_varchar2_table(43) := 'tation,governance'',30,sp_util.fix_demo_dates(sysdate-42),''DOMINIC.REYES@ACME.COM'',sp_util.fix_demo_d';
wwv_flow_imp.g_varchar2_table(44) := 'ates(sysdate-6),''DOMINIC.REYES@ACME.COM'')'||wwv_flow.LF||
' into sp_projects (id,initiative_id,project,owner_id,activ';
wwv_flow_imp.g_varchar2_table(45) := 'e_yn,priority_id,release_id,target_complete,pct_complete,status_id,project_size,status_scale,descrip';
wwv_flow_imp.g_varchar2_table(46) := 'tion,tags,focus_area_id,created,created_by,updated,updated_by) values (8509,1,''Experiment Results Co';
wwv_flow_imp.g_varchar2_table(47) := 'mparison'',17,''Y'',3,3,sp_util.fix_demo_dates(sysdate+17),80,1,''M'',''A'',''Adds side-by-side experiment r';
wwv_flow_imp.g_varchar2_table(48) := 'esult comparison.'',''insightiq,analytics,experimentation'',6,sp_util.fix_demo_dates(sysdate-40),''ETHAN';
wwv_flow_imp.g_varchar2_table(49) := '.CALDWELL@ACME.COM'',sp_util.fix_demo_dates(sysdate-1),''ETHAN.CALDWELL@ACME.COM'')'||wwv_flow.LF||
' into sp_projects (';
wwv_flow_imp.g_varchar2_table(50) := 'id,initiative_id,project,owner_id,active_yn,priority_id,release_id,target_complete,pct_complete,stat';
wwv_flow_imp.g_varchar2_table(51) := 'us_id,project_size,status_scale,description,tags,focus_area_id,created,created_by,updated,updated_by';
wwv_flow_imp.g_varchar2_table(52) := ') values (8510,1,''Analytics Data Retention Controls'',19,''Y'',1,3,sp_util.fix_demo_dates(sysdate+20),7';
wwv_flow_imp.g_varchar2_table(53) := '0,1,''L'',''A'',''New configurable data retention and purge controls.'',''insightiq,security,data-retention';
wwv_flow_imp.g_varchar2_table(54) := ''',4,sp_util.fix_demo_dates(sysdate-38),''LUCAS.BENNETT@ACME.COM'',sp_util.fix_demo_dates(sysdate-2),''L';
wwv_flow_imp.g_varchar2_table(55) := 'UCAS.BENNETT@ACME.COM'')'||wwv_flow.LF||
' into sp_projects (id,initiative_id,project,owner_id,active_yn,priority_id,r';
wwv_flow_imp.g_varchar2_table(56) := 'elease_id,target_complete,pct_complete,status_id,project_size,status_scale,description,tags,focus_ar';
wwv_flow_imp.g_varchar2_table(57) := 'ea_id,created,created_by,updated,updated_by) values (8511,1,''Dashboard Accessibility Improvements'',2';
wwv_flow_imp.g_varchar2_table(58) := '1,''Y'',2,3,sp_util.fix_demo_dates(sysdate+16),90,1,''M'',''A'',''Improves dashboard keyboard navigation an';
wwv_flow_imp.g_varchar2_table(59) := 'd screen-reader support.'',''insightiq,accessibility,dashboards'',3,sp_util.fix_demo_dates(sysdate-36),';
wwv_flow_imp.g_varchar2_table(60) := '''ZOE.MATTHEWS@ACME.COM'',sp_util.fix_demo_dates(sysdate-1),''ZOE.MATTHEWS@ACME.COM'')'||wwv_flow.LF||
' into sp_projects';
wwv_flow_imp.g_varchar2_table(61) := ' (id,initiative_id,project,owner_id,active_yn,priority_id,release_id,target_complete,pct_complete,st';
wwv_flow_imp.g_varchar2_table(62) := 'atus_id,project_size,status_scale,description,tags,focus_area_id,created,created_by,updated,updated_';
wwv_flow_imp.g_varchar2_table(63) := 'by) values (8512,1,''Analytics Export Defect Fixes'',20,''Y'',3,3,sp_util.fix_demo_dates(sysdate+15),90,';
wwv_flow_imp.g_varchar2_table(64) := '1,''S'',''A'',''Fixes export formatting and timezone calculation defects.'',''insightiq,analytics,export,bu';
wwv_flow_imp.g_varchar2_table(65) := 'g-fix'',6,sp_util.fix_demo_dates(sysdate-34),''AIDEN.CLARKE@ACME.COM'',sp_util.fix_demo_dates(sysdate-1';
wwv_flow_imp.g_varchar2_table(66) := '),''AIDEN.CLARKE@ACME.COM'')'||wwv_flow.LF||
'select 1 from dual;'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_project_contributors (id,project_id,t';
wwv_flow_imp.g_varchar2_table(67) := 'eam_member_id,responsibility_id,responsibility,tags,created,created_by,updated,updated_by)'||wwv_flow.LF||
'select 86';
wwv_flow_imp.g_varchar2_table(68) := '00+(p.project_id-8500)*10+r.seq,p.project_id,case when r.seq=1 then p.owner_id when p.owner_id=21 th';
wwv_flow_imp.g_varchar2_table(69) := 'en 20 else p.owner_id+1 end,r.responsibility_id,r.responsibility,r.tags,sp_util.fix_demo_dates(sysda';
wwv_flow_imp.g_varchar2_table(70) := 'te+p.created_offset),p.owner_email,sp_util.fix_demo_dates(sysdate+p.created_offset),p.owner_email'||wwv_flow.LF||
'fr';
wwv_flow_imp.g_varchar2_table(71) := 'om (select 8501 project_id,1 owner_id,''SCOTT.TIGER@ACME.COM'' owner_email,-55 created_offset from dua';
wwv_flow_imp.g_varchar2_table(72) := 'l union all select 8502,3,''ELENA.VARGAS@ACME.COM'',-54 from dual union all select 8503,5,''NAOMI.CHEN@';
wwv_flow_imp.g_varchar2_table(73) := 'ACME.COM'',-52 from dual union all select 8504,7,''CALEB.FOSTER@ACME.COM'',-50 from dual union all sele';
wwv_flow_imp.g_varchar2_table(74) := 'ct 8505,9,''ANDRE.COLLINS@ACME.COM'',-48 from dual union all select 8506,11,''VICTOR.RAMIREZ@ACME.COM'',';
wwv_flow_imp.g_varchar2_table(75) := '-46 from dual union all select 8507,13,''ISAAC.TURNER@ACME.COM'',-44 from dual union all select 8508,1';
wwv_flow_imp.g_varchar2_table(76) := '5,''DOMINIC.REYES@ACME.COM'',-42 from dual union all select 8509,17,''ETHAN.CALDWELL@ACME.COM'',-40 from';
wwv_flow_imp.g_varchar2_table(77) := ' dual union all select 8510,19,''LUCAS.BENNETT@ACME.COM'',-38 from dual union all select 8511,21,''ZOE.';
wwv_flow_imp.g_varchar2_table(78) := 'MATTHEWS@ACME.COM'',-36 from dual union all select 8512,20,''AIDEN.CLARKE@ACME.COM'',-34 from dual) p'||wwv_flow.LF||
'c';
wwv_flow_imp.g_varchar2_table(79) := 'ross join (select 1 seq,3 responsibility_id,''Leads release delivery.'' responsibility,''project-manage';
wwv_flow_imp.g_varchar2_table(80) := 'ment'' tags from dual union all select 2,1,''Builds and tests the delivered change.'',''development,qa'' ';
wwv_flow_imp.g_varchar2_table(81) := 'from dual) r;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Comments are inserted oldest to newest so the comment-number trigger assigns numbe';
wwv_flow_imp.g_varchar2_table(82) := 'rs chronologically.'||wwv_flow.LF||
'insert into sp_project_comments (id,project_id,author_id,body,body_html,body_no_';
wwv_flow_imp.g_varchar2_table(83) := 'images,private_yn,created,created_by,updated,updated_by)'||wwv_flow.LF||
'values (8801,8501,1,''Real-time events passe';
wwv_flow_imp.g_varchar2_table(84) := 'd throughput testing.'',''Real-time events passed throughput testing.'',''Real-time events passed throug';
wwv_flow_imp.g_varchar2_table(85) := 'hput testing.'',''N'',sp_util.fix_demo_dates(sysdate-42),upper(''scott.tiger@acme.com''),sp_util.fix_demo';
wwv_flow_imp.g_varchar2_table(86) := '_dates(sysdate-42),upper(''scott.tiger@acme.com''));'||wwv_flow.LF||
'insert into sp_project_comments (id,project_id,au';
wwv_flow_imp.g_varchar2_table(87) := 'thor_id,body,body_html,body_no_images,private_yn,created,created_by,updated,updated_by)'||wwv_flow.LF||
'values (8802';
wwv_flow_imp.g_varchar2_table(88) := ',8502,3,''Explanation text was approved by Product.'',''Explanation text was approved by Product.'',''Exp';
wwv_flow_imp.g_varchar2_table(89) := 'lanation text was approved by Product.'',''N'',sp_util.fix_demo_dates(sysdate-38),upper(''elena.vargas@a';
wwv_flow_imp.g_varchar2_table(90) := 'cme.com''),sp_util.fix_demo_dates(sysdate-38),upper(''elena.vargas@acme.com''));'||wwv_flow.LF||
'insert into sp_project';
wwv_flow_imp.g_varchar2_table(91) := '_comments (id,project_id,author_id,body,body_html,body_no_images,private_yn,created,created_by,updat';
wwv_flow_imp.g_varchar2_table(92) := 'ed,updated_by)'||wwv_flow.LF||
'values (8803,8503,5,''Scenario inputs were validated with Operations.'',''Scenario input';
wwv_flow_imp.g_varchar2_table(93) := 's were validated with Operations.'',''Scenario inputs were validated with Operations.'',''N'',sp_util.fix';
wwv_flow_imp.g_varchar2_table(94) := '_demo_dates(sysdate-34),upper(''naomi.chen@acme.com''),sp_util.fix_demo_dates(sysdate-34),upper(''naomi';
wwv_flow_imp.g_varchar2_table(95) := '.chen@acme.com''));'||wwv_flow.LF||
'insert into sp_project_comments (id,project_id,author_id,body,body_html,body_no_i';
wwv_flow_imp.g_varchar2_table(96) := 'mages,private_yn,created,created_by,updated,updated_by)'||wwv_flow.LF||
'values (8804,8504,7,''Funnel templates were a';
wwv_flow_imp.g_varchar2_table(97) := 'ccepted for launch.'',''Funnel templates were accepted for launch.'',''Funnel templates were accepted fo';
wwv_flow_imp.g_varchar2_table(98) := 'r launch.'',''N'',sp_util.fix_demo_dates(sysdate-30),upper(''caleb.foster@acme.com''),sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(99) := 'tes(sysdate-30),upper(''caleb.foster@acme.com''));'||wwv_flow.LF||
'insert into sp_project_comments (id,project_id,auth';
wwv_flow_imp.g_varchar2_table(100) := 'or_id,body,body_html,body_no_images,private_yn,created,created_by,updated,updated_by)'||wwv_flow.LF||
'values (8805,8';
wwv_flow_imp.g_varchar2_table(101) := '505,9,''New support intents passed quality review.'',''New support intents passed quality review.'',''New';
wwv_flow_imp.g_varchar2_table(102) := ' support intents passed quality review.'',''N'',sp_util.fix_demo_dates(sysdate-26),upper(''andre.collins';
wwv_flow_imp.g_varchar2_table(103) := '@acme.com''),sp_util.fix_demo_dates(sysdate-26),upper(''andre.collins@acme.com''));'||wwv_flow.LF||
'insert into sp_proj';
wwv_flow_imp.g_varchar2_table(104) := 'ect_comments (id,project_id,author_id,body,body_html,body_no_images,private_yn,created,created_by,up';
wwv_flow_imp.g_varchar2_table(105) := 'dated,updated_by)'||wwv_flow.LF||
'values (8806,8506,11,''Remediation ownership flow was agreed.'',''Remediation ownersh';
wwv_flow_imp.g_varchar2_table(106) := 'ip flow was agreed.'',''Remediation ownership flow was agreed.'',''N'',sp_util.fix_demo_dates(sysdate-22)';
wwv_flow_imp.g_varchar2_table(107) := ',upper(''victor.ramirez@acme.com''),sp_util.fix_demo_dates(sysdate-22),upper(''victor.ramirez@acme.com''';
wwv_flow_imp.g_varchar2_table(108) := '));'||wwv_flow.LF||
'insert into sp_project_comments (id,project_id,author_id,body,body_html,body_no_images,private_y';
wwv_flow_imp.g_varchar2_table(109) := 'n,created,created_by,updated,updated_by)'||wwv_flow.LF||
'values (8807,8507,13,''Drill-through KPI definitions were ap';
wwv_flow_imp.g_varchar2_table(110) := 'proved.'',''Drill-through KPI definitions were approved.'',''Drill-through KPI definitions were approved';
wwv_flow_imp.g_varchar2_table(111) := '.'',''N'',sp_util.fix_demo_dates(sysdate-18),upper(''isaac.turner@acme.com''),sp_util.fix_demo_dates(sysd';
wwv_flow_imp.g_varchar2_table(112) := 'ate-18),upper(''isaac.turner@acme.com''));'||wwv_flow.LF||
'insert into sp_project_comments (id,project_id,author_id,bo';
wwv_flow_imp.g_varchar2_table(113) := 'dy,body_html,body_no_images,private_yn,created,created_by,updated,updated_by)'||wwv_flow.LF||
'values (8808,8508,15,''';
wwv_flow_imp.g_varchar2_table(114) := 'Governance checks are ready for model onboarding.'',''Governance checks are ready for model onboarding';
wwv_flow_imp.g_varchar2_table(115) := '.'',''Governance checks are ready for model onboarding.'',''N'',sp_util.fix_demo_dates(sysdate-14),upper(';
wwv_flow_imp.g_varchar2_table(116) := '''dominic.reyes@acme.com''),sp_util.fix_demo_dates(sysdate-14),upper(''dominic.reyes@acme.com''));'||wwv_flow.LF||
'inser';
wwv_flow_imp.g_varchar2_table(117) := 't into sp_project_comments (id,project_id,author_id,body,body_html,body_no_images,private_yn,created';
wwv_flow_imp.g_varchar2_table(118) := ',created_by,updated,updated_by)'||wwv_flow.LF||
'values (8809,8509,17,''Comparison results include confidence guidance';
wwv_flow_imp.g_varchar2_table(119) := '.'',''Comparison results include confidence guidance.'',''Comparison results include confidence guidance';
wwv_flow_imp.g_varchar2_table(120) := '.'',''N'',sp_util.fix_demo_dates(sysdate-10),upper(''ethan.caldwell@acme.com''),sp_util.fix_demo_dates(sy';
wwv_flow_imp.g_varchar2_table(121) := 'sdate-10),upper(''ethan.caldwell@acme.com''));'||wwv_flow.LF||
'insert into sp_project_comments (id,project_id,author_i';
wwv_flow_imp.g_varchar2_table(122) := 'd,body,body_html,body_no_images,private_yn,created,created_by,updated,updated_by)'||wwv_flow.LF||
'values (8810,8510,';
wwv_flow_imp.g_varchar2_table(123) := '19,''Retention policies were approved by Security.'',''Retention policies were approved by Security.'',''';
wwv_flow_imp.g_varchar2_table(124) := 'Retention policies were approved by Security.'',''N'',sp_util.fix_demo_dates(sysdate-7),upper(''lucas.be';
wwv_flow_imp.g_varchar2_table(125) := 'nnett@acme.com''),sp_util.fix_demo_dates(sysdate-7),upper(''lucas.bennett@acme.com''));'||wwv_flow.LF||
'insert into sp_';
wwv_flow_imp.g_varchar2_table(126) := 'project_comments (id,project_id,author_id,body,body_html,body_no_images,private_yn,created,created_b';
wwv_flow_imp.g_varchar2_table(127) := 'y,updated,updated_by)'||wwv_flow.LF||
'values (8811,8511,21,''Accessibility improvements passed the agreed checks.'',''A';
wwv_flow_imp.g_varchar2_table(128) := 'ccessibility improvements passed the agreed checks.'',''Accessibility improvements passed the agreed c';
wwv_flow_imp.g_varchar2_table(129) := 'hecks.'',''N'',sp_util.fix_demo_dates(sysdate-4),upper(''zoe.matthews@acme.com''),sp_util.fix_demo_dates(';
wwv_flow_imp.g_varchar2_table(130) := 'sysdate-4),upper(''zoe.matthews@acme.com''));'||wwv_flow.LF||
'insert into sp_project_comments (id,project_id,author_id';
wwv_flow_imp.g_varchar2_table(131) := ',body,body_html,body_no_images,private_yn,created,created_by,updated,updated_by)'||wwv_flow.LF||
'values (8812,8512,2';
wwv_flow_imp.g_varchar2_table(132) := '0,''Export defects were corrected and regression-tested.'',''Export defects were corrected and regressi';
wwv_flow_imp.g_varchar2_table(133) := 'on-tested.'',''Export defects were corrected and regression-tested.'',''N'',sp_util.fix_demo_dates(sysdat';
wwv_flow_imp.g_varchar2_table(134) := 'e-2),upper(''aiden.clarke@acme.com''),sp_util.fix_demo_dates(sysdate-2),upper(''aiden.clarke@acme.com'')';
wwv_flow_imp.g_varchar2_table(135) := ');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_tasks (id,project_id,task,task_type_id,task_sub_type_id,owner_id,start_date,targe';
wwv_flow_imp.g_varchar2_table(136) := 't_complete,status_id,status_last_changed_on,description,tags,display_sequence,impact,created,created';
wwv_flow_imp.g_varchar2_table(137) := '_by,updated,updated_by)'||wwv_flow.LF||
'select 8700+(p.project_id-8500)*10+t.seq,p.project_id,t.task,t.task_type_id,';
wwv_flow_imp.g_varchar2_table(138) := 'null,p.owner_id,sp_util.fix_demo_dates(sysdate+t.start_offset),sp_util.fix_demo_dates(sysdate+t.comp';
wwv_flow_imp.g_varchar2_table(139) := 'lete_offset),t.status_id,sp_util.fix_demo_dates(sysdate+t.changed_offset),t.description,t.tags,t.seq';
wwv_flow_imp.g_varchar2_table(140) := '*10,t.impact,sp_util.fix_demo_dates(sysdate+t.created_offset),p.owner_email,sp_util.fix_demo_dates(s';
wwv_flow_imp.g_varchar2_table(141) := 'ysdate+t.updated_offset),p.owner_email'||wwv_flow.LF||
'from ('||wwv_flow.LF||
'select 8501 project_id,1 owner_id,''SCOTT.TIGER@ACME.CO';
wwv_flow_imp.g_varchar2_table(142) := 'M'' owner_email from dual '||wwv_flow.LF||
'union all '||wwv_flow.LF||
'select 8502,3,''ELENA.VARGAS@ACME.COM'' from dual '||wwv_flow.LF||
'union all '||wwv_flow.LF||
'sel';
wwv_flow_imp.g_varchar2_table(143) := 'ect 8503,5,''NAOMI.CHEN@ACME.COM'' from dual '||wwv_flow.LF||
'union all '||wwv_flow.LF||
'select 8504,7,''CALEB.FOSTER@ACME.COM'' from du';
wwv_flow_imp.g_varchar2_table(144) := 'al '||wwv_flow.LF||
'union all '||wwv_flow.LF||
'select 8505,9,''ANDRE.COLLINS@ACME.COM'' from dual '||wwv_flow.LF||
'union all '||wwv_flow.LF||
'select 8506,11,''VICTOR.R';
wwv_flow_imp.g_varchar2_table(145) := 'AMIREZ@ACME.COM'' from dual '||wwv_flow.LF||
'union all '||wwv_flow.LF||
'select 8507,13,''ISAAC.TURNER@ACME.COM'' from dual '||wwv_flow.LF||
'union all '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(146) := 'select 8508,15,''DOMINIC.REYES@ACME.COM'' from dual '||wwv_flow.LF||
'union all '||wwv_flow.LF||
'select 8509,17,''ETHAN.CALDWELL@ACME.CO';
wwv_flow_imp.g_varchar2_table(147) := 'M'' from dual '||wwv_flow.LF||
'union all '||wwv_flow.LF||
'select 8510,19,''LUCAS.BENNETT@ACME.COM'' from dual '||wwv_flow.LF||
'union all '||wwv_flow.LF||
'select 8511,2';
wwv_flow_imp.g_varchar2_table(148) := '1,''ZOE.MATTHEWS@ACME.COM'' from dual '||wwv_flow.LF||
'union all '||wwv_flow.LF||
'select 8512,20,''AIDEN.CLARKE@ACME.COM'' from dual) p'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(149) := 'cross join ('||wwv_flow.LF||
'select 1 seq,''Spec Complete'' task,21 task_type_id,-55 start_offset,-45 complete_offset,';
wwv_flow_imp.g_varchar2_table(150) := '14 status_id,-45 changed_offset,-58 created_offset,-45 updated_offset,''Specification approved.'' desc';
wwv_flow_imp.g_varchar2_table(151) := 'ription,''milestone,spec'' tags,cast(null as varchar2(30)) impact from dual '||wwv_flow.LF||
'union all '||wwv_flow.LF||
'select 2,''Demo';
wwv_flow_imp.g_varchar2_table(152) := 'nstrable'',22,-25,-18,14,-18,-27,-18,''Demonstrated to stakeholders.'',''milestone,demo'',cast(null as va';
wwv_flow_imp.g_varchar2_table(153) := 'rchar2(30)) from dual '||wwv_flow.LF||
'union all '||wwv_flow.LF||
'select 3,''Code Complete'',23,-5,15,11,-2,-7,-2,''Implementation in p';
wwv_flow_imp.g_varchar2_table(154) := 'rogress.'',''milestone,code'',cast(null as varchar2(30)) from dual '||wwv_flow.LF||
'union all '||wwv_flow.LF||
'select 4,''Implementation';
wwv_flow_imp.g_varchar2_table(155) := ' Review'',11,-8,12,4,-3,-10,-3,''Implementation review in progress.'',''review,implementation'',''High'' fr';
wwv_flow_imp.g_varchar2_table(156) := 'om dual) t;'||wwv_flow.LF||
''||wwv_flow.LF||
'sp_globals.g_audit_this := TRUE;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        sp_globals.g_a';
wwv_flow_imp.g_varchar2_table(157) := 'udit_this := TRUE;'||wwv_flow.LF||
'end;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(454656742611805325)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sample data - insight 2.0'
,p_sequence=>9270
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
