prompt --application/deployment/install/install_sp_app_nomenclature_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_app_nomenclature table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_app_nomenclature ('||wwv_flow.LF||
'    id                             number default on null to_numb';
wwv_flow_imp.g_varchar2_table(2) := 'er(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp';
wwv_flow_imp.g_varchar2_table(3) := '_app_nomenclature_pk primary key,'||wwv_flow.LF||
'    static_id                      varchar2(50 char),'||wwv_flow.LF||
'    default_';
wwv_flow_imp.g_varchar2_table(4) := 'order                  number,'||wwv_flow.LF||
'    custom_value                   varchar2(50 char),'||wwv_flow.LF||
'    default_val';
wwv_flow_imp.g_varchar2_table(5) := 'ue                  varchar2(50 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    description                    varchar2(4000 char)';
wwv_flow_imp.g_varchar2_table(6) := ','||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by                     varcha';
wwv_flow_imp.g_varchar2_table(7) := 'r2(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by             ';
wwv_flow_imp.g_varchar2_table(8) := '        varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index sp_app_nomenclature_u1 on sp_app_nomencl';
wwv_flow_imp.g_varchar2_table(9) := 'ature (static_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_app_nomenclature_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(10) := '  on sp_app_nomenclature'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl';
wwv_flow_imp.g_varchar2_table(11) := '(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coalesce(sys_context(''APEX$S';
wwv_flow_imp.g_varchar2_table(12) := 'ESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updat';
wwv_flow_imp.g_varchar2_table(13) := 'ed_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif upda';
wwv_flow_imp.g_varchar2_table(14) := 'ting then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$';
wwv_flow_imp.g_varchar2_table(15) := 'SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.static_id := upper(:new.static_id);'||wwv_flow.LF||
'end sp_a';
wwv_flow_imp.g_varchar2_table(16) := 'pp_nomenclature_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38666223530644333316)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_app_nomenclature table and trigger'
,p_sequence=>3100
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
