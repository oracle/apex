prompt --application/deployment/install/install_sp_comment_util_spec
begin
--   Manifest
--     INSTALL: INSTALL-sp_comment_util spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package sp_comment_util as'||wwv_flow.LF||
''||wwv_flow.LF||
'-- used in the views to swap in current user''s session';
wwv_flow_imp.g_varchar2_table(2) := ' id'||wwv_flow.LF||
'function replace_session_on_display ('||wwv_flow.LF||
'    p_body        in  clob,'||wwv_flow.LF||
'    p_session_id  in  number )';
wwv_flow_imp.g_varchar2_table(3) := ''||wwv_flow.LF||
'    return clob;'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_initiative_comment ('||wwv_flow.LF||
'    p_app_use';
wwv_flow_imp.g_varchar2_table(4) := 'r_id     in  number,'||wwv_flow.LF||
'    p_app_user        in  varchar2,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_p';
wwv_flow_imp.g_varchar2_table(5) := 'rivate_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_initiative_id   in  number,'||wwv_flow.LF||
'    p_app_id          in ';
wwv_flow_imp.g_varchar2_table(6) := ' number,'||wwv_flow.LF||
'    p_link            in  varchar2,'||wwv_flow.LF||
'    p_nomen_sp        in  varchar2,'||wwv_flow.LF||
'    p_image_ref_id ';
wwv_flow_imp.g_varchar2_table(7) := '   in  number   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_initiative_comment ('||wwv_flow.LF||
'    p_comment_id      in  num';
wwv_flow_imp.g_varchar2_table(8) := 'ber,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_image';
wwv_flow_imp.g_varchar2_table(9) := '_ref_id    in  number   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_initiative_comment ('||wwv_flow.LF||
'    p_comment_id     ';
wwv_flow_imp.g_varchar2_table(10) := ' in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_project_comment ('||wwv_flow.LF||
'    p_app_user_id     in  number,'||wwv_flow.LF||
'    p_app_user   ';
wwv_flow_imp.g_varchar2_table(11) := '     in  varchar2,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ''N';
wwv_flow_imp.g_varchar2_table(12) := ''','||wwv_flow.LF||
'    p_project_id      in  number,'||wwv_flow.LF||
'    p_system_gen_yn   in  varchar2 default ''N'','||wwv_flow.LF||
'    p_app_id   ';
wwv_flow_imp.g_varchar2_table(13) := '       in  number   default null,'||wwv_flow.LF||
'    p_permalink_pre   in  varchar2 default null,'||wwv_flow.LF||
'    p_nomen_sp   ';
wwv_flow_imp.g_varchar2_table(14) := '     in  varchar2 default null,'||wwv_flow.LF||
'    p_nomen_project   in  varchar2 default null,'||wwv_flow.LF||
'    p_image_ref_id ';
wwv_flow_imp.g_varchar2_table(15) := '   in  number   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_project_comment ('||wwv_flow.LF||
'    p_comment_id      in  number';
wwv_flow_imp.g_varchar2_table(16) := ','||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_image_re';
wwv_flow_imp.g_varchar2_table(17) := 'f_id    in  number   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_project_comment ('||wwv_flow.LF||
'    p_comment_id      in  n';
wwv_flow_imp.g_varchar2_table(18) := 'umber );'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_task_comment ('||wwv_flow.LF||
'    p_app_user_id     in  number,'||wwv_flow.LF||
'    p_app_user        in  ';
wwv_flow_imp.g_varchar2_table(19) := 'varchar2,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(20) := 'project_id      in  number,'||wwv_flow.LF||
'    p_task_id         in  number,'||wwv_flow.LF||
'    p_app_id          in  number,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(21) := 'p_link            in  varchar2,'||wwv_flow.LF||
'    p_nomen_sp        in  varchar2,'||wwv_flow.LF||
'    p_image_ref_id    in  number';
wwv_flow_imp.g_varchar2_table(22) := '   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_task_comment ('||wwv_flow.LF||
'    p_comment_id      in  number,'||wwv_flow.LF||
'    p_comment ';
wwv_flow_imp.g_varchar2_table(23) := '        in  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_image_ref_id    in  numb';
wwv_flow_imp.g_varchar2_table(24) := 'er   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_task_comment ('||wwv_flow.LF||
'    p_comment_id      in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedur';
wwv_flow_imp.g_varchar2_table(25) := 'e add_release_comment ('||wwv_flow.LF||
'    p_app_user_id     in  number,'||wwv_flow.LF||
'    p_app_user        in  varchar2,'||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(26) := 'comment         in  varchar2,'||wwv_flow.LF||
'    p_release_id      in  number,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 d';
wwv_flow_imp.g_varchar2_table(27) := 'efault ''N'','||wwv_flow.LF||
'    p_app_id          in  number,'||wwv_flow.LF||
'    p_link            in  varchar2,'||wwv_flow.LF||
'    p_nomen_sp    ';
wwv_flow_imp.g_varchar2_table(28) := '    in  varchar2,'||wwv_flow.LF||
'    p_image_ref_id    in  number   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_release_comme';
wwv_flow_imp.g_varchar2_table(29) := 'nt ('||wwv_flow.LF||
'    p_comment_id      in  number,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_private_yn      in ';
wwv_flow_imp.g_varchar2_table(30) := ' varchar2 default ''N'','||wwv_flow.LF||
'    p_image_ref_id    in  number   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_release_';
wwv_flow_imp.g_varchar2_table(31) := 'comment ('||wwv_flow.LF||
'    p_comment_id      in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
' procedure add_init_focus_area_comment ('||wwv_flow.LF||
'    p_app_u';
wwv_flow_imp.g_varchar2_table(32) := 'ser_id         in  number,'||wwv_flow.LF||
'    p_app_user            in  varchar2,'||wwv_flow.LF||
'    p_comment             in  var';
wwv_flow_imp.g_varchar2_table(33) := 'char2,'||wwv_flow.LF||
'    p_init_focus_area_id  in  number,'||wwv_flow.LF||
'    p_private_yn          in  varchar2 default ''N'','||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(34) := ' p_app_id              in  number,'||wwv_flow.LF||
'    p_link                in  varchar2,'||wwv_flow.LF||
'    p_nomen_sp           ';
wwv_flow_imp.g_varchar2_table(35) := ' in  varchar2, '||wwv_flow.LF||
'    p_image_ref_id        in  number   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_init_focus_';
wwv_flow_imp.g_varchar2_table(36) := 'area_comment ('||wwv_flow.LF||
'    p_comment_id      in  number,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_private_y';
wwv_flow_imp.g_varchar2_table(37) := 'n      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_image_ref_id    in  number   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delet';
wwv_flow_imp.g_varchar2_table(38) := 'e_init_focus_area_comment ('||wwv_flow.LF||
'    p_comment_id      in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_activity_comment ('||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(39) := '   p_app_user_id     in  number,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  varch';
wwv_flow_imp.g_varchar2_table(40) := 'ar2 default ''N'','||wwv_flow.LF||
'    p_activity_id     in  number,'||wwv_flow.LF||
'    p_image_ref_id    in  number   default null )';
wwv_flow_imp.g_varchar2_table(41) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_activity_comment ('||wwv_flow.LF||
'    p_comment_id      in  number,'||wwv_flow.LF||
'    p_comment         in  v';
wwv_flow_imp.g_varchar2_table(42) := 'archar2,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_image_ref_id    in  number   default ';
wwv_flow_imp.g_varchar2_table(43) := 'null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_activity_comment ('||wwv_flow.LF||
'    p_comment_id      in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
'------------------';
wwv_flow_imp.g_varchar2_table(44) := '----'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure upload_image ('||wwv_flow.LF||
'    p_file_base64           in  clob,'||wwv_flow.LF||
'    p_filename              in ';
wwv_flow_imp.g_varchar2_table(45) := ' varchar2,'||wwv_flow.LF||
'    p_mimetype              in  varchar2,'||wwv_flow.LF||
'    p_image_ref_id          in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
'proc';
wwv_flow_imp.g_varchar2_table(46) := 'edure display_image ('||wwv_flow.LF||
'    p_unique_filename  in  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'----------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'-- used to pop';
wwv_flow_imp.g_varchar2_table(47) := 'ulate mention lov in comments'||wwv_flow.LF||
'function get_mentions ('||wwv_flow.LF||
'    p_search     in  varchar2,'||wwv_flow.LF||
'    p_scope    ';
wwv_flow_imp.g_varchar2_table(48) := '  in  varchar2, -- PROJECT, TASK, RELEASE, INITIATIVE, FOCUS_AREA'||wwv_flow.LF||
'    p_object_id  in  number'||wwv_flow.LF||
') retu';
wwv_flow_imp.g_varchar2_table(49) := 'rn clob;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- used to populate doc selector in comments'||wwv_flow.LF||
'function get_doc_links ('||wwv_flow.LF||
'    p_search        ';
wwv_flow_imp.g_varchar2_table(50) := '   in  varchar2,'||wwv_flow.LF||
'    p_scope            in  varchar2, -- PROJECT, TASK, RELEASE, INITIATIVE, FOCUS_A';
wwv_flow_imp.g_varchar2_table(51) := 'REA,'||wwv_flow.LF||
'    p_object_id        in  number'||wwv_flow.LF||
') return clob;'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_comment_util;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(22990218013336819424)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_comment_util spec'
,p_sequence=>2050
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
