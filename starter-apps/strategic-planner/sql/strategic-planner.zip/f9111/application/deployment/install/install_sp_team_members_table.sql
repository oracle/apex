prompt --application/deployment/install/install_sp_team_members_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_team_members table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_team_members ('||wwv_flow.LF||
'    id                             number default on null to_number(s';
wwv_flow_imp.g_varchar2_table(2) := 'ys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_tea';
wwv_flow_imp.g_varchar2_table(3) := 'm_members_id_pk primary key,'||wwv_flow.LF||
'    first_name                     varchar2(255 char) not null,'||wwv_flow.LF||
'    las';
wwv_flow_imp.g_varchar2_table(4) := 't_name                      varchar2(255 char) not null,'||wwv_flow.LF||
'    initials                       varchar2';
wwv_flow_imp.g_varchar2_table(5) := '(3 char)   not null,'||wwv_flow.LF||
'    screen_name                    varchar2(50 char),'||wwv_flow.LF||
'    email                ';
wwv_flow_imp.g_varchar2_table(6) := '          varchar2(255 char) not null,'||wwv_flow.LF||
'    email_domain                   varchar2(255 char),'||wwv_flow.LF||
'    no';
wwv_flow_imp.g_varchar2_table(7) := 'tification_pref              varchar2(255 char), -- colon separated list of APP, EMAIL, TEXT, SLACK'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(8) := '    comment_notif_pref             varchar2(255 char), -- colon separated list of APP, EMAIL, TEXT, ';
wwv_flow_imp.g_varchar2_table(9) := 'SLACK'||wwv_flow.LF||
'    tags                           varchar2(4000 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    photo                      ';
wwv_flow_imp.g_varchar2_table(10) := '    blob,'||wwv_flow.LF||
'    photo_filename                 varchar2(512 char),'||wwv_flow.LF||
'    photo_mimetype                 ';
wwv_flow_imp.g_varchar2_table(11) := 'varchar2(512 char),'||wwv_flow.LF||
'    photo_charset                  varchar2(512 char),'||wwv_flow.LF||
'    photo_lastupd        ';
wwv_flow_imp.g_varchar2_table(12) := '          date,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    is_current_yn                  varchar2(1 char) constraint sp_team_member';
wwv_flow_imp.g_varchar2_table(13) := 's_is_current_ck'||wwv_flow.LF||
'                                   check (is_current_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    auto_crea';
wwv_flow_imp.g_varchar2_table(14) := 'ted_yn                varchar2(1 char) constraint sp_team_members_auto_cr_ck'||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(15) := '            check (auto_created_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    location                       varchar2(500 ch';
wwv_flow_imp.g_varchar2_table(16) := 'ar),'||wwv_flow.LF||
'    country_id                     number,'||wwv_flow.LF||
'    timezone                       varchar2(255 char';
wwv_flow_imp.g_varchar2_table(17) := '),'||wwv_flow.LF||
'    hp_my_activities_yn            varchar2(1 char) default on null ''Y'','||wwv_flow.LF||
'    hp_my_initiatives_yn';
wwv_flow_imp.g_varchar2_table(18) := '           varchar2(1 char) default on null ''Y'','||wwv_flow.LF||
'    hp_my_projects_yn              varchar2(1 char)';
wwv_flow_imp.g_varchar2_table(19) := ' default on null ''Y'','||wwv_flow.LF||
'    hp_my_fav_projects_yn          varchar2(1 char) default on null ''N'','||wwv_flow.LF||
'    h';
wwv_flow_imp.g_varchar2_table(20) := 'p_my_open_releases_yn         varchar2(1 char) default on null ''Y'','||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    app_role             ';
wwv_flow_imp.g_varchar2_table(21) := '          varchar2(255 char), -- derived'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    competencies                   varchar2(4000 cha';
wwv_flow_imp.g_varchar2_table(22) := 'r),'||wwv_flow.LF||
'    ooo_summary                    varchar2(4000),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- audit columns'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    create';
wwv_flow_imp.g_varchar2_table(23) := 'd                        date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not nu';
wwv_flow_imp.g_varchar2_table(24) := 'll,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(25';
wwv_flow_imp.g_varchar2_table(25) := '5 char) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index sp_team_members_u1 on sp_team_members (email);'||wwv_flow.LF||
'create uniq';
wwv_flow_imp.g_varchar2_table(26) := 'ue index sp_team_members_u2 on sp_team_members (screen_name);'||wwv_flow.LF||
'create index sp_team_members_i1 on sp_';
wwv_flow_imp.g_varchar2_table(27) := 'team_members (country_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'comment on column sp_team_members.hp_my_activities_yn    is ''Identifies ';
wwv_flow_imp.g_varchar2_table(28) := 'if My Activities region will display on home page (contains current and future activities).'';'||wwv_flow.LF||
'commen';
wwv_flow_imp.g_varchar2_table(29) := 't on column sp_team_members.hp_my_initiatives_yn   is ''Identifies if My Initiatives region will disp';
wwv_flow_imp.g_varchar2_table(30) := 'lay on home page (you own the initiative, own a project within, or are a project contributor within)';
wwv_flow_imp.g_varchar2_table(31) := '.'';'||wwv_flow.LF||
'comment on column sp_team_members.hp_my_projects_yn      is ''Identifies if My Projects region wi';
wwv_flow_imp.g_varchar2_table(32) := 'll display on home page (you own the project or have an active milestone, review or task on that pro';
wwv_flow_imp.g_varchar2_table(33) := 'ject).'';'||wwv_flow.LF||
'comment on column sp_team_members.hp_my_fav_projects_yn  is ''Identifies if My Favorite Proj';
wwv_flow_imp.g_varchar2_table(34) := 'ects region will display on home page (all projects you have favorited).'';'||wwv_flow.LF||
'comment on column sp_team';
wwv_flow_imp.g_varchar2_table(35) := '_members.hp_my_open_releases_yn is ''Identifies if My Open Releases region will display on home page ';
wwv_flow_imp.g_varchar2_table(36) := '(you own the release, own a project within, own a task within a project within, or own a project act';
wwv_flow_imp.g_varchar2_table(37) := 'ivity within).'';'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38666281374522346821)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_team_members table'
,p_sequence=>3070
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
