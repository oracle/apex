prompt --application/deployment/install/install_sp_default_people_tags_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_default_people_tags trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_default_people_tags_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_default_p';
wwv_flow_imp.g_varchar2_table(2) := 'eople_tags'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,';
wwv_flow_imp.g_varchar2_table(3) := 'sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_U';
wwv_flow_imp.g_varchar2_table(4) := 'SER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:';
wwv_flow_imp.g_varchar2_table(5) := 'new.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(6) := '    :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_';
wwv_flow_imp.g_varchar2_table(7) := 'USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.tag := upper(:new.tag);'||wwv_flow.LF||
'    :new.tag := replace(trim(:new.';
wwv_flow_imp.g_varchar2_table(8) := 'tag),'' '',''-'');'||wwv_flow.LF||
'    :new.tag := replace(trim(:new.tag),''_'',''-'');'||wwv_flow.LF||
'end sp_default_people_tags_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(40988980366855270001)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_default_people_tags trigger'
,p_sequence=>4190
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
