prompt --application/deployment/install/install_sp_application_notifications_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_application_notifications table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_application_notifications ('||wwv_flow.LF||
'    id                             number default on nul';
wwv_flow_imp.g_varchar2_table(2) := 'l to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   cons';
wwv_flow_imp.g_varchar2_table(3) := 'traint sp_application_notifications_pk primary key,'||wwv_flow.LF||
'    notification_name              varchar2(128 ';
wwv_flow_imp.g_varchar2_table(4) := 'char)   not null,'||wwv_flow.LF||
'    notification_description       varchar2(4000 char),'||wwv_flow.LF||
'    is_active_yn          ';
wwv_flow_imp.g_varchar2_table(5) := '         varchar2(1 char)    not null,'||wwv_flow.LF||
'    required_user_tag              varchar2(30 char),'||wwv_flow.LF||
'    fro';
wwv_flow_imp.g_varchar2_table(6) := 'm_date                      date,'||wwv_flow.LF||
'    to_date                        date,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created       ';
wwv_flow_imp.g_varchar2_table(7) := '                 date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(8) := 'updated                        date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) ';
wwv_flow_imp.g_varchar2_table(9) := 'not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index sp_application_notifications_u1 on sp_application_notifications(no';
wwv_flow_imp.g_varchar2_table(10) := 'tification_name);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_application_notifications_biu'||wwv_flow.LF||
'    before insert or ';
wwv_flow_imp.g_varchar2_table(11) := 'update'||wwv_flow.LF||
'    on sp_application_notifications'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new';
wwv_flow_imp.g_varchar2_table(12) := '.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coalesce(s';
wwv_flow_imp.g_varchar2_table(13) := 'ys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(14) := '        :new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user';
wwv_flow_imp.g_varchar2_table(15) := '));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(';
wwv_flow_imp.g_varchar2_table(16) := 'sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_application_notifications_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(41353261951098898629)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_application_notifications table and trigger'
,p_sequence=>3540
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
