prompt --application/deployment/install/install_sp_comment_util_body
begin
--   Manifest
--     INSTALL: INSTALL-sp_comment_util body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body sp_comment_util as'||wwv_flow.LF||
''||wwv_flow.LF||
'g_session_placeholder constant varchar2(20) := ''~';
wwv_flow_imp.g_varchar2_table(2) := 'RTE*SESS~'';'||wwv_flow.LF||
''||wwv_flow.LF||
'-- this removes images from abandoned comments (ie. comments never created but images u';
wwv_flow_imp.g_varchar2_table(3) := 'ploaded)'||wwv_flow.LF||
'--   this is executed each time a comment is scanned to avoid the need for a job to do the ';
wwv_flow_imp.g_varchar2_table(4) := 'cleanup'||wwv_flow.LF||
'procedure cleanup_old_images'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    delete from sp_comment_images'||wwv_flow.LF||
'     where image_ref';
wwv_flow_imp.g_varchar2_table(5) := '_id not in '||wwv_flow.LF||
'           (select image_ref_id '||wwv_flow.LF||
'              from sp_initiative_comments'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(6) := 'where image_ref_id is not null'||wwv_flow.LF||
'             union all'||wwv_flow.LF||
'            select image_ref_id '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(7) := ' from sp_project_comments'||wwv_flow.LF||
'             where image_ref_id is not null'||wwv_flow.LF||
'             union all'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(8) := '     select image_ref_id '||wwv_flow.LF||
'              from sp_task_comments'||wwv_flow.LF||
'             where image_ref_id is not';
wwv_flow_imp.g_varchar2_table(9) := ' null'||wwv_flow.LF||
'             union all'||wwv_flow.LF||
'            select image_ref_id '||wwv_flow.LF||
'              from sp_release_comments';
wwv_flow_imp.g_varchar2_table(10) := ''||wwv_flow.LF||
'             where image_ref_id is not null'||wwv_flow.LF||
'             union all'||wwv_flow.LF||
'            select image_ref_id ';
wwv_flow_imp.g_varchar2_table(11) := ''||wwv_flow.LF||
'              from sp_init_focus_area_comments'||wwv_flow.LF||
'             where image_ref_id is not null'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(12) := '     union all'||wwv_flow.LF||
'            select image_ref_id '||wwv_flow.LF||
'              from sp_activity_comments'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(13) := ' where image_ref_id is not null )'||wwv_flow.LF||
'       and created < sysdate-1;'||wwv_flow.LF||
'end cleanup_old_images;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- this ';
wwv_flow_imp.g_varchar2_table(14) := 'finds all the names of images within a clob'||wwv_flow.LF||
'function find_images ('||wwv_flow.LF||
'    p_clob  in  clob )'||wwv_flow.LF||
'    return';
wwv_flow_imp.g_varchar2_table(15) := ' varchar2 '||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_clob                clob;'||wwv_flow.LF||
'    l_clob_length         integer;'||wwv_flow.LF||
'    l_image_prefix ';
wwv_flow_imp.g_varchar2_table(16) := '       varchar2(255)  := ''](''||sp_util.get_setting(p_static_id => ''GET_COMMENT_IMAGE_PREFIX'')||''get-';
wwv_flow_imp.g_varchar2_table(17) := 'image?x01='';'||wwv_flow.LF||
'    l_prefix_length       number         := length(l_image_prefix);'||wwv_flow.LF||
'    l_image_list   ';
wwv_flow_imp.g_varchar2_table(18) := '       varchar2(4000) := null;'||wwv_flow.LF||
'    l_start               integer        := 1;'||wwv_flow.LF||
'    l_match           ';
wwv_flow_imp.g_varchar2_table(19) := '    integer;'||wwv_flow.LF||
'    l_image_name          varchar2(255);'||wwv_flow.LF||
'    l_loop_count          integer        := 0;';
wwv_flow_imp.g_varchar2_table(20) := ''||wwv_flow.LF||
'    l_max_loops           integer        := 100;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- remove session placeholder (if it exi';
wwv_flow_imp.g_varchar2_table(21) := 'sts)'||wwv_flow.LF||
'    l_clob := replace(p_clob,''session=''||g_session_placeholder||''&'','''');'||wwv_flow.LF||
'    -- Get the length ';
wwv_flow_imp.g_varchar2_table(22) := 'of the input clob'||wwv_flow.LF||
'    l_clob_length := sys.dbms_lob.getlength(l_clob);'||wwv_flow.LF||
'    -- Loop through the clob ';
wwv_flow_imp.g_varchar2_table(23) := 'to extract image names'||wwv_flow.LF||
'    while l_start <= l_clob_length loop'||wwv_flow.LF||
'        if l_loop_count > l_max_loops';
wwv_flow_imp.g_varchar2_table(24) := ' then'||wwv_flow.LF||
'            exit; -- prevent infinite loop'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        l_match := null;'||wwv_flow.LF||
'        --';
wwv_flow_imp.g_varchar2_table(25) := ' will find the beginning of the image string'||wwv_flow.LF||
'        l_match := instr(l_clob, l_image_prefix, l_star';
wwv_flow_imp.g_varchar2_table(26) := 't, 1);'||wwv_flow.LF||
'        exit when l_match = 0;'||wwv_flow.LF||
'        -- extract the image name'||wwv_flow.LF||
'        l_image_name := subs';
wwv_flow_imp.g_varchar2_table(27) := 'tr(l_clob, l_match + l_prefix_length, 22);'||wwv_flow.LF||
'        -- Append to the image list'||wwv_flow.LF||
'        if l_image_li';
wwv_flow_imp.g_varchar2_table(28) := 'st is not null then'||wwv_flow.LF||
'            l_image_list := l_image_list || '':'' || l_image_name;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(29) := '          l_image_list := l_image_name;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- Move position forward to continue';
wwv_flow_imp.g_varchar2_table(30) := ' searching'||wwv_flow.LF||
'        l_start := l_start + l_match + l_prefix_length + 22;'||wwv_flow.LF||
'        l_loop_count := l_lo';
wwv_flow_imp.g_varchar2_table(31) := 'op_count + 1;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    return l_image_list;'||wwv_flow.LF||
'end find_images;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- this finds all the i';
wwv_flow_imp.g_varchar2_table(32) := 'mage links in a clob and replaces with [image], for use in IRs and emails'||wwv_flow.LF||
'function replace_images ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(33) := '    p_clob  in  clob )'||wwv_flow.LF||
'    return clob '||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_clob_length         integer;'||wwv_flow.LF||
'    l_image_prefix    ';
wwv_flow_imp.g_varchar2_table(34) := '    varchar2(255);'||wwv_flow.LF||
'    l_prefix_length       number;'||wwv_flow.LF||
'    l_image_list          varchar2(4000) := nul';
wwv_flow_imp.g_varchar2_table(35) := 'l;'||wwv_flow.LF||
'    l_start               integer        := 1;'||wwv_flow.LF||
'    l_match               integer;'||wwv_flow.LF||
'    l_begin    ';
wwv_flow_imp.g_varchar2_table(36) := '           integer;'||wwv_flow.LF||
'    l_image_name          varchar2(255);'||wwv_flow.LF||
'    l_alt_text            varchar2(4000';
wwv_flow_imp.g_varchar2_table(37) := ');'||wwv_flow.LF||
'    l_filename            varchar2(255);'||wwv_flow.LF||
'    l_loop_count          integer        := 0;'||wwv_flow.LF||
'    l_max';
wwv_flow_imp.g_varchar2_table(38) := '_loops           integer        := 100;'||wwv_flow.LF||
'    l_clob                clob           := p_clob;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(39) := '  -- Get the length of the input clob'||wwv_flow.LF||
'    l_clob_length := sys.dbms_lob.getlength(p_clob);'||wwv_flow.LF||
''||wwv_flow.LF||
'-- first';
wwv_flow_imp.g_varchar2_table(40) := ' check without session - if needed, a second loop using session'||wwv_flow.LF||
'    for i in 1..2 loop'||wwv_flow.LF||
'        if i ';
wwv_flow_imp.g_varchar2_table(41) := '= 1 then'||wwv_flow.LF||
'           l_image_prefix   := ''](''||sp_util.get_setting(p_static_id => ''GET_COMMENT_IMAGE_';
wwv_flow_imp.g_varchar2_table(42) := 'PREFIX'')||''get-image?x01='';'||wwv_flow.LF||
'           l_prefix_length  := length(l_image_prefix);'||wwv_flow.LF||
'           l_star';
wwv_flow_imp.g_varchar2_table(43) := 't          := 1;'||wwv_flow.LF||
'           l_loop_count     := 0;    '||wwv_flow.LF||
'        else'||wwv_flow.LF||
'           -- Search again inclu';
wwv_flow_imp.g_varchar2_table(44) := 'ding session'||wwv_flow.LF||
'           l_image_prefix   := ''](''||sp_util.get_setting(p_static_id => ''GET_COMMENT_IM';
wwv_flow_imp.g_varchar2_table(45) := 'AGE_PREFIX'')||''get-image?session=''||g_session_placeholder||''&x01='';'||wwv_flow.LF||
'           l_prefix_length  := l';
wwv_flow_imp.g_varchar2_table(46) := 'ength(l_image_prefix);'||wwv_flow.LF||
'           l_start          := 1;'||wwv_flow.LF||
'           l_loop_count     := 0;'||wwv_flow.LF||
'        e';
wwv_flow_imp.g_varchar2_table(47) := 'nd if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- Loop through the clob to find and replace image names'||wwv_flow.LF||
'        while l_start <= l_';
wwv_flow_imp.g_varchar2_table(48) := 'clob_length loop'||wwv_flow.LF||
'            if l_loop_count > l_max_loops then'||wwv_flow.LF||
'                exit; -- prevent inf';
wwv_flow_imp.g_varchar2_table(49) := 'inite loop'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            l_match := null;'||wwv_flow.LF||
'            -- will find the beginning o';
wwv_flow_imp.g_varchar2_table(50) := 'f the image string'||wwv_flow.LF||
'            l_match := instr(p_clob, l_image_prefix, l_start, 1);'||wwv_flow.LF||
'            exi';
wwv_flow_imp.g_varchar2_table(51) := 't when l_match = 0;'||wwv_flow.LF||
'            -- extract the image name'||wwv_flow.LF||
'            l_image_name := substr(p_clob,';
wwv_flow_imp.g_varchar2_table(52) := ' l_match + l_prefix_length, 22);'||wwv_flow.LF||
'            -- if no alt text added, find image name'||wwv_flow.LF||
'            if';
wwv_flow_imp.g_varchar2_table(53) := ' substr(p_clob,l_match-2,2) = ''!['' then'||wwv_flow.LF||
'               -- find filename of image, if was file and no';
wwv_flow_imp.g_varchar2_table(54) := 't screensnap'||wwv_flow.LF||
'               -- if image gets delete from images table, editing the content will fail';
wwv_flow_imp.g_varchar2_table(55) := ' to save'||wwv_flow.LF||
'               --    wrapping this allows l_filename to be null, which is handled during re';
wwv_flow_imp.g_varchar2_table(56) := 'placement'||wwv_flow.LF||
'               begin'||wwv_flow.LF||
'                   select filename'||wwv_flow.LF||
'                     into l_filena';
wwv_flow_imp.g_varchar2_table(57) := 'me'||wwv_flow.LF||
'                     from sp_comment_images'||wwv_flow.LF||
'                    where unique_filename = l_image_n';
wwv_flow_imp.g_varchar2_table(58) := 'ame;'||wwv_flow.LF||
'               exception'||wwv_flow.LF||
'                   when no_data_found then null;'||wwv_flow.LF||
'               end;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(59) := '              -- replace image link'||wwv_flow.LF||
'               if nvl(l_filename,''image.png'') != ''image.png'' the';
wwv_flow_imp.g_varchar2_table(60) := 'n'||wwv_flow.LF||
'                   -- if link was added to image, there will be extra square brackets'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(61) := '       l_clob := replace(l_clob,''[![''||l_image_prefix||l_image_name||'')]'',''[''||l_filename||'']'');'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(62) := '                l_clob := replace(l_clob,''![''||l_image_prefix||l_image_name||'')'',''[''||l_filename||'']';
wwv_flow_imp.g_varchar2_table(63) := ''');'||wwv_flow.LF||
'               else'||wwv_flow.LF||
'                   -- if link was added to image, there will be extra square';
wwv_flow_imp.g_varchar2_table(64) := ' brackets'||wwv_flow.LF||
'                   l_clob := replace(l_clob,''[![''||l_image_prefix||l_image_name||'')]'',''[im';
wwv_flow_imp.g_varchar2_table(65) := 'age]'');'||wwv_flow.LF||
'                   l_clob := replace(l_clob,''![''||l_image_prefix||l_image_name||'')'',''[image]';
wwv_flow_imp.g_varchar2_table(66) := ''');'||wwv_flow.LF||
'               end if;'||wwv_flow.LF||
'               l_filename := null;'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'                l_beg';
wwv_flow_imp.g_varchar2_table(67) := 'in     := instr(p_clob, ''!['', -(l_clob_length-l_match), 1);'||wwv_flow.LF||
'                l_alt_text  := substr(p_';
wwv_flow_imp.g_varchar2_table(68) := 'clob, l_begin+2, l_match-l_begin-2);'||wwv_flow.LF||
'                -- if link was added to image, there will be ex';
wwv_flow_imp.g_varchar2_table(69) := 'tra square brackets'||wwv_flow.LF||
'                l_clob      := replace(l_clob,''[![''||l_alt_text||l_image_prefix|';
wwv_flow_imp.g_varchar2_table(70) := '|l_image_name||'')]'',''[''||l_alt_text||'']'');'||wwv_flow.LF||
'                l_clob      := replace(l_clob,''![''||l_alt';
wwv_flow_imp.g_varchar2_table(71) := '_text||l_image_prefix||l_image_name||'')'',''[''||l_alt_text||'']'');'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- ';
wwv_flow_imp.g_varchar2_table(72) := 'Move position forward to continue searching'||wwv_flow.LF||
'            l_start := l_match + l_prefix_length + 22;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(73) := '           l_loop_count := l_loop_count + 1;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- if any images replace the';
wwv_flow_imp.g_varchar2_table(74) := 'n no need to check using session'||wwv_flow.LF||
'        if l_image_name is not null then'||wwv_flow.LF||
'           return l_clob;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(75) := '        end if;  '||wwv_flow.LF||
''||wwv_flow.LF||
'    end loop; '||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_clob;'||wwv_flow.LF||
'end replace_images;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function replace_session';
wwv_flow_imp.g_varchar2_table(76) := '_on_save ('||wwv_flow.LF||
'    p_body        in  clob )'||wwv_flow.LF||
'    return clob'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_body  clob := p_body;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_b';
wwv_flow_imp.g_varchar2_table(77) := 'ody := regexp_replace(l_body, ''(\?|&)(session=)([[:digit:]]+)'', ''\1\2'' || g_session_placeholder);'||wwv_flow.LF||
''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(78) := '   l_body := regexp_replace(l_body, ''(%26session%3D)[0-9]+(%26)'', ''\1''||g_session_placeholder||''\2'')';
wwv_flow_imp.g_varchar2_table(79) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_body;'||wwv_flow.LF||
'end replace_session_on_save;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function replace_session_on_display ('||wwv_flow.LF||
'    p_bod';
wwv_flow_imp.g_varchar2_table(80) := 'y        in  clob,'||wwv_flow.LF||
'    p_session_id  in  number )'||wwv_flow.LF||
'    return clob'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_body  clob := p_body;'||wwv_flow.LF||
'beg';
wwv_flow_imp.g_varchar2_table(81) := 'in'||wwv_flow.LF||
'    l_body := replace(l_body, ''session=''||g_session_placeholder, ''session='' || p_session_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(82) := '  l_body := replace(l_body, ''%26session%3D''||g_session_placeholder, ''%26session%3D'' || p_session_id)';
wwv_flow_imp.g_varchar2_table(83) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_body;'||wwv_flow.LF||
'end replace_session_on_display;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- images can be removed during edit or past';
wwv_flow_imp.g_varchar2_table(84) := 'ed in and then removed before create'||wwv_flow.LF||
'--   this ensures those are removed'||wwv_flow.LF||
'procedure remove_orphan_ima';
wwv_flow_imp.g_varchar2_table(85) := 'ges ('||wwv_flow.LF||
'    p_comment_id    in  number,'||wwv_flow.LF||
'    p_comment_type  in  varchar2 )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_image_ref_id  numb';
wwv_flow_imp.g_varchar2_table(86) := 'er;'||wwv_flow.LF||
'    l_body          clob;'||wwv_flow.LF||
'    l_image_list    varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if p_comment_type = ''INI';
wwv_flow_imp.g_varchar2_table(87) := 'TIATIVE'' then'||wwv_flow.LF||
'        select image_ref_id, body'||wwv_flow.LF||
'          into l_image_ref_id, l_body'||wwv_flow.LF||
'          from';
wwv_flow_imp.g_varchar2_table(88) := ' sp_initiative_comments'||wwv_flow.LF||
'         where id = p_comment_id;'||wwv_flow.LF||
'    elsif p_comment_type = ''PROJECT'' then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(89) := '        select image_ref_id, body'||wwv_flow.LF||
'          into l_image_ref_id, l_body'||wwv_flow.LF||
'          from sp_project_co';
wwv_flow_imp.g_varchar2_table(90) := 'mments'||wwv_flow.LF||
'         where id = p_comment_id;'||wwv_flow.LF||
'    elsif p_comment_type = ''TASK'' then'||wwv_flow.LF||
'        select image';
wwv_flow_imp.g_varchar2_table(91) := '_ref_id, body'||wwv_flow.LF||
'          into l_image_ref_id, l_body'||wwv_flow.LF||
'          from sp_task_comments'||wwv_flow.LF||
'         where i';
wwv_flow_imp.g_varchar2_table(92) := 'd = p_comment_id;'||wwv_flow.LF||
'    elsif p_comment_type = ''RELEASE'' then'||wwv_flow.LF||
'        select image_ref_id, body'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(93) := '    into l_image_ref_id, l_body'||wwv_flow.LF||
'          from sp_release_comments'||wwv_flow.LF||
'         where id = p_comment_id;';
wwv_flow_imp.g_varchar2_table(94) := ''||wwv_flow.LF||
'    elsif p_comment_type = ''INIT_FOCUS_AREA'' then'||wwv_flow.LF||
'        select image_ref_id, body'||wwv_flow.LF||
'          into ';
wwv_flow_imp.g_varchar2_table(95) := 'l_image_ref_id, l_body'||wwv_flow.LF||
'          from sp_init_focus_area_comments'||wwv_flow.LF||
'         where id = p_comment_id;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(96) := '    elsif p_comment_type = ''ACTIVITY'' then'||wwv_flow.LF||
'        select image_ref_id, body'||wwv_flow.LF||
'          into l_image_';
wwv_flow_imp.g_varchar2_table(97) := 'ref_id, l_body'||wwv_flow.LF||
'          from sp_activity_comments'||wwv_flow.LF||
'         where id = p_comment_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(98) := '  if l_image_ref_id is not null and l_body is not null then'||wwv_flow.LF||
'        l_image_list := '':''||find_images';
wwv_flow_imp.g_varchar2_table(99) := '(l_body)||'':'';'||wwv_flow.LF||
''||wwv_flow.LF||
'        delete from sp_comment_images'||wwv_flow.LF||
'         where image_ref_id = l_image_ref_id '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(100) := '           and instr(l_image_list,'':''||unique_filename||'':'') = 0;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end remove_orphan_imag';
wwv_flow_imp.g_varchar2_table(101) := 'es;'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure set_comment_email_references ('||wwv_flow.LF||
'    p_comment_id in n';
wwv_flow_imp.g_varchar2_table(102) := 'umber)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_results  apex_t_varchar2 := apex_t_varchar2();  '||wwv_flow.LF||
'    l_string   clob;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- ';
wwv_flow_imp.g_varchar2_table(103) := 'remove emails associated with this project comment'||wwv_flow.LF||
'    delete from sp_project_comments_emails where ';
wwv_flow_imp.g_varchar2_table(104) := 'comment_id = p_comment_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- add emails associated with this project comment'||wwv_flow.LF||
'    for c1 in (se';
wwv_flow_imp.g_varchar2_table(105) := 'lect body from sp_project_comments where id = p_comment_id) loop'||wwv_flow.LF||
'        l_string := c1.body;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(106) := '  l_results := apex_string_util.find_email_addresses(l_string);'||wwv_flow.LF||
'        for i in 1..l_results.count ';
wwv_flow_imp.g_varchar2_table(107) := 'loop'||wwv_flow.LF||
'            insert into sp_project_comments_emails ('||wwv_flow.LF||
'                comment_id, email) '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(108) := '      values ('||wwv_flow.LF||
'                p_comment_id, lower(l_results(i))'||wwv_flow.LF||
'            );'||wwv_flow.LF||
'        end loop; '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(109) := '   end loop; '||wwv_flow.LF||
'end set_comment_email_references;'||wwv_flow.LF||
''||wwv_flow.LF||
'----------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_i';
wwv_flow_imp.g_varchar2_table(110) := 'nitiative_comment ('||wwv_flow.LF||
'    p_app_user_id     in  number,'||wwv_flow.LF||
'    p_app_user        in  varchar2,'||wwv_flow.LF||
'    p_comm';
wwv_flow_imp.g_varchar2_table(111) := 'ent         in  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_initiative_id   in  ';
wwv_flow_imp.g_varchar2_table(112) := 'number,'||wwv_flow.LF||
'    p_app_id          in  number,'||wwv_flow.LF||
'    p_link            in  varchar2,'||wwv_flow.LF||
'    p_nomen_sp        ';
wwv_flow_imp.g_varchar2_table(113) := 'in  varchar2,'||wwv_flow.LF||
'    p_image_ref_id    in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_comment_id         number;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(114) := '    l_comment            clob;'||wwv_flow.LF||
'    l_comment_no_images  clob;'||wwv_flow.LF||
'    l_email_comment      clob;'||wwv_flow.LF||
'    l_m';
wwv_flow_imp.g_varchar2_table(115) := 'entions           varchar2(4000);'||wwv_flow.LF||
'begin '||wwv_flow.LF||
''||wwv_flow.LF||
'    l_comment           := replace_session_on_save(p_comme';
wwv_flow_imp.g_varchar2_table(116) := 'nt);'||wwv_flow.LF||
'    l_comment_no_images := replace_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_initiative_comments (';
wwv_flow_imp.g_varchar2_table(117) := ''||wwv_flow.LF||
'        initiative_id, '||wwv_flow.LF||
'        author_id, '||wwv_flow.LF||
'        body,'||wwv_flow.LF||
'        body_html, '||wwv_flow.LF||
'        body_no_image';
wwv_flow_imp.g_varchar2_table(118) := 's,'||wwv_flow.LF||
'        private_yn,'||wwv_flow.LF||
'        image_ref_id ) '||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_initiative_id,'||wwv_flow.LF||
'        p_app_u';
wwv_flow_imp.g_varchar2_table(119) := 'ser_id,'||wwv_flow.LF||
'        l_comment,'||wwv_flow.LF||
'        apex_markdown.to_html(l_comment),'||wwv_flow.LF||
'        regexp_replace(l_commen';
wwv_flow_imp.g_varchar2_table(120) := 't_no_images, ''\([^)]*/[^/?]*document-details\?p([0-9]+)_id=[^&]+&clear=\1[^)]*\)'', ''''), -- removes l';
wwv_flow_imp.g_varchar2_table(121) := 'ink for docs,'||wwv_flow.LF||
'        p_private_yn,'||wwv_flow.LF||
'        p_image_ref_id )'||wwv_flow.LF||
'    returning id into l_comment_id;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(122) := ' commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doing image cleanup'||wwv_flow.LF||
'    remove_orphan_images ('||wwv_flow.LF||
'        p_comment_id   => l_comment_';
wwv_flow_imp.g_varchar2_table(123) := 'id,'||wwv_flow.LF||
'        p_comment_type => ''INITIATIVE'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_private_yn = ''N'' and'||wwv_flow.LF||
'       apex_util.get_bu';
wwv_flow_imp.g_varchar2_table(124) := 'ild_option_status (p_application_id => p_app_id, p_build_option_name => ''Comment Tagging'') = ''INCLUD';
wwv_flow_imp.g_varchar2_table(125) := 'E'' '||wwv_flow.LF||
'    then'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_email_comment := apex_markdown.to_html(substr(l_comment_no_images,1,2500)||c';
wwv_flow_imp.g_varchar2_table(126) := 'ase when length(l_comment_no_images) > 2500 then '' ...'' end);'||wwv_flow.LF||
''||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            selec';
wwv_flow_imp.g_varchar2_table(127) := 't apex_escape.html(initiative) init_esc,'||wwv_flow.LF||
'                   (select apex_escape.html(comment_nbr) fr';
wwv_flow_imp.g_varchar2_table(128) := 'om sp_initiative_comments where id = l_comment_id) comment_nbr,'||wwv_flow.LF||
'                   apex_escape.html(';
wwv_flow_imp.g_varchar2_table(129) := 'sp_util.get_nomenclature (p_static_id => ''INITIATIVE'')) init_word'||wwv_flow.LF||
'              from sp_initiatives'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(130) := '             where id = p_initiative_id '||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            l_mentions := sp_util.find_menti';
wwv_flow_imp.g_varchar2_table(131) := 'ons(l_comment_no_images);'||wwv_flow.LF||
'            -- mentions (not current user)'||wwv_flow.LF||
'            if l_mentions is no';
wwv_flow_imp.g_varchar2_table(132) := 't null then'||wwv_flow.LF||
'                for c2 in ('||wwv_flow.LF||
'                    select id, first_name'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(133) := '    from sp_team_members'||wwv_flow.LF||
'                     where instr('':''||l_mentions||'':'','':''||screen_name||'':''';
wwv_flow_imp.g_varchar2_table(134) := ') > 0'||wwv_flow.LF||
'                       and id != p_app_user_id '||wwv_flow.LF||
'                       and screen_name is not ';
wwv_flow_imp.g_varchar2_table(135) := 'null'||wwv_flow.LF||
'                ) loop'||wwv_flow.LF||
'                    sp_util.comment_notification ('||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(136) := '   p_team_member_id => c2.id, '||wwv_flow.LF||
'                        p_app_name       => p_nomen_sp, '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(137) := '            p_app_id         => p_app_id,'||wwv_flow.LF||
'                        p_title          => ''You were ment';
wwv_flow_imp.g_varchar2_table(138) := 'ioned in a comment added to ''||c1.init_word||'' ''||c1.init_esc,'||wwv_flow.LF||
'                        p_initiative_';
wwv_flow_imp.g_varchar2_table(139) := 'id  => p_initiative_id, '||wwv_flow.LF||
'                        p_link           => p_link, '||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(140) := '  p_view_what      => c1.init_word,'||wwv_flow.LF||
'                        p_email_contents => ''Hi ''||c2.first_name';
wwv_flow_imp.g_varchar2_table(141) := '||''<br/><br/>''||'||wwv_flow.LF||
'                                            ''You were mentioned in a new comment ad';
wwv_flow_imp.g_varchar2_table(142) := 'ded to <a  style="font-weight:bold" href="''||p_link||''">''||c1.init_esc||''</a><br/>''||'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(143) := '                              ''Comment: ''||c1.comment_nbr||''<br/>''||'||wwv_flow.LF||
'                               ';
wwv_flow_imp.g_varchar2_table(144) := '             ''Comment by: ''||apex_escape.html(lower(p_app_user))||''<br/>''||'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(145) := '                    l_email_comment,'||wwv_flow.LF||
'                        p_notification_type => ''MENTION'' );'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(146) := '             end loop;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'end add_initiative_comment';
wwv_flow_imp.g_varchar2_table(147) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_initiative_comment ('||wwv_flow.LF||
'    p_comment_id      in  number,'||wwv_flow.LF||
'    p_comment         in';
wwv_flow_imp.g_varchar2_table(148) := '  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_image_ref_id    in  number   defau';
wwv_flow_imp.g_varchar2_table(149) := 'lt null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_comment            clob;'||wwv_flow.LF||
'    l_comment_no_images  clob;'||wwv_flow.LF||
'    l_image_ref_id       ';
wwv_flow_imp.g_varchar2_table(150) := 'number;'||wwv_flow.LF||
'    l_image_list         varchar2(4000);'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_comment           := replace_session_o';
wwv_flow_imp.g_varchar2_table(151) := 'n_save(p_comment);'||wwv_flow.LF||
'    l_comment_no_images := replace_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- for existing conten';
wwv_flow_imp.g_varchar2_table(152) := 't, there may be no image_ref_id, so need to add one'||wwv_flow.LF||
'    update sp_initiative_comments'||wwv_flow.LF||
'       set bod';
wwv_flow_imp.g_varchar2_table(153) := 'y           = l_comment,'||wwv_flow.LF||
'           body_html      = apex_markdown.to_html(l_comment),'||wwv_flow.LF||
'           bo';
wwv_flow_imp.g_varchar2_table(154) := 'dy_no_images = regexp_replace(l_comment_no_images, ''\([^)]*/[^/?]*document-details\?p([0-9]+)_id=[^&';
wwv_flow_imp.g_varchar2_table(155) := ']+&clear=\1[^)]*\)'', ''''), -- removes link for docs,'||wwv_flow.LF||
'           private_yn     = p_private_yn,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(156) := '     image_ref_id   = nvl(image_ref_id,to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX''))'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(157) := '   where id = p_comment_id'||wwv_flow.LF||
'    returning image_ref_id into l_image_ref_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_image_list := find';
wwv_flow_imp.g_varchar2_table(158) := '_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- if no images found, no need to update references'||wwv_flow.LF||
'    if l_image_list is ';
wwv_flow_imp.g_varchar2_table(159) := 'not null then'||wwv_flow.LF||
'        -- updating image_ref_id to match that of the existing content'||wwv_flow.LF||
'        update ';
wwv_flow_imp.g_varchar2_table(160) := 'sp_comment_images'||wwv_flow.LF||
'           set image_ref_id = l_image_ref_id '||wwv_flow.LF||
'         where instr('':''||l_image_li';
wwv_flow_imp.g_varchar2_table(161) := 'st||'':'','':''||unique_filename||'':'') > 0'||wwv_flow.LF||
'           and image_ref_id = p_image_ref_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(162) := '  -- doing image cleanup'||wwv_flow.LF||
'    remove_orphan_images ('||wwv_flow.LF||
'        p_comment_id   => p_comment_id,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(163) := 'p_comment_type => ''INITIATIVE'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- cleaning up old images, only on update'||wwv_flow.LF||
'    cleanup_old_imag';
wwv_flow_imp.g_varchar2_table(164) := 'es;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'end update_initiative_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_initiative_comment ('||wwv_flow.LF||
'    p_comment_id    ';
wwv_flow_imp.g_varchar2_table(165) := '  in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_image_ref_id  number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    select image_ref_id'||wwv_flow.LF||
'      into l_image_ref_i';
wwv_flow_imp.g_varchar2_table(166) := 'd'||wwv_flow.LF||
'      from sp_initiative_comments'||wwv_flow.LF||
'     where id = p_comment_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_image_ref_id is not null';
wwv_flow_imp.g_varchar2_table(167) := ' then'||wwv_flow.LF||
'        delete from sp_comment_images'||wwv_flow.LF||
'         where image_ref_id = l_image_ref_id;'||wwv_flow.LF||
'    end if';
wwv_flow_imp.g_varchar2_table(168) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'    delete from sp_initiative_comments'||wwv_flow.LF||
'     where id = p_comment_id;'||wwv_flow.LF||
'end delete_initiative_commen';
wwv_flow_imp.g_varchar2_table(169) := 't;'||wwv_flow.LF||
''||wwv_flow.LF||
'---------------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_project_comment ('||wwv_flow.LF||
'    p_app_user_id     i';
wwv_flow_imp.g_varchar2_table(170) := 'n  number,'||wwv_flow.LF||
'    p_app_user        in  varchar2,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_private_yn ';
wwv_flow_imp.g_varchar2_table(171) := '     in  varchar2 default ''N'','||wwv_flow.LF||
'    p_project_id      in  number,'||wwv_flow.LF||
'    p_system_gen_yn   in  varchar2 ';
wwv_flow_imp.g_varchar2_table(172) := 'default ''N'','||wwv_flow.LF||
'    p_app_id          in  number   default null,'||wwv_flow.LF||
'    p_permalink_pre   in  varchar2 def';
wwv_flow_imp.g_varchar2_table(173) := 'ault null,'||wwv_flow.LF||
'    p_nomen_sp        in  varchar2 default null,'||wwv_flow.LF||
'    p_nomen_project   in  varchar2 defau';
wwv_flow_imp.g_varchar2_table(174) := 'lt null,'||wwv_flow.LF||
'    p_image_ref_id    in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_comment            clob;'||wwv_flow.LF||
'    l_c';
wwv_flow_imp.g_varchar2_table(175) := 'omment_no_images  clob;'||wwv_flow.LF||
'    l_comment_id         number;'||wwv_flow.LF||
'    l_email_comment      clob;'||wwv_flow.LF||
'    l_link  ';
wwv_flow_imp.g_varchar2_table(176) := '             varchar2(4000);'||wwv_flow.LF||
'    l_mentions           varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_comment           ';
wwv_flow_imp.g_varchar2_table(177) := ':= replace_session_on_save(p_comment);'||wwv_flow.LF||
'    l_comment_no_images := replace_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    in';
wwv_flow_imp.g_varchar2_table(178) := 'sert into SP_PROJECT_COMMENTS ('||wwv_flow.LF||
'        project_id, '||wwv_flow.LF||
'        author_id, '||wwv_flow.LF||
'        body,'||wwv_flow.LF||
'        body_';
wwv_flow_imp.g_varchar2_table(179) := 'html, '||wwv_flow.LF||
'        body_no_images, '||wwv_flow.LF||
'        private_yn,'||wwv_flow.LF||
'        image_ref_id) '||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_pr';
wwv_flow_imp.g_varchar2_table(180) := 'oject_id,'||wwv_flow.LF||
'        p_app_user_id,'||wwv_flow.LF||
'        l_comment,'||wwv_flow.LF||
'        apex_markdown.to_html(l_comment),'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(181) := '  regexp_replace(l_comment_no_images, ''\([^)]*/[^/?]*document-details\?p([0-9]+)_id=[^&]+&clear=\1[^';
wwv_flow_imp.g_varchar2_table(182) := ')]*\)'', ''''), -- removes link for docs'||wwv_flow.LF||
'        p_private_yn,'||wwv_flow.LF||
'        p_image_ref_id)'||wwv_flow.LF||
'    returning id';
wwv_flow_imp.g_varchar2_table(183) := ' into l_comment_id;'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doing image cleanup'||wwv_flow.LF||
'    remove_orphan_images ('||wwv_flow.LF||
'        p_com';
wwv_flow_imp.g_varchar2_table(184) := 'ment_id   => l_comment_id,'||wwv_flow.LF||
'        p_comment_type => ''PROJECT'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_private_yn = ''N'' and p_s';
wwv_flow_imp.g_varchar2_table(185) := 'ystem_gen_yn = ''N'' then'||wwv_flow.LF||
''||wwv_flow.LF||
'        set_comment_email_references(l_comment_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_email_commen';
wwv_flow_imp.g_varchar2_table(186) := 't := apex_markdown.to_html(substr(l_comment_no_images,1,2500)||case when length(l_comment_no_images)';
wwv_flow_imp.g_varchar2_table(187) := ' > 2500 then '' ...'' end);'||wwv_flow.LF||
''||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            select p.project,'||wwv_flow.LF||
'                   apex';
wwv_flow_imp.g_varchar2_table(188) := '_escape.html(p.project) project_esc, '||wwv_flow.LF||
'                   p.friendly_identifier fi, apex_escape.html(';
wwv_flow_imp.g_varchar2_table(189) := 'p.project_url_name) project_url_name, '||wwv_flow.LF||
'                   p.owner_id, apex_escape.html(t.first_name)';
wwv_flow_imp.g_varchar2_table(190) := ' first_name, t.screen_name,'||wwv_flow.LF||
'                   (select apex_escape.html(comment_nbr) from sp_project';
wwv_flow_imp.g_varchar2_table(191) := '_comments where id = l_comment_id) comment_nbr'||wwv_flow.LF||
'              from sp_projects p, '||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(192) := ' sp_team_members t'||wwv_flow.LF||
'             where p.id = p_project_id '||wwv_flow.LF||
'               and p.owner_id = t.id (+)'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(193) := '        ) loop'||wwv_flow.LF||
'            l_link := p_permalink_pre||c1.fi||''&pn=''||c1.project_url_name;'||wwv_flow.LF||
''||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(194) := '   l_mentions := sp_util.find_mentions(l_comment_no_images);'||wwv_flow.LF||
''||wwv_flow.LF||
'            if apex_util.get_build_opt';
wwv_flow_imp.g_varchar2_table(195) := 'ion_status (p_application_id => p_app_id, p_build_option_name => ''Comment Tagging'') = ''INCLUDE'' then';
wwv_flow_imp.g_varchar2_table(196) := ''||wwv_flow.LF||
'                -- mentions (not current user)'||wwv_flow.LF||
'                if l_mentions is not null then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(197) := '               for c2 in ('||wwv_flow.LF||
'                        select id, apex_escape.html(first_name) first_nam';
wwv_flow_imp.g_varchar2_table(198) := 'e'||wwv_flow.LF||
'                          from sp_team_members'||wwv_flow.LF||
'                         where instr('':''||l_mention';
wwv_flow_imp.g_varchar2_table(199) := 's||'':'','':''||screen_name||'':'') > 0'||wwv_flow.LF||
'                           and id != p_app_user_id and screen_name';
wwv_flow_imp.g_varchar2_table(200) := ' is not null'||wwv_flow.LF||
'                    ) loop'||wwv_flow.LF||
'                        sp_util.comment_notification ('||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(201) := '                       p_team_member_id => c2.id, '||wwv_flow.LF||
'                            p_app_name       => p';
wwv_flow_imp.g_varchar2_table(202) := '_nomen_sp, '||wwv_flow.LF||
'                            p_app_id         => p_app_id,'||wwv_flow.LF||
'                            p_';
wwv_flow_imp.g_varchar2_table(203) := 'title          => ''You were mentioned in a comment added to ''||c1.project_esc,'||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(204) := '       p_project_id     => p_project_id, '||wwv_flow.LF||
'                            p_link           => l_link, '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(205) := '                           p_view_what      => p_nomen_project,'||wwv_flow.LF||
'                            p_email_';
wwv_flow_imp.g_varchar2_table(206) := 'contents => ''Hi ''||c2.first_name||''<br/><br/>''||'||wwv_flow.LF||
'                                                ''Yo';
wwv_flow_imp.g_varchar2_table(207) := 'u were mentioned in a new comment added to <a  style="font-weight:bold" href="''||l_link||''">''||c1.pr';
wwv_flow_imp.g_varchar2_table(208) := 'oject_esc||''</a><br/>''||'||wwv_flow.LF||
'                                                ''Comment: ''||c1.comment_nbr';
wwv_flow_imp.g_varchar2_table(209) := '||''<br/>''||'||wwv_flow.LF||
'                                                ''Comment by: ''||apex_escape.html(lower(p';
wwv_flow_imp.g_varchar2_table(210) := '_app_user))||''<br/>''||'||wwv_flow.LF||
'                                                l_email_comment,'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(211) := '                p_notification_type => ''MENTION'' );'||wwv_flow.LF||
'                    end loop;'||wwv_flow.LF||
'                en';
wwv_flow_imp.g_varchar2_table(212) := 'd if;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- owner (not current user and not tagged in comment)'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(213) := '     if c1.owner_id is not null and '||wwv_flow.LF||
'               c1.owner_id != p_app_user_id and '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(214) := ' instr('':''||l_mentions||'':'','':''||c1.screen_name||'':'') = 0 '||wwv_flow.LF||
'            then'||wwv_flow.LF||
'               sp_util.c';
wwv_flow_imp.g_varchar2_table(215) := 'omment_notification ('||wwv_flow.LF||
'                    p_team_member_id => c1.owner_id, '||wwv_flow.LF||
'                    p_ap';
wwv_flow_imp.g_varchar2_table(216) := 'p_name       => p_nomen_sp,'||wwv_flow.LF||
'                    p_app_id         => p_app_id,'||wwv_flow.LF||
'                    p_';
wwv_flow_imp.g_varchar2_table(217) := 'title          => ''New comment added to ''||c1.project_esc,'||wwv_flow.LF||
'                    p_project_id     => p';
wwv_flow_imp.g_varchar2_table(218) := '_project_id, '||wwv_flow.LF||
'                    p_link           => l_link, '||wwv_flow.LF||
'                    p_view_what      ';
wwv_flow_imp.g_varchar2_table(219) := '=> p_nomen_project,'||wwv_flow.LF||
'                    p_email_contents => ''Hi ''||c1.first_name||''<br/><br/>''||'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(220) := '                                     ''A new comment was just added to <a  style="font-weight:bold" h';
wwv_flow_imp.g_varchar2_table(221) := 'ref="''||l_link||''">''||c1.project_esc||''</a><br/>''||'||wwv_flow.LF||
'                                        ''Comment';
wwv_flow_imp.g_varchar2_table(222) := ': ''||c1.comment_nbr||''<br/>''||'||wwv_flow.LF||
'                                        ''Comment by: ''||apex_escape.h';
wwv_flow_imp.g_varchar2_table(223) := 'tml(lower(p_app_user))||''<br/>''||'||wwv_flow.LF||
'                                        l_email_comment,'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(224) := '           p_notification_type => ''COMMENT'' );'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- favorited (not ow';
wwv_flow_imp.g_varchar2_table(225) := 'ner, not current user and not tagged in comment)'||wwv_flow.LF||
'            for c2 in ('||wwv_flow.LF||
'                select f.te';
wwv_flow_imp.g_varchar2_table(226) := 'am_member_id, apex_escape.html(t.first_name) first_name'||wwv_flow.LF||
'                  from sp_favorites f,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(227) := '                  sp_team_members t'||wwv_flow.LF||
'                 where f.project_id = p_project_id'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(228) := '      and f.team_member_id = t.id'||wwv_flow.LF||
'                   and f.team_member_id != p_app_user_id'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(229) := '          and f.team_member_id != c1.owner_id'||wwv_flow.LF||
'                   and t.screen_name is not null'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(230) := '              and instr('':''||l_mentions||'':'','':''||t.screen_name||'':'') = 0'||wwv_flow.LF||
'            ) loop'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(231) := '         sp_util.comment_notification ('||wwv_flow.LF||
'                    p_team_member_id => c2.team_member_id, '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(232) := '                    p_app_name       => p_nomen_sp,'||wwv_flow.LF||
'                    p_app_id         => p_app_id';
wwv_flow_imp.g_varchar2_table(233) := ','||wwv_flow.LF||
'                    p_title          => ''New comment added to ''||c1.project_esc,'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(234) := '   p_project_id     => p_project_id, '||wwv_flow.LF||
'                    p_link           => l_link, '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(235) := '       p_view_what      => p_nomen_project,'||wwv_flow.LF||
'                    p_email_contents => ''Hi ''||c2.first_';
wwv_flow_imp.g_varchar2_table(236) := 'name||''<br/><br/>''||'||wwv_flow.LF||
'                                        ''A new comment was just added to <a  st';
wwv_flow_imp.g_varchar2_table(237) := 'yle="font-weight:bold" href="''||l_link||''">''||c1.project_esc||''</a><br/>''||'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(238) := '                ''Comment: ''||c1.comment_nbr||''<br/>''||'||wwv_flow.LF||
'                                        ''Comm';
wwv_flow_imp.g_varchar2_table(239) := 'ent by: ''||apex_escape.html(lower(p_app_user))||''<br/>''||'||wwv_flow.LF||
'                                        l_';
wwv_flow_imp.g_varchar2_table(240) := 'email_comment,'||wwv_flow.LF||
'                    p_notification_type => ''COMMENT'' );'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(241) := ' end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end add_project_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_project_comment ('||wwv_flow.LF||
'    p_comment_i';
wwv_flow_imp.g_varchar2_table(242) := 'd      in  number,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ''N';
wwv_flow_imp.g_varchar2_table(243) := ''','||wwv_flow.LF||
'    p_image_ref_id    in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_comment            clob;'||wwv_flow.LF||
'    l_comment';
wwv_flow_imp.g_varchar2_table(244) := '_no_images  clob;'||wwv_flow.LF||
'    l_image_ref_id       number;'||wwv_flow.LF||
'    l_image_list         varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(245) := '  l_comment           := replace_session_on_save(p_comment);'||wwv_flow.LF||
'    l_comment_no_images := replace_imag';
wwv_flow_imp.g_varchar2_table(246) := 'es(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- for existing content, there may be no image_ref_id, so need to add one'||wwv_flow.LF||
'    up';
wwv_flow_imp.g_varchar2_table(247) := 'date sp_project_comments'||wwv_flow.LF||
'       set body           = l_comment,'||wwv_flow.LF||
'           body_html      = apex_mar';
wwv_flow_imp.g_varchar2_table(248) := 'kdown.to_html(l_comment),'||wwv_flow.LF||
'           body_no_images = regexp_replace(l_comment_no_images, ''\([^)]*/[';
wwv_flow_imp.g_varchar2_table(249) := '^/?]*document-details\?p([0-9]+)_id=[^&]+&clear=\1[^)]*\)'', ''''), -- removes link for docs'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(250) := ' private_yn     = p_private_yn,'||wwv_flow.LF||
'           image_ref_id   = nvl(image_ref_id,to_number(sys_guid(), ''';
wwv_flow_imp.g_varchar2_table(251) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX''))'||wwv_flow.LF||
'     where id = p_comment_id'||wwv_flow.LF||
'    returning image_ref_id into l_i';
wwv_flow_imp.g_varchar2_table(252) := 'mage_ref_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_image_list := find_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_image_list is not null then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(253) := '    -- updating image_ref_id to match that of the existing content'||wwv_flow.LF||
'        update sp_comment_images'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(254) := '           set image_ref_id = l_image_ref_id '||wwv_flow.LF||
'         where instr('':''||l_image_list||'':'','':''||uniqu';
wwv_flow_imp.g_varchar2_table(255) := 'e_filename||'':'') > 0'||wwv_flow.LF||
'           and image_ref_id = p_image_ref_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doing image c';
wwv_flow_imp.g_varchar2_table(256) := 'leanup'||wwv_flow.LF||
'    remove_orphan_images ('||wwv_flow.LF||
'        p_comment_id   => p_comment_id,'||wwv_flow.LF||
'        p_comment_type => ';
wwv_flow_imp.g_varchar2_table(257) := '''PROJECT'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- cleaning up old images, only on update'||wwv_flow.LF||
'    cleanup_old_images;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_private';
wwv_flow_imp.g_varchar2_table(258) := '_yn = ''N'' then'||wwv_flow.LF||
'        set_comment_email_references(p_comment_id);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end update_project_co';
wwv_flow_imp.g_varchar2_table(259) := 'mment;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_project_comment ('||wwv_flow.LF||
'    p_comment_id      in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_image_ref_id';
wwv_flow_imp.g_varchar2_table(260) := '  number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    select image_ref_id'||wwv_flow.LF||
'      into l_image_ref_id'||wwv_flow.LF||
'      from sp_project_comments'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(261) := '  where id = p_comment_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_image_ref_id is not null then'||wwv_flow.LF||
'        delete from sp_comment_im';
wwv_flow_imp.g_varchar2_table(262) := 'ages'||wwv_flow.LF||
'         where image_ref_id = l_image_ref_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    delete from sp_project_comments'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(263) := '     where id = p_comment_id;'||wwv_flow.LF||
'end delete_project_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
'-----------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_ta';
wwv_flow_imp.g_varchar2_table(264) := 'sk_comment ('||wwv_flow.LF||
'    p_app_user_id     in  number,'||wwv_flow.LF||
'    p_app_user        in  varchar2,'||wwv_flow.LF||
'    p_comment    ';
wwv_flow_imp.g_varchar2_table(265) := '     in  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_project_id      in  number,';
wwv_flow_imp.g_varchar2_table(266) := ''||wwv_flow.LF||
'    p_task_id         in  number,'||wwv_flow.LF||
'    p_app_id          in  number,'||wwv_flow.LF||
'    p_link            in  varch';
wwv_flow_imp.g_varchar2_table(267) := 'ar2,'||wwv_flow.LF||
'    p_nomen_sp        in  varchar2,'||wwv_flow.LF||
'    p_image_ref_id    in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_';
wwv_flow_imp.g_varchar2_table(268) := 'comment            clob;'||wwv_flow.LF||
'    l_comment_no_images  clob;'||wwv_flow.LF||
'    l_comment_id         number;'||wwv_flow.LF||
'    l_email';
wwv_flow_imp.g_varchar2_table(269) := '_comment      clob;'||wwv_flow.LF||
'    l_mentions           varchar2(4000);'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    l_comment           := repla';
wwv_flow_imp.g_varchar2_table(270) := 'ce_session_on_save(p_comment);'||wwv_flow.LF||
'    l_comment_no_images := replace_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert int';
wwv_flow_imp.g_varchar2_table(271) := 'o sp_task_comments ('||wwv_flow.LF||
'        task_id, '||wwv_flow.LF||
'        author_id, '||wwv_flow.LF||
'        body,'||wwv_flow.LF||
'        body_html, '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(272) := ' body_no_images,'||wwv_flow.LF||
'        private_yn,'||wwv_flow.LF||
'        image_ref_id ) '||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_task_id,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(273) := ' p_app_user_id,'||wwv_flow.LF||
'        l_comment,'||wwv_flow.LF||
'        apex_markdown.to_html(l_comment),'||wwv_flow.LF||
'        regexp_replace(';
wwv_flow_imp.g_varchar2_table(274) := 'l_comment_no_images, ''\([^)]*/[^/?]*document-details\?p([0-9]+)_id=[^&]+&clear=\1[^)]*\)'', ''''), -- r';
wwv_flow_imp.g_varchar2_table(275) := 'emoves link for docs,'||wwv_flow.LF||
'        p_private_yn,'||wwv_flow.LF||
'        p_image_ref_id )'||wwv_flow.LF||
'    returning id into l_comment';
wwv_flow_imp.g_varchar2_table(276) := '_id;'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doing image cleanup'||wwv_flow.LF||
'    remove_orphan_images ('||wwv_flow.LF||
'        p_comment_id   => l_';
wwv_flow_imp.g_varchar2_table(277) := 'comment_id,'||wwv_flow.LF||
'        p_comment_type => ''TASK'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_private_yn = ''N'' then'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_email_com';
wwv_flow_imp.g_varchar2_table(278) := 'ment := apex_markdown.to_html(substr(l_comment_no_images,1,2500)||case when length(l_comment_no_imag';
wwv_flow_imp.g_varchar2_table(279) := 'es) > 2500 then '' ...'' end);'||wwv_flow.LF||
''||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            select p.project, '||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(280) := 'apex_escape.html(p.project) project_esc,'||wwv_flow.LF||
'                   apex_escape.html((select task_type from ';
wwv_flow_imp.g_varchar2_table(281) := 'sp_task_types rt where rt.id = a.task_type_id)||'||wwv_flow.LF||
'                                     case when a.ta';
wwv_flow_imp.g_varchar2_table(282) := 'sk_sub_type_id is not null then '': '' end ||'||wwv_flow.LF||
'                                     (select task_type f';
wwv_flow_imp.g_varchar2_table(283) := 'rom sp_task_types rt where rt.id = a.task_sub_type_id) ||'||wwv_flow.LF||
'                                     case ';
wwv_flow_imp.g_varchar2_table(284) := 'when a.task is not null then '' - ''||a.task end) task_name,'||wwv_flow.LF||
'                   apex_escape.html((sele';
wwv_flow_imp.g_varchar2_table(285) := 'ct rt.task_type'||wwv_flow.LF||
'                                       from sp_task_types rt'||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(286) := '               where a.id = p_task_id'||wwv_flow.LF||
'                                        and rt.id = a.task_typ';
wwv_flow_imp.g_varchar2_table(287) := 'e_id)) parent_task_type,'||wwv_flow.LF||
'                   p.owner_id, apex_escape.html(t.first_name) first_name, t';
wwv_flow_imp.g_varchar2_table(288) := '.screen_name,'||wwv_flow.LF||
'                   (select apex_escape.html(comment_nbr) from sp_task_comments where i';
wwv_flow_imp.g_varchar2_table(289) := 'd = l_comment_id) comment_nbr'||wwv_flow.LF||
'              from sp_projects p, '||wwv_flow.LF||
'                   sp_tasks a,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(290) := '               sp_team_members t'||wwv_flow.LF||
'             where p.id = p_project_id '||wwv_flow.LF||
'               and a.id = p';
wwv_flow_imp.g_varchar2_table(291) := '_task_id'||wwv_flow.LF||
'               and p.owner_id = t.id (+)'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            if apex_util.get_build_';
wwv_flow_imp.g_varchar2_table(292) := 'option_status (p_application_id => p_app_id, p_build_option_name => ''Comment Tagging'') = ''INCLUDE'' t';
wwv_flow_imp.g_varchar2_table(293) := 'hen'||wwv_flow.LF||
'                l_mentions := sp_util.find_mentions(l_comment_no_images);'||wwv_flow.LF||
'                -- men';
wwv_flow_imp.g_varchar2_table(294) := 'tions (not current user)'||wwv_flow.LF||
'                if l_mentions is not null then'||wwv_flow.LF||
'                    for c2 i';
wwv_flow_imp.g_varchar2_table(295) := 'n ('||wwv_flow.LF||
'                        select id, first_name'||wwv_flow.LF||
'                          from sp_team_members'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(296) := '                      where instr('':''||l_mentions||'':'','':''||screen_name||'':'') > 0'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(297) := '         and id != p_app_user_id '||wwv_flow.LF||
'                           and screen_name is not null'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(298) := '         ) loop'||wwv_flow.LF||
'                        sp_util.comment_notification ('||wwv_flow.LF||
'                            p';
wwv_flow_imp.g_varchar2_table(299) := '_team_member_id => c2.id, '||wwv_flow.LF||
'                            p_app_name       => p_nomen_sp, '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(300) := '                p_app_id         => p_app_id,'||wwv_flow.LF||
'                            p_title          => ''You w';
wwv_flow_imp.g_varchar2_table(301) := 'ere mentioned in a comment added to ''||c1.project_esc||'' - ''||c1.task_name,'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(302) := '    p_project_id     => p_project_id, '||wwv_flow.LF||
'                            p_task_id        => p_task_id,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(303) := '                          p_link           => p_link, '||wwv_flow.LF||
'                            p_view_what      ';
wwv_flow_imp.g_varchar2_table(304) := '=> c1.parent_task_type,'||wwv_flow.LF||
'                            p_email_contents => ''Hi ''||c2.first_name||''<br/>';
wwv_flow_imp.g_varchar2_table(305) := '<br/>''||'||wwv_flow.LF||
'                                                ''You were mentioned in a new comment added ';
wwv_flow_imp.g_varchar2_table(306) := 'to ''||c1.project_esc||'' - <a  style="font-weight:bold" href="''||p_link||''">''||apex_escape.html(c1.ta';
wwv_flow_imp.g_varchar2_table(307) := 'sk_name)||''</a><br/>''||'||wwv_flow.LF||
'                                                ''Comment: ''||c1.comment_nbr|';
wwv_flow_imp.g_varchar2_table(308) := '|''<br/>''||'||wwv_flow.LF||
'                                                ''Comment by: ''||apex_escape.html(lower(p_';
wwv_flow_imp.g_varchar2_table(309) := 'app_user))||''<br/>''||'||wwv_flow.LF||
'                                                l_email_comment,'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(310) := '               p_notification_type => ''MENTION'' );'||wwv_flow.LF||
'                    end loop;'||wwv_flow.LF||
'                end';
wwv_flow_imp.g_varchar2_table(311) := ' if;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- owner (not current user and not tagged in comment)'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(312) := '    if c1.owner_id is not null and '||wwv_flow.LF||
'               c1.owner_id != p_app_user_id and '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(313) := 'instr('':''||l_mentions||'':'','':''||c1.screen_name||'':'') = 0 '||wwv_flow.LF||
'            then'||wwv_flow.LF||
'               sp_util.co';
wwv_flow_imp.g_varchar2_table(314) := 'mment_notification ('||wwv_flow.LF||
'                    p_team_member_id => c1.owner_id, '||wwv_flow.LF||
'                    p_app';
wwv_flow_imp.g_varchar2_table(315) := '_name       => p_nomen_sp,'||wwv_flow.LF||
'                    p_app_id         => p_app_id,'||wwv_flow.LF||
'                    p_t';
wwv_flow_imp.g_varchar2_table(316) := 'itle          => ''New comment added to ''||c1.project_esc||'' - ''||c1.task_name,'||wwv_flow.LF||
'                    p';
wwv_flow_imp.g_varchar2_table(317) := '_project_id     => p_project_id, '||wwv_flow.LF||
'                    p_task_id        => p_task_id,'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(318) := '     p_link           => p_link, '||wwv_flow.LF||
'                    p_view_what      => c1.parent_task_type,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(319) := '               p_email_contents => ''Hi ''||c1.first_name||''<br/><br/>''||'||wwv_flow.LF||
'                            ';
wwv_flow_imp.g_varchar2_table(320) := '            ''A new comment was just added to ''||c1.project_esc||'' - <a  style="font-weight:bold" hre';
wwv_flow_imp.g_varchar2_table(321) := 'f="''||p_link||''">''||apex_escape.html(c1.task_name)||''</a><br/>''||'||wwv_flow.LF||
'                                  ';
wwv_flow_imp.g_varchar2_table(322) := '      ''Comment: ''||c1.comment_nbr||''<br/>''||'||wwv_flow.LF||
'                                        ''Comment by: ''|';
wwv_flow_imp.g_varchar2_table(323) := '|apex_escape.html(lower(p_app_user))||''<br/>''||'||wwv_flow.LF||
'                                        l_email_comm';
wwv_flow_imp.g_varchar2_table(324) := 'ent,'||wwv_flow.LF||
'                    p_notification_type => ''COMMENT'' );'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- tas';
wwv_flow_imp.g_varchar2_table(325) := 'k owner (not project owner, current user and not tagged in comment)'||wwv_flow.LF||
'            for c2 in ('||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(326) := '        select a.owner_id team_member_id, apex_escape.html(t.first_name) first_name'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(327) := '  from sp_tasks a,'||wwv_flow.LF||
'                       sp_team_members t'||wwv_flow.LF||
'                 where a.id = p_task_id'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(328) := '                   and a.owner_id = t.id'||wwv_flow.LF||
'                   and a.owner_id != p_app_user_id'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(329) := '           and a.owner_id != c1.owner_id'||wwv_flow.LF||
'                   and instr('':''||l_mentions||'':'','':''||t.sc';
wwv_flow_imp.g_varchar2_table(330) := 'reen_name||'':'') = 0'||wwv_flow.LF||
'            ) loop'||wwv_flow.LF||
'                sp_util.comment_notification ('||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(331) := '      p_team_member_id => c2.team_member_id, '||wwv_flow.LF||
'                    p_app_name       => p_nomen_sp,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(332) := '                  p_app_id         => p_app_id,'||wwv_flow.LF||
'                    p_title          => ''New comment';
wwv_flow_imp.g_varchar2_table(333) := ' added to ''||c1.project_esc||'' - ''||c1.task_name,'||wwv_flow.LF||
'                    p_project_id     => p_project_';
wwv_flow_imp.g_varchar2_table(334) := 'id, '||wwv_flow.LF||
'                    p_task_id        => p_task_id,'||wwv_flow.LF||
'                    p_link           => p_li';
wwv_flow_imp.g_varchar2_table(335) := 'nk, '||wwv_flow.LF||
'                    p_view_what      => c1.parent_task_type,'||wwv_flow.LF||
'                    p_email_conten';
wwv_flow_imp.g_varchar2_table(336) := 'ts => ''Hi ''||c2.first_name||''<br/><br/>''||'||wwv_flow.LF||
'                                        ''A new comment wa';
wwv_flow_imp.g_varchar2_table(337) := 's just added to ''||c1.project_esc||'' - <a  style="font-weight:bold" href="''||p_link||''">''||apex_esca';
wwv_flow_imp.g_varchar2_table(338) := 'pe.html(c1.task_name)||''</a><br/>''||'||wwv_flow.LF||
'                                        ''Comment: ''||c1.comment';
wwv_flow_imp.g_varchar2_table(339) := '_nbr||''<br/>''||'||wwv_flow.LF||
'                                        ''Comment by: ''||apex_escape.html(lower(p_app';
wwv_flow_imp.g_varchar2_table(340) := '_user))||''<br/>''||'||wwv_flow.LF||
'                                        l_email_comment,'||wwv_flow.LF||
'                    p_no';
wwv_flow_imp.g_varchar2_table(341) := 'tification_type => ''COMMENT'' );'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- favorited (not owner, not curr';
wwv_flow_imp.g_varchar2_table(342) := 'ent user and not tagged in comment)'||wwv_flow.LF||
'            for c2 in ('||wwv_flow.LF||
'                select f.team_member_id,';
wwv_flow_imp.g_varchar2_table(343) := ' apex_escape.html(t.first_name) first_name'||wwv_flow.LF||
'                  from sp_favorites f,'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(344) := '     sp_team_members t'||wwv_flow.LF||
'                 where f.project_id = p_project_id'||wwv_flow.LF||
'                   and f.t';
wwv_flow_imp.g_varchar2_table(345) := 'eam_member_id = t.id'||wwv_flow.LF||
'                   and f.team_member_id != p_app_user_id'||wwv_flow.LF||
'                   and';
wwv_flow_imp.g_varchar2_table(346) := ' f.team_member_id != c1.owner_id'||wwv_flow.LF||
'                   and t.screen_name is not null'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(347) := ' and instr('':''||l_mentions||'':'','':''||t.screen_name||'':'') = 0'||wwv_flow.LF||
'            ) loop'||wwv_flow.LF||
'                sp_u';
wwv_flow_imp.g_varchar2_table(348) := 'til.comment_notification ('||wwv_flow.LF||
'                    p_team_member_id => c2.team_member_id, '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(349) := '       p_app_name       => p_nomen_sp,'||wwv_flow.LF||
'                    p_app_id         => p_app_id,'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(350) := '         p_title          => ''New comment added to ''||c1.project_esc||'' - ''||c1.task_name,'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(351) := '           p_project_id     => p_project_id, '||wwv_flow.LF||
'                    p_task_id        => p_task_id,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(352) := '                 p_link           => p_link, '||wwv_flow.LF||
'                    p_view_what      => c1.parent_task';
wwv_flow_imp.g_varchar2_table(353) := '_type,'||wwv_flow.LF||
'                    p_email_contents => ''Hi ''||c2.first_name||''<br/><br/>''||'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(354) := '                        ''A new comment was just added to ''||c1.project_esc||'' - <a  style="font-weig';
wwv_flow_imp.g_varchar2_table(355) := 'ht:bold" href="''||p_link||''">''||apex_escape.html(c1.task_name)||''</a><br/>''||'||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(356) := '                  ''Comment: ''||c1.comment_nbr||''<br/>''||'||wwv_flow.LF||
'                                        ''Co';
wwv_flow_imp.g_varchar2_table(357) := 'mment by: ''||apex_escape.html(lower(p_app_user))||''<br/>''||'||wwv_flow.LF||
'                                        ';
wwv_flow_imp.g_varchar2_table(358) := 'l_email_comment,'||wwv_flow.LF||
'                    p_notification_type => ''COMMENT'' );'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(359) := '   end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end add_task_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_task_comment ('||wwv_flow.LF||
'    p_comment_id   ';
wwv_flow_imp.g_varchar2_table(360) := '   in  number,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(361) := '   p_image_ref_id    in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_comment            clob;'||wwv_flow.LF||
'    l_comment_no_';
wwv_flow_imp.g_varchar2_table(362) := 'images  clob;'||wwv_flow.LF||
'    l_image_ref_id       number;'||wwv_flow.LF||
'    l_image_list         varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_';
wwv_flow_imp.g_varchar2_table(363) := 'comment           := replace_session_on_save(p_comment);'||wwv_flow.LF||
'    l_comment_no_images := replace_images(l';
wwv_flow_imp.g_varchar2_table(364) := '_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- for existing content, there may be no image_ref_id, so need to add one'||wwv_flow.LF||
'    update';
wwv_flow_imp.g_varchar2_table(365) := ' sp_task_comments'||wwv_flow.LF||
'       set body           = l_comment,'||wwv_flow.LF||
'           body_html      = apex_markdown.t';
wwv_flow_imp.g_varchar2_table(366) := 'o_html(l_comment),'||wwv_flow.LF||
'           body_no_images = regexp_replace(l_comment_no_images, ''\([^)]*/[^/?]*do';
wwv_flow_imp.g_varchar2_table(367) := 'cument-details\?p([0-9]+)_id=[^&]+&clear=\1[^)]*\)'', ''''), -- removes link for docs,'||wwv_flow.LF||
'           priva';
wwv_flow_imp.g_varchar2_table(368) := 'te_yn     = p_private_yn,'||wwv_flow.LF||
'           image_ref_id   = nvl(image_ref_id,to_number(sys_guid(), ''XXXXXX';
wwv_flow_imp.g_varchar2_table(369) := 'XXXXXXXXXXXXXXXXXXXXXXXXXX''))'||wwv_flow.LF||
'     where id = p_comment_id'||wwv_flow.LF||
'    returning image_ref_id into l_image_r';
wwv_flow_imp.g_varchar2_table(370) := 'ef_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_image_list := find_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_image_list is not null then'||wwv_flow.LF||
'        --';
wwv_flow_imp.g_varchar2_table(371) := ' updating image_ref_id to match that of the existing content'||wwv_flow.LF||
'        update sp_comment_images'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(372) := '     set image_ref_id = l_image_ref_id '||wwv_flow.LF||
'         where instr('':''||l_image_list||'':'','':''||unique_file';
wwv_flow_imp.g_varchar2_table(373) := 'name||'':'') > 0'||wwv_flow.LF||
'           and image_ref_id = p_image_ref_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doing image cleanup';
wwv_flow_imp.g_varchar2_table(374) := ''||wwv_flow.LF||
'    remove_orphan_images ('||wwv_flow.LF||
'        p_comment_id   => p_comment_id,'||wwv_flow.LF||
'        p_comment_type => ''TASK''';
wwv_flow_imp.g_varchar2_table(375) := ');'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- cleaning up old images, only on update'||wwv_flow.LF||
'    cleanup_old_images;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'end update_task_comme';
wwv_flow_imp.g_varchar2_table(376) := 'nt;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_task_comment ('||wwv_flow.LF||
'    p_comment_id      in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_image_ref_id  numb';
wwv_flow_imp.g_varchar2_table(377) := 'er;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    select image_ref_id'||wwv_flow.LF||
'      into l_image_ref_id'||wwv_flow.LF||
'      from sp_task_comments'||wwv_flow.LF||
'     where i';
wwv_flow_imp.g_varchar2_table(378) := 'd = p_comment_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_image_ref_id is not null then'||wwv_flow.LF||
'        delete from sp_comment_images'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(379) := '     where image_ref_id = l_image_ref_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    delete from sp_task_comments'||wwv_flow.LF||
'     where i';
wwv_flow_imp.g_varchar2_table(380) := 'd = p_comment_id;'||wwv_flow.LF||
'end delete_task_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_release_comment';
wwv_flow_imp.g_varchar2_table(381) := ' ('||wwv_flow.LF||
'    p_app_user_id     in  number,'||wwv_flow.LF||
'    p_app_user        in  varchar2,'||wwv_flow.LF||
'    p_comment         in  v';
wwv_flow_imp.g_varchar2_table(382) := 'archar2,'||wwv_flow.LF||
'    p_release_id      in  number,'||wwv_flow.LF||
'    p_private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_app';
wwv_flow_imp.g_varchar2_table(383) := '_id          in  number,'||wwv_flow.LF||
'    p_link            in  varchar2,'||wwv_flow.LF||
'    p_nomen_sp        in  varchar2,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(384) := ' p_image_ref_id    in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_comment            clob;'||wwv_flow.LF||
'    l_comment_no_im';
wwv_flow_imp.g_varchar2_table(385) := 'ages  clob;'||wwv_flow.LF||
'    l_comment_id         number;'||wwv_flow.LF||
'    l_email_comment      clob;'||wwv_flow.LF||
'    l_mentions          ';
wwv_flow_imp.g_varchar2_table(386) := ' varchar2(4000);'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    l_comment           := replace_session_on_save(p_comment);'||wwv_flow.LF||
'    l_comment';
wwv_flow_imp.g_varchar2_table(387) := '_no_images := replace_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_release_comments ('||wwv_flow.LF||
'        release_id, ';
wwv_flow_imp.g_varchar2_table(388) := ''||wwv_flow.LF||
'        author_id, '||wwv_flow.LF||
'        body,'||wwv_flow.LF||
'        body_html, '||wwv_flow.LF||
'        body_no_images,'||wwv_flow.LF||
'        private_yn,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(389) := '       image_ref_id ) '||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_release_id,'||wwv_flow.LF||
'        p_app_user_id,'||wwv_flow.LF||
'        l_comment,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(390) := '        apex_markdown.to_html(l_comment),'||wwv_flow.LF||
'        regexp_replace(l_comment_no_images, ''\([^)]*/[^/?]';
wwv_flow_imp.g_varchar2_table(391) := '*document-details\?p([0-9]+)_id=[^&]+&clear=\1[^)]*\)'', ''''), -- removes link for docs,'||wwv_flow.LF||
'        p_pri';
wwv_flow_imp.g_varchar2_table(392) := 'vate_yn,'||wwv_flow.LF||
'        p_image_ref_id )'||wwv_flow.LF||
'    returning id into l_comment_id;'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doing imag';
wwv_flow_imp.g_varchar2_table(393) := 'e cleanup'||wwv_flow.LF||
'    remove_orphan_images ('||wwv_flow.LF||
'        p_comment_id   => l_comment_id,'||wwv_flow.LF||
'        p_comment_type ';
wwv_flow_imp.g_varchar2_table(394) := '=> ''RELEASE'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_private_yn = ''N'' and'||wwv_flow.LF||
'       apex_util.get_build_option_status (p_applicati';
wwv_flow_imp.g_varchar2_table(395) := 'on_id => p_app_id, p_build_option_name => ''Comment Tagging'') = ''INCLUDE'' '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'        l_email_c';
wwv_flow_imp.g_varchar2_table(396) := 'omment := apex_markdown.to_html(substr(l_comment_no_images,1,2500)||case when length(l_comment_no_im';
wwv_flow_imp.g_varchar2_table(397) := 'ages) > 2500 then '' ...'' end);'||wwv_flow.LF||
''||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            select apex_escape.html(r.release_tr';
wwv_flow_imp.g_varchar2_table(398) := 'ain||'' ''||r.release) release_esc,'||wwv_flow.LF||
'                   (select apex_escape.html(comment_nbr) from sp_r';
wwv_flow_imp.g_varchar2_table(399) := 'elease_comments where id = l_comment_id) comment_nbr'||wwv_flow.LF||
'              from sp_release_trains r'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(400) := '     where r.id = p_release_id '||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            l_mentions := sp_util.find_mentions(l_com';
wwv_flow_imp.g_varchar2_table(401) := 'ment_no_images);'||wwv_flow.LF||
'            -- mentions (not current user)'||wwv_flow.LF||
'            if l_mentions is not null th';
wwv_flow_imp.g_varchar2_table(402) := 'en'||wwv_flow.LF||
'                for c2 in ('||wwv_flow.LF||
'                    select id, first_name'||wwv_flow.LF||
'                      from ';
wwv_flow_imp.g_varchar2_table(403) := 'sp_team_members'||wwv_flow.LF||
'                     where instr('':''||l_mentions||'':'','':''||screen_name||'':'') > 0'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(404) := '                    and id != p_app_user_id '||wwv_flow.LF||
'                       and screen_name is not null'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(405) := '            ) loop'||wwv_flow.LF||
'                    sp_util.comment_notification ('||wwv_flow.LF||
'                        p_team';
wwv_flow_imp.g_varchar2_table(406) := '_member_id => c2.id, '||wwv_flow.LF||
'                        p_app_name       => p_nomen_sp, '||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(407) := '   p_app_id         => p_app_id,'||wwv_flow.LF||
'                        p_title          => ''You were mentioned in ';
wwv_flow_imp.g_varchar2_table(408) := 'a comment added to Release ''||c1.release_esc,'||wwv_flow.LF||
'                        p_release_id     => p_release_';
wwv_flow_imp.g_varchar2_table(409) := 'id, '||wwv_flow.LF||
'                        p_link           => p_link, '||wwv_flow.LF||
'                        p_view_what      =';
wwv_flow_imp.g_varchar2_table(410) := '> ''Release'','||wwv_flow.LF||
'                        p_email_contents => ''Hi ''||c2.first_name||''<br/><br/>''||'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(411) := '                                      ''You were mentioned in a new comment added to <a  style="font-';
wwv_flow_imp.g_varchar2_table(412) := 'weight:bold" href="''||p_link||''">''||c1.release_esc||''</a><br/>''||'||wwv_flow.LF||
'                                  ';
wwv_flow_imp.g_varchar2_table(413) := '          ''Comment: ''||c1.comment_nbr||''<br/>''||'||wwv_flow.LF||
'                                            ''Commen';
wwv_flow_imp.g_varchar2_table(414) := 't by: ''||apex_escape.html(lower(p_app_user))||''<br/>''||'||wwv_flow.LF||
'                                            ';
wwv_flow_imp.g_varchar2_table(415) := 'l_email_comment,'||wwv_flow.LF||
'                        p_notification_type => ''MENTION'' );'||wwv_flow.LF||
'                end loo';
wwv_flow_imp.g_varchar2_table(416) := 'p;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'end add_release_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_re';
wwv_flow_imp.g_varchar2_table(417) := 'lease_comment ('||wwv_flow.LF||
'    p_comment_id      in  number,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_private_';
wwv_flow_imp.g_varchar2_table(418) := 'yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_image_ref_id    in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_comment';
wwv_flow_imp.g_varchar2_table(419) := '            clob;'||wwv_flow.LF||
'    l_comment_no_images  clob;'||wwv_flow.LF||
'    l_image_ref_id       number;'||wwv_flow.LF||
'    l_image_list  ';
wwv_flow_imp.g_varchar2_table(420) := '       varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_comment           := replace_session_on_save(p_comment);'||wwv_flow.LF||
'    l_co';
wwv_flow_imp.g_varchar2_table(421) := 'mment_no_images := replace_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- for existing content, there may be no image_re';
wwv_flow_imp.g_varchar2_table(422) := 'f_id, so need to add one'||wwv_flow.LF||
'    update sp_release_comments'||wwv_flow.LF||
'       set body           = l_comment,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(423) := '      body_html      = apex_markdown.to_html(l_comment),'||wwv_flow.LF||
'           body_no_images = regexp_replace(';
wwv_flow_imp.g_varchar2_table(424) := 'l_comment_no_images, ''\([^)]*/[^/?]*document-details\?p([0-9]+)_id=[^&]+&clear=\1[^)]*\)'', ''''), -- r';
wwv_flow_imp.g_varchar2_table(425) := 'emoves link for docs,'||wwv_flow.LF||
'           private_yn     = p_private_yn,'||wwv_flow.LF||
'           image_ref_id   = nvl(imag';
wwv_flow_imp.g_varchar2_table(426) := 'e_ref_id,to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX''))'||wwv_flow.LF||
'     where id = p_comment_id'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(427) := ' returning image_ref_id into l_image_ref_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_image_list := find_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_';
wwv_flow_imp.g_varchar2_table(428) := 'image_list is not null then'||wwv_flow.LF||
'        -- updating image_ref_id to match that of the existing content'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(429) := '       update sp_comment_images'||wwv_flow.LF||
'           set image_ref_id = l_image_ref_id '||wwv_flow.LF||
'         where instr(''';
wwv_flow_imp.g_varchar2_table(430) := ':''||l_image_list||'':'','':''||unique_filename||'':'') > 0'||wwv_flow.LF||
'           and image_ref_id = p_image_ref_id;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(431) := '   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doing image cleanup'||wwv_flow.LF||
'    remove_orphan_images ('||wwv_flow.LF||
'        p_comment_id   => p_commen';
wwv_flow_imp.g_varchar2_table(432) := 't_id,'||wwv_flow.LF||
'        p_comment_type => ''RELEASE'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- cleaning up old images, only on update'||wwv_flow.LF||
'    clean';
wwv_flow_imp.g_varchar2_table(433) := 'up_old_images;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'end update_release_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_release_comment ('||wwv_flow.LF||
'    p_comment_i';
wwv_flow_imp.g_varchar2_table(434) := 'd      in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_image_ref_id  number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    select image_ref_id'||wwv_flow.LF||
'      into l_image_';
wwv_flow_imp.g_varchar2_table(435) := 'ref_id'||wwv_flow.LF||
'      from sp_release_comments'||wwv_flow.LF||
'     where id = p_comment_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_image_ref_id is not nu';
wwv_flow_imp.g_varchar2_table(436) := 'll then'||wwv_flow.LF||
'        delete from sp_comment_images'||wwv_flow.LF||
'         where image_ref_id = l_image_ref_id;'||wwv_flow.LF||
'    end ';
wwv_flow_imp.g_varchar2_table(437) := 'if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    delete from sp_release_comments'||wwv_flow.LF||
'     where id = p_comment_id;'||wwv_flow.LF||
'end delete_release_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(438) := '-------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_init_focus_area_comment ('||wwv_flow.LF||
'    p_app_user_id         in  num';
wwv_flow_imp.g_varchar2_table(439) := 'ber,'||wwv_flow.LF||
'    p_app_user            in  varchar2,'||wwv_flow.LF||
'    p_comment             in  varchar2,'||wwv_flow.LF||
'    p_init_focu';
wwv_flow_imp.g_varchar2_table(440) := 's_area_id  in  number,'||wwv_flow.LF||
'    p_private_yn          in  varchar2 default ''N'','||wwv_flow.LF||
'    p_app_id             ';
wwv_flow_imp.g_varchar2_table(441) := ' in  number,'||wwv_flow.LF||
'    p_link                in  varchar2,'||wwv_flow.LF||
'    p_nomen_sp            in  varchar2, '||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(442) := 'image_ref_id        in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_comment            clob;'||wwv_flow.LF||
'    l_comment_no_i';
wwv_flow_imp.g_varchar2_table(443) := 'mages  clob;'||wwv_flow.LF||
'    l_comment_id         number;'||wwv_flow.LF||
'    l_email_comment      clob;'||wwv_flow.LF||
'    l_mentions         ';
wwv_flow_imp.g_varchar2_table(444) := '  varchar2(4000);'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    l_comment           := replace_session_on_save(p_comment);'||wwv_flow.LF||
'    l_commen';
wwv_flow_imp.g_varchar2_table(445) := 't_no_images := replace_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_init_focus_area_comments ('||wwv_flow.LF||
'        ini';
wwv_flow_imp.g_varchar2_table(446) := 't_focus_area_id, '||wwv_flow.LF||
'        author_id, '||wwv_flow.LF||
'        body,'||wwv_flow.LF||
'        body_html, '||wwv_flow.LF||
'        body_no_images,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(447) := '    private_yn,'||wwv_flow.LF||
'        image_ref_id ) '||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_init_focus_area_id,'||wwv_flow.LF||
'        p_app_use';
wwv_flow_imp.g_varchar2_table(448) := 'r_id,'||wwv_flow.LF||
'        l_comment,'||wwv_flow.LF||
'        apex_markdown.to_html(l_comment),'||wwv_flow.LF||
'        regexp_replace(l_comment_';
wwv_flow_imp.g_varchar2_table(449) := 'no_images, ''\([^)]*/[^/?]*document-details\?p([0-9]+)_id=[^&]+&clear=\1[^)]*\)'', ''''), -- removes lin';
wwv_flow_imp.g_varchar2_table(450) := 'k for docs,'||wwv_flow.LF||
'        p_private_yn,'||wwv_flow.LF||
'        p_image_ref_id )'||wwv_flow.LF||
'    returning id into l_comment_id;'||wwv_flow.LF||
'    c';
wwv_flow_imp.g_varchar2_table(451) := 'ommit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doing image cleanup'||wwv_flow.LF||
'    remove_orphan_images ('||wwv_flow.LF||
'        p_comment_id   => l_comment_id';
wwv_flow_imp.g_varchar2_table(452) := ','||wwv_flow.LF||
'        p_comment_type => ''INIT_FOCUS_AREA'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_private_yn = ''N'' and'||wwv_flow.LF||
'       apex_util.get';
wwv_flow_imp.g_varchar2_table(453) := '_build_option_status (p_application_id => p_app_id, p_build_option_name => ''Comment Tagging'') = ''INC';
wwv_flow_imp.g_varchar2_table(454) := 'LUDE'' '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'        l_email_comment := apex_markdown.to_html(substr(l_comment_no_images,1,2500)|';
wwv_flow_imp.g_varchar2_table(455) := '|case when length(l_comment_no_images) > 2500 then '' ...'' end);'||wwv_flow.LF||
''||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            sel';
wwv_flow_imp.g_varchar2_table(456) := 'ect apex_escape.html(focus_area) fa_esc,'||wwv_flow.LF||
'                   (select apex_escape.html(comment_nbr) fr';
wwv_flow_imp.g_varchar2_table(457) := 'om sp_init_focus_area_comments where id = l_comment_id) comment_nbr,'||wwv_flow.LF||
'                   apex_escape.';
wwv_flow_imp.g_varchar2_table(458) := 'html(sp_util.get_nomenclature (p_static_id => ''INITIATIVE''))|| '' Focus Area'' init_fa_word,'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(459) := '          (select apex_escape.html(initiative) from sp_initiatives where id = fa.initiative_id) init';
wwv_flow_imp.g_varchar2_table(460) := 'iative_esc'||wwv_flow.LF||
'              from sp_initiative_focus_areas fa'||wwv_flow.LF||
'             where id = p_init_focus_area';
wwv_flow_imp.g_varchar2_table(461) := '_id '||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            l_mentions := sp_util.find_mentions(l_comment_no_images);'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(462) := '  -- mentions (not current user)'||wwv_flow.LF||
'            if l_mentions is not null then'||wwv_flow.LF||
'                for c2 i';
wwv_flow_imp.g_varchar2_table(463) := 'n ('||wwv_flow.LF||
'                    select id, first_name'||wwv_flow.LF||
'                      from sp_team_members'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(464) := '          where instr('':''||l_mentions||'':'','':''||screen_name||'':'') > 0'||wwv_flow.LF||
'                       and id ';
wwv_flow_imp.g_varchar2_table(465) := '!= p_app_user_id '||wwv_flow.LF||
'                       and screen_name is not null'||wwv_flow.LF||
'                ) loop'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(466) := '            sp_util.comment_notification ('||wwv_flow.LF||
'                        p_team_member_id     => c2.id, '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(467) := '                       p_app_name           => p_nomen_sp, '||wwv_flow.LF||
'                        p_app_id        ';
wwv_flow_imp.g_varchar2_table(468) := '     => p_app_id,'||wwv_flow.LF||
'                        p_title              => ''You were mentioned in a comment a';
wwv_flow_imp.g_varchar2_table(469) := 'dded to ''||c1.init_fa_word||'' ''||c1.initiative_esc||'' - ''||c1.fa_esc,'||wwv_flow.LF||
'                        p_init';
wwv_flow_imp.g_varchar2_table(470) := '_focus_area_id => p_init_focus_area_id, '||wwv_flow.LF||
'                        p_link               => p_link, '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(471) := '                      p_view_what          => c1.init_fa_word,'||wwv_flow.LF||
'                        p_email_conte';
wwv_flow_imp.g_varchar2_table(472) := 'nts     => ''Hi ''||c2.first_name||''<br/><br/>''||'||wwv_flow.LF||
'                                                ''You';
wwv_flow_imp.g_varchar2_table(473) := ' were mentioned in a new comment added to <a  style="font-weight:bold" href="''||p_link||''">''||c1.ini';
wwv_flow_imp.g_varchar2_table(474) := 'tiative_esc||'' - ''||c1.fa_esc||''</a><br/>''||'||wwv_flow.LF||
'                                                ''Commen';
wwv_flow_imp.g_varchar2_table(475) := 't: ''||c1.comment_nbr||''<br/>''||'||wwv_flow.LF||
'                                                ''Comment by: ''||apex';
wwv_flow_imp.g_varchar2_table(476) := '_escape.html(lower(p_app_user))||''<br/>''||'||wwv_flow.LF||
'                                                l_email_c';
wwv_flow_imp.g_varchar2_table(477) := 'omment,'||wwv_flow.LF||
'                        p_notification_type     => ''MENTION'' );'||wwv_flow.LF||
'                end loop;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(478) := '          end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'end add_init_focus_area_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update';
wwv_flow_imp.g_varchar2_table(479) := '_init_focus_area_comment ('||wwv_flow.LF||
'    p_comment_id      in  number,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(480) := ' p_private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_image_ref_id    in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(481) := '  l_comment            clob;'||wwv_flow.LF||
'    l_comment_no_images  clob;'||wwv_flow.LF||
'    l_image_ref_id       number;'||wwv_flow.LF||
'    l_i';
wwv_flow_imp.g_varchar2_table(482) := 'mage_list         varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_comment           := replace_session_on_save(p_comment';
wwv_flow_imp.g_varchar2_table(483) := ');'||wwv_flow.LF||
'    l_comment_no_images := replace_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- for existing content, there may be ';
wwv_flow_imp.g_varchar2_table(484) := 'no image_ref_id, so need to add one'||wwv_flow.LF||
'    update sp_init_focus_area_comments'||wwv_flow.LF||
'       set body          ';
wwv_flow_imp.g_varchar2_table(485) := ' = l_comment,'||wwv_flow.LF||
'           body_html      = apex_markdown.to_html(l_comment),'||wwv_flow.LF||
'           body_no_image';
wwv_flow_imp.g_varchar2_table(486) := 's = regexp_replace(l_comment_no_images, ''\([^)]*/[^/?]*document-details\?p([0-9]+)_id=[^&]+&clear=\1';
wwv_flow_imp.g_varchar2_table(487) := '[^)]*\)'', ''''), -- removes link for docs,'||wwv_flow.LF||
'           private_yn     = p_private_yn,'||wwv_flow.LF||
'           image_';
wwv_flow_imp.g_varchar2_table(488) := 'ref_id   = nvl(image_ref_id,to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX''))'||wwv_flow.LF||
'     where id';
wwv_flow_imp.g_varchar2_table(489) := ' = p_comment_id'||wwv_flow.LF||
'    returning image_ref_id into l_image_ref_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_image_list := find_images(l_c';
wwv_flow_imp.g_varchar2_table(490) := 'omment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_image_list is not null then'||wwv_flow.LF||
'        -- updating image_ref_id to match that of the';
wwv_flow_imp.g_varchar2_table(491) := ' existing content'||wwv_flow.LF||
'        update sp_comment_images'||wwv_flow.LF||
'           set image_ref_id = l_image_ref_id '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(492) := '      where instr('':''||l_image_list||'':'','':''||unique_filename||'':'') > 0'||wwv_flow.LF||
'           and image_ref_id ';
wwv_flow_imp.g_varchar2_table(493) := '= p_image_ref_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doing image cleanup'||wwv_flow.LF||
'    remove_orphan_images ('||wwv_flow.LF||
'        p_comme';
wwv_flow_imp.g_varchar2_table(494) := 'nt_id   => p_comment_id,'||wwv_flow.LF||
'        p_comment_type => ''INIT_FOCUS_AREA'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- cleaning up old image';
wwv_flow_imp.g_varchar2_table(495) := 's, only on update'||wwv_flow.LF||
'    cleanup_old_images;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'end update_init_focus_area_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delet';
wwv_flow_imp.g_varchar2_table(496) := 'e_init_focus_area_comment ('||wwv_flow.LF||
'    p_comment_id      in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_image_ref_id  number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(497) := '    select image_ref_id'||wwv_flow.LF||
'      into l_image_ref_id'||wwv_flow.LF||
'      from sp_init_focus_area_comments'||wwv_flow.LF||
'     where ';
wwv_flow_imp.g_varchar2_table(498) := 'id = p_comment_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_image_ref_id is not null then'||wwv_flow.LF||
'        delete from sp_comment_images'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(499) := '      where image_ref_id = l_image_ref_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    delete from sp_init_focus_area_comments'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(500) := '     where id = p_comment_id;'||wwv_flow.LF||
'end delete_init_focus_area_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
'----------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure';
wwv_flow_imp.g_varchar2_table(501) := ' add_activity_comment ('||wwv_flow.LF||
'    p_app_user_id     in  number,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(502) := 'private_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_activity_id     in  number,'||wwv_flow.LF||
'    p_image_ref_id    in';
wwv_flow_imp.g_varchar2_table(503) := '  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_comment_id         number;'||wwv_flow.LF||
'    l_comment            clob;'||wwv_flow.LF||
'    l_c';
wwv_flow_imp.g_varchar2_table(504) := 'omment_no_images  clob;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
''||wwv_flow.LF||
'    l_comment           := replace_session_on_save(p_comment);'||wwv_flow.LF||
'    l';
wwv_flow_imp.g_varchar2_table(505) := '_comment_no_images := replace_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_activity_comments ('||wwv_flow.LF||
'        act';
wwv_flow_imp.g_varchar2_table(506) := 'ivity_id, '||wwv_flow.LF||
'        author_id, '||wwv_flow.LF||
'        body,'||wwv_flow.LF||
'        body_html, '||wwv_flow.LF||
'        body_no_images,'||wwv_flow.LF||
'        pri';
wwv_flow_imp.g_varchar2_table(507) := 'vate_yn,'||wwv_flow.LF||
'        image_ref_id ) '||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_activity_id,'||wwv_flow.LF||
'        p_app_user_id,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(508) := 'l_comment,'||wwv_flow.LF||
'        apex_markdown.to_html(l_comment),'||wwv_flow.LF||
'        l_comment_no_images,'||wwv_flow.LF||
'        p_private_';
wwv_flow_imp.g_varchar2_table(509) := 'yn,'||wwv_flow.LF||
'        p_image_ref_id )'||wwv_flow.LF||
'    returning id into l_comment_id;'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doing image cle';
wwv_flow_imp.g_varchar2_table(510) := 'anup'||wwv_flow.LF||
'    remove_orphan_images ('||wwv_flow.LF||
'        p_comment_id   => l_comment_id,'||wwv_flow.LF||
'        p_comment_type => ''A';
wwv_flow_imp.g_varchar2_table(511) := 'CTIVITY'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- no mention support'||wwv_flow.LF||
'end add_activity_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_activity_comment';
wwv_flow_imp.g_varchar2_table(512) := ' ('||wwv_flow.LF||
'    p_comment_id      in  number,'||wwv_flow.LF||
'    p_comment         in  varchar2,'||wwv_flow.LF||
'    p_private_yn      in  v';
wwv_flow_imp.g_varchar2_table(513) := 'archar2 default ''N'','||wwv_flow.LF||
'    p_image_ref_id    in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_comment            c';
wwv_flow_imp.g_varchar2_table(514) := 'lob;'||wwv_flow.LF||
'    l_comment_no_images  clob;'||wwv_flow.LF||
'    l_image_ref_id       number;'||wwv_flow.LF||
'    l_image_list         varcha';
wwv_flow_imp.g_varchar2_table(515) := 'r2(4000);'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_comment           := replace_session_on_save(p_comment);'||wwv_flow.LF||
'    l_comment_no_ima';
wwv_flow_imp.g_varchar2_table(516) := 'ges := replace_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- for existing content, there may be no image_ref_id, so nee';
wwv_flow_imp.g_varchar2_table(517) := 'd to add one'||wwv_flow.LF||
'    update sp_activity_comments'||wwv_flow.LF||
'       set body           = l_comment,'||wwv_flow.LF||
'           body_';
wwv_flow_imp.g_varchar2_table(518) := 'html      = apex_markdown.to_html(l_comment),'||wwv_flow.LF||
'           body_no_images = regexp_replace(l_comment_n';
wwv_flow_imp.g_varchar2_table(519) := 'o_images, ''\([^)]*/[^/?]*document-details\?p([0-9]+)_id=[^&]+&clear=\1[^)]*\)'', ''''), -- removes link';
wwv_flow_imp.g_varchar2_table(520) := ' for docs,'||wwv_flow.LF||
'           private_yn     = p_private_yn,'||wwv_flow.LF||
'           image_ref_id   = nvl(image_ref_id,to';
wwv_flow_imp.g_varchar2_table(521) := '_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX''))'||wwv_flow.LF||
'     where id = p_comment_id'||wwv_flow.LF||
'    returning ';
wwv_flow_imp.g_varchar2_table(522) := 'image_ref_id into l_image_ref_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_image_list := find_images(l_comment);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- if no images ';
wwv_flow_imp.g_varchar2_table(523) := 'found, no need to update references'||wwv_flow.LF||
'    if l_image_list is not null then'||wwv_flow.LF||
'        -- updating image_r';
wwv_flow_imp.g_varchar2_table(524) := 'ef_id to match that of the existing content'||wwv_flow.LF||
'        update sp_comment_images'||wwv_flow.LF||
'           set image_re';
wwv_flow_imp.g_varchar2_table(525) := 'f_id = l_image_ref_id '||wwv_flow.LF||
'         where instr('':''||l_image_list||'':'','':''||unique_filename||'':'') > 0'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(526) := '         and image_ref_id = p_image_ref_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- doing image cleanup'||wwv_flow.LF||
'    remove_orpha';
wwv_flow_imp.g_varchar2_table(527) := 'n_images ('||wwv_flow.LF||
'        p_comment_id   => p_comment_id,'||wwv_flow.LF||
'        p_comment_type => ''ACTIVITY'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- cl';
wwv_flow_imp.g_varchar2_table(528) := 'eaning up old images, only on update'||wwv_flow.LF||
'    cleanup_old_images;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'end update_activity_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'pro';
wwv_flow_imp.g_varchar2_table(529) := 'cedure delete_activity_comment ('||wwv_flow.LF||
'    p_comment_id      in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_image_ref_id  number;'||wwv_flow.LF||
'b';
wwv_flow_imp.g_varchar2_table(530) := 'egin'||wwv_flow.LF||
'    select image_ref_id'||wwv_flow.LF||
'      into l_image_ref_id'||wwv_flow.LF||
'      from sp_activity_comments'||wwv_flow.LF||
'     where id';
wwv_flow_imp.g_varchar2_table(531) := ' = p_comment_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_image_ref_id is not null then'||wwv_flow.LF||
'        delete from sp_comment_images'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(532) := '    where image_ref_id = l_image_ref_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    delete from sp_activity_comments'||wwv_flow.LF||
'     wher';
wwv_flow_imp.g_varchar2_table(533) := 'e id = p_comment_id;'||wwv_flow.LF||
'end delete_activity_comment;'||wwv_flow.LF||
''||wwv_flow.LF||
'---------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure upload_ima';
wwv_flow_imp.g_varchar2_table(534) := 'ge ('||wwv_flow.LF||
'    p_file_base64           in  clob,'||wwv_flow.LF||
'    p_filename              in  varchar2,'||wwv_flow.LF||
'    p_mimetype ';
wwv_flow_imp.g_varchar2_table(535) := '             in  varchar2,'||wwv_flow.LF||
'    p_image_ref_id          in  number ) '||wwv_flow.LF||
'as'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_rte_file_types     va';
wwv_flow_imp.g_varchar2_table(536) := 'rchar2(255) := ''jpeg|image/jpeg,jpg|image/jpg,gif|image/gif,png|image/png,webp|image/webp'';'||wwv_flow.LF||
'    l_un';
wwv_flow_imp.g_varchar2_table(537) := 'ique_filename    sp_comment_images.unique_filename%type;'||wwv_flow.LF||
'    l_max_file_size_mb   pls_integer := 3;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(538) := '    l_file               blob;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- Exceptions'||wwv_flow.LF||
'    e_image_too_large    exception;'||wwv_flow.LF||
'    e_invalid_';
wwv_flow_imp.g_varchar2_table(539) := 'mime_type  exception;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- Handles JSON message error handling'||wwv_flow.LF||
'    procedure send_error ('||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(540) := ' p_message in varchar2 )'||wwv_flow.LF||
'    as'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        apex_json.open_object;'||wwv_flow.LF||
'        apex_json.open_obje';
wwv_flow_imp.g_varchar2_table(541) := 'ct(''error'');'||wwv_flow.LF||
'        apex_json.write(''message'', p_message);'||wwv_flow.LF||
'        apex_json.close_object;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(542) := 'apex_json.close_object;'||wwv_flow.LF||
'    end send_error;'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_file := apex_web_service.clobbase642blob(p_';
wwv_flow_imp.g_varchar2_table(543) := 'file_base64);'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- Validations'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- File not too big'||wwv_flow.LF||
'    if sys.dbms_lob.getlength(l_file) / (';
wwv_flow_imp.g_varchar2_table(544) := ' power(1024, 3) / 1024 ) > l_max_file_size_mb then'||wwv_flow.LF||
'        raise e_image_too_large;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(545) := ' -- Valid mimetype'||wwv_flow.LF||
'    if instr(l_rte_file_types, ''|'' || lower(p_mimetype), 1) = 0 then'||wwv_flow.LF||
'        rais';
wwv_flow_imp.g_varchar2_table(546) := 'e e_invalid_mime_type;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_unique_filename := sys.dbms_random.string(''a'',8) || ''-'' ||';
wwv_flow_imp.g_varchar2_table(547) := ' substr(sys.dbms_random.normal,-4) || ''-'' || sys.dbms_random.string(''a'',8);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_comm';
wwv_flow_imp.g_varchar2_table(548) := 'ent_images'||wwv_flow.LF||
'        (file_blob, unique_filename, filename, mimetype, blob_size, '||wwv_flow.LF||
'         created, cr';
wwv_flow_imp.g_varchar2_table(549) := 'eated_by, image_ref_id)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (l_file, l_unique_filename, p_filename, p_mimetype, sys.d';
wwv_flow_imp.g_varchar2_table(550) := 'bms_lob.getlength(l_file), '||wwv_flow.LF||
'         sysdate, apex_application.g_user, p_image_ref_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'    apex_js';
wwv_flow_imp.g_varchar2_table(551) := 'on.open_object;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- P9000: Rejoin Sessions: Enabled for all sessions (where supported)'||wwv_flow.LF||
'    apex_';
wwv_flow_imp.g_varchar2_table(552) := 'json.write(''url'', '||wwv_flow.LF||
'        apex_page.get_url ('||wwv_flow.LF||
'            p_page => 9000,'||wwv_flow.LF||
'            p_plain_url =';
wwv_flow_imp.g_varchar2_table(553) := '> true,'||wwv_flow.LF||
'            p_x01  => l_unique_filename'||wwv_flow.LF||
'        )'||wwv_flow.LF||
'    );'||wwv_flow.LF||
' '||wwv_flow.LF||
'    apex_json.write(''mimetype'', p';
wwv_flow_imp.g_varchar2_table(554) := '_mimetype);'||wwv_flow.LF||
'    apex_json.close_object;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'        when e_image_too_large then'||wwv_flow.LF||
'            s';
wwv_flow_imp.g_varchar2_table(555) := 'end_error ('||wwv_flow.LF||
'                p_message => apex_string.format('||wwv_flow.LF||
'                    p_message  => ''File';
wwv_flow_imp.g_varchar2_table(556) := ' too large must be less than %0MB'','||wwv_flow.LF||
'                    p0         => l_max_file_size_mb'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(557) := '     )'||wwv_flow.LF||
'            );'||wwv_flow.LF||
'        when e_invalid_mime_type then'||wwv_flow.LF||
'            send_error(p_message => ''Inv';
wwv_flow_imp.g_varchar2_table(558) := 'alid mimetype'');'||wwv_flow.LF||
'        when others then'||wwv_flow.LF||
'            send_error(p_message => ''Could not upload file';
wwv_flow_imp.g_varchar2_table(559) := ': '' || sqlerrm );'||wwv_flow.LF||
'end upload_image;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure display_image ('||wwv_flow.LF||
'    p_unique_filename  in  varchar2 ';
wwv_flow_imp.g_varchar2_table(560) := ')'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_file_blob  sp_comment_images.file_blob%type;'||wwv_flow.LF||
'    l_mimetype   sp_comment_images.mimetype%';
wwv_flow_imp.g_varchar2_table(561) := 'type;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    select file_blob, mimetype'||wwv_flow.LF||
'      into l_file_blob, l_mimetype'||wwv_flow.LF||
'      from sp_comment';
wwv_flow_imp.g_varchar2_table(562) := '_images'||wwv_flow.LF||
'     where unique_filename = apex_application.g_x01;'||wwv_flow.LF||
''||wwv_flow.LF||
'    apex_http.download ('||wwv_flow.LF||
'        p_blo';
wwv_flow_imp.g_varchar2_table(563) := 'b         => l_file_blob,'||wwv_flow.LF||
'        p_content_type => l_mimetype,'||wwv_flow.LF||
'        p_is_inline    => true );'||wwv_flow.LF||
''||wwv_flow.LF||
'e';
wwv_flow_imp.g_varchar2_table(564) := 'nd display_image;'||wwv_flow.LF||
''||wwv_flow.LF||
'-----------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_mentions ('||wwv_flow.LF||
'    p_search     in  varchar2,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(565) := '   p_scope      in  varchar2, -- PROJECT, TASK, RELEASE, INITIATIVE, FOCUS_AREA'||wwv_flow.LF||
'    p_object_id  in ';
wwv_flow_imp.g_varchar2_table(566) := ' number'||wwv_flow.LF||
') return clob'||wwv_flow.LF||
'as'||wwv_flow.LF||
'    c_json_mentions_key  constant varchar2(10)   := ''mentions'';'||wwv_flow.LF||
'    c_searc';
wwv_flow_imp.g_varchar2_table(567) := 'h             constant varchar2(1000) := lower(p_search);'||wwv_flow.LF||
'    c_search_length      constant number  ';
wwv_flow_imp.g_varchar2_table(568) := '       := nvl(length(c_search),0);'||wwv_flow.LF||
'    c_rows_returned      constant number         := 20;'||wwv_flow.LF||
'    l_ret';
wwv_flow_imp.g_varchar2_table(569) := 'urn             clob;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    if instr(c_search, '' '') > 0 then-- in CK Editor if you start an "@"';
wwv_flow_imp.g_varchar2_table(570) := ' followed by spaces and then more words it keeps sending over (bug in CK Editor)'||wwv_flow.LF||
'        return json';
wwv_flow_imp.g_varchar2_table(571) := '_object(c_json_mentions_key value null);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    select'||wwv_flow.LF||
'        json_object('||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(572) := '  c_json_mentions_key value json_arrayagg('||wwv_flow.LF||
'                    json_object('||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(573) := '''name''        value name,'||wwv_flow.LF||
'                        ''email''       value email,'||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(574) := ' ''id''          value ''@'' || screen_name, -- Must start with ''@'' and be called id'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(575) := '     ''avatarUrl''   value photo_url'||wwv_flow.LF||
'                    )'||wwv_flow.LF||
'                    returning clob'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(576) := '        )'||wwv_flow.LF||
'                returning clob'||wwv_flow.LF||
'        )'||wwv_flow.LF||
'    into l_return'||wwv_flow.LF||
'    from '||wwv_flow.LF||
'    ('||wwv_flow.LF||
'    select * fr';
wwv_flow_imp.g_varchar2_table(577) := 'om '||wwv_flow.LF||
'    ('||wwv_flow.LF||
'        with assoc_users as '||wwv_flow.LF||
'        ('||wwv_flow.LF||
'        select owner_id tm_id'||wwv_flow.LF||
'          from sp_pro';
wwv_flow_imp.g_varchar2_table(578) := 'jects'||wwv_flow.LF||
'         where id = p_object_id'||wwv_flow.LF||
'           and owner_id is not null'||wwv_flow.LF||
'           and p_scope = ''';
wwv_flow_imp.g_varchar2_table(579) := 'PROJECT'''||wwv_flow.LF||
'        union'||wwv_flow.LF||
'        select c.team_member_id tm_id'||wwv_flow.LF||
'          from sp_projects p,'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(580) := '      sp_project_contributors c'||wwv_flow.LF||
'         where p.id = p_object_id'||wwv_flow.LF||
'           and p.id = c.project_id';
wwv_flow_imp.g_varchar2_table(581) := ''||wwv_flow.LF||
'           and p_scope = ''PROJECT'''||wwv_flow.LF||
'        union'||wwv_flow.LF||
'        select t.owner_id tm_id'||wwv_flow.LF||
'          from sp_';
wwv_flow_imp.g_varchar2_table(582) := 'projects p,'||wwv_flow.LF||
'               sp_tasks t'||wwv_flow.LF||
'         where p.id = p_object_id'||wwv_flow.LF||
'           and p.id = t.proj';
wwv_flow_imp.g_varchar2_table(583) := 'ect_id'||wwv_flow.LF||
'           and t.owner_id is not null'||wwv_flow.LF||
'           and p_scope = ''PROJECT'''||wwv_flow.LF||
'        union'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(584) := '  select c.author_id tm_id'||wwv_flow.LF||
'          from sp_projects p,'||wwv_flow.LF||
'               sp_project_comments c'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(585) := '   where p.id = p_object_id'||wwv_flow.LF||
'           and p.id = c.project_id'||wwv_flow.LF||
'           and p_scope = ''PROJECT'''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(586) := '      union all'||wwv_flow.LF||
''||wwv_flow.LF||
'        select t.owner_id tm_id'||wwv_flow.LF||
'          from sp_tasks t'||wwv_flow.LF||
'         where t.id = p_o';
wwv_flow_imp.g_varchar2_table(587) := 'bject_id'||wwv_flow.LF||
'           and t.owner_id is not null'||wwv_flow.LF||
'           and p_scope = ''TASK'''||wwv_flow.LF||
'        union'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(588) := ' select c.author_id tm_id'||wwv_flow.LF||
'          from sp_tasks t,'||wwv_flow.LF||
'               sp_task_comments c'||wwv_flow.LF||
'         wher';
wwv_flow_imp.g_varchar2_table(589) := 'e t.id = p_object_id'||wwv_flow.LF||
'           and t.id = c.task_id'||wwv_flow.LF||
'           and p_scope = ''TASK'''||wwv_flow.LF||
'        union'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(590) := '       select p.owner_id tm_id'||wwv_flow.LF||
'          from sp_projects p,'||wwv_flow.LF||
'               sp_tasks t'||wwv_flow.LF||
'         wher';
wwv_flow_imp.g_varchar2_table(591) := 'e t.id = p_object_id'||wwv_flow.LF||
'           and t.project_id = p.id'||wwv_flow.LF||
'           and p.owner_id is not null'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(592) := '     and p_scope = ''TASK'''||wwv_flow.LF||
'        union'||wwv_flow.LF||
'        select c.team_member_id tm_id'||wwv_flow.LF||
'          from sp_task';
wwv_flow_imp.g_varchar2_table(593) := 's t,'||wwv_flow.LF||
'               sp_projects p,'||wwv_flow.LF||
'               sp_project_contributors c'||wwv_flow.LF||
'         where t.id = p_';
wwv_flow_imp.g_varchar2_table(594) := 'object_id'||wwv_flow.LF||
'           and t.project_id = p.id'||wwv_flow.LF||
'           and p.id = c.project_id'||wwv_flow.LF||
'           and p_sco';
wwv_flow_imp.g_varchar2_table(595) := 'pe = ''TASK'''||wwv_flow.LF||
'        union all'||wwv_flow.LF||
''||wwv_flow.LF||
'        select t.release_owner_id tm_id'||wwv_flow.LF||
'          from sp_release_tra';
wwv_flow_imp.g_varchar2_table(596) := 'ins t'||wwv_flow.LF||
'         where t.id = p_object_id'||wwv_flow.LF||
'           and t.release_owner_id is not null'||wwv_flow.LF||
'           and';
wwv_flow_imp.g_varchar2_table(597) := ' p_scope = ''RELEASE'''||wwv_flow.LF||
'        union'||wwv_flow.LF||
'        select c.author_id tm_id'||wwv_flow.LF||
'          from sp_release_trains';
wwv_flow_imp.g_varchar2_table(598) := ' t,'||wwv_flow.LF||
'               sp_release_comments c'||wwv_flow.LF||
'         where t.id = p_object_id'||wwv_flow.LF||
'           and t.id = c.r';
wwv_flow_imp.g_varchar2_table(599) := 'elease_id'||wwv_flow.LF||
'           and p_scope = ''RELEASE'''||wwv_flow.LF||
'        union'||wwv_flow.LF||
'        select p.owner_id tm_id'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(600) := ' from sp_release_trains t,'||wwv_flow.LF||
'               sp_projects p'||wwv_flow.LF||
'         where t.id = p_object_id'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(601) := ' and t.id = p.release_id'||wwv_flow.LF||
'           and p.owner_id is not null'||wwv_flow.LF||
'           and p_scope = ''RELEASE'''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(602) := '      union all'||wwv_flow.LF||
''||wwv_flow.LF||
'        select a.owner_id tm_id'||wwv_flow.LF||
'          from sp_areas a, sp_initiatives i'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(603) := '  where a.id = i.area_id'||wwv_flow.LF||
'           and i.id = p_object_id'||wwv_flow.LF||
'           and a.owner_id is not null'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(604) := '        and p_scope = ''INITIATIVE'''||wwv_flow.LF||
'        union'||wwv_flow.LF||
'        select i.sponsor_id tm_id'||wwv_flow.LF||
'          from sp';
wwv_flow_imp.g_varchar2_table(605) := '_areas a, sp_initiatives i'||wwv_flow.LF||
'         where a.id = i.area_id'||wwv_flow.LF||
'           and i.id = p_object_id'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(606) := '    and i.sponsor_id is not null'||wwv_flow.LF||
'           and p_scope = ''INITIATIVE'''||wwv_flow.LF||
'        union'||wwv_flow.LF||
'        select ';
wwv_flow_imp.g_varchar2_table(607) := 'c.author_id tm_id'||wwv_flow.LF||
'          from sp_areas a, sp_initiatives i,'||wwv_flow.LF||
'               sp_initiative_comments';
wwv_flow_imp.g_varchar2_table(608) := ' c'||wwv_flow.LF||
'         where a.id = i.area_id'||wwv_flow.LF||
'           and i.id = p_object_id'||wwv_flow.LF||
'           and i.id = c.initiat';
wwv_flow_imp.g_varchar2_table(609) := 'ive_id'||wwv_flow.LF||
'           and p_scope = ''INITIATIVE'''||wwv_flow.LF||
'        union'||wwv_flow.LF||
'        select f.development_owner_id tm_';
wwv_flow_imp.g_varchar2_table(610) := 'id'||wwv_flow.LF||
'          from sp_areas a, sp_initiatives i,'||wwv_flow.LF||
'               sp_initiative_focus_areas f'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(611) := 'where a.id = i.area_id'||wwv_flow.LF||
'           and i.id = p_object_id'||wwv_flow.LF||
'           and i.id = f.initiative_id'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(612) := '      and f.development_owner_id is not null'||wwv_flow.LF||
'           and p_scope = ''INITIATIVE'''||wwv_flow.LF||
'        union all';
wwv_flow_imp.g_varchar2_table(613) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'        select f.development_owner_id tm_id'||wwv_flow.LF||
'          from sp_initiatives i,'||wwv_flow.LF||
'               sp_ini';
wwv_flow_imp.g_varchar2_table(614) := 'tiative_focus_areas f'||wwv_flow.LF||
'         where i.id = f.initiative_id'||wwv_flow.LF||
'           and f.id = p_object_id'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(615) := '     and f.development_owner_id is not null'||wwv_flow.LF||
'           and p_scope = ''FOCUS_AREA'''||wwv_flow.LF||
'        union'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(616) := '    select i.sponsor_id tm_id'||wwv_flow.LF||
'          from sp_initiatives i,'||wwv_flow.LF||
'               sp_initiative_focus_ar';
wwv_flow_imp.g_varchar2_table(617) := 'eas f'||wwv_flow.LF||
'         where i.id = f.initiative_id'||wwv_flow.LF||
'           and f.id = p_object_id'||wwv_flow.LF||
'           and i.spons';
wwv_flow_imp.g_varchar2_table(618) := 'or_id is not null'||wwv_flow.LF||
'           and p_scope = ''FOCUS_AREA'''||wwv_flow.LF||
'        union'||wwv_flow.LF||
'        select p.owner_id tm_i';
wwv_flow_imp.g_varchar2_table(619) := 'd'||wwv_flow.LF||
'          from sp_initiative_focus_areas f,'||wwv_flow.LF||
'               sp_projects p'||wwv_flow.LF||
'         where f.id = p.f';
wwv_flow_imp.g_varchar2_table(620) := 'ocus_area_id'||wwv_flow.LF||
'           and f.id = p_object_id'||wwv_flow.LF||
'           and p.owner_id is not null'||wwv_flow.LF||
'           and ';
wwv_flow_imp.g_varchar2_table(621) := 'p_scope = ''FOCUS_AREA'''||wwv_flow.LF||
'        )'||wwv_flow.LF||
'        select tm.first_name||'' ''||tm.last_name name,'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(622) := '  tm.email,'||wwv_flow.LF||
'               tm.screen_name,'||wwv_flow.LF||
'               case when tm.photo is not null'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(623) := '         then apex_page.get_url ('||wwv_flow.LF||
'                             p_page   => 160,'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(624) := '         p_items  => ''P160_TM_ID'','||wwv_flow.LF||
'                             p_values => tm.id )'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(625) := '    end photo_url,'||wwv_flow.LF||
'               instr(tm.screen_name,c_search) screen_name_instr,'||wwv_flow.LF||
'               i';
wwv_flow_imp.g_varchar2_table(626) := 'nstr(tm.email,c_search) email_instr, '||wwv_flow.LF||
'               instr(lower(tm.first_name||'' ''||tm.last_name),c';
wwv_flow_imp.g_varchar2_table(627) := '_search) name_instr,'||wwv_flow.LF||
'               case when au.tm_id is not null then 1 else 2 end rank'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(628) := 'from sp_team_members tm,'||wwv_flow.LF||
'               assoc_users au'||wwv_flow.LF||
'         where tm.is_current_yn = ''Y'''||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(629) := '    and tm.id = au.tm_id (+)'||wwv_flow.LF||
'           and tm.screen_name is not null'||wwv_flow.LF||
'           -- restrict mentio';
wwv_flow_imp.g_varchar2_table(630) := 'ns to associated users when only a few chars provided'||wwv_flow.LF||
'           and tm.id = case when c_search_leng';
wwv_flow_imp.g_varchar2_table(631) := 'th <=2 then au.tm_id else tm.id end'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'     where screen_name_instr > 0'||wwv_flow.LF||
'        or email_instr > ';
wwv_flow_imp.g_varchar2_table(632) := '0 '||wwv_flow.LF||
'        or name_instr > 0'||wwv_flow.LF||
'     order by rank, '||wwv_flow.LF||
'              nullif(screen_name_instr,0) nulls la';
wwv_flow_imp.g_varchar2_table(633) := 'st, '||wwv_flow.LF||
'              nullif(email_instr,0) nulls last, '||wwv_flow.LF||
'              nullif(name_instr,0) nulls last,';
wwv_flow_imp.g_varchar2_table(634) := ''||wwv_flow.LF||
'              email'||wwv_flow.LF||
'    ) where rownum <= c_rows_returned;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_return;'||wwv_flow.LF||
''||wwv_flow.LF||
'end get_mentions;';
wwv_flow_imp.g_varchar2_table(635) := ''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_doc_links ('||wwv_flow.LF||
'    p_search           in  varchar2,'||wwv_flow.LF||
'    p_scope            in  varchar2';
wwv_flow_imp.g_varchar2_table(636) := ', -- PROJECT, TASK, RELEASE, INITIATIVE, FOCUS_AREA,'||wwv_flow.LF||
'    p_object_id        in  number'||wwv_flow.LF||
') return clob';
wwv_flow_imp.g_varchar2_table(637) := ''||wwv_flow.LF||
'as'||wwv_flow.LF||
'    c_json_docs_key  constant varchar2(10)   := ''docs'';'||wwv_flow.LF||
'    c_search         constant varchar2(1';
wwv_flow_imp.g_varchar2_table(638) := '000) := lower(p_search);'||wwv_flow.LF||
'    c_search_length  constant number         := nvl(length(c_search),0);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(639) := '  c_rows_returned  constant number         := 20;'||wwv_flow.LF||
'    l_return         clob;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    select'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(640) := '   json_object('||wwv_flow.LF||
'                c_json_docs_key value json_arrayagg('||wwv_flow.LF||
'                    json_object';
wwv_flow_imp.g_varchar2_table(641) := '('||wwv_flow.LF||
'                        ''id''          value ''~'' || filename, -- Must start with ''~'' and be called ';
wwv_flow_imp.g_varchar2_table(642) := 'id'||wwv_flow.LF||
'                        ''filename''    value filename,'||wwv_flow.LF||
'                        ''addedby''     value';
wwv_flow_imp.g_varchar2_table(643) := ' addedby,'||wwv_flow.LF||
'                        ''addedon''     value addedon,'||wwv_flow.LF||
'                        ''url''        ';
wwv_flow_imp.g_varchar2_table(644) := ' value doclink'||wwv_flow.LF||
'                    )'||wwv_flow.LF||
'                    returning clob'||wwv_flow.LF||
'                )'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(645) := '      returning clob'||wwv_flow.LF||
'        )'||wwv_flow.LF||
'    into l_return'||wwv_flow.LF||
'    from '||wwv_flow.LF||
'    ('||wwv_flow.LF||
'    select document_id,'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(646) := 'apex_escape.html(document_filename) filename,'||wwv_flow.LF||
'           case when (p_scope = ''PROJECT'' and doc_type';
wwv_flow_imp.g_varchar2_table(647) := ' = ''Task'') or'||wwv_flow.LF||
'                     (p_scope = ''INITIATIVE'' and doc_type = ''Initiative Focus Area'')'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(648) := '               then ''(''||name||'') '''||wwv_flow.LF||
'                when (p_scope = ''TASK'' and doc_type = ''Project'')';
wwv_flow_imp.g_varchar2_table(649) := ' or'||wwv_flow.LF||
'                     (p_scope = ''FOCUS_AREA'' and doc_type = ''Initiative'')'||wwv_flow.LF||
'                then ''';
wwv_flow_imp.g_varchar2_table(650) := '(''||doc_type||'') '''||wwv_flow.LF||
'                end || lower(added_by) addedby,'||wwv_flow.LF||
'           apex_util.get_since(cr';
wwv_flow_imp.g_varchar2_table(651) := 'eated) addedon,'||wwv_flow.LF||
'           case when doc_type = ''Project'''||wwv_flow.LF||
'                then apex_page.get_url ('||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(652) := '                        p_page   => ''30'','||wwv_flow.LF||
'                         p_items  => ''P30_ID'','||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(653) := '              p_values => document_id,'||wwv_flow.LF||
'                         p_clear_cache => ''30'','||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(654) := '            p_plain_url => true ) '||wwv_flow.LF||
'                when doc_type = ''Task'''||wwv_flow.LF||
'                then apex_';
wwv_flow_imp.g_varchar2_table(655) := 'page.get_url ('||wwv_flow.LF||
'                         p_page   => ''505'','||wwv_flow.LF||
'                         p_items  => ''P50';
wwv_flow_imp.g_varchar2_table(656) := '5_ID'','||wwv_flow.LF||
'                         p_values => document_id,'||wwv_flow.LF||
'                         p_clear_cache => ''';
wwv_flow_imp.g_varchar2_table(657) := '505'','||wwv_flow.LF||
'                         p_plain_url => true ) '||wwv_flow.LF||
'                when doc_type = ''Release'''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(658) := '            then apex_page.get_url ('||wwv_flow.LF||
'                         p_page   => ''42'','||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(659) := '     p_items  => ''P42_ID'','||wwv_flow.LF||
'                         p_values => document_id,'||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(660) := '  p_clear_cache => ''42'','||wwv_flow.LF||
'                         p_plain_url => true )  '||wwv_flow.LF||
'                when doc_t';
wwv_flow_imp.g_varchar2_table(661) := 'ype = ''Initiative'''||wwv_flow.LF||
'                then apex_page.get_url ('||wwv_flow.LF||
'                         p_page   => ''53';
wwv_flow_imp.g_varchar2_table(662) := ''','||wwv_flow.LF||
'                         p_items  => ''P53_ID'','||wwv_flow.LF||
'                         p_values => document_id,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(663) := '                         p_clear_cache => ''53'','||wwv_flow.LF||
'                         p_plain_url => true )  '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(664) := '             when doc_type = ''Initiative Focus Area'''||wwv_flow.LF||
'                then apex_page.get_url ('||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(665) := '                   p_page   => ''59'','||wwv_flow.LF||
'                         p_items  => ''P59_ID'','||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(666) := '         p_values => document_id,'||wwv_flow.LF||
'                         p_clear_cache => ''59'','||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(667) := '       p_plain_url => true )  '||wwv_flow.LF||
'           end doclink'||wwv_flow.LF||
'      from SP_DOCUMENTS_V'||wwv_flow.LF||
'     where ( (p_scop';
wwv_flow_imp.g_varchar2_table(668) := 'e = ''PROJECT'' and project_id = p_object_id) or'||wwv_flow.LF||
'             (p_scope = ''TASK'' and '||wwv_flow.LF||
'              (ta';
wwv_flow_imp.g_varchar2_table(669) := 'sk_id = p_object_id or '||wwv_flow.LF||
'               (task_id is null and project_id in (select project_id from sp';
wwv_flow_imp.g_varchar2_table(670) := '_tasks where id = p_object_id)))) or'||wwv_flow.LF||
'             (p_scope = ''RELEASE'' and release_id = p_object_id)';
wwv_flow_imp.g_varchar2_table(671) := ' or'||wwv_flow.LF||
'             (p_scope = ''INITIATIVE'' and initiative_id = p_object_id) or'||wwv_flow.LF||
'             (p_scope =';
wwv_flow_imp.g_varchar2_table(672) := ' ''FOCUS_AREA'' and '||wwv_flow.LF||
'              (initiative_focus_area_id = p_object_id or '||wwv_flow.LF||
'               (initiat';
wwv_flow_imp.g_varchar2_table(673) := 'ive_focus_area_id is null and initiative_id in (select initiative_id from sp_initiative_focus_areas ';
wwv_flow_imp.g_varchar2_table(674) := 'where id = p_object_id)))) )'||wwv_flow.LF||
'       and ( (doc_type in (''Project'',''Task'') and p_scope in (''PROJECT'',';
wwv_flow_imp.g_varchar2_table(675) := '''TASK'')) or'||wwv_flow.LF||
'             (doc_type in (''Initiative'',''Initiative Focus Area'') and p_scope in (''INITIA';
wwv_flow_imp.g_varchar2_table(676) := 'TIVE'',''FOCUS_AREA'')) or'||wwv_flow.LF||
'             upper(doc_type) = p_scope ) -- RELEASE'||wwv_flow.LF||
'       and ( instr(lower';
wwv_flow_imp.g_varchar2_table(677) := '(document_filename),c_search) > 0 or'||wwv_flow.LF||
'             instr(lower(added_by),c_search) > 0 or'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(678) := '  c_search is null)'||wwv_flow.LF||
'     order by document_filename nulls last, created desc'||wwv_flow.LF||
'    ) where rownum <= c';
wwv_flow_imp.g_varchar2_table(679) := '_rows_returned;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return nvl(l_return,''[]'');'||wwv_flow.LF||
''||wwv_flow.LF||
'end get_doc_links;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_comment_util;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(22990085173248580272)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_comment_util body'
,p_sequence=>7070
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
