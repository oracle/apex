prompt --application/deployment/install/install_sample_data_cust_hub_1_0
begin
--   Manifest
--     INSTALL: INSTALL-sample data - cust hub 1.0
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'sp_globals.g_audit_this := FALSE;'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_projects'||wwv_flow.LF||
'  (id, initiative_id, project, own';
wwv_flow_imp.g_varchar2_table(2) := 'er_id, active_yn, priority_id, release_id,'||wwv_flow.LF||
'   target_complete, pct_complete, status_id, project_size';
wwv_flow_imp.g_varchar2_table(3) := ', status_scale,'||wwv_flow.LF||
'   description, tags, focus_area_id, created, created_by, updated, updated_by)'||wwv_flow.LF||
'value';
wwv_flow_imp.g_varchar2_table(4) := 's'||wwv_flow.LF||
'  (1001, 1, ''Customer Hub Account Overview'', 1, ''N'', 2, 1,'||wwv_flow.LF||
'   sp_util.fix_demo_dates(sysdate - 12)';
wwv_flow_imp.g_varchar2_table(5) := ', 100, 1, ''L'', ''A'','||wwv_flow.LF||
'   ''Delivered a consolidated account dashboard with balances, service alerts, an';
wwv_flow_imp.g_varchar2_table(6) := 'd recent activity.'','||wwv_flow.LF||
'   ''customer-hub,portal,account-dashboard'', 1, sp_util.fix_demo_dates(sysdate -';
wwv_flow_imp.g_varchar2_table(7) := ' 100), ''SCOTT.TIGER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''SCOTT.TIGER@ACME.COM'');'||wwv_flow.LF||
''||wwv_flow.LF||
'inser';
wwv_flow_imp.g_varchar2_table(8) := 't into sp_projects (id, initiative_id, project, owner_id, active_yn, priority_id, release_id, target';
wwv_flow_imp.g_varchar2_table(9) := '_complete, pct_complete, status_id, project_size, status_scale, description, tags, focus_area_id, cr';
wwv_flow_imp.g_varchar2_table(10) := 'eated, created_by, updated, updated_by) values'||wwv_flow.LF||
'  (1002, 1, ''Customer Hub Service Request Intake'', 3,';
wwv_flow_imp.g_varchar2_table(11) := ' ''N'', 2, 1,'||wwv_flow.LF||
'   sp_util.fix_demo_dates(sysdate - 11), 100, 1, ''L'', ''A'','||wwv_flow.LF||
'   ''Delivered guided service-';
wwv_flow_imp.g_varchar2_table(12) := 'request intake, attachment validation, and request-status visibility.'','||wwv_flow.LF||
'   ''customer-hub,service-req';
wwv_flow_imp.g_varchar2_table(13) := 'uests,workflow'', 2, sp_util.fix_demo_dates(sysdate - 100), ''ELENA.VARGAS@ACME.COM'', sp_util.fix_demo';
wwv_flow_imp.g_varchar2_table(14) := '_dates(sysdate - 10), ''ELENA.VARGAS@ACME.COM'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_projects (id, initiative_id, project';
wwv_flow_imp.g_varchar2_table(15) := ', owner_id, active_yn, priority_id, release_id, target_complete, pct_complete, status_id, project_si';
wwv_flow_imp.g_varchar2_table(16) := 'ze, status_scale, description, tags, focus_area_id, created, created_by, updated, updated_by) values';
wwv_flow_imp.g_varchar2_table(17) := ''||wwv_flow.LF||
'  (1003, 1, ''Customer Hub Document Center'', 5, ''N'', 3, 1,'||wwv_flow.LF||
'   sp_util.fix_demo_dates(sysdate - 14), ';
wwv_flow_imp.g_varchar2_table(18) := '100, 1, ''M'', ''A'','||wwv_flow.LF||
'   ''Delivered secure customer document access, search, and download auditing.'','||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(19) := ' ''customer-hub,documents,security'', 1, sp_util.fix_demo_dates(sysdate - 100), ''NAOMI.CHEN@ACME.COM'',';
wwv_flow_imp.g_varchar2_table(20) := ' sp_util.fix_demo_dates(sysdate - 10), ''NAOMI.CHEN@ACME.COM'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_projects (id, initiat';
wwv_flow_imp.g_varchar2_table(21) := 'ive_id, project, owner_id, active_yn, priority_id, release_id, target_complete, pct_complete, status';
wwv_flow_imp.g_varchar2_table(22) := '_id, project_size, status_scale, description, tags, focus_area_id, created, created_by, updated, upd';
wwv_flow_imp.g_varchar2_table(23) := 'ated_by) values'||wwv_flow.LF||
'  (1004, 1, ''Customer Hub Billing and Payments'', 7, ''N'', 1, 1,'||wwv_flow.LF||
'   sp_util.fix_demo_d';
wwv_flow_imp.g_varchar2_table(24) := 'ates(sysdate - 10), 100, 1, ''XL'', ''A'','||wwv_flow.LF||
'   ''Delivered invoice viewing, payment initiation, and paymen';
wwv_flow_imp.g_varchar2_table(25) := 't-history integrations.'','||wwv_flow.LF||
'   ''customer-hub,billing,payments'', 1, sp_util.fix_demo_dates(sysdate - 10';
wwv_flow_imp.g_varchar2_table(26) := '0), ''CALEB.FOSTER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''CALEB.FOSTER@ACME.COM'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert';
wwv_flow_imp.g_varchar2_table(27) := ' into sp_projects (id, initiative_id, project, owner_id, active_yn, priority_id, release_id, target_';
wwv_flow_imp.g_varchar2_table(28) := 'complete, pct_complete, status_id, project_size, status_scale, description, tags, focus_area_id, cre';
wwv_flow_imp.g_varchar2_table(29) := 'ated, created_by, updated, updated_by) values'||wwv_flow.LF||
'  (1005, 3, ''Customer Hub AI Support Assistant'', 9, ''N';
wwv_flow_imp.g_varchar2_table(30) := ''', 2, 1,'||wwv_flow.LF||
'   sp_util.fix_demo_dates(sysdate - 13), 100, 1, ''XL'', ''A'','||wwv_flow.LF||
'   ''Delivered an AI-assisted su';
wwv_flow_imp.g_varchar2_table(31) := 'pport experience with knowledge-grounded answers and handoff routing.'','||wwv_flow.LF||
'   ''customer-hub,ai,support''';
wwv_flow_imp.g_varchar2_table(32) := ', 30, sp_util.fix_demo_dates(sysdate - 100), ''ANDRE.COLLINS@ACME.COM'', sp_util.fix_demo_dates(sysdat';
wwv_flow_imp.g_varchar2_table(33) := 'e - 10), ''ANDRE.COLLINS@ACME.COM'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_projects (id, initiative_id, project, owner_id, ';
wwv_flow_imp.g_varchar2_table(34) := 'active_yn, priority_id, release_id, target_complete, pct_complete, status_id, project_size, status_s';
wwv_flow_imp.g_varchar2_table(35) := 'cale, description, tags, focus_area_id, created, created_by, updated, updated_by) values'||wwv_flow.LF||
'  (1006, 1,';
wwv_flow_imp.g_varchar2_table(36) := ' ''Customer Hub Notification Preferences'', 11, ''N'', 3, 1,'||wwv_flow.LF||
'   sp_util.fix_demo_dates(sysdate - 15), 10';
wwv_flow_imp.g_varchar2_table(37) := '0, 1, ''M'', ''A'','||wwv_flow.LF||
'   ''Delivered self-service email and SMS notification preference management.'','||wwv_flow.LF||
'   ''c';
wwv_flow_imp.g_varchar2_table(38) := 'ustomer-hub,notifications,preferences'', 2, sp_util.fix_demo_dates(sysdate - 100), ''VICTOR.RAMIREZ@AC';
wwv_flow_imp.g_varchar2_table(39) := 'ME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''VICTOR.RAMIREZ@ACME.COM'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_projects ';
wwv_flow_imp.g_varchar2_table(40) := '(id, initiative_id, project, owner_id, active_yn, priority_id, release_id, target_complete, pct_comp';
wwv_flow_imp.g_varchar2_table(41) := 'lete, status_id, project_size, status_scale, description, tags, focus_area_id, created, created_by, ';
wwv_flow_imp.g_varchar2_table(42) := 'updated, updated_by) values'||wwv_flow.LF||
'  (1007, 1, ''Customer Hub Identity and Access'', 13, ''N'', 1, 1,'||wwv_flow.LF||
'   sp_uti';
wwv_flow_imp.g_varchar2_table(43) := 'l.fix_demo_dates(sysdate - 10), 100, 1, ''XL'', ''A'','||wwv_flow.LF||
'   ''Delivered single sign-on, multifactor authent';
wwv_flow_imp.g_varchar2_table(44) := 'ication, and delegated account-access controls.'','||wwv_flow.LF||
'   ''customer-hub,identity,security,sso'', 4, sp_uti';
wwv_flow_imp.g_varchar2_table(45) := 'l.fix_demo_dates(sysdate - 100), ''ISAAC.TURNER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''ISA';
wwv_flow_imp.g_varchar2_table(46) := 'AC.TURNER@ACME.COM'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_projects (id, initiative_id, project, owner_id, active_yn, pri';
wwv_flow_imp.g_varchar2_table(47) := 'ority_id, release_id, target_complete, pct_complete, status_id, project_size, status_scale, descript';
wwv_flow_imp.g_varchar2_table(48) := 'ion, tags, focus_area_id, created, created_by, updated, updated_by) values'||wwv_flow.LF||
'  (1008, 1, ''Customer Hub';
wwv_flow_imp.g_varchar2_table(49) := ' Accessibility Foundation'', 15, ''N'', 2, 1,'||wwv_flow.LF||
'   sp_util.fix_demo_dates(sysdate - 16), 100, 1, ''L'', ''A''';
wwv_flow_imp.g_varchar2_table(50) := ','||wwv_flow.LF||
'   ''Delivered reusable accessible UI components and keyboard-navigation support.'','||wwv_flow.LF||
'   ''customer-hu';
wwv_flow_imp.g_varchar2_table(51) := 'b,accessibility,design-system'', 3, sp_util.fix_demo_dates(sysdate - 100), ''DOMINIC.REYES@ACME.COM'', ';
wwv_flow_imp.g_varchar2_table(52) := 'sp_util.fix_demo_dates(sysdate - 10), ''DOMINIC.REYES@ACME.COM'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_projects (id, initi';
wwv_flow_imp.g_varchar2_table(53) := 'ative_id, project, owner_id, active_yn, priority_id, release_id, target_complete, pct_complete, stat';
wwv_flow_imp.g_varchar2_table(54) := 'us_id, project_size, status_scale, description, tags, focus_area_id, created, created_by, updated, u';
wwv_flow_imp.g_varchar2_table(55) := 'pdated_by) values'||wwv_flow.LF||
'  (1009, 1, ''Customer Hub Analytics Instrumentation'', 17, ''N'', 3, 1,'||wwv_flow.LF||
'   sp_util.fi';
wwv_flow_imp.g_varchar2_table(56) := 'x_demo_dates(sysdate - 12), 100, 1, ''M'', ''A'','||wwv_flow.LF||
'   ''Delivered privacy-aware product analytics events, ';
wwv_flow_imp.g_varchar2_table(57) := 'dashboards, and operational monitoring.'','||wwv_flow.LF||
'   ''customer-hub,analytics,observability'', 6, sp_util.fix_';
wwv_flow_imp.g_varchar2_table(58) := 'demo_dates(sysdate - 100), ''ETHAN.CALDWELL@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''ETHAN.C';
wwv_flow_imp.g_varchar2_table(59) := 'ALDWELL@ACME.COM'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_projects (id, initiative_id, project, owner_id, active_yn, prior';
wwv_flow_imp.g_varchar2_table(60) := 'ity_id, release_id, target_complete, pct_complete, status_id, project_size, status_scale, descriptio';
wwv_flow_imp.g_varchar2_table(61) := 'n, tags, focus_area_id, created, created_by, updated, updated_by) values'||wwv_flow.LF||
'  (1010, 1, ''Customer Hub P';
wwv_flow_imp.g_varchar2_table(62) := 'erformance and Resilience'', 19, ''N'', 2, 1,'||wwv_flow.LF||
'   sp_util.fix_demo_dates(sysdate - 10), 100, 1, ''L'', ''A''';
wwv_flow_imp.g_varchar2_table(63) := ','||wwv_flow.LF||
'   ''Delivered performance improvements, load testing, and resilience safeguards for peak customer ';
wwv_flow_imp.g_varchar2_table(64) := 'traffic.'','||wwv_flow.LF||
'   ''customer-hub,performance,resilience,load-testing'', 1, sp_util.fix_demo_dates(sysdate ';
wwv_flow_imp.g_varchar2_table(65) := '- 100), ''LUCAS.BENNETT@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''LUCAS.BENNETT@ACME.COM'');'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(66) := '-- Contributor assignments: project manager, primary delivery role, and a supporting role.'||wwv_flow.LF||
'insert al';
wwv_flow_imp.g_varchar2_table(67) := 'l'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_id, responsibility_id, responsibility,';
wwv_flow_imp.g_varchar2_table(68) := ' tags, created, created_by, updated, updated_by) values (5001, 1001, 1, 3, ''Owns delivery planning a';
wwv_flow_imp.g_varchar2_table(69) := 'nd stakeholder communication.'', ''project-management'', sp_util.fix_demo_dates(sysdate - 100), ''SCOTT.';
wwv_flow_imp.g_varchar2_table(70) := 'TIGER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 35), ''SCOTT.TIGER@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_con';
wwv_flow_imp.g_varchar2_table(71) := 'tributors (id, project_id, team_member_id, responsibility_id, responsibility, tags, created, created';
wwv_flow_imp.g_varchar2_table(72) := '_by, updated, updated_by) values (5002, 1001, 2, 1, ''Builds account overview UI and supporting servi';
wwv_flow_imp.g_varchar2_table(73) := 'ces.'', ''frontend,backend'', sp_util.fix_demo_dates(sysdate - 100), ''SCOTT.TIGER@ACME.COM'', sp_util.fi';
wwv_flow_imp.g_varchar2_table(74) := 'x_demo_dates(sysdate - 35), ''SCOTT.TIGER@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, ';
wwv_flow_imp.g_varchar2_table(75) := 'team_member_id, responsibility_id, responsibility, tags, created, created_by, updated, updated_by) v';
wwv_flow_imp.g_varchar2_table(76) := 'alues (5003, 1001, 8, 8, ''Designs account summary information architecture.'', ''ux,design'', sp_util.f';
wwv_flow_imp.g_varchar2_table(77) := 'ix_demo_dates(sysdate - 100), ''SCOTT.TIGER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 35), ''SCOTT.T';
wwv_flow_imp.g_varchar2_table(78) := 'IGER@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_id, responsibility_id, r';
wwv_flow_imp.g_varchar2_table(79) := 'esponsibility, tags, created, created_by, updated, updated_by) values (5004, 1002, 3, 3, ''Owns deliv';
wwv_flow_imp.g_varchar2_table(80) := 'ery planning and operations alignment.'', ''project-management'', sp_util.fix_demo_dates(sysdate - 100)';
wwv_flow_imp.g_varchar2_table(81) := ', ''ELENA.VARGAS@ACME.COM'', sp_util.fix_demo_dates(sysdate - 35), ''ELENA.VARGAS@ACME.COM'')'||wwv_flow.LF||
'  into sp_';
wwv_flow_imp.g_varchar2_table(82) := 'project_contributors (id, project_id, team_member_id, responsibility_id, responsibility, tags, creat';
wwv_flow_imp.g_varchar2_table(83) := 'ed, created_by, updated, updated_by) values (5005, 1002, 4, 1, ''Builds guided request intake and rou';
wwv_flow_imp.g_varchar2_table(84) := 'ting integration.'', ''workflow,backend'', sp_util.fix_demo_dates(sysdate - 100), ''ELENA.VARGAS@ACME.CO';
wwv_flow_imp.g_varchar2_table(85) := 'M'', sp_util.fix_demo_dates(sysdate - 35), ''ELENA.VARGAS@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (i';
wwv_flow_imp.g_varchar2_table(86) := 'd, project_id, team_member_id, responsibility_id, responsibility, tags, created, created_by, updated';
wwv_flow_imp.g_varchar2_table(87) := ', updated_by) values (5006, 1002, 6, 5, ''Validates request flows and regression coverage.'', ''qa,func';
wwv_flow_imp.g_varchar2_table(88) := 'tional-testing'', sp_util.fix_demo_dates(sysdate - 100), ''ELENA.VARGAS@ACME.COM'', sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(89) := 'tes(sysdate - 35), ''ELENA.VARGAS@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_mem';
wwv_flow_imp.g_varchar2_table(90) := 'ber_id, responsibility_id, responsibility, tags, created, created_by, updated, updated_by) values (5';
wwv_flow_imp.g_varchar2_table(91) := '007, 1003, 5, 3, ''Owns document-center delivery and compliance coordination.'', ''project-management'',';
wwv_flow_imp.g_varchar2_table(92) := ' sp_util.fix_demo_dates(sysdate - 100), ''NAOMI.CHEN@ACME.COM'', sp_util.fix_demo_dates(sysdate - 35),';
wwv_flow_imp.g_varchar2_table(93) := ' ''NAOMI.CHEN@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_id, responsibili';
wwv_flow_imp.g_varchar2_table(94) := 'ty_id, responsibility, tags, created, created_by, updated, updated_by) values (5008, 1003, 6, 1, ''Bu';
wwv_flow_imp.g_varchar2_table(95) := 'ilds secure document search and download capabilities.'', ''search,security'', sp_util.fix_demo_dates(s';
wwv_flow_imp.g_varchar2_table(96) := 'ysdate - 100), ''NAOMI.CHEN@ACME.COM'', sp_util.fix_demo_dates(sysdate - 35), ''NAOMI.CHEN@ACME.COM'')'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(97) := ' into sp_project_contributors (id, project_id, team_member_id, responsibility_id, responsibility, ta';
wwv_flow_imp.g_varchar2_table(98) := 'gs, created, created_by, updated, updated_by) values (5009, 1003, 8, 8, ''Designs document browsing a';
wwv_flow_imp.g_varchar2_table(99) := 'nd search interactions.'', ''ux,design'', sp_util.fix_demo_dates(sysdate - 100), ''NAOMI.CHEN@ACME.COM'',';
wwv_flow_imp.g_varchar2_table(100) := ' sp_util.fix_demo_dates(sysdate - 35), ''NAOMI.CHEN@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, pr';
wwv_flow_imp.g_varchar2_table(101) := 'oject_id, team_member_id, responsibility_id, responsibility, tags, created, created_by, updated, upd';
wwv_flow_imp.g_varchar2_table(102) := 'ated_by) values (5010, 1004, 7, 3, ''Owns billing and payment release coordination.'', ''project-manage';
wwv_flow_imp.g_varchar2_table(103) := 'ment'', sp_util.fix_demo_dates(sysdate - 100), ''CALEB.FOSTER@ACME.COM'', sp_util.fix_demo_dates(sysdat';
wwv_flow_imp.g_varchar2_table(104) := 'e - 35), ''CALEB.FOSTER@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_id, re';
wwv_flow_imp.g_varchar2_table(105) := 'sponsibility_id, responsibility, tags, created, created_by, updated, updated_by) values (5011, 1004,';
wwv_flow_imp.g_varchar2_table(106) := ' 8, 1, ''Builds billing and payment-processor integrations.'', ''payments,integration'', sp_util.fix_dem';
wwv_flow_imp.g_varchar2_table(107) := 'o_dates(sysdate - 100), ''CALEB.FOSTER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 35), ''CALEB.FOSTER';
wwv_flow_imp.g_varchar2_table(108) := '@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_id, responsibility_id, respo';
wwv_flow_imp.g_varchar2_table(109) := 'nsibility, tags, created, created_by, updated, updated_by) values (5012, 1004, 10, 5, ''Validates pay';
wwv_flow_imp.g_varchar2_table(110) := 'ment and invoice acceptance paths.'', ''qa,functional-testing'', sp_util.fix_demo_dates(sysdate - 100),';
wwv_flow_imp.g_varchar2_table(111) := ' ''CALEB.FOSTER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 35), ''CALEB.FOSTER@ACME.COM'')'||wwv_flow.LF||
'  into sp_p';
wwv_flow_imp.g_varchar2_table(112) := 'roject_contributors (id, project_id, team_member_id, responsibility_id, responsibility, tags, create';
wwv_flow_imp.g_varchar2_table(113) := 'd, created_by, updated, updated_by) values (5013, 1005, 9, 3, ''Owns AI assistant delivery and suppor';
wwv_flow_imp.g_varchar2_table(114) := 't partnership.'', ''project-management,ai'', sp_util.fix_demo_dates(sysdate - 100), ''ANDRE.COLLINS@ACME';
wwv_flow_imp.g_varchar2_table(115) := '.COM'', sp_util.fix_demo_dates(sysdate - 35), ''ANDRE.COLLINS@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributor';
wwv_flow_imp.g_varchar2_table(116) := 's (id, project_id, team_member_id, responsibility_id, responsibility, tags, created, created_by, upd';
wwv_flow_imp.g_varchar2_table(117) := 'ated, updated_by) values (5014, 1005, 10, 1, ''Builds assistant orchestration and support handoff.'', ';
wwv_flow_imp.g_varchar2_table(118) := '''ai,backend'', sp_util.fix_demo_dates(sysdate - 100), ''ANDRE.COLLINS@ACME.COM'', sp_util.fix_demo_date';
wwv_flow_imp.g_varchar2_table(119) := 's(sysdate - 35), ''ANDRE.COLLINS@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_memb';
wwv_flow_imp.g_varchar2_table(120) := 'er_id, responsibility_id, responsibility, tags, created, created_by, updated, updated_by) values (50';
wwv_flow_imp.g_varchar2_table(121) := '15, 1005, 12, 7, ''Evaluates answer quality and knowledge coverage.'', ''research,ai-quality'', sp_util.';
wwv_flow_imp.g_varchar2_table(122) := 'fix_demo_dates(sysdate - 100), ''ANDRE.COLLINS@ACME.COM'', sp_util.fix_demo_dates(sysdate - 35), ''ANDR';
wwv_flow_imp.g_varchar2_table(123) := 'E.COLLINS@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_id, responsibility_';
wwv_flow_imp.g_varchar2_table(124) := 'id, responsibility, tags, created, created_by, updated, updated_by) values (5016, 1006, 11, 3, ''Owns';
wwv_flow_imp.g_varchar2_table(125) := ' notification preference delivery.'', ''project-management'', sp_util.fix_demo_dates(sysdate - 100), ''V';
wwv_flow_imp.g_varchar2_table(126) := 'ICTOR.RAMIREZ@ACME.COM'', sp_util.fix_demo_dates(sysdate - 35), ''VICTOR.RAMIREZ@ACME.COM'')'||wwv_flow.LF||
'  into sp_';
wwv_flow_imp.g_varchar2_table(127) := 'project_contributors (id, project_id, team_member_id, responsibility_id, responsibility, tags, creat';
wwv_flow_imp.g_varchar2_table(128) := 'ed, created_by, updated, updated_by) values (5017, 1006, 12, 1, ''Builds preference center and consen';
wwv_flow_imp.g_varchar2_table(129) := 't workflows.'', ''notifications,backend'', sp_util.fix_demo_dates(sysdate - 100), ''VICTOR.RAMIREZ@ACME.';
wwv_flow_imp.g_varchar2_table(130) := 'COM'', sp_util.fix_demo_dates(sysdate - 35), ''VICTOR.RAMIREZ@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributor';
wwv_flow_imp.g_varchar2_table(131) := 's (id, project_id, team_member_id, responsibility_id, responsibility, tags, created, created_by, upd';
wwv_flow_imp.g_varchar2_table(132) := 'ated, updated_by) values (5018, 1006, 14, 8, ''Designs preference controls and consent interactions.''';
wwv_flow_imp.g_varchar2_table(133) := ', ''ux,design'', sp_util.fix_demo_dates(sysdate - 100), ''VICTOR.RAMIREZ@ACME.COM'', sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(134) := 'tes(sysdate - 35), ''VICTOR.RAMIREZ@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_m';
wwv_flow_imp.g_varchar2_table(135) := 'ember_id, responsibility_id, responsibility, tags, created, created_by, updated, updated_by) values ';
wwv_flow_imp.g_varchar2_table(136) := '(5019, 1007, 13, 3, ''Owns identity and access release delivery.'', ''project-management,security'', sp_';
wwv_flow_imp.g_varchar2_table(137) := 'util.fix_demo_dates(sysdate - 100), ''ISAAC.TURNER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 35), ''';
wwv_flow_imp.g_varchar2_table(138) := 'ISAAC.TURNER@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_id, responsibili';
wwv_flow_imp.g_varchar2_table(139) := 'ty_id, responsibility, tags, created, created_by, updated, updated_by) values (5020, 1007, 14, 1, ''B';
wwv_flow_imp.g_varchar2_table(140) := 'uilds SSO, MFA, and delegated access controls.'', ''identity,security'', sp_util.fix_demo_dates(sysdate';
wwv_flow_imp.g_varchar2_table(141) := ' - 100), ''ISAAC.TURNER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 35), ''ISAAC.TURNER@ACME.COM'')'||wwv_flow.LF||
'  i';
wwv_flow_imp.g_varchar2_table(142) := 'nto sp_project_contributors (id, project_id, team_member_id, responsibility_id, responsibility, tags';
wwv_flow_imp.g_varchar2_table(143) := ', created, created_by, updated, updated_by) values (5021, 1007, 16, 2, ''Reviews authentication archi';
wwv_flow_imp.g_varchar2_table(144) := 'tecture and threat controls.'', ''architecture,security'', sp_util.fix_demo_dates(sysdate - 100), ''ISAA';
wwv_flow_imp.g_varchar2_table(145) := 'C.TURNER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 35), ''ISAAC.TURNER@ACME.COM'')'||wwv_flow.LF||
'  into sp_project';
wwv_flow_imp.g_varchar2_table(146) := '_contributors (id, project_id, team_member_id, responsibility_id, responsibility, tags, created, cre';
wwv_flow_imp.g_varchar2_table(147) := 'ated_by, updated, updated_by) values (5022, 1008, 15, 3, ''Owns accessibility foundation delivery.'', ';
wwv_flow_imp.g_varchar2_table(148) := '''project-management,accessibility'', sp_util.fix_demo_dates(sysdate - 100), ''DOMINIC.REYES@ACME.COM'',';
wwv_flow_imp.g_varchar2_table(149) := ' sp_util.fix_demo_dates(sysdate - 35), ''DOMINIC.REYES@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id,';
wwv_flow_imp.g_varchar2_table(150) := ' project_id, team_member_id, responsibility_id, responsibility, tags, created, created_by, updated, ';
wwv_flow_imp.g_varchar2_table(151) := 'updated_by) values (5023, 1008, 16, 1, ''Builds reusable accessible component behavior.'', ''frontend,a';
wwv_flow_imp.g_varchar2_table(152) := 'ccessibility'', sp_util.fix_demo_dates(sysdate - 100), ''DOMINIC.REYES@ACME.COM'', sp_util.fix_demo_dat';
wwv_flow_imp.g_varchar2_table(153) := 'es(sysdate - 35), ''DOMINIC.REYES@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_mem';
wwv_flow_imp.g_varchar2_table(154) := 'ber_id, responsibility_id, responsibility, tags, created, created_by, updated, updated_by) values (5';
wwv_flow_imp.g_varchar2_table(155) := '024, 1008, 18, 5, ''Validates accessibility and keyboard-navigation coverage.'', ''qa,accessibility'', s';
wwv_flow_imp.g_varchar2_table(156) := 'p_util.fix_demo_dates(sysdate - 100), ''DOMINIC.REYES@ACME.COM'', sp_util.fix_demo_dates(sysdate - 35)';
wwv_flow_imp.g_varchar2_table(157) := ', ''DOMINIC.REYES@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_id, responsi';
wwv_flow_imp.g_varchar2_table(158) := 'bility_id, responsibility, tags, created, created_by, updated, updated_by) values (5025, 1009, 17, 3';
wwv_flow_imp.g_varchar2_table(159) := ', ''Owns analytics instrumentation delivery.'', ''project-management,analytics'', sp_util.fix_demo_dates';
wwv_flow_imp.g_varchar2_table(160) := '(sysdate - 100), ''ETHAN.CALDWELL@ACME.COM'', sp_util.fix_demo_dates(sysdate - 35), ''ETHAN.CALDWELL@AC';
wwv_flow_imp.g_varchar2_table(161) := 'ME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_id, responsibility_id, responsi';
wwv_flow_imp.g_varchar2_table(162) := 'bility, tags, created, created_by, updated, updated_by) values (5026, 1009, 18, 1, ''Builds event col';
wwv_flow_imp.g_varchar2_table(163) := 'lection and reporting integration.'', ''analytics,backend'', sp_util.fix_demo_dates(sysdate - 100), ''ET';
wwv_flow_imp.g_varchar2_table(164) := 'HAN.CALDWELL@ACME.COM'', sp_util.fix_demo_dates(sysdate - 35), ''ETHAN.CALDWELL@ACME.COM'')'||wwv_flow.LF||
'  into sp_p';
wwv_flow_imp.g_varchar2_table(165) := 'roject_contributors (id, project_id, team_member_id, responsibility_id, responsibility, tags, create';
wwv_flow_imp.g_varchar2_table(166) := 'd, created_by, updated, updated_by) values (5027, 1009, 20, 7, ''Defines analytics taxonomy and repor';
wwv_flow_imp.g_varchar2_table(167) := 'ting questions.'', ''research,analytics'', sp_util.fix_demo_dates(sysdate - 100), ''ETHAN.CALDWELL@ACME.';
wwv_flow_imp.g_varchar2_table(168) := 'COM'', sp_util.fix_demo_dates(sysdate - 35), ''ETHAN.CALDWELL@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributor';
wwv_flow_imp.g_varchar2_table(169) := 's (id, project_id, team_member_id, responsibility_id, responsibility, tags, created, created_by, upd';
wwv_flow_imp.g_varchar2_table(170) := 'ated, updated_by) values (5028, 1010, 19, 3, ''Owns performance and resilience delivery.'', ''project-m';
wwv_flow_imp.g_varchar2_table(171) := 'anagement,reliability'', sp_util.fix_demo_dates(sysdate - 100), ''LUCAS.BENNETT@ACME.COM'', sp_util.fix';
wwv_flow_imp.g_varchar2_table(172) := '_demo_dates(sysdate - 35), ''LUCAS.BENNETT@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id,';
wwv_flow_imp.g_varchar2_table(173) := ' team_member_id, responsibility_id, responsibility, tags, created, created_by, updated, updated_by) ';
wwv_flow_imp.g_varchar2_table(174) := 'values (5029, 1010, 20, 1, ''Builds performance improvements and resilience controls.'', ''performance,';
wwv_flow_imp.g_varchar2_table(175) := 'backend'', sp_util.fix_demo_dates(sysdate - 100), ''LUCAS.BENNETT@ACME.COM'', sp_util.fix_demo_dates(sy';
wwv_flow_imp.g_varchar2_table(176) := 'sdate - 35), ''LUCAS.BENNETT@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_i';
wwv_flow_imp.g_varchar2_table(177) := 'd, responsibility_id, responsibility, tags, created, created_by, updated, updated_by) values (5030, ';
wwv_flow_imp.g_varchar2_table(178) := '1010, 21, 5, ''Validates load testing and recovery scenarios.'', ''qa,performance'', sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(179) := 'tes(sysdate - 100), ''LUCAS.BENNETT@ACME.COM'', sp_util.fix_demo_dates(sysdate - 35), ''LUCAS.BENNETT@A';
wwv_flow_imp.g_varchar2_table(180) := 'CME.COM'')'||wwv_flow.LF||
'select 1 from dual;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Comments are inserted oldest to newest for each project.'||wwv_flow.LF||
'insert in';
wwv_flow_imp.g_varchar2_table(181) := 'to sp_project_comments (id, project_id, author_id, body, body_html, body_no_images, private_yn, crea';
wwv_flow_imp.g_varchar2_table(182) := 'ted, created_by, updated, updated_by) values (2001, 1001, 1, ''The dashboard scope was reduced to the';
wwv_flow_imp.g_varchar2_table(183) := ' three highest-value account summary cards for the 1.0 release.'', ''The dashboard scope was reduced t';
wwv_flow_imp.g_varchar2_table(184) := 'o the three highest-value account summary cards for the 1.0 release.'', ''The dashboard scope was redu';
wwv_flow_imp.g_varchar2_table(185) := 'ced to the three highest-value account summary cards for the 1.0 release.'', ''N'', sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(186) := 'tes(sysdate -75), ''SCOTT.TIGER@ACME.COM'', sp_util.fix_demo_dates(sysdate -75), ''SCOTT.TIGER@ACME.COM';
wwv_flow_imp.g_varchar2_table(187) := ''');'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id, author_id, body, body_html, body_no_images, pri';
wwv_flow_imp.g_varchar2_table(188) := 'vate_yn, created, created_by, updated, updated_by) values (2002, 1001, 2, ''Pilot feedback confirmed ';
wwv_flow_imp.g_varchar2_table(189) := 'that recent activity should remain above the fold.'', ''Pilot feedback confirmed that recent activity ';
wwv_flow_imp.g_varchar2_table(190) := 'should remain above the fold.'', ''Pilot feedback confirmed that recent activity should remain above t';
wwv_flow_imp.g_varchar2_table(191) := 'he fold.'', ''N'', sp_util.fix_demo_dates(sysdate -32), ''MARCUS.HALE@ACME.COM'', sp_util.fix_demo_dates(';
wwv_flow_imp.g_varchar2_table(192) := 'sysdate -32), ''MARCUS.HALE@ACME.COM'');'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id, author_id, b';
wwv_flow_imp.g_varchar2_table(193) := 'ody, body_html, body_no_images, private_yn, created, created_by, updated, updated_by) values (2003, ';
wwv_flow_imp.g_varchar2_table(194) := '1002, 3, ''We selected guided intake rather than a free-form form to improve data quality and routing';
wwv_flow_imp.g_varchar2_table(195) := '.'', ''We selected guided intake rather than a free-form form to improve data quality and routing.'', ''';
wwv_flow_imp.g_varchar2_table(196) := 'We selected guided intake rather than a free-form form to improve data quality and routing.'', ''N'', s';
wwv_flow_imp.g_varchar2_table(197) := 'p_util.fix_demo_dates(sysdate -75), ''ELENA.VARGAS@ACME.COM'', sp_util.fix_demo_dates(sysdate -75), ''E';
wwv_flow_imp.g_varchar2_table(198) := 'LENA.VARGAS@ACME.COM'');'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id, author_id, body, body_html,';
wwv_flow_imp.g_varchar2_table(199) := ' body_no_images, private_yn, created, created_by, updated, updated_by) values (2004, 1002, 4, ''Opera';
wwv_flow_imp.g_varchar2_table(200) := 'tions approved the required fields and the new status vocabulary.'', ''Operations approved the require';
wwv_flow_imp.g_varchar2_table(201) := 'd fields and the new status vocabulary.'', ''Operations approved the required fields and the new statu';
wwv_flow_imp.g_varchar2_table(202) := 's vocabulary.'', ''N'', sp_util.fix_demo_dates(sysdate -32), ''TYLER.BROOKS@ACME.COM'', sp_util.fix_demo_';
wwv_flow_imp.g_varchar2_table(203) := 'dates(sysdate -32), ''TYLER.BROOKS@ACME.COM'');'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id, autho';
wwv_flow_imp.g_varchar2_table(204) := 'r_id, body, body_html, body_no_images, private_yn, created, created_by, updated, updated_by) values ';
wwv_flow_imp.g_varchar2_table(205) := '(2005, 1003, 5, ''Download audit events are retained for compliance reporting; previews remain out of';
wwv_flow_imp.g_varchar2_table(206) := ' scope for this release.'', ''Download audit events are retained for compliance reporting; previews re';
wwv_flow_imp.g_varchar2_table(207) := 'main out of scope for this release.'', ''Download audit events are retained for compliance reporting; ';
wwv_flow_imp.g_varchar2_table(208) := 'previews remain out of scope for this release.'', ''N'', sp_util.fix_demo_dates(sysdate -75), ''NAOMI.CH';
wwv_flow_imp.g_varchar2_table(209) := 'EN@ACME.COM'', sp_util.fix_demo_dates(sysdate -75), ''NAOMI.CHEN@ACME.COM'');'||wwv_flow.LF||
'insert into sp_project_co';
wwv_flow_imp.g_varchar2_table(210) := 'mments (id, project_id, author_id, body, body_html, body_no_images, private_yn, created, created_by,';
wwv_flow_imp.g_varchar2_table(211) := ' updated, updated_by) values (2006, 1003, 6, ''The pilot group reported that document categories make';
wwv_flow_imp.g_varchar2_table(212) := ' the new search much easier to use.'', ''The pilot group reported that document categories make the ne';
wwv_flow_imp.g_varchar2_table(213) := 'w search much easier to use.'', ''The pilot group reported that document categories make the new searc';
wwv_flow_imp.g_varchar2_table(214) := 'h much easier to use.'', ''N'', sp_util.fix_demo_dates(sysdate -32), ''JORDAN.AVERY@ACME.COM'', sp_util.f';
wwv_flow_imp.g_varchar2_table(215) := 'ix_demo_dates(sysdate -32), ''JORDAN.AVERY@ACME.COM'');'||wwv_flow.LF||
'insert into sp_project_comments (id, project_i';
wwv_flow_imp.g_varchar2_table(216) := 'd, author_id, body, body_html, body_no_images, private_yn, created, created_by, updated, updated_by)';
wwv_flow_imp.g_varchar2_table(217) := ' values (2007, 1004, 7, ''Payment initiation will redirect to the existing payment processor to keep ';
wwv_flow_imp.g_varchar2_table(218) := 'PCI scope unchanged.'', ''Payment initiation will redirect to the existing payment processor to keep P';
wwv_flow_imp.g_varchar2_table(219) := 'CI scope unchanged.'', ''Payment initiation will redirect to the existing payment processor to keep PC';
wwv_flow_imp.g_varchar2_table(220) := 'I scope unchanged.'', ''N'', sp_util.fix_demo_dates(sysdate -75), ''CALEB.FOSTER@ACME.COM'', sp_util.fix_';
wwv_flow_imp.g_varchar2_table(221) := 'demo_dates(sysdate -75), ''CALEB.FOSTER@ACME.COM'');'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id, ';
wwv_flow_imp.g_varchar2_table(222) := 'author_id, body, body_html, body_no_images, private_yn, created, created_by, updated, updated_by) va';
wwv_flow_imp.g_varchar2_table(223) := 'lues (2008, 1004, 8, ''Finance approved the invoice and payment-history reconciliation approach.'', ''F';
wwv_flow_imp.g_varchar2_table(224) := 'inance approved the invoice and payment-history reconciliation approach.'', ''Finance approved the inv';
wwv_flow_imp.g_varchar2_table(225) := 'oice and payment-history reconciliation approach.'', ''N'', sp_util.fix_demo_dates(sysdate -32), ''LILA.';
wwv_flow_imp.g_varchar2_table(226) := 'MONTGOMERY@ACME.COM'', sp_util.fix_demo_dates(sysdate -32), ''LILA.MONTGOMERY@ACME.COM'');'||wwv_flow.LF||
'insert into ';
wwv_flow_imp.g_varchar2_table(227) := 'sp_project_comments (id, project_id, author_id, body, body_html, body_no_images, private_yn, created';
wwv_flow_imp.g_varchar2_table(228) := ', created_by, updated, updated_by) values (2009, 1005, 9, ''The assistant uses approved support artic';
wwv_flow_imp.g_varchar2_table(229) := 'les only and routes uncertain answers to a human support queue.'', ''The assistant uses approved suppo';
wwv_flow_imp.g_varchar2_table(230) := 'rt articles only and routes uncertain answers to a human support queue.'', ''The assistant uses approv';
wwv_flow_imp.g_varchar2_table(231) := 'ed support articles only and routes uncertain answers to a human support queue.'', ''N'', sp_util.fix_d';
wwv_flow_imp.g_varchar2_table(232) := 'emo_dates(sysdate -75), ''ANDRE.COLLINS@ACME.COM'', sp_util.fix_demo_dates(sysdate -75), ''ANDRE.COLLIN';
wwv_flow_imp.g_varchar2_table(233) := 'S@ACME.COM'');'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id, author_id, body, body_html, body_no_i';
wwv_flow_imp.g_varchar2_table(234) := 'mages, private_yn, created, created_by, updated, updated_by) values (2010, 1005, 10, ''Support leader';
wwv_flow_imp.g_varchar2_table(235) := 'ship accepted the confidence threshold and escalation wording.'', ''Support leadership accepted the co';
wwv_flow_imp.g_varchar2_table(236) := 'nfidence threshold and escalation wording.'', ''Support leadership accepted the confidence threshold a';
wwv_flow_imp.g_varchar2_table(237) := 'nd escalation wording.'', ''N'', sp_util.fix_demo_dates(sysdate -32), ''SOPHIE.BENNETT@ACME.COM'', sp_uti';
wwv_flow_imp.g_varchar2_table(238) := 'l.fix_demo_dates(sysdate -32), ''SOPHIE.BENNETT@ACME.COM'');'||wwv_flow.LF||
'insert into sp_project_comments (id, proj';
wwv_flow_imp.g_varchar2_table(239) := 'ect_id, author_id, body, body_html, body_no_images, private_yn, created, created_by, updated, update';
wwv_flow_imp.g_varchar2_table(240) := 'd_by) values (2011, 1006, 11, ''The team consolidated notification controls into a single preference ';
wwv_flow_imp.g_varchar2_table(241) := 'center.'', ''The team consolidated notification controls into a single preference center.'', ''The team ';
wwv_flow_imp.g_varchar2_table(242) := 'consolidated notification controls into a single preference center.'', ''N'', sp_util.fix_demo_dates(sy';
wwv_flow_imp.g_varchar2_table(243) := 'sdate -75), ''VICTOR.RAMIREZ@ACME.COM'', sp_util.fix_demo_dates(sysdate -75), ''VICTOR.RAMIREZ@ACME.COM';
wwv_flow_imp.g_varchar2_table(244) := ''');'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id, author_id, body, body_html, body_no_images, pri';
wwv_flow_imp.g_varchar2_table(245) := 'vate_yn, created, created_by, updated, updated_by) values (2012, 1006, 12, ''Legal approved the conse';
wwv_flow_imp.g_varchar2_table(246) := 'nt language and SMS opt-in flow.'', ''Legal approved the consent language and SMS opt-in flow.'', ''Lega';
wwv_flow_imp.g_varchar2_table(247) := 'l approved the consent language and SMS opt-in flow.'', ''N'', sp_util.fix_demo_dates(sysdate -32), ''HA';
wwv_flow_imp.g_varchar2_table(248) := 'NNAH.DOYLE@ACME.COM'', sp_util.fix_demo_dates(sysdate -32), ''HANNAH.DOYLE@ACME.COM'');'||wwv_flow.LF||
'insert into sp_';
wwv_flow_imp.g_varchar2_table(249) := 'project_comments (id, project_id, author_id, body, body_html, body_no_images, private_yn, created, c';
wwv_flow_imp.g_varchar2_table(250) := 'reated_by, updated, updated_by) values (2013, 1007, 13, ''MFA enrollment was made progressive to avoi';
wwv_flow_imp.g_varchar2_table(251) := 'd disrupting existing customers on first sign-in.'', ''MFA enrollment was made progressive to avoid di';
wwv_flow_imp.g_varchar2_table(252) := 'srupting existing customers on first sign-in.'', ''MFA enrollment was made progressive to avoid disrup';
wwv_flow_imp.g_varchar2_table(253) := 'ting existing customers on first sign-in.'', ''N'', sp_util.fix_demo_dates(sysdate -75), ''ISAAC.TURNER@';
wwv_flow_imp.g_varchar2_table(254) := 'ACME.COM'', sp_util.fix_demo_dates(sysdate -75), ''ISAAC.TURNER@ACME.COM'');'||wwv_flow.LF||
'insert into sp_project_com';
wwv_flow_imp.g_varchar2_table(255) := 'ments (id, project_id, author_id, body, body_html, body_no_images, private_yn, created, created_by, ';
wwv_flow_imp.g_varchar2_table(256) := 'updated, updated_by) values (2014, 1007, 14, ''Security approved the SSO session-timeout policy and r';
wwv_flow_imp.g_varchar2_table(257) := 'ecovery controls.'', ''Security approved the SSO session-timeout policy and recovery controls.'', ''Secu';
wwv_flow_imp.g_varchar2_table(258) := 'rity approved the SSO session-timeout policy and recovery controls.'', ''N'', sp_util.fix_demo_dates(sy';
wwv_flow_imp.g_varchar2_table(259) := 'sdate -32), ''CHLOE.WHITAKER@ACME.COM'', sp_util.fix_demo_dates(sysdate -32), ''CHLOE.WHITAKER@ACME.COM';
wwv_flow_imp.g_varchar2_table(260) := ''');'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id, author_id, body, body_html, body_no_images, pri';
wwv_flow_imp.g_varchar2_table(261) := 'vate_yn, created, created_by, updated, updated_by) values (2015, 1008, 15, ''Keyboard navigation and ';
wwv_flow_imp.g_varchar2_table(262) := 'focus management were implemented in the shared component library.'', ''Keyboard navigation and focus ';
wwv_flow_imp.g_varchar2_table(263) := 'management were implemented in the shared component library.'', ''Keyboard navigation and focus manage';
wwv_flow_imp.g_varchar2_table(264) := 'ment were implemented in the shared component library.'', ''N'', sp_util.fix_demo_dates(sysdate -75), ''';
wwv_flow_imp.g_varchar2_table(265) := 'DOMINIC.REYES@ACME.COM'', sp_util.fix_demo_dates(sysdate -75), ''DOMINIC.REYES@ACME.COM'');'||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(266) := ' sp_project_comments (id, project_id, author_id, body, body_html, body_no_images, private_yn, create';
wwv_flow_imp.g_varchar2_table(267) := 'd, created_by, updated, updated_by) values (2016, 1008, 16, ''Accessibility review confirmed the port';
wwv_flow_imp.g_varchar2_table(268) := 'al meets the agreed WCAG AA baseline.'', ''Accessibility review confirmed the portal meets the agreed ';
wwv_flow_imp.g_varchar2_table(269) := 'WCAG AA baseline.'', ''Accessibility review confirmed the portal meets the agreed WCAG AA baseline.'', ';
wwv_flow_imp.g_varchar2_table(270) := '''N'', sp_util.fix_demo_dates(sysdate -32), ''MAYA.PATEL@ACME.COM'', sp_util.fix_demo_dates(sysdate -32)';
wwv_flow_imp.g_varchar2_table(271) := ', ''MAYA.PATEL@ACME.COM'');'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id, author_id, body, body_htm';
wwv_flow_imp.g_varchar2_table(272) := 'l, body_no_images, private_yn, created, created_by, updated, updated_by) values (2017, 1009, 17, ''We';
wwv_flow_imp.g_varchar2_table(273) := ' removed direct identifiers from event payloads and documented the approved analytics taxonomy.'', ''W';
wwv_flow_imp.g_varchar2_table(274) := 'e removed direct identifiers from event payloads and documented the approved analytics taxonomy.'', ''';
wwv_flow_imp.g_varchar2_table(275) := 'We removed direct identifiers from event payloads and documented the approved analytics taxonomy.'', ';
wwv_flow_imp.g_varchar2_table(276) := '''N'', sp_util.fix_demo_dates(sysdate -75), ''ETHAN.CALDWELL@ACME.COM'', sp_util.fix_demo_dates(sysdate ';
wwv_flow_imp.g_varchar2_table(277) := '-75), ''ETHAN.CALDWELL@ACME.COM'');'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id, author_id, body, ';
wwv_flow_imp.g_varchar2_table(278) := 'body_html, body_no_images, private_yn, created, created_by, updated, updated_by) values (2018, 1009,';
wwv_flow_imp.g_varchar2_table(279) := ' 18, ''Product managers accepted the adoption dashboard and weekly reporting cadence.'', ''Product mana';
wwv_flow_imp.g_varchar2_table(280) := 'gers accepted the adoption dashboard and weekly reporting cadence.'', ''Product managers accepted the ';
wwv_flow_imp.g_varchar2_table(281) := 'adoption dashboard and weekly reporting cadence.'', ''N'', sp_util.fix_demo_dates(sysdate -32), ''VANESS';
wwv_flow_imp.g_varchar2_table(282) := 'A.CRUZ@ACME.COM'', sp_util.fix_demo_dates(sysdate -32), ''VANESSA.CRUZ@ACME.COM'');'||wwv_flow.LF||
'insert into sp_proj';
wwv_flow_imp.g_varchar2_table(283) := 'ect_comments (id, project_id, author_id, body, body_html, body_no_images, private_yn, created, creat';
wwv_flow_imp.g_varchar2_table(284) := 'ed_by, updated, updated_by) values (2019, 1010, 19, ''Load testing validated the target concurrency l';
wwv_flow_imp.g_varchar2_table(285) := 'evel after query and cache improvements.'', ''Load testing validated the target concurrency level afte';
wwv_flow_imp.g_varchar2_table(286) := 'r query and cache improvements.'', ''Load testing validated the target concurrency level after query a';
wwv_flow_imp.g_varchar2_table(287) := 'nd cache improvements.'', ''N'', sp_util.fix_demo_dates(sysdate -75), ''LUCAS.BENNETT@ACME.COM'', sp_util';
wwv_flow_imp.g_varchar2_table(288) := '.fix_demo_dates(sysdate -75), ''LUCAS.BENNETT@ACME.COM'');'||wwv_flow.LF||
'insert into sp_project_comments (id, projec';
wwv_flow_imp.g_varchar2_table(289) := 't_id, author_id, body, body_html, body_no_images, private_yn, created, created_by, updated, updated_';
wwv_flow_imp.g_varchar2_table(290) := 'by) values (2020, 1010, 20, ''The service-level objectives and release rollback thresholds were appro';
wwv_flow_imp.g_varchar2_table(291) := 'ved.'', ''The service-level objectives and release rollback thresholds were approved.'', ''The service-l';
wwv_flow_imp.g_varchar2_table(292) := 'evel objectives and release rollback thresholds were approved.'', ''N'', sp_util.fix_demo_dates(sysdate';
wwv_flow_imp.g_varchar2_table(293) := ' -32), ''AIDEN.CLARKE@ACME.COM'', sp_util.fix_demo_dates(sysdate -32), ''AIDEN.CLARKE@ACME.COM'');'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- ';
wwv_flow_imp.g_varchar2_table(294) := 'Standard release milestones, sequenced against the Customer Hub 1.0 window.'||wwv_flow.LF||
'insert all'||wwv_flow.LF||
'  into sp_tas';
wwv_flow_imp.g_varchar2_table(295) := 'ks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, sta';
wwv_flow_imp.g_varchar2_table(296) := 'tus_id, status_last_changed_on, description, tags, display_sequence, impact, created, created_by, up';
wwv_flow_imp.g_varchar2_table(297) := 'dated, updated_by)'||wwv_flow.LF||
'    values (3001, 1001, ''Spec Complete'', 21, null, 2, sp_util.fix_demo_dates(sysd';
wwv_flow_imp.g_varchar2_table(298) := 'ate - 98), sp_util.fix_demo_dates(sysdate - 90), 14, sp_util.fix_demo_dates(sysdate - 90), ''Approved';
wwv_flow_imp.g_varchar2_table(299) := ' functional and technical design.'', ''milestone,spec'', 10, null, sp_util.fix_demo_dates(sysdate - 100';
wwv_flow_imp.g_varchar2_table(300) := '), ''SCOTT.TIGER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''MARCUS.HALE@ACME.COM'')'||wwv_flow.LF||
'  into sp_t';
wwv_flow_imp.g_varchar2_table(301) := 'asks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, s';
wwv_flow_imp.g_varchar2_table(302) := 'tatus_id, status_last_changed_on, description, tags, display_sequence, impact, created, created_by, ';
wwv_flow_imp.g_varchar2_table(303) := 'updated, updated_by) values (3002, 1001, ''Demonstrable'', 22, null, 2, sp_util.fix_demo_dates(sysdate';
wwv_flow_imp.g_varchar2_table(304) := ' - 76), sp_util.fix_demo_dates(sysdate - 72), 14, sp_util.fix_demo_dates(sysdate - 72), ''Account sum';
wwv_flow_imp.g_varchar2_table(305) := 'mary demonstrated to stakeholders.'', ''milestone,demo'', 20, null, sp_util.fix_demo_dates(sysdate - 10';
wwv_flow_imp.g_varchar2_table(306) := '0), ''SCOTT.TIGER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''MARCUS.HALE@ACME.COM'')'||wwv_flow.LF||
'  into sp_';
wwv_flow_imp.g_varchar2_table(307) := 'tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, ';
wwv_flow_imp.g_varchar2_table(308) := 'status_id, status_last_changed_on, description, tags, display_sequence, impact, created, created_by,';
wwv_flow_imp.g_varchar2_table(309) := ' updated, updated_by) values (3003, 1001, ''Code Complete'', 23, null, 1, sp_util.fix_demo_dates(sysda';
wwv_flow_imp.g_varchar2_table(310) := 'te - 50), sp_util.fix_demo_dates(sysdate - 45), 14, sp_util.fix_demo_dates(sysdate - 45), ''Implement';
wwv_flow_imp.g_varchar2_table(311) := 'ation complete and unit tests passing.'', ''milestone,code'', 30, null, sp_util.fix_demo_dates(sysdate ';
wwv_flow_imp.g_varchar2_table(312) := '- 100), ''SCOTT.TIGER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''SCOTT.TIGER@ACME.COM'')'||wwv_flow.LF||
'  into';
wwv_flow_imp.g_varchar2_table(313) := ' sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_comple';
wwv_flow_imp.g_varchar2_table(314) := 'te, status_id, status_last_changed_on, description, tags, display_sequence, impact, created, created';
wwv_flow_imp.g_varchar2_table(315) := '_by, updated, updated_by) values (3004, 1001, ''Merged'', 24, null, 1, sp_util.fix_demo_dates(sysdate ';
wwv_flow_imp.g_varchar2_table(316) := '- 39), sp_util.fix_demo_dates(sysdate - 35), 14, sp_util.fix_demo_dates(sysdate - 35), ''Changes merg';
wwv_flow_imp.g_varchar2_table(317) := 'ed to the release branch.'', ''milestone,merge'', 40, null, sp_util.fix_demo_dates(sysdate - 100), ''SCO';
wwv_flow_imp.g_varchar2_table(318) := 'TT.TIGER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''SCOTT.TIGER@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (i';
wwv_flow_imp.g_varchar2_table(319) := 'd, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_i';
wwv_flow_imp.g_varchar2_table(320) := 'd, status_last_changed_on, description, tags, display_sequence, impact, created, created_by, updated';
wwv_flow_imp.g_varchar2_table(321) := ', updated_by) values (3005, 1001, ''Hosted'', 25, null, 2, sp_util.fix_demo_dates(sysdate - 25), sp_ut';
wwv_flow_imp.g_varchar2_table(322) := 'il.fix_demo_dates(sysdate - 20), 14, sp_util.fix_demo_dates(sysdate - 20), ''Deployed to the producti';
wwv_flow_imp.g_varchar2_table(323) := 'on hosting environment.'', ''milestone,hosting'', 50, null, sp_util.fix_demo_dates(sysdate - 100), ''SCO';
wwv_flow_imp.g_varchar2_table(324) := 'TT.TIGER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''MARCUS.HALE@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (i';
wwv_flow_imp.g_varchar2_table(325) := 'd, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_i';
wwv_flow_imp.g_varchar2_table(326) := 'd, status_last_changed_on, description, tags, display_sequence, impact, created, created_by, updated';
wwv_flow_imp.g_varchar2_table(327) := ', updated_by) values (3006, 1001, ''Complete'', 26, null, 1, sp_util.fix_demo_dates(sysdate - 12), sp_';
wwv_flow_imp.g_varchar2_table(328) := 'util.fix_demo_dates(sysdate - 12), 14, sp_util.fix_demo_dates(sysdate - 12), ''Release scope accepted';
wwv_flow_imp.g_varchar2_table(329) := '.'', ''milestone,complete'', 60, null, sp_util.fix_demo_dates(sysdate - 100), ''SCOTT.TIGER@ACME.COM'', s';
wwv_flow_imp.g_varchar2_table(330) := 'p_util.fix_demo_dates(sysdate - 10), ''SCOTT.TIGER@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, ';
wwv_flow_imp.g_varchar2_table(331) := 'task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_change';
wwv_flow_imp.g_varchar2_table(332) := 'd_on, description, tags, display_sequence, impact, created, created_by, updated, updated_by) values ';
wwv_flow_imp.g_varchar2_table(333) := '(3011, 1002, ''Spec Complete'', 21, null, 4, sp_util.fix_demo_dates(sysdate - 98), sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(334) := 'tes(sysdate - 90), 14, sp_util.fix_demo_dates(sysdate - 90), ''Approved functional and technical desi';
wwv_flow_imp.g_varchar2_table(335) := 'gn.'', ''milestone,spec'', 10, null, sp_util.fix_demo_dates(sysdate - 100), ''ELENA.VARGAS@ACME.COM'', sp';
wwv_flow_imp.g_varchar2_table(336) := '_util.fix_demo_dates(sysdate - 10), ''TYLER.BROOKS@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, ';
wwv_flow_imp.g_varchar2_table(337) := 'task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_change';
wwv_flow_imp.g_varchar2_table(338) := 'd_on, description, tags, display_sequence, impact, created, created_by, updated, updated_by) values ';
wwv_flow_imp.g_varchar2_table(339) := '(3012, 1002, ''Demonstrable'', 22, null, 4, sp_util.fix_demo_dates(sysdate - 76), sp_util.fix_demo_dat';
wwv_flow_imp.g_varchar2_table(340) := 'es(sysdate - 72), 14, sp_util.fix_demo_dates(sysdate - 72), ''Request flow demonstrated to stakeholde';
wwv_flow_imp.g_varchar2_table(341) := 'rs.'', ''milestone,demo'', 20, null, sp_util.fix_demo_dates(sysdate - 100), ''ELENA.VARGAS@ACME.COM'', sp';
wwv_flow_imp.g_varchar2_table(342) := '_util.fix_demo_dates(sysdate - 10), ''TYLER.BROOKS@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, ';
wwv_flow_imp.g_varchar2_table(343) := 'task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_change';
wwv_flow_imp.g_varchar2_table(344) := 'd_on, description, tags, display_sequence, impact, created, created_by, updated, updated_by) values ';
wwv_flow_imp.g_varchar2_table(345) := '(3013, 1002, ''Code Complete'', 23, null, 3, sp_util.fix_demo_dates(sysdate - 50), sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(346) := 'tes(sysdate - 45), 14, sp_util.fix_demo_dates(sysdate - 45), ''Implementation complete and unit tests';
wwv_flow_imp.g_varchar2_table(347) := ' passing.'', ''milestone,code'', 30, null, sp_util.fix_demo_dates(sysdate - 100), ''ELENA.VARGAS@ACME.CO';
wwv_flow_imp.g_varchar2_table(348) := 'M'', sp_util.fix_demo_dates(sysdate - 10), ''ELENA.VARGAS@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, ';
wwv_flow_imp.g_varchar2_table(349) := 'task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_';
wwv_flow_imp.g_varchar2_table(350) := 'changed_on, description, tags, display_sequence, impact, created, created_by, updated, updated_by) v';
wwv_flow_imp.g_varchar2_table(351) := 'alues (3014, 1002, ''Merged'', 24, null, 3, sp_util.fix_demo_dates(sysdate - 39), sp_util.fix_demo_dat';
wwv_flow_imp.g_varchar2_table(352) := 'es(sysdate - 35), 14, sp_util.fix_demo_dates(sysdate - 35), ''Changes merged to the release branch.'',';
wwv_flow_imp.g_varchar2_table(353) := ' ''milestone,merge'', 40, null, sp_util.fix_demo_dates(sysdate - 100), ''ELENA.VARGAS@ACME.COM'', sp_uti';
wwv_flow_imp.g_varchar2_table(354) := 'l.fix_demo_dates(sysdate - 10), ''ELENA.VARGAS@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task';
wwv_flow_imp.g_varchar2_table(355) := '_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_changed_on';
wwv_flow_imp.g_varchar2_table(356) := ', description, tags, display_sequence, impact, created, created_by, updated, updated_by) values (301';
wwv_flow_imp.g_varchar2_table(357) := '5, 1002, ''Hosted'', 25, null, 4, sp_util.fix_demo_dates(sysdate - 25), sp_util.fix_demo_dates(sysdate';
wwv_flow_imp.g_varchar2_table(358) := ' - 20), 14, sp_util.fix_demo_dates(sysdate - 20), ''Deployed to the production hosting environment.'',';
wwv_flow_imp.g_varchar2_table(359) := ' ''milestone,hosting'', 50, null, sp_util.fix_demo_dates(sysdate - 100), ''ELENA.VARGAS@ACME.COM'', sp_u';
wwv_flow_imp.g_varchar2_table(360) := 'til.fix_demo_dates(sysdate - 10), ''TYLER.BROOKS@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, ta';
wwv_flow_imp.g_varchar2_table(361) := 'sk_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_changed_';
wwv_flow_imp.g_varchar2_table(362) := 'on, description, tags, display_sequence, impact, created, created_by, updated, updated_by) values (3';
wwv_flow_imp.g_varchar2_table(363) := '016, 1002, ''Complete'', 26, null, 3, sp_util.fix_demo_dates(sysdate - 11), sp_util.fix_demo_dates(sys';
wwv_flow_imp.g_varchar2_table(364) := 'date - 11), 14, sp_util.fix_demo_dates(sysdate - 11), ''Release scope accepted.'', ''milestone,complete';
wwv_flow_imp.g_varchar2_table(365) := ''', 60, null, sp_util.fix_demo_dates(sysdate - 100), ''ELENA.VARGAS@ACME.COM'', sp_util.fix_demo_dates(';
wwv_flow_imp.g_varchar2_table(366) := 'sysdate - 10), ''ELENA.VARGAS@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_su';
wwv_flow_imp.g_varchar2_table(367) := 'b_type_id, owner_id, start_date, target_complete, status_id, status_last_changed_on, description, ta';
wwv_flow_imp.g_varchar2_table(368) := 'gs, display_sequence, impact, created, created_by, updated, updated_by) values (3021, 1003, ''Spec Co';
wwv_flow_imp.g_varchar2_table(369) := 'mplete'', 21, null, 6, sp_util.fix_demo_dates(sysdate - 98), sp_util.fix_demo_dates(sysdate - 90), 14';
wwv_flow_imp.g_varchar2_table(370) := ', sp_util.fix_demo_dates(sysdate - 90), ''Approved functional and technical design.'', ''milestone,spec';
wwv_flow_imp.g_varchar2_table(371) := ''', 10, null, sp_util.fix_demo_dates(sysdate - 100), ''NAOMI.CHEN@ACME.COM'', sp_util.fix_demo_dates(sy';
wwv_flow_imp.g_varchar2_table(372) := 'sdate - 10), ''JORDAN.AVERY@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_';
wwv_flow_imp.g_varchar2_table(373) := 'type_id, owner_id, start_date, target_complete, status_id, status_last_changed_on, description, tags';
wwv_flow_imp.g_varchar2_table(374) := ', display_sequence, impact, created, created_by, updated, updated_by) values (3022, 1003, ''Demonstra';
wwv_flow_imp.g_varchar2_table(375) := 'ble'', 22, null, 6, sp_util.fix_demo_dates(sysdate - 76), sp_util.fix_demo_dates(sysdate - 72), 14, s';
wwv_flow_imp.g_varchar2_table(376) := 'p_util.fix_demo_dates(sysdate - 72), ''Document search demonstrated to stakeholders.'', ''milestone,dem';
wwv_flow_imp.g_varchar2_table(377) := 'o'', 20, null, sp_util.fix_demo_dates(sysdate - 100), ''NAOMI.CHEN@ACME.COM'', sp_util.fix_demo_dates(s';
wwv_flow_imp.g_varchar2_table(378) := 'ysdate - 10), ''JORDAN.AVERY@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub';
wwv_flow_imp.g_varchar2_table(379) := '_type_id, owner_id, start_date, target_complete, status_id, status_last_changed_on, description, tag';
wwv_flow_imp.g_varchar2_table(380) := 's, display_sequence, impact, created, created_by, updated, updated_by) values (3023, 1003, ''Code Com';
wwv_flow_imp.g_varchar2_table(381) := 'plete'', 23, null, 5, sp_util.fix_demo_dates(sysdate - 50), sp_util.fix_demo_dates(sysdate - 45), 14,';
wwv_flow_imp.g_varchar2_table(382) := ' sp_util.fix_demo_dates(sysdate - 45), ''Implementation complete and unit tests passing.'', ''milestone';
wwv_flow_imp.g_varchar2_table(383) := ',code'', 30, null, sp_util.fix_demo_dates(sysdate - 100), ''NAOMI.CHEN@ACME.COM'', sp_util.fix_demo_dat';
wwv_flow_imp.g_varchar2_table(384) := 'es(sysdate - 10), ''NAOMI.CHEN@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_s';
wwv_flow_imp.g_varchar2_table(385) := 'ub_type_id, owner_id, start_date, target_complete, status_id, status_last_changed_on, description, t';
wwv_flow_imp.g_varchar2_table(386) := 'ags, display_sequence, impact, created, created_by, updated, updated_by) values (3024, 1003, ''Merged';
wwv_flow_imp.g_varchar2_table(387) := ''', 24, null, 5, sp_util.fix_demo_dates(sysdate - 39), sp_util.fix_demo_dates(sysdate - 35), 14, sp_u';
wwv_flow_imp.g_varchar2_table(388) := 'til.fix_demo_dates(sysdate - 35), ''Changes merged to the release branch.'', ''milestone,merge'', 40, nu';
wwv_flow_imp.g_varchar2_table(389) := 'll, sp_util.fix_demo_dates(sysdate - 100), ''NAOMI.CHEN@ACME.COM'', sp_util.fix_demo_dates(sysdate - 1';
wwv_flow_imp.g_varchar2_table(390) := '0), ''NAOMI.CHEN@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, ow';
wwv_flow_imp.g_varchar2_table(391) := 'ner_id, start_date, target_complete, status_id, status_last_changed_on, description, tags, display_s';
wwv_flow_imp.g_varchar2_table(392) := 'equence, impact, created, created_by, updated, updated_by) values (3025, 1003, ''Hosted'', 25, null, 6';
wwv_flow_imp.g_varchar2_table(393) := ', sp_util.fix_demo_dates(sysdate - 25), sp_util.fix_demo_dates(sysdate - 20), 14, sp_util.fix_demo_d';
wwv_flow_imp.g_varchar2_table(394) := 'ates(sysdate - 20), ''Deployed to the production hosting environment.'', ''milestone,hosting'', 50, null';
wwv_flow_imp.g_varchar2_table(395) := ', sp_util.fix_demo_dates(sysdate - 100), ''NAOMI.CHEN@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10)';
wwv_flow_imp.g_varchar2_table(396) := ', ''JORDAN.AVERY@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, ow';
wwv_flow_imp.g_varchar2_table(397) := 'ner_id, start_date, target_complete, status_id, status_last_changed_on, description, tags, display_s';
wwv_flow_imp.g_varchar2_table(398) := 'equence, impact, created, created_by, updated, updated_by) values (3026, 1003, ''Complete'', 26, null,';
wwv_flow_imp.g_varchar2_table(399) := ' 5, sp_util.fix_demo_dates(sysdate - 14), sp_util.fix_demo_dates(sysdate - 14), 14, sp_util.fix_demo';
wwv_flow_imp.g_varchar2_table(400) := '_dates(sysdate - 14), ''Release scope accepted.'', ''milestone,complete'', 60, null, sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(401) := 'tes(sysdate - 100), ''NAOMI.CHEN@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''NAOMI.CHEN@ACME.CO';
wwv_flow_imp.g_varchar2_table(402) := 'M'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, tar';
wwv_flow_imp.g_varchar2_table(403) := 'get_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, create';
wwv_flow_imp.g_varchar2_table(404) := 'd, created_by, updated, updated_by) values (3031, 1004, ''Spec Complete'', 21, null, 8, sp_util.fix_de';
wwv_flow_imp.g_varchar2_table(405) := 'mo_dates(sysdate - 98), sp_util.fix_demo_dates(sysdate - 90), 14, sp_util.fix_demo_dates(sysdate - 9';
wwv_flow_imp.g_varchar2_table(406) := '0), ''Approved functional and technical design.'', ''milestone,spec'', 10, null, sp_util.fix_demo_dates(';
wwv_flow_imp.g_varchar2_table(407) := 'sysdate - 100), ''CALEB.FOSTER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''LILA.MONTGOMERY@ACME';
wwv_flow_imp.g_varchar2_table(408) := '.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, ';
wwv_flow_imp.g_varchar2_table(409) := 'target_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, cre';
wwv_flow_imp.g_varchar2_table(410) := 'ated, created_by, updated, updated_by) values (3032, 1004, ''Demonstrable'', 22, null, 8, sp_util.fix_';
wwv_flow_imp.g_varchar2_table(411) := 'demo_dates(sysdate - 76), sp_util.fix_demo_dates(sysdate - 72), 14, sp_util.fix_demo_dates(sysdate -';
wwv_flow_imp.g_varchar2_table(412) := ' 72), ''Billing flow demonstrated to stakeholders.'', ''milestone,demo'', 20, null, sp_util.fix_demo_dat';
wwv_flow_imp.g_varchar2_table(413) := 'es(sysdate - 100), ''CALEB.FOSTER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''LILA.MONTGOMERY@A';
wwv_flow_imp.g_varchar2_table(414) := 'CME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_dat';
wwv_flow_imp.g_varchar2_table(415) := 'e, target_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, ';
wwv_flow_imp.g_varchar2_table(416) := 'created, created_by, updated, updated_by) values (3033, 1004, ''Code Complete'', 23, null, 7, sp_util.';
wwv_flow_imp.g_varchar2_table(417) := 'fix_demo_dates(sysdate - 50), sp_util.fix_demo_dates(sysdate - 45), 14, sp_util.fix_demo_dates(sysda';
wwv_flow_imp.g_varchar2_table(418) := 'te - 45), ''Implementation complete and unit tests passing.'', ''milestone,code'', 30, null, sp_util.fix';
wwv_flow_imp.g_varchar2_table(419) := '_demo_dates(sysdate - 100), ''CALEB.FOSTER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''CALEB.FO';
wwv_flow_imp.g_varchar2_table(420) := 'STER@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, sta';
wwv_flow_imp.g_varchar2_table(421) := 'rt_date, target_complete, status_id, status_last_changed_on, description, tags, display_sequence, im';
wwv_flow_imp.g_varchar2_table(422) := 'pact, created, created_by, updated, updated_by) values (3034, 1004, ''Merged'', 24, null, 7, sp_util.f';
wwv_flow_imp.g_varchar2_table(423) := 'ix_demo_dates(sysdate - 39), sp_util.fix_demo_dates(sysdate - 35), 14, sp_util.fix_demo_dates(sysdat';
wwv_flow_imp.g_varchar2_table(424) := 'e - 35), ''Changes merged to the release branch.'', ''milestone,merge'', 40, null, sp_util.fix_demo_date';
wwv_flow_imp.g_varchar2_table(425) := 's(sysdate - 100), ''CALEB.FOSTER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''CALEB.FOSTER@ACME.';
wwv_flow_imp.g_varchar2_table(426) := 'COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, t';
wwv_flow_imp.g_varchar2_table(427) := 'arget_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, crea';
wwv_flow_imp.g_varchar2_table(428) := 'ted, created_by, updated, updated_by) values (3035, 1004, ''Hosted'', 25, null, 8, sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(429) := 'tes(sysdate - 25), sp_util.fix_demo_dates(sysdate - 20), 14, sp_util.fix_demo_dates(sysdate - 20), ''';
wwv_flow_imp.g_varchar2_table(430) := 'Deployed to the production hosting environment.'', ''milestone,hosting'', 50, null, sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(431) := 'tes(sysdate - 100), ''CALEB.FOSTER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''LILA.MONTGOMERY@';
wwv_flow_imp.g_varchar2_table(432) := 'ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_da';
wwv_flow_imp.g_varchar2_table(433) := 'te, target_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact,';
wwv_flow_imp.g_varchar2_table(434) := ' created, created_by, updated, updated_by) values (3036, 1004, ''Complete'', 26, null, 7, sp_util.fix_';
wwv_flow_imp.g_varchar2_table(435) := 'demo_dates(sysdate - 10), sp_util.fix_demo_dates(sysdate - 10), 14, sp_util.fix_demo_dates(sysdate -';
wwv_flow_imp.g_varchar2_table(436) := ' 10), ''Release scope accepted.'', ''milestone,complete'', 60, null, sp_util.fix_demo_dates(sysdate - 10';
wwv_flow_imp.g_varchar2_table(437) := '0), ''CALEB.FOSTER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''CALEB.FOSTER@ACME.COM'')'||wwv_flow.LF||
'  into s';
wwv_flow_imp.g_varchar2_table(438) := 'p_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete';
wwv_flow_imp.g_varchar2_table(439) := ', status_id, status_last_changed_on, description, tags, display_sequence, impact, created, created_b';
wwv_flow_imp.g_varchar2_table(440) := 'y, updated, updated_by) values (3041, 1005, ''Spec Complete'', 21, null, 10, sp_util.fix_demo_dates(sy';
wwv_flow_imp.g_varchar2_table(441) := 'sdate - 98), sp_util.fix_demo_dates(sysdate - 90), 14, sp_util.fix_demo_dates(sysdate - 90), ''Approv';
wwv_flow_imp.g_varchar2_table(442) := 'ed functional and technical design.'', ''milestone,spec'', 10, null, sp_util.fix_demo_dates(sysdate - 1';
wwv_flow_imp.g_varchar2_table(443) := '00), ''ANDRE.COLLINS@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''SOPHIE.BENNETT@ACME.COM'')'||wwv_flow.LF||
'  in';
wwv_flow_imp.g_varchar2_table(444) := 'to sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_comp';
wwv_flow_imp.g_varchar2_table(445) := 'lete, status_id, status_last_changed_on, description, tags, display_sequence, impact, created, creat';
wwv_flow_imp.g_varchar2_table(446) := 'ed_by, updated, updated_by) values (3042, 1005, ''Demonstrable'', 22, null, 10, sp_util.fix_demo_dates';
wwv_flow_imp.g_varchar2_table(447) := '(sysdate - 76), sp_util.fix_demo_dates(sysdate - 72), 14, sp_util.fix_demo_dates(sysdate - 72), ''Ass';
wwv_flow_imp.g_varchar2_table(448) := 'istant workflow demonstrated to stakeholders.'', ''milestone,demo'', 20, null, sp_util.fix_demo_dates(s';
wwv_flow_imp.g_varchar2_table(449) := 'ysdate - 100), ''ANDRE.COLLINS@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''SOPHIE.BENNETT@ACME.';
wwv_flow_imp.g_varchar2_table(450) := 'COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, t';
wwv_flow_imp.g_varchar2_table(451) := 'arget_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, crea';
wwv_flow_imp.g_varchar2_table(452) := 'ted, created_by, updated, updated_by) values (3043, 1005, ''Code Complete'', 23, null, 9, sp_util.fix_';
wwv_flow_imp.g_varchar2_table(453) := 'demo_dates(sysdate - 50), sp_util.fix_demo_dates(sysdate - 45), 14, sp_util.fix_demo_dates(sysdate -';
wwv_flow_imp.g_varchar2_table(454) := ' 45), ''Implementation complete and unit tests passing.'', ''milestone,code'', 30, null, sp_util.fix_dem';
wwv_flow_imp.g_varchar2_table(455) := 'o_dates(sysdate - 100), ''ANDRE.COLLINS@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''ANDRE.COLLI';
wwv_flow_imp.g_varchar2_table(456) := 'NS@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start';
wwv_flow_imp.g_varchar2_table(457) := '_date, target_complete, status_id, status_last_changed_on, description, tags, display_sequence, impa';
wwv_flow_imp.g_varchar2_table(458) := 'ct, created, created_by, updated, updated_by) values (3044, 1005, ''Merged'', 24, null, 9, sp_util.fix';
wwv_flow_imp.g_varchar2_table(459) := '_demo_dates(sysdate - 39), sp_util.fix_demo_dates(sysdate - 35), 14, sp_util.fix_demo_dates(sysdate ';
wwv_flow_imp.g_varchar2_table(460) := '- 35), ''Changes merged to the release branch.'', ''milestone,merge'', 40, null, sp_util.fix_demo_dates(';
wwv_flow_imp.g_varchar2_table(461) := 'sysdate - 100), ''ANDRE.COLLINS@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''ANDRE.COLLINS@ACME.';
wwv_flow_imp.g_varchar2_table(462) := 'COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, t';
wwv_flow_imp.g_varchar2_table(463) := 'arget_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, crea';
wwv_flow_imp.g_varchar2_table(464) := 'ted, created_by, updated, updated_by) values (3045, 1005, ''Hosted'', 25, null, 10, sp_util.fix_demo_d';
wwv_flow_imp.g_varchar2_table(465) := 'ates(sysdate - 25), sp_util.fix_demo_dates(sysdate - 20), 14, sp_util.fix_demo_dates(sysdate - 20), ';
wwv_flow_imp.g_varchar2_table(466) := '''Deployed to the production hosting environment.'', ''milestone,hosting'', 50, null, sp_util.fix_demo_d';
wwv_flow_imp.g_varchar2_table(467) := 'ates(sysdate - 100), ''ANDRE.COLLINS@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''SOPHIE.BENNETT';
wwv_flow_imp.g_varchar2_table(468) := '@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_d';
wwv_flow_imp.g_varchar2_table(469) := 'ate, target_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact';
wwv_flow_imp.g_varchar2_table(470) := ', created, created_by, updated, updated_by) values (3046, 1005, ''Complete'', 26, null, 9, sp_util.fix';
wwv_flow_imp.g_varchar2_table(471) := '_demo_dates(sysdate - 13), sp_util.fix_demo_dates(sysdate - 13), 14, sp_util.fix_demo_dates(sysdate ';
wwv_flow_imp.g_varchar2_table(472) := '- 13), ''Release scope accepted.'', ''milestone,complete'', 60, null, sp_util.fix_demo_dates(sysdate - 1';
wwv_flow_imp.g_varchar2_table(473) := '00), ''ANDRE.COLLINS@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''ANDRE.COLLINS@ACME.COM'')'||wwv_flow.LF||
'  int';
wwv_flow_imp.g_varchar2_table(474) := 'o sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_compl';
wwv_flow_imp.g_varchar2_table(475) := 'ete, status_id, status_last_changed_on, description, tags, display_sequence, impact, created, create';
wwv_flow_imp.g_varchar2_table(476) := 'd_by, updated, updated_by) values (3051, 1006, ''Spec Complete'', 21, null, 12, sp_util.fix_demo_dates';
wwv_flow_imp.g_varchar2_table(477) := '(sysdate - 98), sp_util.fix_demo_dates(sysdate - 90), 14, sp_util.fix_demo_dates(sysdate - 90), ''App';
wwv_flow_imp.g_varchar2_table(478) := 'roved functional and technical design.'', ''milestone,spec'', 10, null, sp_util.fix_demo_dates(sysdate ';
wwv_flow_imp.g_varchar2_table(479) := '- 100), ''VICTOR.RAMIREZ@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''HANNAH.DOYLE@ACME.COM'')'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(480) := 'into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_co';
wwv_flow_imp.g_varchar2_table(481) := 'mplete, status_id, status_last_changed_on, description, tags, display_sequence, impact, created, cre';
wwv_flow_imp.g_varchar2_table(482) := 'ated_by, updated, updated_by) values (3052, 1006, ''Demonstrable'', 22, null, 12, sp_util.fix_demo_dat';
wwv_flow_imp.g_varchar2_table(483) := 'es(sysdate - 76), sp_util.fix_demo_dates(sysdate - 72), 14, sp_util.fix_demo_dates(sysdate - 72), ''P';
wwv_flow_imp.g_varchar2_table(484) := 'reference center demonstrated to stakeholders.'', ''milestone,demo'', 20, null, sp_util.fix_demo_dates(';
wwv_flow_imp.g_varchar2_table(485) := 'sysdate - 100), ''VICTOR.RAMIREZ@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''HANNAH.DOYLE@ACME.';
wwv_flow_imp.g_varchar2_table(486) := 'COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, t';
wwv_flow_imp.g_varchar2_table(487) := 'arget_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, crea';
wwv_flow_imp.g_varchar2_table(488) := 'ted, created_by, updated, updated_by) values (3053, 1006, ''Code Complete'', 23, null, 11, sp_util.fix';
wwv_flow_imp.g_varchar2_table(489) := '_demo_dates(sysdate - 50), sp_util.fix_demo_dates(sysdate - 45), 14, sp_util.fix_demo_dates(sysdate ';
wwv_flow_imp.g_varchar2_table(490) := '- 45), ''Implementation complete and unit tests passing.'', ''milestone,code'', 30, null, sp_util.fix_de';
wwv_flow_imp.g_varchar2_table(491) := 'mo_dates(sysdate - 100), ''VICTOR.RAMIREZ@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''VICTOR.RA';
wwv_flow_imp.g_varchar2_table(492) := 'MIREZ@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, st';
wwv_flow_imp.g_varchar2_table(493) := 'art_date, target_complete, status_id, status_last_changed_on, description, tags, display_sequence, i';
wwv_flow_imp.g_varchar2_table(494) := 'mpact, created, created_by, updated, updated_by) values (3054, 1006, ''Merged'', 24, null, 11, sp_util';
wwv_flow_imp.g_varchar2_table(495) := '.fix_demo_dates(sysdate - 39), sp_util.fix_demo_dates(sysdate - 35), 14, sp_util.fix_demo_dates(sysd';
wwv_flow_imp.g_varchar2_table(496) := 'ate - 35), ''Changes merged to the release branch.'', ''milestone,merge'', 40, null, sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(497) := 'tes(sysdate - 100), ''VICTOR.RAMIREZ@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''VICTOR.RAMIREZ';
wwv_flow_imp.g_varchar2_table(498) := '@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_d';
wwv_flow_imp.g_varchar2_table(499) := 'ate, target_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact';
wwv_flow_imp.g_varchar2_table(500) := ', created, created_by, updated, updated_by) values (3055, 1006, ''Hosted'', 25, null, 12, sp_util.fix_';
wwv_flow_imp.g_varchar2_table(501) := 'demo_dates(sysdate - 25), sp_util.fix_demo_dates(sysdate - 20), 14, sp_util.fix_demo_dates(sysdate -';
wwv_flow_imp.g_varchar2_table(502) := ' 20), ''Deployed to the production hosting environment.'', ''milestone,hosting'', 50, null, sp_util.fix_';
wwv_flow_imp.g_varchar2_table(503) := 'demo_dates(sysdate - 100), ''VICTOR.RAMIREZ@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''HANNAH.';
wwv_flow_imp.g_varchar2_table(504) := 'DOYLE@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, st';
wwv_flow_imp.g_varchar2_table(505) := 'art_date, target_complete, status_id, status_last_changed_on, description, tags, display_sequence, i';
wwv_flow_imp.g_varchar2_table(506) := 'mpact, created, created_by, updated, updated_by) values (3056, 1006, ''Complete'', 26, null, 11, sp_ut';
wwv_flow_imp.g_varchar2_table(507) := 'il.fix_demo_dates(sysdate - 15), sp_util.fix_demo_dates(sysdate - 15), 14, sp_util.fix_demo_dates(sy';
wwv_flow_imp.g_varchar2_table(508) := 'sdate - 15), ''Release scope accepted.'', ''milestone,complete'', 60, null, sp_util.fix_demo_dates(sysda';
wwv_flow_imp.g_varchar2_table(509) := 'te - 100), ''VICTOR.RAMIREZ@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''VICTOR.RAMIREZ@ACME.COM';
wwv_flow_imp.g_varchar2_table(510) := ''')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, targ';
wwv_flow_imp.g_varchar2_table(511) := 'et_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, created';
wwv_flow_imp.g_varchar2_table(512) := ', created_by, updated, updated_by) values (3061, 1007, ''Spec Complete'', 21, null, 14, sp_util.fix_de';
wwv_flow_imp.g_varchar2_table(513) := 'mo_dates(sysdate - 98), sp_util.fix_demo_dates(sysdate - 90), 14, sp_util.fix_demo_dates(sysdate - 9';
wwv_flow_imp.g_varchar2_table(514) := '0), ''Approved functional and technical design.'', ''milestone,spec'', 10, null, sp_util.fix_demo_dates(';
wwv_flow_imp.g_varchar2_table(515) := 'sysdate - 100), ''ISAAC.TURNER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''CHLOE.WHITAKER@ACME.';
wwv_flow_imp.g_varchar2_table(516) := 'COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, t';
wwv_flow_imp.g_varchar2_table(517) := 'arget_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, crea';
wwv_flow_imp.g_varchar2_table(518) := 'ted, created_by, updated, updated_by) values (3062, 1007, ''Demonstrable'', 22, null, 14, sp_util.fix_';
wwv_flow_imp.g_varchar2_table(519) := 'demo_dates(sysdate - 76), sp_util.fix_demo_dates(sysdate - 72), 14, sp_util.fix_demo_dates(sysdate -';
wwv_flow_imp.g_varchar2_table(520) := ' 72), ''Identity flows demonstrated to stakeholders.'', ''milestone,demo'', 20, null, sp_util.fix_demo_d';
wwv_flow_imp.g_varchar2_table(521) := 'ates(sysdate - 100), ''ISAAC.TURNER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''CHLOE.WHITAKER@';
wwv_flow_imp.g_varchar2_table(522) := 'ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_da';
wwv_flow_imp.g_varchar2_table(523) := 'te, target_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact,';
wwv_flow_imp.g_varchar2_table(524) := ' created, created_by, updated, updated_by) values (3063, 1007, ''Code Complete'', 23, null, 13, sp_uti';
wwv_flow_imp.g_varchar2_table(525) := 'l.fix_demo_dates(sysdate - 50), sp_util.fix_demo_dates(sysdate - 45), 14, sp_util.fix_demo_dates(sys';
wwv_flow_imp.g_varchar2_table(526) := 'date - 45), ''Implementation complete and unit tests passing.'', ''milestone,code'', 30, null, sp_util.f';
wwv_flow_imp.g_varchar2_table(527) := 'ix_demo_dates(sysdate - 100), ''ISAAC.TURNER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''ISAAC.';
wwv_flow_imp.g_varchar2_table(528) := 'TURNER@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, s';
wwv_flow_imp.g_varchar2_table(529) := 'tart_date, target_complete, status_id, status_last_changed_on, description, tags, display_sequence, ';
wwv_flow_imp.g_varchar2_table(530) := 'impact, created, created_by, updated, updated_by) values (3064, 1007, ''Merged'', 24, null, 13, sp_uti';
wwv_flow_imp.g_varchar2_table(531) := 'l.fix_demo_dates(sysdate - 39), sp_util.fix_demo_dates(sysdate - 35), 14, sp_util.fix_demo_dates(sys';
wwv_flow_imp.g_varchar2_table(532) := 'date - 35), ''Changes merged to the release branch.'', ''milestone,merge'', 40, null, sp_util.fix_demo_d';
wwv_flow_imp.g_varchar2_table(533) := 'ates(sysdate - 100), ''ISAAC.TURNER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''ISAAC.TURNER@AC';
wwv_flow_imp.g_varchar2_table(534) := 'ME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date';
wwv_flow_imp.g_varchar2_table(535) := ', target_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, c';
wwv_flow_imp.g_varchar2_table(536) := 'reated, created_by, updated, updated_by) values (3065, 1007, ''Hosted'', 25, null, 14, sp_util.fix_dem';
wwv_flow_imp.g_varchar2_table(537) := 'o_dates(sysdate - 25), sp_util.fix_demo_dates(sysdate - 20), 14, sp_util.fix_demo_dates(sysdate - 20';
wwv_flow_imp.g_varchar2_table(538) := '), ''Deployed to the production hosting environment.'', ''milestone,hosting'', 50, null, sp_util.fix_dem';
wwv_flow_imp.g_varchar2_table(539) := 'o_dates(sysdate - 100), ''ISAAC.TURNER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''CHLOE.WHITAK';
wwv_flow_imp.g_varchar2_table(540) := 'ER@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start';
wwv_flow_imp.g_varchar2_table(541) := '_date, target_complete, status_id, status_last_changed_on, description, tags, display_sequence, impa';
wwv_flow_imp.g_varchar2_table(542) := 'ct, created, created_by, updated, updated_by) values (3066, 1007, ''Complete'', 26, null, 13, sp_util.';
wwv_flow_imp.g_varchar2_table(543) := 'fix_demo_dates(sysdate - 10), sp_util.fix_demo_dates(sysdate - 10), 14, sp_util.fix_demo_dates(sysda';
wwv_flow_imp.g_varchar2_table(544) := 'te - 10), ''Release scope accepted.'', ''milestone,complete'', 60, null, sp_util.fix_demo_dates(sysdate ';
wwv_flow_imp.g_varchar2_table(545) := '- 100), ''ISAAC.TURNER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''ISAAC.TURNER@ACME.COM'')'||wwv_flow.LF||
'  in';
wwv_flow_imp.g_varchar2_table(546) := 'to sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_comp';
wwv_flow_imp.g_varchar2_table(547) := 'lete, status_id, status_last_changed_on, description, tags, display_sequence, impact, created, creat';
wwv_flow_imp.g_varchar2_table(548) := 'ed_by, updated, updated_by) values (3071, 1008, ''Spec Complete'', 21, null, 16, sp_util.fix_demo_date';
wwv_flow_imp.g_varchar2_table(549) := 's(sysdate - 98), sp_util.fix_demo_dates(sysdate - 90), 14, sp_util.fix_demo_dates(sysdate - 90), ''Ap';
wwv_flow_imp.g_varchar2_table(550) := 'proved functional and technical design.'', ''milestone,spec'', 10, null, sp_util.fix_demo_dates(sysdate';
wwv_flow_imp.g_varchar2_table(551) := ' - 100), ''DOMINIC.REYES@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''MAYA.PATEL@ACME.COM'')'||wwv_flow.LF||
'  in';
wwv_flow_imp.g_varchar2_table(552) := 'to sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_comp';
wwv_flow_imp.g_varchar2_table(553) := 'lete, status_id, status_last_changed_on, description, tags, display_sequence, impact, created, creat';
wwv_flow_imp.g_varchar2_table(554) := 'ed_by, updated, updated_by) values (3072, 1008, ''Demonstrable'', 22, null, 16, sp_util.fix_demo_dates';
wwv_flow_imp.g_varchar2_table(555) := '(sysdate - 76), sp_util.fix_demo_dates(sysdate - 72), 14, sp_util.fix_demo_dates(sysdate - 72), ''Acc';
wwv_flow_imp.g_varchar2_table(556) := 'essible components demonstrated to stakeholders.'', ''milestone,demo'', 20, null, sp_util.fix_demo_date';
wwv_flow_imp.g_varchar2_table(557) := 's(sysdate - 100), ''DOMINIC.REYES@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''MAYA.PATEL@ACME.C';
wwv_flow_imp.g_varchar2_table(558) := 'OM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, ta';
wwv_flow_imp.g_varchar2_table(559) := 'rget_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, creat';
wwv_flow_imp.g_varchar2_table(560) := 'ed, created_by, updated, updated_by) values (3073, 1008, ''Code Complete'', 23, null, 15, sp_util.fix_';
wwv_flow_imp.g_varchar2_table(561) := 'demo_dates(sysdate - 50), sp_util.fix_demo_dates(sysdate - 45), 14, sp_util.fix_demo_dates(sysdate -';
wwv_flow_imp.g_varchar2_table(562) := ' 45), ''Implementation complete and unit tests passing.'', ''milestone,code'', 30, null, sp_util.fix_dem';
wwv_flow_imp.g_varchar2_table(563) := 'o_dates(sysdate - 100), ''DOMINIC.REYES@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''DOMINIC.REY';
wwv_flow_imp.g_varchar2_table(564) := 'ES@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start';
wwv_flow_imp.g_varchar2_table(565) := '_date, target_complete, status_id, status_last_changed_on, description, tags, display_sequence, impa';
wwv_flow_imp.g_varchar2_table(566) := 'ct, created, created_by, updated, updated_by) values (3074, 1008, ''Merged'', 24, null, 15, sp_util.fi';
wwv_flow_imp.g_varchar2_table(567) := 'x_demo_dates(sysdate - 39), sp_util.fix_demo_dates(sysdate - 35), 14, sp_util.fix_demo_dates(sysdate';
wwv_flow_imp.g_varchar2_table(568) := ' - 35), ''Changes merged to the release branch.'', ''milestone,merge'', 40, null, sp_util.fix_demo_dates';
wwv_flow_imp.g_varchar2_table(569) := '(sysdate - 100), ''DOMINIC.REYES@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''DOMINIC.REYES@ACME';
wwv_flow_imp.g_varchar2_table(570) := '.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, ';
wwv_flow_imp.g_varchar2_table(571) := 'target_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, cre';
wwv_flow_imp.g_varchar2_table(572) := 'ated, created_by, updated, updated_by) values (3075, 1008, ''Hosted'', 25, null, 16, sp_util.fix_demo_';
wwv_flow_imp.g_varchar2_table(573) := 'dates(sysdate - 25), sp_util.fix_demo_dates(sysdate - 20), 14, sp_util.fix_demo_dates(sysdate - 20),';
wwv_flow_imp.g_varchar2_table(574) := ' ''Deployed to the production hosting environment.'', ''milestone,hosting'', 50, null, sp_util.fix_demo_';
wwv_flow_imp.g_varchar2_table(575) := 'dates(sysdate - 100), ''DOMINIC.REYES@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''MAYA.PATEL@AC';
wwv_flow_imp.g_varchar2_table(576) := 'ME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date';
wwv_flow_imp.g_varchar2_table(577) := ', target_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, c';
wwv_flow_imp.g_varchar2_table(578) := 'reated, created_by, updated, updated_by) values (3076, 1008, ''Complete'', 26, null, 15, sp_util.fix_d';
wwv_flow_imp.g_varchar2_table(579) := 'emo_dates(sysdate - 16), sp_util.fix_demo_dates(sysdate - 16), 14, sp_util.fix_demo_dates(sysdate - ';
wwv_flow_imp.g_varchar2_table(580) := '16), ''Release scope accepted.'', ''milestone,complete'', 60, null, sp_util.fix_demo_dates(sysdate - 100';
wwv_flow_imp.g_varchar2_table(581) := '), ''DOMINIC.REYES@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''DOMINIC.REYES@ACME.COM'')'||wwv_flow.LF||
'  into ';
wwv_flow_imp.g_varchar2_table(582) := 'sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complet';
wwv_flow_imp.g_varchar2_table(583) := 'e, status_id, status_last_changed_on, description, tags, display_sequence, impact, created, created_';
wwv_flow_imp.g_varchar2_table(584) := 'by, updated, updated_by) values (3081, 1009, ''Spec Complete'', 21, null, 18, sp_util.fix_demo_dates(s';
wwv_flow_imp.g_varchar2_table(585) := 'ysdate - 98), sp_util.fix_demo_dates(sysdate - 90), 14, sp_util.fix_demo_dates(sysdate - 90), ''Appro';
wwv_flow_imp.g_varchar2_table(586) := 'ved functional and technical design.'', ''milestone,spec'', 10, null, sp_util.fix_demo_dates(sysdate - ';
wwv_flow_imp.g_varchar2_table(587) := '100), ''ETHAN.CALDWELL@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''VANESSA.CRUZ@ACME.COM'')'||wwv_flow.LF||
'  in';
wwv_flow_imp.g_varchar2_table(588) := 'to sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_comp';
wwv_flow_imp.g_varchar2_table(589) := 'lete, status_id, status_last_changed_on, description, tags, display_sequence, impact, created, creat';
wwv_flow_imp.g_varchar2_table(590) := 'ed_by, updated, updated_by) values (3082, 1009, ''Demonstrable'', 22, null, 18, sp_util.fix_demo_dates';
wwv_flow_imp.g_varchar2_table(591) := '(sysdate - 76), sp_util.fix_demo_dates(sysdate - 72), 14, sp_util.fix_demo_dates(sysdate - 72), ''Ana';
wwv_flow_imp.g_varchar2_table(592) := 'lytics dashboards demonstrated to stakeholders.'', ''milestone,demo'', 20, null, sp_util.fix_demo_dates';
wwv_flow_imp.g_varchar2_table(593) := '(sysdate - 100), ''ETHAN.CALDWELL@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''VANESSA.CRUZ@ACME';
wwv_flow_imp.g_varchar2_table(594) := '.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, ';
wwv_flow_imp.g_varchar2_table(595) := 'target_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, cre';
wwv_flow_imp.g_varchar2_table(596) := 'ated, created_by, updated, updated_by) values (3083, 1009, ''Code Complete'', 23, null, 17, sp_util.fi';
wwv_flow_imp.g_varchar2_table(597) := 'x_demo_dates(sysdate - 50), sp_util.fix_demo_dates(sysdate - 45), 14, sp_util.fix_demo_dates(sysdate';
wwv_flow_imp.g_varchar2_table(598) := ' - 45), ''Implementation complete and unit tests passing.'', ''milestone,code'', 30, null, sp_util.fix_d';
wwv_flow_imp.g_varchar2_table(599) := 'emo_dates(sysdate - 100), ''ETHAN.CALDWELL@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''ETHAN.CA';
wwv_flow_imp.g_varchar2_table(600) := 'LDWELL@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, s';
wwv_flow_imp.g_varchar2_table(601) := 'tart_date, target_complete, status_id, status_last_changed_on, description, tags, display_sequence, ';
wwv_flow_imp.g_varchar2_table(602) := 'impact, created, created_by, updated, updated_by) values (3084, 1009, ''Merged'', 24, null, 17, sp_uti';
wwv_flow_imp.g_varchar2_table(603) := 'l.fix_demo_dates(sysdate - 39), sp_util.fix_demo_dates(sysdate - 35), 14, sp_util.fix_demo_dates(sys';
wwv_flow_imp.g_varchar2_table(604) := 'date - 35), ''Changes merged to the release branch.'', ''milestone,merge'', 40, null, sp_util.fix_demo_d';
wwv_flow_imp.g_varchar2_table(605) := 'ates(sysdate - 100), ''ETHAN.CALDWELL@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''ETHAN.CALDWEL';
wwv_flow_imp.g_varchar2_table(606) := 'L@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_';
wwv_flow_imp.g_varchar2_table(607) := 'date, target_complete, status_id, status_last_changed_on, description, tags, display_sequence, impac';
wwv_flow_imp.g_varchar2_table(608) := 't, created, created_by, updated, updated_by) values (3085, 1009, ''Hosted'', 25, null, 18, sp_util.fix';
wwv_flow_imp.g_varchar2_table(609) := '_demo_dates(sysdate - 25), sp_util.fix_demo_dates(sysdate - 20), 14, sp_util.fix_demo_dates(sysdate ';
wwv_flow_imp.g_varchar2_table(610) := '- 20), ''Deployed to the production hosting environment.'', ''milestone,hosting'', 50, null, sp_util.fix';
wwv_flow_imp.g_varchar2_table(611) := '_demo_dates(sysdate - 100), ''ETHAN.CALDWELL@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''VANESS';
wwv_flow_imp.g_varchar2_table(612) := 'A.CRUZ@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, s';
wwv_flow_imp.g_varchar2_table(613) := 'tart_date, target_complete, status_id, status_last_changed_on, description, tags, display_sequence, ';
wwv_flow_imp.g_varchar2_table(614) := 'impact, created, created_by, updated, updated_by) values (3086, 1009, ''Complete'', 26, null, 17, sp_u';
wwv_flow_imp.g_varchar2_table(615) := 'til.fix_demo_dates(sysdate - 12), sp_util.fix_demo_dates(sysdate - 12), 14, sp_util.fix_demo_dates(s';
wwv_flow_imp.g_varchar2_table(616) := 'ysdate - 12), ''Release scope accepted.'', ''milestone,complete'', 60, null, sp_util.fix_demo_dates(sysd';
wwv_flow_imp.g_varchar2_table(617) := 'ate - 100), ''ETHAN.CALDWELL@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''ETHAN.CALDWELL@ACME.CO';
wwv_flow_imp.g_varchar2_table(618) := 'M'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, tar';
wwv_flow_imp.g_varchar2_table(619) := 'get_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, create';
wwv_flow_imp.g_varchar2_table(620) := 'd, created_by, updated, updated_by) values (3091, 1010, ''Spec Complete'', 21, null, 20, sp_util.fix_d';
wwv_flow_imp.g_varchar2_table(621) := 'emo_dates(sysdate - 98), sp_util.fix_demo_dates(sysdate - 90), 14, sp_util.fix_demo_dates(sysdate - ';
wwv_flow_imp.g_varchar2_table(622) := '90), ''Approved functional and technical design.'', ''milestone,spec'', 10, null, sp_util.fix_demo_dates';
wwv_flow_imp.g_varchar2_table(623) := '(sysdate - 100), ''LUCAS.BENNETT@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''AIDEN.CLARKE@ACME.';
wwv_flow_imp.g_varchar2_table(624) := 'COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, t';
wwv_flow_imp.g_varchar2_table(625) := 'arget_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, crea';
wwv_flow_imp.g_varchar2_table(626) := 'ted, created_by, updated, updated_by) values (3092, 1010, ''Demonstrable'', 22, null, 20, sp_util.fix_';
wwv_flow_imp.g_varchar2_table(627) := 'demo_dates(sysdate - 76), sp_util.fix_demo_dates(sysdate - 72), 14, sp_util.fix_demo_dates(sysdate -';
wwv_flow_imp.g_varchar2_table(628) := ' 72), ''Performance test results demonstrated to stakeholders.'', ''milestone,demo'', 20, null, sp_util.';
wwv_flow_imp.g_varchar2_table(629) := 'fix_demo_dates(sysdate - 100), ''LUCAS.BENNETT@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''AIDE';
wwv_flow_imp.g_varchar2_table(630) := 'N.CLARKE@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id,';
wwv_flow_imp.g_varchar2_table(631) := ' start_date, target_complete, status_id, status_last_changed_on, description, tags, display_sequence';
wwv_flow_imp.g_varchar2_table(632) := ', impact, created, created_by, updated, updated_by) values (3093, 1010, ''Code Complete'', 23, null, 1';
wwv_flow_imp.g_varchar2_table(633) := '9, sp_util.fix_demo_dates(sysdate - 50), sp_util.fix_demo_dates(sysdate - 45), 14, sp_util.fix_demo_';
wwv_flow_imp.g_varchar2_table(634) := 'dates(sysdate - 45), ''Implementation complete and unit tests passing.'', ''milestone,code'', 30, null, ';
wwv_flow_imp.g_varchar2_table(635) := 'sp_util.fix_demo_dates(sysdate - 100), ''LUCAS.BENNETT@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10';
wwv_flow_imp.g_varchar2_table(636) := '), ''LUCAS.BENNETT@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, ';
wwv_flow_imp.g_varchar2_table(637) := 'owner_id, start_date, target_complete, status_id, status_last_changed_on, description, tags, display';
wwv_flow_imp.g_varchar2_table(638) := '_sequence, impact, created, created_by, updated, updated_by) values (3094, 1010, ''Merged'', 24, null,';
wwv_flow_imp.g_varchar2_table(639) := ' 19, sp_util.fix_demo_dates(sysdate - 39), sp_util.fix_demo_dates(sysdate - 35), 14, sp_util.fix_dem';
wwv_flow_imp.g_varchar2_table(640) := 'o_dates(sysdate - 35), ''Changes merged to the release branch.'', ''milestone,merge'', 40, null, sp_util';
wwv_flow_imp.g_varchar2_table(641) := '.fix_demo_dates(sysdate - 100), ''LUCAS.BENNETT@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''LUC';
wwv_flow_imp.g_varchar2_table(642) := 'AS.BENNETT@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_i';
wwv_flow_imp.g_varchar2_table(643) := 'd, start_date, target_complete, status_id, status_last_changed_on, description, tags, display_sequen';
wwv_flow_imp.g_varchar2_table(644) := 'ce, impact, created, created_by, updated, updated_by) values (3095, 1010, ''Hosted'', 25, null, 20, sp';
wwv_flow_imp.g_varchar2_table(645) := '_util.fix_demo_dates(sysdate - 25), sp_util.fix_demo_dates(sysdate - 20), 14, sp_util.fix_demo_dates';
wwv_flow_imp.g_varchar2_table(646) := '(sysdate - 20), ''Deployed to the production hosting environment.'', ''milestone,hosting'', 50, null, sp';
wwv_flow_imp.g_varchar2_table(647) := '_util.fix_demo_dates(sysdate - 100), ''LUCAS.BENNETT@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10),';
wwv_flow_imp.g_varchar2_table(648) := ' ''AIDEN.CLARKE@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, own';
wwv_flow_imp.g_varchar2_table(649) := 'er_id, start_date, target_complete, status_id, status_last_changed_on, description, tags, display_se';
wwv_flow_imp.g_varchar2_table(650) := 'quence, impact, created, created_by, updated, updated_by) values (3096, 1010, ''Complete'', 26, null, ';
wwv_flow_imp.g_varchar2_table(651) := '19, sp_util.fix_demo_dates(sysdate - 10), sp_util.fix_demo_dates(sysdate - 10), 14, sp_util.fix_demo';
wwv_flow_imp.g_varchar2_table(652) := '_dates(sysdate - 10), ''Release scope accepted.'', ''milestone,complete'', 60, null, sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(653) := 'tes(sysdate - 100), ''LUCAS.BENNETT@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''LUCAS.BENNETT@A';
wwv_flow_imp.g_varchar2_table(654) := 'CME.COM'')'||wwv_flow.LF||
'select 1 from dual;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Completed reviews are also represented as tasks.  Status ID 8 is t';
wwv_flow_imp.g_varchar2_table(655) := 'he supplied'||wwv_flow.LF||
'-- review status value for Completed.'||wwv_flow.LF||
'insert all'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, ';
wwv_flow_imp.g_varchar2_table(656) := 'task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_change';
wwv_flow_imp.g_varchar2_table(657) := 'd_on, description, tags, display_sequence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    val';
wwv_flow_imp.g_varchar2_table(658) := 'ues (4001, 1001, ''Account Overview Functional Spec Review'', 2, null, 8, sp_util.fix_demo_dates(sysda';
wwv_flow_imp.g_varchar2_table(659) := 'te - 88), sp_util.fix_demo_dates(sysdate - 84), 8, sp_util.fix_demo_dates(sysdate - 84), ''Functional';
wwv_flow_imp.g_varchar2_table(660) := ' specification approved with the account-card scope decision.'', ''review,functional-spec'', 15, ''Mediu';
wwv_flow_imp.g_varchar2_table(661) := 'm'', sp_util.fix_demo_dates(sysdate - 100), ''SCOTT.TIGER@ACME.COM'', sp_util.fix_demo_dates(sysdate - ';
wwv_flow_imp.g_varchar2_table(662) := '10), ''LILA.MONTGOMERY@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_';
wwv_flow_imp.g_varchar2_table(663) := 'id, owner_id, start_date, target_complete, status_id, status_last_changed_on, description, tags, dis';
wwv_flow_imp.g_varchar2_table(664) := 'play_sequence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (4002, 1002, ''Service Re';
wwv_flow_imp.g_varchar2_table(665) := 'quest Spec Review'', 3, null, 6, sp_util.fix_demo_dates(sysdate - 86), sp_util.fix_demo_dates(sysdate';
wwv_flow_imp.g_varchar2_table(666) := ' - 80), 8, sp_util.fix_demo_dates(sysdate - 80), ''Request data model and routing rules approved.'', ''';
wwv_flow_imp.g_varchar2_table(667) := 'review,spec'', 15, ''High'', sp_util.fix_demo_dates(sysdate - 100), ''ELENA.VARGAS@ACME.COM'', sp_util.fi';
wwv_flow_imp.g_varchar2_table(668) := 'x_demo_dates(sysdate - 10), ''JORDAN.AVERY@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_typ';
wwv_flow_imp.g_varchar2_table(669) := 'e_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_changed_on, de';
wwv_flow_imp.g_varchar2_table(670) := 'scription, tags, display_sequence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (400';
wwv_flow_imp.g_varchar2_table(671) := '3, 1003, ''Document Center Peer Review'', 4, null, 6, sp_util.fix_demo_dates(sysdate - 50), sp_util.fi';
wwv_flow_imp.g_varchar2_table(672) := 'x_demo_dates(sysdate - 44), 8, sp_util.fix_demo_dates(sysdate - 44), ''Peer review completed for secu';
wwv_flow_imp.g_varchar2_table(673) := 're document retrieval and audit events.'', ''review,peer'', 35, ''Medium'', sp_util.fix_demo_dates(sysdat';
wwv_flow_imp.g_varchar2_table(674) := 'e - 100), ''NAOMI.CHEN@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''JORDAN.AVERY@ACME.COM'')'||wwv_flow.LF||
'  in';
wwv_flow_imp.g_varchar2_table(675) := 'to sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_comp';
wwv_flow_imp.g_varchar2_table(676) := 'lete, status_id, status_last_changed_on, description, tags, display_sequence, impact, created, creat';
wwv_flow_imp.g_varchar2_table(677) := 'ed_by, updated, updated_by)'||wwv_flow.LF||
'    values (4004, 1004, ''Billing and Payments Security Review'', 5, null,';
wwv_flow_imp.g_varchar2_table(678) := ' 8, sp_util.fix_demo_dates(sysdate - 48), sp_util.fix_demo_dates(sysdate - 42), 8, sp_util.fix_demo_';
wwv_flow_imp.g_varchar2_table(679) := 'dates(sysdate - 42), ''Security controls accepted with payment processing remaining external.'', ''revi';
wwv_flow_imp.g_varchar2_table(680) := 'ew,security'', 35, ''High'', sp_util.fix_demo_dates(sysdate - 100), ''CALEB.FOSTER@ACME.COM'', sp_util.fi';
wwv_flow_imp.g_varchar2_table(681) := 'x_demo_dates(sysdate - 10), ''LILA.MONTGOMERY@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_';
wwv_flow_imp.g_varchar2_table(682) := 'type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_changed_on,';
wwv_flow_imp.g_varchar2_table(683) := ' description, tags, display_sequence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (';
wwv_flow_imp.g_varchar2_table(684) := '4005, 1005, ''AI Support Assistant Product Management Review'', 7, null, 10, sp_util.fix_demo_dates(sy';
wwv_flow_imp.g_varchar2_table(685) := 'sdate - 55), sp_util.fix_demo_dates(sysdate - 49), 8, sp_util.fix_demo_dates(sysdate - 49), ''Product';
wwv_flow_imp.g_varchar2_table(686) := ' management approved knowledge grounding and human handoff behavior.'', ''review,product-management,ai';
wwv_flow_imp.g_varchar2_table(687) := ''', 25, ''High'', sp_util.fix_demo_dates(sysdate - 100), ''ANDRE.COLLINS@ACME.COM'', sp_util.fix_demo_dat';
wwv_flow_imp.g_varchar2_table(688) := 'es(sysdate - 10), ''SOPHIE.BENNETT@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, ta';
wwv_flow_imp.g_varchar2_table(689) := 'sk_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_changed_on, descriptio';
wwv_flow_imp.g_varchar2_table(690) := 'n, tags, display_sequence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (4006, 1006,';
wwv_flow_imp.g_varchar2_table(691) := ' ''Notification Preferences Documentation Review'', 8, null, 12, sp_util.fix_demo_dates(sysdate - 30),';
wwv_flow_imp.g_varchar2_table(692) := ' sp_util.fix_demo_dates(sysdate - 24), 8, sp_util.fix_demo_dates(sysdate - 24), ''Consent language an';
wwv_flow_imp.g_varchar2_table(693) := 'd customer help content approved.'', ''review,documentation'', 45, ''Medium'', sp_util.fix_demo_dates(sys';
wwv_flow_imp.g_varchar2_table(694) := 'date - 100), ''VICTOR.RAMIREZ@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''HANNAH.DOYLE@ACME.COM';
wwv_flow_imp.g_varchar2_table(695) := ''')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, targ';
wwv_flow_imp.g_varchar2_table(696) := 'et_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, created';
wwv_flow_imp.g_varchar2_table(697) := ', created_by, updated, updated_by)'||wwv_flow.LF||
'    values (4007, 1007, ''Identity and Access Security Review'', 5,';
wwv_flow_imp.g_varchar2_table(698) := ' null, 16, sp_util.fix_demo_dates(sysdate - 49), sp_util.fix_demo_dates(sysdate - 43), 8, sp_util.fi';
wwv_flow_imp.g_varchar2_table(699) := 'x_demo_dates(sysdate - 43), ''Threat model, MFA, and recovery controls approved.'', ''review,security,i';
wwv_flow_imp.g_varchar2_table(700) := 'dentity'', 35, ''High'', sp_util.fix_demo_dates(sysdate - 100), ''ISAAC.TURNER@ACME.COM'', sp_util.fix_de';
wwv_flow_imp.g_varchar2_table(701) := 'mo_dates(sysdate - 10), ''MAYA.PATEL@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, ';
wwv_flow_imp.g_varchar2_table(702) := 'task_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_changed_on, descript';
wwv_flow_imp.g_varchar2_table(703) := 'ion, tags, display_sequence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (4008, 100';
wwv_flow_imp.g_varchar2_table(704) := '8, ''Accessibility Foundation Accessibility Review'', 6, null, 18, sp_util.fix_demo_dates(sysdate - 47';
wwv_flow_imp.g_varchar2_table(705) := '), sp_util.fix_demo_dates(sysdate - 4), 8, sp_util.fix_demo_dates(sysdate - 41), ''Shared components ';
wwv_flow_imp.g_varchar2_table(706) := 'validated against the agreed accessibility baseline.'', ''review,accessibility'', 35, ''High'', sp_util.f';
wwv_flow_imp.g_varchar2_table(707) := 'ix_demo_dates(sysdate - 100), ''DOMINIC.REYES@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''VANES';
wwv_flow_imp.g_varchar2_table(708) := 'SA.CRUZ@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, ';
wwv_flow_imp.g_varchar2_table(709) := 'start_date, target_complete, status_id, status_last_changed_on, description, tags, display_sequence,';
wwv_flow_imp.g_varchar2_table(710) := ' impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (4009, 1009, ''Analytics Instrumentatio';
wwv_flow_imp.g_varchar2_table(711) := 'n Functional Testing Review'', 9, null, 18, sp_util.fix_demo_dates(sysdate - 25), sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(712) := 'tes(sysdate - 19), 8, sp_util.fix_demo_dates(sysdate - 19), ''Event payloads, dashboard totals, and p';
wwv_flow_imp.g_varchar2_table(713) := 'rivacy controls validated.'', ''review,functional-testing,analytics'', 55, ''Medium'', sp_util.fix_demo_d';
wwv_flow_imp.g_varchar2_table(714) := 'ates(sysdate - 100), ''ETHAN.CALDWELL@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''VANESSA.CRUZ@';
wwv_flow_imp.g_varchar2_table(715) := 'ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_da';
wwv_flow_imp.g_varchar2_table(716) := 'te, target_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact,';
wwv_flow_imp.g_varchar2_table(717) := ' created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (4010, 1010, ''Performance and Resilience Imple';
wwv_flow_imp.g_varchar2_table(718) := 'mentation Review'', 11, null, 20, sp_util.fix_demo_dates(sysdate - 21), sp_util.fix_demo_dates(sysdat';
wwv_flow_imp.g_varchar2_table(719) := 'e - 17), 8, sp_util.fix_demo_dates(sysdate - 17), ''Load test results and rollback procedures approve';
wwv_flow_imp.g_varchar2_table(720) := 'd before code freeze.'', ''review,implementation,performance'', 55, ''High'', sp_util.fix_demo_dates(sysd';
wwv_flow_imp.g_varchar2_table(721) := 'ate - 100), ''LUCAS.BENNETT@ACME.COM'', sp_util.fix_demo_dates(sysdate - 10), ''AIDEN.CLARKE@ACME.COM'')';
wwv_flow_imp.g_varchar2_table(722) := ''||wwv_flow.LF||
'select 1 from dual;'||wwv_flow.LF||
''||wwv_flow.LF||
'sp_globals.g_audit_this := TRUE;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        sp_gl';
wwv_flow_imp.g_varchar2_table(723) := 'obals.g_audit_this := TRUE;'||wwv_flow.LF||
'end;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(453315159625485430)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sample data - cust hub 1.0'
,p_sequence=>9240
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
