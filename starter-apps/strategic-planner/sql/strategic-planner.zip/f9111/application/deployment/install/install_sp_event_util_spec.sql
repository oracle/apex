prompt --application/deployment/install/install_sp_event_util_spec
begin
--   Manifest
--     INSTALL: INSTALL-sp_event_util spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package sp_event_util'||wwv_flow.LF||
'as '||wwv_flow.LF||
''||wwv_flow.LF||
'procedure create_event ( '||wwv_flow.LF||
'    p_event_type_id    number';
wwv_flow_imp.g_varchar2_table(2) := ', '||wwv_flow.LF||
'    p_event_date       timestamp with time zone, '||wwv_flow.LF||
'    p_event_name       varchar2, '||wwv_flow.LF||
'    p_for_use';
wwv_flow_imp.g_varchar2_table(3) := 'r_id      number, '||wwv_flow.LF||
'    p_event_details    varchar2, '||wwv_flow.LF||
'    p_recur_freq       varchar2, '||wwv_flow.LF||
'    p_recur_e';
wwv_flow_imp.g_varchar2_table(4) := 'nd_date   timestamp with time zone ); '||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_event ( '||wwv_flow.LF||
'    p_event_id        number, '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(5) := ' p_delete_type     varchar2 ); -- ONLY, ALL, FUTURE (usually ONLY  if not series)'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_';
wwv_flow_imp.g_varchar2_table(6) := 'event ( '||wwv_flow.LF||
'    p_event_id         number, '||wwv_flow.LF||
'    p_event_type_id    number, '||wwv_flow.LF||
'    p_event_date       time';
wwv_flow_imp.g_varchar2_table(7) := 'stamp with time zone, '||wwv_flow.LF||
'    p_event_name       varchar2, '||wwv_flow.LF||
'    p_for_user_id      number,'||wwv_flow.LF||
'    p_event_';
wwv_flow_imp.g_varchar2_table(8) := 'details    varchar2, '||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    p_recur_freq       varchar2, '||wwv_flow.LF||
'    p_recur_end_date   timestamp wit';
wwv_flow_imp.g_varchar2_table(9) := 'h time zone, '||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    p_update_type      varchar2 ); -- ONLY, ALL, FUTURE (usually ONLY if not s';
wwv_flow_imp.g_varchar2_table(10) := 'eries)'||wwv_flow.LF||
''||wwv_flow.LF||
'-----------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'function days_out_summary ('||wwv_flow.LF||
'    p_user_id      in  number'||wwv_flow.LF||
') return ';
wwv_flow_imp.g_varchar2_table(11) := 'varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function days_out ('||wwv_flow.LF||
'    p_user_id      in  number'||wwv_flow.LF||
') return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure load_one_';
wwv_flow_imp.g_varchar2_table(12) := 'ooo ('||wwv_flow.LF||
'    p_team_member_id  in   number,'||wwv_flow.LF||
'    p_updated_yn      out  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure load_all_';
wwv_flow_imp.g_varchar2_table(13) := 'ooo;'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_event_util;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(35718285008999167411)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_event_util spec'
,p_sequence=>2100
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
