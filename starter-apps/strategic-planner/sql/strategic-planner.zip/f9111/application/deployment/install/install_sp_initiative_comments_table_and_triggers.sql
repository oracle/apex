prompt --application/deployment/install/install_sp_initiative_comments_table_and_triggers
begin
--   Manifest
--     INSTALL: INSTALL-sp_initiative_comments table and triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_initiative_comments ('||wwv_flow.LF||
'    id                             number default on null to_n';
wwv_flow_imp.g_varchar2_table(2) := 'umber(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint';
wwv_flow_imp.g_varchar2_table(3) := ' sp_initiative_comments_pk primary key,'||wwv_flow.LF||
'    initiative_id                  number'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(4) := '                 constraint sp_initiative_commments_fk'||wwv_flow.LF||
'                                   references';
wwv_flow_imp.g_varchar2_table(5) := ' sp_initiatives (id)'||wwv_flow.LF||
'                                   on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    comment_nbr   ';
wwv_flow_imp.g_varchar2_table(6) := '                 number,'||wwv_flow.LF||
'    body                           clob,'||wwv_flow.LF||
'    body_html                     ';
wwv_flow_imp.g_varchar2_table(7) := ' clob,'||wwv_flow.LF||
'    body_no_images                 clob,'||wwv_flow.LF||
'    image_ref_id                   number,'||wwv_flow.LF||
'    autho';
wwv_flow_imp.g_varchar2_table(8) := 'r_id                      number,'||wwv_flow.LF||
'    private_yn                     varchar2(1 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    cr';
wwv_flow_imp.g_varchar2_table(9) := 'eated                        date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) no';
wwv_flow_imp.g_varchar2_table(10) := 't null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by                     varchar';
wwv_flow_imp.g_varchar2_table(11) := '2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_initiative_comments_i1 on sp_initiative_comments (initiativ';
wwv_flow_imp.g_varchar2_table(12) := 'e_id);'||wwv_flow.LF||
'create index sp_initiative_comments_i2 on sp_initiative_comments (author_id);'||wwv_flow.LF||
'create index sp';
wwv_flow_imp.g_varchar2_table(13) := '_initiative_comments_i3 on sp_initiative_comments (image_ref_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_init';
wwv_flow_imp.g_varchar2_table(14) := 'iative_comments_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_initiative_comments'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin';
wwv_flow_imp.g_varchar2_table(15) := ''||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by';
wwv_flow_imp.g_varchar2_table(16) := ' := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.update';
wwv_flow_imp.g_varchar2_table(17) := 'd    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(sys_cont';
wwv_flow_imp.g_varchar2_table(18) := 'ext(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(19) := '       :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(20) := '    if :new.private_yn is null then '||wwv_flow.LF||
'        :new.private_yn := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inser';
wwv_flow_imp.g_varchar2_table(21) := 'ting then'||wwv_flow.LF||
'        for c1 in (select nvl(max(comment_nbr),0) cnbr from sp_initiative_comments where i';
wwv_flow_imp.g_varchar2_table(22) := 'nitiative_id = :new.initiative_id)'||wwv_flow.LF||
'        loop :new.comment_nbr := c1.cnbr+1; end loop;'||wwv_flow.LF||
'    end if;';
wwv_flow_imp.g_varchar2_table(23) := ''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if sp_globals.g_audit_this then'||wwv_flow.LF||
'        update sp_initi';
wwv_flow_imp.g_varchar2_table(24) := 'atives set updated = sysdate, updated_by = :new.updated_by where id = :new.initiative_id;'||wwv_flow.LF||
'    end if';
wwv_flow_imp.g_varchar2_table(25) := ';'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    if inserting and :new.private_yn = ''N'' then'||wwv_flow.LF||
'        insert into sp_initiative_h';
wwv_flow_imp.g_varchar2_table(26) := 'istory'||wwv_flow.LF||
'            (initiative_id, attribute_column, change_type, new_value, new_value_clob, changed';
wwv_flow_imp.g_varchar2_table(27) := '_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.initiative_id, ''COMMENT'', ''CREATE'', dbms_lob.subst';
wwv_flow_imp.g_varchar2_table(28) := 'r(:new.body_no_images,500,1), :new.body_no_images, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'     elsif upda';
wwv_flow_imp.g_varchar2_table(29) := 'ting and :old.private_yn = ''N'' and :new.private_yn = ''N'' then'||wwv_flow.LF||
'        if not sp_value_compare.is_equ';
wwv_flow_imp.g_varchar2_table(30) := 'al(:old.body_no_images,:new.body_no_images) then'||wwv_flow.LF||
'            insert into sp_initiative_history'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(31) := '           (initiative_id, attribute_column, change_type, old_value, new_value, old_value_clob, new_';
wwv_flow_imp.g_varchar2_table(32) := 'value_clob, changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.initiative_id, ''COMMENT';
wwv_flow_imp.g_varchar2_table(33) := ''', ''UPDATE'', dbms_lob.substr(:old.body_no_images,500,1), dbms_lob.substr(:new.body_no_images,1), :ol';
wwv_flow_imp.g_varchar2_table(34) := 'd.body_no_images, :new.body_no_images, sysdate, lower(:new.updated_by));'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;';
wwv_flow_imp.g_varchar2_table(35) := ''||wwv_flow.LF||
'end sp_initiative_comments_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_initiative_comments_bd'||wwv_flow.LF||
'    before d';
wwv_flow_imp.g_varchar2_table(36) := 'elete'||wwv_flow.LF||
'    on sp_initiative_comments'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :old.private_yn = ''N'' then'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(37) := '    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_initiatives set updated = sysdate, updated_by = :old.';
wwv_flow_imp.g_varchar2_table(38) := 'updated_by where id = :old.initiative_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    insert into sp_initiative_history'||wwv_flow.LF||
'        (init';
wwv_flow_imp.g_varchar2_table(39) := 'iative_id, attribute_column, change_type, old_value, old_value_clob, changed_on, changed_by)'||wwv_flow.LF||
'    val';
wwv_flow_imp.g_varchar2_table(40) := 'ues'||wwv_flow.LF||
'        (:old.initiative_id, ''COMMENT'', ''DELETE'', dbms_lob.substr(:old.body_no_images,500,1), :o';
wwv_flow_imp.g_varchar2_table(41) := 'ld.body_no_images, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'    end i';
wwv_flow_imp.g_varchar2_table(42) := 'f;'||wwv_flow.LF||
'end sp_initiative_comments_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(41595058009512786846)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_initiative_comments table and triggers'
,p_sequence=>3460
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
