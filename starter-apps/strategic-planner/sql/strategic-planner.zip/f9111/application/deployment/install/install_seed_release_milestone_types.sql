prompt --application/deployment/install/install_seed_release_milestone_types
begin
--   Manifest
--     INSTALL: INSTALL-seed release_milestone_types
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into sp_release_milestone_types (id, milestone_type, display_seq, calendar_event_color)'||wwv_flow.LF||
'    v';
wwv_flow_imp.g_varchar2_table(2) := 'alues (1, ''Build'', 1, ''blue'');'||wwv_flow.LF||
'insert into sp_release_milestone_types (id, milestone_type, display_s';
wwv_flow_imp.g_varchar2_table(3) := 'eq, calendar_event_color)'||wwv_flow.LF||
'    values (2, ''Doc'', 2, ''silver'');'||wwv_flow.LF||
'insert into sp_release_milestone_types';
wwv_flow_imp.g_varchar2_table(4) := ' (id, milestone_type, display_seq, calendar_event_color)'||wwv_flow.LF||
'    values (3, ''Milestone'', 3, ''green'');'||wwv_flow.LF||
'in';
wwv_flow_imp.g_varchar2_table(5) := 'sert into sp_release_milestone_types (id, milestone_type, display_seq, calendar_event_color)'||wwv_flow.LF||
'    val';
wwv_flow_imp.g_varchar2_table(6) := 'ues (4, ''PSE'', 4, ''darkblue'');'||wwv_flow.LF||
'insert into sp_release_milestone_types (id, milestone_type, display_s';
wwv_flow_imp.g_varchar2_table(7) := 'eq, calendar_event_color)'||wwv_flow.LF||
'    values (5, ''Translation Drop'', 5, ''cyan'');'||wwv_flow.LF||
'insert into sp_release_mile';
wwv_flow_imp.g_varchar2_table(8) := 'stone_types (id, milestone_type, display_seq, calendar_event_color)'||wwv_flow.LF||
'    values (6, ''Upgrade'', 6, ''or';
wwv_flow_imp.g_varchar2_table(9) := 'ange'');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(43085096754055875745)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed release_milestone_types'
,p_sequence=>9100
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
