prompt --application/deployment/install/install_sp_event_types_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_event_types table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_event_types ('||wwv_flow.LF||
'    id                        number'||wwv_flow.LF||
'                                 ';
wwv_flow_imp.g_varchar2_table(2) := ' default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(3) := '          constraint sp_event_types_pk primary key,'||wwv_flow.LF||
'    event_type                varchar2(60)   not';
wwv_flow_imp.g_varchar2_table(4) := ' null  '||wwv_flow.LF||
'                                  constraint sp_event_types_uk unique,'||wwv_flow.LF||
'    general_event_yn ';
wwv_flow_imp.g_varchar2_table(5) := '         varchar2(1) default on null ''N'''||wwv_flow.LF||
'                                  constraint sp_event_types';
wwv_flow_imp.g_varchar2_table(6) := '_general_event_cc'||wwv_flow.LF||
'                                  check (general_event_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(7) := '  calendar_event_color      varchar2(30),'||wwv_flow.LF||
'    icon_class                varchar2(30),'||wwv_flow.LF||
'    quick_pick';
wwv_flow_imp.g_varchar2_table(8) := '_yn             varchar2(1) default on null ''N'''||wwv_flow.LF||
'                                  constraint sp_even';
wwv_flow_imp.g_varchar2_table(9) := 't_types_quick_pick_cc'||wwv_flow.LF||
'                                  check (quick_pick_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    acti';
wwv_flow_imp.g_varchar2_table(10) := 've_yn                 varchar2(1) default on null ''Y'''||wwv_flow.LF||
'                                  constraint s';
wwv_flow_imp.g_varchar2_table(11) := 'p_event_types_active_cc'||wwv_flow.LF||
'                                  check (active_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(12) := ' created                   date            not null,'||wwv_flow.LF||
'    created_by                varchar2(255)   n';
wwv_flow_imp.g_varchar2_table(13) := 'ot null,'||wwv_flow.LF||
'    updated                   date            not null,'||wwv_flow.LF||
'    updated_by                varch';
wwv_flow_imp.g_varchar2_table(14) := 'ar2(255)   not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_event_types_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(15) := ' on sp_event_types'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.';
wwv_flow_imp.g_varchar2_table(16) := 'created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION';
wwv_flow_imp.g_varchar2_table(17) := ''',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by ';
wwv_flow_imp.g_varchar2_table(18) := ':= nvl(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating t';
wwv_flow_imp.g_varchar2_table(19) := 'hen'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSIO';
wwv_flow_imp.g_varchar2_table(20) := 'N'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_event_types_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(35718630793100190181)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_event_types table and trigger'
,p_sequence=>3080
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
