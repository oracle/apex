prompt --application/deployment/install/install_sp_notifications_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_notifications table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_notifications ('||wwv_flow.LF||
'    id                             number default on null to_number(';
wwv_flow_imp.g_varchar2_table(2) := 'sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_no';
wwv_flow_imp.g_varchar2_table(3) := 'tifications_id_pk primary key,'||wwv_flow.LF||
''||wwv_flow.LF||
'    name                           varchar2(150 char)  not null,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(4) := ' static_id                      varchar2(30 char)   not null,'||wwv_flow.LF||
'    description                    var';
wwv_flow_imp.g_varchar2_table(5) := 'char2(4000 char) not null,'||wwv_flow.LF||
'    is_active_yn                   varchar2(1 char)    not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(6) := '   created                        date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 cha';
wwv_flow_imp.g_varchar2_table(7) := 'r) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by                     va';
wwv_flow_imp.g_varchar2_table(8) := 'rchar2(255 char) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index sp_notifications_u1 on sp_notifications(name);'||wwv_flow.LF||
''||wwv_flow.LF||
'c';
wwv_flow_imp.g_varchar2_table(9) := 'reate or replace trigger sp_notifications_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_notifications'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(10) := '  for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(11) := '     :new.created_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));';
wwv_flow_imp.g_varchar2_table(12) := ''||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_b';
wwv_flow_imp.g_varchar2_table(13) := 'y, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.upda';
wwv_flow_imp.g_varchar2_table(14) := 'ted    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);';
wwv_flow_imp.g_varchar2_table(15) := ''||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.static_id := upper(:new.static_id);'||wwv_flow.LF||
'end sp_notifications_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(40984528927197905540)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_notifications table and trigger'
,p_sequence=>3380
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
