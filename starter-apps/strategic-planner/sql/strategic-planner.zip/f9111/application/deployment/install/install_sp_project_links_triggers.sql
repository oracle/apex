prompt --application/deployment/install/install_sp_project_links_triggers
begin
--   Manifest
--     INSTALL: INSTALL-sp_project_links triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_project_links_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_project_links'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(2) := '   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(3) := '      :new.created_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user))';
wwv_flow_imp.g_varchar2_table(4) := ';'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_';
wwv_flow_imp.g_varchar2_table(5) := 'by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.upd';
wwv_flow_imp.g_varchar2_table(6) := 'ated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)';
wwv_flow_imp.g_varchar2_table(7) := ';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if sp_globals.g_audit_this then'||wwv_flow.LF||
'        up';
wwv_flow_imp.g_varchar2_table(8) := 'date sp_projects set updated = sysdate, updated_by = :new.updated_by where id = :new.project_id;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(9) := ' end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'       if :new.project_id is not null th';
wwv_flow_imp.g_varchar2_table(10) := 'en'||wwv_flow.LF||
'           insert into sp_project_history'||wwv_flow.LF||
'               (project_id, attribute_column, change_ty';
wwv_flow_imp.g_varchar2_table(11) := 'pe, new_value, changed_on, changed_by)'||wwv_flow.LF||
'           values'||wwv_flow.LF||
'               (:new.project_id, ''LINK'', ''C';
wwv_flow_imp.g_varchar2_table(12) := 'REATE'', :new.link_url, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'       elsif updating then'||wwv_flow.LF||
'          if not';
wwv_flow_imp.g_varchar2_table(13) := ' sp_value_compare.is_equal(:old.link_url,:new.link_url) then'||wwv_flow.LF||
'              insert into sp_project_hi';
wwv_flow_imp.g_varchar2_table(14) := 'story'||wwv_flow.LF||
'                  (project_id, attribute_column, change_type, old_value, new_value,changed_on,';
wwv_flow_imp.g_varchar2_table(15) := ' changed_by)'||wwv_flow.LF||
'              values'||wwv_flow.LF||
'                  (:new.project_id, ''LINK'', ''UPDATE'', :old.link_ur';
wwv_flow_imp.g_varchar2_table(16) := 'l, :new.link_url, sysdate, lower(:new.updated_by));'||wwv_flow.LF||
'          end if;'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end';
wwv_flow_imp.g_varchar2_table(17) := ' sp_project_links_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_project_links_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_';
wwv_flow_imp.g_varchar2_table(18) := 'project_links'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :old.project_id is not null then'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        -- t';
wwv_flow_imp.g_varchar2_table(19) := 'ouch parent table'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        update sp_projects set updated = sysdate, updated_by = :old.upd';
wwv_flow_imp.g_varchar2_table(20) := 'ated_by where id = :old.project_id;'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        insert into sp_project_history'||wwv_flow.LF||
'            (p';
wwv_flow_imp.g_varchar2_table(21) := 'roject_id, attribute_column, change_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(22) := '    (:old.project_id, ''LINK'', ''DELETE'', :old.link_url, sysdate, lower(coalesce(sys_context(''APEX$SES';
wwv_flow_imp.g_varchar2_table(23) := 'SION'',''APP_USER''),user)));'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_project_links_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38224458835426696105)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_project_links triggers'
,p_sequence=>4130
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
