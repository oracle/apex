prompt --application/deployment/install/install_sp_value_compare_spec
begin
--   Manifest
--     INSTALL: INSTALL-sp_value_compare spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package sp_value_compare'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Determine if two values are equal or not regardless o';
wwv_flow_imp.g_varchar2_table(2) := 'f their nullness'||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- In Oracle, to handle comparison with NULL values, you need to use the followi';
wwv_flow_imp.g_varchar2_table(3) := 'ng Oracle operators: '||wwv_flow.LF||
'-- IS NULL     the logical operation = NULL'||wwv_flow.LF||
'-- IS NOT NULL the logical operati';
wwv_flow_imp.g_varchar2_table(4) := 'on != NULL'||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- for use in database triggers for columns that can be null'||wwv_flow.LF||
'-- you can ue is_equal to';
wwv_flow_imp.g_varchar2_table(5) := ' compare two columns regardless of null values'||wwv_flow.LF||
'--'||wwv_flow.LF||
'as'||wwv_flow.LF||
''||wwv_flow.LF||
'function is_equal ('||wwv_flow.LF||
'   p_value1     in varchar';
wwv_flow_imp.g_varchar2_table(6) := '2 default null,'||wwv_flow.LF||
'   p_value2     in varchar2 default null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return boolean;'||wwv_flow.LF||
''||wwv_flow.LF||
'function is_equal ';
wwv_flow_imp.g_varchar2_table(7) := '('||wwv_flow.LF||
'   p_value1     in date default null,'||wwv_flow.LF||
'   p_value2     in date default null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return boolean;';
wwv_flow_imp.g_varchar2_table(8) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'function is_equal ('||wwv_flow.LF||
'   p_value1     in timestamp default null,'||wwv_flow.LF||
'   p_value2     in timestamp defaul';
wwv_flow_imp.g_varchar2_table(9) := 't null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return boolean;'||wwv_flow.LF||
''||wwv_flow.LF||
'function is_equal ('||wwv_flow.LF||
'   p_value1     in clob default null,'||wwv_flow.LF||
'   p_value';
wwv_flow_imp.g_varchar2_table(10) := '2     in clob default null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return boolean;'||wwv_flow.LF||
''||wwv_flow.LF||
'--function is_equal ('||wwv_flow.LF||
'--   p_value1     in blob ';
wwv_flow_imp.g_varchar2_table(11) := 'default null,'||wwv_flow.LF||
'--   p_value2     in blob default null'||wwv_flow.LF||
'--   )'||wwv_flow.LF||
'--   return boolean;'||wwv_flow.LF||
''||wwv_flow.LF||
'function is_equal ';
wwv_flow_imp.g_varchar2_table(12) := '('||wwv_flow.LF||
'   p_value1     in number default null,'||wwv_flow.LF||
'   p_value2     in number default null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return bool';
wwv_flow_imp.g_varchar2_table(13) := 'ean;'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_value_compare;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(63884275154837728713)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_value_compare spec'
,p_sequence=>2030
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
