prompt --application/deployment/install/install_sp_log_spec
begin
--   Manifest
--     INSTALL: INSTALL-sp_log spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package sp_log'||wwv_flow.LF||
'as '||wwv_flow.LF||
'procedure log_interaction (p_project_id in number);'||wwv_flow.LF||
'function  l';
wwv_flow_imp.g_varchar2_table(2) := 'og_and_summarize (p_project_id in number) return varchar2;'||wwv_flow.LF||
'end sp_log;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(35717605280753760517)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_log spec'
,p_sequence=>2020
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
