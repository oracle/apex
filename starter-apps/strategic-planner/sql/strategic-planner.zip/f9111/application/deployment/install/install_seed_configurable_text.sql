prompt --application/deployment/install/install_seed_configurable_text
begin
--   Manifest
--     INSTALL: INSTALL-seed configurable text
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into sp_configurable_text (id, config_id, description, configurable_content) '||wwv_flow.LF||
'values (1, ''ABO';
wwv_flow_imp.g_varchar2_table(2) := 'UT-PRIMARY-TEXT'',''Primary text displayed on application about page.'','||wwv_flow.LF||
'''**Strategic Planner Applicati';
wwv_flow_imp.g_varchar2_table(3) := 'on** '||wwv_flow.LF||
''||wwv_flow.LF||
'This application is a tool to identify and track projects. '||wwv_flow.LF||
''||wwv_flow.LF||
'The goal of this application is ';
wwv_flow_imp.g_varchar2_table(4) := 'provide a coherent view over many projects with contributions from many individuals. '||wwv_flow.LF||
''||wwv_flow.LF||
'**Application';
wwv_flow_imp.g_varchar2_table(5) := ' Capabilities** '||wwv_flow.LF||
'* Manage releases, staff assignments, and release progress '||wwv_flow.LF||
'* Manage your backlog; ';
wwv_flow_imp.g_varchar2_table(6) := 'ensure your prioritized efforts are progressing '||wwv_flow.LF||
'* Provide a common place to share comments, links, ';
wwv_flow_imp.g_varchar2_table(7) := 'documents, and images '||wwv_flow.LF||
'* Provides a uniform configurable way of tracking status using standardized p';
wwv_flow_imp.g_varchar2_table(8) := 'ercent complete milestones'||wwv_flow.LF||
'* Customizable Nomenclature'');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(283538628411395153)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed configurable text'
,p_sequence=>9012
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
