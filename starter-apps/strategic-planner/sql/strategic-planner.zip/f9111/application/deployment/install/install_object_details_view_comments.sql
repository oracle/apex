prompt --application/deployment/install/install_object_details_view_comments
begin
--   Manifest
--     INSTALL: INSTALL-object details view comments
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'comment on table SP_AREA_DETAILS_V is ''Details about Areas (used to group initiatives where are used';
wwv_flow_imp.g_varchar2_table(2) := ' to group projects together)'';'||wwv_flow.LF||
'comment on column SP_AREA_DETAILS_V.AREA_ID is ''System generated uniq';
wwv_flow_imp.g_varchar2_table(3) := 'ue identifier of the area'';'||wwv_flow.LF||
'comment on column SP_AREA_DETAILS_V.AREA is ''Area name'';'||wwv_flow.LF||
'comment on colu';
wwv_flow_imp.g_varchar2_table(4) := 'mn SP_AREA_DETAILS_V.DESCRIPTION is ''Area description (just the first 80 characters)'';'||wwv_flow.LF||
'comment on co';
wwv_flow_imp.g_varchar2_table(5) := 'lumn SP_AREA_DETAILS_V.OWNER_ID is ''System generated unique identifier of the area owner (use to lin';
wwv_flow_imp.g_varchar2_table(6) := 'k to SP_PERSON_DETAILS_V)'';'||wwv_flow.LF||
'comment on column SP_AREA_DETAILS_V.OWNER_NAME is ''First and last name o';
wwv_flow_imp.g_varchar2_table(7) := 'f the area owner'';'||wwv_flow.LF||
'comment on column SP_AREA_DETAILS_V.OWNER_EMAIL is ''Email of the area owner'';'||wwv_flow.LF||
'com';
wwv_flow_imp.g_varchar2_table(8) := 'ment on column SP_AREA_DETAILS_V.TAGS is ''Comma separated list of tags associated with the area'';'||wwv_flow.LF||
'co';
wwv_flow_imp.g_varchar2_table(9) := 'mment on column SP_AREA_DETAILS_V.INITIATIVE_COUNT is ''Number of initiatives associated with the are';
wwv_flow_imp.g_varchar2_table(10) := 'a'';'||wwv_flow.LF||
'comment on column SP_AREA_DETAILS_V.PROJECT_COUNT is ''Number of projects associated with the are';
wwv_flow_imp.g_varchar2_table(11) := 'a'';'||wwv_flow.LF||
'comment on column SP_AREA_DETAILS_V.OPEN_PROJECT_COUNT is ''Number of open projects associated wi';
wwv_flow_imp.g_varchar2_table(12) := 'th this area (not at 0 or 100 % complete)'';'||wwv_flow.LF||
'comment on column SP_AREA_DETAILS_V.LAST_PROJECT_CREATED';
wwv_flow_imp.g_varchar2_table(13) := '_DATE is ''Most recent date on which an associated project was created'';'||wwv_flow.LF||
'comment on column SP_AREA_DE';
wwv_flow_imp.g_varchar2_table(14) := 'TAILS_V.LAST_PROJECT_UPDATED_DATE is ''Most recent date on which an associated project was updated'';'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(15) := 'comment on column SP_AREA_DETAILS_V.CREATED_DATE is ''Date on which this area was created'';'||wwv_flow.LF||
'comment o';
wwv_flow_imp.g_varchar2_table(16) := 'n column SP_AREA_DETAILS_V.CREATED_BY_APP_USERNAME is ''Lowercase application username of user who cr';
wwv_flow_imp.g_varchar2_table(17) := 'eated the area'';'||wwv_flow.LF||
'comment on column SP_AREA_DETAILS_V.LAST_UPDATED_DATE is ''Date on which this area w';
wwv_flow_imp.g_varchar2_table(18) := 'as last updated'';'||wwv_flow.LF||
'comment on column SP_AREA_DETAILS_V.LAST_UPDATED_BY_APP_USERNAME is ''Lowercase app';
wwv_flow_imp.g_varchar2_table(19) := 'lication username of user who last updated this area'';'||wwv_flow.LF||
''||wwv_flow.LF||
'comment on table SP_INITIATIVE_DETAILS_V is ';
wwv_flow_imp.g_varchar2_table(20) := '''Details about Initiatives (used to group projects together)'';'||wwv_flow.LF||
'comment on column SP_INITIATIVE_DETAI';
wwv_flow_imp.g_varchar2_table(21) := 'LS_V.INITIATIVE_ID is ''System generated unique identifier of the initiative'';'||wwv_flow.LF||
'comment on column SP_I';
wwv_flow_imp.g_varchar2_table(22) := 'NITIATIVE_DETAILS_V.INITIATIVE is ''Initiative name'';'||wwv_flow.LF||
'comment on column SP_INITIATIVE_DETAILS_V.AREA_';
wwv_flow_imp.g_varchar2_table(23) := 'ID is ''System generated unique identifier of area associated with the initiative (use to link to SP_';
wwv_flow_imp.g_varchar2_table(24) := 'AREA_DETAILS_V)'';'||wwv_flow.LF||
'comment on column SP_INITIATIVE_DETAILS_V.AREA is ''Area associated with the initia';
wwv_flow_imp.g_varchar2_table(25) := 'tive'';'||wwv_flow.LF||
'comment on column SP_INITIATIVE_DETAILS_V.OBJECTIVE is ''Purpose of the initiative (just the f';
wwv_flow_imp.g_varchar2_table(26) := 'irst 80 characters)'';'||wwv_flow.LF||
'comment on column SP_INITIATIVE_DETAILS_V.TAGS is ''Comma separated list of tag';
wwv_flow_imp.g_varchar2_table(27) := 's associated with the initiative'';'||wwv_flow.LF||
'comment on column SP_INITIATIVE_DETAILS_V.ACTIVE_FOCUS_AREA_COUNT';
wwv_flow_imp.g_varchar2_table(28) := ' is ''Number of active focus areas that are associated with this initiative'';'||wwv_flow.LF||
'comment on column SP_IN';
wwv_flow_imp.g_varchar2_table(29) := 'ITIATIVE_DETAILS_V.ACTIVE_FOCUS_AREAS is ''Comma separated list of active focus areas that are associ';
wwv_flow_imp.g_varchar2_table(30) := 'ated with this initiative'';'||wwv_flow.LF||
'comment on column SP_INITIATIVE_DETAILS_V.OWNER_ID is ''System generated ';
wwv_flow_imp.g_varchar2_table(31) := 'unique identifier of the initiative owner (use to link to SP_PERSON_DETAILS_V)'';'||wwv_flow.LF||
'comment on column S';
wwv_flow_imp.g_varchar2_table(32) := 'P_INITIATIVE_DETAILS_V.OWNER_NAME is ''First and last name of the initiative owner'';'||wwv_flow.LF||
'comment on colum';
wwv_flow_imp.g_varchar2_table(33) := 'n SP_INITIATIVE_DETAILS_V.OWNER_EMAIL is ''Email of the initiative owner'';'||wwv_flow.LF||
'comment on column SP_INITI';
wwv_flow_imp.g_varchar2_table(34) := 'ATIVE_DETAILS_V.PROJECT_COUNT is ''Number of projects associated with this initiative'';'||wwv_flow.LF||
'comment on co';
wwv_flow_imp.g_varchar2_table(35) := 'lumn SP_INITIATIVE_DETAILS_V.OPEN_PROJECT_COUNT is ''Number of open projects associated with this ini';
wwv_flow_imp.g_varchar2_table(36) := 'tiative (not at 0 or 100 % complete)'';'||wwv_flow.LF||
'comment on column SP_INITIATIVE_DETAILS_V.COMPLETED_PROJECT_C';
wwv_flow_imp.g_varchar2_table(37) := 'OUNT is ''Number of completed projects associated with this initiative (just those at 100 % complete)';
wwv_flow_imp.g_varchar2_table(38) := ''';'||wwv_flow.LF||
'comment on column SP_INITIATIVE_DETAILS_V.LAST_PROJECT_CREATED_DATE is ''Most recent date on which';
wwv_flow_imp.g_varchar2_table(39) := ' an associated project was created'';'||wwv_flow.LF||
'comment on column SP_INITIATIVE_DETAILS_V.LAST_PROJECT_UPDATED_';
wwv_flow_imp.g_varchar2_table(40) := 'DATE is ''Most recent date on which an associated project was updated'';'||wwv_flow.LF||
'comment on column SP_INITIATI';
wwv_flow_imp.g_varchar2_table(41) := 'VE_DETAILS_V.CREATED_DATE is ''Date on which this initiative was created'';'||wwv_flow.LF||
'comment on column SP_INITI';
wwv_flow_imp.g_varchar2_table(42) := 'ATIVE_DETAILS_V.CREATED_BY_APP_USERNAME is ''Lowercase application username of user who created the i';
wwv_flow_imp.g_varchar2_table(43) := 'nitiative'';'||wwv_flow.LF||
'comment on column SP_INITIATIVE_DETAILS_V.LAST_UPDATED_DATE is ''Date on which this initi';
wwv_flow_imp.g_varchar2_table(44) := 'ative was last updated'';'||wwv_flow.LF||
'comment on column SP_INITIATIVE_DETAILS_V.LAST_UPDATED_BY_APP_USERNAME is ''';
wwv_flow_imp.g_varchar2_table(45) := 'Lowercase application username of user who last updated this initiative'';'||wwv_flow.LF||
''||wwv_flow.LF||
'comment on table SP_PROJE';
wwv_flow_imp.g_varchar2_table(46) := 'CT_DETAILS_V is ''Details about Projects'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.PROJECT_ID is ''Syst';
wwv_flow_imp.g_varchar2_table(47) := 'em generated unique identifier of the project'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.PROJECT is ''P';
wwv_flow_imp.g_varchar2_table(48) := 'roject name'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.DESCRIPTION is ''Project description (just the f';
wwv_flow_imp.g_varchar2_table(49) := 'irst 80 characters)'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.AREA_ID is ''System generated unique ide';
wwv_flow_imp.g_varchar2_table(50) := 'ntifier of area associated with the project (use to link to SP_AREA_DETAILS_V)'';'||wwv_flow.LF||
'comment on column S';
wwv_flow_imp.g_varchar2_table(51) := 'P_PROJECT_DETAILS_V.AREA is ''Area the associated Initiative is part of'';'||wwv_flow.LF||
'comment on column SP_PROJEC';
wwv_flow_imp.g_varchar2_table(52) := 'T_DETAILS_V.INITIATIVE_ID is ''System generated unique identifier of initiative associated with the p';
wwv_flow_imp.g_varchar2_table(53) := 'roject (use to link to SP_INITIATIVE_DETAILS_V)'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.INITIATIVE ';
wwv_flow_imp.g_varchar2_table(54) := 'is ''Initiative the project is part of'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.FOCUS_AREA is ''Focus ';
wwv_flow_imp.g_varchar2_table(55) := 'area associated with the project'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.OWNER_ID is ''System genera';
wwv_flow_imp.g_varchar2_table(56) := 'ted unique identifier of the project owner  (use to link to SP_PERSON_DETAILS_V)'';'||wwv_flow.LF||
'comment on column';
wwv_flow_imp.g_varchar2_table(57) := ' SP_PROJECT_DETAILS_V.OWNER_NAME is ''First and last name of the project owner'';'||wwv_flow.LF||
'comment on column SP';
wwv_flow_imp.g_varchar2_table(58) := '_PROJECT_DETAILS_V.OWNER_EMAIL is ''Email of the project owner'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS';
wwv_flow_imp.g_varchar2_table(59) := '_V.OWNER_TAGS is ''Tag associated with the owner'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.PRIORITY is';
wwv_flow_imp.g_varchar2_table(60) := ' ''Priority of the project (typically 1-5 with 1 being the highest - customizable by instance)'';'||wwv_flow.LF||
'comm';
wwv_flow_imp.g_varchar2_table(61) := 'ent on column SP_PROJECT_DETAILS_V.PROJECT_SIZE is ''Size of the project (typically S thru XL - custo';
wwv_flow_imp.g_varchar2_table(62) := 'mizable by instance)'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.SIZE_DESCRIPTION is ''Description of th';
wwv_flow_imp.g_varchar2_table(63) := 'e size of the project'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.EFFORT_DAYS is ''Effort in days (comes';
wwv_flow_imp.g_varchar2_table(64) := ' from the size selected - customizable by instance)'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.DAYS_RE';
wwv_flow_imp.g_varchar2_table(65) := 'MAINING is ''Days remaining, based on percent complete and effort in days'';'||wwv_flow.LF||
'comment on column SP_PROJ';
wwv_flow_imp.g_varchar2_table(66) := 'ECT_DETAILS_V.PCT_COMPLETE is ''Percent complete, scale of 0-100'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAI';
wwv_flow_imp.g_varchar2_table(67) := 'LS_V.STATUS is ''Status of project, only prompted for those active (as determined by the selected com';
wwv_flow_imp.g_varchar2_table(68) := 'pleteness scale) and not complete (not at 100% complete) - customizable by instance'';'||wwv_flow.LF||
'comment on col';
wwv_flow_imp.g_varchar2_table(69) := 'umn SP_PROJECT_DETAILS_V.REQUIRES_REVIEWS is ''Yes if the project requires reviews and No if it does ';
wwv_flow_imp.g_varchar2_table(70) := 'not, used in exception reporting'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.DOC_IMPACT is ''Yes if this';
wwv_flow_imp.g_varchar2_table(71) := ' project will impact documentation, No if it will not'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.TAGS ';
wwv_flow_imp.g_varchar2_table(72) := 'is ''Comma separated list of tags associated with the project'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_';
wwv_flow_imp.g_varchar2_table(73) := 'V.PROJECT_GROUP is ''Project Group which categorizes Projects across Initiatives.'';'||wwv_flow.LF||
'comment on column';
wwv_flow_imp.g_varchar2_table(74) := ' SP_PROJECT_DETAILS_V.RELEASE_ID is ''If associated with a release, system generated unique identifie';
wwv_flow_imp.g_varchar2_table(75) := 'r of release, if associated with a release (use to link to SP_RELEASE_DETAILS_V)'';'||wwv_flow.LF||
'comment on column';
wwv_flow_imp.g_varchar2_table(76) := ' SP_PROJECT_DETAILS_V.RELEASE is ''If associated with a release, the release'';'||wwv_flow.LF||
'comment on column SP_P';
wwv_flow_imp.g_varchar2_table(77) := 'ROJECT_DETAILS_V.TARGET_COMPLETE is ''The date the project is expected to be complete (or null if no ';
wwv_flow_imp.g_varchar2_table(78) := 'date provided)'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.EXTERNAL_TICKET_IDENTIFIER is ''If associated';
wwv_flow_imp.g_varchar2_table(79) := ' with an external system, the identifier in that system'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.EXT';
wwv_flow_imp.g_varchar2_table(80) := 'ERNAL_SYSTEM_LINK is ''If associated with an external system, the link to the details in that system''';
wwv_flow_imp.g_varchar2_table(81) := ';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.CONTRIBUTOR_NAMES is ''Comma separated list of first and las';
wwv_flow_imp.g_varchar2_table(82) := 't names of contributors to the project'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.CONTRIBUTOR_EMAILS i';
wwv_flow_imp.g_varchar2_table(83) := 's ''Comma separated list of emails of contributors to the project'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETA';
wwv_flow_imp.g_varchar2_table(84) := 'ILS_V.REVIEW_COUNT is ''Number of reviews associated with the project'';'||wwv_flow.LF||
'comment on column SP_PROJECT_';
wwv_flow_imp.g_varchar2_table(85) := 'DETAILS_V.REVIEWER_NAMES is ''Comma separated list of first and last names of reviewers associated wi';
wwv_flow_imp.g_varchar2_table(86) := 'th the project'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.REVIEWER_EMAILS is ''Comma separated list of ';
wwv_flow_imp.g_varchar2_table(87) := 'emails of reviewers associated with the project'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.REVIEWS is ';
wwv_flow_imp.g_varchar2_table(88) := '''Comma separated list of reviews, including type and target complete date, associated with the proje';
wwv_flow_imp.g_varchar2_table(89) := 'ct'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.MILESTONE_COUNT is ''Number of milestones associated with';
wwv_flow_imp.g_varchar2_table(90) := ' the project'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.MILESTONES is ''Comma separated list of milesto';
wwv_flow_imp.g_varchar2_table(91) := 'nes, including type and target complete date, associated with the project'';'||wwv_flow.LF||
'comment on column SP_PRO';
wwv_flow_imp.g_varchar2_table(92) := 'JECT_DETAILS_V.APPROVALS is ''Comma separated list of approvals, including type of current status, as';
wwv_flow_imp.g_varchar2_table(93) := 'sociated with the project'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.LAST_COMMENT is ''First 255 charac';
wwv_flow_imp.g_varchar2_table(94) := 'ters of the last comment about this project'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.LAST_COMMENT_ON';
wwv_flow_imp.g_varchar2_table(95) := ' is ''Date on which the last comment about this project was added'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETA';
wwv_flow_imp.g_varchar2_table(96) := 'ILS_V.LAST_COMMENT_BY is ''First and last name of the user who last commented on this project'';'||wwv_flow.LF||
'comme';
wwv_flow_imp.g_varchar2_table(97) := 'nt on column SP_PROJECT_DETAILS_V.LAST_COMMENT_BY_OWNER is ''First 255 characters of the last comment';
wwv_flow_imp.g_varchar2_table(98) := ' about this project by the owner of the project'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.LAST_COMMEN';
wwv_flow_imp.g_varchar2_table(99) := 'T_BY_OWNER_ON is ''Date on which the owner of the project last commented on this project'';'||wwv_flow.LF||
'comment on';
wwv_flow_imp.g_varchar2_table(100) := ' column SP_PROJECT_DETAILS_V.COMMENTS_28D is ''Number of comments about this project in the last 28 d';
wwv_flow_imp.g_varchar2_table(101) := 'ays'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.CURRENT_ACTIVITY_COUNT is ''Number of current activity i';
wwv_flow_imp.g_varchar2_table(102) := 'tems associated with this project (those started and not yet complete)'';'||wwv_flow.LF||
'comment on column SP_PROJEC';
wwv_flow_imp.g_varchar2_table(103) := 'T_DETAILS_V.FAVORITED is ''Number of users who have favorited this project'';'||wwv_flow.LF||
'comment on column SP_PRO';
wwv_flow_imp.g_varchar2_table(104) := 'JECT_DETAILS_V.VIEWS_28D is ''Number of times this project has been viewed in the last 28 days'';'||wwv_flow.LF||
'comm';
wwv_flow_imp.g_varchar2_table(105) := 'ent on column SP_PROJECT_DETAILS_V.DISTINCT_USER_VIEWS_28D is ''Number of distinct users who have vie';
wwv_flow_imp.g_varchar2_table(106) := 'wed this project in the last 28 days'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.CREATED_DATE is ''Date ';
wwv_flow_imp.g_varchar2_table(107) := 'on which this project was created'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DETAILS_V.CREATED_BY_APP_USERNAME i';
wwv_flow_imp.g_varchar2_table(108) := 's ''Lowercase application username of user who created this project'';'||wwv_flow.LF||
'comment on column SP_PROJECT_DE';
wwv_flow_imp.g_varchar2_table(109) := 'TAILS_V.LAST_UPDATED_DATE is ''Date on which this project was last updated'';'||wwv_flow.LF||
'comment on column SP_PRO';
wwv_flow_imp.g_varchar2_table(110) := 'JECT_DETAILS_V.LAST_UPDATED_BY_APP_USERNAME is ''Lowercase application username of user who last upda';
wwv_flow_imp.g_varchar2_table(111) := 'ted this project'';'||wwv_flow.LF||
''||wwv_flow.LF||
'comment on table SP_PROJECT_CHANGE_HISTORY_V is ''History of all changes made to ';
wwv_flow_imp.g_varchar2_table(112) := 'projects and project tasks'';'||wwv_flow.LF||
'comment on column SP_PROJECT_CHANGE_HISTORY_V.CHANGE_TO is ''Either "Pro';
wwv_flow_imp.g_varchar2_table(113) := 'ject" or the type of task'';'||wwv_flow.LF||
'comment on column SP_PROJECT_CHANGE_HISTORY_V.PROJECT_ID is ''System gene';
wwv_flow_imp.g_varchar2_table(114) := 'rated unique identifier of the project (use to link to SP_PROJECT_DETAILS_V)'';'||wwv_flow.LF||
'comment on column SP_';
wwv_flow_imp.g_varchar2_table(115) := 'PROJECT_CHANGE_HISTORY_V.PROJECT is ''Project name'';'||wwv_flow.LF||
'comment on column SP_PROJECT_CHANGE_HISTORY_V.CH';
wwv_flow_imp.g_varchar2_table(116) := 'ANGE_TYPE is ''Change type (CREATE, UPDATE, DELETE)'';'||wwv_flow.LF||
'comment on column SP_PROJECT_CHANGE_HISTORY_V.A';
wwv_flow_imp.g_varchar2_table(117) := 'TTRIBUTE_COLUMN is ''Name of attribute changed'';'||wwv_flow.LF||
'comment on column SP_PROJECT_CHANGE_HISTORY_V.OLD_VA';
wwv_flow_imp.g_varchar2_table(118) := 'LUE is ''Previous value of the attribute'';'||wwv_flow.LF||
'comment on column SP_PROJECT_CHANGE_HISTORY_V.NEW_VALUE is';
wwv_flow_imp.g_varchar2_table(119) := ' ''Value this attribute was changed to'';'||wwv_flow.LF||
'comment on column SP_PROJECT_CHANGE_HISTORY_V.ATTRIBUTE_CHAN';
wwv_flow_imp.g_varchar2_table(120) := 'GE_DATE is ''Date on which this change was made'';'||wwv_flow.LF||
'comment on column SP_PROJECT_CHANGE_HISTORY_V.CHANG';
wwv_flow_imp.g_varchar2_table(121) := 'ED_BY_APP_USERNAME is ''Lowercase application username of user who made the change'';'||wwv_flow.LF||
''||wwv_flow.LF||
'comment on tabl';
wwv_flow_imp.g_varchar2_table(122) := 'e SP_RELEASE_DETAILS_V IS ''Details about Releases (used to group projects together that will be rele';
wwv_flow_imp.g_varchar2_table(123) := 'ased together)'';'||wwv_flow.LF||
'comment on column SP_RELEASE_DETAILS_V.RELEASE_ID is ''System generated unique ident';
wwv_flow_imp.g_varchar2_table(124) := 'ifier of the release'';'||wwv_flow.LF||
'comment on column SP_RELEASE_DETAILS_V.RELEASE_TRAIN is ''Typically the produc';
wwv_flow_imp.g_varchar2_table(125) := 't being released'';'||wwv_flow.LF||
'comment on column SP_RELEASE_DETAILS_V.RELEASE is ''Version of the product being r';
wwv_flow_imp.g_varchar2_table(126) := 'eleased'';'||wwv_flow.LF||
'comment on column SP_RELEASE_DETAILS_V.RELEASE_TYPE is ''Type of release, Full or Patch'';'||wwv_flow.LF||
'c';
wwv_flow_imp.g_varchar2_table(127) := 'omment on column SP_RELEASE_DETAILS_V.RELEASE_OPEN_DATE is ''Date on which the release opened for wor';
wwv_flow_imp.g_varchar2_table(128) := 'k'';'||wwv_flow.LF||
'comment on column SP_RELEASE_DETAILS_V.RELEASE_TARGET_DATE is ''Date on which the work on the rel';
wwv_flow_imp.g_varchar2_table(129) := 'ease is targeted to be completed'';'||wwv_flow.LF||
'comment on column SP_RELEASE_DETAILS_V.RELEASE_STATUS is ''Status ';
wwv_flow_imp.g_varchar2_table(130) := 'of the release timeframe, Open, Closed or Future'';'||wwv_flow.LF||
'comment on column SP_RELEASE_DETAILS_V.DURATION_I';
wwv_flow_imp.g_varchar2_table(131) := 'N_DAYS is ''Number of days the release was (or is) open'';'||wwv_flow.LF||
'comment on column SP_RELEASE_DETAILS_V.DAYS';
wwv_flow_imp.g_varchar2_table(132) := '_REMAINING is ''Number of days remaining until the targeted completion date (null for Closed releases';
wwv_flow_imp.g_varchar2_table(133) := ')'';'||wwv_flow.LF||
'comment on column SP_RELEASE_DETAILS_V.OWNER_ID is ''Unique identifier of the release owner (use ';
wwv_flow_imp.g_varchar2_table(134) := 'to link to SP_PERSON_DETAILS_V)'';'||wwv_flow.LF||
'comment on column SP_RELEASE_DETAILS_V.OWNER_NAME is ''First and la';
wwv_flow_imp.g_varchar2_table(135) := 'st name of the release owner'';'||wwv_flow.LF||
'comment on column SP_RELEASE_DETAILS_V.OWNER_EMAIL is ''Email of the r';
wwv_flow_imp.g_varchar2_table(136) := 'elease owner'';'||wwv_flow.LF||
'comment on column SP_RELEASE_DETAILS_V.PROJECT_COUNT is ''Number of projects associate';
wwv_flow_imp.g_varchar2_table(137) := 'd with this release'';'||wwv_flow.LF||
'comment on column SP_RELEASE_DETAILS_V.OPEN_PROJECT_COUNT is ''Number of open p';
wwv_flow_imp.g_varchar2_table(138) := 'rojects associated with this release (not at 0 or 100 % complete)'';'||wwv_flow.LF||
'comment on column SP_RELEASE_DET';
wwv_flow_imp.g_varchar2_table(139) := 'AILS_V.COMPLETED_PROJECT_COUNT is ''Number of completed projects associated with this release (just t';
wwv_flow_imp.g_varchar2_table(140) := 'hose at 100 % complete)'';'||wwv_flow.LF||
'comment on column SP_RELEASE_DETAILS_V.PROJECT_CONTRIBUTOR_COUNT is ''Numbe';
wwv_flow_imp.g_varchar2_table(141) := 'r of unique people who own project tasks (including reviews and milestones) associated with this rel';
wwv_flow_imp.g_varchar2_table(142) := 'ease'';'||wwv_flow.LF||
'comment on column SP_RELEASE_DETAILS_V.AVG_PROJECT_PCT_COMPLETE is ''Average percent complete ';
wwv_flow_imp.g_varchar2_table(143) := 'of the projects associated with this release'';'||wwv_flow.LF||
'comment on column SP_RELEASE_DETAILS_V.LAST_PROJECT_U';
wwv_flow_imp.g_varchar2_table(144) := 'PDATE is ''Most recent date on which an associated project was updated'';'||wwv_flow.LF||
'comment on column SP_RELEASE';
wwv_flow_imp.g_varchar2_table(145) := '_DETAILS_V.MILESTONE_COUNT is ''Number of milestones associated with this release'';'||wwv_flow.LF||
'comment on column';
wwv_flow_imp.g_varchar2_table(146) := ' SP_RELEASE_DETAILS_V.COMPLETED_MILESTONE_COUNT is ''Number of milestones associated with the release';
wwv_flow_imp.g_varchar2_table(147) := ' that have been completed'';'||wwv_flow.LF||
'comment on column SP_RELEASE_DETAILS_V.CREATED_DATE is ''Date on which th';
wwv_flow_imp.g_varchar2_table(148) := 'is initiative was created'';'||wwv_flow.LF||
'comment on column SP_RELEASE_DETAILS_V.CREATED_BY_APP_USERNAME is ''Lower';
wwv_flow_imp.g_varchar2_table(149) := 'case application username of user who created the initiative'';'||wwv_flow.LF||
'comment on column SP_RELEASE_DETAILS_';
wwv_flow_imp.g_varchar2_table(150) := 'V.LAST_UPDATED_DATE is ''Date on which this initiative was last updated'';'||wwv_flow.LF||
'comment on column SP_RELEAS';
wwv_flow_imp.g_varchar2_table(151) := 'E_DETAILS_V.LAST_UPDATED_BY_APP_USERNAME is ''Lowercase application username of user who last updated';
wwv_flow_imp.g_varchar2_table(152) := ' this initiative'';'||wwv_flow.LF||
''||wwv_flow.LF||
'comment on table SP_PERSON_DETAILS_V is ''Details about the people who participat';
wwv_flow_imp.g_varchar2_table(153) := 'e with initiatives, projects and releases'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.PERSON_ID is ''Syst';
wwv_flow_imp.g_varchar2_table(154) := 'em generated unique identifier of the person'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.FIRST_NAME is ''';
wwv_flow_imp.g_varchar2_table(155) := 'First name of the person'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.LAST_NAME is ''Last name of the pers';
wwv_flow_imp.g_varchar2_table(156) := 'on'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.EMAIL is ''Email address of the person'';'||wwv_flow.LF||
'comment on column';
wwv_flow_imp.g_varchar2_table(157) := ' SP_PERSON_DETAILS_V.EMAIL_DOMAIN is ''Email domain of the person'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAI';
wwv_flow_imp.g_varchar2_table(158) := 'LS_V.SCREEN_NAME is ''Screen name of the person, used to mention someone in a comment (and the person';
wwv_flow_imp.g_varchar2_table(159) := ' can get an alert of the mention)'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.LOCATION is ''Location of t';
wwv_flow_imp.g_varchar2_table(160) := 'he person'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.COUNTRY is ''Country the person is associated with''';
wwv_flow_imp.g_varchar2_table(161) := ';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.REGION is ''Region the person is associated with (Asia Pacifi';
wwv_flow_imp.g_varchar2_table(162) := 'c, EMEA, Japan, North America, South America)'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.TAGS is ''Comma';
wwv_flow_imp.g_varchar2_table(163) := ' separated list of tags associated with the person'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.COMPETENC';
wwv_flow_imp.g_varchar2_table(164) := 'IES is ''Comma separated list of competencies the person possesses relative to work'';'||wwv_flow.LF||
'comment on colu';
wwv_flow_imp.g_varchar2_table(165) := 'mn SP_PERSON_DETAILS_V.IS_ACTIVE is ''Yes if user is marked as an active participant within the appli';
wwv_flow_imp.g_varchar2_table(166) := 'cation, No if not'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.AREA_OWNER_COUNT is ''Number of areas the p';
wwv_flow_imp.g_varchar2_table(167) := 'erson owns'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.INITIATIVE_OWNER_COUNT is ''Number of initiatives ';
wwv_flow_imp.g_varchar2_table(168) := 'the person owns'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.PROJECT_OWNER_COUNT is ''Number of projects t';
wwv_flow_imp.g_varchar2_table(169) := 'he person owns'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.TASK_OWNER_COUNT is ''Number of project tasks ';
wwv_flow_imp.g_varchar2_table(170) := '(including milestones and reviews) the person owns'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.PROJECT_C';
wwv_flow_imp.g_varchar2_table(171) := 'ONTRIB_DOC_COUNT is ''Number of documents the person has contributed to projects'';'||wwv_flow.LF||
'comment on column ';
wwv_flow_imp.g_varchar2_table(172) := 'SP_PERSON_DETAILS_V.INITIATIVE_CONTRIB_DOC_COUNT is ''Number of documents the person has contributed ';
wwv_flow_imp.g_varchar2_table(173) := 'to initiatives'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.RELEASE_CONTRIB_DOC_COUNT is ''Number of docum';
wwv_flow_imp.g_varchar2_table(174) := 'ents the person has contributed to releases'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.TASK_CONTRIB_DOC';
wwv_flow_imp.g_varchar2_table(175) := '_COUNT is ''Number of documents the person has contributed to project tasks (including milestones and';
wwv_flow_imp.g_varchar2_table(176) := ' reviews)'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.PROJ_CONTRIB_COMMENT_COUNT is ''Number of comments ';
wwv_flow_imp.g_varchar2_table(177) := 'the person has contributed to projects'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.INITIATIVE_CONTRIB_CO';
wwv_flow_imp.g_varchar2_table(178) := 'MMENT_COUNT is ''Number of comments the person has contributed to initiatives'';'||wwv_flow.LF||
'comment on column SP_';
wwv_flow_imp.g_varchar2_table(179) := 'PERSON_DETAILS_V.RELEASE_CONTRIB_COMMENT_COUNT is ''Number of comments the person has contributed to ';
wwv_flow_imp.g_varchar2_table(180) := 'releases'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.TASK_CONTRIB_COMMENT_COUNT is ''Number of comments t';
wwv_flow_imp.g_varchar2_table(181) := 'he person has contributed to project tasks (including milestones and reviews)'';'||wwv_flow.LF||
'comment on column SP';
wwv_flow_imp.g_varchar2_table(182) := '_PERSON_DETAILS_V.ACTIVE_ACTIVITY_COUNT is ''Number of activity entries the person is associated with';
wwv_flow_imp.g_varchar2_table(183) := ' that are active (not yet complete)'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.OPEN_REVIEW_COUNT is ''Nu';
wwv_flow_imp.g_varchar2_table(184) := 'mber of open reviews this person is assigned to (not yet complete)'';'||wwv_flow.LF||
'comment on column SP_PERSON_DET';
wwv_flow_imp.g_varchar2_table(185) := 'AILS_V.GROUP_MEMBERSHIP_COUNT is ''Number of groups this person is associated with'';'||wwv_flow.LF||
'comment on colum';
wwv_flow_imp.g_varchar2_table(186) := 'n SP_PERSON_DETAILS_V.GROUP_MEMBERSHIP is ''Comma separated list of groups this person is associated ';
wwv_flow_imp.g_varchar2_table(187) := 'with'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.CREATED_DATE is ''Date on which this person row was crea';
wwv_flow_imp.g_varchar2_table(188) := 'ted'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.CREATED_BY_APP_USERNAME is ''Lowercase application userna';
wwv_flow_imp.g_varchar2_table(189) := 'me of user who created the person row'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.LAST_UPDATED_DATE is ''';
wwv_flow_imp.g_varchar2_table(190) := 'Date on which this person row was last updated'';'||wwv_flow.LF||
'comment on column SP_PERSON_DETAILS_V.LAST_UPDATED_';
wwv_flow_imp.g_varchar2_table(191) := 'BY_APP_USERNAME is ''Lowercase application username of user who last updated this person row'';'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(20048552529115331213)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'object details view comments'
,p_sequence=>5040
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
