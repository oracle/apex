prompt --application/deployment/install/install_sp_project_sizes_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_project_sizes table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_project_sizes ('||wwv_flow.LF||
'    id                             number default on null to_number(';
wwv_flow_imp.g_varchar2_table(2) := 'sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_pr';
wwv_flow_imp.g_varchar2_table(3) := 'oject_size_id_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    project_size                   varchar2(30 char) not null,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(4) := '    size_description               varchar2(100 char) not null,'||wwv_flow.LF||
'    effort_days                    n';
wwv_flow_imp.g_varchar2_table(5) := 'umber not null,'||wwv_flow.LF||
'    include_yn                     varchar2(1 char) not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created    ';
wwv_flow_imp.g_varchar2_table(6) := '                    date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(7) := '   updated                        date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 cha';
wwv_flow_imp.g_varchar2_table(8) := 'r) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index sp_project_sizes_u1 on sp_project_sizes (project_size);'||wwv_flow.LF||
'create ';
wwv_flow_imp.g_varchar2_table(9) := 'unique index sp_project_sizes_u2 on sp_project_sizes(EFFORT_DAYS);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_pro';
wwv_flow_imp.g_varchar2_table(10) := 'ject_sizes_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_project_sizes'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if ins';
wwv_flow_imp.g_varchar2_table(11) := 'erting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:ne';
wwv_flow_imp.g_varchar2_table(12) := 'w.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl';
wwv_flow_imp.g_varchar2_table(13) := '(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$S';
wwv_flow_imp.g_varchar2_table(14) := 'ESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new';
wwv_flow_imp.g_varchar2_table(15) := '.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new';
wwv_flow_imp.g_varchar2_table(16) := '.include_yn is null then'||wwv_flow.LF||
'       :new.include_yn := ''Y'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_project_sizes_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(45802041970265502712)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_project_sizes table and trigger'
,p_sequence=>3220
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
