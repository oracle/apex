prompt --application/deployment/install/install_sp_app_settings_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_app_settings table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_app_settings ('||wwv_flow.LF||
'    id                             number '||wwv_flow.LF||
'                          ';
wwv_flow_imp.g_varchar2_table(2) := '            default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(3) := '                         constraint sp_app_settings_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    static_id            ';
wwv_flow_imp.g_varchar2_table(4) := '          varchar2(255)  not null'||wwv_flow.LF||
'                                      constraint sp_app_settings_u';
wwv_flow_imp.g_varchar2_table(5) := 'k unique,'||wwv_flow.LF||
'    description                    varchar2(4000) not null,'||wwv_flow.LF||
'    setting_value             ';
wwv_flow_imp.g_varchar2_table(6) := '     varchar2(4000),'||wwv_flow.LF||
'    is_numeric_yn                  varchar2(1)    not null    -- used in valida';
wwv_flow_imp.g_varchar2_table(7) := 'tion'||wwv_flow.LF||
'                                      constraint sp_app_settings_is_numeric_cc'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(8) := '                      check (is_numeric_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    is_yn                          varchar';
wwv_flow_imp.g_varchar2_table(9) := '2(1)    not null    -- used in validation'||wwv_flow.LF||
'                                      constraint sp_app_se';
wwv_flow_imp.g_varchar2_table(10) := 'ttings_is_yn_cc'||wwv_flow.LF||
'                                      check (is_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created';
wwv_flow_imp.g_varchar2_table(11) := '                        date            not null,'||wwv_flow.LF||
'    created_by                     varchar2(255)  ';
wwv_flow_imp.g_varchar2_table(12) := ' not null,'||wwv_flow.LF||
'    updated                        date            not null,'||wwv_flow.LF||
'    updated_by              ';
wwv_flow_imp.g_varchar2_table(13) := '       varchar2(255)   not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_app_settings_biu'||wwv_flow.LF||
'    before insert ';
wwv_flow_imp.g_varchar2_table(14) := 'or update '||wwv_flow.LF||
'    on sp_app_settings'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created ';
wwv_flow_imp.g_varchar2_table(15) := '   := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coalesce(sys_contex';
wwv_flow_imp.g_varchar2_table(16) := 't(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :';
wwv_flow_imp.g_varchar2_table(17) := 'new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(18) := 'lsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_conte';
wwv_flow_imp.g_varchar2_table(19) := 'xt(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.static_id  := upper(:new.static_id)';
wwv_flow_imp.g_varchar2_table(20) := ';'||wwv_flow.LF||
'end sp_app_settings_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(47919353187324088111)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_app_settings table'
,p_sequence=>3030
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
