prompt --application/deployment/install/install_sp_relation_types_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_relation_types table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_relation_types ('||wwv_flow.LF||
'    id                        number'||wwv_flow.LF||
'                              ';
wwv_flow_imp.g_varchar2_table(2) := '    default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(3) := '             constraint sp_relation_types_pk primary key,'||wwv_flow.LF||
'    relation_type             varchar2(60)';
wwv_flow_imp.g_varchar2_table(4) := '   not null  '||wwv_flow.LF||
'                                  constraint sp_relation_types_uk unique,'||wwv_flow.LF||
'    relation';
wwv_flow_imp.g_varchar2_table(5) := '_reverse          varchar2(60),'||wwv_flow.LF||
'    active_yn                 varchar2(1) default on null ''Y'''||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(6) := '                            constraint sp_relation_types_active_cc'||wwv_flow.LF||
'                                 ';
wwv_flow_imp.g_varchar2_table(7) := ' check (active_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                   date            not null,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(8) := 'created_by                varchar2(255)   not null,'||wwv_flow.LF||
'    updated                   date            no';
wwv_flow_imp.g_varchar2_table(9) := 't null,'||wwv_flow.LF||
'    updated_by                varchar2(255)   not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_rela';
wwv_flow_imp.g_varchar2_table(10) := 'tion_types_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_relation_types'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if in';
wwv_flow_imp.g_varchar2_table(11) := 'serting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:n';
wwv_flow_imp.g_varchar2_table(12) := 'ew.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nv';
wwv_flow_imp.g_varchar2_table(13) := 'l(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$';
wwv_flow_imp.g_varchar2_table(14) := 'SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :ne';
wwv_flow_imp.g_varchar2_table(15) := 'w.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_relation_t';
wwv_flow_imp.g_varchar2_table(16) := 'ypes_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(36946890303761967225)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_relation_types table and trigger'
,p_sequence=>3560
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
