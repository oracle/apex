prompt --application/deployment/install/install_sp_release_timeline_spec
begin
--   Manifest
--     INSTALL: INSTALL-sp_release_timeline spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package sp_release_timeline'||wwv_flow.LF||
'as'||wwv_flow.LF||
''||wwv_flow.LF||
'function show_week ('||wwv_flow.LF||
'    p_release_id           in';
wwv_flow_imp.g_varchar2_table(2) := ' number,'||wwv_flow.LF||
'    p_show_past_yn         in varchar2 default ''N'','||wwv_flow.LF||
'    p_exclude_complete_yn  in varchar2 ';
wwv_flow_imp.g_varchar2_table(3) := 'default ''N'')'||wwv_flow.LF||
'    return clob;'||wwv_flow.LF||
''||wwv_flow.LF||
'function release_exceptions ('||wwv_flow.LF||
'    p_release_id               in numbe';
wwv_flow_imp.g_varchar2_table(4) := 'r,'||wwv_flow.LF||
'    p_links                    in varchar2 default ''NONE'','||wwv_flow.LF||
'    p_apex_session             in varc';
wwv_flow_imp.g_varchar2_table(5) := 'har2 default null )'||wwv_flow.LF||
'    return clob;'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_release_timeline;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(41457322764762148679)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_release_timeline spec'
,p_sequence=>2080
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
