prompt --application/deployment/install/install_table_comments
begin
--   Manifest
--     INSTALL: INSTALL-Table Comments
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'comment on table sp_app_log is ''Log of all changes to administrative data (users, settings, valid va';
wwv_flow_imp.g_varchar2_table(2) := 'lues).'';'||wwv_flow.LF||
'comment on table sp_error_log is ''Errors raised by the packages used by this application.'';';
wwv_flow_imp.g_varchar2_table(3) := ''||wwv_flow.LF||
'comment on table sp_app_settings is ''Values for application settings (ai service, default timezone)';
wwv_flow_imp.g_varchar2_table(4) := '.'';'||wwv_flow.LF||
'comment on table sp_ai_prompts is ''Prompts used for generating Project and Release summaries.'';'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(5) := 'comment on table SP_DEFAULT_TAGS is ''Default quick picks for Project Tags.'';'||wwv_flow.LF||
'comment on table sp_tea';
wwv_flow_imp.g_varchar2_table(6) := 'm_members is ''All People defined within this application. These people can be assigned Projects and ';
wwv_flow_imp.g_varchar2_table(7) := 'Tasks but they are not necessarily users of the application (users are handled separately).'';'||wwv_flow.LF||
'commen';
wwv_flow_imp.g_varchar2_table(8) := 't on table sp_event_types is ''Out of Office event types used within Team Calendar and Team Member av';
wwv_flow_imp.g_varchar2_table(9) := 'ailability.'';'||wwv_flow.LF||
'comment on table sp_event_series is ''Details of Event Series, including start and end ';
wwv_flow_imp.g_varchar2_table(10) := 'dates and recurrence frequency.'';'||wwv_flow.LF||
'comment on table SP_APP_NOMENCLATURE is ''Customized display values';
wwv_flow_imp.g_varchar2_table(11) := ' set for Application Name and main objects within this application (Initiative, Project).'';'||wwv_flow.LF||
'comment ';
wwv_flow_imp.g_varchar2_table(12) := 'on table sp_events is ''General and person-specific events displayed on the Team Calendar, used for A';
wwv_flow_imp.g_varchar2_table(13) := 'vailability tracking.  The Team Calendar feature can be disabled if not desired.'';'||wwv_flow.LF||
'comment on table ';
wwv_flow_imp.g_varchar2_table(14) := 'sp_resource_types is ''List of Contributor Roles used within Projects.'';'||wwv_flow.LF||
'comment on table sp_competen';
wwv_flow_imp.g_varchar2_table(15) := 'cies is ''List of competencies that can be associated with Team Members and displayed within their pr';
wwv_flow_imp.g_varchar2_table(16) := 'ofile.'';'||wwv_flow.LF||
'comment on table SP_GROUPS is ''Mechanism to group Team Members together. Facilitates viewin';
wwv_flow_imp.g_varchar2_table(17) := 'g Projects assigned to Team Members within each group. The Groups feature can be disabled if not des';
wwv_flow_imp.g_varchar2_table(18) := 'ired.'';'||wwv_flow.LF||
'comment on table SP_GROUP_MEMBERS is ''List of Team Members assigned to each group. The Group';
wwv_flow_imp.g_varchar2_table(19) := 's feature can be disabled if not desired.'';'||wwv_flow.LF||
'comment on table sp_release_trains is ''Details about Rel';
wwv_flow_imp.g_varchar2_table(20) := 'eases (used to group Projects together that will be released together).  The Releases feature can be';
wwv_flow_imp.g_varchar2_table(21) := ' disabled if not desired.'';'||wwv_flow.LF||
'comment on table sp_release_history is ''History of changes within each R';
wwv_flow_imp.g_varchar2_table(22) := 'elease (old and new values, who made the change and when the change was made).'';'||wwv_flow.LF||
'comment on table sp';
wwv_flow_imp.g_varchar2_table(23) := '_areas is ''Top level organization for Projects. All Projects are organized by Initiatives that are o';
wwv_flow_imp.g_varchar2_table(24) := 'rganized by Areas.'';'||wwv_flow.LF||
'comment on table sp_project_scales is ''Completeness scales used to track progre';
wwv_flow_imp.g_varchar2_table(25) := 'ss of Projects.  These determine what each increment (from 0-100% complete in increments of 10) mean';
wwv_flow_imp.g_varchar2_table(26) := 's - e.g. 50% = Active Development as well as at what level of completeness a status must be set (e.g';
wwv_flow_imp.g_varchar2_table(27) := '. 30%).  The default scale is set at the Initiative level but can be overridden for any Project.'';'||wwv_flow.LF||
'c';
wwv_flow_imp.g_varchar2_table(28) := 'omment on table sp_initiatives is ''Further organize Areas. All Projects are organized by Initiatives';
wwv_flow_imp.g_varchar2_table(29) := ' that are organized by Areas.'';'||wwv_flow.LF||
'comment on table sp_project_priorities is ''Available Project priorit';
wwv_flow_imp.g_varchar2_table(30) := 'ies.  Allows categorization of Projects (e.g. P1 - Highest Priority).'';'||wwv_flow.LF||
'comment on table sp_project_';
wwv_flow_imp.g_varchar2_table(31) := 'sizes is ''Available sizes for Projects with estimated level of effort in days (e.g. Small, 2 days).''';
wwv_flow_imp.g_varchar2_table(32) := ';'||wwv_flow.LF||
'comment on table sp_project_statuses is ''Available statuses for Projects, used when Active (as set';
wwv_flow_imp.g_varchar2_table(33) := ' by selected Completeness Scale) and not complete (e.g. On Track, At Risk).'';'||wwv_flow.LF||
'comment on table sp_pr';
wwv_flow_imp.g_varchar2_table(34) := 'oject_groups is ''Allows viewing of all Comments and Activity across a common organizing structure. E';
wwv_flow_imp.g_varchar2_table(35) := 'ach Project can only belong to one Group. The Project Groups feature can be disabled if not desired.';
wwv_flow_imp.g_varchar2_table(36) := ''';'||wwv_flow.LF||
'comment on table sp_initiative_focus_areas is ''Focus Areas within each Initiative.  Projects can ';
wwv_flow_imp.g_varchar2_table(37) := 'be associated with a Focus Area that matches the Initiative the Project is associated with. This all';
wwv_flow_imp.g_varchar2_table(38) := 'ows for viewing the attributes and milestones of those Projects.'';'||wwv_flow.LF||
'comment on table sp_init_focus_ar';
wwv_flow_imp.g_varchar2_table(39) := 'ea_links is ''Links associated with an Initiative Focus Area.'';'||wwv_flow.LF||
'comment on table sp_init_focus_area_d';
wwv_flow_imp.g_varchar2_table(40) := 'ocuments is ''Documents associated with an Initiative Focus Area.'';'||wwv_flow.LF||
'comment on table sp_init_focus_ar';
wwv_flow_imp.g_varchar2_table(41) := 'ea_comments is ''Comments associated with an Initiative Focus Area.'';'||wwv_flow.LF||
'comment on table sp_init_focus_';
wwv_flow_imp.g_varchar2_table(42) := 'area_history is ''All changes to an Initiative Focus Area (old and new values, who made the change an';
wwv_flow_imp.g_varchar2_table(43) := 'd when the change was made).'';'||wwv_flow.LF||
'comment on table sp_projects is ''Details about Projects tracked by th';
wwv_flow_imp.g_varchar2_table(44) := 'is application.  This includes the Initiative the Project belongs to, the owner, reviews, milestones';
wwv_flow_imp.g_varchar2_table(45) := ', tasks, links, documents, etc.'';'||wwv_flow.LF||
'comment on table sp_project_history is ''All changes to Projects (o';
wwv_flow_imp.g_varchar2_table(46) := 'ld and new values, who made the change and when the change was made).'';'||wwv_flow.LF||
'comment on table sp_project_';
wwv_flow_imp.g_varchar2_table(47) := 'links is ''Links associated with Projects.'';'||wwv_flow.LF||
'comment on table sp_project_comments is ''Comments associ';
wwv_flow_imp.g_varchar2_table(48) := 'ated with Projects, note that some might be private.'';'||wwv_flow.LF||
'comment on table sp_release_comments is ''Comm';
wwv_flow_imp.g_varchar2_table(49) := 'ents associated with Releases, note that some might be private.'';'||wwv_flow.LF||
'comment on table sp_comment_images';
wwv_flow_imp.g_varchar2_table(50) := ' is ''Images associated with Comments, across all object types (Initiatives, Projects, Tasks, ...).'';';
wwv_flow_imp.g_varchar2_table(51) := ''||wwv_flow.LF||
'comment on table sp_release_milestone_types is ''Available Milestone Types available for Releases. T';
wwv_flow_imp.g_varchar2_table(52) := 'he Releases feature can be disabled if not desired.'';'||wwv_flow.LF||
'comment on table sp_release_milestones is ''Mil';
wwv_flow_imp.g_varchar2_table(53) := 'estones associated with Releases. The Releases feature can be disabled if not desired.'';'||wwv_flow.LF||
'comment on ';
wwv_flow_imp.g_varchar2_table(54) := 'table sp_release_milestone_default_tags is ''Default quick picks for Release Milestone Tags. The Rele';
wwv_flow_imp.g_varchar2_table(55) := 'ases feature can be disabled if not desired.'';'||wwv_flow.LF||
'comment on table sp_release_documents is ''Documents a';
wwv_flow_imp.g_varchar2_table(56) := 'ssociated with Releases. The Releases feature can be disabled if not desired.'';'||wwv_flow.LF||
'comment on table sp_';
wwv_flow_imp.g_varchar2_table(57) := 'countries is ''Countries that are then associated with Team Members.'';'||wwv_flow.LF||
'comment on table SP_EXTERNAL_T';
wwv_flow_imp.g_varchar2_table(58) := 'ICKETING_SYSTEMS is ''Configurable patterns used to link Projects to external systems. Regular Expres';
wwv_flow_imp.g_varchar2_table(59) := 'sion patterns need to be part of project naming.'';'||wwv_flow.LF||
'comment on table sp_proj_interactions_log is ''Log';
wwv_flow_imp.g_varchar2_table(60) := ' of interactions with Projects and things related to Projects (e.g. Tasks).  Used to show Project In';
wwv_flow_imp.g_varchar2_table(61) := 'teractions on Project Details page.'';'||wwv_flow.LF||
'comment on table sp_activity_types is ''Available types of acti';
wwv_flow_imp.g_varchar2_table(62) := 'vities to be tracked.'';'||wwv_flow.LF||
'comment on table sp_activities is ''Work performed by Team Members defined wi';
wwv_flow_imp.g_varchar2_table(63) := 'thin this application.  These can be specific to a Project or general. The Activity Planning feature';
wwv_flow_imp.g_varchar2_table(64) := ' can be disabled if not desired.'';'||wwv_flow.LF||
'comment on table sp_favorites is ''All Projects that have been fav';
wwv_flow_imp.g_varchar2_table(65) := 'orited by Team Members.'';'||wwv_flow.LF||
'comment on table SP_CONFIGURABLE_TEXT is ''Supports clobs of text that are ';
wwv_flow_imp.g_varchar2_table(66) := 'displayed within the application but can be customized per install.  Currently, only used for the Ab';
wwv_flow_imp.g_varchar2_table(67) := 'out header.'';'||wwv_flow.LF||
'comment on table SP_DEFAULT_PEOPLE_TAGS is ''Default quick picks for Team Member Tags.''';
wwv_flow_imp.g_varchar2_table(68) := ';'||wwv_flow.LF||
'comment on table sp_initiative_comments is ''Comments associated with Initiatives, note that some m';
wwv_flow_imp.g_varchar2_table(69) := 'ight be private.'';'||wwv_flow.LF||
'comment on table SP_release_links is ''Links associated with Releases.'';'||wwv_flow.LF||
'comment o';
wwv_flow_imp.g_varchar2_table(70) := 'n table SP_INITIATIVE_LINKS is ''Links associated with Initiatives.'';'||wwv_flow.LF||
'comment on table sp_initiative_';
wwv_flow_imp.g_varchar2_table(71) := 'documents is ''Documents associated with Initiatives.'';'||wwv_flow.LF||
'comment on table sp_task_types is ''Available ';
wwv_flow_imp.g_varchar2_table(72) := 'task types and their details.  These categorize not only Tasks, but Reviews and Milestones as well.''';
wwv_flow_imp.g_varchar2_table(73) := ';'||wwv_flow.LF||
'comment on table sp_project_ai_summaries is ''All AI Summaries, both full and updates, that have be';
wwv_flow_imp.g_varchar2_table(74) := 'en generated for Projects.  This includes the details sent to AI along with the full JSON response s';
wwv_flow_imp.g_varchar2_table(75) := 'ent back. The AI Project Summaries feature can be disabled if not desired.'';'||wwv_flow.LF||
'comment on table sp_rel';
wwv_flow_imp.g_varchar2_table(76) := 'ease_ai_summaries is ''All AI Summaries that have been generated for Releases.  This includes the det';
wwv_flow_imp.g_varchar2_table(77) := 'ails sent to AI along with the full JSON response sent back. The AI Release Summaries feature can be';
wwv_flow_imp.g_varchar2_table(78) := ' disabled if not desired.'';'||wwv_flow.LF||
'comment on table SP_NOTIFICATIONS is ''List of reports that can be subscr';
wwv_flow_imp.g_varchar2_table(79) := 'ibed to.  This data should not be modified except via the UI where the description can be updated, a';
wwv_flow_imp.g_varchar2_table(80) := 'nd a report could be set as inactive.'';'||wwv_flow.LF||
'comment on table sp_notification_subscriptions is ''List of T';
wwv_flow_imp.g_varchar2_table(81) := 'eam Members and the Notifications they are either currently subscribed to or those they had previous';
wwv_flow_imp.g_varchar2_table(82) := 'ly been subscribed to. This includes whether they are currently opted in, what frequency the reports';
wwv_flow_imp.g_varchar2_table(83) := ' should be sent and when they received their last report.'';'||wwv_flow.LF||
'comment on table SP_APPLICATION_NOTIFICA';
wwv_flow_imp.g_varchar2_table(84) := 'TIONS is ''List of Home Page Messages displayed on the application Home page.  These can be permanent';
wwv_flow_imp.g_varchar2_table(85) := ' or display during an identified time frame. They can also be displayed to all or to just Team Membe';
wwv_flow_imp.g_varchar2_table(86) := 'rs with a specific tag.''; '||wwv_flow.LF||
'comment on table sp_team_member_notifications is ''All Notifications creat';
wwv_flow_imp.g_varchar2_table(87) := 'ed for Team Members.  This includes Project, Milestone, Review and Task assignments as well as Comme';
wwv_flow_imp.g_varchar2_table(88) := 'nt mentions. Each user decides how to get notifications (in App, Via Email, both or not at all).'';'||wwv_flow.LF||
'c';
wwv_flow_imp.g_varchar2_table(89) := 'omment on table sp_relation_types is ''List of Relations that are used to describe the relationship b';
wwv_flow_imp.g_varchar2_table(90) := 'etween two tasks when they are identified as related.'';'||wwv_flow.LF||
'comment on table sp_task_related is ''List of';
wwv_flow_imp.g_varchar2_table(91) := ' Tasks that are related, along with the type of relationship they have.'';'||wwv_flow.LF||
''||wwv_flow.LF||
'comment on table sp_appro';
wwv_flow_imp.g_varchar2_table(92) := 'val_types is ''Types of Approvals that can be associated with an Initiative, and therefore able to be';
wwv_flow_imp.g_varchar2_table(93) := ' requested for a Project within that Initiative. The Approvals feature can be disabled if not desire';
wwv_flow_imp.g_varchar2_table(94) := 'd.'';'||wwv_flow.LF||
'comment on table sp_initiative_approvals is ''All Approval Types that can be requested for Proje';
wwv_flow_imp.g_varchar2_table(95) := 'ct within a given Initiative. The Approvals feature can be disabled if not desired.'';'||wwv_flow.LF||
'comment on tab';
wwv_flow_imp.g_varchar2_table(96) := 'le sp_initiative_approval_chain is ''Ordered list of Team Members that review an Approval.  This is s';
wwv_flow_imp.g_varchar2_table(97) := 'pecific to an Initiative and reviewers can be set as inactive and can also have an alternate reviewe';
wwv_flow_imp.g_varchar2_table(98) := 'r set during a given time period (to accomodate vacations). The Approvals feature can be disabled if';
wwv_flow_imp.g_varchar2_table(99) := ' not desired.'';'||wwv_flow.LF||
'comment on table sp_project_approvals is ''All Approvals that have been requested for';
wwv_flow_imp.g_varchar2_table(100) := ' Projects, along with their current status. The Approvals feature can be disabled if not desired.'';'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(101) := 'comment on table sp_project_approval_chain is ''The history of each Team Member that reviewed each Ap';
wwv_flow_imp.g_varchar2_table(102) := 'proval requested along with any additional information requested and whether they approved or reject';
wwv_flow_imp.g_varchar2_table(103) := 'ed the request. The Approvals feature can be disabled if not desired.'';'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(39220751340360277551)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'Table Comments'
,p_sequence=>8500
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
