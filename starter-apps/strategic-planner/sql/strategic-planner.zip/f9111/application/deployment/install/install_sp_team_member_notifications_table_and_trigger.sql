prompt --application/deployment/install/install_sp_team_member_notifications_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_team_member_notifications table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_team_member_notifications ('||wwv_flow.LF||
'    id                             number default on nul';
wwv_flow_imp.g_varchar2_table(2) := 'l to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   cons';
wwv_flow_imp.g_varchar2_table(3) := 'traint sp_team_member_notifications_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    team_member_id                 number';
wwv_flow_imp.g_varchar2_table(4) := '  not null'||wwv_flow.LF||
'                                   constraint sp_team_member_notifications_tm_fk'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(5) := '                           references sp_team_members on delete cascade,'||wwv_flow.LF||
'    notification_pref      ';
wwv_flow_imp.g_varchar2_table(6) := '        varchar2(255),'||wwv_flow.LF||
'    title                          varchar2(255)  not null,'||wwv_flow.LF||
'    email_content';
wwv_flow_imp.g_varchar2_table(7) := 's                 varchar2(4000 char),'||wwv_flow.LF||
'    notification_type              varchar2(30 char),'||wwv_flow.LF||
'    pro';
wwv_flow_imp.g_varchar2_table(8) := 'ject_id                     number'||wwv_flow.LF||
'                                   constraint sp_team_member_noti';
wwv_flow_imp.g_varchar2_table(9) := 'fications_project_fk'||wwv_flow.LF||
'                                   references sp_projects on delete cascade,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(10) := '  task_id                        number '||wwv_flow.LF||
'                                   constraint sp_team_membe';
wwv_flow_imp.g_varchar2_table(11) := 'r_notifications_task_fk'||wwv_flow.LF||
'                                   references sp_tasks on delete cascade,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(12) := '  release_id                     number '||wwv_flow.LF||
'                                   constraint sp_team_membe';
wwv_flow_imp.g_varchar2_table(13) := 'r_notifications_release_fk'||wwv_flow.LF||
'                                   references sp_release_trains on delete';
wwv_flow_imp.g_varchar2_table(14) := ' cascade,'||wwv_flow.LF||
'    initiative_id                  number '||wwv_flow.LF||
'                                   constraint s';
wwv_flow_imp.g_varchar2_table(15) := 'p_team_member_notif_initiative_fk'||wwv_flow.LF||
'                                   references sp_initiatives on de';
wwv_flow_imp.g_varchar2_table(16) := 'lete cascade,'||wwv_flow.LF||
'    init_focus_area_id             number '||wwv_flow.LF||
'                                   constrai';
wwv_flow_imp.g_varchar2_table(17) := 'nt sp_team_member_notif_init_fa_fk'||wwv_flow.LF||
'                                   references sp_initiative_focus';
wwv_flow_imp.g_varchar2_table(18) := '_areas on delete cascade,'||wwv_flow.LF||
'    dismissed_yn                   varchar2(1 char)  default on null ''N'''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(19) := '                                  constraint sp_team_member_notifications_dismissed_cc'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(20) := '                      check (dismissed_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        d';
wwv_flow_imp.g_varchar2_table(21) := 'ate  not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated          ';
wwv_flow_imp.g_varchar2_table(22) := '              date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
'creat';
wwv_flow_imp.g_varchar2_table(23) := 'e index sp_team_member_notifications_i1 on sp_team_member_notifications (team_member_id);'||wwv_flow.LF||
'create ind';
wwv_flow_imp.g_varchar2_table(24) := 'ex sp_team_member_notifications_i2 on sp_team_member_notifications (project_id);'||wwv_flow.LF||
'create index sp_tea';
wwv_flow_imp.g_varchar2_table(25) := 'm_member_notifications_i3 on sp_team_member_notifications (created);'||wwv_flow.LF||
'create index sp_team_member_not';
wwv_flow_imp.g_varchar2_table(26) := 'ifications_i4 on sp_team_member_notifications (task_id);'||wwv_flow.LF||
'create index sp_team_member_notifications_i';
wwv_flow_imp.g_varchar2_table(27) := '5 on sp_team_member_notifications (release_id);'||wwv_flow.LF||
'create index sp_team_member_notifications_i6 on sp_t';
wwv_flow_imp.g_varchar2_table(28) := 'eam_member_notifications (initiative_id);'||wwv_flow.LF||
'create index sp_team_member_notifications_i7 on sp_team_me';
wwv_flow_imp.g_varchar2_table(29) := 'mber_notifications (init_focus_area_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_team_member_notifications_biu';
wwv_flow_imp.g_varchar2_table(30) := ''||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_team_member_notifications'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(31) := ' if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := ';
wwv_flow_imp.g_varchar2_table(32) := 'nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated   ';
wwv_flow_imp.g_varchar2_table(33) := ' := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(sys_context(';
wwv_flow_imp.g_varchar2_table(34) := '''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(35) := '   :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_team';
wwv_flow_imp.g_varchar2_table(36) := '_member_notifications_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(40710424119003372688)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_team_member_notifications table and trigger'
,p_sequence=>3550
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
