prompt --application/deployment/install/install_sample_data_insight_1_1
begin
--   Manifest
--     INSTALL: INSTALL-sample data - insight 1.1
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'sp_globals.g_audit_this := FALSE;'||wwv_flow.LF||
''||wwv_flow.LF||
'insert all'||wwv_flow.LF||
' into sp_projects (id,initiative_id,project,own';
wwv_flow_imp.g_varchar2_table(2) := 'er_id,active_yn,priority_id,release_id,target_complete,pct_complete,status_id,project_size,status_sc';
wwv_flow_imp.g_varchar2_table(3) := 'ale,description,tags,focus_area_id,created,created_by,updated,updated_by) values (8201,1,''Behavior D';
wwv_flow_imp.g_varchar2_table(4) := 'ashboard Filter Defects'',2,''N'',2,8,sp_util.fix_demo_dates(sysdate-27),100,1,''M'',''A'',''Fixes inconsist';
wwv_flow_imp.g_varchar2_table(5) := 'ent dashboard filters and incorrect saved-filter restoration.'',''insightiq,analytics,bug-fix'',6,sp_ut';
wwv_flow_imp.g_varchar2_table(6) := 'il.fix_demo_dates(sysdate-85),''MARCUS.HALE@ACME.COM'',sp_util.fix_demo_dates(sysdate-25),''MARCUS.HALE';
wwv_flow_imp.g_varchar2_table(7) := '@ACME.COM'')'||wwv_flow.LF||
' into sp_projects (id,initiative_id,project,owner_id,active_yn,priority_id,release_id,ta';
wwv_flow_imp.g_varchar2_table(8) := 'rget_complete,pct_complete,status_id,project_size,status_scale,description,tags,focus_area_id,create';
wwv_flow_imp.g_varchar2_table(9) := 'd,created_by,updated,updated_by) values (8202,3,''Recommendation API Latency Tuning'',4,''N'',1,8,sp_uti';
wwv_flow_imp.g_varchar2_table(10) := 'l.fix_demo_dates(sysdate-25),100,1,''L'',''A'',''Improves existing recommendation API response times and ';
wwv_flow_imp.g_varchar2_table(11) := 'timeout handling.'',''insightiq,ai,recommendations,performance'',30,sp_util.fix_demo_dates(sysdate-85),';
wwv_flow_imp.g_varchar2_table(12) := '''TYLER.BROOKS@ACME.COM'',sp_util.fix_demo_dates(sysdate-25),''TYLER.BROOKS@ACME.COM'')'||wwv_flow.LF||
' into sp_project';
wwv_flow_imp.g_varchar2_table(13) := 's (id,initiative_id,project,owner_id,active_yn,priority_id,release_id,target_complete,pct_complete,s';
wwv_flow_imp.g_varchar2_table(14) := 'tatus_id,project_size,status_scale,description,tags,focus_area_id,created,created_by,updated,updated';
wwv_flow_imp.g_varchar2_table(15) := '_by) values (8203,3,''Forecast Confidence Band Correction'',6,''N'',2,8,sp_util.fix_demo_dates(sysdate-2';
wwv_flow_imp.g_varchar2_table(16) := '8),100,1,''M'',''A'',''Corrects confidence-band calculations in the existing demand forecasting models.'',';
wwv_flow_imp.g_varchar2_table(17) := '''insightiq,ai,forecasting,bug-fix'',30,sp_util.fix_demo_dates(sysdate-85),''JORDAN.AVERY@ACME.COM'',sp_';
wwv_flow_imp.g_varchar2_table(18) := 'util.fix_demo_dates(sysdate-25),''JORDAN.AVERY@ACME.COM'')'||wwv_flow.LF||
' into sp_projects (id,initiative_id,project';
wwv_flow_imp.g_varchar2_table(19) := ',owner_id,active_yn,priority_id,release_id,target_complete,pct_complete,status_id,project_size,statu';
wwv_flow_imp.g_varchar2_table(20) := 's_scale,description,tags,focus_area_id,created,created_by,updated,updated_by) values (8204,1,''Journe';
wwv_flow_imp.g_varchar2_table(21) := 'y Event Deduplication'',8,''N'',2,8,sp_util.fix_demo_dates(sysdate-26),100,1,''M'',''A'',''Removes duplicate';
wwv_flow_imp.g_varchar2_table(22) := ' customer journey events and corrects conversion totals.'',''insightiq,customer-systems,data-quality'',';
wwv_flow_imp.g_varchar2_table(23) := '1,sp_util.fix_demo_dates(sysdate-85),''LILA.MONTGOMERY@ACME.COM'',sp_util.fix_demo_dates(sysdate-25),''';
wwv_flow_imp.g_varchar2_table(24) := 'LILA.MONTGOMERY@ACME.COM'')'||wwv_flow.LF||
' into sp_projects (id,initiative_id,project,owner_id,active_yn,priority_i';
wwv_flow_imp.g_varchar2_table(25) := 'd,release_id,target_complete,pct_complete,status_id,project_size,status_scale,description,tags,focus';
wwv_flow_imp.g_varchar2_table(26) := '_area_id,created,created_by,updated,updated_by) values (8205,1,''Executive Dashboard Export Fixes'',10';
wwv_flow_imp.g_varchar2_table(27) := ',''N'',3,8,sp_util.fix_demo_dates(sysdate-25),100,1,''S'',''A'',''Fixes PDF export formatting and timezone ';
wwv_flow_imp.g_varchar2_table(28) := 'display in executive dashboards.'',''insightiq,analytics,dashboards,bug-fix'',6,sp_util.fix_demo_dates(';
wwv_flow_imp.g_varchar2_table(29) := 'sysdate-85),''SOPHIE.BENNETT@ACME.COM'',sp_util.fix_demo_dates(sysdate-25),''SOPHIE.BENNETT@ACME.COM'')'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(30) := ' into sp_projects (id,initiative_id,project,owner_id,active_yn,priority_id,release_id,target_complet';
wwv_flow_imp.g_varchar2_table(31) := 'e,pct_complete,status_id,project_size,status_scale,description,tags,focus_area_id,created,created_by';
wwv_flow_imp.g_varchar2_table(32) := ',updated,updated_by) values (8206,1,''Analytics Access Audit Hardening'',12,''N'',1,8,sp_util.fix_demo_d';
wwv_flow_imp.g_varchar2_table(33) := 'ates(sysdate-25),100,1,''M'',''A'',''Strengthens audit-event coverage and resolves access-control edge ca';
wwv_flow_imp.g_varchar2_table(34) := 'ses.'',''insightiq,security,audit,bug-fix'',4,sp_util.fix_demo_dates(sysdate-85),''HANNAH.DOYLE@ACME.COM';
wwv_flow_imp.g_varchar2_table(35) := ''',sp_util.fix_demo_dates(sysdate-25),''HANNAH.DOYLE@ACME.COM'')'||wwv_flow.LF||
'select 1 from dual;'||wwv_flow.LF||
''||wwv_flow.LF||
'insert all'||wwv_flow.LF||
' into ';
wwv_flow_imp.g_varchar2_table(36) := 'sp_project_contributors (id,project_id,team_member_id,responsibility_id,responsibility,tags,created,';
wwv_flow_imp.g_varchar2_table(37) := 'created_by,updated,updated_by) values (8301,8201,2,3,''Coordinates dashboard defect resolution.'',''pro';
wwv_flow_imp.g_varchar2_table(38) := 'ject-management'',sp_util.fix_demo_dates(sysdate-82),''MARCUS.HALE@ACME.COM'',sp_util.fix_demo_dates(sy';
wwv_flow_imp.g_varchar2_table(39) := 'sdate-82),''MARCUS.HALE@ACME.COM'') into sp_project_contributors (id,project_id,team_member_id,respons';
wwv_flow_imp.g_varchar2_table(40) := 'ibility_id,responsibility,tags,created,created_by,updated,updated_by) values (8302,8201,1,1,''Fixes f';
wwv_flow_imp.g_varchar2_table(41) := 'iltering behavior.'',''analytics,development'',sp_util.fix_demo_dates(sysdate-82),''MARCUS.HALE@ACME.COM';
wwv_flow_imp.g_varchar2_table(42) := ''',sp_util.fix_demo_dates(sysdate-82),''MARCUS.HALE@ACME.COM'')'||wwv_flow.LF||
' into sp_project_contributors (id,proje';
wwv_flow_imp.g_varchar2_table(43) := 'ct_id,team_member_id,responsibility_id,responsibility,tags,created,created_by,updated,updated_by) va';
wwv_flow_imp.g_varchar2_table(44) := 'lues (8303,8202,4,3,''Coordinates API performance work.'',''project-management'',sp_util.fix_demo_dates(';
wwv_flow_imp.g_varchar2_table(45) := 'sysdate-82),''TYLER.BROOKS@ACME.COM'',sp_util.fix_demo_dates(sysdate-82),''TYLER.BROOKS@ACME.COM'') into';
wwv_flow_imp.g_varchar2_table(46) := ' sp_project_contributors (id,project_id,team_member_id,responsibility_id,responsibility,tags,created';
wwv_flow_imp.g_varchar2_table(47) := ',created_by,updated,updated_by) values (8304,8202,3,1,''Tunes recommendation service.'',''ai,developmen';
wwv_flow_imp.g_varchar2_table(48) := 't'',sp_util.fix_demo_dates(sysdate-82),''TYLER.BROOKS@ACME.COM'',sp_util.fix_demo_dates(sysdate-82),''TY';
wwv_flow_imp.g_varchar2_table(49) := 'LER.BROOKS@ACME.COM'')'||wwv_flow.LF||
' into sp_project_contributors (id,project_id,team_member_id,responsibility_id,';
wwv_flow_imp.g_varchar2_table(50) := 'responsibility,tags,created,created_by,updated,updated_by) values (8305,8203,6,3,''Coordinates foreca';
wwv_flow_imp.g_varchar2_table(51) := 'sting correction.'',''project-management'',sp_util.fix_demo_dates(sysdate-82),''JORDAN.AVERY@ACME.COM'',s';
wwv_flow_imp.g_varchar2_table(52) := 'p_util.fix_demo_dates(sysdate-82),''JORDAN.AVERY@ACME.COM'') into sp_project_contributors (id,project_';
wwv_flow_imp.g_varchar2_table(53) := 'id,team_member_id,responsibility_id,responsibility,tags,created,created_by,updated,updated_by) value';
wwv_flow_imp.g_varchar2_table(54) := 's (8306,8203,5,7,''Validates forecast calculations.'',''research,ai'',sp_util.fix_demo_dates(sysdate-82)';
wwv_flow_imp.g_varchar2_table(55) := ',''JORDAN.AVERY@ACME.COM'',sp_util.fix_demo_dates(sysdate-82),''JORDAN.AVERY@ACME.COM'')'||wwv_flow.LF||
' into sp_projec';
wwv_flow_imp.g_varchar2_table(56) := 't_contributors (id,project_id,team_member_id,responsibility_id,responsibility,tags,created,created_b';
wwv_flow_imp.g_varchar2_table(57) := 'y,updated,updated_by) values (8307,8204,8,3,''Coordinates journey data correction.'',''project-manageme';
wwv_flow_imp.g_varchar2_table(58) := 'nt'',sp_util.fix_demo_dates(sysdate-82),''LILA.MONTGOMERY@ACME.COM'',sp_util.fix_demo_dates(sysdate-82)';
wwv_flow_imp.g_varchar2_table(59) := ',''LILA.MONTGOMERY@ACME.COM'') into sp_project_contributors (id,project_id,team_member_id,responsibili';
wwv_flow_imp.g_varchar2_table(60) := 'ty_id,responsibility,tags,created,created_by,updated,updated_by) values (8308,8204,7,1,''Fixes event ';
wwv_flow_imp.g_varchar2_table(61) := 'processing.'',''customer-systems,development'',sp_util.fix_demo_dates(sysdate-82),''LILA.MONTGOMERY@ACME';
wwv_flow_imp.g_varchar2_table(62) := '.COM'',sp_util.fix_demo_dates(sysdate-82),''LILA.MONTGOMERY@ACME.COM'')'||wwv_flow.LF||
' into sp_project_contributors (';
wwv_flow_imp.g_varchar2_table(63) := 'id,project_id,team_member_id,responsibility_id,responsibility,tags,created,created_by,updated,update';
wwv_flow_imp.g_varchar2_table(64) := 'd_by) values (8309,8205,10,3,''Coordinates export fixes.'',''project-management'',sp_util.fix_demo_dates';
wwv_flow_imp.g_varchar2_table(65) := '(sysdate-82),''SOPHIE.BENNETT@ACME.COM'',sp_util.fix_demo_dates(sysdate-82),''SOPHIE.BENNETT@ACME.COM'')';
wwv_flow_imp.g_varchar2_table(66) := ' into sp_project_contributors (id,project_id,team_member_id,responsibility_id,responsibility,tags,cr';
wwv_flow_imp.g_varchar2_table(67) := 'eated,created_by,updated,updated_by) values (8310,8205,9,5,''Validates dashboard exports.'',''qa,analyt';
wwv_flow_imp.g_varchar2_table(68) := 'ics'',sp_util.fix_demo_dates(sysdate-82),''SOPHIE.BENNETT@ACME.COM'',sp_util.fix_demo_dates(sysdate-82)';
wwv_flow_imp.g_varchar2_table(69) := ',''SOPHIE.BENNETT@ACME.COM'')'||wwv_flow.LF||
' into sp_project_contributors (id,project_id,team_member_id,responsibili';
wwv_flow_imp.g_varchar2_table(70) := 'ty_id,responsibility,tags,created,created_by,updated,updated_by) values (8311,8206,12,3,''Coordinates';
wwv_flow_imp.g_varchar2_table(71) := ' audit hardening.'',''project-management'',sp_util.fix_demo_dates(sysdate-82),''HANNAH.DOYLE@ACME.COM'',s';
wwv_flow_imp.g_varchar2_table(72) := 'p_util.fix_demo_dates(sysdate-82),''HANNAH.DOYLE@ACME.COM'') into sp_project_contributors (id,project_';
wwv_flow_imp.g_varchar2_table(73) := 'id,team_member_id,responsibility_id,responsibility,tags,created,created_by,updated,updated_by) value';
wwv_flow_imp.g_varchar2_table(74) := 's (8312,8206,11,2,''Reviews access-control architecture.'',''security,architecture'',sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(75) := 'tes(sysdate-82),''HANNAH.DOYLE@ACME.COM'',sp_util.fix_demo_dates(sysdate-82),''HANNAH.DOYLE@ACME.COM'')'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(76) := 'select 1 from dual;'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_project_comments (id,project_id,author_id,body,body_html,body_no';
wwv_flow_imp.g_varchar2_table(77) := '_images,private_yn,created,created_by,updated,updated_by) values (9301,8201,2,''Saved-filter restorat';
wwv_flow_imp.g_varchar2_table(78) := 'ion now uses the selected dashboard context.'',''Saved-filter restoration now uses the selected dashbo';
wwv_flow_imp.g_varchar2_table(79) := 'ard context.'',''Saved-filter restoration now uses the selected dashboard context.'',''N'',sp_util.fix_de';
wwv_flow_imp.g_varchar2_table(80) := 'mo_dates(sysdate-60),''MARCUS.HALE@ACME.COM'',sp_util.fix_demo_dates(sysdate-60),''MARCUS.HALE@ACME.COM';
wwv_flow_imp.g_varchar2_table(81) := ''');'||wwv_flow.LF||
'insert into sp_project_comments (id,project_id,author_id,body,body_html,body_no_images,private_y';
wwv_flow_imp.g_varchar2_table(82) := 'n,created,created_by,updated,updated_by) values (9302,8202,4,''API timeout handling was tuned without';
wwv_flow_imp.g_varchar2_table(83) := ' changing recommendation behavior.'',''API timeout handling was tuned without changing recommendation ';
wwv_flow_imp.g_varchar2_table(84) := 'behavior.'',''API timeout handling was tuned without changing recommendation behavior.'',''N'',sp_util.fi';
wwv_flow_imp.g_varchar2_table(85) := 'x_demo_dates(sysdate-60),''TYLER.BROOKS@ACME.COM'',sp_util.fix_demo_dates(sysdate-60),''TYLER.BROOKS@AC';
wwv_flow_imp.g_varchar2_table(86) := 'ME.COM'');'||wwv_flow.LF||
'insert into sp_project_comments (id,project_id,author_id,body,body_html,body_no_images,pri';
wwv_flow_imp.g_varchar2_table(87) := 'vate_yn,created,created_by,updated,updated_by) values (9303,8203,6,''Forecast confidence calculations';
wwv_flow_imp.g_varchar2_table(88) := ' were corrected and regression-tested.'',''Forecast confidence calculations were corrected and regress';
wwv_flow_imp.g_varchar2_table(89) := 'ion-tested.'',''Forecast confidence calculations were corrected and regression-tested.'',''N'',sp_util.fi';
wwv_flow_imp.g_varchar2_table(90) := 'x_demo_dates(sysdate-60),''JORDAN.AVERY@ACME.COM'',sp_util.fix_demo_dates(sysdate-60),''JORDAN.AVERY@AC';
wwv_flow_imp.g_varchar2_table(91) := 'ME.COM'');'||wwv_flow.LF||
'insert into sp_project_comments (id,project_id,author_id,body,body_html,body_no_images,pri';
wwv_flow_imp.g_varchar2_table(92) := 'vate_yn,created,created_by,updated,updated_by) values (9304,8204,8,''Duplicate journey events are now';
wwv_flow_imp.g_varchar2_table(93) := ' rejected before aggregation.'',''Duplicate journey events are now rejected before aggregation.'',''Dupl';
wwv_flow_imp.g_varchar2_table(94) := 'icate journey events are now rejected before aggregation.'',''N'',sp_util.fix_demo_dates(sysdate-60),''L';
wwv_flow_imp.g_varchar2_table(95) := 'ILA.MONTGOMERY@ACME.COM'',sp_util.fix_demo_dates(sysdate-60),''LILA.MONTGOMERY@ACME.COM'');'||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(96) := ' sp_project_comments (id,project_id,author_id,body,body_html,body_no_images,private_yn,created,creat';
wwv_flow_imp.g_varchar2_table(97) := 'ed_by,updated,updated_by) values (9305,8205,10,''Export formatting and timezone handling were verifie';
wwv_flow_imp.g_varchar2_table(98) := 'd with Finance.'',''Export formatting and timezone handling were verified with Finance.'',''Export forma';
wwv_flow_imp.g_varchar2_table(99) := 'tting and timezone handling were verified with Finance.'',''N'',sp_util.fix_demo_dates(sysdate-60),''SOP';
wwv_flow_imp.g_varchar2_table(100) := 'HIE.BENNETT@ACME.COM'',sp_util.fix_demo_dates(sysdate-60),''SOPHIE.BENNETT@ACME.COM'');'||wwv_flow.LF||
'insert into sp_';
wwv_flow_imp.g_varchar2_table(101) := 'project_comments (id,project_id,author_id,body,body_html,body_no_images,private_yn,created,created_b';
wwv_flow_imp.g_varchar2_table(102) := 'y,updated,updated_by) values (9306,8206,12,''Security approved the expanded analytics access audit co';
wwv_flow_imp.g_varchar2_table(103) := 'verage.'',''Security approved the expanded analytics access audit coverage.'',''Security approved the ex';
wwv_flow_imp.g_varchar2_table(104) := 'panded analytics access audit coverage.'',''N'',sp_util.fix_demo_dates(sysdate-60),''HANNAH.DOYLE@ACME.C';
wwv_flow_imp.g_varchar2_table(105) := 'OM'',sp_util.fix_demo_dates(sysdate-60),''HANNAH.DOYLE@ACME.COM'');'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_tasks'||wwv_flow.LF||
' (id,project';
wwv_flow_imp.g_varchar2_table(106) := '_id,task,task_type_id,task_sub_type_id,owner_id,start_date,target_complete,status_id,status_last_cha';
wwv_flow_imp.g_varchar2_table(107) := 'nged_on,description,tags,display_sequence,impact,created,created_by,updated,updated_by)'||wwv_flow.LF||
'select 8400+';
wwv_flow_imp.g_varchar2_table(108) := '(p.project_id-8200)*10+t.seq,p.project_id,t.task,t.task_type_id,null,p.owner_id,'||wwv_flow.LF||
' sp_util.fix_demo_d';
wwv_flow_imp.g_varchar2_table(109) := 'ates(sysdate+t.start_offset),sp_util.fix_demo_dates(sysdate+t.complete_offset),t.status_id,sp_util.f';
wwv_flow_imp.g_varchar2_table(110) := 'ix_demo_dates(sysdate+t.complete_offset),t.description,t.tags,t.seq*10,t.impact,sp_util.fix_demo_dat';
wwv_flow_imp.g_varchar2_table(111) := 'es(sysdate-85),case p.owner_id when 2 then ''MARCUS.HALE@ACME.COM'' when 4 then ''TYLER.BROOKS@ACME.COM';
wwv_flow_imp.g_varchar2_table(112) := ''' when 6 then ''JORDAN.AVERY@ACME.COM'' when 8 then ''LILA.MONTGOMERY@ACME.COM'' when 10 then ''SOPHIE.BE';
wwv_flow_imp.g_varchar2_table(113) := 'NNETT@ACME.COM'' when 12 then ''HANNAH.DOYLE@ACME.COM'' end,sp_util.fix_demo_dates(sysdate+t.complete_o';
wwv_flow_imp.g_varchar2_table(114) := 'ffset),case p.owner_id when 2 then ''MARCUS.HALE@ACME.COM'' when 4 then ''TYLER.BROOKS@ACME.COM'' when 6';
wwv_flow_imp.g_varchar2_table(115) := ' then ''JORDAN.AVERY@ACME.COM'' when 8 then ''LILA.MONTGOMERY@ACME.COM'' when 10 then ''SOPHIE.BENNETT@AC';
wwv_flow_imp.g_varchar2_table(116) := 'ME.COM'' when 12 then ''HANNAH.DOYLE@ACME.COM'' end'||wwv_flow.LF||
'from (select 8201 project_id,2 owner_id from dual u';
wwv_flow_imp.g_varchar2_table(117) := 'nion all select 8202,4 from dual union all select 8203,6 from dual union all select 8204,8 from dual';
wwv_flow_imp.g_varchar2_table(118) := ' union all select 8205,10 from dual union all select 8206,12 from dual) p'||wwv_flow.LF||
'cross join (select 1 seq,''';
wwv_flow_imp.g_varchar2_table(119) := 'Spec Complete'' task,21 task_type_id,-80 start_offset,-74 complete_offset,14 status_id,''Patch scope a';
wwv_flow_imp.g_varchar2_table(120) := 'pproved.'' description,''milestone,spec'' tags,cast(null as varchar2(30)) impact from dual union all se';
wwv_flow_imp.g_varchar2_table(121) := 'lect 2,''Code Complete'',23,-50,-40,14,''Fix implementation complete.'',''milestone,code'',cast(null as va';
wwv_flow_imp.g_varchar2_table(122) := 'rchar2(30)) from dual union all select 3,''Merged'',24,-38,-35,14,''Merged before code freeze.'',''milest';
wwv_flow_imp.g_varchar2_table(123) := 'one,merge'',cast(null as varchar2(30)) from dual union all select 4,''Peer Review'',4,-55,-48,8,''Peer r';
wwv_flow_imp.g_varchar2_table(124) := 'eview completed.'',''review,peer'',''Medium'' from dual) t;'||wwv_flow.LF||
''||wwv_flow.LF||
'sp_globals.g_audit_this := TRUE;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(125) := '    when others then'||wwv_flow.LF||
'        sp_globals.g_audit_this := TRUE;'||wwv_flow.LF||
'end;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(454645375120801709)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sample data - insight 1.1'
,p_sequence=>9260
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
