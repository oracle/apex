prompt --application/deployment/install/install_sp_release_trains_triggers
begin
--   Manifest
--     INSTALL: INSTALL-sp_release_trains triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_release_trains_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_release_trains';
wwv_flow_imp.g_varchar2_table(2) := ''||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_old_value   varchar2(4000) := null;'||wwv_flow.LF||
'    l_new_value   varchar2(4000)';
wwv_flow_imp.g_varchar2_table(3) := ' := null;'||wwv_flow.LF||
'    l_changed_by  varchar2(255)  := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created';
wwv_flow_imp.g_varchar2_table(4) := '    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coalesce(sys_conte';
wwv_flow_imp.g_varchar2_table(5) := 'xt(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(6) := ':new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(7) := 'elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_cont';
wwv_flow_imp.g_varchar2_table(8) := 'ext(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- defaults'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.release_';
wwv_flow_imp.g_varchar2_table(9) := 'completed is null then '||wwv_flow.LF||
'       :new.release_completed := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.RELEASE_OPEN_C';
wwv_flow_imp.g_varchar2_table(10) := 'OMPLETED is null then'||wwv_flow.LF||
'       :new.RELEASE_OPEN_COMPLETED := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- change hi';
wwv_flow_imp.g_varchar2_table(11) := 'story tracking'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        l_changed_by := lower(:new.updated_by);'||wwv_flow.LF||
'        -';
wwv_flow_imp.g_varchar2_table(12) := '-'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.release_train,:new.release_train) then'||wwv_flow.LF||
'           in';
wwv_flow_imp.g_varchar2_table(13) := 'sert into sp_release_history'||wwv_flow.LF||
'               (release_id, attribute_column, change_type, old_value, n';
wwv_flow_imp.g_varchar2_table(14) := 'ew_value, changed_on, changed_by)'||wwv_flow.LF||
'           values'||wwv_flow.LF||
'               (:new.id, ''RELEASE_TRAIN'', ''UPDAT';
wwv_flow_imp.g_varchar2_table(15) := 'E'', :old.release_train, :new.release_train, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not s';
wwv_flow_imp.g_varchar2_table(16) := 'p_value_compare.is_equal(:old.release,:new.release) then'||wwv_flow.LF||
'           insert into sp_release_history'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(17) := '              (release_id, attribute_column, change_type, old_value, new_value, changed_on, changed_';
wwv_flow_imp.g_varchar2_table(18) := 'by)'||wwv_flow.LF||
'           values'||wwv_flow.LF||
'               (:new.id, ''RELEASE'', ''UPDATE'', :old.release, :new.release, sysd';
wwv_flow_imp.g_varchar2_table(19) := 'ate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.RELEASE_OWNER_ID,:';
wwv_flow_imp.g_varchar2_table(20) := 'new.RELEASE_OWNER_ID) then'||wwv_flow.LF||
'           for c1 in (select email v from sp_team_members x where x.id = ';
wwv_flow_imp.g_varchar2_table(21) := ':old.RELEASE_OWNER_ID) loop l_old_value := c1.v; end loop;'||wwv_flow.LF||
'           for c1 in (select email v from';
wwv_flow_imp.g_varchar2_table(22) := ' sp_team_members x where x.id = :new.RELEASE_OWNER_ID) loop l_new_value := c1.v; end loop;'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(23) := '  insert into sp_release_history'||wwv_flow.LF||
'               (release_id, attribute_column, change_type, old_valu';
wwv_flow_imp.g_varchar2_table(24) := 'e, new_value, changed_on, changed_by)'||wwv_flow.LF||
'           values'||wwv_flow.LF||
'               (:new.id, ''RELEASE_OWNER'', ''U';
wwv_flow_imp.g_varchar2_table(25) := 'PDATE'', l_old_value, l_new_value, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(26) := ' if not sp_value_compare.is_equal(:old.RELEASE_OPEN_DATE,:new.RELEASE_OPEN_DATE) then'||wwv_flow.LF||
'          inse';
wwv_flow_imp.g_varchar2_table(27) := 'rt into sp_release_history'||wwv_flow.LF||
'              (release_id, attribute_column, change_type, old_value, new_';
wwv_flow_imp.g_varchar2_table(28) := 'value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''RELEASE_OPEN_DATE'', ''UPDATE';
wwv_flow_imp.g_varchar2_table(29) := ''', to_char(:old.RELEASE_OPEN_DATE,''DD-MON-YYYY''), to_char(:new.RELEASE_OPEN_DATE,''DD-MON-YYYY''), sys';
wwv_flow_imp.g_varchar2_table(30) := 'date, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.RELEASE_OPEN_COMPLE';
wwv_flow_imp.g_varchar2_table(31) := 'TED,:new.RELEASE_OPEN_COMPLETED) then'||wwv_flow.LF||
'          insert into sp_release_history'||wwv_flow.LF||
'              (releas';
wwv_flow_imp.g_varchar2_table(32) := 'e_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(33) := '              (:new.id, ''RELEASE_OPEN_COMPLETED'', ''UPDATE'', :old.RELEASE_OPEN_COMPLETED, :new.RELEAS';
wwv_flow_imp.g_varchar2_table(34) := 'E_OPEN_COMPLETED, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is';
wwv_flow_imp.g_varchar2_table(35) := '_equal(:old.RELEASE_TARGET_DATE,:new.RELEASE_TARGET_DATE) then'||wwv_flow.LF||
'          insert into sp_release_hist';
wwv_flow_imp.g_varchar2_table(36) := 'ory'||wwv_flow.LF||
'              (release_id, attribute_column, change_type, old_value, new_value, changed_on, chan';
wwv_flow_imp.g_varchar2_table(37) := 'ged_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''RELEASE_TARGET_DATE'', ''UPDATE'', to_char(:old.RELEA';
wwv_flow_imp.g_varchar2_table(38) := 'SE_TARGET_DATE,''DD-MON-YYYY''), to_char(:new.RELEASE_TARGET_DATE,''DD-MON-YYYY''), sysdate, l_changed_b';
wwv_flow_imp.g_varchar2_table(39) := 'y);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.RELEASE_COMPLETED,:new.RELEASE_COMPL';
wwv_flow_imp.g_varchar2_table(40) := 'ETED) then'||wwv_flow.LF||
'          insert into sp_release_history'||wwv_flow.LF||
'              (release_id, attribute_column, cha';
wwv_flow_imp.g_varchar2_table(41) := 'nge_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''RE';
wwv_flow_imp.g_varchar2_table(42) := 'LEASE_COMPLETED'', ''UPDATE'', :old.RELEASE_COMPLETED, :new.RELEASE_COMPLETED, sysdate, l_changed_by);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(43) := '       end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_release_trains_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_release_trains';
wwv_flow_imp.g_varchar2_table(44) := '_ai'||wwv_flow.LF||
'    after insert'||wwv_flow.LF||
'    on sp_release_trains'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_release_hist';
wwv_flow_imp.g_varchar2_table(45) := 'ory'||wwv_flow.LF||
'        (release_id, attribute_column, change_type, new_value, changed_on, changed_by)'||wwv_flow.LF||
'    value';
wwv_flow_imp.g_varchar2_table(46) := 's'||wwv_flow.LF||
'        (:new.id, ''RELEASE'', ''CREATE'', :new.release_train || '' '' ||:new.release, sysdate, lower(:n';
wwv_flow_imp.g_varchar2_table(47) := 'ew.created_by));'||wwv_flow.LF||
'end sp_release_trains_ai;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_release_trains_bd'||wwv_flow.LF||
'    bef';
wwv_flow_imp.g_varchar2_table(48) := 'ore delete'||wwv_flow.LF||
'    on sp_release_trains'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_release_history'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(49) := '  (release_id, attribute_column, change_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(50) := '(:old.id, ''RELEASE'', ''DELETE'', :old.release_train || '' '' ||:old.release, sysdate, lower(coalesce(sys';
wwv_flow_imp.g_varchar2_table(51) := '_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'end sp_release_trains_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(39232704596824323245)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_release_trains triggers'
,p_sequence=>4020
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
