prompt --application/deployment/install/install_sp_summary_util_spec
begin
--   Manifest
--     INSTALL: INSTALL-sp_summary_util spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package sp_summary_util as'||wwv_flow.LF||
''||wwv_flow.LF||
'g_hrs_to_replace  number := 6;'||wwv_flow.LF||
''||wwv_flow.LF||
'function ai_summary_in';
wwv_flow_imp.g_varchar2_table(2) := 'fo ('||wwv_flow.LF||
'    p_type  in  varchar2 )'||wwv_flow.LF||
'    return clob;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- used for generative ai agent'||wwv_flow.LF||
'function generate_';
wwv_flow_imp.g_varchar2_table(3) := 'project_md ('||wwv_flow.LF||
'    p_project_id   in  number,'||wwv_flow.LF||
'    p_app_user_id  in  number )'||wwv_flow.LF||
'    return clob;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- use';
wwv_flow_imp.g_varchar2_table(4) := 'd in UI for getting high-level project details in markdown format'||wwv_flow.LF||
'function generate_project_high_lev';
wwv_flow_imp.g_varchar2_table(5) := 'el ('||wwv_flow.LF||
'    p_project_id  in  number )'||wwv_flow.LF||
'    return clob;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- can be run from APEX App UI (not SQL Comman';
wwv_flow_imp.g_varchar2_table(6) := 'ds) '||wwv_flow.LF||
'--  or from within a job (if session context is set)'||wwv_flow.LF||
'procedure generate_project_summary ('||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(7) := '_project_id    in   number,'||wwv_flow.LF||
'    p_summary_type  in   varchar2,'||wwv_flow.LF||
'    p_ai_id         out  number,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(8) := 'p_error_yn      out  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'-- run as a job, once a week (cannot be run via SQL Commands)'||wwv_flow.LF||
'proc';
wwv_flow_imp.g_varchar2_table(9) := 'edure generate_project_summaries;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- can be run from APEX App UI (not SQL Commands) or from within ';
wwv_flow_imp.g_varchar2_table(10) := 'a job (if session context is set)'||wwv_flow.LF||
'procedure generate_release_summary ('||wwv_flow.LF||
'    p_release_id  in   number';
wwv_flow_imp.g_varchar2_table(11) := ','||wwv_flow.LF||
'    p_error_yn    out  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_summary_util;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(27818825302399250916)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_summary_util spec'
,p_sequence=>2060
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
