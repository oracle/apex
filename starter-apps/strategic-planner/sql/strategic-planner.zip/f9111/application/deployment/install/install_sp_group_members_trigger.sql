prompt --application/deployment/install/install_sp_group_members_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_group_members trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_group_members_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_group_members'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(2) := '   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(3) := '      :new.created_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user))';
wwv_flow_imp.g_varchar2_table(4) := ';'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_';
wwv_flow_imp.g_varchar2_table(5) := 'by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.upd';
wwv_flow_imp.g_varchar2_table(6) := 'ated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)';
wwv_flow_imp.g_varchar2_table(7) := ';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_group_members_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(45886298610454374026)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_group_members trigger'
,p_sequence=>4040
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
