prompt --application/deployment/install/install_sp_approvals_body
begin
--   Manifest
--     INSTALL: INSTALL-sp_approvals body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body sp_approvals'||wwv_flow.LF||
'as'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure submit_for_approval ('||wwv_flow.LF||
'    p_project_id    ';
wwv_flow_imp.g_varchar2_table(2) := '       in  number,'||wwv_flow.LF||
'    p_approval_type_id     in  number,'||wwv_flow.LF||
'    p_team_member_id       in  number,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(3) := ' p_justification        in  varchar2,'||wwv_flow.LF||
'    p_project_approval_id  out number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in';
wwv_flow_imp.g_varchar2_table(4) := ' ('||wwv_flow.LF||
'        select i.id initiative_approval_id,'||wwv_flow.LF||
'               (select count(*) from sp_initiative_ap';
wwv_flow_imp.g_varchar2_table(5) := 'proval_chain'||wwv_flow.LF||
'                 where initiative_approval_id = i.id'||wwv_flow.LF||
'                   and active_yn =';
wwv_flow_imp.g_varchar2_table(6) := ' ''Y'') approvers_cnt'||wwv_flow.LF||
'          from sp_projects p,'||wwv_flow.LF||
'               sp_initiative_approvals i'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(7) := 'where p.id = p_project_id'||wwv_flow.LF||
'           and p.initiative_id = i.initiative_id'||wwv_flow.LF||
'           and i.approval';
wwv_flow_imp.g_varchar2_table(8) := '_type_id = p_approval_type_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        insert into sp_project_approvals'||wwv_flow.LF||
'            (appro';
wwv_flow_imp.g_varchar2_table(9) := 'val_type_id, project_id, submitted_by_team_member_id, justification, initiative_approval_id)'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(10) := ' values'||wwv_flow.LF||
'            (p_approval_type_id, p_project_id, p_team_member_id, p_justification, c1.initiat';
wwv_flow_imp.g_varchar2_table(11) := 'ive_approval_id)'||wwv_flow.LF||
'        returning id into p_project_approval_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'        if c1.in';
wwv_flow_imp.g_varchar2_table(12) := 'itiative_approval_id is null then '||wwv_flow.LF||
'            -- no approval chain'||wwv_flow.LF||
'            update sp_project_ap';
wwv_flow_imp.g_varchar2_table(13) := 'provals'||wwv_flow.LF||
'               set status = ''NO-APPROVAL'''||wwv_flow.LF||
'             where id = p_project_approval_id;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(14) := '     elsif c1.approvers_cnt = 0 then '||wwv_flow.LF||
'            -- no approvers'||wwv_flow.LF||
'            update sp_project_appr';
wwv_flow_imp.g_varchar2_table(15) := 'ovals'||wwv_flow.LF||
'               set status = ''NO-APPROVERS'''||wwv_flow.LF||
'             where id = p_project_approval_id;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(16) := '    else '||wwv_flow.LF||
'            -- if submittor is in approval chain, auto-approve that person'||wwv_flow.LF||
'            for';
wwv_flow_imp.g_varchar2_table(17) := ' c2 in ('||wwv_flow.LF||
'                select id'||wwv_flow.LF||
'                  from sp_initiative_approval_chain'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(18) := '    where initiative_approval_id = c1.initiative_approval_id'||wwv_flow.LF||
'                   and (team_member_id ';
wwv_flow_imp.g_varchar2_table(19) := '= p_team_member_id or '||wwv_flow.LF||
'                        (alternate_team_member_id = p_team_member_id and'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(20) := '                     nvl(alternate_start_date,sysdate) <= sysdate and'||wwv_flow.LF||
'                         nvl(a';
wwv_flow_imp.g_varchar2_table(21) := 'lternate_end_date,sysdate)+1 > sysdate) )'||wwv_flow.LF||
'                   and active_yn = ''Y'''||wwv_flow.LF||
'            ) loop'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(22) := '                insert into sp_project_approval_chain'||wwv_flow.LF||
'                    (project_approval_id, init';
wwv_flow_imp.g_varchar2_table(23) := 'iative_approval_chain_id, team_member_id, status, comments)'||wwv_flow.LF||
'                values'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(24) := '   (p_project_approval_id, c2.id, p_team_member_id, ''APPROVED'', ''auto approved'');'||wwv_flow.LF||
'                co';
wwv_flow_imp.g_varchar2_table(25) := 'mmit;'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        sp_';
wwv_flow_imp.g_varchar2_table(26) := 'util.add_error_log ('||wwv_flow.LF||
'            p_package_name    => ''sp_approvals'','||wwv_flow.LF||
'            p_procedure_name  ';
wwv_flow_imp.g_varchar2_table(27) := '=> ''submit_for_approval'', '||wwv_flow.LF||
'            p_error           => sqlerrm, '||wwv_flow.LF||
'            p_error_backtrace ';
wwv_flow_imp.g_varchar2_table(28) := '=> dbms_utility.format_error_backtrace, '||wwv_flow.LF||
'            p_arg1_name       => ''p_project_id'', p_arg1_val';
wwv_flow_imp.g_varchar2_table(29) := ' => p_project_id, '||wwv_flow.LF||
'            p_arg2_name       => ''p_approval_type_id'', p_arg2_val => p_approval_t';
wwv_flow_imp.g_varchar2_table(30) := 'ype_id,'||wwv_flow.LF||
'            p_arg3_name       => ''p_team_member_id'', p_arg3_val => p_team_member_id );'||wwv_flow.LF||
'end s';
wwv_flow_imp.g_varchar2_table(31) := 'ubmit_for_approval;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure clarify ('||wwv_flow.LF||
'    p_project_approval_chain_id  number,'||wwv_flow.LF||
'    p_team_member';
wwv_flow_imp.g_varchar2_table(32) := '_id             number,'||wwv_flow.LF||
'    p_response                   varchar2 )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_project_approval_id  nu';
wwv_flow_imp.g_varchar2_table(33) := 'mber;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_project_approval_chain'||wwv_flow.LF||
'        (project_approval_id, initiative_appro';
wwv_flow_imp.g_varchar2_table(34) := 'val_chain_id, '||wwv_flow.LF||
'         team_member_id, comments,'||wwv_flow.LF||
'         response, response_by_team_member_id,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(35) := '      status, last_status_on,'||wwv_flow.LF||
'         final_yn)'||wwv_flow.LF||
'    select project_approval_id, initiative_approval';
wwv_flow_imp.g_varchar2_table(36) := '_chain_id,  '||wwv_flow.LF||
'           team_member_id, comments, '||wwv_flow.LF||
'           p_response, p_team_member_id,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(37) := '   ''CLARIFICATION-REQUESTED'', sysdate,'||wwv_flow.LF||
'           ''N'''||wwv_flow.LF||
'      from sp_project_approval_chain'||wwv_flow.LF||
'     wher';
wwv_flow_imp.g_varchar2_table(38) := 'e id = p_project_approval_chain_id;  '||wwv_flow.LF||
''||wwv_flow.LF||
'    update sp_project_approval_chain'||wwv_flow.LF||
'       set status = ''PEN';
wwv_flow_imp.g_varchar2_table(39) := 'DING'','||wwv_flow.LF||
'           last_status_on = sysdate,'||wwv_flow.LF||
'           comments = null'||wwv_flow.LF||
'     where id = p_project_app';
wwv_flow_imp.g_varchar2_table(40) := 'roval_chain_id'||wwv_flow.LF||
'     returning project_approval_id into l_project_approval_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'     update sp_projec';
wwv_flow_imp.g_varchar2_table(41) := 't_approvals'||wwv_flow.LF||
'        set status = ''PENDING'''||wwv_flow.LF||
'      where id = l_project_approval_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    wh';
wwv_flow_imp.g_varchar2_table(42) := 'en others then'||wwv_flow.LF||
'        sp_util.add_error_log ('||wwv_flow.LF||
'            p_package_name    => ''sp_approvals'','||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(43) := '        p_procedure_name  => ''clarify'', '||wwv_flow.LF||
'            p_error           => sqlerrm, '||wwv_flow.LF||
'            p_er';
wwv_flow_imp.g_varchar2_table(44) := 'ror_backtrace => dbms_utility.format_error_backtrace, '||wwv_flow.LF||
'            p_arg1_name       => ''p_project_a';
wwv_flow_imp.g_varchar2_table(45) := 'pproval_chain_id'', p_arg1_val => p_project_approval_chain_id, '||wwv_flow.LF||
'            p_arg2_name       => ''p_t';
wwv_flow_imp.g_varchar2_table(46) := 'eam_member_id'', p_arg2_val => p_team_member_id );'||wwv_flow.LF||
'end clarify;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure withdraw ('||wwv_flow.LF||
'    p_project_';
wwv_flow_imp.g_varchar2_table(47) := 'approval_id  in  number,'||wwv_flow.LF||
'    p_team_member_id       in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_project_approval_id  numbe';
wwv_flow_imp.g_varchar2_table(48) := 'r;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    update sp_project_approvals'||wwv_flow.LF||
'       set status = ''WITHDRAWN'','||wwv_flow.LF||
'           withdrawn_by_te';
wwv_flow_imp.g_varchar2_table(49) := 'am_member_id = p_team_member_id'||wwv_flow.LF||
'     where id = p_project_approval_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    update sp_project_approv';
wwv_flow_imp.g_varchar2_table(50) := 'al_chain'||wwv_flow.LF||
'       set final_yn = ''N'''||wwv_flow.LF||
'     where project_approval_id = p_project_approval_id'||wwv_flow.LF||
'       and';
wwv_flow_imp.g_varchar2_table(51) := ' final_yn != ''N'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- removing fk to allow for approval chain changes over time (team_member is ';
wwv_flow_imp.g_varchar2_table(52) := 'always known)'||wwv_flow.LF||
'    update sp_project_approval_chain'||wwv_flow.LF||
'       set initiative_approval_chain_id = null'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(53) := '   where project_approval_id = p_project_approval_id'||wwv_flow.LF||
'       and initiative_approval_chain_id is not ';
wwv_flow_imp.g_varchar2_table(54) := 'null;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        sp_util.add_error_log ('||wwv_flow.LF||
'            p_package_name    ';
wwv_flow_imp.g_varchar2_table(55) := '=> ''sp_approvals'','||wwv_flow.LF||
'            p_procedure_name  => ''withdraw'', '||wwv_flow.LF||
'            p_error           => sq';
wwv_flow_imp.g_varchar2_table(56) := 'lerrm, '||wwv_flow.LF||
'            p_error_backtrace => dbms_utility.format_error_backtrace, '||wwv_flow.LF||
'            p_arg1_na';
wwv_flow_imp.g_varchar2_table(57) := 'me       => ''p_project_approval_id'', p_arg1_val => p_project_approval_id, '||wwv_flow.LF||
'            p_arg2_name  ';
wwv_flow_imp.g_varchar2_table(58) := '     => ''p_team_member_id'', p_arg2_val => p_team_member_id );'||wwv_flow.LF||
'end withdraw;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function approval_pend';
wwv_flow_imp.g_varchar2_table(59) := 'ing ('||wwv_flow.LF||
'    p_project_id      in  number,'||wwv_flow.LF||
'    p_team_member_id  in  number'||wwv_flow.LF||
') return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(60) := '  for c1 in ('||wwv_flow.LF||
'        select c.id'||wwv_flow.LF||
'          from sp_project_approval_chain c,'||wwv_flow.LF||
'               sp_proj';
wwv_flow_imp.g_varchar2_table(61) := 'ect_approvals a'||wwv_flow.LF||
'         where a.id = c.project_approval_id'||wwv_flow.LF||
'           and a.project_id = p_project_';
wwv_flow_imp.g_varchar2_table(62) := 'id'||wwv_flow.LF||
'           and c.team_member_id = p_team_member_id'||wwv_flow.LF||
'           and c.status = ''PENDING'''||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(63) := ' and c.final_yn = ''Y'''||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return null;'||wwv_flow.LF||
'end approval_';
wwv_flow_imp.g_varchar2_table(64) := 'pending;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function more_info_pending ('||wwv_flow.LF||
'    p_project_id      in  number,'||wwv_flow.LF||
'    p_team_member_id  in  ';
wwv_flow_imp.g_varchar2_table(65) := 'number'||wwv_flow.LF||
') return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select c.id'||wwv_flow.LF||
'          from sp_project_approv';
wwv_flow_imp.g_varchar2_table(66) := 'al_chain c,'||wwv_flow.LF||
'               sp_project_approvals a'||wwv_flow.LF||
'         where a.id = c.project_approval_id'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(67) := '     and a.project_id = p_project_id'||wwv_flow.LF||
'           and c.status = ''CLARIFICATION-REQUESTED'''||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(68) := 'and a.status = ''CLARIFICATION-REQUESTED'''||wwv_flow.LF||
'           and c.final_yn = ''Y'''||wwv_flow.LF||
'           and a.submitted_';
wwv_flow_imp.g_varchar2_table(69) := 'by_team_member_id = p_team_member_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return null';
wwv_flow_imp.g_varchar2_table(70) := ';'||wwv_flow.LF||
'end more_info_pending;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function approval_pending_cnt ('||wwv_flow.LF||
'    p_team_member_id  in  number'||wwv_flow.LF||
') return';
wwv_flow_imp.g_varchar2_table(71) := ' number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select count(*) cnt'||wwv_flow.LF||
'          from sp_project_approval_chai';
wwv_flow_imp.g_varchar2_table(72) := 'n c,'||wwv_flow.LF||
'               sp_project_approvals a'||wwv_flow.LF||
'         where a.id = c.project_approval_id'||wwv_flow.LF||
'           an';
wwv_flow_imp.g_varchar2_table(73) := 'd c.team_member_id = p_team_member_id'||wwv_flow.LF||
'           and c.status = ''PENDING'''||wwv_flow.LF||
'           and c.final_yn ';
wwv_flow_imp.g_varchar2_table(74) := '= ''Y'''||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return c1.cnt;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end approval_pending_cnt;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function more_info';
wwv_flow_imp.g_varchar2_table(75) := '_pending_cnt ('||wwv_flow.LF||
'    p_team_member_id  in  number'||wwv_flow.LF||
') return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        sel';
wwv_flow_imp.g_varchar2_table(76) := 'ect count(*) cnt'||wwv_flow.LF||
'          from sp_project_approval_chain c,'||wwv_flow.LF||
'               sp_project_approvals a'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(77) := '        where a.id = c.project_approval_id'||wwv_flow.LF||
'           and c.status = ''CLARIFICATION-REQUESTED'''||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(78) := '      and a.status = ''CLARIFICATION-REQUESTED'''||wwv_flow.LF||
'           and c.final_yn = ''Y'''||wwv_flow.LF||
'           and a.subm';
wwv_flow_imp.g_varchar2_table(79) := 'itted_by_team_member_id = p_team_member_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return c1.cnt;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end more_';
wwv_flow_imp.g_varchar2_table(80) := 'info_pending_cnt;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delegate ('||wwv_flow.LF||
'    p_project_approval_chain_id  in  number,'||wwv_flow.LF||
'    p_delegate';
wwv_flow_imp.g_varchar2_table(81) := '_reason            in  varchar2, -- ''APPROVER-SET-INACTIVE'',''REASSIGNMENT'''||wwv_flow.LF||
'    p_delegate_comments  ';
wwv_flow_imp.g_varchar2_table(82) := '        in  varchar2,'||wwv_flow.LF||
'    p_team_member_id             in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_task_id                ';
wwv_flow_imp.g_varchar2_table(83) := '      number;'||wwv_flow.LF||
'    l_new_proj_approval_chain_id   number;'||wwv_flow.LF||
'    l_parameters                   apex_hum';
wwv_flow_imp.g_varchar2_table(84) := 'an_task.t_task_parameters;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select project_approval_id,'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(85) := ' initiative_approval_chain_id,'||wwv_flow.LF||
'               (select upper(email)'||wwv_flow.LF||
'                  from sp_team_me';
wwv_flow_imp.g_varchar2_table(86) := 'mbers'||wwv_flow.LF||
'                 where id = p_team_member_id) team_member_email,'||wwv_flow.LF||
'               (select task_i';
wwv_flow_imp.g_varchar2_table(87) := 'd'||wwv_flow.LF||
'                  from apex_task_parameters'||wwv_flow.LF||
'                 where param_static_id = ''V_PROJECT_AP';
wwv_flow_imp.g_varchar2_table(88) := 'PROVAL_CHAIN_ID'''||wwv_flow.LF||
'                   and param_value = p_project_approval_chain_id) task_id'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(89) := ' from sp_project_approval_chain'||wwv_flow.LF||
'         where id = p_project_approval_chain_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        l';
wwv_flow_imp.g_varchar2_table(90) := '_task_id := c1.task_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- UPDATE OLD REQUEST'||wwv_flow.LF||
'        update sp_project_approval_chain'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(91) := '       set status = p_delegate_reason, '||wwv_flow.LF||
'               last_status_on = sysdate,'||wwv_flow.LF||
'               fina';
wwv_flow_imp.g_varchar2_table(92) := 'l_yn = ''N'','||wwv_flow.LF||
'               comments = p_delegate_comments'||wwv_flow.LF||
'         where id = p_project_approval_cha';
wwv_flow_imp.g_varchar2_table(93) := 'in_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- CREATE NEW REQUEST'||wwv_flow.LF||
'        insert into sp_project_approval_chain'||wwv_flow.LF||
'            (pro';
wwv_flow_imp.g_varchar2_table(94) := 'ject_approval_id, initiative_approval_chain_id, team_member_id, status)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (';
wwv_flow_imp.g_varchar2_table(95) := 'c1.project_approval_id, c1.initiative_approval_chain_id, p_team_member_id, ''PENDING'')'||wwv_flow.LF||
'        return';
wwv_flow_imp.g_varchar2_table(96) := 'ing id into l_new_proj_approval_chain_id;'||wwv_flow.LF||
'	'||wwv_flow.LF||
'        l_parameters(1) := apex_human_task.t_task_parame';
wwv_flow_imp.g_varchar2_table(97) := 'ter ('||wwv_flow.LF||
'            static_id    => ''V_PROJECT_APPROVAL_CHAIN_ID'','||wwv_flow.LF||
'            string_value => to_char';
wwv_flow_imp.g_varchar2_table(98) := '(l_new_proj_approval_chain_id) );'||wwv_flow.LF||
'        l_parameters(2) := apex_human_task.t_task_parameter ('||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(99) := '        static_id    => ''V_REVIEWER_TM_ID'','||wwv_flow.LF||
'            string_value => to_char(p_team_member_id) );';
wwv_flow_imp.g_varchar2_table(100) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'        apex_human_task.set_task_parameter_values ('||wwv_flow.LF||
'            p_task_id    => l_task_id,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(101) := '     p_parameters => l_parameters );'||wwv_flow.LF||
''||wwv_flow.LF||
'        for c2 in ('||wwv_flow.LF||
'            select workflow_id'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(102) := '   from apex_workflow_variables'||wwv_flow.LF||
'             where static_id = ''V_PROJECT_APPROVAL_CHAIN_ID'''||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(103) := '        and display_value = p_project_approval_chain_id'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            --  MUST SUSPEND ';
wwv_flow_imp.g_varchar2_table(104) := 'TO UPDATE'||wwv_flow.LF||
'            apex_workflow.suspend(p_instance_id => c2.workflow_id);'||wwv_flow.LF||
'            apex_workf';
wwv_flow_imp.g_varchar2_table(105) := 'low.update_variables ('||wwv_flow.LF||
'                p_instance_id => c2.workflow_id,'||wwv_flow.LF||
'                p_changed_pa';
wwv_flow_imp.g_varchar2_table(106) := 'rams => apex_workflow.t_workflow_parameters ('||wwv_flow.LF||
'                    1 => apex_workflow.t_workflow_para';
wwv_flow_imp.g_varchar2_table(107) := 'meter(static_id => ''V_PROJECT_APPROVAL_CHAIN_ID'', string_value => to_char(l_new_proj_approval_chain_';
wwv_flow_imp.g_varchar2_table(108) := 'id)),'||wwv_flow.LF||
'                    2 => apex_workflow.t_workflow_parameter(static_id => ''V_REVIEWER_TM_ID'', s';
wwv_flow_imp.g_varchar2_table(109) := 'tring_value => to_char(p_team_member_id)) ));'||wwv_flow.LF||
'            apex_workflow.resume(p_instance_id => c2.w';
wwv_flow_imp.g_varchar2_table(110) := 'orkflow_id);'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'        apex_human_task.add_task_potential_owner ('||wwv_flow.LF||
'            p_tas';
wwv_flow_imp.g_varchar2_table(111) := 'k_id         => l_task_id,'||wwv_flow.LF||
'            p_potential_owner => c1.team_member_email );'||wwv_flow.LF||
''||wwv_flow.LF||
'        apex_hu';
wwv_flow_imp.g_varchar2_table(112) := 'man_task.delegate_task ('||wwv_flow.LF||
'            p_task_id => l_task_id,'||wwv_flow.LF||
'            p_to_user => c1.team_member';
wwv_flow_imp.g_varchar2_table(113) := '_email );'||wwv_flow.LF||
''||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        sp_util.add_error_log ('||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(114) := 'p_package_name    => ''sp_approvals'','||wwv_flow.LF||
'            p_procedure_name  => ''delegate'', '||wwv_flow.LF||
'            p_err';
wwv_flow_imp.g_varchar2_table(115) := 'or           => sqlerrm, '||wwv_flow.LF||
'            p_error_backtrace => dbms_utility.format_error_backtrace, '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(116) := '         p_arg1_name       => ''p_project_approval_chain_id'', p_arg1_val => p_project_approval_chain_';
wwv_flow_imp.g_varchar2_table(117) := 'id, '||wwv_flow.LF||
'            p_arg2_name       => ''p_team_member_id'', p_arg2_val => p_team_member_id,'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(118) := '  p_arg3_name       => ''l_task_id'', p_arg3_val => l_task_id );'||wwv_flow.LF||
'end delegate;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'---------------------';
wwv_flow_imp.g_varchar2_table(119) := '--------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure identify_next_reviewer ('||wwv_flow.LF||
'    p_project_approval_id        in  ';
wwv_flow_imp.g_varchar2_table(120) := ' number,'||wwv_flow.LF||
'    p_project_approval_chain_id  out  number,'||wwv_flow.LF||
'    p_reviewer_tm_id             out  number ';
wwv_flow_imp.g_varchar2_table(121) := ')'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_project_approval_chain_id  number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select initiative_approv';
wwv_flow_imp.g_varchar2_table(122) := 'al_chain_id, team_member_id,'||wwv_flow.LF||
'               (select email from sp_team_members where id = team_membe';
wwv_flow_imp.g_varchar2_table(123) := 'r_id) reviewer_email'||wwv_flow.LF||
'          from ('||wwv_flow.LF||
'        select iac.id initiative_approval_chain_id, '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(124) := '      case when iac.alternate_team_member_id is not null and '||wwv_flow.LF||
'                         nvl(iac.alter';
wwv_flow_imp.g_varchar2_table(125) := 'nate_start_date,sysdate) <= sysdate and '||wwv_flow.LF||
'                         nvl(iac.alternate_end_date+1,sysda';
wwv_flow_imp.g_varchar2_table(126) := 'te) > sysdate'||wwv_flow.LF||
'                    then iac.alternate_team_member_id'||wwv_flow.LF||
'                    else iac.tea';
wwv_flow_imp.g_varchar2_table(127) := 'm_member_id'||wwv_flow.LF||
'                    end team_member_id'||wwv_flow.LF||
'          from sp_project_approvals pa,'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(128) := '      sp_initiative_approval_chain iac'||wwv_flow.LF||
'         where pa.id =  p_project_approval_id'||wwv_flow.LF||
'           and ';
wwv_flow_imp.g_varchar2_table(129) := 'pa.initiative_approval_id = iac.initiative_approval_id'||wwv_flow.LF||
'           and iac.active_yn = ''Y'''||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(130) := ' and iac.id not in (select initiative_approval_chain_id'||wwv_flow.LF||
'                                from sp_proj';
wwv_flow_imp.g_varchar2_table(131) := 'ect_approval_chain'||wwv_flow.LF||
'                               where project_approval_id = pa.id'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(132) := '                 and status = ''APPROVED'''||wwv_flow.LF||
'                                 and final_yn = ''Y'')'||wwv_flow.LF||
'--    ';
wwv_flow_imp.g_varchar2_table(133) := '       and iac.approval_seq > nvl((select max(iac2.approval_seq)'||wwv_flow.LF||
'--                                 ';
wwv_flow_imp.g_varchar2_table(134) := '        from sp_project_approval_chain pac,'||wwv_flow.LF||
'--                                              sp_initi';
wwv_flow_imp.g_varchar2_table(135) := 'ative_approval_chain iac2'||wwv_flow.LF||
'--                                        where pac.initiative_approval_ch';
wwv_flow_imp.g_varchar2_table(136) := 'ain_id = iac2.id'||wwv_flow.LF||
'--                                          and pac.project_approval_id = pa.id'||wwv_flow.LF||
'-- ';
wwv_flow_imp.g_varchar2_table(137) := '                                         and pac.status = ''APPROVED'''||wwv_flow.LF||
'--                             ';
wwv_flow_imp.g_varchar2_table(138) := '             and pac.final_yn = ''Y''),-100)'||wwv_flow.LF||
'         order by iac.approval_seq'||wwv_flow.LF||
'         )'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(139) := '        insert into sp_project_approval_chain (project_approval_id, initiative_approval_chain_id, te';
wwv_flow_imp.g_varchar2_table(140) := 'am_member_id)'||wwv_flow.LF||
'        values (p_project_approval_id, c1.initiative_approval_chain_id, c1.team_member';
wwv_flow_imp.g_varchar2_table(141) := '_id)'||wwv_flow.LF||
'        returning id into l_project_approval_chain_id;'||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'        p_project_appro';
wwv_flow_imp.g_varchar2_table(142) := 'val_chain_id := l_project_approval_chain_id;'||wwv_flow.LF||
'        p_reviewer_tm_id := c1.team_member_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(143) := ' exit;  -- to just get the next stop'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        sp_util.a';
wwv_flow_imp.g_varchar2_table(144) := 'dd_error_log ('||wwv_flow.LF||
'            p_package_name    => ''sp_approvals'','||wwv_flow.LF||
'            p_procedure_name  => ''id';
wwv_flow_imp.g_varchar2_table(145) := 'entify_next_reviewer'', '||wwv_flow.LF||
'            p_error           => sqlerrm, '||wwv_flow.LF||
'            p_error_backtrace => ';
wwv_flow_imp.g_varchar2_table(146) := 'dbms_utility.format_error_backtrace, '||wwv_flow.LF||
'            p_arg1_name       => ''p_project_approval_id'', p_ar';
wwv_flow_imp.g_varchar2_table(147) := 'g1_val => p_project_approval_id, '||wwv_flow.LF||
'            p_arg2_name       => ''p_project_approval_chain_id'', p_';
wwv_flow_imp.g_varchar2_table(148) := 'arg2_val => p_project_approval_chain_id, '||wwv_flow.LF||
'            p_arg3_name       => ''p_reviewer_tm_id'', p_arg';
wwv_flow_imp.g_varchar2_table(149) := '3_val => p_reviewer_tm_id );'||wwv_flow.LF||
'end identify_next_reviewer;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure approve ('||wwv_flow.LF||
'    p_project_approva';
wwv_flow_imp.g_varchar2_table(150) := 'l_chain_id  in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    update sp_project_approval_chain'||wwv_flow.LF||
'       set status = ''APPROVED';
wwv_flow_imp.g_varchar2_table(151) := ''','||wwv_flow.LF||
'           last_status_on = sysdate'||wwv_flow.LF||
'     where id = p_project_approval_chain_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    w';
wwv_flow_imp.g_varchar2_table(152) := 'hen others then'||wwv_flow.LF||
'        sp_util.add_error_log ('||wwv_flow.LF||
'            p_package_name    => ''sp_approvals'','||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(153) := '         p_procedure_name  => ''approve'', '||wwv_flow.LF||
'            p_error           => sqlerrm, '||wwv_flow.LF||
'            p_e';
wwv_flow_imp.g_varchar2_table(154) := 'rror_backtrace => dbms_utility.format_error_backtrace, '||wwv_flow.LF||
'            p_arg1_name       => ''p_project_';
wwv_flow_imp.g_varchar2_table(155) := 'approval_chain_id'', p_arg1_val => p_project_approval_chain_id );'||wwv_flow.LF||
'end approve;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure reject ('||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(156) := '   p_project_approval_chain_id  in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_project_approval_id  number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    update ';
wwv_flow_imp.g_varchar2_table(157) := 'sp_project_approval_chain'||wwv_flow.LF||
'       set status = ''REJECTED'','||wwv_flow.LF||
'           last_status_on = sysdate'||wwv_flow.LF||
'     w';
wwv_flow_imp.g_varchar2_table(158) := 'here id = p_project_approval_chain_id'||wwv_flow.LF||
' returning project_approval_id into l_project_approval_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(159) := '  update sp_project_approvals'||wwv_flow.LF||
'       set status = ''REJECTED'''||wwv_flow.LF||
'     where id = l_project_approval_id;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(160) := ''||wwv_flow.LF||
'    -- removing fk to allow for approval chain changes over time (team_member is always known)'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(161) := 'update sp_project_approval_chain'||wwv_flow.LF||
'       set initiative_approval_chain_id = null'||wwv_flow.LF||
'     where project_a';
wwv_flow_imp.g_varchar2_table(162) := 'pproval_id = l_project_approval_id'||wwv_flow.LF||
'       and initiative_approval_chain_id is not null;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(163) := '   when others then'||wwv_flow.LF||
'        sp_util.add_error_log ('||wwv_flow.LF||
'            p_package_name    => ''sp_approvals'',';
wwv_flow_imp.g_varchar2_table(164) := ''||wwv_flow.LF||
'            p_procedure_name  => ''reject'', '||wwv_flow.LF||
'            p_error           => sqlerrm, '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(165) := 'p_error_backtrace => dbms_utility.format_error_backtrace, '||wwv_flow.LF||
'            p_arg1_name       => ''p_proje';
wwv_flow_imp.g_varchar2_table(166) := 'ct_approval_chain_id'', p_arg1_val => p_project_approval_chain_id );'||wwv_flow.LF||
'end reject;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_comm';
wwv_flow_imp.g_varchar2_table(167) := 'ents ('||wwv_flow.LF||
'    p_project_approval_chain_id  in  number,'||wwv_flow.LF||
'    p_comments                   in  varchar2 )'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(168) := 'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    update sp_project_approval_chain'||wwv_flow.LF||
'       set comments = p_comments'||wwv_flow.LF||
'     where id = p_pro';
wwv_flow_imp.g_varchar2_table(169) := 'ject_approval_chain_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        sp_util.add_error_log ('||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(170) := 'p_package_name    => ''sp_approvals'','||wwv_flow.LF||
'            p_procedure_name  => ''add_comments'', '||wwv_flow.LF||
'            p';
wwv_flow_imp.g_varchar2_table(171) := '_error           => sqlerrm, '||wwv_flow.LF||
'            p_error_backtrace => dbms_utility.format_error_backtrace, ';
wwv_flow_imp.g_varchar2_table(172) := ''||wwv_flow.LF||
'            p_arg1_name       => ''p_project_approval_chain_id'', p_arg1_val => p_project_approval_ch';
wwv_flow_imp.g_varchar2_table(173) := 'ain_id, '||wwv_flow.LF||
'            p_arg2_name       => ''p_comments'', p_arg2_val => substr(p_comments,1,4000) );'||wwv_flow.LF||
'e';
wwv_flow_imp.g_varchar2_table(174) := 'nd add_comments;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure request_clarification ('||wwv_flow.LF||
'    p_project_approval_chain_id  in  number,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(175) := '  p_comments                   in  varchar2 )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_project_approval_id  number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    update';
wwv_flow_imp.g_varchar2_table(176) := ' sp_project_approval_chain'||wwv_flow.LF||
'       set status = ''CLARIFICATION-REQUESTED'','||wwv_flow.LF||
'           comments = p_co';
wwv_flow_imp.g_varchar2_table(177) := 'mments,'||wwv_flow.LF||
'           last_status_on = sysdate'||wwv_flow.LF||
'     where id = p_project_approval_chain_id'||wwv_flow.LF||
'     returni';
wwv_flow_imp.g_varchar2_table(178) := 'ng project_approval_id into l_project_approval_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    update sp_project_approvals'||wwv_flow.LF||
'       set statu';
wwv_flow_imp.g_varchar2_table(179) := 's = ''CLARIFICATION-REQUESTED'''||wwv_flow.LF||
'     where id = l_project_approval_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then';
wwv_flow_imp.g_varchar2_table(180) := ''||wwv_flow.LF||
'        sp_util.add_error_log ('||wwv_flow.LF||
'            p_package_name    => ''sp_approvals'','||wwv_flow.LF||
'            p_proc';
wwv_flow_imp.g_varchar2_table(181) := 'edure_name  => ''request_clarification'', '||wwv_flow.LF||
'            p_error           => sqlerrm, '||wwv_flow.LF||
'            p_er';
wwv_flow_imp.g_varchar2_table(182) := 'ror_backtrace => dbms_utility.format_error_backtrace, '||wwv_flow.LF||
'            p_arg1_name       => ''p_project_a';
wwv_flow_imp.g_varchar2_table(183) := 'pproval_chain_id'', p_arg1_val => p_project_approval_chain_id, '||wwv_flow.LF||
'            p_arg2_name       => ''p_c';
wwv_flow_imp.g_varchar2_table(184) := 'omments'', p_arg2_val => substr(p_comments,1,4000) );'||wwv_flow.LF||
'end request_clarification;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure approve_';
wwv_flow_imp.g_varchar2_table(185) := 'request ('||wwv_flow.LF||
'    p_project_approval_id  in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    update sp_project_approvals '||wwv_flow.LF||
'       s';
wwv_flow_imp.g_varchar2_table(186) := 'et status = ''APPROVED'''||wwv_flow.LF||
'     where id = p_project_approval_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- removing fk to allow for appro';
wwv_flow_imp.g_varchar2_table(187) := 'val chain changes over time (team_member is always known)'||wwv_flow.LF||
'    update sp_project_approval_chain'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(188) := '  set initiative_approval_chain_id = null'||wwv_flow.LF||
'     where project_approval_id = p_project_approval_id'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(189) := '    and initiative_approval_chain_id is not null;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        sp_util.ad';
wwv_flow_imp.g_varchar2_table(190) := 'd_error_log ('||wwv_flow.LF||
'            p_package_name    => ''sp_approvals'','||wwv_flow.LF||
'            p_procedure_name  => ''app';
wwv_flow_imp.g_varchar2_table(191) := 'rove_request'', '||wwv_flow.LF||
'            p_error           => sqlerrm, '||wwv_flow.LF||
'            p_error_backtrace => dbms_uti';
wwv_flow_imp.g_varchar2_table(192) := 'lity.format_error_backtrace, '||wwv_flow.LF||
'            p_arg1_name       => ''p_project_approval_id'', p_arg1_val =';
wwv_flow_imp.g_varchar2_table(193) := '> p_project_approval_id );'||wwv_flow.LF||
'end approve_request;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_approvals;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(52070496458467448394)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_approvals body'
,p_sequence=>7060
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
