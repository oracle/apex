prompt --application/deployment/install/install_sp_task_related_table_and_triggers
begin
--   Manifest
--     INSTALL: INSTALL-sp_task_related table and triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_task_related ('||wwv_flow.LF||
'    id                             number default on null to_number(s';
wwv_flow_imp.g_varchar2_table(2) := 'ys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_tas';
wwv_flow_imp.g_varchar2_table(3) := 'k_related_pk primary key,'||wwv_flow.LF||
'    task_id                        number  not null'||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(4) := '             constraint sp_task_related_task1_fk'||wwv_flow.LF||
'                                   references sp_ta';
wwv_flow_imp.g_varchar2_table(5) := 'sks on delete cascade,'||wwv_flow.LF||
'    related_task_id                number  not null'||wwv_flow.LF||
'                         ';
wwv_flow_imp.g_varchar2_table(6) := '          constraint sp_task_related_task2_fk'||wwv_flow.LF||
'                                   references sp_tasks';
wwv_flow_imp.g_varchar2_table(7) := ' on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    relation_type_id               number'||wwv_flow.LF||
'                               ';
wwv_flow_imp.g_varchar2_table(8) := '    constraint sp_task_related_type_fk'||wwv_flow.LF||
'                                   references sp_relation_typ';
wwv_flow_imp.g_varchar2_table(9) := 'es,'||wwv_flow.LF||
'    relation_details               varchar2(4000 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                      ';
wwv_flow_imp.g_varchar2_table(10) := '  date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated        ';
wwv_flow_imp.g_varchar2_table(11) := '                date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'cr';
wwv_flow_imp.g_varchar2_table(12) := 'eate index sp_task_related_i1 on sp_task_related (task_id);'||wwv_flow.LF||
'create index sp_task_related_i2 on sp_ta';
wwv_flow_imp.g_varchar2_table(13) := 'sk_related (related_task_id);'||wwv_flow.LF||
'create index sp_task_related_i3 on sp_task_related (relation_type_id);';
wwv_flow_imp.g_varchar2_table(14) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_task_related_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_task_related'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(15) := '   for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_old_value   varchar2(4000) := null;'||wwv_flow.LF||
'    l_new_value   varchar2(4000) :';
wwv_flow_imp.g_varchar2_table(16) := '= null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :n';
wwv_flow_imp.g_varchar2_table(17) := 'ew.created_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(18) := '  :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coal';
wwv_flow_imp.g_varchar2_table(19) := 'esce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    ';
wwv_flow_imp.g_varchar2_table(20) := ':= sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    en';
wwv_flow_imp.g_varchar2_table(21) := 'd if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if sp_globals.g_audit_this then'||wwv_flow.LF||
'        update sp_';
wwv_flow_imp.g_varchar2_table(22) := 'tasks set updated = sysdate, updated_by = :new.updated_by where id = :new.task_id;'||wwv_flow.LF||
'        update sp';
wwv_flow_imp.g_varchar2_table(23) := '_tasks set updated = sysdate, updated_by = :new.updated_by where id = :new.related_task_id;'||wwv_flow.LF||
'    end ';
wwv_flow_imp.g_varchar2_table(24) := 'if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            select nvl((s';
wwv_flow_imp.g_varchar2_table(25) := 'elect relation_type from sp_relation_types where id = :new.relation_type_id),''relates to'') ||'' ''||'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(26) := '                  task ||'||wwv_flow.LF||
'                   case when task is not null then '' ('' end ||'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(27) := '        (select task_type from sp_task_types rt where rt.id = task_type_id)||'||wwv_flow.LF||
'                    ca';
wwv_flow_imp.g_varchar2_table(28) := 'se when task_sub_type_id is not null '||wwv_flow.LF||
'                         then '': ''||(select task_type from sp_';
wwv_flow_imp.g_varchar2_table(29) := 'task_types rt where rt.id = task_sub_type_id) '||wwv_flow.LF||
'                         end ||'||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(30) := '    case when task is not null then '')'' end x'||wwv_flow.LF||
'             from sp_tasks'||wwv_flow.LF||
'            where id = :new';
wwv_flow_imp.g_varchar2_table(31) := '.related_task_id'||wwv_flow.LF||
'        ) loop l_new_value := substr(c1.x,1,4000); end loop;'||wwv_flow.LF||
'        insert into sp';
wwv_flow_imp.g_varchar2_table(32) := '_task_history'||wwv_flow.LF||
'            (task_id, attribute_column, change_type, new_value, changed_on, changed_by';
wwv_flow_imp.g_varchar2_table(33) := ')'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.task_id, ''RELATED_TASK'', ''CREATE'', l_new_value, sysdate, lower(:n';
wwv_flow_imp.g_varchar2_table(34) := 'ew.created_by));'||wwv_flow.LF||
'    elsif updating and'||wwv_flow.LF||
'          (nvl(:old.relation_type_id,-1) != nvl(:new.relatio';
wwv_flow_imp.g_varchar2_table(35) := 'n_type_id,-1) or'||wwv_flow.LF||
'           :new.related_task_id != :new.related_task_id) then '||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(36) := '            select nvl((select relation_type from sp_relation_types where id = :old.relation_type_id';
wwv_flow_imp.g_varchar2_table(37) := '),''relates to'') ||'' ''||'||wwv_flow.LF||
'                   task ||'||wwv_flow.LF||
'                   case when task is not null the';
wwv_flow_imp.g_varchar2_table(38) := 'n '' ('' end ||'||wwv_flow.LF||
'                   (select task_type from sp_task_types rt where rt.id = task_type_id)';
wwv_flow_imp.g_varchar2_table(39) := '||'||wwv_flow.LF||
'                    case when task_sub_type_id is not null '||wwv_flow.LF||
'                         then '': ''||(';
wwv_flow_imp.g_varchar2_table(40) := 'select task_type from sp_task_types rt where rt.id = task_sub_type_id) '||wwv_flow.LF||
'                         end';
wwv_flow_imp.g_varchar2_table(41) := ' ||'||wwv_flow.LF||
'                         case when task is not null then '')'' end x'||wwv_flow.LF||
'             from sp_tasks'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(42) := '          where id = :old.related_task_id'||wwv_flow.LF||
'        ) loop l_old_value := substr(c1.x,1,4000); end loo';
wwv_flow_imp.g_varchar2_table(43) := 'p;'||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            select nvl((select relation_type from sp_relation_types where id ';
wwv_flow_imp.g_varchar2_table(44) := '= :new.relation_type_id),''relates to'') ||'' ''||'||wwv_flow.LF||
'                   task ||'||wwv_flow.LF||
'                   case wh';
wwv_flow_imp.g_varchar2_table(45) := 'en task is not null then '' ('' end ||'||wwv_flow.LF||
'                   (select task_type from sp_task_types rt wher';
wwv_flow_imp.g_varchar2_table(46) := 'e rt.id = task_type_id)||'||wwv_flow.LF||
'                    case when task_sub_type_id is not null '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(47) := '           then '': ''||(select task_type from sp_task_types rt where rt.id = task_sub_type_id) '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(48) := '                    end ||'||wwv_flow.LF||
'                         case when task is not null then '')'' end x'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(49) := '       from sp_tasks'||wwv_flow.LF||
'            where id = :new.related_task_id'||wwv_flow.LF||
'        ) loop l_new_value := subst';
wwv_flow_imp.g_varchar2_table(50) := 'r(c1.x,1,4000); end loop;'||wwv_flow.LF||
'        insert into sp_task_history'||wwv_flow.LF||
'            (task_id, attribute_column';
wwv_flow_imp.g_varchar2_table(51) := ', change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.task_i';
wwv_flow_imp.g_varchar2_table(52) := 'd, ''RELATED_TASK'', ''UPDATE'', l_old_value, l_new_value, sysdate, lower(:new.updated_by));'||wwv_flow.LF||
'    end if;';
wwv_flow_imp.g_varchar2_table(53) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_task_related_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_task_related_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on ';
wwv_flow_imp.g_varchar2_table(54) := 'sp_task_related'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_old_value   varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- touc';
wwv_flow_imp.g_varchar2_table(55) := 'h parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_tasks set updated = sysdate, updated_by = :old.updated_by where ';
wwv_flow_imp.g_varchar2_table(56) := 'id = :old.task_id;'||wwv_flow.LF||
'    update sp_tasks set updated = sysdate, updated_by = :old.updated_by where id ';
wwv_flow_imp.g_varchar2_table(57) := '= :old.related_task_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select nvl((select rela';
wwv_flow_imp.g_varchar2_table(58) := 'tion_type from sp_relation_types where id = :old.relation_type_id),''relates to'') ||'' ''||'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(59) := '    task ||'||wwv_flow.LF||
'               case when task is not null then '' ('' end ||'||wwv_flow.LF||
'               (select task_t';
wwv_flow_imp.g_varchar2_table(60) := 'ype from sp_task_types rt where rt.id = task_type_id)||'||wwv_flow.LF||
'                case when task_sub_type_id i';
wwv_flow_imp.g_varchar2_table(61) := 's not null '||wwv_flow.LF||
'                     then '': ''||(select task_type from sp_task_types rt where rt.id = ta';
wwv_flow_imp.g_varchar2_table(62) := 'sk_sub_type_id) '||wwv_flow.LF||
'                     end ||'||wwv_flow.LF||
'                     case when task is not null then '')';
wwv_flow_imp.g_varchar2_table(63) := ''' end x'||wwv_flow.LF||
'         from sp_tasks'||wwv_flow.LF||
'        where id = :old.related_task_id'||wwv_flow.LF||
'    ) loop l_old_value := sub';
wwv_flow_imp.g_varchar2_table(64) := 'str(c1.x,1,4000); end loop;'||wwv_flow.LF||
'    insert into sp_task_history'||wwv_flow.LF||
'        (task_id, attribute_column, chan';
wwv_flow_imp.g_varchar2_table(65) := 'ge_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.task_id, ''RELATED_TASK'', ''DELET';
wwv_flow_imp.g_varchar2_table(66) := 'E'', l_old_value, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'end sp_task';
wwv_flow_imp.g_varchar2_table(67) := '_related_bd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(36947220612470624821)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_task_related table and triggers'
,p_sequence=>3570
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
