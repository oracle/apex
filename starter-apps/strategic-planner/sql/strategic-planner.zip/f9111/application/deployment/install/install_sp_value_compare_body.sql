prompt --application/deployment/install/install_sp_value_compare_body
begin
--   Manifest
--     INSTALL: INSTALL-sp_value_compare body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body sp_value_compare'||wwv_flow.LF||
'as'||wwv_flow.LF||
''||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- string'||wwv_flow.LF||
'--'||wwv_flow.LF||
'function is_equal ('||wwv_flow.LF||
'   p_value1 ';
wwv_flow_imp.g_varchar2_table(2) := '    in varchar2 default null,'||wwv_flow.LF||
'   p_value2     in varchar2 default null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return boolean'||wwv_flow.LF||
'is'||wwv_flow.LF||
'beg';
wwv_flow_imp.g_varchar2_table(3) := 'in'||wwv_flow.LF||
'   if p_value1 is null then'||wwv_flow.LF||
'      if p_value2 is null then'||wwv_flow.LF||
'         return true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(4) := '    return false;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   elsif p_value2 is null then'||wwv_flow.LF||
'      return false;'||wwv_flow.LF||
'   else'||wwv_flow.LF||
'      if ';
wwv_flow_imp.g_varchar2_table(5) := 'p_value1 = p_value2 then'||wwv_flow.LF||
'         return true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         return false;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   en';
wwv_flow_imp.g_varchar2_table(6) := 'd if;'||wwv_flow.LF||
'end is_equal;'||wwv_flow.LF||
''||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- date'||wwv_flow.LF||
'--'||wwv_flow.LF||
'function is_equal ('||wwv_flow.LF||
'   p_value1     in date default null,'||wwv_flow.LF||
'   p_va';
wwv_flow_imp.g_varchar2_table(7) := 'lue2     in date default null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return boolean'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if p_value1 is null then'||wwv_flow.LF||
'      if p';
wwv_flow_imp.g_varchar2_table(8) := '_value2 is null then'||wwv_flow.LF||
'         return true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         return false;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   elsif ';
wwv_flow_imp.g_varchar2_table(9) := 'p_value2 is null then'||wwv_flow.LF||
'      return false;'||wwv_flow.LF||
'   else'||wwv_flow.LF||
'      if p_value1 = p_value2 then'||wwv_flow.LF||
'         return ';
wwv_flow_imp.g_varchar2_table(10) := 'true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         return false;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end is_equal;'||wwv_flow.LF||
''||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- date'||wwv_flow.LF||
'--'||wwv_flow.LF||
'functi';
wwv_flow_imp.g_varchar2_table(11) := 'on is_equal ('||wwv_flow.LF||
'   p_value1     in timestamp default null,'||wwv_flow.LF||
'   p_value2     in timestamp default null'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(12) := '  )'||wwv_flow.LF||
'   return boolean'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if p_value1 is null then'||wwv_flow.LF||
'      if p_value2 is null then'||wwv_flow.LF||
'         r';
wwv_flow_imp.g_varchar2_table(13) := 'eturn true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         return false;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   elsif p_value2 is null then'||wwv_flow.LF||
'      ret';
wwv_flow_imp.g_varchar2_table(14) := 'urn false;'||wwv_flow.LF||
'   else'||wwv_flow.LF||
'      if p_value1 = p_value2 then'||wwv_flow.LF||
'         return true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         retur';
wwv_flow_imp.g_varchar2_table(15) := 'n false;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end is_equal;'||wwv_flow.LF||
''||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- CLOB'||wwv_flow.LF||
'--'||wwv_flow.LF||
'function is_equal ('||wwv_flow.LF||
'   p_value1     i';
wwv_flow_imp.g_varchar2_table(16) := 'n clob default null,'||wwv_flow.LF||
'   p_value2     in clob default null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return boolean'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if p_va';
wwv_flow_imp.g_varchar2_table(17) := 'lue1 is null then'||wwv_flow.LF||
'      if p_value2 is null then'||wwv_flow.LF||
'         return true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         return fa';
wwv_flow_imp.g_varchar2_table(18) := 'lse;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   elsif p_value2 is null then'||wwv_flow.LF||
'      return false;'||wwv_flow.LF||
'   else'||wwv_flow.LF||
'      if DBMS_LOB.COMP';
wwv_flow_imp.g_varchar2_table(19) := 'ARE(p_value1,p_value2) = 0 then'||wwv_flow.LF||
'         return true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         return false;'||wwv_flow.LF||
'      end if';
wwv_flow_imp.g_varchar2_table(20) := ';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end is_equal;'||wwv_flow.LF||
''||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- BLOB'||wwv_flow.LF||
'--'||wwv_flow.LF||
'/*'||wwv_flow.LF||
'function is_equal ('||wwv_flow.LF||
'   p_value1     in blob default nul';
wwv_flow_imp.g_varchar2_table(21) := 'l,'||wwv_flow.LF||
'   p_value2     in blob default null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return boolean'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if p_value1 is null then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(22) := '      if p_value2 is null then'||wwv_flow.LF||
'         return true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         return false;'||wwv_flow.LF||
'      end if;';
wwv_flow_imp.g_varchar2_table(23) := ''||wwv_flow.LF||
'   elsif p_value2 is null then'||wwv_flow.LF||
'      return false;'||wwv_flow.LF||
'   else'||wwv_flow.LF||
'      if DBMS_LOB.COMPARE(p_value1,p_val';
wwv_flow_imp.g_varchar2_table(24) := 'ue2) = 0 then'||wwv_flow.LF||
'         return true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         return false;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end i';
wwv_flow_imp.g_varchar2_table(25) := 's_equal;'||wwv_flow.LF||
'*/'||wwv_flow.LF||
''||wwv_flow.LF||
'--'||wwv_flow.LF||
'-- number'||wwv_flow.LF||
'--'||wwv_flow.LF||
'function is_equal ('||wwv_flow.LF||
'   p_value1     in number default null,'||wwv_flow.LF||
'   p_value2';
wwv_flow_imp.g_varchar2_table(26) := '     in number default null'||wwv_flow.LF||
'   )'||wwv_flow.LF||
'   return boolean'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if p_value1 is null then'||wwv_flow.LF||
'      if p_v';
wwv_flow_imp.g_varchar2_table(27) := 'alue2 is null then'||wwv_flow.LF||
'         return true;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         return false;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   elsif p_';
wwv_flow_imp.g_varchar2_table(28) := 'value2 is null then'||wwv_flow.LF||
'      return false;'||wwv_flow.LF||
'   else'||wwv_flow.LF||
'      if p_value1 = p_value2 then'||wwv_flow.LF||
'         return tr';
wwv_flow_imp.g_varchar2_table(29) := 'ue;'||wwv_flow.LF||
'      else'||wwv_flow.LF||
'         return false;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end is_equal;'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_value_compare;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(30) := '/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(35718073537345795437)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_value_compare body'
,p_sequence=>7030
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
