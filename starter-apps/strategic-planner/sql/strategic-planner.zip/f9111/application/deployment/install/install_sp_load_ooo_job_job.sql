prompt --application/deployment/install/install_sp_load_ooo_job_job
begin
--   Manifest
--     INSTALL: INSTALL-SP_LOAD_OOO_JOB job
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
'    dbms_scheduler.create_job ('||wwv_flow.LF||
'        job_name   => ''SP_LOAD_OOO_JOB'','||wwv_flow.LF||
'        job_type   =>';
wwv_flow_imp.g_varchar2_table(2) := ' ''STORED_PROCEDURE'','||wwv_flow.LF||
'        job_action => ''sp_event_util.load_all_ooo'','||wwv_flow.LF||
'        start_date => null,';
wwv_flow_imp.g_varchar2_table(3) := ''||wwv_flow.LF||
'        repeat_interval => ''FREQ=DAILY; BYTIME=050000;'','||wwv_flow.LF||
'        enabled    => TRUE,'||wwv_flow.LF||
'        auto_d';
wwv_flow_imp.g_varchar2_table(4) := 'rop  => FALSE,'||wwv_flow.LF||
'        comments   => ''Loads Out of Office Summary for each active team member'' );'||wwv_flow.LF||
'en';
wwv_flow_imp.g_varchar2_table(5) := 'd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(35720425917371937677)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'SP_LOAD_OOO_JOB job'
,p_sequence=>8030
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
