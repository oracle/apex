prompt --application/deployment/install/install_sp_project_documents_triggers
begin
--   Manifest
--     INSTALL: INSTALL-sp_project_documents triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_project_documents_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_project_doc';
wwv_flow_imp.g_varchar2_table(2) := 'uments'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_tags varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(3) := '   :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coa';
wwv_flow_imp.g_varchar2_table(4) := 'lesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sys';
wwv_flow_imp.g_varchar2_table(5) := 'date);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER';
wwv_flow_imp.g_varchar2_table(6) := '''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := co';
wwv_flow_imp.g_varchar2_table(7) := 'alesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.tags := upper(:new.';
wwv_flow_imp.g_varchar2_table(8) := 'tags);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if sp_globals.g_audit_this then'||wwv_flow.LF||
'        update sp';
wwv_flow_imp.g_varchar2_table(9) := '_projects set updated = sysdate, updated_by = :new.updated_by where id = :new.project_id;'||wwv_flow.LF||
'    end if';
wwv_flow_imp.g_varchar2_table(10) := ';'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- adjust tag data'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.tags is not null then'||wwv_flow.LF||
'        l_tags := trim(uppe';
wwv_flow_imp.g_varchar2_table(11) := 'r(:new.tags));'||wwv_flow.LF||
'        -- remove multiple spaces'||wwv_flow.LF||
'        if instr(l_tags,''  '') > 0 then'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(12) := 'for j in 1..10 loop '||wwv_flow.LF||
'                l_tags := replace(l_tags,''  '','' ''); '||wwv_flow.LF||
'                if instr(l';
wwv_flow_imp.g_varchar2_table(13) := '_tags,''  '') = 0 then'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(14) := ' end if;'||wwv_flow.LF||
'        for i in 1..length(l_tags) loop'||wwv_flow.LF||
'            if i > 2 and substr(l_tags,i,1) = '' '' a';
wwv_flow_imp.g_varchar2_table(15) := 'nd substr(l_tags,i-1,1) != '','' then'||wwv_flow.LF||
'               l_tags := substr(l_tags,1,i-1)||''-''||substr(l_tag';
wwv_flow_imp.g_varchar2_table(16) := 's,i+1);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        :new.tags := l_tags;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- ';
wwv_flow_imp.g_varchar2_table(17) := 'history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        insert into sp_project_history'||wwv_flow.LF||
'            (project_id,';
wwv_flow_imp.g_varchar2_table(18) := ' attribute_column, change_type, new_value, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.';
wwv_flow_imp.g_varchar2_table(19) := 'project_id, ''DOCUMENT'', ''CREATE'', :new.DOCUMENT_FILENAME, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'    elsi';
wwv_flow_imp.g_varchar2_table(20) := 'f updating then '||wwv_flow.LF||
'        insert into sp_project_history'||wwv_flow.LF||
'            (project_id, attribute_column, c';
wwv_flow_imp.g_varchar2_table(21) := 'hange_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.project_i';
wwv_flow_imp.g_varchar2_table(22) := 'd, ''DOCUMENT'', ''UPDATE'', :old.DOCUMENT_FILENAME, :new.DOCUMENT_FILENAME, sysdate, lower(:new.updated';
wwv_flow_imp.g_varchar2_table(23) := '_by));'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_project_documents_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_project_documents_b';
wwv_flow_imp.g_varchar2_table(24) := 'd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_project_documents'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent ta';
wwv_flow_imp.g_varchar2_table(25) := 'ble'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_projects set updated = sysdate, updated_by = :old.updated_by where id = :ol';
wwv_flow_imp.g_varchar2_table(26) := 'd.project_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    insert into sp_project_history'||wwv_flow.LF||
'        (project_id, attribute_column, chang';
wwv_flow_imp.g_varchar2_table(27) := 'e_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.project_id, ''DOCUMENT'', ''DELETE''';
wwv_flow_imp.g_varchar2_table(28) := ', :old.document_filename, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'en';
wwv_flow_imp.g_varchar2_table(29) := 'd sp_project_documents_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38224367776755673880)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_project_documents triggers'
,p_sequence=>4120
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
