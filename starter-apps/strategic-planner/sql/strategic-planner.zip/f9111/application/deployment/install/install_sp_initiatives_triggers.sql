prompt --application/deployment/install/install_sp_initiatives_triggers
begin
--   Manifest
--     INSTALL: INSTALL-sp_initiatives triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_initiatives_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_initiatives'||wwv_flow.LF||
'    f';
wwv_flow_imp.g_varchar2_table(2) := 'or each row'||wwv_flow.LF||
'declare '||wwv_flow.LF||
'    l_tags        varchar2(4000);'||wwv_flow.LF||
'    l_old_value   varchar2(4000) := null;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(3) := ' l_new_value   varchar2(4000) := null;'||wwv_flow.LF||
'    l_changed_by  varchar2(255)  := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if insert';
wwv_flow_imp.g_varchar2_table(4) := 'ing then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.c';
wwv_flow_imp.g_varchar2_table(5) := 'reated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:n';
wwv_flow_imp.g_varchar2_table(6) := 'ew.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SESS';
wwv_flow_imp.g_varchar2_table(7) := 'ION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.up';
wwv_flow_imp.g_varchar2_table(8) := 'dated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.SP';
wwv_flow_imp.g_varchar2_table(9) := 'ONSOR_ID is null then'||wwv_flow.LF||
'       for c1 in (select OWNER_ID from SP_AREAS f where f.id = :new.AREA_ID an';
wwv_flow_imp.g_varchar2_table(10) := 'd owner_id is not null) loop'||wwv_flow.LF||
'           :new.SPONSOR_ID := c1.owner_id;'||wwv_flow.LF||
'       end loop;'||wwv_flow.LF||
'    end if;';
wwv_flow_imp.g_varchar2_table(11) := ''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- short ID used as an alternative to long numeric ID primary key column'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :';
wwv_flow_imp.g_varchar2_table(12) := 'new.friendly_identifier is null then'||wwv_flow.LF||
'       :new.friendly_identifier := sp_util.compress_int(sp_seq.';
wwv_flow_imp.g_varchar2_table(13) := 'nextval);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- used to provide friendly URLs'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if not sp_value_compare';
wwv_flow_imp.g_varchar2_table(14) := '.is_equal(:old.initiative,:new.initiative) then'||wwv_flow.LF||
'       :new.initiative_url_name := ltrim(rtrim(repla';
wwv_flow_imp.g_varchar2_table(15) := 'ce(replace(REGEXP_REPLACE(translate(substr(:new.initiative,1,80),''()+%$&^!@[];:"?/~!-+_.<>'',''       ';
wwv_flow_imp.g_varchar2_table(16) := '                 ''),''\s+'', '' ''), '''''''', ''''),'' '',''-''),''-''),''-'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- status scal';
wwv_flow_imp.g_varchar2_table(17) := 'e'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.status_scale is null then'||wwv_flow.LF||
'       :new.status_scale := ''A'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(18) := '   -- adjust tag data'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.tags is not null then'||wwv_flow.LF||
'        l_tags := trim(upper(:new.tag';
wwv_flow_imp.g_varchar2_table(19) := 's));'||wwv_flow.LF||
'        -- remove multiple spaces'||wwv_flow.LF||
'        if instr(l_tags,''  '') > 0 then'||wwv_flow.LF||
'            for j in 1';
wwv_flow_imp.g_varchar2_table(20) := '..10 loop '||wwv_flow.LF||
'                l_tags := replace(l_tags,''  '','' ''); '||wwv_flow.LF||
'                if instr(l_tags,''  ''';
wwv_flow_imp.g_varchar2_table(21) := ') = 0 then'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(22) := '       for i in 1..length(l_tags) loop'||wwv_flow.LF||
'            if i > 2 and substr(l_tags,i,1) = '' '' and substr(';
wwv_flow_imp.g_varchar2_table(23) := 'l_tags,i-1,1) != '','' then'||wwv_flow.LF||
'               l_tags := substr(l_tags,1,i-1)||''-''||substr(l_tags,i+1);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(24) := '          end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        :new.tags := l_tags;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   if ';
wwv_flow_imp.g_varchar2_table(25) := ':new.hidden_by_default_yn is null then'||wwv_flow.LF||
'      :new.hidden_by_default_yn := ''N'';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   -';
wwv_flow_imp.g_varchar2_table(26) := '- touch parent table'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   if sp_globals.g_audit_this then'||wwv_flow.LF||
'      update sp_areas set updated = sy';
wwv_flow_imp.g_varchar2_table(27) := 'sdate, updated_by = :new.updated_by where id = :new.area_id;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(28) := ''||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        l_changed_by := lower(:new.updated_by);'||wwv_flow.LF||
''||wwv_flow.LF||
'        if not sp_value_compa';
wwv_flow_imp.g_varchar2_table(29) := 're.is_equal(:old.initiative,:new.initiative) then'||wwv_flow.LF||
'            insert into sp_initiative_history'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(30) := '            (initiative_id, attribute_column, change_type, old_value, new_value,changed_on, changed_';
wwv_flow_imp.g_varchar2_table(31) := 'by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.id, ''INITIATIVE'', ''UPDATE'', :old.initiative, :new.initi';
wwv_flow_imp.g_varchar2_table(32) := 'ative, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.area_id';
wwv_flow_imp.g_varchar2_table(33) := ',:new.area_id) then'||wwv_flow.LF||
'            for c1 in (select AREA r from SP_AREAS x where x.id = :old.AREA_ID) ';
wwv_flow_imp.g_varchar2_table(34) := 'loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'            for c1 in (select AREA r from SP_AREAS x where x.id ';
wwv_flow_imp.g_varchar2_table(35) := '= :new.AREA_ID) loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'            insert into sp_initiative_history'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(36) := '              (initiative_id, attribute_column, change_type, old_value, new_value,changed_on, change';
wwv_flow_imp.g_varchar2_table(37) := 'd_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.id, ''AREA'', ''UPDATE'', l_old_value, l_new_value, sysda';
wwv_flow_imp.g_varchar2_table(38) := 'te, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.objective,:new.obje';
wwv_flow_imp.g_varchar2_table(39) := 'ctive) then'||wwv_flow.LF||
'            insert into sp_initiative_history'||wwv_flow.LF||
'                (initiative_id, attribute_';
wwv_flow_imp.g_varchar2_table(40) := 'column, change_type, old_value, new_value,changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(41) := ' (:new.id, ''OBJECTIVE'', ''UPDATE'', :old.objective, :new.objective, sysdate, l_changed_by);'||wwv_flow.LF||
'        en';
wwv_flow_imp.g_varchar2_table(42) := 'd if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.sponsor_id,:new.sponsor_id) then'||wwv_flow.LF||
'            for';
wwv_flow_imp.g_varchar2_table(43) := ' c1 in (select lower(email) r from SP_TEAM_MEMBERS x where x.id = :old.sponsor_id) loop l_old_value ';
wwv_flow_imp.g_varchar2_table(44) := ':= c1.r; end loop;'||wwv_flow.LF||
'            for c1 in (select lower(email) r from SP_TEAM_MEMBERS x where x.id = ';
wwv_flow_imp.g_varchar2_table(45) := ':new.sponsor_id) loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'            insert into sp_initiative_history'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(46) := '               (initiative_id, attribute_column, change_type, old_value, new_value,changed_on, chang';
wwv_flow_imp.g_varchar2_table(47) := 'ed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.id, ''SPONSOR'', ''UPDATE'', l_old_value, l_new_value, s';
wwv_flow_imp.g_varchar2_table(48) := 'ysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.status_scale,:n';
wwv_flow_imp.g_varchar2_table(49) := 'ew.status_scale) then'||wwv_flow.LF||
'            insert into sp_initiative_history'||wwv_flow.LF||
'                (initiative_id, ';
wwv_flow_imp.g_varchar2_table(50) := 'attribute_column, change_type, old_value, new_value,changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(51) := '           (:new.id, ''STATUS_SCALE'', ''UPDATE'', :old.status_scale, :new.status_scale, sysdate, l_chan';
wwv_flow_imp.g_varchar2_table(52) := 'ged_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.tags,:new.tags) then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(53) := '    insert into sp_initiative_history'||wwv_flow.LF||
'                (initiative_id, attribute_column, change_type,';
wwv_flow_imp.g_varchar2_table(54) := ' old_value, new_value,changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.id, ''TAGS'', ''';
wwv_flow_imp.g_varchar2_table(55) := 'UPDATE'', :old.tags, :new.tags, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compa';
wwv_flow_imp.g_varchar2_table(56) := 're.is_equal(:old.archived_yn,:new.archived_yn) then'||wwv_flow.LF||
'            insert into sp_initiative_history'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(57) := '              (initiative_id, attribute_column, change_type, old_value, new_value, changed_on, chang';
wwv_flow_imp.g_varchar2_table(58) := 'ed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.id, ''ARCHIVED'', ''UPDATE'', :old.archived_yn, :new.arc';
wwv_flow_imp.g_varchar2_table(59) := 'hived_yn, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.hidd';
wwv_flow_imp.g_varchar2_table(60) := 'en_by_default_yn,:new.hidden_by_default_yn) then'||wwv_flow.LF||
'            insert into sp_initiative_history'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(61) := '           (initiative_id, attribute_column, change_type, old_value, new_value, changed_on, changed_';
wwv_flow_imp.g_varchar2_table(62) := 'by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.id, ''HIDDEN_BY_DEFAULT'', ''UPDATE'', :old.hidden_by_defau';
wwv_flow_imp.g_varchar2_table(63) := 'lt_yn, :new.hidden_by_default_yn, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_initiat';
wwv_flow_imp.g_varchar2_table(64) := 'ives_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_initiatives_ai'||wwv_flow.LF||
'    after insert'||wwv_flow.LF||
'    on sp_initiatives'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(65) := 'for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_new_value   varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in (select AREA r fr';
wwv_flow_imp.g_varchar2_table(66) := 'om SP_AREAS x where x.id = :new.AREA_ID) loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'    insert into sp_init';
wwv_flow_imp.g_varchar2_table(67) := 'iative_history'||wwv_flow.LF||
'        (initiative_id, attribute_column, change_type, old_value, changed_on, changed';
wwv_flow_imp.g_varchar2_table(68) := '_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:new.id, ''INITIATIVE'', ''CREATE'', l_new_value||'': ''||:new.initiative, sysdat';
wwv_flow_imp.g_varchar2_table(69) := 'e, lower(:new.created_by));'||wwv_flow.LF||
'end sp_initiatives_ai;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger sp_initiatives_bd'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(70) := ' before delete'||wwv_flow.LF||
'    on sp_initiatives'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_old_value   varchar2(4000) := nu';
wwv_flow_imp.g_varchar2_table(71) := 'll;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_areas set updated = sysdate, updated';
wwv_flow_imp.g_varchar2_table(72) := '_by = :old.updated_by where id = :old.area_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for c1 in (select AREA r from SP_AREAS x w';
wwv_flow_imp.g_varchar2_table(73) := 'here x.id = :old.AREA_ID) loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'    insert into sp_initiative_history'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(74) := '        (initiative_id, attribute_column, change_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values';
wwv_flow_imp.g_varchar2_table(75) := ''||wwv_flow.LF||
'        (:old.id, ''INITIATIVE'', ''DELETE'', l_old_value||'': ''||:old.initiative, sysdate, lower(coales';
wwv_flow_imp.g_varchar2_table(76) := 'ce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'end sp_initiatives_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38175845302854070433)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_initiatives triggers'
,p_sequence=>4070
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
