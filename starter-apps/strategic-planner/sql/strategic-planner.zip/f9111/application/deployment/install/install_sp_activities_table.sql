prompt --application/deployment/install/install_sp_activities_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_activities table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_activities ('||wwv_flow.LF||
'    id                             number default on null to_number(sys';
wwv_flow_imp.g_varchar2_table(2) := '_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_activ';
wwv_flow_imp.g_varchar2_table(3) := 'ities_pk '||wwv_flow.LF||
'                                   primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    activity_type_id               ';
wwv_flow_imp.g_varchar2_table(4) := 'number '||wwv_flow.LF||
'                                   constraint sp_activities_type_fk'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(5) := '           references sp_activity_types (id),'||wwv_flow.LF||
'    project_id                     number '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(6) := '                        constraint sp_activities_project_fk'||wwv_flow.LF||
'                                   refer';
wwv_flow_imp.g_varchar2_table(7) := 'ences sp_projects (id),'||wwv_flow.LF||
'    team_member_id                 number  not null'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(8) := '           constraint sp_activities_person_fk'||wwv_flow.LF||
'                                   references sp_team_';
wwv_flow_imp.g_varchar2_table(9) := 'members (id),'||wwv_flow.LF||
'    initiative_id                  number'||wwv_flow.LF||
'                                   constrain';
wwv_flow_imp.g_varchar2_table(10) := 't sp_activities_initiative_fk'||wwv_flow.LF||
'                                   references sp_initiatives (id),'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(11) := ' --'||wwv_flow.LF||
'    start_date                     date not null,'||wwv_flow.LF||
'    end_date                       date not nu';
wwv_flow_imp.g_varchar2_table(12) := 'll,'||wwv_flow.LF||
'    activity                       varchar2(255 char) not null,'||wwv_flow.LF||
'    comments                    ';
wwv_flow_imp.g_varchar2_table(13) := '   varchar2(4000 char),'||wwv_flow.LF||
'    url                            varchar2(500 char),'||wwv_flow.LF||
'    private_yn       ';
wwv_flow_imp.g_varchar2_table(14) := '              varchar2(1 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    tags                           varchar2(4000 char),'||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(15) := '-'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 ';
wwv_flow_imp.g_varchar2_table(16) := 'char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by                    ';
wwv_flow_imp.g_varchar2_table(17) := ' varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_activities_i1 on sp_activities (activity_type_id);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(18) := 'create index sp_activities_i2 on sp_activities (project_id);'||wwv_flow.LF||
'create index sp_activities_i3 on sp_act';
wwv_flow_imp.g_varchar2_table(19) := 'ivities (team_member_id);'||wwv_flow.LF||
'create index sp_activities_i4 on sp_activities (end_date);'||wwv_flow.LF||
'create index sp';
wwv_flow_imp.g_varchar2_table(20) := '_activities_i5 on sp_activities (start_date);'||wwv_flow.LF||
'create index sp_activities_i6 on sp_activities (initia';
wwv_flow_imp.g_varchar2_table(21) := 'tive_id);'||wwv_flow.LF||
'create index sp_activities_i7 on sp_activities (activity);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(50991133439765885511)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_activities table'
,p_sequence=>3410
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
