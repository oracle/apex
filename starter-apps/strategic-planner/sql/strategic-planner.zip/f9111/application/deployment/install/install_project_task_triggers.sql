prompt --application/deployment/install/install_project_task_triggers
begin
--   Manifest
--     INSTALL: INSTALL-Project Task triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_task_types_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_task_types'||wwv_flow.LF||
'    for';
wwv_flow_imp.g_varchar2_table(2) := ' each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(3) := ':new.created_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(4) := '    :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, co';
wwv_flow_imp.g_varchar2_table(5) := 'alesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated  ';
wwv_flow_imp.g_varchar2_table(6) := '  := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(7) := 'end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.static_id := upper(:new.static_id);'||wwv_flow.LF||
'end sp_task_types_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or rep';
wwv_flow_imp.g_varchar2_table(8) := 'lace trigger sp_initiative_def_tasks_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_initiative_default_ta';
wwv_flow_imp.g_varchar2_table(9) := 'sks'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate';
wwv_flow_imp.g_varchar2_table(10) := ');'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),u';
wwv_flow_imp.g_varchar2_table(11) := 'ser));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.upd';
wwv_flow_imp.g_varchar2_table(12) := 'ated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :ne';
wwv_flow_imp.g_varchar2_table(13) := 'w.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),';
wwv_flow_imp.g_varchar2_table(14) := 'user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if sp_globals.g_audit_this then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(15) := '   update sp_initiatives set updated = sysdate, updated_by = :new.updated_by where id = :new.initiat';
wwv_flow_imp.g_varchar2_table(16) := 'ive_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_initiative_def_tasks_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_task_statuses_';
wwv_flow_imp.g_varchar2_table(17) := 'biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_task_statuses'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then';
wwv_flow_imp.g_varchar2_table(18) := ''||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_b';
wwv_flow_imp.g_varchar2_table(19) := 'y, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updat';
wwv_flow_imp.g_varchar2_table(20) := 'ed,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',''AP';
wwv_flow_imp.g_varchar2_table(21) := 'P_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by';
wwv_flow_imp.g_varchar2_table(22) := ' := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.static_id := ';
wwv_flow_imp.g_varchar2_table(23) := 'upper(:new.static_id);'||wwv_flow.LF||
'end sp_task_statuses_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_tasks_biu'||wwv_flow.LF||
'    befo';
wwv_flow_imp.g_varchar2_table(24) := 're insert or update'||wwv_flow.LF||
'    on sp_tasks'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_old_value   varchar2(4000) := nul';
wwv_flow_imp.g_varchar2_table(25) := 'l;'||wwv_flow.LF||
'    l_new_value   varchar2(4000) := null;'||wwv_flow.LF||
'    l_changed_by  varchar2(255)  := null;'||wwv_flow.LF||
'    l_tags   ';
wwv_flow_imp.g_varchar2_table(26) := '     varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- maintain tracking columns'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting t';
wwv_flow_imp.g_varchar2_table(27) := 'hen'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.create';
wwv_flow_imp.g_varchar2_table(28) := 'd_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.up';
wwv_flow_imp.g_varchar2_table(29) := 'dated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',';
wwv_flow_imp.g_varchar2_table(30) := '''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated';
wwv_flow_imp.g_varchar2_table(31) := '_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- maintain status_la';
wwv_flow_imp.g_varchar2_table(32) := 'st_changed'||wwv_flow.LF||
'    if not sp_value_compare.is_equal(:old.status_id,:new.status_id) then'||wwv_flow.LF||
'       :new.stat';
wwv_flow_imp.g_varchar2_table(33) := 'us_last_changed_on := sysdate;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- adjust tag data'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.tags is';
wwv_flow_imp.g_varchar2_table(34) := ' not null then'||wwv_flow.LF||
'        l_tags := trim(upper(:new.tags));'||wwv_flow.LF||
'        -- remove multiple spaces'||wwv_flow.LF||
'        i';
wwv_flow_imp.g_varchar2_table(35) := 'f instr(l_tags,''  '') > 0 then'||wwv_flow.LF||
'            for j in 1..10 loop '||wwv_flow.LF||
'                l_tags := replace(l_t';
wwv_flow_imp.g_varchar2_table(36) := 'ags,''  '','' ''); '||wwv_flow.LF||
'                if instr(l_tags,''  '') = 0 then'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(37) := '    end if;'||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        for i in 1..length(l_tags) loop'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(38) := '   if i > 2 and substr(l_tags,i,1) = '' '' and substr(l_tags,i-1,1) != '','' then'||wwv_flow.LF||
'               l_tags ';
wwv_flow_imp.g_varchar2_table(39) := ':= substr(l_tags,1,i-1)||''-''||substr(l_tags,i+1);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        :new';
wwv_flow_imp.g_varchar2_table(40) := '.tags := l_tags;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if sp_globals.g_audit_this ';
wwv_flow_imp.g_varchar2_table(41) := 'then'||wwv_flow.LF||
'        update sp_projects set updated = sysdate, updated_by = :new.updated_by where id = :new.';
wwv_flow_imp.g_varchar2_table(42) := 'project_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- change history tracking'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'       l_c';
wwv_flow_imp.g_varchar2_table(43) := 'hanged_by := lower(:new.updated_by);'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- PROJECT_ID'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value';
wwv_flow_imp.g_varchar2_table(44) := '_compare.is_equal(:old.PROJECT_ID,:new.PROJECT_ID) then'||wwv_flow.LF||
'          for c1 in (select PROJECT r from S';
wwv_flow_imp.g_varchar2_table(45) := 'P_PROJECTS x where x.id = :old.PROJECT_ID) loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'          for c1 in (';
wwv_flow_imp.g_varchar2_table(46) := 'select PROJECT r from SP_PROJECTS x where x.id = :new.PROJECT_ID) loop l_new_value := c1.r; end loop';
wwv_flow_imp.g_varchar2_table(47) := ';'||wwv_flow.LF||
'          insert into sp_task_history'||wwv_flow.LF||
'              (task_id, attribute_column, change_type, old_v';
wwv_flow_imp.g_varchar2_table(48) := 'alue, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''PROJECT'', ''UPDATE';
wwv_flow_imp.g_varchar2_table(49) := ''', l_old_value, l_new_value, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- TASK_TYPE '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(50) := '      --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.TASK_TYPE_ID,:new.TASK_TYPE_ID) then'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(51) := ' for c1 in (select TASK_TYPE r from SP_TASK_TYPES x where x.id = :old.TASK_TYPE_ID) loop l_old_value';
wwv_flow_imp.g_varchar2_table(52) := ' := c1.r; end loop;'||wwv_flow.LF||
'          for c1 in (select TASK_TYPE r from SP_TASK_TYPES x where x.id = :new.T';
wwv_flow_imp.g_varchar2_table(53) := 'ASK_TYPE_ID) loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'          insert into sp_task_history'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(54) := ' (task_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          va';
wwv_flow_imp.g_varchar2_table(55) := 'lues'||wwv_flow.LF||
'              (:new.id, ''TASK_TYPE'', ''UPDATE'', l_old_value, l_new_value, sysdate, l_changed_by)';
wwv_flow_imp.g_varchar2_table(56) := ';'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- TASK_SUB_TYPE '||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equa';
wwv_flow_imp.g_varchar2_table(57) := 'l(:old.TASK_SUB_TYPE_ID,:new.TASK_SUB_TYPE_ID) then'||wwv_flow.LF||
'          for c1 in (select TASK_TYPE r from SP_';
wwv_flow_imp.g_varchar2_table(58) := 'TASK_TYPES x where x.id = :old.TASK_SUB_TYPE_ID) loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'          for c';
wwv_flow_imp.g_varchar2_table(59) := '1 in (select TASK_TYPE r from SP_TASK_TYPES x where x.id = :new.TASK_SUB_TYPE_ID) loop l_new_value :';
wwv_flow_imp.g_varchar2_table(60) := '= c1.r; end loop;'||wwv_flow.LF||
'          insert into sp_task_history'||wwv_flow.LF||
'              (task_id, attribute_column, ch';
wwv_flow_imp.g_varchar2_table(61) := 'ange_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''T';
wwv_flow_imp.g_varchar2_table(62) := 'ASK_SUB_TYPE'', ''UPDATE'', l_old_value, l_new_value, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(63) := '       -- TASK'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.TASK,:new.TASK) then'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(64) := ' insert into sp_task_history'||wwv_flow.LF||
'              (task_id, attribute_column, change_type, old_value, new_v';
wwv_flow_imp.g_varchar2_table(65) := 'alue, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''TASK'', ''UPDATE'', :old.TASK, ';
wwv_flow_imp.g_varchar2_table(66) := ':new.TASK, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- OWNER_ID'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if n';
wwv_flow_imp.g_varchar2_table(67) := 'ot sp_value_compare.is_equal(:old.OWNER_ID,:new.OWNER_ID) then'||wwv_flow.LF||
'          for c1 in (select lower(ema';
wwv_flow_imp.g_varchar2_table(68) := 'il) r from SP_TEAM_MEMBERS x where x.id = :old.owner_id) loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(69) := '   for c1 in (select lower(email) r from SP_TEAM_MEMBERS x where x.id = :new.owner_id) loop l_new_va';
wwv_flow_imp.g_varchar2_table(70) := 'lue := c1.r; end loop;'||wwv_flow.LF||
'          insert into sp_task_history'||wwv_flow.LF||
'              (task_id, attribute_colum';
wwv_flow_imp.g_varchar2_table(71) := 'n, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.i';
wwv_flow_imp.g_varchar2_table(72) := 'd, ''OWNER'', ''UPDATE'', l_old_value, l_new_value, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(73) := '    -- START_DATE'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.START_DATE,:new.START_DATE)';
wwv_flow_imp.g_varchar2_table(74) := ' then'||wwv_flow.LF||
'          insert into sp_task_history'||wwv_flow.LF||
'              (task_id, attribute_column, change_type, o';
wwv_flow_imp.g_varchar2_table(75) := 'ld_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''START_DATE'', ';
wwv_flow_imp.g_varchar2_table(76) := '''UPDATE'', to_char(:old.START_DATE,''DD-MON-YYYY''), to_char(:new.START_DATE,''DD-MON-YYYY''), sysdate, l';
wwv_flow_imp.g_varchar2_table(77) := '_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- TARGET_COMPLETE'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_co';
wwv_flow_imp.g_varchar2_table(78) := 'mpare.is_equal(:old.TARGET_COMPLETE,:new.TARGET_COMPLETE) then'||wwv_flow.LF||
'          insert into sp_task_history';
wwv_flow_imp.g_varchar2_table(79) := ''||wwv_flow.LF||
'              (task_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by';
wwv_flow_imp.g_varchar2_table(80) := ')'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''TARGET_COMPLETE'', ''UPDATE'', to_char(:old.TARGET_COMPLETE';
wwv_flow_imp.g_varchar2_table(81) := ',''DD-MON-YYYY''), to_char(:new.TARGET_COMPLETE,''DD-MON-YYYY''), sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;';
wwv_flow_imp.g_varchar2_table(82) := ''||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- STATUS'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.status_id,:new.st';
wwv_flow_imp.g_varchar2_table(83) := 'atus_id) then'||wwv_flow.LF||
'          for c1 in (select status r from SP_TASK_STATUSES x where x.id = :old.status_';
wwv_flow_imp.g_varchar2_table(84) := 'id) loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'          for c1 in (select status r from SP_TASK_STATUSES x';
wwv_flow_imp.g_varchar2_table(85) := ' where x.id = :new.status_id) loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'          insert into sp_task_hist';
wwv_flow_imp.g_varchar2_table(86) := 'ory'||wwv_flow.LF||
'              (task_id, attribute_column, change_type, old_value, new_value, changed_on, changed';
wwv_flow_imp.g_varchar2_table(87) := '_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''STATUS'', ''UPDATE'', l_old_value, l_new_value, sysdate,';
wwv_flow_imp.g_varchar2_table(88) := ' l_changed_by);'||wwv_flow.LF||
'       end if;  '||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- DESCRIPTION '||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_c';
wwv_flow_imp.g_varchar2_table(89) := 'ompare.is_equal(:old.DESCRIPTION,:new.DESCRIPTION) then'||wwv_flow.LF||
'          insert into sp_task_history'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(90) := '        (task_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(91) := '     values'||wwv_flow.LF||
'              (:new.id, ''DESCRIPTION'', ''UPDATE'', :old.DESCRIPTION, :new.DESCRIPTION, sys';
wwv_flow_imp.g_varchar2_table(92) := 'date, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- TAGS'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compar';
wwv_flow_imp.g_varchar2_table(93) := 'e.is_equal(:old.tags,:new.tags) then'||wwv_flow.LF||
'          insert into sp_task_history'||wwv_flow.LF||
'              (task_id, a';
wwv_flow_imp.g_varchar2_table(94) := 'ttribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(95) := '       (:new.id, ''TAGS'', ''UPDATE'', :old.tags, :new.tags, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(96) := '   --'||wwv_flow.LF||
'       -- IMPACT'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.impact,:new.impact) th';
wwv_flow_imp.g_varchar2_table(97) := 'en'||wwv_flow.LF||
'          insert into sp_task_history'||wwv_flow.LF||
'              (task_id, attribute_column, change_type, old_';
wwv_flow_imp.g_varchar2_table(98) := 'value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''IMPACT'', ''UPDATE';
wwv_flow_imp.g_varchar2_table(99) := ''', :old.impact, :new.impact, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'end sp_tasks_bi';
wwv_flow_imp.g_varchar2_table(100) := 'u;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_tasks_ai'||wwv_flow.LF||
'    after insert'||wwv_flow.LF||
'    on sp_tasks'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declar';
wwv_flow_imp.g_varchar2_table(101) := 'e'||wwv_flow.LF||
'    l_type  varchar2(5000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select TASK_TYPE || case when :n';
wwv_flow_imp.g_varchar2_table(102) := 'ew.TASK_SUB_TYPE_ID is not null'||wwv_flow.LF||
'                                 then '': ''||(select task_type from s';
wwv_flow_imp.g_varchar2_table(103) := 'p_task_types'||wwv_flow.LF||
'                                              where id = :new.task_sub_type_id)'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(104) := '                          end ||'||wwv_flow.LF||
'                            case when :new.task is not null '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(105) := '                           then '' - ''||:new.task'||wwv_flow.LF||
'                                 end  r'||wwv_flow.LF||
'          f';
wwv_flow_imp.g_varchar2_table(106) := 'rom SP_TASK_TYPES x '||wwv_flow.LF||
'         where x.id = :new.TASK_TYPE_ID'||wwv_flow.LF||
'    ) loop l_type := substr(c1.r,1,4000';
wwv_flow_imp.g_varchar2_table(107) := '); end loop;'||wwv_flow.LF||
'    insert into sp_task_history'||wwv_flow.LF||
'        (task_id, attribute_column, change_type, new_va';
wwv_flow_imp.g_varchar2_table(108) := 'lue, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:new.id, ''TASK'', ''CREATE'', l_type, sysdate, lower(:';
wwv_flow_imp.g_varchar2_table(109) := 'new.created_by));'||wwv_flow.LF||
'end sp_tasks_ai;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_tasks_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on';
wwv_flow_imp.g_varchar2_table(110) := ' sp_tasks'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_type  varchar2(5000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch par';
wwv_flow_imp.g_varchar2_table(111) := 'ent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_projects set updated = sysdate, updated_by = :old.updated_by where id';
wwv_flow_imp.g_varchar2_table(112) := ' = :old.project_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select TASK_TYPE || case when :old.TASK_SUB_TYPE_';
wwv_flow_imp.g_varchar2_table(113) := 'ID is not null'||wwv_flow.LF||
'                                 then '': ''||(select task_type from sp_task_types'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(114) := '                                          where id = :old.task_sub_type_id)'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(115) := '         end ||'||wwv_flow.LF||
'                            case when :old.task is not null '||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(116) := '          then '' - ''||:new.task'||wwv_flow.LF||
'                                 end r'||wwv_flow.LF||
'          from SP_TASK_TYPES ';
wwv_flow_imp.g_varchar2_table(117) := 'x '||wwv_flow.LF||
'         where x.id = :old.TASK_TYPE_ID'||wwv_flow.LF||
'    ) loop l_type := substr(c1.r,1,4000); end loop;'||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(118) := 'nsert into sp_task_history'||wwv_flow.LF||
'        (task_id, attribute_column, change_type, old_value, changed_on, c';
wwv_flow_imp.g_varchar2_table(119) := 'hanged_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.id, ''TASK'', ''DELETE'', l_type, sysdate, lower(coalesce(sys_contex';
wwv_flow_imp.g_varchar2_table(120) := 't(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'end sp_tasks_bd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_task_links_bi';
wwv_flow_imp.g_varchar2_table(121) := 'u'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_task_links'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(122) := '    :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, co';
wwv_flow_imp.g_varchar2_table(123) := 'alesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sy';
wwv_flow_imp.g_varchar2_table(124) := 'sdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USE';
wwv_flow_imp.g_varchar2_table(125) := 'R''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := c';
wwv_flow_imp.g_varchar2_table(126) := 'oalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(127) := '   --'||wwv_flow.LF||
'    if sp_globals.g_audit_this then'||wwv_flow.LF||
'        update sp_tasks set updated = sysdate, updated_by ';
wwv_flow_imp.g_varchar2_table(128) := '= :new.updated_by where id = :new.task_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting';
wwv_flow_imp.g_varchar2_table(129) := ' then'||wwv_flow.LF||
'       if :new.task_id is not null then'||wwv_flow.LF||
'           insert into sp_task_history'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(130) := '(task_id, attribute_column, change_type, new_value, changed_on, changed_by)'||wwv_flow.LF||
'           values'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(131) := '         (:new.task_id, ''LINK'', ''CREATE'', :new.link_url, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'       el';
wwv_flow_imp.g_varchar2_table(132) := 'sif updating then'||wwv_flow.LF||
'          if not sp_value_compare.is_equal(:old.link_url,:new.link_url) then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(133) := '         insert into sp_task_history'||wwv_flow.LF||
'                  (task_id, attribute_column, change_type, old_';
wwv_flow_imp.g_varchar2_table(134) := 'value, new_value,changed_on, changed_by)'||wwv_flow.LF||
'              values'||wwv_flow.LF||
'                  (:new.task_id, ''LINK';
wwv_flow_imp.g_varchar2_table(135) := ''', ''UPDATE'', :old.link_url, :new.link_url, sysdate, lower(:new.updated_by));'||wwv_flow.LF||
'          end if;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(136) := '  end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_task_links_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_task_links_bd'||wwv_flow.LF||
'    befor';
wwv_flow_imp.g_varchar2_table(137) := 'e delete'||wwv_flow.LF||
'    on sp_task_links'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :old.task_id is not null then'||wwv_flow.LF||
'        --';
wwv_flow_imp.g_varchar2_table(138) := ''||wwv_flow.LF||
'        -- touch parent table'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        update sp_tasks set updated = sysdate, updated_by ';
wwv_flow_imp.g_varchar2_table(139) := '= :old.updated_by where id = :old.task_id;'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        insert into sp_task_history'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(140) := '  (task_id, attribute_column, change_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(141) := '     (:old.task_id, ''LINK'', ''DELETE'', :old.link_url, sysdate, lower(coalesce(sys_context(''APEX$SESSI';
wwv_flow_imp.g_varchar2_table(142) := 'ON'',''APP_USER''),user)));'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_task_links_bd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'	'||wwv_flow.LF||
'create or replace trigger sp_task_do';
wwv_flow_imp.g_varchar2_table(143) := 'cuments_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_task_documents'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_tags';
wwv_flow_imp.g_varchar2_table(144) := ' varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sys';
wwv_flow_imp.g_varchar2_table(145) := 'date);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER';
wwv_flow_imp.g_varchar2_table(146) := '''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new';
wwv_flow_imp.g_varchar2_table(147) := '.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(148) := ' :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USE';
wwv_flow_imp.g_varchar2_table(149) := 'R''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.tags := upper(:new.tags);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(150) := '  --'||wwv_flow.LF||
'    if sp_globals.g_audit_this then'||wwv_flow.LF||
'        update sp_tasks set updated = sysdate, updated_by =';
wwv_flow_imp.g_varchar2_table(151) := ' :new.updated_by where id = :new.task_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- adjust tag data'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :n';
wwv_flow_imp.g_varchar2_table(152) := 'ew.tags is not null then'||wwv_flow.LF||
'        l_tags := trim(upper(:new.tags));'||wwv_flow.LF||
'        -- remove multiple spaces';
wwv_flow_imp.g_varchar2_table(153) := ''||wwv_flow.LF||
'        if instr(l_tags,''  '') > 0 then'||wwv_flow.LF||
'            for j in 1..10 loop '||wwv_flow.LF||
'                l_tags := r';
wwv_flow_imp.g_varchar2_table(154) := 'eplace(l_tags,''  '','' ''); '||wwv_flow.LF||
'                if instr(l_tags,''  '') = 0 then'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(155) := '              end if;'||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        for i in 1..length(l_tags) loop';
wwv_flow_imp.g_varchar2_table(156) := ''||wwv_flow.LF||
'            if i > 2 and substr(l_tags,i,1) = '' '' and substr(l_tags,i-1,1) != '','' then'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(157) := '   l_tags := substr(l_tags,1,i-1)||''-''||substr(l_tags,i+1);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(158) := '      :new.tags := l_tags;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        ins';
wwv_flow_imp.g_varchar2_table(159) := 'ert into sp_task_history'||wwv_flow.LF||
'            (task_id, attribute_column, change_type, new_value, changed_on,';
wwv_flow_imp.g_varchar2_table(160) := ' changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.task_id, ''DOCUMENT'', ''CREATE'', :new.DOCUMENT_FILENAME,';
wwv_flow_imp.g_varchar2_table(161) := ' sysdate, lower(:new.created_by));'||wwv_flow.LF||
'    elsif updating then '||wwv_flow.LF||
'        insert into sp_task_history'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(162) := '        (task_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(163) := '   values'||wwv_flow.LF||
'            (:new.task_id, ''DOCUMENT'', ''UPDATE'', :old.DOCUMENT_FILENAME, :new.DOCUMENT_FIL';
wwv_flow_imp.g_varchar2_table(164) := 'ENAME, sysdate, lower(:new.updated_by));'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_task_documents_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace';
wwv_flow_imp.g_varchar2_table(165) := ' trigger sp_task_documents_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_task_documents'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(166) := '--'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_tasks set updated = sysdate, updated_by = :old.upd';
wwv_flow_imp.g_varchar2_table(167) := 'ated_by where id = :old.task_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    insert into sp_task_history'||wwv_flow.LF||
'        (task_id, attribute_';
wwv_flow_imp.g_varchar2_table(168) := 'column, change_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.task_id, ''DOCUMENT''';
wwv_flow_imp.g_varchar2_table(169) := ', ''DELETE'', :old.document_filename, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),u';
wwv_flow_imp.g_varchar2_table(170) := 'ser)));'||wwv_flow.LF||
'end sp_task_documents_bd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_task_comments_biu'||wwv_flow.LF||
'    before inse';
wwv_flow_imp.g_varchar2_table(171) := 'rt or update'||wwv_flow.LF||
'    on sp_task_comments'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.creat';
wwv_flow_imp.g_varchar2_table(172) := 'ed    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coalesce(sys_con';
wwv_flow_imp.g_varchar2_table(173) := 'text(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(174) := '  :new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(175) := '  elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_co';
wwv_flow_imp.g_varchar2_table(176) := 'ntext(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        for c1 in (';
wwv_flow_imp.g_varchar2_table(177) := 'select nvl(max(comment_nbr),0) cnbr from sp_task_comments where task_id = :new.task_id)'||wwv_flow.LF||
'        loop';
wwv_flow_imp.g_varchar2_table(178) := ' :new.comment_nbr := c1.cnbr+1; end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.private_yn is null then '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(179) := '      :new.private_yn := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if sp_globals.';
wwv_flow_imp.g_varchar2_table(180) := 'g_audit_this then'||wwv_flow.LF||
'        update sp_tasks set updated = sysdate, updated_by = :new.updated_by where ';
wwv_flow_imp.g_varchar2_table(181) := 'id = :new.task_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting and :new.private_yn = ''';
wwv_flow_imp.g_varchar2_table(182) := 'N'' then'||wwv_flow.LF||
'        insert into sp_task_history'||wwv_flow.LF||
'            (task_id, attribute_column, change_type, new';
wwv_flow_imp.g_varchar2_table(183) := '_value, new_value_clob, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.task_id, ''COMMENT'',';
wwv_flow_imp.g_varchar2_table(184) := ' ''CREATE'', dbms_lob.substr(:new.body_no_images,500,1), :new.body_no_images, sysdate, lower(:new.crea';
wwv_flow_imp.g_varchar2_table(185) := 'ted_by));'||wwv_flow.LF||
'    elsif updating and :old.private_yn = ''N'' and :new.private_yn = ''N'' then'||wwv_flow.LF||
'        if not';
wwv_flow_imp.g_varchar2_table(186) := ' sp_value_compare.is_equal(:old.body_no_images,:new.body_no_images) then'||wwv_flow.LF||
'            insert into sp_';
wwv_flow_imp.g_varchar2_table(187) := 'task_history'||wwv_flow.LF||
'                (task_id, attribute_column, change_type, old_value, new_value, old_valu';
wwv_flow_imp.g_varchar2_table(188) := 'e_clob, new_value_clob, changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.task_id, ''C';
wwv_flow_imp.g_varchar2_table(189) := 'OMMENT'', ''UPDATE'', dbms_lob.substr(:old.body_no_images,500,1), dbms_lob.substr(:new.body_no_images,1';
wwv_flow_imp.g_varchar2_table(190) := '), :old.body_no_images, :new.body_no_images, sysdate, lower(:new.updated_by));'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(191) := 'nd if;'||wwv_flow.LF||
'end sp_task_comments_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_task_comments_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(192) := '    on sp_task_comments'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :old.private_yn = ''N'' then'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(193) := '-- touch parent table'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        update sp_tasks set updated = sysdate, updated_by = :old.up';
wwv_flow_imp.g_varchar2_table(194) := 'dated_by where id = :old.task_id;'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        insert into sp_task_history'||wwv_flow.LF||
'            (task_i';
wwv_flow_imp.g_varchar2_table(195) := 'd, attribute_column, change_type, old_value, old_value_clob, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(196) := '            (:old.task_id, ''COMMENT'', ''DELETE'', dbms_lob.substr(:old.body_no_images,500,1), :old.bod';
wwv_flow_imp.g_varchar2_table(197) := 'y_no_images, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end';
wwv_flow_imp.g_varchar2_table(198) := ' sp_task_comments_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38218220673520999286)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'Project Task triggers'
,p_sequence=>4200
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
