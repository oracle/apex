prompt --application/deployment/install/install_sp_release_comments_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_release_comments table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_release_comments ('||wwv_flow.LF||
'    id                             number default on null to_numb';
wwv_flow_imp.g_varchar2_table(2) := 'er(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp';
wwv_flow_imp.g_varchar2_table(3) := '_release_comments_id_pk primary key,'||wwv_flow.LF||
'    release_id                     number'||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(4) := '              constraint sp_release_comm_proj_id_fk'||wwv_flow.LF||
'                                   references SP';
wwv_flow_imp.g_varchar2_table(5) := '_RELEASE_TRAINS on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    comment_nbr                    number,'||wwv_flow.LF||
'    body       ';
wwv_flow_imp.g_varchar2_table(6) := '                    clob,'||wwv_flow.LF||
'    body_html                      clob,'||wwv_flow.LF||
'    body_no_images               ';
wwv_flow_imp.g_varchar2_table(7) := '  clob,'||wwv_flow.LF||
'    image_ref_id                   number, '||wwv_flow.LF||
'    author_id                      number,'||wwv_flow.LF||
'    P';
wwv_flow_imp.g_varchar2_table(8) := 'RIVATE_YN                     varchar2(1 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not n';
wwv_flow_imp.g_varchar2_table(9) := 'ull,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                    ';
wwv_flow_imp.g_varchar2_table(10) := '    date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index s';
wwv_flow_imp.g_varchar2_table(11) := 'p_release_comments_i1 on sp_release_comments (release_id);'||wwv_flow.LF||
'create index sp_release_comments_i2 on sp';
wwv_flow_imp.g_varchar2_table(12) := '_release_comments (author_id);'||wwv_flow.LF||
'create index sp_release_comments_i3 on sp_release_comments (image_ref';
wwv_flow_imp.g_varchar2_table(13) := '_id);'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(44986834484223245076)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_release_comments table'
,p_sequence=>3300
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
