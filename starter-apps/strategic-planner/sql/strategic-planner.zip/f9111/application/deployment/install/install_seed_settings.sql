prompt --application/deployment/install/install_seed_settings
begin
--   Manifest
--     INSTALL: INSTALL-seed settings
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
'    sp_util.add_setting (  '||wwv_flow.LF||
'        p_static_id     => ''APP_ID'',   '||wwv_flow.LF||
'        p_description   =>';
wwv_flow_imp.g_varchar2_table(2) := ' ''Application ID of the application.  Used by summary jobs.'', '||wwv_flow.LF||
'        p_setting_value => null, '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(3) := '     p_is_numeric_yn => ''Y'', '||wwv_flow.LF||
'        p_is_yn         => ''N'' );'||wwv_flow.LF||
'    sp_util.add_setting (  '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(4) := 'p_static_id     => ''APP_PREFIX_URL'',   '||wwv_flow.LF||
'        p_description   => ''Prefix URL of the application.  ';
wwv_flow_imp.g_varchar2_table(5) := 'Used for link creation in summary jobs.'', '||wwv_flow.LF||
'        p_setting_value => null, '||wwv_flow.LF||
'        p_is_numeric_yn';
wwv_flow_imp.g_varchar2_table(6) := ' => ''N'', '||wwv_flow.LF||
'        p_is_yn         => ''N'' );'||wwv_flow.LF||
'    sp_util.add_setting (  '||wwv_flow.LF||
'        p_static_id     => ''';
wwv_flow_imp.g_varchar2_table(7) := 'APP_HOME_URL'',   '||wwv_flow.LF||
'        p_description   => ''Full URL to the home page of the application.  Used fo';
wwv_flow_imp.g_varchar2_table(8) := 'r home link in summary emails.'', '||wwv_flow.LF||
'        p_setting_value => null, '||wwv_flow.LF||
'        p_is_numeric_yn => ''N'', ';
wwv_flow_imp.g_varchar2_table(9) := ''||wwv_flow.LF||
'        p_is_yn         => ''N'' );'||wwv_flow.LF||
'    sp_util.add_setting (  '||wwv_flow.LF||
'        p_static_id     => ''GET_COMME';
wwv_flow_imp.g_varchar2_table(10) := 'NT_IMAGE_PREFIX'',   '||wwv_flow.LF||
'        p_description   => ''Path to displacy images within comments, set by pro';
wwv_flow_imp.g_varchar2_table(11) := 'cess, do not edit'', '||wwv_flow.LF||
'        p_setting_value => null, '||wwv_flow.LF||
'        p_is_numeric_yn => ''N'', '||wwv_flow.LF||
'        p_is';
wwv_flow_imp.g_varchar2_table(12) := '_yn         => ''N'');'||wwv_flow.LF||
'    sp_util.add_setting (  '||wwv_flow.LF||
'        p_static_id     => ''AI_SERVICE'',   '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(13) := ' p_description   => ''Name of AI Service used (for generating summaries). Must be configured under Ge';
wwv_flow_imp.g_varchar2_table(14) := 'nerative AI Services of the application.'', '||wwv_flow.LF||
'        p_setting_value => null, '||wwv_flow.LF||
'        p_is_numeric_y';
wwv_flow_imp.g_varchar2_table(15) := 'n => ''N'', '||wwv_flow.LF||
'        p_is_yn         => ''N'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- most recent install of Strategic Planner'||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(16) := ''||wwv_flow.LF||
'    for a in ('||wwv_flow.LF||
'        select application_id'||wwv_flow.LF||
'          from apex_applications'||wwv_flow.LF||
'         where applic';
wwv_flow_imp.g_varchar2_table(17) := 'ation_name = ''Strategic Planner'''||wwv_flow.LF||
'         order by last_updated_on desc'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        sp_util.s';
wwv_flow_imp.g_varchar2_table(18) := 'et_setting (p_static_id     => ''APP_ID'',   '||wwv_flow.LF||
'                             p_setting_value => a.applic';
wwv_flow_imp.g_varchar2_table(19) := 'ation_id); '||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    sp_util.set_setting (p_static_id     => ''APP_PREFIX_URL'',   '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(20) := '                 p_setting_value => APEX_UTIL.HOST_URL); '||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(47919416495201664618)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed settings'
,p_sequence=>9015
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
