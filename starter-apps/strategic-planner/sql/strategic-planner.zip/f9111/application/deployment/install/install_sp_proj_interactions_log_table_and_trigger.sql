prompt --application/deployment/install/install_sp_proj_interactions_log_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_proj_interactions_log table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_proj_interactions_log ('||wwv_flow.LF||
'    id                             number default on null to';
wwv_flow_imp.g_varchar2_table(2) := '_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constrai';
wwv_flow_imp.g_varchar2_table(3) := 'nt sp_proj_interactions_log_pk primary key,'||wwv_flow.LF||
'    project_id                     number'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(4) := '                     constraint sp_proj_interactions_log_fk'||wwv_flow.LF||
'                                   refer';
wwv_flow_imp.g_varchar2_table(5) := 'ences sp_projects (id),'||wwv_flow.LF||
'    app_page                       number not null,'||wwv_flow.LF||
'    app_user            ';
wwv_flow_imp.g_varchar2_table(6) := '           varchar2(255 char) not null,'||wwv_flow.LF||
'    action                         varchar2(50 char) not nul';
wwv_flow_imp.g_varchar2_table(7) := 'l,'||wwv_flow.LF||
'    page_rendered                  date);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_proj_interactions_log_biu';
wwv_flow_imp.g_varchar2_table(8) := ''||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_proj_interactions_log'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    :new.page_re';
wwv_flow_imp.g_varchar2_table(9) := 'ndered := sysdate;'||wwv_flow.LF||
'    :new.app_user := lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user))';
wwv_flow_imp.g_varchar2_table(10) := ';'||wwv_flow.LF||
'end sp_proj_interactions_log_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create  index sp_proj_interactions_log_i1 on sp_proj_interact';
wwv_flow_imp.g_varchar2_table(11) := 'ions_log (project_id);'||wwv_flow.LF||
'create  index sp_proj_interactions_log_i2 on sp_proj_interactions_log (app_us';
wwv_flow_imp.g_varchar2_table(12) := 'er);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(48875414637661213707)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_proj_interactions_log table and trigger'
,p_sequence=>3390
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
