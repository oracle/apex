prompt --application/deployment/install/install_sp_projects_triggers
begin
--   Manifest
--     INSTALL: INSTALL-sp_projects triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_projects_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_projects'||wwv_flow.LF||
'    for eac';
wwv_flow_imp.g_varchar2_table(2) := 'h row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_old_value   varchar2(4000) := null;'||wwv_flow.LF||
'    l_new_value   varchar2(4000) := null;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(3) := '  l_changed_by  varchar2(255)  := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    l_old_c';
wwv_flow_imp.g_varchar2_table(4) := 'lob    clob;'||wwv_flow.LF||
'    l_new_clob    clob;'||wwv_flow.LF||
'    l_tags        varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- m';
wwv_flow_imp.g_varchar2_table(5) := 'aintain tracking columns'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sy';
wwv_flow_imp.g_varchar2_table(6) := 'sdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, l_changed_by);'||wwv_flow.LF||
'        :new.updated    := nv';
wwv_flow_imp.g_varchar2_table(7) := 'l(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, l_changed_by);'||wwv_flow.LF||
'    elsif up';
wwv_flow_imp.g_varchar2_table(8) := 'dating and sp_globals.g_audit_this then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by ';
wwv_flow_imp.g_varchar2_table(9) := ':= l_changed_by;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- upper project name'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.upper_project_name := ';
wwv_flow_imp.g_varchar2_table(10) := 'upper(:new.project);'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- set external_ticket_identifier and EXTERNAL_TICKET_SYSTEM and ex';
wwv_flow_imp.g_varchar2_table(11) := 'ternal_system_link'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.external_ticket_system     := null;'||wwv_flow.LF||
'    :new.external_ticket_iden';
wwv_flow_imp.g_varchar2_table(12) := 'tifier := null;'||wwv_flow.LF||
'    :new.external_system_link       := null;'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select EXTERNAL';
wwv_flow_imp.g_varchar2_table(13) := '_SYSTEM_NAME, '||wwv_flow.LF||
'               LINK_PATTERN, '||wwv_flow.LF||
'               TICKET_ID_REGEX,'||wwv_flow.LF||
'               REQUIRED';
wwv_flow_imp.g_varchar2_table(14) := '_INITIATIVE_ID,'||wwv_flow.LF||
'               replace(replace(replace(replace(regexp_substr(:new.project,ticket_id_';
wwv_flow_imp.g_varchar2_table(15) := 'regex),'':'',''-''),'' '',''-''),''<'',''-''),''>'',''-'') ext_id'||wwv_flow.LF||
'          from SP_EXTERNAL_TICKETING_SYSTEMS'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(16) := '    where nvl(IS_ACTIVE_YN,''N'') = ''Y'''||wwv_flow.LF||
'           and regexp_substr(:new.project,ticket_id_regex) is ';
wwv_flow_imp.g_varchar2_table(17) := 'not null'||wwv_flow.LF||
'           and (required_initiative_id is null or required_initiative_id = :new.initiative_';
wwv_flow_imp.g_varchar2_table(18) := 'id)'||wwv_flow.LF||
'         order by evaulation_sequence'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'           :new.EXTERNAL_TICKET_SYSTEM := c1.EX';
wwv_flow_imp.g_varchar2_table(19) := 'TERNAL_SYSTEM_NAME;'||wwv_flow.LF||
'           if instr(c1.LINK_PATTERN,''#TICKET_NUMERIC#'') > 0 then'||wwv_flow.LF||
'              :';
wwv_flow_imp.g_varchar2_table(20) := 'new.external_ticket_identifier := c1.ext_id;'||wwv_flow.LF||
'              :new.external_system_link       := replac';
wwv_flow_imp.g_varchar2_table(21) := 'e(c1.LINK_PATTERN,''#TICKET_NUMERIC#'',regexp_replace(c1.ext_id,''[^0-9]'',''''));'||wwv_flow.LF||
'           elsif instr(';
wwv_flow_imp.g_varchar2_table(22) := 'c1.LINK_PATTERN,''#TICKET#'') > 0 then'||wwv_flow.LF||
'              :new.external_ticket_identifier := c1.ext_id;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(23) := '           :new.external_system_link       := replace(c1.LINK_PATTERN,''#TICKET#'',:new.external_ticke';
wwv_flow_imp.g_varchar2_table(24) := 't_identifier);'||wwv_flow.LF||
'           else'||wwv_flow.LF||
'              :new.external_ticket_identifier := null;'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(25) := ':new.external_system_link       := c1.LINK_PATTERN;'||wwv_flow.LF||
'           end if;'||wwv_flow.LF||
'           exit;'||wwv_flow.LF||
'    end loop';
wwv_flow_imp.g_varchar2_table(26) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- adjust tag data'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.tags is not null then'||wwv_flow.LF||
'        l_tags := trim(upp';
wwv_flow_imp.g_varchar2_table(27) := 'er(:new.tags));'||wwv_flow.LF||
'        -- remove multiple spaces'||wwv_flow.LF||
'        if instr(l_tags,''  '') > 0 then'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(28) := ' for j in 1..10 loop '||wwv_flow.LF||
'                l_tags := replace(l_tags,''  '','' ''); '||wwv_flow.LF||
'                if instr(';
wwv_flow_imp.g_varchar2_table(29) := 'l_tags,''  '') = 0 then'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(30) := '  end if;'||wwv_flow.LF||
'        for i in 1..length(l_tags) loop'||wwv_flow.LF||
'            if i > 2 and substr(l_tags,i,1) = '' '' ';
wwv_flow_imp.g_varchar2_table(31) := 'and substr(l_tags,i-1,1) != '','' then'||wwv_flow.LF||
'               l_tags := substr(l_tags,1,i-1)||''-''||substr(l_ta';
wwv_flow_imp.g_varchar2_table(32) := 'gs,i+1);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        :new.tags := l_tags;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(33) := '- defaults'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.STATUS_SCALE is null then'||wwv_flow.LF||
'       :new.STATUS_SCALE := ''A'';'||wwv_flow.LF||
'    end if;';
wwv_flow_imp.g_varchar2_table(34) := ''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.ARCHIVED_YN is null then'||wwv_flow.LF||
'       :new.ARCHIVED_YN := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(35) := '-- short project ID used as an alturnative to long numeric ID primary key column'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.';
wwv_flow_imp.g_varchar2_table(36) := 'friendly_identifier is null then'||wwv_flow.LF||
'       :new.friendly_identifier := sp_util.compress_int(sp_seq.next';
wwv_flow_imp.g_varchar2_table(37) := 'val);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- used to provide friendly URLs'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if not sp_value_compare.is_';
wwv_flow_imp.g_varchar2_table(38) := 'equal(:old.project,:new.project) then'||wwv_flow.LF||
'       :new.project_url_name := ltrim(rtrim(replace(replace(RE';
wwv_flow_imp.g_varchar2_table(39) := 'GEXP_REPLACE(translate(substr(:new.project,1,80),''()+%$&^!@[];:"?/~!-+_.<>'',''                       ';
wwv_flow_imp.g_varchar2_table(40) := ' ''),''\s+'', '' ''), '''''''', ''''),'' '',''-''),''-''),''-'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- change history tracking'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(41) := '  --'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'       l_changed_by := lower(l_changed_by);'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- INITIATIVE';
wwv_flow_imp.g_varchar2_table(42) := '_ID'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.INITIATIVE_ID,:new.INITIATIVE_ID) then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(43) := '        for c1 in (select INITIATIVE r from SP_INITIATIVES x where x.id = :old.INITIATIVE_ID) loop l';
wwv_flow_imp.g_varchar2_table(44) := '_old_value := c1.r; end loop;'||wwv_flow.LF||
'          for c1 in (select INITIATIVE r from SP_INITIATIVES x where x';
wwv_flow_imp.g_varchar2_table(45) := '.id = :new.INITIATIVE_ID) loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'          insert into sp_project_histo';
wwv_flow_imp.g_varchar2_table(46) := 'ry'||wwv_flow.LF||
'              (project_id, attribute_column, change_type, old_value, new_value, changed_on, chang';
wwv_flow_imp.g_varchar2_table(47) := 'ed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''INITIATIVE'', ''UPDATE'', l_old_value, l_new_value, sy';
wwv_flow_imp.g_varchar2_table(48) := 'sdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- PROJECT '||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_c';
wwv_flow_imp.g_varchar2_table(49) := 'ompare.is_equal(:old.PROJECT,:new.PROJECT) then'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(50) := '   (project_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(51) := '   values'||wwv_flow.LF||
'              (:new.id, ''PROJECT'', ''UPDATE'', :old.PROJECT, :new.PROJECT, sysdate, l_change';
wwv_flow_imp.g_varchar2_table(52) := 'd_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- DESCRIPTION '||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_e';
wwv_flow_imp.g_varchar2_table(53) := 'qual(:old.DESCRIPTION,:new.DESCRIPTION) then'||wwv_flow.LF||
'          l_old_clob := :old.DESCRIPTION;'||wwv_flow.LF||
'          l_n';
wwv_flow_imp.g_varchar2_table(54) := 'ew_clob := :new.DESCRIPTION;'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'              (project_id, att';
wwv_flow_imp.g_varchar2_table(55) := 'ribute_column, change_type, old_value, new_value, old_value_clob, new_value_clob, changed_on, change';
wwv_flow_imp.g_varchar2_table(56) := 'd_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''DESCRIPTION'', ''UPDATE'', dbms_lob.substr(:old.DESCRIP';
wwv_flow_imp.g_varchar2_table(57) := 'TION,500,1), dbms_lob.substr(:new.DESCRIPTION,500,1), l_old_clob, l_new_clob, sysdate, l_changed_by)';
wwv_flow_imp.g_varchar2_table(58) := ';'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- OWNER_ID'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old';
wwv_flow_imp.g_varchar2_table(59) := '.OWNER_ID,:new.OWNER_ID) then'||wwv_flow.LF||
'          for c1 in (select lower(email) r from SP_TEAM_MEMBERS x wher';
wwv_flow_imp.g_varchar2_table(60) := 'e x.id = :old.owner_id) loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'          for c1 in (select lower(email)';
wwv_flow_imp.g_varchar2_table(61) := ' r from SP_TEAM_MEMBERS x where x.id = :new.owner_id) loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(62) := 'insert into sp_project_history'||wwv_flow.LF||
'              (project_id, attribute_column, change_type, old_value, ';
wwv_flow_imp.g_varchar2_table(63) := 'new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''OWNER'', ''UPDATE'', l_old';
wwv_flow_imp.g_varchar2_table(64) := '_value, l_new_value, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- TARGET_COMPLETE'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(65) := '   --'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.TARGET_COMPLETE,:new.TARGET_COMPLETE) then'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(66) := '    insert into sp_project_history'||wwv_flow.LF||
'              (project_id, attribute_column, change_type, old_val';
wwv_flow_imp.g_varchar2_table(67) := 'ue, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''TARGET_COMPLETE'', ''';
wwv_flow_imp.g_varchar2_table(68) := 'UPDATE'', to_char(:old.TARGET_COMPLETE,''DD-MON-YYYY''), to_char(:new.TARGET_COMPLETE,''DD-MON-YYYY''), s';
wwv_flow_imp.g_varchar2_table(69) := 'ysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- STATUS_SCALE'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp_va';
wwv_flow_imp.g_varchar2_table(70) := 'lue_compare.is_equal(:old.status_scale,:new.status_scale) then'||wwv_flow.LF||
'          for c1 in (select scale_nam';
wwv_flow_imp.g_varchar2_table(71) := 'e from sp_project_scales where :old.status_scale = scale_letter) loop l_old_value := c1.scale_name; ';
wwv_flow_imp.g_varchar2_table(72) := 'end loop;'||wwv_flow.LF||
'          for c1 in (select scale_name from sp_project_scales where :new.status_scale = sc';
wwv_flow_imp.g_varchar2_table(73) := 'ale_letter) loop l_new_value := c1.scale_name; end loop;'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(74) := '            (project_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by';
wwv_flow_imp.g_varchar2_table(75) := ')'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''STATUS_SCALE'', ''UPDATE'', l_old_value, l_new_value, sysda';
wwv_flow_imp.g_varchar2_table(76) := 'te, l_changed_by);'||wwv_flow.LF||
'       end if;       '||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- PCT_COMPLETE'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       if not sp';
wwv_flow_imp.g_varchar2_table(77) := '_value_compare.is_equal(:old.pct_complete,:new.pct_complete) then'||wwv_flow.LF||
'          insert into sp_project_h';
wwv_flow_imp.g_varchar2_table(78) := 'istory'||wwv_flow.LF||
'              (project_id, attribute_column, change_type, old_value, new_value, changed_on, c';
wwv_flow_imp.g_varchar2_table(79) := 'hanged_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''PCT_COMPLETE'', ''UPDATE'', :old.pct_complete, :ne';
wwv_flow_imp.g_varchar2_table(80) := 'w.pct_complete, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       -- STATUS'||wwv_flow.LF||
'       if not sp_value_compa';
wwv_flow_imp.g_varchar2_table(81) := 're.is_equal(:old.status_id,:new.status_id) then'||wwv_flow.LF||
'          for c1 in (select status from sp_project_s';
wwv_flow_imp.g_varchar2_table(82) := 'tatuses where :old.status_id = id) loop l_old_value := c1.status; end loop;'||wwv_flow.LF||
'          for c1 in (sel';
wwv_flow_imp.g_varchar2_table(83) := 'ect status from sp_project_statuses where :new.status_id = id) loop l_new_value := c1.status; end lo';
wwv_flow_imp.g_varchar2_table(84) := 'op;'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'              (project_id, attribute_column, change_typ';
wwv_flow_imp.g_varchar2_table(85) := 'e, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''STATUS'', ';
wwv_flow_imp.g_varchar2_table(86) := '''UPDATE'', l_old_value, l_new_value, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;  '||wwv_flow.LF||
'       -- REQUIRES_REVI';
wwv_flow_imp.g_varchar2_table(87) := 'EWS_YN'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.requires_reviews_yn,:new.requires_reviews_yn) th';
wwv_flow_imp.g_varchar2_table(88) := 'en'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'              (project_id, attribute_column, change_type';
wwv_flow_imp.g_varchar2_table(89) := ', old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''REQUIRES_R';
wwv_flow_imp.g_varchar2_table(90) := 'EVIEWS'', ''UPDATE'', :old.requires_reviews_yn, :new.requires_reviews_yn, sysdate, l_changed_by);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(91) := '  end if;'||wwv_flow.LF||
'       -- DUPLICATE_OF_PROJECT_ID'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.duplicate_o';
wwv_flow_imp.g_varchar2_table(92) := 'f_project_id,:new.duplicate_of_project_id) then'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(93) := '   (project_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(94) := '   values'||wwv_flow.LF||
'              (:new.id, ''DUPLICATE_OF_PROJECT_ID'', ''UPDATE'', :old.duplicate_of_project_id,';
wwv_flow_imp.g_varchar2_table(95) := ' :new.duplicate_of_project_id, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'       -- PRIORITY_ID'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(96) := 'if not sp_value_compare.is_equal(:old.priority_id,:new.priority_id) then'||wwv_flow.LF||
'          for c1 in (select';
wwv_flow_imp.g_varchar2_table(97) := ' ''P''||PRIORITY r from SP_PROJECT_PRIORITIES x where x.id = :old.PRIORITY_ID) loop l_old_value := c1.';
wwv_flow_imp.g_varchar2_table(98) := 'r; end loop;'||wwv_flow.LF||
'          for c1 in (select ''P''||PRIORITY r from SP_PROJECT_PRIORITIES x where x.id = :';
wwv_flow_imp.g_varchar2_table(99) := 'new.PRIORITY_ID) loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(100) := '        (project_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(101) := '        values'||wwv_flow.LF||
'              (:new.id, ''PRIORITY'', ''UPDATE'', l_old_value, l_new_value, sysdate, l_ch';
wwv_flow_imp.g_varchar2_table(102) := 'anged_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       -- RELEASE_ID'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.RELEASE_';
wwv_flow_imp.g_varchar2_table(103) := 'ID,:new.RELEASE_ID) then'||wwv_flow.LF||
'          for c1 in (select RELEASE_TRAIN||'' ''||RELEASE r from SP_RELEASE_T';
wwv_flow_imp.g_varchar2_table(104) := 'RAINS x where x.id = :old.RELEASE_ID) loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'          for c1 in (selec';
wwv_flow_imp.g_varchar2_table(105) := 't RELEASE_TRAIN||'' ''||RELEASE r from SP_RELEASE_TRAINS x where x.id = :new.RELEASE_ID) loop l_new_va';
wwv_flow_imp.g_varchar2_table(106) := 'lue := c1.r; end loop;'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'              (project_id, attribute';
wwv_flow_imp.g_varchar2_table(107) := '_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (';
wwv_flow_imp.g_varchar2_table(108) := ':new.id, ''RELEASE'', ''UPDATE'', l_old_value, l_new_value, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(109) := '  -- TAGS'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.tags,:new.tags) then'||wwv_flow.LF||
'          insert into sp';
wwv_flow_imp.g_varchar2_table(110) := '_project_history'||wwv_flow.LF||
'              (project_id, attribute_column, change_type, old_value, new_value, cha';
wwv_flow_imp.g_varchar2_table(111) := 'nged_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''TAGS'', ''UPDATE'', :old.tags, :new.tags';
wwv_flow_imp.g_varchar2_table(112) := ', sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       -- PROJECT_GROUP'||wwv_flow.LF||
'       if not sp_value_compare.is_e';
wwv_flow_imp.g_varchar2_table(113) := 'qual(:old.PROJECT_GROUP_ID,:new.PROJECT_GROUP_ID) then'||wwv_flow.LF||
'          for c1 in (select GROUP_NAME r from';
wwv_flow_imp.g_varchar2_table(114) := ' SP_PROJECT_GROUPS x where x.id = :old.PROJECT_GROUP_ID) loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(115) := '   for c1 in (select GROUP_NAME r from SP_PROJECT_GROUPS x where x.id = :new.PROJECT_GROUP_ID) loop ';
wwv_flow_imp.g_varchar2_table(116) := 'l_new_value := c1.r; end loop;'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'              (project_id, a';
wwv_flow_imp.g_varchar2_table(117) := 'ttribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(118) := '       (:new.id, ''PROJECT_GROUP'', ''UPDATE'', l_old_value, l_new_value, sysdate, l_changed_by);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(119) := ' end if;'||wwv_flow.LF||
'       -- PROJECT_SIZE'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.project_size,:new.proje';
wwv_flow_imp.g_varchar2_table(120) := 'ct_size) then'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'              (project_id, attribute_column, ';
wwv_flow_imp.g_varchar2_table(121) := 'change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ';
wwv_flow_imp.g_varchar2_table(122) := '''PROJECT_SIZE'', ''UPDATE'', :old.project_size, :new.project_size, sysdate, l_changed_by);'||wwv_flow.LF||
'       end i';
wwv_flow_imp.g_varchar2_table(123) := 'f;'||wwv_flow.LF||
'       -- KB_STACK_RANK'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.kb_stack_rank,:new.kb_stack_';
wwv_flow_imp.g_varchar2_table(124) := 'rank) then'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'              (project_id, attribute_column, cha';
wwv_flow_imp.g_varchar2_table(125) := 'nge_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''KB';
wwv_flow_imp.g_varchar2_table(126) := '_STACK_RANK'', ''UPDATE'', :old.kb_stack_rank, :new.kb_stack_rank, sysdate, l_changed_by);'||wwv_flow.LF||
'       end i';
wwv_flow_imp.g_varchar2_table(127) := 'f;'||wwv_flow.LF||
'       -- FOCUS_AREA_ID'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.focus_area_id,:new.focus_are';
wwv_flow_imp.g_varchar2_table(128) := 'a_id) then'||wwv_flow.LF||
'          for c1 in (select focus_area r from SP_INITIATIVE_FOCUS_AREAS x where x.id = :o';
wwv_flow_imp.g_varchar2_table(129) := 'ld.FOCUS_AREA_ID) loop l_old_value := c1.r; end loop;'||wwv_flow.LF||
'          for c1 in (select focus_area r from ';
wwv_flow_imp.g_varchar2_table(130) := 'SP_INITIATIVE_FOCUS_AREAS x where x.id = :new.FOCUS_AREA_ID) loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(131) := '       insert into sp_project_history'||wwv_flow.LF||
'              (project_id, attribute_column, change_type, old_';
wwv_flow_imp.g_varchar2_table(132) := 'value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''FOCUS_AREA'', ''UP';
wwv_flow_imp.g_varchar2_table(133) := 'DATE'', l_old_value, l_new_value, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       -- ACTIVE_YN'||wwv_flow.LF||
'       i';
wwv_flow_imp.g_varchar2_table(134) := 'f not sp_value_compare.is_equal(:old.active_yn,:new.active_yn) then'||wwv_flow.LF||
'          insert into sp_project';
wwv_flow_imp.g_varchar2_table(135) := '_history'||wwv_flow.LF||
'              (project_id, attribute_column, change_type, old_value, new_value, changed_on,';
wwv_flow_imp.g_varchar2_table(136) := ' changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''ACTIVE'', ''UPDATE'', :old.active_yn, :new.activ';
wwv_flow_imp.g_varchar2_table(137) := 'e_yn, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       -- ARCHIVED_YN'||wwv_flow.LF||
'       if not sp_value_compare.is';
wwv_flow_imp.g_varchar2_table(138) := '_equal(:old.archived_yn,:new.archived_yn) then'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(139) := '  (project_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(140) := '  values'||wwv_flow.LF||
'              (:new.id, ''ARCHIVED'', ''UPDATE'', :old.archived_yn, :new.archived_yn, sysdate, ';
wwv_flow_imp.g_varchar2_table(141) := 'l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'       -- EXTERNAL SYNC COLUMNS'||wwv_flow.LF||
'       if not sp_value_compare.is_equ';
wwv_flow_imp.g_varchar2_table(142) := 'al(:old.sync_identifier,:new.sync_identifier) then'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(143) := '      (project_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(144) := '      values'||wwv_flow.LF||
'              (:new.id, ''SYNC_IDENTIFIER'', ''UPDATE'', :old.sync_identifier, :new.sync_id';
wwv_flow_imp.g_varchar2_table(145) := 'entifier, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.sync_s';
wwv_flow_imp.g_varchar2_table(146) := 'ystem_link,:new.sync_system_link) then'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'              (proje';
wwv_flow_imp.g_varchar2_table(147) := 'ct_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values';
wwv_flow_imp.g_varchar2_table(148) := ''||wwv_flow.LF||
'              (:new.id, ''SYNC_SYSTEM_LINK'', ''UPDATE'', :old.sync_system_link, :new.sync_system_link,';
wwv_flow_imp.g_varchar2_table(149) := ' sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       if not sp_value_compare.is_equal(:old.last_sync_statu';
wwv_flow_imp.g_varchar2_table(150) := 's,:new.last_sync_status) then'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'              (project_id, at';
wwv_flow_imp.g_varchar2_table(151) := 'tribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'          values'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(152) := '      (:new.id, ''LAST_SYNCED_ON'', ''UPDATE'', to_char(:old.last_synced_on,''DD-MON-YYYY''), to_char(:new';
wwv_flow_imp.g_varchar2_table(153) := '.last_synced_on,''DD-MON-YYYY''), sysdate, l_changed_by);'||wwv_flow.LF||
'          insert into sp_project_history'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(154) := '           (project_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)';
wwv_flow_imp.g_varchar2_table(155) := ''||wwv_flow.LF||
'          values'||wwv_flow.LF||
'              (:new.id, ''LAST_SYNC_STATUS'', ''UPDATE'', :old.last_sync_status, :new.';
wwv_flow_imp.g_varchar2_table(156) := 'last_sync_status, sysdate, l_changed_by);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'end sp_projects_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'c';
wwv_flow_imp.g_varchar2_table(157) := 'reate or replace trigger sp_projects_ai'||wwv_flow.LF||
'    after insert'||wwv_flow.LF||
'    on sp_projects'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(158) := '   insert into sp_project_history'||wwv_flow.LF||
'        (project_id, attribute_column, change_type, new_value, cha';
wwv_flow_imp.g_varchar2_table(159) := 'nged_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:new.id, ''PROJECT'', ''CREATE'', :new.PROJECT, sysdate, lower(';
wwv_flow_imp.g_varchar2_table(160) := ':new.created_by));'||wwv_flow.LF||
'end sp_projects_ai;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_projects_bd'||wwv_flow.LF||
'    before delete';
wwv_flow_imp.g_varchar2_table(161) := ''||wwv_flow.LF||
'    on sp_projects'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_project_history'||wwv_flow.LF||
'        (project_id, a';
wwv_flow_imp.g_varchar2_table(162) := 'ttribute_column, change_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.id, ''PROJE';
wwv_flow_imp.g_varchar2_table(163) := 'CT'', ''DELETE'', :old.PROJECT, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));';
wwv_flow_imp.g_varchar2_table(164) := ''||wwv_flow.LF||
'end sp_projects_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(68245429853897984834)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_projects triggers'
,p_sequence=>4150
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
