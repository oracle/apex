prompt --application/deployment/install/install_sample_data_team_members
begin
--   Manifest
--     INSTALL: INSTALL-sample data - team members
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into SP_TEAM_MEMBERS ('||wwv_flow.LF||
'    id, first_name, last_name, email, screen_name, country_id, notific';
wwv_flow_imp.g_varchar2_table(2) := 'ation_pref, comment_notif_pref) '||wwv_flow.LF||
'    values (1,  ''Scott'', ''Tiger'', ''scott.tiger@acme.com'', ''stiger'',';
wwv_flow_imp.g_varchar2_table(3) := ' 187, ''APP'', ''APP'');'||wwv_flow.LF||
'insert into SP_TEAM_MEMBERS ('||wwv_flow.LF||
'    id, first_name, last_name, email, screen_name';
wwv_flow_imp.g_varchar2_table(4) := ', country_id, notification_pref, comment_notif_pref) '||wwv_flow.LF||
'    values (2, ''Marcus'', ''Hale'', ''Marcus.Hale@';
wwv_flow_imp.g_varchar2_table(5) := 'acme.com'', ''mhale'', 187, ''APP'', ''APP'');'||wwv_flow.LF||
'insert into SP_TEAM_MEMBERS ('||wwv_flow.LF||
'    id, first_name, last_name,';
wwv_flow_imp.g_varchar2_table(6) := ' email, screen_name, country_id, notification_pref, comment_notif_pref) '||wwv_flow.LF||
'    values (3, ''Elena'', ''Va';
wwv_flow_imp.g_varchar2_table(7) := 'rgas'', ''Elena.Vargas@acme.com'', ''evargas'', 187, ''APP'', ''APP'');'||wwv_flow.LF||
'insert into SP_TEAM_MEMBERS ('||wwv_flow.LF||
'    id,';
wwv_flow_imp.g_varchar2_table(8) := ' first_name, last_name, email, screen_name, country_id, notification_pref, comment_notif_pref) '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(9) := 'values (4, ''Tyler'', ''Brooks'', ''Tyler.Brooks@acme.com'', ''tbrooks'' , 187, ''APP'', ''APP'');'||wwv_flow.LF||
'insert into S';
wwv_flow_imp.g_varchar2_table(10) := 'P_TEAM_MEMBERS ('||wwv_flow.LF||
'    id, first_name, last_name, email, screen_name, country_id, notification_pref, c';
wwv_flow_imp.g_varchar2_table(11) := 'omment_notif_pref) '||wwv_flow.LF||
'    values (5, ''Naomi'', ''Chen'', ''Naomi.Chen@acme.com'', ''nchen'', 187, ''APP'', ''APP';
wwv_flow_imp.g_varchar2_table(12) := ''');'||wwv_flow.LF||
'insert into SP_TEAM_MEMBERS ('||wwv_flow.LF||
'    id, first_name, last_name, email, screen_name, country_id, not';
wwv_flow_imp.g_varchar2_table(13) := 'ification_pref, comment_notif_pref) '||wwv_flow.LF||
'    values (6, ''Jordan'', ''Avery'', ''Jordan.Avery@acme.com'', ''jav';
wwv_flow_imp.g_varchar2_table(14) := 'ery'', 187, ''APP'', ''APP'');'||wwv_flow.LF||
'insert into SP_TEAM_MEMBERS ('||wwv_flow.LF||
'    id, first_name, last_name, email, screen';
wwv_flow_imp.g_varchar2_table(15) := '_name, country_id, notification_pref, comment_notif_pref) '||wwv_flow.LF||
'    values (7, ''Caleb'', ''Foster'', ''Caleb.';
wwv_flow_imp.g_varchar2_table(16) := 'Foster@acme.com'', ''cfoster'', 187, ''APP'', ''APP'');'||wwv_flow.LF||
'insert into SP_TEAM_MEMBERS ('||wwv_flow.LF||
'    id, first_name, l';
wwv_flow_imp.g_varchar2_table(17) := 'ast_name, email, screen_name, country_id, notification_pref, comment_notif_pref) '||wwv_flow.LF||
'    values (8, ''Li';
wwv_flow_imp.g_varchar2_table(18) := 'la'', ''Montgomery'', ''Lila.Montgomery@acme.com'', ''lmontgomery'', 187, ''APP'', ''APP'');'||wwv_flow.LF||
'insert into SP_TEA';
wwv_flow_imp.g_varchar2_table(19) := 'M_MEMBERS ('||wwv_flow.LF||
'    id, first_name, last_name, email, screen_name, country_id, notification_pref, commen';
wwv_flow_imp.g_varchar2_table(20) := 't_notif_pref) '||wwv_flow.LF||
'    values (9, ''Andre'', ''Collins'', ''Andre.Collins@acme.com'', ''acollins'', 187, ''APP'', ';
wwv_flow_imp.g_varchar2_table(21) := '''APP'');'||wwv_flow.LF||
'insert into SP_TEAM_MEMBERS ('||wwv_flow.LF||
'    id, first_name, last_name, email, screen_name, country_id,';
wwv_flow_imp.g_varchar2_table(22) := ' notification_pref, comment_notif_pref) '||wwv_flow.LF||
'    values (10, ''Sophie'', ''Bennett'', ''Sophie.Bennett@acme.c';
wwv_flow_imp.g_varchar2_table(23) := 'om'', ''sbennett'', 187, ''APP'', ''APP'');'||wwv_flow.LF||
'insert into SP_TEAM_MEMBERS ('||wwv_flow.LF||
'    id, first_name, last_name, em';
wwv_flow_imp.g_varchar2_table(24) := 'ail, screen_name, country_id, notification_pref, comment_notif_pref) '||wwv_flow.LF||
'    values (11, ''Victor'', ''Ram';
wwv_flow_imp.g_varchar2_table(25) := 'irez'', ''Victor.Ramirez@acme.com'', ''vramirez'', 187, ''APP'', ''APP'');'||wwv_flow.LF||
'insert into SP_TEAM_MEMBERS ('||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(26) := 'id, first_name, last_name, email, screen_name, country_id, notification_pref, comment_notif_pref) '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(27) := '   values (12, ''Hannah'', ''Doyle'', ''Hannah.Doyle@acme.com'', ''hdoyle'', 187, ''APP'', ''APP'');'||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(28) := ' SP_TEAM_MEMBERS ('||wwv_flow.LF||
'    id, first_name, last_name, email, screen_name, country_id, notification_pref,';
wwv_flow_imp.g_varchar2_table(29) := ' comment_notif_pref) '||wwv_flow.LF||
'    values (13, ''Isaac'', ''Turner'', ''Isaac.Turner@acme.com'', ''iturner''  , 187, ';
wwv_flow_imp.g_varchar2_table(30) := '''APP'', ''APP'');'||wwv_flow.LF||
'insert into SP_TEAM_MEMBERS ('||wwv_flow.LF||
'    id, first_name, last_name, email, screen_name, coun';
wwv_flow_imp.g_varchar2_table(31) := 'try_id, notification_pref, comment_notif_pref) '||wwv_flow.LF||
'    values (14, ''Chloe'', ''Whitaker'', ''Chloe.Whitaker';
wwv_flow_imp.g_varchar2_table(32) := '@acme.com'', ''cwhitaker'', 187, ''APP'', ''APP'');'||wwv_flow.LF||
'insert into SP_TEAM_MEMBERS ('||wwv_flow.LF||
'    id, first_name, last_';
wwv_flow_imp.g_varchar2_table(33) := 'name, email, screen_name, country_id, notification_pref, comment_notif_pref) '||wwv_flow.LF||
'    values (15, ''Domin';
wwv_flow_imp.g_varchar2_table(34) := 'ic'', ''Reyes'', ''Dominic.Reyes@acme.com'', ''dreyes'', 187, ''APP'', ''APP'');'||wwv_flow.LF||
'insert into SP_TEAM_MEMBERS ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(35) := '    id, first_name, last_name, email, screen_name, country_id, notification_pref, comment_notif_pref';
wwv_flow_imp.g_varchar2_table(36) := ') '||wwv_flow.LF||
'    values (16, ''Maya'', ''Patel'', ''Maya.Patel@acme.com'', ''mpatel'', 187, ''APP'', ''APP'');'||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(37) := ' SP_TEAM_MEMBERS ('||wwv_flow.LF||
'    id, first_name, last_name, email, screen_name, country_id, notification_pref,';
wwv_flow_imp.g_varchar2_table(38) := ' comment_notif_pref) '||wwv_flow.LF||
'    values (17, ''Ethan'', ''Caldwell'', ''Ethan.Caldwell@acme.com'', ''ecaldwell'', 1';
wwv_flow_imp.g_varchar2_table(39) := '87, ''APP'', ''APP'');'||wwv_flow.LF||
'insert into SP_TEAM_MEMBERS ('||wwv_flow.LF||
'    id, first_name, last_name, email, screen_name, ';
wwv_flow_imp.g_varchar2_table(40) := 'country_id, notification_pref, comment_notif_pref) '||wwv_flow.LF||
'    values (18, ''Vanessa'', ''Cruz'', ''Vanessa.Cruz';
wwv_flow_imp.g_varchar2_table(41) := '@acme.com'', ''vcruz'', 187, ''APP'', ''APP'');'||wwv_flow.LF||
'insert into SP_TEAM_MEMBERS ('||wwv_flow.LF||
'    id, first_name, last_name';
wwv_flow_imp.g_varchar2_table(42) := ', email, screen_name, country_id, notification_pref, comment_notif_pref) '||wwv_flow.LF||
'    values (19, ''Lucas'', ''';
wwv_flow_imp.g_varchar2_table(43) := 'Bennett'', ''Lucas.Bennett@acme.com'', ''lbennett'', 187, ''APP'', ''APP'');'||wwv_flow.LF||
'insert into SP_TEAM_MEMBERS ('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(44) := '  id, first_name, last_name, email, screen_name, country_id, notification_pref, comment_notif_pref) ';
wwv_flow_imp.g_varchar2_table(45) := ''||wwv_flow.LF||
'    values (20, ''Aiden'', ''Clarke'', ''Aiden.Clarke@acme.com'', ''aclarke'', 187, ''APP'', ''APP'');'||wwv_flow.LF||
'insert i';
wwv_flow_imp.g_varchar2_table(46) := 'nto SP_TEAM_MEMBERS ('||wwv_flow.LF||
'    id, first_name, last_name, email, screen_name, country_id, notification_pr';
wwv_flow_imp.g_varchar2_table(47) := 'ef, comment_notif_pref) '||wwv_flow.LF||
'    values (21, ''Zoe'', ''Matthews'', ''Zoe.Matthews@acme.com'', ''zmatthews'', 18';
wwv_flow_imp.g_varchar2_table(48) := '7, ''APP'', ''APP'');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(148801735575490129097)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sample data - team members'
,p_sequence=>9200
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
