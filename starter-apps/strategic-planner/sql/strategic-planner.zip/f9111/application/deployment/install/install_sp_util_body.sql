prompt --application/deployment/install/install_sp_util_body
begin
--   Manifest
--     INSTALL: INSTALL-sp_util body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body sp_util as'||wwv_flow.LF||
''||wwv_flow.LF||
'g_error_retention_in_days  number := 21;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_e';
wwv_flow_imp.g_varchar2_table(2) := 'rror_log ( '||wwv_flow.LF||
'    p_package_name    in varchar2,'||wwv_flow.LF||
'    p_procedure_name  in varchar2, '||wwv_flow.LF||
'    p_error      ';
wwv_flow_imp.g_varchar2_table(3) := '     in varchar2, '||wwv_flow.LF||
'    p_error_backtrace in varchar2 default null,'||wwv_flow.LF||
'    p_arg1_name       in varchar2';
wwv_flow_imp.g_varchar2_table(4) := ' default null, '||wwv_flow.LF||
'    p_arg1_val        in varchar2 default null, '||wwv_flow.LF||
'    p_arg2_name       in varchar2 d';
wwv_flow_imp.g_varchar2_table(5) := 'efault null, '||wwv_flow.LF||
'    p_arg2_val        in varchar2 default null, '||wwv_flow.LF||
'    p_arg3_name       in varchar2 def';
wwv_flow_imp.g_varchar2_table(6) := 'ault null, '||wwv_flow.LF||
'    p_arg3_val        in varchar2 default null, '||wwv_flow.LF||
'    p_arg4_name       in varchar2 defau';
wwv_flow_imp.g_varchar2_table(7) := 'lt null, '||wwv_flow.LF||
'    p_arg4_val        in varchar2 default null, '||wwv_flow.LF||
'    p_arg5_name       in varchar2 default';
wwv_flow_imp.g_varchar2_table(8) := ' null, '||wwv_flow.LF||
'    p_arg5_val        in varchar2 default null ) '||wwv_flow.LF||
'as '||wwv_flow.LF||
'    pragma       autonomous_transactio';
wwv_flow_imp.g_varchar2_table(9) := 'n; '||wwv_flow.LF||
'begin '||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_error_log '||wwv_flow.LF||
'       (package_name, procedure_name, error, error_backtra';
wwv_flow_imp.g_varchar2_table(10) := 'ce,'||wwv_flow.LF||
'        arg1_name, arg1_val, arg2_name, arg2_val, arg3_name, arg3_val, '||wwv_flow.LF||
'        arg4_name, arg4_';
wwv_flow_imp.g_varchar2_table(11) := 'val, arg5_name, arg5_val ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'       (substr(p_package_name,1,255), substr(p_procedure_nam';
wwv_flow_imp.g_varchar2_table(12) := 'e,1,500), substr(p_error,1,4000), substr(p_error_backtrace,1,4000),'||wwv_flow.LF||
'        substr(p_arg1_name,1,255';
wwv_flow_imp.g_varchar2_table(13) := '), substr(p_arg1_val,1,4000), substr(p_arg2_name,1,255), substr(p_arg2_val,1,4000), '||wwv_flow.LF||
'        substr(';
wwv_flow_imp.g_varchar2_table(14) := 'p_arg3_name,1,255), substr(p_arg3_val,1,4000), substr(p_arg4_name,1,255), substr(p_arg4_val,1,4000),';
wwv_flow_imp.g_varchar2_table(15) := ' '||wwv_flow.LF||
'        substr(p_arg5_name,1,255), substr(p_arg5_val,1,4000) );'||wwv_flow.LF||
'    commit; '||wwv_flow.LF||
''||wwv_flow.LF||
'    -- g_error_reten';
wwv_flow_imp.g_varchar2_table(16) := 'tion_in_days is in the spec'||wwv_flow.LF||
'    delete from sp_error_log'||wwv_flow.LF||
'     where created_trunc < sysdate - g_erro';
wwv_flow_imp.g_varchar2_table(17) := 'r_retention_in_days;'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'end add_error_log;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_app_log ( '||wwv_flow.LF||
'    p_activity   in ';
wwv_flow_imp.g_varchar2_table(18) := 'varchar2,'||wwv_flow.LF||
'    p_details    in varchar2 ) '||wwv_flow.LF||
'as '||wwv_flow.LF||
'begin '||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_app_log '||wwv_flow.LF||
'       (activity, ';
wwv_flow_imp.g_varchar2_table(19) := 'details) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'       (substr(p_activity,1,255), substr(p_details,1,4000) );'||wwv_flow.LF||
'    commit; '||wwv_flow.LF||
''||wwv_flow.LF||
'en';
wwv_flow_imp.g_varchar2_table(20) := 'd add_app_log;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function create_area ('||wwv_flow.LF||
'    p_area                     in varchar2,'||wwv_flow.LF||
'    p_descriptio';
wwv_flow_imp.g_varchar2_table(21) := 'n              in varchar2 default null,'||wwv_flow.LF||
'    p_owner_id                 in number   default null'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(22) := ' )'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_area_id number := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_areas ('||wwv_flow.LF||
'        AREA';
wwv_flow_imp.g_varchar2_table(23) := ','||wwv_flow.LF||
'        description,'||wwv_flow.LF||
'        OWNER_ID)'||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_area,'||wwv_flow.LF||
'        p_description,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(24) := ' p_owner_id'||wwv_flow.LF||
'        )'||wwv_flow.LF||
'        returning id into l_area_id;'||wwv_flow.LF||
'    return l_area_id;'||wwv_flow.LF||
'end create_area;'||wwv_flow.LF||
''||wwv_flow.LF||
'f';
wwv_flow_imp.g_varchar2_table(25) := 'unction create_initiative ('||wwv_flow.LF||
'    p_area_id                  in number,'||wwv_flow.LF||
'    p_initiative              ';
wwv_flow_imp.g_varchar2_table(26) := ' in varchar2,'||wwv_flow.LF||
'    p_objective                in varchar2 default null,'||wwv_flow.LF||
'    P_OWNER_ID               ';
wwv_flow_imp.g_varchar2_table(27) := '  in number   default null'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_initiative_id number := null;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(28) := '  insert into sp_initiatives ('||wwv_flow.LF||
'        area_id,'||wwv_flow.LF||
'        initiative,'||wwv_flow.LF||
'        objective,'||wwv_flow.LF||
'        SPONS';
wwv_flow_imp.g_varchar2_table(29) := 'OR_ID) '||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_area_id,'||wwv_flow.LF||
'        p_initiative,'||wwv_flow.LF||
'        p_objective,'||wwv_flow.LF||
'        p_owner_I';
wwv_flow_imp.g_varchar2_table(30) := 'D'||wwv_flow.LF||
'        )'||wwv_flow.LF||
'    returning id into l_initiative_id ;'||wwv_flow.LF||
'    return l_initiative_id;'||wwv_flow.LF||
'end create_initiativ';
wwv_flow_imp.g_varchar2_table(31) := 'e;'||wwv_flow.LF||
''||wwv_flow.LF||
'function create_release ('||wwv_flow.LF||
'    p_release_train                  in varchar2,'||wwv_flow.LF||
'    p_release_owner_';
wwv_flow_imp.g_varchar2_table(32) := 'id               in number,'||wwv_flow.LF||
'    p_release                        in varchar2,'||wwv_flow.LF||
'    p_release_target_d';
wwv_flow_imp.g_varchar2_table(33) := 'ate            in date,'||wwv_flow.LF||
'    p_release_open_date              in date'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(34) := ' l_release_id  number := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_release_trains ('||wwv_flow.LF||
'        release_train,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(35) := '    release_owner_id,'||wwv_flow.LF||
'        release,'||wwv_flow.LF||
'        release_target_date,'||wwv_flow.LF||
'        release_open_date'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(36) := '  )'||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_release_train,'||wwv_flow.LF||
'        p_release_owner_id,'||wwv_flow.LF||
'        p_release,'||wwv_flow.LF||
'        p_r';
wwv_flow_imp.g_varchar2_table(37) := 'elease_target_date,'||wwv_flow.LF||
'        p_release_open_date'||wwv_flow.LF||
'        )'||wwv_flow.LF||
'        returning id into l_release_id;'||wwv_flow.LF||
''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(38) := '   return l_release_id;'||wwv_flow.LF||
'end create_release;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure copy_release ('||wwv_flow.LF||
'    p_copy_from_release_id  in';
wwv_flow_imp.g_varchar2_table(39) := '  number,'||wwv_flow.LF||
'    p_new_release           in  varchar2,'||wwv_flow.LF||
'    p_push_days             in  number,'||wwv_flow.LF||
'    p_ne';
wwv_flow_imp.g_varchar2_table(40) := 'w_release_id        out number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select release_train, release_owne';
wwv_flow_imp.g_varchar2_table(41) := 'r_id,'||wwv_flow.LF||
'               release_target_date, release_open_date,'||wwv_flow.LF||
'               description'||wwv_flow.LF||
'          fr';
wwv_flow_imp.g_varchar2_table(42) := 'om sp_release_trains'||wwv_flow.LF||
'         where id = p_copy_from_release_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        insert into sp_re';
wwv_flow_imp.g_varchar2_table(43) := 'lease_trains'||wwv_flow.LF||
'            (release_train, release_owner_id, release, '||wwv_flow.LF||
'             release_target_dat';
wwv_flow_imp.g_varchar2_table(44) := 'e, release_open_date,'||wwv_flow.LF||
'             description)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (c1.release_train, c1.rel';
wwv_flow_imp.g_varchar2_table(45) := 'ease_owner_id, p_new_release, '||wwv_flow.LF||
'             c1.release_target_date + p_push_days, c1.release_open_da';
wwv_flow_imp.g_varchar2_table(46) := 'te + p_push_days,'||wwv_flow.LF||
'             c1.description)'||wwv_flow.LF||
'            returning id into p_new_release_id;'||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(47) := 'nd loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_release_milestones'||wwv_flow.LF||
'       (release_id, milestone_name, upper_milestone_';
wwv_flow_imp.g_varchar2_table(48) := 'name, '||wwv_flow.LF||
'        milestone_date, milestone_description)'||wwv_flow.LF||
'    select p_new_release_id, milestone_name, u';
wwv_flow_imp.g_varchar2_table(49) := 'pper_milestone_name, '||wwv_flow.LF||
'           milestone_date + p_push_days, milestone_description'||wwv_flow.LF||
'      from sp_r';
wwv_flow_imp.g_varchar2_table(50) := 'elease_milestones'||wwv_flow.LF||
'     where release_id = p_copy_from_release_id;'||wwv_flow.LF||
'end copy_release;'||wwv_flow.LF||
''||wwv_flow.LF||
'function create';
wwv_flow_imp.g_varchar2_table(51) := '_team_member ('||wwv_flow.LF||
'    p_first_name                     in varchar2,'||wwv_flow.LF||
'    p_last_name                    ';
wwv_flow_imp.g_varchar2_table(52) := '  in varchar2,'||wwv_flow.LF||
'    p_email                          in varchar2,'||wwv_flow.LF||
'    p_tags                         ';
wwv_flow_imp.g_varchar2_table(53) := '  in varchar2 default null,'||wwv_flow.LF||
'    p_is_current_yn                  in varchar2 default ''Y'''||wwv_flow.LF||
'    )'||wwv_flow.LF||
'    r';
wwv_flow_imp.g_varchar2_table(54) := 'eturn number'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_team_member_id number := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_team_members ('||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(55) := '  first_name,'||wwv_flow.LF||
'        last_name,'||wwv_flow.LF||
'        email,'||wwv_flow.LF||
'        tags,'||wwv_flow.LF||
'        is_current_yn'||wwv_flow.LF||
'        )'||wwv_flow.LF||
'    va';
wwv_flow_imp.g_varchar2_table(56) := 'lues ('||wwv_flow.LF||
'        p_first_name,'||wwv_flow.LF||
'        p_last_name,'||wwv_flow.LF||
'        p_email,'||wwv_flow.LF||
'        p_tags,'||wwv_flow.LF||
'        p_is_curr';
wwv_flow_imp.g_varchar2_table(57) := 'ent_yn'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'    returning id into l_team_member_id;'||wwv_flow.LF||
'    return l_team_member_id;'||wwv_flow.LF||
'end create_team_me';
wwv_flow_imp.g_varchar2_table(58) := 'mber;'||wwv_flow.LF||
''||wwv_flow.LF||
'function create_project ('||wwv_flow.LF||
'    p_initiative_id                  in number,'||wwv_flow.LF||
'    p_project      ';
wwv_flow_imp.g_varchar2_table(59) := '                  in varchar2,'||wwv_flow.LF||
'    p_owner_id                       in number,'||wwv_flow.LF||
'    p_status_scale   ';
wwv_flow_imp.g_varchar2_table(60) := '                in varchar2  default ''A'','||wwv_flow.LF||
'    p_pct_complete                   in number    default ';
wwv_flow_imp.g_varchar2_table(61) := '10,'||wwv_flow.LF||
'    p_priority_id                    in number    default 4,'||wwv_flow.LF||
'    p_target_complete              ';
wwv_flow_imp.g_varchar2_table(62) := '  in date      default null,'||wwv_flow.LF||
'    p_release_id                     in number    default null,'||wwv_flow.LF||
'    p_p';
wwv_flow_imp.g_varchar2_table(63) := 'roject_size                   in varchar2  default ''M'','||wwv_flow.LF||
'    p_description                    in varc';
wwv_flow_imp.g_varchar2_table(64) := 'har2  default null,'||wwv_flow.LF||
'    p_tags                           in varchar2  default null'||wwv_flow.LF||
'    ) '||wwv_flow.LF||
'    return';
wwv_flow_imp.g_varchar2_table(65) := ' number'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_project_id           number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_projects ('||wwv_flow.LF||
'        initiati';
wwv_flow_imp.g_varchar2_table(66) := 've_id,'||wwv_flow.LF||
'        project,'||wwv_flow.LF||
'        owner_id,'||wwv_flow.LF||
'        status_scale,'||wwv_flow.LF||
'        pct_complete,'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(67) := '     priority_id,'||wwv_flow.LF||
'        release_id,'||wwv_flow.LF||
'        project_size,'||wwv_flow.LF||
'        description,'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(68) := 'tags) '||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_initiative_id,'||wwv_flow.LF||
'        p_project,'||wwv_flow.LF||
'        p_owner_id,'||wwv_flow.LF||
'        p_status';
wwv_flow_imp.g_varchar2_table(69) := '_scale,'||wwv_flow.LF||
'        p_pct_complete,'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        p_priority_id,'||wwv_flow.LF||
'        p_release_id,'||wwv_flow.LF||
'        p_pr';
wwv_flow_imp.g_varchar2_table(70) := 'oject_size,'||wwv_flow.LF||
'        p_description,'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        p_tags) '||wwv_flow.LF||
'    returning id into l_project_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(71) := '    return l_project_id;'||wwv_flow.LF||
'end create_project;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function copy_project ('||wwv_flow.LF||
'    p_project_id             ';
wwv_flow_imp.g_varchar2_table(72) := '        in number,'||wwv_flow.LF||
'    p_new_project_name               in varchar2'||wwv_flow.LF||
'    ) '||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(73) := ' l_project_id           number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- forced to use cursor to do insert into select returnin';
wwv_flow_imp.g_varchar2_table(74) := 'g'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select initiative_id,'||wwv_flow.LF||
'               owner_id,'||wwv_flow.LF||
'               status_scale';
wwv_flow_imp.g_varchar2_table(75) := ','||wwv_flow.LF||
'               priority_id,'||wwv_flow.LF||
'               project_size,'||wwv_flow.LF||
'               description,'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(76) := '  requires_reviews_yn,'||wwv_flow.LF||
'               doc_impact_yn,'||wwv_flow.LF||
'               focus_area_id,'||wwv_flow.LF||
'               pr';
wwv_flow_imp.g_varchar2_table(77) := 'oject_group_id,'||wwv_flow.LF||
'               tags'||wwv_flow.LF||
'          from sp_projects'||wwv_flow.LF||
'         where id = p_project_id'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(78) := ') loop'||wwv_flow.LF||
'        insert into sp_projects ('||wwv_flow.LF||
'               initiative_id,'||wwv_flow.LF||
'               project,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(79) := '          owner_id,'||wwv_flow.LF||
'               status_scale,'||wwv_flow.LF||
'               pct_complete,'||wwv_flow.LF||
'               --'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(80) := '           priority_id,'||wwv_flow.LF||
'               project_size,'||wwv_flow.LF||
'               description,'||wwv_flow.LF||
'               --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(81) := '              requires_reviews_yn,'||wwv_flow.LF||
'               doc_impact_yn,'||wwv_flow.LF||
'               focus_area_id,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(82) := '          project_group_id,'||wwv_flow.LF||
'               tags ) '||wwv_flow.LF||
'        values ('||wwv_flow.LF||
'               c1.initiative_id,';
wwv_flow_imp.g_varchar2_table(83) := ''||wwv_flow.LF||
'               p_new_project_name,'||wwv_flow.LF||
'               c1.owner_id,'||wwv_flow.LF||
'               c1.status_scale,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(84) := '           10,'||wwv_flow.LF||
'               --'||wwv_flow.LF||
'               c1.priority_id,'||wwv_flow.LF||
'               c1.project_size,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(85) := '           c1.description,'||wwv_flow.LF||
'               --'||wwv_flow.LF||
'               c1.requires_reviews_yn,'||wwv_flow.LF||
'               c';
wwv_flow_imp.g_varchar2_table(86) := '1.doc_impact_yn,'||wwv_flow.LF||
'               c1.focus_area_id,'||wwv_flow.LF||
'               c1.project_group_id,'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(87) := ' c1.tags )'||wwv_flow.LF||
'        returning id into l_project_id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    default_project_tasks (p_proje';
wwv_flow_imp.g_varchar2_table(88) := 'ct_id => l_project_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_project_contributors ('||wwv_flow.LF||
'           project_id,'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(89) := ' team_member_id,'||wwv_flow.LF||
'           responsibility_id,'||wwv_flow.LF||
'           responsibility, '||wwv_flow.LF||
'           tags )'||wwv_flow.LF||
'    sel';
wwv_flow_imp.g_varchar2_table(90) := 'ect l_project_id,'||wwv_flow.LF||
'           team_member_id,'||wwv_flow.LF||
'           responsibility_id,'||wwv_flow.LF||
'           responsibility';
wwv_flow_imp.g_varchar2_table(91) := ', '||wwv_flow.LF||
'           tags'||wwv_flow.LF||
'      from sp_project_contributors'||wwv_flow.LF||
'     where project_id = p_project_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ret';
wwv_flow_imp.g_varchar2_table(92) := 'urn l_project_id;'||wwv_flow.LF||
'end copy_project;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_related_project ('||wwv_flow.LF||
'    p_related_project_id in nu';
wwv_flow_imp.g_varchar2_table(93) := 'mber,'||wwv_flow.LF||
'    p_project_id         in number)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    insert into SP_PROJECT_RELATED ('||wwv_flow.LF||
'        PR';
wwv_flow_imp.g_varchar2_table(94) := 'OJECT_ID,'||wwv_flow.LF||
'        RELATED_PROJECT_ID)'||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_project_id,'||wwv_flow.LF||
'        p_related_project_i';
wwv_flow_imp.g_varchar2_table(95) := 'd);'||wwv_flow.LF||
'end add_related_project;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_project_contributor ('||wwv_flow.LF||
'    P_TEAM_MEMBER_ID    in number';
wwv_flow_imp.g_varchar2_table(96) := ','||wwv_flow.LF||
'    p_RESPONSIBILITY_ID in number,'||wwv_flow.LF||
'    p_project_id        in number)'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_team_member_id numb';
wwv_flow_imp.g_varchar2_table(97) := 'er;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into SP_PROJECT_CONTRIBUTORS ('||wwv_flow.LF||
'        TEAM_MEMBER_ID, '||wwv_flow.LF||
'        RESPONSIBILITY_';
wwv_flow_imp.g_varchar2_table(98) := 'ID, '||wwv_flow.LF||
'        project_id) '||wwv_flow.LF||
'        values ('||wwv_flow.LF||
'        P_TEAM_MEMBER_ID,'||wwv_flow.LF||
'        p_RESPONSIBILITY_ID,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(99) := '      p_project_id);'||wwv_flow.LF||
'    '||wwv_flow.LF||
'end add_project_contributor;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_project_link ('||wwv_flow.LF||
'    p_project_';
wwv_flow_imp.g_varchar2_table(100) := 'id      in number,'||wwv_flow.LF||
'    p_link_name       in varchar2,'||wwv_flow.LF||
'    p_link_url        in varchar2)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(101) := '   insert into SP_PROJECT_LINKS (PROJECT_ID, link_name, LINK_URL) '||wwv_flow.LF||
'    values (p_project_id, p_link_';
wwv_flow_imp.g_varchar2_table(102) := 'name, p_link_url);'||wwv_flow.LF||
'end add_project_link;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure default_project_tasks ('||wwv_flow.LF||
'    p_project_id      i';
wwv_flow_imp.g_varchar2_table(103) := 'n number)'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_tasks'||wwv_flow.LF||
'        (project_id, task_type_id, task_sub_type_id, sta';
wwv_flow_imp.g_varchar2_table(104) := 'tus_id)'||wwv_flow.LF||
'    select p.id,'||wwv_flow.LF||
'           nvl(tt.parent_type_id,tt.id),'||wwv_flow.LF||
'           case when tt.parent_typ';
wwv_flow_imp.g_varchar2_table(105) := 'e_id is not null then tt.id end,'||wwv_flow.LF||
'           (select min(id) from sp_task_statuses'||wwv_flow.LF||
'             where';
wwv_flow_imp.g_varchar2_table(106) := ' is_default_yn = ''Y'''||wwv_flow.LF||
'               and task_type_id = tt.parent_type_id)'||wwv_flow.LF||
'      from sp_projects p,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(107) := '           sp_initiatives i,'||wwv_flow.LF||
'           sp_initiative_default_tasks dt,'||wwv_flow.LF||
'           sp_task_types tt'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(108) := '     where p.id = p_project_id'||wwv_flow.LF||
'       and p.initiative_id = i.id'||wwv_flow.LF||
'       and i.id = dt.initiative_id'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(109) := '       and dt.type_id = tt.id'||wwv_flow.LF||
'       and tt.include_yn = ''Y'';'||wwv_flow.LF||
'end default_project_tasks;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure';
wwv_flow_imp.g_varchar2_table(110) := ' archive_project ('||wwv_flow.LF||
'    p_project_id      in number,'||wwv_flow.LF||
'    p_app_user        in varchar2)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(111) := 'update sp_projects set archived_yn = ''Y'', archived_date = sysdate, archived_by = p_app_user where id';
wwv_flow_imp.g_varchar2_table(112) := ' = p_project_id;'||wwv_flow.LF||
'end archive_project;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure un_archive_project ('||wwv_flow.LF||
'    p_project_id      in numbe';
wwv_flow_imp.g_varchar2_table(113) := 'r)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   update sp_projects set archived_yn = ''N'', archived_date = null where id = p_project_';
wwv_flow_imp.g_varchar2_table(114) := 'id;'||wwv_flow.LF||
'end un_archive_project;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure mark_proj_as_duplidate ('||wwv_flow.LF||
'    p_project_id        in number,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(115) := '   p_dup_of_project    in number)'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    update sp_projects set DUPLICATE_OF_PROJECT_ID = p_du';
wwv_flow_imp.g_varchar2_table(116) := 'p_of_project where id = p_project_id;'||wwv_flow.LF||
'end mark_proj_as_duplidate;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure unmark_proj_as_duplicat';
wwv_flow_imp.g_varchar2_table(117) := 'e ('||wwv_flow.LF||
'    p_project_id        in number)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    update sp_projects set DUPLICATE_OF_PROJECT_ID ';
wwv_flow_imp.g_varchar2_table(118) := '= null where id = p_project_id;'||wwv_flow.LF||
'end unmark_proj_as_duplicate;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- additional APIs'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_use';
wwv_flow_imp.g_varchar2_table(119) := 'r_email ('||wwv_flow.LF||
'    p_app_user     in  varchar2  default null,'||wwv_flow.LF||
'    p_user_id      in  number    default nu';
wwv_flow_imp.g_varchar2_table(120) := 'll )'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_email varchar(255) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select e';
wwv_flow_imp.g_varchar2_table(121) := 'mail '||wwv_flow.LF||
'          from sp_team_members '||wwv_flow.LF||
'         where email = lower(p_app_user)'||wwv_flow.LF||
'            or id = p';
wwv_flow_imp.g_varchar2_table(122) := '_user_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        l_email := c1.email;'||wwv_flow.LF||
'        exit;'||wwv_flow.LF||
'    end loop;     '||wwv_flow.LF||
'    return l_email';
wwv_flow_imp.g_varchar2_table(123) := ';'||wwv_flow.LF||
'end get_user_email;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_user_id ('||wwv_flow.LF||
'    p_app_user     in  varchar2  default null,'||wwv_flow.LF||
'    p_s';
wwv_flow_imp.g_varchar2_table(124) := 'creen_name  in  varchar2  default null)'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_id number := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for ';
wwv_flow_imp.g_varchar2_table(125) := 'c1 in ('||wwv_flow.LF||
'        select id '||wwv_flow.LF||
'          from sp_team_members '||wwv_flow.LF||
'         where email = lower(p_app_user)'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(126) := '            or screen_name = lower(p_screen_name)'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        l_id := c1.id;'||wwv_flow.LF||
'        exit;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(127) := '  end loop;     '||wwv_flow.LF||
'    return l_id;'||wwv_flow.LF||
'end get_user_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_area_name ('||wwv_flow.LF||
'    p_id              i';
wwv_flow_imp.g_varchar2_table(128) := 'n number)'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_name varchar2(255) := null;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    for c1 in (select area';
wwv_flow_imp.g_varchar2_table(129) := ' from SP_AREAS where id = p_id) loop'||wwv_flow.LF||
'        l_name := c1.area;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    return l_name;'||wwv_flow.LF||
'end';
wwv_flow_imp.g_varchar2_table(130) := ' get_area_name;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_initiative_name ('||wwv_flow.LF||
'    p_id              in number)'||wwv_flow.LF||
'    return varchar2';
wwv_flow_imp.g_varchar2_table(131) := ''||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_name varchar2(255) := null;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    for c1 in (select INITIATIVE from SP_INITIATIVES wh';
wwv_flow_imp.g_varchar2_table(132) := 'ere id = p_id) loop'||wwv_flow.LF||
'        l_name := c1.INITIATIVE;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    return l_name;'||wwv_flow.LF||
'end get_initia';
wwv_flow_imp.g_varchar2_table(133) := 'tive_name;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_project_name ('||wwv_flow.LF||
'    p_id              in number)'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(134) := 'l_name varchar2(255) := null;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    for c1 in (select PROJECT from SP_PROJECTS where id = p_id)';
wwv_flow_imp.g_varchar2_table(135) := ' loop'||wwv_flow.LF||
'        l_name := c1.PROJECT;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    return l_name;'||wwv_flow.LF||
'end get_project_name;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedu';
wwv_flow_imp.g_varchar2_table(136) := 're add_project_tag ('||wwv_flow.LF||
'    p_project_id        in number,'||wwv_flow.LF||
'    p_tag               in varchar2)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(137) := ' l_tags varchar2(4000) := null;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    if trim(p_tag) is not null then'||wwv_flow.LF||
'       for c1 in (select ';
wwv_flow_imp.g_varchar2_table(138) := 'tags from sp_projects where id = p_project_id) loop'||wwv_flow.LF||
'          l_tags := c1.tags;'||wwv_flow.LF||
'          if c1.tag';
wwv_flow_imp.g_varchar2_table(139) := 's is null then'||wwv_flow.LF||
'             update sp_projects set tags = upper(p_tag) where id = p_project_id;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(140) := '      elsif instr('',''||c1.tags||'','', '',''||upper(p_tag)||'','') = 0 then'||wwv_flow.LF||
'             l_tags := rtrim(l';
wwv_flow_imp.g_varchar2_table(141) := '_tags,'', '');'||wwv_flow.LF||
'             l_tags := ltrim(l_tags,'','');'||wwv_flow.LF||
'             l_tags := l_tags||'',''||upper(p_t';
wwv_flow_imp.g_varchar2_table(142) := 'ag);'||wwv_flow.LF||
'             update sp_projects set tags = l_tags where id = p_project_id;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(143) := '    end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end add_project_tag;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure remove_project_tag ('||wwv_flow.LF||
'    p_project_id     ';
wwv_flow_imp.g_varchar2_table(144) := '   in number,'||wwv_flow.LF||
'    p_tag               in varchar2)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_tags varchar(4000) := null;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(145) := 'update sp_projects set tags = replace(tags,'', '','','') where id = p_project_id;'||wwv_flow.LF||
'    update sp_projects';
wwv_flow_imp.g_varchar2_table(146) := ' set tags = rtrim(rtrim(tags,'',''),'' '') where id = p_project_id;'||wwv_flow.LF||
'    update sp_projects set tags = lt';
wwv_flow_imp.g_varchar2_table(147) := 'rim(ltrim(tags,'',''),'' '') where id = p_project_id;'||wwv_flow.LF||
'    for c1 in (select tags from sp_projects where ';
wwv_flow_imp.g_varchar2_table(148) := 'id = p_project_id) loop'||wwv_flow.LF||
'       if c1.tags = upper(p_tag) then'||wwv_flow.LF||
'           update sp_projects set tags';
wwv_flow_imp.g_varchar2_table(149) := ' = null where id = p_project_id;'||wwv_flow.LF||
'       elsif instr(c1.tags, '',''||upper(p_tag)||'','') > 0 then'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(150) := '     update sp_projects set tags = replace(tags,upper(p_tag)||'','',null) where id = p_project_id;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(151) := '    elsif instr(c1.tags, '',''||upper(p_tag)) > 0 then'||wwv_flow.LF||
'           update sp_projects set tags = replac';
wwv_flow_imp.g_varchar2_table(152) := 'e(tags,'',''||upper(p_tag),null) where id = p_project_id;'||wwv_flow.LF||
'       elsif instr(c1.tags, upper(p_tag)) > ';
wwv_flow_imp.g_varchar2_table(153) := '0 then'||wwv_flow.LF||
'           update sp_projects set tags = replace(tags,upper(p_tag),null) where id = p_project';
wwv_flow_imp.g_varchar2_table(154) := '_id;'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    update sp_projects set tags = rtrim(tags,'', '') where id = p_pr';
wwv_flow_imp.g_varchar2_table(155) := 'oject_id;'||wwv_flow.LF||
'end remove_project_tag;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure set_nomenclature'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        sel';
wwv_flow_imp.g_varchar2_table(156) := 'ect static_id, '||wwv_flow.LF||
'               nvl(custom_value, default_value) nomenclature'||wwv_flow.LF||
'        from SP_APP_NOM';
wwv_flow_imp.g_varchar2_table(157) := 'ENCLATURE'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'    '||wwv_flow.LF||
'        if    c1.static_id = ''PROJECTS''    then APEX_UTIL.SET_SESSION_';
wwv_flow_imp.g_varchar2_table(158) := 'STATE(''NOMENCLATURE_PROJECTS'',   c1.nomenclature); '||wwv_flow.LF||
'        elsif c1.static_id = ''PROJECT''     then ';
wwv_flow_imp.g_varchar2_table(159) := 'APEX_UTIL.SET_SESSION_STATE(''NOMENCLATURE_PROJECT'',    c1.nomenclature); '||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        elsif c';
wwv_flow_imp.g_varchar2_table(160) := '1.static_id = ''AREAS''       then APEX_UTIL.SET_SESSION_STATE(''NOMENCLATURE_AREAS'',      c1.nomenclat';
wwv_flow_imp.g_varchar2_table(161) := 'ure);'||wwv_flow.LF||
'        elsif c1.static_id = ''AREA''        then APEX_UTIL.SET_SESSION_STATE(''NOMENCLATURE_AREA';
wwv_flow_imp.g_varchar2_table(162) := ''',       c1.nomenclature); '||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        elsif c1.static_id = ''INITIATIVES'' then APEX_UTIL.SET';
wwv_flow_imp.g_varchar2_table(163) := '_SESSION_STATE(''NOMENCLATURE_INITIATIVES'', c1.nomenclature); '||wwv_flow.LF||
'        elsif c1.static_id = ''INITIATI';
wwv_flow_imp.g_varchar2_table(164) := 'VE''  then APEX_UTIL.SET_SESSION_STATE(''NOMENCLATURE_INITIATIVE'',  c1.nomenclature); '||wwv_flow.LF||
'        --'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(165) := '    elsif c1.static_id = ''CONTRIBUTOR''   then APEX_UTIL.SET_SESSION_STATE(''NOMENCLATURE_CONTRIBUTOR''';
wwv_flow_imp.g_varchar2_table(166) := ',  c1.nomenclature); '||wwv_flow.LF||
'        elsif c1.static_id = ''CONTRIBUTORS''  then APEX_UTIL.SET_SESSION_STATE(';
wwv_flow_imp.g_varchar2_table(167) := '''NOMENCLATURE_CONTRIBUTORS'', c1.nomenclature); '||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        elsif c1.static_id = ''';
wwv_flow_imp.g_varchar2_table(168) := 'USERS''       then APEX_UTIL.SET_SESSION_STATE(''NOMENCLATURE_USERS'',       c1.nomenclature); '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(169) := ' elsif c1.static_id = ''USER''        then APEX_UTIL.SET_SESSION_STATE(''NOMENCLATURE_USER'',        c1.';
wwv_flow_imp.g_varchar2_table(170) := 'nomenclature); '||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        elsif c1.static_id = ''STRATEGIC_PLANNER'' then APEX_UTIL.SET_SESSI';
wwv_flow_imp.g_varchar2_table(171) := 'ON_STATE(''NOMENCLATURE_STRATEGIC_PLANNER'', c1.nomenclature); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end set_';
wwv_flow_imp.g_varchar2_table(172) := 'nomenclature;'||wwv_flow.LF||
''||wwv_flow.LF||
'function show_nomenclature return clob'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'return ''Area:        <strong>''||apex';
wwv_flow_imp.g_varchar2_table(173) := '_util.get_session_state(''NOMENCLATURE_AREA'')||''</strong><br>'||wwv_flow.LF||
'Areas:       <strong>''||apex_util.get_s';
wwv_flow_imp.g_varchar2_table(174) := 'ession_state(''NOMENCLATURE_AREAS'')||''</strong><br>'||wwv_flow.LF||
'Initiative:  <strong>''||apex_util.get_session_sta';
wwv_flow_imp.g_varchar2_table(175) := 'te(''NOMENCLATURE_INITIATIVE'')||''</strong><br>'||wwv_flow.LF||
'Initiatives: <strong>''||apex_util.get_session_state(''N';
wwv_flow_imp.g_varchar2_table(176) := 'OMENCLATURE_INITIATIVES'')||''</strong><br>'||wwv_flow.LF||
'Projects:    <strong>''||apex_util.get_session_state(''NOMEN';
wwv_flow_imp.g_varchar2_table(177) := 'CLATURE_PROJECTS'')||''</strong><br>'||wwv_flow.LF||
'Project:     <strong>''||apex_util.get_session_state(''NOMENCLATURE';
wwv_flow_imp.g_varchar2_table(178) := '_PROJECT'')||''</strong><br>'||wwv_flow.LF||
'Contributors:<strong>''||apex_util.get_session_state(''NOMENCLATURE_CONTRIB';
wwv_flow_imp.g_varchar2_table(179) := 'UTORS'')||''</strong><br>'||wwv_flow.LF||
'Contributor: <strong>''||apex_util.get_session_state(''NOMENCLATURE_CONTRIBUTO';
wwv_flow_imp.g_varchar2_table(180) := 'R'')||''</strong><br>'';'||wwv_flow.LF||
'end show_nomenclature;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_nomenclature ('||wwv_flow.LF||
'    p_static_id  in  varch';
wwv_flow_imp.g_varchar2_table(181) := 'ar2 )'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select nvl(custom_value, default_value) n';
wwv_flow_imp.g_varchar2_table(182) := 'omenclature'||wwv_flow.LF||
'          from sp_app_nomenclature'||wwv_flow.LF||
'         where static_id = upper(p_static_id)'||wwv_flow.LF||
'    ) l';
wwv_flow_imp.g_varchar2_table(183) := 'oop'||wwv_flow.LF||
'        return c1.nomenclature;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return null;'||wwv_flow.LF||
'end get_nomenclature;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedur';
wwv_flow_imp.g_varchar2_table(184) := 'e add_setting (  '||wwv_flow.LF||
'    p_static_id      in  varchar2,   '||wwv_flow.LF||
'    p_description    in  varchar2, '||wwv_flow.LF||
'    p_se';
wwv_flow_imp.g_varchar2_table(185) := 'tting_value  in  varchar2, '||wwv_flow.LF||
'    p_is_numeric_yn  in  varchar2, '||wwv_flow.LF||
'    p_is_yn          in  varchar2 ) ';
wwv_flow_imp.g_varchar2_table(186) := ''||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_is_numeric_yn = ''Y'' and p_is_yn = ''Y'' then '||wwv_flow.LF||
'        raise_application_error(-201';
wwv_flow_imp.g_varchar2_table(187) := '11,''Setting cannot be both numeric and YN.''); '||wwv_flow.LF||
'    end if; '||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into sp_app_settings  '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(188) := '   (static_id, description, is_numeric_yn, is_yn) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'        (p_static_id, p_description, ';
wwv_flow_imp.g_varchar2_table(189) := 'p_is_numeric_yn, p_is_yn); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    set_setting(p_static_id => p_static_id, p_setting_value => p_setti';
wwv_flow_imp.g_varchar2_table(190) := 'ng_value); '||wwv_flow.LF||
''||wwv_flow.LF||
'end add_setting;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure set_setting (  '||wwv_flow.LF||
'    p_static_id      in  varchar2,   '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(191) := 'p_setting_value  in  varchar2 ) '||wwv_flow.LF||
'is  '||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'  '||wwv_flow.LF||
'    for c1 in ( '||wwv_flow.LF||
'        select id, '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(192) := ' setting_value,'||wwv_flow.LF||
'               is_numeric_yn, '||wwv_flow.LF||
'               is_yn '||wwv_flow.LF||
'          from sp_app_settings ';
wwv_flow_imp.g_varchar2_table(193) := ' '||wwv_flow.LF||
'         where static_id = upper(p_static_id) '||wwv_flow.LF||
'    ) loop '||wwv_flow.LF||
'        if c1.is_numeric_yn = ''Y'' and v';
wwv_flow_imp.g_varchar2_table(194) := 'alidate_conversion(p_setting_value as NUMBER) = 0 then '||wwv_flow.LF||
'                raise_application_error(-201';
wwv_flow_imp.g_varchar2_table(195) := '11,''Value must be numeric.''); '||wwv_flow.LF||
'        elsif c1.is_yn = ''Y'' and p_setting_value not in (''Y'',''N'') the';
wwv_flow_imp.g_varchar2_table(196) := 'n  '||wwv_flow.LF||
'            raise_application_error(-20111,''Value must be Y or N.''); '||wwv_flow.LF||
'        end if; '||wwv_flow.LF||
'        u';
wwv_flow_imp.g_varchar2_table(197) := 'pdate sp_app_settings  '||wwv_flow.LF||
'           set setting_value = p_setting_value  '||wwv_flow.LF||
'         where id = c1.id'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(198) := '          and (p_setting_value != c1.setting_value or c1.setting_value is null or p_setting_value is';
wwv_flow_imp.g_varchar2_table(199) := ' null);  '||wwv_flow.LF||
'    end loop; '||wwv_flow.LF||
''||wwv_flow.LF||
'end set_setting;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_setting ('||wwv_flow.LF||
'    p_static_id  in  varchar2 )'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(200) := '    return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select setting_value'||wwv_flow.LF||
'          from sp_app_set';
wwv_flow_imp.g_varchar2_table(201) := 'tings'||wwv_flow.LF||
'         where static_id = upper(p_static_id)'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return c1.setting_value;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(202) := 'end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return null;'||wwv_flow.LF||
''||wwv_flow.LF||
'end get_setting;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_ai_prompt (  '||wwv_flow.LF||
'    p_static_id      in ';
wwv_flow_imp.g_varchar2_table(203) := ' varchar2,   '||wwv_flow.LF||
'    p_description    in  varchar2, '||wwv_flow.LF||
'    p_prompt         in  clob ) '||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    ins';
wwv_flow_imp.g_varchar2_table(204) := 'ert into sp_ai_prompts  '||wwv_flow.LF||
'        (static_id, description) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'        (p_static_id, p_descr';
wwv_flow_imp.g_varchar2_table(205) := 'iption); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    set_ai_prompt(p_static_id => p_static_id, p_prompt => p_prompt); '||wwv_flow.LF||
''||wwv_flow.LF||
'end add_ai_prompt';
wwv_flow_imp.g_varchar2_table(206) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure set_ai_prompt (  '||wwv_flow.LF||
'    p_static_id   in  varchar2,   '||wwv_flow.LF||
'    p_prompt      in  clob ) '||wwv_flow.LF||
'is ';
wwv_flow_imp.g_varchar2_table(207) := ' '||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'  '||wwv_flow.LF||
'    for c1 in ( '||wwv_flow.LF||
'        select id, prompt '||wwv_flow.LF||
'          from sp_ai_prompts  '||wwv_flow.LF||
'         whe';
wwv_flow_imp.g_varchar2_table(208) := 're static_id = upper(p_static_id) '||wwv_flow.LF||
'    ) loop '||wwv_flow.LF||
'        if (c1.prompt is null and p_prompt is not nul';
wwv_flow_imp.g_varchar2_table(209) := 'l) or '||wwv_flow.LF||
'           (c1.prompt is not null and p_prompt is null) or'||wwv_flow.LF||
'           c1.prompt != p_prompt'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(210) := '       then '||wwv_flow.LF||
'            update sp_ai_prompts '||wwv_flow.LF||
'               set prompt = p_prompt  '||wwv_flow.LF||
'             w';
wwv_flow_imp.g_varchar2_table(211) := 'here id = c1.id;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'end set_ai_prompt;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_ai_prompt ('||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(212) := 'static_id  in  varchar2 )'||wwv_flow.LF||
'    return clob'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select prompt'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(213) := 'from sp_ai_prompts'||wwv_flow.LF||
'         where static_id = upper(p_static_id)'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return c1.prompt';
wwv_flow_imp.g_varchar2_table(214) := ';'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return null;'||wwv_flow.LF||
''||wwv_flow.LF||
'end get_ai_prompt;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_notification_id ('||wwv_flow.LF||
'    p_static_';
wwv_flow_imp.g_varchar2_table(215) := 'id   in  varchar2 )'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select id'||wwv_flow.LF||
'          from sp_';
wwv_flow_imp.g_varchar2_table(216) := 'notifications'||wwv_flow.LF||
'         where static_id = upper(p_static_id)'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return c1.id;'||wwv_flow.LF||
'    end';
wwv_flow_imp.g_varchar2_table(217) := ' loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return null;'||wwv_flow.LF||
''||wwv_flow.LF||
'end get_notification_id;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure notification_opt_in ('||wwv_flow.LF||
'    p_team_memb';
wwv_flow_imp.g_varchar2_table(218) := 'er_id   in  number,'||wwv_flow.LF||
'    p_notification_id  in  number,'||wwv_flow.LF||
'    p_frequency        in  varchar2 default ''';
wwv_flow_imp.g_varchar2_table(219) := 'WEEKLY'','||wwv_flow.LF||
'    p_release_id       in  number   default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select ';
wwv_flow_imp.g_varchar2_table(220) := 'count(*) cnt'||wwv_flow.LF||
'          from sp_notification_subscriptions'||wwv_flow.LF||
'         where team_member_id = p_team_mem';
wwv_flow_imp.g_varchar2_table(221) := 'ber_id'||wwv_flow.LF||
'           and notification_id = p_notification_id'||wwv_flow.LF||
'           and (release_id = p_release_id ';
wwv_flow_imp.g_varchar2_table(222) := 'or p_release_id is null)'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        if c1.cnt = 0 then'||wwv_flow.LF||
'            insert into sp_notificati';
wwv_flow_imp.g_varchar2_table(223) := 'on_subscriptions'||wwv_flow.LF||
'                (team_member_id, notification_id, frequency, release_id, opted_in_y';
wwv_flow_imp.g_varchar2_table(224) := 'n)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (p_team_member_id, p_notification_id, p_frequency, p_release_i';
wwv_flow_imp.g_varchar2_table(225) := 'd, ''Y'');'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            update sp_notification_subscriptions'||wwv_flow.LF||
'               set opted_in_y';
wwv_flow_imp.g_varchar2_table(226) := 'n = ''Y'''||wwv_flow.LF||
'             where team_member_id = p_team_member_id'||wwv_flow.LF||
'               and notification_id = p_';
wwv_flow_imp.g_varchar2_table(227) := 'notification_id'||wwv_flow.LF||
'               and (release_id = p_release_id or p_release_id is null);'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(228) := 'update sp_notification_subscriptions'||wwv_flow.LF||
'               set frequency = p_frequency'||wwv_flow.LF||
'             where t';
wwv_flow_imp.g_varchar2_table(229) := 'eam_member_id = p_team_member_id'||wwv_flow.LF||
'               and notification_id = p_notification_id'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(230) := '   and (release_id = p_release_id or p_release_id is null)'||wwv_flow.LF||
'               and frequency != p_frequen';
wwv_flow_imp.g_varchar2_table(231) := 'cy;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end notification_opt_in;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure notification_opt_out ('||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(232) := 'team_member_id   in  number,'||wwv_flow.LF||
'    p_notification_id  in  number,'||wwv_flow.LF||
'    p_release_id       in  number de';
wwv_flow_imp.g_varchar2_table(233) := 'fault null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select id'||wwv_flow.LF||
'          from sp_notification_subscriptions';
wwv_flow_imp.g_varchar2_table(234) := ''||wwv_flow.LF||
'         where team_member_id = p_team_member_id'||wwv_flow.LF||
'           and notification_id = p_notification_id';
wwv_flow_imp.g_varchar2_table(235) := ''||wwv_flow.LF||
'           and (release_id = p_release_id or p_release_id is null)'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        update sp_not';
wwv_flow_imp.g_varchar2_table(236) := 'ification_subscriptions'||wwv_flow.LF||
'           set opted_in_yn = ''N'''||wwv_flow.LF||
'         where id = c1.id'||wwv_flow.LF||
'           and op';
wwv_flow_imp.g_varchar2_table(237) := 'ted_in_yn != ''N'';'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end notification_opt_out;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure get_create_project_qp ('||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(238) := 'app_user         in varchar2,'||wwv_flow.LF||
'    p_quick_pick_id_1  out number,'||wwv_flow.LF||
'    p_quick_pick_1     out varchar2';
wwv_flow_imp.g_varchar2_table(239) := ','||wwv_flow.LF||
'    p_quick_pick_id_2  out number,'||wwv_flow.LF||
'    p_quick_pick_2     out varchar2,'||wwv_flow.LF||
'    p_quick_pick_id_3  out';
wwv_flow_imp.g_varchar2_table(240) := ' number,'||wwv_flow.LF||
'    p_quick_pick_3     out varchar2,'||wwv_flow.LF||
'    p_quick_pick_id_4  out number,'||wwv_flow.LF||
'    p_quick_pick_4 ';
wwv_flow_imp.g_varchar2_table(241) := '    out varchar2'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    c int := 0;'||wwv_flow.LF||
'    l_quick_pick_id_1   number        := null;'||wwv_flow.LF||
'    l_quic';
wwv_flow_imp.g_varchar2_table(242) := 'k_pick_1      varchar2(255) := null;'||wwv_flow.LF||
'    l_quick_pick_id_2   number        := null;'||wwv_flow.LF||
'    l_quick_pick';
wwv_flow_imp.g_varchar2_table(243) := '_2      varchar2(255) := null;'||wwv_flow.LF||
'    l_quick_pick_id_3   number        := null;'||wwv_flow.LF||
'    l_quick_pick_3    ';
wwv_flow_imp.g_varchar2_table(244) := '  varchar2(255) := null;'||wwv_flow.LF||
'    l_quick_pick_id_4   number        := null;'||wwv_flow.LF||
'    l_quick_pick_4      varc';
wwv_flow_imp.g_varchar2_table(245) := 'har2(255) := null;'||wwv_flow.LF||
'    l_app_user_id       number        := null;'||wwv_flow.LF||
'    l_app_user          varchar2(2';
wwv_flow_imp.g_varchar2_table(246) := '55) := null;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    -- get top 4 project owners'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select t.first_name||'' ''';
wwv_flow_imp.g_varchar2_table(247) := '||t.last_name||'' (''||t.email||'')'' n, p.owner_id, count(*) c '||wwv_flow.LF||
'        from sp_projects p, sp_team_mem';
wwv_flow_imp.g_varchar2_table(248) := 'bers t '||wwv_flow.LF||
'        where p.owner_id = t.id '||wwv_flow.LF||
'        group by t.first_name||'' ''||t.last_name||'' (''||t.em';
wwv_flow_imp.g_varchar2_table(249) := 'ail||'')'', p.owner_id '||wwv_flow.LF||
'        order by 3 desc '||wwv_flow.LF||
'        fetch first 5 rows only) loop'||wwv_flow.LF||
'            c :';
wwv_flow_imp.g_varchar2_table(250) := '= c + 1;'||wwv_flow.LF||
'            if c = 1 then '||wwv_flow.LF||
'                l_quick_pick_id_1 := c1.owner_id; '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(251) := '   l_quick_pick_1    := c1.n;'||wwv_flow.LF||
'            elsif c = 2 then '||wwv_flow.LF||
'                l_quick_pick_id_2 := c1.';
wwv_flow_imp.g_varchar2_table(252) := 'owner_id; '||wwv_flow.LF||
'                l_quick_pick_2    := c1.n;'||wwv_flow.LF||
'            elsif c = 3 then '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(253) := 'l_quick_pick_id_3 := c1.owner_id; '||wwv_flow.LF||
'                l_quick_pick_3    := c1.n;'||wwv_flow.LF||
'            elsif c = ';
wwv_flow_imp.g_varchar2_table(254) := '4 then '||wwv_flow.LF||
'                l_quick_pick_id_4 := c1.owner_id; '||wwv_flow.LF||
'                l_quick_pick_4    := c1.n';
wwv_flow_imp.g_varchar2_table(255) := ';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- make sure the current user is on the list'||wwv_flow.LF||
'    for c1 in ';
wwv_flow_imp.g_varchar2_table(256) := '(select id, t.first_name||'' ''||t.last_name||'' (''||t.email||'')'' n from SP_TEAM_MEMBERS t where t.emai';
wwv_flow_imp.g_varchar2_table(257) := 'l = lower(p_app_user)) loop'||wwv_flow.LF||
'        l_app_user_id := c1.id;'||wwv_flow.LF||
'        l_app_user := c1.n;'||wwv_flow.LF||
'    end loop';
wwv_flow_imp.g_varchar2_table(258) := ';'||wwv_flow.LF||
'    if l_app_user_id = l_quick_pick_id_1 or '||wwv_flow.LF||
'       l_app_user_id = l_quick_pick_id_2 or '||wwv_flow.LF||
'       l';
wwv_flow_imp.g_varchar2_table(259) := '_app_user_id = l_quick_pick_id_3 or '||wwv_flow.LF||
'       l_app_user_id = l_quick_pick_id_4 then'||wwv_flow.LF||
'        null;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(260) := ' else'||wwv_flow.LF||
'       l_quick_pick_id_4 := l_app_user_id;'||wwv_flow.LF||
'       l_quick_pick_4 := l_app_user;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(261) := '   -- set return values'||wwv_flow.LF||
'    p_quick_pick_id_1  := l_quick_pick_id_1 ;'||wwv_flow.LF||
'    p_quick_pick_1     := l_qu';
wwv_flow_imp.g_varchar2_table(262) := 'ick_pick_1    ;'||wwv_flow.LF||
'    p_quick_pick_id_2  := l_quick_pick_id_2 ;'||wwv_flow.LF||
'    p_quick_pick_2     := l_quick_pick';
wwv_flow_imp.g_varchar2_table(263) := '_2   ;'||wwv_flow.LF||
'    p_quick_pick_id_3  := l_quick_pick_id_3 ;'||wwv_flow.LF||
'    p_quick_pick_3     := l_quick_pick_3   ;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(264) := '  p_quick_pick_id_4  := l_quick_pick_id_4 ;'||wwv_flow.LF||
'    p_quick_pick_4     := l_quick_pick_4    ;'||wwv_flow.LF||
'end get_cr';
wwv_flow_imp.g_varchar2_table(265) := 'eate_project_qp;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure get_current_username_and_id ('||wwv_flow.LF||
'    p_app_user         in varchar2,'||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(266) := 'users_name       out varchar2,'||wwv_flow.LF||
'    p_users_id         out number'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_users_name varchar(';
wwv_flow_imp.g_varchar2_table(267) := '255) := null;'||wwv_flow.LF||
'    l_users_id   number := null;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    for c1 in (select first_name, last_name, i';
wwv_flow_imp.g_varchar2_table(268) := 'd from SP_TEAM_MEMBERS where email = lower(p_app_user)) loop '||wwv_flow.LF||
'        l_users_name := c1.first_name ';
wwv_flow_imp.g_varchar2_table(269) := '|| '' '' || c1.last_name;'||wwv_flow.LF||
'        l_users_id := c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    p_users_name := l_users_name;';
wwv_flow_imp.g_varchar2_table(270) := ''||wwv_flow.LF||
'    p_users_id := p_users_id;'||wwv_flow.LF||
'end get_current_username_and_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------'||wwv_flow.LF||
'-- data sync'||wwv_flow.LF||
'--'||wwv_flow.LF||
''||wwv_flow.LF||
'proc';
wwv_flow_imp.g_varchar2_table(271) := 'edure sync_team_members_app_role ('||wwv_flow.LF||
'    p_app_id in number)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'       select '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(272) := '           t.id,'||wwv_flow.LF||
'           t.first_name,'||wwv_flow.LF||
'           t.last_name,'||wwv_flow.LF||
'           t.email,'||wwv_flow.LF||
'           nvl';
wwv_flow_imp.g_varchar2_table(273) := '(t.APP_ROLE,''Unknown'') current_app_role,'||wwv_flow.LF||
'           nvl(('||wwv_flow.LF||
'            select'||wwv_flow.LF||
'                    dec';
wwv_flow_imp.g_varchar2_table(274) := 'ode(instr(role_names,''Administrator''),0,'||wwv_flow.LF||
'                    decode(instr(role_names,''Contributor''),';
wwv_flow_imp.g_varchar2_table(275) := '0,'||wwv_flow.LF||
'                    decode(instr(role_names,''Reader''),0,''No Access'',''Reader''),'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(276) := '  ''Contributor''),'||wwv_flow.LF||
'                    ''Administrator'') role_names'||wwv_flow.LF||
'             from   APEX_APPL_ACL_';
wwv_flow_imp.g_varchar2_table(277) := 'USERS u '||wwv_flow.LF||
'             where  u.APPLICATION_ID = p_app_id and '||wwv_flow.LF||
'                    u.user_name_lc = t';
wwv_flow_imp.g_varchar2_table(278) := '.email'||wwv_flow.LF||
'             ),'||wwv_flow.LF||
'             ''No Access'') app_role'||wwv_flow.LF||
'        from sp_team_members t'||wwv_flow.LF||
'        whe';
wwv_flow_imp.g_varchar2_table(279) := 're nvl(('||wwv_flow.LF||
'            select'||wwv_flow.LF||
'                    decode(instr(role_names,''Administrator''),0,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(280) := '            decode(instr(role_names,''Contributor''),0,'||wwv_flow.LF||
'                    decode(instr(role_names,''R';
wwv_flow_imp.g_varchar2_table(281) := 'eader''),0,''No Access'',''Reader''),'||wwv_flow.LF||
'                    ''Contributor''),'||wwv_flow.LF||
'                    ''Administra';
wwv_flow_imp.g_varchar2_table(282) := 'tor'') role_names'||wwv_flow.LF||
'             from   APEX_APPL_ACL_USERS u '||wwv_flow.LF||
'             where  u.APPLICATION_ID = p';
wwv_flow_imp.g_varchar2_table(283) := '_app_id and '||wwv_flow.LF||
'                    u.user_name_lc = t.email),'||wwv_flow.LF||
'             ''No Access'') != nvl(t.APP_R';
wwv_flow_imp.g_varchar2_table(284) := 'OLE,''Unknown'')'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            update sp_team_members'||wwv_flow.LF||
'            set app_role = c1.app_r';
wwv_flow_imp.g_varchar2_table(285) := 'ole'||wwv_flow.LF||
'            where id = c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end sync_team_members_app_role;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure sync_team';
wwv_flow_imp.g_varchar2_table(286) := '_member_app_role ('||wwv_flow.LF||
'    p_app_id in number,'||wwv_flow.LF||
'    p_email  in varchar2)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(287) := '  select '||wwv_flow.LF||
'           t.id,'||wwv_flow.LF||
'           t.first_name,'||wwv_flow.LF||
'           t.last_name,'||wwv_flow.LF||
'           t.email,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(288) := '       nvl(t.APP_ROLE,''Unknown'') current_app_role,'||wwv_flow.LF||
'           nvl(('||wwv_flow.LF||
'            select'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(289) := '       decode(instr(role_names,''Administrator''),0,'||wwv_flow.LF||
'                    decode(instr(role_names,''Cont';
wwv_flow_imp.g_varchar2_table(290) := 'ributor''),0,'||wwv_flow.LF||
'                    decode(instr(role_names,''Reader''),0,''No Access'',''Reader''),'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(291) := '            ''Contributor''),'||wwv_flow.LF||
'                    ''Administrator'') role_names'||wwv_flow.LF||
'             from   APEX';
wwv_flow_imp.g_varchar2_table(292) := '_APPL_ACL_USERS u '||wwv_flow.LF||
'             where  u.APPLICATION_ID = p_app_id and '||wwv_flow.LF||
'                    u.user_n';
wwv_flow_imp.g_varchar2_table(293) := 'ame_lc = t.email'||wwv_flow.LF||
'             ),'||wwv_flow.LF||
'             ''No Access'') app_role'||wwv_flow.LF||
'        from sp_team_members t'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(294) := '       where nvl(('||wwv_flow.LF||
'            select'||wwv_flow.LF||
'                    decode(instr(role_names,''Administrator''),0';
wwv_flow_imp.g_varchar2_table(295) := ','||wwv_flow.LF||
'                    decode(instr(role_names,''Contributor''),0,'||wwv_flow.LF||
'                    decode(instr(rol';
wwv_flow_imp.g_varchar2_table(296) := 'e_names,''Reader''),0,''No Access'',''Reader''),'||wwv_flow.LF||
'                    ''Contributor''),'||wwv_flow.LF||
'                    ''';
wwv_flow_imp.g_varchar2_table(297) := 'Administrator'') role_names'||wwv_flow.LF||
'             from   APEX_APPL_ACL_USERS u '||wwv_flow.LF||
'             where  u.APPLICAT';
wwv_flow_imp.g_varchar2_table(298) := 'ION_ID = p_app_id and USER_NAME_LC = lower(p_email)),'||wwv_flow.LF||
'             ''No Access'') != nvl(t.APP_ROLE,''U';
wwv_flow_imp.g_varchar2_table(299) := 'nknown'')'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            update sp_team_members'||wwv_flow.LF||
'            set app_role = c1.app_role'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(300) := '          where id = c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end sync_team_member_app_role;'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------'||wwv_flow.LF||
'-- Tags'||wwv_flow.LF||
'--'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(301) := 'procedure add_default_tag ('||wwv_flow.LF||
'    p_tag        in varchar2,'||wwv_flow.LF||
'    p_sequence   in number default null)'||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(302) := 's '||wwv_flow.LF||
'    l_seq number := p_sequence;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if l_seq is null then '||wwv_flow.LF||
'        for c1 in (select max(DI';
wwv_flow_imp.g_varchar2_table(303) := 'SPLAY_SEQUENCE) mds from SP_DEFAULT_TAGS) loop'||wwv_flow.LF||
'            l_seq := c1.mds + 10;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(304) := '   end if;'||wwv_flow.LF||
'    insert into SP_DEFAULT_TAGS (DISPLAY_SEQUENCE, tag) values (l_seq, upper(p_tag));'||wwv_flow.LF||
'end';
wwv_flow_imp.g_varchar2_table(305) := ' add_default_tag;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure get_default_tags ('||wwv_flow.LF||
'    p_tag_1      out varchar2,'||wwv_flow.LF||
'    p_tag_2      out ';
wwv_flow_imp.g_varchar2_table(306) := 'varchar2,'||wwv_flow.LF||
'    p_tag_3      out varchar2,'||wwv_flow.LF||
'    p_tag_4      out varchar2,'||wwv_flow.LF||
'    p_tag_5      out varchar';
wwv_flow_imp.g_varchar2_table(307) := '2,'||wwv_flow.LF||
'    p_tag_6      out varchar2)'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    c int := 0;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    p_tag_1 := null;'||wwv_flow.LF||
'    p_tag_2 := null;';
wwv_flow_imp.g_varchar2_table(308) := ''||wwv_flow.LF||
'    p_tag_3 := null;'||wwv_flow.LF||
'    p_tag_4 := null;'||wwv_flow.LF||
'    p_tag_5 := null;'||wwv_flow.LF||
'    p_tag_6 := null;'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ';
wwv_flow_imp.g_varchar2_table(309) := '(select tag from SP_DEFAULT_TAGS order by display_sequence, tag) loop'||wwv_flow.LF||
'        c := c + 1;'||wwv_flow.LF||
'        if';
wwv_flow_imp.g_varchar2_table(310) := '    c = 1 then p_tag_1 := c1.tag;'||wwv_flow.LF||
'        elsif c = 2 then p_tag_2 := c1.tag;'||wwv_flow.LF||
'        elsif c = 3 th';
wwv_flow_imp.g_varchar2_table(311) := 'en p_tag_3 := c1.tag;'||wwv_flow.LF||
'        elsif c = 4 then p_tag_4 := c1.tag;'||wwv_flow.LF||
'        elsif c = 5 then p_tag_5 :';
wwv_flow_imp.g_varchar2_table(312) := '= c1.tag;'||wwv_flow.LF||
'        elsif c = 6 then p_tag_6 := c1.tag;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end get_default_';
wwv_flow_imp.g_varchar2_table(313) := 'tags;'||wwv_flow.LF||
''||wwv_flow.LF||
'function prepare_tags ('||wwv_flow.LF||
'    p_tags in varchar2)'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_tags  varchar2(';
wwv_flow_imp.g_varchar2_table(314) := '4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- remove whitespace, have leading and trailing commas to facilitate instr'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(315) := '    l_tags := trim(upper(p_tags));'||wwv_flow.LF||
'    l_tags := '',''||l_tags||'','';'||wwv_flow.LF||
'    l_tags := replace(l_tags,chr(';
wwv_flow_imp.g_varchar2_table(316) := '9),'' '');'||wwv_flow.LF||
'    for i in 1..5 loop '||wwv_flow.LF||
'        l_tags := replace(l_tags,'', '','',''); '||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    l_ta';
wwv_flow_imp.g_varchar2_table(317) := 'gs := replace(l_tags,'',,'','','');'||wwv_flow.LF||
'    return l_tags;'||wwv_flow.LF||
'end prepare_tags;'||wwv_flow.LF||
''||wwv_flow.LF||
'function reformat_tags ('||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(318) := '_tags in varchar2) '||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_tags varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- call thi';
wwv_flow_imp.g_varchar2_table(319) := 's after calling prepare tags to reformat to friendly format'||wwv_flow.LF||
'    l_tags := ltrim(p_tags,'','');'||wwv_flow.LF||
'    l_t';
wwv_flow_imp.g_varchar2_table(320) := 'ags := rtrim(l_tags,'','');'||wwv_flow.LF||
'    l_tags := replace(l_tags,'','','', '');'||wwv_flow.LF||
'    return l_tags;'||wwv_flow.LF||
'end reformat_ta';
wwv_flow_imp.g_varchar2_table(321) := 'gs;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function count_project_tags ('||wwv_flow.LF||
'    p_project_id in number)'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_tag_coun';
wwv_flow_imp.g_varchar2_table(322) := 't number := 0;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    for c1 in (select tags from sp_projects where id = p_project_id and tags i';
wwv_flow_imp.g_varchar2_table(323) := 's not null) loop'||wwv_flow.LF||
'       l_tag_count := 1 + length(c1.tags) - length(replace(c1.tags,'','',null));'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(324) := 'end loop;'||wwv_flow.LF||
'    return l_tag_count;'||wwv_flow.LF||
'end count_project_tags;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_project_id ('||wwv_flow.LF||
'    p_friendly';
wwv_flow_imp.g_varchar2_table(325) := '_identifier in varchar2,'||wwv_flow.LF||
'    p_project_url_name    in varchar2)'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_id number';
wwv_flow_imp.g_varchar2_table(326) := ' := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if p_friendly_identifier is not null then'||wwv_flow.LF||
'       for c1 in (select id from sp_pr';
wwv_flow_imp.g_varchar2_table(327) := 'ojects where FRIENDLY_IDENTIFIER = p_friendly_identifier) loop'||wwv_flow.LF||
'            l_id := c1.id;'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(328) := '  exit;'||wwv_flow.LF||
'       end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if l_id is null and p_project_url_name is not null then '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(329) := '     for c1 in (select id from sp_projects where PROJECT_URL_NAME = p_project_url_name) loop'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(330) := '     l_id := c1.id;'||wwv_flow.LF||
'            exit;'||wwv_flow.LF||
'       end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    return l_id;'||wwv_flow.LF||
'end get_project_';
wwv_flow_imp.g_varchar2_table(331) := 'id;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_initiative_id ('||wwv_flow.LF||
'    p_friendly_identifier    in varchar2,'||wwv_flow.LF||
'    p_initiative_url_na';
wwv_flow_imp.g_varchar2_table(332) := 'me    in varchar2)'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_id number := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if p_friendly_identifier ';
wwv_flow_imp.g_varchar2_table(333) := 'is not null then'||wwv_flow.LF||
'       for c1 in (select id from sp_initiatives where FRIENDLY_IDENTIFIER = p_frien';
wwv_flow_imp.g_varchar2_table(334) := 'dly_identifier) loop'||wwv_flow.LF||
'            l_id := c1.id;'||wwv_flow.LF||
'            exit;'||wwv_flow.LF||
'       end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(335) := 'f l_id is null and p_initiative_url_name is not null then '||wwv_flow.LF||
'       for c1 in (select id from sp_initi';
wwv_flow_imp.g_varchar2_table(336) := 'atives where INITIATIVE_URL_NAME = p_initiative_url_name) loop'||wwv_flow.LF||
'            l_id := c1.id;'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(337) := '  exit;'||wwv_flow.LF||
'       end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    return l_id;'||wwv_flow.LF||
'end get_initiative_id;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'--------------------'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(338) := '-- Utility Functions'||wwv_flow.LF||
'--'||wwv_flow.LF||
''||wwv_flow.LF||
'function compress_int (n in integer ) return varchar2'||wwv_flow.LF||
'as'||wwv_flow.LF||
'   ret       varch';
wwv_flow_imp.g_varchar2_table(339) := 'ar2(30);'||wwv_flow.LF||
'   quotient  integer;'||wwv_flow.LF||
'   remainder integer;'||wwv_flow.LF||
'   digit     char(1);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   ret := null; quo';
wwv_flow_imp.g_varchar2_table(340) := 'tient := n;'||wwv_flow.LF||
'   while quotient > 0'||wwv_flow.LF||
'   loop'||wwv_flow.LF||
'       remainder := mod(quotient, 10 + 26);'||wwv_flow.LF||
'       quotien';
wwv_flow_imp.g_varchar2_table(341) := 't := floor(quotient  / (10 + 26));'||wwv_flow.LF||
'       if remainder < 26 then'||wwv_flow.LF||
'           digit := chr(ascii(''A'') ';
wwv_flow_imp.g_varchar2_table(342) := '+ remainder);'||wwv_flow.LF||
'       else'||wwv_flow.LF||
'           digit := chr(ascii(''0'') + remainder - 26);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(343) := '  ret := digit || ret;'||wwv_flow.LF||
'   end loop ;'||wwv_flow.LF||
'   if length(ret) < 5 then ret := lpad(ret, 4, ''A''); end if ;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(344) := '  return upper(ret);'||wwv_flow.LF||
'end compress_int;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- mostly used in comments but could be helpful elsewhere'||wwv_flow.LF||
'f';
wwv_flow_imp.g_varchar2_table(345) := 'unction find_mentions ('||wwv_flow.LF||
'    p_clob in clob )'||wwv_flow.LF||
'    return varchar2 '||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_clob               clob;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(346) := '    l_mention_list       varchar2(4000) := null;'||wwv_flow.LF||
'    l_pos                integer := 1;'||wwv_flow.LF||
'    l_match ';
wwv_flow_imp.g_varchar2_table(347) := '             varchar2(320);'||wwv_flow.LF||
'    l_clob_length        integer;'||wwv_flow.LF||
'    l_screen_name_exists boolean := fa';
wwv_flow_imp.g_varchar2_table(348) := 'lse;'||wwv_flow.LF||
'    l_user_id            number;'||wwv_flow.LF||
'    l_loop_count         integer := 0;'||wwv_flow.LF||
'    l_max_loops        ';
wwv_flow_imp.g_varchar2_table(349) := '  integer := 100;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- remove characters considered trailing white space'||wwv_flow.LF||
'    l_clob := repla';
wwv_flow_imp.g_varchar2_table(350) := 'ce(p_clob, ''+'', '' ''); -- remove all plus'||wwv_flow.LF||
'    l_clob := replace(l_clob, ''.'', '' ''); -- remove all dots';
wwv_flow_imp.g_varchar2_table(351) := ''||wwv_flow.LF||
'    l_clob := replace(l_clob, '','', '' ''); -- remove all commas'||wwv_flow.LF||
'    l_clob := replace(l_clob, ''@'', '' ';
wwv_flow_imp.g_varchar2_table(352) := '@''); -- prefix at sign with white space'||wwv_flow.LF||
'    -- Get the length of the input CLOB'||wwv_flow.LF||
'    l_clob_length :=';
wwv_flow_imp.g_varchar2_table(353) := ' DBMS_LOB.GETLENGTH(l_clob);'||wwv_flow.LF||
'    -- Loop through the CLOB to extract mentions using regex'||wwv_flow.LF||
'    WHILE ';
wwv_flow_imp.g_varchar2_table(354) := 'l_pos <= l_clob_length loop'||wwv_flow.LF||
'        if l_loop_count > l_max_loops then'||wwv_flow.LF||
'            exit; -- prevent ';
wwv_flow_imp.g_varchar2_table(355) := 'infinite loop'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        l_match := null;'||wwv_flow.LF||
'        l_match := REGEXP_SUBSTR(l_clob,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(356) := '                             ''@\S+'',  -- Match "@" followed by non-whitespace characters'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(357) := '                      l_pos, 1);'||wwv_flow.LF||
'        EXIT WHEN l_match IS NULL;'||wwv_flow.LF||
'        -- clean l_match'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(358) := ' l_match := lower(trim(l_match));'||wwv_flow.LF||
'        l_match := ltrim(l_match,''@''); -- remove leading at signs'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(359) := '        l_match := rtrim(l_match,''.,;:"''''\/-|!#$%^&*()[]'');'||wwv_flow.LF||
'        -- locate screen name in team me';
wwv_flow_imp.g_varchar2_table(360) := 'mbers table'||wwv_flow.LF||
'        l_screen_name_exists := false;'||wwv_flow.LF||
'        -- see if screen name exists in database,';
wwv_flow_imp.g_varchar2_table(361) := ' note stored as lower case'||wwv_flow.LF||
'        for c1 in (select id from sp_team_members tm where tm.screen_name';
wwv_flow_imp.g_varchar2_table(362) := ' = l_match) loop'||wwv_flow.LF||
'            l_screen_name_exists := true;'||wwv_flow.LF||
'            exit;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(363) := '   -- see if name already exists in string, e.g. avoid returning duplicate names'||wwv_flow.LF||
'        if l_screen';
wwv_flow_imp.g_varchar2_table(364) := '_name_exists and'||wwv_flow.LF||
'           instr('':''||l_mention_list||'':'','':''||l_match||'':'') > 0 then'||wwv_flow.LF||
'           l_';
wwv_flow_imp.g_varchar2_table(365) := 'screen_name_exists := false;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- Append to the mention list'||wwv_flow.LF||
'        if l_scre';
wwv_flow_imp.g_varchar2_table(366) := 'en_name_exists then'||wwv_flow.LF||
'            if l_mention_list is not null then'||wwv_flow.LF||
'                l_mention_list :=';
wwv_flow_imp.g_varchar2_table(367) := ' l_mention_list || '':'' || l_match;'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'                l_mention_list := l_match;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(368) := '       end if;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- Move position forward to continue searching'||wwv_flow.LF||
'        l_pos ';
wwv_flow_imp.g_varchar2_table(369) := ':= INSTR(l_clob, l_match, l_pos) + LENGTH(l_match);'||wwv_flow.LF||
'        l_loop_count := l_loop_count + 1;'||wwv_flow.LF||
'    en';
wwv_flow_imp.g_varchar2_table(370) := 'd loop;'||wwv_flow.LF||
'    return l_mention_list;'||wwv_flow.LF||
'end find_mentions;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function list_change ('||wwv_flow.LF||
'    p_old_list   in v';
wwv_flow_imp.g_varchar2_table(371) := 'archar2 default null, '||wwv_flow.LF||
'    p_new_list   in varchar2 default null, '||wwv_flow.LF||
'    p_delim      in varchar2 defa';
wwv_flow_imp.g_varchar2_table(372) := 'ult '','')'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'as'||wwv_flow.LF||
'    l_old_array           apex_t_varchar2;'||wwv_flow.LF||
'    l_new_array          ';
wwv_flow_imp.g_varchar2_table(373) := ' apex_t_varchar2;'||wwv_flow.LF||
'    l_added               varchar2(4000) := null;'||wwv_flow.LF||
'    l_removed             varcha';
wwv_flow_imp.g_varchar2_table(374) := 'r2(4000) := null;'||wwv_flow.LF||
'    l_found               boolean := false;'||wwv_flow.LF||
'    l_action              varchar2(327';
wwv_flow_imp.g_varchar2_table(375) := '67) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- determine list changes including nulls'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if p_old_list is ';
wwv_flow_imp.g_varchar2_table(376) := 'null and p_new_list is null then'||wwv_flow.LF||
'        l_action := ''No Values'';'||wwv_flow.LF||
'    elsif p_old_list is not null a';
wwv_flow_imp.g_varchar2_table(377) := 'nd p_new_list is null then '||wwv_flow.LF||
'        l_removed := p_old_list;'||wwv_flow.LF||
'        l_action := ''All values removed';
wwv_flow_imp.g_varchar2_table(378) := ''';'||wwv_flow.LF||
'    elsif p_old_list is null and p_new_list is not null then '||wwv_flow.LF||
'        l_added := ''"''||p_new_list|';
wwv_flow_imp.g_varchar2_table(379) := '|''"'';'||wwv_flow.LF||
'        l_action := ''First values added'';'||wwv_flow.LF||
'    elsif p_old_list = p_new_list then'||wwv_flow.LF||
'        l_act';
wwv_flow_imp.g_varchar2_table(380) := 'ion := ''No change'';'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        l_action := ''Values changed'';'||wwv_flow.LF||
'       l_old_array := apex_string';
wwv_flow_imp.g_varchar2_table(381) := '.split(p_str => p_old_list, p_sep => nvl(p_delim,'',''));'||wwv_flow.LF||
'       l_new_array := apex_string.split(p_st';
wwv_flow_imp.g_varchar2_table(382) := 'r => p_new_list, p_sep => nvl(p_delim,'',''));'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- added'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       for i in 1..';
wwv_flow_imp.g_varchar2_table(383) := 'l_new_array.count loop '||wwv_flow.LF||
'           l_found := false;'||wwv_flow.LF||
'           for j in 1..l_old_array.count loop'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(384) := '               if trim(l_new_array(i)) = trim(l_old_array(j)) then '||wwv_flow.LF||
'                   l_found := tr';
wwv_flow_imp.g_varchar2_table(385) := 'ue;'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'           end loop;'||wwv_flow.LF||
'           if not l_found ';
wwv_flow_imp.g_varchar2_table(386) := 'then '||wwv_flow.LF||
'               l_added := l_added||''"''||trim(l_new_array(i))||''", '';'||wwv_flow.LF||
'           end if;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(387) := ' end loop;'||wwv_flow.LF||
'       l_added := rtrim(l_added,'', '');'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- removed'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       for i';
wwv_flow_imp.g_varchar2_table(388) := ' in 1..l_old_array.count loop '||wwv_flow.LF||
'           l_found := false;'||wwv_flow.LF||
'           for j in 1..l_new_array.count';
wwv_flow_imp.g_varchar2_table(389) := ' loop'||wwv_flow.LF||
'                if trim(l_old_array(i)) = trim(l_new_array(j)) then '||wwv_flow.LF||
'                   l_foun';
wwv_flow_imp.g_varchar2_table(390) := 'd := true;'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'           end loop;'||wwv_flow.LF||
'           if not l';
wwv_flow_imp.g_varchar2_table(391) := '_found then '||wwv_flow.LF||
'               l_removed := l_removed||''"''||trim(l_old_array(i))||''", '';'||wwv_flow.LF||
'           end';
wwv_flow_imp.g_varchar2_table(392) := ' if;'||wwv_flow.LF||
'       end loop;'||wwv_flow.LF||
'       l_removed := rtrim(l_removed,'', '');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if l_added is not n';
wwv_flow_imp.g_varchar2_table(393) := 'ull and l_removed is null then'||wwv_flow.LF||
'       l_action := ''added ''||trim(l_added);'||wwv_flow.LF||
'    elsif l_added is null';
wwv_flow_imp.g_varchar2_table(394) := ' and l_removed is not null then '||wwv_flow.LF||
'       l_action := ''removed ''||trim(l_removed);'||wwv_flow.LF||
'    elsif l_added i';
wwv_flow_imp.g_varchar2_table(395) := 's not null and l_added is not null then '||wwv_flow.LF||
'       l_action := ''added ''||trim(l_added)||'' and removed ''';
wwv_flow_imp.g_varchar2_table(396) := '||trim(l_removed);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    return l_action;'||wwv_flow.LF||
'end list_change;'||wwv_flow.LF||
''||wwv_flow.LF||
'--------------------'||wwv_flow.LF||
'-- for No';
wwv_flow_imp.g_varchar2_table(397) := 'tification Subscriptions'||wwv_flow.LF||
'--'||wwv_flow.LF||
'procedure send_notif_subscriptions'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_app_id         varchar2(30);';
wwv_flow_imp.g_varchar2_table(398) := ''||wwv_flow.LF||
'    l_app_url        varchar2(4000);'||wwv_flow.LF||
'    l_app_name       varchar2(4000);'||wwv_flow.LF||
'    l_opt_out_url    varc';
wwv_flow_imp.g_varchar2_table(399) := 'har2(4000);'||wwv_flow.LF||
'    l_gen_date       varchar2(30);'||wwv_flow.LF||
'    l_summary        clob;'||wwv_flow.LF||
'    l_day            varch';
wwv_flow_imp.g_varchar2_table(400) := 'ar2(3) := to_char(sysdate,''DY'');'||wwv_flow.LF||
'    l_sysdate        date        := sysdate;'||wwv_flow.LF||
'    l_tsysdate       d';
wwv_flow_imp.g_varchar2_table(401) := 'ate        := trunc(sysdate);'||wwv_flow.LF||
'    l_project_label  varchar2(255);'||wwv_flow.LF||
'    l_changes_yn     varchar2(1);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(402) := 'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- need to fetch app_id because this is being run by a db job so has no knowledge of the ';
wwv_flow_imp.g_varchar2_table(403) := 'app'||wwv_flow.LF||
'    l_app_id := get_setting(p_static_id => ''APP_ID'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- the app_id is used to get the work';
wwv_flow_imp.g_varchar2_table(404) := 'space, workspace must be set in order to use other apex apis (like apex_mail.send - without sgid, em';
wwv_flow_imp.g_varchar2_table(405) := 'ail template will not be found)'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select workspace_id'||wwv_flow.LF||
'         from apex_appli';
wwv_flow_imp.g_varchar2_table(406) := 'cations'||wwv_flow.LF||
'        where application_id = l_app_id '||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        apex_util.set_security_group_id(';
wwv_flow_imp.g_varchar2_table(407) := 'p_security_group_id => c1.workspace_id);'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- if build not not enabled, nothing wil';
wwv_flow_imp.g_varchar2_table(408) := 'l be run (careful to not update the build option name in the UI without editing this)'||wwv_flow.LF||
'    if apex_ut';
wwv_flow_imp.g_varchar2_table(409) := 'il.get_build_option_status('||wwv_flow.LF||
'           p_application_id    => l_app_id, '||wwv_flow.LF||
'           p_build_option_n';
wwv_flow_imp.g_varchar2_table(410) := 'ame => ''Subscriptions'') = ''INCLUDE'' and'||wwv_flow.LF||
'       apex_util.get_build_option_status ('||wwv_flow.LF||
'           p_appl';
wwv_flow_imp.g_varchar2_table(411) := 'ication_id    => l_app_id,'||wwv_flow.LF||
'           p_build_option_name => ''Email Configured'') = ''INCLUDE'''||wwv_flow.LF||
'    the';
wwv_flow_imp.g_varchar2_table(412) := 'n'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_app_url       := get_setting(p_static_id => ''APP_HOME_URL'');'||wwv_flow.LF||
'        l_project_label :=';
wwv_flow_imp.g_varchar2_table(413) := ' get_nomenclature(''PROJECT'');'||wwv_flow.LF||
'        l_app_name      := get_nomenclature(''STRATEGIC_PLANNER'');'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(414) := '    l_gen_date      := to_char(l_sysdate,''DD-Mon-YYYY'');'||wwv_flow.LF||
'        l_opt_out_url   := get_setting(p_st';
wwv_flow_imp.g_varchar2_table(415) := 'atic_id => ''APP_PREFIX_URL'')||'||wwv_flow.LF||
'                               apex_page.get_url('||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(416) := '                p_application => l_app_id,'||wwv_flow.LF||
'                                   p_page        => 139,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(417) := '                                   p_session     => null,'||wwv_flow.LF||
'                                   p_plain';
wwv_flow_imp.g_varchar2_table(418) := '_url   => TRUE );'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- WEEKLY_SUMMARY'||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            select tm.id team_membe';
wwv_flow_imp.g_varchar2_table(419) := 'r_id, '||wwv_flow.LF||
'                   tm.email, '||wwv_flow.LF||
'                   s.id subscription_id'||wwv_flow.LF||
'              from sp_t';
wwv_flow_imp.g_varchar2_table(420) := 'eam_members tm,'||wwv_flow.LF||
'                   sp_notification_subscriptions s,'||wwv_flow.LF||
'                   sp_notificati';
wwv_flow_imp.g_varchar2_table(421) := 'ons n'||wwv_flow.LF||
'             where tm.id = s.team_member_id'||wwv_flow.LF||
'               and s.notification_id = n.id'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(422) := '         and n.static_id = ''WEEKLY_SUMMARY'''||wwv_flow.LF||
'               and n.is_active_yn = ''Y'''||wwv_flow.LF||
'               a';
wwv_flow_imp.g_varchar2_table(423) := 'nd s.opted_in_yn = ''Y'''||wwv_flow.LF||
'               and ( (s.frequency = ''WEEKDAYS'' and '||wwv_flow.LF||
'                      l_d';
wwv_flow_imp.g_varchar2_table(424) := 'ay in (''MON'',''TUES'',''WED'',''THU'',''FRI'') and'||wwv_flow.LF||
'                      (s.last_sent < l_sysdate - 1/2 or s';
wwv_flow_imp.g_varchar2_table(425) := '.last_sent is null) )'||wwv_flow.LF||
'                     or'||wwv_flow.LF||
'                     (s.frequency = ''WEEKLY'' and '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(426) := '                  l_day = ''MON'' and'||wwv_flow.LF||
'                      (s.last_sent < l_sysdate - 6 or s.last_sen';
wwv_flow_imp.g_varchar2_table(427) := 't is null) ) )'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'            l_summary := sp_contributor_summary.generate ('||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(428) := '                   p_team_member_id  => c1.team_member_id,'||wwv_flow.LF||
'                             p_show_activ';
wwv_flow_imp.g_varchar2_table(429) := 'ities => ''Y'','||wwv_flow.LF||
'                             p_show_projects   => ''Y'','||wwv_flow.LF||
'                             p_';
wwv_flow_imp.g_varchar2_table(430) := 'links           => ''JOB'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'            apex_mail.send ( '||wwv_flow.LF||
'                p_to                 => c';
wwv_flow_imp.g_varchar2_table(431) := '1.email,   '||wwv_flow.LF||
'                p_from               => c1.email,  '||wwv_flow.LF||
'                p_application_id    ';
wwv_flow_imp.g_varchar2_table(432) := ' => l_app_id,  '||wwv_flow.LF||
'                p_template_static_id => ''NOTIF_SUBSCRIPTIONS_JOB'',  '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(433) := ' p_placeholders       => ''{'' || ''"APPLICATION_LINK": "'' || l_app_url ||''", ''|| '||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(434) := '                           ''"OPT_OUT_URL": "''      || l_opt_out_url ||''", ''||'||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(435) := '                         ''"APP_NAME": ''          || apex_json.stringify( l_app_name ) ||'', ''||'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(436) := '                                          ''"SUBJECT": ''           || apex_json.stringify( l_app_name';
wwv_flow_imp.g_varchar2_table(437) := '||'' Weekly Summary - ''||to_char(l_sysdate,''Month DD, YYYY'' ) )||'', ''||'||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(438) := '                  ''"SUMMARY": ''           || apex_json.stringify( l_summary ) ||'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(439) := '                      ''}'' ); '||wwv_flow.LF||
''||wwv_flow.LF||
'            -- this allows job to be restarted without duplicate emai';
wwv_flow_imp.g_varchar2_table(440) := 'ls going out'||wwv_flow.LF||
'            -- this marks that an email was queued to be sent, but the sending could ul';
wwv_flow_imp.g_varchar2_table(441) := 'timately fail'||wwv_flow.LF||
'            update sp_notification_subscriptions'||wwv_flow.LF||
'               set last_sent = sysdat';
wwv_flow_imp.g_varchar2_table(442) := 'e'||wwv_flow.LF||
'             where id = c1.subscription_id;'||wwv_flow.LF||
'        end loop; '||wwv_flow.LF||
''||wwv_flow.LF||
'        -- PROJECT_EXCEPTIONS'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(443) := '    for c1 in ('||wwv_flow.LF||
'            select tm.id team_member_id, '||wwv_flow.LF||
'                   tm.email, '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(444) := '       s.id subscription_id'||wwv_flow.LF||
'              from sp_team_members tm,'||wwv_flow.LF||
'                   sp_notificatio';
wwv_flow_imp.g_varchar2_table(445) := 'n_subscriptions s,'||wwv_flow.LF||
'                   sp_notifications n'||wwv_flow.LF||
'             where tm.id = s.team_member_id';
wwv_flow_imp.g_varchar2_table(446) := ''||wwv_flow.LF||
'               and s.notification_id = n.id'||wwv_flow.LF||
'               and n.static_id = ''PROJECT_EXCEPTIONS'''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(447) := '              and n.is_active_yn = ''Y'''||wwv_flow.LF||
'               and s.opted_in_yn = ''Y'''||wwv_flow.LF||
'               and ( (';
wwv_flow_imp.g_varchar2_table(448) := 's.frequency = ''WEEKDAYS'' and '||wwv_flow.LF||
'                      l_day in (''MON'',''TUES'',''WED'',''THU'',''FRI'') and'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(449) := '                    (s.last_sent < l_sysdate - 1/2 or s.last_sent is null) )'||wwv_flow.LF||
'                     or';
wwv_flow_imp.g_varchar2_table(450) := ''||wwv_flow.LF||
'                     (s.frequency = ''WEEKLY'' and '||wwv_flow.LF||
'                      l_day = ''MON'' and'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(451) := '             (s.last_sent < l_sysdate - 6 or s.last_sent is null) ) )'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'            l_';
wwv_flow_imp.g_varchar2_table(452) := 'summary := sp_contributor_summary.project_exceptions ('||wwv_flow.LF||
'                             p_team_member_id';
wwv_flow_imp.g_varchar2_table(453) := '  => c1.team_member_id,'||wwv_flow.LF||
'                             p_links           => ''JOB'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'            apex';
wwv_flow_imp.g_varchar2_table(454) := '_mail.send ( '||wwv_flow.LF||
'                p_to                 => c1.email,   '||wwv_flow.LF||
'                p_from           ';
wwv_flow_imp.g_varchar2_table(455) := '    => c1.email,  '||wwv_flow.LF||
'                p_application_id     => l_app_id,  '||wwv_flow.LF||
'                p_template_st';
wwv_flow_imp.g_varchar2_table(456) := 'atic_id => ''NOTIF_SUBSCRIPTIONS_JOB'',  '||wwv_flow.LF||
'                p_placeholders       => ''{'' || ''"APPLICATION';
wwv_flow_imp.g_varchar2_table(457) := '_LINK": "'' || l_app_url ||''", ''|| '||wwv_flow.LF||
'                                               ''"OPT_OUT_URL": "''';
wwv_flow_imp.g_varchar2_table(458) := '      || l_opt_out_url ||''", ''||'||wwv_flow.LF||
'                                               ''"APP_NAME": ''      ';
wwv_flow_imp.g_varchar2_table(459) := '    || apex_json.stringify( l_app_name ) ||'', ''||'||wwv_flow.LF||
'                                               ''"S';
wwv_flow_imp.g_varchar2_table(460) := 'UBJECT": ''           || apex_json.stringify( l_app_name||'' ''||l_project_label||'' Exceptions - ''||to_';
wwv_flow_imp.g_varchar2_table(461) := 'char(l_sysdate,''Month DD, YYYY'' ) )||'', ''||'||wwv_flow.LF||
'                                               ''"SUMMARY';
wwv_flow_imp.g_varchar2_table(462) := '": ''           || apex_json.stringify( l_summary ) ||'||wwv_flow.LF||
'                                         ''}'' )';
wwv_flow_imp.g_varchar2_table(463) := '; '||wwv_flow.LF||
''||wwv_flow.LF||
'            -- this allows job to be restarted without duplicate emails going out'||wwv_flow.LF||
'            --';
wwv_flow_imp.g_varchar2_table(464) := ' this marks that an email was queued to be sent, but the sending could ultimately fail'||wwv_flow.LF||
'            u';
wwv_flow_imp.g_varchar2_table(465) := 'pdate sp_notification_subscriptions'||wwv_flow.LF||
'               set last_sent = sysdate'||wwv_flow.LF||
'             where id = c';
wwv_flow_imp.g_varchar2_table(466) := '1.subscription_id;'||wwv_flow.LF||
'        end loop; '||wwv_flow.LF||
''||wwv_flow.LF||
'        -- RELEASE_EXCEPTIONS'||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(467) := ' select tm.id team_member_id, '||wwv_flow.LF||
'                   tm.email, '||wwv_flow.LF||
'                   s.id subscription_id';
wwv_flow_imp.g_varchar2_table(468) := ','||wwv_flow.LF||
'                   r.release_train||'' ''||r.release release,'||wwv_flow.LF||
'                   r.id release_id'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(469) := '           from sp_team_members tm,'||wwv_flow.LF||
'                   sp_notification_subscriptions s,'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(470) := '       sp_notifications n,'||wwv_flow.LF||
'                   sp_release_trains r'||wwv_flow.LF||
'             where tm.id = s.team_';
wwv_flow_imp.g_varchar2_table(471) := 'member_id'||wwv_flow.LF||
'               and s.notification_id = n.id'||wwv_flow.LF||
'               and n.static_id = ''RELEASE_EXCE';
wwv_flow_imp.g_varchar2_table(472) := 'PTIONS'''||wwv_flow.LF||
'               and n.is_active_yn = ''Y'''||wwv_flow.LF||
'               and s.release_id = r.id'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(473) := '  and nvl(r.release_completed,''N'') != ''Y'''||wwv_flow.LF||
'               and s.opted_in_yn = ''Y'''||wwv_flow.LF||
'               and ';
wwv_flow_imp.g_varchar2_table(474) := '( (s.frequency = ''WEEKDAYS'' and '||wwv_flow.LF||
'                      l_day in (''MON'',''TUES'',''WED'',''THU'',''FRI'') and';
wwv_flow_imp.g_varchar2_table(475) := ''||wwv_flow.LF||
'                      (s.last_sent < l_sysdate - 1/2 or s.last_sent is null) )'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(476) := ' or'||wwv_flow.LF||
'                     (s.frequency = ''WEEKLY'' and '||wwv_flow.LF||
'                      l_day = ''MON'' and'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(477) := '                (s.last_sent < l_sysdate - 6 or s.last_sent is null) ) )'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(478) := ' l_summary := sp_release_timeline.release_exceptions ('||wwv_flow.LF||
'                             p_release_id => ';
wwv_flow_imp.g_varchar2_table(479) := 'c1.release_id,'||wwv_flow.LF||
'                             p_links      => ''JOB'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'            apex_mail.send ( '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(480) := '                p_to                 => c1.email,   '||wwv_flow.LF||
'                p_from               => c1.emai';
wwv_flow_imp.g_varchar2_table(481) := 'l,  '||wwv_flow.LF||
'                p_application_id     => l_app_id,  '||wwv_flow.LF||
'                p_template_static_id => ''NO';
wwv_flow_imp.g_varchar2_table(482) := 'TIF_SUBSCRIPTIONS_JOB'',  '||wwv_flow.LF||
'                p_placeholders       => ''{'' || ''"APPLICATION_LINK": "'' || ';
wwv_flow_imp.g_varchar2_table(483) := 'l_app_url ||''", ''|| '||wwv_flow.LF||
'                                               ''"OPT_OUT_URL": "''      || l_opt';
wwv_flow_imp.g_varchar2_table(484) := '_out_url ||''", ''||'||wwv_flow.LF||
'                                               ''"APP_NAME": ''          || apex_js';
wwv_flow_imp.g_varchar2_table(485) := 'on.stringify( l_app_name ) ||'', ''||'||wwv_flow.LF||
'                                               ''"SUBJECT": ''    ';
wwv_flow_imp.g_varchar2_table(486) := '       || apex_json.stringify( l_app_name||'' ''||c1.release||'' Release Exceptions - ''||to_char(l_sysd';
wwv_flow_imp.g_varchar2_table(487) := 'ate,''Month DD, YYYY'') )||'', ''||'||wwv_flow.LF||
'                                               ''"SUMMARY": ''        ';
wwv_flow_imp.g_varchar2_table(488) := '   || apex_json.stringify( l_summary ) ||'||wwv_flow.LF||
'                                         ''}'' ); '||wwv_flow.LF||
''||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(489) := '    -- this allows job to be restarted without duplicate emails going out'||wwv_flow.LF||
'            -- this marks ';
wwv_flow_imp.g_varchar2_table(490) := 'that an email was queued to be sent, but the sending could ultimately fail'||wwv_flow.LF||
'            update sp_not';
wwv_flow_imp.g_varchar2_table(491) := 'ification_subscriptions'||wwv_flow.LF||
'               set last_sent = sysdate'||wwv_flow.LF||
'             where id = c1.subscripti';
wwv_flow_imp.g_varchar2_table(492) := 'on_id;'||wwv_flow.LF||
'        end loop; '||wwv_flow.LF||
''||wwv_flow.LF||
'        -- PROJECT_CHANGES'||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            select tm.id t';
wwv_flow_imp.g_varchar2_table(493) := 'eam_member_id, '||wwv_flow.LF||
'                   tm.email, '||wwv_flow.LF||
'                   s.id subscription_id,'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(494) := '      s.frequency'||wwv_flow.LF||
'              from sp_team_members tm,'||wwv_flow.LF||
'                   sp_notification_subscrip';
wwv_flow_imp.g_varchar2_table(495) := 'tions s,'||wwv_flow.LF||
'                   sp_notifications n'||wwv_flow.LF||
'             where tm.id = s.team_member_id'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(496) := '      and s.notification_id = n.id'||wwv_flow.LF||
'               and n.static_id = ''PROJECT_CHANGES'''||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(497) := ' and n.is_active_yn = ''Y'''||wwv_flow.LF||
'               and s.opted_in_yn = ''Y'''||wwv_flow.LF||
'               and ( (s.frequency =';
wwv_flow_imp.g_varchar2_table(498) := ' ''WEEKDAYS'' and '||wwv_flow.LF||
'                      l_day in (''MON'',''TUES'',''WED'',''THU'',''FRI'') and'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(499) := '       (s.last_sent < l_sysdate - 1/2 or s.last_sent is null) )'||wwv_flow.LF||
'                     or'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(500) := '         (s.frequency = ''WEEKLY'' and '||wwv_flow.LF||
'                      l_day = ''MON'' and'||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(501) := '(s.last_sent < l_sysdate - 6 or s.last_sent is null) ) )'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'            sp_contributor_';
wwv_flow_imp.g_varchar2_table(502) := 'summary.project_changes ('||wwv_flow.LF||
'                p_team_member_id => c1.team_member_id,'||wwv_flow.LF||
'                p_f';
wwv_flow_imp.g_varchar2_table(503) := 'requency      => c1.frequency,'||wwv_flow.LF||
'                p_links          => ''JOB'','||wwv_flow.LF||
'                p_changes_';
wwv_flow_imp.g_varchar2_table(504) := 'yn     => l_changes_yn,'||wwv_flow.LF||
'                p_change_summary => l_summary );'||wwv_flow.LF||
''||wwv_flow.LF||
'            if l_changes_y';
wwv_flow_imp.g_varchar2_table(505) := 'n = ''Y'' then'||wwv_flow.LF||
''||wwv_flow.LF||
'                apex_mail.send ( '||wwv_flow.LF||
'                    p_to                 => c1.email';
wwv_flow_imp.g_varchar2_table(506) := ',   '||wwv_flow.LF||
'                    p_from               => c1.email,  '||wwv_flow.LF||
'                    p_application_id   ';
wwv_flow_imp.g_varchar2_table(507) := '  => l_app_id,  '||wwv_flow.LF||
'                    p_template_static_id => ''NOTIF_SUBSCRIPTIONS_JOB'',  '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(508) := '          p_placeholders       => ''{'' || ''"APPLICATION_LINK": "'' || l_app_url ||''", ''|| '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(509) := '                                        ''"OPT_OUT_URL": "''      || l_opt_out_url ||''", ''||'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(510) := '                                          ''"APP_NAME": ''          || apex_json.stringify( l_app_name';
wwv_flow_imp.g_varchar2_table(511) := ' ) ||'', ''||'||wwv_flow.LF||
'                                                   ''"SUBJECT": ''           || apex_json.';
wwv_flow_imp.g_varchar2_table(512) := 'stringify( l_app_name||'' ''||l_project_label||'' Changes - ''||to_char(l_sysdate,''Month DD, YYYY'' ) )||';
wwv_flow_imp.g_varchar2_table(513) := ''', ''||'||wwv_flow.LF||
'                                                   ''"SUMMARY": ''           || apex_json.strin';
wwv_flow_imp.g_varchar2_table(514) := 'gify( l_summary ) ||'||wwv_flow.LF||
'                                             ''}'' ); '||wwv_flow.LF||
''||wwv_flow.LF||
'                -- this a';
wwv_flow_imp.g_varchar2_table(515) := 'llows job to be restarted without duplicate emails going out'||wwv_flow.LF||
'                -- this marks that an e';
wwv_flow_imp.g_varchar2_table(516) := 'mail was queued to be sent, but the sending could ultimately fail'||wwv_flow.LF||
'                update sp_notifica';
wwv_flow_imp.g_varchar2_table(517) := 'tion_subscriptions'||wwv_flow.LF||
'                   set last_sent = sysdate'||wwv_flow.LF||
'                 where id = c1.subscri';
wwv_flow_imp.g_varchar2_table(518) := 'ption_id;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end loop; '||wwv_flow.LF||
''||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'end send_notif_subscriptions;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'proce';
wwv_flow_imp.g_varchar2_table(519) := 'dure assignment_notification ('||wwv_flow.LF||
'    p_team_member_id     in  number,'||wwv_flow.LF||
'    p_app_name           in  var';
wwv_flow_imp.g_varchar2_table(520) := 'char2,'||wwv_flow.LF||
'    p_app_id             in  number,'||wwv_flow.LF||
'    p_project_id         in  number  default null,'||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(521) := '_task_id            in  number  default null,'||wwv_flow.LF||
'    p_link               in  varchar2,'||wwv_flow.LF||
'    p_view_what';
wwv_flow_imp.g_varchar2_table(522) := '          in  varchar2,'||wwv_flow.LF||
'    p_title              in  varchar2,'||wwv_flow.LF||
'    p_email_contents     in  varchar2';
wwv_flow_imp.g_varchar2_table(523) := ','||wwv_flow.LF||
'    p_notification_type  in  varchar2 )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- only send if person is also a user (projec';
wwv_flow_imp.g_varchar2_table(524) := 't owners may not be users)'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select email, '||wwv_flow.LF||
'               nvl(notification_pr';
wwv_flow_imp.g_varchar2_table(525) := 'ef,''APP:EMAIL'') notification_pref'||wwv_flow.LF||
'          from sp_team_members t'||wwv_flow.LF||
'         where id = p_team_member';
wwv_flow_imp.g_varchar2_table(526) := '_id'||wwv_flow.LF||
'           and exists (select 1'||wwv_flow.LF||
'                         from APEX_APPL_ACL_USERS'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(527) := '          where application_id = p_app_id'||wwv_flow.LF||
'                          and user_name_lc = t.email)'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(528) := ') loop'||wwv_flow.LF||
'        insert into sp_team_member_notifications'||wwv_flow.LF||
'            (team_member_id, project_id, tas';
wwv_flow_imp.g_varchar2_table(529) := 'k_id, title, email_contents, notification_pref, notification_type)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (p_tea';
wwv_flow_imp.g_varchar2_table(530) := 'm_member_id, p_project_id, p_task_id, p_title, p_email_contents, c1.notification_pref, p_notificatio';
wwv_flow_imp.g_varchar2_table(531) := 'n_type);'||wwv_flow.LF||
''||wwv_flow.LF||
'        if instr('':''||c1.notification_pref||'':'','':EMAIL:'') > 0 and'||wwv_flow.LF||
'           apex_util.ge';
wwv_flow_imp.g_varchar2_table(532) := 't_build_option_status ('||wwv_flow.LF||
'               p_application_id    => p_app_id,'||wwv_flow.LF||
'               p_build_optio';
wwv_flow_imp.g_varchar2_table(533) := 'n_name => ''Email Configured'') = ''INCLUDE'''||wwv_flow.LF||
'        then'||wwv_flow.LF||
'            apex_mail.send ( '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(534) := ' p_to                 => c1.email,   '||wwv_flow.LF||
'                p_from               => c1.email,  '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(535) := '      p_application_id     => p_app_id,  '||wwv_flow.LF||
'                p_template_static_id => ''NOTIFICATIONS'',  ';
wwv_flow_imp.g_varchar2_table(536) := ''||wwv_flow.LF||
'                p_placeholders       => ''{'' || ''"VIEW_LINK": "'' || p_link ||''", ''|| '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(537) := '                                 ''"APP_NAME": ''   || apex_json.stringify( p_app_name ) ||'', ''||'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(538) := '                                           ''"SUBJECT": ''    || apex_json.stringify( p_title ) ||'', ''';
wwv_flow_imp.g_varchar2_table(539) := '||'||wwv_flow.LF||
'                                               ''"VIEW_WHAT": ''  || apex_json.stringify( p_view_wh';
wwv_flow_imp.g_varchar2_table(540) := 'at ) ||'', ''||'||wwv_flow.LF||
'                                               ''"SUMMARY": ''    || apex_json.stringify';
wwv_flow_imp.g_varchar2_table(541) := '( p_email_contents ) ||'||wwv_flow.LF||
'                                         ''}'' ); '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end loo';
wwv_flow_imp.g_varchar2_table(542) := 'p;'||wwv_flow.LF||
'end assignment_notification;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure comment_notification ('||wwv_flow.LF||
'    p_team_member_id      in  num';
wwv_flow_imp.g_varchar2_table(543) := 'ber,'||wwv_flow.LF||
'    p_app_name            in  varchar2,'||wwv_flow.LF||
'    p_app_id              in  number,'||wwv_flow.LF||
'    p_project_id ';
wwv_flow_imp.g_varchar2_table(544) := '         in  number  default null,'||wwv_flow.LF||
'    p_task_id             in  number  default null,'||wwv_flow.LF||
'    p_release';
wwv_flow_imp.g_varchar2_table(545) := '_id          in  number  default null,'||wwv_flow.LF||
'    p_initiative_id       in  number  default null,'||wwv_flow.LF||
'    p_ini';
wwv_flow_imp.g_varchar2_table(546) := 't_focus_area_id  in  number  default null,'||wwv_flow.LF||
'    p_link                in  varchar2,'||wwv_flow.LF||
'    p_view_what  ';
wwv_flow_imp.g_varchar2_table(547) := '         in  varchar2,'||wwv_flow.LF||
'    p_title               in  varchar2,'||wwv_flow.LF||
'    p_email_contents      in  varchar';
wwv_flow_imp.g_varchar2_table(548) := '2,'||wwv_flow.LF||
'    p_notification_type   in  varchar2 default ''COMMENT'' )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- only send if person is';
wwv_flow_imp.g_varchar2_table(549) := ' also a user (project owners may not be users)'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select email, '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(550) := ' nvl(comment_notif_pref,''APP:EMAIL'') comment_pref'||wwv_flow.LF||
'          from sp_team_members t'||wwv_flow.LF||
'         where id';
wwv_flow_imp.g_varchar2_table(551) := ' = p_team_member_id'||wwv_flow.LF||
'           and (instr('':''||nvl(comment_notif_pref,''APP:EMAIL'')||'':'','':APP:'') > 0';
wwv_flow_imp.g_varchar2_table(552) := ' or'||wwv_flow.LF||
'                instr('':''||nvl(comment_notif_pref,''APP:EMAIL'')||'':'','':EMAIL:'') > 0)'||wwv_flow.LF||
'           a';
wwv_flow_imp.g_varchar2_table(553) := 'nd exists (select 1'||wwv_flow.LF||
'                         from APEX_APPL_ACL_USERS'||wwv_flow.LF||
'                        where ';
wwv_flow_imp.g_varchar2_table(554) := 'application_id = p_app_id'||wwv_flow.LF||
'                          and user_name_lc = t.email)'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        i';
wwv_flow_imp.g_varchar2_table(555) := 'nsert into sp_team_member_notifications'||wwv_flow.LF||
'            (team_member_id, project_id, task_id, release_id';
wwv_flow_imp.g_varchar2_table(556) := ', initiative_id, init_focus_area_id,'||wwv_flow.LF||
'             title, email_contents, notification_pref, notifica';
wwv_flow_imp.g_varchar2_table(557) := 'tion_type)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (p_team_member_id, p_project_id, p_task_id, p_release_id, p_in';
wwv_flow_imp.g_varchar2_table(558) := 'itiative_id, p_init_focus_area_id,'||wwv_flow.LF||
'             p_title, substr(p_email_contents,1,4000), c1.comment';
wwv_flow_imp.g_varchar2_table(559) := '_pref, p_notification_type);'||wwv_flow.LF||
''||wwv_flow.LF||
'        if instr('':''||c1.comment_pref||'':'','':EMAIL:'') > 0 and'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(560) := '   apex_util.get_build_option_status ('||wwv_flow.LF||
'               p_application_id    => p_app_id,'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(561) := '  p_build_option_name => ''Email Configured'') = ''INCLUDE'''||wwv_flow.LF||
'        then'||wwv_flow.LF||
'            apex_mail.send ( '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(562) := '                p_to                 => c1.email,   '||wwv_flow.LF||
'                p_from               => c1.emai';
wwv_flow_imp.g_varchar2_table(563) := 'l,  '||wwv_flow.LF||
'                p_application_id     => p_app_id,  '||wwv_flow.LF||
'                p_template_static_id => ''NO';
wwv_flow_imp.g_varchar2_table(564) := 'TIFICATIONS'',  '||wwv_flow.LF||
'                p_placeholders       => ''{'' || ''"VIEW_LINK": "'' || p_link ||''", ''|| ';
wwv_flow_imp.g_varchar2_table(565) := ''||wwv_flow.LF||
'                                               ''"APP_NAME": ''   || apex_json.stringify( p_app_name ';
wwv_flow_imp.g_varchar2_table(566) := ') ||'', ''||'||wwv_flow.LF||
'                                               ''"SUBJECT": ''    || apex_json.stringify( p';
wwv_flow_imp.g_varchar2_table(567) := '_title ) ||'', ''||'||wwv_flow.LF||
'                                               ''"VIEW_WHAT": ''  || apex_json.strin';
wwv_flow_imp.g_varchar2_table(568) := 'gify( p_view_what ) ||'', ''||'||wwv_flow.LF||
'                                               ''"SUMMARY": ''    || apex';
wwv_flow_imp.g_varchar2_table(569) := '_json.stringify( p_email_contents ) ||'||wwv_flow.LF||
'                                         ''}'' ); '||wwv_flow.LF||
'        end ';
wwv_flow_imp.g_varchar2_table(570) := 'if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end comment_notification;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- used by SP_CONTRIBUTOR_SUMMARY, SP_RELEASE_TIMELINE';
wwv_flow_imp.g_varchar2_table(571) := ' and with app'||wwv_flow.LF||
'function exceptions_for_project ('||wwv_flow.LF||
'    p_project_id      in  number,'||wwv_flow.LF||
'    p_one_project_';
wwv_flow_imp.g_varchar2_table(572) := 'yn  in  varchar2 default ''N'','||wwv_flow.LF||
'    p_team_member_id  in  number   default null,'||wwv_flow.LF||
'    p_link_type      ';
wwv_flow_imp.g_varchar2_table(573) := ' in  varchar2,'||wwv_flow.LF||
'    p_app_prefix_url  in  varchar2,'||wwv_flow.LF||
'    p_app_id          in  number,'||wwv_flow.LF||
'    p_apex_sess';
wwv_flow_imp.g_varchar2_table(574) := 'ion    in  number   default null,'||wwv_flow.LF||
'    p_reviews_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_approvals_yn';
wwv_flow_imp.g_varchar2_table(575) := '    in  varchar2 default ''N'' )'||wwv_flow.LF||
'    return clob'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_proj_yn              varchar2(1) := ''N'';'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(576) := ' l_exceptions_yn        varchar2(1) := ''N'';'||wwv_flow.LF||
'    l_sysdate              date := trunc(sysdate);'||wwv_flow.LF||
'    l';
wwv_flow_imp.g_varchar2_table(577) := '_date_fm              varchar2(255) := ''FMDay DD-MON'';'||wwv_flow.LF||
'    l_project              varchar2(4000);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(578) := '  l_role                 varchar2(4000);'||wwv_flow.LF||
'    l_url                  varchar2(4000);'||wwv_flow.LF||
'    l_activity  ';
wwv_flow_imp.g_varchar2_table(579) := '           varchar2(4000);'||wwv_flow.LF||
'    x                      clob := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        se';
wwv_flow_imp.g_varchar2_table(580) := 'lect p.id,'||wwv_flow.LF||
'               p.friendly_identifier,'||wwv_flow.LF||
'               p.project,'||wwv_flow.LF||
'               p.owner_id';
wwv_flow_imp.g_varchar2_table(581) := ','||wwv_flow.LF||
'               p.requires_reviews_yn,'||wwv_flow.LF||
'               p.pct_complete,'||wwv_flow.LF||
'               '' - ''|| to_cha';
wwv_flow_imp.g_varchar2_table(582) := 'r(p.pct_complete) ||''% ''|| p.project_size ||'' P''||to_char(r.priority) quick_summary,'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(583) := 'case when p.owner_id is not null then '' - ''||(select first_name ||'' ''||last_name from sp_team_member';
wwv_flow_imp.g_varchar2_table(584) := 's where id = p.owner_id) end owner,'||wwv_flow.LF||
'               case when p.pct_complete >= s.min_pc_for_status a';
wwv_flow_imp.g_varchar2_table(585) := 'nd'||wwv_flow.LF||
'                         p.pct_complete != 100 and '||wwv_flow.LF||
'                         p.status_id is null'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(586) := '                    then ''Y'''||wwv_flow.LF||
'                    end status_not_set'||wwv_flow.LF||
'          from sp_projects p,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(587) := '             sp_initiatives i,'||wwv_flow.LF||
'               sp_project_priorities r,'||wwv_flow.LF||
'               sp_project_sca';
wwv_flow_imp.g_varchar2_table(588) := 'les s'||wwv_flow.LF||
'         where p.id = p_project_id'||wwv_flow.LF||
'           and p.initiative_id = i.id'||wwv_flow.LF||
'           and p.prio';
wwv_flow_imp.g_varchar2_table(589) := 'rity_id = r.id'||wwv_flow.LF||
'           and i.status_scale = s.scale_letter'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_proj_yn := ''N'';'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(590) := ''||wwv_flow.LF||
'        -- if for just one project, no need to include the project header'||wwv_flow.LF||
'        if p_one_project_';
wwv_flow_imp.g_varchar2_table(591) := 'yn = ''N'' then'||wwv_flow.LF||
'            l_project := ''<strong>''||apex_escape.html(c1.project)||''</strong>'';'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(592) := '      -- broken out to avoid bulk bind error'||wwv_flow.LF||
'            if c1.owner_id = p_team_member_id then l_ro';
wwv_flow_imp.g_varchar2_table(593) := 'le := '' (Owner)'';'||wwv_flow.LF||
'            else select listagg(rt.resource_type, '', '' on overflow truncate with c';
wwv_flow_imp.g_varchar2_table(594) := 'ount) within group (order by rt.resource_type)'||wwv_flow.LF||
'                   into l_role'||wwv_flow.LF||
'                   fro';
wwv_flow_imp.g_varchar2_table(595) := 'm sp_project_contributors c,'||wwv_flow.LF||
'                        sp_resource_types rt'||wwv_flow.LF||
'                  where c.';
wwv_flow_imp.g_varchar2_table(596) := 'project_id = c1.id'||wwv_flow.LF||
'                    and c.team_member_id = p_team_member_id'||wwv_flow.LF||
'                    a';
wwv_flow_imp.g_varchar2_table(597) := 'nd c.responsibility_id = rt.id;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'            if p_link_type = ''APP'' then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(598) := '        l_url := apex_util.prepare_url(''f?p=''||p_app_id||'':3:''||p_apex_session||''::NO:3:FI:''||apex_e';
wwv_flow_imp.g_varchar2_table(599) := 'scape.html(c1.friendly_identifier));'||wwv_flow.LF||
'               l_project := ''<a href="''||l_url||''">''||l_project';
wwv_flow_imp.g_varchar2_table(600) := '||''</a>'' || case when l_role is not null then '' (''||apex_escape.html(l_role)||'')'' end || apex_escape';
wwv_flow_imp.g_varchar2_table(601) := '.html(c1.owner) || apex_escape.html(c1.quick_summary);'||wwv_flow.LF||
'            elsif p_link_type in (''EMAIL'',''JO';
wwv_flow_imp.g_varchar2_table(602) := 'B'') then'||wwv_flow.LF||
'               l_url := apex_page.get_url('||wwv_flow.LF||
'                            p_application => p_a';
wwv_flow_imp.g_varchar2_table(603) := 'pp_id,'||wwv_flow.LF||
'                            p_page        => 3,'||wwv_flow.LF||
'                            p_session     => ';
wwv_flow_imp.g_varchar2_table(604) := 'null,'||wwv_flow.LF||
'                            p_items       => ''FI'','||wwv_flow.LF||
'                            p_values      =';
wwv_flow_imp.g_varchar2_table(605) := '> c1.friendly_identifier,'||wwv_flow.LF||
'                            p_plain_url   => TRUE );'||wwv_flow.LF||
'               if p_l';
wwv_flow_imp.g_varchar2_table(606) := 'ink_type = ''EMAIL'' then'||wwv_flow.LF||
'                  l_url := p_app_prefix_url || l_url; '||wwv_flow.LF||
'               end if';
wwv_flow_imp.g_varchar2_table(607) := ';'||wwv_flow.LF||
'               l_project := ''<a href="''||l_url||''">''||l_project||''</a>'' || apex_escape.html(l_role';
wwv_flow_imp.g_varchar2_table(608) := ') || apex_escape.html(c1.owner) || apex_escape.html(c1.quick_summary);'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(609) := '   l_project := l_project || apex_escape.html(l_role) || apex_escape.html(c1.owner) || apex_escape.h';
wwv_flow_imp.g_varchar2_table(610) := 'tml(c1.quick_summary);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- NO PROJECT OWNER'||wwv_flow.LF||
'        if c';
wwv_flow_imp.g_varchar2_table(611) := '1.owner_id is null then'||wwv_flow.LF||
'            l_exceptions_yn := ''Y'';'||wwv_flow.LF||
'            x := x||l_project||chr(10)||';
wwv_flow_imp.g_varchar2_table(612) := '''<ul>'';'||wwv_flow.LF||
'            l_proj_yn := ''Y'';'||wwv_flow.LF||
'            x := x||''<li>No Owner</li>''||chr(10);'||wwv_flow.LF||
'        end ';
wwv_flow_imp.g_varchar2_table(613) := 'if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- STATUS NOT SET'||wwv_flow.LF||
'        if c1.status_not_set = ''Y'' then'||wwv_flow.LF||
'            if l_proj_yn = ''N';
wwv_flow_imp.g_varchar2_table(614) := ''' then'||wwv_flow.LF||
'               x := x||l_project||chr(10)||''<ul>'';'||wwv_flow.LF||
'               l_proj_yn := ''Y'';'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(615) := '   end if;'||wwv_flow.LF||
'            l_exceptions_yn := ''Y'';'||wwv_flow.LF||
'            x := x||''<li>Status not set</li>''||chr(10';
wwv_flow_imp.g_varchar2_table(616) := ');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- NO PROJECT REVIEWERS'||wwv_flow.LF||
'        if c1.requires_reviews_yn = ''Y'' and'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(617) := '       c1.pct_complete >= 50 and'||wwv_flow.LF||
'           p_reviews_yn = ''Y'' then'||wwv_flow.LF||
'            for c2 in ('||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(618) := '        select count(*) cnt'||wwv_flow.LF||
'                  from sp_tasks t,'||wwv_flow.LF||
'                       sp_task_types ';
wwv_flow_imp.g_varchar2_table(619) := 'tt'||wwv_flow.LF||
'                 where t.project_id = c1.id'||wwv_flow.LF||
'                   and nvl(t.task_sub_type_id,t.task_';
wwv_flow_imp.g_varchar2_table(620) := 'type_id) = tt.id'||wwv_flow.LF||
'                   and tt.static_id like ''REVIEW%'''||wwv_flow.LF||
'                   and t.owner_i';
wwv_flow_imp.g_varchar2_table(621) := 'd is not null'||wwv_flow.LF||
'            ) loop'||wwv_flow.LF||
'                if c2.cnt = 0 then'||wwv_flow.LF||
'                    if l_proj_yn';
wwv_flow_imp.g_varchar2_table(622) := ' = ''N'' then'||wwv_flow.LF||
'                        x := x||l_project||chr(10)||''<ul>'';'||wwv_flow.LF||
'                        l_pr';
wwv_flow_imp.g_varchar2_table(623) := 'oj_yn := ''Y'';'||wwv_flow.LF||
'                    end if;'||wwv_flow.LF||
'                    l_exceptions_yn := ''Y'';'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(624) := '      x := x||''<li>No Reviewers</li>''||chr(10);'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(625) := '  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- OVERDUE PROJECT MILESTONES'||wwv_flow.LF||
'        for c2 in ('||wwv_flow.LF||
'            select (select firs';
wwv_flow_imp.g_varchar2_table(626) := 't_name||'' ''||last_name from sp_team_members tm where tm.id = t.owner_id) owner,'||wwv_flow.LF||
'                   t';
wwv_flow_imp.g_varchar2_table(627) := 't.task_type type,'||wwv_flow.LF||
'                   s.status,'||wwv_flow.LF||
'                   trunc(t.target_complete) target_co';
wwv_flow_imp.g_varchar2_table(628) := 'mplete'||wwv_flow.LF||
'              from sp_tasks t,'||wwv_flow.LF||
'                   sp_task_types tt,'||wwv_flow.LF||
'                   sp_tas';
wwv_flow_imp.g_varchar2_table(629) := 'k_statuses s'||wwv_flow.LF||
'             where t.project_id = c1.id'||wwv_flow.LF||
'               and nvl(t.task_sub_type_id,t.tas';
wwv_flow_imp.g_varchar2_table(630) := 'k_type_id) = tt.id'||wwv_flow.LF||
'               and tt.static_id like ''MILESTONE%'''||wwv_flow.LF||
'               and t.status_id ';
wwv_flow_imp.g_varchar2_table(631) := '= s.id'||wwv_flow.LF||
'               and s.indicates_complete_yn = ''N'''||wwv_flow.LF||
'               and trunc(t.target_complete) ';
wwv_flow_imp.g_varchar2_table(632) := '< l_sysdate'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'             if l_proj_yn = ''N'' then'||wwv_flow.LF||
'                 x := x||l_project||';
wwv_flow_imp.g_varchar2_table(633) := 'chr(10)||''<ul>'';'||wwv_flow.LF||
'                 l_proj_yn := ''Y'';'||wwv_flow.LF||
'             end if;'||wwv_flow.LF||
'             l_exceptions_y';
wwv_flow_imp.g_varchar2_table(634) := 'n := ''Y'';'||wwv_flow.LF||
'             x := x||''<li>''|| apex_escape.html(c2.type)|| case when c2.owner is not null '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(635) := '                                                               then '' assigned to ''||apex_escape.htm';
wwv_flow_imp.g_varchar2_table(636) := 'l(c2.owner) '||wwv_flow.LF||
'                                                               else '', no owner,'' '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(637) := '                                                           end ||'' was due ''|| to_char(c2.target_com';
wwv_flow_imp.g_varchar2_table(638) := 'plete,l_date_fm)||''  (''||apex_escape.html(c2.status)||'')</li>''||chr(10);'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(639) := '-- OVERDUE REVIEWS'||wwv_flow.LF||
'        if c1.requires_reviews_yn = ''Y'' and'||wwv_flow.LF||
'           p_reviews_yn = ''Y'' then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(640) := '          for c2 in ('||wwv_flow.LF||
'                select (select first_name||'' ''||last_name from sp_team_members';
wwv_flow_imp.g_varchar2_table(641) := ' tm where tm.id = t.owner_id) reviewer,'||wwv_flow.LF||
'                       tt.task_type type,'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(642) := '     s.status,'||wwv_flow.LF||
'                       trunc(t.target_complete) review_date'||wwv_flow.LF||
'                  from sp';
wwv_flow_imp.g_varchar2_table(643) := '_tasks t,'||wwv_flow.LF||
'                       sp_task_types tt,'||wwv_flow.LF||
'                       sp_task_statuses s'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(644) := '          where t.project_id = c1.id'||wwv_flow.LF||
'                   and nvl(t.task_sub_type_id,t.task_type_id) =';
wwv_flow_imp.g_varchar2_table(645) := ' tt.id'||wwv_flow.LF||
'                   and tt.static_id like ''REVIEW%'''||wwv_flow.LF||
'                   and t.status_id = s.id'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(646) := '                   and s.indicates_complete_yn = ''N'''||wwv_flow.LF||
'                   and trunc(t.target_complete)';
wwv_flow_imp.g_varchar2_table(647) := ' < l_sysdate'||wwv_flow.LF||
'            ) loop'||wwv_flow.LF||
'                if l_proj_yn = ''N'' then'||wwv_flow.LF||
'                    x := x||';
wwv_flow_imp.g_varchar2_table(648) := 'l_project||chr(10)||''<ul>'';'||wwv_flow.LF||
'                    l_proj_yn := ''Y'';'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(649) := '      l_exceptions_yn := ''Y'';'||wwv_flow.LF||
'                x := x||''<li>''||apex_escape.html(c2.type)|| case when ';
wwv_flow_imp.g_varchar2_table(650) := 'c2.reviewer is not null'||wwv_flow.LF||
'                                                                 then '' by ''';
wwv_flow_imp.g_varchar2_table(651) := '||apex_escape.html(c2.reviewer)'||wwv_flow.LF||
'                                                                 els';
wwv_flow_imp.g_varchar2_table(652) := 'e '', no reviewer assigned,'''||wwv_flow.LF||
'                                                                 end || ';
wwv_flow_imp.g_varchar2_table(653) := ''' was targeted for ''||to_char(c2.review_date,l_date_fm)||''  (''||apex_escape.html(c2.status)||'')</li>';
wwv_flow_imp.g_varchar2_table(654) := '''||chr(10);'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'            -- REVIEWS WITHOUT DATES'||wwv_flow.LF||
'            for c2 in ('||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(655) := '            select (select first_name||'' ''||last_name from sp_team_members tm where tm.id = t.owner_';
wwv_flow_imp.g_varchar2_table(656) := 'id) reviewer,'||wwv_flow.LF||
'                       tt.task_type type,'||wwv_flow.LF||
'                       s.status'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(657) := '      from sp_tasks t,'||wwv_flow.LF||
'                       sp_task_types tt,'||wwv_flow.LF||
'                       sp_task_statu';
wwv_flow_imp.g_varchar2_table(658) := 'ses s'||wwv_flow.LF||
'                 where t.project_id = c1.id'||wwv_flow.LF||
'                   and nvl(t.task_sub_type_id,t.ta';
wwv_flow_imp.g_varchar2_table(659) := 'sk_type_id) = tt.id'||wwv_flow.LF||
'                   and tt.static_id like ''REVIEW%'''||wwv_flow.LF||
'                   and t.stat';
wwv_flow_imp.g_varchar2_table(660) := 'us_id = s.id'||wwv_flow.LF||
'                   and s.indicates_complete_yn = ''N'''||wwv_flow.LF||
'                   and t.target_co';
wwv_flow_imp.g_varchar2_table(661) := 'mplete is null'||wwv_flow.LF||
'            ) loop'||wwv_flow.LF||
'                if l_proj_yn = ''N'' then'||wwv_flow.LF||
'                    x := x';
wwv_flow_imp.g_varchar2_table(662) := '||l_project||chr(10)||''<ul>'';'||wwv_flow.LF||
'                    l_proj_yn := ''Y'';'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(663) := '        l_exceptions_yn := ''Y'';'||wwv_flow.LF||
'                x := x||''<li>''||apex_escape.html(c2.type)|| case whe';
wwv_flow_imp.g_varchar2_table(664) := 'n c2.reviewer is not null'||wwv_flow.LF||
'                                                                 then '' by';
wwv_flow_imp.g_varchar2_table(665) := ' ''||apex_escape.html(c2.reviewer)'||wwv_flow.LF||
'                                                                 e';
wwv_flow_imp.g_varchar2_table(666) := 'lse '', no reviewer assigned,'''||wwv_flow.LF||
'                                                                 end |';
wwv_flow_imp.g_varchar2_table(667) := '| '' has no target date (''||apex_escape.html(c2.status)||'')</li>''||chr(10);'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(668) := '     end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -- PENDING APPROVALS'||wwv_flow.LF||
'        if p_approvals_yn = ''Y'' then'||wwv_flow.LF||
'            for c2 i';
wwv_flow_imp.g_varchar2_table(669) := 'n ('||wwv_flow.LF||
'                select (select first_name||'' ''||last_name from sp_team_members tm where tm.id = ';
wwv_flow_imp.g_varchar2_table(670) := 'a.submitted_by_team_member_id) owner,'||wwv_flow.LF||
'                       t.approval_type ||'' Review'' type,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(671) := '                  case when a.status = ''PENDING'''||wwv_flow.LF||
'                            then ''Pending Review'''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(672) := '                           when a.status = ''CLARIFICATION-REQUESTED'''||wwv_flow.LF||
'                            the';
wwv_flow_imp.g_varchar2_table(673) := 'n ''Clarification Requested'''||wwv_flow.LF||
'                            end status,'||wwv_flow.LF||
'                       trunc(a.u';
wwv_flow_imp.g_varchar2_table(674) := 'pdated) target_complete'||wwv_flow.LF||
'                  from sp_project_approvals a,'||wwv_flow.LF||
'                       sp_app';
wwv_flow_imp.g_varchar2_table(675) := 'roval_types t'||wwv_flow.LF||
'                 where a.project_id = c1.id'||wwv_flow.LF||
'                   and a.approval_type_id ';
wwv_flow_imp.g_varchar2_table(676) := '= t.id'||wwv_flow.LF||
'                   and a.status in (''PENDING'',''CLARIFICATION-REQUESTED'')'||wwv_flow.LF||
'            ) loop'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(677) := '                if l_proj_yn = ''N'' then'||wwv_flow.LF||
'                     x := x||l_project||chr(10)||''<ul>'';'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(678) := '                  l_proj_yn := ''Y'';'||wwv_flow.LF||
'                 end if;'||wwv_flow.LF||
'                 l_exceptions_yn := ''Y''';
wwv_flow_imp.g_varchar2_table(679) := ';'||wwv_flow.LF||
'                 x := x||''<li>''|| apex_escape.html(c2.type)||'' submitted by ''||apex_escape.html(c2';
wwv_flow_imp.g_varchar2_table(680) := '.owner) ||'' is currently ''||apex_escape.html(c2.status)||''</li>''||chr(10);'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(681) := '     end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        if l_proj_yn = ''Y'' then'||wwv_flow.LF||
'            x := x||''</ul>'';'||wwv_flow.LF||
'        end if;    '||wwv_flow.LF||
'  '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(682) := '  end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return x;'||wwv_flow.LF||
''||wwv_flow.LF||
'end exceptions_for_project;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function replace_nomenclature ('||wwv_flow.LF||
'    p_cont';
wwv_flow_imp.g_varchar2_table(683) := 'ents  in  varchar2'||wwv_flow.LF||
') return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_new_contents  varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_new_contents';
wwv_flow_imp.g_varchar2_table(684) := ' := p_contents;'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select static_id, custom_value'||wwv_flow.LF||
'          from sp_app_nomenc';
wwv_flow_imp.g_varchar2_table(685) := 'lature'||wwv_flow.LF||
'         order by static_id desc'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        l_new_contents := replace(l_new_contents,';
wwv_flow_imp.g_varchar2_table(686) := '''&NOMENCLATURE_''||c1.static_id||''.'',c1.custom_value);'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select ';
wwv_flow_imp.g_varchar2_table(687) := 'static_id, custom_value'||wwv_flow.LF||
'          from sp_app_nomenclature'||wwv_flow.LF||
'         order by static_id desc'||wwv_flow.LF||
'    ) lo';
wwv_flow_imp.g_varchar2_table(688) := 'op'||wwv_flow.LF||
'        l_new_contents := replace(l_new_contents,''NOMENCLATURE_''||c1.static_id,c1.custom_value);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(689) := '    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_new_contents;'||wwv_flow.LF||
''||wwv_flow.LF||
'end replace_nomenclature;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function fix_demo_dates ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(690) := ' p_date  in  date'||wwv_flow.LF||
') return date'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_date  date;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_date := case to_char(p_date,''DY'') w';
wwv_flow_imp.g_varchar2_table(691) := 'hen ''SAT'' then p_date-1'||wwv_flow.LF||
'                                        when ''SUN'' then p_date+1'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(692) := '                             else p_date'||wwv_flow.LF||
'                                        end;'||wwv_flow.LF||
'    return l_d';
wwv_flow_imp.g_varchar2_table(693) := 'ate;'||wwv_flow.LF||
'end fix_demo_dates;'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_util;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(151732928632544295777)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_util body'
,p_sequence=>7010
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
