prompt --application/deployment/install/install_sp_event_util_body
begin
--   Manifest
--     INSTALL: INSTALL-sp_event_util body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body sp_event_util'||wwv_flow.LF||
'as '||wwv_flow.LF||
''||wwv_flow.LF||
'function create_series_l ( '||wwv_flow.LF||
'    p_start_date  time';
wwv_flow_imp.g_varchar2_table(2) := 'stamp with time zone, '||wwv_flow.LF||
'    p_end_date    timestamp with time zone, '||wwv_flow.LF||
'    p_recur_freq  varchar2 ) '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(3) := '  return number '||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_series_id       number; '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    insert into sp_event_series '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(4) := '(start_date, end_date, recur_freq) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'        (p_start_date, p_end_date, p_recur_freq) '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(5) := '  returning id into l_series_id; '||wwv_flow.LF||
'    return l_series_id; '||wwv_flow.LF||
'end create_series_l; '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure create_';
wwv_flow_imp.g_varchar2_table(6) := 'event_l ( '||wwv_flow.LF||
'    p_event_type_id    number, '||wwv_flow.LF||
'    p_event_date       timestamp with time zone, '||wwv_flow.LF||
'    p_e';
wwv_flow_imp.g_varchar2_table(7) := 'vent_name       varchar2, '||wwv_flow.LF||
'    p_for_user_id      number,'||wwv_flow.LF||
'    p_event_details    varchar2 default nu';
wwv_flow_imp.g_varchar2_table(8) := 'll,'||wwv_flow.LF||
'    p_series_id        number   default null ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    insert into sp_events'||wwv_flow.LF||
'        (ev';
wwv_flow_imp.g_varchar2_table(9) := 'ent_type_id, event_date, event_name,  '||wwv_flow.LF||
'         for_user_id, event_details,'||wwv_flow.LF||
'         series_id) '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(10) := ' values '||wwv_flow.LF||
'        (p_event_type_id, p_event_date, p_event_name,  '||wwv_flow.LF||
'         p_for_user_id, p_event_det';
wwv_flow_imp.g_varchar2_table(11) := 'ails,'||wwv_flow.LF||
'         p_series_id); '||wwv_flow.LF||
'end create_event_l; '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure create_recur_events_l ( '||wwv_flow.LF||
'    p_series';
wwv_flow_imp.g_varchar2_table(12) := '_id        number,'||wwv_flow.LF||
'    p_event_type_id    number, '||wwv_flow.LF||
'    p_event_name       varchar2, '||wwv_flow.LF||
'    p_for_user_';
wwv_flow_imp.g_varchar2_table(13) := 'id      number,'||wwv_flow.LF||
'    p_event_details    varchar2 default null ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_cnt              number; '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(14) := 'begin '||wwv_flow.LF||
'    for c1 in ( '||wwv_flow.LF||
'        select start_date, end_date, recur_freq '||wwv_flow.LF||
'          from sp_event_ser';
wwv_flow_imp.g_varchar2_table(15) := 'ies '||wwv_flow.LF||
'         where id = p_series_id'||wwv_flow.LF||
'    ) loop '||wwv_flow.LF||
'        if c1.recur_freq = ''D'' then '||wwv_flow.LF||
'            l_';
wwv_flow_imp.g_varchar2_table(16) := 'cnt := trunc(to_number(substr((c1.end_date-c1.start_date),1,instr(c1.end_date-c1.start_date,'' ''))));';
wwv_flow_imp.g_varchar2_table(17) := ' '||wwv_flow.LF||
'            for i in 0..l_cnt loop '||wwv_flow.LF||
'                create_event_l ( '||wwv_flow.LF||
'                    p_series';
wwv_flow_imp.g_varchar2_table(18) := '_id     => p_series_id,'||wwv_flow.LF||
'                    p_event_type_id => p_event_type_id, '||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(19) := ' p_event_date    => c1.start_date + i, '||wwv_flow.LF||
'                    p_event_name    => p_event_name, '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(20) := '              p_for_user_id   => p_for_user_id,'||wwv_flow.LF||
'                    p_event_details => p_event_detai';
wwv_flow_imp.g_varchar2_table(21) := 'ls ); '||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        elsif c1.recur_freq = ''WD'' then '||wwv_flow.LF||
'            l_cnt := trunc(to';
wwv_flow_imp.g_varchar2_table(22) := '_number(substr((c1.end_date-c1.start_date),1,instr(c1.end_date-c1.start_date,'' ''))));'||wwv_flow.LF||
'            fo';
wwv_flow_imp.g_varchar2_table(23) := 'r i in 0..l_cnt loop '||wwv_flow.LF||
'                if to_char(c1.start_date + i,''DY'') not in (''SAT'',''SUN'') then '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(24) := '                    create_event_l ( '||wwv_flow.LF||
'                        p_series_id     => p_series_id,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(25) := '                  p_event_type_id => p_event_type_id, '||wwv_flow.LF||
'                        p_event_date    => c1';
wwv_flow_imp.g_varchar2_table(26) := '.start_date + i, '||wwv_flow.LF||
'                        p_event_name    => p_event_name, '||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(27) := 'p_for_user_id   => p_for_user_id,'||wwv_flow.LF||
'                        p_event_details => p_event_details ); '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(28) := '             end if; '||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        elsif c1.recur_freq = ''W'' then '||wwv_flow.LF||
'            l_c';
wwv_flow_imp.g_varchar2_table(29) := 'nt := trunc(to_number(substr((c1.end_date-c1.start_date),1,instr(c1.end_date-c1.start_date,'' '')))/7)';
wwv_flow_imp.g_varchar2_table(30) := ';  '||wwv_flow.LF||
'            for i in 0..l_cnt loop '||wwv_flow.LF||
'                create_event_l ( '||wwv_flow.LF||
'                    p_seri';
wwv_flow_imp.g_varchar2_table(31) := 'es_id     => p_series_id,'||wwv_flow.LF||
'                    p_event_type_id => p_event_type_id, '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(32) := '   p_event_date    => c1.start_date + (i*7),'||wwv_flow.LF||
'                    p_event_name    => p_event_name, '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(33) := '                   p_for_user_id   => p_for_user_id,'||wwv_flow.LF||
'                    p_event_details => p_event_';
wwv_flow_imp.g_varchar2_table(34) := 'details ); '||wwv_flow.LF||
''||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        elsif c1.recur_freq = ''2W'' then '||wwv_flow.LF||
'            l_cnt := tr';
wwv_flow_imp.g_varchar2_table(35) := 'unc(to_number(substr((c1.end_date-c1.start_date),1,instr(c1.end_date-c1.start_date,'' '')))/14); '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(36) := '        for i in 0..l_cnt loop '||wwv_flow.LF||
'                create_event_l ( '||wwv_flow.LF||
'                    p_series_id   ';
wwv_flow_imp.g_varchar2_table(37) := '  => p_series_id,'||wwv_flow.LF||
'                    p_event_type_id => p_event_type_id, '||wwv_flow.LF||
'                    p_eve';
wwv_flow_imp.g_varchar2_table(38) := 'nt_date    => c1.start_date + (i*14),'||wwv_flow.LF||
'                    p_event_name    => p_event_name, '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(39) := '            p_for_user_id   => p_for_user_id,'||wwv_flow.LF||
'                    p_event_details => p_event_details';
wwv_flow_imp.g_varchar2_table(40) := ' ); '||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        elsif c1.recur_freq = ''M'' then '||wwv_flow.LF||
'            l_cnt := trunc(month';
wwv_flow_imp.g_varchar2_table(41) := 's_between(to_date(to_char(c1.end_date,''DD-MON-RRRR''),''DD-MON-RRRR''),  '||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(42) := '             to_date(to_char(c1.start_date,''DD-MON-RRRR''),''DD-MON-RRRR''))); '||wwv_flow.LF||
'            for i in 0.';
wwv_flow_imp.g_varchar2_table(43) := '.l_cnt loop '||wwv_flow.LF||
'                create_event_l ( '||wwv_flow.LF||
'                    p_series_id     => p_series_id,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(44) := '                   p_event_type_id => p_event_type_id, '||wwv_flow.LF||
'                    p_event_date    => add_m';
wwv_flow_imp.g_varchar2_table(45) := 'onths(c1.start_date,i), '||wwv_flow.LF||
'                    p_event_name    => p_event_name, '||wwv_flow.LF||
'                    p';
wwv_flow_imp.g_varchar2_table(46) := '_for_user_id   => p_for_user_id,'||wwv_flow.LF||
'                    p_event_details => p_event_details ); '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(47) := '    end loop; '||wwv_flow.LF||
'        end if; '||wwv_flow.LF||
'    end loop; '||wwv_flow.LF||
'end create_recur_events_l; '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure create_more_r';
wwv_flow_imp.g_varchar2_table(48) := 'ecur_events_l ( '||wwv_flow.LF||
'    p_event_type_id         number, '||wwv_flow.LF||
'    p_event_name            varchar2, '||wwv_flow.LF||
'    p_l';
wwv_flow_imp.g_varchar2_table(49) := 'ast_event_date       timestamp with time zone, '||wwv_flow.LF||
'    p_for_user_id           number, '||wwv_flow.LF||
'    p_event_det';
wwv_flow_imp.g_varchar2_table(50) := 'ails         varchar2, '||wwv_flow.LF||
'    p_series_id             number ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_cnt                   number';
wwv_flow_imp.g_varchar2_table(51) := '; '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    for c1 in ( '||wwv_flow.LF||
'        select end_date, recur_freq '||wwv_flow.LF||
'          from sp_event_series '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(52) := '     where id = p_series_id'||wwv_flow.LF||
'    ) loop '||wwv_flow.LF||
'        if c1.recur_freq = ''D'' then '||wwv_flow.LF||
'            l_cnt := tr';
wwv_flow_imp.g_varchar2_table(53) := 'unc(to_number(substr((c1.end_date-p_last_event_date),1,instr(c1.end_date-p_last_event_date,'' '')))); ';
wwv_flow_imp.g_varchar2_table(54) := ''||wwv_flow.LF||
'--            l_cnt := trunc(c1.end_date-p_last_event_date);'||wwv_flow.LF||
'            for i in 1..l_cnt loop '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(55) := '              create_event_l ( '||wwv_flow.LF||
'                    p_event_type_id => p_event_type_id, '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(56) := '         p_event_date    => p_last_event_date + i, '||wwv_flow.LF||
'                    p_event_name    => p_event_n';
wwv_flow_imp.g_varchar2_table(57) := 'ame, '||wwv_flow.LF||
'                    p_for_user_id   => p_for_user_id, '||wwv_flow.LF||
'                    p_event_details => ';
wwv_flow_imp.g_varchar2_table(58) := 'p_event_details, '||wwv_flow.LF||
'                    p_series_id     => p_series_id ); '||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(59) := '    elsif c1.recur_freq = ''WD'' then '||wwv_flow.LF||
'            l_cnt := trunc(to_number(substr((c1.end_date-p_last';
wwv_flow_imp.g_varchar2_table(60) := '_event_date),1,instr(c1.end_date-p_last_event_date,'' '')))); '||wwv_flow.LF||
'--            l_cnt := trunc(c1.end_dat';
wwv_flow_imp.g_varchar2_table(61) := 'e-p_last_event_date); '||wwv_flow.LF||
'            for i in 1..l_cnt loop '||wwv_flow.LF||
'                if to_char(p_last_event_d';
wwv_flow_imp.g_varchar2_table(62) := 'ate + i,''DY'') not in (''SAT'',''SUN'') then '||wwv_flow.LF||
'                    create_event_l ( '||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(63) := '   p_event_type_id => p_event_type_id, '||wwv_flow.LF||
'                        p_event_date    => p_last_event_date';
wwv_flow_imp.g_varchar2_table(64) := ' + i, '||wwv_flow.LF||
'                        p_event_name    => p_event_name, '||wwv_flow.LF||
'                        p_for_user_';
wwv_flow_imp.g_varchar2_table(65) := 'id   => p_for_user_id, '||wwv_flow.LF||
'                        p_event_details => p_event_details, '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(66) := '         p_series_id     => p_series_id ); '||wwv_flow.LF||
'                end if; '||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(67) := 'elsif c1.recur_freq = ''W'' then  '||wwv_flow.LF||
'            l_cnt := trunc(to_number(substr((c1.end_date-p_last_eve';
wwv_flow_imp.g_varchar2_table(68) := 'nt_date),1,instr(c1.end_date-p_last_event_date,'' '')))/7); '||wwv_flow.LF||
'--            l_cnt := trunc((c1.end_date';
wwv_flow_imp.g_varchar2_table(69) := '-p_last_event_date)/7);'||wwv_flow.LF||
'             for i in 1..l_cnt loop '||wwv_flow.LF||
'                 create_event_l ( '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(70) := '                p_event_type_id => p_event_type_id, '||wwv_flow.LF||
'                    p_event_date    => p_last_e';
wwv_flow_imp.g_varchar2_table(71) := 'vent_date + (i*7), '||wwv_flow.LF||
'                    p_event_name    => p_event_name, '||wwv_flow.LF||
'                    p_for_';
wwv_flow_imp.g_varchar2_table(72) := 'user_id   => p_for_user_id, '||wwv_flow.LF||
'                    p_event_details => p_event_details, '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(73) := '      p_series_id     => p_series_id ); '||wwv_flow.LF||
'             end loop; '||wwv_flow.LF||
'        elsif c1.recur_freq = ''2W'' ';
wwv_flow_imp.g_varchar2_table(74) := 'then '||wwv_flow.LF||
'            l_cnt := trunc(to_number(substr((c1.end_date-p_last_event_date),1,instr(c1.end_dat';
wwv_flow_imp.g_varchar2_table(75) := 'e-p_last_event_date,'' '')))/14); '||wwv_flow.LF||
'--            l_cnt := trunc((c1.end_date-p_last_event_date)/14);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(76) := '           for i in 1..l_cnt loop '||wwv_flow.LF||
'                create_event_l ( '||wwv_flow.LF||
'                    p_event_typ';
wwv_flow_imp.g_varchar2_table(77) := 'e_id => p_event_type_id, '||wwv_flow.LF||
'                    p_event_date    => p_last_event_date + (i*14), '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(78) := '              p_event_name    => p_event_name, '||wwv_flow.LF||
'                    p_for_user_id   => p_for_user_id';
wwv_flow_imp.g_varchar2_table(79) := ', '||wwv_flow.LF||
'                    p_event_details => p_event_details, '||wwv_flow.LF||
'                    p_series_id     => p';
wwv_flow_imp.g_varchar2_table(80) := '_series_id ); '||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        elsif c1.recur_freq = ''M'' then '||wwv_flow.LF||
'            l_cnt := t';
wwv_flow_imp.g_varchar2_table(81) := 'runc(months_between(to_date(to_char(c1.end_date,''DD-MON-RRRR''),''DD-MON-RRRR''),  '||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(82) := '                       to_date(to_char(p_last_event_date,''DD-MON-RRRR''),''DD-MON-RRRR''))); '||wwv_flow.LF||
'--       ';
wwv_flow_imp.g_varchar2_table(83) := '     l_cnt := trunc(months_between(c1.end_date, p_last_event_date)); '||wwv_flow.LF||
'            for i in 1..l_cnt ';
wwv_flow_imp.g_varchar2_table(84) := 'loop '||wwv_flow.LF||
'                create_event_l ( '||wwv_flow.LF||
'                    p_event_type_id => p_event_type_id, '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(85) := '                 p_event_date    => add_months(p_last_event_date,i), '||wwv_flow.LF||
'                    p_event_na';
wwv_flow_imp.g_varchar2_table(86) := 'me    => p_event_name, '||wwv_flow.LF||
'                    p_for_user_id   => p_for_user_id, '||wwv_flow.LF||
'                    p';
wwv_flow_imp.g_varchar2_table(87) := '_event_details => p_event_details, '||wwv_flow.LF||
'                    p_series_id     => p_series_id ); '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(88) := '   end loop; '||wwv_flow.LF||
'        end if; '||wwv_flow.LF||
'    end loop; '||wwv_flow.LF||
'end create_more_recur_events_l; '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_ev';
wwv_flow_imp.g_varchar2_table(89) := 'ent_l ( '||wwv_flow.LF||
'    p_event_id  number ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    delete from sp_events'||wwv_flow.LF||
'     where id = p_event_id; ';
wwv_flow_imp.g_varchar2_table(90) := ''||wwv_flow.LF||
'end delete_event_l; '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_series_l ( '||wwv_flow.LF||
'    p_series_id  number ) '||wwv_flow.LF||
'is  '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    dele';
wwv_flow_imp.g_varchar2_table(91) := 'te from sp_event_series '||wwv_flow.LF||
'     where id = p_series_id; '||wwv_flow.LF||
'end delete_series_l; '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure clear_serie';
wwv_flow_imp.g_varchar2_table(92) := 's_l ( '||wwv_flow.LF||
'    p_series_id  number ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    update sp_events'||wwv_flow.LF||
'       set series_id = null '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(93) := 'where series_id = p_series_id; '||wwv_flow.LF||
'end clear_series_l; '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_series_end_date_l ( '||wwv_flow.LF||
'    p_s';
wwv_flow_imp.g_varchar2_table(94) := 'eries_id  number, '||wwv_flow.LF||
'    p_end_date   timestamp with time zone ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    update sp_event_serie';
wwv_flow_imp.g_varchar2_table(95) := 's'||wwv_flow.LF||
'       set end_date = p_end_date '||wwv_flow.LF||
'     where id = p_series_id; '||wwv_flow.LF||
'end update_series_end_date_l; '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'p';
wwv_flow_imp.g_varchar2_table(96) := 'rocedure update_event_l ( '||wwv_flow.LF||
'    p_event_id         number, '||wwv_flow.LF||
'    p_event_name       varchar2, '||wwv_flow.LF||
'    p_e';
wwv_flow_imp.g_varchar2_table(97) := 'vent_type_id    number, '||wwv_flow.LF||
'    p_event_date       timestamp with time zone, '||wwv_flow.LF||
'    p_event_details    va';
wwv_flow_imp.g_varchar2_table(98) := 'rchar2,'||wwv_flow.LF||
'    p_for_user_id      number  default null,'||wwv_flow.LF||
'    p_series_id        number  default null ) '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(99) := 'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    for c1 in ( '||wwv_flow.LF||
'        select event_type_id, event_date, event_name, '||wwv_flow.LF||
'               fo';
wwv_flow_imp.g_varchar2_table(100) := 'r_user_id, event_details,'||wwv_flow.LF||
'               series_id'||wwv_flow.LF||
'          from sp_events '||wwv_flow.LF||
'         where id = p_e';
wwv_flow_imp.g_varchar2_table(101) := 'vent_id'||wwv_flow.LF||
'    ) loop '||wwv_flow.LF||
'        if c1.event_type_id != p_event_type_id then '||wwv_flow.LF||
'            update sp_event';
wwv_flow_imp.g_varchar2_table(102) := 's '||wwv_flow.LF||
'               set event_type_id = p_event_type_id '||wwv_flow.LF||
'             where id = p_event_id; '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(103) := 'end if; '||wwv_flow.LF||
'        -- only for non-recurring events, recur pass in db value (update of recurring date ';
wwv_flow_imp.g_varchar2_table(104) := 'handled elsewhere) '||wwv_flow.LF||
'        if to_char(c1.event_date,''DD-MON-YYYY'') != to_char(p_event_date,''DD-MON-';
wwv_flow_imp.g_varchar2_table(105) := 'YYYY'') then '||wwv_flow.LF||
'            update sp_events'||wwv_flow.LF||
'               set event_date = p_event_date '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(106) := ' where id = p_event_id; '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if nvl(c1.event_name,''~'') != nvl(p_event_name,''~'') ';
wwv_flow_imp.g_varchar2_table(107) := 'then '||wwv_flow.LF||
'            update sp_events '||wwv_flow.LF||
'               set event_name = p_event_name '||wwv_flow.LF||
'             where';
wwv_flow_imp.g_varchar2_table(108) := ' id = p_event_id; '||wwv_flow.LF||
'        end if; '||wwv_flow.LF||
'        if nvl(c1.for_user_id,-1) != nvl(p_for_user_id,-1) then ';
wwv_flow_imp.g_varchar2_table(109) := ''||wwv_flow.LF||
'            update sp_events'||wwv_flow.LF||
'               set for_user_id = p_for_user_id '||wwv_flow.LF||
'             where id ';
wwv_flow_imp.g_varchar2_table(110) := '= p_event_id; '||wwv_flow.LF||
'        end if; '||wwv_flow.LF||
'        if nvl(c1.event_details,''~'') != nvl(p_event_details,''~'') the';
wwv_flow_imp.g_varchar2_table(111) := 'n '||wwv_flow.LF||
'            update sp_events '||wwv_flow.LF||
'               set event_details = p_event_details '||wwv_flow.LF||
'             wh';
wwv_flow_imp.g_varchar2_table(112) := 'ere id = p_event_id; '||wwv_flow.LF||
'        end if; '||wwv_flow.LF||
'        if nvl(c1.series_id,0) != nvl(p_series_id,0) then '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(113) := '          update sp_events '||wwv_flow.LF||
'               set series_id = p_series_id '||wwv_flow.LF||
'             where id = p_ev';
wwv_flow_imp.g_varchar2_table(114) := 'ent_id; '||wwv_flow.LF||
'        end if; '||wwv_flow.LF||
'    end loop; '||wwv_flow.LF||
'end update_event_l; '||wwv_flow.LF||
''||wwv_flow.LF||
'-------------------------------------';
wwv_flow_imp.g_varchar2_table(115) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure create_event ( '||wwv_flow.LF||
'    p_event_type_id    number, '||wwv_flow.LF||
'    p_event_date       timestamp with ti';
wwv_flow_imp.g_varchar2_table(116) := 'me zone, '||wwv_flow.LF||
'    p_event_name       varchar2, '||wwv_flow.LF||
'    p_for_user_id      number, '||wwv_flow.LF||
'    p_event_details    v';
wwv_flow_imp.g_varchar2_table(117) := 'archar2, '||wwv_flow.LF||
'    p_recur_freq       varchar2, '||wwv_flow.LF||
'    p_recur_end_date   timestamp with time zone ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(118) := '   l_series_id        number; '||wwv_flow.LF||
'begin '||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_recur_freq is not null then '||wwv_flow.LF||
'        l_series_id := ';
wwv_flow_imp.g_varchar2_table(119) := 'create_series_l ( '||wwv_flow.LF||
'                           p_start_date  => p_event_date, '||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(120) := '     p_end_date    => p_recur_end_date, '||wwv_flow.LF||
'                           p_recur_freq  => p_recur_freq );';
wwv_flow_imp.g_varchar2_table(121) := ' '||wwv_flow.LF||
'        create_recur_events_l ( '||wwv_flow.LF||
'            p_series_id     => l_series_id,'||wwv_flow.LF||
'            p_event_t';
wwv_flow_imp.g_varchar2_table(122) := 'ype_id => p_event_type_id, '||wwv_flow.LF||
'            p_event_name    => p_event_name, '||wwv_flow.LF||
'            p_for_user_id ';
wwv_flow_imp.g_varchar2_table(123) := '  => p_for_user_id, '||wwv_flow.LF||
'            p_event_details => p_event_details ); '||wwv_flow.LF||
'    else '||wwv_flow.LF||
'        create_eve';
wwv_flow_imp.g_varchar2_table(124) := 'nt_l ( '||wwv_flow.LF||
'            p_event_type_id => p_event_type_id, '||wwv_flow.LF||
'            p_event_date    => p_event_date';
wwv_flow_imp.g_varchar2_table(125) := ', '||wwv_flow.LF||
'            p_event_name    => p_event_name, '||wwv_flow.LF||
'            p_for_user_id   => p_for_user_id, '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(126) := '        p_event_details => p_event_details ); '||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'   commit; '||wwv_flow.LF||
'end create_event; '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedur';
wwv_flow_imp.g_varchar2_table(127) := 'e delete_event ( '||wwv_flow.LF||
'    p_event_id        number, '||wwv_flow.LF||
'    p_delete_type     varchar2 ) -- ONLY, ALL, FUTU';
wwv_flow_imp.g_varchar2_table(128) := 'RE (usually ONLY if not series)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_event_cnt  number  default 0; '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    for c1 in ( '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(129) := '     select series_id, event_date '||wwv_flow.LF||
'          from sp_events '||wwv_flow.LF||
'         where id = p_event_id'||wwv_flow.LF||
'    ) lo';
wwv_flow_imp.g_varchar2_table(130) := 'op '||wwv_flow.LF||
'        -- simple delete '||wwv_flow.LF||
'        if c1.series_id is null then '||wwv_flow.LF||
'            delete_event_l ( '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(131) := '              p_event_id => p_event_id ); '||wwv_flow.LF||
'        -- recurring '||wwv_flow.LF||
'        else '||wwv_flow.LF||
'            if p_dele';
wwv_flow_imp.g_varchar2_table(132) := 'te_type = ''ONLY'' then '||wwv_flow.LF||
'                delete_event_l (p_event_id => p_event_id); '||wwv_flow.LF||
'                -';
wwv_flow_imp.g_varchar2_table(133) := '- if no more events in the series, delete the series '||wwv_flow.LF||
'                select count(*) '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(134) := '     into l_event_cnt '||wwv_flow.LF||
'                  from sp_events '||wwv_flow.LF||
'                 where series_id = c1.serie';
wwv_flow_imp.g_varchar2_table(135) := 's_id; '||wwv_flow.LF||
'                if l_event_cnt = 0 then '||wwv_flow.LF||
'                    delete_series_l (p_series_id => ';
wwv_flow_imp.g_varchar2_table(136) := 'c1.series_id); '||wwv_flow.LF||
'                elsif l_event_cnt = 1 then '||wwv_flow.LF||
'                    -- only one event le';
wwv_flow_imp.g_varchar2_table(137) := 'ft, update event to remove series and delete series '||wwv_flow.LF||
'                    clear_series_l (p_series_id';
wwv_flow_imp.g_varchar2_table(138) := ' => c1.series_id); '||wwv_flow.LF||
'                    delete_series_l (p_series_id => c1.series_id); '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(139) := '    else '||wwv_flow.LF||
'                    -- update series end date, if last event was deleted '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(140) := '    for c3 in ( '||wwv_flow.LF||
'                        select max(event_date) last_date '||wwv_flow.LF||
'                         ';
wwv_flow_imp.g_varchar2_table(141) := ' from sp_events '||wwv_flow.LF||
'                         where series_id = c1.series_id'||wwv_flow.LF||
'                    ) loop ';
wwv_flow_imp.g_varchar2_table(142) := ''||wwv_flow.LF||
'                        update_series_end_date_l ( '||wwv_flow.LF||
'                            p_series_id => c1.s';
wwv_flow_imp.g_varchar2_table(143) := 'eries_id, '||wwv_flow.LF||
'                            p_end_date  => c3.last_date ); '||wwv_flow.LF||
'                    end loop;';
wwv_flow_imp.g_varchar2_table(144) := ' '||wwv_flow.LF||
'                end if; '||wwv_flow.LF||
'            else  '||wwv_flow.LF||
'                for c2 in ( '||wwv_flow.LF||
'                   select';
wwv_flow_imp.g_varchar2_table(145) := ' id event_id, event_date'||wwv_flow.LF||
'                     from sp_events '||wwv_flow.LF||
'                    where series_id = ';
wwv_flow_imp.g_varchar2_table(146) := 'c1.series_id'||wwv_flow.LF||
'                ) loop '||wwv_flow.LF||
'                    if p_delete_type = ''ALL'' then '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(147) := '            delete_event_l (p_event_id => c2.event_id); '||wwv_flow.LF||
'                    elsif p_delete_type = ''';
wwv_flow_imp.g_varchar2_table(148) := 'FUTURE'' then '||wwv_flow.LF||
'                        -- delete future '||wwv_flow.LF||
'                        if c2.event_date >= ';
wwv_flow_imp.g_varchar2_table(149) := 'c1.event_date then '||wwv_flow.LF||
'                            delete_event_l (p_event_id => c2.event_id); '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(150) := '                 end if; '||wwv_flow.LF||
'                    end if; '||wwv_flow.LF||
'                end loop; '||wwv_flow.LF||
'                --';
wwv_flow_imp.g_varchar2_table(151) := ' if no more events in the series, delete the series '||wwv_flow.LF||
'                select count(*) '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(152) := '    into l_event_cnt '||wwv_flow.LF||
'                  from sp_events '||wwv_flow.LF||
'                 where series_id = c1.series';
wwv_flow_imp.g_varchar2_table(153) := '_id; '||wwv_flow.LF||
'                if l_event_cnt = 0 then '||wwv_flow.LF||
'                    delete_series_l (p_series_id => c';
wwv_flow_imp.g_varchar2_table(154) := '1.series_id); '||wwv_flow.LF||
'                else '||wwv_flow.LF||
'                    -- update series end date '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(155) := '    for c2 in ( '||wwv_flow.LF||
'                        select max(event_date) last_date '||wwv_flow.LF||
'                         ';
wwv_flow_imp.g_varchar2_table(156) := ' from sp_events '||wwv_flow.LF||
'                         where series_id = c1.series_id'||wwv_flow.LF||
'                    ) loop ';
wwv_flow_imp.g_varchar2_table(157) := ''||wwv_flow.LF||
'                        update_series_end_date_l ( '||wwv_flow.LF||
'                            p_series_id => c1.s';
wwv_flow_imp.g_varchar2_table(158) := 'eries_id, '||wwv_flow.LF||
'                            p_end_date  => c2.last_date ); '||wwv_flow.LF||
'                    end loop;';
wwv_flow_imp.g_varchar2_table(159) := ' '||wwv_flow.LF||
'                end if; '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'        end if; '||wwv_flow.LF||
'    end loop; '||wwv_flow.LF||
'end delete_event; '||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(160) := ''||wwv_flow.LF||
'procedure update_event ( '||wwv_flow.LF||
'    p_event_id         number, '||wwv_flow.LF||
'    p_event_type_id    number, '||wwv_flow.LF||
'    p_eve';
wwv_flow_imp.g_varchar2_table(161) := 'nt_date       timestamp with time zone, '||wwv_flow.LF||
'    p_event_name       varchar2, '||wwv_flow.LF||
'    p_for_user_id      nu';
wwv_flow_imp.g_varchar2_table(162) := 'mber,'||wwv_flow.LF||
'    p_event_details    varchar2, '||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    p_recur_freq       varchar2, '||wwv_flow.LF||
'    p_recur_end_da';
wwv_flow_imp.g_varchar2_table(163) := 'te   timestamp with time zone, '||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    p_update_type      varchar2 ) -- ONLY, ALL, FUTURE (usua';
wwv_flow_imp.g_varchar2_table(164) := 'lly ONLY if not series)'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_series_id        number; '||wwv_flow.LF||
'    l_event_cnt        number; '||wwv_flow.LF||
'begin '||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(165) := '    for c1 in ( '||wwv_flow.LF||
'        select event_type_id, event_date, event_name, '||wwv_flow.LF||
'               for_user_id, ';
wwv_flow_imp.g_varchar2_table(166) := 'event_details,'||wwv_flow.LF||
'               series_id '||wwv_flow.LF||
'          from sp_events '||wwv_flow.LF||
'         where id = p_event_id'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(167) := '  ) loop '||wwv_flow.LF||
'        -- simple update '||wwv_flow.LF||
'        if p_recur_freq is null and c1.series_id is null then '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(168) := '           update_event_l ( '||wwv_flow.LF||
'                p_event_id      => p_event_id, '||wwv_flow.LF||
'                p_event';
wwv_flow_imp.g_varchar2_table(169) := '_type_id => p_event_type_id, '||wwv_flow.LF||
'                p_event_name    => p_event_name, '||wwv_flow.LF||
'                p_ev';
wwv_flow_imp.g_varchar2_table(170) := 'ent_date    => p_event_date, '||wwv_flow.LF||
'                p_for_user_id   => p_for_user_id,'||wwv_flow.LF||
'                p_ev';
wwv_flow_imp.g_varchar2_table(171) := 'ent_details => p_event_details ); '||wwv_flow.LF||
'        -- adding recurrence (remove event and recreate as series';
wwv_flow_imp.g_varchar2_table(172) := ') '||wwv_flow.LF||
'        elsif p_recur_freq is not null and c1.series_id is null then '||wwv_flow.LF||
'            delete_event_l ';
wwv_flow_imp.g_varchar2_table(173) := '(p_event_id => p_event_id); '||wwv_flow.LF||
'            l_series_id := create_series_l ( '||wwv_flow.LF||
'                         ';
wwv_flow_imp.g_varchar2_table(174) := '      p_start_date  => p_event_date, '||wwv_flow.LF||
'                               p_end_date    => p_recur_end_da';
wwv_flow_imp.g_varchar2_table(175) := 'te, '||wwv_flow.LF||
'                               p_recur_freq  => p_recur_freq ); '||wwv_flow.LF||
'            create_recur_event';
wwv_flow_imp.g_varchar2_table(176) := 's_l ( '||wwv_flow.LF||
'                p_series_id     => l_series_id,'||wwv_flow.LF||
'                p_event_type_id => p_event_ty';
wwv_flow_imp.g_varchar2_table(177) := 'pe_id, '||wwv_flow.LF||
'                p_event_name    => p_event_name, '||wwv_flow.LF||
'                p_for_user_id   => p_for_u';
wwv_flow_imp.g_varchar2_table(178) := 'ser_id,'||wwv_flow.LF||
'                p_event_details => p_event_details );'||wwv_flow.LF||
'        -- removing recurrence '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(179) := '  elsif p_recur_freq is null and c1.series_id is not null then '||wwv_flow.LF||
'            -- update event, delete ';
wwv_flow_imp.g_varchar2_table(180) := 'rest of events and series '||wwv_flow.LF||
'            update_event_l ( '||wwv_flow.LF||
'                p_event_id      => p_event_';
wwv_flow_imp.g_varchar2_table(181) := 'id, '||wwv_flow.LF||
'                p_event_type_id => p_event_type_id, '||wwv_flow.LF||
'                p_event_name    => p_event';
wwv_flow_imp.g_varchar2_table(182) := '_name, '||wwv_flow.LF||
'                p_event_date    => p_event_date, '||wwv_flow.LF||
'                p_for_user_id   => p_for_u';
wwv_flow_imp.g_varchar2_table(183) := 'ser_id,'||wwv_flow.LF||
'                p_event_details => p_event_details,'||wwv_flow.LF||
'                p_series_id     => null ';
wwv_flow_imp.g_varchar2_table(184) := '); '||wwv_flow.LF||
'            -- delete rest by series_id and then delete series '||wwv_flow.LF||
'            for c2 in ( '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(185) := '         select id event_id '||wwv_flow.LF||
'                  from sp_events '||wwv_flow.LF||
'                 where series_id = c1';
wwv_flow_imp.g_varchar2_table(186) := '.series_id'||wwv_flow.LF||
'            ) loop '||wwv_flow.LF||
'                delete_event_l (p_event_id => c2.event_id); '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(187) := '    end loop; '||wwv_flow.LF||
'            delete_series_l (p_series_id => c1.series_id); '||wwv_flow.LF||
'        -- updating recur';
wwv_flow_imp.g_varchar2_table(188) := 'ring event '||wwv_flow.LF||
'        elsif p_recur_freq is not null and c1.series_id is not null then '||wwv_flow.LF||
'            --';
wwv_flow_imp.g_varchar2_table(189) := ' updating standard columns '||wwv_flow.LF||
'            if p_event_type_id != c1.event_type_id or'||wwv_flow.LF||
'               nvl';
wwv_flow_imp.g_varchar2_table(190) := '(p_event_name,''~'') != nvl(c1.event_name,''~'') or '||wwv_flow.LF||
'               nvl(p_for_user_id,-1) != nvl(c1.for_';
wwv_flow_imp.g_varchar2_table(191) := 'user_id,-1) or'||wwv_flow.LF||
'               nvl(p_event_details,''~'') != nvl(c1.event_details,''~'')'||wwv_flow.LF||
'            then';
wwv_flow_imp.g_varchar2_table(192) := ' '||wwv_flow.LF||
'                if p_update_type = ''ONLY'' then '||wwv_flow.LF||
'                    update_event_l ( '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(193) := '            p_event_id      => p_event_id, '||wwv_flow.LF||
'                        p_event_type_id => p_event_type_';
wwv_flow_imp.g_varchar2_table(194) := 'id, '||wwv_flow.LF||
'                        p_event_name    => p_event_name, '||wwv_flow.LF||
'                        p_event_date ';
wwv_flow_imp.g_varchar2_table(195) := '   => c1.event_date, -- passing base value so no update '||wwv_flow.LF||
'                        p_for_user_id   => ';
wwv_flow_imp.g_varchar2_table(196) := 'p_for_user_id, '||wwv_flow.LF||
'                        p_event_details => p_event_details, '||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(197) := ' p_series_id     => c1.series_id ); '||wwv_flow.LF||
'                else '||wwv_flow.LF||
'                    for c2 in ( '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(198) := '                select id event_id, event_date'||wwv_flow.LF||
'                          from sp_events '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(199) := '              where series_id = c1.series_id'||wwv_flow.LF||
'                    ) loop '||wwv_flow.LF||
'                        if ';
wwv_flow_imp.g_varchar2_table(200) := 'p_update_type = ''ALL'' then '||wwv_flow.LF||
'                            update_event_l ( '||wwv_flow.LF||
'                          ';
wwv_flow_imp.g_varchar2_table(201) := '      p_event_id      => c2.event_id, '||wwv_flow.LF||
'                                p_event_type_id => p_event_ty';
wwv_flow_imp.g_varchar2_table(202) := 'pe_id, '||wwv_flow.LF||
'                                p_event_name    => p_event_name, '||wwv_flow.LF||
'                          ';
wwv_flow_imp.g_varchar2_table(203) := '      p_event_date    => c2.event_date, -- passing base value so no update '||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(204) := '        p_for_user_id   => p_for_user_id, '||wwv_flow.LF||
'                                p_event_details => p_even';
wwv_flow_imp.g_varchar2_table(205) := 't_details, '||wwv_flow.LF||
'                                p_series_id     => c1.series_id ); '||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(206) := '    elsif p_update_type = ''FUTURE'' then '||wwv_flow.LF||
'                            if c2.event_date >= c1.event_da';
wwv_flow_imp.g_varchar2_table(207) := 'te then '||wwv_flow.LF||
'                                update_event_l ( '||wwv_flow.LF||
'                                    p_eve';
wwv_flow_imp.g_varchar2_table(208) := 'nt_id      => c2.event_id, '||wwv_flow.LF||
'                                    p_event_type_id => p_event_type_id, ';
wwv_flow_imp.g_varchar2_table(209) := ''||wwv_flow.LF||
'                                    p_event_name    => p_event_name, '||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(210) := '       p_event_date    => c2.event_date, -- passing base value so no update '||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(211) := '             p_for_user_id   => p_for_user_id, '||wwv_flow.LF||
'                                    p_event_details ';
wwv_flow_imp.g_varchar2_table(212) := '=> p_event_details, '||wwv_flow.LF||
'                                    p_series_id     => c1.series_id ); '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(213) := '                     end if; '||wwv_flow.LF||
'                        end if; '||wwv_flow.LF||
'                    end loop; '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(214) := '          end if; '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
''||wwv_flow.LF||
'            -- update non-standard columns '||wwv_flow.LF||
'            for';
wwv_flow_imp.g_varchar2_table(215) := ' c2 in ( '||wwv_flow.LF||
'                select recur_freq, end_date '||wwv_flow.LF||
'                  from sp_event_series '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(216) := '            where id = c1.series_id'||wwv_flow.LF||
'            ) loop '||wwv_flow.LF||
'                 if p_recur_freq != c2.recur';
wwv_flow_imp.g_varchar2_table(217) := '_freq then '||wwv_flow.LF||
'                     if p_update_type = ''ALL'' then '||wwv_flow.LF||
'                         for c3 in (';
wwv_flow_imp.g_varchar2_table(218) := ' '||wwv_flow.LF||
'                             select id event_id '||wwv_flow.LF||
'                               from sp_events '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(219) := '                            where series_id = c1.series_id'||wwv_flow.LF||
'                         ) loop '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(220) := '                     delete_event_l (p_event_id => c3.event_id); '||wwv_flow.LF||
'                         end loop;';
wwv_flow_imp.g_varchar2_table(221) := ' '||wwv_flow.LF||
'                         delete_series_l (p_series_id => c1.series_id); '||wwv_flow.LF||
'                         ';
wwv_flow_imp.g_varchar2_table(222) := 'l_series_id := create_series_l ( '||wwv_flow.LF||
'                                            p_start_date  => p_eve';
wwv_flow_imp.g_varchar2_table(223) := 'nt_date, '||wwv_flow.LF||
'                                            p_end_date    => p_recur_end_date, '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(224) := '                                  p_recur_freq  => p_recur_freq ); '||wwv_flow.LF||
'                         create_';
wwv_flow_imp.g_varchar2_table(225) := 'recur_events_l ( '||wwv_flow.LF||
'                             p_series_id     => l_series_id,'||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(226) := '        p_event_type_id => p_event_type_id, '||wwv_flow.LF||
'                             p_event_name    => p_event';
wwv_flow_imp.g_varchar2_table(227) := '_name, '||wwv_flow.LF||
'                             p_for_user_id   => p_for_user_id, '||wwv_flow.LF||
'                            ';
wwv_flow_imp.g_varchar2_table(228) := ' p_event_details => p_event_details ); '||wwv_flow.LF||
'                     elsif p_update_type = ''FUTURE'' then '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(229) := '                       -- drop and recreate future only as new series '||wwv_flow.LF||
'                         for ';
wwv_flow_imp.g_varchar2_table(230) := 'c3 in ( '||wwv_flow.LF||
'                             select id event_id, event_date'||wwv_flow.LF||
'                               ';
wwv_flow_imp.g_varchar2_table(231) := 'from sp_events '||wwv_flow.LF||
'                              where series_id = c1.series_id'||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(232) := '  ) loop '||wwv_flow.LF||
'                             if c3.event_date >= c1.event_date then '||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(233) := '            delete_event_l (p_event_id => c3.event_id); '||wwv_flow.LF||
'                             end if; '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(234) := '                    end loop; '||wwv_flow.LF||
'                         select count(*) '||wwv_flow.LF||
'                           ';
wwv_flow_imp.g_varchar2_table(235) := 'into l_event_cnt '||wwv_flow.LF||
'                           from sp_events '||wwv_flow.LF||
'                          where series_';
wwv_flow_imp.g_varchar2_table(236) := 'id = c1.series_id; '||wwv_flow.LF||
'                         -- if no more events in the series, delete the series '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(237) := '                         if l_event_cnt = 0 then '||wwv_flow.LF||
'                            delete_series_l (p_ser';
wwv_flow_imp.g_varchar2_table(238) := 'ies_id => c1.series_id); '||wwv_flow.LF||
'                         else '||wwv_flow.LF||
'                             -- update seri';
wwv_flow_imp.g_varchar2_table(239) := 'es end date '||wwv_flow.LF||
'                             for c3 in ( '||wwv_flow.LF||
'                                 select max(e';
wwv_flow_imp.g_varchar2_table(240) := 'vent_date) last_date '||wwv_flow.LF||
'                                   from sp_events '||wwv_flow.LF||
'                           ';
wwv_flow_imp.g_varchar2_table(241) := '       where series_id = c1.series_id'||wwv_flow.LF||
'                             ) loop '||wwv_flow.LF||
'                         ';
wwv_flow_imp.g_varchar2_table(242) := '        update_series_end_date_l ( '||wwv_flow.LF||
'                                     p_series_id => c1.series_id';
wwv_flow_imp.g_varchar2_table(243) := ', '||wwv_flow.LF||
'                                     p_end_date  => c3.last_date ); '||wwv_flow.LF||
'                            ';
wwv_flow_imp.g_varchar2_table(244) := ' end loop; '||wwv_flow.LF||
'                         end if; '||wwv_flow.LF||
'                         l_series_id := create_series_';
wwv_flow_imp.g_varchar2_table(245) := 'l ( '||wwv_flow.LF||
'                                            p_start_date  => p_event_date, '||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(246) := '                         p_end_date    => p_recur_end_date, '||wwv_flow.LF||
'                                       ';
wwv_flow_imp.g_varchar2_table(247) := '     p_recur_freq  => p_recur_freq ); '||wwv_flow.LF||
'                         create_recur_events_l ( '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(248) := '                  p_series_id     => l_series_id,'||wwv_flow.LF||
'                             p_event_type_id => p_';
wwv_flow_imp.g_varchar2_table(249) := 'event_type_id,'||wwv_flow.LF||
'                             p_event_name    => p_event_name, '||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(250) := '       p_for_user_id   => p_for_user_id, '||wwv_flow.LF||
'                             p_event_details => p_event_de';
wwv_flow_imp.g_varchar2_table(251) := 'tails ); '||wwv_flow.LF||
'                     end if; '||wwv_flow.LF||
'                 else -- no freq change, date change '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(252) := '               if p_event_date != c1.event_date then '||wwv_flow.LF||
'                         if p_update_type = ''O';
wwv_flow_imp.g_varchar2_table(253) := 'NLY'' then '||wwv_flow.LF||
'                             update_event_l ( '||wwv_flow.LF||
'                                 p_event_i';
wwv_flow_imp.g_varchar2_table(254) := 'd      => p_event_id, '||wwv_flow.LF||
'                                 p_event_type_id => p_event_type_id,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(255) := '                         p_event_date    => p_event_date,'||wwv_flow.LF||
'                                 p_event_n';
wwv_flow_imp.g_varchar2_table(256) := 'ame    => p_event_name, '||wwv_flow.LF||
'                                 p_for_user_id   => p_for_user_id, '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(257) := '                          p_event_details => p_event_details, '||wwv_flow.LF||
'                                 p_se';
wwv_flow_imp.g_varchar2_table(258) := 'ries_id     => c1.series_id ); '||wwv_flow.LF||
'                         elsif p_update_type = ''ALL'' then '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(259) := '                    -- drop and recreate '||wwv_flow.LF||
'                             for c3 in ( '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(260) := '                 select id event_id'||wwv_flow.LF||
'                                   from sp_events '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(261) := '                     where series_id = c1.series_id'||wwv_flow.LF||
'                             ) loop '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(262) := '                      delete_event_l (p_event_id => c3.event_id); '||wwv_flow.LF||
'                             end ';
wwv_flow_imp.g_varchar2_table(263) := 'loop; '||wwv_flow.LF||
'                             delete_series_l (p_series_id => c1.series_id); '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(264) := '             l_series_id := create_series_l ( '||wwv_flow.LF||
'                                                p_sta';
wwv_flow_imp.g_varchar2_table(265) := 'rt_date  => p_event_date, '||wwv_flow.LF||
'                                                p_end_date    => p_recur_';
wwv_flow_imp.g_varchar2_table(266) := 'end_date, '||wwv_flow.LF||
'                                                p_recur_freq  => p_recur_freq ); '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(267) := '                      create_recur_events_l ( '||wwv_flow.LF||
'                                 p_series_id     => l';
wwv_flow_imp.g_varchar2_table(268) := '_series_id,'||wwv_flow.LF||
'                                 p_event_type_id => p_event_type_id,'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(269) := '              p_event_name    => p_event_name,  '||wwv_flow.LF||
'                                 p_for_user_id   =>';
wwv_flow_imp.g_varchar2_table(270) := ' p_for_user_id, '||wwv_flow.LF||
'                                 p_event_details => p_event_details ); '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(271) := '              elsif p_update_type = ''FUTURE'' then '||wwv_flow.LF||
'                             -- drop and recreate';
wwv_flow_imp.g_varchar2_table(272) := ' future only as new series '||wwv_flow.LF||
'                             for c3 in ( '||wwv_flow.LF||
'                              ';
wwv_flow_imp.g_varchar2_table(273) := '   select id event_id, event_date '||wwv_flow.LF||
'                                   from sp_events '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(274) := '                    where series_id = c1.series_id'||wwv_flow.LF||
'                             ) loop '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(275) := '                     if c3.event_date >= c1.event_date then '||wwv_flow.LF||
'                                     de';
wwv_flow_imp.g_varchar2_table(276) := 'lete_event_l (p_event_id => c3.event_id); '||wwv_flow.LF||
'                                 end if; '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(277) := '              end loop; '||wwv_flow.LF||
'                             select count(*) '||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(278) := '  into l_event_cnt '||wwv_flow.LF||
'                               from sp_events '||wwv_flow.LF||
'                              whe';
wwv_flow_imp.g_varchar2_table(279) := 're series_id = c1.series_id; '||wwv_flow.LF||
'                             -- if no more events in the series, delet';
wwv_flow_imp.g_varchar2_table(280) := 'e the series '||wwv_flow.LF||
'                             if l_event_cnt = 0 then '||wwv_flow.LF||
'                                ';
wwv_flow_imp.g_varchar2_table(281) := ' delete_series_l (p_series_id => c1.series_id); '||wwv_flow.LF||
'                             else '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(282) := '                 -- update series end date '||wwv_flow.LF||
'                                 for c3 in ( '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(283) := '                           select max(event_date) last_date '||wwv_flow.LF||
'                                       ';
wwv_flow_imp.g_varchar2_table(284) := 'from sp_events '||wwv_flow.LF||
'                                      where series_id = c1.series_id'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(285) := '                  ) loop '||wwv_flow.LF||
'                                     update_series_end_date_l ( '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(286) := '                                p_series_id => c1.series_id, '||wwv_flow.LF||
'                                      ';
wwv_flow_imp.g_varchar2_table(287) := '   p_end_date  => c3.last_date ); '||wwv_flow.LF||
'                                 end loop; '||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(288) := '        end if; '||wwv_flow.LF||
'                             l_series_id := create_series_l ( '||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(289) := '                            p_start_date  => p_event_date, '||wwv_flow.LF||
'                                        ';
wwv_flow_imp.g_varchar2_table(290) := '        p_end_date    => p_recur_end_date, '||wwv_flow.LF||
'                                                p_recur_';
wwv_flow_imp.g_varchar2_table(291) := 'freq  => p_recur_freq ); '||wwv_flow.LF||
'                             create_recur_events_l ( '||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(292) := '             p_series_id     => l_series_id,'||wwv_flow.LF||
'                                 p_event_type_id => p_e';
wwv_flow_imp.g_varchar2_table(293) := 'vent_type_id,'||wwv_flow.LF||
'                                 p_event_name    => p_event_name,  '||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(294) := '               p_for_user_id   => p_for_user_id, '||wwv_flow.LF||
'                                 p_event_details =';
wwv_flow_imp.g_varchar2_table(295) := '> p_event_details ); '||wwv_flow.LF||
'                         end if; '||wwv_flow.LF||
'                     end if; '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(296) := '       -- recur_end_date change, remove or add events '||wwv_flow.LF||
'                     if p_recur_end_date != c';
wwv_flow_imp.g_varchar2_table(297) := '2.end_date then '||wwv_flow.LF||
'                         -- when new end date earlier '||wwv_flow.LF||
'                         if ';
wwv_flow_imp.g_varchar2_table(298) := 'p_recur_end_date < c2.end_date then '||wwv_flow.LF||
'                             -- remove future events '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(299) := '                    for c3 in ( '||wwv_flow.LF||
'                                 select id event_id, event_date'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(300) := '                                from sp_events '||wwv_flow.LF||
'                                  where series_id = ';
wwv_flow_imp.g_varchar2_table(301) := 'c1.series_id'||wwv_flow.LF||
'                             ) loop '||wwv_flow.LF||
'                                 if c3.event_date ';
wwv_flow_imp.g_varchar2_table(302) := '> p_recur_end_date then '||wwv_flow.LF||
'                                     delete_event_l (p_event_id => c3.event';
wwv_flow_imp.g_varchar2_table(303) := '_id); '||wwv_flow.LF||
'                                 end if; '||wwv_flow.LF||
'                             end loop; '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(304) := '                  -- update series end date '||wwv_flow.LF||
'                             for c3 in ( '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(305) := '                    select max(event_date) last_date '||wwv_flow.LF||
'                                   from sp_eve';
wwv_flow_imp.g_varchar2_table(306) := 'nts '||wwv_flow.LF||
'                                  where series_id = c1.series_id'||wwv_flow.LF||
'                             )';
wwv_flow_imp.g_varchar2_table(307) := ' loop '||wwv_flow.LF||
'                                 update_series_end_date_l ( '||wwv_flow.LF||
'                                ';
wwv_flow_imp.g_varchar2_table(308) := '     p_series_id => c1.series_id, '||wwv_flow.LF||
'                                     p_end_date  => c3.last_date ';
wwv_flow_imp.g_varchar2_table(309) := '); '||wwv_flow.LF||
'                             end loop; '||wwv_flow.LF||
'                         -- new end date after, update s';
wwv_flow_imp.g_varchar2_table(310) := 'eries and add events '||wwv_flow.LF||
'                         else '||wwv_flow.LF||
'                             update_series_end_';
wwv_flow_imp.g_varchar2_table(311) := 'date_l ( '||wwv_flow.LF||
'                                 p_series_id => c1.series_id, '||wwv_flow.LF||
'                           ';
wwv_flow_imp.g_varchar2_table(312) := '      p_end_date  => p_recur_end_date); '||wwv_flow.LF||
'                             for c3 in ( '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(313) := '                select max(event_date) last_date '||wwv_flow.LF||
'                                   from sp_events ';
wwv_flow_imp.g_varchar2_table(314) := ''||wwv_flow.LF||
'                                  where series_id = c1.series_id'||wwv_flow.LF||
'                             ) loo';
wwv_flow_imp.g_varchar2_table(315) := 'p '||wwv_flow.LF||
'                                 create_more_recur_events_l ( '||wwv_flow.LF||
'                                  ';
wwv_flow_imp.g_varchar2_table(316) := '   p_event_type_id   => p_event_type_id,'||wwv_flow.LF||
'                                     p_last_event_date => c';
wwv_flow_imp.g_varchar2_table(317) := '3.last_date, '||wwv_flow.LF||
'                                     p_event_name      => p_event_name,  '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(318) := '                         p_for_user_id     => p_for_user_id, '||wwv_flow.LF||
'                                     p';
wwv_flow_imp.g_varchar2_table(319) := '_event_details   => p_event_details, '||wwv_flow.LF||
'                                     p_series_id       => c1.s';
wwv_flow_imp.g_varchar2_table(320) := 'eries_id ); '||wwv_flow.LF||
'                             end loop; '||wwv_flow.LF||
'                         end if; '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(321) := '        end if; '||wwv_flow.LF||
'                 end if; '||wwv_flow.LF||
'             end loop; '||wwv_flow.LF||
'         end if; '||wwv_flow.LF||
'     end loop; ';
wwv_flow_imp.g_varchar2_table(322) := ''||wwv_flow.LF||
'end update_event; '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'function days_out_summary ('||wwv_flow.LF||
'    p_user_id     ';
wwv_flow_imp.g_varchar2_table(323) := ' in  number'||wwv_flow.LF||
') return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_systimestamp       timestamp with time zone := systimestamp a';
wwv_flow_imp.g_varchar2_table(324) := 't time zone ''UTC'';'||wwv_flow.LF||
'    l_days               number := 14;'||wwv_flow.LF||
'    l_days_out_cnt       number := 0;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(325) := 'l_ooo_events         varchar2(4000);'||wwv_flow.LF||
'    l_general_event_cnt  number := 0;'||wwv_flow.LF||
'    l_general_events     ';
wwv_flow_imp.g_varchar2_table(326) := 'varchar2(4000);'||wwv_flow.LF||
'    l_return             varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select systi';
wwv_flow_imp.g_varchar2_table(327) := 'mestamp at time zone timezone user_sysdate'||wwv_flow.LF||
'          from sp_team_members'||wwv_flow.LF||
'         where id = p_user';
wwv_flow_imp.g_varchar2_table(328) := '_id'||wwv_flow.LF||
'           and timezone is not null'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        l_systimestamp := c1.user_sysdate;'||wwv_flow.LF||
'    en';
wwv_flow_imp.g_varchar2_table(329) := 'd loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_systimestamp := trunc(l_systimestamp);'||wwv_flow.LF||
''||wwv_flow.LF||
'    select count(unique(event_date)) days_out';
wwv_flow_imp.g_varchar2_table(330) := ''||wwv_flow.LF||
'      into l_days_out_cnt'||wwv_flow.LF||
'      from sp_events'||wwv_flow.LF||
'     where for_user_id = p_user_id'||wwv_flow.LF||
'       and event_';
wwv_flow_imp.g_varchar2_table(331) := 'date >= l_systimestamp'||wwv_flow.LF||
'       and event_date <= l_systimestamp + l_days'||wwv_flow.LF||
'       and to_char(event_dat';
wwv_flow_imp.g_varchar2_table(332) := 'e,''DY'') not in (''SAT'',''SUN'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_days_out_cnt > 0 then'||wwv_flow.LF||
'        select listagg(distinct t.even';
wwv_flow_imp.g_varchar2_table(333) := 't_type || case when e.event_name is not null'||wwv_flow.LF||
'                                                     th';
wwv_flow_imp.g_varchar2_table(334) := 'en '' - ''||e.event_name'||wwv_flow.LF||
'                                                     end, '', '' on overflow tr';
wwv_flow_imp.g_varchar2_table(335) := 'uncate with count)'||wwv_flow.LF||
'               within group (order by t.event_type)'||wwv_flow.LF||
'          into l_ooo_events'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(336) := '         from sp_events e,'||wwv_flow.LF||
'               sp_event_types t'||wwv_flow.LF||
'         where e.event_type_id = t.id'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(337) := '        and e.for_user_id = p_user_id'||wwv_flow.LF||
'           and e.event_date >= l_systimestamp'||wwv_flow.LF||
'           and e';
wwv_flow_imp.g_varchar2_table(338) := '.event_date <= l_systimestamp + l_days'||wwv_flow.LF||
'           and to_char(e.event_date,''DY'') not in (''SAT'',''SUN''';
wwv_flow_imp.g_varchar2_table(339) := ');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    select count(unique(event_date)) gen_events'||wwv_flow.LF||
'      into l_general_event_cnt'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(340) := ' from sp_events'||wwv_flow.LF||
'     where for_user_id is null'||wwv_flow.LF||
'       and event_date >= l_systimestamp'||wwv_flow.LF||
'       and ev';
wwv_flow_imp.g_varchar2_table(341) := 'ent_date <= l_systimestamp + l_days'||wwv_flow.LF||
'       and to_char(event_date,''DY'') not in (''SAT'',''SUN'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(342) := 'f l_general_event_cnt > 0 then'||wwv_flow.LF||
'        select listagg(distinct t.event_type||'' - ''||e.event_name, '',';
wwv_flow_imp.g_varchar2_table(343) := ' '' on overflow truncate with count)'||wwv_flow.LF||
'               within group (order by t.event_type)'||wwv_flow.LF||
'          in';
wwv_flow_imp.g_varchar2_table(344) := 'to l_general_events'||wwv_flow.LF||
'          from sp_events e,'||wwv_flow.LF||
'               sp_event_types t'||wwv_flow.LF||
'         where e.eve';
wwv_flow_imp.g_varchar2_table(345) := 'nt_type_id = t.id'||wwv_flow.LF||
'           and e.for_user_id is null'||wwv_flow.LF||
'           and e.event_date >= l_systimestamp';
wwv_flow_imp.g_varchar2_table(346) := ''||wwv_flow.LF||
'           and e.event_date <= l_systimestamp + l_days'||wwv_flow.LF||
'           and to_char(e.event_date,''DY'') no';
wwv_flow_imp.g_varchar2_table(347) := 't in (''SAT'',''SUN'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_days_out_cnt = 0 then'||wwv_flow.LF||
'        l_return := ''No Out of Offic';
wwv_flow_imp.g_varchar2_table(348) := 'e for next 2 weeks.'';'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        l_return := ''Out of Office ''|| l_days_out_cnt || '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(349) := '          case when l_days_out_cnt = 1 then '' weekday'' else '' weekdays'' end||'' over the next 2 weeks';
wwv_flow_imp.g_varchar2_table(350) := ' (''||l_ooo_events||'').'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_general_event_cnt > 0 then'||wwv_flow.LF||
'        l_return := l_retu';
wwv_flow_imp.g_varchar2_table(351) := 'rn|| '' May be affected by ''|| l_general_event_cnt || '||wwv_flow.LF||
'                     case when l_general_event';
wwv_flow_imp.g_varchar2_table(352) := '_cnt = 1 then '' weekday'' else '' weekdays'' end||'' with general events (''||l_general_events||'').'';'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(353) := ' end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_return;'||wwv_flow.LF||
''||wwv_flow.LF||
'end days_out_summary;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function days_out ('||wwv_flow.LF||
'    p_user_id      in  n';
wwv_flow_imp.g_varchar2_table(354) := 'umber'||wwv_flow.LF||
') return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_systimestamp       timestamp with time zone := systimestamp at time';
wwv_flow_imp.g_varchar2_table(355) := ' zone ''UTC'';'||wwv_flow.LF||
'    l_days               number := 14;'||wwv_flow.LF||
'    l_days_out_cnt       number := 0;'||wwv_flow.LF||
'    l_retu';
wwv_flow_imp.g_varchar2_table(356) := 'rn             varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select systimestamp at time zone timez';
wwv_flow_imp.g_varchar2_table(357) := 'one user_sysdate'||wwv_flow.LF||
'          from sp_team_members'||wwv_flow.LF||
'         where id = p_user_id'||wwv_flow.LF||
'           and timezon';
wwv_flow_imp.g_varchar2_table(358) := 'e is not null'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        l_systimestamp := c1.user_sysdate;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_systimestam';
wwv_flow_imp.g_varchar2_table(359) := 'p := trunc(l_systimestamp);'||wwv_flow.LF||
''||wwv_flow.LF||
'    select count(unique(event_date)) days_out'||wwv_flow.LF||
'      into l_days_out_cnt';
wwv_flow_imp.g_varchar2_table(360) := ''||wwv_flow.LF||
'      from sp_events'||wwv_flow.LF||
'     where for_user_id = p_user_id'||wwv_flow.LF||
'       and event_date >= l_systimestamp'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(361) := '    and event_date <= l_systimestamp + l_days'||wwv_flow.LF||
'       and to_char(event_date,''DY'') not in (''SAT'',''SUN';
wwv_flow_imp.g_varchar2_table(362) := ''');'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_days_out_cnt = 0 then'||wwv_flow.LF||
'        l_return := null;'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        l_return := ''Out of O';
wwv_flow_imp.g_varchar2_table(363) := 'ffice ''|| l_days_out_cnt || '||wwv_flow.LF||
'                     '' of next 10 work days'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l';
wwv_flow_imp.g_varchar2_table(364) := '_return;'||wwv_flow.LF||
''||wwv_flow.LF||
'end days_out;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure load_one_ooo ('||wwv_flow.LF||
'    p_team_member_id  in   number,'||wwv_flow.LF||
'    p_updated_';
wwv_flow_imp.g_varchar2_table(365) := 'yn      out  varchar2 )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_ooo_summary  varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    p_updated_yn := ''N'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    f';
wwv_flow_imp.g_varchar2_table(366) := 'or c1 in ('||wwv_flow.LF||
'        select id, ooo_summary'||wwv_flow.LF||
'          from sp_team_members'||wwv_flow.LF||
'         where id = p_team_';
wwv_flow_imp.g_varchar2_table(367) := 'member_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        l_ooo_summary := days_out (p_user_id     => c1.id);'||wwv_flow.LF||
''||wwv_flow.LF||
'        if nvl(l_o';
wwv_flow_imp.g_varchar2_table(368) := 'oo_summary,''~'') != nvl(c1.ooo_summary,''~'') then'||wwv_flow.LF||
'            update sp_team_members'||wwv_flow.LF||
'               se';
wwv_flow_imp.g_varchar2_table(369) := 't ooo_summary = l_ooo_summary'||wwv_flow.LF||
'             where id = c1.id;'||wwv_flow.LF||
'            commit;'||wwv_flow.LF||
'            p_updat';
wwv_flow_imp.g_varchar2_table(370) := 'ed_yn := ''Y'';'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'end load_one_ooo;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure load_all_ooo'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_app';
wwv_flow_imp.g_varchar2_table(371) := '_id         number;'||wwv_flow.LF||
'    l_count_sent     number := 0;'||wwv_flow.LF||
'    l_count_updated  number := 0;'||wwv_flow.LF||
'    l_update';
wwv_flow_imp.g_varchar2_table(372) := 'd_yn     varchar2(1);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_app_id := sp_util.get_setting (p_static_id => ''APP_ID'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- ';
wwv_flow_imp.g_varchar2_table(373) := 'when run from a job, need a session'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select workspace, workspace_id'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(374) := ' from apex_applications'||wwv_flow.LF||
'         where application_id = l_app_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        apex_util.set_wo';
wwv_flow_imp.g_varchar2_table(375) := 'rkspace (p_workspace => c1.workspace );'||wwv_flow.LF||
'        apex_util.set_security_group_id(p_security_group_id ';
wwv_flow_imp.g_varchar2_table(376) := '=> c1.workspace_id );'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- if build not not enabled, nothing will be run (careful t';
wwv_flow_imp.g_varchar2_table(377) := 'o not update build option names)'||wwv_flow.LF||
'    if apex_util.get_build_option_status ('||wwv_flow.LF||
'           p_application';
wwv_flow_imp.g_varchar2_table(378) := '_id    => l_app_id, '||wwv_flow.LF||
'           p_build_option_name => ''Team Calendar'') = ''INCLUDE'''||wwv_flow.LF||
'    then'||wwv_flow.LF||
''||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(379) := '  for c1 in ('||wwv_flow.LF||
'            select id'||wwv_flow.LF||
'              from sp_team_members'||wwv_flow.LF||
'             where is_current';
wwv_flow_imp.g_varchar2_table(380) := '_yn = ''Y'''||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            l_count_sent := l_count_sent + 1;'||wwv_flow.LF||
'            load_one_ooo ('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(381) := '              p_team_member_id => c1.id,'||wwv_flow.LF||
'                p_updated_yn     => l_updated_yn );'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(382) := '     if l_updated_yn = ''Y'' then'||wwv_flow.LF||
'                l_count_updated := l_count_updated + 1;'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(383) := 'end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'        sp_util.add_app_log ( '||wwv_flow.LF||
'            p_activity => ''sp_event_util.l';
wwv_flow_imp.g_varchar2_table(384) := 'oad_all_ooo'','||wwv_flow.LF||
'            p_details  => l_count_updated||'' of ''||l_count_sent||'' required update.'' )';
wwv_flow_imp.g_varchar2_table(385) := ';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'end load_all_ooo;'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_event_util;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(35718460349610827660)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_event_util body'
,p_sequence=>7100
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
