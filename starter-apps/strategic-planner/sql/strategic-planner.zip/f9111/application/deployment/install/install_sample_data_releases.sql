prompt --application/deployment/install/install_sample_data_releases
begin
--   Manifest
--     INSTALL: INSTALL-sample data - releases
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'sp_globals.g_audit_this := FALSE;'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_release_trains'||wwv_flow.LF||
'    (id, release_train, rele';
wwv_flow_imp.g_varchar2_table(2) := 'ase, release_owner_id, description, release_type,'||wwv_flow.LF||
'     release_target_date, release_open_date, relea';
wwv_flow_imp.g_varchar2_table(3) := 'se_open_completed, release_completed,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'    (1, ';
wwv_flow_imp.g_varchar2_table(4) := '''Cust Hub'', ''1.0'', 7, ''Web portal for account management, service requests, documents, billing, and ';
wwv_flow_imp.g_varchar2_table(5) := 'AI-assisted support.'', ''FULL'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-10), sp_util.fix_demo_dates(sysda';
wwv_flow_imp.g_varchar2_table(6) := 'te-100), ''Y'', ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-110), upper(''Caleb.Foster@acme.com''), sp_util';
wwv_flow_imp.g_varchar2_table(7) := '.fix_demo_dates(sysdate-8), upper(''Caleb.Foster@acme.com''));'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(8) := '(id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'     cre';
wwv_flow_imp.g_varchar2_table(9) := 'ated, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (10, 1, 1, ''Build Open'', sp_util.fix_demo_date';
wwv_flow_imp.g_varchar2_table(10) := 's(sysdate-100), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-110), upper(''Caleb.Foster@acme.com''), sp_ut';
wwv_flow_imp.g_varchar2_table(11) := 'il.fix_demo_dates(sysdate-100), upper(''Caleb.Foster@acme.com''));'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(12) := '   (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(13) := 'created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (11, 1, 3, ''Feature Complete'', sp_util.fix_';
wwv_flow_imp.g_varchar2_table(14) := 'demo_dates(sysdate-65), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-110), upper(''Caleb.Foster@acme.com''';
wwv_flow_imp.g_varchar2_table(15) := '), sp_util.fix_demo_dates(sysdate-65), upper(''Caleb.Foster@acme.com''));'||wwv_flow.LF||
'insert into sp_release_miles';
wwv_flow_imp.g_varchar2_table(16) := 'tones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_completed_yn';
wwv_flow_imp.g_varchar2_table(17) := ','||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (12, 1, 1, ''QA Build 1'', sp_util.fix';
wwv_flow_imp.g_varchar2_table(18) := '_demo_dates(sysdate-61), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-110), upper(''Caleb.Foster@acme.com';
wwv_flow_imp.g_varchar2_table(19) := '''), sp_util.fix_demo_dates(sysdate-61), upper(''Caleb.Foster@acme.com''));'||wwv_flow.LF||
'insert into sp_release_mile';
wwv_flow_imp.g_varchar2_table(20) := 'stones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_completed_y';
wwv_flow_imp.g_varchar2_table(21) := 'n,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (13, 1, 1, ''QA Build 2'', sp_util.fi';
wwv_flow_imp.g_varchar2_table(22) := 'x_demo_dates(sysdate-47), ''Y'','||wwv_flow.LF||
'    sp_util.fix_demo_dates(sysdate-110), upper(''Caleb.Foster@acme.com';
wwv_flow_imp.g_varchar2_table(23) := '''),  sp_util.fix_demo_dates(sysdate-47), upper(''Caleb.Foster@acme.com''));'||wwv_flow.LF||
'insert into sp_release_mil';
wwv_flow_imp.g_varchar2_table(24) := 'estones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_completed_';
wwv_flow_imp.g_varchar2_table(25) := 'yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (14, 1, 1, ''QA Build 3'', sp_util.f';
wwv_flow_imp.g_varchar2_table(26) := 'ix_demo_dates(sysdate-33), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-110), upper(''Caleb.Foster@acme.c';
wwv_flow_imp.g_varchar2_table(27) := 'om''), sp_util.fix_demo_dates(sysdate-33), upper(''Caleb.Foster@acme.com''));'||wwv_flow.LF||
'insert into sp_release_mi';
wwv_flow_imp.g_varchar2_table(28) := 'lestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_completed';
wwv_flow_imp.g_varchar2_table(29) := '_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (15, 1, 1, ''QA Build 4'', sp_util.';
wwv_flow_imp.g_varchar2_table(30) := 'fix_demo_dates(sysdate-19), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-110), upper(''Caleb.Foster@acme.';
wwv_flow_imp.g_varchar2_table(31) := 'com''), sp_util.fix_demo_dates(sysdate-19), upper(''Caleb.Foster@acme.com''));'||wwv_flow.LF||
'insert into sp_release_m';
wwv_flow_imp.g_varchar2_table(32) := 'ilestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_complete';
wwv_flow_imp.g_varchar2_table(33) := 'd_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (16, 1, 5, ''Translation Drop 1'',';
wwv_flow_imp.g_varchar2_table(34) := ' sp_util.fix_demo_dates(sysdate-45), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-110), upper(''Caleb.Fos';
wwv_flow_imp.g_varchar2_table(35) := 'ter@acme.com''), sp_util.fix_demo_dates(sysdate-45), upper(''Caleb.Foster@acme.com''));'||wwv_flow.LF||
'insert into sp_';
wwv_flow_imp.g_varchar2_table(36) := 'release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone';
wwv_flow_imp.g_varchar2_table(37) := '_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (17, 1, 5, ''Translation';
wwv_flow_imp.g_varchar2_table(38) := ' Drop 2'', sp_util.fix_demo_dates(sysdate-17), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-110), upper(''';
wwv_flow_imp.g_varchar2_table(39) := 'Caleb.Foster@acme.com''), sp_util.fix_demo_dates(sysdate-17), upper(''Caleb.Foster@acme.com''));'||wwv_flow.LF||
'insert';
wwv_flow_imp.g_varchar2_table(40) := ' into sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, ';
wwv_flow_imp.g_varchar2_table(41) := 'milestone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (18, 1, 2, ''Re';
wwv_flow_imp.g_varchar2_table(42) := 'lease Note Review'', sp_util.fix_demo_dates(sysdate-25), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-110';
wwv_flow_imp.g_varchar2_table(43) := '), upper(''Caleb.Foster@acme.com''), sp_util.fix_demo_dates(sysdate-25), upper(''Caleb.Foster@acme.com''';
wwv_flow_imp.g_varchar2_table(44) := '));'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milest';
wwv_flow_imp.g_varchar2_table(45) := 'one_date, milestone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (19,';
wwv_flow_imp.g_varchar2_table(46) := ' 1, 2, ''Release Notes Final'', sp_util.fix_demo_dates(sysdate-13), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(s';
wwv_flow_imp.g_varchar2_table(47) := 'ysdate-110), upper(''Caleb.Foster@acme.com''), sp_util.fix_demo_dates(sysdate-13), upper(''Caleb.Foster';
wwv_flow_imp.g_varchar2_table(48) := '@acme.com''));'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_na';
wwv_flow_imp.g_varchar2_table(49) := 'me, milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    value';
wwv_flow_imp.g_varchar2_table(50) := 's'||wwv_flow.LF||
'    (19.1, 1, 3, ''Code Freeze'', sp_util.fix_demo_dates(sysdate-17), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dat';
wwv_flow_imp.g_varchar2_table(51) := 'es(sysdate-110), upper(''Caleb.Foster@acme.com''), sp_util.fix_demo_dates(sysdate-17), upper(''Caleb.Fo';
wwv_flow_imp.g_varchar2_table(52) := 'ster@acme.com''));'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, mileston';
wwv_flow_imp.g_varchar2_table(53) := 'e_name, milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    v';
wwv_flow_imp.g_varchar2_table(54) := 'alues'||wwv_flow.LF||
'    (19.2, 1, 3, ''Release Complete'', sp_util.fix_demo_dates(sysdate-10), ''Y'','||wwv_flow.LF||
'     sp_util.fix';
wwv_flow_imp.g_varchar2_table(55) := '_demo_dates(sysdate-110), upper(''Caleb.Foster@acme.com''), sp_util.fix_demo_dates(sysdate-17), upper(';
wwv_flow_imp.g_varchar2_table(56) := '''Caleb.Foster@acme.com''));'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_release_trains'||wwv_flow.LF||
'    (id, release_train, release, release_';
wwv_flow_imp.g_varchar2_table(57) := 'owner_id, description, release_type,'||wwv_flow.LF||
'     release_target_date, release_open_date, release_open_compl';
wwv_flow_imp.g_varchar2_table(58) := 'eted, release_completed,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'    (2, ''Mobile Comp''';
wwv_flow_imp.g_varchar2_table(59) := ', ''1.0'', 3, ''Modern iOS and Android app for notifications, self-service workflows, mobile document u';
wwv_flow_imp.g_varchar2_table(60) := 'pload, and personalized recommendations.'',''FULL'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate+20), sp_util.f';
wwv_flow_imp.g_varchar2_table(61) := 'ix_demo_dates(sysdate-60), ''Y'', ''N'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-70), upper(''Elena.Vargas@ac';
wwv_flow_imp.g_varchar2_table(62) := 'me.com''), sp_util.fix_demo_dates(sysdate), upper(''Elena.Vargas@acme.com''));'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_release_';
wwv_flow_imp.g_varchar2_table(63) := 'milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_complet';
wwv_flow_imp.g_varchar2_table(64) := 'ed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (20, 2, 1, ''Build Open'', sp_uti';
wwv_flow_imp.g_varchar2_table(65) := 'l.fix_demo_dates(sysdate-60), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-70), upper(''Elena.Vargas@acme';
wwv_flow_imp.g_varchar2_table(66) := '.com''), sp_util.fix_demo_dates(sysdate-60), upper(''Elena.Vargas@acme.com''));'||wwv_flow.LF||
'insert into sp_release_';
wwv_flow_imp.g_varchar2_table(67) := 'milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_complet';
wwv_flow_imp.g_varchar2_table(68) := 'ed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (21, 2, 1, ''QA Build 1'', sp_uti';
wwv_flow_imp.g_varchar2_table(69) := 'l.fix_demo_dates(sysdate-30), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-70), upper(''Elena.Vargas@acme';
wwv_flow_imp.g_varchar2_table(70) := '.com''), sp_util.fix_demo_dates(sysdate-30), upper(''Elena.Vargas@acme.com''));'||wwv_flow.LF||
'insert into sp_release_';
wwv_flow_imp.g_varchar2_table(71) := 'milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_complet';
wwv_flow_imp.g_varchar2_table(72) := 'ed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (22, 2, 1, ''QA Build 2'', sp_uti';
wwv_flow_imp.g_varchar2_table(73) := 'l.fix_demo_dates(sysdate-16), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-70), upper(''Elena.Vargas@acme';
wwv_flow_imp.g_varchar2_table(74) := '.com''), sp_util.fix_demo_dates(sysdate-16), upper(''Elena.Vargas@acme.com''));'||wwv_flow.LF||
'insert into sp_release_';
wwv_flow_imp.g_varchar2_table(75) := 'milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_complet';
wwv_flow_imp.g_varchar2_table(76) := 'ed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (23, 2, 1, ''QA Build 3'', sp_uti';
wwv_flow_imp.g_varchar2_table(77) := 'l.fix_demo_dates(sysdate-2), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-70), upper(''Elena.Vargas@acme.';
wwv_flow_imp.g_varchar2_table(78) := 'com''), sp_util.fix_demo_dates(sysdate-2), upper(''Elena.Vargas@acme.com''));'||wwv_flow.LF||
'insert into sp_release_mi';
wwv_flow_imp.g_varchar2_table(79) := 'lestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_completed';
wwv_flow_imp.g_varchar2_table(80) := '_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (24, 2, 1, ''QA Build 4'', sp_util.';
wwv_flow_imp.g_varchar2_table(81) := 'fix_demo_dates(sysdate+12), ''N'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-70), upper(''Elena.Vargas@acme.c';
wwv_flow_imp.g_varchar2_table(82) := 'om''), sp_util.fix_demo_dates(sysdate), upper(''Elena.Vargas@acme.com''));'||wwv_flow.LF||
'insert into sp_release_miles';
wwv_flow_imp.g_varchar2_table(83) := 'tones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_completed_yn';
wwv_flow_imp.g_varchar2_table(84) := ','||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (25, 2, 3, ''Feature Complete'', sp_ut';
wwv_flow_imp.g_varchar2_table(85) := 'il.fix_demo_dates(sysdate-10), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-70), upper(''Elena.Vargas@acm';
wwv_flow_imp.g_varchar2_table(86) := 'e.com''), sp_util.fix_demo_dates(sysdate-10), upper(''Elena.Vargas@acme.com''));'||wwv_flow.LF||
'insert into sp_release';
wwv_flow_imp.g_varchar2_table(87) := '_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_comple';
wwv_flow_imp.g_varchar2_table(88) := 'ted_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (26, 2, 5, ''Translation Drop 1';
wwv_flow_imp.g_varchar2_table(89) := ''', sp_util.fix_demo_dates(sysdate-15), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-70), upper(''Elena.Va';
wwv_flow_imp.g_varchar2_table(90) := 'rgas@acme.com''), sp_util.fix_demo_dates(sysdate-15), upper(''Elena.Vargas@acme.com''));'||wwv_flow.LF||
'insert into sp';
wwv_flow_imp.g_varchar2_table(91) := '_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, mileston';
wwv_flow_imp.g_varchar2_table(92) := 'e_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (27, 2, 5, ''Translatio';
wwv_flow_imp.g_varchar2_table(93) := 'n Drop 2'', sp_util.fix_demo_dates(sysdate+13), ''N'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-70), upper(''';
wwv_flow_imp.g_varchar2_table(94) := 'Elena.Vargas@acme.com''), sp_util.fix_demo_dates(sysdate), upper(''Elena.Vargas@acme.com''));'||wwv_flow.LF||
'insert in';
wwv_flow_imp.g_varchar2_table(95) := 'to sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, mil';
wwv_flow_imp.g_varchar2_table(96) := 'estone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (28, 2, 2, ''Relea';
wwv_flow_imp.g_varchar2_table(97) := 'se Note Review'', sp_util.fix_demo_dates(sysdate+1), ''N'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-70), up';
wwv_flow_imp.g_varchar2_table(98) := 'per(''Elena.Vargas@acme.com''), sp_util.fix_demo_dates(sysdate), upper(''Elena.Vargas@acme.com''));'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(99) := 'rt into sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date';
wwv_flow_imp.g_varchar2_table(100) := ', milestone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (29, 2, 2, ''';
wwv_flow_imp.g_varchar2_table(101) := 'Release Notes Final'', sp_util.fix_demo_dates(sysdate+17), ''N'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-7';
wwv_flow_imp.g_varchar2_table(102) := '0), upper(''Elena.Vargas@acme.com''), sp_util.fix_demo_dates(sysdate), upper(''Elena.Vargas@acme.com''))';
wwv_flow_imp.g_varchar2_table(103) := ';'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, mileston';
wwv_flow_imp.g_varchar2_table(104) := 'e_date, milestone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (29.1,';
wwv_flow_imp.g_varchar2_table(105) := ' 2, 3, ''Code Freeze'', sp_util.fix_demo_dates(sysdate+13), ''N'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-7';
wwv_flow_imp.g_varchar2_table(106) := '0), upper(''Elena.Vargas@acme.com''), sp_util.fix_demo_dates(sysdate), upper(''Elena.Vargas@acme.com''))';
wwv_flow_imp.g_varchar2_table(107) := ';'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, mileston';
wwv_flow_imp.g_varchar2_table(108) := 'e_date, milestone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (29.2,';
wwv_flow_imp.g_varchar2_table(109) := ' 2, 3, ''Release Complete'', sp_util.fix_demo_dates(sysdate+20), ''N'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysd';
wwv_flow_imp.g_varchar2_table(110) := 'ate-70), upper(''Elena.Vargas@acme.com''), sp_util.fix_demo_dates(sysdate), upper(''Elena.Vargas@acme.c';
wwv_flow_imp.g_varchar2_table(111) := 'om''));'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_release_trains'||wwv_flow.LF||
'    (id, release_train, release, release_owner_id, descriptio';
wwv_flow_imp.g_varchar2_table(112) := 'n, release_type,'||wwv_flow.LF||
'     release_target_date, release_open_date, release_open_completed, release_comple';
wwv_flow_imp.g_varchar2_table(113) := 'ted,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'    (7, ''InsIQ'', ''1.0'', 14, ''Analytics an';
wwv_flow_imp.g_varchar2_table(114) := 'd machine-learning platform powering customer insights, recommendations, forecasting, and operationa';
wwv_flow_imp.g_varchar2_table(115) := 'l dashboards.'', ''FULL'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-90), sp_util.fix_demo_dates(sysdate-200)';
wwv_flow_imp.g_varchar2_table(116) := ', ''Y'', ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-220), upper(''Chloe.Whitaker@acme.com''), sp_util.fix_';
wwv_flow_imp.g_varchar2_table(117) := 'demo_dates(sysdate-88), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (i';
wwv_flow_imp.g_varchar2_table(118) := 'd, release_id, milestone_type_id, milestone_name, milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'     creat';
wwv_flow_imp.g_varchar2_table(119) := 'ed, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (70 ,7, 1, ''Build Open'', sp_util.fix_demo_dates(';
wwv_flow_imp.g_varchar2_table(120) := 'sysdate-200), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-220), upper(''Chloe.Whitaker@acme.com''), sp_ut';
wwv_flow_imp.g_varchar2_table(121) := 'il.fix_demo_dates(sysdate-200), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_release_milestones';
wwv_flow_imp.g_varchar2_table(122) := ''||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(123) := '  created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (71 ,7, 1, ''QA Build 1'', sp_util.fix_demo';
wwv_flow_imp.g_varchar2_table(124) := '_dates(sysdate-140), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-220), upper(''Chloe.Whitaker@acme.com'')';
wwv_flow_imp.g_varchar2_table(125) := ', sp_util.fix_demo_dates(sysdate-140), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_release_mil';
wwv_flow_imp.g_varchar2_table(126) := 'estones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_completed_';
wwv_flow_imp.g_varchar2_table(127) := 'yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (72 ,7, 1, ''QA Build 2'', sp_util.f';
wwv_flow_imp.g_varchar2_table(128) := 'ix_demo_dates(sysdate-126), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-220), upper(''Chloe.Whitaker@acm';
wwv_flow_imp.g_varchar2_table(129) := 'e.com''), sp_util.fix_demo_dates(sysdate-126), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_rele';
wwv_flow_imp.g_varchar2_table(130) := 'ase_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_com';
wwv_flow_imp.g_varchar2_table(131) := 'pleted_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (73 ,7, 1, ''QA Build 3'', sp';
wwv_flow_imp.g_varchar2_table(132) := '_util.fix_demo_dates(sysdate-112), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-220), upper(''Chloe.Whita';
wwv_flow_imp.g_varchar2_table(133) := 'ker@acme.com''), sp_util.fix_demo_dates(sysdate-112), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into ';
wwv_flow_imp.g_varchar2_table(134) := 'sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milest';
wwv_flow_imp.g_varchar2_table(135) := 'one_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (74 ,7, 1, ''QA Build';
wwv_flow_imp.g_varchar2_table(136) := ' 4'', sp_util.fix_demo_dates(sysdate-98), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-220), upper(''Chloe';
wwv_flow_imp.g_varchar2_table(137) := '.Whitaker@acme.com''), sp_util.fix_demo_dates(sysdate-98), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert ';
wwv_flow_imp.g_varchar2_table(138) := 'into sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, m';
wwv_flow_imp.g_varchar2_table(139) := 'ilestone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (75 ,7, 3, ''Fea';
wwv_flow_imp.g_varchar2_table(140) := 'ture Complete'', sp_util.fix_demo_dates(sysdate-125), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-220), ';
wwv_flow_imp.g_varchar2_table(141) := 'upper(''Chloe.Whitaker@acme.com''), sp_util.fix_demo_dates(sysdate-125), upper(''Chloe.Whitaker@acme.co';
wwv_flow_imp.g_varchar2_table(142) := 'm''));'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, mile';
wwv_flow_imp.g_varchar2_table(143) := 'stone_date, milestone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (7';
wwv_flow_imp.g_varchar2_table(144) := '6 ,7, 5, ''Translation Drop 1'', sp_util.fix_demo_dates(sysdate-145), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates';
wwv_flow_imp.g_varchar2_table(145) := '(sysdate-220), upper(''Chloe.Whitaker@acme.com''), sp_util.fix_demo_dates(sysdate-145), upper(''Chloe.W';
wwv_flow_imp.g_varchar2_table(146) := 'hitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, miles';
wwv_flow_imp.g_varchar2_table(147) := 'tone_name, milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(148) := '  values'||wwv_flow.LF||
'    (77 ,7, 5, ''Translation Drop 2'', sp_util.fix_demo_dates(sysdate-97), ''Y'','||wwv_flow.LF||
'     sp_util.';
wwv_flow_imp.g_varchar2_table(149) := 'fix_demo_dates(sysdate-220), upper(''Chloe.Whitaker@acme.com''), sp_util.fix_demo_dates(sysdate-97), u';
wwv_flow_imp.g_varchar2_table(150) := 'pper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_t';
wwv_flow_imp.g_varchar2_table(151) := 'ype_id, milestone_name, milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, u';
wwv_flow_imp.g_varchar2_table(152) := 'pdated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (78 ,7, 2, ''Release Note Review'', sp_util.fix_demo_dates(sysdate-110), ''Y''';
wwv_flow_imp.g_varchar2_table(153) := ','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-220), upper(''Chloe.Whitaker@acme.com''), sp_util.fix_demo_dates';
wwv_flow_imp.g_varchar2_table(154) := '(sysdate-110), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (id, release';
wwv_flow_imp.g_varchar2_table(155) := '_id, milestone_type_id, milestone_name, milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'     created, create';
wwv_flow_imp.g_varchar2_table(156) := 'd_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (79 ,7, 2, ''Release Notes Final'', sp_util.fix_demo_dates(s';
wwv_flow_imp.g_varchar2_table(157) := 'ysdate-93), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-220), upper(''Chloe.Whitaker@acme.com''), sp_util';
wwv_flow_imp.g_varchar2_table(158) := '.fix_demo_dates(sysdate-93), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(159) := '  (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'     c';
wwv_flow_imp.g_varchar2_table(160) := 'reated, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (79.1 ,7, 3, ''Code Freeze'', sp_util.fix_demo';
wwv_flow_imp.g_varchar2_table(161) := '_dates(sysdate-97), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-220), upper(''Chloe.Whitaker@acme.com''),';
wwv_flow_imp.g_varchar2_table(162) := ' sp_util.fix_demo_dates(sysdate-97), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_release_miles';
wwv_flow_imp.g_varchar2_table(163) := 'tones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_completed_yn';
wwv_flow_imp.g_varchar2_table(164) := ','||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (79.2 ,7, 3, ''Release Complete'', sp_';
wwv_flow_imp.g_varchar2_table(165) := 'util.fix_demo_dates(sysdate-90), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-220), upper(''Chloe.Whitake';
wwv_flow_imp.g_varchar2_table(166) := 'r@acme.com''), sp_util.fix_demo_dates(sysdate-90), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'insert into s';
wwv_flow_imp.g_varchar2_table(167) := 'p_release_trains'||wwv_flow.LF||
'    (id, release_train, release, release_owner_id, description, release_type,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(168) := 'release_target_date, release_open_date, release_open_completed, release_completed,'||wwv_flow.LF||
'     created, cre';
wwv_flow_imp.g_varchar2_table(169) := 'ated_by, updated, updated_by)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'    (8, ''InsIQ'', ''1.1'', 14, ''Improvements and bug fixes to 1.0''';
wwv_flow_imp.g_varchar2_table(170) := ', ''PATCH'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-25), sp_util.fix_demo_dates(sysdate-85), ''Y'', ''Y'','||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(171) := '   sp_util.fix_demo_dates(sysdate-95), upper(''Chloe.Whitaker@acme.com''), sp_util.fix_demo_dates(sysd';
wwv_flow_imp.g_varchar2_table(172) := 'ate-20), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, ';
wwv_flow_imp.g_varchar2_table(173) := 'milestone_type_id, milestone_name, milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'     created, created_by,';
wwv_flow_imp.g_varchar2_table(174) := ' updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (80, 8, 1, ''Build Open'', sp_util.fix_demo_dates(sysdate-85), ''Y';
wwv_flow_imp.g_varchar2_table(175) := ''','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-95), upper(''Chloe.Whitaker@acme.com''), sp_util.fix_demo_dates';
wwv_flow_imp.g_varchar2_table(176) := '(sysdate-85), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (id, release_';
wwv_flow_imp.g_varchar2_table(177) := 'id, milestone_type_id, milestone_name, milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'     created, created';
wwv_flow_imp.g_varchar2_table(178) := '_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (81, 8, 1, ''QA Build 1'', sp_util.fix_demo_dates(sysdate-55)';
wwv_flow_imp.g_varchar2_table(179) := ', ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-95), upper(''Chloe.Whitaker@acme.com''), sp_util.fix_demo_d';
wwv_flow_imp.g_varchar2_table(180) := 'ates(sysdate-55), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (id, rele';
wwv_flow_imp.g_varchar2_table(181) := 'ase_id, milestone_type_id, milestone_name, milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'     created, cre';
wwv_flow_imp.g_varchar2_table(182) := 'ated_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (82, 8, 1, ''QA Build 2'', sp_util.fix_demo_dates(sysdate';
wwv_flow_imp.g_varchar2_table(183) := '-41), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-95), upper(''Chloe.Whitaker@acme.com''), sp_util.fix_de';
wwv_flow_imp.g_varchar2_table(184) := 'mo_dates(sysdate-41), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (id, ';
wwv_flow_imp.g_varchar2_table(185) := 'release_id, milestone_type_id, milestone_name, milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'     created,';
wwv_flow_imp.g_varchar2_table(186) := ' created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (83, 8, 1, ''QA Build 3'', sp_util.fix_demo_dates(sys';
wwv_flow_imp.g_varchar2_table(187) := 'date-27), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-95), upper(''Chloe.Whitaker@acme.com''), sp_util.fi';
wwv_flow_imp.g_varchar2_table(188) := 'x_demo_dates(sysdate-27), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (';
wwv_flow_imp.g_varchar2_table(189) := 'id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'     crea';
wwv_flow_imp.g_varchar2_table(190) := 'ted, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (84, 8, 3, ''Feature Complete'', sp_util.fix_demo';
wwv_flow_imp.g_varchar2_table(191) := '_dates(sysdate-50), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-95), upper(''Chloe.Whitaker@acme.com''), ';
wwv_flow_imp.g_varchar2_table(192) := 'sp_util.fix_demo_dates(sysdate-50), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_release_milest';
wwv_flow_imp.g_varchar2_table(193) := 'ones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_completed_yn,';
wwv_flow_imp.g_varchar2_table(194) := ''||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (85, 8, 5, ''Translation Drop'', sp_uti';
wwv_flow_imp.g_varchar2_table(195) := 'l.fix_demo_dates(sysdate-32), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-95), upper(''Chloe.Whitaker@ac';
wwv_flow_imp.g_varchar2_table(196) := 'me.com''), sp_util.fix_demo_dates(sysdate-32), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_rele';
wwv_flow_imp.g_varchar2_table(197) := 'ase_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_com';
wwv_flow_imp.g_varchar2_table(198) := 'pleted_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (86, 8, 2, ''Release Note Re';
wwv_flow_imp.g_varchar2_table(199) := 'view'', sp_util.fix_demo_dates(sysdate-48), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-95), upper(''Chlo';
wwv_flow_imp.g_varchar2_table(200) := 'e.Whitaker@acme.com''), sp_util.fix_demo_dates(sysdate-48), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert';
wwv_flow_imp.g_varchar2_table(201) := ' into sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, ';
wwv_flow_imp.g_varchar2_table(202) := 'milestone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (87, 8, 2, ''Re';
wwv_flow_imp.g_varchar2_table(203) := 'lease Notes Final'', sp_util.fix_demo_dates(sysdate-28), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-95)';
wwv_flow_imp.g_varchar2_table(204) := ', upper(''Chloe.Whitaker@acme.com''), sp_util.fix_demo_dates(sysdate-28), upper(''Chloe.Whitaker@acme.c';
wwv_flow_imp.g_varchar2_table(205) := 'om''));'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, mil';
wwv_flow_imp.g_varchar2_table(206) := 'estone_date, milestone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (';
wwv_flow_imp.g_varchar2_table(207) := '88, 8, 3, ''Code Freeze'', sp_util.fix_demo_dates(sysdate-32), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdat';
wwv_flow_imp.g_varchar2_table(208) := 'e-95), upper(''Chloe.Whitaker@acme.com''), sp_util.fix_demo_dates(sysdate-32), upper(''Chloe.Whitaker@a';
wwv_flow_imp.g_varchar2_table(209) := 'cme.com''));'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name';
wwv_flow_imp.g_varchar2_table(210) := ', milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(211) := '    (89, 8, 3, ''Release Complete'', sp_util.fix_demo_dates(sysdate-25), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(212) := 'tes(sysdate-95), upper(''Chloe.Whitaker@acme.com''), sp_util.fix_demo_dates(sysdate-25), upper(''Chloe.';
wwv_flow_imp.g_varchar2_table(213) := 'Whitaker@acme.com''));'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_release_trains'||wwv_flow.LF||
'    (id, release_train, release, release_owner';
wwv_flow_imp.g_varchar2_table(214) := '_id, description, release_type,'||wwv_flow.LF||
'     release_target_date, release_open_date, release_open_completed,';
wwv_flow_imp.g_varchar2_table(215) := ' release_completed,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'values'||wwv_flow.LF||
'    (3, ''InsIQ'', ''2.0'', 14';
wwv_flow_imp.g_varchar2_table(216) := ', ''Analytics and machine-learning platform powering customer insights, recommendations, forecasting,';
wwv_flow_imp.g_varchar2_table(217) := ' and operational dashboards.'', ''FULL'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate+27), sp_util.fix_demo_dat';
wwv_flow_imp.g_varchar2_table(218) := 'es(sysdate-60), ''Y'', ''N'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-70), upper(''Chloe.Whitaker@acme.com''),';
wwv_flow_imp.g_varchar2_table(219) := ' sp_util.fix_demo_dates(sysdate), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_release_milesto';
wwv_flow_imp.g_varchar2_table(220) := 'nes'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(221) := '     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (30, 3, 1, ''Build Open'', sp_util.fix_d';
wwv_flow_imp.g_varchar2_table(222) := 'emo_dates(sysdate-60), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-70), upper(''Chloe.Whitaker@acme.com''';
wwv_flow_imp.g_varchar2_table(223) := '), sp_util.fix_demo_dates(sysdate-60), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_release_mil';
wwv_flow_imp.g_varchar2_table(224) := 'estones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_completed_';
wwv_flow_imp.g_varchar2_table(225) := 'yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (31, 3, 1, ''QA Build 1'', sp_util.f';
wwv_flow_imp.g_varchar2_table(226) := 'ix_demo_dates(sysdate-15), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-70), upper(''Chloe.Whitaker@acme.';
wwv_flow_imp.g_varchar2_table(227) := 'com''), sp_util.fix_demo_dates(sysdate-15), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_release';
wwv_flow_imp.g_varchar2_table(228) := '_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_comple';
wwv_flow_imp.g_varchar2_table(229) := 'ted_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (32, 3, 1, ''QA Build 2'', sp_ut';
wwv_flow_imp.g_varchar2_table(230) := 'il.fix_demo_dates(sysdate-1), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-70), upper(''Chloe.Whitaker@ac';
wwv_flow_imp.g_varchar2_table(231) := 'me.com''), sp_util.fix_demo_dates(sysdate-1), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_relea';
wwv_flow_imp.g_varchar2_table(232) := 'se_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_comp';
wwv_flow_imp.g_varchar2_table(233) := 'leted_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (33, 3, 1, ''QA Build 3'', sp_';
wwv_flow_imp.g_varchar2_table(234) := 'util.fix_demo_dates(sysdate+13), ''N'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-70), upper(''Chloe.Whitaker';
wwv_flow_imp.g_varchar2_table(235) := '@acme.com''), sp_util.fix_demo_dates(sysdate), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_rele';
wwv_flow_imp.g_varchar2_table(236) := 'ase_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, milestone_com';
wwv_flow_imp.g_varchar2_table(237) := 'pleted_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (34, 3, 3, ''Feature Complet';
wwv_flow_imp.g_varchar2_table(238) := 'e'', sp_util.fix_demo_dates(sysdate-5), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-70), upper(''Chloe.Wh';
wwv_flow_imp.g_varchar2_table(239) := 'itaker@acme.com''), sp_util.fix_demo_dates(sysdate-5), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(240) := ' sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone_date, miles';
wwv_flow_imp.g_varchar2_table(241) := 'tone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (35, 3, 5, ''Transla';
wwv_flow_imp.g_varchar2_table(242) := 'tion Drop 1'', sp_util.fix_demo_dates(sysdate-10), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdate-70), uppe';
wwv_flow_imp.g_varchar2_table(243) := 'r(''Chloe.Whitaker@acme.com''), sp_util.fix_demo_dates(sysdate-10), upper(''Chloe.Whitaker@acme.com''));';
wwv_flow_imp.g_varchar2_table(244) := ''||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, milestone';
wwv_flow_imp.g_varchar2_table(245) := '_date, milestone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (36, 3,';
wwv_flow_imp.g_varchar2_table(246) := ' 5, ''Translation Drop 2'', sp_util.fix_demo_dates(sysdate+20), ''N'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysda';
wwv_flow_imp.g_varchar2_table(247) := 'te-70), upper(''Chloe.Whitaker@acme.com''), sp_util.fix_demo_dates(sysdate), upper(''Chloe.Whitaker@acm';
wwv_flow_imp.g_varchar2_table(248) := 'e.com''));'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milestone_name, ';
wwv_flow_imp.g_varchar2_table(249) := 'milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(250) := '  (37, 3, 2, ''Release Note Review'', sp_util.fix_demo_dates(sysdate+7), ''N'','||wwv_flow.LF||
'     sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(251) := 'tes(sysdate-70), upper(''Chloe.Whitaker@acme.com''), sp_util.fix_demo_dates(sysdate), upper(''Chloe.Whi';
wwv_flow_imp.g_varchar2_table(252) := 'taker@acme.com''));'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_id, milesto';
wwv_flow_imp.g_varchar2_table(253) := 'ne_name, milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(254) := 'values'||wwv_flow.LF||
'    (38, 3, 2, ''Release Notes Final'', sp_util.fix_demo_dates(sysdate+24), ''N'','||wwv_flow.LF||
'     sp_util.f';
wwv_flow_imp.g_varchar2_table(255) := 'ix_demo_dates(sysdate-70), upper(''Chloe.Whitaker@acme.com''), sp_util.fix_demo_dates(sysdate), upper(';
wwv_flow_imp.g_varchar2_table(256) := '''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type_i';
wwv_flow_imp.g_varchar2_table(257) := 'd, milestone_name, milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, update';
wwv_flow_imp.g_varchar2_table(258) := 'd_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (39, 3, 3, ''Code Freeze'', sp_util.fix_demo_dates(sysdate+20), ''N'','||wwv_flow.LF||
'     sp_util';
wwv_flow_imp.g_varchar2_table(259) := '.fix_demo_dates(sysdate-70), upper(''Chloe.Whitaker@acme.com''), sp_util.fix_demo_dates(sysdate), uppe';
wwv_flow_imp.g_varchar2_table(260) := 'r(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_release_milestones'||wwv_flow.LF||
'    (id, release_id, milestone_type';
wwv_flow_imp.g_varchar2_table(261) := '_id, milestone_name, milestone_date, milestone_completed_yn,'||wwv_flow.LF||
'     created, created_by, updated, upda';
wwv_flow_imp.g_varchar2_table(262) := 'ted_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (39.1, 3, 3, ''Release Complete'', sp_util.fix_demo_dates(sysdate+27), ''N'','||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(263) := '  sp_util.fix_demo_dates(sysdate-70), upper(''Chloe.Whitaker@acme.com''), sp_util.fix_demo_dates(sysda';
wwv_flow_imp.g_varchar2_table(264) := 'te), upper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
''||wwv_flow.LF||
'sp_globals.g_audit_this := TRUE;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others';
wwv_flow_imp.g_varchar2_table(265) := ' then'||wwv_flow.LF||
'        sp_globals.g_audit_this := TRUE;'||wwv_flow.LF||
'end;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(454525077776764237)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sample data - releases'
,p_sequence=>9210
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
