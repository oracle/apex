prompt --application/deployment/install/install_sp_initiative_focus_areas_tables
begin
--   Manifest
--     INSTALL: INSTALL-sp_initiative_focus_areas tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_initiative_focus_areas ('||wwv_flow.LF||
'    id                             number default on null t';
wwv_flow_imp.g_varchar2_table(2) := 'o_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constra';
wwv_flow_imp.g_varchar2_table(3) := 'int sp_initiative_focus_area_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    initiative_id                  number  not n';
wwv_flow_imp.g_varchar2_table(4) := 'ull'||wwv_flow.LF||
'                                   constraint sp_initiative_focus_areas_fk'||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(5) := '              references sp_initiatives '||wwv_flow.LF||
'                                   on delete cascade,'||wwv_flow.LF||
'    f';
wwv_flow_imp.g_varchar2_table(6) := 'ocus_area                     varchar2(60 char)  not null,'||wwv_flow.LF||
'    external_key                   varcha';
wwv_flow_imp.g_varchar2_table(7) := 'r2(30 char),'||wwv_flow.LF||
'    active_yn                      varchar2(1 char)   default on null ''Y'''||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(8) := '                      constraint sp_initiative_fa_active_cc'||wwv_flow.LF||
'                                   check';
wwv_flow_imp.g_varchar2_table(9) := ' (active_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- control display for kanban'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    display_sequence     ';
wwv_flow_imp.g_varchar2_table(10) := '          number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    development_owner_id           number'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(11) := '                constraint sp_dev_focus_area_owner_fk'||wwv_flow.LF||
'                                   references ';
wwv_flow_imp.g_varchar2_table(12) := 'sp_team_members (id),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    description                    varchar2(4000 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(13) := '   --'||wwv_flow.LF||
'    created                        date  not null,'||wwv_flow.LF||
'    created_by                     varchar2';
wwv_flow_imp.g_varchar2_table(14) := '(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by               ';
wwv_flow_imp.g_varchar2_table(15) := '      varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index sp_initiative_focus_areas_u1 on sp_initiat';
wwv_flow_imp.g_varchar2_table(16) := 'ive_focus_areas (initiative_id, focus_area);'||wwv_flow.LF||
'create unique index sp_initiative_focus_areas_u2 on sp_';
wwv_flow_imp.g_varchar2_table(17) := 'initiative_focus_areas (lower(external_key));'||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_init_focus_area_links ('||wwv_flow.LF||
'    id       ';
wwv_flow_imp.g_varchar2_table(18) := '                      number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(19) := ''') '||wwv_flow.LF||
'                                   constraint sp_init_focus_area_links_pk primary key,'||wwv_flow.LF||
'    init_';
wwv_flow_imp.g_varchar2_table(20) := 'focus_area_id             number  not null'||wwv_flow.LF||
'                                   constraint sp_init_foc';
wwv_flow_imp.g_varchar2_table(21) := 'us_area_links_ifa_fk'||wwv_flow.LF||
'                                   references sp_initiative_focus_areas on dele';
wwv_flow_imp.g_varchar2_table(22) := 'te cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    link_name                      varchar2(255 char)   not null,'||wwv_flow.LF||
'    link_url   ';
wwv_flow_imp.g_varchar2_table(23) := '                    varchar2(4000 char) not null,'||wwv_flow.LF||
'    important_yn                   varchar2(1 char';
wwv_flow_imp.g_varchar2_table(24) := ') default on null ''N'''||wwv_flow.LF||
'                                   constraint sp_init_focus_area_link_imp_cc'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(25) := '                                  check (important_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created             ';
wwv_flow_imp.g_varchar2_table(26) := '           date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    update';
wwv_flow_imp.g_varchar2_table(27) := 'd                        date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not nu';
wwv_flow_imp.g_varchar2_table(28) := 'll'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_init_focus_area_links_i1 on sp_init_focus_area_links (init_focus_area_id);'||wwv_flow.LF||
'cr';
wwv_flow_imp.g_varchar2_table(29) := 'eate index sp_init_focus_area_links_i2 on sp_init_focus_area_links (updated);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_init';
wwv_flow_imp.g_varchar2_table(30) := '_focus_area_documents ('||wwv_flow.LF||
'    id                             number default on null to_number(sys_guid';
wwv_flow_imp.g_varchar2_table(31) := '(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_init_focus';
wwv_flow_imp.g_varchar2_table(32) := '_area_documents_pk primary key,'||wwv_flow.LF||
'    init_focus_area_id             number  not null'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(33) := '                   constraint sp_init_focus_area_document_ifa_fk'||wwv_flow.LF||
'                                   ';
wwv_flow_imp.g_varchar2_table(34) := 'references sp_initiative_focus_areas on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    document_blob                  bl';
wwv_flow_imp.g_varchar2_table(35) := 'ob,'||wwv_flow.LF||
'    document_filename              varchar2(512 char),'||wwv_flow.LF||
'    document_mimetype              varcha';
wwv_flow_imp.g_varchar2_table(36) := 'r2(512 char),'||wwv_flow.LF||
'    document_charset               varchar2(512 char),'||wwv_flow.LF||
'    document_lastupd           ';
wwv_flow_imp.g_varchar2_table(37) := '    date,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    important_yn                   varchar2(1 char) default on null ''N'''||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(38) := '                        constraint sp_init_focus_area_doc_imp_cc'||wwv_flow.LF||
'                                   ';
wwv_flow_imp.g_varchar2_table(39) := 'check (important_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    doc_description                varchar2(4000 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(40) := '  tags                           varchar2(4000 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date';
wwv_flow_imp.g_varchar2_table(41) := ' not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated              ';
wwv_flow_imp.g_varchar2_table(42) := '          date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create i';
wwv_flow_imp.g_varchar2_table(43) := 'ndex sp_init_focus_area_documents_i1 on sp_init_focus_area_documents (init_focus_area_id);'||wwv_flow.LF||
'create in';
wwv_flow_imp.g_varchar2_table(44) := 'dex sp_init_focus_area_documents_i2 on sp_init_focus_area_documents (updated);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_ini';
wwv_flow_imp.g_varchar2_table(45) := 't_focus_area_comments ('||wwv_flow.LF||
'    id                             number default on null to_number(sys_guid';
wwv_flow_imp.g_varchar2_table(46) := '(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_init_focus';
wwv_flow_imp.g_varchar2_table(47) := '_area_comments_pk primary key,'||wwv_flow.LF||
'    init_focus_area_id             number  not null'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(48) := '                  constraint sp_init_focus_area_comment_ifa_fk'||wwv_flow.LF||
'                                   re';
wwv_flow_imp.g_varchar2_table(49) := 'ferences sp_initiative_focus_areas on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    comment_nbr                    numb';
wwv_flow_imp.g_varchar2_table(50) := 'er,'||wwv_flow.LF||
'    body                           clob,'||wwv_flow.LF||
'    body_html                      clob,'||wwv_flow.LF||
'    body_no_im';
wwv_flow_imp.g_varchar2_table(51) := 'ages                 clob,'||wwv_flow.LF||
'    image_ref_id                   number, '||wwv_flow.LF||
'    author_id                ';
wwv_flow_imp.g_varchar2_table(52) := '      number,'||wwv_flow.LF||
'    private_yn                     varchar2(1 char) default on null ''N'''||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(53) := '                     constraint sp_init_focus_area_comment_private_cc'||wwv_flow.LF||
'                              ';
wwv_flow_imp.g_varchar2_table(54) := '     check (private_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    c';
wwv_flow_imp.g_varchar2_table(55) := 'reated_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                        date n';
wwv_flow_imp.g_varchar2_table(56) := 'ot null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_init_foc';
wwv_flow_imp.g_varchar2_table(57) := 'us_area_comments_i1 on sp_init_focus_area_comments (init_focus_area_id);'||wwv_flow.LF||
'create index sp_init_focus_';
wwv_flow_imp.g_varchar2_table(58) := 'area_comments_i2 on sp_init_focus_area_comments (author_id);'||wwv_flow.LF||
'create index sp_init_focus_area_comment';
wwv_flow_imp.g_varchar2_table(59) := 's_i3 on sp_init_focus_area_comments (image_ref_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_init_focus_area_history ('||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(60) := 'd                             number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(61) := 'XXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_init_focus_area_history_pk primary key,';
wwv_flow_imp.g_varchar2_table(62) := ''||wwv_flow.LF||
'    init_focus_area_id             number  not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    attribute_column               varc';
wwv_flow_imp.g_varchar2_table(63) := 'har2(255 char) not null, '||wwv_flow.LF||
'    change_type                    varchar2(30 char)  not null'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(64) := '                        constraint sp_init_focus_area_history_type_cc '||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(65) := '      check (change_type in (''CREATE'',''UPDATE'',''DELETE'')),'||wwv_flow.LF||
'    old_value                      varcha';
wwv_flow_imp.g_varchar2_table(66) := 'r2(4000 char),'||wwv_flow.LF||
'    new_value                      varchar2(4000 char),'||wwv_flow.LF||
'    old_value_clob           ';
wwv_flow_imp.g_varchar2_table(67) := '      clob,'||wwv_flow.LF||
'    new_value_clob                 clob,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    changed_on                     date ';
wwv_flow_imp.g_varchar2_table(68) := ' not null,'||wwv_flow.LF||
'    changed_by                     varchar2(255 char)'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_init_focus_area';
wwv_flow_imp.g_varchar2_table(69) := '_history_i1 on sp_init_focus_area_history (init_focus_area_id);'||wwv_flow.LF||
'create index sp_init_focus_area_hist';
wwv_flow_imp.g_varchar2_table(70) := 'ory_i2 on sp_init_focus_area_history (changed_by);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(40396100482752984993)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_initiative_focus_areas tables'
,p_sequence=>3250
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
