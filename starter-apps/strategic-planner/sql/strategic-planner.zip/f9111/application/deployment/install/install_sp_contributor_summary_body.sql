prompt --application/deployment/install/install_sp_contributor_summary_body
begin
--   Manifest
--     INSTALL: INSTALL-sp_contributor_summary body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body sp_contributor_summary'||wwv_flow.LF||
'as'||wwv_flow.LF||
''||wwv_flow.LF||
'function generate ('||wwv_flow.LF||
'    p_team_member_id  ';
wwv_flow_imp.g_varchar2_table(2) := '   in number,'||wwv_flow.LF||
'    p_show_activities    in varchar2 default ''Y'','||wwv_flow.LF||
'    p_show_projects      in varchar2';
wwv_flow_imp.g_varchar2_table(3) := ' default ''Y'','||wwv_flow.LF||
'    p_show_approvals     in varchar2 default ''N'',  -- based on build option in app'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(4) := ' p_links              in varchar2 default ''NONE'','||wwv_flow.LF||
'    p_include_title_yn   in varchar2 default ''Y'','||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(5) := '    p_apex_session       in varchar2 default null )'||wwv_flow.LF||
'    return clob'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    x                      cl';
wwv_flow_imp.g_varchar2_table(6) := 'ob := null;'||wwv_flow.LF||
'    x2                     clob := null;'||wwv_flow.LF||
'    x3                     clob := null;'||wwv_flow.LF||
'    x4';
wwv_flow_imp.g_varchar2_table(7) := '                     clob := null;'||wwv_flow.LF||
'    x5                     clob := null;'||wwv_flow.LF||
'    x6                  ';
wwv_flow_imp.g_varchar2_table(8) := '   clob := null;'||wwv_flow.LF||
'    x7                     clob := null;'||wwv_flow.LF||
'    l_date_from            date := trunc(s';
wwv_flow_imp.g_varchar2_table(9) := 'ysdate) - 6;'||wwv_flow.LF||
'    l_date_to              date := sysdate;'||wwv_flow.LF||
'    l_person               varchar2(255);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(10) := '   l_email                varchar2(255);'||wwv_flow.LF||
'    l_team_member_id       number;'||wwv_flow.LF||
'    l_lower_app_user    ';
wwv_flow_imp.g_varchar2_table(11) := '   varchar2(255) := null;'||wwv_flow.LF||
'    l_date_fm              varchar2(255) := ''FMDay DD-MON'';'||wwv_flow.LF||
'    l_date_fm2';
wwv_flow_imp.g_varchar2_table(12) := '             varchar2(255) := ''FMDay DD-MON-YYYY'';'||wwv_flow.LF||
'    l_day_fm               varchar2(255) := ''FMDa';
wwv_flow_imp.g_varchar2_table(13) := 'y'';'||wwv_flow.LF||
'    l_days                 number;'||wwv_flow.LF||
'    l_last_heading         varchar2(500);'||wwv_flow.LF||
'    l_row_count    ';
wwv_flow_imp.g_varchar2_table(14) := '        int := 0;'||wwv_flow.LF||
'    l_activity_count       int := 0;'||wwv_flow.LF||
'    l_release_count        int := 0;'||wwv_flow.LF||
'    l_ma';
wwv_flow_imp.g_varchar2_table(15) := 'x_text_length      int := 120;'||wwv_flow.LF||
'    l_project_max_count    int := 20;'||wwv_flow.LF||
'    l_link_type            varc';
wwv_flow_imp.g_varchar2_table(16) := 'har2(30);'||wwv_flow.LF||
'    l_project_label        varchar2(255);'||wwv_flow.LF||
'    l_initiative_label     varchar2(255);'||wwv_flow.LF||
'    l_';
wwv_flow_imp.g_varchar2_table(17) := 'projects_label       varchar2(255);'||wwv_flow.LF||
'    l_initiatives_label    varchar2(255);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- support ';
wwv_flow_imp.g_varchar2_table(18) := 'for links'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    l_project              varchar2(4000);'||wwv_flow.LF||
'    l_role                 varchar2(4000';
wwv_flow_imp.g_varchar2_table(19) := ');'||wwv_flow.LF||
'    l_url                  varchar2(4000);'||wwv_flow.LF||
'    l_app_id               varchar2(4000);'||wwv_flow.LF||
'    l_app_p';
wwv_flow_imp.g_varchar2_table(20) := 'refix_url       varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- get settings'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    l_project_label     := s';
wwv_flow_imp.g_varchar2_table(21) := 'p_util.get_nomenclature(''PROJECT'');'||wwv_flow.LF||
'    l_initiative_label  := sp_util.get_nomenclature(''INITIATIVE''';
wwv_flow_imp.g_varchar2_table(22) := ');'||wwv_flow.LF||
'    l_projects_label    := sp_util.get_nomenclature(''PROJECTS'');'||wwv_flow.LF||
'    l_initiatives_label := sp_ut';
wwv_flow_imp.g_varchar2_table(23) := 'il.get_nomenclature(''INITIATIVES'');'||wwv_flow.LF||
'    l_app_id            := sp_util.get_setting(''APP_ID'');'||wwv_flow.LF||
'    l_';
wwv_flow_imp.g_varchar2_table(24) := 'app_prefix_url    := sp_util.get_setting(''APP_PREFIX_URL'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- determine link type'||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(25) := '-'||wwv_flow.LF||
'    -- APP: generate links from within the current app requires p_apex_session'||wwv_flow.LF||
'    -- EMAIL: gener';
wwv_flow_imp.g_varchar2_table(26) := 'ate fully qualified links'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if p_links = ''APP'' and p_apex_session is not null and l_app_id ';
wwv_flow_imp.g_varchar2_table(27) := 'is not null then'||wwv_flow.LF||
'       l_link_type := ''APP'';'||wwv_flow.LF||
'    elsif p_links = ''EMAIL'' and l_app_id is not null t';
wwv_flow_imp.g_varchar2_table(28) := 'hen'||wwv_flow.LF||
'       l_link_type := ''EMAIL'';'||wwv_flow.LF||
'    elsif p_links = ''JOB'' and l_app_id is not null then'||wwv_flow.LF||
'       l_';
wwv_flow_imp.g_varchar2_table(29) := 'link_type := ''JOB'';'||wwv_flow.LF||
'    elsif p_links is null then'||wwv_flow.LF||
'       l_link_type := ''NONE'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(30) := '-'||wwv_flow.LF||
'    -- name'||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select first_Name||'' ''||last_name name, email, id '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(31) := '       from sp_team_members tm '||wwv_flow.LF||
'         where id = p_team_member_id'||wwv_flow.LF||
'    ) loop '||wwv_flow.LF||
'        l_person :=';
wwv_flow_imp.g_varchar2_table(32) := ' apex_escape.html(c1.name);'||wwv_flow.LF||
'        l_email  := lower(apex_escape.html(c1.email));'||wwv_flow.LF||
'        l_lower_a';
wwv_flow_imp.g_varchar2_table(33) := 'pp_user := lower(c1.email);'||wwv_flow.LF||
'        l_team_member_id := c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- heading'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(34) := '    --'||wwv_flow.LF||
'    if p_include_title_yn = ''Y'' then'||wwv_flow.LF||
'       x := ''<h3>Weekly report for ''||l_person||''</h3>''|';
wwv_flow_imp.g_varchar2_table(35) := '|chr(10);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if l_link_type != ''APP'' then'||wwv_flow.LF||
'        x := x||''<span><strong>email</strong>';
wwv_flow_imp.g_varchar2_table(36) := ': ''||l_email||''</span><br>'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    x := x||''<span><strong>timeframe</strong>: ''||to_char(l';
wwv_flow_imp.g_varchar2_table(37) := '_date_from,l_date_fm)||'' - ''||to_char(l_date_to,l_date_fm2)||''</span><br><br><p style="border-bottom';
wwv_flow_imp.g_varchar2_table(38) := ': 1px solid #E0DEDD;"></p>'';'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --  ######################################################';
wwv_flow_imp.g_varchar2_table(39) := '#########'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --  A C T I V I T I E S'||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --  current'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if p_show_act';
wwv_flow_imp.g_varchar2_table(40) := 'ivities = ''Y'' then'||wwv_flow.LF||
'    '||wwv_flow.LF||
'        x2 := x2||''<h3>Activities</h3>''||chr(10);'||wwv_flow.LF||
'        l_row_count := 0;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(41) := '        for c1 in ('||wwv_flow.LF||
'            select ap.id, '||wwv_flow.LF||
'                   ap.project_id,'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(42) := '--'||wwv_flow.LF||
'                   -- activity core information'||wwv_flow.LF||
'                   --'||wwv_flow.LF||
'                   at.activ';
wwv_flow_imp.g_varchar2_table(43) := 'ity_type,'||wwv_flow.LF||
'                   ap.activity,'||wwv_flow.LF||
'                   decode(greatest(length(ap.comments),l_m';
wwv_flow_imp.g_varchar2_table(44) := 'ax_text_length),l_max_text_length,ap.comments,substr(ap.comments,1,l_max_text_length)||''...'') commen';
wwv_flow_imp.g_varchar2_table(45) := 'ts,'||wwv_flow.LF||
'                   --'||wwv_flow.LF||
'                   to_char(ap.start_date,''DD-MON'')||'' to ''||to_char(ap.end';
wwv_flow_imp.g_varchar2_table(46) := '_date,''DD-MON-YYYY'') TIMELINE,'||wwv_flow.LF||
'                   --'||wwv_flow.LF||
'                   decode(ap.project_id,null,nu';
wwv_flow_imp.g_varchar2_table(47) := 'll,('||wwv_flow.LF||
'                       select decode(greatest(length(p.project),l_max_text_length),l_max_text_l';
wwv_flow_imp.g_varchar2_table(48) := 'ength,p.PROJECT,substr(p.project,1,l_max_text_length)||''...'') project '||wwv_flow.LF||
'                       from s';
wwv_flow_imp.g_varchar2_table(49) := 'p_projects p '||wwv_flow.LF||
'                       where p.id = ap.project_id and '||wwv_flow.LF||
'                             p.';
wwv_flow_imp.g_varchar2_table(50) := 'DUPLICATE_OF_PROJECT_ID is null and'||wwv_flow.LF||
'                             p.ARCHIVED_YN = ''N'')'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(51) := '         ) project,'||wwv_flow.LF||
'                    --'||wwv_flow.LF||
'                    -- initiative'||wwv_flow.LF||
'                    --'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(52) := '                    decode(ap.initiative_id,null,null,('||wwv_flow.LF||
'                        select i.initiative ';
wwv_flow_imp.g_varchar2_table(53) := 'from sp_initiatives i where i.id = ap.initiative_id)) initiative,'||wwv_flow.LF||
'                    ap.initiative_';
wwv_flow_imp.g_varchar2_table(54) := 'id,'||wwv_flow.LF||
'                    --'||wwv_flow.LF||
'                    (select FRIENDLY_IDENTIFIER '||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(55) := 'from sp_projects p '||wwv_flow.LF||
'                       where p.id = ap.project_id and '||wwv_flow.LF||
'                         ';
wwv_flow_imp.g_varchar2_table(56) := '    p.DUPLICATE_OF_PROJECT_ID is null and'||wwv_flow.LF||
'                             p.ARCHIVED_YN = ''N'') friendly';
wwv_flow_imp.g_varchar2_table(57) := '_identifier'||wwv_flow.LF||
'            from sp_activities ap,'||wwv_flow.LF||
'                 sp_activity_types at,'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(58) := '   sp_team_members tm'||wwv_flow.LF||
'            where '||wwv_flow.LF||
'                  ap.activity_type_id = at.id and'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(59) := '         tm.id = l_team_member_id and'||wwv_flow.LF||
'                  ap.team_member_id = tm.id and'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(60) := '    trunc(sysdate) <= ap.end_date and'||wwv_flow.LF||
'                  ap.start_date <= trunc(sysdate) and'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(61) := '          nvl(ap.private_yn,''N'') = ''N''  -- must exclude all private activities '||wwv_flow.LF||
'                  or';
wwv_flow_imp.g_varchar2_table(62) := 'der by ap.end_date'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            l_row_count := l_row_count + 1;'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(63) := '     -- determine project link'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            l_project  := apex_escape.html(c1.project)';
wwv_flow_imp.g_varchar2_table(64) := ';'||wwv_flow.LF||
'            if c1.project is not null then '||wwv_flow.LF||
'                if l_link_type = ''APP'' then'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(65) := '         l_url := apex_util.prepare_url(''f?p=''||l_app_id||'':3:''||p_apex_session||''::NO:3:FI:''||c1.FR';
wwv_flow_imp.g_varchar2_table(66) := 'IENDLY_IDENTIFIER);'||wwv_flow.LF||
'                   l_project := ''<a href="''||l_url||''">''||l_project||''</a>'';'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(67) := '             elsif l_link_type in (''EMAIL'',''JOB'') then'||wwv_flow.LF||
'                   l_url := apex_page.get_url';
wwv_flow_imp.g_varchar2_table(68) := '('||wwv_flow.LF||
'                              p_application => l_app_id,'||wwv_flow.LF||
'                              p_page     ';
wwv_flow_imp.g_varchar2_table(69) := '   => 3,'||wwv_flow.LF||
'                              p_session     => null,'||wwv_flow.LF||
'                              p_items ';
wwv_flow_imp.g_varchar2_table(70) := '      => ''FI'','||wwv_flow.LF||
'                              p_values      => c1.FRIENDLY_IDENTIFIER,'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(71) := '                p_plain_url   => TRUE );'||wwv_flow.LF||
'                   if l_link_type = ''EMAIL'' then'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(72) := '            l_url := l_app_prefix_url || l_url; '||wwv_flow.LF||
'                   end if;'||wwv_flow.LF||
'                   l_pro';
wwv_flow_imp.g_varchar2_table(73) := 'ject := ''<a href="''||l_url||''">''||l_project||''</a>'';'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(74) := '         --'||wwv_flow.LF||
'            -- generate HTML for activities'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            if l_row_count = ';
wwv_flow_imp.g_varchar2_table(75) := '1 then '||wwv_flow.LF||
'              x2 := x2||chr(10)||''<h4>Current</h4>''||chr(10)||''<ul>'';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(76) := '          x2 := x2||''<li>''||'||wwv_flow.LF||
'                  '' ''||apex_escape.html(c1.TIMELINE)||'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(77) := '  '' (<strong>''||apex_escape.html(c1.activity_type)||''</strong>) - ''||'||wwv_flow.LF||
'                  apex_escape.';
wwv_flow_imp.g_varchar2_table(78) := 'html(c1.activity)||case when c1.comments is not null then '' - ''||apex_escape.html(c1.comments) end;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(79) := '            if c1.project is not null then '||wwv_flow.LF||
'                x2 := x2||''<br>''||nvl(l_project_label,''P';
wwv_flow_imp.g_varchar2_table(80) := 'roject'')||'': ''||l_project;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            if c1.initiative is not null then '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(81) := '          x2 := x2||''<br>''||nvl(l_initiative_label,''Initiative'')||'': ''||apex_escape.html(c1.initiati';
wwv_flow_imp.g_varchar2_table(82) := 've);'||wwv_flow.LF||
'            end if;        '||wwv_flow.LF||
'            x2 := x2||''</li>'';'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'        if l_row_';
wwv_flow_imp.g_varchar2_table(83) := 'count > 0 then'||wwv_flow.LF||
'            x2 := x2||chr(10)||''</ul>'';'||wwv_flow.LF||
'            l_activity_count := l_row_count;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(84) := '        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        -- FUTURE'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        l_row_count := 0;'||wwv_flow.LF||
'        for c1 in';
wwv_flow_imp.g_varchar2_table(85) := ' ('||wwv_flow.LF||
'            select ap.id, '||wwv_flow.LF||
'                   ap.project_id,'||wwv_flow.LF||
'                   --'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(86) := '     -- activity core information'||wwv_flow.LF||
'                   --'||wwv_flow.LF||
'                   at.activity_type,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(87) := '            ap.activity,'||wwv_flow.LF||
'                   decode(greatest(length(ap.comments),l_max_text_length),l';
wwv_flow_imp.g_varchar2_table(88) := '_max_text_length,ap.comments,substr(ap.comments,1,l_max_text_length)||''...'') comments,'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(89) := '      --'||wwv_flow.LF||
'                   to_char(ap.start_date,''DD-MON-YYYY'')||'' to ''||to_char(ap.end_date,''DD-MO';
wwv_flow_imp.g_varchar2_table(90) := 'N-YYYY'') TIMELINE,'||wwv_flow.LF||
'                   --'||wwv_flow.LF||
'                   decode(ap.project_id,null,null,('||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(91) := '                select decode(greatest(length(p.project),l_max_text_length),l_max_text_length,p.PROJ';
wwv_flow_imp.g_varchar2_table(92) := 'ECT,substr(p.project,1,l_max_text_length)||''...'') project '||wwv_flow.LF||
'                       from sp_projects p';
wwv_flow_imp.g_varchar2_table(93) := ' '||wwv_flow.LF||
'                       where p.id = ap.project_id and '||wwv_flow.LF||
'                             p.DUPLICATE_OF';
wwv_flow_imp.g_varchar2_table(94) := '_PROJECT_ID is null and'||wwv_flow.LF||
'                             p.ARCHIVED_YN = ''N'')'||wwv_flow.LF||
'                       ) p';
wwv_flow_imp.g_varchar2_table(95) := 'roject,'||wwv_flow.LF||
'                    --'||wwv_flow.LF||
'                    -- initiative'||wwv_flow.LF||
'                    --'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(96) := '        decode(ap.initiative_id,null,null,('||wwv_flow.LF||
'                        select i.initiative from sp_init';
wwv_flow_imp.g_varchar2_table(97) := 'iatives i where i.id = ap.initiative_id)) initiative,'||wwv_flow.LF||
'                    ap.initiative_id,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(98) := '            (select FRIENDLY_IDENTIFIER '||wwv_flow.LF||
'                        from sp_projects p '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(99) := '        where p.id = ap.project_id and '||wwv_flow.LF||
'                             p.DUPLICATE_OF_PROJECT_ID is nu';
wwv_flow_imp.g_varchar2_table(100) := 'll and'||wwv_flow.LF||
'                             p.ARCHIVED_YN = ''N'') friendly_identifier'||wwv_flow.LF||
'            from sp_act';
wwv_flow_imp.g_varchar2_table(101) := 'ivities ap,'||wwv_flow.LF||
'                 sp_activity_types at,'||wwv_flow.LF||
'                 sp_team_members tm'||wwv_flow.LF||
'            w';
wwv_flow_imp.g_varchar2_table(102) := 'here '||wwv_flow.LF||
'                  ap.activity_type_id = at.id and'||wwv_flow.LF||
'                  tm.id = l_team_member_id a';
wwv_flow_imp.g_varchar2_table(103) := 'nd'||wwv_flow.LF||
'                  ap.team_member_id = tm.id and'||wwv_flow.LF||
'                  ap.start_date > trunc(sysdate) ';
wwv_flow_imp.g_varchar2_table(104) := 'and'||wwv_flow.LF||
'                  nvl(ap.private_yn,''N'') = ''N''  -- must exclude all private activities'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(105) := '   order by ap.end_date'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            l_row_count := l_row_count + 1;'||wwv_flow.LF||
'           '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(106) := '       if l_row_count = 1 then   '||wwv_flow.LF||
'               x3 := x3||''<h4>Future</h4><ul>'';'||wwv_flow.LF||
'            end if';
wwv_flow_imp.g_varchar2_table(107) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            -- determine project link'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            l_project  := ape';
wwv_flow_imp.g_varchar2_table(108) := 'x_escape.html(c1.project);'||wwv_flow.LF||
'            if c1.project is not null then '||wwv_flow.LF||
'                if l_link_typ';
wwv_flow_imp.g_varchar2_table(109) := 'e = ''APP'' then'||wwv_flow.LF||
'                   l_url := apex_util.prepare_url(''f?p=''||l_app_id||'':3:''||p_apex_ses';
wwv_flow_imp.g_varchar2_table(110) := 'sion||''::NO:3:FI:''||c1.FRIENDLY_IDENTIFIER);'||wwv_flow.LF||
'                   l_project := ''<a href="''||l_url||''">';
wwv_flow_imp.g_varchar2_table(111) := '''||l_project||''</a>'';'||wwv_flow.LF||
'                elsif l_link_type in (''EMAIL'',''JOB'') then'||wwv_flow.LF||
'                   l';
wwv_flow_imp.g_varchar2_table(112) := '_url := apex_page.get_url('||wwv_flow.LF||
'                              p_application => l_app_id,'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(113) := '              p_page        => 3,'||wwv_flow.LF||
'                              p_session     => null,'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(114) := '                 p_items       => ''FI'','||wwv_flow.LF||
'                              p_values      => c1.FRIENDLY_I';
wwv_flow_imp.g_varchar2_table(115) := 'DENTIFIER,'||wwv_flow.LF||
'                              p_plain_url   => TRUE );'||wwv_flow.LF||
'                   if l_link_type ';
wwv_flow_imp.g_varchar2_table(116) := '= ''EMAIL'' then'||wwv_flow.LF||
'                      l_url := l_app_prefix_url || l_url; '||wwv_flow.LF||
'                   end if;';
wwv_flow_imp.g_varchar2_table(117) := ''||wwv_flow.LF||
'                   l_project := ''<a href="''||l_url||''">''||l_project||''</a>'';'||wwv_flow.LF||
'                end if';
wwv_flow_imp.g_varchar2_table(118) := ';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'            x3 := x3||''<li>''||'||wwv_flow.LF||
'                  '' ''||apex_escape.html(c1.TIM';
wwv_flow_imp.g_varchar2_table(119) := 'ELINE)||'||wwv_flow.LF||
'                  '' (<strong>''||apex_escape.html(c1.activity_type)||''</strong>) - ''||'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(120) := '             apex_escape.html(c1.activity)||case when c1.comments is not null then '' - ''||apex_escap';
wwv_flow_imp.g_varchar2_table(121) := 'e.html(c1.comments) end;'||wwv_flow.LF||
'            if c1.project is not null then '||wwv_flow.LF||
'               x3 := x3||''<br>''';
wwv_flow_imp.g_varchar2_table(122) := '||nvl(l_project_label,''Project'')||'': ''||l_project;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            if c1.initiative ';
wwv_flow_imp.g_varchar2_table(123) := 'is not null then '||wwv_flow.LF||
'               x3 := x3||''<br>''||nvl(l_initiative_label,''Initiative'')||'': ''||apex_';
wwv_flow_imp.g_varchar2_table(124) := 'escape.html(c1.initiative);'||wwv_flow.LF||
'            end if;    '||wwv_flow.LF||
'            x3 := x3||''</li>'';'||wwv_flow.LF||
'           '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(125) := '   end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'        if l_row_count > 0 then '||wwv_flow.LF||
'           x3 := x3||''</ul>'';'||wwv_flow.LF||
'           l_activity_c';
wwv_flow_imp.g_varchar2_table(126) := 'ount := l_activity_count + l_row_count;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        -- LAST WEEK'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(127) := '        l_row_count := 0;'||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            select ap.id, '||wwv_flow.LF||
'                   ap.proje';
wwv_flow_imp.g_varchar2_table(128) := 'ct_id,'||wwv_flow.LF||
'                   --'||wwv_flow.LF||
'                   -- activity core information'||wwv_flow.LF||
'                   --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(129) := '                  at.activity_type,'||wwv_flow.LF||
'                   ap.activity,'||wwv_flow.LF||
'                   decode(greate';
wwv_flow_imp.g_varchar2_table(130) := 'st(length(ap.comments),l_max_text_length),l_max_text_length,ap.comments,substr(ap.comments,1,l_max_t';
wwv_flow_imp.g_varchar2_table(131) := 'ext_length)||''...'') comments,'||wwv_flow.LF||
'                   --'||wwv_flow.LF||
'                   to_char(ap.start_date,''DD-MON';
wwv_flow_imp.g_varchar2_table(132) := '-YYYY'')||'' to ''||to_char(ap.end_date,''DD-MON-YYYY'') TIMELINE,'||wwv_flow.LF||
'                   --'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(133) := '   decode(ap.project_id,null,null,('||wwv_flow.LF||
'                          select decode(greatest(length(p.projec';
wwv_flow_imp.g_varchar2_table(134) := 't),l_max_text_length),l_max_text_length,p.PROJECT,substr(p.project,1,l_max_text_length)||''...'') proj';
wwv_flow_imp.g_varchar2_table(135) := 'ect '||wwv_flow.LF||
'                            from sp_projects p '||wwv_flow.LF||
'                           where p.id = ap.proj';
wwv_flow_imp.g_varchar2_table(136) := 'ect_id and '||wwv_flow.LF||
'                                 p.DUPLICATE_OF_PROJECT_ID is null and'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(137) := '                p.ARCHIVED_YN = ''N'')'||wwv_flow.LF||
'                          ) project,'||wwv_flow.LF||
'                    --'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(138) := '                 -- initiative'||wwv_flow.LF||
'                    --'||wwv_flow.LF||
'                    decode(ap.initiative_id,nu';
wwv_flow_imp.g_varchar2_table(139) := 'll,null,('||wwv_flow.LF||
'                           select i.initiative from sp_initiatives i where i.id = ap.initi';
wwv_flow_imp.g_varchar2_table(140) := 'ative_id)) initiative,'||wwv_flow.LF||
'                    ap.initiative_id'||wwv_flow.LF||
'            from sp_activities ap,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(141) := '            sp_activity_types at,'||wwv_flow.LF||
'                 sp_team_members tm'||wwv_flow.LF||
'            where '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(142) := '       ap.activity_type_id = at.id and'||wwv_flow.LF||
'                  tm.id = l_team_member_id and'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(143) := '    ap.team_member_id = tm.id and'||wwv_flow.LF||
'                  ap.end_date > trunc(sysdate) - 7 and'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(144) := '       ap.end_date < trunc(sysdate) and'||wwv_flow.LF||
'                  nvl(ap.private_yn,''N'') = ''N''  -- must excl';
wwv_flow_imp.g_varchar2_table(145) := 'ude all private activities'||wwv_flow.LF||
'            order by ap.end_date '||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            l_row_count ';
wwv_flow_imp.g_varchar2_table(146) := ':= l_row_count + 1;'||wwv_flow.LF||
'            if l_row_count = 1 then '||wwv_flow.LF||
'               x3 := x3||''<h4>Last week</h4';
wwv_flow_imp.g_varchar2_table(147) := '>''||chr(10)||''<ul>'';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            x3 := x3||chr(10)||''<li>''||'||wwv_flow.LF||
'                 '' ';
wwv_flow_imp.g_varchar2_table(148) := '''||apex_escape.html(c1.TIMELINE)||'||wwv_flow.LF||
'                 '' (<strong>''||apex_escape.html(c1.activity_type)';
wwv_flow_imp.g_varchar2_table(149) := '||''</strong>) - ''||'||wwv_flow.LF||
'                 apex_escape.html(c1.activity) || case when c1.comments is not n';
wwv_flow_imp.g_varchar2_table(150) := 'ull then '' - ''||apex_escape.html(c1.comments) end;'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            if c1.project is not n';
wwv_flow_imp.g_varchar2_table(151) := 'ull then '||wwv_flow.LF||
'               x3 := x3||''<br>''||nvl(l_project_label,''Project'')||'': ''||apex_escape.html(c1';
wwv_flow_imp.g_varchar2_table(152) := '.project);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            if c1.initiative is not null then '||wwv_flow.LF||
'               x3 := x';
wwv_flow_imp.g_varchar2_table(153) := '3||''<br>''||nvl(l_initiative_label,''Initiative'')||'': ''||apex_escape.html(c1.initiative);'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(154) := 'end if;    '||wwv_flow.LF||
'            x3 := x3||''</li>'';'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        if l_row_count > 0 then '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(155) := '     x3 := x3||''</ul>''||chr(10);'||wwv_flow.LF||
'           l_activity_count := l_activity_count + l_row_count;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(156) := '    end if;'||wwv_flow.LF||
'        -- end of activity reporting'||wwv_flow.LF||
'        x3 := x3||chr(10);'||wwv_flow.LF||
''||wwv_flow.LF||
'        x3 := x3||''<p><';
wwv_flow_imp.g_varchar2_table(157) := 'i>Activities listed include activities for the past week, current and future planned.</i></p>'';'||wwv_flow.LF||
''||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(158) := '     if l_activity_count = 0 then'||wwv_flow.LF||
'           x3 := x3||''<p>No Activities found.</p>'';'||wwv_flow.LF||
'        end if';
wwv_flow_imp.g_varchar2_table(159) := ';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'      '||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --  ###############################################################';
wwv_flow_imp.g_varchar2_table(160) := ''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- P R O J E C T S'||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    if p_show_projects = ''Y'' then'||wwv_flow.LF||
'        l_row_count := 0;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(161) := '       x4 := ''<h3>''||apex_escape.html(nvl(l_projects_label,''Projects'')) ||''</h3>'';'||wwv_flow.LF||
'        x4 := x4|';
wwv_flow_imp.g_varchar2_table(162) := '|''<i>Only above 20% complete are included.</i>'';'||wwv_flow.LF||
'        l_row_count := 0;'||wwv_flow.LF||
'        l_release_count :';
wwv_flow_imp.g_varchar2_table(163) := '= 0;'||wwv_flow.LF||
''||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            select case when p.release_id is not null then 1 '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(164) := '            when p.target_complete is null then 3'||wwv_flow.LF||
'                        else 2 end sort_order_1,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(165) := '                  case when p.target_complete is null and p.release_id is not null'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(166) := '       then (select release_target_date from sp_release_trains where id = p.release_id)'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(167) := '            else p.target_complete end sort_order_2,'||wwv_flow.LF||
'                   pp.priority sort_order_3,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(168) := '                 case when p.release_id is not null '||wwv_flow.LF||
'                             then (select relea';
wwv_flow_imp.g_varchar2_table(169) := 'se_train||'': ''||release from SP_RELEASE_TRAINS t where t.id = p.release_id)'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(170) := 'when p.target_complete is null'||wwv_flow.LF||
'                        then ''No Target'''||wwv_flow.LF||
'                        else';
wwv_flow_imp.g_varchar2_table(171) := ' to_char(p.target_complete,''Mon-YYYY'')'||wwv_flow.LF||
'                        end heading,'||wwv_flow.LF||
'                   p.pro';
wwv_flow_imp.g_varchar2_table(172) := 'ject, '||wwv_flow.LF||
'                   p.pct_complete, '||wwv_flow.LF||
'                   p.project_size,'||wwv_flow.LF||
'                   pp.';
wwv_flow_imp.g_varchar2_table(173) := 'priority,'||wwv_flow.LF||
'                   p.id project_id,'||wwv_flow.LF||
'                   p.FRIENDLY_IDENTIFIER,'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(174) := '       p.owner_id,'||wwv_flow.LF||
'                   (select count(*) cnt'||wwv_flow.LF||
'                      from sp_tasks t,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(175) := '                         sp_task_types tt'||wwv_flow.LF||
'                     where t.owner_id = l_team_member_id '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(176) := '                       and t.project_id = p.id'||wwv_flow.LF||
'                       and t.task_type_id = tt.id'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(177) := '                    and tt.static_id like ''REVIEW%'') review_cnt,'||wwv_flow.LF||
'                   (select count(*)';
wwv_flow_imp.g_varchar2_table(178) := ' cnt'||wwv_flow.LF||
'                      from sp_tasks t,'||wwv_flow.LF||
'                           sp_task_types tt'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(179) := '         where t.owner_id = l_team_member_id '||wwv_flow.LF||
'                       and t.project_id = p.id'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(180) := '                and t.task_type_id = tt.id'||wwv_flow.LF||
'                       and tt.static_id like ''MILESTONE%''';
wwv_flow_imp.g_varchar2_table(181) := ') milestone_cnt,'||wwv_flow.LF||
'                   (select count(*) cnt'||wwv_flow.LF||
'                      from sp_tasks t,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(182) := '                       sp_task_types tt'||wwv_flow.LF||
'                     where t.owner_id = l_team_member_id '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(183) := '                     and t.project_id = p.id'||wwv_flow.LF||
'                       and t.task_type_id = tt.id'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(184) := '                  and tt.static_id not like ''REVIEW%'''||wwv_flow.LF||
'                       and tt.static_id not li';
wwv_flow_imp.g_varchar2_table(185) := 'ke ''MILESTONE%'') other_task_cnt'||wwv_flow.LF||
'              from sp_projects p, '||wwv_flow.LF||
'                   SP_PROJECT_PRI';
wwv_flow_imp.g_varchar2_table(186) := 'ORITIES pp'||wwv_flow.LF||
'             where p.priority_id = pp.id and '||wwv_flow.LF||
'                   p.pct_complete > 20 and'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(187) := '                   p.pct_complete != 100 and'||wwv_flow.LF||
'                   p.ARCHIVED_YN = ''N'' and'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(188) := '       p.DUPLICATE_OF_PROJECT_ID is null and '||wwv_flow.LF||
'                   ('||wwv_flow.LF||
'                      p.release_i';
wwv_flow_imp.g_varchar2_table(189) := 'd is null or '||wwv_flow.LF||
'                       p.release_id in (select t.id from SP_RELEASE_TRAINS t where nvl';
wwv_flow_imp.g_varchar2_table(190) := '(t.RELEASE_OPEN_COMPLETED,''Y'') = ''Y'' and nvl(RELEASE_COMPLETED,''N'') = ''N'')'||wwv_flow.LF||
'                   ) and'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(191) := '                   (p.owner_id = l_team_member_id or '||wwv_flow.LF||
'                    exists (select 1'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(192) := '                     from sp_tasks'||wwv_flow.LF||
'                             where owner_id = l_team_member_id '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(193) := '                              and project_id = p.id) or '||wwv_flow.LF||
'                    exists (select 1'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(194) := '                        from sp_project_contributors'||wwv_flow.LF||
'                             where team_member_';
wwv_flow_imp.g_varchar2_table(195) := 'id = l_team_member_id '||wwv_flow.LF||
'                               and project_id = p.id) )'||wwv_flow.LF||
'            order by ';
wwv_flow_imp.g_varchar2_table(196) := '1, 2, 3 asc, 4'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            l_row_count := l_row_count + 1;'||wwv_flow.LF||
'            l_project := a';
wwv_flow_imp.g_varchar2_table(197) := 'pex_escape.html(c1.project);'||wwv_flow.LF||
'            -- broken out to avoid bulk bind error'||wwv_flow.LF||
'            if c1.ow';
wwv_flow_imp.g_varchar2_table(198) := 'ner_id = l_team_member_id then l_role := ''Owner'';'||wwv_flow.LF||
'            elsif c1.review_cnt > 0 then l_role :=';
wwv_flow_imp.g_varchar2_table(199) := ' ''Reviewer'';'||wwv_flow.LF||
'            elsif c1.milestone_cnt > 0 then l_role := ''Milestone Owner'';'||wwv_flow.LF||
'            el';
wwv_flow_imp.g_varchar2_table(200) := 'sif c1.other_task_cnt > 0 then l_role := ''Task Owner'';'||wwv_flow.LF||
'            else select listagg(rt.resource_t';
wwv_flow_imp.g_varchar2_table(201) := 'ype, '', '' on overflow truncate with count) within group (order by rt.resource_type)'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(202) := '   into l_role'||wwv_flow.LF||
'                   from sp_project_contributors c,'||wwv_flow.LF||
'                        sp_resourc';
wwv_flow_imp.g_varchar2_table(203) := 'e_types rt'||wwv_flow.LF||
'                  where c.project_id = c1.project_id'||wwv_flow.LF||
'                    and c.team_membe';
wwv_flow_imp.g_varchar2_table(204) := 'r_id = l_team_member_id'||wwv_flow.LF||
'                    and c.responsibility_id = rt.id;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(205) := '         if l_link_type = ''APP'' then'||wwv_flow.LF||
'               l_url := apex_util.prepare_url(''f?p=''||l_app_id|';
wwv_flow_imp.g_varchar2_table(206) := '|'':3:''||p_apex_session||''::NO:3:FI:''||c1.FRIENDLY_IDENTIFIER);'||wwv_flow.LF||
'               l_project := ''<a href=';
wwv_flow_imp.g_varchar2_table(207) := '"''||l_url||''">''||l_project||''</a>'';'||wwv_flow.LF||
'            elsif l_link_type in (''EMAIL'',''JOB'') then'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(208) := '     l_url := apex_page.get_url('||wwv_flow.LF||
'                          p_application => l_app_id,'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(209) := '            p_page        => 3,'||wwv_flow.LF||
'                          p_session     => null,'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(210) := '       p_items       => ''FI'','||wwv_flow.LF||
'                          p_values      => c1.FRIENDLY_IDENTIFIER,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(211) := '                       p_plain_url   => TRUE );'||wwv_flow.LF||
'               if l_link_type = ''EMAIL'' then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(212) := '           l_url := l_app_prefix_url || l_url; '||wwv_flow.LF||
'               end if;'||wwv_flow.LF||
'               l_project := ''';
wwv_flow_imp.g_varchar2_table(213) := '<a href="''||l_url||''">''||l_project||''</a>'';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'            if c1.heading != l_last';
wwv_flow_imp.g_varchar2_table(214) := '_heading or l_last_heading is null then'||wwv_flow.LF||
'                if l_row_count > 1 then'||wwv_flow.LF||
'                   x';
wwv_flow_imp.g_varchar2_table(215) := '4 := x4||''</ul>'';'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'                x4 := x4||''<h4>''||apex_escape.html(c1.head';
wwv_flow_imp.g_varchar2_table(216) := 'ing)||''</h4>'';'||wwv_flow.LF||
'                x4 := x4||''<ul>'';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            x4 := x4||''<li> ''||';
wwv_flow_imp.g_varchar2_table(217) := 'l_project||'||wwv_flow.LF||
'                      '' (<strong>''||apex_escape.html(l_role)||''</strong>) - ''||'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(218) := '              to_char(c1.pct_complete)||''% ''||apex_escape.html(c1.project_size)||'' ''||  '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(219) := '           ''P''||to_char(c1.priority)||''</li>'';'||wwv_flow.LF||
'            l_last_heading := c1.heading;'||wwv_flow.LF||
''||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(220) := '  if p_links in (''EMAIL'',''JOB'') and l_row_count = l_project_max_count then'||wwv_flow.LF||
'               x4 := x4||';
wwv_flow_imp.g_varchar2_table(221) := '''View more in application...'';'||wwv_flow.LF||
'               exit;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'       '||wwv_flow.LF||
'         end loop;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(222) := '        if l_row_count = 0 then'||wwv_flow.LF||
'            -- x4 := x4||''</ul>'';'||wwv_flow.LF||
'            x4 := x4||''No ''||l_pro';
wwv_flow_imp.g_varchar2_table(223) := 'jects_label||'' found'';'||wwv_flow.LF||
'         else'||wwv_flow.LF||
'            x4 := x4||''</ul>'';'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'         --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(224) := '        -- APPROVALS'||wwv_flow.LF||
'         --'||wwv_flow.LF||
'         if p_show_approvals = ''Y'' then'||wwv_flow.LF||
'             l_row_count :=';
wwv_flow_imp.g_varchar2_table(225) := ' 0;'||wwv_flow.LF||
'             x5 := ''<h3>''||apex_escape.html(nvl(l_project_label,''Project'')) ||'' Approvals</h3> <';
wwv_flow_imp.g_varchar2_table(226) := 'ul>'';'||wwv_flow.LF||
'             for c1 in ('||wwv_flow.LF||
'                 select p.project, p.friendly_identifier, '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(227) := '              t.approval_type,'||wwv_flow.LF||
'                        case when a.submitted_by_team_member_id = p_t';
wwv_flow_imp.g_varchar2_table(228) := 'eam_member_id'||wwv_flow.LF||
'                             then ''Submitter'''||wwv_flow.LF||
'                             else  (sele';
wwv_flow_imp.g_varchar2_table(229) := 'ct case when status = ''PENDING'' then ''Pending Review'''||wwv_flow.LF||
'                                              ';
wwv_flow_imp.g_varchar2_table(230) := '  else initcap(replace(status,''-'','' ''))'||wwv_flow.LF||
'                                                end'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(231) := '                              from'||wwv_flow.LF||
'                                       (select status,'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(232) := '                                     updated,'||wwv_flow.LF||
'                                               max(upd';
wwv_flow_imp.g_varchar2_table(233) := 'ated) over (partition by team_member_id) last_updated'||wwv_flow.LF||
'                                          from';
wwv_flow_imp.g_varchar2_table(234) := ' sp_project_approval_chain'||wwv_flow.LF||
'                                         where project_approval_id = a.id';
wwv_flow_imp.g_varchar2_table(235) := ''||wwv_flow.LF||
'                                           and team_member_id = p_team_member_id)'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(236) := '                    where last_updated = updated)'||wwv_flow.LF||
'                             end role,'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(237) := '             initcap(replace(a.status,''-'','' '')) current_status'||wwv_flow.LF||
'                   from sp_projects p';
wwv_flow_imp.g_varchar2_table(238) := ', '||wwv_flow.LF||
'                        sp_project_approvals a,'||wwv_flow.LF||
'                        sp_approval_types t'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(239) := '             where p.id = a.project_id'||wwv_flow.LF||
'                    and p.ARCHIVED_YN = ''N'''||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(240) := '   and p.DUPLICATE_OF_PROJECT_ID is null'||wwv_flow.LF||
'                    and a.approval_type_id = t.id'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(241) := '           and ( (a.submitted_by_team_member_id = p_team_member_id and'||wwv_flow.LF||
'                           a.';
wwv_flow_imp.g_varchar2_table(242) := 'submitted between l_date_from and l_date_to)'||wwv_flow.LF||
'                          or'||wwv_flow.LF||
'                          ';
wwv_flow_imp.g_varchar2_table(243) := 'exists (select 1 from sp_project_approval_chain'||wwv_flow.LF||
'                                   where project_app';
wwv_flow_imp.g_varchar2_table(244) := 'roval_id = a.id'||wwv_flow.LF||
'                                     and team_member_id = p_team_member_id'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(245) := '                            and updated between l_date_from and l_date_to) )'||wwv_flow.LF||
'                  order';
wwv_flow_imp.g_varchar2_table(246) := ' by p.project, t.approval_type'||wwv_flow.LF||
'            ) loop'||wwv_flow.LF||
'                l_row_count := l_row_count + 1;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(247) := '              l_project := apex_escape.html(c1.project);'||wwv_flow.LF||
'                if l_link_type = ''APP'' then';
wwv_flow_imp.g_varchar2_table(248) := ''||wwv_flow.LF||
'                   l_url := apex_util.prepare_url(''f?p=''||l_app_id||'':3:''||p_apex_session||''::NO:3:';
wwv_flow_imp.g_varchar2_table(249) := 'FI:''||c1.friendly_identifier);'||wwv_flow.LF||
'                   l_project := ''<a href="''||l_url||''">''||l_project||';
wwv_flow_imp.g_varchar2_table(250) := '''</a>'';'||wwv_flow.LF||
'                elsif l_Link_type in (''EMAIL'',''JOB'') then'||wwv_flow.LF||
'                   l_url := apex_p';
wwv_flow_imp.g_varchar2_table(251) := 'age.get_url('||wwv_flow.LF||
'                         p_application => l_app_id,'||wwv_flow.LF||
'                         p_page    ';
wwv_flow_imp.g_varchar2_table(252) := '    => 3,'||wwv_flow.LF||
'                         p_session     => null,'||wwv_flow.LF||
'                         p_items       => ';
wwv_flow_imp.g_varchar2_table(253) := '''FI'','||wwv_flow.LF||
'                         p_values      => c1.FRIENDLY_IDENTIFIER,'||wwv_flow.LF||
'                         p_p';
wwv_flow_imp.g_varchar2_table(254) := 'lain_url   => TRUE );'||wwv_flow.LF||
'                   if l_link_type = ''EMAIL'' then'||wwv_flow.LF||
'                      l_url :';
wwv_flow_imp.g_varchar2_table(255) := '= l_app_prefix_url || l_url; '||wwv_flow.LF||
'                   end if;'||wwv_flow.LF||
'                   l_project := ''<a href="''';
wwv_flow_imp.g_varchar2_table(256) := '||l_url||''">''||l_project||''</a>'';'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'                x5 := x5||''<li>''||l_projec';
wwv_flow_imp.g_varchar2_table(257) := 't||'' - ''||apex_escape.html(c1.approval_type)||'' - ''||apex_escape.html(c1.role);'||wwv_flow.LF||
'                x5 :';
wwv_flow_imp.g_varchar2_table(258) := '= x5||'' (Current Status: ''||apex_escape.html(c1.current_status)||'')''; '||wwv_flow.LF||
'                x5 := x5||''</';
wwv_flow_imp.g_varchar2_table(259) := 'li>'';'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'            x5 := x5||''</ul>'';'||wwv_flow.LF||
'            if l_row_count = 0 then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(260) := '          x5 := x5||''No Approvals found'';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'         --'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(261) := ' -- PROJECTS COMMENTED'||wwv_flow.LF||
'         --'||wwv_flow.LF||
'         l_row_count := 0;'||wwv_flow.LF||
'         x6 := ''<h3>''||apex_escape.htm';
wwv_flow_imp.g_varchar2_table(262) := 'l(nvl(l_projects_label,''Projects'')) ||'' Commented On''||''</h3> <ul>'';'||wwv_flow.LF||
'         for c1 in ('||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(263) := '   select p.project, max(p.friendly_identifier) friendly_identifier, min(c.created) min_created, max';
wwv_flow_imp.g_varchar2_table(264) := '(c.created) max_created, Count(*) comments'||wwv_flow.LF||
'               from sp_projects p, '||wwv_flow.LF||
'                    s';
wwv_flow_imp.g_varchar2_table(265) := 'p_project_comments c'||wwv_flow.LF||
'              where lower(c.created_by) = l_lower_app_user and '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(266) := '     p.id = c.project_id and'||wwv_flow.LF||
'                    c.created between l_date_from and l_date_to and'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(267) := '                 p.ARCHIVED_YN = ''N'' and'||wwv_flow.LF||
'                    p.DUPLICATE_OF_PROJECT_ID is null'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(268) := '         group by p.project'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            l_row_count := l_row_count + 1;'||wwv_flow.LF||
'            l';
wwv_flow_imp.g_varchar2_table(269) := '_project := apex_escape.html(c1.project);'||wwv_flow.LF||
'            if l_link_type = ''APP'' then'||wwv_flow.LF||
'               l_u';
wwv_flow_imp.g_varchar2_table(270) := 'rl := apex_util.prepare_url(''f?p=''||l_app_id||'':3:''||p_apex_session||''::NO:3:FI:''||c1.friendly_ident';
wwv_flow_imp.g_varchar2_table(271) := 'ifier);'||wwv_flow.LF||
'               l_project := ''<a href="''||l_url||''">''||l_project||''</a>'';'||wwv_flow.LF||
'            elsif l';
wwv_flow_imp.g_varchar2_table(272) := '_Link_type in (''EMAIL'',''JOB'') then'||wwv_flow.LF||
'               l_url := apex_page.get_url('||wwv_flow.LF||
'                     p';
wwv_flow_imp.g_varchar2_table(273) := '_application => l_app_id,'||wwv_flow.LF||
'                     p_page        => 3,'||wwv_flow.LF||
'                     p_session   ';
wwv_flow_imp.g_varchar2_table(274) := '  => null,'||wwv_flow.LF||
'                     p_items       => ''FI'','||wwv_flow.LF||
'                     p_values      => c1.FRIE';
wwv_flow_imp.g_varchar2_table(275) := 'NDLY_IDENTIFIER,'||wwv_flow.LF||
'                     p_plain_url   => TRUE );'||wwv_flow.LF||
'               if l_link_type = ''EMAI';
wwv_flow_imp.g_varchar2_table(276) := 'L'' then'||wwv_flow.LF||
'                  l_url := l_app_prefix_url || l_url; '||wwv_flow.LF||
'               end if;'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(277) := ' l_project := ''<a href="''||l_url||''">''||l_project||''</a>'';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            x6 := x6|';
wwv_flow_imp.g_varchar2_table(278) := '|''<li>''||l_project||'' - ''||to_char(c1.min_created,l_day_fm);'||wwv_flow.LF||
'            if c1.comments > 1 then '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(279) := '              if trunc(c1.min_created) != trunc(c1.max_created) then'||wwv_flow.LF||
'                   x6 := x6||'' ';
wwv_flow_imp.g_varchar2_table(280) := 'to ''||to_char(c1.max_created,l_day_fm);'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'                x6 := x6||'' (''||apex';
wwv_flow_imp.g_varchar2_table(281) := '_escape.html(c1.comments)||'' comments)''; '||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            x6 := x6||''</li>'';'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(282) := ' end loop;'||wwv_flow.LF||
'        x6 := x6||''</ul>'';'||wwv_flow.LF||
'        if l_row_count = 0 then'||wwv_flow.LF||
'           x6 := x6||''No ''||l_';
wwv_flow_imp.g_varchar2_table(283) := 'projects_label||'' found'';'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        -- PROJECTS ADDED'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(284) := 'l_row_count := 0;'||wwv_flow.LF||
'        x7 := ''<h3>''||apex_escape.html(nvl(l_projects_label,''Projects'')) ||'' Creat';
wwv_flow_imp.g_varchar2_table(285) := 'ed''||''</h3> <ul>'';'||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            select p.project, p.FRIENDLY_IDENTIFIER, to_char(';
wwv_flow_imp.g_varchar2_table(286) := 'p.created,l_day_fm) created'||wwv_flow.LF||
'              from sp_projects p'||wwv_flow.LF||
'             where lower(p.created_by) ';
wwv_flow_imp.g_varchar2_table(287) := '= l_lower_app_user and '||wwv_flow.LF||
'                   p.created between l_date_from and l_date_to and'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(288) := '          p.ARCHIVED_YN = ''N'' and'||wwv_flow.LF||
'                   p.DUPLICATE_OF_PROJECT_ID is null'||wwv_flow.LF||
'        ) loo';
wwv_flow_imp.g_varchar2_table(289) := 'p'||wwv_flow.LF||
'            l_row_count := l_row_count + 1;'||wwv_flow.LF||
'            l_project := apex_escape.html(c1.project);';
wwv_flow_imp.g_varchar2_table(290) := ''||wwv_flow.LF||
'            if l_link_type = ''APP'' then'||wwv_flow.LF||
'               l_url := apex_util.prepare_url(''f?p=''||l_app';
wwv_flow_imp.g_varchar2_table(291) := '_id||'':3:''||p_apex_session||''::NO:3:FI:''||c1.friendly_identifier);'||wwv_flow.LF||
'               l_project := ''<a h';
wwv_flow_imp.g_varchar2_table(292) := 'ref="''||l_url||''">''||l_project||''</a>'';'||wwv_flow.LF||
'            elsif l_Link_type in (''EMAIL'',''JOB'') then'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(293) := '         l_url := apex_page.get_url('||wwv_flow.LF||
'                     p_application => l_app_id,'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(294) := '      p_page        => 3,'||wwv_flow.LF||
'                     p_session     => null,'||wwv_flow.LF||
'                     p_items  ';
wwv_flow_imp.g_varchar2_table(295) := '     => ''FI'','||wwv_flow.LF||
'                     p_values      => c1.FRIENDLY_IDENTIFIER,'||wwv_flow.LF||
'                     p_p';
wwv_flow_imp.g_varchar2_table(296) := 'lain_url   => TRUE );'||wwv_flow.LF||
'               if l_link_type = ''EMAIL'' then'||wwv_flow.LF||
'                  l_url := l_app_';
wwv_flow_imp.g_varchar2_table(297) := 'prefix_url || l_url; '||wwv_flow.LF||
'               end if;'||wwv_flow.LF||
'               l_project := ''<a href="''||l_url||''">''||l';
wwv_flow_imp.g_varchar2_table(298) := '_project||''</a>'';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            x7 := x7||''<li>''||l_project||'' - ''||c1.created||'' ';
wwv_flow_imp.g_varchar2_table(299) := '</li>'';'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        x7 := x7||''</ul>'';'||wwv_flow.LF||
'        if l_row_count = 0 then'||wwv_flow.LF||
'           x7 :';
wwv_flow_imp.g_varchar2_table(300) := '= x7||''No ''||l_projects_label||'' found'';'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- END CHECKING P_SHOW_PROJECTS'||wwv_flow.LF||
'    en';
wwv_flow_imp.g_varchar2_table(301) := 'd if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_show_activities = ''Y'' then'||wwv_flow.LF||
'       sys.dbms_lob.append(x, x2);'||wwv_flow.LF||
'       sys.dbms_lob.ap';
wwv_flow_imp.g_varchar2_table(302) := 'pend(x, x3);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if p_show_projects = ''Y'' then'||wwv_flow.LF||
'       sys.dbms_lob.append(x, x4);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(303) := ' if p_show_approvals = ''Y'' then'||wwv_flow.LF||
'           sys.dbms_lob.append(x, x5);'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'       sys.dbm';
wwv_flow_imp.g_varchar2_table(304) := 's_lob.append(x, x6);'||wwv_flow.LF||
'       sys.dbms_lob.append(x, x7);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    return x;'||wwv_flow.LF||
''||wwv_flow.LF||
'end generate;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'f';
wwv_flow_imp.g_varchar2_table(305) := 'unction project_exceptions ('||wwv_flow.LF||
'    p_team_member_id     in number,'||wwv_flow.LF||
'    p_links              in varchar';
wwv_flow_imp.g_varchar2_table(306) := '2 default ''NONE'','||wwv_flow.LF||
'    p_include_title_yn   in varchar2 default ''Y'','||wwv_flow.LF||
'    p_apex_session       in varc';
wwv_flow_imp.g_varchar2_table(307) := 'har2 default null )'||wwv_flow.LF||
'    return clob'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_header               clob := null;'||wwv_flow.LF||
'    l_proj_content  ';
wwv_flow_imp.g_varchar2_table(308) := '       clob := null;'||wwv_flow.LF||
'    x                      clob := null;'||wwv_flow.LF||
'    l_person               varchar2(25';
wwv_flow_imp.g_varchar2_table(309) := '5);'||wwv_flow.LF||
'    l_email                varchar2(255);'||wwv_flow.LF||
'    l_team_member_id       number;'||wwv_flow.LF||
'    l_link_type    ';
wwv_flow_imp.g_varchar2_table(310) := '        varchar2(30);'||wwv_flow.LF||
'    l_project_label        varchar2(255);'||wwv_flow.LF||
'    l_exceptions_yn        varchar2(';
wwv_flow_imp.g_varchar2_table(311) := '1) := ''N'';'||wwv_flow.LF||
'    l_reviews_yn           varchar2(1);'||wwv_flow.LF||
'    l_approvals_yn         varchar2(1);'||wwv_flow.LF||
'    l_pro';
wwv_flow_imp.g_varchar2_table(312) := 'j_except_count    int := 0;'||wwv_flow.LF||
'    l_project_max_count    int := 20;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- support for links'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(313) := '  --'||wwv_flow.LF||
'    l_project              varchar2(4000);'||wwv_flow.LF||
'    l_role                 varchar2(4000);'||wwv_flow.LF||
'    l_url';
wwv_flow_imp.g_varchar2_table(314) := '                  varchar2(4000);'||wwv_flow.LF||
'    l_app_id               varchar2(4000);'||wwv_flow.LF||
'    l_app_prefix_url   ';
wwv_flow_imp.g_varchar2_table(315) := '    varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- get settings'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    l_project_label     := sp_util.get_n';
wwv_flow_imp.g_varchar2_table(316) := 'omenclature(''PROJECT'');'||wwv_flow.LF||
'    l_app_id            := sp_util.get_setting(''APP_ID'');'||wwv_flow.LF||
'    l_app_prefix_u';
wwv_flow_imp.g_varchar2_table(317) := 'rl    := sp_util.get_setting(''APP_PREFIX_URL'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    if apex_util.get_build_option_status ('||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(318) := '   p_application_id    => l_app_id,'||wwv_flow.LF||
'           p_build_option_name => ''Reviews'') = ''INCLUDE'''||wwv_flow.LF||
'    the';
wwv_flow_imp.g_varchar2_table(319) := 'n'||wwv_flow.LF||
'         l_reviews_yn := ''Y'';'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'         l_reviews_yn := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if apex_util';
wwv_flow_imp.g_varchar2_table(320) := '.get_build_option_status ('||wwv_flow.LF||
'           p_application_id    => l_app_id,'||wwv_flow.LF||
'           p_build_option_nam';
wwv_flow_imp.g_varchar2_table(321) := 'e => ''Approvals'') = ''INCLUDE'''||wwv_flow.LF||
'    then'||wwv_flow.LF||
'         l_approvals_yn := ''Y'';'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'         l_approvals';
wwv_flow_imp.g_varchar2_table(322) := '_yn := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- determine link type'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- APP: generate links from wi';
wwv_flow_imp.g_varchar2_table(323) := 'thin the current app requires p_apex_session'||wwv_flow.LF||
'    -- EMAIL: generate fully qualified links'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(324) := ' if p_links = ''APP'' and p_apex_session is not null and l_app_id is not null then'||wwv_flow.LF||
'       l_link_type ';
wwv_flow_imp.g_varchar2_table(325) := ':= ''APP'';'||wwv_flow.LF||
'    elsif p_links = ''EMAIL'' and l_app_id is not null then'||wwv_flow.LF||
'       l_link_type := ''EMAIL'';'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(326) := '   elsif p_links = ''JOB'' and l_app_id is not null then'||wwv_flow.LF||
'       l_link_type := ''JOB'';'||wwv_flow.LF||
'    elsif p_link';
wwv_flow_imp.g_varchar2_table(327) := 's is null then'||wwv_flow.LF||
'       l_link_type := ''NONE'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- name'||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    for c1 in (';
wwv_flow_imp.g_varchar2_table(328) := ''||wwv_flow.LF||
'        select first_Name||'' ''||last_name name, email, id '||wwv_flow.LF||
'          from sp_team_members tm '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(329) := '    where id = p_team_member_id'||wwv_flow.LF||
'    ) loop '||wwv_flow.LF||
'        l_person := apex_escape.html(c1.name);'||wwv_flow.LF||
'        l';
wwv_flow_imp.g_varchar2_table(330) := '_email  := lower(apex_escape.html(c1.email));'||wwv_flow.LF||
'        l_team_member_id := c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(331) := '--'||wwv_flow.LF||
'    -- heading'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if p_include_title_yn = ''Y'' then'||wwv_flow.LF||
'       l_header := ''<h3>''||nvl(l_proje';
wwv_flow_imp.g_varchar2_table(332) := 'ct_label,''Project'')||'' Exception report for ''||l_person||''</h3>''||chr(10);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    if l';
wwv_flow_imp.g_varchar2_table(333) := '_link_type != ''APP'' then'||wwv_flow.LF||
'        l_header := l_header||''<strong>email</strong>: ''||l_email||''<br>'';'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(334) := '    end if;'||wwv_flow.LF||
'    l_header := l_header||''<i>Only above 20% complete are included.</i><br><br>'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(335) := '-'||wwv_flow.LF||
'    -- PROJECT ISSUES'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select p.id'||wwv_flow.LF||
'          from sp_projects p,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(336) := '            sp_project_priorities r'||wwv_flow.LF||
'         where p.duplicate_of_project_id is null'||wwv_flow.LF||
'           and ';
wwv_flow_imp.g_varchar2_table(337) := 'p.archived_yn = ''N'''||wwv_flow.LF||
'           and p.priority_id = r.id'||wwv_flow.LF||
'           and p.pct_complete > 20'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(338) := '  and p.pct_complete < 100'||wwv_flow.LF||
'           and (p.owner_id = l_team_member_id or '||wwv_flow.LF||
'                exists ';
wwv_flow_imp.g_varchar2_table(339) := '(select 1'||wwv_flow.LF||
'                          from sp_project_contributors'||wwv_flow.LF||
'                         where team';
wwv_flow_imp.g_varchar2_table(340) := '_member_id = l_team_member_id '||wwv_flow.LF||
'                           and project_id = p.id) )'||wwv_flow.LF||
'         order by';
wwv_flow_imp.g_varchar2_table(341) := ' r.priority, p.project'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        l_proj_content := null;'||wwv_flow.LF||
'        l_proj_content := sp_util.';
wwv_flow_imp.g_varchar2_table(342) := 'exceptions_for_project ('||wwv_flow.LF||
'                              p_project_id      => c1.id,'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(343) := '             p_one_project_yn  => ''N'','||wwv_flow.LF||
'                              p_team_member_id  => l_team_mem';
wwv_flow_imp.g_varchar2_table(344) := 'ber_id,'||wwv_flow.LF||
'                              p_link_type       => l_link_type,'||wwv_flow.LF||
'                            ';
wwv_flow_imp.g_varchar2_table(345) := '  p_app_prefix_url  => l_app_prefix_url,'||wwv_flow.LF||
'                              p_app_id          => l_app_id';
wwv_flow_imp.g_varchar2_table(346) := ','||wwv_flow.LF||
'                              p_apex_session    => p_apex_session,'||wwv_flow.LF||
'                              p';
wwv_flow_imp.g_varchar2_table(347) := '_reviews_yn      => l_reviews_yn,'||wwv_flow.LF||
'                              p_approvals_yn    => l_approvals_yn ';
wwv_flow_imp.g_varchar2_table(348) := ');'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'        if dbms_lob.getlength(l_proj_content) != 0 then'||wwv_flow.LF||
'            l_proj_except_count := l_pr';
wwv_flow_imp.g_varchar2_table(349) := 'oj_except_count + 1;'||wwv_flow.LF||
'            x := x||l_proj_content;'||wwv_flow.LF||
'        end if; '||wwv_flow.LF||
'        '||wwv_flow.LF||
'        if l_proj';
wwv_flow_imp.g_varchar2_table(350) := '_except_count = l_project_max_count and p_links in (''EMAIL'',''JOB'') then'||wwv_flow.LF||
'            x := x||''View mo';
wwv_flow_imp.g_varchar2_table(351) := 're in application...'';'||wwv_flow.LF||
'            exit;'||wwv_flow.LF||
'        end if; '||wwv_flow.LF||
''||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- END PROJECT EXCEPTI';
wwv_flow_imp.g_varchar2_table(352) := 'ONS'||wwv_flow.LF||
'    if dbms_lob.getlength(x) = 0 then'||wwv_flow.LF||
'       x := l_header||''No exceptions found'';'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(353) := '   x := l_header||x;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return x;'||wwv_flow.LF||
''||wwv_flow.LF||
'end project_exceptions;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure project_changes';
wwv_flow_imp.g_varchar2_table(354) := ' ('||wwv_flow.LF||
'    p_team_member_id     in number,'||wwv_flow.LF||
'    p_frequency          in varchar2, -- WEEKLY, WEEKDAYS'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(355) := ' p_links              in varchar2 default ''NONE'','||wwv_flow.LF||
'    p_apex_session       in varchar2 default null,';
wwv_flow_imp.g_varchar2_table(356) := ''||wwv_flow.LF||
'    p_exclude_user_yn    in varchar2 default ''N'','||wwv_flow.LF||
'    p_changes_yn         out  varchar2,  -- if N ';
wwv_flow_imp.g_varchar2_table(357) := 'changes, no email'||wwv_flow.LF||
'    p_change_summary     out  clob ) '||wwv_flow.LF||
'is'||wwv_flow.LF||
'    x                      clob := null;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(358) := '    l_person               varchar2(255);'||wwv_flow.LF||
'    l_email                varchar2(255);'||wwv_flow.LF||
'    l_team_membe';
wwv_flow_imp.g_varchar2_table(359) := 'r_id       number;'||wwv_flow.LF||
'    l_exclude_user_yn      varchar2(1);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_day                  varchar2(3) :';
wwv_flow_imp.g_varchar2_table(360) := '= to_char(sysdate,''DY'');'||wwv_flow.LF||
'    l_tsysdate             date        := trunc(sysdate);'||wwv_flow.LF||
'    l_date_from  ';
wwv_flow_imp.g_varchar2_table(361) := '          date;'||wwv_flow.LF||
'    l_row_count            int := 0;'||wwv_flow.LF||
'    l_last_project_id      number;'||wwv_flow.LF||
'    l_proj_y';
wwv_flow_imp.g_varchar2_table(362) := 'n              varchar2(1) := ''N'';'||wwv_flow.LF||
'    l_max_change_count     int := 30;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- support for l';
wwv_flow_imp.g_varchar2_table(363) := 'inks'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    l_project_label        varchar2(255);'||wwv_flow.LF||
'    l_link_type            varchar2(30);'||wwv_flow.LF||
'    l';
wwv_flow_imp.g_varchar2_table(364) := '_project              varchar2(4000);'||wwv_flow.LF||
'    l_url                  varchar2(4000);'||wwv_flow.LF||
'    l_app_id       ';
wwv_flow_imp.g_varchar2_table(365) := '        varchar2(4000);'||wwv_flow.LF||
'    l_app_prefix_url       varchar2(4000);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- get settings'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(366) := '    --'||wwv_flow.LF||
'    l_app_id            := sp_util.get_setting(''APP_ID'');'||wwv_flow.LF||
'    l_app_prefix_url    := sp_util.';
wwv_flow_imp.g_varchar2_table(367) := 'get_setting(''APP_PREFIX_URL'');'||wwv_flow.LF||
'    l_project_label     := sp_util.get_nomenclature(''PROJECT'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(368) := '--'||wwv_flow.LF||
'    -- LINK TYPE'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- APP: generate links from within the current app requires p_apex_se';
wwv_flow_imp.g_varchar2_table(369) := 'ssion'||wwv_flow.LF||
'    -- EMAIL: generate fully qualified links'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if p_links = ''APP'' and p_apex_session ';
wwv_flow_imp.g_varchar2_table(370) := 'is not null and l_app_id is not null then'||wwv_flow.LF||
'       l_link_type := ''APP'';'||wwv_flow.LF||
'    elsif p_links = ''EMAIL'' a';
wwv_flow_imp.g_varchar2_table(371) := 'nd l_app_id is not null then'||wwv_flow.LF||
'       l_link_type := ''EMAIL'';'||wwv_flow.LF||
'    elsif p_links = ''JOB'' and l_app_id i';
wwv_flow_imp.g_varchar2_table(372) := 's not null then'||wwv_flow.LF||
'       l_link_type := ''JOB'';'||wwv_flow.LF||
'    elsif p_links is null then'||wwv_flow.LF||
'       l_link_type := ''N';
wwv_flow_imp.g_varchar2_table(373) := 'ONE'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- TIMESPAN'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if p_frequency = ''WEEKDAYS'' and l_day != ''MON'' ';
wwv_flow_imp.g_varchar2_table(374) := ''||wwv_flow.LF||
'       then l_date_from := l_tsysdate - 1;'||wwv_flow.LF||
'    elsif p_frequency = ''WEEKDAYS'' and l_day = ''MON'''||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(375) := '    then l_date_from := l_tsysdate - 3;'||wwv_flow.LF||
'    elsif p_frequency = ''WEEKLY'' '||wwv_flow.LF||
'       then l_date_from :=';
wwv_flow_imp.g_varchar2_table(376) := ' l_tsysdate - 7;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- NAME'||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select first_Name||';
wwv_flow_imp.g_varchar2_table(377) := ''' ''||last_name name, email, id '||wwv_flow.LF||
'          from sp_team_members tm '||wwv_flow.LF||
'         where id = p_team_member';
wwv_flow_imp.g_varchar2_table(378) := '_id'||wwv_flow.LF||
'    ) loop '||wwv_flow.LF||
'        l_person := apex_escape.html(c1.name);'||wwv_flow.LF||
'        l_email  := lower(c1.email);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(379) := '        l_team_member_id := c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_link_type in (''EMAIL'',''JOB'') then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(380) := ' l_exclude_user_yn := nvl(apex_util.GET_preference ('||wwv_flow.LF||
'                                 p_preference =';
wwv_flow_imp.g_varchar2_table(381) := '> ''P5_PROJ_CHANGE_EXCLUDE_USER_YN'','||wwv_flow.LF||
'                                 p_user       => upper(l_email) ';
wwv_flow_imp.g_varchar2_table(382) := '),''N'');'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        l_exclude_user_yn := p_exclude_user_yn;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- HEADING'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(383) := '    --'||wwv_flow.LF||
'    x := ''<h3>''||l_project_label||'' Change report for ''||l_person||''</h3>''||chr(10);'||wwv_flow.LF||
'    x :=';
wwv_flow_imp.g_varchar2_table(384) := ' x||''<i>Changes for projects you own or have favorited</i><br/>''||chr(10);'||wwv_flow.LF||
'    if l_link_type in (''E';
wwv_flow_imp.g_varchar2_table(385) := 'MAIL'',''JOB'') and l_exclude_user_yn = ''Y'' then'||wwv_flow.LF||
'       x := x||''<i>(changes made by current user are e';
wwv_flow_imp.g_varchar2_table(386) := 'xcluded)</i><br/>'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    x := x||''<strong>timeframe</strong>: ''||case when p_frequency =';
wwv_flow_imp.g_varchar2_table(387) := ' ''WEEKDAYS'' and l_day != ''MON'''||wwv_flow.LF||
'                                                     then ''last day'''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(388) := '                                                 when p_frequency = ''WEEKDAYS'' and l_day = ''MON'''||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(389) := '                                                  then ''last 3 days'''||wwv_flow.LF||
'                               ';
wwv_flow_imp.g_varchar2_table(390) := '                  when p_frequency = ''WEEKLY'''||wwv_flow.LF||
'                                                     t';
wwv_flow_imp.g_varchar2_table(391) := 'hen ''last 7 days'''||wwv_flow.LF||
'                                                 end ||''<br><br>'';'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ';
wwv_flow_imp.g_varchar2_table(392) := '( '||wwv_flow.LF||
'        with fav as (select project_id from sp_favorites'||wwv_flow.LF||
'                      where team_member_';
wwv_flow_imp.g_varchar2_table(393) := 'id = l_team_member_id)'||wwv_flow.LF||
'        select pc.project_id,'||wwv_flow.LF||
'               p.project,'||wwv_flow.LF||
'               p.frie';
wwv_flow_imp.g_varchar2_table(394) := 'ndly_identifier,'||wwv_flow.LF||
'               '' - ''|| to_char(p.pct_complete) ||''% ''|| p.project_size ||'' P''||to_c';
wwv_flow_imp.g_varchar2_table(395) := 'har(pp.priority) quick_summary,'||wwv_flow.LF||
'               case when p.owner_id is not null then '' - ''||(select ';
wwv_flow_imp.g_varchar2_table(396) := 'first_name ||'' ''||last_name from sp_team_members where id = p.owner_id) end owner,'||wwv_flow.LF||
'               --';
wwv_flow_imp.g_varchar2_table(397) := ''||wwv_flow.LF||
'               case when pc.attribute_column = ''TAGS'' and pc.change_type = ''UPDATE'''||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(398) := '     then ''Tags, ''||sp_util.list_change ('||wwv_flow.LF||
'                                        p_old_list => pc.o';
wwv_flow_imp.g_varchar2_table(399) := 'ld_value, '||wwv_flow.LF||
'                                        p_new_list => pc.new_value )||'' '''||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(400) := '     when pc.change_type = ''CREATE'''||wwv_flow.LF||
'                    then initcap(replace(pc.attribute_column,''_''';
wwv_flow_imp.g_varchar2_table(401) := ','' ''))||'' ''||case when pc.attribute_column in (''COMMENT'',''LINK'') then ''"'' end||'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(402) := '        case when pc.attribute_column = ''COMMENT'''||wwv_flow.LF||
'                                 then substr(pc.ne';
wwv_flow_imp.g_varchar2_table(403) := 'w_value,1,40)||case when length(pc.new_value) > 40 then ''...'' end'||wwv_flow.LF||
'                                 e';
wwv_flow_imp.g_varchar2_table(404) := 'lse decode(pc.new_value,''Y'',''Yes'',''N'',''No'',pc.new_value)'||wwv_flow.LF||
'                                 end ||'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(405) := '                         case when pc.attribute_column in (''COMMENT'',''LINK'') then ''"'' end||'' added ''';
wwv_flow_imp.g_varchar2_table(406) := ''||wwv_flow.LF||
'                    when pc.change_type = ''DELETE'''||wwv_flow.LF||
'                    then initcap(replace(pc.attr';
wwv_flow_imp.g_varchar2_table(407) := 'ibute_column,''_'','' ''))||'' ''||case when pc.attribute_column in (''COMMENT'',''LINK'') then ''"'' end||'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(408) := '                         decode(pc.old_value,''Y'',''Yes'',''N'',''No'',pc.old_value)||case when pc.attribut';
wwv_flow_imp.g_varchar2_table(409) := 'e_column in (''COMMENT'',''LINK'') then ''"'' end||'' deleted '''||wwv_flow.LF||
'                    when pc.attribute_colum';
wwv_flow_imp.g_varchar2_table(410) := 'n = ''OWNER'' and pc.old_value is null and pc.new_value is not null'||wwv_flow.LF||
'                      then ''Owner ';
wwv_flow_imp.g_varchar2_table(411) := 'added "''||pc.new_value||''" '''||wwv_flow.LF||
'                    when pc.attribute_column = ''RELEASE'' and pc.old_val';
wwv_flow_imp.g_varchar2_table(412) := 'ue is null and pc.new_value is not null'||wwv_flow.LF||
'                      then ''Release added "''||pc.new_value||';
wwv_flow_imp.g_varchar2_table(413) := '''" '''||wwv_flow.LF||
'                    when pc.attribute_column = ''COMMENT'''||wwv_flow.LF||
'                      then ''Comment ch';
wwv_flow_imp.g_varchar2_table(414) := 'anged from "''||substr(pc.old_value,1,40)||case when length(pc.old_value) > 40 then ''...'' end||''" to ';
wwv_flow_imp.g_varchar2_table(415) := '"''||'||wwv_flow.LF||
'                                                substr(pc.new_value,1,40)||case when length(pc.';
wwv_flow_imp.g_varchar2_table(416) := 'new_value) > 40 then ''...'' end||''" '''||wwv_flow.LF||
'                    else initcap(replace(pc.attribute_column,''_';
wwv_flow_imp.g_varchar2_table(417) := ''','' ''))||'||wwv_flow.LF||
'                             '' changed from "''||nvl(decode(pc.old_value,''Y'',''Yes'',''N'',''No''';
wwv_flow_imp.g_varchar2_table(418) := ',pc.old_value),''NULL'')||''" to "''||'||wwv_flow.LF||
'                                                nvl(decode(pc.new';
wwv_flow_imp.g_varchar2_table(419) := '_value,''Y'',''Yes'',''N'',''No'',pc.new_value),''NULL'')||''" '''||wwv_flow.LF||
'                    end ||'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(420) := ' apex_util.get_since(pc.changed_on) || '' by '' || lower(pc.changed_by) change,'||wwv_flow.LF||
'               --'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(421) := '           case when p.owner_id = l_team_member_id then 1 else 0 end ob1,'||wwv_flow.LF||
'               pp.priority';
wwv_flow_imp.g_varchar2_table(422) := ' ob2,'||wwv_flow.LF||
'               p.pct_complete ob3,'||wwv_flow.LF||
'               pc.project_id ob4,'||wwv_flow.LF||
'               pc.changed';
wwv_flow_imp.g_varchar2_table(423) := '_on ob5'||wwv_flow.LF||
'          from sp_project_history pc,'||wwv_flow.LF||
'               sp_projects p, '||wwv_flow.LF||
'               sp_proje';
wwv_flow_imp.g_varchar2_table(424) := 'ct_priorities pp'||wwv_flow.LF||
'         where pc.project_id = p.id'||wwv_flow.LF||
'           and p.priority_id = pp.id'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(425) := ' and (p.owner_id = l_team_member_id or '||wwv_flow.LF||
'                p.id in (select project_id from fav) )'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(426) := '      and pc.changed_on > l_date_from'||wwv_flow.LF||
'           and (l_exclude_user_yn = ''N'' or pc.changed_by != l_';
wwv_flow_imp.g_varchar2_table(427) := 'email)'||wwv_flow.LF||
'           and pc.changed_by != ''nobody'''||wwv_flow.LF||
'        union all'||wwv_flow.LF||
'        select p.id project_id,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(428) := '             p.project,'||wwv_flow.LF||
'               p.friendly_identifier,'||wwv_flow.LF||
'               '' - ''|| to_char(p.pct_c';
wwv_flow_imp.g_varchar2_table(429) := 'omplete) ||''% ''|| p.project_size ||'' P''||to_char(pp.priority) quick_summary,'||wwv_flow.LF||
'               case whe';
wwv_flow_imp.g_varchar2_table(430) := 'n p.owner_id is not null then '' - ''||(select first_name ||'' ''||last_name from sp_team_members where ';
wwv_flow_imp.g_varchar2_table(431) := 'id = p.owner_id) end owner,'||wwv_flow.LF||
'               --'||wwv_flow.LF||
'               tt.task_type || case when t.task is not';
wwv_flow_imp.g_varchar2_table(432) := ' null then '' - ''||t.task end ||'' ''||'||wwv_flow.LF||
'               case when pc.attribute_column = ''TAGS'' and pc.ch';
wwv_flow_imp.g_varchar2_table(433) := 'ange_type = ''UPDATE'''||wwv_flow.LF||
'                      then ''Tags, ''||sp_util.list_change ('||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(434) := '                    p_old_list => pc.old_value, '||wwv_flow.LF||
'                                        p_new_list ';
wwv_flow_imp.g_varchar2_table(435) := '=> pc.new_value )||'' '''||wwv_flow.LF||
'                    when pc.change_type = ''CREATE'''||wwv_flow.LF||
'                      then';
wwv_flow_imp.g_varchar2_table(436) := ' initcap(replace(pc.attribute_column,''_'','' ''))||'' ''||case when pc.attribute_column in (''COMMENT'',''LI';
wwv_flow_imp.g_varchar2_table(437) := 'NK'') then ''"'' end||'||wwv_flow.LF||
'                           case when pc.attribute_column = ''COMMENT'''||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(438) := '                     then substr(pc.new_value,1,40)||case when length(pc.new_value) > 40 then ''...'' ';
wwv_flow_imp.g_varchar2_table(439) := 'end'||wwv_flow.LF||
'                                else decode(pc.new_value,''Y'',''Yes'',''N'',''No'',pc.new_value)'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(440) := '                          end ||'||wwv_flow.LF||
'                           case when pc.attribute_column in (''COMME';
wwv_flow_imp.g_varchar2_table(441) := 'NT'',''LINK'') then ''"'' end||'' added '''||wwv_flow.LF||
'                    when pc.change_type = ''DELETE'''||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(442) := '         then initcap(replace(pc.attribute_column,''_'','' ''))||'' ''||case when pc.attribute_column in (';
wwv_flow_imp.g_varchar2_table(443) := '''COMMENT'',''LINK'') then ''"'' end||'||wwv_flow.LF||
'                             decode(pc.old_value,''Y'',''Yes'',''N'',''No''';
wwv_flow_imp.g_varchar2_table(444) := ',pc.old_value)||case when pc.attribute_column in (''COMMENT'',''LINK'') then ''"'' end||'' deleted '''||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(445) := '              when pc.attribute_column = ''OWNER'' and pc.old_value is null and pc.new_value is not nu';
wwv_flow_imp.g_varchar2_table(446) := 'll'||wwv_flow.LF||
'                      then ''Owner added "''||pc.new_value||''" '''||wwv_flow.LF||
'                    when pc.attrib';
wwv_flow_imp.g_varchar2_table(447) := 'ute_column = ''COMMENT'''||wwv_flow.LF||
'                      then ''Comment changed from "''||substr(pc.old_value,1,40';
wwv_flow_imp.g_varchar2_table(448) := ')||case when length(pc.old_value) > 40 then ''...'' end||''" to "''||'||wwv_flow.LF||
'                                  ';
wwv_flow_imp.g_varchar2_table(449) := '              substr(pc.new_value,1,40)||case when length(pc.new_value) > 40 then ''...'' end||''" '''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(450) := '                  else initcap(replace(pc.attribute_column,''_'','' ''))||'||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(451) := ''' changed from "''||nvl(decode(pc.old_value,''Y'',''Yes'',''N'',''No'',pc.old_value),''NULL'')||''" to "''||'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(452) := '                                            nvl(decode(pc.new_value,''Y'',''Yes'',''N'',''No'',pc.new_value)';
wwv_flow_imp.g_varchar2_table(453) := ',''NULL'')||''" '''||wwv_flow.LF||
'                    end ||'||wwv_flow.LF||
'                    apex_util.get_since(pc.changed_on) || ';
wwv_flow_imp.g_varchar2_table(454) := ''' by '' || lower(pc.changed_by) change,'||wwv_flow.LF||
'               --'||wwv_flow.LF||
'               case when p.owner_id = l_tea';
wwv_flow_imp.g_varchar2_table(455) := 'm_member_id then 1 else 0 end ob1,'||wwv_flow.LF||
'               pp.priority ob2,'||wwv_flow.LF||
'               p.pct_complete ob3';
wwv_flow_imp.g_varchar2_table(456) := ','||wwv_flow.LF||
'               p.id ob4,'||wwv_flow.LF||
'               pc.changed_on ob5'||wwv_flow.LF||
'          from sp_task_history pc,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(457) := '          sp_tasks t,'||wwv_flow.LF||
'               sp_projects p, '||wwv_flow.LF||
'               sp_project_priorities pp,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(458) := '         sp_task_types tt'||wwv_flow.LF||
'         where p.id = t.project_id'||wwv_flow.LF||
'           and pc.task_id = t.id'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(459) := '     and p.priority_id = pp.id'||wwv_flow.LF||
'           and nvl(t.task_sub_type_id,t.task_type_id) = tt.id'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(460) := '    and p.owner_id = l_team_member_id'||wwv_flow.LF||
'           and pc.changed_on > l_date_from'||wwv_flow.LF||
'           and (l_e';
wwv_flow_imp.g_varchar2_table(461) := 'xclude_user_yn = ''N'' or pc.changed_by != l_email)'||wwv_flow.LF||
'         order by ob1, ob2, ob3 desc, ob4, ob5 des';
wwv_flow_imp.g_varchar2_table(462) := 'c'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'        if l_last_project_id is null or l_last_project_id != c1.project_id then'||wwv_flow.LF||
''||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(463) := '       -- CREATE PROJECT HEADER TO BREAK ON'||wwv_flow.LF||
'            if l_link_type = ''APP'' then'||wwv_flow.LF||
'               l';
wwv_flow_imp.g_varchar2_table(464) := '_url := apex_util.prepare_url(''f?p=''||l_app_id||'':3:''||p_apex_session||''::NO:3:FI:''||apex_escape.htm';
wwv_flow_imp.g_varchar2_table(465) := 'l(c1.friendly_identifier));'||wwv_flow.LF||
'               l_project := ''<a href="''||l_url||''"><strong>''||apex_escap';
wwv_flow_imp.g_varchar2_table(466) := 'e.html(c1.project)||''</strong></a>'';'||wwv_flow.LF||
'            elsif l_link_type in (''EMAIL'',''JOB'') then'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(467) := '      l_url := apex_page.get_url('||wwv_flow.LF||
'                            p_application => l_app_id,'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(468) := '                 p_page        => 3,'||wwv_flow.LF||
'                            p_session     => null,'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(469) := '                p_items       => ''FI'','||wwv_flow.LF||
'                            p_values      => c1.friendly_iden';
wwv_flow_imp.g_varchar2_table(470) := 'tifier,'||wwv_flow.LF||
'                            p_plain_url   => TRUE );'||wwv_flow.LF||
'               if l_link_type = ''EMAIL''';
wwv_flow_imp.g_varchar2_table(471) := ' then'||wwv_flow.LF||
'                  l_url := l_app_prefix_url || l_url; '||wwv_flow.LF||
'               end if;'||wwv_flow.LF||
'               l';
wwv_flow_imp.g_varchar2_table(472) := '_project := ''<a href="''||l_url||''"><strong>''||apex_escape.html(c1.project)||''</strong></a>'';'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(473) := '     else'||wwv_flow.LF||
'               l_project := ''<strong>''||apex_escape.html(c1.project)||''</strong>'';'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(474) := '     end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'            if l_row_count = 0 then'||wwv_flow.LF||
'                x := x|| l_project || apex_escape.';
wwv_flow_imp.g_varchar2_table(475) := 'html(c1.owner) || apex_escape.html(c1.quick_summary) ||''<ul>''||chr(10);'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(476) := '     x := x||''</ul>''|| l_project || apex_escape.html(c1.owner) || apex_escape.html(c1.quick_summary)';
wwv_flow_imp.g_varchar2_table(477) := ' ||''<ul>''||chr(10);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        x := x||''<li>''||apex_escape.html(c1';
wwv_flow_imp.g_varchar2_table(478) := '.change)||''</li>''||chr(10);'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_last_project_id := c1.project_id;'||wwv_flow.LF||
'        l_row_count := l_ro';
wwv_flow_imp.g_varchar2_table(479) := 'w_count + 1;'||wwv_flow.LF||
''||wwv_flow.LF||
'        if p_links in (''EMAIL'',''JOB'') and l_row_count = l_max_change_count then'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(480) := '     x := x||''View more in application...'';'||wwv_flow.LF||
'           exit;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if ';
wwv_flow_imp.g_varchar2_table(481) := 'l_row_count = 0 then'||wwv_flow.LF||
'       p_changes_yn := ''N'';'||wwv_flow.LF||
'       p_change_summary := null;'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'       x ';
wwv_flow_imp.g_varchar2_table(482) := ':= x||''</ul>'';'||wwv_flow.LF||
'       p_changes_yn := ''Y'';'||wwv_flow.LF||
'       p_change_summary := x;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'end project_ch';
wwv_flow_imp.g_varchar2_table(483) := 'anges;'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_contributor_summary;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(40922002279481301958)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_contributor_summary body'
,p_sequence=>7040
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
