prompt --application/deployment/install/install_sp_activity_types_triggers
begin
--   Manifest
--     INSTALL: INSTALL- sp_activity_types triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_activity_types_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_activity_types';
wwv_flow_imp.g_varchar2_table(2) := ''||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(3) := '        :new.created_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user';
wwv_flow_imp.g_varchar2_table(4) := '));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.update';
wwv_flow_imp.g_varchar2_table(5) := 'd_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.u';
wwv_flow_imp.g_varchar2_table(6) := 'pdated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),use';
wwv_flow_imp.g_varchar2_table(7) := 'r);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.is_active_yn is null then'||wwv_flow.LF||
'       :new.is_active_yn := ''Y'';'||wwv_flow.LF||
'    en';
wwv_flow_imp.g_varchar2_table(8) := 'd if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        insert into sp_app_log'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(9) := '(activity, details)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (''Added Activity Type'' , :new.activity_type);'||wwv_flow.LF||
'    els';
wwv_flow_imp.g_varchar2_table(10) := 'if updating then'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.activity_type,:new.activity_type) the';
wwv_flow_imp.g_varchar2_table(11) := 'n'||wwv_flow.LF||
'            insert into sp_app_log'||wwv_flow.LF||
'                (activity, details)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(12) := '        (''Updated Activity Type'' , ''Changed "''||:old.activity_type ||''" to "''||:new.activity_type||''';
wwv_flow_imp.g_varchar2_table(13) := '"'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.STATIC_ID,:new.STATIC_ID) then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(14) := '          insert into sp_app_log'||wwv_flow.LF||
'                (activity, details)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(15) := '    (''Updated Activity Type'' , :new.activity_type||'': changed STATIC_ID from "''||:old.STATIC_ID||''" ';
wwv_flow_imp.g_varchar2_table(16) := 'to "''||:new.STATIC_ID||''"'');'||wwv_flow.LF||
'        end if;      '||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.IS_';
wwv_flow_imp.g_varchar2_table(17) := 'DEFAULT_YN,:new.IS_DEFAULT_YN) then'||wwv_flow.LF||
'            insert into sp_app_log'||wwv_flow.LF||
'                (activity, de';
wwv_flow_imp.g_varchar2_table(18) := 'tails)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (''Updated Activity Type'' , :new.activity_type||'': changed ';
wwv_flow_imp.g_varchar2_table(19) := 'IS_DEFAULT from "''||:old.IS_DEFAULT_YN||''" to "''||:new.IS_DEFAULT_YN||''"'');'||wwv_flow.LF||
'        end if;   '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(20) := '   if not sp_value_compare.is_equal(:old.IS_ACTIVE_YN,:new.IS_ACTIVE_YN) then'||wwv_flow.LF||
'            insert int';
wwv_flow_imp.g_varchar2_table(21) := 'o sp_app_log'||wwv_flow.LF||
'                (activity, details)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (''Updated Activi';
wwv_flow_imp.g_varchar2_table(22) := 'ty Type'' , :new.activity_type||'': changed IS_ACTIVE from "''||:old.IS_ACTIVE_YN||''" to "''||:new.IS_AC';
wwv_flow_imp.g_varchar2_table(23) := 'TIVE_YN||''"'');'||wwv_flow.LF||
'        end if;       '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_activity_types_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace tr';
wwv_flow_imp.g_varchar2_table(24) := 'igger sp_activity_types_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_activity_types'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    ins';
wwv_flow_imp.g_varchar2_table(25) := 'ert into sp_app_log'||wwv_flow.LF||
'        (activity, details)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (''Deleted Activity Type'', :old.ac';
wwv_flow_imp.g_varchar2_table(26) := 'tivity_type);'||wwv_flow.LF||
'end sp_activity_types_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(50990981462053841129)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>' sp_activity_types triggers'
,p_sequence=>4170
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
