prompt --application/deployment/install/install_sp_error_log_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_error_log table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_error_log ('||wwv_flow.LF||
'   id                     number default on null to_number(sys_guid(), ''';
wwv_flow_imp.g_varchar2_table(2) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                              constraint sp_error_log_pk primary';
wwv_flow_imp.g_varchar2_table(3) := ' key,'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   package_name           varchar2(255 char),'||wwv_flow.LF||
'   procedure_name         varchar2(500 cha';
wwv_flow_imp.g_varchar2_table(4) := 'r),'||wwv_flow.LF||
'   error                  varchar2(4000 char)  not null,'||wwv_flow.LF||
'   error_backtrace        varchar2(4000';
wwv_flow_imp.g_varchar2_table(5) := ' char),'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   arg1_name              varchar2(255 char),'||wwv_flow.LF||
'   arg1_val               varchar2(4000 ';
wwv_flow_imp.g_varchar2_table(6) := 'char),'||wwv_flow.LF||
'   arg2_name              varchar2(255 char),'||wwv_flow.LF||
'   arg2_val               varchar2(4000 char),'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(7) := '   arg3_name              varchar2(255 char),'||wwv_flow.LF||
'   arg3_val               varchar2(4000 char),'||wwv_flow.LF||
'   arg4';
wwv_flow_imp.g_varchar2_table(8) := '_name              varchar2(255 char),'||wwv_flow.LF||
'   arg4_val               varchar2(4000 char),'||wwv_flow.LF||
'   arg5_name  ';
wwv_flow_imp.g_varchar2_table(9) := '            varchar2(255 char),'||wwv_flow.LF||
'   arg5_val               varchar2(4000 char),'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   created     ';
wwv_flow_imp.g_varchar2_table(10) := '           date,'||wwv_flow.LF||
'   created_trunc          date,'||wwv_flow.LF||
'   created_by             varchar2(255 char)'||wwv_flow.LF||
');'||wwv_flow.LF||
'cre';
wwv_flow_imp.g_varchar2_table(11) := 'ate index sp_error_log_i1 on sp_error_log (created_trunc);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_error_log_b';
wwv_flow_imp.g_varchar2_table(12) := 'i'||wwv_flow.LF||
'    before insert'||wwv_flow.LF||
'    on sp_error_log'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   :new.created       := nvl(:new.cre';
wwv_flow_imp.g_varchar2_table(13) := 'ated,sysdate);'||wwv_flow.LF||
'   :new.created_trunc := trunc(:new.created);'||wwv_flow.LF||
'   :new.created_by    := nvl(:new.creat';
wwv_flow_imp.g_varchar2_table(14) := 'ed_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'end sp_error_log_bi;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(31601651557589722024)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_error_log table and trigger'
,p_sequence=>3020
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
