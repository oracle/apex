prompt --application/deployment/install/install_sample_data_insight_1_0
begin
--   Manifest
--     INSTALL: INSTALL-sample data - insight 1.0
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'sp_globals.g_audit_this := FALSE;'||wwv_flow.LF||
''||wwv_flow.LF||
'insert all'||wwv_flow.LF||
' into sp_projects (id,initiative_id,project,own';
wwv_flow_imp.g_varchar2_table(2) := 'er_id,active_yn,priority_id,release_id,target_complete,pct_complete,status_id,project_size,status_sc';
wwv_flow_imp.g_varchar2_table(3) := 'ale,description,tags,focus_area_id,created,created_by,updated,updated_by) values (8001,1,''Customer B';
wwv_flow_imp.g_varchar2_table(4) := 'ehavior Analytics'',1,''N'',2,7,sp_util.fix_demo_dates(sysdate-92),100,1,''L'',''A'',''Delivered customer be';
wwv_flow_imp.g_varchar2_table(5) := 'havior dashboards and conversion analysis.'',''insightiq,analytics,customer-behavior'',6,sp_util.fix_de';
wwv_flow_imp.g_varchar2_table(6) := 'mo_dates(sysdate-200),''SCOTT.TIGER@ACME.COM'',sp_util.fix_demo_dates(sysdate-90),''SCOTT.TIGER@ACME.CO';
wwv_flow_imp.g_varchar2_table(7) := 'M'')'||wwv_flow.LF||
' into sp_projects (id,initiative_id,project,owner_id,active_yn,priority_id,release_id,target_com';
wwv_flow_imp.g_varchar2_table(8) := 'plete,pct_complete,status_id,project_size,status_scale,description,tags,focus_area_id,created,create';
wwv_flow_imp.g_varchar2_table(9) := 'd_by,updated,updated_by) values (8002,3,''Personalized Recommendations Engine'',3,''N'',1,7,sp_util.fix_';
wwv_flow_imp.g_varchar2_table(10) := 'demo_dates(sysdate-90),100,1,''XL'',''A'',''Delivered recommendation models and an API for personalized e';
wwv_flow_imp.g_varchar2_table(11) := 'xperiences.'',''insightiq,ai,recommendations'',30,sp_util.fix_demo_dates(sysdate-200),''ELENA.VARGAS@ACM';
wwv_flow_imp.g_varchar2_table(12) := 'E.COM'',sp_util.fix_demo_dates(sysdate-90),''ELENA.VARGAS@ACME.COM'')'||wwv_flow.LF||
' into sp_projects (id,initiative_';
wwv_flow_imp.g_varchar2_table(13) := 'id,project,owner_id,active_yn,priority_id,release_id,target_complete,pct_complete,status_id,project_';
wwv_flow_imp.g_varchar2_table(14) := 'size,status_scale,description,tags,focus_area_id,created,created_by,updated,updated_by) values (8003';
wwv_flow_imp.g_varchar2_table(15) := ',3,''Demand Forecasting Models'',5,''N'',2,7,sp_util.fix_demo_dates(sysdate-94),100,1,''XL'',''A'',''Delivere';
wwv_flow_imp.g_varchar2_table(16) := 'd demand forecasts for operations planning and customer demand signals.'',''insightiq,ai,forecasting'',';
wwv_flow_imp.g_varchar2_table(17) := '30,sp_util.fix_demo_dates(sysdate-200),''NAOMI.CHEN@ACME.COM'',sp_util.fix_demo_dates(sysdate-90),''NAO';
wwv_flow_imp.g_varchar2_table(18) := 'MI.CHEN@ACME.COM'')'||wwv_flow.LF||
' into sp_projects (id,initiative_id,project,owner_id,active_yn,priority_id,releas';
wwv_flow_imp.g_varchar2_table(19) := 'e_id,target_complete,pct_complete,status_id,project_size,status_scale,description,tags,focus_area_id';
wwv_flow_imp.g_varchar2_table(20) := ',created,created_by,updated,updated_by) values (8004,1,''Customer Journey Insights'',7,''N'',2,7,sp_util';
wwv_flow_imp.g_varchar2_table(21) := '.fix_demo_dates(sysdate-93),100,1,''L'',''A'',''Delivered end-to-end customer journey reporting and drop-';
wwv_flow_imp.g_varchar2_table(22) := 'off analysis.'',''insightiq,journey,customer-systems'',1,sp_util.fix_demo_dates(sysdate-200),''CALEB.FOS';
wwv_flow_imp.g_varchar2_table(23) := 'TER@ACME.COM'',sp_util.fix_demo_dates(sysdate-90),''CALEB.FOSTER@ACME.COM'')'||wwv_flow.LF||
' into sp_projects (id,init';
wwv_flow_imp.g_varchar2_table(24) := 'iative_id,project,owner_id,active_yn,priority_id,release_id,target_complete,pct_complete,status_id,p';
wwv_flow_imp.g_varchar2_table(25) := 'roject_size,status_scale,description,tags,focus_area_id,created,created_by,updated,updated_by) value';
wwv_flow_imp.g_varchar2_table(26) := 's (8005,3,''Support Intelligence Classifier'',9,''N'',2,7,sp_util.fix_demo_dates(sysdate-91),100,1,''L'',''';
wwv_flow_imp.g_varchar2_table(27) := 'A'',''Delivered AI classification for support requests and routing insights.'',''insightiq,ai,support'',3';
wwv_flow_imp.g_varchar2_table(28) := '0,sp_util.fix_demo_dates(sysdate-200),''ANDRE.COLLINS@ACME.COM'',sp_util.fix_demo_dates(sysdate-90),''A';
wwv_flow_imp.g_varchar2_table(29) := 'NDRE.COLLINS@ACME.COM'')'||wwv_flow.LF||
' into sp_projects (id,initiative_id,project,owner_id,active_yn,priority_id,r';
wwv_flow_imp.g_varchar2_table(30) := 'elease_id,target_complete,pct_complete,status_id,project_size,status_scale,description,tags,focus_ar';
wwv_flow_imp.g_varchar2_table(31) := 'ea_id,created,created_by,updated,updated_by) values (8006,1,''Data Quality Monitoring'',11,''N'',1,7,sp_';
wwv_flow_imp.g_varchar2_table(32) := 'util.fix_demo_dates(sysdate-90),100,1,''L'',''A'',''Delivered source-data quality checks, alerts, and rem';
wwv_flow_imp.g_varchar2_table(33) := 'ediation dashboards.'',''insightiq,analytics,data-quality'',6,sp_util.fix_demo_dates(sysdate-200),''VICT';
wwv_flow_imp.g_varchar2_table(34) := 'OR.RAMIREZ@ACME.COM'',sp_util.fix_demo_dates(sysdate-90),''VICTOR.RAMIREZ@ACME.COM'')'||wwv_flow.LF||
' into sp_projects';
wwv_flow_imp.g_varchar2_table(35) := ' (id,initiative_id,project,owner_id,active_yn,priority_id,release_id,target_complete,pct_complete,st';
wwv_flow_imp.g_varchar2_table(36) := 'atus_id,project_size,status_scale,description,tags,focus_area_id,created,created_by,updated,updated_';
wwv_flow_imp.g_varchar2_table(37) := 'by) values (8007,1,''InsightIQ Executive Dashboards'',13,''N'',3,7,sp_util.fix_demo_dates(sysdate-95),10';
wwv_flow_imp.g_varchar2_table(38) := '0,1,''M'',''A'',''Delivered executive KPI dashboards with drill-through reporting.'',''insightiq,analytics,';
wwv_flow_imp.g_varchar2_table(39) := 'dashboards'',6,sp_util.fix_demo_dates(sysdate-200),''ISAAC.TURNER@ACME.COM'',sp_util.fix_demo_dates(sys';
wwv_flow_imp.g_varchar2_table(40) := 'date-90),''ISAAC.TURNER@ACME.COM'')'||wwv_flow.LF||
' into sp_projects (id,initiative_id,project,owner_id,active_yn,pri';
wwv_flow_imp.g_varchar2_table(41) := 'ority_id,release_id,target_complete,pct_complete,status_id,project_size,status_scale,description,tag';
wwv_flow_imp.g_varchar2_table(42) := 's,focus_area_id,created,created_by,updated,updated_by) values (8008,3,''Customer Segmentation Models''';
wwv_flow_imp.g_varchar2_table(43) := ',15,''N'',2,7,sp_util.fix_demo_dates(sysdate-92),100,1,''L'',''A'',''Delivered behavioral customer segments';
wwv_flow_imp.g_varchar2_table(44) := ' for insight and targeting use cases.'',''insightiq,ai,segmentation'',30,sp_util.fix_demo_dates(sysdate';
wwv_flow_imp.g_varchar2_table(45) := '-200),''DOMINIC.REYES@ACME.COM'',sp_util.fix_demo_dates(sysdate-90),''DOMINIC.REYES@ACME.COM'')'||wwv_flow.LF||
' into sp';
wwv_flow_imp.g_varchar2_table(46) := '_projects (id,initiative_id,project,owner_id,active_yn,priority_id,release_id,target_complete,pct_co';
wwv_flow_imp.g_varchar2_table(47) := 'mplete,status_id,project_size,status_scale,description,tags,focus_area_id,created,created_by,updated';
wwv_flow_imp.g_varchar2_table(48) := ',updated_by) values (8009,1,''Experimentation Analytics'',17,''N'',3,7,sp_util.fix_demo_dates(sysdate-94';
wwv_flow_imp.g_varchar2_table(49) := '),100,1,''M'',''A'',''Delivered experiment measurement and statistical-result reporting.'',''insightiq,anal';
wwv_flow_imp.g_varchar2_table(50) := 'ytics,experimentation'',6,sp_util.fix_demo_dates(sysdate-200),''ETHAN.CALDWELL@ACME.COM'',sp_util.fix_d';
wwv_flow_imp.g_varchar2_table(51) := 'emo_dates(sysdate-90),''ETHAN.CALDWELL@ACME.COM'')'||wwv_flow.LF||
' into sp_projects (id,initiative_id,project,owner_i';
wwv_flow_imp.g_varchar2_table(52) := 'd,active_yn,priority_id,release_id,target_complete,pct_complete,status_id,project_size,status_scale,';
wwv_flow_imp.g_varchar2_table(53) := 'description,tags,focus_area_id,created,created_by,updated,updated_by) values (8010,1,''InsightIQ Data';
wwv_flow_imp.g_varchar2_table(54) := ' Access Controls'',19,''N'',1,7,sp_util.fix_demo_dates(sysdate-90),100,1,''L'',''A'',''Delivered role-based ';
wwv_flow_imp.g_varchar2_table(55) := 'access controls and audit reporting for analytics data.'',''insightiq,security,data-access'',4,sp_util.';
wwv_flow_imp.g_varchar2_table(56) := 'fix_demo_dates(sysdate-200),''LUCAS.BENNETT@ACME.COM'',sp_util.fix_demo_dates(sysdate-90),''LUCAS.BENNE';
wwv_flow_imp.g_varchar2_table(57) := 'TT@ACME.COM'')'||wwv_flow.LF||
'select 1 from dual;'||wwv_flow.LF||
''||wwv_flow.LF||
'insert all'||wwv_flow.LF||
' into sp_project_contributors (id,project_id,team_memb';
wwv_flow_imp.g_varchar2_table(58) := 'er_id,responsibility_id,responsibility,tags,created,created_by,updated,updated_by) values (8101,8001';
wwv_flow_imp.g_varchar2_table(59) := ',1,3,''Leads delivery and stakeholder reporting.'',''project-management'',sp_util.fix_demo_dates(sysdate';
wwv_flow_imp.g_varchar2_table(60) := '-198),''SCOTT.TIGER@ACME.COM'',sp_util.fix_demo_dates(sysdate-198),''SCOTT.TIGER@ACME.COM'') into sp_pro';
wwv_flow_imp.g_varchar2_table(61) := 'ject_contributors (id,project_id,team_member_id,responsibility_id,responsibility,tags,created,create';
wwv_flow_imp.g_varchar2_table(62) := 'd_by,updated,updated_by) values (8102,8001,2,1,''Builds behavior dashboards.'',''analytics,development''';
wwv_flow_imp.g_varchar2_table(63) := ',sp_util.fix_demo_dates(sysdate-198),''SCOTT.TIGER@ACME.COM'',sp_util.fix_demo_dates(sysdate-198),''SCO';
wwv_flow_imp.g_varchar2_table(64) := 'TT.TIGER@ACME.COM'')'||wwv_flow.LF||
' into sp_project_contributors (id,project_id,team_member_id,responsibility_id,re';
wwv_flow_imp.g_varchar2_table(65) := 'sponsibility,tags,created,created_by,updated,updated_by) values (8103,8002,3,3,''Leads recommendation';
wwv_flow_imp.g_varchar2_table(66) := ' delivery.'',''project-management'',sp_util.fix_demo_dates(sysdate-198),''ELENA.VARGAS@ACME.COM'',sp_util';
wwv_flow_imp.g_varchar2_table(67) := '.fix_demo_dates(sysdate-198),''ELENA.VARGAS@ACME.COM'') into sp_project_contributors (id,project_id,te';
wwv_flow_imp.g_varchar2_table(68) := 'am_member_id,responsibility_id,responsibility,tags,created,created_by,updated,updated_by) values (81';
wwv_flow_imp.g_varchar2_table(69) := '04,8002,4,1,''Builds recommendation API.'',''ai,development'',sp_util.fix_demo_dates(sysdate-198),''ELENA';
wwv_flow_imp.g_varchar2_table(70) := '.VARGAS@ACME.COM'',sp_util.fix_demo_dates(sysdate-198),''ELENA.VARGAS@ACME.COM'')'||wwv_flow.LF||
' into sp_project_cont';
wwv_flow_imp.g_varchar2_table(71) := 'ributors (id,project_id,team_member_id,responsibility_id,responsibility,tags,created,created_by,upda';
wwv_flow_imp.g_varchar2_table(72) := 'ted,updated_by) values (8105,8003,5,3,''Leads forecasting delivery.'',''project-management'',sp_util.fix';
wwv_flow_imp.g_varchar2_table(73) := '_demo_dates(sysdate-198),''NAOMI.CHEN@ACME.COM'',sp_util.fix_demo_dates(sysdate-198),''NAOMI.CHEN@ACME.';
wwv_flow_imp.g_varchar2_table(74) := 'COM'') into sp_project_contributors (id,project_id,team_member_id,responsibility_id,responsibility,ta';
wwv_flow_imp.g_varchar2_table(75) := 'gs,created,created_by,updated,updated_by) values (8106,8003,6,7,''Validates forecast assumptions.'',''r';
wwv_flow_imp.g_varchar2_table(76) := 'esearch,ai'',sp_util.fix_demo_dates(sysdate-198),''NAOMI.CHEN@ACME.COM'',sp_util.fix_demo_dates(sysdate';
wwv_flow_imp.g_varchar2_table(77) := '-198),''NAOMI.CHEN@ACME.COM'')'||wwv_flow.LF||
' into sp_project_contributors (id,project_id,team_member_id,responsibil';
wwv_flow_imp.g_varchar2_table(78) := 'ity_id,responsibility,tags,created,created_by,updated,updated_by) values (8107,8004,7,3,''Leads journ';
wwv_flow_imp.g_varchar2_table(79) := 'ey insight delivery.'',''project-management'',sp_util.fix_demo_dates(sysdate-198),''CALEB.FOSTER@ACME.CO';
wwv_flow_imp.g_varchar2_table(80) := 'M'',sp_util.fix_demo_dates(sysdate-198),''CALEB.FOSTER@ACME.COM'') into sp_project_contributors (id,pro';
wwv_flow_imp.g_varchar2_table(81) := 'ject_id,team_member_id,responsibility_id,responsibility,tags,created,created_by,updated,updated_by) ';
wwv_flow_imp.g_varchar2_table(82) := 'values (8108,8004,8,8,''Designs journey visualizations.'',''ux,analytics'',sp_util.fix_demo_dates(sysdat';
wwv_flow_imp.g_varchar2_table(83) := 'e-198),''CALEB.FOSTER@ACME.COM'',sp_util.fix_demo_dates(sysdate-198),''CALEB.FOSTER@ACME.COM'')'||wwv_flow.LF||
' into sp';
wwv_flow_imp.g_varchar2_table(84) := '_project_contributors (id,project_id,team_member_id,responsibility_id,responsibility,tags,created,cr';
wwv_flow_imp.g_varchar2_table(85) := 'eated_by,updated,updated_by) values (8109,8005,9,3,''Leads support intelligence delivery.'',''project-m';
wwv_flow_imp.g_varchar2_table(86) := 'anagement'',sp_util.fix_demo_dates(sysdate-198),''ANDRE.COLLINS@ACME.COM'',sp_util.fix_demo_dates(sysda';
wwv_flow_imp.g_varchar2_table(87) := 'te-198),''ANDRE.COLLINS@ACME.COM'') into sp_project_contributors (id,project_id,team_member_id,respons';
wwv_flow_imp.g_varchar2_table(88) := 'ibility_id,responsibility,tags,created,created_by,updated,updated_by) values (8110,8005,10,1,''Builds';
wwv_flow_imp.g_varchar2_table(89) := ' classification workflow.'',''ai,development'',sp_util.fix_demo_dates(sysdate-198),''ANDRE.COLLINS@ACME.';
wwv_flow_imp.g_varchar2_table(90) := 'COM'',sp_util.fix_demo_dates(sysdate-198),''ANDRE.COLLINS@ACME.COM'')'||wwv_flow.LF||
' into sp_project_contributors (id';
wwv_flow_imp.g_varchar2_table(91) := ',project_id,team_member_id,responsibility_id,responsibility,tags,created,created_by,updated,updated_';
wwv_flow_imp.g_varchar2_table(92) := 'by) values (8111,8006,11,3,''Leads data-quality delivery.'',''project-management'',sp_util.fix_demo_date';
wwv_flow_imp.g_varchar2_table(93) := 's(sysdate-198),''VICTOR.RAMIREZ@ACME.COM'',sp_util.fix_demo_dates(sysdate-198),''VICTOR.RAMIREZ@ACME.CO';
wwv_flow_imp.g_varchar2_table(94) := 'M'') into sp_project_contributors (id,project_id,team_member_id,responsibility_id,responsibility,tags';
wwv_flow_imp.g_varchar2_table(95) := ',created,created_by,updated,updated_by) values (8112,8006,12,5,''Validates quality controls.'',''qa,dat';
wwv_flow_imp.g_varchar2_table(96) := 'a-quality'',sp_util.fix_demo_dates(sysdate-198),''VICTOR.RAMIREZ@ACME.COM'',sp_util.fix_demo_dates(sysd';
wwv_flow_imp.g_varchar2_table(97) := 'ate-198),''VICTOR.RAMIREZ@ACME.COM'')'||wwv_flow.LF||
' into sp_project_contributors (id,project_id,team_member_id,resp';
wwv_flow_imp.g_varchar2_table(98) := 'onsibility_id,responsibility,tags,created,created_by,updated,updated_by) values (8113,8007,13,3,''Lea';
wwv_flow_imp.g_varchar2_table(99) := 'ds dashboard delivery.'',''project-management'',sp_util.fix_demo_dates(sysdate-198),''ISAAC.TURNER@ACME.';
wwv_flow_imp.g_varchar2_table(100) := 'COM'',sp_util.fix_demo_dates(sysdate-198),''ISAAC.TURNER@ACME.COM'') into sp_project_contributors (id,p';
wwv_flow_imp.g_varchar2_table(101) := 'roject_id,team_member_id,responsibility_id,responsibility,tags,created,created_by,updated,updated_by';
wwv_flow_imp.g_varchar2_table(102) := ') values (8114,8007,14,8,''Designs executive dashboard views.'',''ux,analytics'',sp_util.fix_demo_dates(';
wwv_flow_imp.g_varchar2_table(103) := 'sysdate-198),''ISAAC.TURNER@ACME.COM'',sp_util.fix_demo_dates(sysdate-198),''ISAAC.TURNER@ACME.COM'')'||wwv_flow.LF||
' i';
wwv_flow_imp.g_varchar2_table(104) := 'nto sp_project_contributors (id,project_id,team_member_id,responsibility_id,responsibility,tags,crea';
wwv_flow_imp.g_varchar2_table(105) := 'ted,created_by,updated,updated_by) values (8115,8008,15,3,''Leads segmentation delivery.'',''project-ma';
wwv_flow_imp.g_varchar2_table(106) := 'nagement'',sp_util.fix_demo_dates(sysdate-198),''DOMINIC.REYES@ACME.COM'',sp_util.fix_demo_dates(sysdat';
wwv_flow_imp.g_varchar2_table(107) := 'e-198),''DOMINIC.REYES@ACME.COM'') into sp_project_contributors (id,project_id,team_member_id,responsi';
wwv_flow_imp.g_varchar2_table(108) := 'bility_id,responsibility,tags,created,created_by,updated,updated_by) values (8116,8008,16,7,''Evaluat';
wwv_flow_imp.g_varchar2_table(109) := 'es segment quality.'',''research,ai'',sp_util.fix_demo_dates(sysdate-198),''DOMINIC.REYES@ACME.COM'',sp_u';
wwv_flow_imp.g_varchar2_table(110) := 'til.fix_demo_dates(sysdate-198),''DOMINIC.REYES@ACME.COM'')'||wwv_flow.LF||
' into sp_project_contributors (id,project_';
wwv_flow_imp.g_varchar2_table(111) := 'id,team_member_id,responsibility_id,responsibility,tags,created,created_by,updated,updated_by) value';
wwv_flow_imp.g_varchar2_table(112) := 's (8117,8009,17,3,''Leads experimentation delivery.'',''project-management'',sp_util.fix_demo_dates(sysd';
wwv_flow_imp.g_varchar2_table(113) := 'ate-198),''ETHAN.CALDWELL@ACME.COM'',sp_util.fix_demo_dates(sysdate-198),''ETHAN.CALDWELL@ACME.COM'') in';
wwv_flow_imp.g_varchar2_table(114) := 'to sp_project_contributors (id,project_id,team_member_id,responsibility_id,responsibility,tags,creat';
wwv_flow_imp.g_varchar2_table(115) := 'ed,created_by,updated,updated_by) values (8118,8009,18,1,''Builds experiment reporting.'',''analytics,d';
wwv_flow_imp.g_varchar2_table(116) := 'evelopment'',sp_util.fix_demo_dates(sysdate-198),''ETHAN.CALDWELL@ACME.COM'',sp_util.fix_demo_dates(sys';
wwv_flow_imp.g_varchar2_table(117) := 'date-198),''ETHAN.CALDWELL@ACME.COM'')'||wwv_flow.LF||
' into sp_project_contributors (id,project_id,team_member_id,res';
wwv_flow_imp.g_varchar2_table(118) := 'ponsibility_id,responsibility,tags,created,created_by,updated,updated_by) values (8119,8010,19,3,''Le';
wwv_flow_imp.g_varchar2_table(119) := 'ads access-control delivery.'',''project-management'',sp_util.fix_demo_dates(sysdate-198),''LUCAS.BENNET';
wwv_flow_imp.g_varchar2_table(120) := 'T@ACME.COM'',sp_util.fix_demo_dates(sysdate-198),''LUCAS.BENNETT@ACME.COM'') into sp_project_contributo';
wwv_flow_imp.g_varchar2_table(121) := 'rs (id,project_id,team_member_id,responsibility_id,responsibility,tags,created,created_by,updated,up';
wwv_flow_imp.g_varchar2_table(122) := 'dated_by) values (8120,8010,20,2,''Reviews data-security architecture.'',''architecture,security'',sp_ut';
wwv_flow_imp.g_varchar2_table(123) := 'il.fix_demo_dates(sysdate-198),''LUCAS.BENNETT@ACME.COM'',sp_util.fix_demo_dates(sysdate-198),''LUCAS.B';
wwv_flow_imp.g_varchar2_table(124) := 'ENNETT@ACME.COM'')'||wwv_flow.LF||
'select 1 from dual;'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_project_comments (id,project_id,author_id,body';
wwv_flow_imp.g_varchar2_table(125) := ',body_html,body_no_images,private_yn,created,created_by,updated,updated_by) values (9201,8001,1,''Beh';
wwv_flow_imp.g_varchar2_table(126) := 'avior dashboards were limited to approved aggregated metrics for 1.0.'',''Behavior dashboards were lim';
wwv_flow_imp.g_varchar2_table(127) := 'ited to approved aggregated metrics for 1.0.'',''Behavior dashboards were limited to approved aggregat';
wwv_flow_imp.g_varchar2_table(128) := 'ed metrics for 1.0.'',''N'',sp_util.fix_demo_dates(sysdate-170),''SCOTT.TIGER@ACME.COM'',sp_util.fix_demo';
wwv_flow_imp.g_varchar2_table(129) := '_dates(sysdate-170),''SCOTT.TIGER@ACME.COM'');'||wwv_flow.LF||
'insert into sp_project_comments (id,project_id,author_i';
wwv_flow_imp.g_varchar2_table(130) := 'd,body,body_html,body_no_images,private_yn,created,created_by,updated,updated_by) values (9202,8002,';
wwv_flow_imp.g_varchar2_table(131) := '3,''The recommendation API contract was approved after latency testing.'',''The recommendation API cont';
wwv_flow_imp.g_varchar2_table(132) := 'ract was approved after latency testing.'',''The recommendation API contract was approved after latenc';
wwv_flow_imp.g_varchar2_table(133) := 'y testing.'',''N'',sp_util.fix_demo_dates(sysdate-170),''ELENA.VARGAS@ACME.COM'',sp_util.fix_demo_dates(s';
wwv_flow_imp.g_varchar2_table(134) := 'ysdate-170),''ELENA.VARGAS@ACME.COM'');'||wwv_flow.LF||
'insert into sp_project_comments (id,project_id,author_id,body,';
wwv_flow_imp.g_varchar2_table(135) := 'body_html,body_no_images,private_yn,created,created_by,updated,updated_by) values (9203,8003,5,''Oper';
wwv_flow_imp.g_varchar2_table(136) := 'ations approved the forecast horizon and confidence bands.'',''Operations approved the forecast horizo';
wwv_flow_imp.g_varchar2_table(137) := 'n and confidence bands.'',''Operations approved the forecast horizon and confidence bands.'',''N'',sp_uti';
wwv_flow_imp.g_varchar2_table(138) := 'l.fix_demo_dates(sysdate-170),''NAOMI.CHEN@ACME.COM'',sp_util.fix_demo_dates(sysdate-170),''NAOMI.CHEN@';
wwv_flow_imp.g_varchar2_table(139) := 'ACME.COM'');'||wwv_flow.LF||
'insert into sp_project_comments (id,project_id,author_id,body,body_html,body_no_images,p';
wwv_flow_imp.g_varchar2_table(140) := 'rivate_yn,created,created_by,updated,updated_by) values (9204,8004,7,''Journey reporting uses the agr';
wwv_flow_imp.g_varchar2_table(141) := 'eed customer-event taxonomy.'',''Journey reporting uses the agreed customer-event taxonomy.'',''Journey ';
wwv_flow_imp.g_varchar2_table(142) := 'reporting uses the agreed customer-event taxonomy.'',''N'',sp_util.fix_demo_dates(sysdate-170),''CALEB.F';
wwv_flow_imp.g_varchar2_table(143) := 'OSTER@ACME.COM'',sp_util.fix_demo_dates(sysdate-170),''CALEB.FOSTER@ACME.COM'');'||wwv_flow.LF||
'insert into sp_project';
wwv_flow_imp.g_varchar2_table(144) := '_comments (id,project_id,author_id,body,body_html,body_no_images,private_yn,created,created_by,updat';
wwv_flow_imp.g_varchar2_table(145) := 'ed,updated_by) values (9205,8005,9,''Support leadership approved the classifier escalation threshold.';
wwv_flow_imp.g_varchar2_table(146) := ''',''Support leadership approved the classifier escalation threshold.'',''Support leadership approved th';
wwv_flow_imp.g_varchar2_table(147) := 'e classifier escalation threshold.'',''N'',sp_util.fix_demo_dates(sysdate-170),''ANDRE.COLLINS@ACME.COM''';
wwv_flow_imp.g_varchar2_table(148) := ',sp_util.fix_demo_dates(sysdate-170),''ANDRE.COLLINS@ACME.COM'');'||wwv_flow.LF||
'insert into sp_project_comments (id,';
wwv_flow_imp.g_varchar2_table(149) := 'project_id,author_id,body,body_html,body_no_images,private_yn,created,created_by,updated,updated_by)';
wwv_flow_imp.g_varchar2_table(150) := ' values (9206,8006,11,''Data-quality alerts now identify the source owner and remediation path.'',''Dat';
wwv_flow_imp.g_varchar2_table(151) := 'a-quality alerts now identify the source owner and remediation path.'',''Data-quality alerts now ident';
wwv_flow_imp.g_varchar2_table(152) := 'ify the source owner and remediation path.'',''N'',sp_util.fix_demo_dates(sysdate-170),''VICTOR.RAMIREZ@';
wwv_flow_imp.g_varchar2_table(153) := 'ACME.COM'',sp_util.fix_demo_dates(sysdate-170),''VICTOR.RAMIREZ@ACME.COM'');'||wwv_flow.LF||
'insert into sp_project_com';
wwv_flow_imp.g_varchar2_table(154) := 'ments (id,project_id,author_id,body,body_html,body_no_images,private_yn,created,created_by,updated,u';
wwv_flow_imp.g_varchar2_table(155) := 'pdated_by) values (9207,8007,13,''Executive KPI definitions were agreed before dashboard publication.';
wwv_flow_imp.g_varchar2_table(156) := ''',''Executive KPI definitions were agreed before dashboard publication.'',''Executive KPI definitions w';
wwv_flow_imp.g_varchar2_table(157) := 'ere agreed before dashboard publication.'',''N'',sp_util.fix_demo_dates(sysdate-170),''ISAAC.TURNER@ACME';
wwv_flow_imp.g_varchar2_table(158) := '.COM'',sp_util.fix_demo_dates(sysdate-170),''ISAAC.TURNER@ACME.COM'');'||wwv_flow.LF||
'insert into sp_project_comments ';
wwv_flow_imp.g_varchar2_table(159) := '(id,project_id,author_id,body,body_html,body_no_images,private_yn,created,created_by,updated,updated';
wwv_flow_imp.g_varchar2_table(160) := '_by) values (9208,8008,15,''Segmentation models passed the agreed stability and bias checks.'',''Segmen';
wwv_flow_imp.g_varchar2_table(161) := 'tation models passed the agreed stability and bias checks.'',''Segmentation models passed the agreed s';
wwv_flow_imp.g_varchar2_table(162) := 'tability and bias checks.'',''N'',sp_util.fix_demo_dates(sysdate-170),''DOMINIC.REYES@ACME.COM'',sp_util.';
wwv_flow_imp.g_varchar2_table(163) := 'fix_demo_dates(sysdate-170),''DOMINIC.REYES@ACME.COM'');'||wwv_flow.LF||
'insert into sp_project_comments (id,project_i';
wwv_flow_imp.g_varchar2_table(164) := 'd,author_id,body,body_html,body_no_images,private_yn,created,created_by,updated,updated_by) values (';
wwv_flow_imp.g_varchar2_table(165) := '9209,8009,17,''Experiment results now include the required statistical-confidence summary.'',''Experime';
wwv_flow_imp.g_varchar2_table(166) := 'nt results now include the required statistical-confidence summary.'',''Experiment results now include';
wwv_flow_imp.g_varchar2_table(167) := ' the required statistical-confidence summary.'',''N'',sp_util.fix_demo_dates(sysdate-170),''ETHAN.CALDWE';
wwv_flow_imp.g_varchar2_table(168) := 'LL@ACME.COM'',sp_util.fix_demo_dates(sysdate-170),''ETHAN.CALDWELL@ACME.COM'');'||wwv_flow.LF||
'insert into sp_project_';
wwv_flow_imp.g_varchar2_table(169) := 'comments (id,project_id,author_id,body,body_html,body_no_images,private_yn,created,created_by,update';
wwv_flow_imp.g_varchar2_table(170) := 'd,updated_by) values (9210,8010,19,''Security approved the analytics-data access model and audit even';
wwv_flow_imp.g_varchar2_table(171) := 'ts.'',''Security approved the analytics-data access model and audit events.'',''Security approved the an';
wwv_flow_imp.g_varchar2_table(172) := 'alytics-data access model and audit events.'',''N'',sp_util.fix_demo_dates(sysdate-170),''LUCAS.BENNETT@';
wwv_flow_imp.g_varchar2_table(173) := 'ACME.COM'',sp_util.fix_demo_dates(sysdate-170),''LUCAS.BENNETT@ACME.COM'');'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- Three milestones and o';
wwv_flow_imp.g_varchar2_table(174) := 'ne completed review per project.'||wwv_flow.LF||
'insert into sp_tasks'||wwv_flow.LF||
' (id,project_id,task,task_type_id,task_sub_typ';
wwv_flow_imp.g_varchar2_table(175) := 'e_id,owner_id,start_date,target_complete,status_id,status_last_changed_on,description,tags,display_s';
wwv_flow_imp.g_varchar2_table(176) := 'equence,impact,created,created_by,updated,updated_by)'||wwv_flow.LF||
'select 9000 + (p.project_id - 8000) * 10 + t.s';
wwv_flow_imp.g_varchar2_table(177) := 'eq, p.project_id, t.task,'||wwv_flow.LF||
'       t.task_type_id, null, p.owner_id,'||wwv_flow.LF||
'       sp_util.fix_demo_dates(sys';
wwv_flow_imp.g_varchar2_table(178) := 'date + t.start_offset),'||wwv_flow.LF||
'       sp_util.fix_demo_dates(sysdate + t.complete_offset), t.status_id,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(179) := '    sp_util.fix_demo_dates(sysdate + t.complete_offset), t.description,'||wwv_flow.LF||
'       t.tags, t.seq * 10, t';
wwv_flow_imp.g_varchar2_table(180) := '.impact,sp_util.fix_demo_dates(sysdate-200),case p.owner_id when 1 then ''SCOTT.TIGER@ACME.COM'' when ';
wwv_flow_imp.g_varchar2_table(181) := '3 then ''ELENA.VARGAS@ACME.COM'' when 5 then ''NAOMI.CHEN@ACME.COM'' when 7 then ''CALEB.FOSTER@ACME.COM''';
wwv_flow_imp.g_varchar2_table(182) := ' when 9 then ''ANDRE.COLLINS@ACME.COM'' when 11 then ''VICTOR.RAMIREZ@ACME.COM'' when 13 then ''ISAAC.TUR';
wwv_flow_imp.g_varchar2_table(183) := 'NER@ACME.COM'' when 15 then ''DOMINIC.REYES@ACME.COM'' when 17 then ''ETHAN.CALDWELL@ACME.COM'' when 19 t';
wwv_flow_imp.g_varchar2_table(184) := 'hen ''LUCAS.BENNETT@ACME.COM'' end,sp_util.fix_demo_dates(sysdate+t.complete_offset),case p.owner_id w';
wwv_flow_imp.g_varchar2_table(185) := 'hen 1 then ''SCOTT.TIGER@ACME.COM'' when 3 then ''ELENA.VARGAS@ACME.COM'' when 5 then ''NAOMI.CHEN@ACME.C';
wwv_flow_imp.g_varchar2_table(186) := 'OM'' when 7 then ''CALEB.FOSTER@ACME.COM'' when 9 then ''ANDRE.COLLINS@ACME.COM'' when 11 then ''VICTOR.RA';
wwv_flow_imp.g_varchar2_table(187) := 'MIREZ@ACME.COM'' when 13 then ''ISAAC.TURNER@ACME.COM'' when 15 then ''DOMINIC.REYES@ACME.COM'' when 17 t';
wwv_flow_imp.g_varchar2_table(188) := 'hen ''ETHAN.CALDWELL@ACME.COM'' when 19 then ''LUCAS.BENNETT@ACME.COM'' end'||wwv_flow.LF||
'from ('||wwv_flow.LF||
'  select 8001 project';
wwv_flow_imp.g_varchar2_table(189) := '_id, 1 owner_id from dual union all select 8002,3 from dual union all'||wwv_flow.LF||
'  select 8003,5 from dual unio';
wwv_flow_imp.g_varchar2_table(190) := 'n all select 8004,7 from dual union all'||wwv_flow.LF||
'  select 8005,9 from dual union all select 8006,11 from dual';
wwv_flow_imp.g_varchar2_table(191) := ' union all'||wwv_flow.LF||
'  select 8007,13 from dual union all select 8008,15 from dual union all'||wwv_flow.LF||
'  select 8009,17 ';
wwv_flow_imp.g_varchar2_table(192) := 'from dual union all select 8010,19 from dual'||wwv_flow.LF||
') p'||wwv_flow.LF||
'cross join ('||wwv_flow.LF||
'  select 1 seq, ''Spec Complete'' task, ';
wwv_flow_imp.g_varchar2_table(193) := '21 task_type_id, -195 start_offset, -185 complete_offset, 14 status_id, ''Specification approved.'' de';
wwv_flow_imp.g_varchar2_table(194) := 'scription, ''milestone,spec'' tags, cast(null as varchar2(30)) impact from dual union all'||wwv_flow.LF||
'  select 2, ';
wwv_flow_imp.g_varchar2_table(195) := '''Code Complete'', 23, -140, -120, 14, ''Implementation complete.'', ''milestone,code'', cast(null as varc';
wwv_flow_imp.g_varchar2_table(196) := 'har2(30)) from dual union all'||wwv_flow.LF||
'  select 3, ''Merged'', 24, -110, -105, 14, ''Merged to the release branc';
wwv_flow_imp.g_varchar2_table(197) := 'h.'', ''milestone,merge'', cast(null as varchar2(30)) from dual union all'||wwv_flow.LF||
'  select 4, ''Peer Review'', 4,';
wwv_flow_imp.g_varchar2_table(198) := ' -165, -158, 8, ''Peer review completed.'', ''review,peer'', ''Medium'' from dual'||wwv_flow.LF||
') t;'||wwv_flow.LF||
''||wwv_flow.LF||
'sp_globals.g_audit';
wwv_flow_imp.g_varchar2_table(199) := '_this := TRUE;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        sp_globals.g_audit_this := TRUE;'||wwv_flow.LF||
'end;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(454626615868798001)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sample data - insight 1.0'
,p_sequence=>9250
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
