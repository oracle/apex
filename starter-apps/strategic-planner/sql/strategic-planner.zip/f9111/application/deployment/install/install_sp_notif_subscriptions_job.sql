prompt --application/deployment/install/install_sp_notif_subscriptions_job
begin
--   Manifest
--     INSTALL: INSTALL-SP_NOTIF_SUBSCRIPTIONS job
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
'    sys.dbms_scheduler.create_job    '||wwv_flow.LF||
'     (job_name        => ''SP_NOTIF_SUBSCRIPTIONS'','||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(2) := ' job_type        => ''STORED_PROCEDURE'','||wwv_flow.LF||
'      job_action      => ''SP_UTIL.SEND_NOTIF_SUBSCRIPTIONS'',';
wwv_flow_imp.g_varchar2_table(3) := ''||wwv_flow.LF||
'      start_date      => systimestamp,'||wwv_flow.LF||
'      repeat_interval => ''FREQ=DAILY; BYDAY=MON,TUE,WED,THU,';
wwv_flow_imp.g_varchar2_table(4) := 'FRI; BYHOUR=8; BYMINUTE=0;'','||wwv_flow.LF||
'      enabled         => true,'||wwv_flow.LF||
'      auto_drop       => false);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(47919436764942669492)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'SP_NOTIF_SUBSCRIPTIONS job'
,p_sequence=>8010
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
