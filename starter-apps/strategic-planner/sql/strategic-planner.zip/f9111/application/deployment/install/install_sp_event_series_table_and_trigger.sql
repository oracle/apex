prompt --application/deployment/install/install_sp_event_series_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_event_series table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_event_series ('||wwv_flow.LF||
'    id                      number'||wwv_flow.LF||
'                              defa';
wwv_flow_imp.g_varchar2_table(2) := 'ult on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(3) := ' constraint sp_event_series_pk primary key,'||wwv_flow.LF||
'    start_date              timestamp with time zone  no';
wwv_flow_imp.g_varchar2_table(4) := 't null,'||wwv_flow.LF||
'    end_date                timestamp with time zone  not null,'||wwv_flow.LF||
'    recur_freq              ';
wwv_flow_imp.g_varchar2_table(5) := 'varchar2(10)  not null'||wwv_flow.LF||
'                              constraint sp_event_series_freq_cc'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(6) := '                  check (recur_freq in (''D'',''WD'',''W'',''2W'',''M'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                 ';
wwv_flow_imp.g_varchar2_table(7) := 'date            not null,'||wwv_flow.LF||
'    created_by              varchar2(255)   not null,'||wwv_flow.LF||
'    updated         ';
wwv_flow_imp.g_varchar2_table(8) := '        date            not null,'||wwv_flow.LF||
'    updated_by              varchar2(255)   not null'||wwv_flow.LF||
');'||wwv_flow.LF||
'create ind';
wwv_flow_imp.g_varchar2_table(9) := 'ex sp_event_series_i1 on sp_event_series (start_date);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_event_series_bi';
wwv_flow_imp.g_varchar2_table(10) := 'u'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_event_series'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(11) := '      :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, ';
wwv_flow_imp.g_varchar2_table(12) := 'coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,';
wwv_flow_imp.g_varchar2_table(13) := 'sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_U';
wwv_flow_imp.g_varchar2_table(14) := 'SER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by :=';
wwv_flow_imp.g_varchar2_table(15) := ' coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_event_series_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(35719232743950878348)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_event_series table and trigger'
,p_sequence=>3090
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
