prompt --application/deployment/install/install_sp_documents_v_view
begin
--   Manifest
--     INSTALL: INSTALL-sp_documents_v view
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace view sp_documents_v as'||wwv_flow.LF||
'select ''Project'' doc_type,'||wwv_flow.LF||
'       apex_page.get_url ('||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(2) := '      p_page   => 30,'||wwv_flow.LF||
'           p_clear_cache => 30,'||wwv_flow.LF||
'           p_items  => ''P30_ID,P30_PREV_PAGE'',';
wwv_flow_imp.g_varchar2_table(3) := ''||wwv_flow.LF||
'           p_values => d.ID||'',156'') link,'||wwv_flow.LF||
'       p.project name,'||wwv_flow.LF||
'       p.project project,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(4) := 'd.DOCUMENT_FILENAME,'||wwv_flow.LF||
'       d.UPDATED,'||wwv_flow.LF||
'       d.created,'||wwv_flow.LF||
'       substr(d.doc_description,1,200)||cas';
wwv_flow_imp.g_varchar2_table(5) := 'e when length(d.doc_description) > 200 then ''...'' end doc_description,'||wwv_flow.LF||
'       lower(d.created_by) ad';
wwv_flow_imp.g_varchar2_table(6) := 'ded_by,'||wwv_flow.LF||
'       dbms_lob.getlength(document_BLOB) filesize,'||wwv_flow.LF||
'       lower(substr(DOCUMENT_FILENAME,ins';
wwv_flow_imp.g_varchar2_table(7) := 'tr(DOCUMENT_FILENAME,''.'',-1)+1,length(DOCUMENT_FILENAME)-instr(DOCUMENT_FILENAME,''.'',-1))) file_exte';
wwv_flow_imp.g_varchar2_table(8) := 'nsion,'||wwv_flow.LF||
'       d.tags,'||wwv_flow.LF||
'       nvl((select release_train||'' ''||release from sp_release_trains'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(9) := '     where id = p.release_id),''Not Targeted'') release,'||wwv_flow.LF||
'       decode(d.important_yn,''Y'', ''Yes'',''No'')';
wwv_flow_imp.g_varchar2_table(10) := ' important,'||wwv_flow.LF||
'       -- for download'||wwv_flow.LF||
'       d.id document_id,'||wwv_flow.LF||
'       d.document_BLOB,'||wwv_flow.LF||
'       d.documen';
wwv_flow_imp.g_varchar2_table(11) := 't_mimetype,'||wwv_flow.LF||
'       d.document_lastupd,'||wwv_flow.LF||
'       d.document_charset,'||wwv_flow.LF||
'       p.id project_id,'||wwv_flow.LF||
'       nul';
wwv_flow_imp.g_varchar2_table(12) := 'l release_id,'||wwv_flow.LF||
'       null task_id,'||wwv_flow.LF||
'       null initiative_id,'||wwv_flow.LF||
'       null initiative_focus_area_id'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(13) := ' from SP_PROJECT_DOCUMENTS d,'||wwv_flow.LF||
'       sp_projects p'||wwv_flow.LF||
' where project_id = p.id and'||wwv_flow.LF||
'       p.ARCHIVED_YN';
wwv_flow_imp.g_varchar2_table(14) := ' = ''N'' and '||wwv_flow.LF||
'       p.DUPLICATE_OF_PROJECT_ID is null'||wwv_flow.LF||
'union all'||wwv_flow.LF||
'select ''Release'' doc_type,'||wwv_flow.LF||
'       ape';
wwv_flow_imp.g_varchar2_table(15) := 'x_page.get_url ('||wwv_flow.LF||
'           p_page   => 42,'||wwv_flow.LF||
'           p_clear_cache => 42,'||wwv_flow.LF||
'           p_items  => ''';
wwv_flow_imp.g_varchar2_table(16) := 'P42_ID,P42_PREV_PAGE'','||wwv_flow.LF||
'           p_values => d.ID||'',156'') link,'||wwv_flow.LF||
'       r.release_train ||'' '' ||r.r';
wwv_flow_imp.g_varchar2_table(17) := 'elease name,'||wwv_flow.LF||
'       null project,'||wwv_flow.LF||
'       d.DOCUMENT_FILENAME,'||wwv_flow.LF||
'       d.UPDATED,'||wwv_flow.LF||
'       d.created,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(18) := '     substr(d.doc_description,1,200)||case when length(d.doc_description) > 200 then ''...'' end doc_d';
wwv_flow_imp.g_varchar2_table(19) := 'escription,'||wwv_flow.LF||
'       lower(d.created_by) added_by,'||wwv_flow.LF||
'       dbms_lob.getlength(document_BLOB) filesize,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(20) := '       lower(substr(DOCUMENT_FILENAME,instr(DOCUMENT_FILENAME,''.'',-1)+1,length(DOCUMENT_FILENAME)-in';
wwv_flow_imp.g_varchar2_table(21) := 'str(DOCUMENT_FILENAME,''.'',-1))) file_extension,'||wwv_flow.LF||
'       d.tags,'||wwv_flow.LF||
'       release_train||'' ''||release re';
wwv_flow_imp.g_varchar2_table(22) := 'lease,'||wwv_flow.LF||
'       decode(d.important_yn,''Y'', ''Yes'',''No'') important,'||wwv_flow.LF||
'       -- for download'||wwv_flow.LF||
'       d.id d';
wwv_flow_imp.g_varchar2_table(23) := 'ocument_id,'||wwv_flow.LF||
'       d.document_BLOB,'||wwv_flow.LF||
'       d.document_mimetype,'||wwv_flow.LF||
'       d.document_lastupd,'||wwv_flow.LF||
'       d.';
wwv_flow_imp.g_varchar2_table(24) := 'document_charset,'||wwv_flow.LF||
'       null project_id,'||wwv_flow.LF||
'       r.id release_id,'||wwv_flow.LF||
'       null task_id,'||wwv_flow.LF||
'       null i';
wwv_flow_imp.g_varchar2_table(25) := 'nitiative_id,'||wwv_flow.LF||
'       null initiative_focus_area_id'||wwv_flow.LF||
'  from SP_RELEASE_DOCUMENTS d,'||wwv_flow.LF||
'       sp_release_';
wwv_flow_imp.g_varchar2_table(26) := 'trains r'||wwv_flow.LF||
' where r.id = d.release_id'||wwv_flow.LF||
'union all'||wwv_flow.LF||
'select ''Initiative'' doc_type,'||wwv_flow.LF||
'       apex_page.get_url';
wwv_flow_imp.g_varchar2_table(27) := ' ('||wwv_flow.LF||
'           p_page   => 53,'||wwv_flow.LF||
'           p_clear_cache => 53,'||wwv_flow.LF||
'           p_items  => ''P53_ID,P53_PRE';
wwv_flow_imp.g_varchar2_table(28) := 'V_PAGE'','||wwv_flow.LF||
'           p_values => d.ID||'',156'') link,'||wwv_flow.LF||
'       a.area || '' / '' ||initiative name,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(29) := ' null project,'||wwv_flow.LF||
'       d.DOCUMENT_FILENAME,'||wwv_flow.LF||
'       d.UPDATED,'||wwv_flow.LF||
'       d.created,'||wwv_flow.LF||
'       substr(d.doc_d';
wwv_flow_imp.g_varchar2_table(30) := 'escription,1,200)||case when length(d.doc_description) > 200 then ''...'' end doc_description,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(31) := 'lower(d.created_by) added_by,'||wwv_flow.LF||
'       dbms_lob.getlength(document_BLOB) filesize,'||wwv_flow.LF||
'       lower(substr';
wwv_flow_imp.g_varchar2_table(32) := '(DOCUMENT_FILENAME,instr(DOCUMENT_FILENAME,''.'',-1)+1,length(DOCUMENT_FILENAME)-instr(DOCUMENT_FILENA';
wwv_flow_imp.g_varchar2_table(33) := 'ME,''.'',-1))) file_extension,'||wwv_flow.LF||
'       d.tags,'||wwv_flow.LF||
'       null release,'||wwv_flow.LF||
'       decode(d.important_yn,''Y'', ''';
wwv_flow_imp.g_varchar2_table(34) := 'Yes'',''No'') important,'||wwv_flow.LF||
'       -- for download'||wwv_flow.LF||
'       d.id document_id,'||wwv_flow.LF||
'       d.document_BLOB,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(35) := ' d.document_mimetype,'||wwv_flow.LF||
'       d.document_lastupd,'||wwv_flow.LF||
'       d.document_charset,'||wwv_flow.LF||
'       null project_id,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(36) := '       null release_id,'||wwv_flow.LF||
'       null task_id,'||wwv_flow.LF||
'       i.id initiative_id,'||wwv_flow.LF||
'       null initiative_focus';
wwv_flow_imp.g_varchar2_table(37) := '_area_id'||wwv_flow.LF||
'  from SP_INITIATIVE_DOCUMENTS d,'||wwv_flow.LF||
'       sp_initiatives i,'||wwv_flow.LF||
'       sp_areas a'||wwv_flow.LF||
' where d.initi';
wwv_flow_imp.g_varchar2_table(38) := 'ative_id = i.id'||wwv_flow.LF||
'   and i.area_id = a.id'||wwv_flow.LF||
'union all'||wwv_flow.LF||
'select ''Initiative Focus Area'' doc_type,'||wwv_flow.LF||
'       ap';
wwv_flow_imp.g_varchar2_table(39) := 'ex_page.get_url ('||wwv_flow.LF||
'           p_page   => 59,'||wwv_flow.LF||
'           p_clear_cache => 59,'||wwv_flow.LF||
'           p_items  => ';
wwv_flow_imp.g_varchar2_table(40) := '''P59_ID,P59_PREV_PAGE'','||wwv_flow.LF||
'           p_values => d.ID||'',156'') link,'||wwv_flow.LF||
'       i.initiative ||'' - ''|| f.f';
wwv_flow_imp.g_varchar2_table(41) := 'ocus_area name,'||wwv_flow.LF||
'       null project,'||wwv_flow.LF||
'       d.DOCUMENT_FILENAME,'||wwv_flow.LF||
'       d.UPDATED,'||wwv_flow.LF||
'       d.created,';
wwv_flow_imp.g_varchar2_table(42) := ''||wwv_flow.LF||
'       substr(d.doc_description,1,200)||case when length(d.doc_description) > 200 then ''...'' end do';
wwv_flow_imp.g_varchar2_table(43) := 'c_description,'||wwv_flow.LF||
'       lower(d.created_by) added_by,'||wwv_flow.LF||
'       dbms_lob.getlength(document_BLOB) filesiz';
wwv_flow_imp.g_varchar2_table(44) := 'e,'||wwv_flow.LF||
'       lower(substr(DOCUMENT_FILENAME,instr(DOCUMENT_FILENAME,''.'',-1)+1,length(DOCUMENT_FILENAME)';
wwv_flow_imp.g_varchar2_table(45) := '-instr(DOCUMENT_FILENAME,''.'',-1))) file_extension,'||wwv_flow.LF||
'       d.tags,'||wwv_flow.LF||
'       null release,'||wwv_flow.LF||
'       decode';
wwv_flow_imp.g_varchar2_table(46) := '(d.important_yn,''Y'', ''Yes'',''No'') important,'||wwv_flow.LF||
'       -- for download'||wwv_flow.LF||
'       d.id document_id,'||wwv_flow.LF||
'       d';
wwv_flow_imp.g_varchar2_table(47) := '.document_BLOB,'||wwv_flow.LF||
'       d.document_mimetype,'||wwv_flow.LF||
'       d.document_lastupd,'||wwv_flow.LF||
'       d.document_charset,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(48) := '     null project_id,'||wwv_flow.LF||
'       null release_id,'||wwv_flow.LF||
'       null task_id,'||wwv_flow.LF||
'       i.id initiative_id,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(49) := ' f.id initiative_focus_area_id'||wwv_flow.LF||
'  from SP_INIT_FOCUS_AREA_DOCUMENTS d,'||wwv_flow.LF||
'       sp_initiative_focus_are';
wwv_flow_imp.g_varchar2_table(50) := 'as f,'||wwv_flow.LF||
'       sp_initiatives i'||wwv_flow.LF||
' where d.init_focus_area_id = f.id'||wwv_flow.LF||
'   and f.initiative_id = i.id'||wwv_flow.LF||
'union';
wwv_flow_imp.g_varchar2_table(51) := ' all'||wwv_flow.LF||
'select ''Task'' doc_type,'||wwv_flow.LF||
'       apex_page.get_url ('||wwv_flow.LF||
'           p_page   => 505,'||wwv_flow.LF||
'           p_cle';
wwv_flow_imp.g_varchar2_table(52) := 'ar_cache => 505,'||wwv_flow.LF||
'           p_items  => ''P505_ID,P505_PREV_PAGE'','||wwv_flow.LF||
'           p_values => d.ID||'',156';
wwv_flow_imp.g_varchar2_table(53) := ''') link,'||wwv_flow.LF||
'       case when t.task_sub_type_id is not null'||wwv_flow.LF||
'            then (select task_type from sp_';
wwv_flow_imp.g_varchar2_table(54) := 'task_types'||wwv_flow.LF||
'                   where id = t.task_type_id)||'': '''||wwv_flow.LF||
'            end || tt.task_type || ca';
wwv_flow_imp.g_varchar2_table(55) := 'se when t.task is not null then '' - ''||t.task end name,'||wwv_flow.LF||
'       p.project,'||wwv_flow.LF||
'       d.DOCUMENT_FILENAME';
wwv_flow_imp.g_varchar2_table(56) := ','||wwv_flow.LF||
'       d.UPDATED,'||wwv_flow.LF||
'       d.created,'||wwv_flow.LF||
'       substr(d.doc_description,1,200)||case when length(d.doc';
wwv_flow_imp.g_varchar2_table(57) := '_description) > 200 then ''...'' end doc_description,'||wwv_flow.LF||
'       lower(d.created_by) added_by,'||wwv_flow.LF||
'       dbms';
wwv_flow_imp.g_varchar2_table(58) := '_lob.getlength(document_BLOB) filesize,'||wwv_flow.LF||
'       lower(substr(DOCUMENT_FILENAME,instr(DOCUMENT_FILENAM';
wwv_flow_imp.g_varchar2_table(59) := 'E,''.'',-1)+1,length(DOCUMENT_FILENAME)-instr(DOCUMENT_FILENAME,''.'',-1))) file_extension,'||wwv_flow.LF||
'       d.tag';
wwv_flow_imp.g_varchar2_table(60) := 's,'||wwv_flow.LF||
'       nvl((select release_train||'' ''||release from sp_release_trains'||wwv_flow.LF||
'             where id = p.r';
wwv_flow_imp.g_varchar2_table(61) := 'elease_id),''Not Targeted'') release,'||wwv_flow.LF||
'       decode(d.important_yn,''Y'', ''Yes'',''No'') important,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(62) := '-- for download'||wwv_flow.LF||
'       d.id document_id,'||wwv_flow.LF||
'       d.document_BLOB,'||wwv_flow.LF||
'       d.document_mimetype,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(63) := 'd.document_lastupd,'||wwv_flow.LF||
'       d.document_charset,'||wwv_flow.LF||
'       p.id project_id,'||wwv_flow.LF||
'       null release_id,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(64) := '  t.id task_id,'||wwv_flow.LF||
'       null initiative_id,'||wwv_flow.LF||
'       null initiative_focus_area_id'||wwv_flow.LF||
'  from SP_TASK_DOCUM';
wwv_flow_imp.g_varchar2_table(65) := 'ENTS d,'||wwv_flow.LF||
'       sp_tasks t,'||wwv_flow.LF||
'       sp_task_types tt,'||wwv_flow.LF||
'       sp_projects p'||wwv_flow.LF||
' where d.task_id = t.id'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(66) := 'and nvl(t.task_sub_type_id,t.task_type_id) = tt.id'||wwv_flow.LF||
'   and t.project_id = p.id;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(30934223342583470523)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_documents_v view'
,p_sequence=>5020
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
