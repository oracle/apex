prompt --application/deployment/install/install_sp_resource_types_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_resource_types table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_resource_types ('||wwv_flow.LF||
'    id                             number default on null to_number';
wwv_flow_imp.g_varchar2_table(2) := '(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_r';
wwv_flow_imp.g_varchar2_table(3) := 'esource_types_id_pk primary key,'||wwv_flow.LF||
'    resource_type                  varchar2(50 char) not null,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(4) := 'resource_description           varchar2(4000 char),'||wwv_flow.LF||
'    is_default_yn                  varchar2(1 ch';
wwv_flow_imp.g_varchar2_table(5) := 'ar)'||wwv_flow.LF||
'                                   constraint sp_res_t_is_default_ck '||wwv_flow.LF||
'                          ';
wwv_flow_imp.g_varchar2_table(6) := '         check (is_default_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null';
wwv_flow_imp.g_varchar2_table(7) := ','||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                       ';
wwv_flow_imp.g_varchar2_table(8) := ' date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique ind';
wwv_flow_imp.g_varchar2_table(9) := 'ex sp_resource_types_u1 on sp_resource_types (resource_type);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_resource';
wwv_flow_imp.g_varchar2_table(10) := '_types_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_resource_types'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if insert';
wwv_flow_imp.g_varchar2_table(11) := 'ing then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.c';
wwv_flow_imp.g_varchar2_table(12) := 'reated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:n';
wwv_flow_imp.g_varchar2_table(13) := 'ew.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SESS';
wwv_flow_imp.g_varchar2_table(14) := 'ION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.up';
wwv_flow_imp.g_varchar2_table(15) := 'dated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_resource_types';
wwv_flow_imp.g_varchar2_table(16) := '_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38666232472587336567)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_resource_types table and trigger'
,p_sequence=>3120
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
