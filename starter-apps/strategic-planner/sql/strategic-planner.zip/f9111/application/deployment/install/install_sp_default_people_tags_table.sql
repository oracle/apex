prompt --application/deployment/install/install_sp_default_people_tags_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_default_people_tags table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_default_people_tags ('||wwv_flow.LF||
'    id                             number default on null to_n';
wwv_flow_imp.g_varchar2_table(2) := 'umber(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint';
wwv_flow_imp.g_varchar2_table(3) := ' sp_default_people_tags_pk primary key,'||wwv_flow.LF||
'    display_sequence               number             not nu';
wwv_flow_imp.g_varchar2_table(4) := 'll,'||wwv_flow.LF||
'    tag                            varchar2(30 char)  not null,'||wwv_flow.LF||
'    description                 ';
wwv_flow_imp.g_varchar2_table(5) := '   varchar2(512 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by      ';
wwv_flow_imp.g_varchar2_table(6) := '               varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    up';
wwv_flow_imp.g_varchar2_table(7) := 'dated_by                     varchar2(255 char) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index sp_default_people_';
wwv_flow_imp.g_varchar2_table(8) := 'tags_u1 on sp_default_people_tags (tag);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(40988789672556621699)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_default_people_tags table'
,p_sequence=>3450
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
