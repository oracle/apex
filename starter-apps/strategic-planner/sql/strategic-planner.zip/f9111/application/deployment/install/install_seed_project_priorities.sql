prompt --application/deployment/install/install_seed_project_priorities
begin
--   Manifest
--     INSTALL: INSTALL-seed project priorities
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into sp_project_priorities (id, priority, description, IS_DEFAULT_YN) values (1,1, ''P1 - High';
wwv_flow_imp.g_varchar2_table(2) := 'est'',''N'');'||wwv_flow.LF||
'insert into sp_project_priorities (id, priority, description, IS_DEFAULT_YN) values (2,2,';
wwv_flow_imp.g_varchar2_table(3) := ' ''P2 - High (Critical)'',''N'');'||wwv_flow.LF||
'insert into sp_project_priorities (id, priority, description, IS_DEFAU';
wwv_flow_imp.g_varchar2_table(4) := 'LT_YN) values (3,3, ''P3 - Medium'',''N'');'||wwv_flow.LF||
'insert into sp_project_priorities (id, priority, description';
wwv_flow_imp.g_varchar2_table(5) := ', IS_DEFAULT_YN) values (4,4, ''P4 - Low'',''N'');'||wwv_flow.LF||
'insert into sp_project_priorities (id, priority, desc';
wwv_flow_imp.g_varchar2_table(6) := 'ription, IS_DEFAULT_YN) values (5,5, ''P5 - Not Prioritized'',''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(148844856080147479262)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed project priorities'
,p_sequence=>9130
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
