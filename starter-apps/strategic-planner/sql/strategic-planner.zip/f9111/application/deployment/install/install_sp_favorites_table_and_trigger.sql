prompt --application/deployment/install/install_sp_favorites_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_favorites table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_favorites ('||wwv_flow.LF||
'    id                  number default on null to_number(sys_guid(), ''xx';
wwv_flow_imp.g_varchar2_table(2) := 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'') not null, '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    project_id          number '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(3) := '       constraint sp_fav_to_proj_fk'||wwv_flow.LF||
'                        references sp_projects(id)'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(4) := '           on delete cascade,'||wwv_flow.LF||
'    team_member_id      number '||wwv_flow.LF||
'                        constraint sp_';
wwv_flow_imp.g_varchar2_table(5) := 'fav_to_user_fk'||wwv_flow.LF||
'                        references sp_team_members(id)'||wwv_flow.LF||
'                        on del';
wwv_flow_imp.g_varchar2_table(6) := 'ete cascade,'||wwv_flow.LF||
'    created             date not null, '||wwv_flow.LF||
'    created_by          varchar2(255 char) not ';
wwv_flow_imp.g_varchar2_table(7) := 'null, '||wwv_flow.LF||
'    updated             date not null, '||wwv_flow.LF||
'    updated_by          varchar2(255 char) not null'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(8) := '   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index sp_favorites_i1 on sp_favorites (project_id, team_member_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or';
wwv_flow_imp.g_varchar2_table(9) := ' replace trigger sp_favorites_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_favorites'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'b';
wwv_flow_imp.g_varchar2_table(10) := 'egin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.create';
wwv_flow_imp.g_varchar2_table(11) := 'd_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.up';
wwv_flow_imp.g_varchar2_table(12) := 'dated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(sys_';
wwv_flow_imp.g_varchar2_table(13) := 'context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdat';
wwv_flow_imp.g_varchar2_table(14) := 'e;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end';
wwv_flow_imp.g_varchar2_table(15) := ' sp_favorites_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38738446955986676453)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_favorites table and trigger'
,p_sequence=>3420
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
