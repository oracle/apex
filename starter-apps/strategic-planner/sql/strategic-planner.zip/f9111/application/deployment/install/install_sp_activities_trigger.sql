prompt --application/deployment/install/install_sp_activities_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_activities trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_activities_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_activities'||wwv_flow.LF||
'    for';
wwv_flow_imp.g_varchar2_table(2) := ' each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_tags varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.create';
wwv_flow_imp.g_varchar2_table(3) := 'd    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coalesce(sys_cont';
wwv_flow_imp.g_varchar2_table(4) := 'ext(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(5) := ' :new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(6) := ' elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_con';
wwv_flow_imp.g_varchar2_table(7) := 'text(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.private_yn is null then '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(8) := '  :new.private_yn := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- validations'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.end_date < :new.s';
wwv_flow_imp.g_varchar2_table(9) := 'tart_date then'||wwv_flow.LF||
'        raise_application_error(-20111,''End date must be greater than start date'');'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(10) := '   end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- adjust tags'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.tags is not null then'||wwv_flow.LF||
'        l_tags := trim';
wwv_flow_imp.g_varchar2_table(11) := '(upper(:new.tags));'||wwv_flow.LF||
'        -- remove multiple spaces'||wwv_flow.LF||
'        if instr(l_tags,''  '') > 0 then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(12) := '     for j in 1..10 loop '||wwv_flow.LF||
'                l_tags := replace(l_tags,''  '','' ''); '||wwv_flow.LF||
'                if in';
wwv_flow_imp.g_varchar2_table(13) := 'str(l_tags,''  '') = 0 then'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(14) := '      end if;'||wwv_flow.LF||
'        for i in 1..length(l_tags) loop'||wwv_flow.LF||
'            if i > 2 and substr(l_tags,i,1) = ';
wwv_flow_imp.g_varchar2_table(15) := ''' '' and substr(l_tags,i-1,1) != '','' then'||wwv_flow.LF||
'               l_tags := substr(l_tags,1,i-1)||''-''||substr(';
wwv_flow_imp.g_varchar2_table(16) := 'l_tags,i+1);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        :new.tags := l_tags;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(17) := '   -- touch parent'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if sp_globals.g_audit_this and :new.initiative_id is not null then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(18) := '     update sp_initiatives set updated = sysdate, updated_by = :new.updated_by where id = :new.initi';
wwv_flow_imp.g_varchar2_table(19) := 'ative_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if sp_globals.g_audit_this and :new.project_id is not null then'||wwv_flow.LF||
'        up';
wwv_flow_imp.g_varchar2_table(20) := 'date sp_projects set updated = sysdate, updated_by = :new.updated_by where id = :new.project_id;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(21) := ' end if;'||wwv_flow.LF||
'end sp_activities_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(50992170994909531180)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_activities trigger'
,p_sequence=>4180
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
