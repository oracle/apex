prompt --application/deployment/install/install_sp_default_tags_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_default_tags table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_default_tags ('||wwv_flow.LF||
'    id                             number default on null to_number(s';
wwv_flow_imp.g_varchar2_table(2) := 'ys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_def';
wwv_flow_imp.g_varchar2_table(3) := 'ault_tags_pk primary key,'||wwv_flow.LF||
'    display_sequence               number            not null,'||wwv_flow.LF||
'    tag    ';
wwv_flow_imp.g_varchar2_table(4) := '                        varchar2(30 char) not null,'||wwv_flow.LF||
'    description                    varchar2(512 ';
wwv_flow_imp.g_varchar2_table(5) := 'char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by                     v';
wwv_flow_imp.g_varchar2_table(6) := 'archar2(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by        ';
wwv_flow_imp.g_varchar2_table(7) := '             varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index sp_default_tags_u1 on sp_default_ta';
wwv_flow_imp.g_varchar2_table(8) := 'gs (tag);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_default_tags_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_defau';
wwv_flow_imp.g_varchar2_table(9) := 'lt_tags'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sys';
wwv_flow_imp.g_varchar2_table(10) := 'date);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER';
wwv_flow_imp.g_varchar2_table(11) := '''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new';
wwv_flow_imp.g_varchar2_table(12) := '.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(13) := ' :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USE';
wwv_flow_imp.g_varchar2_table(14) := 'R''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.tag := upper(:new.tag);'||wwv_flow.LF||
'end sp_default_tags_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38666200808385329694)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_default_tags table and trigger'
,p_sequence=>3060
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
