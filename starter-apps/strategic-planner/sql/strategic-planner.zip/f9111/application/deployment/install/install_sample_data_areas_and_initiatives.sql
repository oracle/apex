prompt --application/deployment/install/install_sample_data_areas_and_initiatives
begin
--   Manifest
--     INSTALL: INSTALL-sample data - areas and initiatives
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into SP_AREAS'||wwv_flow.LF||
'    (id, area, description, owner_id) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (1, ''Product Development';
wwv_flow_imp.g_varchar2_table(2) := ''', ''Building and enhancing customer-facing software products and applications.'', 1);'||wwv_flow.LF||
'insert into SP_';
wwv_flow_imp.g_varchar2_table(3) := 'AREAS'||wwv_flow.LF||
'    (id, area, description, owner_id) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (2, ''Engineering Excellence'', ''Improvin';
wwv_flow_imp.g_varchar2_table(4) := 'g engineering processes, infrastructure, developer productivity, and software quality.'', 1);'||wwv_flow.LF||
'insert ';
wwv_flow_imp.g_varchar2_table(5) := 'into SP_AREAS'||wwv_flow.LF||
'    (id, area, description, owner_id) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'    (3, ''Technical Enablement'', ''Cr';
wwv_flow_imp.g_varchar2_table(6) := 'eating documentation, reference implementations, training materials, and technical assets.'', 1);'||wwv_flow.LF||
''||wwv_flow.LF||
'in';
wwv_flow_imp.g_varchar2_table(7) := 'sert into SP_INITIATIVES'||wwv_flow.LF||
'    (id, area_id, initiative, status_scale, objective, sponsor_id) '||wwv_flow.LF||
'    val';
wwv_flow_imp.g_varchar2_table(8) := 'ues'||wwv_flow.LF||
'    (1, 1, ''Customer Portal'', ''A'', ''Deliver a modern web portal with improved user experience an';
wwv_flow_imp.g_varchar2_table(9) := 'd new capabilities.'', 1);'||wwv_flow.LF||
'insert into SP_INITIATIVES'||wwv_flow.LF||
'    (id, area_id, initiative, status_scale, obj';
wwv_flow_imp.g_varchar2_table(10) := 'ective, sponsor_id) '||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (2, 1, ''Mobile App Modernization'', ''C'', ''Update existing mobile ';
wwv_flow_imp.g_varchar2_table(11) := 'applications using current frameworks and design standards.'', 1);'||wwv_flow.LF||
'insert into SP_INITIATIVES'||wwv_flow.LF||
'    (id';
wwv_flow_imp.g_varchar2_table(12) := ', area_id, initiative, status_scale, objective, sponsor_id) '||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (3, 1, ''AI-Powered Integ';
wwv_flow_imp.g_varchar2_table(13) := 'ration'', ''A'', ''Integrate AI capabilities such as chat assistants, recommendations, and intelligent s';
wwv_flow_imp.g_varchar2_table(14) := 'earch.'', 1);'||wwv_flow.LF||
'insert into SP_INITIATIVES'||wwv_flow.LF||
'    (id, area_id, initiative, status_scale, objective, spons';
wwv_flow_imp.g_varchar2_table(15) := 'or_id) '||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (4, 2, ''Developer Productivity & Tooling'', ''A'', ''Improve CI/CD pipelines, dev';
wwv_flow_imp.g_varchar2_table(16) := 'eloper tools, and engineering workflows.'', 1);'||wwv_flow.LF||
'insert into SP_INITIATIVES'||wwv_flow.LF||
'    (id, area_id, initiati';
wwv_flow_imp.g_varchar2_table(17) := 've, status_scale, objective, sponsor_id) '||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (5, 2, ''Cloud Migration'', ''C'', ''Migrate app';
wwv_flow_imp.g_varchar2_table(18) := 'lications and services to modern cloud-native architectures.'', 1);'||wwv_flow.LF||
'insert into SP_INITIATIVES'||wwv_flow.LF||
'    (i';
wwv_flow_imp.g_varchar2_table(19) := 'd, area_id, initiative, status_scale, objective, sponsor_id) '||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (6, 2, ''Quality & Test ';
wwv_flow_imp.g_varchar2_table(20) := 'Automation'', ''A'', ''Expand automated testing, code quality, and release reliability across products.''';
wwv_flow_imp.g_varchar2_table(21) := ', 1);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_initiative_links'||wwv_flow.LF||
'    (id, initiative_id, link_name, link_url, important_yn)'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(22) := '   values'||wwv_flow.LF||
'    (1, 1, ''Fav development platform'',''https://apex.oracle.com'', ''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_in';
wwv_flow_imp.g_varchar2_table(23) := 'itiative_focus_areas'||wwv_flow.LF||
'    (id, initiative_id, focus_area)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (1, 1, ''Customer Systems'');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(24) := 'insert into sp_initiative_focus_areas'||wwv_flow.LF||
'    (id, initiative_id, focus_area)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (2, 1, ''Wor';
wwv_flow_imp.g_varchar2_table(25) := 'kflow'');'||wwv_flow.LF||
'insert into sp_initiative_focus_areas'||wwv_flow.LF||
'    (id, initiative_id, focus_area)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (3';
wwv_flow_imp.g_varchar2_table(26) := ', 1, ''Accessibility'');'||wwv_flow.LF||
'insert into sp_initiative_focus_areas'||wwv_flow.LF||
'    (id, initiative_id, focus_area)'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(27) := ' values'||wwv_flow.LF||
'    (4, 1, ''Security & Identity'');'||wwv_flow.LF||
'insert into sp_initiative_focus_areas'||wwv_flow.LF||
'    (id, initiative';
wwv_flow_imp.g_varchar2_table(28) := '_id, focus_area)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (6, 1, ''Analytics'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_initiative_focus_areas'||wwv_flow.LF||
'    (id,';
wwv_flow_imp.g_varchar2_table(29) := ' initiative_id, focus_area)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (30, 3, ''AI'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_initiative_focus_areas (id';
wwv_flow_imp.g_varchar2_table(30) := ', initiative_id, focus_area) values (31, 2, ''Mobile Experience'');'||wwv_flow.LF||
'insert into sp_initiative_focus_ar';
wwv_flow_imp.g_varchar2_table(31) := 'eas (id, initiative_id, focus_area) values (32, 2, ''Mobile Workflows'');'||wwv_flow.LF||
'insert into sp_initiative_fo';
wwv_flow_imp.g_varchar2_table(32) := 'cus_areas (id, initiative_id, focus_area) values (33, 2, ''Offline & Sync'');'||wwv_flow.LF||
'insert into sp_initiativ';
wwv_flow_imp.g_varchar2_table(33) := 'e_focus_areas (id, initiative_id, focus_area) values (35, 2, ''Mobile Security'');'||wwv_flow.LF||
'insert into sp_init';
wwv_flow_imp.g_varchar2_table(34) := 'iative_focus_areas (id, initiative_id, focus_area) values (36, 2, ''Mobile Commerce'');'||wwv_flow.LF||
'insert into sp';
wwv_flow_imp.g_varchar2_table(35) := '_initiative_focus_areas (id, initiative_id, focus_area) values (37, 2, ''Mobile Accessibility'');'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(36) := 'rt into sp_initiative_focus_areas (id, initiative_id, focus_area) values (38, 2, ''Mobile Quality'');'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(453177761193460361)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sample data - areas and initiatives'
,p_sequence=>9220
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
