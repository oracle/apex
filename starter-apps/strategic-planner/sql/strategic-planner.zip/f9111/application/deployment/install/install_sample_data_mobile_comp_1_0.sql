prompt --application/deployment/install/install_sample_data_mobile_comp_1_0
begin
--   Manifest
--     INSTALL: INSTALL-sample data - mobile comp 1.0
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'sp_globals.g_audit_this := FALSE;'||wwv_flow.LF||
''||wwv_flow.LF||
'insert all'||wwv_flow.LF||
'  into sp_projects (id, initiative_id, project,';
wwv_flow_imp.g_varchar2_table(2) := ' owner_id, active_yn, priority_id, release_id, target_complete, pct_complete, status_id, project_siz';
wwv_flow_imp.g_varchar2_table(3) := 'e, status_scale, description, tags, focus_area_id, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    val';
wwv_flow_imp.g_varchar2_table(4) := 'ues (6001, 2, ''Mobile Companion App Shell and Navigation'', 1, ''Y'', 2, 2, sp_util.fix_demo_dates(sysd';
wwv_flow_imp.g_varchar2_table(5) := 'ate + 12), 80, 1, ''L'', ''A'', ''Delivers the mobile application shell, navigation patterns, and home ex';
wwv_flow_imp.g_varchar2_table(6) := 'perience.'', ''mobile-companion,navigation,ui'', 31, sp_util.fix_demo_dates(sysdate - 60), ''SCOTT.TIGER';
wwv_flow_imp.g_varchar2_table(7) := '@ACME.COM'', sp_util.fix_demo_dates(sysdate - 2), ''SCOTT.TIGER@ACME.COM'')'||wwv_flow.LF||
'  into sp_projects (id, ini';
wwv_flow_imp.g_varchar2_table(8) := 'tiative_id, project, owner_id, active_yn, priority_id, release_id, target_complete, pct_complete, st';
wwv_flow_imp.g_varchar2_table(9) := 'atus_id, project_size, status_scale, description, tags, focus_area_id, created, created_by, updated,';
wwv_flow_imp.g_varchar2_table(10) := ' updated_by)'||wwv_flow.LF||
'    values (6002, 2, ''Mobile Companion Identity and Profile'', 3, ''Y'', 1, 2, sp_util.fix';
wwv_flow_imp.g_varchar2_table(11) := '_demo_dates(sysdate + 13), 80, 1, ''XL'', ''A'', ''Delivers secure mobile sign-in, multifactor enrollment';
wwv_flow_imp.g_varchar2_table(12) := ', and profile management.'', ''mobile-companion,identity,profile'', 35, sp_util.fix_demo_dates(sysdate ';
wwv_flow_imp.g_varchar2_table(13) := '- 60), ''ELENA.VARGAS@ACME.COM'', sp_util.fix_demo_dates(sysdate - 2), ''ELENA.VARGAS@ACME.COM'')'||wwv_flow.LF||
'  into';
wwv_flow_imp.g_varchar2_table(14) := ' sp_projects (id, initiative_id, project, owner_id, active_yn, priority_id, release_id, target_compl';
wwv_flow_imp.g_varchar2_table(15) := 'ete, pct_complete, status_id, project_size, status_scale, description, tags, focus_area_id, created,';
wwv_flow_imp.g_varchar2_table(16) := ' created_by, updated, updated_by)'||wwv_flow.LF||
'    values (6003, 2, ''Mobile Service Request Intake'', 5, ''Y'', 2, 2';
wwv_flow_imp.g_varchar2_table(17) := ', sp_util.fix_demo_dates(sysdate + 10), 70, 1, ''L'', ''A'', ''Delivers guided mobile service-request int';
wwv_flow_imp.g_varchar2_table(18) := 'ake with attachment capture and request tracking.'', ''mobile-companion,service-requests,workflow'', 32';
wwv_flow_imp.g_varchar2_table(19) := ', sp_util.fix_demo_dates(sysdate - 60), ''NAOMI.CHEN@ACME.COM'', sp_util.fix_demo_dates(sysdate - 3), ';
wwv_flow_imp.g_varchar2_table(20) := '''NAOMI.CHEN@ACME.COM'')'||wwv_flow.LF||
'  into sp_projects (id, initiative_id, project, owner_id, active_yn, priority';
wwv_flow_imp.g_varchar2_table(21) := '_id, release_id, target_complete, pct_complete, status_id, project_size, status_scale, description, ';
wwv_flow_imp.g_varchar2_table(22) := 'tags, focus_area_id, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (6004, 2, ''Mobile Document';
wwv_flow_imp.g_varchar2_table(23) := ' Capture and Upload'', 7, ''Y'', 3, 2, sp_util.fix_demo_dates(sysdate + 9), 60, 1, ''M'', ''A'', ''Delivers ';
wwv_flow_imp.g_varchar2_table(24) := 'camera-based document capture, upload validation, and resumable transfers.'', ''mobile-companion,docum';
wwv_flow_imp.g_varchar2_table(25) := 'ents,upload'', 33, sp_util.fix_demo_dates(sysdate - 60), ''CALEB.FOSTER@ACME.COM'', sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(26) := 'tes(sysdate - 4), ''CALEB.FOSTER@ACME.COM'')'||wwv_flow.LF||
'  into sp_projects (id, initiative_id, project, owner_id,';
wwv_flow_imp.g_varchar2_table(27) := ' active_yn, priority_id, release_id, target_complete, pct_complete, status_id, project_size, status_';
wwv_flow_imp.g_varchar2_table(28) := 'scale, description, tags, focus_area_id, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (6005,';
wwv_flow_imp.g_varchar2_table(29) := ' 2, ''Mobile Notifications and Preferences'', 9, ''Y'', 3, 2, sp_util.fix_demo_dates(sysdate + 8), 60, 1';
wwv_flow_imp.g_varchar2_table(30) := ', ''M'', ''A'', ''Delivers push-notification preferences, deep links, and mobile notification delivery.'',';
wwv_flow_imp.g_varchar2_table(31) := ' ''mobile-companion,notifications,preferences'', 31, sp_util.fix_demo_dates(sysdate - 60), ''ANDRE.COLL';
wwv_flow_imp.g_varchar2_table(32) := 'INS@ACME.COM'', sp_util.fix_demo_dates(sysdate - 4), ''ANDRE.COLLINS@ACME.COM'')'||wwv_flow.LF||
'  into sp_projects (id';
wwv_flow_imp.g_varchar2_table(33) := ', initiative_id, project, owner_id, active_yn, priority_id, release_id, target_complete, pct_complet';
wwv_flow_imp.g_varchar2_table(34) := 'e, status_id, project_size, status_scale, description, tags, focus_area_id, created, created_by, upd';
wwv_flow_imp.g_varchar2_table(35) := 'ated, updated_by)'||wwv_flow.LF||
'    values (6006, 2, ''Mobile Offline Mode and Synchronization'', 11, ''Y'', 1, 2, sp_';
wwv_flow_imp.g_varchar2_table(36) := 'util.fix_demo_dates(sysdate + 13), 80, 2, ''XL'', ''A'', ''Delivers offline access to key customer data a';
wwv_flow_imp.g_varchar2_table(37) := 'nd conflict-aware background synchronization.'', ''mobile-companion,offline,sync'', 33, sp_util.fix_dem';
wwv_flow_imp.g_varchar2_table(38) := 'o_dates(sysdate - 60), ''VICTOR.RAMIREZ@ACME.COM'', sp_util.fix_demo_dates(sysdate - 5), ''VICTOR.RAMIR';
wwv_flow_imp.g_varchar2_table(39) := 'EZ@ACME.COM'')'||wwv_flow.LF||
'  into sp_projects (id, initiative_id, project, owner_id, active_yn, priority_id, rele';
wwv_flow_imp.g_varchar2_table(40) := 'ase_id, target_complete, pct_complete, status_id, project_size, status_scale, description, tags, foc';
wwv_flow_imp.g_varchar2_table(41) := 'us_area_id, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (6007, 2, ''Mobile Billing and Payme';
wwv_flow_imp.g_varchar2_table(42) := 'nts'', 13, ''Y'', 1, 2, sp_util.fix_demo_dates(sysdate + 14), 70, 2, ''XL'', ''A'', ''Delivers invoice viewi';
wwv_flow_imp.g_varchar2_table(43) := 'ng, payment initiation, and secure payment confirmations on mobile.'', ''mobile-companion,billing,paym';
wwv_flow_imp.g_varchar2_table(44) := 'ents'', 36, sp_util.fix_demo_dates(sysdate - 60), ''ISAAC.TURNER@ACME.COM'', sp_util.fix_demo_dates(sys';
wwv_flow_imp.g_varchar2_table(45) := 'date - 6), ''ISAAC.TURNER@ACME.COM'')'||wwv_flow.LF||
'  into sp_projects (id, initiative_id, project, owner_id, active';
wwv_flow_imp.g_varchar2_table(46) := '_yn, priority_id, release_id, target_complete, pct_complete, status_id, project_size, status_scale, ';
wwv_flow_imp.g_varchar2_table(47) := 'description, tags, focus_area_id, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (6008, 3, ''Mo';
wwv_flow_imp.g_varchar2_table(48) := 'bile AI Support Assistant'', 15, ''Y'', 2, 2, sp_util.fix_demo_dates(sysdate + 12), 70, 1, ''L'', ''A'', ''D';
wwv_flow_imp.g_varchar2_table(49) := 'elivers a knowledge-grounded AI assistant with mobile-first escalation to customer support.'', ''mobil';
wwv_flow_imp.g_varchar2_table(50) := 'e-companion,ai,support'', 30, sp_util.fix_demo_dates(sysdate - 60), ''DOMINIC.REYES@ACME.COM'', sp_util';
wwv_flow_imp.g_varchar2_table(51) := '.fix_demo_dates(sysdate - 3), ''DOMINIC.REYES@ACME.COM'')'||wwv_flow.LF||
'  into sp_projects (id, initiative_id, proje';
wwv_flow_imp.g_varchar2_table(52) := 'ct, owner_id, active_yn, priority_id, release_id, target_complete, pct_complete, status_id, project_';
wwv_flow_imp.g_varchar2_table(53) := 'size, status_scale, description, tags, focus_area_id, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(54) := 'values (6009, 2, ''Mobile Accessibility Foundation'', 17, ''Y'', 2, 2, sp_util.fix_demo_dates(sysdate + ';
wwv_flow_imp.g_varchar2_table(55) := '7), 90, 1, ''L'', ''A'', ''Delivers accessible components, screen-reader support, and keyboard-equivalent';
wwv_flow_imp.g_varchar2_table(56) := ' interactions.'', ''mobile-companion,accessibility'', 37, sp_util.fix_demo_dates(sysdate - 60), ''ETHAN.';
wwv_flow_imp.g_varchar2_table(57) := 'CALDWELL@ACME.COM'', sp_util.fix_demo_dates(sysdate - 1), ''ETHAN.CALDWELL@ACME.COM'')'||wwv_flow.LF||
'  into sp_projec';
wwv_flow_imp.g_varchar2_table(58) := 'ts (id, initiative_id, project, owner_id, active_yn, priority_id, release_id, target_complete, pct_c';
wwv_flow_imp.g_varchar2_table(59) := 'omplete, status_id, project_size, status_scale, description, tags, focus_area_id, created, created_b';
wwv_flow_imp.g_varchar2_table(60) := 'y, updated, updated_by)'||wwv_flow.LF||
'    values (6010, 2, ''Mobile Performance and Quality Automation'', 19, ''Y'', 2';
wwv_flow_imp.g_varchar2_table(61) := ', 2, sp_util.fix_demo_dates(sysdate + 15), 60, 2, ''L'', ''A'', ''Delivers automated device testing, perf';
wwv_flow_imp.g_varchar2_table(62) := 'ormance telemetry, and mobile release-quality gates.'', ''mobile-companion,performance,quality-automat';
wwv_flow_imp.g_varchar2_table(63) := 'ion'', 38, sp_util.fix_demo_dates(sysdate - 60), ''LUCAS.BENNETT@ACME.COM'', sp_util.fix_demo_dates(sys';
wwv_flow_imp.g_varchar2_table(64) := 'date - 5), ''LUCAS.BENNETT@ACME.COM'')'||wwv_flow.LF||
'select 1 from dual;'||wwv_flow.LF||
''||wwv_flow.LF||
'insert all'||wwv_flow.LF||
'  into sp_project_contributors ';
wwv_flow_imp.g_varchar2_table(65) := '(id, project_id, team_member_id, responsibility_id, responsibility, tags, created, created_by, updat';
wwv_flow_imp.g_varchar2_table(66) := 'ed, updated_by) values (6101, 6001, 1, 3, ''Owns app-shell delivery and stakeholder coordination.'', ''';
wwv_flow_imp.g_varchar2_table(67) := 'project-management'', sp_util.fix_demo_dates(sysdate - 60), ''SCOTT.TIGER@ACME.COM'', sp_util.fix_demo_';
wwv_flow_imp.g_varchar2_table(68) := 'dates(sysdate - 60), ''SCOTT.TIGER@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_me';
wwv_flow_imp.g_varchar2_table(69) := 'mber_id, responsibility_id, responsibility, tags, created, created_by, updated, updated_by) values (';
wwv_flow_imp.g_varchar2_table(70) := '6102, 6001, 2, 1, ''Builds navigation and mobile home experience.'', ''mobile,frontend'', sp_util.fix_de';
wwv_flow_imp.g_varchar2_table(71) := 'mo_dates(sysdate - 60), ''SCOTT.TIGER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 60), ''SCOTT.TIGER@A';
wwv_flow_imp.g_varchar2_table(72) := 'CME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_id, responsibility_id, respons';
wwv_flow_imp.g_varchar2_table(73) := 'ibility, tags, created, created_by, updated, updated_by) values (6103, 6001, 8, 8, ''Designs mobile n';
wwv_flow_imp.g_varchar2_table(74) := 'avigation patterns.'', ''ux,design'', sp_util.fix_demo_dates(sysdate - 60), ''SCOTT.TIGER@ACME.COM'', sp_';
wwv_flow_imp.g_varchar2_table(75) := 'util.fix_demo_dates(sysdate - 60), ''SCOTT.TIGER@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, proje';
wwv_flow_imp.g_varchar2_table(76) := 'ct_id, team_member_id, responsibility_id, responsibility, tags, created, created_by, updated, update';
wwv_flow_imp.g_varchar2_table(77) := 'd_by) values (6104, 6002, 3, 3, ''Owns identity and profile delivery.'', ''project-management'', sp_util';
wwv_flow_imp.g_varchar2_table(78) := '.fix_demo_dates(sysdate - 60), ''ELENA.VARGAS@ACME.COM'', sp_util.fix_demo_dates(sysdate - 60), ''ELENA';
wwv_flow_imp.g_varchar2_table(79) := '.VARGAS@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_id, responsibility_id';
wwv_flow_imp.g_varchar2_table(80) := ', responsibility, tags, created, created_by, updated, updated_by) values (6105, 6002, 4, 1, ''Builds ';
wwv_flow_imp.g_varchar2_table(81) := 'mobile sign-in and profile functions.'', ''identity,mobile'', sp_util.fix_demo_dates(sysdate - 60), ''EL';
wwv_flow_imp.g_varchar2_table(82) := 'ENA.VARGAS@ACME.COM'', sp_util.fix_demo_dates(sysdate - 60), ''ELENA.VARGAS@ACME.COM'')'||wwv_flow.LF||
'  into sp_proje';
wwv_flow_imp.g_varchar2_table(83) := 'ct_contributors (id, project_id, team_member_id, responsibility_id, responsibility, tags, created, c';
wwv_flow_imp.g_varchar2_table(84) := 'reated_by, updated, updated_by) values (6106, 6002, 6, 2, ''Reviews mobile authentication architectur';
wwv_flow_imp.g_varchar2_table(85) := 'e.'', ''architecture,security'', sp_util.fix_demo_dates(sysdate - 60), ''ELENA.VARGAS@ACME.COM'', sp_util';
wwv_flow_imp.g_varchar2_table(86) := '.fix_demo_dates(sysdate - 60), ''ELENA.VARGAS@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_';
wwv_flow_imp.g_varchar2_table(87) := 'id, team_member_id, responsibility_id, responsibility, tags, created, created_by, updated, updated_b';
wwv_flow_imp.g_varchar2_table(88) := 'y) values (6107, 6003, 5, 3, ''Owns service-request intake delivery.'', ''project-management'', sp_util.';
wwv_flow_imp.g_varchar2_table(89) := 'fix_demo_dates(sysdate - 60), ''NAOMI.CHEN@ACME.COM'', sp_util.fix_demo_dates(sysdate - 60), ''NAOMI.CH';
wwv_flow_imp.g_varchar2_table(90) := 'EN@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_id, responsibility_id, res';
wwv_flow_imp.g_varchar2_table(91) := 'ponsibility, tags, created, created_by, updated, updated_by) values (6108, 6003, 6, 1, ''Builds reque';
wwv_flow_imp.g_varchar2_table(92) := 'st workflow and attachment capture.'', ''workflow,mobile'', sp_util.fix_demo_dates(sysdate - 60), ''NAOM';
wwv_flow_imp.g_varchar2_table(93) := 'I.CHEN@ACME.COM'', sp_util.fix_demo_dates(sysdate - 60), ''NAOMI.CHEN@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_con';
wwv_flow_imp.g_varchar2_table(94) := 'tributors (id, project_id, team_member_id, responsibility_id, responsibility, tags, created, created';
wwv_flow_imp.g_varchar2_table(95) := '_by, updated, updated_by) values (6109, 6003, 10, 5, ''Validates request and attachment scenarios.'', ';
wwv_flow_imp.g_varchar2_table(96) := '''qa,functional-testing'', sp_util.fix_demo_dates(sysdate - 60), ''NAOMI.CHEN@ACME.COM'', sp_util.fix_de';
wwv_flow_imp.g_varchar2_table(97) := 'mo_dates(sysdate - 60), ''NAOMI.CHEN@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_';
wwv_flow_imp.g_varchar2_table(98) := 'member_id, responsibility_id, responsibility, tags, created, created_by, updated, updated_by) values';
wwv_flow_imp.g_varchar2_table(99) := ' (6110, 6004, 7, 3, ''Owns document capture delivery.'', ''project-management'', sp_util.fix_demo_dates(';
wwv_flow_imp.g_varchar2_table(100) := 'sysdate - 60), ''CALEB.FOSTER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 60), ''CALEB.FOSTER@ACME.COM';
wwv_flow_imp.g_varchar2_table(101) := ''')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_id, responsibility_id, responsibility';
wwv_flow_imp.g_varchar2_table(102) := ', tags, created, created_by, updated, updated_by) values (6111, 6004, 8, 1, ''Builds camera capture a';
wwv_flow_imp.g_varchar2_table(103) := 'nd upload processing.'', ''mobile,upload'', sp_util.fix_demo_dates(sysdate - 60), ''CALEB.FOSTER@ACME.CO';
wwv_flow_imp.g_varchar2_table(104) := 'M'', sp_util.fix_demo_dates(sysdate - 60), ''CALEB.FOSTER@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (i';
wwv_flow_imp.g_varchar2_table(105) := 'd, project_id, team_member_id, responsibility_id, responsibility, tags, created, created_by, updated';
wwv_flow_imp.g_varchar2_table(106) := ', updated_by) values (6112, 6004, 12, 5, ''Validates upload reliability and recovery.'', ''qa,upload'', ';
wwv_flow_imp.g_varchar2_table(107) := 'sp_util.fix_demo_dates(sysdate - 60), ''CALEB.FOSTER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 60),';
wwv_flow_imp.g_varchar2_table(108) := ' ''CALEB.FOSTER@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_id, responsibi';
wwv_flow_imp.g_varchar2_table(109) := 'lity_id, responsibility, tags, created, created_by, updated, updated_by) values (6113, 6005, 9, 3, ''';
wwv_flow_imp.g_varchar2_table(110) := 'Owns notification delivery.'', ''project-management'', sp_util.fix_demo_dates(sysdate - 60), ''ANDRE.COL';
wwv_flow_imp.g_varchar2_table(111) := 'LINS@ACME.COM'', sp_util.fix_demo_dates(sysdate - 60), ''ANDRE.COLLINS@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_co';
wwv_flow_imp.g_varchar2_table(112) := 'ntributors (id, project_id, team_member_id, responsibility_id, responsibility, tags, created, create';
wwv_flow_imp.g_varchar2_table(113) := 'd_by, updated, updated_by) values (6114, 6005, 10, 1, ''Builds push notifications and deep links.'', ''';
wwv_flow_imp.g_varchar2_table(114) := 'notifications,mobile'', sp_util.fix_demo_dates(sysdate - 60), ''ANDRE.COLLINS@ACME.COM'', sp_util.fix_d';
wwv_flow_imp.g_varchar2_table(115) := 'emo_dates(sysdate - 60), ''ANDRE.COLLINS@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, t';
wwv_flow_imp.g_varchar2_table(116) := 'eam_member_id, responsibility_id, responsibility, tags, created, created_by, updated, updated_by) va';
wwv_flow_imp.g_varchar2_table(117) := 'lues (6115, 6005, 14, 8, ''Designs notification preference screens.'', ''ux,design'', sp_util.fix_demo_d';
wwv_flow_imp.g_varchar2_table(118) := 'ates(sysdate - 60), ''ANDRE.COLLINS@ACME.COM'', sp_util.fix_demo_dates(sysdate - 60), ''ANDRE.COLLINS@A';
wwv_flow_imp.g_varchar2_table(119) := 'CME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_id, responsibility_id, respons';
wwv_flow_imp.g_varchar2_table(120) := 'ibility, tags, created, created_by, updated, updated_by) values (6116, 6006, 11, 3, ''Owns offline sy';
wwv_flow_imp.g_varchar2_table(121) := 'nchronization delivery.'', ''project-management'', sp_util.fix_demo_dates(sysdate - 60), ''VICTOR.RAMIRE';
wwv_flow_imp.g_varchar2_table(122) := 'Z@ACME.COM'', sp_util.fix_demo_dates(sysdate - 60), ''VICTOR.RAMIREZ@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_cont';
wwv_flow_imp.g_varchar2_table(123) := 'ributors (id, project_id, team_member_id, responsibility_id, responsibility, tags, created, created_';
wwv_flow_imp.g_varchar2_table(124) := 'by, updated, updated_by) values (6117, 6006, 12, 1, ''Builds local data storage and synchronization.''';
wwv_flow_imp.g_varchar2_table(125) := ', ''offline,sync'', sp_util.fix_demo_dates(sysdate - 60), ''VICTOR.RAMIREZ@ACME.COM'', sp_util.fix_demo_';
wwv_flow_imp.g_varchar2_table(126) := 'dates(sysdate - 60), ''VICTOR.RAMIREZ@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team';
wwv_flow_imp.g_varchar2_table(127) := '_member_id, responsibility_id, responsibility, tags, created, created_by, updated, updated_by) value';
wwv_flow_imp.g_varchar2_table(128) := 's (6118, 6006, 16, 5, ''Validates offline and conflict scenarios.'', ''qa,sync'', sp_util.fix_demo_dates';
wwv_flow_imp.g_varchar2_table(129) := '(sysdate - 60), ''VICTOR.RAMIREZ@ACME.COM'', sp_util.fix_demo_dates(sysdate - 60), ''VICTOR.RAMIREZ@ACM';
wwv_flow_imp.g_varchar2_table(130) := 'E.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_id, responsibility_id, responsib';
wwv_flow_imp.g_varchar2_table(131) := 'ility, tags, created, created_by, updated, updated_by) values (6119, 6007, 13, 3, ''Owns mobile payme';
wwv_flow_imp.g_varchar2_table(132) := 'nt delivery.'', ''project-management'', sp_util.fix_demo_dates(sysdate - 60), ''ISAAC.TURNER@ACME.COM'', ';
wwv_flow_imp.g_varchar2_table(133) := 'sp_util.fix_demo_dates(sysdate - 60), ''ISAAC.TURNER@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, p';
wwv_flow_imp.g_varchar2_table(134) := 'roject_id, team_member_id, responsibility_id, responsibility, tags, created, created_by, updated, up';
wwv_flow_imp.g_varchar2_table(135) := 'dated_by) values (6120, 6007, 14, 1, ''Builds mobile billing and payment integration.'', ''payments,mob';
wwv_flow_imp.g_varchar2_table(136) := 'ile'', sp_util.fix_demo_dates(sysdate - 60), ''ISAAC.TURNER@ACME.COM'', sp_util.fix_demo_dates(sysdate ';
wwv_flow_imp.g_varchar2_table(137) := '- 60), ''ISAAC.TURNER@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_id, resp';
wwv_flow_imp.g_varchar2_table(138) := 'onsibility_id, responsibility, tags, created, created_by, updated, updated_by) values (6121, 6007, 1';
wwv_flow_imp.g_varchar2_table(139) := '6, 2, ''Reviews payment security architecture.'', ''architecture,security'', sp_util.fix_demo_dates(sysd';
wwv_flow_imp.g_varchar2_table(140) := 'ate - 60), ''ISAAC.TURNER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 60), ''ISAAC.TURNER@ACME.COM'')'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(141) := ' into sp_project_contributors (id, project_id, team_member_id, responsibility_id, responsibility, ta';
wwv_flow_imp.g_varchar2_table(142) := 'gs, created, created_by, updated, updated_by) values (6122, 6008, 15, 3, ''Owns mobile AI assistant d';
wwv_flow_imp.g_varchar2_table(143) := 'elivery.'', ''project-management,ai'', sp_util.fix_demo_dates(sysdate - 60), ''DOMINIC.REYES@ACME.COM'', ';
wwv_flow_imp.g_varchar2_table(144) := 'sp_util.fix_demo_dates(sysdate - 60), ''DOMINIC.REYES@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, ';
wwv_flow_imp.g_varchar2_table(145) := 'project_id, team_member_id, responsibility_id, responsibility, tags, created, created_by, updated, u';
wwv_flow_imp.g_varchar2_table(146) := 'pdated_by) values (6123, 6008, 16, 1, ''Builds mobile assistant and support handoff.'', ''ai,mobile'', s';
wwv_flow_imp.g_varchar2_table(147) := 'p_util.fix_demo_dates(sysdate - 60), ''DOMINIC.REYES@ACME.COM'', sp_util.fix_demo_dates(sysdate - 60),';
wwv_flow_imp.g_varchar2_table(148) := ' ''DOMINIC.REYES@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_id, responsib';
wwv_flow_imp.g_varchar2_table(149) := 'ility_id, responsibility, tags, created, created_by, updated, updated_by) values (6124, 6008, 18, 7,';
wwv_flow_imp.g_varchar2_table(150) := ' ''Evaluates assistant knowledge coverage.'', ''research,ai'', sp_util.fix_demo_dates(sysdate - 60), ''DO';
wwv_flow_imp.g_varchar2_table(151) := 'MINIC.REYES@ACME.COM'', sp_util.fix_demo_dates(sysdate - 60), ''DOMINIC.REYES@ACME.COM'')'||wwv_flow.LF||
'  into sp_pro';
wwv_flow_imp.g_varchar2_table(152) := 'ject_contributors (id, project_id, team_member_id, responsibility_id, responsibility, tags, created,';
wwv_flow_imp.g_varchar2_table(153) := ' created_by, updated, updated_by) values (6125, 6009, 17, 3, ''Owns accessibility foundation delivery';
wwv_flow_imp.g_varchar2_table(154) := '.'', ''project-management,accessibility'', sp_util.fix_demo_dates(sysdate - 60), ''ETHAN.CALDWELL@ACME.C';
wwv_flow_imp.g_varchar2_table(155) := 'OM'', sp_util.fix_demo_dates(sysdate - 60), ''ETHAN.CALDWELL@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors';
wwv_flow_imp.g_varchar2_table(156) := ' (id, project_id, team_member_id, responsibility_id, responsibility, tags, created, created_by, upda';
wwv_flow_imp.g_varchar2_table(157) := 'ted, updated_by) values (6126, 6009, 18, 1, ''Builds accessible mobile components.'', ''mobile,accessib';
wwv_flow_imp.g_varchar2_table(158) := 'ility'', sp_util.fix_demo_dates(sysdate - 60), ''ETHAN.CALDWELL@ACME.COM'', sp_util.fix_demo_dates(sysd';
wwv_flow_imp.g_varchar2_table(159) := 'ate - 60), ''ETHAN.CALDWELL@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_id';
wwv_flow_imp.g_varchar2_table(160) := ', responsibility_id, responsibility, tags, created, created_by, updated, updated_by) values (6127, 6';
wwv_flow_imp.g_varchar2_table(161) := '009, 20, 5, ''Validates screen-reader and interaction coverage.'', ''qa,accessibility'', sp_util.fix_dem';
wwv_flow_imp.g_varchar2_table(162) := 'o_dates(sysdate - 60), ''ETHAN.CALDWELL@ACME.COM'', sp_util.fix_demo_dates(sysdate - 60), ''ETHAN.CALDW';
wwv_flow_imp.g_varchar2_table(163) := 'ELL@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, project_id, team_member_id, responsibility_id, re';
wwv_flow_imp.g_varchar2_table(164) := 'sponsibility, tags, created, created_by, updated, updated_by) values (6128, 6010, 19, 3, ''Owns perfo';
wwv_flow_imp.g_varchar2_table(165) := 'rmance and quality delivery.'', ''project-management,quality'', sp_util.fix_demo_dates(sysdate - 60), ''';
wwv_flow_imp.g_varchar2_table(166) := 'LUCAS.BENNETT@ACME.COM'', sp_util.fix_demo_dates(sysdate - 60), ''LUCAS.BENNETT@ACME.COM'')'||wwv_flow.LF||
'  into sp_p';
wwv_flow_imp.g_varchar2_table(167) := 'roject_contributors (id, project_id, team_member_id, responsibility_id, responsibility, tags, create';
wwv_flow_imp.g_varchar2_table(168) := 'd, created_by, updated, updated_by) values (6129, 6010, 20, 1, ''Builds automated testing and telemet';
wwv_flow_imp.g_varchar2_table(169) := 'ry.'', ''automation,performance'', sp_util.fix_demo_dates(sysdate - 60), ''LUCAS.BENNETT@ACME.COM'', sp_u';
wwv_flow_imp.g_varchar2_table(170) := 'til.fix_demo_dates(sysdate - 60), ''LUCAS.BENNETT@ACME.COM'')'||wwv_flow.LF||
'  into sp_project_contributors (id, proj';
wwv_flow_imp.g_varchar2_table(171) := 'ect_id, team_member_id, responsibility_id, responsibility, tags, created, created_by, updated, updat';
wwv_flow_imp.g_varchar2_table(172) := 'ed_by) values (6130, 6010, 21, 5, ''Validates device coverage and quality gates.'', ''qa,automation'', s';
wwv_flow_imp.g_varchar2_table(173) := 'p_util.fix_demo_dates(sysdate - 60), ''LUCAS.BENNETT@ACME.COM'', sp_util.fix_demo_dates(sysdate - 60),';
wwv_flow_imp.g_varchar2_table(174) := ' ''LUCAS.BENNETT@ACME.COM'')'||wwv_flow.LF||
'select 1 from dual;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Comments are inserted oldest to newest so the com';
wwv_flow_imp.g_varchar2_table(175) := 'ment-number trigger assigns numbers chronologically.'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id';
wwv_flow_imp.g_varchar2_table(176) := ', author_id, body, body_html, body_no_images, private_yn, created, created_by, updated, updated_by)'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(177) := '  values (6201, 6001, 1, ''Navigation patterns were consolidated into a shared shell to keep iOS and ';
wwv_flow_imp.g_varchar2_table(178) := 'Android behavior aligned.'', ''Navigation patterns were consolidated into a shared shell to keep iOS a';
wwv_flow_imp.g_varchar2_table(179) := 'nd Android behavior aligned.'', ''Navigation patterns were consolidated into a shared shell to keep iO';
wwv_flow_imp.g_varchar2_table(180) := 'S and Android behavior aligned.'', ''N'', sp_util.fix_demo_dates(sysdate - 45), upper(''scott.tiger@acme';
wwv_flow_imp.g_varchar2_table(181) := '.com''), sp_util.fix_demo_dates(sysdate - 45), upper(''scott.tiger@acme.com''));'||wwv_flow.LF||
'insert into sp_project';
wwv_flow_imp.g_varchar2_table(182) := '_comments (id, project_id, author_id, body, body_html, body_no_images, private_yn, created, created_';
wwv_flow_imp.g_varchar2_table(183) := 'by, updated, updated_by)'||wwv_flow.LF||
'  values (6202, 6001, 2, ''Product approved the simplified home experience f';
wwv_flow_imp.g_varchar2_table(184) := 'or the 1.0 release.'', ''Product approved the simplified home experience for the 1.0 release.'', ''Produ';
wwv_flow_imp.g_varchar2_table(185) := 'ct approved the simplified home experience for the 1.0 release.'', ''N'', sp_util.fix_demo_dates(sysdat';
wwv_flow_imp.g_varchar2_table(186) := 'e - 43), upper(''marcus.hale@acme.com''), sp_util.fix_demo_dates(sysdate - 43), upper(''marcus.hale@acm';
wwv_flow_imp.g_varchar2_table(187) := 'e.com''));'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id, author_id, body, body_html, body_no_image';
wwv_flow_imp.g_varchar2_table(188) := 's, private_yn, created, created_by, updated, updated_by)'||wwv_flow.LF||
'  values (6203, 6002, 3, ''MFA enrollment wi';
wwv_flow_imp.g_varchar2_table(189) := 'll be progressive so existing customers are not blocked at first sign-in.'', ''MFA enrollment will be ';
wwv_flow_imp.g_varchar2_table(190) := 'progressive so existing customers are not blocked at first sign-in.'', ''MFA enrollment will be progre';
wwv_flow_imp.g_varchar2_table(191) := 'ssive so existing customers are not blocked at first sign-in.'', ''N'', sp_util.fix_demo_dates(sysdate ';
wwv_flow_imp.g_varchar2_table(192) := '- 40), upper(''elena.vargas@acme.com''), sp_util.fix_demo_dates(sysdate - 40), upper(''elena.vargas@acm';
wwv_flow_imp.g_varchar2_table(193) := 'e.com''));'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id, author_id, body, body_html, body_no_image';
wwv_flow_imp.g_varchar2_table(194) := 's, private_yn, created, created_by, updated, updated_by)'||wwv_flow.LF||
'  values (6204, 6002, 4, ''Security accepted';
wwv_flow_imp.g_varchar2_table(195) := ' the mobile session timeout and account-recovery approach.'', ''Security accepted the mobile session t';
wwv_flow_imp.g_varchar2_table(196) := 'imeout and account-recovery approach.'', ''Security accepted the mobile session timeout and account-re';
wwv_flow_imp.g_varchar2_table(197) := 'covery approach.'', ''N'', sp_util.fix_demo_dates(sysdate - 38), upper(''tyler.brooks@acme.com''), sp_uti';
wwv_flow_imp.g_varchar2_table(198) := 'l.fix_demo_dates(sysdate - 38), upper(''tyler.brooks@acme.com''));'||wwv_flow.LF||
'insert into sp_project_comments (id';
wwv_flow_imp.g_varchar2_table(199) := ', project_id, author_id, body, body_html, body_no_images, private_yn, created, created_by, updated, ';
wwv_flow_imp.g_varchar2_table(200) := 'updated_by)'||wwv_flow.LF||
'  values (6205, 6003, 5, ''Guided intake was selected over a free-form request screen to ';
wwv_flow_imp.g_varchar2_table(201) := 'improve routing quality.'', ''Guided intake was selected over a free-form request screen to improve ro';
wwv_flow_imp.g_varchar2_table(202) := 'uting quality.'', ''Guided intake was selected over a free-form request screen to improve routing qual';
wwv_flow_imp.g_varchar2_table(203) := 'ity.'', ''N'', sp_util.fix_demo_dates(sysdate - 35), upper(''naomi.chen@acme.com''), sp_util.fix_demo_dat';
wwv_flow_imp.g_varchar2_table(204) := 'es(sysdate - 35), upper(''naomi.chen@acme.com''));'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id, au';
wwv_flow_imp.g_varchar2_table(205) := 'thor_id, body, body_html, body_no_images, private_yn, created, created_by, updated, updated_by)'||wwv_flow.LF||
'  va';
wwv_flow_imp.g_varchar2_table(206) := 'lues (6206, 6003, 6, ''Operations approved the required request fields and mobile attachment limits.''';
wwv_flow_imp.g_varchar2_table(207) := ', ''Operations approved the required request fields and mobile attachment limits.'', ''Operations appro';
wwv_flow_imp.g_varchar2_table(208) := 'ved the required request fields and mobile attachment limits.'', ''N'', sp_util.fix_demo_dates(sysdate ';
wwv_flow_imp.g_varchar2_table(209) := '- 33), upper(''jordan.avery@acme.com''), sp_util.fix_demo_dates(sysdate - 33), upper(''jordan.avery@acm';
wwv_flow_imp.g_varchar2_table(210) := 'e.com''));'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id, author_id, body, body_html, body_no_image';
wwv_flow_imp.g_varchar2_table(211) := 's, private_yn, created, created_by, updated, updated_by)'||wwv_flow.LF||
'  values (6207, 6004, 7, ''The upload flow n';
wwv_flow_imp.g_varchar2_table(212) := 'ow resumes interrupted transfers when the device reconnects.'', ''The upload flow now resumes interrup';
wwv_flow_imp.g_varchar2_table(213) := 'ted transfers when the device reconnects.'', ''The upload flow now resumes interrupted transfers when ';
wwv_flow_imp.g_varchar2_table(214) := 'the device reconnects.'', ''N'', sp_util.fix_demo_dates(sysdate - 30), upper(''caleb.foster@acme.com''), ';
wwv_flow_imp.g_varchar2_table(215) := 'sp_util.fix_demo_dates(sysdate - 30), upper(''caleb.foster@acme.com''));'||wwv_flow.LF||
'insert into sp_project_commen';
wwv_flow_imp.g_varchar2_table(216) := 'ts (id, project_id, author_id, body, body_html, body_no_images, private_yn, created, created_by, upd';
wwv_flow_imp.g_varchar2_table(217) := 'ated, updated_by)'||wwv_flow.LF||
'  values (6208, 6004, 8, ''The team agreed to limit document capture to PDF and ima';
wwv_flow_imp.g_varchar2_table(218) := 'ge formats for 1.0.'', ''The team agreed to limit document capture to PDF and image formats for 1.0.'',';
wwv_flow_imp.g_varchar2_table(219) := ' ''The team agreed to limit document capture to PDF and image formats for 1.0.'', ''N'', sp_util.fix_dem';
wwv_flow_imp.g_varchar2_table(220) := 'o_dates(sysdate - 28), upper(''lila.montgomery@acme.com''), sp_util.fix_demo_dates(sysdate - 28), uppe';
wwv_flow_imp.g_varchar2_table(221) := 'r(''lila.montgomery@acme.com''));'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id, author_id, body, bo';
wwv_flow_imp.g_varchar2_table(222) := 'dy_html, body_no_images, private_yn, created, created_by, updated, updated_by)'||wwv_flow.LF||
'  values (6209, 6005,';
wwv_flow_imp.g_varchar2_table(223) := ' 9, ''Notification preferences were moved into one screen to avoid conflicting channel settings.'', ''N';
wwv_flow_imp.g_varchar2_table(224) := 'otification preferences were moved into one screen to avoid conflicting channel settings.'', ''Notific';
wwv_flow_imp.g_varchar2_table(225) := 'ation preferences were moved into one screen to avoid conflicting channel settings.'', ''N'', sp_util.f';
wwv_flow_imp.g_varchar2_table(226) := 'ix_demo_dates(sysdate - 25), upper(''andre.collins@acme.com''), sp_util.fix_demo_dates(sysdate - 25), ';
wwv_flow_imp.g_varchar2_table(227) := 'upper(''andre.collins@acme.com''));'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id, author_id, body, ';
wwv_flow_imp.g_varchar2_table(228) := 'body_html, body_no_images, private_yn, created, created_by, updated, updated_by)'||wwv_flow.LF||
'  values (6210, 600';
wwv_flow_imp.g_varchar2_table(229) := '5, 10, ''Product approved deep links for request updates and billing alerts.'', ''Product approved deep';
wwv_flow_imp.g_varchar2_table(230) := ' links for request updates and billing alerts.'', ''Product approved deep links for request updates an';
wwv_flow_imp.g_varchar2_table(231) := 'd billing alerts.'', ''N'', sp_util.fix_demo_dates(sysdate - 23), upper(''sophie.bennett@acme.com''), sp_';
wwv_flow_imp.g_varchar2_table(232) := 'util.fix_demo_dates(sysdate - 23), upper(''sophie.bennett@acme.com''));'||wwv_flow.LF||
'insert into sp_project_comment';
wwv_flow_imp.g_varchar2_table(233) := 's (id, project_id, author_id, body, body_html, body_no_images, private_yn, created, created_by, upda';
wwv_flow_imp.g_varchar2_table(234) := 'ted, updated_by)'||wwv_flow.LF||
'  values (6211, 6006, 11, ''The synchronization engine now records conflicts for cus';
wwv_flow_imp.g_varchar2_table(235) := 'tomer review rather than overwriting data.'', ''The synchronization engine now records conflicts for c';
wwv_flow_imp.g_varchar2_table(236) := 'ustomer review rather than overwriting data.'', ''The synchronization engine now records conflicts for';
wwv_flow_imp.g_varchar2_table(237) := ' customer review rather than overwriting data.'', ''N'', sp_util.fix_demo_dates(sysdate - 20), upper(''v';
wwv_flow_imp.g_varchar2_table(238) := 'ictor.ramirez@acme.com''), sp_util.fix_demo_dates(sysdate - 20), upper(''victor.ramirez@acme.com''));'||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(239) := 'nsert into sp_project_comments (id, project_id, author_id, body, body_html, body_no_images, private_';
wwv_flow_imp.g_varchar2_table(240) := 'yn, created, created_by, updated, updated_by)'||wwv_flow.LF||
'  values (6212, 6006, 12, ''The team deferred offline d';
wwv_flow_imp.g_varchar2_table(241) := 'ocument downloads to a later release to protect device storage.'', ''The team deferred offline documen';
wwv_flow_imp.g_varchar2_table(242) := 't downloads to a later release to protect device storage.'', ''The team deferred offline document down';
wwv_flow_imp.g_varchar2_table(243) := 'loads to a later release to protect device storage.'', ''N'', sp_util.fix_demo_dates(sysdate - 18), upp';
wwv_flow_imp.g_varchar2_table(244) := 'er(''hannah.doyle@acme.com''), sp_util.fix_demo_dates(sysdate - 18), upper(''hannah.doyle@acme.com''));'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(245) := 'insert into sp_project_comments (id, project_id, author_id, body, body_html, body_no_images, private';
wwv_flow_imp.g_varchar2_table(246) := '_yn, created, created_by, updated, updated_by)'||wwv_flow.LF||
'  values (6213, 6007, 13, ''Mobile payment initiation ';
wwv_flow_imp.g_varchar2_table(247) := 'uses the existing processor to keep PCI scope unchanged.'', ''Mobile payment initiation uses the exist';
wwv_flow_imp.g_varchar2_table(248) := 'ing processor to keep PCI scope unchanged.'', ''Mobile payment initiation uses the existing processor ';
wwv_flow_imp.g_varchar2_table(249) := 'to keep PCI scope unchanged.'', ''N'', sp_util.fix_demo_dates(sysdate - 15), upper(''isaac.turner@acme.c';
wwv_flow_imp.g_varchar2_table(250) := 'om''), sp_util.fix_demo_dates(sysdate - 15), upper(''isaac.turner@acme.com''));'||wwv_flow.LF||
'insert into sp_project_';
wwv_flow_imp.g_varchar2_table(251) := 'comments (id, project_id, author_id, body, body_html, body_no_images, private_yn, created, created_b';
wwv_flow_imp.g_varchar2_table(252) := 'y, updated, updated_by)'||wwv_flow.LF||
'  values (6214, 6007, 14, ''Finance approved the payment confirmation and rec';
wwv_flow_imp.g_varchar2_table(253) := 'onciliation design.'', ''Finance approved the payment confirmation and reconciliation design.'', ''Finan';
wwv_flow_imp.g_varchar2_table(254) := 'ce approved the payment confirmation and reconciliation design.'', ''N'', sp_util.fix_demo_dates(sysdat';
wwv_flow_imp.g_varchar2_table(255) := 'e - 13), upper(''chloe.whitaker@acme.com''), sp_util.fix_demo_dates(sysdate - 13), upper(''chloe.whitak';
wwv_flow_imp.g_varchar2_table(256) := 'er@acme.com''));'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id, author_id, body, body_html, body_no';
wwv_flow_imp.g_varchar2_table(257) := '_images, private_yn, created, created_by, updated, updated_by)'||wwv_flow.LF||
'  values (6215, 6008, 15, ''The assist';
wwv_flow_imp.g_varchar2_table(258) := 'ant will use approved support articles and hand off low-confidence answers.'', ''The assistant will us';
wwv_flow_imp.g_varchar2_table(259) := 'e approved support articles and hand off low-confidence answers.'', ''The assistant will use approved ';
wwv_flow_imp.g_varchar2_table(260) := 'support articles and hand off low-confidence answers.'', ''N'', sp_util.fix_demo_dates(sysdate - 10), u';
wwv_flow_imp.g_varchar2_table(261) := 'pper(''dominic.reyes@acme.com''), sp_util.fix_demo_dates(sysdate - 10), upper(''dominic.reyes@acme.com''';
wwv_flow_imp.g_varchar2_table(262) := '));'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id, author_id, body, body_html, body_no_images, pri';
wwv_flow_imp.g_varchar2_table(263) := 'vate_yn, created, created_by, updated, updated_by)'||wwv_flow.LF||
'  values (6216, 6008, 16, ''Support leadership app';
wwv_flow_imp.g_varchar2_table(264) := 'roved the escalation wording and customer handoff queue.'', ''Support leadership approved the escalati';
wwv_flow_imp.g_varchar2_table(265) := 'on wording and customer handoff queue.'', ''Support leadership approved the escalation wording and cus';
wwv_flow_imp.g_varchar2_table(266) := 'tomer handoff queue.'', ''N'', sp_util.fix_demo_dates(sysdate - 8), upper(''maya.patel@acme.com''), sp_ut';
wwv_flow_imp.g_varchar2_table(267) := 'il.fix_demo_dates(sysdate - 8), upper(''maya.patel@acme.com''));'||wwv_flow.LF||
'insert into sp_project_comments (id, ';
wwv_flow_imp.g_varchar2_table(268) := 'project_id, author_id, body, body_html, body_no_images, private_yn, created, created_by, updated, up';
wwv_flow_imp.g_varchar2_table(269) := 'dated_by)'||wwv_flow.LF||
'  values (6217, 6009, 17, ''Screen-reader labels and focus order are now part of the shared';
wwv_flow_imp.g_varchar2_table(270) := ' component acceptance criteria.'', ''Screen-reader labels and focus order are now part of the shared c';
wwv_flow_imp.g_varchar2_table(271) := 'omponent acceptance criteria.'', ''Screen-reader labels and focus order are now part of the shared com';
wwv_flow_imp.g_varchar2_table(272) := 'ponent acceptance criteria.'', ''N'', sp_util.fix_demo_dates(sysdate - 5), upper(''ethan.caldwell@acme.c';
wwv_flow_imp.g_varchar2_table(273) := 'om''), sp_util.fix_demo_dates(sysdate - 5), upper(''ethan.caldwell@acme.com''));'||wwv_flow.LF||
'insert into sp_project';
wwv_flow_imp.g_varchar2_table(274) := '_comments (id, project_id, author_id, body, body_html, body_no_images, private_yn, created, created_';
wwv_flow_imp.g_varchar2_table(275) := 'by, updated, updated_by)'||wwv_flow.LF||
'  values (6218, 6009, 18, ''Accessibility review confirmed the planned contr';
wwv_flow_imp.g_varchar2_table(276) := 'ols meet the mobile AA baseline.'', ''Accessibility review confirmed the planned controls meet the mob';
wwv_flow_imp.g_varchar2_table(277) := 'ile AA baseline.'', ''Accessibility review confirmed the planned controls meet the mobile AA baseline.';
wwv_flow_imp.g_varchar2_table(278) := ''', ''N'', sp_util.fix_demo_dates(sysdate - 3), upper(''vanessa.cruz@acme.com''), sp_util.fix_demo_dates(';
wwv_flow_imp.g_varchar2_table(279) := 'sysdate - 3), upper(''vanessa.cruz@acme.com''));'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id, auth';
wwv_flow_imp.g_varchar2_table(280) := 'or_id, body, body_html, body_no_images, private_yn, created, created_by, updated, updated_by)'||wwv_flow.LF||
'  valu';
wwv_flow_imp.g_varchar2_table(281) := 'es (6219, 6010, 19, ''Automated device tests now run for the supported operating-system versions.'', ''';
wwv_flow_imp.g_varchar2_table(282) := 'Automated device tests now run for the supported operating-system versions.'', ''Automated device test';
wwv_flow_imp.g_varchar2_table(283) := 's now run for the supported operating-system versions.'', ''N'', sp_util.fix_demo_dates(sysdate - 2), u';
wwv_flow_imp.g_varchar2_table(284) := 'pper(''lucas.bennett@acme.com''), sp_util.fix_demo_dates(sysdate - 2), upper(''lucas.bennett@acme.com'')';
wwv_flow_imp.g_varchar2_table(285) := ');'||wwv_flow.LF||
'insert into sp_project_comments (id, project_id, author_id, body, body_html, body_no_images, priv';
wwv_flow_imp.g_varchar2_table(286) := 'ate_yn, created, created_by, updated, updated_by)'||wwv_flow.LF||
'  values (6220, 6010, 20, ''The release-quality gat';
wwv_flow_imp.g_varchar2_table(287) := 'e will require performance results before code freeze.'', ''The release-quality gate will require perf';
wwv_flow_imp.g_varchar2_table(288) := 'ormance results before code freeze.'', ''The release-quality gate will require performance results bef';
wwv_flow_imp.g_varchar2_table(289) := 'ore code freeze.'', ''N'', sp_util.fix_demo_dates(sysdate - 1), upper(''aiden.clarke@acme.com''), sp_util';
wwv_flow_imp.g_varchar2_table(290) := '.fix_demo_dates(sysdate - 1), upper(''aiden.clarke@acme.com''));'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Three milestones and two reviews ';
wwv_flow_imp.g_varchar2_table(291) := 'per project. All task dates use the demo-date helper.'||wwv_flow.LF||
'insert all'||wwv_flow.LF||
'  into sp_tasks (id, project_id, ta';
wwv_flow_imp.g_varchar2_table(292) := 'sk, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_ch';
wwv_flow_imp.g_varchar2_table(293) := 'anged_on, description, tags, display_sequence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(294) := ' values (7001, 6001, ''Spec Complete'', 21, null, 2, sp_util.fix_demo_dates(sysdate - 52), sp_util.fix';
wwv_flow_imp.g_varchar2_table(295) := '_demo_dates(sysdate - 48), 14, sp_util.fix_demo_dates(sysdate - 48), ''Mobile navigation specificatio';
wwv_flow_imp.g_varchar2_table(296) := 'n approved.'', ''milestone,spec'', 10, null, sp_util.fix_demo_dates(sysdate - 56), ''SCOTT.TIGER@ACME.CO';
wwv_flow_imp.g_varchar2_table(297) := 'M'', sp_util.fix_demo_dates(sysdate - 48), ''MARCUS.HALE@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, t';
wwv_flow_imp.g_varchar2_table(298) := 'ask, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_c';
wwv_flow_imp.g_varchar2_table(299) := 'hanged_on, description, tags, display_sequence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(300) := '  values (7002, 6001, ''Demonstrable'', 22, null, 2, sp_util.fix_demo_dates(sysdate - 30), sp_util.fix';
wwv_flow_imp.g_varchar2_table(301) := '_demo_dates(sysdate - 25), 14, sp_util.fix_demo_dates(sysdate - 25), ''App shell demonstrated to stak';
wwv_flow_imp.g_varchar2_table(302) := 'eholders.'', ''milestone,demo'', 20, null, sp_util.fix_demo_dates(sysdate - 34), ''SCOTT.TIGER@ACME.COM''';
wwv_flow_imp.g_varchar2_table(303) := ', sp_util.fix_demo_dates(sysdate - 25), ''MARCUS.HALE@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, tas';
wwv_flow_imp.g_varchar2_table(304) := 'k, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_cha';
wwv_flow_imp.g_varchar2_table(305) := 'nged_on, description, tags, display_sequence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(306) := 'values (7003, 6001, ''Code Complete'', 23, null, 1, sp_util.fix_demo_dates(sysdate - 5), sp_util.fix_d';
wwv_flow_imp.g_varchar2_table(307) := 'emo_dates(sysdate + 7), 11, sp_util.fix_demo_dates(sysdate - 2), ''Navigation implementation in progr';
wwv_flow_imp.g_varchar2_table(308) := 'ess.'', ''milestone,code'', 30, null, sp_util.fix_demo_dates(sysdate - 8), ''SCOTT.TIGER@ACME.COM'', sp_u';
wwv_flow_imp.g_varchar2_table(309) := 'til.fix_demo_dates(sysdate - 2), ''SCOTT.TIGER@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task';
wwv_flow_imp.g_varchar2_table(310) := '_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_changed_on';
wwv_flow_imp.g_varchar2_table(311) := ', description, tags, display_sequence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values ';
wwv_flow_imp.g_varchar2_table(312) := '(7004, 6001, ''Functional Spec Review'', 2, null, 8, sp_util.fix_demo_dates(sysdate - 56), sp_util.fix';
wwv_flow_imp.g_varchar2_table(313) := '_demo_dates(sysdate - 50), 8, sp_util.fix_demo_dates(sysdate - 50), ''Functional specification approv';
wwv_flow_imp.g_varchar2_table(314) := 'ed.'', ''review,functional-spec'', 15, ''Medium'', sp_util.fix_demo_dates(sysdate - 58), ''SCOTT.TIGER@ACM';
wwv_flow_imp.g_varchar2_table(315) := 'E.COM'', sp_util.fix_demo_dates(sysdate - 50), ''LILA.MONTGOMERY@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, proje';
wwv_flow_imp.g_varchar2_table(316) := 'ct_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, statu';
wwv_flow_imp.g_varchar2_table(317) := 's_last_changed_on, description, tags, display_sequence, impact, created, created_by, updated, update';
wwv_flow_imp.g_varchar2_table(318) := 'd_by)'||wwv_flow.LF||
'    values (7005, 6001, ''User Experience Review'', 10, null, 8, sp_util.fix_demo_dates(sysdate ';
wwv_flow_imp.g_varchar2_table(319) := '- 4), sp_util.fix_demo_dates(sysdate + 5), 4, sp_util.fix_demo_dates(sysdate - 4), ''User experience ';
wwv_flow_imp.g_varchar2_table(320) := 'review in progress.'', ''review,ux'', 35, ''Medium'', sp_util.fix_demo_dates(sysdate - 7), ''SCOTT.TIGER@A';
wwv_flow_imp.g_varchar2_table(321) := 'CME.COM'', sp_util.fix_demo_dates(sysdate - 4), ''LILA.MONTGOMERY@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, proj';
wwv_flow_imp.g_varchar2_table(322) := 'ect_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, stat';
wwv_flow_imp.g_varchar2_table(323) := 'us_last_changed_on, description, tags, display_sequence, impact, created, created_by, updated, updat';
wwv_flow_imp.g_varchar2_table(324) := 'ed_by)'||wwv_flow.LF||
'    values (7011, 6002, ''Spec Complete'', 21, null, 4, sp_util.fix_demo_dates(sysdate - 52), s';
wwv_flow_imp.g_varchar2_table(325) := 'p_util.fix_demo_dates(sysdate - 48), 14, sp_util.fix_demo_dates(sysdate - 48), ''Mobile identity spec';
wwv_flow_imp.g_varchar2_table(326) := 'ification approved.'', ''milestone,spec'', 10, null, sp_util.fix_demo_dates(sysdate - 56), ''ELENA.VARGA';
wwv_flow_imp.g_varchar2_table(327) := 'S@ACME.COM'', sp_util.fix_demo_dates(sysdate - 48), ''TYLER.BROOKS@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, pro';
wwv_flow_imp.g_varchar2_table(328) := 'ject_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, sta';
wwv_flow_imp.g_varchar2_table(329) := 'tus_last_changed_on, description, tags, display_sequence, impact, created, created_by, updated, upda';
wwv_flow_imp.g_varchar2_table(330) := 'ted_by)'||wwv_flow.LF||
'    values (7012, 6002, ''Demonstrable'', 22, null, 4, sp_util.fix_demo_dates(sysdate - 30), s';
wwv_flow_imp.g_varchar2_table(331) := 'p_util.fix_demo_dates(sysdate - 25), 14, sp_util.fix_demo_dates(sysdate - 25), ''Sign-in and profile ';
wwv_flow_imp.g_varchar2_table(332) := 'flow demonstrated.'', ''milestone,demo'', 20, null, sp_util.fix_demo_dates(sysdate - 34), ''ELENA.VARGAS';
wwv_flow_imp.g_varchar2_table(333) := '@ACME.COM'', sp_util.fix_demo_dates(sysdate - 25), ''TYLER.BROOKS@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, proj';
wwv_flow_imp.g_varchar2_table(334) := 'ect_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, stat';
wwv_flow_imp.g_varchar2_table(335) := 'us_last_changed_on, description, tags, display_sequence, impact, created, created_by, updated, updat';
wwv_flow_imp.g_varchar2_table(336) := 'ed_by)'||wwv_flow.LF||
'    values (7013, 6002, ''Code Complete'', 23, null, 3, sp_util.fix_demo_dates(sysdate - 5), sp';
wwv_flow_imp.g_varchar2_table(337) := '_util.fix_demo_dates(sysdate + 8), 11, sp_util.fix_demo_dates(sysdate - 1), ''MFA and profile work in';
wwv_flow_imp.g_varchar2_table(338) := ' progress.'', ''milestone,code'', 30, null, sp_util.fix_demo_dates(sysdate - 8), ''ELENA.VARGAS@ACME.COM';
wwv_flow_imp.g_varchar2_table(339) := ''', sp_util.fix_demo_dates(sysdate - 1), ''ELENA.VARGAS@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, ta';
wwv_flow_imp.g_varchar2_table(340) := 'sk, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_ch';
wwv_flow_imp.g_varchar2_table(341) := 'anged_on, description, tags, display_sequence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(342) := ' values (7014, 6002, ''Security Review'', 5, null, 6, sp_util.fix_demo_dates(sysdate - 10), sp_util.fi';
wwv_flow_imp.g_varchar2_table(343) := 'x_demo_dates(sysdate + 4), 4, sp_util.fix_demo_dates(sysdate - 2), ''Mobile authentication security r';
wwv_flow_imp.g_varchar2_table(344) := 'eview in progress.'', ''review,security'', 35, ''High'', sp_util.fix_demo_dates(sysdate - 12), ''ELENA.VAR';
wwv_flow_imp.g_varchar2_table(345) := 'GAS@ACME.COM'', sp_util.fix_demo_dates(sysdate - 2), ''JORDAN.AVERY@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, pr';
wwv_flow_imp.g_varchar2_table(346) := 'oject_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, st';
wwv_flow_imp.g_varchar2_table(347) := 'atus_last_changed_on, description, tags, display_sequence, impact, created, created_by, updated, upd';
wwv_flow_imp.g_varchar2_table(348) := 'ated_by)'||wwv_flow.LF||
'    values (7015, 6002, ''Implementation Review'', 11, null, 4, sp_util.fix_demo_dates(sysdat';
wwv_flow_imp.g_varchar2_table(349) := 'e + 5), sp_util.fix_demo_dates(sysdate + 12), 2, sp_util.fix_demo_dates(sysdate - 3), ''Implementatio';
wwv_flow_imp.g_varchar2_table(350) := 'n review scheduled before code freeze.'', ''review,implementation'', 40, ''High'', sp_util.fix_demo_dates';
wwv_flow_imp.g_varchar2_table(351) := '(sysdate - 10), ''ELENA.VARGAS@ACME.COM'', sp_util.fix_demo_dates(sysdate - 3), ''TYLER.BROOKS@ACME.COM';
wwv_flow_imp.g_varchar2_table(352) := ''')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, targ';
wwv_flow_imp.g_varchar2_table(353) := 'et_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, created';
wwv_flow_imp.g_varchar2_table(354) := ', created_by, updated, updated_by)'||wwv_flow.LF||
'    values (7021, 6003, ''Spec Complete'', 21, null, 6, sp_util.fix';
wwv_flow_imp.g_varchar2_table(355) := '_demo_dates(sysdate - 52), sp_util.fix_demo_dates(sysdate - 48), 14, sp_util.fix_demo_dates(sysdate ';
wwv_flow_imp.g_varchar2_table(356) := '- 48), ''Request intake specification approved.'', ''milestone,spec'', 10, null, sp_util.fix_demo_dates(';
wwv_flow_imp.g_varchar2_table(357) := 'sysdate - 56), ''NAOMI.CHEN@ACME.COM'', sp_util.fix_demo_dates(sysdate - 48), ''JORDAN.AVERY@ACME.COM'')';
wwv_flow_imp.g_varchar2_table(358) := ''||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target';
wwv_flow_imp.g_varchar2_table(359) := '_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, created, ';
wwv_flow_imp.g_varchar2_table(360) := 'created_by, updated, updated_by)'||wwv_flow.LF||
'    values (7022, 6003, ''Demonstrable'', 22, null, 6, sp_util.fix_de';
wwv_flow_imp.g_varchar2_table(361) := 'mo_dates(sysdate - 30), sp_util.fix_demo_dates(sysdate - 25), 14, sp_util.fix_demo_dates(sysdate - 2';
wwv_flow_imp.g_varchar2_table(362) := '5), ''Guided request flow demonstrated.'', ''milestone,demo'', 20, null, sp_util.fix_demo_dates(sysdate ';
wwv_flow_imp.g_varchar2_table(363) := '- 34), ''NAOMI.CHEN@ACME.COM'', sp_util.fix_demo_dates(sysdate - 25), ''JORDAN.AVERY@ACME.COM'')'||wwv_flow.LF||
'  into ';
wwv_flow_imp.g_varchar2_table(364) := 'sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complet';
wwv_flow_imp.g_varchar2_table(365) := 'e, status_id, status_last_changed_on, description, tags, display_sequence, impact, created, created_';
wwv_flow_imp.g_varchar2_table(366) := 'by, updated, updated_by)'||wwv_flow.LF||
'    values (7023, 6003, ''Code Complete'', 23, null, 5, sp_util.fix_demo_date';
wwv_flow_imp.g_varchar2_table(367) := 's(sysdate - 5), sp_util.fix_demo_dates(sysdate + 6), 11, sp_util.fix_demo_dates(sysdate - 2), ''Reque';
wwv_flow_imp.g_varchar2_table(368) := 'st workflow work in progress.'', ''milestone,code'', 30, null, sp_util.fix_demo_dates(sysdate - 8), ''NA';
wwv_flow_imp.g_varchar2_table(369) := 'OMI.CHEN@ACME.COM'', sp_util.fix_demo_dates(sysdate - 2), ''NAOMI.CHEN@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id,';
wwv_flow_imp.g_varchar2_table(370) := ' project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id,';
wwv_flow_imp.g_varchar2_table(371) := ' status_last_changed_on, description, tags, display_sequence, impact, created, created_by, updated, ';
wwv_flow_imp.g_varchar2_table(372) := 'updated_by)'||wwv_flow.LF||
'    values (7024, 6003, ''Functional Spec Review'', 2, null, 10, sp_util.fix_demo_dates(sy';
wwv_flow_imp.g_varchar2_table(373) := 'sdate - 56), sp_util.fix_demo_dates(sysdate - 50), 8, sp_util.fix_demo_dates(sysdate - 50), ''Functio';
wwv_flow_imp.g_varchar2_table(374) := 'nal specification approved.'', ''review,functional-spec'', 15, ''High'', sp_util.fix_demo_dates(sysdate -';
wwv_flow_imp.g_varchar2_table(375) := ' 58), ''NAOMI.CHEN@ACME.COM'', sp_util.fix_demo_dates(sysdate - 50), ''SOPHIE.BENNETT@ACME.COM'')'||wwv_flow.LF||
'  into';
wwv_flow_imp.g_varchar2_table(376) := ' sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_comple';
wwv_flow_imp.g_varchar2_table(377) := 'te, status_id, status_last_changed_on, description, tags, display_sequence, impact, created, created';
wwv_flow_imp.g_varchar2_table(378) := '_by, updated, updated_by)'||wwv_flow.LF||
'    values (7025, 6003, ''Functional Testing Review'', 9, null, 10, sp_util.';
wwv_flow_imp.g_varchar2_table(379) := 'fix_demo_dates(sysdate - 3), sp_util.fix_demo_dates(sysdate + 7), 4, sp_util.fix_demo_dates(sysdate ';
wwv_flow_imp.g_varchar2_table(380) := '- 3), ''Functional testing review in progress.'', ''review,functional-testing'', 35, ''High'', sp_util.fix';
wwv_flow_imp.g_varchar2_table(381) := '_demo_dates(sysdate - 6), ''NAOMI.CHEN@ACME.COM'', sp_util.fix_demo_dates(sysdate - 3), ''SOPHIE.BENNET';
wwv_flow_imp.g_varchar2_table(382) := 'T@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_';
wwv_flow_imp.g_varchar2_table(383) := 'date, target_complete, status_id, status_last_changed_on, description, tags, display_sequence, impac';
wwv_flow_imp.g_varchar2_table(384) := 't, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (7031, 6004, ''Spec Complete'', 21, null, 8, s';
wwv_flow_imp.g_varchar2_table(385) := 'p_util.fix_demo_dates(sysdate - 52), sp_util.fix_demo_dates(sysdate - 48), 14, sp_util.fix_demo_date';
wwv_flow_imp.g_varchar2_table(386) := 's(sysdate - 48), ''Capture and upload specification approved.'', ''milestone,spec'', 10, null, sp_util.f';
wwv_flow_imp.g_varchar2_table(387) := 'ix_demo_dates(sysdate - 56), ''CALEB.FOSTER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 48), ''LILA.MO';
wwv_flow_imp.g_varchar2_table(388) := 'NTGOMERY@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id,';
wwv_flow_imp.g_varchar2_table(389) := ' start_date, target_complete, status_id, status_last_changed_on, description, tags, display_sequence';
wwv_flow_imp.g_varchar2_table(390) := ', impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (7032, 6004, ''Demonstrable'', 22, null';
wwv_flow_imp.g_varchar2_table(391) := ', 8, sp_util.fix_demo_dates(sysdate - 30), sp_util.fix_demo_dates(sysdate - 25), 14, sp_util.fix_dem';
wwv_flow_imp.g_varchar2_table(392) := 'o_dates(sysdate - 25), ''Document capture demonstrated.'', ''milestone,demo'', 20, null, sp_util.fix_dem';
wwv_flow_imp.g_varchar2_table(393) := 'o_dates(sysdate - 34), ''CALEB.FOSTER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 25), ''LILA.MONTGOME';
wwv_flow_imp.g_varchar2_table(394) := 'RY@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start';
wwv_flow_imp.g_varchar2_table(395) := '_date, target_complete, status_id, status_last_changed_on, description, tags, display_sequence, impa';
wwv_flow_imp.g_varchar2_table(396) := 'ct, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (7033, 6004, ''Code Complete'', 23, null, 7, ';
wwv_flow_imp.g_varchar2_table(397) := 'sp_util.fix_demo_dates(sysdate - 5), sp_util.fix_demo_dates(sysdate + 5), 11, sp_util.fix_demo_dates';
wwv_flow_imp.g_varchar2_table(398) := '(sysdate - 1), ''Upload recovery work in progress.'', ''milestone,code'', 30, null, sp_util.fix_demo_dat';
wwv_flow_imp.g_varchar2_table(399) := 'es(sysdate - 8), ''CALEB.FOSTER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 1), ''CALEB.FOSTER@ACME.CO';
wwv_flow_imp.g_varchar2_table(400) := 'M'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, tar';
wwv_flow_imp.g_varchar2_table(401) := 'get_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, create';
wwv_flow_imp.g_varchar2_table(402) := 'd, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (7034, 6004, ''Peer Review'', 4, null, 12, sp_util.fix_';
wwv_flow_imp.g_varchar2_table(403) := 'demo_dates(sysdate - 8), sp_util.fix_demo_dates(sysdate + 3), 4, sp_util.fix_demo_dates(sysdate - 2)';
wwv_flow_imp.g_varchar2_table(404) := ', ''Upload handling peer review in progress.'', ''review,peer'', 35, ''Medium'', sp_util.fix_demo_dates(sy';
wwv_flow_imp.g_varchar2_table(405) := 'sdate - 10), ''CALEB.FOSTER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 2), ''HANNAH.DOYLE@ACME.COM'')'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(406) := '  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_';
wwv_flow_imp.g_varchar2_table(407) := 'complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, created, c';
wwv_flow_imp.g_varchar2_table(408) := 'reated_by, updated, updated_by)'||wwv_flow.LF||
'    values (7035, 6004, ''Functional Testing Review'', 9, null, 12, sp';
wwv_flow_imp.g_varchar2_table(409) := '_util.fix_demo_dates(sysdate + 2), sp_util.fix_demo_dates(sysdate + 9), 2, sp_util.fix_demo_dates(sy';
wwv_flow_imp.g_varchar2_table(410) := 'sdate - 4), ''Upload reliability testing scheduled.'', ''review,functional-testing'', 40, ''Medium'', sp_u';
wwv_flow_imp.g_varchar2_table(411) := 'til.fix_demo_dates(sysdate - 7), ''CALEB.FOSTER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 4), ''HANN';
wwv_flow_imp.g_varchar2_table(412) := 'AH.DOYLE@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id,';
wwv_flow_imp.g_varchar2_table(413) := ' start_date, target_complete, status_id, status_last_changed_on, description, tags, display_sequence';
wwv_flow_imp.g_varchar2_table(414) := ', impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (7041, 6005, ''Spec Complete'', 21, nul';
wwv_flow_imp.g_varchar2_table(415) := 'l, 10, sp_util.fix_demo_dates(sysdate - 52), sp_util.fix_demo_dates(sysdate - 48), 14, sp_util.fix_d';
wwv_flow_imp.g_varchar2_table(416) := 'emo_dates(sysdate - 48), ''Notifications specification approved.'', ''milestone,spec'', 10, null, sp_uti';
wwv_flow_imp.g_varchar2_table(417) := 'l.fix_demo_dates(sysdate - 56), ''ANDRE.COLLINS@ACME.COM'', sp_util.fix_demo_dates(sysdate - 48), ''SOP';
wwv_flow_imp.g_varchar2_table(418) := 'HIE.BENNETT@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_';
wwv_flow_imp.g_varchar2_table(419) := 'id, start_date, target_complete, status_id, status_last_changed_on, description, tags, display_seque';
wwv_flow_imp.g_varchar2_table(420) := 'nce, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (7042, 6005, ''Demonstrable'', 22, n';
wwv_flow_imp.g_varchar2_table(421) := 'ull, 10, sp_util.fix_demo_dates(sysdate - 30), sp_util.fix_demo_dates(sysdate - 25), 14, sp_util.fix';
wwv_flow_imp.g_varchar2_table(422) := '_demo_dates(sysdate - 25), ''Notification preferences demonstrated.'', ''milestone,demo'', 20, null, sp_';
wwv_flow_imp.g_varchar2_table(423) := 'util.fix_demo_dates(sysdate - 34), ''ANDRE.COLLINS@ACME.COM'', sp_util.fix_demo_dates(sysdate - 25), ''';
wwv_flow_imp.g_varchar2_table(424) := 'SOPHIE.BENNETT@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, own';
wwv_flow_imp.g_varchar2_table(425) := 'er_id, start_date, target_complete, status_id, status_last_changed_on, description, tags, display_se';
wwv_flow_imp.g_varchar2_table(426) := 'quence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (7043, 6005, ''Code Complete'', 2';
wwv_flow_imp.g_varchar2_table(427) := '3, null, 9, sp_util.fix_demo_dates(sysdate - 5), sp_util.fix_demo_dates(sysdate + 5), 11, sp_util.fi';
wwv_flow_imp.g_varchar2_table(428) := 'x_demo_dates(sysdate - 1), ''Push notification work in progress.'', ''milestone,code'', 30, null, sp_uti';
wwv_flow_imp.g_varchar2_table(429) := 'l.fix_demo_dates(sysdate - 8), ''ANDRE.COLLINS@ACME.COM'', sp_util.fix_demo_dates(sysdate - 1), ''ANDRE';
wwv_flow_imp.g_varchar2_table(430) := '.COLLINS@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id,';
wwv_flow_imp.g_varchar2_table(431) := ' start_date, target_complete, status_id, status_last_changed_on, description, tags, display_sequence';
wwv_flow_imp.g_varchar2_table(432) := ', impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (7044, 6005, ''Product Management Revi';
wwv_flow_imp.g_varchar2_table(433) := 'ew'', 7, null, 14, sp_util.fix_demo_dates(sysdate - 56), sp_util.fix_demo_dates(sysdate - 50), 8, sp_';
wwv_flow_imp.g_varchar2_table(434) := 'util.fix_demo_dates(sysdate - 50), ''Notification scope approved.'', ''review,product-management'', 15, ';
wwv_flow_imp.g_varchar2_table(435) := '''Medium'', sp_util.fix_demo_dates(sysdate - 58), ''ANDRE.COLLINS@ACME.COM'', sp_util.fix_demo_dates(sys';
wwv_flow_imp.g_varchar2_table(436) := 'date - 50), ''CHLOE.WHITAKER@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub';
wwv_flow_imp.g_varchar2_table(437) := '_type_id, owner_id, start_date, target_complete, status_id, status_last_changed_on, description, tag';
wwv_flow_imp.g_varchar2_table(438) := 's, display_sequence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (7045, 6005, ''Impl';
wwv_flow_imp.g_varchar2_table(439) := 'ementation Review'', 11, null, 10, sp_util.fix_demo_dates(sysdate + 2), sp_util.fix_demo_dates(sysdat';
wwv_flow_imp.g_varchar2_table(440) := 'e + 9), 2, sp_util.fix_demo_dates(sysdate - 4), ''Deep link implementation review scheduled.'', ''revie';
wwv_flow_imp.g_varchar2_table(441) := 'w,implementation'', 40, ''Medium'', sp_util.fix_demo_dates(sysdate - 7), ''ANDRE.COLLINS@ACME.COM'', sp_u';
wwv_flow_imp.g_varchar2_table(442) := 'til.fix_demo_dates(sysdate - 4), ''SOPHIE.BENNETT@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, t';
wwv_flow_imp.g_varchar2_table(443) := 'ask_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_changed';
wwv_flow_imp.g_varchar2_table(444) := '_on, description, tags, display_sequence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    valu';
wwv_flow_imp.g_varchar2_table(445) := 'es (7051, 6006, ''Spec Complete'', 21, null, 12, sp_util.fix_demo_dates(sysdate - 52), sp_util.fix_dem';
wwv_flow_imp.g_varchar2_table(446) := 'o_dates(sysdate - 48), 14, sp_util.fix_demo_dates(sysdate - 48), ''Offline synchronization specificat';
wwv_flow_imp.g_varchar2_table(447) := 'ion approved.'', ''milestone,spec'', 10, null, sp_util.fix_demo_dates(sysdate - 56), ''VICTOR.RAMIREZ@AC';
wwv_flow_imp.g_varchar2_table(448) := 'ME.COM'', sp_util.fix_demo_dates(sysdate - 48), ''HANNAH.DOYLE@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project';
wwv_flow_imp.g_varchar2_table(449) := '_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_';
wwv_flow_imp.g_varchar2_table(450) := 'last_changed_on, description, tags, display_sequence, impact, created, created_by, updated, updated_';
wwv_flow_imp.g_varchar2_table(451) := 'by)'||wwv_flow.LF||
'    values (7052, 6006, ''Demonstrable'', 22, null, 12, sp_util.fix_demo_dates(sysdate - 30), sp_u';
wwv_flow_imp.g_varchar2_table(452) := 'til.fix_demo_dates(sysdate - 25), 14, sp_util.fix_demo_dates(sysdate - 25), ''Offline mode demonstrat';
wwv_flow_imp.g_varchar2_table(453) := 'ed.'', ''milestone,demo'', 20, null, sp_util.fix_demo_dates(sysdate - 34), ''VICTOR.RAMIREZ@ACME.COM'', s';
wwv_flow_imp.g_varchar2_table(454) := 'p_util.fix_demo_dates(sysdate - 25), ''HANNAH.DOYLE@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task,';
wwv_flow_imp.g_varchar2_table(455) := ' task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_chang';
wwv_flow_imp.g_varchar2_table(456) := 'ed_on, description, tags, display_sequence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    va';
wwv_flow_imp.g_varchar2_table(457) := 'lues (7053, 6006, ''Code Complete'', 23, null, 11, sp_util.fix_demo_dates(sysdate - 5), sp_util.fix_de';
wwv_flow_imp.g_varchar2_table(458) := 'mo_dates(sysdate + 10), 11, sp_util.fix_demo_dates(sysdate - 1), ''Conflict handling work in progress';
wwv_flow_imp.g_varchar2_table(459) := '.'', ''milestone,code'', 30, null, sp_util.fix_demo_dates(sysdate - 8), ''VICTOR.RAMIREZ@ACME.COM'', sp_u';
wwv_flow_imp.g_varchar2_table(460) := 'til.fix_demo_dates(sysdate - 1), ''VICTOR.RAMIREZ@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, t';
wwv_flow_imp.g_varchar2_table(461) := 'ask_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_changed';
wwv_flow_imp.g_varchar2_table(462) := '_on, description, tags, display_sequence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    valu';
wwv_flow_imp.g_varchar2_table(463) := 'es (7054, 6006, ''Peer Review'', 4, null, 16, sp_util.fix_demo_dates(sysdate - 8), sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(464) := 'tes(sysdate + 4), 4, sp_util.fix_demo_dates(sysdate - 2), ''Synchronization conflict handling peer re';
wwv_flow_imp.g_varchar2_table(465) := 'view in progress.'', ''review,peer'', 35, ''High'', sp_util.fix_demo_dates(sysdate - 10), ''VICTOR.RAMIREZ';
wwv_flow_imp.g_varchar2_table(466) := '@ACME.COM'', sp_util.fix_demo_dates(sysdate - 2), ''MAYA.PATEL@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project';
wwv_flow_imp.g_varchar2_table(467) := '_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_';
wwv_flow_imp.g_varchar2_table(468) := 'last_changed_on, description, tags, display_sequence, impact, created, created_by, updated, updated_';
wwv_flow_imp.g_varchar2_table(469) := 'by)'||wwv_flow.LF||
'    values (7055, 6006, ''Functional Testing Review'', 9, null, 16, sp_util.fix_demo_dates(sysdate';
wwv_flow_imp.g_varchar2_table(470) := ' + 4), sp_util.fix_demo_dates(sysdate + 12), 2, sp_util.fix_demo_dates(sysdate - 4), ''Offline test m';
wwv_flow_imp.g_varchar2_table(471) := 'atrix scheduled.'', ''review,functional-testing'', 40, ''High'', sp_util.fix_demo_dates(sysdate - 7), ''VI';
wwv_flow_imp.g_varchar2_table(472) := 'CTOR.RAMIREZ@ACME.COM'', sp_util.fix_demo_dates(sysdate - 4), ''MAYA.PATEL@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks ';
wwv_flow_imp.g_varchar2_table(473) := '(id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status';
wwv_flow_imp.g_varchar2_table(474) := '_id, status_last_changed_on, description, tags, display_sequence, impact, created, created_by, updat';
wwv_flow_imp.g_varchar2_table(475) := 'ed, updated_by)'||wwv_flow.LF||
'    values (7061, 6007, ''Spec Complete'', 21, null, 14, sp_util.fix_demo_dates(sysdat';
wwv_flow_imp.g_varchar2_table(476) := 'e - 52), sp_util.fix_demo_dates(sysdate - 48), 14, sp_util.fix_demo_dates(sysdate - 48), ''Mobile pay';
wwv_flow_imp.g_varchar2_table(477) := 'ments specification approved.'', ''milestone,spec'', 10, null, sp_util.fix_demo_dates(sysdate - 56), ''I';
wwv_flow_imp.g_varchar2_table(478) := 'SAAC.TURNER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 48), ''CHLOE.WHITAKER@ACME.COM'')'||wwv_flow.LF||
'  into sp_ta';
wwv_flow_imp.g_varchar2_table(479) := 'sks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, st';
wwv_flow_imp.g_varchar2_table(480) := 'atus_id, status_last_changed_on, description, tags, display_sequence, impact, created, created_by, u';
wwv_flow_imp.g_varchar2_table(481) := 'pdated, updated_by)'||wwv_flow.LF||
'    values (7062, 6007, ''Demonstrable'', 22, null, 14, sp_util.fix_demo_dates(sys';
wwv_flow_imp.g_varchar2_table(482) := 'date - 30), sp_util.fix_demo_dates(sysdate - 25), 14, sp_util.fix_demo_dates(sysdate - 25), ''Mobile ';
wwv_flow_imp.g_varchar2_table(483) := 'payment flow demonstrated.'', ''milestone,demo'', 20, null, sp_util.fix_demo_dates(sysdate - 34), ''ISAA';
wwv_flow_imp.g_varchar2_table(484) := 'C.TURNER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 25), ''CHLOE.WHITAKER@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks';
wwv_flow_imp.g_varchar2_table(485) := ' (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, statu';
wwv_flow_imp.g_varchar2_table(486) := 's_id, status_last_changed_on, description, tags, display_sequence, impact, created, created_by, upda';
wwv_flow_imp.g_varchar2_table(487) := 'ted, updated_by)'||wwv_flow.LF||
'    values (7063, 6007, ''Code Complete'', 23, null, 13, sp_util.fix_demo_dates(sysda';
wwv_flow_imp.g_varchar2_table(488) := 'te - 5), sp_util.fix_demo_dates(sysdate + 11), 11, sp_util.fix_demo_dates(sysdate - 1), ''Payment con';
wwv_flow_imp.g_varchar2_table(489) := 'firmation work in progress.'', ''milestone,code'', 30, null, sp_util.fix_demo_dates(sysdate - 8), ''ISAA';
wwv_flow_imp.g_varchar2_table(490) := 'C.TURNER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 1), ''ISAAC.TURNER@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (i';
wwv_flow_imp.g_varchar2_table(491) := 'd, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_i';
wwv_flow_imp.g_varchar2_table(492) := 'd, status_last_changed_on, description, tags, display_sequence, impact, created, created_by, updated';
wwv_flow_imp.g_varchar2_table(493) := ', updated_by)'||wwv_flow.LF||
'    values (7064, 6007, ''Security Review'', 5, null, 16, sp_util.fix_demo_dates(sysdate';
wwv_flow_imp.g_varchar2_table(494) := ' - 10), sp_util.fix_demo_dates(sysdate + 5), 4, sp_util.fix_demo_dates(sysdate - 2), ''Mobile payment';
wwv_flow_imp.g_varchar2_table(495) := ' security review in progress.'', ''review,security'', 35, ''High'', sp_util.fix_demo_dates(sysdate - 12),';
wwv_flow_imp.g_varchar2_table(496) := ' ''ISAAC.TURNER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 2), ''MAYA.PATEL@ACME.COM'')'||wwv_flow.LF||
'  into sp_task';
wwv_flow_imp.g_varchar2_table(497) := 's (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, stat';
wwv_flow_imp.g_varchar2_table(498) := 'us_id, status_last_changed_on, description, tags, display_sequence, impact, created, created_by, upd';
wwv_flow_imp.g_varchar2_table(499) := 'ated, updated_by)'||wwv_flow.LF||
'    values (7065, 6007, ''Functional Testing Review'', 9, null, 16, sp_util.fix_demo';
wwv_flow_imp.g_varchar2_table(500) := '_dates(sysdate + 4), sp_util.fix_demo_dates(sysdate + 12), 2, sp_util.fix_demo_dates(sysdate - 4), ''';
wwv_flow_imp.g_varchar2_table(501) := 'Payment integration testing scheduled.'', ''review,functional-testing'', 40, ''High'', sp_util.fix_demo_d';
wwv_flow_imp.g_varchar2_table(502) := 'ates(sysdate - 7), ''ISAAC.TURNER@ACME.COM'', sp_util.fix_demo_dates(sysdate - 4), ''MAYA.PATEL@ACME.CO';
wwv_flow_imp.g_varchar2_table(503) := 'M'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, tar';
wwv_flow_imp.g_varchar2_table(504) := 'get_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, create';
wwv_flow_imp.g_varchar2_table(505) := 'd, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (7071, 6008, ''Spec Complete'', 21, null, 16, sp_util.f';
wwv_flow_imp.g_varchar2_table(506) := 'ix_demo_dates(sysdate - 52), sp_util.fix_demo_dates(sysdate - 48), 14, sp_util.fix_demo_dates(sysdat';
wwv_flow_imp.g_varchar2_table(507) := 'e - 48), ''Mobile assistant specification approved.'', ''milestone,spec'', 10, null, sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(508) := 'tes(sysdate - 56), ''DOMINIC.REYES@ACME.COM'', sp_util.fix_demo_dates(sysdate - 48), ''MAYA.PATEL@ACME.';
wwv_flow_imp.g_varchar2_table(509) := 'COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, t';
wwv_flow_imp.g_varchar2_table(510) := 'arget_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, crea';
wwv_flow_imp.g_varchar2_table(511) := 'ted, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (7072, 6008, ''Demonstrable'', 22, null, 16, sp_util.';
wwv_flow_imp.g_varchar2_table(512) := 'fix_demo_dates(sysdate - 30), sp_util.fix_demo_dates(sysdate - 25), 14, sp_util.fix_demo_dates(sysda';
wwv_flow_imp.g_varchar2_table(513) := 'te - 25), ''Assistant experience demonstrated.'', ''milestone,demo'', 20, null, sp_util.fix_demo_dates(s';
wwv_flow_imp.g_varchar2_table(514) := 'ysdate - 34), ''DOMINIC.REYES@ACME.COM'', sp_util.fix_demo_dates(sysdate - 25), ''MAYA.PATEL@ACME.COM'')';
wwv_flow_imp.g_varchar2_table(515) := ''||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target';
wwv_flow_imp.g_varchar2_table(516) := '_complete, status_id, status_last_changed_on, description, tags, display_sequence, impact, created, ';
wwv_flow_imp.g_varchar2_table(517) := 'created_by, updated, updated_by)'||wwv_flow.LF||
'    values (7073, 6008, ''Code Complete'', 23, null, 15, sp_util.fix_';
wwv_flow_imp.g_varchar2_table(518) := 'demo_dates(sysdate - 5), sp_util.fix_demo_dates(sysdate + 8), 11, sp_util.fix_demo_dates(sysdate - 1';
wwv_flow_imp.g_varchar2_table(519) := '), ''Knowledge grounding work in progress.'', ''milestone,code'', 30, null, sp_util.fix_demo_dates(sysda';
wwv_flow_imp.g_varchar2_table(520) := 'te - 8), ''DOMINIC.REYES@ACME.COM'', sp_util.fix_demo_dates(sysdate - 1), ''DOMINIC.REYES@ACME.COM'')'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(521) := 'into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_co';
wwv_flow_imp.g_varchar2_table(522) := 'mplete, status_id, status_last_changed_on, description, tags, display_sequence, impact, created, cre';
wwv_flow_imp.g_varchar2_table(523) := 'ated_by, updated, updated_by)'||wwv_flow.LF||
'    values (7074, 6008, ''Product Management Review'', 7, null, 18, sp_u';
wwv_flow_imp.g_varchar2_table(524) := 'til.fix_demo_dates(sysdate - 56), sp_util.fix_demo_dates(sysdate - 50), 8, sp_util.fix_demo_dates(sy';
wwv_flow_imp.g_varchar2_table(525) := 'sdate - 50), ''Assistant scope and handoff approved.'', ''review,product-management'', 15, ''High'', sp_ut';
wwv_flow_imp.g_varchar2_table(526) := 'il.fix_demo_dates(sysdate - 58), ''DOMINIC.REYES@ACME.COM'', sp_util.fix_demo_dates(sysdate - 50), ''VA';
wwv_flow_imp.g_varchar2_table(527) := 'NESSA.CRUZ@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task_sub_type_id, owner_i';
wwv_flow_imp.g_varchar2_table(528) := 'd, start_date, target_complete, status_id, status_last_changed_on, description, tags, display_sequen';
wwv_flow_imp.g_varchar2_table(529) := 'ce, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (7075, 6008, ''Implementation Review';
wwv_flow_imp.g_varchar2_table(530) := ''', 11, null, 16, sp_util.fix_demo_dates(sysdate + 2), sp_util.fix_demo_dates(sysdate + 9), 2, sp_uti';
wwv_flow_imp.g_varchar2_table(531) := 'l.fix_demo_dates(sysdate - 4), ''Support-handoff implementation review scheduled.'', ''review,implement';
wwv_flow_imp.g_varchar2_table(532) := 'ation'', 40, ''High'', sp_util.fix_demo_dates(sysdate - 7), ''DOMINIC.REYES@ACME.COM'', sp_util.fix_demo_';
wwv_flow_imp.g_varchar2_table(533) := 'dates(sysdate - 4), ''MAYA.PATEL@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, task';
wwv_flow_imp.g_varchar2_table(534) := '_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_changed_on, description,';
wwv_flow_imp.g_varchar2_table(535) := ' tags, display_sequence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (7081, 6009, ''';
wwv_flow_imp.g_varchar2_table(536) := 'Spec Complete'', 21, null, 18, sp_util.fix_demo_dates(sysdate - 52), sp_util.fix_demo_dates(sysdate -';
wwv_flow_imp.g_varchar2_table(537) := ' 48), 14, sp_util.fix_demo_dates(sysdate - 48), ''Accessibility specification approved.'', ''milestone,';
wwv_flow_imp.g_varchar2_table(538) := 'spec'', 10, null, sp_util.fix_demo_dates(sysdate - 56), ''ETHAN.CALDWELL@ACME.COM'', sp_util.fix_demo_d';
wwv_flow_imp.g_varchar2_table(539) := 'ates(sysdate - 48), ''VANESSA.CRUZ@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, ta';
wwv_flow_imp.g_varchar2_table(540) := 'sk_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_changed_on, descriptio';
wwv_flow_imp.g_varchar2_table(541) := 'n, tags, display_sequence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (7082, 6009,';
wwv_flow_imp.g_varchar2_table(542) := ' ''Demonstrable'', 22, null, 18, sp_util.fix_demo_dates(sysdate - 30), sp_util.fix_demo_dates(sysdate ';
wwv_flow_imp.g_varchar2_table(543) := '- 25), 14, sp_util.fix_demo_dates(sysdate - 25), ''Accessible components demonstrated.'', ''milestone,d';
wwv_flow_imp.g_varchar2_table(544) := 'emo'', 20, null, sp_util.fix_demo_dates(sysdate - 34), ''ETHAN.CALDWELL@ACME.COM'', sp_util.fix_demo_da';
wwv_flow_imp.g_varchar2_table(545) := 'tes(sysdate - 25), ''VANESSA.CRUZ@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type_id, tas';
wwv_flow_imp.g_varchar2_table(546) := 'k_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_changed_on, description';
wwv_flow_imp.g_varchar2_table(547) := ', tags, display_sequence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (7083, 6009, ';
wwv_flow_imp.g_varchar2_table(548) := '''Code Complete'', 23, null, 17, sp_util.fix_demo_dates(sysdate - 5), sp_util.fix_demo_dates(sysdate +';
wwv_flow_imp.g_varchar2_table(549) := ' 6), 11, sp_util.fix_demo_dates(sysdate - 1), ''Accessibility implementation work in progress.'', ''mil';
wwv_flow_imp.g_varchar2_table(550) := 'estone,code'', 30, null, sp_util.fix_demo_dates(sysdate - 8), ''ETHAN.CALDWELL@ACME.COM'', sp_util.fix_';
wwv_flow_imp.g_varchar2_table(551) := 'demo_dates(sysdate - 1), ''ETHAN.CALDWELL@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, task, task_type';
wwv_flow_imp.g_varchar2_table(552) := '_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_changed_on, des';
wwv_flow_imp.g_varchar2_table(553) := 'cription, tags, display_sequence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values (7084';
wwv_flow_imp.g_varchar2_table(554) := ', 6009, ''Accessibility Review'', 6, null, 20, sp_util.fix_demo_dates(sysdate - 8), sp_util.fix_demo_d';
wwv_flow_imp.g_varchar2_table(555) := 'ates(sysdate + 3), 4, sp_util.fix_demo_dates(sysdate - 2), ''Mobile accessibility review in progress.';
wwv_flow_imp.g_varchar2_table(556) := ''', ''review,accessibility'', 35, ''High'', sp_util.fix_demo_dates(sysdate - 10), ''ETHAN.CALDWELL@ACME.CO';
wwv_flow_imp.g_varchar2_table(557) := 'M'', sp_util.fix_demo_dates(sysdate - 2), ''AIDEN.CLARKE@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_id, t';
wwv_flow_imp.g_varchar2_table(558) := 'ask, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_last_c';
wwv_flow_imp.g_varchar2_table(559) := 'hanged_on, description, tags, display_sequence, impact, created, created_by, updated, updated_by)'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(560) := '  values (7085, 6009, ''User Experience Review'', 10, null, 18, sp_util.fix_demo_dates(sysdate + 2), s';
wwv_flow_imp.g_varchar2_table(561) := 'p_util.fix_demo_dates(sysdate + 9), 2, sp_util.fix_demo_dates(sysdate - 4), ''Assistive interaction r';
wwv_flow_imp.g_varchar2_table(562) := 'eview scheduled.'', ''review,ux'', 40, ''High'', sp_util.fix_demo_dates(sysdate - 7), ''ETHAN.CALDWELL@ACM';
wwv_flow_imp.g_varchar2_table(563) := 'E.COM'', sp_util.fix_demo_dates(sysdate - 4), ''VANESSA.CRUZ@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, project_i';
wwv_flow_imp.g_varchar2_table(564) := 'd, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, status_la';
wwv_flow_imp.g_varchar2_table(565) := 'st_changed_on, description, tags, display_sequence, impact, created, created_by, updated, updated_by';
wwv_flow_imp.g_varchar2_table(566) := ')'||wwv_flow.LF||
'    values (7091, 6010, ''Spec Complete'', 21, null, 20, sp_util.fix_demo_dates(sysdate - 52), sp_ut';
wwv_flow_imp.g_varchar2_table(567) := 'il.fix_demo_dates(sysdate - 48), 14, sp_util.fix_demo_dates(sysdate - 48), ''Quality automation speci';
wwv_flow_imp.g_varchar2_table(568) := 'fication approved.'', ''milestone,spec'', 10, null, sp_util.fix_demo_dates(sysdate - 56), ''LUCAS.BENNET';
wwv_flow_imp.g_varchar2_table(569) := 'T@ACME.COM'', sp_util.fix_demo_dates(sysdate - 48), ''AIDEN.CLARKE@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, pro';
wwv_flow_imp.g_varchar2_table(570) := 'ject_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, sta';
wwv_flow_imp.g_varchar2_table(571) := 'tus_last_changed_on, description, tags, display_sequence, impact, created, created_by, updated, upda';
wwv_flow_imp.g_varchar2_table(572) := 'ted_by)'||wwv_flow.LF||
'    values (7092, 6010, ''Demonstrable'', 22, null, 20, sp_util.fix_demo_dates(sysdate - 30), ';
wwv_flow_imp.g_varchar2_table(573) := 'sp_util.fix_demo_dates(sysdate - 25), 14, sp_util.fix_demo_dates(sysdate - 25), ''Device test dashboa';
wwv_flow_imp.g_varchar2_table(574) := 'rd demonstrated.'', ''milestone,demo'', 20, null, sp_util.fix_demo_dates(sysdate - 34), ''LUCAS.BENNETT@';
wwv_flow_imp.g_varchar2_table(575) := 'ACME.COM'', sp_util.fix_demo_dates(sysdate - 25), ''AIDEN.CLARKE@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, proje';
wwv_flow_imp.g_varchar2_table(576) := 'ct_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, statu';
wwv_flow_imp.g_varchar2_table(577) := 's_last_changed_on, description, tags, display_sequence, impact, created, created_by, updated, update';
wwv_flow_imp.g_varchar2_table(578) := 'd_by)'||wwv_flow.LF||
'    values (7093, 6010, ''Code Complete'', 23, null, 19, sp_util.fix_demo_dates(sysdate - 5), sp';
wwv_flow_imp.g_varchar2_table(579) := '_util.fix_demo_dates(sysdate + 11), 11, sp_util.fix_demo_dates(sysdate - 1), ''Automation and telemet';
wwv_flow_imp.g_varchar2_table(580) := 'ry work in progress.'', ''milestone,code'', 30, null, sp_util.fix_demo_dates(sysdate - 8), ''LUCAS.BENNE';
wwv_flow_imp.g_varchar2_table(581) := 'TT@ACME.COM'', sp_util.fix_demo_dates(sysdate - 1), ''LUCAS.BENNETT@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, pr';
wwv_flow_imp.g_varchar2_table(582) := 'oject_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, st';
wwv_flow_imp.g_varchar2_table(583) := 'atus_last_changed_on, description, tags, display_sequence, impact, created, created_by, updated, upd';
wwv_flow_imp.g_varchar2_table(584) := 'ated_by)'||wwv_flow.LF||
'    values (7094, 6010, ''Peer Review'', 4, null, 21, sp_util.fix_demo_dates(sysdate - 8), sp';
wwv_flow_imp.g_varchar2_table(585) := '_util.fix_demo_dates(sysdate + 3), 4, sp_util.fix_demo_dates(sysdate - 2), ''Test automation peer rev';
wwv_flow_imp.g_varchar2_table(586) := 'iew in progress.'', ''review,peer'', 35, ''Medium'', sp_util.fix_demo_dates(sysdate - 10), ''LUCAS.BENNETT';
wwv_flow_imp.g_varchar2_table(587) := '@ACME.COM'', sp_util.fix_demo_dates(sysdate - 2), ''ZOE.MATTHEWS@ACME.COM'')'||wwv_flow.LF||
'  into sp_tasks (id, proje';
wwv_flow_imp.g_varchar2_table(588) := 'ct_id, task, task_type_id, task_sub_type_id, owner_id, start_date, target_complete, status_id, statu';
wwv_flow_imp.g_varchar2_table(589) := 's_last_changed_on, description, tags, display_sequence, impact, created, created_by, updated, update';
wwv_flow_imp.g_varchar2_table(590) := 'd_by)'||wwv_flow.LF||
'    values (7095, 6010, ''Functional Testing Review'', 9, null, 21, sp_util.fix_demo_dates(sysda';
wwv_flow_imp.g_varchar2_table(591) := 'te + 4), sp_util.fix_demo_dates(sysdate + 12), 2, sp_util.fix_demo_dates(sysdate - 4), ''Device cover';
wwv_flow_imp.g_varchar2_table(592) := 'age review scheduled before code freeze.'', ''review,functional-testing'', 40, ''High'', sp_util.fix_demo';
wwv_flow_imp.g_varchar2_table(593) := '_dates(sysdate - 7), ''LUCAS.BENNETT@ACME.COM'', sp_util.fix_demo_dates(sysdate - 4), ''ZOE.MATTHEWS@AC';
wwv_flow_imp.g_varchar2_table(594) := 'ME.COM'')'||wwv_flow.LF||
'select 1 from dual;'||wwv_flow.LF||
''||wwv_flow.LF||
'sp_globals.g_audit_this := TRUE;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(595) := '   sp_globals.g_audit_this := TRUE;'||wwv_flow.LF||
'end;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(453304385028480163)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sample data - mobile comp 1.0'
,p_sequence=>9230
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
