prompt --application/deployment/install/install_seed_ai_prompts
begin
--   Manifest
--     INSTALL: INSTALL-seed ai_prompts
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
'    sp_util.add_ai_prompt (  '||wwv_flow.LF||
'        p_static_id     => ''FULL_PROJECT_SUMMARY'',   '||wwv_flow.LF||
'        p_';
wwv_flow_imp.g_varchar2_table(2) := 'description   => ''Used for generating a full project summary.'', '||wwv_flow.LF||
'        p_prompt        => ''You are';
wwv_flow_imp.g_varchar2_table(3) := ' given details for a software development project, in json format, including the most recent comment';
wwv_flow_imp.g_varchar2_table(4) := 's from the last 90 days. Please return the following:'||wwv_flow.LF||
''||wwv_flow.LF||
'Concise Summary: Extract key points to create';
wwv_flow_imp.g_varchar2_table(5) := ' a brief but accurate summary of the overall progress, tasks completed, any issues or blockers, and ';
wwv_flow_imp.g_varchar2_table(6) := 'any milestones achieved or reviews completed.  Also include any concerns, such as having no Contribu';
wwv_flow_imp.g_varchar2_table(7) := 'tors or Milestones defined or dates being past due.  This can be 1 or 2 paragraphs depending on the ';
wwv_flow_imp.g_varchar2_table(8) := 'size of the input.'||wwv_flow.LF||
''||wwv_flow.LF||
'Risk Assessment: Analyze for signs of potential project risks (e.g., delays, una';
wwv_flow_imp.g_varchar2_table(9) := 'ddressed issues, lack of progress, etc.). Based on this analysis, assign a risk level to the project';
wwv_flow_imp.g_varchar2_table(10) := ' as follows:'||wwv_flow.LF||
''||wwv_flow.LF||
'None: No risk, assign to all projects with percent complete of 100% (and only those).'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(11) := ''||wwv_flow.LF||
'Low: No immediate concerns; project is progressing smoothly with no major issues.'||wwv_flow.LF||
''||wwv_flow.LF||
'Moderate: Some c';
wwv_flow_imp.g_varchar2_table(12) := 'oncerns or blockers are present but can be addressed; risk to the timeline or scope is possible.'||wwv_flow.LF||
''||wwv_flow.LF||
'Hi';
wwv_flow_imp.g_varchar2_table(13) := 'gh: Major issues or blockers that significantly affect the progress; there is a real danger to the t';
wwv_flow_imp.g_varchar2_table(14) := 'imeline, scope, or quality.'||wwv_flow.LF||
''||wwv_flow.LF||
'Additionally, list any project highlight achievements, percent complete';
wwv_flow_imp.g_varchar2_table(15) := ', tags or status changes, completed reviews, approvals received, or anything significant about the p';
wwv_flow_imp.g_varchar2_table(16) := 'roject in the highlights section of the JSON.  Always include them in a JSON array.  If there are no';
wwv_flow_imp.g_varchar2_table(17) := ' highlights, simply add a single element called "No Highlights".'||wwv_flow.LF||
''||wwv_flow.LF||
'Return using a JSON document with ';
wwv_flow_imp.g_varchar2_table(18) := 'the following structure:'||wwv_flow.LF||
''||wwv_flow.LF||
'{'||wwv_flow.LF||
'  "summary": "Concise summary of the project progress and key highlights';
wwv_flow_imp.g_varchar2_table(19) := '.",'||wwv_flow.LF||
'  "highlights" : "List project highlights",'||wwv_flow.LF||
'  "risk": "None | Low | Moderate | High"'||wwv_flow.LF||
'}'||wwv_flow.LF||
''||wwv_flow.LF||
'Make sur';
wwv_flow_imp.g_varchar2_table(20) := 'e to accurately assess the project risk and provide a clear, easy-to-understand summary.  Do not inc';
wwv_flow_imp.g_varchar2_table(21) := 'lude any prefix or suffix characters - only a JSON document.'' );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    sp_util.add_ai_p';
wwv_flow_imp.g_varchar2_table(22) := 'rompt (  '||wwv_flow.LF||
'        p_static_id     => ''UPDATE_PROJECT_SUMMARY'',   '||wwv_flow.LF||
'        p_description   => ''Used f';
wwv_flow_imp.g_varchar2_table(23) := 'or generating an updated project summary.'', '||wwv_flow.LF||
'        p_prompt        => ''You are given details for a';
wwv_flow_imp.g_varchar2_table(24) := ' software development project, in json format, and the last summary generated along with any data th';
wwv_flow_imp.g_varchar2_table(25) := 'at has changed since the last summary. Please return the following:'||wwv_flow.LF||
''||wwv_flow.LF||
'Concise Summary: Extract key po';
wwv_flow_imp.g_varchar2_table(26) := 'ints to create a brief but accurate summary of the overall progress since the last summary, tasks co';
wwv_flow_imp.g_varchar2_table(27) := 'mpleted, any issues or blockers, and any milestones achieved or reviews completed.  Also include any';
wwv_flow_imp.g_varchar2_table(28) := ' concerns, such as having no Contributors or Milestones defined or dates being past due.  This can b';
wwv_flow_imp.g_varchar2_table(29) := 'e 1 or 2 paragraphs depending on the size of the input.'||wwv_flow.LF||
''||wwv_flow.LF||
'Risk Assessment: Analyze for signs of poten';
wwv_flow_imp.g_varchar2_table(30) := 'tial project risks (e.g., delays, unaddressed issues, lack of progress, etc.). Based on this analysi';
wwv_flow_imp.g_varchar2_table(31) := 's, assign a risk level to the project as follows:'||wwv_flow.LF||
''||wwv_flow.LF||
'None: No risk, assign to all projects with percen';
wwv_flow_imp.g_varchar2_table(32) := 't complete of 100% (and only those).'||wwv_flow.LF||
''||wwv_flow.LF||
'Low: No immediate concerns; project is progressing smoothly wi';
wwv_flow_imp.g_varchar2_table(33) := 'th no major issues.'||wwv_flow.LF||
''||wwv_flow.LF||
'Moderate: Some concerns or blockers are present but can be addressed; risk to t';
wwv_flow_imp.g_varchar2_table(34) := 'he timeline or scope is possible.'||wwv_flow.LF||
''||wwv_flow.LF||
'High: Major issues or blockers that significantly affect the prog';
wwv_flow_imp.g_varchar2_table(35) := 'ress; there is a real danger to the timeline, scope, or quality.'||wwv_flow.LF||
''||wwv_flow.LF||
'Additionally, list any project hig';
wwv_flow_imp.g_varchar2_table(36) := 'hlight achievements, percent complete, tags or status changes, completed reviews, approvals received';
wwv_flow_imp.g_varchar2_table(37) := ', or anything significant about the project in the highlights section of the JSON.  Always include t';
wwv_flow_imp.g_varchar2_table(38) := 'hem in a JSON array.  If there are no highlights, simply add a single element called "No Highlights"';
wwv_flow_imp.g_varchar2_table(39) := '.'||wwv_flow.LF||
''||wwv_flow.LF||
'Return using a JSON document with the following structure:'||wwv_flow.LF||
''||wwv_flow.LF||
'{'||wwv_flow.LF||
'  "summary": "Concise summary of th';
wwv_flow_imp.g_varchar2_table(40) := 'e project progress and key highlights.",'||wwv_flow.LF||
'  "highlights" : "List project highlights",'||wwv_flow.LF||
'  "risk": "None';
wwv_flow_imp.g_varchar2_table(41) := ' | Low | Moderate | High"'||wwv_flow.LF||
'}'||wwv_flow.LF||
''||wwv_flow.LF||
'Make sure to accurately assess the project risk and provide a clear, ea';
wwv_flow_imp.g_varchar2_table(42) := 'sy-to-understand summary.  Do not include any prefix or suffix characters - only a JSON document.'' )';
wwv_flow_imp.g_varchar2_table(43) := ';'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    sp_util.add_ai_prompt (  '||wwv_flow.LF||
'        p_static_id     => ''RELEASE_SUMMARY'',   '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(44) := '    p_description   => ''Used for generating a release summary.'', '||wwv_flow.LF||
'        p_prompt        => ''You ar';
wwv_flow_imp.g_varchar2_table(45) := 'e given details for a software development product release, in markdown format.  This includes basic';
wwv_flow_imp.g_varchar2_table(46) := ' release details along with all the features included in the release, grouped by focus area. Please ';
wwv_flow_imp.g_varchar2_table(47) := 'return a JSON document with the following structure:'||wwv_flow.LF||
''||wwv_flow.LF||
'{'||wwv_flow.LF||
'  "summary": "Concise summary of the release';
wwv_flow_imp.g_varchar2_table(48) := '",'||wwv_flow.LF||
'  "highlights": "List release highlights"'||wwv_flow.LF||
'}'||wwv_flow.LF||
''||wwv_flow.LF||
'Make sure to provide a clear, easy-to-understand sum';
wwv_flow_imp.g_varchar2_table(49) := 'mary.  Do not include any prefix or suffix characters - only a JSON document.'||wwv_flow.LF||
''||wwv_flow.LF||
'Summary: Extract key ';
wwv_flow_imp.g_varchar2_table(50) := 'points to create a brief but accurate summary of the release.  This can be 1 or 2 paragraphs dependi';
wwv_flow_imp.g_varchar2_table(51) := 'ng on the size of the input.'||wwv_flow.LF||
''||wwv_flow.LF||
'Highlights: List any release highlights, such as important features in';
wwv_flow_imp.g_varchar2_table(52) := ' the highlights section of the JSON.  Always include them in a JSON array.  If there are no highligh';
wwv_flow_imp.g_varchar2_table(53) := 'ts, simply add a single element called "No Highlights".'' );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(35719336673158896392)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed ai_prompts'
,p_sequence=>9140
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
