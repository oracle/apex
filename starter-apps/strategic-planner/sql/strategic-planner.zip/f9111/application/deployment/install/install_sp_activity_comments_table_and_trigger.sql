prompt --application/deployment/install/install_sp_activity_comments_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_activity_comments table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_activity_comments ('||wwv_flow.LF||
'    id                             number default on null to_num';
wwv_flow_imp.g_varchar2_table(2) := 'ber(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint s';
wwv_flow_imp.g_varchar2_table(3) := 'p_activity_comments_pk primary key,'||wwv_flow.LF||
'    activity_id                    number'||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(4) := '             constraint sp_activity_comments_act_fk'||wwv_flow.LF||
'                                   references sp';
wwv_flow_imp.g_varchar2_table(5) := '_activities on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    comment_nbr                    number,'||wwv_flow.LF||
'    body           ';
wwv_flow_imp.g_varchar2_table(6) := '                clob,'||wwv_flow.LF||
'    body_html                      clob,'||wwv_flow.LF||
'    body_no_images                 cl';
wwv_flow_imp.g_varchar2_table(7) := 'ob,'||wwv_flow.LF||
'    image_ref_id                   number, '||wwv_flow.LF||
'    author_id                      number,'||wwv_flow.LF||
'    PRIVA';
wwv_flow_imp.g_varchar2_table(8) := 'TE_YN                     varchar2(1 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,';
wwv_flow_imp.g_varchar2_table(9) := ''||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                        ';
wwv_flow_imp.g_varchar2_table(10) := 'date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_ac';
wwv_flow_imp.g_varchar2_table(11) := 'tivity_comments_i1 on sp_activity_comments (activity_id);'||wwv_flow.LF||
'create index sp_activity_comments_i2 on sp';
wwv_flow_imp.g_varchar2_table(12) := '_activity_comments (author_id);'||wwv_flow.LF||
'create index sp_activity_comments_i3 on sp_activity_comments (image_';
wwv_flow_imp.g_varchar2_table(13) := 'ref_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_activity_comments_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_a';
wwv_flow_imp.g_varchar2_table(14) := 'ctivity_comments'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.cr';
wwv_flow_imp.g_varchar2_table(15) := 'eated,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',';
wwv_flow_imp.g_varchar2_table(16) := '''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by :=';
wwv_flow_imp.g_varchar2_table(17) := ' nvl(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating the';
wwv_flow_imp.g_varchar2_table(18) := 'n'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSION''';
wwv_flow_imp.g_varchar2_table(19) := ',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.private_yn is null then '||wwv_flow.LF||
'       :new.private_yn :';
wwv_flow_imp.g_varchar2_table(20) := '= ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        for c1 in (select nvl(max(comment_nbr),0) cn';
wwv_flow_imp.g_varchar2_table(21) := 'br from sp_activity_comments where activity_id = :new.activity_id)'||wwv_flow.LF||
'        loop :new.comment_nbr := ';
wwv_flow_imp.g_varchar2_table(22) := 'c1.cnbr+1; end loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if sp_globals.g_audit_t';
wwv_flow_imp.g_varchar2_table(23) := 'his then'||wwv_flow.LF||
'        update sp_activities set updated = sysdate, updated_by = :new.updated_by where id =';
wwv_flow_imp.g_varchar2_table(24) := ' :new.activity_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_activity_comments_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2520363415285936202)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_activity_comments table and trigger'
,p_sequence=>3415
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
