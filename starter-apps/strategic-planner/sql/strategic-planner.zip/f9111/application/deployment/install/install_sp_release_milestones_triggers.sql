prompt --application/deployment/install/install_sp_release_milestones_triggers
begin
--   Manifest
--     INSTALL: INSTALL-sp_release_milestones triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_release_milestones_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_release_mi';
wwv_flow_imp.g_varchar2_table(2) := 'lestones'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_tags        varchar2(4000) := null;'||wwv_flow.LF||
'    l_changed_by  varcha';
wwv_flow_imp.g_varchar2_table(3) := 'r2(255)  := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(4) := '        :new.created_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user';
wwv_flow_imp.g_varchar2_table(5) := '));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.update';
wwv_flow_imp.g_varchar2_table(6) := 'd_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        if :new.original_mi';
wwv_flow_imp.g_varchar2_table(7) := 'lestone_date is null then'||wwv_flow.LF||
'            :new.original_milestone_date := :new.milestone_date;'||wwv_flow.LF||
'        e';
wwv_flow_imp.g_varchar2_table(8) := 'nd if;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coales';
wwv_flow_imp.g_varchar2_table(9) := 'ce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.upper_milestone_name :=';
wwv_flow_imp.g_varchar2_table(10) := ' upper(:new.milestone_name);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- adjust tag data'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.tags is not null then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(11) := '        l_tags := trim(upper(:new.tags));'||wwv_flow.LF||
'        -- remove multiple spaces'||wwv_flow.LF||
'        if instr(l_tags,';
wwv_flow_imp.g_varchar2_table(12) := '''  '') > 0 then'||wwv_flow.LF||
'            for j in 1..10 loop '||wwv_flow.LF||
'                l_tags := replace(l_tags,''  '','' ''); ';
wwv_flow_imp.g_varchar2_table(13) := ''||wwv_flow.LF||
'                if instr(l_tags,''  '') = 0 then'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(14) := '         end loop; '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        for i in 1..length(l_tags) loop'||wwv_flow.LF||
'            if i > 2 and';
wwv_flow_imp.g_varchar2_table(15) := ' substr(l_tags,i,1) = '' '' and substr(l_tags,i-1,1) != '','' then'||wwv_flow.LF||
'               l_tags := substr(l_tag';
wwv_flow_imp.g_varchar2_table(16) := 's,1,i-1)||''-''||substr(l_tags,i+1);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        :new.tags := l_tags';
wwv_flow_imp.g_varchar2_table(17) := ';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if sp_globals.g_audit_this then'||wwv_flow.LF||
'        up';
wwv_flow_imp.g_varchar2_table(18) := 'date sp_release_trains set updated = sysdate, updated_by = :new.updated_by where id = :new.release_i';
wwv_flow_imp.g_varchar2_table(19) := 'd;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- change history tracking'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        insert int';
wwv_flow_imp.g_varchar2_table(20) := 'o sp_release_history'||wwv_flow.LF||
'            (release_id, attribute_column, change_type, new_value, changed_on, ';
wwv_flow_imp.g_varchar2_table(21) := 'changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.release_id, ''RELEASE_MILESTONE'', ''CREATE'', :new.milesto';
wwv_flow_imp.g_varchar2_table(22) := 'ne_name, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        l_changed_by := lower(:ne';
wwv_flow_imp.g_varchar2_table(23) := 'w.updated_by);'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.milestone_name,:new.mileston';
wwv_flow_imp.g_varchar2_table(24) := 'e_name) then'||wwv_flow.LF||
'           insert into sp_release_history'||wwv_flow.LF||
'               (release_id, attribute_column,';
wwv_flow_imp.g_varchar2_table(25) := ' change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'           values'||wwv_flow.LF||
'               (:new.r';
wwv_flow_imp.g_varchar2_table(26) := 'elease_id, ''RELEASE_MILESTONE'', ''UPDATE'', :old.milestone_name, :new.milestone_name, sysdate, l_chang';
wwv_flow_imp.g_varchar2_table(27) := 'ed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.milestone_start_dat';
wwv_flow_imp.g_varchar2_table(28) := 'e,:new.milestone_start_date) then'||wwv_flow.LF||
'           insert into sp_release_history'||wwv_flow.LF||
'               (release_';
wwv_flow_imp.g_varchar2_table(29) := 'id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'           values'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(30) := '              (:new.release_id, ''RELEASE_MILESTONE_''||substr(:new.milestone_name,1,200)||''_START'', ''';
wwv_flow_imp.g_varchar2_table(31) := 'UPDATE'', to_char(:old.milestone_start_date,''DD-MON-YYYY''), to_char(:new.milestone_start_date,''DD-MON';
wwv_flow_imp.g_varchar2_table(32) := '-YYYY''), sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        if not sp_value_compare.is_equal';
wwv_flow_imp.g_varchar2_table(33) := '(:old.milestone_date,:new.milestone_date) then'||wwv_flow.LF||
'           insert into sp_release_history'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(34) := '    (release_id, attribute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(35) := '     values'||wwv_flow.LF||
'               (:new.release_id, ''RELEASE_MILESTONE_''||substr(:new.milestone_name,1,235)';
wwv_flow_imp.g_varchar2_table(36) := ', ''UPDATE'', to_char(:old.milestone_date,''DD-MON-YYYY''), to_char(:new.milestone_date,''DD-MON-YYYY''), ';
wwv_flow_imp.g_varchar2_table(37) := 'sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old';
wwv_flow_imp.g_varchar2_table(38) := '.MILESTONE_COMPLETED_YN,:new.MILESTONE_COMPLETED_YN) then'||wwv_flow.LF||
'           insert into sp_release_history'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(39) := '               (release_id, attribute_column, change_type, old_value, new_value, changed_on, changed';
wwv_flow_imp.g_varchar2_table(40) := '_by)'||wwv_flow.LF||
'           values'||wwv_flow.LF||
'               (:new.release_id, ''RELEASE_MILESTONE_''||substr(:new.milestone_';
wwv_flow_imp.g_varchar2_table(41) := 'name,1,225)||''_COMPLETED'', ''UPDATE'', :old.MILESTONE_COMPLETED_YN, :new.MILESTONE_COMPLETED_YN, sysda';
wwv_flow_imp.g_varchar2_table(42) := 'te, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        -- '||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.tags,:n';
wwv_flow_imp.g_varchar2_table(43) := 'ew.tags) then'||wwv_flow.LF||
'           insert into sp_release_history'||wwv_flow.LF||
'               (release_id, attribute_column';
wwv_flow_imp.g_varchar2_table(44) := ', change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'           values'||wwv_flow.LF||
'               (:new.';
wwv_flow_imp.g_varchar2_table(45) := 'release_id, ''RELEASE_MILESTONE_''||substr(:new.milestone_name,1,225)||''_TAGS'', ''UPDATE'', :old.TAGS, :';
wwv_flow_imp.g_varchar2_table(46) := 'new.TAGS, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_release_milestones_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'crea';
wwv_flow_imp.g_varchar2_table(47) := 'te or replace trigger sp_release_milestones_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_release_milestones'||wwv_flow.LF||
'    fo';
wwv_flow_imp.g_varchar2_table(48) := 'r each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_release_history'||wwv_flow.LF||
'        (release_id, attribute_column, change_ty';
wwv_flow_imp.g_varchar2_table(49) := 'pe, old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.release_id, ''RELEASE_MILESTONE'', ''DE';
wwv_flow_imp.g_varchar2_table(50) := 'LETE'', :old.milestone_name, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(51) := 'end sp_release_milestones_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(45056630421329478925)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_release_milestones triggers'
,p_sequence=>4160
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
