prompt --application/deployment/install/install_sp_areas_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_areas trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_areas_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_areas'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(2) := 'declare'||wwv_flow.LF||
'    l_tags varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nv';
wwv_flow_imp.g_varchar2_table(3) := 'l(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coalesce(sys_context(''APEX$';
wwv_flow_imp.g_varchar2_table(4) := 'SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.upda';
wwv_flow_imp.g_varchar2_table(5) := 'ted_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif upd';
wwv_flow_imp.g_varchar2_table(6) := 'ating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX';
wwv_flow_imp.g_varchar2_table(7) := '$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.hidden_by_default_yn is null then'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(8) := ':new.hidden_by_default_yn := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- adjust tag data'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.tags ';
wwv_flow_imp.g_varchar2_table(9) := 'is not null then'||wwv_flow.LF||
'        l_tags := trim(upper(:new.tags));'||wwv_flow.LF||
'        -- remove multiple spaces'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(10) := ' if instr(l_tags,''  '') > 0 then'||wwv_flow.LF||
'            for j in 1..10 loop '||wwv_flow.LF||
'                l_tags := replace(l';
wwv_flow_imp.g_varchar2_table(11) := '_tags,''  '','' ''); '||wwv_flow.LF||
'                if instr(l_tags,''  '') = 0 then'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(12) := '      end if;'||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        for i in 1..length(l_tags) loop'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(13) := '     if i > 2 and substr(l_tags,i,1) = '' '' and substr(l_tags,i-1,1) != '','' then'||wwv_flow.LF||
'               l_tag';
wwv_flow_imp.g_varchar2_table(14) := 's := substr(l_tags,1,i-1)||''-''||substr(l_tags,i+1);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        :n';
wwv_flow_imp.g_varchar2_table(15) := 'ew.tags := l_tags;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end sp_areas_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(42307995341673022746)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_areas trigger'
,p_sequence=>4010
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
