prompt --application/deployment/install/install_sp_external_ticketing_systems_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_external_ticketing_systems table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_external_ticketing_systems ('||wwv_flow.LF||
'    id                             number default on nu';
wwv_flow_imp.g_varchar2_table(2) := 'll to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   con';
wwv_flow_imp.g_varchar2_table(3) := 'straint sp_external_ticketing_systems_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    external_system_name           varc';
wwv_flow_imp.g_varchar2_table(4) := 'har2(30 char)   not null,'||wwv_flow.LF||
'    description                    varchar2(4000 char),'||wwv_flow.LF||
'    is_active_yn  ';
wwv_flow_imp.g_varchar2_table(5) := '                 varchar2(1 char)    not null,'||wwv_flow.LF||
'    link_pattern                   varchar2(4000 char';
wwv_flow_imp.g_varchar2_table(6) := ') not null,'||wwv_flow.LF||
'    min_id_length                  integer,'||wwv_flow.LF||
'    max_id_length                  integer,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(7) := '    --'||wwv_flow.LF||
'    must_contain                   varchar2(255 char),'||wwv_flow.LF||
'    ticket_id_regex                var';
wwv_flow_imp.g_varchar2_table(8) := 'char2(255 char) not null,'||wwv_flow.LF||
'    evaulation_sequence            number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    required_initiative_';
wwv_flow_imp.g_varchar2_table(9) := 'id         number'||wwv_flow.LF||
'                                   constraint sp_external_ticketing_system_ini_fk ';
wwv_flow_imp.g_varchar2_table(10) := ''||wwv_flow.LF||
'                                   references sp_initiatives (id)'||wwv_flow.LF||
'                                 ';
wwv_flow_imp.g_varchar2_table(11) := '  on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by        ';
wwv_flow_imp.g_varchar2_table(12) := '             varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    upda';
wwv_flow_imp.g_varchar2_table(13) := 'ted_by                     varchar2(255 char) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_external_t';
wwv_flow_imp.g_varchar2_table(14) := 'icketing_systems_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_external_ticketing_systems'||wwv_flow.LF||
'    for each r';
wwv_flow_imp.g_varchar2_table(15) := 'ow'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.cr';
wwv_flow_imp.g_varchar2_table(16) := 'eated_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :ne';
wwv_flow_imp.g_varchar2_table(17) := 'w.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(';
wwv_flow_imp.g_varchar2_table(18) := 'sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sy';
wwv_flow_imp.g_varchar2_table(19) := 'sdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;';
wwv_flow_imp.g_varchar2_table(20) := ''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- default values'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.evaulation_sequence is null then'||wwv_flow.LF||
'       :new.evaula';
wwv_flow_imp.g_varchar2_table(21) := 'tion_sequence := 100;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.is_active_yn is null then'||wwv_flow.LF||
'       :new.is_active_yn := ';
wwv_flow_imp.g_varchar2_table(22) := '''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_external_ticketing_systems_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(41353364325581523273)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_external_ticketing_systems table and trigger'
,p_sequence=>3370
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
