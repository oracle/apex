prompt --application/deployment/install/install_approval_tables_and_triggers
begin
--   Manifest
--     INSTALL: INSTALL-Approval tables and triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_approval_types ('||wwv_flow.LF||
'    id                             number default on null to_number';
wwv_flow_imp.g_varchar2_table(2) := '(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_a';
wwv_flow_imp.g_varchar2_table(3) := 'pproval_types_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    display_seq                    number             not null,';
wwv_flow_imp.g_varchar2_table(4) := ''||wwv_flow.LF||
'    approval_type                  varchar2(30 char)  not null, -- DEVELOPMENT, RELEASE INCLUSION '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(5) := '    description                    varchar2(4000 char),'||wwv_flow.LF||
'    active_yn                      varchar2(';
wwv_flow_imp.g_varchar2_table(6) := '1 char) default on null ''Y'''||wwv_flow.LF||
'                                   constraint sp_approval_types_active_c';
wwv_flow_imp.g_varchar2_table(7) := 'c'||wwv_flow.LF||
'                                   check (active_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created             ';
wwv_flow_imp.g_varchar2_table(8) := '           date                not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char)  not ';
wwv_flow_imp.g_varchar2_table(9) := 'null,'||wwv_flow.LF||
'    updated                        date                not null,'||wwv_flow.LF||
'    updated_by               ';
wwv_flow_imp.g_varchar2_table(10) := '      varchar2(255 char)  not null'||wwv_flow.LF||
');'||wwv_flow.LF||
'alter table sp_approval_types add constraint sp_approval_types';
wwv_flow_imp.g_varchar2_table(11) := '_uk'||wwv_flow.LF||
'    unique (approval_type);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_approval_types_biu'||wwv_flow.LF||
'    before insert o';
wwv_flow_imp.g_varchar2_table(12) := 'r update'||wwv_flow.LF||
'    on sp_approval_types'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created ';
wwv_flow_imp.g_varchar2_table(13) := '   := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coalesce(sys_contex';
wwv_flow_imp.g_varchar2_table(14) := 't(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :';
wwv_flow_imp.g_varchar2_table(15) := 'new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(16) := 'lsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_conte';
wwv_flow_imp.g_varchar2_table(17) := 'xt(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_approval_types_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_init';
wwv_flow_imp.g_varchar2_table(18) := 'iative_approvals ('||wwv_flow.LF||
'    id                             number default on null to_number(sys_guid(), ''';
wwv_flow_imp.g_varchar2_table(19) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_initiative_appr';
wwv_flow_imp.g_varchar2_table(20) := 'ovals_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    initiative_id                  number'||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(21) := '      constraint sp_initiative_approvals_init_fk'||wwv_flow.LF||
'                                   references sp_in';
wwv_flow_imp.g_varchar2_table(22) := 'itiatives on delete cascade,'||wwv_flow.LF||
'    approval_type_id               number  not null'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(23) := '                constraint sp_initiative_approvals_apptype_fk'||wwv_flow.LF||
'                                   ref';
wwv_flow_imp.g_varchar2_table(24) := 'erences sp_approval_types,   '||wwv_flow.LF||
'    active_yn                      varchar2(1 char) default on null ''Y';
wwv_flow_imp.g_varchar2_table(25) := ''''||wwv_flow.LF||
'                                   constraint sp_initiative_approvals_active_cc'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(26) := '                 check (active_yn in (''Y'',''N'')),           '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                      ';
wwv_flow_imp.g_varchar2_table(27) := '  date                not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char)  not null,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(28) := ' updated                        date                not null,'||wwv_flow.LF||
'    updated_by                     var';
wwv_flow_imp.g_varchar2_table(29) := 'char2(255 char)  not null'||wwv_flow.LF||
');'||wwv_flow.LF||
'alter table sp_initiative_approvals add constraint sp_initiative_approv';
wwv_flow_imp.g_varchar2_table(30) := 'als_uk'||wwv_flow.LF||
'    unique (initiative_id, approval_type_id);'||wwv_flow.LF||
'create index sp_initiative_approvals_i1 on sp_i';
wwv_flow_imp.g_varchar2_table(31) := 'nitiative_approvals (approval_type_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_initiative_approvals_biu'||wwv_flow.LF||
'    b';
wwv_flow_imp.g_varchar2_table(32) := 'efore insert or update'||wwv_flow.LF||
'    on sp_initiative_approvals'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_old_value   var';
wwv_flow_imp.g_varchar2_table(33) := 'char2(4000) := null;'||wwv_flow.LF||
'    l_new_value   varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :';
wwv_flow_imp.g_varchar2_table(34) := 'new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coalesc';
wwv_flow_imp.g_varchar2_table(35) := 'e(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate';
wwv_flow_imp.g_varchar2_table(36) := ');'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),u';
wwv_flow_imp.g_varchar2_table(37) := 'ser));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coales';
wwv_flow_imp.g_varchar2_table(38) := 'ce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(39) := ''||wwv_flow.LF||
'    if sp_globals.g_audit_this then'||wwv_flow.LF||
'        update sp_initiatives set updated = sysdate, updated_by';
wwv_flow_imp.g_varchar2_table(40) := ' = :new.updated_by where id = :new.initiative_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if in';
wwv_flow_imp.g_varchar2_table(41) := 'serting then'||wwv_flow.LF||
'        for c1 in (select approval_type r from sp_approval_types x where x.id = :new.ap';
wwv_flow_imp.g_varchar2_table(42) := 'proval_type_id) loop l_new_value := c1.r; end loop; '||wwv_flow.LF||
'        insert into sp_initiative_history '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(43) := '        (initiative_id, attribute_column, change_type, new_value, changed_on, changed_by) '||wwv_flow.LF||
'        v';
wwv_flow_imp.g_varchar2_table(44) := 'alues '||wwv_flow.LF||
'            (:new.initiative_id, ''INITIATIVE_APPROVAL'', ''CREATE'', l_new_value||'' (''||case whe';
wwv_flow_imp.g_varchar2_table(45) := 'n :new.active_yn = ''Y'' then ''Active'' else ''Inactive'' end||'')'', sysdate, lower(:new.created_by)); '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(46) := '  elsif updating then'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.approval_type_id,:new.approval_t';
wwv_flow_imp.g_varchar2_table(47) := 'ype_id) or'||wwv_flow.LF||
'           not sp_value_compare.is_equal(:old.active_yn,:new.active_yn) then'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(48) := 'for c1 in (select approval_type r from sp_approval_types x where x.id = :old.approval_type_id) loop ';
wwv_flow_imp.g_varchar2_table(49) := 'l_old_value := c1.r; end loop;'||wwv_flow.LF||
'            for c1 in (select approval_type r from sp_approval_types ';
wwv_flow_imp.g_varchar2_table(50) := 'x where x.id = :new.approval_type_id) loop l_new_value := c1.r; end loop; '||wwv_flow.LF||
'            insert into s';
wwv_flow_imp.g_varchar2_table(51) := 'p_initiative_history'||wwv_flow.LF||
'                (initiative_id, attribute_column, change_type, old_value, new_v';
wwv_flow_imp.g_varchar2_table(52) := 'alue,changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.initiative_id, ''INITIATIVE_APP';
wwv_flow_imp.g_varchar2_table(53) := 'ROVAL'', ''UPDATE'', '||wwv_flow.LF||
'                 l_old_value||'' (''||case when :old.active_yn = ''Y'' then ''Active'' ';
wwv_flow_imp.g_varchar2_table(54) := 'else ''Inactive'' end||'')'', '||wwv_flow.LF||
'                 l_new_value||'' (''||case when :new.active_yn = ''Y'' then ''';
wwv_flow_imp.g_varchar2_table(55) := 'Active'' else ''Inactive'' end||'')'', '||wwv_flow.LF||
'                 sysdate, lower(:new.updated_by));'||wwv_flow.LF||
'        end if';
wwv_flow_imp.g_varchar2_table(56) := ';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_initiative_approvals_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_initiative_approvals_';
wwv_flow_imp.g_varchar2_table(57) := 'bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_initiative_approvals'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_old_value   varch';
wwv_flow_imp.g_varchar2_table(58) := 'ar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_initiatives set updat';
wwv_flow_imp.g_varchar2_table(59) := 'ed = sysdate, updated_by = :old.updated_by where id = :old.initiative_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for c1 in (sele';
wwv_flow_imp.g_varchar2_table(60) := 'ct approval_type r from sp_approval_types x where x.id = :old.approval_type_id) loop l_old_value := ';
wwv_flow_imp.g_varchar2_table(61) := 'c1.r; end loop; '||wwv_flow.LF||
'    insert into sp_initiative_history'||wwv_flow.LF||
'        (initiative_id, attribute_column, cha';
wwv_flow_imp.g_varchar2_table(62) := 'nge_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.initiative_id, ''INITIATIVE_APP';
wwv_flow_imp.g_varchar2_table(63) := 'ROVAL'', ''DELETE'', '||wwv_flow.LF||
'         l_old_value||'' (''||case when :old.active_yn = ''Y'' then ''Active'' else ''In';
wwv_flow_imp.g_varchar2_table(64) := 'active'' end||'')'', sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'end sp_ini';
wwv_flow_imp.g_varchar2_table(65) := 'tiative_approvals_bd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_initiative_approval_chain ('||wwv_flow.LF||
'    id                        ';
wwv_flow_imp.g_varchar2_table(66) := '     number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(67) := '                      constraint sp_initiative_approval_chain_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    initiative_';
wwv_flow_imp.g_varchar2_table(68) := 'approval_id         number  not null'||wwv_flow.LF||
'                                   constraint sp_initiative_app';
wwv_flow_imp.g_varchar2_table(69) := 'roval_chain_apptype_fk'||wwv_flow.LF||
'                                   references sp_initiative_approvals,       ';
wwv_flow_imp.g_varchar2_table(70) := '       '||wwv_flow.LF||
'    team_member_id                 number'||wwv_flow.LF||
'                                   constraint sp_i';
wwv_flow_imp.g_varchar2_table(71) := 'nitiative_approval_chain_tm_fk'||wwv_flow.LF||
'                                   references sp_team_members,'||wwv_flow.LF||
'    ap';
wwv_flow_imp.g_varchar2_table(72) := 'proval_seq                   number not null,'||wwv_flow.LF||
'    active_yn                      varchar2(1 char) de';
wwv_flow_imp.g_varchar2_table(73) := 'fault on null ''Y'''||wwv_flow.LF||
'                                   constraint sp_initiative_approval_chain_active_';
wwv_flow_imp.g_varchar2_table(74) := 'cc'||wwv_flow.LF||
'                                   check (active_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    alternate_team_member_id  ';
wwv_flow_imp.g_varchar2_table(75) := '     number'||wwv_flow.LF||
'                                   constraint sp_project_approval_chain_alt_tm_fk'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(76) := '                             references sp_team_members,'||wwv_flow.LF||
'    alternate_start_date           date,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(77) := '  alternate_end_date             date,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date               ';
wwv_flow_imp.g_varchar2_table(78) := ' not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char)  not null,'||wwv_flow.LF||
'    updated             ';
wwv_flow_imp.g_varchar2_table(79) := '           date                not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char)  not ';
wwv_flow_imp.g_varchar2_table(80) := 'null'||wwv_flow.LF||
');'||wwv_flow.LF||
'alter table sp_initiative_approval_chain add constraint sp_initiative_approval_chain_uk1'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(81) := ' unique (initiative_approval_id, team_member_id);'||wwv_flow.LF||
'alter table sp_initiative_approval_chain add const';
wwv_flow_imp.g_varchar2_table(82) := 'raint sp_initiative_approval_chain_uk2'||wwv_flow.LF||
'    unique (initiative_approval_id, approval_seq);'||wwv_flow.LF||
'create ind';
wwv_flow_imp.g_varchar2_table(83) := 'ex sp_initiative_approval_chain_i1 on sp_initiative_approval_chain (team_member_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or repl';
wwv_flow_imp.g_varchar2_table(84) := 'ace trigger sp_initiative_approval_chain_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_initiative_approv';
wwv_flow_imp.g_varchar2_table(85) := 'al_chain'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_initiative_id  number;'||wwv_flow.LF||
'    l_approval_type  varchar2(4000) :';
wwv_flow_imp.g_varchar2_table(86) := '= null;'||wwv_flow.LF||
'    l_old_value      varchar2(4000) := null;'||wwv_flow.LF||
'    l_new_value      varchar2(4000) := null;'||wwv_flow.LF||
'be';
wwv_flow_imp.g_varchar2_table(87) := 'gin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created';
wwv_flow_imp.g_varchar2_table(88) := '_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.cre';
wwv_flow_imp.g_varchar2_table(89) := 'ated    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coalesce(sys_c';
wwv_flow_imp.g_varchar2_table(90) := 'ontext(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate';
wwv_flow_imp.g_varchar2_table(91) := ';'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(92) := '--'||wwv_flow.LF||
'    :new.alternate_start_date := trunc(:new.alternate_start_date);'||wwv_flow.LF||
'    :new.alternate_end_date   ';
wwv_flow_imp.g_varchar2_table(93) := ':= trunc(:new.alternate_end_date);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if sp_globals.g_audit';
wwv_flow_imp.g_varchar2_table(94) := '_this then'||wwv_flow.LF||
'        update sp_initiative_approvals set updated = sysdate, updated_by = :old.updated_b';
wwv_flow_imp.g_varchar2_table(95) := 'y where id = :old.initiative_approval_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting ';
wwv_flow_imp.g_varchar2_table(96) := 'then'||wwv_flow.LF||
'        for c1 in (select x.initiative_id, t.approval_type '||wwv_flow.LF||
'                     from sp_initia';
wwv_flow_imp.g_varchar2_table(97) := 'tive_approvals x, sp_approval_types t '||wwv_flow.LF||
'                    where x.id = :new.initiative_approval_id'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(98) := '                      and x.approval_type_id = t.id'||wwv_flow.LF||
'                  ) loop l_initiative_id := c1.i';
wwv_flow_imp.g_varchar2_table(99) := 'nitiative_id; l_approval_type := c1.approval_type; end loop;     '||wwv_flow.LF||
'        for c1 in (select lower(em';
wwv_flow_imp.g_varchar2_table(100) := 'ail) r from SP_TEAM_MEMBERS x where x.id = :new.team_member_id) loop l_new_value := :new.approval_se';
wwv_flow_imp.g_varchar2_table(101) := 'q||''-''||c1.r; end loop;'||wwv_flow.LF||
'        insert into sp_initiative_history '||wwv_flow.LF||
'            (initiative_id, attri';
wwv_flow_imp.g_varchar2_table(102) := 'bute_column, change_type, new_value, changed_on, changed_by) '||wwv_flow.LF||
'        values '||wwv_flow.LF||
'            (l_initiat';
wwv_flow_imp.g_varchar2_table(103) := 'ive_id, ''INITIATIVE_APPROVAL_CHAIN'', ''CREATE'', l_approval_type||'' - ''||l_new_value, sysdate, lower(:';
wwv_flow_imp.g_varchar2_table(104) := 'new.created_by)); '||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.team_member';
wwv_flow_imp.g_varchar2_table(105) := '_id,:new.team_member_id) or'||wwv_flow.LF||
'               sp_value_compare.is_equal(:old.approval_seq,:new.approval';
wwv_flow_imp.g_varchar2_table(106) := '_seq) or'||wwv_flow.LF||
'               sp_value_compare.is_equal(:old.active_yn,:new.active_yn) or'||wwv_flow.LF||
'               s';
wwv_flow_imp.g_varchar2_table(107) := 'p_value_compare.is_equal(:old.alternate_team_member_id,:new.alternate_team_member_id) or'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(108) := '    sp_value_compare.is_equal(:old.alternate_start_date,:new.alternate_start_date) or'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(109) := ' sp_value_compare.is_equal(:old.alternate_end_date,:new.alternate_end_date)'||wwv_flow.LF||
'        then'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(110) := ' for c1 in (select x.initiative_id, t.approval_type '||wwv_flow.LF||
'                         from sp_initiative_app';
wwv_flow_imp.g_varchar2_table(111) := 'rovals x, sp_approval_types t '||wwv_flow.LF||
'                        where x.id = :new.initiative_approval_id'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(112) := '                      and x.approval_type_id = t.id'||wwv_flow.LF||
'                      ) loop l_initiative_id := ';
wwv_flow_imp.g_varchar2_table(113) := 'c1.initiative_id; l_approval_type := c1.approval_type; end loop;   '||wwv_flow.LF||
'            for c1 in (select lo';
wwv_flow_imp.g_varchar2_table(114) := 'wer(email) r from SP_TEAM_MEMBERS x where x.id = :old.team_member_id) loop l_old_value := :old.appro';
wwv_flow_imp.g_varchar2_table(115) := 'val_seq||''-''||c1.r; end loop;'||wwv_flow.LF||
'            for c1 in (select lower(email) r from SP_TEAM_MEMBERS x wh';
wwv_flow_imp.g_varchar2_table(116) := 'ere x.id = :new.team_member_id) loop l_new_value := :new.approval_seq||''-''||c1.r; end loop;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(117) := '    if sp_value_compare.is_equal(:old.alternate_team_member_id,:new.alternate_team_member_id) then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(118) := '               for c1 in (select lower(email) r from SP_TEAM_MEMBERS x where x.id = :old.alternate_t';
wwv_flow_imp.g_varchar2_table(119) := 'eam_member_id) loop '||wwv_flow.LF||
'                           l_old_value := l_old_value || '' [alternate ''||c1.r||';
wwv_flow_imp.g_varchar2_table(120) := ''' ''||case when :old.alternate_start_date is not null then :old.alternate_start_date||'' thru '' end|| ';
wwv_flow_imp.g_varchar2_table(121) := ''||wwv_flow.LF||
'                                                                                    case when :old.';
wwv_flow_imp.g_varchar2_table(122) := 'alternate_end_date is not null then :old.alternate_end_date end||'']''; end loop;'||wwv_flow.LF||
'                for ';
wwv_flow_imp.g_varchar2_table(123) := 'c1 in (select lower(email) r from SP_TEAM_MEMBERS x where x.id = :new.alternate_team_member_id) loop';
wwv_flow_imp.g_varchar2_table(124) := ' '||wwv_flow.LF||
'                           l_new_value := l_new_value || '' [alternate ''||c1.r||'' ''||case when :new';
wwv_flow_imp.g_varchar2_table(125) := '.alternate_start_date is not null then :new.alternate_start_date||'' thru '' end|| '||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(126) := '                                                                  case when :new.alternate_end_date ';
wwv_flow_imp.g_varchar2_table(127) := 'is not null then :new.alternate_end_date end||'']''; end loop;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            insert ';
wwv_flow_imp.g_varchar2_table(128) := 'into sp_initiative_history'||wwv_flow.LF||
'                (initiative_id, attribute_column, change_type, old_value,';
wwv_flow_imp.g_varchar2_table(129) := ' new_value,changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (l_initiative_id, ''INITIATIVE_';
wwv_flow_imp.g_varchar2_table(130) := 'APPROVAL_CHAIN'', ''UPDATE'', '||wwv_flow.LF||
'                 l_approval_type||'' - ''||l_old_value||'' (''||decode(:old.';
wwv_flow_imp.g_varchar2_table(131) := 'active_yn,''Y'',''Active'',''Inactive'')||'')'', '||wwv_flow.LF||
'                 l_approval_type||'' - ''||l_new_value||'' (''';
wwv_flow_imp.g_varchar2_table(132) := '||decode(:new.active_yn,''Y'',''Active'',''Inactive'')||'')'', '||wwv_flow.LF||
'                 sysdate, lower(:new.updated';
wwv_flow_imp.g_varchar2_table(133) := '_by));'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_initiative_approval_chain_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigge';
wwv_flow_imp.g_varchar2_table(134) := 'r sp_initiative_approval_chain_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_initiative_approval_chain'||wwv_flow.LF||
'    for each';
wwv_flow_imp.g_varchar2_table(135) := ' row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_initiative_id  number;'||wwv_flow.LF||
'    l_approval_type  varchar2(4000) := null;'||wwv_flow.LF||
'    l_old_val';
wwv_flow_imp.g_varchar2_table(136) := 'ue      varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_initiati';
wwv_flow_imp.g_varchar2_table(137) := 've_approvals set updated = sysdate, updated_by = :old.updated_by where id = :old.initiative_approval';
wwv_flow_imp.g_varchar2_table(138) := '_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for c1 in (select x.initiative_id, t.approval_type '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(139) := '       from sp_initiative_approvals x, sp_approval_types t '||wwv_flow.LF||
'                where x.id = :old.initia';
wwv_flow_imp.g_varchar2_table(140) := 'tive_approval_id'||wwv_flow.LF||
'                  and x.approval_type_id = t.id'||wwv_flow.LF||
'              ) loop l_initiative_i';
wwv_flow_imp.g_varchar2_table(141) := 'd := c1.initiative_id; l_approval_type := c1.approval_type; end loop; '||wwv_flow.LF||
'    for c1 in (select lower(e';
wwv_flow_imp.g_varchar2_table(142) := 'mail) r from SP_TEAM_MEMBERS x where x.id = :old.team_member_id) loop l_old_value := :old.approval_s';
wwv_flow_imp.g_varchar2_table(143) := 'eq||''-''||c1.r; end loop;'||wwv_flow.LF||
'    insert into sp_initiative_history'||wwv_flow.LF||
'        (initiative_id, attribute_col';
wwv_flow_imp.g_varchar2_table(144) := 'umn, change_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (l_initiative_id, ''INITIATIV';
wwv_flow_imp.g_varchar2_table(145) := 'E_APPROVAL'', ''DELETE'', '||wwv_flow.LF||
'         l_approval_type||'' - ''||l_old_value||'' (''||decode(:old.active_yn,''Y';
wwv_flow_imp.g_varchar2_table(146) := ''',''Active'',''Inactive'')||'')'', '||wwv_flow.LF||
'         sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''';
wwv_flow_imp.g_varchar2_table(147) := '),user)));'||wwv_flow.LF||
'end sp_initiative_approval_chain_bd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_project_approvals ('||wwv_flow.LF||
'    id      ';
wwv_flow_imp.g_varchar2_table(148) := '                       number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(149) := 'X'') '||wwv_flow.LF||
'                                   constraint sp_project_approvals_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    a';
wwv_flow_imp.g_varchar2_table(150) := 'pproval_type_id               number  not null'||wwv_flow.LF||
'                                   constraint sp_proj';
wwv_flow_imp.g_varchar2_table(151) := 'ect_approvals_apptype_fk'||wwv_flow.LF||
'                                   references sp_approval_types, '||wwv_flow.LF||
'    proje';
wwv_flow_imp.g_varchar2_table(152) := 'ct_id                     number  not null'||wwv_flow.LF||
'                                   constraint sp_project_';
wwv_flow_imp.g_varchar2_table(153) := 'approvals_proj_fk'||wwv_flow.LF||
'                                   references sp_projects on delete cascade,'||wwv_flow.LF||
'    s';
wwv_flow_imp.g_varchar2_table(154) := 'ubmitted_by_team_member_id    number  not null'||wwv_flow.LF||
'                                   constraint sp_proj';
wwv_flow_imp.g_varchar2_table(155) := 'ect_approvals_subm_fk'||wwv_flow.LF||
'                                   references sp_team_members,'||wwv_flow.LF||
'    justificati';
wwv_flow_imp.g_varchar2_table(156) := 'on                  varchar2(4000)  not null,'||wwv_flow.LF||
'    submitted                      date  not null,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(157) := ' initiative_approval_id         number'||wwv_flow.LF||
'                                   constraint sp_project_appr';
wwv_flow_imp.g_varchar2_table(158) := 'ovals_chain_fk'||wwv_flow.LF||
'                                   references sp_initiative_approvals,'||wwv_flow.LF||
'    status    ';
wwv_flow_imp.g_varchar2_table(159) := '                     varchar2(30)  default on null ''PENDING'', -- Pending, Withdrawn, Clarification R';
wwv_flow_imp.g_varchar2_table(160) := 'equested, Approved, Rejected'||wwv_flow.LF||
'    withdrawn_by_team_member_id    number'||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(161) := '      constraint sp_project_approvals_withd_fk'||wwv_flow.LF||
'                                   references sp_team';
wwv_flow_imp.g_varchar2_table(162) := '_members,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    updated                        date                not null,'||wwv_flow.LF||
'    updated_by    ';
wwv_flow_imp.g_varchar2_table(163) := '                 varchar2(255 char)  not null'||wwv_flow.LF||
');'||wwv_flow.LF||
'create index sp_project_approvals_i1 on sp_project_';
wwv_flow_imp.g_varchar2_table(164) := 'approvals (approval_type_id);'||wwv_flow.LF||
'create index sp_project_approvals_i2 on sp_project_approvals (project_';
wwv_flow_imp.g_varchar2_table(165) := 'id);'||wwv_flow.LF||
'create index sp_project_approvals_i3 on sp_project_approvals (submitted_by_team_member_id);'||wwv_flow.LF||
'cre';
wwv_flow_imp.g_varchar2_table(166) := 'ate index sp_project_approvals_i4 on sp_project_approvals (initiative_approval_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or repla';
wwv_flow_imp.g_varchar2_table(167) := 'ce trigger sp_project_approvals_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_project_approvals'||wwv_flow.LF||
'    for ';
wwv_flow_imp.g_varchar2_table(168) := 'each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_old_value   varchar2(4000) := null;'||wwv_flow.LF||
'    l_new_value   varchar2(4000) := null;';
wwv_flow_imp.g_varchar2_table(169) := ''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.submitted  := nvl(:new.submitted,sysdate);'||wwv_flow.LF||
'        :new.up';
wwv_flow_imp.g_varchar2_table(170) := 'dated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(sys_';
wwv_flow_imp.g_varchar2_table(171) := 'context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdat';
wwv_flow_imp.g_varchar2_table(172) := 'e;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(173) := ' --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if sp_globals.g_audit_this then'||wwv_flow.LF||
'        update sp_projects ';
wwv_flow_imp.g_varchar2_table(174) := 'set updated = sysdate, updated_by = :new.updated_by where id = :new.project_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(175) := '   -- history'||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        for c1 in (select approval_type x from sp_approv';
wwv_flow_imp.g_varchar2_table(176) := 'al_types t where t.id = :new.approval_type_id) loop l_new_value := c1.x; end loop;'||wwv_flow.LF||
'        insert in';
wwv_flow_imp.g_varchar2_table(177) := 'to sp_project_history'||wwv_flow.LF||
'            (project_id, attribute_column, change_type, new_value, changed_on,';
wwv_flow_imp.g_varchar2_table(178) := ' changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.project_id, ''APPROVAL'', ''CREATE'', l_new_value, sysdate';
wwv_flow_imp.g_varchar2_table(179) := ', coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        if not sp_';
wwv_flow_imp.g_varchar2_table(180) := 'value_compare.is_equal(:old.status,:new.status) then'||wwv_flow.LF||
'            for c1 in (select approval_type x f';
wwv_flow_imp.g_varchar2_table(181) := 'rom sp_approval_types t where t.id = :new.approval_type_id) loop l_new_value := c1.x; end loop;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(182) := '        insert into sp_project_history'||wwv_flow.LF||
'                (project_id, attribute_column, change_type, n';
wwv_flow_imp.g_varchar2_table(183) := 'ew_value, changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.project_id, ''APPROVAL'', ''';
wwv_flow_imp.g_varchar2_table(184) := 'UPDATE'', l_new_value||'' - ''||:new.status, sysdate, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),u';
wwv_flow_imp.g_varchar2_table(185) := 'ser));'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_project_approvals_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_pro';
wwv_flow_imp.g_varchar2_table(186) := 'ject_approvals_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_project_approvals'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_old_v';
wwv_flow_imp.g_varchar2_table(187) := 'alue   varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_projects ';
wwv_flow_imp.g_varchar2_table(188) := 'set updated = sysdate, updated_by = :old.updated_by where id = :old.project_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for c1 in';
wwv_flow_imp.g_varchar2_table(189) := ' (select approval_type x from sp_approval_types t where t.id = :old.approval_type_id) loop l_old_val';
wwv_flow_imp.g_varchar2_table(190) := 'ue := c1.x; end loop;'||wwv_flow.LF||
'    insert into sp_project_history'||wwv_flow.LF||
'        (project_id, attribute_column, chan';
wwv_flow_imp.g_varchar2_table(191) := 'ge_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.project_id, ''APPROVAL'', ''DELETE';
wwv_flow_imp.g_varchar2_table(192) := ''', l_old_value, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'end sp_proje';
wwv_flow_imp.g_varchar2_table(193) := 'ct_approvals_bd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_project_approval_chain ('||wwv_flow.LF||
'    id                             numb';
wwv_flow_imp.g_varchar2_table(194) := 'er default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(195) := '             constraint sp_project_approval_chain_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    project_approval_id    ';
wwv_flow_imp.g_varchar2_table(196) := '        number  not null'||wwv_flow.LF||
'                                   constraint sp_project_approval_chain_pro';
wwv_flow_imp.g_varchar2_table(197) := 'japp_fk'||wwv_flow.LF||
'                                   references sp_project_approvals on delete cascade,'||wwv_flow.LF||
'    in';
wwv_flow_imp.g_varchar2_table(198) := 'itiative_approval_chain_id   number'||wwv_flow.LF||
'                                   constraint sp_project_approva';
wwv_flow_imp.g_varchar2_table(199) := 'l_chain_iac_fk'||wwv_flow.LF||
'                                   references sp_initiative_approval_chain,'||wwv_flow.LF||
'    team_';
wwv_flow_imp.g_varchar2_table(200) := 'member_id                 number  not null'||wwv_flow.LF||
'                                   constraint sp_project_';
wwv_flow_imp.g_varchar2_table(201) := 'approval_chain_tm_fk'||wwv_flow.LF||
'                                   references sp_team_members,'||wwv_flow.LF||
'    status      ';
wwv_flow_imp.g_varchar2_table(202) := '                   varchar2(30 char)  default on null ''PENDING'', -- Pending, Withdrawn, Clarificatio';
wwv_flow_imp.g_varchar2_table(203) := 'n Requested, Approved, Rejected'||wwv_flow.LF||
'    last_status_on                 date               default on nul';
wwv_flow_imp.g_varchar2_table(204) := 'l sysdate,'||wwv_flow.LF||
'    comments                       varchar2(4000),  -- not null if clarification or rejec';
wwv_flow_imp.g_varchar2_table(205) := 'ted'||wwv_flow.LF||
'    response                       varchar2(4000),'||wwv_flow.LF||
'    response_by_team_member_id     number'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(206) := '                                constraint sp_project_approval_chain_resp_fk'||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(207) := '            references sp_team_members,'||wwv_flow.LF||
'    responded_on                   date,'||wwv_flow.LF||
'    final_yn       ';
wwv_flow_imp.g_varchar2_table(208) := '                varchar2(1 char)'||wwv_flow.LF||
'                                      default on null ''Y'''||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(209) := '                             constraint sp_project_approval_chain_final_cc'||wwv_flow.LF||
'                         ';
wwv_flow_imp.g_varchar2_table(210) := '             check (final_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date          ';
wwv_flow_imp.g_varchar2_table(211) := '      not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char)  not null,'||wwv_flow.LF||
'    updated        ';
wwv_flow_imp.g_varchar2_table(212) := '                date                not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) ';
wwv_flow_imp.g_varchar2_table(213) := ' not null'||wwv_flow.LF||
');'||wwv_flow.LF||
'create index sp_project_approval_chain_i1 on sp_project_approval_chain (project_approva';
wwv_flow_imp.g_varchar2_table(214) := 'l_id);'||wwv_flow.LF||
'create index sp_project_approval_chain_i2 on sp_project_approval_chain (initiative_approval_c';
wwv_flow_imp.g_varchar2_table(215) := 'hain_id);'||wwv_flow.LF||
'create index sp_project_approval_chain_i3 on sp_project_approval_chain (team_member_id);'||wwv_flow.LF||
'c';
wwv_flow_imp.g_varchar2_table(216) := 'reate index sp_project_approval_chain_i4 on sp_project_approval_chain (response_by_team_member_id);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(217) := ''||wwv_flow.LF||
'-- protects against duplicate, active approvals'||wwv_flow.LF||
'create or replace trigger sp_project_approval_chain';
wwv_flow_imp.g_varchar2_table(218) := '_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_project_approval_chain'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inse';
wwv_flow_imp.g_varchar2_table(219) := 'rting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new';
wwv_flow_imp.g_varchar2_table(220) := '.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(';
wwv_flow_imp.g_varchar2_table(221) := ':new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SE';
wwv_flow_imp.g_varchar2_table(222) := 'SSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.';
wwv_flow_imp.g_varchar2_table(223) := 'updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- no ne';
wwv_flow_imp.g_varchar2_table(224) := 'ed to update project table nor history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'end sp_project_approval_chain_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(51780881287912418571)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'Approval tables and triggers'
,p_sequence=>3510
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
