prompt --application/deployment/install/install_sp_project_contributors_triggers
begin
--   Manifest
--     INSTALL: INSTALL-sp_project_contributors triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_project_contributors_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_project_';
wwv_flow_imp.g_varchar2_table(2) := 'contributors'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_old_value   varchar2(4000) := null;'||wwv_flow.LF||
'    l_new_value   va';
wwv_flow_imp.g_varchar2_table(3) := 'rchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdat';
wwv_flow_imp.g_varchar2_table(4) := 'e);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),';
wwv_flow_imp.g_varchar2_table(5) := 'user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.up';
wwv_flow_imp.g_varchar2_table(6) := 'dated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :n';
wwv_flow_imp.g_varchar2_table(7) := 'ew.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER'')';
wwv_flow_imp.g_varchar2_table(8) := ',user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.tags := trim(upper(:new.tags));'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table';
wwv_flow_imp.g_varchar2_table(9) := ''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if sp_globals.g_audit_this then'||wwv_flow.LF||
'        update sp_projects set updated = sysdate, update';
wwv_flow_imp.g_varchar2_table(10) := 'd_by = :new.updated_by where id = :new.project_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if i';
wwv_flow_imp.g_varchar2_table(11) := 'nserting then'||wwv_flow.LF||
'          for c1 in (select first_name||'' ''||last_name||'' - ''||email x from SP_TEAM_ME';
wwv_flow_imp.g_varchar2_table(12) := 'MBERS t where t.id = :NEW.TEAM_MEMBER_ID) loop l_new_value := c1.x; end loop;'||wwv_flow.LF||
'          for c1 in (s';
wwv_flow_imp.g_varchar2_table(13) := 'elect resource_type x from SP_RESOURCE_TYPES t where t.id = :NEW.RESPONSIBILITY_ID) loop l_new_value';
wwv_flow_imp.g_varchar2_table(14) := ' := l_new_value||'' - ''||c1.x; end loop;'||wwv_flow.LF||
'        insert into sp_project_history'||wwv_flow.LF||
'            (project_';
wwv_flow_imp.g_varchar2_table(15) := 'id, attribute_column, change_type, new_value, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:n';
wwv_flow_imp.g_varchar2_table(16) := 'ew.project_id, ''CONTRIBUTOR'', ''CREATE'', l_new_value, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'    elsif upd';
wwv_flow_imp.g_varchar2_table(17) := 'ating then'||wwv_flow.LF||
'          for c1 in (select first_name||'' ''||last_name||'' - ''||email x from SP_TEAM_MEMBE';
wwv_flow_imp.g_varchar2_table(18) := 'RS t where t.id = :OLD.TEAM_MEMBER_ID) loop l_old_value := c1.x; end loop;'||wwv_flow.LF||
'          for c1 in (sele';
wwv_flow_imp.g_varchar2_table(19) := 'ct first_name||'' ''||last_name||'' - ''||email x from SP_TEAM_MEMBERS t where t.id = :NEW.TEAM_MEMBER_I';
wwv_flow_imp.g_varchar2_table(20) := 'D) loop l_new_value := c1.x; end loop;'||wwv_flow.LF||
'          for c1 in (select resource_type x from SP_RESOURCE_';
wwv_flow_imp.g_varchar2_table(21) := 'TYPES t where t.id = :OLD.RESPONSIBILITY_ID) loop l_old_value := l_old_value||'' - ''||c1.x; end loop;';
wwv_flow_imp.g_varchar2_table(22) := ''||wwv_flow.LF||
'          for c1 in (select resource_type x from SP_RESOURCE_TYPES t where t.id = :NEW.RESPONSIBILI';
wwv_flow_imp.g_varchar2_table(23) := 'TY_ID) loop l_new_value := l_new_value||'' - ''||c1.x; end loop;'||wwv_flow.LF||
'          --'||wwv_flow.LF||
'          -- only log up';
wwv_flow_imp.g_varchar2_table(24) := 'dates that change values'||wwv_flow.LF||
'          --'||wwv_flow.LF||
'          if nvl(l_old_value,''x'') != nvl(l_new_value,''x'') then';
wwv_flow_imp.g_varchar2_table(25) := ''||wwv_flow.LF||
'              insert into sp_project_history'||wwv_flow.LF||
'                  (project_id, attribute_column, chang';
wwv_flow_imp.g_varchar2_table(26) := 'e_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'              values'||wwv_flow.LF||
'                  (:new.p';
wwv_flow_imp.g_varchar2_table(27) := 'roject_id, ''CONTRIBUTOR'', ''UPDATE'', l_old_value, l_new_value, sysdate, lower(:new.updated_by));'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(28) := '      end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_project_contributors_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_project';
wwv_flow_imp.g_varchar2_table(29) := '_contributors_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_project_contributors'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    v1   ';
wwv_flow_imp.g_varchar2_table(30) := 'varchar2(255) := null;'||wwv_flow.LF||
'    v2   varchar2(255) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(31) := ''||wwv_flow.LF||
'    update sp_projects set updated = sysdate, updated_by = :old.updated_by where id = :old.project_';
wwv_flow_imp.g_varchar2_table(32) := 'id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for c1 in (select email from sp_team_members x where x.id = :old.team_member_id) loop';
wwv_flow_imp.g_varchar2_table(33) := ''||wwv_flow.LF||
'        v1 := c1.email;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    for c1 in (select resource_type from sp_resource_types x ';
wwv_flow_imp.g_varchar2_table(34) := 'where x.id = :old.responsibility_id) loop '||wwv_flow.LF||
'        v2 := c1.resource_type;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    insert ';
wwv_flow_imp.g_varchar2_table(35) := 'into sp_project_history'||wwv_flow.LF||
'        (project_id, attribute_column, change_type, old_value, changed_on, c';
wwv_flow_imp.g_varchar2_table(36) := 'hanged_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.project_id, ''CONTRIBUTOR'', ''DELETE'', v2||'': ''||v1, sysdate, lowe';
wwv_flow_imp.g_varchar2_table(37) := 'r(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'end sp_project_contributors_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(44038547199966599573)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_project_contributors triggers'
,p_sequence=>4100
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
