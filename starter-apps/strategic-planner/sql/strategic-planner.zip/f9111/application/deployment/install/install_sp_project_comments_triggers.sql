prompt --application/deployment/install/install_sp_project_comments_triggers
begin
--   Manifest
--     INSTALL: INSTALL-sp_project_comments triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_project_comments_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_project_comm';
wwv_flow_imp.g_varchar2_table(2) := 'ents'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdat';
wwv_flow_imp.g_varchar2_table(3) := 'e);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),';
wwv_flow_imp.g_varchar2_table(4) := 'user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.up';
wwv_flow_imp.g_varchar2_table(5) := 'dated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :n';
wwv_flow_imp.g_varchar2_table(6) := 'ew.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER'')';
wwv_flow_imp.g_varchar2_table(7) := ',user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.private_yn is null then '||wwv_flow.LF||
'       :new.private_yn := ''N'';'||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(8) := 'nd if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        for c1 in (select nvl(max(comment_nbr),0) cnbr from sp_p';
wwv_flow_imp.g_varchar2_table(9) := 'roject_comments where project_id = :new.project_id)'||wwv_flow.LF||
'        loop :new.comment_nbr := c1.cnbr+1; end ';
wwv_flow_imp.g_varchar2_table(10) := 'loop;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if sp_globals.g_audit_this then'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(11) := '  update sp_projects set updated = sysdate, updated_by = :new.updated_by where id = :new.project_id;';
wwv_flow_imp.g_varchar2_table(12) := ''||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting and :new.private_yn = ''N'' then'||wwv_flow.LF||
'        in';
wwv_flow_imp.g_varchar2_table(13) := 'sert into sp_project_history'||wwv_flow.LF||
'            (project_id, attribute_column, change_type, new_value, new_';
wwv_flow_imp.g_varchar2_table(14) := 'value_clob, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.project_id, ''COMMENT'', ''CREATE''';
wwv_flow_imp.g_varchar2_table(15) := ', dbms_lob.substr(:new.body_no_images,500,1), :new.body_no_images, sysdate, lower(:new.created_by));';
wwv_flow_imp.g_varchar2_table(16) := ''||wwv_flow.LF||
'    elsif updating and :old.private_yn = ''N'' and :new.private_yn = ''N'' then'||wwv_flow.LF||
'        if not sp_value';
wwv_flow_imp.g_varchar2_table(17) := '_compare.is_equal(:old.body_no_images,:new.body_no_images) then'||wwv_flow.LF||
'            insert into sp_project_h';
wwv_flow_imp.g_varchar2_table(18) := 'istory'||wwv_flow.LF||
'                (project_id, attribute_column, change_type, old_value, new_value, old_value_c';
wwv_flow_imp.g_varchar2_table(19) := 'lob, new_value_clob, changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.project_id, ''C';
wwv_flow_imp.g_varchar2_table(20) := 'OMMENT'', ''UPDATE'', dbms_lob.substr(:old.body_no_images,500,1), dbms_lob.substr(:new.body_no_images,5';
wwv_flow_imp.g_varchar2_table(21) := '00,1), :old.body_no_images, :new.body_no_images, sysdate, lower(:new.updated_by));'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(22) := '   end if;'||wwv_flow.LF||
'end sp_project_comments_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_project_comments_bd'||wwv_flow.LF||
'    bef';
wwv_flow_imp.g_varchar2_table(23) := 'ore delete'||wwv_flow.LF||
'    on sp_project_comments'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :old.private_yn = ''N'' then'||wwv_flow.LF||
'    -';
wwv_flow_imp.g_varchar2_table(24) := '-'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_projects set updated = sysdate, updated_by = :old.u';
wwv_flow_imp.g_varchar2_table(25) := 'pdated_by where id = :old.project_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    insert into sp_project_histor';
wwv_flow_imp.g_varchar2_table(26) := 'y'||wwv_flow.LF||
'        (project_id, attribute_column, change_type, old_value, old_value_clob, changed_on, changed';
wwv_flow_imp.g_varchar2_table(27) := '_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.project_id, ''COMMENT'', ''DELETE'', dbms_lob.substr(:old.body_no_images,5';
wwv_flow_imp.g_varchar2_table(28) := '00,1), :old.body_no_images, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(29) := '    end if;'||wwv_flow.LF||
'end sp_project_comments_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38223893616558653385)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_project_comments triggers'
,p_sequence=>4090
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
