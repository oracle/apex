prompt --application/deployment/install/install_sp_initiative_focus_areas_triggers
begin
--   Manifest
--     INSTALL: INSTALL-sp_initiative_focus_areas triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_initiative_focus_areas_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_initia';
wwv_flow_imp.g_varchar2_table(2) := 'tive_focus_areas'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare '||wwv_flow.LF||
'    l_old_value   varchar2(4000) := null;'||wwv_flow.LF||
'    l_new_value';
wwv_flow_imp.g_varchar2_table(3) := '   varchar2(4000) := null;'||wwv_flow.LF||
'    l_changed_by  varchar2(255)  := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(4) := '     :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, c';
wwv_flow_imp.g_varchar2_table(5) := 'oalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,s';
wwv_flow_imp.g_varchar2_table(6) := 'ysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_US';
wwv_flow_imp.g_varchar2_table(7) := 'ER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := ';
wwv_flow_imp.g_varchar2_table(8) := 'coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(9) := 'if updating then'||wwv_flow.LF||
'        l_changed_by := lower(:new.updated_by);'||wwv_flow.LF||
''||wwv_flow.LF||
'        if not sp_value_compare.is';
wwv_flow_imp.g_varchar2_table(10) := '_equal(:old.focus_area,:new.focus_area) then'||wwv_flow.LF||
'            insert into sp_init_focus_area_history'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(11) := '            (init_focus_area_id, attribute_column, change_type, old_value, new_value,changed_on, cha';
wwv_flow_imp.g_varchar2_table(12) := 'nged_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.id, ''INITIATIVE_FOCUS_AREA'', ''UPDATE'', :old.focus_';
wwv_flow_imp.g_varchar2_table(13) := 'area, :new.focus_area, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_eq';
wwv_flow_imp.g_varchar2_table(14) := 'ual(:old.external_key,:new.external_key) then'||wwv_flow.LF||
'            insert into sp_init_focus_area_history'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(15) := '             (init_focus_area_id, attribute_column, change_type, old_value, new_value,changed_on, ch';
wwv_flow_imp.g_varchar2_table(16) := 'anged_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.id, ''EXTERNAL_KEY'', ''UPDATE'', :old.external_key, ';
wwv_flow_imp.g_varchar2_table(17) := ':new.external_key, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(';
wwv_flow_imp.g_varchar2_table(18) := ':old.development_owner_id,:new.development_owner_id) then'||wwv_flow.LF||
'            for c1 in (select lower(email)';
wwv_flow_imp.g_varchar2_table(19) := ' r from SP_TEAM_MEMBERS x where x.id = :old.development_owner_id) loop l_old_value := c1.r; end loop';
wwv_flow_imp.g_varchar2_table(20) := ';'||wwv_flow.LF||
'            for c1 in (select lower(email) r from SP_TEAM_MEMBERS x where x.id = :new.development_';
wwv_flow_imp.g_varchar2_table(21) := 'owner_id) loop l_new_value := c1.r; end loop;'||wwv_flow.LF||
'            insert into sp_init_focus_area_history'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(22) := '             (init_focus_area_id, attribute_column, change_type, old_value, new_value,changed_on, ch';
wwv_flow_imp.g_varchar2_table(23) := 'anged_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'                (:new.id, ''DEVELOPMENT_OWNER'', ''UPDATE'', l_old_value, l';
wwv_flow_imp.g_varchar2_table(24) := '_new_value, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.de';
wwv_flow_imp.g_varchar2_table(25) := 'scription,:new.description) then'||wwv_flow.LF||
'            insert into sp_init_focus_area_history'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(26) := '(init_focus_area_id, attribute_column, change_type, old_value, new_value,changed_on, changed_by)'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(27) := '         values'||wwv_flow.LF||
'                (:new.id, ''DESCRIPTION'', ''UPDATE'', :old.description, :new.descriptio';
wwv_flow_imp.g_varchar2_table(28) := 'n, sysdate, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.active_yn,:';
wwv_flow_imp.g_varchar2_table(29) := 'new.active_yn) then'||wwv_flow.LF||
'            insert into sp_init_focus_area_history'||wwv_flow.LF||
'                (init_focus_a';
wwv_flow_imp.g_varchar2_table(30) := 'rea_id, attribute_column, change_type, old_value, new_value,changed_on, changed_by)'||wwv_flow.LF||
'            valu';
wwv_flow_imp.g_varchar2_table(31) := 'es'||wwv_flow.LF||
'                (:new.id, ''ACTIVE'', ''UPDATE'', :old.active_yn, :new.active_yn, sysdate, l_changed_';
wwv_flow_imp.g_varchar2_table(32) := 'by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.display_sequence,:new.display_seq';
wwv_flow_imp.g_varchar2_table(33) := 'uence) then'||wwv_flow.LF||
'            insert into sp_init_focus_area_history'||wwv_flow.LF||
'                (init_focus_area_id, ';
wwv_flow_imp.g_varchar2_table(34) := 'attribute_column, change_type, old_value, new_value,changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(35) := '           (:new.id, ''DISPLAY_SEQUENCE'', ''UPDATE'', :old.display_sequence, :new.display_sequence, sys';
wwv_flow_imp.g_varchar2_table(36) := 'date, l_changed_by);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_initiative_focus_areas_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or repl';
wwv_flow_imp.g_varchar2_table(37) := 'ace trigger sp_initiative_focus_areas_ai'||wwv_flow.LF||
'    after insert'||wwv_flow.LF||
'    on sp_initiative_focus_areas'||wwv_flow.LF||
'    for e';
wwv_flow_imp.g_varchar2_table(38) := 'ach row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_init_focus_area_history'||wwv_flow.LF||
'        (init_focus_area_id, attribute_colu';
wwv_flow_imp.g_varchar2_table(39) := 'mn, change_type, new_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:new.id, ''INITIATIVE_FOCUS_A';
wwv_flow_imp.g_varchar2_table(40) := 'REA'', ''CREATE'', :new.focus_area, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'end sp_initiative_focus_areas_ai;';
wwv_flow_imp.g_varchar2_table(41) := ''||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger sp_initiative_focus_areas_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_initiative_foc';
wwv_flow_imp.g_varchar2_table(42) := 'us_areas'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    insert into sp_init_focus_area_history'||wwv_flow.LF||
'        (init_focus_area_';
wwv_flow_imp.g_varchar2_table(43) := 'id, attribute_column, change_type, old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.id, ''';
wwv_flow_imp.g_varchar2_table(44) := 'INITIATIVE_FOCUS_AREA'', ''DELETE'', :old.focus_area, sysdate, lower(coalesce(sys_context(''APEX$SESSION';
wwv_flow_imp.g_varchar2_table(45) := ''',''APP_USER''),user)));'||wwv_flow.LF||
'end sp_initiative_focus_areas_bd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_init_focus';
wwv_flow_imp.g_varchar2_table(46) := '_area_links_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_init_focus_area_links'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(47) := '   if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by :';
wwv_flow_imp.g_varchar2_table(48) := '= nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated ';
wwv_flow_imp.g_varchar2_table(49) := '   := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(sys_contex';
wwv_flow_imp.g_varchar2_table(50) := 't(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(51) := '     :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(52) := '  -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if sp_globals.g_audit_this then'||wwv_flow.LF||
'        update sp_initiative_focu';
wwv_flow_imp.g_varchar2_table(53) := 's_areas set updated = sysdate, updated_by = :new.updated_by where id = :new.init_focus_area_id;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(54) := 'end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        insert into sp_init_focus_area_hi';
wwv_flow_imp.g_varchar2_table(55) := 'story'||wwv_flow.LF||
'            (init_focus_area_id, attribute_column, change_type, new_value, changed_on, changed';
wwv_flow_imp.g_varchar2_table(56) := '_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.init_focus_area_id, ''LINK'', ''CREATE'', :new.link_url, sysdate, ';
wwv_flow_imp.g_varchar2_table(57) := 'lower(:new.created_by));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        if not sp_value_compare.is_equal(:old.link_';
wwv_flow_imp.g_varchar2_table(58) := 'url,:new.link_url) then'||wwv_flow.LF||
'            insert into sp_init_focus_area_history'||wwv_flow.LF||
'                (init_foc';
wwv_flow_imp.g_varchar2_table(59) := 'us_area_id, attribute_column, change_type, old_value, new_value,changed_on, changed_by)'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(60) := 'values'||wwv_flow.LF||
'                (:new.init_focus_area_id, ''LINK'', ''UPDATE'', :old.link_url, :new.link_url, sys';
wwv_flow_imp.g_varchar2_table(61) := 'date, lower(:new.updated_by));'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_init_focus_area_links_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'cr';
wwv_flow_imp.g_varchar2_table(62) := 'eate or replace trigger sp_init_focus_area_links_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_init_focus_area_link';
wwv_flow_imp.g_varchar2_table(63) := 's'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_initiative_focus_area';
wwv_flow_imp.g_varchar2_table(64) := 's set updated = sysdate, updated_by = :old.updated_by where id = :old.init_focus_area_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(65) := ' insert into sp_init_focus_area_history'||wwv_flow.LF||
'        (init_focus_area_id, attribute_column, change_type, ';
wwv_flow_imp.g_varchar2_table(66) := 'old_value, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.init_focus_area_id, ''LINK'', ''DELETE'', :o';
wwv_flow_imp.g_varchar2_table(67) := 'ld.link_url, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'end sp_init_foc';
wwv_flow_imp.g_varchar2_table(68) := 'us_area_links_bd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'	'||wwv_flow.LF||
'create or replace trigger sp_init_focus_area_documents_biu'||wwv_flow.LF||
'    before insert ';
wwv_flow_imp.g_varchar2_table(69) := 'or update'||wwv_flow.LF||
'    on sp_init_focus_area_documents'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_tags varchar2(4000) := ';
wwv_flow_imp.g_varchar2_table(70) := 'null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new';
wwv_flow_imp.g_varchar2_table(71) := '.created_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(72) := ':new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coales';
wwv_flow_imp.g_varchar2_table(73) := 'ce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    :=';
wwv_flow_imp.g_varchar2_table(74) := ' sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end ';
wwv_flow_imp.g_varchar2_table(75) := 'if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.tags := upper(:new.tags);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(76) := '    if sp_globals.g_audit_this then'||wwv_flow.LF||
'        update sp_initiative_focus_areas set updated = sysdate, ';
wwv_flow_imp.g_varchar2_table(77) := 'updated_by = :new.updated_by where id = :new.init_focus_area_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- adjust ta';
wwv_flow_imp.g_varchar2_table(78) := 'g data'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.tags is not null then'||wwv_flow.LF||
'        l_tags := trim(upper(:new.tags));'||wwv_flow.LF||
'        --';
wwv_flow_imp.g_varchar2_table(79) := ' remove multiple spaces'||wwv_flow.LF||
'        if instr(l_tags,''  '') > 0 then'||wwv_flow.LF||
'            for j in 1..10 loop '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(80) := '            l_tags := replace(l_tags,''  '','' ''); '||wwv_flow.LF||
'                if instr(l_tags,''  '') = 0 then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(81) := '               exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        for i in';
wwv_flow_imp.g_varchar2_table(82) := ' 1..length(l_tags) loop'||wwv_flow.LF||
'            if i > 2 and substr(l_tags,i,1) = '' '' and substr(l_tags,i-1,1) !';
wwv_flow_imp.g_varchar2_table(83) := '= '','' then'||wwv_flow.LF||
'               l_tags := substr(l_tags,1,i-1)||''-''||substr(l_tags,i+1);'||wwv_flow.LF||
'            end i';
wwv_flow_imp.g_varchar2_table(84) := 'f;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        :new.tags := l_tags;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if ins';
wwv_flow_imp.g_varchar2_table(85) := 'erting then'||wwv_flow.LF||
'        insert into sp_init_focus_area_history'||wwv_flow.LF||
'            (init_focus_area_id, attribut';
wwv_flow_imp.g_varchar2_table(86) := 'e_column, change_type, new_value, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.init_focu';
wwv_flow_imp.g_varchar2_table(87) := 's_area_id, ''DOCUMENT'', ''CREATE'', :new.DOCUMENT_FILENAME, sysdate, lower(:new.created_by));'||wwv_flow.LF||
'    elsif';
wwv_flow_imp.g_varchar2_table(88) := ' updating then '||wwv_flow.LF||
'        insert into sp_init_focus_area_history'||wwv_flow.LF||
'            (init_focus_area_id, attr';
wwv_flow_imp.g_varchar2_table(89) := 'ibute_column, change_type, old_value, new_value, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(90) := '(:new.init_focus_area_id, ''DOCUMENT'', ''UPDATE'', :old.DOCUMENT_FILENAME, :new.DOCUMENT_FILENAME, sysd';
wwv_flow_imp.g_varchar2_table(91) := 'ate, lower(:new.updated_by));'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_init_focus_area_documents_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace';
wwv_flow_imp.g_varchar2_table(92) := ' trigger sp_init_focus_area_documents_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_init_focus_area_documents'||wwv_flow.LF||
'    f';
wwv_flow_imp.g_varchar2_table(93) := 'or each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    update sp_initiative_focus_areas set u';
wwv_flow_imp.g_varchar2_table(94) := 'pdated = sysdate, updated_by = :old.updated_by where id = :old.init_focus_area_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    insert';
wwv_flow_imp.g_varchar2_table(95) := ' into sp_init_focus_area_history'||wwv_flow.LF||
'        (init_focus_area_id, attribute_column, change_type, old_val';
wwv_flow_imp.g_varchar2_table(96) := 'ue, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (:old.init_focus_area_id, ''DOCUMENT'', ''DELETE'', :old.';
wwv_flow_imp.g_varchar2_table(97) := 'document_filename, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'end sp_in';
wwv_flow_imp.g_varchar2_table(98) := 'it_focus_area_documents_bd;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_init_focus_area_comments_biu'||wwv_flow.LF||
'    before';
wwv_flow_imp.g_varchar2_table(99) := ' insert or update'||wwv_flow.LF||
'    on sp_init_focus_area_comments'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(100) := '      :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, ';
wwv_flow_imp.g_varchar2_table(101) := 'coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,';
wwv_flow_imp.g_varchar2_table(102) := 'sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_U';
wwv_flow_imp.g_varchar2_table(103) := 'SER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by :=';
wwv_flow_imp.g_varchar2_table(104) := ' coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(105) := '     for c1 in (select nvl(max(comment_nbr),0) cnbr from sp_init_focus_area_comments where init_focu';
wwv_flow_imp.g_varchar2_table(106) := 's_area_id = :new.init_focus_area_id)'||wwv_flow.LF||
'        loop :new.comment_nbr := c1.cnbr+1; end loop;'||wwv_flow.LF||
'    end i';
wwv_flow_imp.g_varchar2_table(107) := 'f;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.private_yn is null then '||wwv_flow.LF||
'        :new.private_yn := ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(108) := '  -- touch parent table'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if sp_globals.g_audit_this then'||wwv_flow.LF||
'        update sp_initiative_focu';
wwv_flow_imp.g_varchar2_table(109) := 's_areas set updated = sysdate, updated_by = :new.updated_by where id = :new.init_focus_area_id;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(110) := 'end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- history'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if inserting and :new.private_yn = ''N'' then'||wwv_flow.LF||
'        insert ';
wwv_flow_imp.g_varchar2_table(111) := 'into sp_init_focus_area_history'||wwv_flow.LF||
'            (init_focus_area_id, attribute_column, change_type, new_';
wwv_flow_imp.g_varchar2_table(112) := 'value, new_value_clob, changed_on, changed_by)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'            (:new.init_focus_area_id, ';
wwv_flow_imp.g_varchar2_table(113) := '''COMMENT'', ''CREATE'', dbms_lob.substr(:new.body_no_images,500,1), :new.body_no_images, sysdate, lower';
wwv_flow_imp.g_varchar2_table(114) := '(:new.created_by));'||wwv_flow.LF||
'    elsif updating and :old.private_yn = ''N'' and :new.private_yn = ''N'' then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(115) := '    if not sp_value_compare.is_equal(:old.body_no_images,:new.body_no_images) then'||wwv_flow.LF||
'            inser';
wwv_flow_imp.g_varchar2_table(116) := 't into sp_init_focus_area_history'||wwv_flow.LF||
'                (init_focus_area_id, attribute_column, change_type';
wwv_flow_imp.g_varchar2_table(117) := ', old_value, new_value, old_value_clob, new_value_clob, changed_on, changed_by)'||wwv_flow.LF||
'            values'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(118) := '               (:new.init_focus_area_id, ''COMMENT'', ''UPDATE'', dbms_lob.substr(:old.body_no_images,50';
wwv_flow_imp.g_varchar2_table(119) := '0,1), dbms_lob.substr(:new.body_no_images,500,1), :old.body_no_images, :new.body_no_images, sysdate,';
wwv_flow_imp.g_varchar2_table(120) := ' lower(:new.updated_by));'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_init_focus_area_comments_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create';
wwv_flow_imp.g_varchar2_table(121) := ' or replace trigger sp_init_focus_area_comments_bd'||wwv_flow.LF||
'    before delete'||wwv_flow.LF||
'    on sp_init_focus_area_comme';
wwv_flow_imp.g_varchar2_table(122) := 'nts'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :old.private_yn = ''N'' then'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- touch parent table'||wwv_flow.LF||
'    --';
wwv_flow_imp.g_varchar2_table(123) := ''||wwv_flow.LF||
'    update sp_initiative_focus_areas set updated = sysdate, updated_by = :old.updated_by where id =';
wwv_flow_imp.g_varchar2_table(124) := ' :old.init_focus_area_id;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    insert into sp_init_focus_area_history'||wwv_flow.LF||
'        (init_focus_area';
wwv_flow_imp.g_varchar2_table(125) := '_id, attribute_column, change_type, old_value, old_value_clob, changed_on, changed_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(126) := '      (:old.init_focus_area_id, ''COMMENT'', ''DELETE'', dbms_lob.substr(:old.body_no_images,500,1), :ol';
wwv_flow_imp.g_varchar2_table(127) := 'd.body_no_images, sysdate, lower(coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user)));'||wwv_flow.LF||
'    end if';
wwv_flow_imp.g_varchar2_table(128) := ';'||wwv_flow.LF||
'end sp_init_focus_area_comments_bd;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(53804463742521797528)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_initiative_focus_areas triggers'
,p_sequence=>4080
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
