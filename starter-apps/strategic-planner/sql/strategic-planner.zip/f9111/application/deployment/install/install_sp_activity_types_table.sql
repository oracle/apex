prompt --application/deployment/install/install_sp_activity_types_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_activity_types table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_activity_types ('||wwv_flow.LF||
'    id                             number default on null to_number';
wwv_flow_imp.g_varchar2_table(2) := '(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_a';
wwv_flow_imp.g_varchar2_table(3) := 'ctivity_types_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    display_sequence               number not null,'||wwv_flow.LF||
'    activit';
wwv_flow_imp.g_varchar2_table(4) := 'y_type                  varchar2(50 char) not null,'||wwv_flow.LF||
'    activity_type_description      varchar2(4000';
wwv_flow_imp.g_varchar2_table(5) := ' char),'||wwv_flow.LF||
'    static_id                      varchar2(30 char),'||wwv_flow.LF||
'    is_default_yn                  var';
wwv_flow_imp.g_varchar2_table(6) := 'char2(1 char),'||wwv_flow.LF||
'    is_active_yn                   varchar2(1 char),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created              ';
wwv_flow_imp.g_varchar2_table(7) := '          date not null,'||wwv_flow.LF||
'    created_by                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated';
wwv_flow_imp.g_varchar2_table(8) := '                        date not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255 char) not nul';
wwv_flow_imp.g_varchar2_table(9) := 'l'||wwv_flow.LF||
');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(50990974132188838076)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_activity_types table'
,p_sequence=>3400
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
