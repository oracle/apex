prompt --application/deployment/install/install_seed_first_user
begin
--   Manifest
--     INSTALL: INSTALL-seed first user
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'declare'||wwv_flow.LF||
'    l_app_user     varchar2(255) := apex_custom_auth.get_username;'||wwv_flow.LF||
'    l_app_user_id  number';
wwv_flow_imp.g_varchar2_table(2) := ';'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- get email of developer installing the app'||wwv_flow.LF||
'    -- if no email, see if app_user ';
wwv_flow_imp.g_varchar2_table(3) := 'is an email'||wwv_flow.LF||
'    -- (first autonomous user may not have an email)'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for u in ('||wwv_flow.LF||
'        selec';
wwv_flow_imp.g_varchar2_table(4) := 't first_name, last_name,'||wwv_flow.LF||
'               case when email is null and regexp_like(l_app_user,''[a-z0-9.';
wwv_flow_imp.g_varchar2_table(5) := '_%+-]+@[a-z0-9.-]+\.[a-z]{2,4}'')'||wwv_flow.LF||
'                    then l_app_user'||wwv_flow.LF||
'                    else email'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(6) := '                    end email'||wwv_flow.LF||
'          from apex_workspace_apex_users'||wwv_flow.LF||
'         where user_name = l_';
wwv_flow_imp.g_varchar2_table(7) := 'app_user'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'      if u.email is not null then'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        -- most recent install of S';
wwv_flow_imp.g_varchar2_table(8) := 'trategic Planner'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        for a in ('||wwv_flow.LF||
'            select application_id'||wwv_flow.LF||
'              from ';
wwv_flow_imp.g_varchar2_table(9) := 'apex_applications'||wwv_flow.LF||
'             where application_name = ''Strategic Planner'''||wwv_flow.LF||
'             order by la';
wwv_flow_imp.g_varchar2_table(10) := 'st_updated_on desc'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            -- determine admin app role id'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(11) := '    --'||wwv_flow.LF||
'            for r in ('||wwv_flow.LF||
'                select role_id'||wwv_flow.LF||
'                  from apex_appl_acl_ro';
wwv_flow_imp.g_varchar2_table(12) := 'les'||wwv_flow.LF||
'                 where application_id = a.application_id '||wwv_flow.LF||
'                   and role_static_id ';
wwv_flow_imp.g_varchar2_table(13) := '= ''ADMINISTRATOR'''||wwv_flow.LF||
'            ) loop'||wwv_flow.LF||
'                --'||wwv_flow.LF||
'                -- make installer an app adm';
wwv_flow_imp.g_varchar2_table(14) := 'in'||wwv_flow.LF||
'                --'||wwv_flow.LF||
'                apex_acl.add_user_role ('||wwv_flow.LF||
'            	    p_application_id => ';
wwv_flow_imp.g_varchar2_table(15) := 'a.application_id,'||wwv_flow.LF||
'            	    p_user_name      => u.email,'||wwv_flow.LF||
'           	    p_role_id        => ';
wwv_flow_imp.g_varchar2_table(16) := 'r.role_id );'||wwv_flow.LF||
'                commit;'||wwv_flow.LF||
'                --'||wwv_flow.LF||
'                -- also add this first user ';
wwv_flow_imp.g_varchar2_table(17) := 'as a Team Member'||wwv_flow.LF||
'                --'||wwv_flow.LF||
'                insert into SP_TEAM_MEMBERS '||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(18) := ' (email, first_name, last_name) '||wwv_flow.LF||
'                values '||wwv_flow.LF||
'                    (u.email, u.first_name,';
wwv_flow_imp.g_varchar2_table(19) := ' u.last_name)'||wwv_flow.LF||
'                returning id into l_app_user_id;'||wwv_flow.LF||
'                commit;'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(20) := '   insert into sp_activities'||wwv_flow.LF||
'                    (id, activity_type_id, team_member_id, start_date, ';
wwv_flow_imp.g_varchar2_table(21) := 'end_date, activity)'||wwv_flow.LF||
'                    values'||wwv_flow.LF||
'                    (1, 3, l_app_user_id, sysdate, sy';
wwv_flow_imp.g_varchar2_table(22) := 'sdate+7, ''Review Strategic Planner features and then remove demo data'');'||wwv_flow.LF||
'                exit;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(23) := '       end loop;'||wwv_flow.LF||
'            exit;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(47697610704689532526)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed first user'
,p_sequence=>9900
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
