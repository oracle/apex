prompt --application/deployment/install/install_sp_configurable_text_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_configurable_text table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_configurable_text ('||wwv_flow.LF||
'    id                   number default on null to_number(sys_gu';
wwv_flow_imp.g_varchar2_table(2) := 'id(), ''xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'') not null, '||wwv_flow.LF||
'    config_id            varchar2(50 char) not ';
wwv_flow_imp.g_varchar2_table(3) := 'null,'||wwv_flow.LF||
'    description          varchar2(4000 char) not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    configurable_content clob,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(4) := '   --'||wwv_flow.LF||
'    created              date not null, '||wwv_flow.LF||
'    created_by           varchar2(255 char) not null,';
wwv_flow_imp.g_varchar2_table(5) := ' '||wwv_flow.LF||
'    updated              date not null, '||wwv_flow.LF||
'    updated_by           varchar2(255 char) not null'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(6) := ') '||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_configurable_text_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_confi';
wwv_flow_imp.g_varchar2_table(7) := 'gurable_text'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.create';
wwv_flow_imp.g_varchar2_table(8) := 'd,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP';
wwv_flow_imp.g_varchar2_table(9) := '_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl';
wwv_flow_imp.g_varchar2_table(10) := '(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(11) := '      :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''AP';
wwv_flow_imp.g_varchar2_table(12) := 'P_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_configurable_text_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(39187982706000043550)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_configurable_text table and trigger'
,p_sequence=>3430
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
