prompt --application/deployment/install/install_sp_events_table_and_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_events table and trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- HOLDS ALL EVENTS BY DAY (RECURRENCE DETAILS IN SERIES)'||wwv_flow.LF||
'create table sp_events ('||wwv_flow.LF||
'    id           ';
wwv_flow_imp.g_varchar2_table(2) := '             number'||wwv_flow.LF||
'                                default on null to_number(sys_guid(), ''XXXXXXXXX';
wwv_flow_imp.g_varchar2_table(3) := 'XXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                constraint sp_events_pk primary key,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(4) := 'event_type_id             number  not null'||wwv_flow.LF||
'                                constraint sp_events_type';
wwv_flow_imp.g_varchar2_table(5) := '_fk'||wwv_flow.LF||
'                                references sp_event_types,'||wwv_flow.LF||
'    event_date                timesta';
wwv_flow_imp.g_varchar2_table(6) := 'mp with time zone  not null,'||wwv_flow.LF||
'    event_name                varchar2(255),'||wwv_flow.LF||
'    for_user_id           ';
wwv_flow_imp.g_varchar2_table(7) := '    number'||wwv_flow.LF||
'                                constraint sp_events_for_user_fk'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(8) := '        references sp_team_members,'||wwv_flow.LF||
'    event_details             varchar2(4000),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    series_';
wwv_flow_imp.g_varchar2_table(9) := 'id                 number'||wwv_flow.LF||
'                                constraint sp_events_series_fk'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(10) := '                     references sp_event_series,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                   date          ';
wwv_flow_imp.g_varchar2_table(11) := '  not null,'||wwv_flow.LF||
'    created_by                varchar2(255)   not null,'||wwv_flow.LF||
'    updated                   da';
wwv_flow_imp.g_varchar2_table(12) := 'te            not null,'||wwv_flow.LF||
'    updated_by                varchar2(255)   not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_e';
wwv_flow_imp.g_varchar2_table(13) := 'vents_i1 on sp_events (event_type_id);'||wwv_flow.LF||
'create index sp_events_i2 on sp_events (for_user_id);'||wwv_flow.LF||
'create ';
wwv_flow_imp.g_varchar2_table(14) := 'index sp_events_i3 on sp_events (series_id);'||wwv_flow.LF||
'create index sp_events_i4 on sp_events (event_date);'||wwv_flow.LF||
''||wwv_flow.LF||
'c';
wwv_flow_imp.g_varchar2_table(15) := 'reate or replace trigger sp_events_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_events'||wwv_flow.LF||
'    for each row';
wwv_flow_imp.g_varchar2_table(16) := ''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.crea';
wwv_flow_imp.g_varchar2_table(17) := 'ted_by := nvl(:new.created_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.';
wwv_flow_imp.g_varchar2_table(18) := 'updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(sy';
wwv_flow_imp.g_varchar2_table(19) := 's_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysd';
wwv_flow_imp.g_varchar2_table(20) := 'ate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'e';
wwv_flow_imp.g_varchar2_table(21) := 'nd sp_events_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(35719255047475881827)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_events table and trigger'
,p_sequence=>3110
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
