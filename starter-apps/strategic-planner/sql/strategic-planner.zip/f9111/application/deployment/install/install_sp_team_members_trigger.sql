prompt --application/deployment/install/install_sp_team_members_trigger
begin
--   Manifest
--     INSTALL: INSTALL-sp_team_members trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger sp_team_members_biu'||wwv_flow.LF||
'    before insert or update'||wwv_flow.LF||
'    on sp_team_members'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(2) := ' for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    b integer := 0; -- first dot occurrance'||wwv_flow.LF||
'    e integer := 0; -- first at si';
wwv_flow_imp.g_varchar2_table(3) := 'gn occurrance'||wwv_flow.LF||
'    l integer := 0; -- length between dot and at sign'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(4) := '    :new.created    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, co';
wwv_flow_imp.g_varchar2_table(5) := 'alesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sy';
wwv_flow_imp.g_varchar2_table(6) := 'sdate);'||wwv_flow.LF||
'        :new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USE';
wwv_flow_imp.g_varchar2_table(7) := 'R''),user));'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := c';
wwv_flow_imp.g_varchar2_table(8) := 'oalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.email := lower(:ne';
wwv_flow_imp.g_varchar2_table(9) := 'w.email);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.screen_name := lower(:new.screen_name);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if :new.is_current_yn i';
wwv_flow_imp.g_varchar2_table(10) := 's null then'||wwv_flow.LF||
'       :new.is_current_yn := ''Y'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    b := instr(:new.email,''.'');'||wwv_flow.LF||
'    e := i';
wwv_flow_imp.g_varchar2_table(11) := 'nstr(:new.email,''@'');'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.email_domain := substr(:new.email,e+1);'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if e > 2 an';
wwv_flow_imp.g_varchar2_table(12) := 'd b > 1 and :new.first_name is null and :new.last_name is null then'||wwv_flow.LF||
'       l := (e - b) - 1;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(13) := 'if b < e and l > 0 then'||wwv_flow.LF||
'           :new.first_name := initcap(substr(:new.email,1,b-1));'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(14) := ':new.last_name  := initcap(substr(:new.email,b+1,l));'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.initial';
wwv_flow_imp.g_varchar2_table(15) := 's is null and :new.first_name is not null and :new.last_name is not null then'||wwv_flow.LF||
'        :new.initials ';
wwv_flow_imp.g_varchar2_table(16) := ':= nvl(substr(:new.first_name,1,1)||substr(:new.last_name,1,1),''X'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.initial';
wwv_flow_imp.g_varchar2_table(17) := 's is null then'||wwv_flow.LF||
'       :new.initials := ''AA'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.first_name is null then '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(18) := ' :new.first_name := ''unknown'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.last_name is null then'||wwv_flow.LF||
'       :new.last_name ';
wwv_flow_imp.g_varchar2_table(19) := ':= ''unknown'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- tags'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    :new.tags := upper(:new.tags);'||wwv_flow.LF||
''||wwv_flow.LF||
'end sp_team_';
wwv_flow_imp.g_varchar2_table(20) := 'members_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(41435377846911228647)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_team_members trigger'
,p_sequence=>4030
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
