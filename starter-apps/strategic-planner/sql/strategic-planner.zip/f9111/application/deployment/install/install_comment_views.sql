prompt --application/deployment/install/install_comment_views
begin
--   Manifest
--     INSTALL: INSTALL-comment views
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace view sp_initiative_comments_v as'||wwv_flow.LF||
'select id, '||wwv_flow.LF||
'       initiative_id,'||wwv_flow.LF||
'       comment_';
wwv_flow_imp.g_varchar2_table(2) := 'nbr,'||wwv_flow.LF||
'       sp_comment_util.replace_session_on_display(body, sys_context(''APEX$SESSION'', ''APP_SESSIO';
wwv_flow_imp.g_varchar2_table(3) := 'N'') ) body,'||wwv_flow.LF||
'       sp_comment_util.replace_session_on_display(body_html, sys_context(''APEX$SESSION'',';
wwv_flow_imp.g_varchar2_table(4) := ' ''APP_SESSION'') ) body_html,'||wwv_flow.LF||
'       body_no_images, '||wwv_flow.LF||
'       author_id, private_yn,'||wwv_flow.LF||
'       image_ref_';
wwv_flow_imp.g_varchar2_table(5) := 'id,'||wwv_flow.LF||
'       created, created_by, updated, updated_by'||wwv_flow.LF||
'  from sp_initiative_comments;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or repla';
wwv_flow_imp.g_varchar2_table(6) := 'ce view sp_init_focus_area_comments_v as'||wwv_flow.LF||
'select id, '||wwv_flow.LF||
'       init_focus_area_id,'||wwv_flow.LF||
'       comment_nbr,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(7) := '       sp_comment_util.replace_session_on_display(body, sys_context(''APEX$SESSION'', ''APP_SESSION'') )';
wwv_flow_imp.g_varchar2_table(8) := ' body,'||wwv_flow.LF||
'       sp_comment_util.replace_session_on_display(body_html, sys_context(''APEX$SESSION'', ''APP';
wwv_flow_imp.g_varchar2_table(9) := '_SESSION'') ) body_html,'||wwv_flow.LF||
'       body_no_images, '||wwv_flow.LF||
'       author_id, private_yn,'||wwv_flow.LF||
'       image_ref_id,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(10) := '      created, created_by, updated, updated_by'||wwv_flow.LF||
'  from sp_init_focus_area_comments;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or repla';
wwv_flow_imp.g_varchar2_table(11) := 'ce view sp_project_comments_v as'||wwv_flow.LF||
'select id, '||wwv_flow.LF||
'       project_id,'||wwv_flow.LF||
'       comment_nbr,'||wwv_flow.LF||
'       sp_commen';
wwv_flow_imp.g_varchar2_table(12) := 't_util.replace_session_on_display(body, sys_context(''APEX$SESSION'', ''APP_SESSION'') ) body,'||wwv_flow.LF||
'       sp';
wwv_flow_imp.g_varchar2_table(13) := '_comment_util.replace_session_on_display(body_html, sys_context(''APEX$SESSION'', ''APP_SESSION'') ) bod';
wwv_flow_imp.g_varchar2_table(14) := 'y_html,'||wwv_flow.LF||
'       body_no_images, '||wwv_flow.LF||
'       author_id, private_yn,'||wwv_flow.LF||
'       image_ref_id,'||wwv_flow.LF||
'       created, c';
wwv_flow_imp.g_varchar2_table(15) := 'reated_by, updated, updated_by'||wwv_flow.LF||
'  from sp_project_comments;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace view sp_task_comments';
wwv_flow_imp.g_varchar2_table(16) := '_v as'||wwv_flow.LF||
'select id, '||wwv_flow.LF||
'       task_id,'||wwv_flow.LF||
'       comment_nbr,'||wwv_flow.LF||
'       sp_comment_util.replace_session_on_disp';
wwv_flow_imp.g_varchar2_table(17) := 'lay(body, sys_context(''APEX$SESSION'', ''APP_SESSION'') ) body,'||wwv_flow.LF||
'       sp_comment_util.replace_session_';
wwv_flow_imp.g_varchar2_table(18) := 'on_display(body_html, sys_context(''APEX$SESSION'', ''APP_SESSION'') ) body_html,'||wwv_flow.LF||
'       body_no_images,';
wwv_flow_imp.g_varchar2_table(19) := ' '||wwv_flow.LF||
'       author_id, private_yn,'||wwv_flow.LF||
'       image_ref_id,'||wwv_flow.LF||
'       created, created_by, updated, updated_by';
wwv_flow_imp.g_varchar2_table(20) := ''||wwv_flow.LF||
'  from sp_task_comments;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace view sp_release_comments_v as'||wwv_flow.LF||
'select id, '||wwv_flow.LF||
'       relea';
wwv_flow_imp.g_varchar2_table(21) := 'se_id,'||wwv_flow.LF||
'       comment_nbr,'||wwv_flow.LF||
'       sp_comment_util.replace_session_on_display(body, sys_context(''APEX';
wwv_flow_imp.g_varchar2_table(22) := '$SESSION'', ''APP_SESSION'') ) body,'||wwv_flow.LF||
'       sp_comment_util.replace_session_on_display(body_html, sys_c';
wwv_flow_imp.g_varchar2_table(23) := 'ontext(''APEX$SESSION'', ''APP_SESSION'') ) body_html,'||wwv_flow.LF||
'       body_no_images, '||wwv_flow.LF||
'       author_id, private';
wwv_flow_imp.g_varchar2_table(24) := '_yn,'||wwv_flow.LF||
'       image_ref_id,'||wwv_flow.LF||
'       created, created_by, updated, updated_by'||wwv_flow.LF||
'  from sp_release_comments';
wwv_flow_imp.g_varchar2_table(25) := ';';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(23777722229995146087)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'comment views'
,p_sequence=>5010
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
