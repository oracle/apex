prompt --application/deployment/install/install_sp_project_comments_table
begin
--   Manifest
--     INSTALL: INSTALL-sp_project_comments table
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_project_comments ('||wwv_flow.LF||
'    id                             number default on null to_numb';
wwv_flow_imp.g_varchar2_table(2) := 'er(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp';
wwv_flow_imp.g_varchar2_table(3) := '_project_comments_id_pk primary key,'||wwv_flow.LF||
'    project_id                     number'||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(4) := '              constraint sp_project_comm_proj_id_fk'||wwv_flow.LF||
'                                   references sp';
wwv_flow_imp.g_varchar2_table(5) := '_projects on delete cascade,'||wwv_flow.LF||
'    comment_nbr                    number,'||wwv_flow.LF||
'    body                    ';
wwv_flow_imp.g_varchar2_table(6) := '       clob,'||wwv_flow.LF||
'    body_html                      clob,'||wwv_flow.LF||
'    body_no_images                 clob,'||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(7) := 'mage_ref_id                   number,'||wwv_flow.LF||
'    private_yn                     varchar2(1 char)'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(8) := '                         default on null ''Y'''||wwv_flow.LF||
'                                   constraint sp_projec';
wwv_flow_imp.g_varchar2_table(9) := 't_comm_private_ck'||wwv_flow.LF||
'                                   check (private_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    author_id ';
wwv_flow_imp.g_varchar2_table(10) := '                     number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by';
wwv_flow_imp.g_varchar2_table(11) := '                     varchar2(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(12) := '    updated_by                     varchar2(255 char) not null'||wwv_flow.LF||
')'||wwv_flow.LF||
';'||wwv_flow.LF||
''||wwv_flow.LF||
'create index sp_project_comments';
wwv_flow_imp.g_varchar2_table(13) := '_i1 on sp_project_comments (project_id);'||wwv_flow.LF||
'create index sp_project_comments_i2 on sp_project_comments ';
wwv_flow_imp.g_varchar2_table(14) := '(author_id);'||wwv_flow.LF||
'create index sp_project_comments_i3 on sp_project_comments (updated);'||wwv_flow.LF||
'create index sp_p';
wwv_flow_imp.g_varchar2_table(15) := 'roject_comments_i4 on sp_project_comments (image_ref_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create table sp_project_comments_emails (';
wwv_flow_imp.g_varchar2_table(16) := ''||wwv_flow.LF||
'    id                             number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(17) := 'XXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                   constraint sp_proj_comment_em_id_pk primary key';
wwv_flow_imp.g_varchar2_table(18) := ','||wwv_flow.LF||
'    comment_id                     number'||wwv_flow.LF||
'                                   constraint sp_proj_co';
wwv_flow_imp.g_varchar2_table(19) := 'mment_em_id_fk'||wwv_flow.LF||
'                                   references sp_project_comments (id)'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(20) := '                     on delete cascade,'||wwv_flow.LF||
'    email                          varchar2(255 char)'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'cr';
wwv_flow_imp.g_varchar2_table(21) := 'eate index sp_project_comm_emails_i1 on sp_project_comments_emails (comment_id);'||wwv_flow.LF||
'create index sp_pro';
wwv_flow_imp.g_varchar2_table(22) := 'ject_comm_emails_i2 on sp_project_comments_emails (email);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38667683472379490690)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_project_comments table'
,p_sequence=>3290
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
