prompt --application/deployment/install/install_sp_log_body
begin
--   Manifest
--     INSTALL: INSTALL-sp_log body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body sp_log '||wwv_flow.LF||
'as  '||wwv_flow.LF||
'procedure log_interaction ('||wwv_flow.LF||
'    p_project_id in number) ';
wwv_flow_imp.g_varchar2_table(2) := ''||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_action varchar2(50) := null;'||wwv_flow.LF||
'    l_page   number := to_number(v(''APP_PAGE_ID''));'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(3) := '  --'||wwv_flow.LF||
'    -- determine action based on page'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    if    l_page = 3   then l_action := ''detail vi';
wwv_flow_imp.g_varchar2_table(4) := 'ew''; '||wwv_flow.LF||
'    elsif l_page = 6   then l_action := ''edit link'';'||wwv_flow.LF||
'    elsif l_page = 9   then l_action := ''';
wwv_flow_imp.g_varchar2_table(5) := 'edit contributor'';'||wwv_flow.LF||
'    elsif l_page = 10  then l_action := ''edit related'';'||wwv_flow.LF||
'    elsif l_page = 12  th';
wwv_flow_imp.g_varchar2_table(6) := 'en l_action := ''add/edit document'';'||wwv_flow.LF||
'    elsif l_page = 24  then l_action := ''edit project'';'||wwv_flow.LF||
'    elsi';
wwv_flow_imp.g_varchar2_table(7) := 'f l_page = 28  then l_action := ''edit comment'';'||wwv_flow.LF||
'    elsif l_page = 32  then l_action := ''edit descri';
wwv_flow_imp.g_varchar2_table(8) := 'ption'';'||wwv_flow.LF||
'    elsif l_page = 36  then l_action := ''quick look'';'||wwv_flow.LF||
'    elsif l_page = 47  then l_action :';
wwv_flow_imp.g_varchar2_table(9) := '= ''archive'';'||wwv_flow.LF||
'    elsif l_page = 49  then l_action := ''mark as duplicate'';'||wwv_flow.LF||
'    elsif l_page = 64  the';
wwv_flow_imp.g_varchar2_table(10) := 'n l_action := ''view change history'';'||wwv_flow.LF||
'    elsif l_page = 82  then l_action := ''view tag history'';'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(11) := ' elsif l_page = 96  then l_action := ''view description history'';'||wwv_flow.LF||
'    elsif l_page = 101 then l_actio';
wwv_flow_imp.g_varchar2_table(12) := 'n := ''edit activity'';    '||wwv_flow.LF||
'    elsif l_page = 136 then l_action := ''view description'';'||wwv_flow.LF||
'    elsif l_pa';
wwv_flow_imp.g_varchar2_table(13) := 'ge = 501 then l_action := ''task'';'||wwv_flow.LF||
'    elsif l_page = 502 then l_action := ''task details'';'||wwv_flow.LF||
'    elsif ';
wwv_flow_imp.g_varchar2_table(14) := 'l_page = 503 then l_action := ''edit task comment'';   '||wwv_flow.LF||
'    elsif l_page = 504 then l_action := ''edit ';
wwv_flow_imp.g_varchar2_table(15) := 'task document''; '||wwv_flow.LF||
'    elsif l_page = 506 then l_action := ''edit task link''; '||wwv_flow.LF||
'    elsif l_page = 507 t';
wwv_flow_imp.g_varchar2_table(16) := 'hen l_action := ''task history'';'||wwv_flow.LF||
'    elsif l_page = 508 then l_action := ''milestone'';'||wwv_flow.LF||
'    elsif l_pag';
wwv_flow_imp.g_varchar2_table(17) := 'e = 509 then l_action := ''review'';'||wwv_flow.LF||
'    else                    l_action := ''unknown'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(18) := '   --'||wwv_flow.LF||
'    -- log project interaction'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    insert into sp_proj_interactions_log (project_id, ap';
wwv_flow_imp.g_varchar2_table(19) := 'p_page, action) values (p_project_id, l_page, l_action);'||wwv_flow.LF||
'end log_interaction;'||wwv_flow.LF||
''||wwv_flow.LF||
'function log_and_summ';
wwv_flow_imp.g_varchar2_table(20) := 'arize ('||wwv_flow.LF||
'    p_project_id in number) '||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_return varchar2(50) := null;'||wwv_flow.LF||
'begi';
wwv_flow_imp.g_varchar2_table(21) := 'n  '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- log interaction'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    log_interaction('||wwv_flow.LF||
'        p_project_id => p_project_id);';
wwv_flow_imp.g_varchar2_table(22) := ''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- return interaction summary'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for c1 in (select count(*) c, count(distinct(ap';
wwv_flow_imp.g_varchar2_table(23) := 'p_user)) u from sp_proj_interactions_log where project_id = p_project_id) loop '||wwv_flow.LF||
'        l_return := ';
wwv_flow_imp.g_varchar2_table(24) := 'trim(to_char(c1.c,''999G999G999G990''));'||wwv_flow.LF||
'        if c1.c = 1 then  '||wwv_flow.LF||
'            l_return := l_return||';
wwv_flow_imp.g_varchar2_table(25) := ''' interaction by ''||trim(to_char(c1.u,''999G999G999G990''));'||wwv_flow.LF||
'        else '||wwv_flow.LF||
'            l_return := l_r';
wwv_flow_imp.g_varchar2_table(26) := 'eturn||'' interactions by ''||trim(to_char(c1.u,''999G999G999G990''));'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        if c1.u =';
wwv_flow_imp.g_varchar2_table(27) := ' 1 then '||wwv_flow.LF||
'            l_return := l_return ||'' user'';'||wwv_flow.LF||
'        else '||wwv_flow.LF||
'            l_return := l_return ';
wwv_flow_imp.g_varchar2_table(28) := '||'' users'';'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    return l_return;'||wwv_flow.LF||
'end log_and_summarize;'||wwv_flow.LF||
'end sp_log;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(35717151544558109660)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_log body'
,p_sequence=>7020
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
