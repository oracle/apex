prompt --application/deployment/install/install_sp_project_scales_table_and_triggers
begin
--   Manifest
--     INSTALL: INSTALL-sp_project_scales table and triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table sp_project_scales ('||wwv_flow.LF||
'    scale_letter                   varchar2(1 char) not null'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(2) := '                             constraint sp_project_scales_pk primary key,'||wwv_flow.LF||
'    scale_name            ';
wwv_flow_imp.g_varchar2_table(3) := '         varchar2(50 char) not null,'||wwv_flow.LF||
'    is_active_yn                   varchar2(1 char) not null'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(4) := '                                    constraint sp_project_scales_active_yn_ck'||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(5) := '                check (is_active_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    min_pc_for_status              number,'||wwv_flow.LF||
'    pc';
wwv_flow_imp.g_varchar2_table(6) := '0_label                      varchar2(60 char),'||wwv_flow.LF||
'    pc0_desc                       varchar2(4000 cha';
wwv_flow_imp.g_varchar2_table(7) := 'r),'||wwv_flow.LF||
'    pc10_label                     varchar2(60 char),'||wwv_flow.LF||
'    pc10_desc                      varchar';
wwv_flow_imp.g_varchar2_table(8) := '2(4000 char),'||wwv_flow.LF||
'    pc20_label                     varchar2(60 char),'||wwv_flow.LF||
'    pc20_desc                   ';
wwv_flow_imp.g_varchar2_table(9) := '   varchar2(4000 char),'||wwv_flow.LF||
'    pc30_label                     varchar2(60 char),'||wwv_flow.LF||
'    pc30_desc         ';
wwv_flow_imp.g_varchar2_table(10) := '             varchar2(4000 char),'||wwv_flow.LF||
'    pc40_label                     varchar2(60 char),'||wwv_flow.LF||
'    pc40_des';
wwv_flow_imp.g_varchar2_table(11) := 'c                      varchar2(4000 char),'||wwv_flow.LF||
'    pc50_label                     varchar2(60 char),'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(12) := '  pc50_desc                      varchar2(4000 char),'||wwv_flow.LF||
'    pc60_label                     varchar2(60';
wwv_flow_imp.g_varchar2_table(13) := ' char),'||wwv_flow.LF||
'    pc60_desc                      varchar2(4000 char),'||wwv_flow.LF||
'    pc70_label                     v';
wwv_flow_imp.g_varchar2_table(14) := 'archar2(60 char),'||wwv_flow.LF||
'    pc70_desc                      varchar2(4000 char),'||wwv_flow.LF||
'    pc80_label            ';
wwv_flow_imp.g_varchar2_table(15) := '         varchar2(60 char),'||wwv_flow.LF||
'    pc80_desc                      varchar2(4000 char),'||wwv_flow.LF||
'    pc90_label  ';
wwv_flow_imp.g_varchar2_table(16) := '                   varchar2(60 char),'||wwv_flow.LF||
'    pc90_desc                      varchar2(4000 char),'||wwv_flow.LF||
'    pc';
wwv_flow_imp.g_varchar2_table(17) := '100_label                    varchar2(60 char),'||wwv_flow.LF||
'    pc100_desc                     varchar2(4000 cha';
wwv_flow_imp.g_varchar2_table(18) := 'r),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                        date not null,'||wwv_flow.LF||
'    created_by                     varc';
wwv_flow_imp.g_varchar2_table(19) := 'har2(255 char) not null,'||wwv_flow.LF||
'    updated                        date not null,'||wwv_flow.LF||
'    updated_by           ';
wwv_flow_imp.g_varchar2_table(20) := '          varchar2(255 char) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table sp_project_scales add constraint sp_project_sc';
wwv_flow_imp.g_varchar2_table(21) := 'ale_ck'||wwv_flow.LF||
'      check (scale_letter in (''A'',''B'',''C'',''D'',''E''));'||wwv_flow.LF||
'create unique index sp_project_scale_uk ';
wwv_flow_imp.g_varchar2_table(22) := 'on sp_project_scales (scale_name);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger sp_project_scales_biu'||wwv_flow.LF||
'    before inser';
wwv_flow_imp.g_varchar2_table(23) := 't or update'||wwv_flow.LF||
'    on sp_project_scales'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.creat';
wwv_flow_imp.g_varchar2_table(24) := 'ed    := nvl(:new.created,sysdate);'||wwv_flow.LF||
'        :new.created_by := nvl(:new.created_by, coalesce(sys_con';
wwv_flow_imp.g_varchar2_table(25) := 'text(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'        :new.updated    := nvl(:new.updated,sysdate);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(26) := '  :new.updated_by := nvl(:new.updated_by, coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user));'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(27) := '  elsif updating then'||wwv_flow.LF||
'        :new.updated    := sysdate;'||wwv_flow.LF||
'        :new.updated_by := coalesce(sys_co';
wwv_flow_imp.g_varchar2_table(28) := 'ntext(''APEX$SESSION'',''APP_USER''),user);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end sp_project_scales_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(42541940820388625538)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_project_scales table and triggers'
,p_sequence=>3190
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
