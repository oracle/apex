prompt --application/deployment/install/install_seed_task_types_statuses_and_relations
begin
--   Manifest
--     INSTALL: INSTALL-seed task types, statuses and relations
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, TASK_NAME_REQ_YN) val';
wwv_flow_imp.g_varchar2_table(2) := 'ues (50, ''DEVELOPMENT'', ''Development'', ''Development Activities'', 1, ''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_task_types';
wwv_flow_imp.g_varchar2_table(3) := ' (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ) values (1, ''REVIEW'', ''Review'', ''Reviews'', 10);';
wwv_flow_imp.g_varchar2_table(4) := ''||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) valu';
wwv_flow_imp.g_varchar2_table(5) := 'es (2, ''REVIEW-FUNCSPEC'', ''Functional Spec Review'', ''A review of the functional specification docume';
wwv_flow_imp.g_varchar2_table(6) := 'nt'', 11, 1);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_T';
wwv_flow_imp.g_varchar2_table(7) := 'YPE_ID) values (3, ''REVIEW-SPEC'', ''Spec Review'', ''A review of the implementation designed to impleme';
wwv_flow_imp.g_varchar2_table(8) := 'nt a functional specification document'', 12, 1);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE';
wwv_flow_imp.g_varchar2_table(9) := ', DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (4, ''REVIEW-PEER'', ''Peer Review'', ''Review of the ';
wwv_flow_imp.g_varchar2_table(10) := 'implementation by your fellow developer'', 13, 1);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYP';
wwv_flow_imp.g_varchar2_table(11) := 'E, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (5, ''REVIEW-SECURITY'', ''Security Review'', ''Revie';
wwv_flow_imp.g_varchar2_table(12) := 'w of the security exposure, remediations, and risk of this implementation'', 14, 1);'||wwv_flow.LF||
'insert into sp_t';
wwv_flow_imp.g_varchar2_table(13) := 'ask_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (6, ''REVIEW-AC';
wwv_flow_imp.g_varchar2_table(14) := 'CESSIBILITY'', ''Accessibility Review'', ''Review web accessibility'', 15, 1);'||wwv_flow.LF||
'insert into sp_task_types ';
wwv_flow_imp.g_varchar2_table(15) := '(ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (7, ''REVIEW-PM'', ''Produc';
wwv_flow_imp.g_varchar2_table(16) := 't Management Review'', ''Project Management (PM) team review'', 16, 1);'||wwv_flow.LF||
'insert into sp_task_types (ID, ';
wwv_flow_imp.g_varchar2_table(17) := 'STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (8, ''REVIEW-DOC'', ''Documentat';
wwv_flow_imp.g_varchar2_table(18) := 'ion Review'', ''Review of the documentation'', 17, 1);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_T';
wwv_flow_imp.g_varchar2_table(19) := 'YPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (9, ''REVIEW-TESTING'', ''Functional Testing Revi';
wwv_flow_imp.g_varchar2_table(20) := 'ew'', ''Review of the testing plan'', 18, 1);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESC';
wwv_flow_imp.g_varchar2_table(21) := 'RIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (10, ''REVIEW-UX'', ''User Experience Review'', ''Review of ';
wwv_flow_imp.g_varchar2_table(22) := 'end-user experience'', 19, 1);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISP';
wwv_flow_imp.g_varchar2_table(23) := 'LAY_SEQ, PARENT_TYPE_ID) values (11, ''REVIEW-IMPLEMENTATION'', ''Implementation Review'', ''An implement';
wwv_flow_imp.g_varchar2_table(24) := 'ation review is typically performed before merge'', 20, 1);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID,';
wwv_flow_imp.g_varchar2_table(25) := ' TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (12, ''REVIEW-OTHER'', ''Other Review'', ''A';
wwv_flow_imp.g_varchar2_table(26) := ' review that does not fall into any other category'', 21, 1);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_';
wwv_flow_imp.g_varchar2_table(27) := 'ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ) values (20, ''MILESTONE'', ''Milestone'', ''Milestones'', 30);'||wwv_flow.LF||
'in';
wwv_flow_imp.g_varchar2_table(28) := 'sert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values ';
wwv_flow_imp.g_varchar2_table(29) := '(21, ''MILESTONE-SPEC'', ''Spec'', ''Specification is complete and ready for review'', 31, 20);'||wwv_flow.LF||
'insert int';
wwv_flow_imp.g_varchar2_table(30) := 'o sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (22, ''MI';
wwv_flow_imp.g_varchar2_table(31) := 'LESTONE-DEMO'', ''Demonstration'', ''Code has been successfully demonstrated'', 32, 20);'||wwv_flow.LF||
'insert into sp_t';
wwv_flow_imp.g_varchar2_table(32) := 'ask_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (23, ''MILESTON';
wwv_flow_imp.g_varchar2_table(33) := 'E-CODE'', ''Code Complete'', ''Code is complete'', 33, 20);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TAS';
wwv_flow_imp.g_varchar2_table(34) := 'K_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (24, ''MILESTONE-MERGED'', ''Merged'', ''Code ha';
wwv_flow_imp.g_varchar2_table(35) := 's been merged'', 34, 20);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_S';
wwv_flow_imp.g_varchar2_table(36) := 'EQ, PARENT_TYPE_ID) values (25, ''MILESTONE-HOSTED'', ''Hosted'', ''Code has been hosted'', 45, 20);'||wwv_flow.LF||
'inser';
wwv_flow_imp.g_varchar2_table(37) := 't into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values (26';
wwv_flow_imp.g_varchar2_table(38) := ', ''MILESTONE-COMPLETE'', ''Fully Completed'', ''The task is now fully complete'', 36, 20);'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into s';
wwv_flow_imp.g_varchar2_table(39) := 'p_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ) values (30, ''PM'', ''PM'', ''Project M';
wwv_flow_imp.g_varchar2_table(40) := 'anagement'', 70);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARE';
wwv_flow_imp.g_varchar2_table(41) := 'NT_TYPE_ID) values (31, ''PM-CUST-ISSUE'', ''Customer Issue Identified'', ''Customer Issue has been ident';
wwv_flow_imp.g_varchar2_table(42) := 'ified'', 71, 30);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARE';
wwv_flow_imp.g_varchar2_table(43) := 'NT_TYPE_ID) values (32, ''PM-RES-IDENTIFIED'', ''Resolution Identified'', ''Resolution has been identifie';
wwv_flow_imp.g_varchar2_table(44) := 'd'', 72, 30);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_T';
wwv_flow_imp.g_varchar2_table(45) := 'YPE_ID) values (33, ''PM-PROVIDED'', ''Provided to Customer'', ''Resolution Provided to Customer'', 73, 30';
wwv_flow_imp.g_varchar2_table(46) := ');'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) va';
wwv_flow_imp.g_varchar2_table(47) := 'lues (34, ''PM-IMPLEMENTED'', ''Implemented by Customer'', ''Resolution implemented by Customer'', 74, 30)';
wwv_flow_imp.g_varchar2_table(48) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ) values (40, ''SALES';
wwv_flow_imp.g_varchar2_table(49) := ''', ''Sales'', ''Sales Engagement'', 80);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTIO';
wwv_flow_imp.g_varchar2_table(50) := 'N, DISPLAY_SEQ, PARENT_TYPE_ID) values (41, ''SALES-OPP-QUALIFIED'', ''Opportunity Qualified'', ''Opportu';
wwv_flow_imp.g_varchar2_table(51) := 'nity has been qualified'', 81, 40);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION,';
wwv_flow_imp.g_varchar2_table(52) := ' DISPLAY_SEQ, PARENT_TYPE_ID) values (42, ''SALES-PRESENT'', ''Presented to Customer'', ''Presented to Cu';
wwv_flow_imp.g_varchar2_table(53) := 'stomer'', 82, 40);'||wwv_flow.LF||
'insert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PAR';
wwv_flow_imp.g_varchar2_table(54) := 'ENT_TYPE_ID) values (43, ''SALES-PROPOSAL-DRAFT'', ''Proposal Drafted'', ''Proposal Drafted'', 83, 40);'||wwv_flow.LF||
'in';
wwv_flow_imp.g_varchar2_table(55) := 'sert into sp_task_types (ID, STATIC_ID, TASK_TYPE, DESCRIPTION, DISPLAY_SEQ, PARENT_TYPE_ID) values ';
wwv_flow_imp.g_varchar2_table(56) := '(44, ''SALES-PROPOSAL-DEL'', ''Proposal Delivered'', ''Proposal Delivered'', 84, 40);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_tas';
wwv_flow_imp.g_varchar2_table(57) := 'k_statuses (id, task_type_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_c';
wwv_flow_imp.g_varchar2_table(58) := 'omplete_yn) values (1, 1, ''Identified'', ''IDENTIFIED'', 1, ''Y'', ''Y'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuse';
wwv_flow_imp.g_varchar2_table(59) := 's (id, task_type_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_y';
wwv_flow_imp.g_varchar2_table(60) := 'n) values (2, 1, ''Assigned'', ''ASSIGNED'', 2, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_t';
wwv_flow_imp.g_varchar2_table(61) := 'ype_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (4,';
wwv_flow_imp.g_varchar2_table(62) := ' 1, ''In Progress'', ''IN-PROGRESS'', 4, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id,';
wwv_flow_imp.g_varchar2_table(63) := ' status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (5, 1, ''Mo';
wwv_flow_imp.g_varchar2_table(64) := 're Information Requested'', ''MORE-INFO'', 5, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_ty';
wwv_flow_imp.g_varchar2_table(65) := 'pe_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (6, ';
wwv_flow_imp.g_varchar2_table(66) := '1, ''Paused'', ''PAUSED'', 6, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, st';
wwv_flow_imp.g_varchar2_table(67) := 'atic_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (7, 1, ''Blocked'', ''BL';
wwv_flow_imp.g_varchar2_table(68) := 'OCKED'', 7, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, static_id, displa';
wwv_flow_imp.g_varchar2_table(69) := 'y_seq, include_yn, is_default_yn, indicates_complete_yn) values (8, 1, ''Completed'', ''COMPLETED'', 8, ';
wwv_flow_imp.g_varchar2_table(70) := '''Y'', ''N'', ''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, static_id, display_seq, inc';
wwv_flow_imp.g_varchar2_table(71) := 'lude_yn, is_default_yn, indicates_complete_yn) values (10, 20, ''Identified'', ''IDENTIFIED'', 1, ''Y'', ''';
wwv_flow_imp.g_varchar2_table(72) := 'Y'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, static_id, display_seq, include_yn';
wwv_flow_imp.g_varchar2_table(73) := ', is_default_yn, indicates_complete_yn) values (11, 20, ''In Progress'', ''IN-PROGRESS'', 4, ''Y'', ''N'', ''';
wwv_flow_imp.g_varchar2_table(74) := 'N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, static_id, display_seq, include_yn, is_';
wwv_flow_imp.g_varchar2_table(75) := 'default_yn, indicates_complete_yn) values (12, 20, ''Paused'', ''PAUSED'', 6, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert int';
wwv_flow_imp.g_varchar2_table(76) := 'o sp_task_statuses (id, task_type_id, status, static_id, display_seq, include_yn, is_default_yn, ind';
wwv_flow_imp.g_varchar2_table(77) := 'icates_complete_yn) values (13, 20, ''Blocked'', ''BLOCKED'', 7, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_sta';
wwv_flow_imp.g_varchar2_table(78) := 'tuses (id, task_type_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_comple';
wwv_flow_imp.g_varchar2_table(79) := 'te_yn) values (14, 20, ''Completed'', ''COMPLETED'', 8, ''Y'', ''N'', ''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_task_statuses (i';
wwv_flow_imp.g_varchar2_table(80) := 'd, task_type_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) v';
wwv_flow_imp.g_varchar2_table(81) := 'alues (21, 30, ''Identified'', ''IDENTIFIED'', 1, ''Y'', ''Y'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task';
wwv_flow_imp.g_varchar2_table(82) := '_type_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (';
wwv_flow_imp.g_varchar2_table(83) := '22, 30, ''Assigned'', ''ASSIGNED'', 2, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, s';
wwv_flow_imp.g_varchar2_table(84) := 'tatus, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (23, 30, ''In';
wwv_flow_imp.g_varchar2_table(85) := ' Progress'', ''IN-PROGRESS'', 4, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status';
wwv_flow_imp.g_varchar2_table(86) := ', static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (24, 30, ''More In';
wwv_flow_imp.g_varchar2_table(87) := 'formation Requested'', ''MORE-INFO'', 5, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id';
wwv_flow_imp.g_varchar2_table(88) := ', status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (25, 30, ';
wwv_flow_imp.g_varchar2_table(89) := '''Paused'', ''PAUSED'', 6, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, stati';
wwv_flow_imp.g_varchar2_table(90) := 'c_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (26, 30, ''Blocked'', ''BLO';
wwv_flow_imp.g_varchar2_table(91) := 'CKED'', 7, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, static_id, display';
wwv_flow_imp.g_varchar2_table(92) := '_seq, include_yn, is_default_yn, indicates_complete_yn) values (27, 30, ''Completed'', ''COMPLETED'', 8,';
wwv_flow_imp.g_varchar2_table(93) := ' ''Y'', ''N'', ''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, static_id, display_seq, in';
wwv_flow_imp.g_varchar2_table(94) := 'clude_yn, is_default_yn, indicates_complete_yn) values (31, 40, ''Identified'', ''IDENTIFIED'', 1, ''Y'', ';
wwv_flow_imp.g_varchar2_table(95) := '''Y'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, static_id, display_seq, include_y';
wwv_flow_imp.g_varchar2_table(96) := 'n, is_default_yn, indicates_complete_yn) values (32, 40, ''Assigned'', ''ASSIGNED'', 2, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(97) := 'insert into sp_task_statuses (id, task_type_id, status, static_id, display_seq, include_yn, is_defau';
wwv_flow_imp.g_varchar2_table(98) := 'lt_yn, indicates_complete_yn) values (33, 40, ''In Progress'', ''IN-PROGRESS'', 4, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'inser';
wwv_flow_imp.g_varchar2_table(99) := 't into sp_task_statuses (id, task_type_id, status, static_id, display_seq, include_yn, is_default_yn';
wwv_flow_imp.g_varchar2_table(100) := ', indicates_complete_yn) values (34, 40, ''Completed'', ''COMPLETED'', 8, ''Y'', ''N'', ''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into s';
wwv_flow_imp.g_varchar2_table(101) := 'p_task_statuses (id, task_type_id, status, static_id, display_seq, include_yn, is_default_yn, indica';
wwv_flow_imp.g_varchar2_table(102) := 'tes_complete_yn) values (41, 50, ''Identified'', ''IDENTIFIED'', 1, ''Y'', ''Y'', ''N'');'||wwv_flow.LF||
'insert into sp_task_';
wwv_flow_imp.g_varchar2_table(103) := 'statuses (id, task_type_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_com';
wwv_flow_imp.g_varchar2_table(104) := 'plete_yn) values (42, 50, ''Assigned'', ''ASSIGNED'', 2, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (i';
wwv_flow_imp.g_varchar2_table(105) := 'd, task_type_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) v';
wwv_flow_imp.g_varchar2_table(106) := 'alues (43, 50, ''In Progress'', ''IN-PROGRESS'', 4, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, ta';
wwv_flow_imp.g_varchar2_table(107) := 'sk_type_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values';
wwv_flow_imp.g_varchar2_table(108) := ' (44, 50, ''More Information Requested'', ''MORE-INFO'', 5, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses';
wwv_flow_imp.g_varchar2_table(109) := ' (id, task_type_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn';
wwv_flow_imp.g_varchar2_table(110) := ') values (45, 50, ''Paused'', ''PAUSED'', 6, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type';
wwv_flow_imp.g_varchar2_table(111) := '_id, status, static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (46, 5';
wwv_flow_imp.g_varchar2_table(112) := '0, ''Blocked'', ''BLOCKED'', 7, ''Y'', ''N'', ''N'');'||wwv_flow.LF||
'insert into sp_task_statuses (id, task_type_id, status, ';
wwv_flow_imp.g_varchar2_table(113) := 'static_id, display_seq, include_yn, is_default_yn, indicates_complete_yn) values (47, 50, ''Completed';
wwv_flow_imp.g_varchar2_table(114) := ''', ''COMPLETED'', 8, ''Y'', ''N'', ''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into SP_RELATION_TYPES (ID, RELATION_TYPE, RELATION_REVER';
wwv_flow_imp.g_varchar2_table(115) := 'SE, ACTIVE_YN) values ( 4, ''Blocked By'', ''Blocks'', ''Y'');'||wwv_flow.LF||
'insert into SP_RELATION_TYPES (ID, RELATION';
wwv_flow_imp.g_varchar2_table(116) := '_TYPE, RELATION_REVERSE, ACTIVE_YN) values ( 3, ''Duplicates'', '''', ''Y'');'||wwv_flow.LF||
'insert into SP_RELATION_TYPE';
wwv_flow_imp.g_varchar2_table(117) := 'S (ID, RELATION_TYPE, RELATION_REVERSE, ACTIVE_YN) values ( 1, ''Relates to'', '''', ''Y'');'||wwv_flow.LF||
'insert into S';
wwv_flow_imp.g_varchar2_table(118) := 'P_RELATION_TYPES (ID, RELATION_TYPE, RELATION_REVERSE, ACTIVE_YN) values ( 2, ''Requires'', ''Is Requir';
wwv_flow_imp.g_varchar2_table(119) := 'ed By'', ''Y'');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(38218326152049015885)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'seed task types, statuses and relations'
,p_sequence=>9120
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
