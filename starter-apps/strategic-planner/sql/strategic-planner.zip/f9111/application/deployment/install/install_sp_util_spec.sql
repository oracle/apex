prompt --application/deployment/install/install_sp_util_spec
begin
--   Manifest
--     INSTALL: INSTALL-sp_util spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package sp_util as'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_error_log ( '||wwv_flow.LF||
'    p_package_name    in varchar2,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(2) := '    p_procedure_name  in varchar2, '||wwv_flow.LF||
'    p_error           in varchar2, '||wwv_flow.LF||
'    p_error_backtrace in var';
wwv_flow_imp.g_varchar2_table(3) := 'char2 default null,'||wwv_flow.LF||
'    p_arg1_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg1_val        in varcha';
wwv_flow_imp.g_varchar2_table(4) := 'r2 default null, '||wwv_flow.LF||
'    p_arg2_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg2_val        in varchar2';
wwv_flow_imp.g_varchar2_table(5) := ' default null, '||wwv_flow.LF||
'    p_arg3_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg3_val        in varchar2 d';
wwv_flow_imp.g_varchar2_table(6) := 'efault null, '||wwv_flow.LF||
'    p_arg4_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg4_val        in varchar2 def';
wwv_flow_imp.g_varchar2_table(7) := 'ault null, '||wwv_flow.LF||
'    p_arg5_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg5_val        in varchar2 defau';
wwv_flow_imp.g_varchar2_table(8) := 'lt null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_app_log ( '||wwv_flow.LF||
'    p_activity   in varchar2,'||wwv_flow.LF||
'    p_details    in varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(9) := '-- create APIs'||wwv_flow.LF||
'function create_area ('||wwv_flow.LF||
'    p_area                     in varchar2,'||wwv_flow.LF||
'    p_description ';
wwv_flow_imp.g_varchar2_table(10) := '             in varchar2 default null,'||wwv_flow.LF||
'    p_owner_id                 in number   default null )'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(11) := ' return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'function create_initiative ('||wwv_flow.LF||
'    p_area_id                  in number,'||wwv_flow.LF||
'    p_initia';
wwv_flow_imp.g_varchar2_table(12) := 'tive               in varchar2,'||wwv_flow.LF||
'    p_objective                in varchar2 default null,'||wwv_flow.LF||
'    p_owner';
wwv_flow_imp.g_varchar2_table(13) := '_id                 in number   default null )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'function create_release ('||wwv_flow.LF||
'    p_r';
wwv_flow_imp.g_varchar2_table(14) := 'elease_train                  in varchar2,'||wwv_flow.LF||
'    p_release_owner_id               in number,'||wwv_flow.LF||
'    p_rel';
wwv_flow_imp.g_varchar2_table(15) := 'ease                        in varchar2,'||wwv_flow.LF||
'    p_release_target_date            in date,'||wwv_flow.LF||
'    p_release';
wwv_flow_imp.g_varchar2_table(16) := '_open_date              in date )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure copy_release ('||wwv_flow.LF||
'    p_copy_from_relea';
wwv_flow_imp.g_varchar2_table(17) := 'se_id  in  number,'||wwv_flow.LF||
'    p_new_release           in  varchar2,'||wwv_flow.LF||
'    p_push_days             in  number,';
wwv_flow_imp.g_varchar2_table(18) := ''||wwv_flow.LF||
'    p_new_release_id        out number );'||wwv_flow.LF||
''||wwv_flow.LF||
'function create_team_member ('||wwv_flow.LF||
'    p_first_name          ';
wwv_flow_imp.g_varchar2_table(19) := '           in varchar2,'||wwv_flow.LF||
'    p_last_name                      in varchar2,'||wwv_flow.LF||
'    p_email               ';
wwv_flow_imp.g_varchar2_table(20) := '           in varchar2,'||wwv_flow.LF||
'    p_tags                           in varchar2 default null,'||wwv_flow.LF||
'    p_is_curr';
wwv_flow_imp.g_varchar2_table(21) := 'ent_yn                  in varchar2 default ''Y'' )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'function create_project ('||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(22) := 'p_initiative_id                  in number,'||wwv_flow.LF||
'    p_project                        in varchar2,'||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(23) := 'owner_id                       in number,'||wwv_flow.LF||
'    p_status_scale                   in varchar2 default ''';
wwv_flow_imp.g_varchar2_table(24) := 'A'','||wwv_flow.LF||
'    p_pct_complete                   in number default 10,'||wwv_flow.LF||
'    p_priority_id                    ';
wwv_flow_imp.g_varchar2_table(25) := 'in number default 4,'||wwv_flow.LF||
'    p_target_complete                in date default null,'||wwv_flow.LF||
'    p_release_id    ';
wwv_flow_imp.g_varchar2_table(26) := '                 in number default null,'||wwv_flow.LF||
'    p_project_size                   in varchar2 default ''M';
wwv_flow_imp.g_varchar2_table(27) := ''','||wwv_flow.LF||
'    p_description                    in varchar2 default null,'||wwv_flow.LF||
'    p_tags                        ';
wwv_flow_imp.g_varchar2_table(28) := '   in varchar2 default null ) '||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'function copy_project ('||wwv_flow.LF||
'    p_project_id         ';
wwv_flow_imp.g_varchar2_table(29) := '            in number,'||wwv_flow.LF||
'    p_new_project_name               in varchar2 ) '||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'proce';
wwv_flow_imp.g_varchar2_table(30) := 'dure add_related_project ('||wwv_flow.LF||
'    p_related_project_id in number,'||wwv_flow.LF||
'    p_project_id         in number );';
wwv_flow_imp.g_varchar2_table(31) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_project_link ('||wwv_flow.LF||
'    p_project_id      in number,'||wwv_flow.LF||
'    p_link_name       in varchar2,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(32) := '   p_link_url        in varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure default_project_tasks ('||wwv_flow.LF||
'    p_project_id      in numb';
wwv_flow_imp.g_varchar2_table(33) := 'er );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure archive_project ('||wwv_flow.LF||
'    p_project_id      in number,'||wwv_flow.LF||
'    p_app_user        in varchar';
wwv_flow_imp.g_varchar2_table(34) := '2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure un_archive_project ('||wwv_flow.LF||
'    p_project_id      in number );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure mark_proj_as_dupl';
wwv_flow_imp.g_varchar2_table(35) := 'idate ('||wwv_flow.LF||
'    p_project_id        in number,'||wwv_flow.LF||
'    p_dup_of_project    in number );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure unmark_pr';
wwv_flow_imp.g_varchar2_table(36) := 'oj_as_duplicate ('||wwv_flow.LF||
'    p_project_id        in number );'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------------'||wwv_flow.LF||
'-- additional APIs'||wwv_flow.LF||
'--'||wwv_flow.LF||
''||wwv_flow.LF||
'f';
wwv_flow_imp.g_varchar2_table(37) := 'unction get_user_email ('||wwv_flow.LF||
'    p_app_user     in  varchar2  default null,'||wwv_flow.LF||
'    p_user_id      in  numbe';
wwv_flow_imp.g_varchar2_table(38) := 'r    default null )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_user_id ('||wwv_flow.LF||
'    p_app_user     in varchar2   de';
wwv_flow_imp.g_varchar2_table(39) := 'fault null,'||wwv_flow.LF||
'    p_screen_name  in  varchar2  default null )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_area_na';
wwv_flow_imp.g_varchar2_table(40) := 'me ('||wwv_flow.LF||
'    p_id              in number )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_initiative_name ('||wwv_flow.LF||
'    p_id';
wwv_flow_imp.g_varchar2_table(41) := '              in number )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_project_name ('||wwv_flow.LF||
'    p_id              in';
wwv_flow_imp.g_varchar2_table(42) := ' number )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_project_contributor ('||wwv_flow.LF||
'    P_TEAM_MEMBER_ID    in numbe';
wwv_flow_imp.g_varchar2_table(43) := 'r,'||wwv_flow.LF||
'    p_RESPONSIBILITY_ID in number,'||wwv_flow.LF||
'    p_project_id        in number );'||wwv_flow.LF||
'    '||wwv_flow.LF||
'procedure add_projec';
wwv_flow_imp.g_varchar2_table(44) := 't_tag ('||wwv_flow.LF||
'    p_project_id        in number,'||wwv_flow.LF||
'    p_tag               in varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure remove_';
wwv_flow_imp.g_varchar2_table(45) := 'project_tag ('||wwv_flow.LF||
'    p_project_id        in number,'||wwv_flow.LF||
'    p_tag               in varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure s';
wwv_flow_imp.g_varchar2_table(46) := 'et_nomenclature;'||wwv_flow.LF||
''||wwv_flow.LF||
'function show_nomenclature return clob;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_nomenclature ('||wwv_flow.LF||
'    p_static_';
wwv_flow_imp.g_varchar2_table(47) := 'id  in  varchar2 )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_setting (  '||wwv_flow.LF||
'    p_static_id      in  varchar2';
wwv_flow_imp.g_varchar2_table(48) := ',   '||wwv_flow.LF||
'    p_description    in  varchar2, '||wwv_flow.LF||
'    p_setting_value  in  varchar2, '||wwv_flow.LF||
'    p_is_numeric_yn  in';
wwv_flow_imp.g_varchar2_table(49) := '  varchar2, '||wwv_flow.LF||
'    p_is_yn          in  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure set_setting (  '||wwv_flow.LF||
'    p_static_id      in';
wwv_flow_imp.g_varchar2_table(50) := '  varchar2,   '||wwv_flow.LF||
'    p_setting_value  in  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_setting ('||wwv_flow.LF||
'    p_static_id  in  var';
wwv_flow_imp.g_varchar2_table(51) := 'char2 )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_ai_prompt (  '||wwv_flow.LF||
'    p_static_id      in  varchar2,   '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(52) := 'p_description    in  varchar2, '||wwv_flow.LF||
'    p_prompt         in  clob );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure set_ai_prompt (  '||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(53) := 'static_id      in  varchar2,   '||wwv_flow.LF||
'    p_prompt         in  clob );'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_ai_prompt ('||wwv_flow.LF||
'    p_sta';
wwv_flow_imp.g_varchar2_table(54) := 'tic_id  in  varchar2 )'||wwv_flow.LF||
'    return clob;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_notification_id ('||wwv_flow.LF||
'    p_static_id   in  varcha';
wwv_flow_imp.g_varchar2_table(55) := 'r2 )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure notification_opt_in ('||wwv_flow.LF||
'    p_team_member_id   in  number,'||wwv_flow.LF||
'    p_no';
wwv_flow_imp.g_varchar2_table(56) := 'tification_id  in  number,'||wwv_flow.LF||
'    p_frequency        in  varchar2 default ''WEEKLY'','||wwv_flow.LF||
'    p_release_id   ';
wwv_flow_imp.g_varchar2_table(57) := '    in  number   default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure notification_opt_out ('||wwv_flow.LF||
'    p_team_member_id   in  number';
wwv_flow_imp.g_varchar2_table(58) := ','||wwv_flow.LF||
'    p_notification_id  in  number,'||wwv_flow.LF||
'    p_release_id       in  number default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure ge';
wwv_flow_imp.g_varchar2_table(59) := 't_create_project_qp ('||wwv_flow.LF||
'    p_app_user         in varchar2,'||wwv_flow.LF||
'    p_quick_pick_id_1  out number,'||wwv_flow.LF||
'    p_q';
wwv_flow_imp.g_varchar2_table(60) := 'uick_pick_1     out varchar2,'||wwv_flow.LF||
'    p_quick_pick_id_2  out number,'||wwv_flow.LF||
'    p_quick_pick_2     out varchar2';
wwv_flow_imp.g_varchar2_table(61) := ','||wwv_flow.LF||
'    p_quick_pick_id_3  out number,'||wwv_flow.LF||
'    p_quick_pick_3     out varchar2,'||wwv_flow.LF||
'    p_quick_pick_id_4  out';
wwv_flow_imp.g_varchar2_table(62) := ' number,'||wwv_flow.LF||
'    p_quick_pick_4     out varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure get_current_username_and_id ('||wwv_flow.LF||
'    p_app_u';
wwv_flow_imp.g_varchar2_table(63) := 'ser         in varchar2,'||wwv_flow.LF||
'    p_users_name       out varchar2,'||wwv_flow.LF||
'    p_users_id         out number );'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(64) := '-------------'||wwv_flow.LF||
'-- data sync'||wwv_flow.LF||
'--'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure sync_team_members_app_role ('||wwv_flow.LF||
'    p_app_id in number );'||wwv_flow.LF||
''||wwv_flow.LF||
'pro';
wwv_flow_imp.g_varchar2_table(65) := 'cedure sync_team_member_app_role ('||wwv_flow.LF||
'    p_app_id in number,'||wwv_flow.LF||
'    p_email  in varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'------------';
wwv_flow_imp.g_varchar2_table(66) := '-'||wwv_flow.LF||
'-- Tags'||wwv_flow.LF||
'--'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_default_tag ('||wwv_flow.LF||
'    p_tag        in varchar2,'||wwv_flow.LF||
'    p_sequence   in number d';
wwv_flow_imp.g_varchar2_table(67) := 'efault null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure get_default_tags ('||wwv_flow.LF||
'    p_tag_1      out varchar2,'||wwv_flow.LF||
'    p_tag_2      out var';
wwv_flow_imp.g_varchar2_table(68) := 'char2,'||wwv_flow.LF||
'    p_tag_3      out varchar2,'||wwv_flow.LF||
'    p_tag_4      out varchar2,'||wwv_flow.LF||
'    p_tag_5      out varchar2,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(69) := '    p_tag_6      out varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'function count_project_tags ('||wwv_flow.LF||
'    p_project_id in number )'||wwv_flow.LF||
'    ret';
wwv_flow_imp.g_varchar2_table(70) := 'urn number;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_project_id ('||wwv_flow.LF||
'    p_friendly_identifier in varchar2,'||wwv_flow.LF||
'    p_project_url_name';
wwv_flow_imp.g_varchar2_table(71) := '    in varchar2 )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
' function get_initiative_id ('||wwv_flow.LF||
'    p_friendly_identifier    in ';
wwv_flow_imp.g_varchar2_table(72) := 'varchar2,'||wwv_flow.LF||
'    p_initiative_url_name    in varchar2 )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'--------------------'||wwv_flow.LF||
'-- uti';
wwv_flow_imp.g_varchar2_table(73) := 'lity functions'||wwv_flow.LF||
'--'||wwv_flow.LF||
''||wwv_flow.LF||
'function compress_int ('||wwv_flow.LF||
'    n in integer ) '||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function find_m';
wwv_flow_imp.g_varchar2_table(74) := 'entions ('||wwv_flow.LF||
'    p_clob in clob )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function list_change ('||wwv_flow.LF||
'    p_old_list   in varc';
wwv_flow_imp.g_varchar2_table(75) := 'har2 default null, '||wwv_flow.LF||
'    p_new_list   in varchar2 default null, '||wwv_flow.LF||
'    p_delim      in varchar2 default';
wwv_flow_imp.g_varchar2_table(76) := ' '','' )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'--------------------'||wwv_flow.LF||
'-- for Notification Subscriptions'||wwv_flow.LF||
'--'||wwv_flow.LF||
'procedure sen';
wwv_flow_imp.g_varchar2_table(77) := 'd_notif_subscriptions;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure assignment_notification ('||wwv_flow.LF||
'    p_team_member_id     in  number,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(78) := ' p_app_name           in  varchar2,'||wwv_flow.LF||
'    p_app_id             in  number,'||wwv_flow.LF||
'    p_project_id         in';
wwv_flow_imp.g_varchar2_table(79) := '  number  default null,'||wwv_flow.LF||
'    p_task_id            in  number  default null,'||wwv_flow.LF||
'    p_link               ';
wwv_flow_imp.g_varchar2_table(80) := 'in  varchar2,'||wwv_flow.LF||
'    p_view_what          in  varchar2,'||wwv_flow.LF||
'    p_title              in  varchar2,'||wwv_flow.LF||
'    p_em';
wwv_flow_imp.g_varchar2_table(81) := 'ail_contents     in  varchar2,'||wwv_flow.LF||
'    p_notification_type  in  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure comment_notificat';
wwv_flow_imp.g_varchar2_table(82) := 'ion ('||wwv_flow.LF||
'    p_team_member_id      in  number,'||wwv_flow.LF||
'    p_app_name            in  varchar2,'||wwv_flow.LF||
'    p_app_id    ';
wwv_flow_imp.g_varchar2_table(83) := '          in  number,'||wwv_flow.LF||
'    p_project_id          in  number  default null,'||wwv_flow.LF||
'    p_task_id             ';
wwv_flow_imp.g_varchar2_table(84) := 'in  number  default null,'||wwv_flow.LF||
'    p_release_id          in  number  default null,'||wwv_flow.LF||
'    p_initiative_id   ';
wwv_flow_imp.g_varchar2_table(85) := '    in  number  default null,'||wwv_flow.LF||
'    p_init_focus_area_id  in  number  default null,'||wwv_flow.LF||
'    p_link        ';
wwv_flow_imp.g_varchar2_table(86) := '        in  varchar2,'||wwv_flow.LF||
'    p_view_what           in  varchar2,'||wwv_flow.LF||
'    p_title               in  varchar2';
wwv_flow_imp.g_varchar2_table(87) := ','||wwv_flow.LF||
'    p_email_contents      in  varchar2,'||wwv_flow.LF||
'    p_notification_type   in  varchar2 default ''COMMENT'' )';
wwv_flow_imp.g_varchar2_table(88) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'-- used by SP_CONTRIBUTOR_SUMMARY, SP_RELEASE_TIMELINE and with app'||wwv_flow.LF||
'function exceptions_for_proje';
wwv_flow_imp.g_varchar2_table(89) := 'ct ('||wwv_flow.LF||
'    p_project_id      in  number,'||wwv_flow.LF||
'    p_one_project_yn  in  varchar2 default ''N'','||wwv_flow.LF||
'    p_team_me';
wwv_flow_imp.g_varchar2_table(90) := 'mber_id  in  number   default null,'||wwv_flow.LF||
'    p_link_type       in  varchar2,'||wwv_flow.LF||
'    p_app_prefix_url  in  va';
wwv_flow_imp.g_varchar2_table(91) := 'rchar2,'||wwv_flow.LF||
'    p_app_id          in  number,'||wwv_flow.LF||
'    p_apex_session    in  number   default null,'||wwv_flow.LF||
'    p_rev';
wwv_flow_imp.g_varchar2_table(92) := 'iews_yn      in  varchar2 default ''N'','||wwv_flow.LF||
'    p_approvals_yn    in  varchar2 default ''N'' )'||wwv_flow.LF||
'    return c';
wwv_flow_imp.g_varchar2_table(93) := 'lob;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- used for build option display within Admin'||wwv_flow.LF||
'function replace_nomenclature ('||wwv_flow.LF||
'    p_contents  ';
wwv_flow_imp.g_varchar2_table(94) := 'in  varchar2 )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function fix_demo_dates ('||wwv_flow.LF||
'    p_date  in  date'||wwv_flow.LF||
') return date;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(95) := 'end sp_util;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(151732874807142016689)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sp_util spec'
,p_sequence=>2040
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
