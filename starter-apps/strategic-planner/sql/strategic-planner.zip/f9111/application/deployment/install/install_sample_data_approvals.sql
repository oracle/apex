prompt --application/deployment/install/install_sample_data_approvals
begin
--   Manifest
--     INSTALL: INSTALL-sample data - approvals
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'sp_globals.g_audit_this := FALSE;'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_approval_types'||wwv_flow.LF||
'    (id, display_seq, approv';
wwv_flow_imp.g_varchar2_table(2) := 'al_type, description, active_yn)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (1, 1, ''Development'', ''Approval to begin development';
wwv_flow_imp.g_varchar2_table(3) := '. This approval should be obtained when a developer is ready to begin development.'', ''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert i';
wwv_flow_imp.g_varchar2_table(4) := 'nto sp_initiative_approvals'||wwv_flow.LF||
'    (id, initiative_id, approval_type_id, active_yn)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (1, ';
wwv_flow_imp.g_varchar2_table(5) := '1, 1, ''Y'');'||wwv_flow.LF||
'insert into sp_initiative_approval_chain'||wwv_flow.LF||
'    (id, initiative_approval_id, team_member_id';
wwv_flow_imp.g_varchar2_table(6) := ', approval_seq, active_yn)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (1, 1, 14, 1, ''Y'');'||wwv_flow.LF||
'insert into sp_initiative_approval_cha';
wwv_flow_imp.g_varchar2_table(7) := 'in'||wwv_flow.LF||
'    (id, initiative_approval_id, team_member_id, approval_seq, active_yn)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (2, 1, 1';
wwv_flow_imp.g_varchar2_table(8) := '6, 2, ''Y'');'||wwv_flow.LF||
'insert into sp_initiative_approval_chain'||wwv_flow.LF||
'    (id, initiative_approval_id, team_member_id';
wwv_flow_imp.g_varchar2_table(9) := ', approval_seq, active_yn)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (3, 1, 18, 3, ''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_initiative_approvals'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(10) := '   (id, initiative_id, approval_type_id, active_yn)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (2, 2, 1, ''Y'');'||wwv_flow.LF||
'insert into sp_in';
wwv_flow_imp.g_varchar2_table(11) := 'itiative_approval_chain'||wwv_flow.LF||
'    (id, initiative_approval_id, team_member_id, approval_seq, active_yn)'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(12) := '  values'||wwv_flow.LF||
'    (21, 2, 14, 1, ''Y'');'||wwv_flow.LF||
'insert into sp_initiative_approval_chain'||wwv_flow.LF||
'    (id, initiative_appro';
wwv_flow_imp.g_varchar2_table(13) := 'val_id, team_member_id, approval_seq, active_yn)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (22, 2, 18, 2, ''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp';
wwv_flow_imp.g_varchar2_table(14) := '_initiative_approvals'||wwv_flow.LF||
'    (id, initiative_id, approval_type_id, active_yn)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (3, 3, 1, ';
wwv_flow_imp.g_varchar2_table(15) := '''Y'');'||wwv_flow.LF||
'insert into sp_initiative_approval_chain'||wwv_flow.LF||
'    (id, initiative_approval_id, team_member_id, appr';
wwv_flow_imp.g_varchar2_table(16) := 'oval_seq, active_yn)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (31, 3, 14, 1, ''Y'');'||wwv_flow.LF||
'insert into sp_initiative_approval_chain'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(17) := '  (id, initiative_approval_id, team_member_id, approval_seq, active_yn)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (32, 3, 16, 2';
wwv_flow_imp.g_varchar2_table(18) := ', ''Y'');'||wwv_flow.LF||
'insert into sp_initiative_approval_chain'||wwv_flow.LF||
'    (id, initiative_approval_id, team_member_id, ap';
wwv_flow_imp.g_varchar2_table(19) := 'proval_seq, active_yn)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (33, 3, 18, 3, ''Y'');'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'insert into sp_project_approvals'||wwv_flow.LF||
'    (i';
wwv_flow_imp.g_varchar2_table(20) := 'd, approval_type_id, project_id, submitted_by_team_member_id, justification, '||wwv_flow.LF||
'     initiative_approv';
wwv_flow_imp.g_varchar2_table(21) := 'al_id, status, submitted, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (1, 1, 8504, 7, ''Specs are done, I am ';
wwv_flow_imp.g_varchar2_table(22) := 'ready to code.'','||wwv_flow.LF||
'     1, ''APPROVED'', sp_util.fix_demo_dates(sysdate-70), sp_util.fix_demo_dates(sysd';
wwv_flow_imp.g_varchar2_table(23) := 'ate-69), upper(''Ethan.Caldwell@acme.com''));'||wwv_flow.LF||
'insert into sp_project_approval_chain'||wwv_flow.LF||
'    (id, project_a';
wwv_flow_imp.g_varchar2_table(24) := 'pproval_id, team_member_id, status, last_status_on, final_yn, '||wwv_flow.LF||
'     created, created_by, updated, up';
wwv_flow_imp.g_varchar2_table(25) := 'dated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'    (1, 1, 14, ''APPROVED'', sp_util.fix_demo_dates(sysdate-67), ''Y'', '||wwv_flow.LF||
'     sp_ut';
wwv_flow_imp.g_varchar2_table(26) := 'il.fix_demo_dates(sysdate-70), upper(''Caleb.Foster@acme.com''), sp_util.fix_demo_dates(sysdate-67), u';
wwv_flow_imp.g_varchar2_table(27) := 'pper(''Chloe.Whitaker@acme.com''));'||wwv_flow.LF||
'insert into sp_project_approval_chain'||wwv_flow.LF||
'    (id, project_approval_id';
wwv_flow_imp.g_varchar2_table(28) := ', team_member_id, status, last_status_on, final_yn, '||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(29) := '    values'||wwv_flow.LF||
'    (2, 1, 16, ''APPROVED'', sp_util.fix_demo_dates(sysdate-68), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo';
wwv_flow_imp.g_varchar2_table(30) := '_dates(sysdate-67), upper(''Chloe.Whitaker@acme.com''), sp_util.fix_demo_dates(sysdate-68), upper(''May';
wwv_flow_imp.g_varchar2_table(31) := 'a.Patel@acme.com''));'||wwv_flow.LF||
'insert into sp_project_approval_chain'||wwv_flow.LF||
'    (id, project_approval_id, team_member';
wwv_flow_imp.g_varchar2_table(32) := '_id, status, last_status_on, final_yn, '||wwv_flow.LF||
'     created, created_by, updated, updated_by)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(33) := '  (3, 1, 17, ''APPROVED'', sp_util.fix_demo_dates(sysdate-69), ''Y'','||wwv_flow.LF||
'     sp_util.fix_demo_dates(sysdat';
wwv_flow_imp.g_varchar2_table(34) := 'e-68), upper(''Maya.Patel@acme.com''), sp_util.fix_demo_dates(sysdate-69), upper(''Ethan.Caldwell@acme.';
wwv_flow_imp.g_varchar2_table(35) := 'com''));'||wwv_flow.LF||
''||wwv_flow.LF||
'sp_globals.g_audit_this := TRUE;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception'||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        sp_globals.g_audit';
wwv_flow_imp.g_varchar2_table(36) := '_this := TRUE;'||wwv_flow.LF||
'end;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(454681718714815500)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'sample data - approvals'
,p_sequence=>9280
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
