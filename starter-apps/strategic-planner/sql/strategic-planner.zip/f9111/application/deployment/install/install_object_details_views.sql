prompt --application/deployment/install/install_object_details_views
begin
--   Manifest
--     INSTALL: INSTALL-object details views
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace view sp_area_details_v as'||wwv_flow.LF||
'select f.ID area_id,'||wwv_flow.LF||
'       f.area AREA,'||wwv_flow.LF||
'       substr(f';
wwv_flow_imp.g_varchar2_table(2) := '.DESCRIPTION,1,80)||decode(greatest(length(f.DESCRIPTION),80),80,null,''...'') DESCRIPTION,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(3) := '       -- owner'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       tm.id owner_id,'||wwv_flow.LF||
'       case when tm.id is null then ''none'' else tm.';
wwv_flow_imp.g_varchar2_table(4) := 'first_name||'' ''||tm.last_name end owner_name,'||wwv_flow.LF||
'       case when tm.id is null then ''none'' else tm.ema';
wwv_flow_imp.g_varchar2_table(5) := 'il end owner_email,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       f.tags,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- initiatives'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       (selec';
wwv_flow_imp.g_varchar2_table(6) := 't count(*) '||wwv_flow.LF||
'          from SP_INITIATIVES i '||wwv_flow.LF||
'         where i.AREA_ID = f.id) initiative_count,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(7) := '   --'||wwv_flow.LF||
'       -- projects'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       (select count(*) '||wwv_flow.LF||
'          from SP_PROJECTS p '||wwv_flow.LF||
'         w';
wwv_flow_imp.g_varchar2_table(8) := 'here ARCHIVED_YN = ''N'' and '||wwv_flow.LF||
'               p.DUPLICATE_OF_PROJECT_ID is null and'||wwv_flow.LF||
'               p.in';
wwv_flow_imp.g_varchar2_table(9) := 'itiative_id in (select distinct id '||wwv_flow.LF||
'                                     from SP_INITIATIVES i '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(10) := '                                where i.AREA_ID = f.id)) project_count,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       (select cou';
wwv_flow_imp.g_varchar2_table(11) := 'nt(*) '||wwv_flow.LF||
'          from SP_PROJECTS p '||wwv_flow.LF||
'         where ARCHIVED_YN = ''N'' and '||wwv_flow.LF||
'               p.DUPLICAT';
wwv_flow_imp.g_varchar2_table(12) := 'E_OF_PROJECT_ID is null and'||wwv_flow.LF||
'               p.pct_complete != 0 and '||wwv_flow.LF||
'               p.pct_complete !=';
wwv_flow_imp.g_varchar2_table(13) := ' 100 and'||wwv_flow.LF||
'               p.initiative_id in (select distinct id '||wwv_flow.LF||
'                                    ';
wwv_flow_imp.g_varchar2_table(14) := ' from SP_INITIATIVES i '||wwv_flow.LF||
'                                    where i.AREA_ID = f.id)) open_project_co';
wwv_flow_imp.g_varchar2_table(15) := 'unt,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       (select max(p.created) '||wwv_flow.LF||
'          from SP_PROJECTS p '||wwv_flow.LF||
'         where p.ARCHIVE';
wwv_flow_imp.g_varchar2_table(16) := 'D_YN = ''N'' and '||wwv_flow.LF||
'               p.DUPLICATE_OF_PROJECT_ID is null and'||wwv_flow.LF||
'               p.initiative_id ';
wwv_flow_imp.g_varchar2_table(17) := 'in (select distinct id '||wwv_flow.LF||
'                                     from SP_INITIATIVES i '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(18) := '                    where i.AREA_ID = f.id)) last_project_created_date,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- most rec';
wwv_flow_imp.g_varchar2_table(19) := 'ently created project'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       (select max(p.updated) '||wwv_flow.LF||
'          from SP_PROJECTS p '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(20) := '  where p.ARCHIVED_YN = ''N'' and '||wwv_flow.LF||
'               p.DUPLICATE_OF_PROJECT_ID is null and'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(21) := ' p.initiative_id in (select distinct id '||wwv_flow.LF||
'                                     from SP_INITIATIVES i ';
wwv_flow_imp.g_varchar2_table(22) := ''||wwv_flow.LF||
'                                    where i.AREA_ID = f.id)) last_project_updated_date,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(23) := '      -- audit info'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       f.created created_date,'||wwv_flow.LF||
'       lower(f.created_by) created_by_a';
wwv_flow_imp.g_varchar2_table(24) := 'pp_username,'||wwv_flow.LF||
'       f.updated last_updated_date,'||wwv_flow.LF||
'       lower(f.updated_by) last_updated_by_app_user';
wwv_flow_imp.g_varchar2_table(25) := 'name'||wwv_flow.LF||
'  from SP_AREAS f,'||wwv_flow.LF||
'       sp_team_members tm'||wwv_flow.LF||
'  where f.OWNER_ID = tm.id(+);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace';
wwv_flow_imp.g_varchar2_table(26) := ' view sp_initiative_details_v as'||wwv_flow.LF||
'select i.ID initiative_id,'||wwv_flow.LF||
'       i.INITIATIVE,'||wwv_flow.LF||
'       i.area_id,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(27) := '      f.AREA,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- details'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       decode(i.OBJECTIVE,null,''none'',substr(i.O';
wwv_flow_imp.g_varchar2_table(28) := 'BJECTIVE,1,80)||decode(greatest(length(i.objective),80),80,null,''...'')) OBJECTIVE,'||wwv_flow.LF||
'       lower(i.ta';
wwv_flow_imp.g_varchar2_table(29) := 'gs) tags,'||wwv_flow.LF||
'       (select count(*)'||wwv_flow.LF||
'          from sp_initiative_focus_areas'||wwv_flow.LF||
'         where initiative';
wwv_flow_imp.g_varchar2_table(30) := '_id = i.id'||wwv_flow.LF||
'           and active_yn = ''Y'') active_focus_area_count,'||wwv_flow.LF||
'       (select listagg(focus_are';
wwv_flow_imp.g_varchar2_table(31) := 'a, '', '' on overflow truncate with count) within group (order by 1) '||wwv_flow.LF||
'          from sp_initiative_foc';
wwv_flow_imp.g_varchar2_table(32) := 'us_areas'||wwv_flow.LF||
'         where initiative_id = i.id'||wwv_flow.LF||
'           and active_yn = ''Y'') active_focus_areas,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(33) := '    --'||wwv_flow.LF||
'       -- owner'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       tm.id owner_id,'||wwv_flow.LF||
'       case when tm.id is null then ''none'' e';
wwv_flow_imp.g_varchar2_table(34) := 'lse tm.first_name||'' ''||tm.last_name end owner_name,'||wwv_flow.LF||
'       case when tm.id is null then ''none'' else';
wwv_flow_imp.g_varchar2_table(35) := ' tm.email end owner_email,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- project counts'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       (select count(*) '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(36) := '       from sp_projects p '||wwv_flow.LF||
'         where p.initiative_id = i.id and '||wwv_flow.LF||
'               p.DUPLICATE_OF_';
wwv_flow_imp.g_varchar2_table(37) := 'PROJECT_ID is null and'||wwv_flow.LF||
'               ARCHIVED_YN = ''N'') project_count,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       (select cou';
wwv_flow_imp.g_varchar2_table(38) := 'nt(*) '||wwv_flow.LF||
'          from sp_projects p '||wwv_flow.LF||
'         where p.initiative_id = i.id and '||wwv_flow.LF||
'               p.DUP';
wwv_flow_imp.g_varchar2_table(39) := 'LICATE_OF_PROJECT_ID is null and'||wwv_flow.LF||
'               p.pct_complete != 0 and '||wwv_flow.LF||
'               p.pct_comple';
wwv_flow_imp.g_varchar2_table(40) := 'te != 100 and'||wwv_flow.LF||
'               ARCHIVED_YN = ''N'') open_project_count,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       (select count(*';
wwv_flow_imp.g_varchar2_table(41) := ') '||wwv_flow.LF||
'          from sp_projects p '||wwv_flow.LF||
'         where p.initiative_id = i.id and '||wwv_flow.LF||
'               p.DUPLICA';
wwv_flow_imp.g_varchar2_table(42) := 'TE_OF_PROJECT_ID is null and'||wwv_flow.LF||
'               p.pct_complete = 100 and'||wwv_flow.LF||
'               ARCHIVED_YN = ''N';
wwv_flow_imp.g_varchar2_table(43) := ''') completed_project_count,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- last projects'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       nvl((select max(p.cre';
wwv_flow_imp.g_varchar2_table(44) := 'ated) '||wwv_flow.LF||
'              from sp_projects p '||wwv_flow.LF||
'             where p.initiative_id = i.id and '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(45) := '       p.ARCHIVED_YN = ''N'' and '||wwv_flow.LF||
'                   p.DUPLICATE_OF_PROJECT_ID is null ),i.updated) la';
wwv_flow_imp.g_varchar2_table(46) := 'st_project_created_date,'||wwv_flow.LF||
'       nvl((select max(p.updated) '||wwv_flow.LF||
'              from sp_projects p '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(47) := '       where p.initiative_id = i.id and '||wwv_flow.LF||
'                   p.ARCHIVED_YN = ''N'' and '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(48) := '    p.DUPLICATE_OF_PROJECT_ID is null ),i.updated) last_project_updated_date,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- au';
wwv_flow_imp.g_varchar2_table(49) := 'dit info'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       i.created created_date,'||wwv_flow.LF||
'       lower(i.created_by) created_by_app_username';
wwv_flow_imp.g_varchar2_table(50) := ','||wwv_flow.LF||
'       i.updated last_updated_date,'||wwv_flow.LF||
'       lower(i.updated_by) last_updated_by_app_username'||wwv_flow.LF||
'  from';
wwv_flow_imp.g_varchar2_table(51) := ' SP_INITIATIVES i, '||wwv_flow.LF||
'       sp_areas f,'||wwv_flow.LF||
'       sp_team_members tm'||wwv_flow.LF||
' where i.area_id = f.id and'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(52) := 'i.SPONSOR_ID = tm.id(+);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace view sp_project_details_v as'||wwv_flow.LF||
'  select  '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(53) := '   -- project information '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       p.ID as project_id, '||wwv_flow.LF||
'       p.PROJECT, '||wwv_flow.LF||
'       decode(n';
wwv_flow_imp.g_varchar2_table(54) := 'vl(dbms_lob.getlength(p.description),0),0,''Not Provided'', '||wwv_flow.LF||
'           dbms_lob.substr(p.description,';
wwv_flow_imp.g_varchar2_table(55) := '200,1)|| '||wwv_flow.LF||
'           decode(greatest(dbms_lob.getlength(p.description),200),200,null,''...'')) descrip';
wwv_flow_imp.g_varchar2_table(56) := 'tion, '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       -- initiative and area '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       p.initiative_id, '||wwv_flow.LF||
'       i.initia';
wwv_flow_imp.g_varchar2_table(57) := 'tive, '||wwv_flow.LF||
'       i.area_id, '||wwv_flow.LF||
'       (select area from sp_areas a where a.id = i.area_id) area, '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(58) := '(select focus_area from sp_initiative_focus_areas where id = p.focus_area_id) focus_area, '||wwv_flow.LF||
'       --';
wwv_flow_imp.g_varchar2_table(59) := ' '||wwv_flow.LF||
'       -- owner '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       p.owner_id, '||wwv_flow.LF||
'       (select FIRST_NAME ||'' ''||last_name from SP';
wwv_flow_imp.g_varchar2_table(60) := '_TEAM_MEMBERS x where x.ID = p.OWNER_ID) owner_name, '||wwv_flow.LF||
'       (select email from SP_TEAM_MEMBERS x wh';
wwv_flow_imp.g_varchar2_table(61) := 'ere x.ID = p.OWNER_ID) owner_email, '||wwv_flow.LF||
'       (select lower(tags) from sp_team_members where id = p.ow';
wwv_flow_imp.g_varchar2_table(62) := 'ner_id) owner_tags, '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       -- project details '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       (select ''P''||PRIORITY f';
wwv_flow_imp.g_varchar2_table(63) := 'rom SP_PROJECT_PRIORITIES x where x.ID = p.PRIORITY_ID) priority, '||wwv_flow.LF||
'       p.PROJECT_SIZE, '||wwv_flow.LF||
'       z.';
wwv_flow_imp.g_varchar2_table(64) := 'size_description, '||wwv_flow.LF||
'       z.effort_days, '||wwv_flow.LF||
'       round((100 - p.PCT_COMPLETE) * z.effort_days *.01) ';
wwv_flow_imp.g_varchar2_table(65) := 'days_remaining, '||wwv_flow.LF||
'       p.PCT_COMPLETE pct_complete, '||wwv_flow.LF||
'       case when p.pct_complete >= s.min_pc_fo';
wwv_flow_imp.g_varchar2_table(66) := 'r_status and p.pct_complete != 100 '||wwv_flow.LF||
'            then nvl((select status from sp_project_statuses '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(67) := '                     where id = p.status_id),''Not Set'')'||wwv_flow.LF||
'            else ''NA'' '||wwv_flow.LF||
'            end statu';
wwv_flow_imp.g_varchar2_table(68) := 's, '||wwv_flow.LF||
'       case when p.requires_reviews_yn = ''Y'' then ''Yes'' else ''No'' end requires_reviews, '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(69) := 'case when p.doc_impact_yn = ''Y'' then ''Yes'' else ''No'' end doc_impact, '||wwv_flow.LF||
'       replace(lower(p.tags),''';
wwv_flow_imp.g_varchar2_table(70) := ','','', '') as tags, '||wwv_flow.LF||
'       (select group_name from sp_project_groups '||wwv_flow.LF||
'         where id = p.project_g';
wwv_flow_imp.g_varchar2_table(71) := 'roup_id) project_group, '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       -- target (release or date) '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       p.release_';
wwv_flow_imp.g_varchar2_table(72) := 'id,'||wwv_flow.LF||
'       (select t.release_train||'' ''||t.release from SP_RELEASE_TRAINS t where t.id = p.release_i';
wwv_flow_imp.g_varchar2_table(73) := 'd) release,'||wwv_flow.LF||
'       p.target_complete, '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       external_ticket_identifier, '||wwv_flow.LF||
'       externa';
wwv_flow_imp.g_varchar2_table(74) := 'l_system_link, '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       -- contributors '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       (select listagg(distinct xtm.fi';
wwv_flow_imp.g_varchar2_table(75) := 'rst_name||'' ''||xtm.last_name, '', '' on overflow truncate with count) within group (order by 1) names ';
wwv_flow_imp.g_varchar2_table(76) := ''||wwv_flow.LF||
'          from SP_TASKS xpc, SP_TEAM_MEMBERS xtm '||wwv_flow.LF||
'         where xpc.project_id = p.id and '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(77) := '        xpc.OWNER_ID = xtm.id '||wwv_flow.LF||
'                ) contributor_names, '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       -- contributo';
wwv_flow_imp.g_varchar2_table(78) := 'r emails '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       (select listagg(distinct xtm.email, '', '' on overflow truncate with count';
wwv_flow_imp.g_varchar2_table(79) := ') within group (order by 1) names '||wwv_flow.LF||
'          from SP_TASKS xpc, SP_TEAM_MEMBERS xtm '||wwv_flow.LF||
'         where ';
wwv_flow_imp.g_varchar2_table(80) := 'xpc.project_id = p.id and '||wwv_flow.LF||
'               xpc.OWNER_ID = xtm.id '||wwv_flow.LF||
'               ) contributor_emails';
wwv_flow_imp.g_varchar2_table(81) := ', '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       -- reviews '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       (select count(*) from sp_tasks t, sp_task_types t';
wwv_flow_imp.g_varchar2_table(82) := 't '||wwv_flow.LF||
'         where t.project_id = p.id  '||wwv_flow.LF||
'           and nvl(t.task_sub_type_id,t.task_type_id) = tt.i';
wwv_flow_imp.g_varchar2_table(83) := 'd     '||wwv_flow.LF||
'           and tt.static_id like ''REVIEW%'') review_count, '||wwv_flow.LF||
'       (select listagg(distinct xt';
wwv_flow_imp.g_varchar2_table(84) := 'm.first_name||'' ''||xtm.last_name, '', '' on overflow truncate with count) within group (order by 1) na';
wwv_flow_imp.g_varchar2_table(85) := 'mes '||wwv_flow.LF||
'          from SP_TASKS xpc, SP_TEAM_MEMBERS xtm, sp_task_types tt '||wwv_flow.LF||
'         where xpc.project_';
wwv_flow_imp.g_varchar2_table(86) := 'id = p.id and '||wwv_flow.LF||
'               xpc.OWNER_ID = xtm.id and  '||wwv_flow.LF||
'               nvl(xpc.task_sub_type_id,xp';
wwv_flow_imp.g_varchar2_table(87) := 'c.task_type_id) = tt.id and  '||wwv_flow.LF||
'               tt.static_id like ''REVIEW%'' '||wwv_flow.LF||
'                ) reviewer';
wwv_flow_imp.g_varchar2_table(88) := '_names, '||wwv_flow.LF||
'       (select listagg(distinct xtm.email, '', '' on overflow truncate with count) within gro';
wwv_flow_imp.g_varchar2_table(89) := 'up (order by 1) names '||wwv_flow.LF||
'          from SP_TASKS xpc, SP_TEAM_MEMBERS xtm, sp_task_types tt '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(90) := 'where xpc.project_id = p.id and '||wwv_flow.LF||
'               xpc.OWNER_ID = xtm.id and  '||wwv_flow.LF||
'               nvl(xpc.t';
wwv_flow_imp.g_varchar2_table(91) := 'ask_sub_type_id,xpc.task_type_id) = tt.id and  '||wwv_flow.LF||
'               tt.static_id like ''REVIEW%'' '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(92) := '        ) reviewer_emails, '||wwv_flow.LF||
'       (select listagg(tt.task_type||'' - ''||nvl(to_char(t.target_complet';
wwv_flow_imp.g_varchar2_table(93) := 'e,''DD-MON-YYYY''),''No date''), '', '' on overflow truncate with count) within group (order by t.target_c';
wwv_flow_imp.g_varchar2_table(94) := 'omplete nulls first)  '||wwv_flow.LF||
'          from sp_tasks t, sp_task_types tt '||wwv_flow.LF||
'         where t.project_id = p.';
wwv_flow_imp.g_varchar2_table(95) := 'id  '||wwv_flow.LF||
'           and nvl(t.task_sub_type_id,t.task_type_id) = tt.id     '||wwv_flow.LF||
'           and tt.static_id ';
wwv_flow_imp.g_varchar2_table(96) := 'like ''REVIEW%'') reviews, '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       -- milestones '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       (select count(*) from s';
wwv_flow_imp.g_varchar2_table(97) := 'p_tasks t, sp_task_types tt '||wwv_flow.LF||
'         where t.project_id = p.id  '||wwv_flow.LF||
'           and nvl(t.task_sub_type';
wwv_flow_imp.g_varchar2_table(98) := '_id,t.task_type_id) = tt.id     '||wwv_flow.LF||
'           and tt.static_id like ''MILESTONE%'') milestone_count, '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(99) := '     (select listagg(tt.task_type||'' - ''||nvl(to_char(t.target_complete,''DD-MON-YYYY''),''No date''), ''';
wwv_flow_imp.g_varchar2_table(100) := ', '' on overflow truncate with count) within group (order by t.target_complete nulls first)  '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(101) := '   from sp_tasks t, sp_task_types tt '||wwv_flow.LF||
'         where t.project_id = p.id  '||wwv_flow.LF||
'           and nvl(t.task';
wwv_flow_imp.g_varchar2_table(102) := '_sub_type_id,t.task_type_id) = tt.id     '||wwv_flow.LF||
'           and tt.static_id like ''MILESTONE%'') milestones,';
wwv_flow_imp.g_varchar2_table(103) := ' '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       -- approvals '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       nvl((select listagg(t.approval_type||'' (''||initc';
wwv_flow_imp.g_varchar2_table(104) := 'ap(replace(status,''-'','' ''))||'')'','', '' on overflow truncate with count) '||wwv_flow.LF||
'                   within gr';
wwv_flow_imp.g_varchar2_table(105) := 'oup (order by submitted) '||wwv_flow.LF||
'              from (select approval_type_id, status, submitted, max(submit';
wwv_flow_imp.g_varchar2_table(106) := 'ted) over (partition by approval_type_id) last_submitted '||wwv_flow.LF||
'                      from sp_project_appr';
wwv_flow_imp.g_varchar2_table(107) := 'ovals '||wwv_flow.LF||
'                     where project_id = p.id) a, '||wwv_flow.LF||
'                   sp_approval_types t '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(108) := '          where a.submitted = a.last_submitted '||wwv_flow.LF||
'               and a.approval_type_id = t.id),''None''';
wwv_flow_imp.g_varchar2_table(109) := ') approvals, '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       -- last comments '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       (select max(dbms_lob.substr(c.bo';
wwv_flow_imp.g_varchar2_table(110) := 'dy,255,1)|| '||wwv_flow.LF||
'               decode(greatest(dbms_lob.getlength(c.body),255),255,null,''...'')) last_co';
wwv_flow_imp.g_varchar2_table(111) := 'mment  '||wwv_flow.LF||
'        from   SP_PROJECT_COMMENTS c  '||wwv_flow.LF||
'        where c.project_id = p.id and  '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(112) := ' c.private_yn = ''N'' and  '||wwv_flow.LF||
'              c.created = (select max(c2.created) from sp_project_comments';
wwv_flow_imp.g_varchar2_table(113) := ' c2 where c2.project_id = p.id and c2.private_yn = ''N'')) '||wwv_flow.LF||
'        as last_comment, '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(114) := '  (select max(c.created) from sp_project_comments c where c.project_id = p.id and c.private_yn = ''N''';
wwv_flow_imp.g_varchar2_table(115) := ') last_comment_on, '||wwv_flow.LF||
'       (select first_name||'' ''||last_name from SP_TEAM_MEMBERS t where t.id = (s';
wwv_flow_imp.g_varchar2_table(116) := 'elect max(c.author_id) from sp_project_comments c where c.project_id = p.id and c.created = (select ';
wwv_flow_imp.g_varchar2_table(117) := 'max(c.created) from sp_project_comments c where c.project_id = p.id and c.private_yn = ''N''))) last_c';
wwv_flow_imp.g_varchar2_table(118) := 'omment_by, '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       -- last owner comments '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       (select max(dbms_lob.substr(';
wwv_flow_imp.g_varchar2_table(119) := 'c.body,255,1)|| '||wwv_flow.LF||
'               decode(greatest(dbms_lob.getlength(c.body),255),255,null,''...'')) las';
wwv_flow_imp.g_varchar2_table(120) := 't_comment  '||wwv_flow.LF||
'        from   SP_PROJECT_COMMENTS c  '||wwv_flow.LF||
'        where c.project_id = p.id and  '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(121) := '     c.private_yn = ''N'' and  '||wwv_flow.LF||
'              c.AUTHOR_ID = p.owner_id and '||wwv_flow.LF||
'              c.created = ';
wwv_flow_imp.g_varchar2_table(122) := '(select max(c2.created) from sp_project_comments c2 where c2.project_id = p.id and c2.AUTHOR_ID = p.';
wwv_flow_imp.g_varchar2_table(123) := 'owner_id and c2.private_yn = ''N'')) '||wwv_flow.LF||
'        as last_comment_by_owner, '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       (select max';
wwv_flow_imp.g_varchar2_table(124) := '(c.created) from sp_project_comments c where c.project_id = p.id and c.author_id = p.owner_id and c.';
wwv_flow_imp.g_varchar2_table(125) := 'private_yn = ''N'') last_comment_by_owner_on, '||wwv_flow.LF||
'       (select count(*) from sp_project_comments c wher';
wwv_flow_imp.g_varchar2_table(126) := 'e c.project_id = p.id and c.created >= sysdate - 28 and c.private_yn = ''N'') comments_28d, '||wwv_flow.LF||
'       --';
wwv_flow_imp.g_varchar2_table(127) := ' '||wwv_flow.LF||
'       -- activity '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       nvl((select count(*) from SP_ACTIVITIES ap where ap.project_';
wwv_flow_imp.g_varchar2_table(128) := 'id = p.id and trunc(sysdate) >= ap.start_date and trunc(sysdate) <= ap.end_date),0) current_activity';
wwv_flow_imp.g_varchar2_table(129) := '_count, '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       -- favorites '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       (select count(*) '||wwv_flow.LF||
'          from sp_favor';
wwv_flow_imp.g_varchar2_table(130) := 'ites f  '||wwv_flow.LF||
'         where f.project_id = p.id) favorited, '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       -- views in last 28 days ';
wwv_flow_imp.g_varchar2_table(131) := ''||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       (select count(*) '||wwv_flow.LF||
'          from sp_proj_interactions_log l '||wwv_flow.LF||
'         where l.pro';
wwv_flow_imp.g_varchar2_table(132) := 'ject_id = p.id '||wwv_flow.LF||
'           and page_rendered >= sysdate-28) views_28d, '||wwv_flow.LF||
'       (select count(distinc';
wwv_flow_imp.g_varchar2_table(133) := 't(app_user)) '||wwv_flow.LF||
'          from sp_proj_interactions_log l '||wwv_flow.LF||
'         where l.project_id = p.id '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(134) := '    and page_rendered >= sysdate-28) distinct_user_views_28d, '||wwv_flow.LF||
'       -- '||wwv_flow.LF||
'       -- audit info '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(135) := '   -- '||wwv_flow.LF||
'       P.created created_date, '||wwv_flow.LF||
'       lower(p.created_by) created_by_app_username, '||wwv_flow.LF||
'       p';
wwv_flow_imp.g_varchar2_table(136) := '.updated last_updated_date, '||wwv_flow.LF||
'       lower(p.updated_by) last_updated_by_app_username '||wwv_flow.LF||
'from  SP_PROJE';
wwv_flow_imp.g_varchar2_table(137) := 'CTS p, '||wwv_flow.LF||
'      sp_project_scales s, '||wwv_flow.LF||
'      sp_initiatives i, '||wwv_flow.LF||
'      SP_PROJECT_SIZES z '||wwv_flow.LF||
'where nvl(p.A';
wwv_flow_imp.g_varchar2_table(138) := 'RCHIVED_YN,''N'') = ''N'' and  '||wwv_flow.LF||
'      p.DUPLICATE_OF_PROJECT_ID is null and '||wwv_flow.LF||
'      p.status_scale = s.sc';
wwv_flow_imp.g_varchar2_table(139) := 'ale_letter and  '||wwv_flow.LF||
'      p.initiative_id = i.id and '||wwv_flow.LF||
'      p.PROJECT_SIZE = z.project_size;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create o';
wwv_flow_imp.g_varchar2_table(140) := 'r replace view sp_project_change_history_v as'||wwv_flow.LF||
'select ''Project'' change_to,'||wwv_flow.LF||
'       h.PROJECT_ID       ';
wwv_flow_imp.g_varchar2_table(141) := '      project_id,'||wwv_flow.LF||
'       p.project                project,'||wwv_flow.LF||
'       h.change_type,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       in';
wwv_flow_imp.g_varchar2_table(142) := 'itcap(replace(h.attribute_column,''_'','' '')) ATTRIBUTE_COLUMN,'||wwv_flow.LF||
'       decode(h.old_value,''Y'',''Yes'',''N''';
wwv_flow_imp.g_varchar2_table(143) := ',''No'',h.old_value) OLD_VALUE,'||wwv_flow.LF||
'       decode(h.new_value,''Y'',''Yes'',''N'',''No'',h.new_value) NEW_VALUE,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(144) := '      h.CHANGED_ON             ATTRIBUTE_CHANGE_DATE,'||wwv_flow.LF||
'       lower(h.changed_by) changed_by_app_user';
wwv_flow_imp.g_varchar2_table(145) := 'name'||wwv_flow.LF||
'  from SP_PROJECT_HISTORY h,'||wwv_flow.LF||
'       sp_projects p'||wwv_flow.LF||
' where h.project_id = p.id'||wwv_flow.LF||
'union all'||wwv_flow.LF||
'select t';
wwv_flow_imp.g_varchar2_table(146) := 't.task_type ||'||wwv_flow.LF||
'       case when t.task_sub_type_id is not null'||wwv_flow.LF||
'            then (select '': ''||task_t';
wwv_flow_imp.g_varchar2_table(147) := 'ype from sp_task_types where t.task_sub_type_id = id)'||wwv_flow.LF||
'            end change_to,'||wwv_flow.LF||
'       t.PROJECT_ID';
wwv_flow_imp.g_varchar2_table(148) := '             project_id,'||wwv_flow.LF||
'       p.project                project,'||wwv_flow.LF||
'       h.change_type,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(149) := '     initcap(replace(h.attribute_column,''_'','' '')) ATTRIBUTE_COLUMN,'||wwv_flow.LF||
'       decode(h.old_value,''Y'',''Y';
wwv_flow_imp.g_varchar2_table(150) := 'es'',''N'',''No'',h.old_value) OLD_VALUE,'||wwv_flow.LF||
'       decode(h.new_value,''Y'',''Yes'',''N'',''No'',h.new_value) NEW_V';
wwv_flow_imp.g_varchar2_table(151) := 'ALUE,'||wwv_flow.LF||
'       h.CHANGED_ON             ATTRIBUTE_CHANGE_DATE,'||wwv_flow.LF||
'       lower(h.changed_by) changed_by_a';
wwv_flow_imp.g_varchar2_table(152) := 'pp_username'||wwv_flow.LF||
'  from sp_task_history h,'||wwv_flow.LF||
'       sp_tasks t,'||wwv_flow.LF||
'       sp_task_types tt,'||wwv_flow.LF||
'       sp_projects';
wwv_flow_imp.g_varchar2_table(153) := ' p'||wwv_flow.LF||
' where h.task_id = t.id'||wwv_flow.LF||
'   and t.task_type_id = tt.id'||wwv_flow.LF||
'   and t.project_id = p.id;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or rep';
wwv_flow_imp.g_varchar2_table(154) := 'lace view sp_release_details_v as'||wwv_flow.LF||
'select r.ID release_id,'||wwv_flow.LF||
'       r.RELEASE_TRAIN,'||wwv_flow.LF||
'       r.RELEASE,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(155) := '       initcap(nvl(r.release_type,''FULL'')) release_type,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- details'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(156) := '  r.RELEASE_OPEN_DATE,'||wwv_flow.LF||
'       r.RELEASE_TARGET_DATE,'||wwv_flow.LF||
'       case when release_open_completed = ''Y'' a';
wwv_flow_imp.g_varchar2_table(157) := 'nd nvl(release_completed,''N'') = ''N'' then'||wwv_flow.LF||
'           ''Open'''||wwv_flow.LF||
'           when nvl(release_open_complete';
wwv_flow_imp.g_varchar2_table(158) := 'd,''N'') = ''N'' then'||wwv_flow.LF||
'           ''Future'''||wwv_flow.LF||
'           else'||wwv_flow.LF||
'           ''Closed'' end release_status,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(159) := ' r.RELEASE_TARGET_DATE - r.RELEASE_OPEN_DATE duration_in_days,'||wwv_flow.LF||
'       case when r.RELEASE_TARGET_DAT';
wwv_flow_imp.g_varchar2_table(160) := 'E >= trunc(sysdate) '||wwv_flow.LF||
'            then trunc(r.RELEASE_TARGET_DATE) - trunc(sysdate) '||wwv_flow.LF||
'            end';
wwv_flow_imp.g_varchar2_table(161) := ' days_remaining,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- release owner'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       r.RELEASE_OWNER_ID owner_id,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(162) := '    (select first_Name||'' ''||last_name from sp_team_members tm where tm.id =  r.RELEASE_OWNER_ID) ow';
wwv_flow_imp.g_varchar2_table(163) := 'ner_name,'||wwv_flow.LF||
'       (select email from sp_team_members tm where tm.id =  r.RELEASE_OWNER_ID) owner_emai';
wwv_flow_imp.g_varchar2_table(164) := 'l,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- project counts'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       (select count(*) '||wwv_flow.LF||
'          from sp_projects ';
wwv_flow_imp.g_varchar2_table(165) := 'p '||wwv_flow.LF||
'         where p.release_id = r.id and '||wwv_flow.LF||
'               p.ARCHIVED_YN = ''N'' and '||wwv_flow.LF||
'               p.';
wwv_flow_imp.g_varchar2_table(166) := 'duplicate_of_project_id is null) project_count,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       (select count(*) c '||wwv_flow.LF||
'          from ';
wwv_flow_imp.g_varchar2_table(167) := 'sp_projects p '||wwv_flow.LF||
'         where p.release_id = r.id and '||wwv_flow.LF||
'               p.pct_complete != 100 and '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(168) := '            p.ARCHIVED_YN = ''N'' and '||wwv_flow.LF||
'               p.duplicate_of_project_id is null) open_project_';
wwv_flow_imp.g_varchar2_table(169) := 'count,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       (select count(*) c '||wwv_flow.LF||
'       from sp_projects p '||wwv_flow.LF||
'       where p.release_id = r';
wwv_flow_imp.g_varchar2_table(170) := '.id and'||wwv_flow.LF||
'             p.pct_complete = 100 and '||wwv_flow.LF||
'             p.ARCHIVED_YN = ''N'' and '||wwv_flow.LF||
'             p.';
wwv_flow_imp.g_varchar2_table(171) := 'duplicate_of_project_id is null) completed_project_count,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       (select count(distinct OW';
wwv_flow_imp.g_varchar2_table(172) := 'NER_ID)'||wwv_flow.LF||
'          from SP_TASKS c '||wwv_flow.LF||
'         where c.PROJECT_ID in (select id '||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(173) := '            from sp_projects p'||wwv_flow.LF||
'                                 where p.release_id  = r.id and '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(174) := '                                   p.ARCHIVED_YN = ''N'' and '||wwv_flow.LF||
'                                       p';
wwv_flow_imp.g_varchar2_table(175) := '.duplicate_of_project_id is null)) project_contributor_count,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       nvl((select round(avg';
wwv_flow_imp.g_varchar2_table(176) := '(p.PCT_COMPLETE))'||wwv_flow.LF||
'              from sp_projects p '||wwv_flow.LF||
'             where p.release_id = r.id and '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(177) := '               p.ARCHIVED_YN = ''N'' and '||wwv_flow.LF||
'                   p.duplicate_of_project_id is null), 0) av';
wwv_flow_imp.g_varchar2_table(178) := 'g_project_pct_complete,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- last project update'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       (select max(updated';
wwv_flow_imp.g_varchar2_table(179) := ') '||wwv_flow.LF||
'          from sp_projects p '||wwv_flow.LF||
'         where p.release_id = r.id and '||wwv_flow.LF||
'               p.ARCHIVED_Y';
wwv_flow_imp.g_varchar2_table(180) := 'N = ''N'' and '||wwv_flow.LF||
'               p.duplicate_of_project_id is null) last_project_update,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(181) := ' -- milestone counts'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       (select count(*) from SP_RELEASE_MILESTONES m where m.RELEASE_';
wwv_flow_imp.g_varchar2_table(182) := 'ID = r.id) milestone_count,'||wwv_flow.LF||
'       (select count(*) from SP_RELEASE_MILESTONES m where m.RELEASE_ID ';
wwv_flow_imp.g_varchar2_table(183) := '= r.id and m.MILESTONE_COMPLETED_YN = ''Y'') completed_milestone_count,'||wwv_flow.LF||
''||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- audit inf';
wwv_flow_imp.g_varchar2_table(184) := 'o'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       r.created created_date,'||wwv_flow.LF||
'       lower(r.created_by) created_by_app_username,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(185) := '  r.updated last_updated_date,'||wwv_flow.LF||
'       lower(r.updated_by) last_updated_by_app_username'||wwv_flow.LF||
'  from SP_REL';
wwv_flow_imp.g_varchar2_table(186) := 'EASE_TRAINS r;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace view sp_person_details_v as'||wwv_flow.LF||
'select t.ID person_id,'||wwv_flow.LF||
'       t.FIRST';
wwv_flow_imp.g_varchar2_table(187) := '_NAME,'||wwv_flow.LF||
'       t.last_name,'||wwv_flow.LF||
'       t.email,'||wwv_flow.LF||
'       t.email_domain,'||wwv_flow.LF||
'       t.screen_name,'||wwv_flow.LF||
'       t.loc';
wwv_flow_imp.g_varchar2_table(188) := 'ation,'||wwv_flow.LF||
'       nvl((select COUNTRY_NAME from sp_countries cc where cc.id = t.country_id),''Unknown'') c';
wwv_flow_imp.g_varchar2_table(189) := 'ountry,'||wwv_flow.LF||
'       nvl((select region from sp_countries cc where cc.id = t.country_id),''Unknown'') region';
wwv_flow_imp.g_varchar2_table(190) := ','||wwv_flow.LF||
'       lower(t.TAGS) tags,'||wwv_flow.LF||
'       t.competencies,'||wwv_flow.LF||
'       decode(t.IS_CURRENT_YN,''Y'',''Yes'',''N'',''No''';
wwv_flow_imp.g_varchar2_table(191) := ',IS_CURRENT_YN) IS_ACTIVE,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- counts'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       (select count(*) from SP_AREA';
wwv_flow_imp.g_varchar2_table(192) := 'S f where f.owner_id = t.id) area_owner_count,'||wwv_flow.LF||
'       (select count(*) from SP_INITIATIVES i where i';
wwv_flow_imp.g_varchar2_table(193) := '.sponsor_id = t.id) initiative_owner_count,'||wwv_flow.LF||
'       (select count(*) from sp_projects p where p.owner';
wwv_flow_imp.g_varchar2_table(194) := '_id = t.id and ARCHIVED_YN = ''N'') project_owner_count,'||wwv_flow.LF||
'       (select count(*) from sp_tasks t, sp_p';
wwv_flow_imp.g_varchar2_table(195) := 'rojects p where t.owner_id = t.id and t.project_id = p.id and p.ARCHIVED_YN = ''N'') task_owner_count,';
wwv_flow_imp.g_varchar2_table(196) := '    '||wwv_flow.LF||
'       (select count(*) from SP_PROJECT_DOCUMENTS d where d.created_by = upper(t.email)) projec';
wwv_flow_imp.g_varchar2_table(197) := 't_contrib_doc_count,'||wwv_flow.LF||
'       (select count(*) from SP_INITIATIVE_DOCUMENTS d where d.created_by = upp';
wwv_flow_imp.g_varchar2_table(198) := 'er(t.email)) initiative_contrib_doc_count,'||wwv_flow.LF||
'       (select count(*) from SP_RELEASE_DOCUMENTS d where';
wwv_flow_imp.g_varchar2_table(199) := ' d.created_by = upper(t.email)) release_contrib_doc_count,'||wwv_flow.LF||
'       (select count(*) from SP_TASK_DOCU';
wwv_flow_imp.g_varchar2_table(200) := 'MENTS d where d.created_by = upper(t.email)) task_contrib_doc_count,'||wwv_flow.LF||
'       (select count(*) from SP';
wwv_flow_imp.g_varchar2_table(201) := '_PROJECT_COMMENTS c where c.AUTHOR_ID = t.id) proj_contrib_comment_count,'||wwv_flow.LF||
'       (select count(*) fr';
wwv_flow_imp.g_varchar2_table(202) := 'om SP_INITIATIVE_COMMENTS c where c.AUTHOR_ID = t.id) initiative_contrib_comment_count,'||wwv_flow.LF||
'       (sele';
wwv_flow_imp.g_varchar2_table(203) := 'ct count(*) from SP_RELEASE_COMMENTS c where c.AUTHOR_ID = t.id) release_contrib_comment_count,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(204) := '   (select count(*) from SP_TASK_COMMENTS c where c.AUTHOR_ID = t.id) task_contrib_comment_count,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(205) := '     (select count(*) from SP_ACTIVITIES ap where ap.TEAM_MEMBER_ID = t.id and ap.end_date >= trunc(';
wwv_flow_imp.g_varchar2_table(206) := 'sysdate)) active_activity_count,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- open reviews'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       (select count(*) ';
wwv_flow_imp.g_varchar2_table(207) := ''||wwv_flow.LF||
'          from SP_TASKS r, SP_TASK_TYPES tt, sp_task_statuses s'||wwv_flow.LF||
'         where r.OWNER_ID = t.id '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(208) := '          and nvl(r.task_sub_type_id,r.task_type_id) = tt.id'||wwv_flow.LF||
'           and tt.static_id like ''REVIE';
wwv_flow_imp.g_varchar2_table(209) := 'W%'''||wwv_flow.LF||
'           and r.status_id = s.id'||wwv_flow.LF||
'           and s.INDICATES_COMPLETE_YN != ''Y'') open_review_cou';
wwv_flow_imp.g_varchar2_table(210) := 'nt,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- groups'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       (select count(*)'||wwv_flow.LF||
'          from SP_GROUP_MEMBERS gm,';
wwv_flow_imp.g_varchar2_table(211) := ' SP_GROUPS g'||wwv_flow.LF||
'         where gm.group_id = g.id '||wwv_flow.LF||
'           and gm.team_member_id = t.id) group_membe';
wwv_flow_imp.g_varchar2_table(212) := 'rship_count,'||wwv_flow.LF||
'       (select LISTAGG(g.group_name, '', '' on overflow truncate with count) within group';
wwv_flow_imp.g_varchar2_table(213) := ' (order by 1)'||wwv_flow.LF||
'          from SP_GROUP_MEMBERS gm, SP_GROUPS g'||wwv_flow.LF||
'         where gm.group_id = g.id '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(214) := '        and gm.team_member_id = t.id) group_membership,'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'       -- audit info'||wwv_flow.LF||
'       --'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(215) := '    t.created created_date,'||wwv_flow.LF||
'       lower(t.created_by) created_by_app_username,'||wwv_flow.LF||
'       t.updated las';
wwv_flow_imp.g_varchar2_table(216) := 't_updated_date,'||wwv_flow.LF||
'       lower(t.updated_by) last_updated_by_app_username'||wwv_flow.LF||
'  from SP_TEAM_MEMBERS t;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(20048720392970665007)
,p_install_id=>wwv_flow_imp.id(176221033654625264606)
,p_name=>'object details views'
,p_sequence=>5030
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
