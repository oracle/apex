prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 9111
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>9111
,p_default_id_offset=>18048597155993173929
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select job_name from user_scheduler_jobs'||wwv_flow.LF||
'         where job_name = ''SP';
wwv_flow_imp.g_varchar2_table(2) := '_NOTIF_SUBSCRIPTIONS'''||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        sys.dbms_scheduler.drop_job(job_name => c1.job_name);'||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(3) := 'nd loop;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select job_name from user_scheduler_jobs'||wwv_flow.LF||
'         wher';
wwv_flow_imp.g_varchar2_table(4) := 'e job_name = ''SP_GENERATE_AI_PROJECT_SUMMARIES_JOB'''||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        sys.dbms_scheduler.drop_job(j';
wwv_flow_imp.g_varchar2_table(5) := 'ob_name => c1.job_name);'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select job_name from use';
wwv_flow_imp.g_varchar2_table(6) := 'r_scheduler_jobs'||wwv_flow.LF||
'         where job_name = ''SP_LOAD_OOO_JOB'''||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        sys.dbms_scheduler.d';
wwv_flow_imp.g_varchar2_table(7) := 'rop_job(job_name => c1.job_name);'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'drop sequence   sp_seq;'||wwv_flow.LF||
'drop sequence   sp_k';
wwv_flow_imp.g_varchar2_table(8) := 'b_stack_rank_seq;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop package    sp_globals;'||wwv_flow.LF||
'drop package    sp_release_timeline;'||wwv_flow.LF||
'drop package    ';
wwv_flow_imp.g_varchar2_table(9) := 'sp_log;'||wwv_flow.LF||
'drop package    sp_util;'||wwv_flow.LF||
'drop package    sp_summary_util;'||wwv_flow.LF||
'drop package    sp_comment_util;'||wwv_flow.LF||
'd';
wwv_flow_imp.g_varchar2_table(10) := 'rop package    sp_event_util;'||wwv_flow.LF||
'drop package    sp_value_compare;'||wwv_flow.LF||
'drop package    sp_contributor_summa';
wwv_flow_imp.g_varchar2_table(11) := 'ry;'||wwv_flow.LF||
'drop package    sp_approvals;'||wwv_flow.LF||
'drop procedure  sp_favorite_toggle;'||wwv_flow.LF||
'drop function   sp_date_range_';
wwv_flow_imp.g_varchar2_table(12) := 'pct_comp;'||wwv_flow.LF||
'drop function   sp_tag_diff;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop view sp_initiative_comments_v;'||wwv_flow.LF||
'drop view sp_init_focus_';
wwv_flow_imp.g_varchar2_table(13) := 'area_comments_v;'||wwv_flow.LF||
'drop view sp_project_comments_v;'||wwv_flow.LF||
'drop view sp_task_comments_v;'||wwv_flow.LF||
'drop view sp_release';
wwv_flow_imp.g_varchar2_table(14) := '_comments_v;'||wwv_flow.LF||
'drop view sp_documents_v;'||wwv_flow.LF||
'drop view sp_area_details_v;'||wwv_flow.LF||
'drop view sp_initiative_details_';
wwv_flow_imp.g_varchar2_table(15) := 'v;'||wwv_flow.LF||
'drop view sp_project_details_v;'||wwv_flow.LF||
'drop view sp_project_change_history_v;'||wwv_flow.LF||
'drop view sp_release_detai';
wwv_flow_imp.g_varchar2_table(16) := 'ls_v;'||wwv_flow.LF||
'drop view sp_person_details_v;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table SP_APP_NOMENCLATURE           cascade constraints;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(17) := 'drop table sp_app_settings               cascade constraints;'||wwv_flow.LF||
'drop table sp_app_log                 ';
wwv_flow_imp.g_varchar2_table(18) := '   cascade constraints;'||wwv_flow.LF||
'drop table sp_error_log                  cascade constraints;'||wwv_flow.LF||
'drop table SP_';
wwv_flow_imp.g_varchar2_table(19) := 'DEFAULT_TAGS               cascade constraints;'||wwv_flow.LF||
'drop table SP_RELEASE_MILESTONE_DEFAULT_TAGS cascade';
wwv_flow_imp.g_varchar2_table(20) := ' constraints;'||wwv_flow.LF||
'drop table sp_countries                  cascade constraints;'||wwv_flow.LF||
'drop table sp_project_pr';
wwv_flow_imp.g_varchar2_table(21) := 'iorities         cascade constraints;'||wwv_flow.LF||
'drop table sp_resource_types             cascade constraints;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(22) := 'drop table sp_team_members               cascade constraints;'||wwv_flow.LF||
'drop table SP_TEAM_MEMBER_NOTIFICATION';
wwv_flow_imp.g_varchar2_table(23) := 'S  cascade constraints;'||wwv_flow.LF||
'drop table sp_areas                      cascade constraints;'||wwv_flow.LF||
'drop table sp_';
wwv_flow_imp.g_varchar2_table(24) := 'initiatives                cascade constraints;'||wwv_flow.LF||
'drop table sp_initiative_history         cascade con';
wwv_flow_imp.g_varchar2_table(25) := 'straints;'||wwv_flow.LF||
'drop table sp_initiative_documents       cascade constraints;'||wwv_flow.LF||
'drop table sp_initiative_com';
wwv_flow_imp.g_varchar2_table(26) := 'ments        cascade constraints;'||wwv_flow.LF||
'drop table sp_initiative_links           cascade constraints;'||wwv_flow.LF||
'drop';
wwv_flow_imp.g_varchar2_table(27) := ' table sp_initiative_focus_areas     cascade constraints;'||wwv_flow.LF||
'drop table sp_init_focus_area_history    c';
wwv_flow_imp.g_varchar2_table(28) := 'ascade constraints;'||wwv_flow.LF||
'drop table sp_init_focus_area_documents  cascade constraints;'||wwv_flow.LF||
'drop table sp_init';
wwv_flow_imp.g_varchar2_table(29) := '_focus_area_comments   cascade constraints;'||wwv_flow.LF||
'drop table sp_init_focus_area_links      cascade constra';
wwv_flow_imp.g_varchar2_table(30) := 'ints;'||wwv_flow.LF||
'drop table sp_projects                   cascade constraints;'||wwv_flow.LF||
'drop table sp_project_history   ';
wwv_flow_imp.g_varchar2_table(31) := '         cascade constraints;'||wwv_flow.LF||
'drop table sp_project_contributors       cascade constraints;'||wwv_flow.LF||
'drop tab';
wwv_flow_imp.g_varchar2_table(32) := 'le sp_project_comments           cascade constraints;'||wwv_flow.LF||
'drop table sp_project_documents          casca';
wwv_flow_imp.g_varchar2_table(33) := 'de constraints;'||wwv_flow.LF||
'drop table sp_project_links              cascade constraints;'||wwv_flow.LF||
'drop table sp_project_';
wwv_flow_imp.g_varchar2_table(34) := 'related            cascade constraints;'||wwv_flow.LF||
'drop table sp_project_comments_emails    cascade constraints';
wwv_flow_imp.g_varchar2_table(35) := ';'||wwv_flow.LF||
'drop table sp_project_sizes              cascade constraints;'||wwv_flow.LF||
'drop table sp_project_groups        ';
wwv_flow_imp.g_varchar2_table(36) := '     cascade constraints;'||wwv_flow.LF||
'drop table sp_project_statuses           cascade constraints;'||wwv_flow.LF||
'drop table s';
wwv_flow_imp.g_varchar2_table(37) := 'p_release_trains             cascade constraints;'||wwv_flow.LF||
'drop table sp_release_comments           cascade c';
wwv_flow_imp.g_varchar2_table(38) := 'onstraints;'||wwv_flow.LF||
'drop table sp_release_milestone_types    cascade constraints;'||wwv_flow.LF||
'drop table sp_release_mile';
wwv_flow_imp.g_varchar2_table(39) := 'stones         cascade constraints;'||wwv_flow.LF||
'drop table sp_release_documents          cascade constraints;'||wwv_flow.LF||
'dr';
wwv_flow_imp.g_varchar2_table(40) := 'op table sp_release_history            cascade constraints;'||wwv_flow.LF||
'drop table SP_RELEASE_LINKS             ';
wwv_flow_imp.g_varchar2_table(41) := ' cascade constraints;'||wwv_flow.LF||
'drop table sp_proj_interactions_log      cascade constraints;'||wwv_flow.LF||
'drop table sp_fa';
wwv_flow_imp.g_varchar2_table(42) := 'vorites                  cascade constraints;'||wwv_flow.LF||
'drop table sp_configurable_text          cascade const';
wwv_flow_imp.g_varchar2_table(43) := 'raints;'||wwv_flow.LF||
'drop table sp_project_scales             cascade constraints;'||wwv_flow.LF||
'drop table sp_activity_types  ';
wwv_flow_imp.g_varchar2_table(44) := '           cascade constraints;'||wwv_flow.LF||
'drop table sp_activity_comments          cascade constraints;'||wwv_flow.LF||
'drop t';
wwv_flow_imp.g_varchar2_table(45) := 'able sp_activities                 cascade constraints;'||wwv_flow.LF||
'drop table sp_notifications              cas';
wwv_flow_imp.g_varchar2_table(46) := 'cade constraints;'||wwv_flow.LF||
'drop table sp_notification_subscriptions cascade constraints;'||wwv_flow.LF||
'drop table SP_GROUPS';
wwv_flow_imp.g_varchar2_table(47) := '                     cascade constraints;'||wwv_flow.LF||
'drop table SP_GROUP_MEMBERS              cascade constrain';
wwv_flow_imp.g_varchar2_table(48) := 'ts;'||wwv_flow.LF||
'drop table SP_DEFAULT_PEOPLE_TAGS        cascade constraints;'||wwv_flow.LF||
'drop table SP_EXTERNAL_TICKETING_S';
wwv_flow_imp.g_varchar2_table(49) := 'YSTEMS cascade constraints;'||wwv_flow.LF||
'drop table SP_APPLICATION_NOTIFICATIONS  cascade constraints;'||wwv_flow.LF||
'drop table';
wwv_flow_imp.g_varchar2_table(50) := ' sp_competencies               cascade constraints;'||wwv_flow.LF||
'drop table sp_task_comments              cascade';
wwv_flow_imp.g_varchar2_table(51) := ' constraints;'||wwv_flow.LF||
'drop table sp_task_documents             cascade constraints;'||wwv_flow.LF||
'drop table sp_task_links';
wwv_flow_imp.g_varchar2_table(52) := '                 cascade constraints;'||wwv_flow.LF||
'drop table sp_task_history               cascade constraints;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(53) := 'drop table sp_tasks                      cascade constraints;'||wwv_flow.LF||
'drop table sp_task_statuses           ';
wwv_flow_imp.g_varchar2_table(54) := '   cascade constraints;'||wwv_flow.LF||
'drop table sp_initiative_default_tasks   cascade constraints;'||wwv_flow.LF||
'drop table sp_';
wwv_flow_imp.g_varchar2_table(55) := 'task_types                 cascade constraints;'||wwv_flow.LF||
'drop table sp_comment_images             cascade con';
wwv_flow_imp.g_varchar2_table(56) := 'straints;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table sp_ai_prompts                 cascade constraints;'||wwv_flow.LF||
'drop table sp_project_ai_su';
wwv_flow_imp.g_varchar2_table(57) := 'mmaries       cascade constraints;'||wwv_flow.LF||
'drop table sp_release_ai_summaries       cascade constraints;'||wwv_flow.LF||
''||wwv_flow.LF||
'dr';
wwv_flow_imp.g_varchar2_table(58) := 'op table sp_approval_types             cascade constraints;'||wwv_flow.LF||
'drop table sp_initiative_approvals      ';
wwv_flow_imp.g_varchar2_table(59) := ' cascade constraints;'||wwv_flow.LF||
'drop table sp_initiative_approval_chain  cascade constraints;'||wwv_flow.LF||
'drop table sp_pr';
wwv_flow_imp.g_varchar2_table(60) := 'oject_approvals          cascade constraints;'||wwv_flow.LF||
'drop table sp_project_approval_chain     cascade const';
wwv_flow_imp.g_varchar2_table(61) := 'raints;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop table sp_events                     cascade constraints;'||wwv_flow.LF||
'drop table sp_event_series   ';
wwv_flow_imp.g_varchar2_table(62) := '            cascade constraints;'||wwv_flow.LF||
'drop table sp_event_types                cascade constraints;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop';
wwv_flow_imp.g_varchar2_table(63) := ' table sp_task_related               cascade constraints;'||wwv_flow.LF||
'drop table sp_relation_types             c';
wwv_flow_imp.g_varchar2_table(64) := 'ascade constraints;';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(176221033654625264606)
,p_welcome_message=>'This application installer will guide you through the process of creating your database objects and seed data.'
,p_configuration_message=>'You can configure the following attributes of your application.'
,p_build_options_message=>'You can choose to include the following build options.'
,p_validation_message=>'The following validations will be performed to ensure your system is compatible with this application.'
,p_install_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_message=>'The application installer has detected that this application''s supporting objects were previously installed.  This wizard will guide you through the process of upgrading these supporting objects.'
,p_upgrade_confirm_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_success_message=>'Your application''s supporting objects have been installed.'
,p_upgrade_failure_message=>'Installation of database objects and seed data has failed.'
,p_deinstall_success_message=>'Deinstallation complete.'
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
,p_required_names_available=>'SP_NOTIF_SUBSCRIPTIONS:SP_RELEASE_TIMELINE:SP_SEQ:SP_LOG:SP_VALUE_COMPARE:SP_CONTRIBUTOR_SUMMARY:SP_FAVORITE_TOGGLE:SP_DATE_RANGE_PCT_COMP:SP_TAG_DIFF:SP_PROJECT_PRIORITIES:SP_RESOURCE_TYPES:SP_TEAM_MEMBERS:SP_INITIATIVES:SP_INITIATIVE_DOCUMENTS:SP_I'
||'NITIATIVE_COMMENTS:SP_PROJECTS:SP_PROJECT_CONTRIBUTORS:SP_PROJECT_HISTORY:SP_PROJECT_COMMENTS:SP_PROJECT_DOCUMENTS:SP_PROJECT_LINKS:SP_PROJECT_RELATED:SP_APP_NOMENCLATURE:SP_APP_SETTINGS:SP_DEFAULT_TAGS:SP_COUNTRIES:SP_PROJECT_COMMENTS_EMAILS:SP_PROJ'
||'ECT_SIZES:SP_RELEASE_TRAINS:SP_RELEASE_COMMENTS:SP_RELEASE_MILESTONES:SP_RELEASE_DOCUMENTS:SP_RELEASE_HISTORY:SP_RELEASE_LINKS:SP_INITIATIVE_LINKS:SP_PROJ_INTERACTIONS_LOG:SP_FAVORITES:SP_CONFIGURABLE_TEXT:SP_PROJECT_SCALES:SP_ACTIVITY_TYPES:SP_ACTIV'
||'ITIES:SP_NOTIFICATIONS:SP_NOTIFICATION_SUBSCRIPTIONS:SP_GROUPS:SP_GROUP_MEMBERS:SP_DEFAULT_PEOPLE_TAGS:SP_EXTERNAL_TICKETING_SYSTEMS:SP_APPLICATION_NOTIFICATIONS:SP_COMPETENCIES:SP_TASK_TYPES:SP_INITIATIVE_DEFAULT_TASKS:SP_TASK_STATUSES:SP_TASKS:SP_T'
||'ASK_HISTORY:SP_TASK_LINKS:SP_TASK_DOCUMENTS:SP_TASK_COMMENTS:SP_AREAS:SP_INITIATIVE_FOCUS_AREAS:SP_TEAM_MEMBER_NOTIFICATIONS:SP_APP_LOG:SP_GLOBALS:SP_APPROVAL_TYPES:SP_INITIATIVE_APPROVALS:SP_INITIATIVE_APPROVAL_CHAIN:SP_PROJECT_APPROVALS:SP_PROJECT_'
||'APPROVAL_CHAIN:SP_COMMENT_IMAGES:SP_UTIL:SP_COMMENT_UTIL:SP_AI_PROMPTS:SP_PROJECT_AI_SUMMARIES:SP_RELEASE_AI_SUMMARIES:SP_DOCUMENTS_V:SP_ERROR_LOG:SP_EVENT_TYPES:SP_EVENT_SERIES:SP_EVENTS:SP_RELATION_TYPES:SP_TASK_RELATED:SP_PERSON_DETAILS_V:SP_RELEA'
||'SE_DETAILS_V:SP_PROJECT_CHANGE_HISTORY_V:SP_PROJECT_DETAILS_V:SP_INITIATIVE_DETAILS_V:SP_ACTIVITY_COMMENTS'
);
wwv_flow_imp.component_end;
end;
/
