prompt --application/deployment/install/install_create_triggers
begin
--   Manifest
--     INSTALL: INSTALL-create triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger qask_log_bi'||wwv_flow.LF||
'    before insert'||wwv_flow.LF||
'    on qask_log'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    :';
wwv_flow_imp.g_varchar2_table(2) := 'new.created_on    := sysdate;'||wwv_flow.LF||
'    :new.created_trunc := trunc(sysdate);'||wwv_flow.LF||
'    :new.created_by    := lo';
wwv_flow_imp.g_varchar2_table(3) := 'wer(nvl(sys_context(''APEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'end sch_log_bi;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger';
wwv_flow_imp.g_varchar2_table(4) := ' qask_service_terms_biu'||wwv_flow.LF||
'    before insert or update '||wwv_flow.LF||
'    on qask_service_terms'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begi';
wwv_flow_imp.g_varchar2_table(5) := 'n'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.row_version := 1;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.row_vers';
wwv_flow_imp.g_varchar2_table(6) := 'ion := nvl(:old.row_version,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_on := sys';
wwv_flow_imp.g_varchar2_table(7) := 'date;'||wwv_flow.LF||
'        :new.created_by := lower(nvl(sys_context(''APEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'    end i';
wwv_flow_imp.g_varchar2_table(8) := 'f;'||wwv_flow.LF||
'    :new.updated_on := sysdate;'||wwv_flow.LF||
'    :new.updated_by := lower(nvl(sys_context(''APEX$SESSION'',''APP_';
wwv_flow_imp.g_varchar2_table(9) := 'USER''),user)); '||wwv_flow.LF||
'end qask_service_terms_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger qask_restricted_email_domai';
wwv_flow_imp.g_varchar2_table(10) := 'ns_biu'||wwv_flow.LF||
'    before insert or update '||wwv_flow.LF||
'    on qask_restricted_email_domains'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(11) := 'if inserting then'||wwv_flow.LF||
'        :new.row_version := 1;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.row_version :=';
wwv_flow_imp.g_varchar2_table(12) := ' nvl(:old.row_version,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_on := sysdate;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(13) := '        :new.created_by := lower(nvl(sys_context(''APEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(14) := ' :new.updated_on := sysdate;'||wwv_flow.LF||
'    :new.updated_by := lower(nvl(sys_context(''APEX$SESSION'',''APP_USER'')';
wwv_flow_imp.g_varchar2_table(15) := ',user)); '||wwv_flow.LF||
'    :new.EMAIL_DOMAIN := lower(:new.EMAIL_DOMAIN);'||wwv_flow.LF||
'end qask_restricted_email_domains_biu;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(16) := '/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger qask_settings_biu'||wwv_flow.LF||
'    before insert or update '||wwv_flow.LF||
'    on qask_settings'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(17) := ' for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.row_version := 1;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(18) := '     :new.row_version := nvl(:old.row_version,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new';
wwv_flow_imp.g_varchar2_table(19) := '.created_on := sysdate;'||wwv_flow.LF||
'        :new.created_by := lower(nvl(sys_context(''APEX$SESSION'',''APP_USER''),';
wwv_flow_imp.g_varchar2_table(20) := 'user)); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated_on := sysdate;'||wwv_flow.LF||
'    :new.updated_by := lower(nvl(sys_context(''A';
wwv_flow_imp.g_varchar2_table(21) := 'PEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'end qask_settings_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger qask_account_r';
wwv_flow_imp.g_varchar2_table(22) := 'equests_biu'||wwv_flow.LF||
'    before insert or update '||wwv_flow.LF||
'    on qask_account_requests '||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if';
wwv_flow_imp.g_varchar2_table(23) := ' inserting then'||wwv_flow.LF||
'        :new.row_version := 1;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.row_version := n';
wwv_flow_imp.g_varchar2_table(24) := 'vl(:old.row_version,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_on := sysdate;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(25) := '      :new.created_by := lower(nvl(sys_context(''APEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'        --'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(26) := '  :new.user_agent      := substr(owa_util.get_cgi_env(''HTTP_USER_AGENT''),1,4000);'||wwv_flow.LF||
'        :new.x_for';
wwv_flow_imp.g_varchar2_table(27) := 'warded_for := substr(owa_util.get_cgi_env(''X-FORWARDED-FOR''),1,4000);'||wwv_flow.LF||
'        :new.remote_addr     :';
wwv_flow_imp.g_varchar2_table(28) := '= substr(owa_util.get_cgi_env(''REMOTE_ADDR''),1,4000);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated_on := sysdate;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(29) := '  :new.updated_by := lower(nvl(sys_context(''APEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'end qask_account_requ';
wwv_flow_imp.g_varchar2_table(30) := 'ests_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger qask_verify_tokens_biu'||wwv_flow.LF||
'    before insert or update '||wwv_flow.LF||
'    on qa';
wwv_flow_imp.g_varchar2_table(31) := 'sk_verify_tokens'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.row_version := 1;'||wwv_flow.LF||
'    els';
wwv_flow_imp.g_varchar2_table(32) := 'if updating then'||wwv_flow.LF||
'        :new.row_version := nvl(:old.row_version,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserti';
wwv_flow_imp.g_varchar2_table(33) := 'ng then'||wwv_flow.LF||
'        :new.created_on := sysdate;'||wwv_flow.LF||
'        :new.created_by := lower(nvl(sys_context(''APEX$S';
wwv_flow_imp.g_varchar2_table(34) := 'ESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated_on := sysdate;'||wwv_flow.LF||
'    :new.updated_by := lowe';
wwv_flow_imp.g_varchar2_table(35) := 'r(nvl(sys_context(''APEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'end qask_verify_tokens_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or repla';
wwv_flow_imp.g_varchar2_table(36) := 'ce trigger qask_answer_sets_biu'||wwv_flow.LF||
'    before insert or update '||wwv_flow.LF||
'    on qask_answer_sets'||wwv_flow.LF||
'    for each ro';
wwv_flow_imp.g_varchar2_table(37) := 'w'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.row_version := 1;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.ro';
wwv_flow_imp.g_varchar2_table(38) := 'w_version := nvl(:old.row_version,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_on ';
wwv_flow_imp.g_varchar2_table(39) := ':= sysdate;'||wwv_flow.LF||
'        :new.created_by := lower(nvl(sys_context(''APEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(40) := ' end if;'||wwv_flow.LF||
'    :new.updated_on := sysdate;'||wwv_flow.LF||
'    :new.updated_by := lower(nvl(sys_context(''APEX$SESSION''';
wwv_flow_imp.g_varchar2_table(41) := ',''APP_USER''),user)); '||wwv_flow.LF||
'end qask_answer_sets_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger qask_aset_answers_biu'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(42) := '   before insert or update '||wwv_flow.LF||
'    on qask_aset_answers'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(43) := '      :new.row_version := 1;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.row_version := nvl(:old.row_versio';
wwv_flow_imp.g_varchar2_table(44) := 'n,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_on := sysdate;'||wwv_flow.LF||
'        :new.created';
wwv_flow_imp.g_varchar2_table(45) := '_by := lower(nvl(sys_context(''APEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated_on := ';
wwv_flow_imp.g_varchar2_table(46) := 'sysdate;'||wwv_flow.LF||
'    :new.updated_by := lower(nvl(sys_context(''APEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'end qask_a';
wwv_flow_imp.g_varchar2_table(47) := 'set_answers_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-----------------'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger qask_sessions_biu'||wwv_flow.LF||
'    before insert';
wwv_flow_imp.g_varchar2_table(48) := ' or update '||wwv_flow.LF||
'    on qask_sessions'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.row_versi';
wwv_flow_imp.g_varchar2_table(49) := 'on := 1;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.row_version := nvl(:old.row_version,0) + 1;'||wwv_flow.LF||
'    end if';
wwv_flow_imp.g_varchar2_table(50) := ';'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_on := sysdate;'||wwv_flow.LF||
'        :new.created_by := lower(nvl(sys';
wwv_flow_imp.g_varchar2_table(51) := '_context(''APEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated_on := sysdate;'||wwv_flow.LF||
'    :new.up';
wwv_flow_imp.g_varchar2_table(52) := 'dated_by := lower(nvl(sys_context(''APEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'end qask_sessions_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'crea';
wwv_flow_imp.g_varchar2_table(53) := 'te or replace trigger qask_session_questions_biu'||wwv_flow.LF||
'    before insert or update '||wwv_flow.LF||
'    on qask_session_qu';
wwv_flow_imp.g_varchar2_table(54) := 'estions'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.row_version := 1;'||wwv_flow.LF||
'    elsif updati';
wwv_flow_imp.g_varchar2_table(55) := 'ng then'||wwv_flow.LF||
'        :new.row_version := nvl(:old.row_version,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(56) := '       :new.created_on := sysdate;'||wwv_flow.LF||
'        :new.created_by := lower(nvl(sys_context(''APEX$SESSION'',''';
wwv_flow_imp.g_varchar2_table(57) := 'APP_USER''),user)); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated_on := sysdate;'||wwv_flow.LF||
'    :new.updated_by := lower(nvl(sys';
wwv_flow_imp.g_varchar2_table(58) := '_context(''APEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'end qask_session_questions_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace tr';
wwv_flow_imp.g_varchar2_table(59) := 'igger qask_sess_question_answers_biu'||wwv_flow.LF||
'    before insert or update '||wwv_flow.LF||
'    on qask_sess_question_answers'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(60) := '    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.row_version := 1;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(61) := '        :new.row_version := nvl(:old.row_version,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :';
wwv_flow_imp.g_varchar2_table(62) := 'new.created_on := sysdate;'||wwv_flow.LF||
'        :new.created_by := lower(nvl(sys_context(''APEX$SESSION'',''APP_USER';
wwv_flow_imp.g_varchar2_table(63) := '''),user)); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated_on := sysdate;'||wwv_flow.LF||
'    :new.updated_by := lower(nvl(sys_context';
wwv_flow_imp.g_varchar2_table(64) := '(''APEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'end qask_sess_question_answers_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'cre';
wwv_flow_imp.g_varchar2_table(65) := 'ate or replace trigger qask_responses_biu'||wwv_flow.LF||
'    before insert or update '||wwv_flow.LF||
'    on qask_responses'||wwv_flow.LF||
'    for';
wwv_flow_imp.g_varchar2_table(66) := ' each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.row_version := 1;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(67) := ' :new.row_version := nvl(:old.row_version,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.ape';
wwv_flow_imp.g_varchar2_table(68) := 'x_session := sys_context(''APEX$SESSION'',''APP_SESSION'');'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        :new.created_on := sysdat';
wwv_flow_imp.g_varchar2_table(69) := 'e;'||wwv_flow.LF||
'        :new.created_by := lower(nvl(sys_context(''APEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'        --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(70) := '       :new.user_agent      := substr(owa_util.get_cgi_env(''HTTP_USER_AGENT''),1,4000);'||wwv_flow.LF||
'        :new.';
wwv_flow_imp.g_varchar2_table(71) := 'x_forwarded_for := substr(owa_util.get_cgi_env(''X-FORWARDED-FOR''),1,4000);'||wwv_flow.LF||
'        :new.remote_addr ';
wwv_flow_imp.g_varchar2_table(72) := '    := substr(owa_util.get_cgi_env(''REMOTE_ADDR''),1,4000);'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated_on := sysdat';
wwv_flow_imp.g_varchar2_table(73) := 'e;'||wwv_flow.LF||
'    :new.updated_by := lower(nvl(sys_context(''APEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'end qask_respons';
wwv_flow_imp.g_varchar2_table(74) := 'es_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger qask_response_answers_biu'||wwv_flow.LF||
'    before insert or update '||wwv_flow.LF||
'    on q';
wwv_flow_imp.g_varchar2_table(75) := 'ask_response_answers'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.row_version := 1;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(76) := ' elsif updating then'||wwv_flow.LF||
'        :new.row_version := nvl(:old.row_version,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if ins';
wwv_flow_imp.g_varchar2_table(77) := 'erting then'||wwv_flow.LF||
'        :new.created_on := sysdate;'||wwv_flow.LF||
'        :new.created_by := lower(nvl(sys_context(''AP';
wwv_flow_imp.g_varchar2_table(78) := 'EX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated_on := sysdate;'||wwv_flow.LF||
'    :new.updated_by := ';
wwv_flow_imp.g_varchar2_table(79) := 'lower(nvl(sys_context(''APEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'end qask_response_answers_biu;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(59294851204945310003)
,p_install_id=>wwv_flow_imp.id(49582154264788065099)
,p_name=>'create triggers'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
