prompt --application/deployment/install/install_qask_util_spec
begin
--   Manifest
--     INSTALL: INSTALL-qask_util spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package qask_util '||wwv_flow.LF||
'as'||wwv_flow.LF||
''||wwv_flow.LF||
'-- if user exceeds max verification attempts, this is raise';
wwv_flow_imp.g_varchar2_table(2) := 'd for the app to read from'||wwv_flow.LF||
'-- se when generating tokens'||wwv_flow.LF||
'e_account_locked  exception;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_';
wwv_flow_imp.g_varchar2_table(3) := 'log ( '||wwv_flow.LF||
'    p_procedure_name  in varchar2, '||wwv_flow.LF||
'    p_log_type        in varchar2 default ''error'', -- err';
wwv_flow_imp.g_varchar2_table(4) := 'or or info'||wwv_flow.LF||
'    p_error           in varchar2, '||wwv_flow.LF||
'    p_arg1_name       in varchar2 default null, '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(5) := 'p_arg1_val        in varchar2 default null, '||wwv_flow.LF||
'    p_arg2_name       in varchar2 default null, '||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(6) := 'arg2_val        in varchar2 default null, '||wwv_flow.LF||
'    p_arg3_name       in varchar2 default null, '||wwv_flow.LF||
'    p_ar';
wwv_flow_imp.g_varchar2_table(7) := 'g3_val        in varchar2 default null, '||wwv_flow.LF||
'    p_arg4_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg4';
wwv_flow_imp.g_varchar2_table(8) := '_val        in varchar2 default null, '||wwv_flow.LF||
'    p_arg5_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg5_v';
wwv_flow_imp.g_varchar2_table(9) := 'al        in varchar2 default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_setting ( '||wwv_flow.LF||
'    p_name           in  varchar2,  ';
wwv_flow_imp.g_varchar2_table(10) := ''||wwv_flow.LF||
'    p_display_order  in  number,'||wwv_flow.LF||
'    p_description    in  varchar2,'||wwv_flow.LF||
'    p_value          in  varcha';
wwv_flow_imp.g_varchar2_table(11) := 'r2,'||wwv_flow.LF||
'    p_is_numeric_yn  in  varchar2,'||wwv_flow.LF||
'    p_is_yn          in  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure set_setting (';
wwv_flow_imp.g_varchar2_table(12) := ' '||wwv_flow.LF||
'    p_name       in  varchar2,  '||wwv_flow.LF||
'    p_value      in  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_setting ( '||wwv_flow.LF||
'    p_n';
wwv_flow_imp.g_varchar2_table(13) := 'ame       in  varchar2 )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure insert_service_terms ('||wwv_flow.LF||
'    p_service_terms ';
wwv_flow_imp.g_varchar2_table(14) := '    in  clob,'||wwv_flow.LF||
'    p_current_yn        in  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_service_terms ('||wwv_flow.LF||
'    p_servic';
wwv_flow_imp.g_varchar2_table(15) := 'e_terms_id  in  number,'||wwv_flow.LF||
'    p_service_terms     in  clob,'||wwv_flow.LF||
'    p_current_yn        in  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'p';
wwv_flow_imp.g_varchar2_table(16) := 'rocedure delete_service_terms ('||wwv_flow.LF||
'    p_service_terms_id  in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_latest_service_t';
wwv_flow_imp.g_varchar2_table(17) := 'erms_id '||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'-----------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_user ('||wwv_flow.LF||
'    p_username           ';
wwv_flow_imp.g_varchar2_table(18) := 'in  varchar2,'||wwv_flow.LF||
'    p_role_id            in  number,'||wwv_flow.LF||
'    p_send_email_yn      in  varchar2 default ''Y''';
wwv_flow_imp.g_varchar2_table(19) := ','||wwv_flow.LF||
'    p_app_id             in  number,'||wwv_flow.LF||
'    p_app_url            in  varchar2 default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'proced';
wwv_flow_imp.g_varchar2_table(20) := 'ure update_user ('||wwv_flow.LF||
'    p_username           in  varchar2,'||wwv_flow.LF||
'    p_role_id            in  number,'||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(21) := 'app_id             in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_user ('||wwv_flow.LF||
'    p_username           in  varchar2,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(22) := ' p_app_id             in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure log_service_terms_accept ('||wwv_flow.LF||
'    p_email              i';
wwv_flow_imp.g_varchar2_table(23) := 'n  varchar2,'||wwv_flow.LF||
'    p_accepted_terms_id  in  number,'||wwv_flow.LF||
'    p_accepted_on        in  date  default null );';
wwv_flow_imp.g_varchar2_table(24) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'function has_accepted_latest_terms_yn ('||wwv_flow.LF||
'    p_email  in  varchar2 )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedur';
wwv_flow_imp.g_varchar2_table(25) := 'e send_verification_email ('||wwv_flow.LF||
'    p_username          in  varchar2,'||wwv_flow.LF||
'    p_token             in  varcha';
wwv_flow_imp.g_varchar2_table(26) := 'r2,'||wwv_flow.LF||
'    p_app_id            in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure log_access ('||wwv_flow.LF||
'    p_username     in  varchar2,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(27) := '   p_verified_yn  in  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'function is_account_locked_yn ( '||wwv_flow.LF||
'    p_username     in  varchar2 ';
wwv_flow_imp.g_varchar2_table(28) := ')'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function is_token_maxed_yn ('||wwv_flow.LF||
'    p_username     in  varchar2 )'||wwv_flow.LF||
'    return va';
wwv_flow_imp.g_varchar2_table(29) := 'rchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function generate_token ('||wwv_flow.LF||
'    p_username       in  varchar2 )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'functio';
wwv_flow_imp.g_varchar2_table(30) := 'n token_is_valid ('||wwv_flow.LF||
'    p_username    in  varchar2,'||wwv_flow.LF||
'    p_token       in  varchar2 )'||wwv_flow.LF||
'    return boole';
wwv_flow_imp.g_varchar2_table(31) := 'an;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure reset_verification_tokens ('||wwv_flow.LF||
'    p_username    in  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'----------------------';
wwv_flow_imp.g_varchar2_table(32) := '----------------'||wwv_flow.LF||
''||wwv_flow.LF||
'function in_restricted_domains_yn ('||wwv_flow.LF||
'    p_email             in  varchar2 )'||wwv_flow.LF||
'    ret';
wwv_flow_imp.g_varchar2_table(33) := 'urn varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure request_access ('||wwv_flow.LF||
'    p_email             in  varchar2,'||wwv_flow.LF||
'    p_justification ';
wwv_flow_imp.g_varchar2_table(34) := '    in  varchar2,'||wwv_flow.LF||
'    p_app_id            in  number,'||wwv_flow.LF||
'    p_app_url           in  varchar2,'||wwv_flow.LF||
'    p_se';
wwv_flow_imp.g_varchar2_table(35) := 'rvice_terms_id  in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_access_request ('||wwv_flow.LF||
'    p_access_request_id  in  number';
wwv_flow_imp.g_varchar2_table(36) := ' );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure approve_access ('||wwv_flow.LF||
'    p_access_request_id  in  number,'||wwv_flow.LF||
'    p_reason             in  va';
wwv_flow_imp.g_varchar2_table(37) := 'rchar2 default null,'||wwv_flow.LF||
'    p_send_email_yn      in  varchar2 default ''Y'','||wwv_flow.LF||
'    p_app_id             in ';
wwv_flow_imp.g_varchar2_table(38) := ' number,'||wwv_flow.LF||
'    p_app_url            in  varchar2 default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure decline_access ('||wwv_flow.LF||
'    p_acc';
wwv_flow_imp.g_varchar2_table(39) := 'ess_request_id  in  number,'||wwv_flow.LF||
'    p_reason             in  varchar2,'||wwv_flow.LF||
'    p_send_email_yn      in  varc';
wwv_flow_imp.g_varchar2_table(40) := 'har2 default ''Y'','||wwv_flow.LF||
'    p_app_id             in  number   default null,'||wwv_flow.LF||
'    p_app_url            in  v';
wwv_flow_imp.g_varchar2_table(41) := 'archar2 default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'--------------------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'function open_session_count_f';
wwv_flow_imp.g_varchar2_table(42) := 'or_user ('||wwv_flow.LF||
'    p_app_user     in varchar2 )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'function add_answer_set ('||wwv_flow.LF||
'    p_answe';
wwv_flow_imp.g_varchar2_table(43) := 'r_set_code  in varchar2,'||wwv_flow.LF||
'    p_answer_set_name  in varchar2 )'||wwv_flow.LF||
'return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_aset_ans';
wwv_flow_imp.g_varchar2_table(44) := 'wer ('||wwv_flow.LF||
'    p_answer_set_id   in number,'||wwv_flow.LF||
'    p_answer_text     in varchar2,'||wwv_flow.LF||
'    p_display_order   in n';
wwv_flow_imp.g_varchar2_table(45) := 'umber );'||wwv_flow.LF||
''||wwv_flow.LF||
'--------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'function new_session_name_ok_yn ('||wwv_flow.LF||
'    p_session_name  in  varchar2,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(46) := '    p_app_user      in  varchar2 )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function create_session ('||wwv_flow.LF||
'    p_app_user   ';
wwv_flow_imp.g_varchar2_table(47) := '             in varchar2,'||wwv_flow.LF||
'    p_session_name            in varchar2,'||wwv_flow.LF||
'    p_purpose                 i';
wwv_flow_imp.g_varchar2_table(48) := 'n varchar2,'||wwv_flow.LF||
'    p_visibility              in varchar2 default ''PRIVATE'', -- NOT CURRENTLY USED'||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(49) := '_resp_name_required_yn   in varchar2 default ''N'','||wwv_flow.LF||
'    p_resp_email_required_yn  in varchar2 default ';
wwv_flow_imp.g_varchar2_table(50) := '''N'','||wwv_flow.LF||
'    p_session_status          in varchar2 default ''OPEN'' )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure get_se';
wwv_flow_imp.g_varchar2_table(51) := 'ssion_details ('||wwv_flow.LF||
'    p_session_id              in  number,'||wwv_flow.LF||
'    p_session_name            out varchar2';
wwv_flow_imp.g_varchar2_table(52) := ','||wwv_flow.LF||
'    p_session_code            out varchar2,'||wwv_flow.LF||
'    p_purpose                 out varchar2,'||wwv_flow.LF||
'    p_resp';
wwv_flow_imp.g_varchar2_table(53) := '_name_required_yn   out varchar2,'||wwv_flow.LF||
'    p_resp_email_required_yn  out varchar2,'||wwv_flow.LF||
'    p_session_status  ';
wwv_flow_imp.g_varchar2_table(54) := '        out varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_session_id ('||wwv_flow.LF||
'    p_session_code  in varchar2 )'||wwv_flow.LF||
'    return numb';
wwv_flow_imp.g_varchar2_table(55) := 'er;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_session_code ('||wwv_flow.LF||
'    p_session_id  in number )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_se';
wwv_flow_imp.g_varchar2_table(56) := 'ssion_name ('||wwv_flow.LF||
'    p_session_id  in number )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_session_owner ('||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(57) := 'session_id  in number )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_session_status ('||wwv_flow.LF||
'    p_session_id    in n';
wwv_flow_imp.g_varchar2_table(58) := 'umber   default null,'||wwv_flow.LF||
'    p_session_code  in varchar2 default null )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function ';
wwv_flow_imp.g_varchar2_table(59) := 'session_resp_name_req_yn ('||wwv_flow.LF||
'    p_session_id    in number   default null )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'func';
wwv_flow_imp.g_varchar2_table(60) := 'tion session_resp_email_req_yn ('||wwv_flow.LF||
'    p_session_id    in number   default null )'||wwv_flow.LF||
'    return varchar2;';
wwv_flow_imp.g_varchar2_table(61) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure close_session ('||wwv_flow.LF||
'    p_session_id  in number );'||wwv_flow.LF||
''||wwv_flow.LF||
'-- if last question created more than x ';
wwv_flow_imp.g_varchar2_table(62) := 'mins ago (or if session created x mins ago and no questions yet)'||wwv_flow.LF||
'procedure close_old_sessions;'||wwv_flow.LF||
''||wwv_flow.LF||
'proc';
wwv_flow_imp.g_varchar2_table(63) := 'edure delete_session ('||wwv_flow.LF||
'    p_session_id  in number );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure start_staged_session ('||wwv_flow.LF||
'    p_sessio';
wwv_flow_imp.g_varchar2_table(64) := 'n_id  in  number, '||wwv_flow.LF||
'    p_app_user    in  varchar2,'||wwv_flow.LF||
'    p_question_id out number );'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_que';
wwv_flow_imp.g_varchar2_table(65) := 'stion_count ('||wwv_flow.LF||
'    p_session_id  in number )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_next_question_number ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(66) := '    p_session_id  in number )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'function add_question ('||wwv_flow.LF||
'    p_session_id          ';
wwv_flow_imp.g_varchar2_table(67) := '           in number,'||wwv_flow.LF||
'    p_question_number                in number,'||wwv_flow.LF||
'    p_question                ';
wwv_flow_imp.g_varchar2_table(68) := '       in varchar2,'||wwv_flow.LF||
'    p_answer_set_id                  in number default null,'||wwv_flow.LF||
'    p_answers      ';
wwv_flow_imp.g_varchar2_table(69) := '                  in varchar2,'||wwv_flow.LF||
'    p_answer_type                    in varchar2,'||wwv_flow.LF||
'    p_ask_for_comme';
wwv_flow_imp.g_varchar2_table(70) := 'nts_yn            in varchar2 default ''N'','||wwv_flow.LF||
'    p_question_explanation           in clob,'||wwv_flow.LF||
'    p_quest';
wwv_flow_imp.g_varchar2_table(71) := 'ion_filename              in varchar2  default null,'||wwv_flow.LF||
'    p_question_file                  in blob   ';
wwv_flow_imp.g_varchar2_table(72) := '   default null,'||wwv_flow.LF||
'    p_question_file_mimetype         in varchar2  default null,'||wwv_flow.LF||
'    p_question_file';
wwv_flow_imp.g_varchar2_table(73) := '_last_updated_on  in date      default null )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure start_staged_question ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(74) := '    p_question_id  in number );'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_next_question_id ('||wwv_flow.LF||
'    p_session_id   in number,'||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(75) := '_question_id  in number   default null,'||wwv_flow.LF||
'    p_status       in varchar2 default ''OPEN'' )'||wwv_flow.LF||
'    return n';
wwv_flow_imp.g_varchar2_table(76) := 'umber;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_prev_question_id ('||wwv_flow.LF||
'    p_session_id   in number,'||wwv_flow.LF||
'    p_question_id  in number,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(77) := '    p_status       in varchar2 default ''OPEN'' )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure get_next_question_stat';
wwv_flow_imp.g_varchar2_table(78) := 'us_json ('||wwv_flow.LF||
'    p_session_id   in number,'||wwv_flow.LF||
'    p_question_id  in number  default null );'||wwv_flow.LF||
''||wwv_flow.LF||
'function ques';
wwv_flow_imp.g_varchar2_table(79) := 'tion_available_yn ('||wwv_flow.LF||
'    p_session_code  in varchar2 )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure get_question_d';
wwv_flow_imp.g_varchar2_table(80) := 'etails ('||wwv_flow.LF||
'    p_question_id           in number,'||wwv_flow.LF||
'    p_question_number       out number,'||wwv_flow.LF||
'    p_questi';
wwv_flow_imp.g_varchar2_table(81) := 'on_status       out varchar2,'||wwv_flow.LF||
'    p_question              out varchar2,'||wwv_flow.LF||
'    p_answer_type           ';
wwv_flow_imp.g_varchar2_table(82) := 'out varchar2,'||wwv_flow.LF||
'    p_ask_for_comments_yn   out varchar2,'||wwv_flow.LF||
'    p_question_explanation  out clob );'||wwv_flow.LF||
''||wwv_flow.LF||
'fun';
wwv_flow_imp.g_varchar2_table(83) := 'ction get_question_status ('||wwv_flow.LF||
'    p_question_id  in number )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function is_ask_for';
wwv_flow_imp.g_varchar2_table(84) := '_comments_yn ('||wwv_flow.LF||
'    p_question_id  in number )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function copy_session ('||wwv_flow.LF||
'    p_fr';
wwv_flow_imp.g_varchar2_table(85) := 'om_session_id         in number,'||wwv_flow.LF||
'    p_app_user                in varchar2,'||wwv_flow.LF||
'    p_session_name      ';
wwv_flow_imp.g_varchar2_table(86) := '      in varchar2,'||wwv_flow.LF||
'    p_purpose                 in varchar2,'||wwv_flow.LF||
'    p_visibility              in varch';
wwv_flow_imp.g_varchar2_table(87) := 'ar2 default ''PRIVATE'', -- NOT CURRENTLY USED'||wwv_flow.LF||
'    p_resp_name_required_yn   in varchar2 default ''N'','||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(88) := '    p_resp_email_required_yn  in varchar2 default ''N'','||wwv_flow.LF||
'    p_session_status          in varchar2 def';
wwv_flow_imp.g_varchar2_table(89) := 'ault ''OPEN'' )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'-------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'function answer_question ('||wwv_flow.LF||
'    p_sessio';
wwv_flow_imp.g_varchar2_table(90) := 'n_id        in number,'||wwv_flow.LF||
'    p_question_id       in number,'||wwv_flow.LF||
'    p_apex_session_id   in number,'||wwv_flow.LF||
'    p_a';
wwv_flow_imp.g_varchar2_table(91) := 'nswer_id         in number   default null,'||wwv_flow.LF||
'    p_answer_freeform   in varchar2 default null,'||wwv_flow.LF||
'    p_c';
wwv_flow_imp.g_varchar2_table(92) := 'omment_text      in varchar2 default null,'||wwv_flow.LF||
'    p_multi_answer      in varchar2 default null,'||wwv_flow.LF||
'    p_r';
wwv_flow_imp.g_varchar2_table(93) := 'esponse_id       in number,'||wwv_flow.LF||
'    p_respondent_name   in varchar2 default null,'||wwv_flow.LF||
'    p_respondent_email';
wwv_flow_imp.g_varchar2_table(94) := '  in varchar2 default null )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'function is_question_answered_yn ('||wwv_flow.LF||
'    p_response_i';
wwv_flow_imp.g_varchar2_table(95) := 'd  in number,'||wwv_flow.LF||
'    p_question_id  in number )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_response_id ('||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(96) := 'session_id        in number,'||wwv_flow.LF||
'    p_apex_session_id   in number )'||wwv_flow.LF||
'    return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure close';
wwv_flow_imp.g_varchar2_table(97) := '_question ('||wwv_flow.LF||
'    p_session_id   in number default null,'||wwv_flow.LF||
'    p_question_id  in number default null );'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(98) := ''||wwv_flow.LF||
'end qask_util;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(59295025400627625022)
,p_install_id=>wwv_flow_imp.id(49582154264788065099)
,p_name=>'qask_util spec'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
