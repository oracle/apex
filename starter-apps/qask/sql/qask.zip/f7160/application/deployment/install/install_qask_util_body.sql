prompt --application/deployment/install/install_qask_util_body
begin
--   Manifest
--     INSTALL: INSTALL-qask_util body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body qask_util '||wwv_flow.LF||
'as'||wwv_flow.LF||
''||wwv_flow.LF||
'-- To catch PL/SQL error, error log procedure needs to';
wwv_flow_imp.g_varchar2_table(2) := ' be autonomous transactions and do commit at the end. '||wwv_flow.LF||
'procedure add_log ( '||wwv_flow.LF||
'    p_procedure_name  in';
wwv_flow_imp.g_varchar2_table(3) := ' varchar2, '||wwv_flow.LF||
'    p_log_type        in varchar2 default ''error'', -- error or info'||wwv_flow.LF||
'    p_error         ';
wwv_flow_imp.g_varchar2_table(4) := '  in varchar2, '||wwv_flow.LF||
'    p_arg1_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg1_val        in varchar2 d';
wwv_flow_imp.g_varchar2_table(5) := 'efault null, '||wwv_flow.LF||
'    p_arg2_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg2_val        in varchar2 def';
wwv_flow_imp.g_varchar2_table(6) := 'ault null, '||wwv_flow.LF||
'    p_arg3_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg3_val        in varchar2 defau';
wwv_flow_imp.g_varchar2_table(7) := 'lt null, '||wwv_flow.LF||
'    p_arg4_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg4_val        in varchar2 default';
wwv_flow_imp.g_varchar2_table(8) := ' null, '||wwv_flow.LF||
'    p_arg5_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg5_val        in varchar2 default n';
wwv_flow_imp.g_varchar2_table(9) := 'ull ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'    pragma autonomous_transaction; '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    insert into qask_log '||wwv_flow.LF||
'       (page_id, pro';
wwv_flow_imp.g_varchar2_table(10) := 'cedure_name, log_type, error, '||wwv_flow.LF||
'        arg1_name, arg1_val, arg2_name, arg2_val, arg3_name, arg3_val';
wwv_flow_imp.g_varchar2_table(11) := ', '||wwv_flow.LF||
'        arg4_name, arg4_val, arg5_name, arg5_val ) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'       (apex_application.g_flow_s';
wwv_flow_imp.g_varchar2_table(12) := 'tep_id, p_procedure_name, p_log_type, p_error, '||wwv_flow.LF||
'        p_arg1_name, p_arg1_val, p_arg2_name, p_arg2';
wwv_flow_imp.g_varchar2_table(13) := '_val, p_arg3_name, p_arg3_val, '||wwv_flow.LF||
'        p_arg4_name, p_arg4_val, p_arg5_name, p_arg5_val ); '||wwv_flow.LF||
'    com';
wwv_flow_imp.g_varchar2_table(14) := 'mit; '||wwv_flow.LF||
'end add_log; '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_setting ( '||wwv_flow.LF||
'    p_name           in  varchar2,  '||wwv_flow.LF||
'    p_display_or';
wwv_flow_imp.g_varchar2_table(15) := 'der  in  number,'||wwv_flow.LF||
'    p_description    in  varchar2,'||wwv_flow.LF||
'    p_value          in  varchar2,'||wwv_flow.LF||
'    p_is_nume';
wwv_flow_imp.g_varchar2_table(16) := 'ric_yn  in  varchar2,'||wwv_flow.LF||
'    p_is_yn          in  varchar2 )'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
' '||wwv_flow.LF||
'    if p_is_numeric_yn = ''Y'' ';
wwv_flow_imp.g_varchar2_table(17) := 'and p_is_yn = ''Y'' then'||wwv_flow.LF||
'        add_log ( '||wwv_flow.LF||
'            p_procedure_name => ''add_setting'', '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(18) := '  p_error          => ''Setting cannot be both numeric and YN'', '||wwv_flow.LF||
'            p_arg1_name      => ''p_n';
wwv_flow_imp.g_varchar2_table(19) := 'ame'', p_arg1_val => p_name ); '||wwv_flow.LF||
'        raise_application_error(-20111,''Setting cannot be both numeri';
wwv_flow_imp.g_varchar2_table(20) := 'c and YN.'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into qask_settings '||wwv_flow.LF||
'        (name, display_order, description, ';
wwv_flow_imp.g_varchar2_table(21) := 'is_numeric_yn, is_yn)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (p_name, p_display_order, p_description, p_is_numeric_yn, p';
wwv_flow_imp.g_varchar2_table(22) := '_is_yn);'||wwv_flow.LF||
''||wwv_flow.LF||
'    set_setting(p_name => p_name, p_value => p_value);'||wwv_flow.LF||
' '||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'    a';
wwv_flow_imp.g_varchar2_table(23) := 'dd_log ( '||wwv_flow.LF||
'        p_procedure_name => ''add_setting'', '||wwv_flow.LF||
'        p_error          =>  sqlerrm, '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(24) := ' p_arg1_name      => ''p_name'', p_arg1_val => p_name ); '||wwv_flow.LF||
'    raise; '||wwv_flow.LF||
'end add_setting;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure set';
wwv_flow_imp.g_varchar2_table(25) := '_setting ( '||wwv_flow.LF||
'    p_name       in  varchar2,  '||wwv_flow.LF||
'    p_value      in  varchar2 )'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
' '||wwv_flow.LF||
'    for c1';
wwv_flow_imp.g_varchar2_table(26) := ' in ('||wwv_flow.LF||
'        select id,'||wwv_flow.LF||
'               is_numeric_yn,'||wwv_flow.LF||
'               is_yn'||wwv_flow.LF||
'          from qask_sett';
wwv_flow_imp.g_varchar2_table(27) := 'ings '||wwv_flow.LF||
'         where name = lower(p_name)'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        if c1.is_numeric_yn = ''Y'' and validate_';
wwv_flow_imp.g_varchar2_table(28) := 'conversion(p_value as NUMBER) = 0 then'||wwv_flow.LF||
'            add_log ( '||wwv_flow.LF||
'                   p_procedure_name =>';
wwv_flow_imp.g_varchar2_table(29) := ' ''set_setting'', '||wwv_flow.LF||
'                   p_log_type       => ''info'','||wwv_flow.LF||
'                   p_error          ';
wwv_flow_imp.g_varchar2_table(30) := '=> ''Value must be numeric'', '||wwv_flow.LF||
'                   p_arg1_name      => ''p_name'', p_arg1_val => p_name, ';
wwv_flow_imp.g_varchar2_table(31) := ''||wwv_flow.LF||
'                   p_arg2_name      => ''p_value'', p_arg2_val => p_value ); '||wwv_flow.LF||
'                raise_a';
wwv_flow_imp.g_varchar2_table(32) := 'pplication_error(-20111,''Value must be numeric.'');'||wwv_flow.LF||
'        elsif c1.is_yn = ''Y'' and p_value not in (';
wwv_flow_imp.g_varchar2_table(33) := '''Y'',''N'') then'||wwv_flow.LF||
'            add_log ( '||wwv_flow.LF||
'                p_procedure_name => ''set_setting'', '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(34) := '     p_log_type       => ''info'','||wwv_flow.LF||
'                p_error          => ''Value must be Y or N'', '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(35) := '          p_arg1_name      => ''p_name'', p_arg1_val => p_name, '||wwv_flow.LF||
'                p_arg2_name      => ''';
wwv_flow_imp.g_varchar2_table(36) := 'p_value'', p_arg2_val => p_value ); '||wwv_flow.LF||
'            raise_application_error(-20111,''Value must be Y or N';
wwv_flow_imp.g_varchar2_table(37) := '.'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        update qask_settings '||wwv_flow.LF||
'           set value = p_value '||wwv_flow.LF||
'         where id';
wwv_flow_imp.g_varchar2_table(38) := ' = c1.id; '||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
' '||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'    add_log ( '||wwv_flow.LF||
'        p_procedure_name => ''s';
wwv_flow_imp.g_varchar2_table(39) := 'et_setting'', '||wwv_flow.LF||
'        p_error          =>  sqlerrm, '||wwv_flow.LF||
'        p_arg1_name      => ''p_name'', p_arg1_va';
wwv_flow_imp.g_varchar2_table(40) := 'l => p_name ); '||wwv_flow.LF||
'    raise; '||wwv_flow.LF||
'end set_setting;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_setting ( '||wwv_flow.LF||
'    p_name       in  varchar2';
wwv_flow_imp.g_varchar2_table(41) := ' )'||wwv_flow.LF||
'    return varchar2 '||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    for c1 in ( '||wwv_flow.LF||
'       select value '||wwv_flow.LF||
'         from qask_settings';
wwv_flow_imp.g_varchar2_table(42) := '  '||wwv_flow.LF||
'        where name = lower(p_name)  '||wwv_flow.LF||
'    ) loop '||wwv_flow.LF||
'        return c1.value;'||wwv_flow.LF||
'    end loop; '||wwv_flow.LF||
' '||wwv_flow.LF||
'    re';
wwv_flow_imp.g_varchar2_table(43) := 'turn null; '||wwv_flow.LF||
'end get_setting; '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure insert_service_terms ('||wwv_flow.LF||
'    p_service_terms     in  clob,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(44) := '   p_current_yn        in  varchar2 )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if p_current_yn = ''Y'' then'||wwv_flow.LF||
'       update qask_ser';
wwv_flow_imp.g_varchar2_table(45) := 'vice_terms'||wwv_flow.LF||
'          set current_yn = ''N'''||wwv_flow.LF||
'        where current_yn = ''Y'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert in';
wwv_flow_imp.g_varchar2_table(46) := 'to qask_service_terms'||wwv_flow.LF||
'        (service_terms, current_yn)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        (p_service_terms, p_cur';
wwv_flow_imp.g_varchar2_table(47) := 'rent_yn);'||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'    add_log ( '||wwv_flow.LF||
'        p_procedure_name => ''insert_service_ter';
wwv_flow_imp.g_varchar2_table(48) := 'ms'', '||wwv_flow.LF||
'        p_error          =>  sqlerrm, '||wwv_flow.LF||
'        p_arg1_name      => ''p_service_terms'', p_arg1_v';
wwv_flow_imp.g_varchar2_table(49) := 'al => substr(p_service_terms,1,255),'||wwv_flow.LF||
'        p_arg2_name      => ''p_current_yn'', p_arg2_val => p_cur';
wwv_flow_imp.g_varchar2_table(50) := 'rent_yn ); '||wwv_flow.LF||
'    raise_application_error(-20111,''Error inserting service terms.'');'||wwv_flow.LF||
'end insert_service';
wwv_flow_imp.g_varchar2_table(51) := '_terms;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_service_terms ('||wwv_flow.LF||
'    p_service_terms_id  in  number,'||wwv_flow.LF||
'    p_service_terms  ';
wwv_flow_imp.g_varchar2_table(52) := '   in  clob,'||wwv_flow.LF||
'    p_current_yn        in  varchar2 )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if p_current_yn = ''Y'' then'||wwv_flow.LF||
'       u';
wwv_flow_imp.g_varchar2_table(53) := 'pdate qask_service_terms'||wwv_flow.LF||
'          set current_yn = ''N'''||wwv_flow.LF||
'        where current_yn = ''Y'''||wwv_flow.LF||
'          and';
wwv_flow_imp.g_varchar2_table(54) := ' id != p_service_terms_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    update qask_service_terms'||wwv_flow.LF||
'       set service_terms = p_s';
wwv_flow_imp.g_varchar2_table(55) := 'ervice_terms,'||wwv_flow.LF||
'           current_yn = p_current_yn'||wwv_flow.LF||
'     where id = p_service_terms_id;'||wwv_flow.LF||
'exception whe';
wwv_flow_imp.g_varchar2_table(56) := 'n others then '||wwv_flow.LF||
'    add_log ( '||wwv_flow.LF||
'        p_procedure_name => ''update_service_terms'', '||wwv_flow.LF||
'        p_error  ';
wwv_flow_imp.g_varchar2_table(57) := '        =>  sqlerrm, '||wwv_flow.LF||
'        p_arg1_name      => ''p_service_terms_id'', p_arg1_val => p_service_term';
wwv_flow_imp.g_varchar2_table(58) := 's_id ); '||wwv_flow.LF||
'    raise_application_error(-20111,''Error updating service terms.'');'||wwv_flow.LF||
'end update_service_ter';
wwv_flow_imp.g_varchar2_table(59) := 'ms;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_service_terms ('||wwv_flow.LF||
'    p_service_terms_id  in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    delete from';
wwv_flow_imp.g_varchar2_table(60) := ' qask_service_terms'||wwv_flow.LF||
'     where id = p_service_terms_id;'||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'    add_log ( '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(61) := '       p_procedure_name => ''delete_service_terms'', '||wwv_flow.LF||
'        p_error          =>  sqlerrm, '||wwv_flow.LF||
'        p';
wwv_flow_imp.g_varchar2_table(62) := '_arg1_name      => ''p_service_terms_id'', p_arg1_val => p_service_terms_id ); '||wwv_flow.LF||
'    raise_application_';
wwv_flow_imp.g_varchar2_table(63) := 'error(-20111,''Error deleting service terms.'');'||wwv_flow.LF||
'end delete_service_terms;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_latest_servi';
wwv_flow_imp.g_varchar2_table(64) := 'ce_terms_id '||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select id'||wwv_flow.LF||
'          from qask_servic';
wwv_flow_imp.g_varchar2_table(65) := 'e_terms'||wwv_flow.LF||
'         where current_yn = ''Y'''||wwv_flow.LF||
'          order by updated_on desc'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return';
wwv_flow_imp.g_varchar2_table(66) := ' c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return null;'||wwv_flow.LF||
'end get_latest_service_terms_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'--------------------------';
wwv_flow_imp.g_varchar2_table(67) := '----------------------'||wwv_flow.LF||
'procedure add_user ('||wwv_flow.LF||
'    p_username           in  varchar2,'||wwv_flow.LF||
'    p_role_id    ';
wwv_flow_imp.g_varchar2_table(68) := '        in  number,'||wwv_flow.LF||
'    p_send_email_yn      in  varchar2 default ''Y'','||wwv_flow.LF||
'    p_app_id             in  ';
wwv_flow_imp.g_varchar2_table(69) := 'number,'||wwv_flow.LF||
'    p_app_url            in  varchar2 default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_from_email  varchar2(255)  := ';
wwv_flow_imp.g_varchar2_table(70) := 'get_setting(''from_email'');'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if p_username is null or'||wwv_flow.LF||
'       p_app_id   is null'||wwv_flow.LF||
'    then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(71) := '     return;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_send_email_yn = ''Y'' and (p_app_url is null or l_from_email is nul';
wwv_flow_imp.g_varchar2_table(72) := 'l) then'||wwv_flow.LF||
'        add_log ( '||wwv_flow.LF||
'            p_procedure_name => ''add_user'', '||wwv_flow.LF||
'            p_log_type      ';
wwv_flow_imp.g_varchar2_table(73) := ' => ''info'','||wwv_flow.LF||
'            p_error          => ''Must have app_url and from_email to send email.'', '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(74) := '        p_arg1_name      => ''p_username'', p_arg1_val => p_username, '||wwv_flow.LF||
'            p_arg2_name      =>';
wwv_flow_imp.g_varchar2_table(75) := ' ''p_role_id'',  p_arg2_val => p_role_id ); '||wwv_flow.LF||
'        raise_application_error(-20111,''Cannot send email';
wwv_flow_imp.g_varchar2_table(76) := '.'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- user may already have access'||wwv_flow.LF||
'    if not apex_acl.has_user_any_roles ('||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(77) := '          p_application_id => p_app_id, '||wwv_flow.LF||
'               p_user_name      => p_username ) '||wwv_flow.LF||
'    then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(78) := '       apex_acl.add_user_role ('||wwv_flow.LF||
'            p_application_id => p_app_id,'||wwv_flow.LF||
'            p_user_name   ';
wwv_flow_imp.g_varchar2_table(79) := '   => p_username,'||wwv_flow.LF||
'            p_role_id        => p_role_id );'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_send_email_yn =';
wwv_flow_imp.g_varchar2_table(80) := ' ''Y'' then'||wwv_flow.LF||
'        apex_mail.send ('||wwv_flow.LF||
'                p_to                 => p_username,  '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(81) := '     p_from               => l_from_email, '||wwv_flow.LF||
'                p_application_id     => p_app_id, '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(82) := '           p_template_static_id => ''USER_CREATED'', '||wwv_flow.LF||
'                p_placeholders       => ''{'' || ''';
wwv_flow_imp.g_varchar2_table(83) := '"APPLICATION_LINK": "'' || p_app_url ||''", ''||'||wwv_flow.LF||
'                                               ''"USERN';
wwv_flow_imp.g_varchar2_table(84) := 'AME":'' || apex_json.stringify( p_username ) ||'||wwv_flow.LF||
'                                         ''}'' ); '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(85) := 'end if;'||wwv_flow.LF||
'   '||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'    add_log ( '||wwv_flow.LF||
'        p_procedure_name => ''add_user'', '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(86) := '    p_error          =>  sqlerrm, '||wwv_flow.LF||
'        p_arg1_name      => ''p_username'', p_arg1_val => p_usernam';
wwv_flow_imp.g_varchar2_table(87) := 'e, '||wwv_flow.LF||
'        p_arg2_name      => ''p_role_id'',  p_arg2_val => p_role_id ); '||wwv_flow.LF||
'    raise_application_erro';
wwv_flow_imp.g_varchar2_table(88) := 'r(-20111,''Error adding user.'');'||wwv_flow.LF||
'end add_user;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_user ('||wwv_flow.LF||
'    p_username           in ';
wwv_flow_imp.g_varchar2_table(89) := ' varchar2,'||wwv_flow.LF||
'    p_role_id            in  number,'||wwv_flow.LF||
'    p_app_id             in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(90) := 'apex_acl.replace_user_roles ('||wwv_flow.LF||
'        p_application_id => p_app_id,'||wwv_flow.LF||
'        p_user_name      => p_us';
wwv_flow_imp.g_varchar2_table(91) := 'ername,'||wwv_flow.LF||
'        p_role_ids       => wwv_flow_t_number(p_role_id) );'||wwv_flow.LF||
''||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(92) := ' add_log ( '||wwv_flow.LF||
'        p_procedure_name => ''update_user'', '||wwv_flow.LF||
'        p_error          =>  sqlerrm, '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(93) := '   p_arg1_name      => ''p_username'', p_arg1_val => p_username, '||wwv_flow.LF||
'        p_arg2_name      => ''p_role_';
wwv_flow_imp.g_varchar2_table(94) := 'id'',  p_arg2_val => p_role_id ); '||wwv_flow.LF||
'    raise_application_error(-20111,''Error updating user.'');'||wwv_flow.LF||
'end up';
wwv_flow_imp.g_varchar2_table(95) := 'date_user;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_user ('||wwv_flow.LF||
'    p_username           in  varchar2,'||wwv_flow.LF||
'    p_app_id            ';
wwv_flow_imp.g_varchar2_table(96) := ' in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    apex_acl.remove_all_user_roles ('||wwv_flow.LF||
'        p_application_id => p_app_id,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(97) := '       p_user_name      => p_username );'||wwv_flow.LF||
''||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'    add_log ( '||wwv_flow.LF||
'        p_proce';
wwv_flow_imp.g_varchar2_table(98) := 'dure_name => ''delete_user'', '||wwv_flow.LF||
'        p_error          =>  sqlerrm, '||wwv_flow.LF||
'        p_arg1_name      => ''p_u';
wwv_flow_imp.g_varchar2_table(99) := 'sername'', p_arg1_val => p_username ); '||wwv_flow.LF||
'    raise_application_error(-20111,''Error deleting user.'');'||wwv_flow.LF||
'e';
wwv_flow_imp.g_varchar2_table(100) := 'nd delete_user;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure log_service_terms_accept ('||wwv_flow.LF||
'    p_email              in  varchar2,'||wwv_flow.LF||
'    p_';
wwv_flow_imp.g_varchar2_table(101) := 'accepted_terms_id  in  number,'||wwv_flow.LF||
'    p_accepted_on        in  date  default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    inser';
wwv_flow_imp.g_varchar2_table(102) := 't into qask_service_term_accepts '||wwv_flow.LF||
'        (email, accepted_terms_id, accepted_on)'||wwv_flow.LF||
'    values'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(103) := ' (lower(p_email), p_accepted_terms_id, nvl(p_accepted_on,sysdate) );'||wwv_flow.LF||
''||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(104) := '  add_log ( '||wwv_flow.LF||
'        p_procedure_name => ''log_service_terms_accept'', '||wwv_flow.LF||
'        p_error          =>  s';
wwv_flow_imp.g_varchar2_table(105) := 'qlerrm, '||wwv_flow.LF||
'        p_arg1_name      => ''p_email'', p_arg1_val => p_email, '||wwv_flow.LF||
'        p_arg2_name      => ';
wwv_flow_imp.g_varchar2_table(106) := '''p_accepted_terms_id'', p_arg2_val => p_accepted_terms_id ); '||wwv_flow.LF||
'    raise_application_error(-20111,''Err';
wwv_flow_imp.g_varchar2_table(107) := 'or accepting service terms.'');'||wwv_flow.LF||
'end log_service_terms_accept;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function has_accepted_latest_terms_yn';
wwv_flow_imp.g_varchar2_table(108) := ' ('||wwv_flow.LF||
'    p_email  in  varchar2 )'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_id number := get_latest_service_terms_id';
wwv_flow_imp.g_varchar2_table(109) := ';'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- no terms to accept'||wwv_flow.LF||
'    if l_id is null then'||wwv_flow.LF||
'       return ''Y'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c';
wwv_flow_imp.g_varchar2_table(110) := '1 in ('||wwv_flow.LF||
'        select 1'||wwv_flow.LF||
'          from qask_service_term_accepts'||wwv_flow.LF||
'         where email = lower(p_emai';
wwv_flow_imp.g_varchar2_table(111) := 'l)'||wwv_flow.LF||
'           and accepted_terms_id = l_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return ''Y'';'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return ';
wwv_flow_imp.g_varchar2_table(112) := '''N'';'||wwv_flow.LF||
'end has_accepted_latest_terms_yn;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure send_verification_email ('||wwv_flow.LF||
'    p_username         ';
wwv_flow_imp.g_varchar2_table(113) := ' in  varchar2,'||wwv_flow.LF||
'    p_token             in  varchar2,'||wwv_flow.LF||
'    p_app_id            in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_f';
wwv_flow_imp.g_varchar2_table(114) := 'rom_email  varchar2(255)  := get_setting(''from_email'');'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    if not apex_acl.has_user_any_role';
wwv_flow_imp.g_varchar2_table(115) := 's ('||wwv_flow.LF||
'               p_application_id => p_app_id, '||wwv_flow.LF||
'               p_user_name      => p_username ) th';
wwv_flow_imp.g_varchar2_table(116) := 'en'||wwv_flow.LF||
'        raise_application_error(-20111,''Not a qASK user.'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    apex_mail.send ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(117) := '     p_to                 => p_username,  '||wwv_flow.LF||
'        p_from               => nvl(l_from_email,p_userna';
wwv_flow_imp.g_varchar2_table(118) := 'me), -- allows first user to login'||wwv_flow.LF||
'        p_application_id     => p_app_id, '||wwv_flow.LF||
'        p_template_sta';
wwv_flow_imp.g_varchar2_table(119) := 'tic_id => ''VERIFICATION'', '||wwv_flow.LF||
'        p_placeholders       => ''{'' || ''"TOKEN": "'' || p_token ||''"'' ||'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(120) := '                                        ''}'' ); '||wwv_flow.LF||
''||wwv_flow.LF||
'    -- must push to get token out immediately'||wwv_flow.LF||
'    a';
wwv_flow_imp.g_varchar2_table(121) := 'pex_mail.push_queue;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'    add_log ( '||wwv_flow.LF||
'        p_procedure_name => ''send_v';
wwv_flow_imp.g_varchar2_table(122) := 'erification_email'', '||wwv_flow.LF||
'        p_error          =>  sqlerrm, '||wwv_flow.LF||
'        p_arg1_name      => ''p_username''';
wwv_flow_imp.g_varchar2_table(123) := ', p_arg1_val => p_username );'||wwv_flow.LF||
'    raise_application_error(-20111,''Error sending verification email.''';
wwv_flow_imp.g_varchar2_table(124) := ');'||wwv_flow.LF||
'end send_verification_email;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure log_access ('||wwv_flow.LF||
'    p_username     in  varchar2,'||wwv_flow.LF||
'    p_veri';
wwv_flow_imp.g_varchar2_table(125) := 'fied_yn  in  varchar2 )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    pragma autonomous_transaction;'||wwv_flow.LF||
'    l_max_verify_attempts  number:= ge';
wwv_flow_imp.g_varchar2_table(126) := 't_setting(''max_verify_attempts_per_token'');'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    update qask_verify_tokens'||wwv_flow.LF||
'       set verified_';
wwv_flow_imp.g_varchar2_table(127) := 'yn     = p_verified_yn,'||wwv_flow.LF||
'           accessed_on     = sysdate,'||wwv_flow.LF||
'           access_attempts = access_at';
wwv_flow_imp.g_varchar2_table(128) := 'tempts + 1,'||wwv_flow.LF||
'           expired_yn      = case when p_verified_yn = ''N'' and access_attempts + 1 >= l_';
wwv_flow_imp.g_varchar2_table(129) := 'max_verify_attempts then ''Y'' '||wwv_flow.LF||
'                                  else expired_yn end'||wwv_flow.LF||
'     where expir';
wwv_flow_imp.g_varchar2_table(130) := 'ed_yn = ''N'''||wwv_flow.LF||
'       and username = lower(p_username);'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'end log_access;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function is_accou';
wwv_flow_imp.g_varchar2_table(131) := 'nt_locked_yn ( '||wwv_flow.LF||
'    p_username     in  varchar2 )'||wwv_flow.LF||
'    return varchar2 '||wwv_flow.LF||
'is                           ';
wwv_flow_imp.g_varchar2_table(132) := '        '||wwv_flow.LF||
'    l_tokens                      number;'||wwv_flow.LF||
'    l_reset_verify_after_x_hours  number;     '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(133) := '  l_max_tokens                  number:= get_setting(''max_tokens''); '||wwv_flow.LF||
'    l_max_verify_attempts      ';
wwv_flow_imp.g_varchar2_table(134) := '   number:= get_setting(''max_verify_attempts_per_token'');                                           ';
wwv_flow_imp.g_varchar2_table(135) := '                                    '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if p_username is null then'||wwv_flow.LF||
'        return ''Y'';'||wwv_flow.LF||
'    en';
wwv_flow_imp.g_varchar2_table(136) := 'd if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_reset_verify_after_x_hours := coalesce(get_setting(''reset_verify_after_x_hours''),0);'||wwv_flow.LF||
''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(137) := '   if l_reset_verify_after_x_hours = 0 then'||wwv_flow.LF||
'       return ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    select count(*)'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(138) := '  into l_tokens'||wwv_flow.LF||
'      from qask_verify_tokens'||wwv_flow.LF||
'     where username = lower(p_username)'||wwv_flow.LF||
'       and cre';
wwv_flow_imp.g_varchar2_table(139) := 'ated_on > sysdate - l_reset_verify_after_x_hours/24'||wwv_flow.LF||
'       and verified_yn = ''N'''||wwv_flow.LF||
'       and (expired';
wwv_flow_imp.g_varchar2_table(140) := '_yn = ''Y'' or access_attempts >= l_max_verify_attempts)'||wwv_flow.LF||
'       and reset_on is null;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_tokens';
wwv_flow_imp.g_varchar2_table(141) := ' >= l_max_tokens then'||wwv_flow.LF||
'        return ''Y'';'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        return ''N'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end is_account_lo';
wwv_flow_imp.g_varchar2_table(142) := 'cked_yn;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function is_token_maxed_yn ('||wwv_flow.LF||
'    p_username     in  varchar2 )'||wwv_flow.LF||
'    return varchar2 '||wwv_flow.LF||
'is'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(143) := '  l_reset_verify_after_x_hours  number;'||wwv_flow.LF||
'    l_max_verify_attempts         number:= get_setting(''max_';
wwv_flow_imp.g_varchar2_table(144) := 'verify_attempts_per_token'');'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_reset_verify_after_x_hours := coalesce(get_setting(''reset_v';
wwv_flow_imp.g_varchar2_table(145) := 'erify_after_x_hours''),0);'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select coalesce ('||wwv_flow.LF||
'                   (select acce';
wwv_flow_imp.g_varchar2_table(146) := 'ss_attempts'||wwv_flow.LF||
'                      from qask_verify_tokens'||wwv_flow.LF||
'                     where username = lowe';
wwv_flow_imp.g_varchar2_table(147) := 'r(p_username)'||wwv_flow.LF||
'                       and (l_reset_verify_after_x_hours = 0 or created_on > sysdate -';
wwv_flow_imp.g_varchar2_table(148) := ' l_reset_verify_after_x_hours/24)'||wwv_flow.LF||
'                       and verified_yn = ''N'''||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(149) := '  and expired_yn = ''N'''||wwv_flow.LF||
'                       and reset_on is null ), '||wwv_flow.LF||
'                   (select ac';
wwv_flow_imp.g_varchar2_table(150) := 'cess_attempts'||wwv_flow.LF||
'                      from qask_verify_tokens'||wwv_flow.LF||
'                     where username = lo';
wwv_flow_imp.g_varchar2_table(151) := 'wer(p_username)'||wwv_flow.LF||
'                       and (l_reset_verify_after_x_hours = 0 or created_on > sysdate';
wwv_flow_imp.g_varchar2_table(152) := ' - l_reset_verify_after_x_hours/24)'||wwv_flow.LF||
'                       and updated_on = (select max (updated_on)';
wwv_flow_imp.g_varchar2_table(153) := ''||wwv_flow.LF||
'                                           from qask_verify_tokens'||wwv_flow.LF||
'                                ';
wwv_flow_imp.g_varchar2_table(154) := '          where username = lower(p_username)) )'||wwv_flow.LF||
'                   ,0) verification_attempts'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(155) := '   from dual'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        if c1.verification_attempts < l_max_verify_attempts then'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(156) := 'return ''N'';'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return ''Y'';'||wwv_flow.LF||
'end is_token_maxed_yn; '||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function genera';
wwv_flow_imp.g_varchar2_table(157) := 'te_token ('||wwv_flow.LF||
'    p_username       in  varchar2 )'||wwv_flow.LF||
'    return varchar2 '||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_max_verify_attempts    ';
wwv_flow_imp.g_varchar2_table(158) := '     number := get_setting(''max_verify_attempts''); '||wwv_flow.LF||
'    l_grace_minutes               number := 5;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(159) := '   l_token_length                number := 6;'||wwv_flow.LF||
'    l_expire_minutes              number := 15; -- if ';
wwv_flow_imp.g_varchar2_table(160) := 'change to setting, need to update verification email template'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    l_token                    ';
wwv_flow_imp.g_varchar2_table(161) := '   varchar2(255);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_max_verify_attempts > 0 then'||wwv_flow.LF||
''||wwv_flow.LF||
'        if is_account_locked_yn(p_us';
wwv_flow_imp.g_varchar2_table(162) := 'ername => p_username) = ''Y'' then'||wwv_flow.LF||
'            add_log (p_procedure_name => ''generate_token'', '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(163) := '                    p_log_type       => ''info'','||wwv_flow.LF||
'                           p_error          => ''Maxi';
wwv_flow_imp.g_varchar2_table(164) := 'mum verification attempts exceeded'','||wwv_flow.LF||
'                           p_arg1_name      => ''p_username'', p_';
wwv_flow_imp.g_varchar2_table(165) := 'arg1_val => p_username );'||wwv_flow.LF||
'            raise e_account_locked;'||wwv_flow.LF||
'--            raise_application_error(';
wwv_flow_imp.g_varchar2_table(166) := '-20111,''Maximum verification attempts exceeded.  Account will reset in ''||get_setting(''reset_verify_';
wwv_flow_imp.g_varchar2_table(167) := 'after_x_hours'')||'' hours.'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        select token'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(168) := 'into l_token'||wwv_flow.LF||
'          from qask_verify_tokens'||wwv_flow.LF||
'        where username = lower(p_username)'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(169) := 'and expire_on > sysdate + l_grace_minutes/(24*60)'||wwv_flow.LF||
'          and verified_yn = ''N'''||wwv_flow.LF||
'          and expi';
wwv_flow_imp.g_varchar2_table(170) := 'red_yn = ''N'';'||wwv_flow.LF||
'    exception'||wwv_flow.LF||
'        when too_many_rows or no_data_found then'||wwv_flow.LF||
'            null;'||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(171) := 'nd;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_token is null then'||wwv_flow.LF||
''||wwv_flow.LF||
'        update qask_verify_tokens'||wwv_flow.LF||
'           set expired_yn = ''Y'''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(172) := '         where username = lower(p_username)'||wwv_flow.LF||
'           and expired_yn = ''N'';'||wwv_flow.LF||
''||wwv_flow.LF||
'        l_token := lpa';
wwv_flow_imp.g_varchar2_table(173) := 'd(to_char(round(dbms_random.value(1,999999))),l_token_length,''0'');'||wwv_flow.LF||
''||wwv_flow.LF||
'        insert into qask_verify_';
wwv_flow_imp.g_varchar2_table(174) := 'tokens ('||wwv_flow.LF||
'            username,'||wwv_flow.LF||
'            token,'||wwv_flow.LF||
'            expire_on )'||wwv_flow.LF||
'        values ('||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(175) := '   lower(p_username),'||wwv_flow.LF||
'            l_token,'||wwv_flow.LF||
'            sysdate + l_expire_minutes/(24*60) );'||wwv_flow.LF||
''||wwv_flow.LF||
'    en';
wwv_flow_imp.g_varchar2_table(176) := 'd if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_token;'||wwv_flow.LF||
'exception '||wwv_flow.LF||
'    when others then'||wwv_flow.LF||
'        add_log (p_procedure_name => ''gen';
wwv_flow_imp.g_varchar2_table(177) := 'erate_token'', '||wwv_flow.LF||
'                       p_error => sqlerrm,'||wwv_flow.LF||
'                       p_arg1_name => ''p_u';
wwv_flow_imp.g_varchar2_table(178) := 'sername'', p_arg1_val => p_username );'||wwv_flow.LF||
'        raise;'||wwv_flow.LF||
'end generate_token;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function token_is_valid (';
wwv_flow_imp.g_varchar2_table(179) := ''||wwv_flow.LF||
'    p_username    in  varchar2,'||wwv_flow.LF||
'    p_token       in  varchar2 )'||wwv_flow.LF||
'    return boolean '||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_verif';
wwv_flow_imp.g_varchar2_table(180) := 'ied_yn  varchar2(1);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        select ''Y'''||wwv_flow.LF||
'          into l_verified_yn'||wwv_flow.LF||
'          from ';
wwv_flow_imp.g_varchar2_table(181) := 'qask_verify_tokens '||wwv_flow.LF||
'         where username = lower(p_username)'||wwv_flow.LF||
'           and token = trim(p_token)';
wwv_flow_imp.g_varchar2_table(182) := ''||wwv_flow.LF||
'           and expire_on > sysdate'||wwv_flow.LF||
'           and expired_yn = ''N'''||wwv_flow.LF||
'           and rownum = 1;'||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(183) := 'xception when no_data_found then'||wwv_flow.LF||
'        l_verified_yn := ''N'';'||wwv_flow.LF||
'        add_log (p_procedure_name => ';
wwv_flow_imp.g_varchar2_table(184) := '''token_is_valid'', '||wwv_flow.LF||
'                       p_log_type       => ''info'','||wwv_flow.LF||
'                       p_error';
wwv_flow_imp.g_varchar2_table(185) := '          => ''invalid token used'','||wwv_flow.LF||
'                       p_arg1_name => ''p_username'', p_arg1_val =>';
wwv_flow_imp.g_varchar2_table(186) := ' p_username,'||wwv_flow.LF||
'                       p_arg2_name => ''p_token'', p_arg2_val => p_token );'||wwv_flow.LF||
'    end;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(187) := 'log_access ('||wwv_flow.LF||
'        p_username    => p_username,'||wwv_flow.LF||
'        p_verified_yn => l_verified_yn );'||wwv_flow.LF||
'    retu';
wwv_flow_imp.g_varchar2_table(188) := 'rn l_verified_yn = ''Y'';'||wwv_flow.LF||
'exception when others then'||wwv_flow.LF||
'    add_log (p_procedure_name => ''token_is_valid''';
wwv_flow_imp.g_varchar2_table(189) := ', '||wwv_flow.LF||
'                   p_error => sqlerrm,'||wwv_flow.LF||
'                   p_arg1_name => ''p_username'', p_arg1_val';
wwv_flow_imp.g_varchar2_table(190) := ' => p_username,'||wwv_flow.LF||
'                   p_arg2_name => ''p_token'', p_arg2_val => p_token );'||wwv_flow.LF||
'    raise_appl';
wwv_flow_imp.g_varchar2_table(191) := 'ication_error(-20111,''Error validating token.'');'||wwv_flow.LF||
'end token_is_valid;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure reset_verification_';
wwv_flow_imp.g_varchar2_table(192) := 'tokens ('||wwv_flow.LF||
'    p_username    in  varchar2 )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    update qask_verify_tokens '||wwv_flow.LF||
'       set reset_o';
wwv_flow_imp.g_varchar2_table(193) := 'n = sysdate,'||wwv_flow.LF||
'           reset_by = lower(nvl(sys_context(''APEX$SESSION'',''APP_USER''),user))'||wwv_flow.LF||
'     wher';
wwv_flow_imp.g_varchar2_table(194) := 'e username = lower(p_username)'||wwv_flow.LF||
'       and reset_on is null'||wwv_flow.LF||
'       and verified_yn = ''N'';'||wwv_flow.LF||
'exception w';
wwv_flow_imp.g_varchar2_table(195) := 'hen others then'||wwv_flow.LF||
'    add_log (p_procedure_name => ''reset_verification_tokens'', '||wwv_flow.LF||
'                   p_';
wwv_flow_imp.g_varchar2_table(196) := 'error => sqlerrm,'||wwv_flow.LF||
'                   p_arg1_name => ''p_username'', p_arg1_val => p_username);'||wwv_flow.LF||
'    rai';
wwv_flow_imp.g_varchar2_table(197) := 'se_application_error(-20111,''Error resetting verification token.'');'||wwv_flow.LF||
'end reset_verification_tokens;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(198) := ''||wwv_flow.LF||
'-----------------------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'function in_restricted_domains_yn ('||wwv_flow.LF||
'    p_email   ';
wwv_flow_imp.g_varchar2_table(199) := '          in  varchar2 )'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select 1'||wwv_flow.LF||
'          fr';
wwv_flow_imp.g_varchar2_table(200) := 'om qask_restricted_email_domains'||wwv_flow.LF||
'         where lower(p_email) like ''%@''||email_domain'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(201) := '      return ''Y'';'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return ''N'';'||wwv_flow.LF||
''||wwv_flow.LF||
'end in_restricted_domains_yn;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure request_';
wwv_flow_imp.g_varchar2_table(202) := 'access ('||wwv_flow.LF||
'    p_email             in  varchar2,'||wwv_flow.LF||
'    p_justification     in  varchar2,'||wwv_flow.LF||
'    p_app_id   ';
wwv_flow_imp.g_varchar2_table(203) := '         in  number,'||wwv_flow.LF||
'    p_app_url           in  varchar2,'||wwv_flow.LF||
'    p_service_terms_id  in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(204) := '   l_exists_yn   varchar2(1)   := ''N'';'||wwv_flow.LF||
'    l_from_email  varchar2(255) := get_setting(''from_email'');';
wwv_flow_imp.g_varchar2_table(205) := ''||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    if get_setting(''allow_account_requests_yn'') = ''N'' then'||wwv_flow.LF||
'        add_log ( '||wwv_flow.LF||
'            p_';
wwv_flow_imp.g_varchar2_table(206) := 'procedure_name => ''request_access'', '||wwv_flow.LF||
'            p_log_type       => ''info'','||wwv_flow.LF||
'            p_error    ';
wwv_flow_imp.g_varchar2_table(207) := '      => ''User Requests not enabled'', '||wwv_flow.LF||
'            p_arg1_name      => ''p_email'', p_arg1_val => p_em';
wwv_flow_imp.g_varchar2_table(208) := 'ail, '||wwv_flow.LF||
'            p_arg2_name      => ''p_justification'',  p_arg2_val => p_justification ); '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(209) := 'raise_application_error(-20111,''User Requests not enabled.'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if get_setting(''restr';
wwv_flow_imp.g_varchar2_table(210) := 'ict_requests_to_email_domains_yn'') = ''Y'' and'||wwv_flow.LF||
'       in_restricted_domains_yn(p_email => p_email) = ''';
wwv_flow_imp.g_varchar2_table(211) := 'N'' then'||wwv_flow.LF||
'        add_log ( '||wwv_flow.LF||
'            p_procedure_name => ''request_access'', '||wwv_flow.LF||
'            p_log_type';
wwv_flow_imp.g_varchar2_table(212) := '       => ''info'','||wwv_flow.LF||
'            p_error          => ''Email not in allowed domains'', '||wwv_flow.LF||
'            p_arg';
wwv_flow_imp.g_varchar2_table(213) := '1_name      => ''p_email'', p_arg1_val => p_email, '||wwv_flow.LF||
'            p_arg2_name      => ''p_justification'',';
wwv_flow_imp.g_varchar2_table(214) := '  p_arg2_val => p_justification ); '||wwv_flow.LF||
'        raise_application_error(-20111,''Email not in allowed dom';
wwv_flow_imp.g_varchar2_table(215) := 'ains.'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if apex_acl.has_user_any_roles ('||wwv_flow.LF||
'           p_application_id  => p_app_id,';
wwv_flow_imp.g_varchar2_table(216) := ''||wwv_flow.LF||
'           p_user_name       => upper(p_email) ) '||wwv_flow.LF||
'    then'||wwv_flow.LF||
'        l_exists_yn := ''Y'';'||wwv_flow.LF||
'        add_';
wwv_flow_imp.g_varchar2_table(217) := 'log ( '||wwv_flow.LF||
'            p_procedure_name => ''request_access'', '||wwv_flow.LF||
'            p_log_type       => ''info'','||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(218) := '          p_error          => ''Requestor already has account'', '||wwv_flow.LF||
'            p_arg1_name      => ''p_e';
wwv_flow_imp.g_varchar2_table(219) := 'mail'', p_arg1_val => p_email );'||wwv_flow.LF||
''||wwv_flow.LF||
'        apex_mail.send ('||wwv_flow.LF||
'            p_to                 => p_emai';
wwv_flow_imp.g_varchar2_table(220) := 'l,  '||wwv_flow.LF||
'            p_from               => l_from_email, '||wwv_flow.LF||
'            p_application_id     => p_app_id';
wwv_flow_imp.g_varchar2_table(221) := ', '||wwv_flow.LF||
'            p_template_static_id => ''EXISTING_ACCOUNT'', '||wwv_flow.LF||
'            p_placeholders       => ''{'' ';
wwv_flow_imp.g_varchar2_table(222) := '|| ''"APPLICATION_LINK": "'' || p_app_url || ''" }'' ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_exists_yn = ''N'' then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(223) := '    for c1 in ('||wwv_flow.LF||
'            select 1'||wwv_flow.LF||
'              from qask_account_requests'||wwv_flow.LF||
'             where ema';
wwv_flow_imp.g_varchar2_table(224) := 'il = upper(p_email)'||wwv_flow.LF||
'               and request_status = ''REQUESTED'''||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            l_exi';
wwv_flow_imp.g_varchar2_table(225) := 'sts_yn := ''Y'';'||wwv_flow.LF||
'            add_log ( '||wwv_flow.LF||
'                p_procedure_name => ''request_access'', '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(226) := '         p_log_type       => ''info'','||wwv_flow.LF||
'                p_error          => ''Requestor already has open';
wwv_flow_imp.g_varchar2_table(227) := ' request'', '||wwv_flow.LF||
'                p_arg1_name      => ''p_email'', p_arg1_val => p_email );'||wwv_flow.LF||
'        end loop';
wwv_flow_imp.g_varchar2_table(228) := ';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_exists_yn = ''N'' then'||wwv_flow.LF||
'        -- other parameters set in trigger'||wwv_flow.LF||
'        inse';
wwv_flow_imp.g_varchar2_table(229) := 'rt into qask_account_requests'||wwv_flow.LF||
'            (email, justification, accepted_terms_id, request_status)'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(230) := '        values'||wwv_flow.LF||
'            (lower(p_email), p_justification, p_service_terms_id, ''REQUESTED'');'||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(231) := 'nd if;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'    add_log ( '||wwv_flow.LF||
'        p_procedure_name => ''request_access'', '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(232) := '      p_error          =>  sqlerrm, '||wwv_flow.LF||
'        p_arg1_name      => ''p_email'', p_arg1_val => p_email, '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(233) := '        p_arg2_name      => ''p_justification'',  p_arg2_val => p_justification ); '||wwv_flow.LF||
'    raise_applicat';
wwv_flow_imp.g_varchar2_table(234) := 'ion_error(-20111,''Error requesting access.'');'||wwv_flow.LF||
'end request_access;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_access_request ';
wwv_flow_imp.g_varchar2_table(235) := '('||wwv_flow.LF||
'    p_access_request_id  in  number )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    delete from qask_account_requests'||wwv_flow.LF||
'     where id';
wwv_flow_imp.g_varchar2_table(236) := ' = p_access_request_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'    add_log ( '||wwv_flow.LF||
'        p_procedure_name => ''del';
wwv_flow_imp.g_varchar2_table(237) := 'ete_access_request'', '||wwv_flow.LF||
'        p_error          =>  sqlerrm, '||wwv_flow.LF||
'        p_arg1_name      => ''p_access_r';
wwv_flow_imp.g_varchar2_table(238) := 'equest_id'', p_arg1_val => p_access_request_id ); '||wwv_flow.LF||
'    raise_application_error(-20111,''Error deleting';
wwv_flow_imp.g_varchar2_table(239) := ' access request.'');'||wwv_flow.LF||
'end delete_access_request;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure approve_access ('||wwv_flow.LF||
'    p_access_request_id ';
wwv_flow_imp.g_varchar2_table(240) := ' in  number,'||wwv_flow.LF||
'    p_reason             in  varchar2 default null,'||wwv_flow.LF||
'    p_send_email_yn      in  varcha';
wwv_flow_imp.g_varchar2_table(241) := 'r2 default ''Y'','||wwv_flow.LF||
'    p_app_id             in  number,'||wwv_flow.LF||
'    p_app_url            in  varchar2 default n';
wwv_flow_imp.g_varchar2_table(242) := 'ull )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if p_send_email_yn = ''Y'' and p_app_url is null then'||wwv_flow.LF||
'        add_log ( '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(243) := '  p_procedure_name => ''approve_access'', '||wwv_flow.LF||
'            p_log_type       => ''info'','||wwv_flow.LF||
'            p_error';
wwv_flow_imp.g_varchar2_table(244) := '          => ''Must have app_url to send email'','||wwv_flow.LF||
'            p_arg1_name      => ''p_access_request_id';
wwv_flow_imp.g_varchar2_table(245) := ''', p_arg1_val => p_access_request_id );'||wwv_flow.LF||
'        raise_application_error(-20111,''Must have app_url to';
wwv_flow_imp.g_varchar2_table(246) := ' send email.'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select email, accepted_terms_id, created_on,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(247) := '             (select role_id'||wwv_flow.LF||
'                  from apex_appl_acl_roles'||wwv_flow.LF||
'                 where appli';
wwv_flow_imp.g_varchar2_table(248) := 'cation_id = p_app_id'||wwv_flow.LF||
'                   and role_static_id = ''CONTRIBUTOR'') role_id'||wwv_flow.LF||
'          from q';
wwv_flow_imp.g_varchar2_table(249) := 'ask_account_requests'||wwv_flow.LF||
'         where id = p_access_request_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
''||wwv_flow.LF||
'        add_user ('||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(250) := '    p_username      => upper(c1.email),'||wwv_flow.LF||
'            p_role_id       => c1.role_id,'||wwv_flow.LF||
'            p_sen';
wwv_flow_imp.g_varchar2_table(251) := 'd_email_yn => p_send_email_yn,'||wwv_flow.LF||
'            p_app_id        => p_app_id,'||wwv_flow.LF||
'            p_app_url       ';
wwv_flow_imp.g_varchar2_table(252) := '=> p_app_url );'||wwv_flow.LF||
''||wwv_flow.LF||
'        update qask_account_requests'||wwv_flow.LF||
'          set request_status = ''APPROVED'','||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(253) := '           status_reason = p_reason'||wwv_flow.LF||
'         where id = p_access_request_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'        if c1.accepted';
wwv_flow_imp.g_varchar2_table(254) := '_terms_id is not null then'||wwv_flow.LF||
'            log_service_terms_accept ('||wwv_flow.LF||
'                p_email           ';
wwv_flow_imp.g_varchar2_table(255) := '  => lower(c1.email),'||wwv_flow.LF||
'                p_accepted_terms_id => c1.accepted_terms_id,'||wwv_flow.LF||
'                p';
wwv_flow_imp.g_varchar2_table(256) := '_accepted_on       => c1.created_on );'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'   '||wwv_flow.LF||
'exception when others then';
wwv_flow_imp.g_varchar2_table(257) := ' '||wwv_flow.LF||
'    add_log ( '||wwv_flow.LF||
'        p_procedure_name => ''approve_access'', '||wwv_flow.LF||
'        p_error          =>  sqlerrm';
wwv_flow_imp.g_varchar2_table(258) := ', '||wwv_flow.LF||
'        p_arg1_name      => ''p_access_request_id'', p_arg1_val => p_access_request_id ); '||wwv_flow.LF||
'    rais';
wwv_flow_imp.g_varchar2_table(259) := 'e_application_error(-20111,''Error approving access.'');'||wwv_flow.LF||
'end approve_access;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure decline_acces';
wwv_flow_imp.g_varchar2_table(260) := 's ('||wwv_flow.LF||
'    p_access_request_id  in  number,'||wwv_flow.LF||
'    p_reason             in  varchar2,'||wwv_flow.LF||
'    p_send_email_yn ';
wwv_flow_imp.g_varchar2_table(261) := '     in  varchar2 default ''Y'','||wwv_flow.LF||
'    p_app_id             in  number   default null,'||wwv_flow.LF||
'    p_app_url    ';
wwv_flow_imp.g_varchar2_table(262) := '        in  varchar2 default null )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_email       qask_account_requests.email%type;'||wwv_flow.LF||
'    l_fro';
wwv_flow_imp.g_varchar2_table(263) := 'm_email  varchar2(255)  := get_setting(''from_email'');'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if p_send_email_yn = ''Y'' and (p_app_';
wwv_flow_imp.g_varchar2_table(264) := 'id is null or p_app_url is null) then'||wwv_flow.LF||
'        add_log ( '||wwv_flow.LF||
'            p_procedure_name => ''decline_ac';
wwv_flow_imp.g_varchar2_table(265) := 'cess'', '||wwv_flow.LF||
'            p_log_type       => ''info'','||wwv_flow.LF||
'            p_error          => ''Must have app_id an';
wwv_flow_imp.g_varchar2_table(266) := 'd app_url to send email'','||wwv_flow.LF||
'            p_arg1_name      => ''p_access_request_id'', p_arg1_val => p_acc';
wwv_flow_imp.g_varchar2_table(267) := 'ess_request_id );'||wwv_flow.LF||
'        raise_application_error(-20111,''Must have app_id and app_url to send email';
wwv_flow_imp.g_varchar2_table(268) := '.'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    update qask_account_requests'||wwv_flow.LF||
'       set request_status = ''DECLINED'','||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(269) := '  status_reason = p_reason'||wwv_flow.LF||
'     where id = p_access_request_id'||wwv_flow.LF||
'     returning email into l_email;'||wwv_flow.LF||
''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(270) := '   if p_send_email_yn = ''Y'' then'||wwv_flow.LF||
'        apex_mail.send ('||wwv_flow.LF||
'            p_to                 => l_emai';
wwv_flow_imp.g_varchar2_table(271) := 'l,  '||wwv_flow.LF||
'            p_from               => l_from_email, '||wwv_flow.LF||
'            p_application_id     => p_app_id';
wwv_flow_imp.g_varchar2_table(272) := ', '||wwv_flow.LF||
'            p_template_static_id => ''ACCESS_DECLINED'', '||wwv_flow.LF||
'            p_placeholders       => ''{'' |';
wwv_flow_imp.g_varchar2_table(273) := '| ''"APPLICATION_LINK": "'' || p_app_url || ''" }'' ); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'    add';
wwv_flow_imp.g_varchar2_table(274) := '_log ( '||wwv_flow.LF||
'        p_procedure_name => ''decline_access'', '||wwv_flow.LF||
'        p_error          =>  sqlerrm, '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(275) := '  p_arg1_name      => ''p_access_request_id'', p_arg1_val => p_access_request_id ); '||wwv_flow.LF||
'    raise_applica';
wwv_flow_imp.g_varchar2_table(276) := 'tion_error(-20111,''Error declining access.'');'||wwv_flow.LF||
'end decline_access;'||wwv_flow.LF||
''||wwv_flow.LF||
'---------------------------------';
wwv_flow_imp.g_varchar2_table(277) := '----------'||wwv_flow.LF||
''||wwv_flow.LF||
'function open_session_count_for_user ('||wwv_flow.LF||
'    p_app_user     in varchar2 )'||wwv_flow.LF||
'    return numbe';
wwv_flow_imp.g_varchar2_table(278) := 'r'||wwv_flow.LF||
'is  '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'       select count(*) cnt'||wwv_flow.LF||
'         from qask_sessions '||wwv_flow.LF||
'        where ';
wwv_flow_imp.g_varchar2_table(279) := 'session_status = ''OPEN'''||wwv_flow.LF||
'    ) loop '||wwv_flow.LF||
'       return c1.cnt;'||wwv_flow.LF||
'   end loop;'||wwv_flow.LF||
'end open_session_count_for_us';
wwv_flow_imp.g_varchar2_table(280) := 'er;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function add_answer_set ('||wwv_flow.LF||
'    p_answer_set_code  in varchar2,'||wwv_flow.LF||
'    p_answer_set_name  in varcha';
wwv_flow_imp.g_varchar2_table(281) := 'r2 )'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_answer_set_id  number;'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    insert into qask_answer_sets'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(282) := '    ( answer_set_code, answer_set_name ) '||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        ( p_answer_set_code, p_answer_set_name ';
wwv_flow_imp.g_varchar2_table(283) := ')'||wwv_flow.LF||
'    returning id into l_answer_set_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_answer_set_id;'||wwv_flow.LF||
'end add_answer_set;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedur';
wwv_flow_imp.g_varchar2_table(284) := 'e add_aset_answer ('||wwv_flow.LF||
'    p_answer_set_id   in number,'||wwv_flow.LF||
'    p_answer_text     in varchar2,'||wwv_flow.LF||
'    p_displa';
wwv_flow_imp.g_varchar2_table(285) := 'y_order   in number )'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    insert into qask_aset_answers'||wwv_flow.LF||
'        ( answer_set_id, answer_t';
wwv_flow_imp.g_varchar2_table(286) := 'ext, display_order ) '||wwv_flow.LF||
'    values'||wwv_flow.LF||
'        ( p_answer_set_id, p_answer_text, p_display_order );'||wwv_flow.LF||
'end ad';
wwv_flow_imp.g_varchar2_table(287) := 'd_aset_answer;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'------------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'function new_session_name_ok_yn ('||wwv_flow.LF||
'    p_sessi';
wwv_flow_imp.g_varchar2_table(288) := 'on_name  in  varchar2,'||wwv_flow.LF||
'    p_app_user      in  varchar2 )'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    -- sess';
wwv_flow_imp.g_varchar2_table(289) := 'ion name must be unique by user for open sessions'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select session_name '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(290) := '     from qask_sessions '||wwv_flow.LF||
'         where session_status in (''OPEN'',''STAGED'')'||wwv_flow.LF||
'           and owner = l';
wwv_flow_imp.g_varchar2_table(291) := 'ower(p_app_user)'||wwv_flow.LF||
'           and lower(session_name) = lower(p_session_name)'||wwv_flow.LF||
'    ) loop '||wwv_flow.LF||
'      return';
wwv_flow_imp.g_varchar2_table(292) := ' ''N'';'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    return ''Y'';'||wwv_flow.LF||
'end new_session_name_ok_yn;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function create_session ('||wwv_flow.LF||
'    p_ap';
wwv_flow_imp.g_varchar2_table(293) := 'p_user                in varchar2,'||wwv_flow.LF||
'    p_session_name            in varchar2,'||wwv_flow.LF||
'    p_purpose         ';
wwv_flow_imp.g_varchar2_table(294) := '        in varchar2,'||wwv_flow.LF||
'    p_visibility              in varchar2 default ''PRIVATE'', -- NOT CURRENTLY U';
wwv_flow_imp.g_varchar2_table(295) := 'SED'||wwv_flow.LF||
'    p_resp_name_required_yn   in varchar2 default ''N'','||wwv_flow.LF||
'    p_resp_email_required_yn  in varchar2';
wwv_flow_imp.g_varchar2_table(296) := ' default ''N'','||wwv_flow.LF||
'    p_session_status          in varchar2 default ''OPEN'' )'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_';
wwv_flow_imp.g_varchar2_table(297) := 'session_code  varchar2(30) := null;'||wwv_flow.LF||
'    l_session_id    number;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function gen_session_code '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(298) := '    return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_code varchar2(30);'||wwv_flow.LF||
''||wwv_flow.LF||
'        function session_code_exists_yn ('||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(299) := '           p_session_code in varchar2 )'||wwv_flow.LF||
'            return varchar2'||wwv_flow.LF||
'        is'||wwv_flow.LF||
'        begin'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(300) := '     for c1 in ('||wwv_flow.LF||
'                select 1'||wwv_flow.LF||
'                  from qask_sessions'||wwv_flow.LF||
'                 wher';
wwv_flow_imp.g_varchar2_table(301) := 'e session_code = p_session_code'||wwv_flow.LF||
'            ) loop'||wwv_flow.LF||
'                return ''Y'';'||wwv_flow.LF||
'            end loop;';
wwv_flow_imp.g_varchar2_table(302) := ''||wwv_flow.LF||
'            return ''N'';'||wwv_flow.LF||
'        end session_code_exists_yn;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        for i in 1..200 loop'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(303) := '            -- generate 3 upper case characters and 3 random numbers with zero padding'||wwv_flow.LF||
'            l';
wwv_flow_imp.g_varchar2_table(304) := '_session_code := dbms_random.string(''U'', 3) || lpad(round(dbms_random.value(1,999)),3,''000'');'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(305) := '      if substr(l_session_code,2,1) in (''E'',''A'',''I'') then'||wwv_flow.LF||
'               null; -- avoid potential ba';
wwv_flow_imp.g_varchar2_table(306) := 'd words'||wwv_flow.LF||
'            elsif substr(l_session_code,1,1) = ''A'' then '||wwv_flow.LF||
'               null; -- avoid poten';
wwv_flow_imp.g_varchar2_table(307) := 'tial bad words'||wwv_flow.LF||
'            elsif session_code_exists_yn(p_session_code => l_session_code)  = ''Y'' the';
wwv_flow_imp.g_varchar2_table(308) := 'n'||wwv_flow.LF||
'               null; -- session exists so get another one'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'               exit; --';
wwv_flow_imp.g_varchar2_table(309) := ' acceptable code found'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        return l_session_code;'||wwv_flow.LF||
'    end ';
wwv_flow_imp.g_varchar2_table(310) := 'gen_session_code;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_session_code := gen_session_code;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_session_code is null then';
wwv_flow_imp.g_varchar2_table(311) := ''||wwv_flow.LF||
'       raise_application_error(-20111,''No Session Code generated.'');'||wwv_flow.LF||
'    else'||wwv_flow.LF||
''||wwv_flow.LF||
'        insert into ';
wwv_flow_imp.g_varchar2_table(312) := 'qask_sessions ('||wwv_flow.LF||
'            owner, '||wwv_flow.LF||
'            session_name,'||wwv_flow.LF||
'            session_code,'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(313) := 'purpose,'||wwv_flow.LF||
'            visibility,'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            resp_name_required_yn,'||wwv_flow.LF||
'            resp_';
wwv_flow_imp.g_varchar2_table(314) := 'email_required_yn,'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            session_status,'||wwv_flow.LF||
'            started_on,'||wwv_flow.LF||
'            st';
wwv_flow_imp.g_varchar2_table(315) := 'arted_by )'||wwv_flow.LF||
'        values ('||wwv_flow.LF||
'            lower(p_app_user),'||wwv_flow.LF||
'            p_session_name,'||wwv_flow.LF||
'            l';
wwv_flow_imp.g_varchar2_table(316) := '_session_code,'||wwv_flow.LF||
'            p_purpose,'||wwv_flow.LF||
'            p_visibility,'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            p_resp_na';
wwv_flow_imp.g_varchar2_table(317) := 'me_required_yn,'||wwv_flow.LF||
'            p_resp_email_required_yn,'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            p_session_status,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(318) := '           case when p_session_status = ''OPEN'' then sysdate end,'||wwv_flow.LF||
'            case when p_session_sta';
wwv_flow_imp.g_varchar2_table(319) := 'tus = ''OPEN'' then lower(p_app_user) end )'||wwv_flow.LF||
'        returning id into l_session_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(320) := '        return l_session_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'    add_log ( '||wwv_flow.LF||
'        p_proc';
wwv_flow_imp.g_varchar2_table(321) := 'edure_name => ''create_session'', '||wwv_flow.LF||
'        p_error          =>  sqlerrm, '||wwv_flow.LF||
'        p_arg1_name      => ';
wwv_flow_imp.g_varchar2_table(322) := '''p_app_user'', p_arg1_val => p_app_user, '||wwv_flow.LF||
'        p_arg2_name      => ''p_session_name'',  p_arg2_val =';
wwv_flow_imp.g_varchar2_table(323) := '> p_session_name ); '||wwv_flow.LF||
'    raise_application_error(-20111,''Error creating session.'');'||wwv_flow.LF||
'end create_sessi';
wwv_flow_imp.g_varchar2_table(324) := 'on;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure get_session_details ('||wwv_flow.LF||
'    p_session_id              in  number,'||wwv_flow.LF||
'    p_session_name  ';
wwv_flow_imp.g_varchar2_table(325) := '          out varchar2,'||wwv_flow.LF||
'    p_session_code            out varchar2,'||wwv_flow.LF||
'    p_purpose                 ou';
wwv_flow_imp.g_varchar2_table(326) := 't varchar2,'||wwv_flow.LF||
'    p_resp_name_required_yn   out varchar2,'||wwv_flow.LF||
'    p_resp_email_required_yn  out varchar2,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(327) := '    p_session_status          out varchar2 )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'       select session_name,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(328) := '            session_code,'||wwv_flow.LF||
'              purpose,'||wwv_flow.LF||
'              resp_name_required_yn,'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(329) := 'resp_email_required_yn,'||wwv_flow.LF||
'              session_status'||wwv_flow.LF||
'         from qask_sessions '||wwv_flow.LF||
'        where id =';
wwv_flow_imp.g_varchar2_table(330) := ' p_session_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        p_session_name           := c1.session_name;'||wwv_flow.LF||
'        p_session_code';
wwv_flow_imp.g_varchar2_table(331) := '           := c1.session_code;'||wwv_flow.LF||
'        p_purpose                := c1.purpose;'||wwv_flow.LF||
'        p_resp_name_r';
wwv_flow_imp.g_varchar2_table(332) := 'equired_yn  := c1.resp_name_required_yn;'||wwv_flow.LF||
'        p_resp_email_required_yn := c1.resp_email_required_';
wwv_flow_imp.g_varchar2_table(333) := 'yn;'||wwv_flow.LF||
'        p_session_status         := c1.session_status;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end get_session_details;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(334) := 'function clean_session_code ('||wwv_flow.LF||
'    p_session_code in varchar2 )'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_session';
wwv_flow_imp.g_varchar2_table(335) := '_code varchar2(30) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- remove white space and upper case also remove dash'||wwv_flow.LF||
'    l_se';
wwv_flow_imp.g_varchar2_table(336) := 'ssion_code := replace(replace(upper(trim(p_session_code)),'' '',null),''-'',null);'||wwv_flow.LF||
'    return l_session_';
wwv_flow_imp.g_varchar2_table(337) := 'code;'||wwv_flow.LF||
'end clean_session_code;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_session_id ('||wwv_flow.LF||
'    p_session_code  in varchar2 )'||wwv_flow.LF||
'    retu';
wwv_flow_imp.g_varchar2_table(338) := 'rn number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_session_code  varchar2(30) := clean_session_code(p_session_code);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c';
wwv_flow_imp.g_varchar2_table(339) := '1 in ('||wwv_flow.LF||
'        select id'||wwv_flow.LF||
'          from qask_sessions '||wwv_flow.LF||
'         where session_code = l_session_code'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(340) := '    ) loop'||wwv_flow.LF||
'        return c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return null;'||wwv_flow.LF||
'end get_session_id;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_';
wwv_flow_imp.g_varchar2_table(341) := 'session_code ('||wwv_flow.LF||
'    p_session_id  in number )'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_session_code  qask_session';
wwv_flow_imp.g_varchar2_table(342) := 's.session_code%type := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    select session_code'||wwv_flow.LF||
'      into l_session_code'||wwv_flow.LF||
'      from qask';
wwv_flow_imp.g_varchar2_table(343) := '_sessions '||wwv_flow.LF||
'     where id = p_session_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_session_code;'||wwv_flow.LF||
'end get_session_code;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'functio';
wwv_flow_imp.g_varchar2_table(344) := 'n get_session_name ('||wwv_flow.LF||
'    p_session_id  in number )'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_session_name  qask_s';
wwv_flow_imp.g_varchar2_table(345) := 'essions.session_name%type := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    select session_name'||wwv_flow.LF||
'      into l_session_name'||wwv_flow.LF||
'      fro';
wwv_flow_imp.g_varchar2_table(346) := 'm qask_sessions '||wwv_flow.LF||
'     where id = p_session_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_session_name;'||wwv_flow.LF||
'end get_session_name;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'f';
wwv_flow_imp.g_varchar2_table(347) := 'unction get_session_owner ('||wwv_flow.LF||
'    p_session_id  in number )'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_owner  qask_s';
wwv_flow_imp.g_varchar2_table(348) := 'essions.owner%type := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    select upper(owner) owner'||wwv_flow.LF||
'      into l_owner'||wwv_flow.LF||
'      from qask_s';
wwv_flow_imp.g_varchar2_table(349) := 'essions '||wwv_flow.LF||
'     where id = p_session_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_owner;'||wwv_flow.LF||
'end get_session_owner;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_se';
wwv_flow_imp.g_varchar2_table(350) := 'ssion_status ('||wwv_flow.LF||
'    p_session_id    in number   default null,'||wwv_flow.LF||
'    p_session_code  in varchar2 default';
wwv_flow_imp.g_varchar2_table(351) := ' null )'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_session_code    varchar2(30) := clean_session_code(p_session_co';
wwv_flow_imp.g_varchar2_table(352) := 'de);'||wwv_flow.LF||
'    l_session_status  qask_sessions.session_status%type := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if p_session_id is n';
wwv_flow_imp.g_varchar2_table(353) := 'ull and p_session_code is null then'||wwv_flow.LF||
'       raise_application_error(-20111,''No Session Identifier pro';
wwv_flow_imp.g_varchar2_table(354) := 'vided.'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    select session_status'||wwv_flow.LF||
'      into l_session_status'||wwv_flow.LF||
'      from qask_session';
wwv_flow_imp.g_varchar2_table(355) := 's '||wwv_flow.LF||
'     where (p_session_id is not null and id = p_session_id)'||wwv_flow.LF||
'        or (p_session_code is not nul';
wwv_flow_imp.g_varchar2_table(356) := 'l and session_code = l_session_code);'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_session_status;'||wwv_flow.LF||
'end get_session_status;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'functi';
wwv_flow_imp.g_varchar2_table(357) := 'on session_resp_name_req_yn ('||wwv_flow.LF||
'    p_session_id    in number   default null )'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(358) := 'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select resp_name_required_yn'||wwv_flow.LF||
'          from qask_sessions'||wwv_flow.LF||
'         whe';
wwv_flow_imp.g_varchar2_table(359) := 're id = p_session_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return c1.resp_name_required_yn;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return ''';
wwv_flow_imp.g_varchar2_table(360) := 'N'';'||wwv_flow.LF||
'end session_resp_name_req_yn;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function session_resp_email_req_yn ('||wwv_flow.LF||
'    p_session_id    in numb';
wwv_flow_imp.g_varchar2_table(361) := 'er   default null )'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select resp_email_required_';
wwv_flow_imp.g_varchar2_table(362) := 'yn'||wwv_flow.LF||
'          from qask_sessions'||wwv_flow.LF||
'         where id = p_session_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return c1.resp_e';
wwv_flow_imp.g_varchar2_table(363) := 'mail_required_yn;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return ''N'';'||wwv_flow.LF||
'end session_resp_email_req_yn;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure close_se';
wwv_flow_imp.g_varchar2_table(364) := 'ssion ('||wwv_flow.LF||
'    p_session_id  in number )'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    close_question (p_session_id => p_session_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(365) := '    update qask_sessions'||wwv_flow.LF||
'       set session_status = ''CLOSED'','||wwv_flow.LF||
'           closed_on = sysdate,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(366) := '      length_minutes = case when session_status = ''OPEN'' then  (sysdate - created_on) * 24 * 60 else';
wwv_flow_imp.g_varchar2_table(367) := ' null end'||wwv_flow.LF||
'     where id = p_session_id'||wwv_flow.LF||
'       and session_status != ''CLOSED'';'||wwv_flow.LF||
''||wwv_flow.LF||
'exception when others';
wwv_flow_imp.g_varchar2_table(368) := ' then '||wwv_flow.LF||
'    add_log ( '||wwv_flow.LF||
'        p_procedure_name => ''close_session'', '||wwv_flow.LF||
'        p_error          =>  sql';
wwv_flow_imp.g_varchar2_table(369) := 'errm, '||wwv_flow.LF||
'        p_arg1_name      => ''p_session_id'', p_arg1_val => p_session_id ); '||wwv_flow.LF||
'    raise_applicat';
wwv_flow_imp.g_varchar2_table(370) := 'ion_error(-20111,''Error closing session.'');'||wwv_flow.LF||
'end close_session;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- if last question created more th';
wwv_flow_imp.g_varchar2_table(371) := 'an x mins ago (or if session created x mins ago and no questions yet)'||wwv_flow.LF||
'procedure close_old_sessions'||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(372) := 's '||wwv_flow.LF||
'    l_max_session_idle_hours  number := to_number(get_setting(''max_session_idle_hours''));'||wwv_flow.LF||
'begin'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(373) := '   for c1 in ('||wwv_flow.LF||
'        select session_id'||wwv_flow.LF||
'          from'||wwv_flow.LF||
'        ('||wwv_flow.LF||
'        select s.id session_id,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(374) := '             s.created_on,'||wwv_flow.LF||
'               (select max(created_on)'||wwv_flow.LF||
'                  from qask_sessio';
wwv_flow_imp.g_varchar2_table(375) := 'n_questions q'||wwv_flow.LF||
'                 where s.id = q.session_id) last_question_start_date'||wwv_flow.LF||
'          from qa';
wwv_flow_imp.g_varchar2_table(376) := 'sk_sessions s'||wwv_flow.LF||
'         where s.session_status = ''OPEN'''||wwv_flow.LF||
'        )'||wwv_flow.LF||
'         where nvl(last_question_st';
wwv_flow_imp.g_varchar2_table(377) := 'art_date,created_on) < sysdate - (l_max_session_idle_hours/24)'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        close_session (p_s';
wwv_flow_imp.g_varchar2_table(378) := 'ession_id => c1.session_id);'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'    add_log ( '||wwv_flow.LF||
'        p_proc';
wwv_flow_imp.g_varchar2_table(379) := 'edure_name => ''close_old_sessions'', '||wwv_flow.LF||
'        p_error          =>  sqlerrm ); '||wwv_flow.LF||
'    -- purposefully no';
wwv_flow_imp.g_varchar2_table(380) := 't raising, will run in background'||wwv_flow.LF||
'end close_old_sessions;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_session ('||wwv_flow.LF||
'    p_session';
wwv_flow_imp.g_varchar2_table(381) := '_id  in number )'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select id'||wwv_flow.LF||
'          from qask_responses'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(382) := 'where session_id = p_session_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        delete from qask_response_answers'||wwv_flow.LF||
'         where ';
wwv_flow_imp.g_varchar2_table(383) := 'response_id = c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    delete from qask_responses'||wwv_flow.LF||
'     where session_id = p_session';
wwv_flow_imp.g_varchar2_table(384) := '_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select id'||wwv_flow.LF||
'          from qask_session_questions'||wwv_flow.LF||
'         where session';
wwv_flow_imp.g_varchar2_table(385) := '_id = p_session_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        delete from qask_sess_question_answers'||wwv_flow.LF||
'         where question';
wwv_flow_imp.g_varchar2_table(386) := '_id = c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    delete from qask_session_questions'||wwv_flow.LF||
'     where session_id = p_session';
wwv_flow_imp.g_varchar2_table(387) := '_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    delete from qask_sessions'||wwv_flow.LF||
'     where id = p_session_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception when other';
wwv_flow_imp.g_varchar2_table(388) := 's then '||wwv_flow.LF||
'    add_log ( '||wwv_flow.LF||
'        p_procedure_name => ''delete_session'', '||wwv_flow.LF||
'        p_error          =>  s';
wwv_flow_imp.g_varchar2_table(389) := 'qlerrm, '||wwv_flow.LF||
'        p_arg1_name      => ''p_session_id'', p_arg1_val => p_session_id ); '||wwv_flow.LF||
'    raise_applic';
wwv_flow_imp.g_varchar2_table(390) := 'ation_error(-20111,''Error deleting session.'');'||wwv_flow.LF||
'end delete_session;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure start_staged_session ';
wwv_flow_imp.g_varchar2_table(391) := '('||wwv_flow.LF||
'    p_session_id  in  number, '||wwv_flow.LF||
'    p_app_user    in  varchar2,'||wwv_flow.LF||
'    p_question_id out number )'||wwv_flow.LF||
'is '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(392) := 'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select id'||wwv_flow.LF||
'          from qask_sessions'||wwv_flow.LF||
'         where id = p_session_i';
wwv_flow_imp.g_varchar2_table(393) := 'd'||wwv_flow.LF||
'           and session_status = ''STAGED'''||wwv_flow.LF||
'           and (owner = lower(p_app_user) or visibility =';
wwv_flow_imp.g_varchar2_table(394) := ' ''SHARED'')'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        update qask_sessions'||wwv_flow.LF||
'           set session_status = ''OPEN'','||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(395) := '      started_on = sysdate,'||wwv_flow.LF||
'               started_by = lower(p_app_user)'||wwv_flow.LF||
'         where id = p_sess';
wwv_flow_imp.g_varchar2_table(396) := 'ion_id;'||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    p_question_id := get_next_question_id ('||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(397) := '        p_session_id => p_session_id,'||wwv_flow.LF||
'                         p_status     => ''ANY'');  -- session w';
wwv_flow_imp.g_varchar2_table(398) := 'ill be OPEN, question will be STAGED'||wwv_flow.LF||
''||wwv_flow.LF||
'    start_staged_question(p_question_id => p_question_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'ex';
wwv_flow_imp.g_varchar2_table(399) := 'ception when others then '||wwv_flow.LF||
'    add_log ( '||wwv_flow.LF||
'        p_procedure_name => ''start_staged_session'', '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(400) := '  p_error          =>  sqlerrm, '||wwv_flow.LF||
'        p_arg1_name      => ''p_session_id'', p_arg1_val => p_session';
wwv_flow_imp.g_varchar2_table(401) := '_id ); '||wwv_flow.LF||
'    raise_application_error(-20111,''Error starting saved session.'');'||wwv_flow.LF||
'end start_staged_sessio';
wwv_flow_imp.g_varchar2_table(402) := 'n;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_question_count ('||wwv_flow.LF||
'    p_session_id  in number )'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_count  n';
wwv_flow_imp.g_varchar2_table(403) := 'umber;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    select count(*) cnt'||wwv_flow.LF||
'      into l_count'||wwv_flow.LF||
'      from qask_session_questions '||wwv_flow.LF||
'     wher';
wwv_flow_imp.g_varchar2_table(404) := 'e session_id = p_session_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_count;'||wwv_flow.LF||
'end get_question_count;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_next_questi';
wwv_flow_imp.g_varchar2_table(405) := 'on_number ('||wwv_flow.LF||
'    p_session_id  in number )'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_next_q_nbr  number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    s';
wwv_flow_imp.g_varchar2_table(406) := 'elect nvl(max(question_number),0) + 1'||wwv_flow.LF||
'      into l_next_q_nbr'||wwv_flow.LF||
'      from qask_session_questions '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(407) := '  where session_id = p_session_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_next_q_nbr;'||wwv_flow.LF||
'end get_next_question_number;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'functio';
wwv_flow_imp.g_varchar2_table(408) := 'n add_question ('||wwv_flow.LF||
'    p_session_id                     in number,'||wwv_flow.LF||
'    p_question_number              ';
wwv_flow_imp.g_varchar2_table(409) := '  in number,'||wwv_flow.LF||
'    p_question                       in varchar2,'||wwv_flow.LF||
'    p_answer_set_id                  ';
wwv_flow_imp.g_varchar2_table(410) := 'in number default null,'||wwv_flow.LF||
'    p_answers                        in varchar2,'||wwv_flow.LF||
'    p_answer_type         ';
wwv_flow_imp.g_varchar2_table(411) := '           in varchar2,'||wwv_flow.LF||
'    p_ask_for_comments_yn            in varchar2 default ''N'','||wwv_flow.LF||
'    p_question';
wwv_flow_imp.g_varchar2_table(412) := '_explanation           in clob,'||wwv_flow.LF||
'    p_question_filename              in varchar2  default null,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(413) := 'p_question_file                  in blob      default null,'||wwv_flow.LF||
'    p_question_file_mimetype         in ';
wwv_flow_imp.g_varchar2_table(414) := 'varchar2  default null,'||wwv_flow.LF||
'    p_question_file_last_updated_on  in date      default null )'||wwv_flow.LF||
'    return ';
wwv_flow_imp.g_varchar2_table(415) := 'number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_question_id   number;'||wwv_flow.LF||
'    l_answers_tmp   varchar2(32767) := p_answers;'||wwv_flow.LF||
'    l_answer';
wwv_flow_imp.g_varchar2_table(416) := 's       apex_t_varchar2;'||wwv_flow.LF||
'    l_answer_count  number := 0;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure add_answer ('||wwv_flow.LF||
'        p_ques';
wwv_flow_imp.g_varchar2_table(417) := 'tion_id   in number,'||wwv_flow.LF||
'        p_answer_number in number,'||wwv_flow.LF||
'        p_answer_text   in varchar2 )'||wwv_flow.LF||
'    is';
wwv_flow_imp.g_varchar2_table(418) := ''||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        insert into qask_sess_question_answers'||wwv_flow.LF||
'           (question_id, answer_number, an';
wwv_flow_imp.g_varchar2_table(419) := 'swer_text)'||wwv_flow.LF||
'        values'||wwv_flow.LF||
'           (p_question_id, p_answer_number, p_answer_text);'||wwv_flow.LF||
'    exception ';
wwv_flow_imp.g_varchar2_table(420) := ''||wwv_flow.LF||
'        when dup_val_on_index then'||wwv_flow.LF||
'            null;  -- do not raise an error if user added duplic';
wwv_flow_imp.g_varchar2_table(421) := 'ate answers'||wwv_flow.LF||
'        when others then '||wwv_flow.LF||
'            raise_application_error(-20111,''Error adding quest';
wwv_flow_imp.g_varchar2_table(422) := 'ion.'');'||wwv_flow.LF||
'    end add_answer;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_answer_type != ''FREEFORM'' and p_answer_set_id is null an';
wwv_flow_imp.g_varchar2_table(423) := 'd p_answers is null then '||wwv_flow.LF||
'       raise_application_error(-20111,''Answers are required.'');'||wwv_flow.LF||
'    end if';
wwv_flow_imp.g_varchar2_table(424) := ';'||wwv_flow.LF||
''||wwv_flow.LF||
'    insert into qask_session_questions ('||wwv_flow.LF||
'        session_id,'||wwv_flow.LF||
'        question,'||wwv_flow.LF||
'        question_n';
wwv_flow_imp.g_varchar2_table(425) := 'umber,'||wwv_flow.LF||
'        answer_set_id,'||wwv_flow.LF||
'        answer_type,'||wwv_flow.LF||
'        ask_for_comments_yn,'||wwv_flow.LF||
'        question_sta';
wwv_flow_imp.g_varchar2_table(426) := 'tus,'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        question_explanation )'||wwv_flow.LF||
'    values ('||wwv_flow.LF||
'        p_session_id,'||wwv_flow.LF||
'        p_question';
wwv_flow_imp.g_varchar2_table(427) := ','||wwv_flow.LF||
'        p_question_number,'||wwv_flow.LF||
'        p_answer_set_id,'||wwv_flow.LF||
'        p_answer_type,'||wwv_flow.LF||
'        p_ask_for_comme';
wwv_flow_imp.g_varchar2_table(428) := 'nts_yn,'||wwv_flow.LF||
'        ''WORKING'','||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        p_question_explanation )'||wwv_flow.LF||
'    returning id into l_quest';
wwv_flow_imp.g_varchar2_table(429) := 'ion_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_question_filename is not null and p_question_file is null -- not a copy but new in';
wwv_flow_imp.g_varchar2_table(430) := 'sert'||wwv_flow.LF||
'    then'||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            select id, blob_content, mime_type, created_on'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(431) := '       from apex_application_temp_files'||wwv_flow.LF||
'             where name = p_question_filename'||wwv_flow.LF||
'        ) loop';
wwv_flow_imp.g_varchar2_table(432) := ''||wwv_flow.LF||
'            update qask_session_questions'||wwv_flow.LF||
'               set question_filename = p_question_filenam';
wwv_flow_imp.g_varchar2_table(433) := 'e,'||wwv_flow.LF||
'                   question_file = c1.blob_content,'||wwv_flow.LF||
'                   question_file_mimetype = c';
wwv_flow_imp.g_varchar2_table(434) := '1.mime_type,'||wwv_flow.LF||
'                   question_file_last_updated_on = c1.created_on'||wwv_flow.LF||
'             where id ';
wwv_flow_imp.g_varchar2_table(435) := '= l_question_id;'||wwv_flow.LF||
'            delete from apex_application_temp_files where id = c1.id;'||wwv_flow.LF||
'        end l';
wwv_flow_imp.g_varchar2_table(436) := 'oop;'||wwv_flow.LF||
'    elsif p_question_filename is not null and p_question_file is not null -- a copy'||wwv_flow.LF||
'    then'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(437) := '      update qask_session_questions'||wwv_flow.LF||
'           set question_filename = p_question_filename,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(438) := '       question_file = p_question_file,'||wwv_flow.LF||
'               question_file_mimetype = p_question_file_mime';
wwv_flow_imp.g_varchar2_table(439) := 'type,'||wwv_flow.LF||
'               question_file_last_updated_on = p_question_file_last_updated_on'||wwv_flow.LF||
'         where ';
wwv_flow_imp.g_varchar2_table(440) := 'id = l_question_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'--    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_answer_set_id is not null then'||wwv_flow.LF||
'       for c1';
wwv_flow_imp.g_varchar2_table(441) := ' in ('||wwv_flow.LF||
'           select answer_text, dense_rank() over (order by display_order) answer_number'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(442) := '       from qask_aset_answers'||wwv_flow.LF||
'            where answer_set_id = p_answer_set_id '||wwv_flow.LF||
'            order b';
wwv_flow_imp.g_varchar2_table(443) := 'y display_order'||wwv_flow.LF||
'       ) loop'||wwv_flow.LF||
'           add_answer ('||wwv_flow.LF||
'               p_question_id   => l_question_i';
wwv_flow_imp.g_varchar2_table(444) := 'd,'||wwv_flow.LF||
'               p_answer_number => c1.answer_number,'||wwv_flow.LF||
'               p_answer_text   => c1.answer_t';
wwv_flow_imp.g_varchar2_table(445) := 'ext );'||wwv_flow.LF||
'       end loop;'||wwv_flow.LF||
'--       commit;'||wwv_flow.LF||
'    elsif p_answers is not null then'||wwv_flow.LF||
'        l_answers_tmp ';
wwv_flow_imp.g_varchar2_table(446) := ' := replace(l_answers_tmp,chr(13)||chr(10),chr(10));'||wwv_flow.LF||
'        l_answers_tmp  := replace(l_answers_tmp';
wwv_flow_imp.g_varchar2_table(447) := ',chr(10),''|'');'||wwv_flow.LF||
'        l_answers      := apex_string.split(l_answers_tmp,''|'');'||wwv_flow.LF||
'        l_answer_coun';
wwv_flow_imp.g_varchar2_table(448) := 't := l_answers.count;'||wwv_flow.LF||
'        if l_answer_count < 2 then'||wwv_flow.LF||
'            raise_application_error(-20111,';
wwv_flow_imp.g_varchar2_table(449) := '''A minimum of two answers is required.'');'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        for i in 1..l_answer_count loop'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(450) := '           add_answer ('||wwv_flow.LF||
'                p_question_id   => l_question_id,'||wwv_flow.LF||
'                p_answer_n';
wwv_flow_imp.g_varchar2_table(451) := 'umber => i,'||wwv_flow.LF||
'                p_answer_text   => l_answers(i) );'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'--        commit;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(452) := '   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select session_status'||wwv_flow.LF||
'          from qask_sessions'||wwv_flow.LF||
'         wher';
wwv_flow_imp.g_varchar2_table(453) := 'e id = p_session_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        -- closes any open question, so only one open at a time'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(454) := '   if c1.session_status = ''OPEN'' then'||wwv_flow.LF||
'            close_question (p_session_id => p_session_id);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(455) := '     end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'        update qask_session_questions'||wwv_flow.LF||
'           set question_status = case when c1.se';
wwv_flow_imp.g_varchar2_table(456) := 'ssion_status = ''STAGED'' then ''STAGED'' else ''OPEN'' end,'||wwv_flow.LF||
'               started_on = case when c1.sess';
wwv_flow_imp.g_varchar2_table(457) := 'ion_status = ''OPEN'' then sysdate end'||wwv_flow.LF||
'         where id = l_question_id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(458) := '   return l_question_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'    add_log ( '||wwv_flow.LF||
'        p_procedure_name => ''ad';
wwv_flow_imp.g_varchar2_table(459) := 'd_question'', '||wwv_flow.LF||
'        p_error          =>  sqlerrm, '||wwv_flow.LF||
'        p_arg1_name      => ''p_session_id'', p_a';
wwv_flow_imp.g_varchar2_table(460) := 'rg1_val => p_session_id, '||wwv_flow.LF||
'        p_arg2_name      => ''p_question_number'', p_arg2_val => p_question_';
wwv_flow_imp.g_varchar2_table(461) := 'number ); '||wwv_flow.LF||
'    rollback;'||wwv_flow.LF||
'    raise_application_error(-20111,''Error adding question.'');'||wwv_flow.LF||
'end add_quest';
wwv_flow_imp.g_varchar2_table(462) := 'ion;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure start_staged_question ('||wwv_flow.LF||
'    p_question_id  in number )'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    update qask_se';
wwv_flow_imp.g_varchar2_table(463) := 'ssion_questions'||wwv_flow.LF||
'       set question_status = ''OPEN'','||wwv_flow.LF||
'           started_on = sysdate'||wwv_flow.LF||
'     where id =';
wwv_flow_imp.g_varchar2_table(464) := ' p_question_id'||wwv_flow.LF||
'       and question_status = ''STAGED'';'||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'    ad';
wwv_flow_imp.g_varchar2_table(465) := 'd_log ( '||wwv_flow.LF||
'        p_procedure_name => ''start_staged_question'', '||wwv_flow.LF||
'        p_error          =>  sqlerrm,';
wwv_flow_imp.g_varchar2_table(466) := ' '||wwv_flow.LF||
'        p_arg1_name      => ''p_question_id'', p_arg1_val => p_question_id ); '||wwv_flow.LF||
'    raise_application';
wwv_flow_imp.g_varchar2_table(467) := '_error(-20111,''Error starting staged question.'');'||wwv_flow.LF||
'end start_staged_question;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_next_que';
wwv_flow_imp.g_varchar2_table(468) := 'stion_id ('||wwv_flow.LF||
'    p_session_id   in number,'||wwv_flow.LF||
'    p_question_id  in number   default null,'||wwv_flow.LF||
'    p_status  ';
wwv_flow_imp.g_varchar2_table(469) := '     in varchar2 default ''OPEN'' )'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select q.id'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(470) := '       from qask_sessions s,'||wwv_flow.LF||
'               qask_session_questions q'||wwv_flow.LF||
'         where s.id = q.session';
wwv_flow_imp.g_varchar2_table(471) := '_id'||wwv_flow.LF||
'           and s.id = p_session_id'||wwv_flow.LF||
'           and (s.session_status = p_status or p_status = ''AN';
wwv_flow_imp.g_varchar2_table(472) := 'Y'')'||wwv_flow.LF||
'           and (q.question_status = p_status or p_status = ''ANY'')'||wwv_flow.LF||
'           and (p_question_id ';
wwv_flow_imp.g_varchar2_table(473) := 'is null or'||wwv_flow.LF||
'                q.question_number > (select question_number'||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(474) := '          from qask_session_questions'||wwv_flow.LF||
'                                      where session_id = s.id'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(475) := '                                        and id = p_question_id))'||wwv_flow.LF||
'         order by q.question_number';
wwv_flow_imp.g_varchar2_table(476) := ''||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return null;'||wwv_flow.LF||
'end get_next_question_id;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'functi';
wwv_flow_imp.g_varchar2_table(477) := 'on get_prev_question_id ('||wwv_flow.LF||
'    p_session_id   in number,'||wwv_flow.LF||
'    p_question_id  in number,'||wwv_flow.LF||
'    p_status  ';
wwv_flow_imp.g_varchar2_table(478) := '     in varchar2 default ''OPEN'' )'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select q.id'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(479) := '       from qask_sessions s,'||wwv_flow.LF||
'               qask_session_questions q'||wwv_flow.LF||
'         where s.id = q.session';
wwv_flow_imp.g_varchar2_table(480) := '_id'||wwv_flow.LF||
'           and s.id = p_session_id'||wwv_flow.LF||
'           and (s.session_status = p_status or p_status = ''AN';
wwv_flow_imp.g_varchar2_table(481) := 'Y'')'||wwv_flow.LF||
'           and (q.question_status = p_status or p_status = ''ANY'')'||wwv_flow.LF||
'           and q.question_numb';
wwv_flow_imp.g_varchar2_table(482) := 'er < (select question_number'||wwv_flow.LF||
'                                      from qask_session_questions'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(483) := '                                where session_id = s.id'||wwv_flow.LF||
'                                       and i';
wwv_flow_imp.g_varchar2_table(484) := 'd = p_question_id)'||wwv_flow.LF||
'         order by q.question_number desc'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return c1.id;'||wwv_flow.LF||
'    end';
wwv_flow_imp.g_varchar2_table(485) := ' loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return null;'||wwv_flow.LF||
'end get_prev_question_id;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure get_next_question_status_json ('||wwv_flow.LF||
'    p';
wwv_flow_imp.g_varchar2_table(486) := '_session_id   in number,'||wwv_flow.LF||
'    p_question_id  in number  default null )'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_next_question_id  nu';
wwv_flow_imp.g_varchar2_table(487) := 'mber;'||wwv_flow.LF||
'    l_status            varchar2(255);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    l_next_question_id := get_next_question_id ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(488) := '                              p_session_id  => p_session_id,'||wwv_flow.LF||
'                              p_questio';
wwv_flow_imp.g_varchar2_table(489) := 'n_id => p_question_id );'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_next_question_id is not null then'||wwv_flow.LF||
'        l_status := get_questio';
wwv_flow_imp.g_varchar2_table(490) := 'n_status ('||wwv_flow.LF||
'                        p_question_id => l_next_question_id );'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'       if get_ses';
wwv_flow_imp.g_varchar2_table(491) := 'sion_status (p_session_id => p_session_id) = ''CLOSED'' then'||wwv_flow.LF||
'           l_status := ''SESSION_CLOSED'';'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(492) := '       end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    apex_json.open_object();'||wwv_flow.LF||
'    apex_json.write( ''status'', l_status );'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(493) := '    apex_json.close_all();'||wwv_flow.LF||
'end get_next_question_status_json;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function question_available_yn ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(494) := ' p_session_code  in varchar2 )'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'    l_session_code  varchar2(30) := clean_sess';
wwv_flow_imp.g_varchar2_table(495) := 'ion_code(p_session_code);'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select ''Y'''||wwv_flow.LF||
'          from qask_sessions s,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(496) := '              qask_session_questions q'||wwv_flow.LF||
'         where s.id = q.session_id'||wwv_flow.LF||
'           and s.session_c';
wwv_flow_imp.g_varchar2_table(497) := 'ode = l_session_code'||wwv_flow.LF||
'           and s.session_status = ''OPEN'''||wwv_flow.LF||
'           and q.question_status = ''OP';
wwv_flow_imp.g_varchar2_table(498) := 'EN'''||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return ''Y'';'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return ''N'';'||wwv_flow.LF||
'end question_available_yn;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'proce';
wwv_flow_imp.g_varchar2_table(499) := 'dure get_question_details ('||wwv_flow.LF||
'    p_question_id           in number,'||wwv_flow.LF||
'    p_question_number       out n';
wwv_flow_imp.g_varchar2_table(500) := 'umber,'||wwv_flow.LF||
'    p_question_status       out varchar2,'||wwv_flow.LF||
'    p_question              out varchar2,'||wwv_flow.LF||
'    p_ans';
wwv_flow_imp.g_varchar2_table(501) := 'wer_type           out varchar2,'||wwv_flow.LF||
'    p_ask_for_comments_yn   out varchar2,'||wwv_flow.LF||
'    p_question_explanatio';
wwv_flow_imp.g_varchar2_table(502) := 'n  out clob )'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'       select question_number,'||wwv_flow.LF||
'              question_status,';
wwv_flow_imp.g_varchar2_table(503) := ''||wwv_flow.LF||
'              question,'||wwv_flow.LF||
'              answer_type,'||wwv_flow.LF||
'              ask_for_comments_yn,'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(504) := ' question_explanation'||wwv_flow.LF||
'         from qask_session_questions '||wwv_flow.LF||
'        where id = p_question_id'||wwv_flow.LF||
'    ) l';
wwv_flow_imp.g_varchar2_table(505) := 'oop'||wwv_flow.LF||
'        p_question_number      := c1.question_number;'||wwv_flow.LF||
'        p_question_status      := c1.quest';
wwv_flow_imp.g_varchar2_table(506) := 'ion_status;'||wwv_flow.LF||
'        p_question             := c1.question;'||wwv_flow.LF||
'        p_answer_type          := c1.answ';
wwv_flow_imp.g_varchar2_table(507) := 'er_type;'||wwv_flow.LF||
'        p_ask_for_comments_yn  := c1.ask_for_comments_yn;'||wwv_flow.LF||
'        p_question_explanation :=';
wwv_flow_imp.g_varchar2_table(508) := ' c1.question_explanation;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end get_question_details;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_question_status ('||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(509) := '   p_question_id  in number )'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_question_status  qask_session_questions.';
wwv_flow_imp.g_varchar2_table(510) := 'question_status%type;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    select question_status'||wwv_flow.LF||
'      into l_question_status'||wwv_flow.LF||
'      from qask_';
wwv_flow_imp.g_varchar2_table(511) := 'session_questions '||wwv_flow.LF||
'     where id = p_question_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_question_status;'||wwv_flow.LF||
'end get_question_st';
wwv_flow_imp.g_varchar2_table(512) := 'atus;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function is_ask_for_comments_yn ('||wwv_flow.LF||
'    p_question_id  in number )'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(513) := ' l_ask_for_comments_yn  qask_session_questions.ask_for_comments_yn%type;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    select ask_for_co';
wwv_flow_imp.g_varchar2_table(514) := 'mments_yn'||wwv_flow.LF||
'      into l_ask_for_comments_yn'||wwv_flow.LF||
'      from qask_session_questions '||wwv_flow.LF||
'     where id = p_ques';
wwv_flow_imp.g_varchar2_table(515) := 'tion_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_ask_for_comments_yn;'||wwv_flow.LF||
'end is_ask_for_comments_yn;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function copy_session ('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(516) := '  p_from_session_id         in number,'||wwv_flow.LF||
'    p_app_user                in varchar2,'||wwv_flow.LF||
'    p_session_name';
wwv_flow_imp.g_varchar2_table(517) := '            in varchar2,'||wwv_flow.LF||
'    p_purpose                 in varchar2,'||wwv_flow.LF||
'    p_visibility              in';
wwv_flow_imp.g_varchar2_table(518) := ' varchar2,'||wwv_flow.LF||
'    p_resp_name_required_yn   in varchar2 default ''N'','||wwv_flow.LF||
'    p_resp_email_required_yn  in v';
wwv_flow_imp.g_varchar2_table(519) := 'archar2 default ''N'','||wwv_flow.LF||
'    p_session_status          in varchar2 default ''OPEN'' )'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is';
wwv_flow_imp.g_varchar2_table(520) := ''||wwv_flow.LF||
'    l_session_id    number;'||wwv_flow.LF||
'    l_question_id   number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_session_id := create_session (';
wwv_flow_imp.g_varchar2_table(521) := ''||wwv_flow.LF||
'                        p_app_user               => p_app_user,'||wwv_flow.LF||
'                        p_session_n';
wwv_flow_imp.g_varchar2_table(522) := 'ame           => p_session_name,'||wwv_flow.LF||
'                        p_purpose                => p_purpose,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(523) := '                    p_visibility             => p_visibility,'||wwv_flow.LF||
'                        p_resp_name_re';
wwv_flow_imp.g_varchar2_table(524) := 'quired_yn  => p_resp_name_required_yn,'||wwv_flow.LF||
'                        p_resp_email_required_yn => p_resp_em';
wwv_flow_imp.g_varchar2_table(525) := 'ail_required_yn,'||wwv_flow.LF||
'                        p_session_status         => ''STAGED'');'||wwv_flow.LF||
''||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(526) := '     select q.*, (select listagg(answer_text, ''|'') '||wwv_flow.LF||
'                            within group (order ';
wwv_flow_imp.g_varchar2_table(527) := 'by answer_number)'||wwv_flow.LF||
'                       from qask_sess_question_answers a'||wwv_flow.LF||
'                      whe';
wwv_flow_imp.g_varchar2_table(528) := 're q.id = a.question_id) answers'||wwv_flow.LF||
'          from qask_session_questions q'||wwv_flow.LF||
'         where q.session_id';
wwv_flow_imp.g_varchar2_table(529) := ' = p_from_session_id'||wwv_flow.LF||
'         order by q.question_number'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        l_question_id := add_que';
wwv_flow_imp.g_varchar2_table(530) := 'stion ('||wwv_flow.LF||
'                             p_session_id                    => l_session_id,'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(531) := '               p_question_number               => c1.question_number,'||wwv_flow.LF||
'                             p';
wwv_flow_imp.g_varchar2_table(532) := '_question                      => c1.question,'||wwv_flow.LF||
'                             p_answer_set_id         ';
wwv_flow_imp.g_varchar2_table(533) := '        => c1.answer_set_id,'||wwv_flow.LF||
'                             p_answers                       => c1.answ';
wwv_flow_imp.g_varchar2_table(534) := 'ers,'||wwv_flow.LF||
'                             p_answer_type                   => c1.answer_type,'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(535) := '              p_ask_for_comments_yn           => c1.ask_for_comments_yn,'||wwv_flow.LF||
'                           ';
wwv_flow_imp.g_varchar2_table(536) := '  p_question_explanation          => c1.question_explanation,'||wwv_flow.LF||
'                             p_questio';
wwv_flow_imp.g_varchar2_table(537) := 'n_file                 => c1.question_file,'||wwv_flow.LF||
'                             p_question_filename        ';
wwv_flow_imp.g_varchar2_table(538) := '     => c1.question_filename,'||wwv_flow.LF||
'                             p_question_file_mimetype        => c1.que';
wwv_flow_imp.g_varchar2_table(539) := 'stion_file_mimetype,'||wwv_flow.LF||
'                             p_question_file_last_updated_on => c1.question_fil';
wwv_flow_imp.g_varchar2_table(540) := 'e_last_updated_on );'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_session_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'    add_lo';
wwv_flow_imp.g_varchar2_table(541) := 'g ( '||wwv_flow.LF||
'        p_procedure_name => ''copy_session'', '||wwv_flow.LF||
'        p_error          =>  sqlerrm, '||wwv_flow.LF||
'        p_a';
wwv_flow_imp.g_varchar2_table(542) := 'rg1_name      => ''p_from_session_id'', p_arg1_val => p_from_session_id, '||wwv_flow.LF||
'        p_arg2_name      => ';
wwv_flow_imp.g_varchar2_table(543) := '''p_app_user'', p_arg2_val => p_app_user ); '||wwv_flow.LF||
'    rollback;'||wwv_flow.LF||
'    raise_application_error(-20111,''Error c';
wwv_flow_imp.g_varchar2_table(544) := 'opying session.'');'||wwv_flow.LF||
'end copy_session;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-----------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- returns response_id';
wwv_flow_imp.g_varchar2_table(545) := ''||wwv_flow.LF||
'function answer_question ('||wwv_flow.LF||
'    p_session_id        in number,'||wwv_flow.LF||
'    p_question_id       in number,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(546) := '  p_apex_session_id   in number,'||wwv_flow.LF||
'    p_answer_id         in number   default null,'||wwv_flow.LF||
'    p_answer_free';
wwv_flow_imp.g_varchar2_table(547) := 'form   in varchar2 default null,'||wwv_flow.LF||
'    p_comment_text      in varchar2 default null,'||wwv_flow.LF||
'    p_multi_answe';
wwv_flow_imp.g_varchar2_table(548) := 'r      in varchar2 default null,'||wwv_flow.LF||
'    p_response_id       in number,'||wwv_flow.LF||
'    p_respondent_name   in varch';
wwv_flow_imp.g_varchar2_table(549) := 'ar2 default null,'||wwv_flow.LF||
'    p_respondent_email  in varchar2 default null )'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_res';
wwv_flow_imp.g_varchar2_table(550) := 'ponse_id             number;'||wwv_flow.LF||
'    l_answer_type             qask_session_questions.answer_type%type;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(551) := '    l_is_ask_for_comments_yn  varchar2(1) := ''N'';'||wwv_flow.LF||
'    l_answer_text             qask_sess_question_a';
wwv_flow_imp.g_varchar2_table(552) := 'nswers.answer_text%type;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- check if session is still open'||wwv_flow.LF||
'    if get_session_status (p_s';
wwv_flow_imp.g_varchar2_table(553) := 'ession_id => p_session_id) != ''OPEN'' then'||wwv_flow.LF||
'       raise_application_error(-20111,''Session is now clos';
wwv_flow_imp.g_varchar2_table(554) := 'ed.'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- check if question is still open'||wwv_flow.LF||
'    if get_question_status (p_question_id';
wwv_flow_imp.g_varchar2_table(555) := ' => p_question_id) != ''OPEN'' then'||wwv_flow.LF||
'       raise_application_error(-20111,''Question is now closed.'');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(556) := '    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- check if response_id matches session_id (if not, user in new session)'||wwv_flow.LF||
'    if p_r';
wwv_flow_imp.g_varchar2_table(557) := 'esponse_id is not null then'||wwv_flow.LF||
'        for c1 in ('||wwv_flow.LF||
'            select 1 from qask_responses'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(558) := '  where id = p_response_id'||wwv_flow.LF||
'               and session_id != p_session_id'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(559) := 'raise_application_error(-20111,''Response ID for different Session ID.'');'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'    end i';
wwv_flow_imp.g_varchar2_table(560) := 'f;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if p_response_id is null then'||wwv_flow.LF||
'        -- check if apex_session_id already has response_id fo';
wwv_flow_imp.g_varchar2_table(561) := 'r this session_id'||wwv_flow.LF||
'        --  (user may have gone back to page 1, which clears out response_id)'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(562) := '    for c1 in ('||wwv_flow.LF||
'            select id from qask_responses'||wwv_flow.LF||
'             where session_id = p_session_';
wwv_flow_imp.g_varchar2_table(563) := 'id'||wwv_flow.LF||
'               and apex_session = nvl(p_apex_session_id,sys_context(''APEX$SESSION'',''APP_SESSION'')';
wwv_flow_imp.g_varchar2_table(564) := ')'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            l_response_id := c1.id;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'        if l_response_id is ';
wwv_flow_imp.g_varchar2_table(565) := 'null then'||wwv_flow.LF||
'            -- only record name and email if required by session'||wwv_flow.LF||
'            insert into q';
wwv_flow_imp.g_varchar2_table(566) := 'ask_responses ('||wwv_flow.LF||
'                session_id,'||wwv_flow.LF||
'                name,'||wwv_flow.LF||
'                email )'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(567) := '  values ('||wwv_flow.LF||
'                p_session_id,'||wwv_flow.LF||
'                case when session_resp_name_req_yn(p_sessio';
wwv_flow_imp.g_varchar2_table(568) := 'n_id => p_session_id) = ''Y'' then p_respondent_name end,'||wwv_flow.LF||
'                case when session_resp_email';
wwv_flow_imp.g_varchar2_table(569) := '_req_yn(p_session_id => p_session_id) = ''Y'' then p_respondent_email end)'||wwv_flow.LF||
'            returning id in';
wwv_flow_imp.g_varchar2_table(570) := 'to l_response_id;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        l_response_id := p_response_id;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(571) := 'select answer_type, ask_for_comments_yn'||wwv_flow.LF||
'      into l_answer_type, l_is_ask_for_comments_yn'||wwv_flow.LF||
'      fro';
wwv_flow_imp.g_varchar2_table(572) := 'm qask_session_questions '||wwv_flow.LF||
'     where id = p_question_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    if l_answer_type = ''MULTI'' then'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(573) := '  for c1 in ('||wwv_flow.LF||
'           select to_number(v.column_value) answer_id, a.answer_text'||wwv_flow.LF||
'             from';
wwv_flow_imp.g_varchar2_table(574) := ' apex_string.split(p_multi_answer, '':'') v,'||wwv_flow.LF||
'                  qask_sess_question_answers a'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(575) := '  where to_number(v.column_value) = a.id (+)'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            insert into qask_response_an';
wwv_flow_imp.g_varchar2_table(576) := 'swers ('||wwv_flow.LF||
'                response_id,'||wwv_flow.LF||
'                question_id,'||wwv_flow.LF||
'                answer_id,'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(577) := '         answer_text )'||wwv_flow.LF||
'            values ('||wwv_flow.LF||
'                l_response_id,'||wwv_flow.LF||
'                p_questio';
wwv_flow_imp.g_varchar2_table(578) := 'n_id,'||wwv_flow.LF||
'                c1.answer_id,'||wwv_flow.LF||
'                c1.answer_text);'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'    else  -- ';
wwv_flow_imp.g_varchar2_table(579) := 'SINGLE or FREEFORM'||wwv_flow.LF||
'        if p_answer_id is not null then'||wwv_flow.LF||
'            select answer_text'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(580) := '    into l_answer_text'||wwv_flow.LF||
'              from qask_sess_question_answers'||wwv_flow.LF||
'             where id = p_answe';
wwv_flow_imp.g_varchar2_table(581) := 'r_id;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        insert into qask_response_answers ('||wwv_flow.LF||
'            response_id,'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(582) := '   question_id,'||wwv_flow.LF||
'            answer_id,'||wwv_flow.LF||
'            answer_text,'||wwv_flow.LF||
'            comment_text )'||wwv_flow.LF||
'        v';
wwv_flow_imp.g_varchar2_table(583) := 'alues ('||wwv_flow.LF||
'            l_response_id,'||wwv_flow.LF||
'            p_question_id,'||wwv_flow.LF||
'            p_answer_id,'||wwv_flow.LF||
'            c';
wwv_flow_imp.g_varchar2_table(584) := 'ase when p_answer_id is not null then l_answer_text else p_answer_freeform end,'||wwv_flow.LF||
'            case whe';
wwv_flow_imp.g_varchar2_table(585) := 'n l_is_ask_for_comments_yn = ''Y'' then p_comment_text end );'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return l_r';
wwv_flow_imp.g_varchar2_table(586) := 'esponse_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'    add_log ( '||wwv_flow.LF||
'        p_procedure_name => ''answer_question';
wwv_flow_imp.g_varchar2_table(587) := ''', '||wwv_flow.LF||
'        p_error          =>  sqlerrm, '||wwv_flow.LF||
'        p_arg1_name      => ''p_session_id'', p_arg1_val =>';
wwv_flow_imp.g_varchar2_table(588) := ' p_session_id, '||wwv_flow.LF||
'        p_arg2_name      => ''p_question_id'', p_arg2_val => p_question_id ); '||wwv_flow.LF||
'    rai';
wwv_flow_imp.g_varchar2_table(589) := 'se_application_error(-20111,''Error answering question.'');'||wwv_flow.LF||
'end answer_question;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function is_questio';
wwv_flow_imp.g_varchar2_table(590) := 'n_answered_yn ('||wwv_flow.LF||
'    p_response_id  in number,'||wwv_flow.LF||
'    p_question_id  in number )'||wwv_flow.LF||
'    return varchar2'||wwv_flow.LF||
'is'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(591) := 'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'        select 1'||wwv_flow.LF||
'          from qask_response_answers'||wwv_flow.LF||
'         where response_';
wwv_flow_imp.g_varchar2_table(592) := 'id = p_response_id'||wwv_flow.LF||
'           and question_id = p_question_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return ''Y'';'||wwv_flow.LF||
'    end';
wwv_flow_imp.g_varchar2_table(593) := ' loop;'||wwv_flow.LF||
'    return ''N'';'||wwv_flow.LF||
'end is_question_answered_yn;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function get_response_id ('||wwv_flow.LF||
'    p_session_id   ';
wwv_flow_imp.g_varchar2_table(594) := '     in number,'||wwv_flow.LF||
'    p_apex_session_id   in number )'||wwv_flow.LF||
'    return number'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for c1 in ('||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(595) := '   select id'||wwv_flow.LF||
'          from qask_responses'||wwv_flow.LF||
'         where session_id = p_session_id'||wwv_flow.LF||
'           and a';
wwv_flow_imp.g_varchar2_table(596) := 'pex_session = p_apex_session_id'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'        return c1.id;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'    return null;'||wwv_flow.LF||
'end';
wwv_flow_imp.g_varchar2_table(597) := ' get_response_id;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'procedure close_question ('||wwv_flow.LF||
'    p_session_id   in number default null,'||wwv_flow.LF||
'    p_ques';
wwv_flow_imp.g_varchar2_table(598) := 'tion_id  in number default null )'||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if p_session_id is not null then'||wwv_flow.LF||
'        update qask';
wwv_flow_imp.g_varchar2_table(599) := '_session_questions'||wwv_flow.LF||
'           set question_status = ''CLOSED'','||wwv_flow.LF||
'           closed_on = case when quest';
wwv_flow_imp.g_varchar2_table(600) := 'ion_status = ''OPEN'' then sysdate end,'||wwv_flow.LF||
'           length_seconds = case when question_status = ''OPEN''';
wwv_flow_imp.g_varchar2_table(601) := ' then (sysdate - started_on)  * 24 * 60 * 60 end'||wwv_flow.LF||
'         where session_id = p_session_id'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(602) := ' and question_status in (''STAGED'',''OPEN'');'||wwv_flow.LF||
'    else'||wwv_flow.LF||
'        update qask_session_questions'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(603) := ' set question_status = ''CLOSED'','||wwv_flow.LF||
'           closed_on = case when question_status = ''OPEN'' then sysd';
wwv_flow_imp.g_varchar2_table(604) := 'ate end,'||wwv_flow.LF||
'           length_seconds = case when question_status = ''OPEN'' then (sysdate - started_on) ';
wwv_flow_imp.g_varchar2_table(605) := ' * 24 * 60 * 60 end'||wwv_flow.LF||
'         where id = p_question_id'||wwv_flow.LF||
'           and question_status in (''STAGED'',''O';
wwv_flow_imp.g_varchar2_table(606) := 'PEN'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'    add_log ( '||wwv_flow.LF||
'        p_procedure_name => ''close_qu';
wwv_flow_imp.g_varchar2_table(607) := 'estion'', '||wwv_flow.LF||
'        p_error          =>  sqlerrm, '||wwv_flow.LF||
'        p_arg1_name      => ''p_session_id'', p_arg1_';
wwv_flow_imp.g_varchar2_table(608) := 'val => p_session_id, '||wwv_flow.LF||
'        p_arg2_name      => ''p_question_id'', p_arg2_val => p_question_id ); '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(609) := '   raise_application_error(-20111,''Error closing question.'');'||wwv_flow.LF||
'end close_question;'||wwv_flow.LF||
''||wwv_flow.LF||
'end qask_util;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(59295033209530626605)
,p_install_id=>wwv_flow_imp.id(49582154264788065099)
,p_name=>'qask_util body'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
