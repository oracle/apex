prompt --application/deployment/install/install_close_old_job
begin
--   Manifest
--     INSTALL: INSTALL-close_old job
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'begin'||wwv_flow.LF||
'   dbms_scheduler.create_job ('||wwv_flow.LF||
'      job_name        => ''QASK_CLOSE_OLD_SESSIONS'','||wwv_flow.LF||
'      job_t';
wwv_flow_imp.g_varchar2_table(2) := 'ype        => ''STORED_PROCEDURE'','||wwv_flow.LF||
'      job_action      => ''QASK_UTIL.CLOSE_OLD_SESSIONS'','||wwv_flow.LF||
'      aut';
wwv_flow_imp.g_varchar2_table(3) := 'o_drop       => false,'||wwv_flow.LF||
'      comments        => ''Closes any sessions idle for more than the allowed ';
wwv_flow_imp.g_varchar2_table(4) := 'time'');'||wwv_flow.LF||
'exception when others then'||wwv_flow.LF||
'    -- ORA-00955: name is already used by an existing object'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(5) := 'if sqlcode not in (-955,-27477) then'||wwv_flow.LF||
'        raise;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(59295070736819632563)
,p_install_id=>wwv_flow_imp.id(49582154264788065099)
,p_name=>'close_old job'
,p_sequence=>60
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
