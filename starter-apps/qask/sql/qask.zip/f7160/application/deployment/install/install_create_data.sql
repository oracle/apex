prompt --application/deployment/install/install_create_data
begin
--   Manifest
--     INSTALL: INSTALL-create data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- load settings'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    qask_util.add_setting ('||wwv_flow.LF||
'        p_name          => ''max_open_sessions_pe';
wwv_flow_imp.g_varchar2_table(2) := 'r_user'','||wwv_flow.LF||
'        p_display_order => 10,'||wwv_flow.LF||
'        p_description   => ''once this is reached, the user w';
wwv_flow_imp.g_varchar2_table(3) := 'ill be prompted to close old sessions before created a new one'','||wwv_flow.LF||
'        p_value         => ''3'','||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(4) := '     p_is_numeric_yn => ''Y'','||wwv_flow.LF||
'        p_is_yn         => ''N'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'    qask_util.add_setting ('||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(5) := 'p_name          => ''max_session_idle_hours'','||wwv_flow.LF||
'        p_display_order => 20,'||wwv_flow.LF||
'        p_description   ';
wwv_flow_imp.g_varchar2_table(6) := '=> ''if a session is left open this long, without adding new questions, it can be auto-closed'','||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(7) := '   p_value         => ''8'','||wwv_flow.LF||
'        p_is_numeric_yn => ''Y'','||wwv_flow.LF||
'        p_is_yn         => ''N'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'    qa';
wwv_flow_imp.g_varchar2_table(8) := 'sk_util.add_setting ('||wwv_flow.LF||
'        p_name          => ''from_email'','||wwv_flow.LF||
'        p_display_order => 30,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(9) := '  p_description   => ''used as the from address for the emails sent (for tokens, account requests)'','||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(10) := '        p_value         => '''','||wwv_flow.LF||
'        p_is_numeric_yn => ''N'','||wwv_flow.LF||
'        p_is_yn         => ''N'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(11) := '  qask_util.add_setting ('||wwv_flow.LF||
'        p_name          => ''allow_account_requests_yn'','||wwv_flow.LF||
'        p_display_';
wwv_flow_imp.g_varchar2_table(12) := 'order => 40,'||wwv_flow.LF||
'        p_description   => ''can users request access to the application'','||wwv_flow.LF||
'        p_val';
wwv_flow_imp.g_varchar2_table(13) := 'ue         => ''Y'','||wwv_flow.LF||
'        p_is_numeric_yn => ''N'','||wwv_flow.LF||
'        p_is_yn         => ''Y'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'    qask_util.';
wwv_flow_imp.g_varchar2_table(14) := 'add_setting ('||wwv_flow.LF||
'        p_name          => ''restrict_requests_to_email_domains_yn'','||wwv_flow.LF||
'        p_display_';
wwv_flow_imp.g_varchar2_table(15) := 'order => 45,'||wwv_flow.LF||
'        p_description   => ''access requests must be within the identified email domains';
wwv_flow_imp.g_varchar2_table(16) := ''','||wwv_flow.LF||
'        p_value         => ''N'','||wwv_flow.LF||
'        p_is_numeric_yn => ''N'','||wwv_flow.LF||
'        p_is_yn         => ''Y'' );';
wwv_flow_imp.g_varchar2_table(17) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'    qask_util.add_setting ('||wwv_flow.LF||
'        p_name          => ''restrict_users_to_email_domains_yn'','||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(18) := '   p_display_order => 46,'||wwv_flow.LF||
'        p_description   => ''users must be within the identified email doma';
wwv_flow_imp.g_varchar2_table(19) := 'ins (if Y, this overrides requests setting)'','||wwv_flow.LF||
'        p_value         => ''N'','||wwv_flow.LF||
'        p_is_numeric_y';
wwv_flow_imp.g_varchar2_table(20) := 'n => ''N'','||wwv_flow.LF||
'        p_is_yn         => ''Y'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'    qask_util.add_setting ('||wwv_flow.LF||
'        p_name          => ';
wwv_flow_imp.g_varchar2_table(21) := '''max_tokens'','||wwv_flow.LF||
'        p_display_order => 50,'||wwv_flow.LF||
'        p_description   => ''how many tokens can be gene';
wwv_flow_imp.g_varchar2_table(22) := 'rated during the reset window'','||wwv_flow.LF||
'        p_value         => ''3'','||wwv_flow.LF||
'        p_is_numeric_yn => ''Y'','||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(23) := '    p_is_yn         => ''N'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'    qask_util.add_setting ('||wwv_flow.LF||
'        p_name          => ''max_verify_at';
wwv_flow_imp.g_varchar2_table(24) := 'tempts_per_token'','||wwv_flow.LF||
'        p_display_order => 55,'||wwv_flow.LF||
'        p_description   => ''how many verification ';
wwv_flow_imp.g_varchar2_table(25) := 'attempts before a token is no longer valid'','||wwv_flow.LF||
'        p_value         => ''3'','||wwv_flow.LF||
'        p_is_numeric_yn';
wwv_flow_imp.g_varchar2_table(26) := ' => ''Y'','||wwv_flow.LF||
'        p_is_yn         => ''N'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'    qask_util.add_setting ('||wwv_flow.LF||
'        p_name          => ''';
wwv_flow_imp.g_varchar2_table(27) := 'reset_verify_after_x_hours'','||wwv_flow.LF||
'        p_display_order => 60,'||wwv_flow.LF||
'        p_description   => ''how many hou';
wwv_flow_imp.g_varchar2_table(28) := 'rs a user will be locked out after exceeding max tokens/max attempts'','||wwv_flow.LF||
'        p_value         => ''1';
wwv_flow_imp.g_varchar2_table(29) := ''','||wwv_flow.LF||
'        p_is_numeric_yn => ''Y'','||wwv_flow.LF||
'        p_is_yn         => ''N'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'    qask_util.add_setting ('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(30) := '      p_name          => ''service_available_yn'','||wwv_flow.LF||
'        p_display_order => 100,'||wwv_flow.LF||
'        p_descripti';
wwv_flow_imp.g_varchar2_table(31) := 'on   => ''if N, only administrators can access the service - sessions cannot be accessed'','||wwv_flow.LF||
'        p_';
wwv_flow_imp.g_varchar2_table(32) := 'value         => ''Y'','||wwv_flow.LF||
'        p_is_numeric_yn => ''N'','||wwv_flow.LF||
'        p_is_yn         => ''Y'' );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'-- ';
wwv_flow_imp.g_varchar2_table(33) := 'seed answer sets'||wwv_flow.LF||
''||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    l_answer_set_id  number;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
''||wwv_flow.LF||
'    delete from qask_answer_sets;'||wwv_flow.LF||
''||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(34) := ' l_answer_set_id := qask_util.add_answer_set (p_answer_set_code => ''EXCPO'', p_answer_set_name => ''Ex';
wwv_flow_imp.g_varchar2_table(35) := 'cellent to Poor'');'||wwv_flow.LF||
''||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_';
wwv_flow_imp.g_varchar2_table(36) := 'text => ''Excellent'', p_display_order => 1);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_';
wwv_flow_imp.g_varchar2_table(37) := 'answer_set_id, p_answer_text => ''Good'', p_display_order => 2);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_';
wwv_flow_imp.g_varchar2_table(38) := 'answer_set_id => l_answer_set_id, p_answer_text => ''Fair'', p_display_order => 3);'||wwv_flow.LF||
'        qask_util.';
wwv_flow_imp.g_varchar2_table(39) := 'add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Poor'', p_display_order => 4);';
wwv_flow_imp.g_varchar2_table(40) := ''||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Very Poor''';
wwv_flow_imp.g_varchar2_table(41) := ', p_display_order => 5);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := qask_util.add_answer_set (p_answer_set_code => ''LIK';
wwv_flow_imp.g_varchar2_table(42) := 'ES'', p_answer_set_name => ''Likelyhood'');'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_ans';
wwv_flow_imp.g_varchar2_table(43) := 'wer_set_id, p_answer_text => ''Most Likely'', p_display_order => 1);'||wwv_flow.LF||
'        qask_util.add_aset_answer';
wwv_flow_imp.g_varchar2_table(44) := ' (p_answer_set_id => l_answer_set_id, p_answer_text => ''Likely'', p_display_order => 2);'||wwv_flow.LF||
'        qask';
wwv_flow_imp.g_varchar2_table(45) := '_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Unsure'', p_display_orde';
wwv_flow_imp.g_varchar2_table(46) := 'r => 3);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''No';
wwv_flow_imp.g_varchar2_table(47) := 't Likely'', p_display_order => 4);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set';
wwv_flow_imp.g_varchar2_table(48) := '_id, p_answer_text => ''Most Unlikely'', p_display_order => 5);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := qask_util.add';
wwv_flow_imp.g_varchar2_table(49) := '_answer_set (p_answer_set_code => ''TRUEF'', p_answer_set_name => ''True False'');'||wwv_flow.LF||
'        qask_util.add';
wwv_flow_imp.g_varchar2_table(50) := '_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''True'', p_display_order => 1);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(51) := '      qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''False'', p_dis';
wwv_flow_imp.g_varchar2_table(52) := 'play_order => 2);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := qask_util.add_answer_set (p_answer_set_code => ''LOVEH'', p';
wwv_flow_imp.g_varchar2_table(53) := '_answer_set_name => ''Love Hate'');'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set';
wwv_flow_imp.g_varchar2_table(54) := '_id, p_answer_text => ''Love'', p_display_order => 1);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set';
wwv_flow_imp.g_varchar2_table(55) := '_id => l_answer_set_id, p_answer_text => ''Hate'', p_display_order => 2);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := qas';
wwv_flow_imp.g_varchar2_table(56) := 'k_util.add_answer_set (p_answer_set_code => ''YESNO'', p_answer_set_name => ''Yes No'');'||wwv_flow.LF||
'        qask_ut';
wwv_flow_imp.g_varchar2_table(57) := 'il.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Yes'', p_display_order => 1';
wwv_flow_imp.g_varchar2_table(58) := ');'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''No'', p_d';
wwv_flow_imp.g_varchar2_table(59) := 'isplay_order => 2);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := qask_util.add_answer_set (p_answer_set_code => ''YNMAY'',';
wwv_flow_imp.g_varchar2_table(60) := ' p_answer_set_name => ''Yes, No, Unsure'');'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_an';
wwv_flow_imp.g_varchar2_table(61) := 'swer_set_id, p_answer_text => ''Yes'', p_display_order => 1);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_ans';
wwv_flow_imp.g_varchar2_table(62) := 'wer_set_id => l_answer_set_id, p_answer_text => ''Unsure'', p_display_order => 2);'||wwv_flow.LF||
'        qask_util.a';
wwv_flow_imp.g_varchar2_table(63) := 'dd_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''No'', p_display_order => 3);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(64) := '    l_answer_set_id := qask_util.add_answer_set (p_answer_set_code => ''EASYH'', p_answer_set_name => ';
wwv_flow_imp.g_varchar2_table(65) := '''Easy'');'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Ve';
wwv_flow_imp.g_varchar2_table(66) := 'ry Easy'', p_display_order => 1);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_';
wwv_flow_imp.g_varchar2_table(67) := 'id, p_answer_text => ''Easy'', p_display_order => 2);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_';
wwv_flow_imp.g_varchar2_table(68) := 'id => l_answer_set_id, p_answer_text => ''Medium'', p_display_order => 3);'||wwv_flow.LF||
'        qask_util.add_aset_';
wwv_flow_imp.g_varchar2_table(69) := 'answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Hard'', p_display_order => 4);'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(70) := 'qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Very Hard'', p_displ';
wwv_flow_imp.g_varchar2_table(71) := 'ay_order => 5);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := qask_util.add_answer_set (p_answer_set_code => ''COOLS'', p_a';
wwv_flow_imp.g_varchar2_table(72) := 'nswer_set_name => ''Cool'');'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_';
wwv_flow_imp.g_varchar2_table(73) := 'answer_text => ''Sub Zero Cool'', p_display_order => 1);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_s';
wwv_flow_imp.g_varchar2_table(74) := 'et_id => l_answer_set_id, p_answer_text => ''Cool'', p_display_order => 2);'||wwv_flow.LF||
'        qask_util.add_aset';
wwv_flow_imp.g_varchar2_table(75) := '_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''OK'', p_display_order => 3);'||wwv_flow.LF||
'        q';
wwv_flow_imp.g_varchar2_table(76) := 'ask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Uncool'', p_display_o';
wwv_flow_imp.g_varchar2_table(77) := 'rder => 4);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ';
wwv_flow_imp.g_varchar2_table(78) := '''Really Uncool'', p_display_order => 5);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := qask_util.add_answer_set (p_answer_s';
wwv_flow_imp.g_varchar2_table(79) := 'et_code => ''MOSCO'', p_answer_set_name => ''MoSCoW'');'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_';
wwv_flow_imp.g_varchar2_table(80) := 'id => l_answer_set_id, p_answer_text => ''Must Have'', p_display_order => 1);'||wwv_flow.LF||
'        qask_util.add_as';
wwv_flow_imp.g_varchar2_table(81) := 'et_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Should Have'', p_display_order => 2)';
wwv_flow_imp.g_varchar2_table(82) := ';'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Could Hav';
wwv_flow_imp.g_varchar2_table(83) := 'e'', p_display_order => 3);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_';
wwv_flow_imp.g_varchar2_table(84) := 'answer_text => ''Won''''t Have this time'', p_display_order => 4);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := qask_util.add';
wwv_flow_imp.g_varchar2_table(85) := '_answer_set (p_answer_set_code => ''LOEFF'', p_answer_set_name => ''Level of Effort'');'||wwv_flow.LF||
'        qask_uti';
wwv_flow_imp.g_varchar2_table(86) := 'l.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Very Complex 2 years+-'', p_';
wwv_flow_imp.g_varchar2_table(87) := 'display_order => 1);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer';
wwv_flow_imp.g_varchar2_table(88) := '_text => ''Complex 1 year+-'', p_display_order => 2);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_';
wwv_flow_imp.g_varchar2_table(89) := 'id => l_answer_set_id, p_answer_text => ''Hard 2 months+-'', p_display_order => 3);'||wwv_flow.LF||
'        qask_util.';
wwv_flow_imp.g_varchar2_table(90) := 'add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Modest 2 weeks+-'', p_display_';
wwv_flow_imp.g_varchar2_table(91) := 'order => 4);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text =>';
wwv_flow_imp.g_varchar2_table(92) := ' ''Easy 2 days+-'', p_display_order => 5);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_ans';
wwv_flow_imp.g_varchar2_table(93) := 'wer_set_id, p_answer_text => ''Trivial 2 hours+-'', p_display_order => 6);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := qas';
wwv_flow_imp.g_varchar2_table(94) := 'k_util.add_answer_set (p_answer_set_code => ''UNDER'', p_answer_set_name => ''Understanding'');'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(95) := 'qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Crystal clear'', p_d';
wwv_flow_imp.g_varchar2_table(96) := 'isplay_order => 1);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_';
wwv_flow_imp.g_varchar2_table(97) := 'text => ''Understood'', p_display_order => 2);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l';
wwv_flow_imp.g_varchar2_table(98) := '_answer_set_id, p_answer_text => ''Got the gist'', p_display_order => 3);'||wwv_flow.LF||
'        qask_util.add_aset_a';
wwv_flow_imp.g_varchar2_table(99) := 'nswer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Vaguely understood'', p_display_order =>';
wwv_flow_imp.g_varchar2_table(100) := ' 4);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''No clu';
wwv_flow_imp.g_varchar2_table(101) := 'e'', p_display_order => 5);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := qask_util.add_answer_set (p_answer_set_code => ''A';
wwv_flow_imp.g_varchar2_table(102) := 'VERA'', p_answer_set_name => ''Average'');'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answ';
wwv_flow_imp.g_varchar2_table(103) := 'er_set_id, p_answer_text => ''Way Above Average'', p_display_order => 1);'||wwv_flow.LF||
'        qask_util.add_aset_a';
wwv_flow_imp.g_varchar2_table(104) := 'nswer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Above Average'', p_display_order => 2);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(105) := '        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Average'', p';
wwv_flow_imp.g_varchar2_table(106) := '_display_order => 3);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answe';
wwv_flow_imp.g_varchar2_table(107) := 'r_text => ''Below Average'', p_display_order => 4);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id';
wwv_flow_imp.g_varchar2_table(108) := ' => l_answer_set_id, p_answer_text => ''Way Below Average'', p_display_order => 5);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_';
wwv_flow_imp.g_varchar2_table(109) := 'id := qask_util.add_answer_set (p_answer_set_code => ''COMPE'', p_answer_set_name => ''Competitiveness''';
wwv_flow_imp.g_varchar2_table(110) := ');'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Most Com';
wwv_flow_imp.g_varchar2_table(111) := 'petitive'', p_display_order => 1);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set';
wwv_flow_imp.g_varchar2_table(112) := '_id, p_answer_text => ''Competitive'', p_display_order => 2);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_ans';
wwv_flow_imp.g_varchar2_table(113) := 'wer_set_id => l_answer_set_id, p_answer_text => ''Middling'', p_display_order => 3);'||wwv_flow.LF||
'        qask_util';
wwv_flow_imp.g_varchar2_table(114) := '.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Less Competitive'', p_display';
wwv_flow_imp.g_varchar2_table(115) := '_order => 4);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text =';
wwv_flow_imp.g_varchar2_table(116) := '> ''Least Competitive'', p_display_order => 5);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := qask_util.add_answer_set (p_an';
wwv_flow_imp.g_varchar2_table(117) := 'swer_set_code => ''WELLN'', p_answer_set_name => ''Willingness'');'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_';
wwv_flow_imp.g_varchar2_table(118) := 'answer_set_id => l_answer_set_id, p_answer_text => ''Most willing'', p_display_order => 1);'||wwv_flow.LF||
'        qa';
wwv_flow_imp.g_varchar2_table(119) := 'sk_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Willing'', p_display_o';
wwv_flow_imp.g_varchar2_table(120) := 'rder => 2);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ';
wwv_flow_imp.g_varchar2_table(121) := '''Not sure'', p_display_order => 3);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_se';
wwv_flow_imp.g_varchar2_table(122) := 't_id, p_answer_text => ''Not willing'', p_display_order => 4);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := qask_util.add_a';
wwv_flow_imp.g_varchar2_table(123) := 'nswer_set (p_answer_set_code => ''CONSI'', p_answer_set_name => ''Consideration'');'||wwv_flow.LF||
'        qask_util.ad';
wwv_flow_imp.g_varchar2_table(124) := 'd_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Not Considering'', p_display_ord';
wwv_flow_imp.g_varchar2_table(125) := 'er => 1);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''C';
wwv_flow_imp.g_varchar2_table(126) := 'onsidering'', p_display_order => 2);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_s';
wwv_flow_imp.g_varchar2_table(127) := 'et_id, p_answer_text => ''Not Sure'', p_display_order => 3);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := qask_util.add_ans';
wwv_flow_imp.g_varchar2_table(128) := 'wer_set (p_answer_set_code => ''PRIOR'', p_answer_set_name => ''Priority'');'||wwv_flow.LF||
'        qask_util.add_aset_';
wwv_flow_imp.g_varchar2_table(129) := 'answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''1. Top Priority'', p_display_order => 2';
wwv_flow_imp.g_varchar2_table(130) := ');'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''0.5 Crit';
wwv_flow_imp.g_varchar2_table(131) := 'ical'', p_display_order => 1);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id,';
wwv_flow_imp.g_varchar2_table(132) := ' p_answer_text => ''2. Important'', p_display_order => 3);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer';
wwv_flow_imp.g_varchar2_table(133) := '_set_id => l_answer_set_id, p_answer_text => ''3. Nice to Have'', p_display_order => 4);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer';
wwv_flow_imp.g_varchar2_table(134) := '_set_id := qask_util.add_answer_set (p_answer_set_code => ''STABI'', p_answer_set_name => ''Stability'')';
wwv_flow_imp.g_varchar2_table(135) := ';'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Rock Soli';
wwv_flow_imp.g_varchar2_table(136) := 'd'', p_display_order => 1);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_';
wwv_flow_imp.g_varchar2_table(137) := 'answer_text => ''Solid'', p_display_order => 2);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id =>';
wwv_flow_imp.g_varchar2_table(138) := ' l_answer_set_id, p_answer_text => ''Adequate'', p_display_order => 3);'||wwv_flow.LF||
'        qask_util.add_aset_ans';
wwv_flow_imp.g_varchar2_table(139) := 'wer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Unstable'', p_display_order => 4);'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(140) := ' qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Most Unstable'', p_';
wwv_flow_imp.g_varchar2_table(141) := 'display_order => 5);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := qask_util.add_answer_set (p_answer_set_code => ''VERYS'',';
wwv_flow_imp.g_varchar2_table(142) := ' p_answer_set_name => ''Very Scale'');'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_';
wwv_flow_imp.g_varchar2_table(143) := 'set_id, p_answer_text => ''Very'', p_display_order => 1);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_';
wwv_flow_imp.g_varchar2_table(144) := 'set_id => l_answer_set_id, p_answer_text => ''Mostly'', p_display_order => 2);'||wwv_flow.LF||
'        qask_util.add_a';
wwv_flow_imp.g_varchar2_table(145) := 'set_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Somewhat'', p_display_order => 3);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(146) := '        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Not Very'', ';
wwv_flow_imp.g_varchar2_table(147) := 'p_display_order => 4);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answ';
wwv_flow_imp.g_varchar2_table(148) := 'er_text => ''Not at all'', p_display_order => 5);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := qask_util.add_answer_set (p_';
wwv_flow_imp.g_varchar2_table(149) := 'answer_set_code => ''USEFU'', p_answer_set_name => ''Usefullness'');'||wwv_flow.LF||
'        qask_util.add_aset_answer (';
wwv_flow_imp.g_varchar2_table(150) := 'p_answer_set_id => l_answer_set_id, p_answer_text => ''Most useful'', p_display_order => 1);'||wwv_flow.LF||
'        q';
wwv_flow_imp.g_varchar2_table(151) := 'ask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Very useful'', p_disp';
wwv_flow_imp.g_varchar2_table(152) := 'lay_order => 2);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_tex';
wwv_flow_imp.g_varchar2_table(153) := 't => ''Somewhat useful'', p_display_order => 3);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id =>';
wwv_flow_imp.g_varchar2_table(154) := ' l_answer_set_id, p_answer_text => ''Not very useful'', p_display_order => 4);'||wwv_flow.LF||
'        qask_util.add_a';
wwv_flow_imp.g_varchar2_table(155) := 'set_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Not useful at all'', p_display_orde';
wwv_flow_imp.g_varchar2_table(156) := 'r => 5);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := qask_util.add_answer_set (p_answer_set_code => ''SATIS'', p_answer_se';
wwv_flow_imp.g_varchar2_table(157) := 't_name => ''Satisfaction'');'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_';
wwv_flow_imp.g_varchar2_table(158) := 'answer_text => ''Very satisfied'', p_display_order => 1);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_';
wwv_flow_imp.g_varchar2_table(159) := 'set_id => l_answer_set_id, p_answer_text => ''Somewhat satisfied'', p_display_order => 2);'||wwv_flow.LF||
'        qas';
wwv_flow_imp.g_varchar2_table(160) := 'k_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Slightly satisfied'', p';
wwv_flow_imp.g_varchar2_table(161) := '_display_order => 3);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answe';
wwv_flow_imp.g_varchar2_table(162) := 'r_text => ''Neither satisfied nor dissatisfied'', p_display_order => 4);'||wwv_flow.LF||
'        qask_util.add_aset_an';
wwv_flow_imp.g_varchar2_table(163) := 'swer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Slightly dissatisfied'', p_display_order ';
wwv_flow_imp.g_varchar2_table(164) := '=> 5);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Some';
wwv_flow_imp.g_varchar2_table(165) := 'what dissatisfied'', p_display_order => 6);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_a';
wwv_flow_imp.g_varchar2_table(166) := 'nswer_set_id, p_answer_text => ''Very dissatisfied'', p_display_order => 7);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := q';
wwv_flow_imp.g_varchar2_table(167) := 'ask_util.add_answer_set (p_answer_set_code => ''HELPF'', p_answer_set_name => ''Helpfulness'');'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(168) := 'qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Extremely helpful'',';
wwv_flow_imp.g_varchar2_table(169) := ' p_display_order => 1);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_ans';
wwv_flow_imp.g_varchar2_table(170) := 'wer_text => ''Very helpful'', p_display_order => 2);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_i';
wwv_flow_imp.g_varchar2_table(171) := 'd => l_answer_set_id, p_answer_text => ''Somewhat helpful'', p_display_order => 3);'||wwv_flow.LF||
'        qask_util.';
wwv_flow_imp.g_varchar2_table(172) := 'add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Not so helpful'', p_display_or';
wwv_flow_imp.g_varchar2_table(173) := 'der => 4);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''';
wwv_flow_imp.g_varchar2_table(174) := 'Not at all helpful'', p_display_order => 5);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := qask_util.add_answer_set (p_answ';
wwv_flow_imp.g_varchar2_table(175) := 'er_set_code => ''STATU'', p_answer_set_name => ''Status'');'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_';
wwv_flow_imp.g_varchar2_table(176) := 'set_id => l_answer_set_id, p_answer_text => ''Not Considering'', p_display_order => 1);'||wwv_flow.LF||
'        qask_u';
wwv_flow_imp.g_varchar2_table(177) := 'til.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Considering'', p_display_o';
wwv_flow_imp.g_varchar2_table(178) := 'rder => 2);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ';
wwv_flow_imp.g_varchar2_table(179) := '''Work Initiated'', p_display_order => 3);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_ans';
wwv_flow_imp.g_varchar2_table(180) := 'wer_set_id, p_answer_text => ''Substantial Progress Made'', p_display_order => 4);'||wwv_flow.LF||
'        qask_util.a';
wwv_flow_imp.g_varchar2_table(181) := 'dd_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Fully Implemented'', p_display_';
wwv_flow_imp.g_varchar2_table(182) := 'order => 5);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text =>';
wwv_flow_imp.g_varchar2_table(183) := ' ''Unknown'', p_display_order => 6);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := qask_util.add_answer_set (p_answer_set_co';
wwv_flow_imp.g_varchar2_table(184) := 'de => ''WHENT'', p_answer_set_name => ''Action'');'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id =>';
wwv_flow_imp.g_varchar2_table(185) := ' l_answer_set_id, p_answer_text => ''Immediately'', p_display_order => 1);'||wwv_flow.LF||
'        qask_util.add_aset_';
wwv_flow_imp.g_varchar2_table(186) := 'answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Soon'', p_display_order => 2);'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(187) := 'qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''When time permits'',';
wwv_flow_imp.g_varchar2_table(188) := ' p_display_order => 3);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_ans';
wwv_flow_imp.g_varchar2_table(189) := 'wer_text => ''At some point'', p_display_order => 4);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_';
wwv_flow_imp.g_varchar2_table(190) := 'id => l_answer_set_id, p_answer_text => ''Never'', p_display_order => 5);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := qask';
wwv_flow_imp.g_varchar2_table(191) := '_util.add_answer_set (p_answer_set_code => ''RATIO'', p_answer_set_name => ''Rationale'');'||wwv_flow.LF||
'        qask_';
wwv_flow_imp.g_varchar2_table(192) := 'util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Cost'', p_display_order =';
wwv_flow_imp.g_varchar2_table(193) := '> 1);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Capab';
wwv_flow_imp.g_varchar2_table(194) := 'ility'', p_display_order => 2);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id';
wwv_flow_imp.g_varchar2_table(195) := ', p_answer_text => ''Performance'', p_display_order => 3);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer';
wwv_flow_imp.g_varchar2_table(196) := '_set_id => l_answer_set_id, p_answer_text => ''Security'', p_display_order => 4);'||wwv_flow.LF||
'        qask_util.ad';
wwv_flow_imp.g_varchar2_table(197) := 'd_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Availability'', p_display_order ';
wwv_flow_imp.g_varchar2_table(198) := '=> 5);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_set_id := qask_util.add_answer_set (p_answer_set_code => ''INDUS'', p_answer_set_';
wwv_flow_imp.g_varchar2_table(199) := 'name => ''Industry'');'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer';
wwv_flow_imp.g_varchar2_table(200) := '_text => ''Automotive'', p_display_order => 1);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => ';
wwv_flow_imp.g_varchar2_table(201) := 'l_answer_set_id, p_answer_text => ''Banking & Finance'', p_display_order => 2);'||wwv_flow.LF||
'        qask_util.add_';
wwv_flow_imp.g_varchar2_table(202) := 'aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Biotechnology'', p_display_order =';
wwv_flow_imp.g_varchar2_table(203) := '> 3);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Comme';
wwv_flow_imp.g_varchar2_table(204) := 'rce'', p_display_order => 4);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, ';
wwv_flow_imp.g_varchar2_table(205) := 'p_answer_text => ''Construction'', p_display_order => 5);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_';
wwv_flow_imp.g_varchar2_table(206) := 'set_id => l_answer_set_id, p_answer_text => ''Defense'', p_display_order => 6);'||wwv_flow.LF||
'        qask_util.add_';
wwv_flow_imp.g_varchar2_table(207) := 'aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Distribution'', p_display_order =>';
wwv_flow_imp.g_varchar2_table(208) := ' 7);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Educat';
wwv_flow_imp.g_varchar2_table(209) := 'ion'', p_display_order => 8);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, ';
wwv_flow_imp.g_varchar2_table(210) := 'p_answer_text => ''Energy'', p_display_order => 9);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id';
wwv_flow_imp.g_varchar2_table(211) := ' => l_answer_set_id, p_answer_text => ''Entertainment'', p_display_order => 10);'||wwv_flow.LF||
'        qask_util.add';
wwv_flow_imp.g_varchar2_table(212) := '_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Government'', p_display_order => ';
wwv_flow_imp.g_varchar2_table(213) := '11);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Health';
wwv_flow_imp.g_varchar2_table(214) := ''', p_display_order => 12);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_';
wwv_flow_imp.g_varchar2_table(215) := 'answer_text => ''Hospitality'', p_display_order => 13);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_se';
wwv_flow_imp.g_varchar2_table(216) := 't_id => l_answer_set_id, p_answer_text => ''Manufacturing'', p_display_order => 14);'||wwv_flow.LF||
'        qask_util';
wwv_flow_imp.g_varchar2_table(217) := '.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Marketing'', p_display_order ';
wwv_flow_imp.g_varchar2_table(218) := '=> 15);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Ret';
wwv_flow_imp.g_varchar2_table(219) := 'ail'', p_display_order => 16);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id,';
wwv_flow_imp.g_varchar2_table(220) := ' p_answer_text => ''Technology'', p_display_order => 17);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_';
wwv_flow_imp.g_varchar2_table(221) := 'set_id => l_answer_set_id, p_answer_text => ''Transportation'', p_display_order => 18);'||wwv_flow.LF||
''||wwv_flow.LF||
'    l_answer_';
wwv_flow_imp.g_varchar2_table(222) := 'set_id := qask_util.add_answer_set (p_answer_set_code => ''REGIO'', p_answer_set_name => ''Regions'');'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(223) := '       qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''Asia Pacific';
wwv_flow_imp.g_varchar2_table(224) := ''', p_display_order => 1);'||wwv_flow.LF||
'        qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_a';
wwv_flow_imp.g_varchar2_table(225) := 'nswer_text => ''Europe, Middleeast and Africa'', p_display_order => 2);'||wwv_flow.LF||
'        qask_util.add_aset_ans';
wwv_flow_imp.g_varchar2_table(226) := 'wer (p_answer_set_id => l_answer_set_id, p_answer_text => ''North America'', p_display_order => 3);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(227) := '      qask_util.add_aset_answer (p_answer_set_id => l_answer_set_id, p_answer_text => ''South America';
wwv_flow_imp.g_varchar2_table(228) := ''', p_display_order => 4);'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into qask_service_terms'||wwv_flow.LF||
'    (service_terms, current_yn)'||wwv_flow.LF||
'va';
wwv_flow_imp.g_varchar2_table(229) := 'lues'||wwv_flow.LF||
'    (''<p><b>This is an example Terms of Service</b><br/>'||wwv_flow.LF||
'    These terms can be updated on the ';
wwv_flow_imp.g_varchar2_table(230) := 'Admin page or they can be turned off.  To turn them off, simply edit the current Terms and then swit';
wwv_flow_imp.g_varchar2_table(231) := 'ch off Current.  Only one set of terms can be current but there do not need to be any.</p>'',''Y'');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(59295057063096628503)
,p_install_id=>wwv_flow_imp.id(49582154264788065099)
,p_name=>'create data'
,p_sequence=>50
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
