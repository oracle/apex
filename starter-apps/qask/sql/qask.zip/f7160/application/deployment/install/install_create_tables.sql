prompt --application/deployment/install/install_create_tables
begin
--   Manifest
--     INSTALL: INSTALL-create tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table qask_log ('||wwv_flow.LF||
'    id                             number '||wwv_flow.LF||
'                                 ';
wwv_flow_imp.g_varchar2_table(2) := '     default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(3) := '                  constraint qask_log_pk primary key,'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   page_id                         numbe';
wwv_flow_imp.g_varchar2_table(4) := 'r,'||wwv_flow.LF||
'   procedure_name                  varchar2(1000),'||wwv_flow.LF||
'   log_type                        varchar2(30';
wwv_flow_imp.g_varchar2_table(5) := ')    not null'||wwv_flow.LF||
'                                       constraint qask_log_type check (log_type in (''e';
wwv_flow_imp.g_varchar2_table(6) := 'rror'',''info'')),'||wwv_flow.LF||
'   error                           varchar2(4000)  not null,'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   arg1_name     ';
wwv_flow_imp.g_varchar2_table(7) := '                  varchar2(255),'||wwv_flow.LF||
'   arg1_val                        varchar2(4000),'||wwv_flow.LF||
'   arg2_name    ';
wwv_flow_imp.g_varchar2_table(8) := '                   varchar2(255),'||wwv_flow.LF||
'   arg2_val                        varchar2(4000),'||wwv_flow.LF||
'   arg3_name   ';
wwv_flow_imp.g_varchar2_table(9) := '                    varchar2(255),'||wwv_flow.LF||
'   arg3_val                        varchar2(4000),'||wwv_flow.LF||
'   arg4_name  ';
wwv_flow_imp.g_varchar2_table(10) := '                     varchar2(255),'||wwv_flow.LF||
'   arg4_val                        varchar2(4000),'||wwv_flow.LF||
'   arg5_name ';
wwv_flow_imp.g_varchar2_table(11) := '                      varchar2(255),'||wwv_flow.LF||
'   arg5_val                        varchar2(4000),'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   cre';
wwv_flow_imp.g_varchar2_table(12) := 'ated_on                      date  not null,'||wwv_flow.LF||
'   created_trunc                   date  not null,'||wwv_flow.LF||
'   c';
wwv_flow_imp.g_varchar2_table(13) := 'reated_by                      varchar2(255)  not null'||wwv_flow.LF||
');'||wwv_flow.LF||
'create index qask_log_i1 on qask_log (crea';
wwv_flow_imp.g_varchar2_table(14) := 'ted_trunc);'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table qask_service_terms ('||wwv_flow.LF||
'    id                             number '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(15) := '                             default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(16) := ''') '||wwv_flow.LF||
'                                      constraint qask_service_terms_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    s';
wwv_flow_imp.g_varchar2_table(17) := 'ervice_terms                  clob,'||wwv_flow.LF||
'    current_yn                     varchar2(1)   not null'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(18) := '                                 constraint qask_service_terms_current check (current_yn in (''Y'',''N''';
wwv_flow_imp.g_varchar2_table(19) := ')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    row_version                    integer       not null,'||wwv_flow.LF||
'    created_on                ';
wwv_flow_imp.g_varchar2_table(20) := '     date          not null,'||wwv_flow.LF||
'    created_by                     varchar2(255) not null,'||wwv_flow.LF||
'    updated_';
wwv_flow_imp.g_varchar2_table(21) := 'on                     date          not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255) not ';
wwv_flow_imp.g_varchar2_table(22) := 'null'||wwv_flow.LF||
');'||wwv_flow.LF||
'-- ensures only one current_yn is set to Y'||wwv_flow.LF||
'create unique index qask_service_terms_one_curren';
wwv_flow_imp.g_varchar2_table(23) := 't on qask_service_terms (nullif(current_yn,''N''));'||wwv_flow.LF||
''||wwv_flow.LF||
'create table qask_service_term_accepts ('||wwv_flow.LF||
'    id  ';
wwv_flow_imp.g_varchar2_table(24) := '                           number '||wwv_flow.LF||
'                                      default on null to_number(s';
wwv_flow_imp.g_varchar2_table(25) := 'ys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                      constraint qas';
wwv_flow_imp.g_varchar2_table(26) := 'k_service_term_accepts_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    email                          varchar2(255) not n';
wwv_flow_imp.g_varchar2_table(27) := 'ull,'||wwv_flow.LF||
'    accepted_terms_id              number        not null,  -- not fk to allow old terms to be ';
wwv_flow_imp.g_varchar2_table(28) := 'removed without setting to null'||wwv_flow.LF||
'    accepted_on                    date          not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create';
wwv_flow_imp.g_varchar2_table(29) := ' index qask_service_term_accepts_i1 on qask_service_term_accepts (email);'||wwv_flow.LF||
''||wwv_flow.LF||
'-- restricts who can be g';
wwv_flow_imp.g_varchar2_table(30) := 'iven access to app (as contributors or administrators'||wwv_flow.LF||
'create table qask_restricted_email_domains ('||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(31) := '   id                             number '||wwv_flow.LF||
'                                      default on null to_n';
wwv_flow_imp.g_varchar2_table(32) := 'umber(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                      constra';
wwv_flow_imp.g_varchar2_table(33) := 'int qask_resticted_email_domains_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    email_domain                   varchar2(';
wwv_flow_imp.g_varchar2_table(34) := '255) not null,'||wwv_flow.LF||
'    comments                       varchar2(4000),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    row_version            ';
wwv_flow_imp.g_varchar2_table(35) := '        integer       not null,'||wwv_flow.LF||
'    created_on                     date          not null,'||wwv_flow.LF||
'    creat';
wwv_flow_imp.g_varchar2_table(36) := 'ed_by                     varchar2(255) not null,'||wwv_flow.LF||
'    updated_on                     date          n';
wwv_flow_imp.g_varchar2_table(37) := 'ot null,'||wwv_flow.LF||
'    updated_by                     varchar2(255) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create table qask_settings ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(38) := '    id                             number '||wwv_flow.LF||
'                                      default on null to_';
wwv_flow_imp.g_varchar2_table(39) := 'number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                      constr';
wwv_flow_imp.g_varchar2_table(40) := 'aint qask_settings_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    display_order                  number,'||wwv_flow.LF||
'    name       ';
wwv_flow_imp.g_varchar2_table(41) := '                    varchar2(255)  not null'||wwv_flow.LF||
'                                      constraint qask_se';
wwv_flow_imp.g_varchar2_table(42) := 'ttings_uk unique,'||wwv_flow.LF||
'    description                    varchar2(4000) not null,'||wwv_flow.LF||
'    value             ';
wwv_flow_imp.g_varchar2_table(43) := '             varchar2(4000),'||wwv_flow.LF||
'    is_numeric_yn                  varchar2(1)    not null    -- used i';
wwv_flow_imp.g_varchar2_table(44) := 'n validation'||wwv_flow.LF||
'                                      constraint qask_settings_is_numeric_cc'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(45) := '                            check (is_numeric_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    is_yn                          v';
wwv_flow_imp.g_varchar2_table(46) := 'archar2(1)    not null    -- used in validation'||wwv_flow.LF||
'                                      constraint qas';
wwv_flow_imp.g_varchar2_table(47) := 'k_settings_is_yn_cc'||wwv_flow.LF||
'                                      check (is_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    row';
wwv_flow_imp.g_varchar2_table(48) := '_version                    integer         not null,'||wwv_flow.LF||
'    created_on                     date       ';
wwv_flow_imp.g_varchar2_table(49) := '     not null,'||wwv_flow.LF||
'    created_by                     varchar2(255)   not null,'||wwv_flow.LF||
'    updated_on          ';
wwv_flow_imp.g_varchar2_table(50) := '           date            not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255)   not null'||wwv_flow.LF||
');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(51) := ''||wwv_flow.LF||
'create table qask_account_requests ('||wwv_flow.LF||
'    id                             number '||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(52) := '                   default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(53) := '                                constraint qask_account_requests_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    email   ';
wwv_flow_imp.g_varchar2_table(54) := '                       varchar2(255) not null,'||wwv_flow.LF||
'    justification                  varchar2(4000),'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(55) := '  accepted_terms_id              number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    user_agent                     varchar2(4000),'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(56) := '   x_forwarded_for                varchar2(4000),'||wwv_flow.LF||
'    remote_addr                    varchar2(4000),';
wwv_flow_imp.g_varchar2_table(57) := ''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    request_status                 varchar2(30)  not null'||wwv_flow.LF||
'                                  ';
wwv_flow_imp.g_varchar2_table(58) := '    constraint qask_account_requests_status_cc'||wwv_flow.LF||
'                                      check (request_';
wwv_flow_imp.g_varchar2_table(59) := 'status in (''REQUESTED'',''APPROVED'',''DECLINED'')),'||wwv_flow.LF||
'    status_reason                  varchar2(4000),'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(60) := '    --'||wwv_flow.LF||
'    row_version                    integer       not null,'||wwv_flow.LF||
'    created_on                    ';
wwv_flow_imp.g_varchar2_table(61) := ' date          not null,'||wwv_flow.LF||
'    created_by                     varchar2(255) not null,'||wwv_flow.LF||
'    updated_on  ';
wwv_flow_imp.g_varchar2_table(62) := '                   date          not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255) not null';
wwv_flow_imp.g_varchar2_table(63) := ''||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index qask_account_requests_i1 on qask_account_requests (email);'||wwv_flow.LF||
''||wwv_flow.LF||
'create table qask_veri';
wwv_flow_imp.g_varchar2_table(64) := 'fy_tokens ('||wwv_flow.LF||
'    id                             number '||wwv_flow.LF||
'                                      default';
wwv_flow_imp.g_varchar2_table(65) := ' on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                ';
wwv_flow_imp.g_varchar2_table(66) := '      constraint qask_ver_token_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    username                       varchar2(2';
wwv_flow_imp.g_varchar2_table(67) := '55) not null,'||wwv_flow.LF||
'    token                          varchar2(30)  not null,'||wwv_flow.LF||
'    verified_yn            ';
wwv_flow_imp.g_varchar2_table(68) := '        varchar2(1)   default ''N'' not null  '||wwv_flow.LF||
'                                      constraint qask_v';
wwv_flow_imp.g_varchar2_table(69) := 'er_token_verified_cc'||wwv_flow.LF||
'                                      check (verified_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    exp';
wwv_flow_imp.g_varchar2_table(70) := 'ired_yn                     varchar2(1)   default ''N'' not null  '||wwv_flow.LF||
'                                   ';
wwv_flow_imp.g_varchar2_table(71) := '   constraint qask_ver_token_expired_cc'||wwv_flow.LF||
'                                      check (expired_yn in (';
wwv_flow_imp.g_varchar2_table(72) := '''Y'',''N'')),'||wwv_flow.LF||
'    expire_on                      date  not null,'||wwv_flow.LF||
'    accessed_on                    dat';
wwv_flow_imp.g_varchar2_table(73) := 'e,'||wwv_flow.LF||
'    access_attempts                number  default 0  not null,'||wwv_flow.LF||
'    reset_on                     ';
wwv_flow_imp.g_varchar2_table(74) := '  date,'||wwv_flow.LF||
'    reset_by                       varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    row_version                    ';
wwv_flow_imp.g_varchar2_table(75) := 'integer       not null,'||wwv_flow.LF||
'    created_on                     date          not null,'||wwv_flow.LF||
'    created_by   ';
wwv_flow_imp.g_varchar2_table(76) := '                  varchar2(255) not null,'||wwv_flow.LF||
'    updated_on                     date          not null,';
wwv_flow_imp.g_varchar2_table(77) := ''||wwv_flow.LF||
'    updated_by                     varchar2(255) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index qask_verify_tokens_i1 on';
wwv_flow_imp.g_varchar2_table(78) := ' qask_verify_tokens (username, token);'||wwv_flow.LF||
''||wwv_flow.LF||
'-- ACCOUNTS HANDLED BY APEX ACL'||wwv_flow.LF||
''||wwv_flow.LF||
'create table qask_answer_se';
wwv_flow_imp.g_varchar2_table(79) := 'ts ('||wwv_flow.LF||
'    id                             number '||wwv_flow.LF||
'                                      default on nul';
wwv_flow_imp.g_varchar2_table(80) := 'l to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                      c';
wwv_flow_imp.g_varchar2_table(81) := 'onstraint qask_answer_sets_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    answer_set_code                varchar2(30)   ';
wwv_flow_imp.g_varchar2_table(82) := 'not null,'||wwv_flow.LF||
'    answer_set_name                varchar2(100)  not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    row_version        ';
wwv_flow_imp.g_varchar2_table(83) := '            integer       not null,'||wwv_flow.LF||
'    created_on                     date          not null,'||wwv_flow.LF||
'    c';
wwv_flow_imp.g_varchar2_table(84) := 'reated_by                     varchar2(255) not null,'||wwv_flow.LF||
'    updated_on                     date       ';
wwv_flow_imp.g_varchar2_table(85) := '   not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique index qask_';
wwv_flow_imp.g_varchar2_table(86) := 'answer_sets_i1 on qask_answer_sets (answer_set_code);'||wwv_flow.LF||
'create unique index qask_answer_sets_i2 on qas';
wwv_flow_imp.g_varchar2_table(87) := 'k_answer_sets (answer_set_name);'||wwv_flow.LF||
''||wwv_flow.LF||
'create table qask_aset_answers ('||wwv_flow.LF||
'    id                           ';
wwv_flow_imp.g_varchar2_table(88) := '  number '||wwv_flow.LF||
'                                      default on null to_number(sys_guid(), ''XXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(89) := 'XXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                      constraint qask_aset_answers_pk primary';
wwv_flow_imp.g_varchar2_table(90) := ' key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    answer_set_id                  number  not null'||wwv_flow.LF||
'                                   ';
wwv_flow_imp.g_varchar2_table(91) := '   constraint aset_answers_aset_fk'||wwv_flow.LF||
'                                      references qask_answer_sets';
wwv_flow_imp.g_varchar2_table(92) := ' on delete cascade,'||wwv_flow.LF||
'    answer_text                    varchar2(255) not null,'||wwv_flow.LF||
'    display_order    ';
wwv_flow_imp.g_varchar2_table(93) := '              number        not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    row_version                    integer       not nu';
wwv_flow_imp.g_varchar2_table(94) := 'll,'||wwv_flow.LF||
'    created_on                     date          not null,'||wwv_flow.LF||
'    created_by                     va';
wwv_flow_imp.g_varchar2_table(95) := 'rchar2(255) not null,'||wwv_flow.LF||
'    updated_on                     date          not null,'||wwv_flow.LF||
'    updated_by     ';
wwv_flow_imp.g_varchar2_table(96) := '                varchar2(255) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index qask_aset_answers_i1 on qask_aset_answers (a';
wwv_flow_imp.g_varchar2_table(97) := 'nswer_set_id);'||wwv_flow.LF||
'create unique index qask_aset_answers_uk on qask_aset_answers (answer_set_id, answer_';
wwv_flow_imp.g_varchar2_table(98) := 'text);'||wwv_flow.LF||
''||wwv_flow.LF||
'---------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'create table qask_sessions ('||wwv_flow.LF||
'    id                             numbe';
wwv_flow_imp.g_varchar2_table(99) := 'r default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(100) := '               constraint qask_sessions_pk primary key,'||wwv_flow.LF||
'    owner                          varchar2(';
wwv_flow_imp.g_varchar2_table(101) := '255) not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    session_name                   varchar2(255)  not null,'||wwv_flow.LF||
'    purpose       ';
wwv_flow_imp.g_varchar2_table(102) := '                 varchar2(4000),'||wwv_flow.LF||
'    visibility                     varchar2(30)  not null'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(103) := '                             constraint qask_sessions_vis_cc'||wwv_flow.LF||
'                                      c';
wwv_flow_imp.g_varchar2_table(104) := 'heck (visibility in (''PRIVATE'',''SHARED'')), -- CURRENTLY NOT USED'||wwv_flow.LF||
'    session_code                   ';
wwv_flow_imp.g_varchar2_table(105) := 'varchar2(30)    not null'||wwv_flow.LF||
'                                      constraint qask_sessions_uk unique,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(106) := '   resp_name_required_yn          varchar2(1)  not null'||wwv_flow.LF||
'                                      constr';
wwv_flow_imp.g_varchar2_table(107) := 'aint qask_sessions_resp_name_req_cc'||wwv_flow.LF||
'                                      check (resp_name_required_';
wwv_flow_imp.g_varchar2_table(108) := 'yn in (''Y'',''N'')),'||wwv_flow.LF||
'    resp_email_required_yn         varchar2(1)  not null'||wwv_flow.LF||
'                         ';
wwv_flow_imp.g_varchar2_table(109) := '             constraint qask_sessions_resp_email_req_cc'||wwv_flow.LF||
'                                      check ';
wwv_flow_imp.g_varchar2_table(110) := '(resp_email_required_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    session_status                 varchar2(30)  not n';
wwv_flow_imp.g_varchar2_table(111) := 'ull'||wwv_flow.LF||
'                                      constraint qask_sessions_status_cc'||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(112) := '               check (session_status in (''STAGED'',''OPEN'',''CLOSED'')),'||wwv_flow.LF||
'    started_on                 ';
wwv_flow_imp.g_varchar2_table(113) := '    date,'||wwv_flow.LF||
'    started_by                     varchar2(255),  -- CURRENTLY NOT USED'||wwv_flow.LF||
'    closed_on    ';
wwv_flow_imp.g_varchar2_table(114) := '                  date,'||wwv_flow.LF||
'    length_minutes                 number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    row_version           ';
wwv_flow_imp.g_varchar2_table(115) := '         integer       not null,'||wwv_flow.LF||
'    created_on                     date          not null,'||wwv_flow.LF||
'    crea';
wwv_flow_imp.g_varchar2_table(116) := 'ted_by                     varchar2(255) not null,'||wwv_flow.LF||
'    updated_on                     date          ';
wwv_flow_imp.g_varchar2_table(117) := 'not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index qask_sessions_i';
wwv_flow_imp.g_varchar2_table(118) := '1 on qask_sessions (owner);'||wwv_flow.LF||
'create index qask_sessions_i2 on qask_sessions (visibility);'||wwv_flow.LF||
'create inde';
wwv_flow_imp.g_varchar2_table(119) := 'x qask_sessions_i3 on qask_sessions (session_status);'||wwv_flow.LF||
''||wwv_flow.LF||
'create table qask_session_questions ('||wwv_flow.LF||
'    id ';
wwv_flow_imp.g_varchar2_table(120) := '                            number default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(121) := 'XXXXXX'') '||wwv_flow.LF||
'                                      constraint qask_session_questions_pk primary key,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(122) := '  session_id                     number  not null'||wwv_flow.LF||
'                                      constraint q';
wwv_flow_imp.g_varchar2_table(123) := 'ask_session_questions_sess_fk'||wwv_flow.LF||
'                                      references qask_sessions on dele';
wwv_flow_imp.g_varchar2_table(124) := 'te cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    question                       varchar2(255)  not null,'||wwv_flow.LF||
'    question_number  ';
wwv_flow_imp.g_varchar2_table(125) := '              integer not null,'||wwv_flow.LF||
'    answer_set_id                  number'||wwv_flow.LF||
'                          ';
wwv_flow_imp.g_varchar2_table(126) := '            constraint qask_session_questions_aset_fk'||wwv_flow.LF||
'                                      referenc';
wwv_flow_imp.g_varchar2_table(127) := 'es qask_answer_sets on delete set null,'||wwv_flow.LF||
'    answer_type                    varchar2(10) not null'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(128) := '                                   constraint qask_session_questions_atype_cc'||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(129) := '                check (answer_type in (''SINGLE'',''MULTI'',''FREEFORM'')),'||wwv_flow.LF||
'    ask_for_comments_yn       ';
wwv_flow_imp.g_varchar2_table(130) := '     varchar2(1)  not null'||wwv_flow.LF||
'                                      constraint qask_session_questions_c';
wwv_flow_imp.g_varchar2_table(131) := 'omments_cc'||wwv_flow.LF||
'                                      check (ask_for_comments_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    quest';
wwv_flow_imp.g_varchar2_table(132) := 'ion_status                varchar2(30) constraint qask_session_questions_status_cc'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(133) := '                     check (question_status in (''WORKING'',''STAGED'',''OPEN'',''CLOSED'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    que';
wwv_flow_imp.g_varchar2_table(134) := 'stion_explanation           clob,'||wwv_flow.LF||
'    question_file                  blob,'||wwv_flow.LF||
'    question_filename    ';
wwv_flow_imp.g_varchar2_table(135) := '          varchar2(512),'||wwv_flow.LF||
'    question_file_mimetype         varchar2(512),'||wwv_flow.LF||
'    question_file_last_up';
wwv_flow_imp.g_varchar2_table(136) := 'dated_on  date,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    started_on                     date,'||wwv_flow.LF||
'    closed_on                      d';
wwv_flow_imp.g_varchar2_table(137) := 'ate,'||wwv_flow.LF||
'    end_date                       date,'||wwv_flow.LF||
'    length_seconds                 number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(138) := 'row_version                    integer       not null,'||wwv_flow.LF||
'    created_on                     date      ';
wwv_flow_imp.g_varchar2_table(139) := '    not null,'||wwv_flow.LF||
'    created_by                     varchar2(255) not null,'||wwv_flow.LF||
'    updated_on             ';
wwv_flow_imp.g_varchar2_table(140) := '        date          not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create';
wwv_flow_imp.g_varchar2_table(141) := ' index qask_session_questions_i1 on qask_session_questions (session_id);'||wwv_flow.LF||
'create index qask_session_q';
wwv_flow_imp.g_varchar2_table(142) := 'uestions_i2 on qask_session_questions (answer_set_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create table qask_sess_question_answers ('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(143) := '  id                             number '||wwv_flow.LF||
'                                      default on null to_nu';
wwv_flow_imp.g_varchar2_table(144) := 'mber(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                      constrai';
wwv_flow_imp.g_varchar2_table(145) := 'nt qask_sess_qa_pk primary key,'||wwv_flow.LF||
'    question_id                    number  not null'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(146) := '                      constraint qask_sess_qa_quest_fk'||wwv_flow.LF||
'                                      referen';
wwv_flow_imp.g_varchar2_table(147) := 'ces qask_session_questions on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    answer_number                  number      ';
wwv_flow_imp.g_varchar2_table(148) := '   not null,'||wwv_flow.LF||
'    answer_text                    varchar2(255)  not null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    row_version     ';
wwv_flow_imp.g_varchar2_table(149) := '               integer       not null,'||wwv_flow.LF||
'    created_on                     date          not null,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(150) := '  created_by                     varchar2(255) not null,'||wwv_flow.LF||
'    updated_on                     date    ';
wwv_flow_imp.g_varchar2_table(151) := '      not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index qask_sess';
wwv_flow_imp.g_varchar2_table(152) := '_question_answers_i1 on qask_sess_question_answers (question_id);'||wwv_flow.LF||
'alter table qask_sess_question_ans';
wwv_flow_imp.g_varchar2_table(153) := 'wers add constraint qask_sess_question_answers_uk unique (question_id,answer_text);'||wwv_flow.LF||
'----------------';
wwv_flow_imp.g_varchar2_table(154) := '--'||wwv_flow.LF||
''||wwv_flow.LF||
'create table qask_responses ('||wwv_flow.LF||
'    id                             number '||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(155) := '               default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(156) := '                            constraint qask_responses_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    session_id         ';
wwv_flow_imp.g_varchar2_table(157) := '            number'||wwv_flow.LF||
'                                      constraint qask_response_session_fk'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(158) := '                               references qask_sessions on delete set null,'||wwv_flow.LF||
'    apex_session        ';
wwv_flow_imp.g_varchar2_table(159) := '           number,'||wwv_flow.LF||
'    name                           varchar2(255),'||wwv_flow.LF||
'    email                      ';
wwv_flow_imp.g_varchar2_table(160) := '    varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    user_agent                     varchar2(4000),'||wwv_flow.LF||
'    x_forwarded_for    ';
wwv_flow_imp.g_varchar2_table(161) := '            varchar2(4000),'||wwv_flow.LF||
'    remote_addr                    varchar2(4000),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    row_versio';
wwv_flow_imp.g_varchar2_table(162) := 'n                    integer       not null,'||wwv_flow.LF||
'    created_on                     date          not nu';
wwv_flow_imp.g_varchar2_table(163) := 'll,'||wwv_flow.LF||
'    created_by                     varchar2(255) not null,'||wwv_flow.LF||
'    updated_on                     da';
wwv_flow_imp.g_varchar2_table(164) := 'te          not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create unique in';
wwv_flow_imp.g_varchar2_table(165) := 'dex qask_responses_i1 on qask_responses (session_id, apex_session);'||wwv_flow.LF||
''||wwv_flow.LF||
'create table qask_response_answ';
wwv_flow_imp.g_varchar2_table(166) := 'ers ('||wwv_flow.LF||
'    id                             number '||wwv_flow.LF||
'                                      default on nu';
wwv_flow_imp.g_varchar2_table(167) := 'll to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                      ';
wwv_flow_imp.g_varchar2_table(168) := 'constraint qask_response_answers_pk primary key,'||wwv_flow.LF||
'    response_id                    number  not null';
wwv_flow_imp.g_varchar2_table(169) := ''||wwv_flow.LF||
'                                      constraint qask_response_answers_resp_fk'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(170) := '                  references qask_responses on delete cascade,'||wwv_flow.LF||
'    question_id                    nu';
wwv_flow_imp.g_varchar2_table(171) := 'mber  not null'||wwv_flow.LF||
'                                      constraint qask_response_answers_q_fk'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(172) := '                             references qask_session_questions on delete cascade,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    answer_';
wwv_flow_imp.g_varchar2_table(173) := 'id                      number'||wwv_flow.LF||
'                                      constraint qask_response_answer';
wwv_flow_imp.g_varchar2_table(174) := 's_a_fk'||wwv_flow.LF||
'                                      references qask_sess_question_answers on delete set nul';
wwv_flow_imp.g_varchar2_table(175) := 'l,'||wwv_flow.LF||
'    answer_text                    varchar2(4000),'||wwv_flow.LF||
'    comment_text                   varchar2(40';
wwv_flow_imp.g_varchar2_table(176) := '00),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    row_version                    integer       not null,'||wwv_flow.LF||
'    created_on               ';
wwv_flow_imp.g_varchar2_table(177) := '      date          not null,'||wwv_flow.LF||
'    created_by                     varchar2(255) not null,'||wwv_flow.LF||
'    updated';
wwv_flow_imp.g_varchar2_table(178) := '_on                     date          not null,'||wwv_flow.LF||
'    updated_by                     varchar2(255) not';
wwv_flow_imp.g_varchar2_table(179) := ' null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index qask_response_answers_i1 on qask_response_answers (response_id);'||wwv_flow.LF||
'create index';
wwv_flow_imp.g_varchar2_table(180) := ' qask_response_answers_i2 on qask_response_answers (question_id);'||wwv_flow.LF||
'create index qask_response_answers';
wwv_flow_imp.g_varchar2_table(181) := '_i3 on qask_response_answers (answer_id);'||wwv_flow.LF||
'create unique index qask_response_answers_i4 on qask_respo';
wwv_flow_imp.g_varchar2_table(182) := 'nse_answers (response_id, question_id, answer_id);';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(59294821579267308335)
,p_install_id=>wwv_flow_imp.id(49582154264788065099)
,p_name=>'create tables'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
