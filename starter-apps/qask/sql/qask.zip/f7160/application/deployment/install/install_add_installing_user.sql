prompt --application/deployment/install/install_add_installing_user
begin
--   Manifest
--     INSTALL: INSTALL-add installing user
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'declare'||wwv_flow.LF||
'    l_app_user  varchar2(255) := apex_custom_auth.get_username;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for u in ('||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(2) := ' select case when email is null and regexp_like(l_app_user,''[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}'')';
wwv_flow_imp.g_varchar2_table(3) := ''||wwv_flow.LF||
'                    then l_app_user'||wwv_flow.LF||
'                    else email'||wwv_flow.LF||
'                    end email'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(4) := '        from apex_workspace_apex_users'||wwv_flow.LF||
'         where user_name = l_app_user'||wwv_flow.LF||
'    ) loop'||wwv_flow.LF||
'      if u.e';
wwv_flow_imp.g_varchar2_table(5) := 'mail is not null then'||wwv_flow.LF||
'        for a in ('||wwv_flow.LF||
'            select application_id'||wwv_flow.LF||
'              from apex_a';
wwv_flow_imp.g_varchar2_table(6) := 'pplications'||wwv_flow.LF||
'             where application_name = ''qAsk'''||wwv_flow.LF||
'             order by last_updated_on desc'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(7) := '        ) loop'||wwv_flow.LF||
'            for r in ('||wwv_flow.LF||
'                select role_id'||wwv_flow.LF||
'                  from apex_app';
wwv_flow_imp.g_varchar2_table(8) := 'l_acl_roles'||wwv_flow.LF||
'                 where application_id = a.application_id '||wwv_flow.LF||
'                   and role_st';
wwv_flow_imp.g_varchar2_table(9) := 'atic_id = ''ADMINISTRATOR'''||wwv_flow.LF||
'            ) loop'||wwv_flow.LF||
'                qask_util.add_user ('||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(10) := '  p_username      => u.email,'||wwv_flow.LF||
'                    p_role_id       => r.role_id,'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(11) := 'p_send_email_yn => ''N'','||wwv_flow.LF||
'                    p_app_id        => a.application_id );'||wwv_flow.LF||
'                e';
wwv_flow_imp.g_varchar2_table(12) := 'xit;'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'            exit;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(59296799819025678245)
,p_install_id=>wwv_flow_imp.id(49582154264788065099)
,p_name=>'add installing user'
,p_sequence=>70
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
