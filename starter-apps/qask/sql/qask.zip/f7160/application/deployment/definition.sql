prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7160
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'drop table qask_log cascade constraints;'||wwv_flow.LF||
'drop table qask_service_terms cascade constraints;'||wwv_flow.LF||
'drop tab';
wwv_flow_imp.g_varchar2_table(2) := 'le qask_service_term_accepts cascade constraints;'||wwv_flow.LF||
'drop table qask_restricted_email_domains cascade c';
wwv_flow_imp.g_varchar2_table(3) := 'onstraints;'||wwv_flow.LF||
'drop table qask_settings cascade constraints;'||wwv_flow.LF||
'drop table qask_account_requests cascade c';
wwv_flow_imp.g_varchar2_table(4) := 'onstraints;'||wwv_flow.LF||
'drop table qask_verify_tokens cascade constraints;'||wwv_flow.LF||
'drop table qask_answer_sets cascade c';
wwv_flow_imp.g_varchar2_table(5) := 'onstraints;'||wwv_flow.LF||
'drop table qask_aset_answers cascade constraints;'||wwv_flow.LF||
'drop table qask_sessions cascade const';
wwv_flow_imp.g_varchar2_table(6) := 'raints;'||wwv_flow.LF||
'drop table qask_session_questions cascade constraints;'||wwv_flow.LF||
'drop table qask_sess_question_answers';
wwv_flow_imp.g_varchar2_table(7) := ' cascade constraints;'||wwv_flow.LF||
'drop table qask_responses cascade constraints;'||wwv_flow.LF||
'drop table qask_response_answer';
wwv_flow_imp.g_varchar2_table(8) := 's cascade constraints;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop package qask_util;'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   dbms_scheduler.drop_job (job_name => ''QASK';
wwv_flow_imp.g_varchar2_table(9) := '_CLOSE_OLD_SESSIONS'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(49582154264788065099)
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER'
,p_required_names_available=>'QASK_SERVICE_TERMS:QASK_SERVICE_TERM_ACCEPTS:QASK_RESTRICTED_EMAIL_DOMAINS:QASK_SETTINGS:QASK_ACCOUNT_REQUESTS:QASK_VERIFY_TOKENS:QASK_ANSWER_SETS:QASK_ASET_ANSWERS:QASK_SESSIONS:QASK_SESSION_QUESTIONS:QASK_SESS_QUESTION_ANSWERS:QASK_RESPONSES:QASK_R'
||'ESPONSE_ANSWERS:QASK_UTIL:QASK_CLOSE_OLD_SESSIONS:QASK_LOG'
);
wwv_flow_imp.component_end;
end;
/
