prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'About'
,p_alias=>'ABOUT'
,p_step_title=>'About qAsk'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(48319318670818829870)
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>'All application help text can be accessed from this page. The links in the "Documentation" region give a much more in-depth explanation of the application''s features and functionality.'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(98147837798696158324)
,p_plug_name=>'About qAsk'
,p_static_id=>'about-qask'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h1:t-ContentBlock--lightBG'
,p_plug_template=>2323592004483952560
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>qAsk is used to run a Q&A session.  It can be used during a lecture or class to gauge understanding of material, interests of a crowd or solicit feedback.  No account is needed for participation - a QR code is scanned to join a Session.</p>',
'',
'<p><b>Who can host qAsk sessions and how do they login?</b><br/>',
'To Host a qAsk Session, you must be a named user of the system.  If Account Requests are allowed, there will be a prompt on the home page (Host a Q&A Session) to request access.  If you are already a user, you click Sign In and provide your email add'
||'ress and a verification code will be sent to you.  Once you enter that code, you will then have access to see your existing sessions and create new ones.</p>',
'<p>qAsk Sessions can be created in real-time or they can be created ahead of time and then the questions can be progressed through.  You can create a session from scratch or copy an existing session.  Questions can be single choice, multiple choice o'
||'r freeform text.</p>',
'',
'<p><b>Who can participate as a user of qAsk session?</b><br/>',
'To participate in a qAsk Session, you scan the QR code displayed with your phone camera and follow it to the qAsk home page where the Session Code will be pre-populated.  Click the Join button and if there is currently an open question, it will be pr'
||'esented to you.  Alternatively, you can navigate to qAsk and enter the session code of the session to join.</p>',
'',
'<p><b>Can some users respond at a later time?</b><br/>',
'Questions are only available for end users until the Host closes the question or closes the session.  If a session is left open for too long, it will automatically be closed (controlled by a setting under Admnistration).</p>',
'',
'<p><b>How can I share the results of qAsk session?</b><br/>',
'If a session is shared, any Host can view the results of the session.</p>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
