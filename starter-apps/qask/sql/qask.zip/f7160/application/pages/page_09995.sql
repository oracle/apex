prompt --application/pages/page_09995
begin
--   Manifest
--     PAGE: 09995
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>9995
,p_name=>'Accept Service Terms'
,p_alias=>'ACCEPT-SERVICE-TERMS'
,p_step_title=>'qAsk Accept Service Terms'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2102634289808461002
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(48319320446482829871)
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(103208992402593077899)
,p_plug_name=>'Accept Service Terms'
,p_static_id=>'accept-service-terms'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2675634334296186762
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56780096423721645329)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(103208992402593077899)
,p_button_name=>'ACCEPT'
,p_static_id=>'accept'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Accept Terms'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(56780102034951645334)
,p_branch_name=>'Go To Sessions'
,p_branch_action=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:9995::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(56780096423721645329)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(56783740054788105674)
,p_name=>'P9995_TERMS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(103208992402593077899)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Terms of Use'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select service_terms',
'  from qask_service_terms',
' where id = :P9995_TERMS_ID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P9995_TERMS_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--normalDisplay'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML',
  'send_on_page_submit', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65816818702252254080)
,p_name=>'P9995_TERMS_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(103208992402593077899)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54421162911513155621)
,p_computation_sequence=>10
,p_computation_item=>'P9995_TERMS_ID'
,p_static_id=>'p9995-terms-id'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>'return qask_util.get_latest_service_terms_id;'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(56780099562070645332)
,p_name=>'Handle Submit on Enter'
,p_static_id=>'handle-submit-on-enter'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9995_USERNAME'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.keyCode === 13'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keypress'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56780100620812645333)
,p_event_id=>wwv_flow_imp.id(56780099562070645332)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_static_id=>'native-cancel-event'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(56780100096293645333)
,p_event_id=>wwv_flow_imp.id(56780099562070645332)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-submit-page'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'request_button_name', 'SEND_TOKEN',
  'show_processing', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56780097990230645331)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'accept_terms'
,p_static_id=>'accept-terms'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.log_service_terms_accept (',
'    p_email             => :APP_USER,',
'    p_accepted_terms_id => :P9995_TERMS_ID );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(56780096423721645329)
,p_process_when=>'P9995_TERMS_ID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_process_success_message=>'Service Terms Accepted.'
,p_internal_uid=>54889672743796248031
);
wwv_flow_imp.component_end;
end;
/
