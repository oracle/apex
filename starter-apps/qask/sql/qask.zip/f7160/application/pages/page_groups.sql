prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7160
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(48319321640535829872)
,p_group_name=>'Administration'
,p_static_id=>'administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(59051128140322479411)
,p_group_name=>'Session Management'
,p_static_id=>'session-management'
);
wwv_flow_imp.component_end;
end;
/
