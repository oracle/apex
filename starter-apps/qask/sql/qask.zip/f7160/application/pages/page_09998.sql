prompt --application/pages/page_09998
begin
--   Manifest
--     PAGE: 09998
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>9998
,p_name=>'User Verification'
,p_alias=>'VERIFICATION'
,p_step_title=>'qAsk Verification'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.app-Form-fieldContainer--verificationCode input.apex-item-text { height: 72px; font-size: 40px; line-height: 72px; }',
'.apex-item-text.apex-page-item-error:focus { border-color: #ff6448 !important; }',
'#P1_VERIFICATION_CODE_CONTAINER .t-Form-error { color: #ff6448 !important; font-weight: bold; }',
'.t-Alert--wizard .t-Alert-title { font-weight: 700; font-size: 32px; }',
'.t-Alert--wizard .t-Alert-body { text-align: center; margin-left: auto; margin-right: auto; }'))
,p_step_template=>2102634289808461002
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13918878503160017707)
,p_plug_name=>'account locked'
,p_static_id=>'account-locked'
,p_parent_plug_id=>wwv_flow_imp.id(6370395366499150603)
,p_icon_css_classes=>'fa-exclamation-circle'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--danger:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>2042159785845301134
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>'Maximum verification attempts exceeded.   Account will reset in &P9998_RESET_VERIFY_AFTER_X_HOURS. hours.'
,p_translate_title=>'N'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P9998_IS_ACCOUNT_LOCKED_YN = ''Y'''
,p_plug_display_when_cond2=>'SQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13918879116123017713)
,p_plug_name=>'for cancel'
,p_static_id=>'for-cancel'
,p_parent_plug_id=>wwv_flow_imp.id(6370395366499150603)
,p_icon_css_classes=>'fa-exclamation-circle'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_translate_title=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13918878593370017708)
,p_plug_name=>'for token'
,p_static_id=>'for-token'
,p_parent_plug_id=>wwv_flow_imp.id(6370395366499150603)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_translate_title=>'N'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9998_IS_ACCOUNT_LOCKED_YN = ''N'' and',
':P9998_IS_TOKEN_MAXED_YN = ''N'''))
,p_plug_display_when_cond2=>'SQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6370395366499150603)
,p_plug_name=>'qAsk User Verification'
,p_static_id=>'qask-user-verification'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2675634334296186762
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13918877957503017702)
,p_plug_name=>'token maxed'
,p_static_id=>'token-maxed'
,p_parent_plug_id=>wwv_flow_imp.id(6370395366499150603)
,p_icon_css_classes=>'fa-exclamation-circle'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--warning:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>2042159785845301134
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>'<p>No more access attempts left, request a new token.</p>'
,p_translate_title=>'N'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9998_IS_ACCOUNT_LOCKED_YN = ''N'' and',
':P9998_IS_TOKEN_MAXED_YN = ''Y'''))
,p_plug_display_when_cond2=>'SQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6370395710345150606)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(13918879116123017713)
,p_button_name=>'cancel'
,p_static_id=>'cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--stretch'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:9998::'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6370395596763150605)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(13918878593370017708)
,p_button_name=>'VERIFY'
,p_static_id=>'verify'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Verify'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(10927142724379006006)
,p_branch_name=>'go to login if P9998_USERNAME is null'
,p_branch_action=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:9998,9999::'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'ITEM_IS_NULL'
,p_branch_condition=>'P9998_USERNAME'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6370399270940150642)
,p_name=>'P9998_CODE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(13918878593370017708)
,p_prompt=>'Verification Code'
,p_placeholder=>'000000'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>6
,p_cMaxlength=>6
,p_tag_css_classes=>'w260 margin-auto u-tC'
,p_tag_attributes=>'inputmode="numeric" pattern="[0-9]*" autocomplete="one-time-code"'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9998_IS_ACCOUNT_LOCKED_YN = ''N'' and',
':P9998_IS_TOKEN_MAXED_YN = ''N'''))
,p_display_when2=>'SQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>2042262243893469891
,p_item_css_classes=>'app-Form-fieldContainer--verificationCode'
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'Y',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13918878131267017703)
,p_name=>'P9998_IS_ACCOUNT_LOCKED_YN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(13918878593370017708)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13918878222999017704)
,p_name=>'P9998_IS_TOKEN_MAXED_YN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(13918878593370017708)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13918879222495017714)
,p_name=>'P9998_RESET_VERIFY_AFTER_X_HOURS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(13918878503160017707)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6370395457679150604)
,p_name=>'P9998_USERNAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(13918878593370017708)
,p_prompt=>'Username'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10927142808557006007)
,p_computation_sequence=>10
,p_computation_item=>'P9998_CODE'
,p_static_id=>'p9998-code'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13918878379277017706)
,p_computation_sequence=>30
,p_computation_item=>'P9998_IS_ACCOUNT_LOCKED_YN'
,p_static_id=>'p9998-is-account-locked-yn'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'qask_util.is_account_locked_yn (p_username => :P9998_USERNAME)'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13918878341930017705)
,p_computation_sequence=>20
,p_computation_item=>'P9998_IS_TOKEN_MAXED_YN'
,p_static_id=>'p9998-is-token-maxed-yn'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'qask_util.is_token_maxed_yn (p_username => :P9998_USERNAME)'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13918879341232017715)
,p_computation_sequence=>10
,p_computation_item=>'P9998_RESET_VERIFY_AFTER_X_HOURS'
,p_static_id=>'p9998-reset-verify-after-x-hours'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'qask_util.get_setting(''reset_verify_after_x_hours'')'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12626201117587938198)
,p_name=>'Only Allow Numbers'
,p_static_id=>'only-allow-numbers'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9998_CODE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keypress'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12626201478978938201)
,p_event_id=>wwv_flow_imp.id(12626201117587938198)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'if (this.browserEvent.key.length === 1 && /\D/.test(this.browserEvent.key)) {',
    '    this.browserEvent.preventDefault();',
    '}')))).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10927144173262006021)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'login'
,p_static_id=>'login'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'package', 'APEX_AUTHENTICATION',
  'package_method', 'LOGIN',
  'type', 'PLSQL_PACKAGE')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>9036718926827608721
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10927144362275006023)
,p_page_process_id=>wwv_flow_imp.id(10927144173262006021)
,p_page_id=>9998
,p_name=>'p_password'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9998_CODE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10927144609358006025)
,p_page_process_id=>wwv_flow_imp.id(10927144173262006021)
,p_page_id=>9998
,p_name=>'p_set_persistent_auth'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>40
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10927144489431006024)
,p_page_process_id=>wwv_flow_imp.id(10927144173262006021)
,p_page_id=>9998
,p_name=>'p_uppercase_username'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>30
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10927144258153006022)
,p_page_process_id=>wwv_flow_imp.id(10927144173262006021)
,p_page_id=>9998
,p_name=>'p_username'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9998_USERNAME'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13918882328733017745)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'redirect to login when token maxed'
,p_static_id=>'redirect-to-login-when-token-maxed'
,p_process_sql_clob=>'apex_util.redirect_url(apex_util.prepare_url(''f?p=''||:APP_ID||'':login:''||:APP_SESSION||'':NEWCODE:::P9999_USERNAME:''||:P9998_USERNAME)); '
,p_process_clob_language=>'PLSQL'
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9998_IS_ACCOUNT_LOCKED_YN = ''N'' and',
':P9998_IS_TOKEN_MAXED_YN = ''Y'''))
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'SQL'
,p_internal_uid=>12028457082298620445
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10886213595633252989)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Set Username Cookie'
,p_static_id=>'set-username-cookie'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'package', 'APEX_AUTHENTICATION',
  'package_method', 'SEND_LOGIN_USERNAME_COOKIE',
  'type', 'PLSQL_PACKAGE')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8995788349198855689
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10886214024681252991)
,p_page_process_id=>wwv_flow_imp.id(10886213595633252989)
,p_page_id=>9998
,p_name=>'p_username'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>1
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':P9998_USERNAME'
);
wwv_flow_imp.component_end;
end;
/
