prompt --application/shared_components/navigation/lists/p120_actions
begin
--   Manifest
--     LIST: p120_actions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(55660828985588873794)
,p_name=>'p120_actions'
,p_static_id=>'p120-actions'
,p_version_scn=>'37167711609130'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(55660829215385873794)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Add Question'
,p_static_id=>'add-question'
,p_list_item_link_target=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:112:P112_SESSION_ID:&P120_SESSION_ID.:'
,p_list_item_icon=>'fa-plus'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions',
' where id = :P120_SESSION_ID',
'   and session_status = ''STAGED''',
'   and owner = lower(:APP_USER)'))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(55660829605682873795)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Copy Session'
,p_static_id=>'copy-session'
,p_list_item_link_target=>'f?p=&APP_ID.:115:&SESSION.::&DEBUG.:115:P115_ID:&P120_SESSION_ID.:'
,p_list_item_icon=>'fa-copy'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions',
' where id = :P120_SESSION_ID',
'   and session_status in (''STAGED'',''CLOSED'')',
'   and owner = lower(:APP_USER)'))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(55660829974362873795)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Delete Session'
,p_static_id=>'delete-session'
,p_list_item_link_target=>'f?p=&APP_ID.:116:&SESSION.::&DEBUG.:116:P116_SESSION_ID:&P120_SESSION_ID.:'
,p_list_item_icon=>'fa-trash-o'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.get_session_status(p_session_id => :P120_SESSION_ID) in (''STAGED'',''CLOSED'') and',
'qask_util.get_session_owner(p_session_id => :P120_SESSION_ID) = :APP_USER'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
