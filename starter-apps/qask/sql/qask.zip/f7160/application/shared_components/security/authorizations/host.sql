prompt --application/shared_components/security/authorizations/host
begin
--   Manifest
--     SECURITY SCHEME: Host
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(48319320446482829871)
,p_name=>'Host'
,p_static_id=>'host'
,p_scheme_type=>'NATIVE_IS_IN_GROUP'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'name', 'Administrator,Host',
  'type', 'A')).to_clob
,p_error_message=>'Insufficient privileges, user is not a Host'
,p_version_scn=>'37167711609130'
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_imp.component_end;
end;
/
