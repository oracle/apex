prompt --application/shared_components/security/app_access_control/administrator
begin
--   Manifest
--     ACL ROLE: Administrator
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(48319319882778829871)
,p_static_id=>'ADMINISTRATOR'
,p_name=>'Administrator'
,p_description=>'Can host sessions, monitor the application and add users.'
,p_version_scn=>'15496324912285'
);
wwv_flow_imp.component_end;
end;
/
