prompt --application/shared_components/security/authorizations/allow_user_requests
begin
--   Manifest
--     SECURITY SCHEME: ALLOW_USER_REQUESTS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(7599480032474820827)
,p_name=>'ALLOW_USER_REQUESTS'
,p_static_id=>'allow-user-requests'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'plsql_function_body', wwv_flow_string.join(wwv_flow_t_varchar2(
    'if qask_util.get_setting(''allow_account_requests_yn'') = ''Y'' then',
    '   return TRUE;',
    'else return FALSE;',
    'end if;')))).to_clob
,p_version_scn=>'37167711609130'
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
