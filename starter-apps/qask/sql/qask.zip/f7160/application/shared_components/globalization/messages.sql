prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 7160
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(6803329108883732143)
,p_name=>'ACCESS_REQUESTS'
,p_message_text=>'Access Requests'
,p_version_scn=>'15493767600927'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(18578305910997526610)
,p_name=>'ACCESS_REQUESTS_RESTRICTED_BY_EMAIL_DOMAIN'
,p_message_text=>'Access requests are restricted by email domain.'
,p_version_scn=>'15495820361300'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(20032478177037165658)
,p_name=>'APEX.AUTHENTICATION.LOGIN_THROTTLE.COUNTER'
,p_message_text=>'Please wait <span id="apex_login_throttle_sec">%0</span> seconds to verify again.'
,p_version_scn=>'15496015297109'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(20032978027747480201)
,p_name=>'APEX.AUTHENTICATION.LOGIN_THROTTLE.ERROR'
,p_message_text=>'The verification attempt has been blocked.'
,p_version_scn=>'15496015311829'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(18564106610611354017)
,p_name=>'EMAIL_DOMAIN_NOT_ALLOWED'
,p_message_text=>'Email Domain not allowed.'
,p_version_scn=>'15495818467593'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(20030767936845447904)
,p_name=>'INVALID_CREDENTIALS'
,p_message_text=>'Invalid verification code'
,p_version_scn=>'15496014953143'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(18581644906000240248)
,p_name=>'UPDATE_SETTINGS_TO_RESTRICT_TO_THESE_DOMAINS'
,p_message_text=>'Update settings if you wish to restrict to these domains.'
,p_version_scn=>'15495820576673'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(18578475549098214983)
,p_name=>'USERS_AND_ACCESS_REQUESTS_RESTRICTED_BY_EMAIL_DOMAIN'
,p_message_text=>'Users and Access requests are restricted by email domain.'
,p_version_scn=>'15495820367655'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(18576961439398198104)
,p_name=>'USERS_RESTRICTED_BY_EMAIL_DOMAIN'
,p_message_text=>'Users are restricted by email domain.'
,p_version_scn=>'15495820199178'
);
wwv_flow_imp.component_end;
end;
/
