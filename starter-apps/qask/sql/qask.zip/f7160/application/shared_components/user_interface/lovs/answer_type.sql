prompt --application/shared_components/user_interface/lovs/answer_type
begin
--   Manifest
--     ANSWER TYPE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(73182437175131099423)
,p_lov_name=>'ANSWER TYPE'
,p_static_id=>'answer-type'
,p_lov_query=>'.'||wwv_flow_imp.id(73182437175131099423)||'.'
,p_location=>'STATIC'
,p_version_scn=>'37167711609134'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(73182438272785099424)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Free Form Answer'
,p_lov_return_value=>'FREEFORM'
,p_static_id=>'free-form-answer'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(73182437944298099424)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Multiple Answers'
,p_lov_return_value=>'MULTI'
,p_static_id=>'multiple-answers'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(73182437464899099423)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Single Answer'
,p_lov_return_value=>'SINGLE'
,p_static_id=>'single-answer'
);
wwv_flow_imp.component_end;
end;
/
