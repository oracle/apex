prompt --application/shared_components/logic/application_processes/close_old_sessions
begin
--   Manifest
--     APPLICATION PROCESS: close old sessions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(73716543311838582836)
,p_process_sequence=>1
,p_process_point=>'AFTER_LOGIN'
,p_process_name=>'close old sessions'
,p_static_id=>'close-old-sessions'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'    select count(*) cnt',
'      from user_scheduler_running_jobs',
'     where job_name = ''QASK_CLOSE_OLD_SESSIONS''',
') loop',
'    if c1.cnt = 0 then',
'        sys.dbms_scheduler.run_job( ''QASK_CLOSE_OLD_SESSIONS'', false );',
'    end if;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_version_scn=>'1'
);
wwv_flow_imp.component_end;
end;
/
