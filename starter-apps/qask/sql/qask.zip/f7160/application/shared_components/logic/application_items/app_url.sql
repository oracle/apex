prompt --application/shared_components/logic/application_items/app_url
begin
--   Manifest
--     APPLICATION ITEM: APP_URL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(6339340474078863226)
,p_name=>'APP_URL'
,p_protection_level=>'I'
,p_version_scn=>'15493657060440'
);
wwv_flow_imp.component_end;
end;
/
