prompt --application/pages/page_10031
begin
--   Manifest
--     PAGE: 10031
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1843380062236545922
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10031
,p_name=>'Manage User Access'
,p_alias=>'MANAGE-USER-ACCESS'
,p_step_title=>'Manage User Access'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(48272276456337978494)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(48272275094264978493)
,p_required_patch=>wwv_flow_imp.id(48272272821533978492)
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page shows a report of the application users and the access level granted.</p>',
'<p>Click on the column headings to sort and filter data, or click on the <strong>Actions</strong> button to customize column display and many additional advanced features.<br>',
'Click the <strong>Reset</strong> button to reset the interactive report back to the default settings.</p>',
'<p>Click the edit icon (yellow pencil) to edit the user details and access level, or to delete the user.</p>',
'<p>Click <strong>Add User</strong>, at the top of the report, to add a new user and their access level.</p>'))
,p_page_component_map=>'25'
,p_last_updated_by=>'SBKENNED'
,p_last_upd_yyyymmddhh24miss=>'20240322134050'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(30539626853989030886)
,p_plug_name=>'Note'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(48271689010712978405)
,p_plug_display_sequence=>5
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P10031_RESTRICT_USERS_YN = ''Y'' then',
'    return apex_lang.message(''USERS_AND_ACCESS_REQUESTS_RESTRICTED_BY_EMAIL_DOMAIN'');',
'elsif :P10031_RESTRICT_REQUESTS_YN = ''Y'' then',
'    return apex_lang.message(''ACCESS_REQUESTS_RESTRICTED_BY_EMAIL_DOMAIN'');',
'end if;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P10031_RESTRICT_USERS_YN,P10031_RESTRICT_REQUESTS_YN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(48272375697328978823)
,p_plug_name=>'Manage User Access'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders'
,p_plug_template=>wwv_flow_imp.id(48271679216432978401)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'   user_name_lc USERNAME,',
'   role_names ACCESS_ROLE,',
'   (select max(updated_on) from qask_verify_tokens',
'     where username = u.user_name_lc',
'       and verified_yn = ''Y'') last_login',
'from APEX_APPL_ACL_USERS u',
'where APPLICATION_ID = :APP_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Manage User Access'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(48272376509997978823)
,p_name=>'Manage User Access'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'SBKENNED'
,p_internal_uid=>46428996447761432901
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(48272376927664978824)
,p_db_column_name=>'ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(48272377320494978825)
,p_db_column_name=>'USERNAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Username'
,p_column_link=>'f?p=&APP_ID.:10032:&SESSION.::&DEBUG.:10032:P10032_ID:#ID#'
,p_column_linktext=>'#USERNAME#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(48272377743283978825)
,p_db_column_name=>'ACCESS_ROLE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Role'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(10880099545209154648)
,p_db_column_name=>'LAST_LOGIN'
,p_display_order=>13
,p_column_identifier=>'D'
,p_column_label=>'Last Login'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(48272379193197978826)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'464289992'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'USERNAME:ACCESS_ROLE:LAST_LOGIN:'
,p_sort_column_1=>'USERNAME'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(305896296996280936277)
,p_plug_name=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48272101477272978410)
,p_plug_display_sequence=>5
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(48271585552422978362)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(48272164061602978436)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(48272380475506978827)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(305896296996280936277)
,p_button_name=>'ADD_MULTIPLE_USERS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(48272162460548978436)
,p_button_image_alt=>'Add Multiple Users'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:10033:&APP_SESSION.::&DEBUG.:10033::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(48272380874867978827)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(305896296996280936277)
,p_button_name=>'ADD_USER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(48272162460548978436)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add User'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:10032:&APP_SESSION.::&DEBUG.:10032::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(48272380064926978827)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(48272375697328978823)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--iconLeft:t-Button--gapRight'
,p_button_template_id=>wwv_flow_imp.id(48272162491040978436)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&APP_SESSION.::&DEBUG.:&APP_PAGE_ID.,RR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(49089541946505088297)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(305896296996280936277)
,p_button_name=>'Up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(48272161758030978435)
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30539628457910030891)
,p_name=>'P10031_RESTRICT_REQUESTS_YN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(30539626853989030886)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(30539628611966030892)
,p_name=>'P10031_RESTRICT_USERS_YN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(30539626853989030886)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13871835201187166348)
,p_computation_sequence=>10
,p_computation_item=>'P10031_RESTRICT_REQUESTS_YN'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'SQL'
,p_computation=>'qask_util.get_setting(''restrict_requests_to_email_domains_yn'')'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13871835313925166349)
,p_computation_sequence=>20
,p_computation_item=>'P10031_RESTRICT_USERS_YN'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'SQL'
,p_computation=>'qask_util.get_setting(''restrict_users_to_email_domains_yn'')'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(48272375849887978823)
,p_name=>'Refresh Report after create'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(305896296996280936277)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48272381557711978828)
,p_event_id=>wwv_flow_imp.id(48272375849887978823)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(48272375697328978823)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(54374119768250304264)
,p_name=>'Refresh Report after edit'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(48272375697328978823)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(54374119906573304265)
,p_event_id=>wwv_flow_imp.id(54374119768250304264)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(48272375697328978823)
);
wwv_flow_imp.component_end;
end;
/
