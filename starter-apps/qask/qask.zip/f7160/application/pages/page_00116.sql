prompt --application/pages/page_00116
begin
--   Manifest
--     PAGE: 00116
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>26987669612026766
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>116
,p_name=>'Delete Session'
,p_alias=>'DELETE-SESSION'
,p_page_mode=>'MODAL'
,p_step_title=>'Delete Session'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(48299262931897005259)
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(22461915012601837831)
,p_plug_name=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48298612707337005146)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(125073391824475456311)
,p_name=>'&P116_SESSION_CODE. - &P116_SESSION_NAME.'
,p_template=>wwv_flow_imp.id(48298676680325005171)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       OWNER,',
'       SESSION_CODE,',
'       initcap(session_status) status,',
'       closed_on DATE_CLOSED,',
'       CREATED_ON CREATED,',
'       started_on,',
'       CREATED_BY,',
'       PURPOSE,',
'       SESSION_NAME,',
'       (select count(*) from qask_session_questions ',
'         where session_id = s.id) question_count,',
'       (select count(*) from qask_responses ',
'         where session_id = s.id) response_count',
'  from QASK_SESSIONS s',
' where id = :P116_SESSION_ID'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P116_SESSION_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(48299118103252005188)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54316523299784247614)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54316523638224247614)
,p_query_column_id=>2
,p_column_alias=>'OWNER'
,p_column_display_sequence=>20
,p_column_heading=>'Owner'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54316524055742247615)
,p_query_column_id=>3
,p_column_alias=>'SESSION_CODE'
,p_column_display_sequence=>30
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54316530060008247619)
,p_query_column_id=>4
,p_column_alias=>'STATUS'
,p_column_display_sequence=>100
,p_column_heading=>'Status'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54316524487797247615)
,p_query_column_id=>5
,p_column_alias=>'DATE_CLOSED'
,p_column_display_sequence=>150
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54316525237836247616)
,p_query_column_id=>6
,p_column_alias=>'CREATED'
,p_column_display_sequence=>120
,p_column_heading=>'Created'
,p_use_as_row_header=>'N'
,p_column_format=>'fmMonth fmDD, YYYY'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions',
' where id = :P116_SESSION_ID',
'   and started_on is null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54316529670153247618)
,p_query_column_id=>7
,p_column_alias=>'STARTED_ON'
,p_column_display_sequence=>130
,p_column_heading=>'Started'
,p_use_as_row_header=>'N'
,p_column_format=>'fmMonth fmDD, YYYY'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions',
' where id = :P116_SESSION_ID',
'   and started_on is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54316525717759247616)
,p_query_column_id=>8
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>180
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54316526904653247617)
,p_query_column_id=>9
,p_column_alias=>'PURPOSE'
,p_column_display_sequence=>60
,p_column_heading=>'Purpose'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions',
' where id = :P116_SESSION_ID',
'   and purpose is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54316527259044247617)
,p_query_column_id=>10
,p_column_alias=>'SESSION_NAME'
,p_column_display_sequence=>40
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54316528095510247617)
,p_query_column_id=>11
,p_column_alias=>'QUESTION_COUNT'
,p_column_display_sequence=>210
,p_column_heading=>'Question Count'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(54316522446326247613)
,p_query_column_id=>12
,p_column_alias=>'RESPONSE_COUNT'
,p_column_display_sequence=>220
,p_column_heading=>'Participant Count'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_responses',
' where session_id = :P116_SESSION_ID'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(22461915042912837832)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(22461915012601837831)
,p_button_name=>'cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(54316521394468247611)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(22461915012601837831)
,p_button_name=>'delete_session'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Delete'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_confirm_message=>'Are you sure you want to delete this session?'
,p_security_scheme=>wwv_flow_imp.id(48299262931897005259)
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(54316547682993247637)
,p_branch_name=>'after delete'
,p_branch_action=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:116::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(54316521394468247611)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(118196441573184752955)
,p_name=>'P116_SESSION_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(125073391824475456311)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(118196441687711752956)
,p_name=>'P116_SESSION_CODE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(125073391824475456311)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(118196441781206752957)
,p_name=>'P116_SESSION_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(125073391824475456311)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54316543932102247635)
,p_computation_sequence=>10
,p_computation_item=>'P116_SESSION_CODE'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return qask_util.get_session_code (',
'    p_session_id => :P116_SESSION_ID );'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54316544411672247635)
,p_computation_sequence=>20
,p_computation_item=>'P116_SESSION_NAME'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return qask_util.get_session_name (',
'    p_session_id => :P116_SESSION_ID );'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(22461915207057837833)
,p_name=>'Cancel'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(22461915042912837832)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22461915259652837834)
,p_event_id=>wwv_flow_imp.id(22461915207057837833)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(54316545872715247636)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'delete session'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.delete_session (',
'    p_session_id => :P116_SESSION_ID );'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Session failed to be deleted.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(54316521394468247611)
,p_process_success_message=>'Session deleted.'
,p_internal_uid=>52446178140866674948
);
wwv_flow_imp.component_end;
end;
/
