prompt --application/pages/page_00021
begin
--   Manifest
--     PAGE: 00021
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1843380062236545922
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>21
,p_name=>'Your Answer'
,p_alias=>'YOUR-ANSWER'
,p_step_title=>'Your Answer'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var checkNextAvailable = function() {',
'    apex.server.process( ''nextAvailable'', {}, {',
'        success: function( pData ) {',
'            if (pData.status === ''OPEN'') {',
'                apex.page.submit(''OPEN'');',
'            } else if (pData.status === ''SESSION_CLOSED'') {',
'                apex.page.submit(''SESSION_CLOSED'');',
'            }',
'        },',
'        error: function( pData ) {',
'            console.log(pData);',
'            apex.message.showErrors([',
'                {',
'                    type:       "error",',
'                    location:   "page",',
'                    message:    "Woops! Something went wrong.",',
'                    unsafe:     false',
'                }',
'            ]);',
'        }',
'    });',
'}'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.answer {',
'    padding: 4px 16px; ',
'    background-color: var(--rw-palette-neutral-190);',
'    color:#FFF;',
'    font-weight: 700;',
'    font-size: 1rem;',
'    margin: 0 8px;',
'    border-radius: 4px;',
'}',
'.multiple-answers {',
'    max-width: 320px;',
'    margin: 24px auto;',
'}',
'',
'.multiple-answers .answer {',
'    display: inline-block;',
'    margin: 0;',
'}',
'.multiple-answers ul {',
'    margin: 0;',
'    list-style: none;',
'}',
'.multiple-answers li {',
'    margin: 8px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_comment=>'Confirms the users answer to a question was counted and provides navigation to the next question if and when it becomes available'
,p_page_component_map=>'10'
,p_last_updated_by=>'SBKENNED'
,p_last_upd_yyyymmddhh24miss=>'20240402212934'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(73064919719342002233)
,p_plug_name=>'Container'
,p_region_css_classes=>'u-tC'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--success:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(48271616986112978376)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(65723288278960051230)
,p_plug_name=>'Session Closed'
,p_parent_plug_id=>wwv_flow_imp.id(73064919719342002233)
,p_region_css_classes=>'margin-top-sm'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48271622197549978379)
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'This session is now closed.'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'qask_util.get_session_status (p_session_id => :SESSION_ID) = ''CLOSED'''
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(87568095735168432251)
,p_plug_name=>'Last Question Closed'
,p_parent_plug_id=>wwv_flow_imp.id(73064919719342002233)
,p_region_css_classes=>'margin-top-sm'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48271622197549978379)
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'The question closed before your answer was submitted.'
,p_plug_display_condition_type=>'REQUEST_EQUALS_CONDITION'
,p_plug_display_when_condition=>'QCLOSED'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(157868412280850704333)
,p_plug_name=>'Next Question Unavailable'
,p_parent_plug_id=>wwv_flow_imp.id(73064919719342002233)
,p_region_css_classes=>'margin-top-sm'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48271622197549978379)
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'The next question is not yet available!'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.get_session_status (p_session_id => :SESSION_ID) != ''CLOSED''',
'and',
'qask_util.get_next_question_id (',
'    p_session_id  => :SESSION_ID,',
'    p_question_id => :QUESTION_ID) is null'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(157868676372832673199)
,p_plug_name=>'Next Question Available'
,p_parent_plug_id=>wwv_flow_imp.id(73064919719342002233)
,p_region_css_classes=>'margin-top-sm'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48271622197549978379)
,p_plug_display_sequence=>50
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'Ready to answer the next question?'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.get_next_question_id (',
'    p_session_id  => :SESSION_ID,',
'    p_question_id => :QUESTION_ID) is not null'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(113543996695154471272)
,p_plug_name=>'Session &SESSION_CODE.'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useRegionTitle'
,p_plug_template=>wwv_flow_imp.id(48272101477272978410)
,p_plug_display_sequence=>5
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'SESSION_CODE'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(157595272082161142504)
,p_plug_name=>'&P20_QUESTION.'
,p_region_css_classes=>'u-tC'
,p_icon_css_classes=>'fa-check-circle fa-2x'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--success'
,p_plug_template=>wwv_flow_imp.id(48271616986112978376)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P20_ANSWER_TYPE = ''MULTI'' then',
'    sys.htp.p(''<div class="multiple-answers">You answered:<ul>'');',
'    for c1 in (',
'        select answer_text',
'          from qask_response_answers',
'         where question_id = :QUESTION_ID ',
'           and response_id = :RESPONSE_ID',
'    ) loop',
'        sys.htp.p(''<li><span class="answer">''||apex_escape.html(c1.answer_text)||''</span></li>'');',
'    end loop;',
'    sys.htp.p(''</ul></div>'');',
'else',
'    for c1 in (',
'        select a.answer_text, a.comment_text, q.answer_type',
'          from qask_response_answers a,',
'               qask_session_questions q',
'         where a.question_id = :QUESTION_ID ',
'           and a.response_id = :RESPONSE_ID',
'           and a.question_id = q.id',
'    ) loop',
'        if c1.answer_type = ''FREEFORM'' then',
'            sys.htp.p(''You answered<br/>''||apex_escape.html(c1.answer_text));',
'        else',
'            sys.htp.p(''You answered<br/><span class="answer">''||apex_escape.html(c1.answer_text)||''</span>'');',
'        end if;',
'        if c1.comment_text is not null then',
'        sys.htp.p(''<br>''||apex_escape.html(c1.comment_text));',
'',
'        end if;',
'    end loop;',
'end if;'))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.is_question_answered_yn (',
'    p_response_id => :RESPONSE_ID,',
'    p_question_id => :QUESTION_ID ) = ''Y'''))
,p_plug_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56279161862752148969)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(157868412280850704333)
,p_button_name=>'REFRESH'
,p_button_static_id=>'refresh_button'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(48272162491040978436)
,p_button_image_alt=>'Refresh'
,p_button_css_classes=>'u-hidden'
,p_icon_css_classes=>'fa-refresh'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(65723288456449051231)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(65723288278960051230)
,p_button_name=>'home'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(48272162460548978436)
,p_button_image_alt=>'Join Another Session'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:1,20::'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(69668846645050516500)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(157868676372832673199)
,p_button_name=>'next_question'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(48272162491040978436)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next Question'
,p_button_redirect_url=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'margin-top-md'
,p_icon_css_classes=>'fa-chevron-right'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(65723289666907051244)
,p_branch_name=>'Session Ended'
,p_branch_action=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:12::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'REQUEST_EQUALS_CONDITION'
,p_branch_condition=>'SESSION_CLOSED'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(65723289788486051245)
,p_branch_name=>'Next Question Available'
,p_branch_action=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:20::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
,p_branch_condition_type=>'REQUEST_EQUALS_CONDITION'
,p_branch_condition=>'OPEN'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(54374119124053304257)
,p_branch_name=>'go home if no SESSION_ID'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>':SESSION_ID is null'
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(87568094784623432242)
,p_branch_name=>'Next Question Available'
,p_branch_action=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:20::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>30
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.get_next_question_id (',
'    p_session_id  => :SESSION_ID,',
'    p_question_id => :QUESTION_ID) is not null'))
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(69668849361761516502)
,p_name=>'Auto Reload'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(69668849807316516502)
,p_event_id=>wwv_flow_imp.id(69668849361761516502)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i = 0;',
'var interval = setInterval(function(){',
'    i += 1;',
'    if(i === 30){',
'        clearInterval(interval);',
'        $("#refresh_button").removeClass(''u-hidden'');',
'    }',
'    checkNextAvailable();',
'}, 5000);'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(65723289569660051243)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'nextAvailable'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.get_next_question_status_json (',
'    p_session_id  => :SESSION_ID,',
'    p_question_id => :QUESTION_ID );'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>63879909507423505321
);
wwv_flow_imp.component_end;
end;
/
