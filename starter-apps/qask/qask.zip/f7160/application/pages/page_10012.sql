prompt --application/pages/page_10012
begin
--   Manifest
--     PAGE: 10012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1905173489740762914
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10012
,p_name=>'Service Terms'
,p_alias=>'SERVICE-TERMS'
,p_step_title=>'Service Terms'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(50177448584005741407)
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_component_map=>'18'
,p_last_updated_by=>'SBKENNED'
,p_last_upd_yyyymmddhh24miss=>'20240209203525'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61102721896514754376)
,p_plug_name=>'Service Terms'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(50176852706173741315)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       substr(SERVICE_TERMS,1,255) || case when length(service_terms) > 255 then ''...'' end service_terms,',
'       ROW_VERSION,',
'       CREATED_ON,',
'       CREATED_BY,',
'       UPDATED_ON,',
'       UPDATED_BY,',
'       CURRENT_YN',
'  from QASK_SERVICE_TERMS'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Service Terms'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(61102722038300754376)
,p_name=>'Service Terms'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:10013:&APP_SESSION.::&DEBUG.:RP:P10013_ID:\#ID#\'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_owner=>'SBKENNED'
,p_internal_uid=>57354168486323445540
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61102722406832754377)
,p_db_column_name=>'ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61102722787036754377)
,p_db_column_name=>'SERVICE_TERMS'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Service Terms'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61102723223516754378)
,p_db_column_name=>'ROW_VERSION'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Row Version'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61102723639734754378)
,p_db_column_name=>'CREATED_ON'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Created On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61102723966750754378)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61102724438860754378)
,p_db_column_name=>'UPDATED_ON'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Updated On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61102724794640754379)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61102725191662754379)
,p_db_column_name=>'CURRENT_YN'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Current '
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(13980766245318241696)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(61106561190090792031)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'573580077'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SERVICE_TERMS:CURRENT_YN:UPDATED_ON:UPDATED_BY:'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(61107051570551488197)
,p_report_id=>wwv_flow_imp.id(61106561190090792031)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'CURRENT_YN'
,p_operator=>'='
,p_expr=>'Yes'
,p_condition_sql=>'"CURRENT_YN" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Yes''  '
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61102727311824754380)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(50177274967013741324)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(50176759042163741276)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(50177337551343741350)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61102725728636754379)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(61102727311824754380)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(50177335950289741350)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add New Terms'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:10013:&APP_SESSION.::&DEBUG.:10013::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61102740470507757033)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(61102727311824754380)
,p_button_name=>'Up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(50177335247771741349)
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(61102725980298754379)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(61102721896514754376)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61102726496483754380)
,p_event_id=>wwv_flow_imp.id(61102725980298754379)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(61102721896514754376)
);
wwv_flow_imp.component_end;
end;
/
