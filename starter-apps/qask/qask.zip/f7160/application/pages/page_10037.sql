prompt --application/pages/page_10037
begin
--   Manifest
--     PAGE: 10037
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>26987669612026766
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10037
,p_name=>'Restricted To Email Domains'
,p_alias=>'RESTRICTED-TO-EMAIL-DOMAINS'
,p_step_title=>'Restricted To Email Domains'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(48299262763877005259)
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13898822122108193106)
,p_plug_name=>'Note'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48298609867162005145)
,p_plug_display_sequence=>10
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P10037_RESTRICT_USERS_YN = ''Y'' then',
'    return apex_lang.message(''USERS_AND_ACCESS_REQUESTS_RESTRICTED_BY_EMAIL_DOMAIN'');',
'elsif :P10037_RESTRICT_REQUESTS_YN = ''Y'' then',
'    return apex_lang.message(''ACCESS_REQUESTS_RESTRICTED_BY_EMAIL_DOMAIN'');',
'else',
'    return apex_lang.message(''UPDATE_SETTINGS_TO_RESTRICT_TO_THESE_DOMAINS'');',
'end if;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P10037_RESTRICT_USERS_YN,P10037_RESTRICT_REQUESTS_YN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14015523185729735254)
,p_plug_name=>'Restricted To Email Domains'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48298666886045005167)
,p_plug_display_sequence=>30
,p_query_type=>'TABLE'
,p_query_table=>'QASK_RESTRICTED_EMAIL_DOMAINS'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Restricted To Email Domains'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(14015523322290735254)
,p_name=>'Restricted To Email Domains'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_base_pk1=>'ID'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:10038:&APP_SESSION.::&DEBUG.:RP:P10038_ID:\#ID#\'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_owner=>'SBKENNED'
,p_internal_uid=>12145155590442162566
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14015523668758735255)
,p_db_column_name=>'ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14015524117762735255)
,p_db_column_name=>'EMAIL_DOMAIN'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Email Domain'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14015524519217735255)
,p_db_column_name=>'COMMENTS'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Comments'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14015524928062735255)
,p_db_column_name=>'ROW_VERSION'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Row Version'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14015525328688735256)
,p_db_column_name=>'CREATED_ON'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Created On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14015525691986735256)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14015526108162735256)
,p_db_column_name=>'UPDATED_ON'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Updated On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(14015526509854735256)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(18071999753712189293)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'162016321'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'EMAIL_DOMAIN:COMMENTS:UPDATED_ON:UPDATED_BY:'
,p_sort_column_1=>'EMAIL_DOMAIN'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(353172479522896233037)
,p_plug_name=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48299089146885005176)
,p_plug_display_sequence=>5
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(48298573222035005128)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(48299151731215005202)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14015526944421735257)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(353172479522896233037)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Domain'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:10038:&APP_SESSION.::&DEBUG.:10038::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(49118172042914140259)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(353172479522896233037)
,p_button_name=>'Up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(48299149427643005201)
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13898822471044193110)
,p_name=>'P10037_RESTRICT_REQUESTS_YN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(13898822122108193106)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13898822625100193111)
,p_name=>'P10037_RESTRICT_USERS_YN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(13898822122108193106)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13898822697490193112)
,p_computation_sequence=>10
,p_computation_item=>'P10037_RESTRICT_REQUESTS_YN'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'qask_util.get_setting(''restrict_requests_to_email_domains_yn'')'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13898822756813193113)
,p_computation_sequence=>20
,p_computation_item=>'P10037_RESTRICT_USERS_YN'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'qask_util.get_setting(''restrict_users_to_email_domains_yn'')'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(14015527275330735257)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(14015523185729735254)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(14015527735925735257)
,p_event_id=>wwv_flow_imp.id(14015527275330735257)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(14015523185729735254)
);
wwv_flow_imp.component_end;
end;
/
