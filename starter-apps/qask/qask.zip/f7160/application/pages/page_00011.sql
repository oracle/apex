prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'Participant Information'
,p_alias=>'PARTICIPANT-INFORMATION'
,p_page_mode=>'MODAL'
,p_step_title=>'Participant Information'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.apex-item-text {',
'    --a-field-input-font-size: 2rem;',
'    --a-field-input-line-height: 4rem;',
'}',
'.t-Form-itemWrapper {',
'    justify-content: center;',
'}',
'',
'.t-Alert--wizard .t-Alert-buttons {',
'    margin-block-start: 0.5rem;',
'}',
'',
'.t-Button--large {',
'    --a-button-font-size: 1rem;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'U'
,p_deep_linking=>'Y'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(171064286090289085336)
,p_plug_name=>'Welcome to qAsk'
,p_region_css_classes=>'u-tC'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--info:t-Form--noPadding'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'Enter details requested for this Session'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(65261902092596990082)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(171064286090289085336)
,p_button_name=>'Join'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Join'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_button_css_classes=>'w260 margin-auto padding-md'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(65261906181639990085)
,p_branch_name=>'show question'
,p_branch_action=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:RR,20::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59153172599444580646)
,p_name=>'P11_EMAIL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(171064286090289085336)
,p_prompt=>'Your Email'
,p_placeholder=>'Your Email'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>0
,p_display_when=>'qask_util.session_resp_email_req_yn(p_session_id => :SESSION_ID) = ''Y'''
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>2040785906935475274
,p_item_template_options=>'#DEFAULT#:margin-top-md'
,p_protection_level=>'I'
,p_restricted_characters=>'NO_SPECIAL_CHAR_NL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134384506883852099009)
,p_name=>'P11_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(171064286090289085336)
,p_prompt=>'Your Name'
,p_placeholder=>'Your Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_css_classes=>'u-tC w320'
,p_grid_label_column_span=>0
,p_display_when=>'qask_util.session_resp_name_req_yn(p_session_id => :SESSION_ID) = ''Y'''
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>2040785906935475274
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:margin-top-md'
,p_protection_level=>'I'
,p_restricted_characters=>'NO_SPECIAL_CHAR_NL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(65261904846603990084)
,p_validation_name=>'name required'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P11_NAME is not null then',
'   return true;',
'else',
'   return false;',
'end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Name is required'
,p_validation_condition=>'qask_util.session_resp_name_req_yn (p_session_id => :SESSION_ID) = ''Y'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(65261902092596990082)
,p_associated_item=>wwv_flow_imp.id(134384506883852099009)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(59153172749294580648)
,p_validation_name=>'email required'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P11_EMAIL is not null then',
'   return true;',
'else',
'   return false;',
'end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Email is required'
,p_validation_condition=>'qask_util.session_resp_email_req_yn (p_session_id => :SESSION_ID) = ''Y'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(65261902092596990082)
,p_associated_item=>wwv_flow_imp.id(59153172599444580646)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(73111963990998853602)
,p_validation_name=>'email valid'
,p_validation_sequence=>40
,p_validation=>'P11_EMAIL'
,p_validation2=>'[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>'Email is not valid'
,p_validation_condition=>'qask_util.session_resp_email_req_yn (p_session_id => :SESSION_ID) = ''Y'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(65261902092596990082)
,p_associated_item=>wwv_flow_imp.id(59153172599444580646)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
