prompt --application/pages/page_10013
begin
--   Manifest
--     PAGE: 10013
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1905173489740762914
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10013
,p_name=>'Service Term Details'
,p_alias=>'SERVICE-TERM-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Service Term Details'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_component_map=>'16'
,p_last_updated_by=>'SBKENNED'
,p_last_upd_yyyymmddhh24miss=>'20240209203531'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61102710340894754363)
,p_plug_name=>'Service Term Details'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(50176795687290741293)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'QASK_SERVICE_TERMS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61102717232890754369)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(50176798527465741294)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61102717616824754370)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(61102717232890754369)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(50177335950289741350)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61102719022258754371)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(61102717232890754369)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(50177335950289741350)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P10013_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61102719386369754371)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(61102717232890754369)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(50177335950289741350)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P10013_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61102719806000754371)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(61102717232890754369)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(50177335950289741350)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P10013_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61102710632089754364)
,p_name=>'P10013_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(61102710340894754363)
,p_item_source_plug_id=>wwv_flow_imp.id(61102710340894754363)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(50177333414722741348)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61102711013688754364)
,p_name=>'P10013_SERVICE_TERMS'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(61102710340894754363)
,p_item_source_plug_id=>wwv_flow_imp.id(61102710340894754363)
,p_prompt=>'Service Terms'
,p_source=>'SERVICE_TERMS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>10
,p_field_template=>wwv_flow_imp.id(50177334664429741349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61102711396080754365)
,p_name=>'P10013_ROW_VERSION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(61102710340894754363)
,p_item_source_plug_id=>wwv_flow_imp.id(61102710340894754363)
,p_source=>'ROW_VERSION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61102711834568754365)
,p_name=>'P10013_CREATED_ON'
,p_source_data_type=>'DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(61102710340894754363)
,p_item_source_plug_id=>wwv_flow_imp.id(61102710340894754363)
,p_source=>'CREATED_ON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_help_text=>'The date on which the record was created.'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61102712662759754366)
,p_name=>'P10013_CREATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(61102710340894754363)
,p_item_source_plug_id=>wwv_flow_imp.id(61102710340894754363)
,p_source=>'CREATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_help_text=>'The user who created the record.'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61102713572348754367)
,p_name=>'P10013_UPDATED_ON'
,p_source_data_type=>'DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(61102710340894754363)
,p_item_source_plug_id=>wwv_flow_imp.id(61102710340894754363)
,p_source=>'UPDATED_ON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61102713954711754367)
,p_name=>'P10013_UPDATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(61102710340894754363)
,p_item_source_plug_id=>wwv_flow_imp.id(61102710340894754363)
,p_source=>'UPDATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61102714379509754368)
,p_name=>'P10013_CURRENT_YN'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(61102710340894754363)
,p_item_source_plug_id=>wwv_flow_imp.id(61102710340894754363)
,p_prompt=>'Current'
,p_source=>'CURRENT_YN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(50177333414722741348)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(61102717701068754370)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(61102717616824754370)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61102718508346754371)
,p_event_id=>wwv_flow_imp.id(61102717701068754370)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56279292172637067167)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'insert service terms'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.insert_service_terms (',
'    p_service_terms => :P10013_SERVICE_TERMS,',
'    p_current_yn    => :P10013_CURRENT_YN);'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error creating Service Terms.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(61102719806000754371)
,p_process_success_message=>'Service Terms created.'
,p_internal_uid=>52530738620659758331
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56279292324242067168)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'update service terms'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.update_service_terms (',
'    p_service_terms_id => :P10013_ID,',
'    p_service_terms    => :P10013_SERVICE_TERMS,',
'    p_current_yn       => :P10013_CURRENT_YN);'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error updating Service Terms.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(61102719386369754371)
,p_process_success_message=>'Service Terms updated.'
,p_internal_uid=>52530738772264758332
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(56279292401633067169)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'delete service terms'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.delete_service_terms (',
'    p_service_terms_id => :P10013_ID);'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error deleting Service Terms.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(61102719022258754371)
,p_process_success_message=>'Service Terms deleted.'
,p_internal_uid=>52530738849655758333
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(61102721004993754372)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>57354167453016445536
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(61102720153627754372)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(61102710340894754363)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Service Term Details'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>57354166601650445536
);
wwv_flow_imp.component_end;
end;
/
