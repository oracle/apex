prompt --application/pages/page_10032
begin
--   Manifest
--     PAGE: 10032
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>26987669612026766
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10032
,p_name=>'User Details'
,p_alias=>'USER_DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'User Details'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(48299264125950005260)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(48299262763877005259)
,p_required_patch=>wwv_flow_imp.id(48299260491146005258)
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(10907087254309181415)
,p_name=>'Verification Tokens'
,p_template=>wwv_flow_imp.id(48298628869164005152)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:is-collapsed:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'QASK_VERIFY_TOKENS'
,p_query_where=>'username = lower(:P10032_USER_NAME)'
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'created_on desc'
,p_include_rowid_column=>false
,p_display_when_condition=>'P10032_ID'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(48299115114158005187)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10907087394391181416)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10907087523990181417)
,p_query_column_id=>2
,p_column_alias=>'USERNAME'
,p_column_display_sequence=>20
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10907087630016181418)
,p_query_column_id=>3
,p_column_alias=>'TOKEN'
,p_column_display_sequence=>50
,p_column_heading=>'Token'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10907087691063181419)
,p_query_column_id=>4
,p_column_alias=>'VERIFIED_YN'
,p_column_display_sequence=>60
,p_column_heading=>'Verified?'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(12102580425189505548)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10907087784069181420)
,p_query_column_id=>5
,p_column_alias=>'EXPIRED_YN'
,p_column_display_sequence=>100
,p_column_heading=>'Expired?'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(12102580425189505548)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10907087832466181421)
,p_query_column_id=>6
,p_column_alias=>'EXPIRE_ON'
,p_column_display_sequence=>110
,p_column_heading=>'Expired'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10907087990697181422)
,p_query_column_id=>7
,p_column_alias=>'ACCESSED_ON'
,p_column_display_sequence=>70
,p_column_heading=>'Accessed'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10907088079913181423)
,p_query_column_id=>8
,p_column_alias=>'ACCESS_ATTEMPTS'
,p_column_display_sequence=>80
,p_column_heading=>'Access Attempts'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10907088191502181424)
,p_query_column_id=>9
,p_column_alias=>'RESET_ON'
,p_column_display_sequence=>120
,p_column_heading=>'Reset'
,p_use_as_row_header=>'N'
,p_column_format=>'SINCE'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10907088254916181425)
,p_query_column_id=>10
,p_column_alias=>'RESET_BY'
,p_column_display_sequence=>130
,p_column_heading=>'Reset By'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10907088367467181426)
,p_query_column_id=>11
,p_column_alias=>'ROW_VERSION'
,p_column_display_sequence=>140
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10907088498642181427)
,p_query_column_id=>12
,p_column_alias=>'CREATED_ON'
,p_column_display_sequence=>30
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10907088583018181428)
,p_query_column_id=>13
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>150
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10907088634799181429)
,p_query_column_id=>14
,p_column_alias=>'UPDATED_ON'
,p_column_display_sequence=>160
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(10907088758043181430)
,p_query_column_id=>15
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>170
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(48299369658429005594)
,p_plug_name=>'Form on Manage User Access'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(48298609867162005145)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'APEX_APPL_ACL_USERS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(48299369770351005594)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(48298612707337005146)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_query_type=>'SQL'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10907089106502181433)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(48299369770351005594)
,p_button_name=>'RESET_VERIFICATION'
,p_button_action=>'SUBMIT'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_image_alt=>'Reset Verification'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P10032_ID is not null and ',
':P10032_IS_ACCOUNT_LOCKED_YN = ''Y'''))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(48299372555153005596)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(48299369770351005594)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P10032_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(48299372993164005596)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(48299369770351005594)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add User'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P10032_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(48299370802670005595)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(48299369770351005594)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_image_alt=>'Cancel'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(48299372217959005595)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(48299369770351005594)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_image_alt=>'Delete'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P10032_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6350339269974326005)
,p_name=>'P10032_SEND_EMAIL_YN'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(48299369658429005594)
,p_item_default=>'Y'
,p_prompt=>'Send Email'
,p_display_as=>'NATIVE_YES_NO'
,p_display_when=>'P10032_ID'
,p_display_when_type=>'ITEM_IS_NULL'
,p_field_template=>wwv_flow_imp.id(48299147594594005200)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10907088923459181431)
,p_name=>'P10032_IS_ACCOUNT_LOCKED_YN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(48299369658429005594)
,p_item_default=>'N'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48299373265092005596)
,p_name=>'P10032_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(48299369658429005594)
,p_item_source_plug_id=>wwv_flow_imp.id(48299369658429005594)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48299373644396005596)
,p_name=>'P10032_APPLICATION_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(48299369658429005594)
,p_item_source_plug_id=>wwv_flow_imp.id(48299369658429005594)
,p_use_cache_before_default=>'NO'
,p_item_default=>'&APP_ID.'
,p_source=>'APPLICATION_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48299374032026005596)
,p_name=>'P10032_USER_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(48299369658429005594)
,p_item_source_plug_id=>wwv_flow_imp.id(48299369658429005594)
,p_prompt=>'Username'
,p_placeholder=>'must be valid email'
,p_source=>'USER_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>255
,p_read_only_when=>'P10032_ID'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(48299148844301005201)
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48299374523545005597)
,p_name=>'P10032_ROLE_ID'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(48299369658429005594)
,p_item_source_plug_id=>wwv_flow_imp.id(48299369658429005594)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select role_id',
'  from APEX_APPL_ACL_ROLES',
' where application_id = :APP_ID ',
'   and role_name = ''Host'''))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Role'
,p_source=>'ROLE_IDS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'ACCESS_ROLES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select role_name d, role_id r',
'  from APEX_APPL_ACL_ROLES',
' where application_id = :APP_ID ',
' order by 1 desc'))
,p_field_template=>wwv_flow_imp.id(48299148844301005201)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(48299375786351005598)
,p_validation_name=>'Cannot remove yourself from administrator'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P10032_USER_NAME = :APP_USER and',
'    apex_acl.is_role_removed_from_user (',
'        p_application_id => :APP_ID,',
'        p_user_name      => :APP_USER,',
'        p_role_static_id => ''ADMINISTRATOR'',',
'        p_role_ids       => apex_string.split_numbers(',
'                                p_str => case when :REQUEST = ''DELETE'' then',
'                                             null',
'                                         else',
'                                             :P10032_ROLE_ID',
'                                         end,',
'                                p_sep => '':'') ) then',
'    return false;',
'else',
'    return true;',
'end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'You cannot remove administrator role from yourself.'
,p_when_button_pressed=>wwv_flow_imp.id(48299372555153005596)
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(6867735907362766689)
,p_validation_name=>'email valid'
,p_validation_sequence=>20
,p_validation=>'P10032_USER_NAME'
,p_validation2=>'[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>'Email is not valid'
,p_when_button_pressed=>wwv_flow_imp.id(48299372993164005596)
,p_associated_item=>wwv_flow_imp.id(48299374032026005596)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(6350339478830326007)
,p_validation_name=>'user already exists'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from apex_appl_acl_users ',
' where application_id = :APP_ID',
'   and user_name_lc = lower(:P10032_USER_NAME)'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'user already exists.'
,p_when_button_pressed=>wwv_flow_imp.id(48299372993164005596)
,p_associated_item=>wwv_flow_imp.id(48299374032026005596)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(18541554045006181023)
,p_validation_name=>'in domains (if restriction enabled)'
,p_validation_sequence=>40
,p_validation=>'qask_util.in_restricted_domains_yn (p_email => :P10032_USER_NAME) = ''Y'''
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Email domain not allowed'
,p_validation_condition=>'qask_util.get_setting(''restrict_users_to_email_domains_yn'') = ''Y'''
,p_validation_condition2=>'SQL'
,p_validation_condition_type=>'EXPRESSION'
,p_associated_item=>wwv_flow_imp.id(48299374032026005596)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(48299370914833005595)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(48299370802670005595)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48299371582477005595)
,p_event_id=>wwv_flow_imp.id(48299370914833005595)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(48299376100301005598)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_region_id=>wwv_flow_imp.id(48299369658429005594)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Manage User Access'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>46429008368452432910
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10907089280787181435)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'load is_account_locked_yn'
,p_process_sql_clob=>':P10032_IS_ACCOUNT_LOCKED_YN := qask_util.is_account_locked_yn (p_username => lower(:P10032_USER_NAME));'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>9036721548938608747
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6350339423270326006)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'add user'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.add_user (',
'    p_username      => :P10032_USER_NAME,',
'    p_role_id       => :P10032_ROLE_ID,',
'    p_send_email_yn => :P10032_SEND_EMAIL_YN,',
'    p_app_id        => :APP_ID,',
'    p_app_url       => case when :P10032_SEND_EMAIL_YN = ''Y'' then :APP_URL end );'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'User failed to be added.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(48299372993164005596)
,p_process_success_message=>'User added.'
,p_internal_uid=>4479971691421753318
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6350339044453326003)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'update user (can only change role)'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'    select role_ids',
'      from apex_appl_acl_users ',
'     where id = :P10032_ID',
'       and application_id = :APP_ID ',
') loop',
'    if :P10032_ROLE_ID != c1.role_ids then',
'        qask_util.update_user (',
'            p_username => :P10032_USER_NAME,',
'            p_role_id  => :P10032_ROLE_ID,',
'            p_app_id   => :APP_ID );',
'    end if;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'User change failed to be saved.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(48299372555153005596)
,p_process_success_message=>'User change saved.'
,p_internal_uid=>4479971312604753315
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6350339149248326004)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'delete user'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.delete_user (',
'    p_username => :P10032_USER_NAME,',
'    p_app_id   => :APP_ID );'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'User failed to be deleted.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(48299372217959005595)
,p_process_success_message=>'User deleted.'
,p_internal_uid=>4479971417399753316
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10907089136550181434)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Reset Verification'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'    select user_name_lc',
'      from APEX_APPL_ACL_USERS',
'     where id = :P10032_ID',
'       and application_id = :APP_ID ',
') loop',
'    qask_util.reset_verification_tokens (',
'        p_username => c1.user_name_lc );',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Verification failed to be reset.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(10907089106502181433)
,p_process_success_message=>'Verification Reset.'
,p_internal_uid=>9036721404701608746
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(48299376914712005599)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>46429009182863432911
);
wwv_flow_imp.component_end;
end;
/
