prompt --application/pages/page_10051
begin
--   Manifest
--     PAGE: 10051
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1905173489740762914
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10051
,p_name=>'Job Reporting'
,p_alias=>'JOB-REPORTING'
,p_step_title=>'Job Reporting'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(50177449946078741408)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(50177448584005741407)
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_component_map=>'18'
,p_last_updated_by=>'SBKENNED'
,p_last_upd_yyyymmddhh24miss=>'20240209203738'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(59681464463875685101)
,p_plug_name=>'Job Reporting'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders'
,p_plug_template=>wwv_flow_imp.id(50176852706173741315)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select job_name, ',
'       comments, ',
'       state, ',
'       last_start_date, ',
'       last_run_duration, ',
'       next_run_date ',
'  from user_scheduler_jobs ',
' where job_name like ''QASK%'''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Email Reporting'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(59681465078978685102)
,p_name=>'Email Reporting'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'SBKENNED'
,p_internal_uid=>55932911527001376266
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12785271929837917551)
,p_db_column_name=>'JOB_NAME'
,p_display_order=>10
,p_column_identifier=>'V'
,p_column_label=>'Job Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12785272040055917552)
,p_db_column_name=>'COMMENTS'
,p_display_order=>20
,p_column_identifier=>'W'
,p_column_label=>'Comments'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12785272100898917553)
,p_db_column_name=>'STATE'
,p_display_order=>30
,p_column_identifier=>'X'
,p_column_label=>'State'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12785272221289917554)
,p_db_column_name=>'LAST_START_DATE'
,p_display_order=>40
,p_column_identifier=>'Y'
,p_column_label=>'Last Started'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12785272258717917555)
,p_db_column_name=>'LAST_RUN_DURATION'
,p_display_order=>50
,p_column_identifier=>'Z'
,p_column_label=>'Last Run Duration'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'OTHER'
,p_heading_alignment=>'LEFT'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12785272399650917556)
,p_db_column_name=>'NEXT_RUN_DATE'
,p_display_order=>60
,p_column_identifier=>'AA'
,p_column_label=>'Next Run Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(59681480794496685355)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'464359010'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'JOB_NAME:COMMENTS:STATE:LAST_START_DATE:LAST_RUN_DURATION:'
,p_sort_column_1=>'JOB_NAME'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'MAIL_MESSAGE_CREATED'
,p_sort_direction_2=>'DESC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(402299001325927568184)
,p_plug_name=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(50177274967013741324)
,p_plug_display_sequence=>5
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(50176759042163741276)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(50177337551343741350)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13245586879496133684)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(59681464463875685101)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(50177335980781741350)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&APP_SESSION.::&DEBUG.:&APP_PAGE_ID.,RR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(50996656150816896406)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(402299001325927568184)
,p_button_name=>'Up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(50177335247771741349)
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp.component_end;
end;
/
