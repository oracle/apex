prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1905173489740762914
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>12
,p_name=>'Session Ended'
,p_alias=>'SESSION-ENDED'
,p_step_title=>'Session Ended'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_comment=>'Page used to indicate a question and answer session is now closed'
,p_page_component_map=>'11'
,p_last_updated_by=>'SBKENNED'
,p_last_upd_yyyymmddhh24miss=>'20230920141350'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(129255282314138956105)
,p_plug_name=>'Thanks for participating!'
,p_region_css_classes=>'u-tC'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--noIcon:t-Alert--info'
,p_plug_template=>wwv_flow_imp.id(50176790475853741290)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'This qAsk session (<em>&SESSION_CODE.</em>) has ended. Thank you for your participation.'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(67494111773200184519)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(129255282314138956105)
,p_button_name=>'OK'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(50177335950289741350)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'OK'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'mnw120'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(67628461637109814142)
,p_branch_name=>'home if no session or session is not closed'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':SESSION_ID is null or ',
'qask_util.get_session_status (',
'    p_session_id => :SESSION_ID) != ''CLOSED'''))
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp.component_end;
end;
/
