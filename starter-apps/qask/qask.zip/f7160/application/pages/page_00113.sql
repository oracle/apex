prompt --application/pages/page_00113
begin
--   Manifest
--     PAGE: 00113
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>26987669612026766
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>113
,p_name=>'Question Responses'
,p_alias=>'QUESTION-RESPONSES'
,p_step_title=>'Question Responses'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#APP_FILES#jquery.qrcode.min.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'	jQuery(''#qr_code'').qrcode({',
'        render	: "table",',
'		text	: ''&P113_QR_URL!RAW.''',
'	});'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
':root {',
'    --a-button-gap-x: 1rem;',
'}',
'.qr-container {',
'    min-height: 348px;',
'    display: flex;',
'    align-items: center;',
'    justify-content: center;',
'    flex-direction: column;',
'}',
'#qr_code {',
'    padding: 8px;',
'    background-color: white;',
'}',
'.qr-container h2 {',
'    margin: 0 0 16px 0;',
'    font-weight: 700;',
'}',
'',
'.t-BadgeList + .t-Report-pagination {',
'    display: none;',
'}',
'',
'/* Style Responses Badge */',
'.t-ContextualInfo-label {',
'    position: absolute;',
'    overflow: hidden;',
'    clip: rect(0 0 0 0);',
'    margin: -1px;',
'    padding: 0;',
'    width: 1px;',
'    height: 1px;',
'    border: 0;',
'}',
'.t-ContextualInfo-value {',
'    margin-top: 4px;',
'    padding: 4px 8px;',
'    background: rgba(0,0,0,.1);',
'    border-radius: 4px;',
'    font-weight: 600;',
'    min-width: 32px;',
'    display: block;',
'    text-align: center;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(48299262931897005259)
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(22461915386519837835)
,p_name=>'View Next Question'
,p_template=>wwv_flow_imp.id(48298628869164005152)
,p_display_sequence=>80
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--staticRowColors:t-Report--rowHighlightOff:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select question',
'  from qask_session_questions',
' where id = :P113_NEXT_QUESTION_ID'))
,p_display_when_condition=>'P113_NEXT_QUESTION_ID'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_items_to_submit=>'P113_NEXT_QUESTION_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(48299115114158005187)
,p_query_headings_type=>'NO_HEADINGS'
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(22461915520237837836)
,p_query_column_id=>1
,p_column_alias=>'QUESTION'
,p_column_display_sequence=>10
,p_column_heading=>'Question'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(63277349662168444165)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48299089146885005176)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(48298573222035005128)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(48299151731215005202)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(114008723727929218982)
,p_plug_name=>'Session QR'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:margin-bottom-none'
,p_plug_template=>wwv_flow_imp.id(48298676680325005171)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="qr-container">',
'    <h2 class="u-tC">Scan QR code to participate!</h2>',
'    <div id="qr_code"></div>',
'    <h2 class="u-tC">&P113_SESSION_CODE.</h2>',
'</div>'))
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'qask_util.get_session_status (p_session_id => :P113_SESSION_ID) = ''OPEN'''
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(122577049598548652565)
,p_plug_name=>'question'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48298609867162005145)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(123923389435124511340)
,p_plug_name=>'Button Container'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(48298612707337005146)
,p_plug_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(128640034513355773446)
,p_plug_name=>'Live Responses'
,p_region_name=>'live_responses_chart'
,p_region_css_classes=>'js-refresh-region'
,p_region_template_options=>'#DEFAULT#:t-Region--hideShowIconsMath:is-collapsed:t-Region--noUI:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(48298628869164005152)
,p_plug_display_sequence=>60
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P113_ANSWER_TYPE != ''FREEFORM'''
,p_plug_display_when_cond2=>'SQL'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(63277343266366444156)
,p_region_id=>wwv_flow_imp.id(128640034513355773446)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(63277345028226444159)
,p_chart_id=>wwv_flow_imp.id(63277343266366444156)
,p_seq=>10
,p_name=>'answers'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select qa.answer_text, ',
'       (select count(*) ',
'          from qask_response_answers a ',
'         where :P113_QUESTION_ID = a.question_id',
'           and a.answer_id = qa.id) answer_count',
'   from qask_session_questions q, ',
'        qask_sess_question_answers qa',
'  where q.session_id = :P113_SESSION_ID',
'    and q.id = qa.question_id',
'    and q.id = :P113_QUESTION_ID',
'order by qa.answer_number'))
,p_max_row_count=>100000
,p_ajax_items_to_submit=>'P113_SESSION_CODE'
,p_items_value_column_name=>'ANSWER_COUNT'
,p_items_label_column_name=>'ANSWER_TEXT'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(63277344353670444157)
,p_chart_id=>wwv_flow_imp.id(63277343266366444156)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(63277343786171444156)
,p_chart_id=>wwv_flow_imp.id(63277343266366444156)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_min_step=>1
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(134254842276100031460)
,p_plug_name=>'&P113_QUESTION_NUMBER.. &P113_QUESTION.'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_plug_template=>wwv_flow_imp.id(48298643368493005158)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(123923390581004511351)
,p_name=>'Session Details'
,p_region_name=>'session_details'
,p_parent_plug_id=>wwv_flow_imp.id(134254842276100031460)
,p_template=>wwv_flow_imp.id(48298611319635005145)
,p_display_sequence=>10
,p_region_css_classes=>'js-refresh-region u-pullRight'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select count(r.id) respondents',
'  from qask_responses r,',
'       qask_response_answers a',
' where r.session_id = :P113_SESSION_ID',
'   and r.id = a.response_id',
'   and a.question_id = :P113_QUESTION_ID'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P113_SESSION_CODE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(48299110907603005185)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(63277346371870444162)
,p_query_column_id=>1
,p_column_alias=>'RESPONDENTS'
,p_column_display_sequence=>40
,p_column_heading=>'Participants'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(243463520094885531489)
,p_plug_name=>'Live Responses'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:is-collapsed:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(48298628869164005152)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P113_ANSWER_TYPE = ''FREEFORM'' or',
':P113_ASK_FOR_COMMENTS_YN = ''Y'''))
,p_plug_display_when_cond2=>'SQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(240709440850449467957)
,p_plug_name=>'Answers by Participant'
,p_region_name=>'live_responses_report'
,p_parent_plug_id=>wwv_flow_imp.id(243463520094885531489)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48298666886045005167)
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.name,',
'       r.email,',
'       r.apex_session,',
'       r.user_agent,',
'       r.x_forwarded_for,',
'       r.remote_addr,',
'       a.answer_id,',
'       a.answer_text,',
'       a.comment_text,',
'       a.created_on',
'  from qask_responses r,',
'       qask_response_answers a',
' where r.session_id = :P113_SESSION_ID',
'   and r.id = a.response_id',
'   and :P113_QUESTION_ID = a.question_id',
'order by r.id, a.answer_text'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Answers by Participant'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(240709440929188467958)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MICHAEL.HICHWA@ME.COM'
,p_internal_uid=>238839073197339895270
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(211912677713213056362)
,p_db_column_name=>'ANSWER_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Answer Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137000538663306074771)
,p_db_column_name=>'APEX_SESSION'
,p_display_order=>20
,p_column_identifier=>'U'
,p_column_label=>'Session ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(211912682213488056368)
,p_db_column_name=>'NAME'
,p_display_order=>30
,p_column_identifier=>'R'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P113_RESP_NAME_REQUIRED_YN = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137000538571255074770)
,p_db_column_name=>'EMAIL'
,p_display_order=>40
,p_column_identifier=>'T'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P113_RESP_EMAIL_REQUIRED_YN = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(211912682591840056368)
,p_db_column_name=>'ANSWER_TEXT'
,p_display_order=>60
,p_column_identifier=>'S'
,p_column_label=>'Answer'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137000538997607074774)
,p_db_column_name=>'COMMENT_TEXT'
,p_display_order=>70
,p_column_identifier=>'X'
,p_column_label=>'Comment Text'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P113_ASK_FOR_COMMENTS_YN = ''Y'''
,p_display_condition2=>'SQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(211912681380569056367)
,p_db_column_name=>'USER_AGENT'
,p_display_order=>80
,p_column_identifier=>'K'
,p_column_label=>'User Agent'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137000538831124074772)
,p_db_column_name=>'X_FORWARDED_FOR'
,p_display_order=>90
,p_column_identifier=>'V'
,p_column_label=>'X Forwarded For'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137000538909422074773)
,p_db_column_name=>'REMOTE_ADDR'
,p_display_order=>100
,p_column_identifier=>'W'
,p_column_label=>'Remote Address'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6350340075152326013)
,p_db_column_name=>'CREATED_ON'
,p_display_order=>110
,p_column_identifier=>'Y'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(241960974425459489174)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'300483001'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'APEX_SESSION:NAME:EMAIL:ANSWER_TEXT:COMMENT_TEXT'
,p_sort_column_1=>'CREATED'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(89746036656947983036)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(123923389435124511340)
,p_button_name=>'REFRESH'
,p_button_static_id=>'refresh_button'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(48299150160653005202)
,p_button_image_alt=>'Refresh'
,p_button_position=>'CHANGE'
,p_button_alignment=>'RIGHT'
,p_button_css_classes=>'u-hidden w200 padding-md u-bold'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(59133114720906756030)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(123923389435124511340)
,p_button_name=>'CLOSE_SESSION'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_image_alt=>'Close Session'
,p_button_position=>'CHANGE'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.get_session_status (',
'    p_session_id => :P113_SESSION_ID) = ''OPEN'''))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_button_css_classes=>'w200 padding-md u-bold'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(63277342123822444153)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(123923389435124511340)
,p_button_name=>'CLOSE_QUESTION'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Close Question'
,p_button_position=>'CHANGE'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.get_question_status (',
'    p_question_id => :P113_QUESTION_ID) = ''OPEN'''))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_button_css_classes=>'w200 padding-md u-bold'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(63277342514401444153)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(123923389435124511340)
,p_button_name=>'ASK_NEW_QUESTION'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Ask New Question'
,p_button_position=>'CHANGE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:RR,112:P112_SESSION_ID:&P113_SESSION_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.get_session_status (',
'    p_session_id => :P113_SESSION_ID) = ''OPEN'' and',
':P113_QUESTION_STATUS = ''CLOSED'' and',
':P113_NEXT_QUESTION_ID is null'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_button_css_classes=>'w200 padding-md u-bold'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(22461912769606837809)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(123923389435124511340)
,p_button_name=>'ASK_NEXT_QUESTION'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Ask Next Question'
,p_button_position=>'CHANGE'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.get_session_status (',
'    p_session_id => :P113_SESSION_ID) = ''OPEN''  and',
':P113_QUESTION_STATUS = ''CLOSED'' and',
':P113_NEXT_QUESTION_ID is not null'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_button_css_classes=>'w200 padding-md u-bold'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(63277353827697444168)
,p_branch_name=>'session summary'
,p_branch_action=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.:RR,120:P120_SESSION_ID:&P113_SESSION_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(59133114720906756030)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(22461913006133837811)
,p_branch_name=>'here for next question (for staged)'
,p_branch_action=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:RR,113:P113_SESSION_ID,P113_QUESTION_ID:&P113_SESSION_ID.,&P113_NEXT_QUESTION_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(22461912769606837809)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13898823791474193123)
,p_name=>'P113_QUESTION_STATUS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(122577049598548652565)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(22461912566799837807)
,p_name=>'P113_NEXT_QUESTION_ID'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(122577049598548652565)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55593484933847184963)
,p_name=>'P113_QUESTION_FILE'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(134254842276100031460)
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_session_questions',
' where id = :P113_QUESTION_ID',
'   and question_filename is not null'))
,p_display_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(48299147314651005200)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'SQL'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select question_file',
'  from qask_session_questions',
' where id = :P113_QUESTION_ID'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59133114031681756023)
,p_name=>'P113_SESSION_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(122577049598548652565)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59133114898770756032)
,p_name=>'P113_QR_URL'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(122577049598548652565)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73091907260841028998)
,p_name=>'P113_ANSWER_TYPE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(122577049598548652565)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73091907574097029001)
,p_name=>'P113_RESP_NAME_REQUIRED_YN'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(122577049598548652565)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73091907688808029002)
,p_name=>'P113_RESP_EMAIL_REQUIRED_YN'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(122577049598548652565)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73091907748943029003)
,p_name=>'P113_ASK_FOR_COMMENTS_YN'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(122577049598548652565)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122577050950000652570)
,p_name=>'P113_QUESTION_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(122577049598548652565)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122577052470093652585)
,p_name=>'P113_SESSION_CODE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(122577049598548652565)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(122600577349367493063)
,p_name=>'P113_QUESTION_NUMBER'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(122577049598548652565)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(123016233208299294944)
,p_name=>'P113_SESSION_NAME'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(122577049598548652565)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(123923391099108511348)
,p_name=>'P113_SESSION_STATUS'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(122577049598548652565)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134254843603122031465)
,p_name=>'P113_QUESTION'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(122577049598548652565)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(59133114949709756033)
,p_computation_sequence=>60
,p_computation_item=>'P113_QR_URL'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    x  varchar2(4000);',
'begin ',
'    x := apex_page.get_url (',
'           p_page => ''home'',',
'           p_session => 0,',
'           p_items => ''P1_CODE'',',
'           p_values => :P113_SESSION_CODE );',
'    x := substr(x,1,instr(x,''&'')-1);',
'',
'    return rtrim(owa_util.get_cgi_env(''HTTP_REFERER''),''/'') || x;',
'end;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(63277352822762444167)
,p_name=>'Auto Refresh'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_display_when_cond=>'P113_QUESTION_STATUS'
,p_display_when_cond2=>'CLOSED'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(63277353253722444168)
,p_event_id=>wwv_flow_imp.id(63277352822762444167)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i = 0;',
'var interval = setInterval(function(){',
'    i += 1;',
'    if(i === 90){',
'        clearInterval(interval);',
'        $("#refresh_button").removeClass(''u-hidden'');',
'    }',
'    apex.region("session_details").refresh();',
'    if (apex.region("live_responses_chart")) {',
'        apex.region("live_responses_chart").refresh();',
'    }',
'    if (apex.region("live_responses_report")) {',
'        console.log(''refreshing report'');',
'        apex.region("live_responses_report").refresh();',
'    }',
'}, 3000);',
'',
'',
'',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(63277352336412444167)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Close Question'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.close_question (',
'    p_question_id => :P113_QUESTION_ID );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(63277342123822444153)
,p_internal_uid=>61406984604563871479
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(59133114787254756031)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Close Session'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.close_session (',
'    p_session_id => :P113_SESSION_ID );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(59133114720906756030)
,p_process_success_message=>'Session Closed.'
,p_internal_uid=>57262747055406183343
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(22461912860661837810)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Next Question (for staged)'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P113_NEXT_QUESTION_ID := qask_util.get_next_question_id (',
'                             p_session_id  => :P113_SESSION_ID,',
'                             p_question_id => :P113_QUESTION_ID,',
'                             p_status      => ''ANY'' );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(63277342123822444153)
,p_internal_uid=>20591545128813265122
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(22461913120180837812)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Open Next Question (for staged)'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.start_staged_question (',
'    p_question_id => :P113_NEXT_QUESTION_ID );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(22461912769606837809)
,p_internal_uid=>20591545388332265124
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(73148829425208026051)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'get session details'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_dont_need  varchar2(4000);',
'begin',
'qask_util.get_session_details (',
'    p_session_id             => :P113_SESSION_ID,',
'    p_session_name           => :P113_SESSION_NAME,',
'    p_session_code           => :P113_SESSION_CODE,',
'    p_purpose                => l_dont_need,',
'    p_resp_name_required_yn  => :P113_RESP_NAME_REQUIRED_YN,',
'    p_resp_email_required_yn => :P113_RESP_EMAIL_REQUIRED_YN,',
'    p_session_status         => :P113_SESSION_STATUS );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>71278461693359453363
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(69891793931837104596)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'get question details'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_dont_need  varchar2(4000);',
'begin',
'qask_util.get_question_details (',
'    p_question_id          => :P113_QUESTION_ID,',
'    p_question_number      => :P113_QUESTION_NUMBER,',
'    p_question_status      => :P113_QUESTION_STATUS,',
'    p_question             => :P113_QUESTION,',
'    p_answer_type          => :P113_ANSWER_TYPE,',
'    p_ask_for_comments_yn  => :P113_ASK_FOR_COMMENTS_YN,',
'    p_question_explanation => l_dont_need );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>68021426199988531908
);
wwv_flow_imp.component_end;
end;
/
