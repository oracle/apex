prompt --application/pages/page_00120
begin
--   Manifest
--     PAGE: 00120
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>26987669612026766
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>120
,p_name=>'Session Summary'
,p_alias=>'SESSION-SUMMARY'
,p_step_title=>'Session Summary'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-ContentRow-misc {',
'    min-width: 150px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(48299262931897005259)
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(72608301991990491869)
,p_plug_name=>'Breadcrumb'
,p_region_sub_css_classes=>'has-header-actions'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48299089146885005176)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(48298573222035005128)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(48299151731215005202)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54401104939095331005)
,p_plug_name=>'Actions Menu'
,p_region_name=>'page_actions'
,p_parent_plug_id=>wwv_flow_imp.id(72608301991990491869)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48298611319635005145)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_list_id=>wwv_flow_imp.id(55640771471003049182)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(48299136929620005196)
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions',
' where id = :P120_SESSION_ID',
'   and session_status in (''STAGED'',''CLOSED'')',
'   and owner = lower(:APP_USER)'))
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(72627239851007781395)
,p_name=>'&P120_SESSION_NAME.'
,p_template=>wwv_flow_imp.id(48298638662514005156)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h2'
,p_component_template_options=>'#DEFAULT#:t-ContextualInfo-label--stacked:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       OWNER,',
'       SESSION_CODE,',
'       initcap(session_status) status,',
'       closed_on DATE_CLOSED,',
'       ROW_VERSION,',
'       CREATED_ON CREATED,',
'       started_on,',
'       CREATED_BY,',
'       UPDATED_ON UPDATED,',
'       UPDATED_BY,',
'       PURPOSE,',
'       case when RESP_NAME_REQUIRED_YN = ''Y'' then ''Yes'' else ''No'' end resp_name_required,',
'       case when RESP_EMAIL_REQUIRED_YN = ''Y'' then ''Yes'' else ''No'' end resp_email_required,',
'       SESSION_NAME,',
'       case when length_minutes is not null',
'            then case when LENGTH_MINUTES < 60',
'                 then round(LENGTH_MINUTES)||'' minutes''',
'                 else round(LENGTH_MINUTES/60,1)||'' hours'' end ',
'            end length,',
'       (select count(*) from qask_session_questions ',
'         where session_id = s.id) question_count,',
'       (select count(*) from qask_responses ',
'         where session_id = s.id) response_count',
'  from QASK_SESSIONS s',
' where id = :P120_SESSION_ID',
'   and owner = lower(:APP_USER)'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P120_SESSION_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(48299110907603005185)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(72627239987399781396)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(72627240033838781397)
,p_query_column_id=>2
,p_column_alias=>'OWNER'
,p_column_display_sequence=>20
,p_column_heading=>'Owner'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(72627240170181781398)
,p_query_column_id=>3
,p_column_alias=>'SESSION_CODE'
,p_column_display_sequence=>30
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(22461913181391837813)
,p_query_column_id=>4
,p_column_alias=>'STATUS'
,p_column_display_sequence=>100
,p_column_heading=>'Status'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(72627240480940781401)
,p_query_column_id=>5
,p_column_alias=>'DATE_CLOSED'
,p_column_display_sequence=>150
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(72627240590534781402)
,p_query_column_id=>6
,p_column_alias=>'ROW_VERSION'
,p_column_display_sequence=>160
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(72627240641844781403)
,p_query_column_id=>7
,p_column_alias=>'CREATED'
,p_column_display_sequence=>120
,p_column_heading=>'Created'
,p_use_as_row_header=>'N'
,p_column_format=>'fmMonth fmDD, YYYY'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions',
' where id = :P120_SESSION_ID',
'   and started_on is null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(22461912252465837804)
,p_query_column_id=>8
,p_column_alias=>'STARTED_ON'
,p_column_display_sequence=>130
,p_column_heading=>'Started'
,p_use_as_row_header=>'N'
,p_column_format=>'fmMonth DD, YYYY'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions',
' where id = :P120_SESSION_ID',
'   and started_on is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(72627240792857781404)
,p_query_column_id=>9
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>170
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(72627240869999781405)
,p_query_column_id=>10
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>180
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(72627241013716781406)
,p_query_column_id=>11
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>190
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(72627241113910781407)
,p_query_column_id=>12
,p_column_alias=>'PURPOSE'
,p_column_display_sequence=>60
,p_column_heading=>'Purpose'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions',
' where id = :P120_SESSION_ID',
'   and purpose is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(72627242153710781418)
,p_query_column_id=>13
,p_column_alias=>'RESP_NAME_REQUIRED'
,p_column_display_sequence=>220
,p_column_heading=>'Participant Name Required'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions',
' where id = :P120_SESSION_ID',
'   and resp_name_required_yn  = ''Y'''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(72627242257065781419)
,p_query_column_id=>14
,p_column_alias=>'RESP_EMAIL_REQUIRED'
,p_column_display_sequence=>230
,p_column_heading=>'Participant Email Required'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions',
' where id = :P120_SESSION_ID',
'   and resp_email_required_yn  = ''Y'''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(72627241387303781410)
,p_query_column_id=>15
,p_column_alias=>'SESSION_NAME'
,p_column_display_sequence=>40
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(90116896737330107211)
,p_query_column_id=>16
,p_column_alias=>'LENGTH'
,p_column_display_sequence=>140
,p_column_heading=>'Length'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from QASK_SESSIONS s',
' where id = :P120_SESSION_ID',
'   and owner = lower(:APP_USER)',
'   and length_minutes is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(72627241581464781412)
,p_query_column_id=>17
,p_column_alias=>'QUESTION_COUNT'
,p_column_display_sequence=>200
,p_column_heading=>'Questions'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(22461912420082837805)
,p_query_column_id=>18
,p_column_alias=>'RESPONSE_COUNT'
,p_column_display_sequence=>210
,p_column_heading=>'Participants'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_responses',
' where session_id = :P120_SESSION_ID'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(72627242793619781424)
,p_plug_name=>'Participants'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(48298628869164005152)
,p_plug_display_sequence=>60
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 ',
'  from qask_responses',
' where session_id = :P120_SESSION_ID'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(65750279256470078029)
,p_plug_name=>'Participants Report'
,p_parent_plug_id=>wwv_flow_imp.id(72627242793619781424)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48298666886045005167)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       APEX_SESSION,',
'       NAME,',
'       EMAIL,',
'       USER_AGENT,',
'       X_FORWARDED_FOR,',
'       REMOTE_ADDR,',
'       ROW_VERSION,',
'       CREATED_ON CREATED,',
'       CREATED_BY,',
'       UPDATED_ON UPDATED,',
'       UPDATED_BY,',
'       SESSION_ID,',
'       (select count(unique question_id) from qask_response_answers',
'         where response_id = r.id) questions_answered',
'  from QASK_RESPONSES r',
' where session_id = :P120_SESSION_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Participants Report'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(65750279356508078030)
,p_max_row_count=>'1000000'
,p_max_rows_per_page=>'15'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'SBKENNED'
,p_internal_uid=>63879911624659505342
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(65750279433062078031)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(65750279592505078032)
,p_db_column_name=>'APEX_SESSION'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Session ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(72627239765282781394)
,p_db_column_name=>'QUESTIONS_ANSWERED'
,p_display_order=>40
,p_column_identifier=>'N'
,p_column_label=>'Questions Answered'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(65750279667563078033)
,p_db_column_name=>'NAME'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.session_resp_name_req_yn (',
'    p_session_id => :P120_SESSION_ID ) = ''Y'''))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(65750279803453078034)
,p_db_column_name=>'EMAIL'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.session_resp_email_req_yn (',
'    p_session_id => :P120_SESSION_ID ) = ''Y'''))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(65750279857355078035)
,p_db_column_name=>'USER_AGENT'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'User Agent'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(65750279942817078036)
,p_db_column_name=>'X_FORWARDED_FOR'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>'X Forwarded For'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(65750280084183078037)
,p_db_column_name=>'REMOTE_ADDR'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'Remote Addr'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(65750280169531078038)
,p_db_column_name=>'ROW_VERSION'
,p_display_order=>110
,p_column_identifier=>'H'
,p_column_label=>'Row Version'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(72627239321735781389)
,p_db_column_name=>'CREATED'
,p_display_order=>120
,p_column_identifier=>'I'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'DD-MON-YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(72627239392429781390)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>130
,p_column_identifier=>'J'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(72627239452576781391)
,p_db_column_name=>'UPDATED'
,p_display_order=>140
,p_column_identifier=>'K'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(72627239619720781392)
,p_db_column_name=>'UPDATED_BY'
,p_display_order=>150
,p_column_identifier=>'L'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(72627239649031781393)
,p_db_column_name=>'SESSION_ID'
,p_display_order=>160
,p_column_identifier=>'M'
,p_column_label=>'Session Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(72634679374864893416)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'707643117'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'APEX_SESSION:QUESTIONS_ANSWERED:NAME:EMAIL:USER_AGENT:X_FORWARDED_FOR:REMOTE_ADDR:'
,p_sort_column_1=>'CREATED'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(87595084310877459026)
,p_plug_name=>'Questions'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48298611319635005145)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       SESSION_ID,',
'       QUESTION,',
'       QUESTION_NUMBER,',
'       ANSWER_TYPE,',
'       case when ask_for_comments_yn = ''Y'' then ''asked for comments'' end ask_for_comments,',
'       question_status,',
'       dbms_lob.substr(QUESTION_EXPLANATION,255) ||',
'           case when dbms_lob.getlength(question_explanation) > 255 then ''...'' end question_explanation,',
'       case when length is not null then ''Open ''||length end length,',
'       CREATED,',
'       case when QUESTION_STATUS in (''OPEN'',''CLOSED'') ',
'            then responses||case when responses = 1 then '' response'' else '' responses'' end ',
'            end responses,',
'       case when length(answers) > 255 then substr(answers,1,255)||''...'' else answers end answers,',
'       question_url',
'from (',
'select ID,',
'       SESSION_ID,',
'       QUESTION,',
'       QUESTION_NUMBER,',
'       (select display_value from APEX_APPLICATION_LOV_ENTRIES',
'         where LIST_OF_VALUES_NAME = ''ANSWER TYPE''',
'           and application_id = :APP_ID',
'           and return_value = ANSWER_TYPE)||',
'           case when answer_type != ''FREEFORM'' then '':'' end answer_type,',
'       ask_for_comments_yn,',
'       QUESTION_STATUS,',
'       QUESTION_EXPLANATION,',
'       case when length_seconds is not null',
'            then case when length_seconds < 60',
'                 then round(length_seconds)||'' seconds''',
'                 when length_seconds/60 > 60 ',
'                 then round(LENGTH_SECONDS/(60*60),1)||'' hours''',
'                else round(LENGTH_SECONDS/60,1)||'' minutes'' end ',
'            end length,',
'       CREATED_ON CREATED,',
'       (select count(unique response_id)',
'          from qask_response_answers',
'         where question_id = q.id) responses,',
'       case when answer_set_id is not null then (select answer_set_name from qask_answer_sets a',
'                                                  where q.answer_set_id =  a.id)  ',
'            when answer_type != ''FREEFORM'' then (select listagg(answer_text,'', '') within group (order by answer_number)',
'                                                   from qask_sess_question_answers ',
'                                                  where question_id = q.id)',
'            end answers,',
'       case when question_status = ''OPEN'' ',
'            then apex_page.get_url(',
'                     p_page => 113,',
'                     p_items => ''P113_SESSION_ID,P113_QUESTION_ID'',',
'                     p_values => session_id||'',''||id,',
'                     p_clear_cache => 113)',
'            else apex_page.get_url(',
'                     p_page => 121,',
'                     p_items => ''P121_SESSION_ID,P121_QUESTION_ID'',',
'                     p_values => session_id||'',''||id,',
'                     p_clear_cache => 121)',
'            end question_url',
'  from QASK_SESSION_QUESTIONS q',
' where session_id = :P120_SESSION_ID',
')',
'order by question_number'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_ajax_items_to_submit=>'P120_SESSION_ID'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_plug_query_no_data_found=>'No questions'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'N',
  'AVATAR_ICON', 'fa-user',
  'AVATAR_SHAPE', 't-Avatar--rounded',
  'AVATAR_TYPE', 'icon',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--md',
  'BADGE_LABEL_DISPLAY', 'N',
  'DESCRIPTION', '{if QUESTION_EXPLANATION/}&QUESTION_EXPLANATION.<br/>{endif/} &ANSWER_TYPE. &ANSWERS. {if ASK_FOR_COMMENTS/}<br/>&ASK_FOR_COMMENTS.{endif/}',
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'MISC', '&LENGTH.<br/>&RESPONSES.',
  'REMOVE_PADDING', 'N',
  'TITLE', '&QUESTION_NUMBER.. &QUESTION.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(90116894757871107191)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(90116894832269107192)
,p_name=>'SESSION_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SESSION_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(90116895019833107193)
,p_name=>'QUESTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QUESTION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(90116895129078107194)
,p_name=>'QUESTION_NUMBER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QUESTION_NUMBER'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(90116895300778107196)
,p_name=>'ANSWER_TYPE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ANSWER_TYPE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(90116895468914107198)
,p_name=>'QUESTION_STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QUESTION_STATUS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>80
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(90116895541581107199)
,p_name=>'QUESTION_EXPLANATION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QUESTION_EXPLANATION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(90116895783684107201)
,p_name=>'CREATED'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>110
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(90116895887641107202)
,p_name=>'RESPONSES'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RESPONSES'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>120
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(90116896003742107203)
,p_name=>'ANSWERS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ANSWERS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>130
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(90116896211318107205)
,p_name=>'ASK_FOR_COMMENTS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ASK_FOR_COMMENTS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>140
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(90116896319072107206)
,p_name=>'LENGTH'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LENGTH'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>150
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(90116896392942107207)
,p_name=>'QUESTION_URL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QUESTION_URL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>160
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61039348605811697601)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(72608301991990491869)
,p_button_name=>'CLOSE_SESSION'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_image_alt=>'Close Session'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions',
' where id = :P120_SESSION_ID',
'   and session_status = ''OPEN''',
'   and owner = lower(:APP_USER)'))
,p_button_condition_type=>'EXISTS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(54401105151848331007)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(72608301991990491869)
,p_button_name=>'Ask_Question'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Ask Question'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:112:P112_SESSION_ID:&P120_SESSION_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions',
' where id = :P120_SESSION_ID',
'   and session_status = ''OPEN''',
'   and owner = lower(:APP_USER)'))
,p_button_condition_type=>'EXISTS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(54401105296378331008)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(72608301991990491869)
,p_button_name=>'Start_Session'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Start Session'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.:114:P114_SESSION_ID:&P120_SESSION_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions s',
' where id = :P120_SESSION_ID',
'   and session_status = ''STAGED''',
'   and owner = lower(:APP_USER)',
'   and exists (select 1 from qask_session_questions',
'                where session_id = s.id)'))
,p_button_condition_type=>'EXISTS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(54401105077263331006)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(72608301991990491869)
,p_button_name=>'ACTIONS_MENU'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(48299149427643005201)
,p_button_image_alt=>'Actions Menu'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions',
' where id = :P120_SESSION_ID',
'   and session_status in (''STAGED'',''CLOSED'')',
'   and owner = lower(:APP_USER)'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-ellipsis-v'
,p_button_cattributes=>'data-menu="page_actions_menu"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(54401104793836331003)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(72608301991990491869)
,p_button_name=>'Up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(48299149427643005201)
,p_button_image_alt=>'Navigate Up'
,p_button_position=>'UP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:120::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65750278773121078024)
,p_name=>'P120_SESSION_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(72627239851007781395)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65750278887648078025)
,p_name=>'P120_SESSION_CODE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(72627239851007781395)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65750278981143078026)
,p_name=>'P120_SESSION_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(72627239851007781395)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(65750279067128078027)
,p_computation_sequence=>10
,p_computation_item=>'P120_SESSION_CODE'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return qask_util.get_session_code (',
'    p_session_id => :P120_SESSION_ID );'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(65750279134911078028)
,p_computation_sequence=>20
,p_computation_item=>'P120_SESSION_NAME'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return qask_util.get_session_name (',
'    p_session_id => :P120_SESSION_ID );'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(61039807622250702226)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Close Session'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.close_session (',
'    p_session_id => :P120_SESSION_ID );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(61039348605811697601)
,p_process_success_message=>'Session Closed.'
,p_internal_uid=>59169439890402129538
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(90116896060520107204)
,p_region_id=>wwv_flow_imp.id(87595084310877459026)
,p_position_id=>wwv_flow_imp.id(50094037761331491794)
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'&QUESTION_URL.'
);
wwv_flow_imp.component_end;
end;
/
