prompt --application/pages/page_00115
begin
--   Manifest
--     PAGE: 00115
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>26987669612026766
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>115
,p_name=>'Copy Session'
,p_alias=>'COPY-SESSION'
,p_step_title=>'Copy Session'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(59031070625736654799)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-HeroRegion-title {',
'    display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(48299262931897005259)
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_comment=>'Start a new Q&A session and asks the first session question'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79489651219515015978)
,p_plug_name=>'Start Session'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(48298676680325005171)
,p_plug_display_sequence=>30
,p_query_type=>'TABLE'
,p_query_table=>'QASK_SESSIONS'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(101459037167812086401)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48299089146885005176)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(48298573222035005128)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(48299151731215005202)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(53722942884543279450)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(101459037167812086401)
,p_button_name=>'Cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_image_alt=>'Cancel'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:RR,111::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(53722942495516279449)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(101459037167812086401)
,p_button_name=>'COPY_SESSION'
,p_button_static_id=>'START_SESSION'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Copy Session'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(53722955294042279463)
,p_branch_name=>'branch to session summary'
,p_branch_action=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.:RR,120:P120_SESSION_ID:&P115_NEW_SESSION_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(22461914515274837826)
,p_name=>'P115_NEW_SESSION_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(79489651219515015978)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79489654009560015988)
,p_name=>'P115_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(79489651219515015978)
,p_item_source_plug_id=>wwv_flow_imp.id(79489651219515015978)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79489654066317015989)
,p_name=>'P115_OWNER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(79489651219515015978)
,p_item_source_plug_id=>wwv_flow_imp.id(79489651219515015978)
,p_source=>'OWNER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79489654194791015990)
,p_name=>'P115_SESSION_CODE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(79489651219515015978)
,p_item_source_plug_id=>wwv_flow_imp.id(79489651219515015978)
,p_source=>'SESSION_CODE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79489654543130015994)
,p_name=>'P115_ROW_VERSION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(79489651219515015978)
,p_item_source_plug_id=>wwv_flow_imp.id(79489651219515015978)
,p_source=>'ROW_VERSION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79489655071816015999)
,p_name=>'P115_PURPOSE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(79489651219515015978)
,p_item_source_plug_id=>wwv_flow_imp.id(79489651219515015978)
,p_prompt=>'Purpose'
,p_source=>'PURPOSE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>2
,p_field_template=>wwv_flow_imp.id(48299147594594005200)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79489655215382016000)
,p_name=>'P115_RESP_NAME_REQUIRED_YN'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(79489651219515015978)
,p_item_source_plug_id=>wwv_flow_imp.id(79489651219515015978)
,p_prompt=>'Participant Name Required'
,p_source=>'RESP_NAME_REQUIRED_YN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(48299147594594005200)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79489655270827016001)
,p_name=>'P115_RESP_EMAIL_REQUIRED_YN'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(79489651219515015978)
,p_item_source_plug_id=>wwv_flow_imp.id(79489651219515015978)
,p_prompt=>'Participant Email Required'
,p_source=>'RESP_EMAIL_REQUIRED_YN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(48299147594594005200)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(110985687635042462760)
,p_name=>'P115_SESSION_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(79489651219515015978)
,p_item_source_plug_id=>wwv_flow_imp.id(79489651219515015978)
,p_prompt=>'Session Name'
,p_source=>'SESSION_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(48299148844301005201)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(53722952692993279461)
,p_validation_name=>'prevent dup names'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.new_session_name_ok_yn (',
'    p_session_name => :P115_SESSION_NAME,',
'    p_app_user     => lower(:APP_USER)) = ''Y'''))
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'You already have a session "&P115_SESSION_NAME.", please enter a different name.'
,p_associated_item=>wwv_flow_imp.id(110985687635042462760)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(53722953395454279461)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'copy session'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P115_NEW_SESSION_ID := qask_util.copy_session (',
'                            p_from_session_id        => :P115_ID,',
'                            p_app_user               => lower(:APP_USER),',
'                            p_session_name           => :P115_SESSION_NAME,',
'                            p_purpose                => :P115_PURPOSE,',
'                            p_resp_name_required_yn  => :P115_RESP_NAME_REQUIRED_YN,',
'                            p_resp_email_required_yn => :P115_RESP_EMAIL_REQUIRED_YN,',
'                            p_session_status         => ''STAGED'' );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Session copied.'
,p_internal_uid=>51852585663605706773
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(22461914419197837825)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(79489651219515015978)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Load session to copy'
,p_internal_uid=>20591546687349265137
);
wwv_flow_imp.component_end;
end;
/
