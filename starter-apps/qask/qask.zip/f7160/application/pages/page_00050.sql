prompt --application/pages/page_00050
begin
--   Manifest
--     PAGE: 00050
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>50
,p_name=>'Host Your Own Sessions'
,p_alias=>'HOST-YOUR-OWN'
,p_page_mode=>'MODAL'
,p_step_title=>'Host Your Own Sessions'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>1661186590416509825
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_required_role=>wwv_flow_imp.id(7599480032474820827)
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4194394175517696177)
,p_plug_name=>'Host Your Own Sessions'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'QASK_ACCOUNT_REQUESTS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_header=>'You are requesting access to host your own sessions.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4194406682469696188)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4194407122966696188)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4194406682469696188)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4194409311710696190)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(4194406682469696188)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4194394508386696178)
,p_name=>'P50_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4194394175517696177)
,p_item_source_plug_id=>wwv_flow_imp.id(4194394175517696177)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4194395661689696179)
,p_name=>'P50_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(4194394175517696177)
,p_item_source_plug_id=>wwv_flow_imp.id(4194394175517696177)
,p_prompt=>'Your Email'
,p_source=>'EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4194396113071696180)
,p_name=>'P50_JUSTIFICATION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(4194394175517696177)
,p_item_source_plug_id=>wwv_flow_imp.id(4194394175517696177)
,p_prompt=>'Justification'
,p_source=>'JUSTIFICATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>2
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4194396539665696180)
,p_name=>'P50_ACCEPTED_TERMS_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(4194394175517696177)
,p_item_source_plug_id=>wwv_flow_imp.id(4194394175517696177)
,p_source=>'ACCEPTED_TERMS_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73645486843471401339)
,p_name=>'P50_TERMS'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(4194394175517696177)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Terms of Use'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select service_terms',
'  from qask_service_terms',
' where id = :P50_ACCEPTED_TERMS_ID'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P50_ACCEPTED_TERMS_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--normalDisplay'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'format', 'HTML',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(73645487174070401343)
,p_computation_sequence=>10
,p_computation_item=>'P50_ACCEPTED_TERMS_ID'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>'return qask_util.get_latest_service_terms_id;'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13918879879970017721)
,p_computation_sequence=>10
,p_computation_item=>'P50_EMAIL'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'SQL'
,p_computation=>'lower(:P50_EMAIL)'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(6459222088287181567)
,p_validation_name=>'email valid'
,p_validation_sequence=>10
,p_validation=>'P50_EMAIL'
,p_validation2=>'[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>'Email is not valid'
,p_when_button_pressed=>wwv_flow_imp.id(4194409311710696190)
,p_associated_item=>wwv_flow_imp.id(4194395661689696179)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(13918879782293017720)
,p_validation_name=>'in domains (if restriction enabled)'
,p_validation_sequence=>20
,p_validation=>'qask_util.in_restricted_domains_yn (p_email => :P50_EMAIL) = ''Y'''
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Email domain not allowed'
,p_validation_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.get_setting(''restrict_requests_to_email_domains_yn'') = ''Y'' or',
'qask_util.get_setting(''restrict_users_to_email_domains_yn'') = ''Y'''))
,p_validation_condition2=>'SQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(4194409311710696190)
,p_associated_item=>wwv_flow_imp.id(4194395661689696179)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4194407206999696188)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(4194407122966696188)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4194408003557696189)
,p_event_id=>wwv_flow_imp.id(4194407206999696188)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(73645486861171401340)
,p_process_sequence=>5
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'request_access'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.request_access (',
'    p_email         => lower(:P50_EMAIL),',
'    p_justification => :P50_JUSTIFICATION,',
'    p_app_id        => :APP_ID,',
'    p_app_url       => :APP_URL,',
'    p_service_terms_id => :P50_ACCEPTED_TERMS_ID );'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Request failed to be submitted.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(4194409311710696190)
,p_process_success_message=>'Request Submitted.'
,p_internal_uid=>71755061614737004040
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(4194410604438696191)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(4194409311710696190)
,p_internal_uid=>2303985358004298891
);
wwv_flow_imp.component_end;
end;
/
