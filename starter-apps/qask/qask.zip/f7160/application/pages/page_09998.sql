prompt --application/pages/page_09998
begin
--   Manifest
--     PAGE: 09998
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1843380062236545922
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>9998
,p_name=>'User Verification'
,p_alias=>'VERIFICATION'
,p_step_title=>'qAsk Verification'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.app-Form-fieldContainer--verificationCode input.apex-item-text { height: 72px; font-size: 40px; line-height: 72px; }',
'.apex-item-text.apex-page-item-error:focus { border-color: #ff6448 !important; }',
'#P1_VERIFICATION_CODE_CONTAINER .t-Form-error { color: #ff6448 !important; font-weight: bold; }',
'.t-Alert--wizard .t-Alert-title { font-weight: 700; font-size: 32px; }',
'.t-Alert--wizard .t-Alert-body { text-align: center; margin-left: auto; margin-right: auto; }'))
,p_step_template=>wwv_flow_imp.id(48271596882053978368)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_component_map=>'17'
,p_last_updated_by=>'SBKENNED'
,p_last_upd_yyyymmddhh24miss=>'20240405204556'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6323350182301299225)
,p_plug_name=>'qAsk User Verification'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48271683857483978403)
,p_plug_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13871832773305166324)
,p_plug_name=>'token maxed'
,p_parent_plug_id=>wwv_flow_imp.id(6323350182301299225)
,p_icon_css_classes=>'fa-exclamation-circle'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--warning:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(48271616986112978376)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>No more access attempts left, request a new token.</p>'
,p_translate_title=>'N'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9998_IS_ACCOUNT_LOCKED_YN = ''N'' and',
':P9998_IS_TOKEN_MAXED_YN = ''Y'''))
,p_plug_display_when_cond2=>'SQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13871833318962166329)
,p_plug_name=>'account locked'
,p_parent_plug_id=>wwv_flow_imp.id(6323350182301299225)
,p_icon_css_classes=>'fa-exclamation-circle'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--danger:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(48271616986112978376)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'Maximum verification attempts exceeded.   Account will reset in &P9998_RESET_VERIFY_AFTER_X_HOURS. hours.'
,p_translate_title=>'N'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P9998_IS_ACCOUNT_LOCKED_YN = ''Y'''
,p_plug_display_when_cond2=>'SQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13871833409172166330)
,p_plug_name=>'for token'
,p_parent_plug_id=>wwv_flow_imp.id(6323350182301299225)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48271622197549978379)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_translate_title=>'N'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9998_IS_ACCOUNT_LOCKED_YN = ''N'' and',
':P9998_IS_TOKEN_MAXED_YN = ''N'''))
,p_plug_display_when_cond2=>'SQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13871833931925166335)
,p_plug_name=>'for cancel'
,p_parent_plug_id=>wwv_flow_imp.id(6323350182301299225)
,p_icon_css_classes=>'fa-exclamation-circle'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48271622197549978379)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_translate_title=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6323350526147299228)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(13871833931925166335)
,p_button_name=>'cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(48272162460548978436)
,p_button_image_alt=>'Cancel'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:9998::'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6323350412565299227)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(13871833409172166330)
,p_button_name=>'VERIFY'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>wwv_flow_imp.id(48272162460548978436)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Verify'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(10880097540181154628)
,p_branch_name=>'go to login if P9998_USERNAME is null'
,p_branch_action=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:9998,9999::'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'ITEM_IS_NULL'
,p_branch_condition=>'P9998_USERNAME'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6323350273481299226)
,p_name=>'P9998_USERNAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(13871833409172166330)
,p_prompt=>'Username'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(48272159924981978434)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6323354086742299264)
,p_name=>'P9998_CODE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(13871833409172166330)
,p_prompt=>'Verification Code'
,p_placeholder=>'000000'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>6
,p_cMaxlength=>6
,p_tag_css_classes=>'w260 margin-auto u-tC'
,p_tag_attributes=>'inputmode="numeric" pattern="[0-9]*" autocomplete="one-time-code"'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9998_IS_ACCOUNT_LOCKED_YN = ''N'' and',
':P9998_IS_TOKEN_MAXED_YN = ''N'''))
,p_display_when2=>'SQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(48272159645038978434)
,p_item_css_classes=>'app-Form-fieldContainer--verificationCode'
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13871832947069166325)
,p_name=>'P9998_IS_ACCOUNT_LOCKED_YN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(13871833409172166330)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13871833038801166326)
,p_name=>'P9998_IS_TOKEN_MAXED_YN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(13871833409172166330)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13871834038297166336)
,p_name=>'P9998_RESET_VERIFY_AFTER_X_HOURS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(13871833318962166329)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13871834157034166337)
,p_computation_sequence=>10
,p_computation_item=>'P9998_RESET_VERIFY_AFTER_X_HOURS'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'qask_util.get_setting(''reset_verify_after_x_hours'')'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10880097624359154629)
,p_computation_sequence=>10
,p_computation_item=>'P9998_CODE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13871833157732166327)
,p_computation_sequence=>20
,p_computation_item=>'P9998_IS_TOKEN_MAXED_YN'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'qask_util.is_token_maxed_yn (p_username => :P9998_USERNAME)'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(13871833195079166328)
,p_computation_sequence=>30
,p_computation_item=>'P9998_IS_ACCOUNT_LOCKED_YN'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'qask_util.is_account_locked_yn (p_username => :P9998_USERNAME)'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12579155933390086820)
,p_name=>'Only Allow Numbers'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9998_CODE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keypress'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12579156294781086823)
,p_event_id=>wwv_flow_imp.id(12579155933390086820)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (this.browserEvent.key.length === 1 && /\D/.test(this.browserEvent.key)) {',
'    this.browserEvent.preventDefault();',
'}'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13871837144535166367)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'redirect to login when token maxed'
,p_process_sql_clob=>'apex_util.redirect_url(apex_util.prepare_url(''f?p=''||:APP_ID||'':login:''||:APP_SESSION||'':NEWCODE:::P9999_USERNAME:''||:P9998_USERNAME)); '
,p_process_clob_language=>'PLSQL'
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9998_IS_ACCOUNT_LOCKED_YN = ''N'' and',
':P9998_IS_TOKEN_MAXED_YN = ''Y'''))
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'SQL'
,p_internal_uid=>12028457082298620445
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10839168411435401611)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Set Username Cookie'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_AUTHENTICATION'
,p_attribute_04=>'SEND_LOGIN_USERNAME_COOKIE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8995788349198855689
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10839168840483401613)
,p_page_process_id=>wwv_flow_imp.id(10839168411435401611)
,p_page_id=>9998
,p_name=>'p_username'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>1
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':P9998_USERNAME'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10880098989064154643)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'login'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_AUTHENTICATION'
,p_attribute_04=>'LOGIN'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>9036718926827608721
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10880099073955154644)
,p_page_process_id=>wwv_flow_imp.id(10880098989064154643)
,p_page_id=>9998
,p_name=>'p_username'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9998_USERNAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10880099178077154645)
,p_page_process_id=>wwv_flow_imp.id(10880098989064154643)
,p_page_id=>9998
,p_name=>'p_password'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9998_CODE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10880099305233154646)
,p_page_process_id=>wwv_flow_imp.id(10880098989064154643)
,p_page_id=>9998
,p_name=>'p_uppercase_username'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>30
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10880099425160154647)
,p_page_process_id=>wwv_flow_imp.id(10880098989064154643)
,p_page_id=>9998
,p_name=>'p_set_persistent_auth'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>40
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp.component_end;
end;
/
