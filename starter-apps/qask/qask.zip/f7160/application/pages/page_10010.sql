prompt --application/pages/page_10010
begin
--   Manifest
--     PAGE: 10010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>26987669612026766
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10010
,p_name=>'Emails From'
,p_alias=>'EMAILS-FROM'
,p_step_title=>'Emails From Setting'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(48298584551666005134)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(48299262763877005259)
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64976193231133842770)
,p_plug_name=>'qAsk Emails From Setting'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48298671527096005169)
,p_plug_display_sequence=>20
,p_plug_header=>'This is the email address that the verification codes will be sent from (can be a noreply@somewhere.org).  The application cannot be used without providing a setting.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(60483724560235940789)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(64976193231133842770)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(54401106069970331016)
,p_branch_name=>'Go To Sessions'
,p_branch_action=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:10010::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54401106139864331017)
,p_name=>'P10010_FROM_EMAIL'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(64976193231133842770)
,p_item_default=>'return qask_util.get_setting(p_name => ''from_email'');'
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'From Email'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(48299148844301005201)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(60489698132456023309)
,p_validation_name=>'email valid'
,p_validation_sequence=>10
,p_validation=>'P10010_FROM_EMAIL'
,p_validation2=>'[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>'Email is not valid'
,p_associated_item=>wwv_flow_imp.id(54401106139864331017)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(60483729598753940794)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update settings'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.set_setting (',
'    p_name  => ''from_email'',',
'    p_value => :P10010_FROM_EMAIL );'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Settings failed to be saved.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Settings saved.'
,p_internal_uid=>58613361866905368106
);
wwv_flow_imp.component_end;
end;
/
