prompt --application/pages/page_00111
begin
--   Manifest
--     PAGE: 00111
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>111
,p_name=>'Session Details'
,p_alias=>'SESSION-DETAILS'
,p_step_title=>'Session Details'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(59051128140322479411)
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-HeroRegion-title {',
'    display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(48319320446482829871)
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_comment=>'Start a new Q&A session and asks the first session question'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(27657134932065133834)
,p_plug_name=>'Session Details'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_query_type=>'TABLE'
,p_query_table=>'QASK_SESSIONS'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(49626520880362204257)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(48318630736620829740)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(49626519813690204256)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(49626520880362204257)
,p_button_name=>'Cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:RR,111::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(49626520163313204256)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(49626520880362204257)
,p_button_name=>'START_SESSION'
,p_button_static_id=>'START_SESSION'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Start Session'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(49626526541661204260)
,p_branch_name=>'branch to ask question'
,p_branch_action=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:RR,112:P112_SESSION_ID:&P111_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13918881403400017736)
,p_name=>'P111_LIVE_YN'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_item_default=>'Y'
,p_prompt=>'Start Session'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Now;Y,In the Future;N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_help_text=>'Sessions that are started Now, will be available for participants to join as soon as the first question is added.  Sessions that are to be started in the future will allow the host to create multiple questions.  Once that session is completed, it wil'
||'l be available from the Sessions report as a Staged session.  Clicking to view the details will allow the author (or any host, if the Session is Shared) to start the session.  This allows Sessions to be prepared in advance of an event.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27657135126624133836)
,p_name=>'P111_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_item_source_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27657135183381133837)
,p_name=>'P111_OWNER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_item_source_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_source=>'OWNER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27657135311855133838)
,p_name=>'P111_SESSION_CODE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_item_source_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_source=>'SESSION_CODE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27657135660194133842)
,p_name=>'P111_ROW_VERSION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_item_source_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_source=>'ROW_VERSION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27657136188880133847)
,p_name=>'P111_PURPOSE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_item_source_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_prompt=>'Purpose'
,p_source=>'PURPOSE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>2
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Purpose is optional and can be used to further differentiate Sessions.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27657136332446133848)
,p_name=>'P111_RESP_NAME_REQUIRED_YN'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_item_source_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_prompt=>'Participant Name Required'
,p_source=>'RESP_NAME_REQUIRED_YN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'If Name is required, each person answering questions will need to provide a name in order to participate.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(27657136387891133849)
,p_name=>'P111_RESP_EMAIL_REQUIRED_YN'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_item_source_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_prompt=>'Participant Email Required'
,p_source=>'RESP_EMAIL_REQUIRED_YN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'If Email is required, each person answering questions will need to provide a valid email in order to participate.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59153168362886580604)
,p_name=>'P111_CREATED_ON'
,p_source_data_type=>'DATE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_item_source_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_source=>'CREATED_ON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59153168485118580605)
,p_name=>'P111_CREATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_item_source_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_source=>'CREATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59153168564325580606)
,p_name=>'P111_UPDATED_ON'
,p_source_data_type=>'DATE'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_item_source_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_source=>'UPDATED_ON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59153168651836580607)
,p_name=>'P111_UPDATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_item_source_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_source=>'UPDATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59153168752106580608)
,p_name=>'P111_SESSION_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_item_source_plug_id=>wwv_flow_imp.id(27657134932065133834)
,p_prompt=>'Session Name'
,p_source=>'SESSION_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Session name is used to differentiate sessions.  It is not displayed to Session participants.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(49626521708781204257)
,p_validation_name=>'prevent dup names'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.new_session_name_ok_yn (',
'    p_session_name => :P111_SESSION_NAME,',
'    p_app_user     => lower(:APP_USER)) = ''Y'''))
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'You already have a session "&P111_SESSION_NAME.", please enter a different name.'
,p_associated_item=>wwv_flow_imp.id(59153168752106580608)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(49626522124738204258)
,p_validation_name=>'check for max open sessions'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_max_open_sessions      number := qask_util.get_setting(''max_open_sessions'');',
'   l_open_session_for_user  number := qask_util.open_session_count_for_user(:APP_USER);',
'begin',
'',
'if l_open_session_for_user >= l_max_open_sessions then ',
'    return ''You have requested more sessions than permitted.  ''||',
'        ''Maximum permitted is ''||l_max_open_sessions||''.  ''||',
'        ''Please close some of your open sessions before starting a new one.'';',
'end if;',
'',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_validation_condition=>'P111_LIVE_YN'
,p_validation_condition2=>'Y'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(22481968554916662404)
,p_name=>'change button name'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P111_LIVE_YN'
,p_condition_element=>'P111_LIVE_YN'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'N'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22481968735703662405)
,p_event_id=>wwv_flow_imp.id(22481968554916662404)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.item("START_SESSION").setValue("Create Session");'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(22481968775253662406)
,p_event_id=>wwv_flow_imp.id(22481968554916662404)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.item("START_SESSION").setValue("Start Session");'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(49626522819949204258)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'create session'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P111_ID := qask_util.create_session (',
'                p_app_user               => lower(:APP_USER),',
'                p_session_name           => :P111_SESSION_NAME,',
'                p_purpose                => :P111_PURPOSE,',
'                p_resp_name_required_yn  => :P111_RESP_NAME_REQUIRED_YN,',
'                p_resp_email_required_yn => :P111_RESP_EMAIL_REQUIRED_YN,',
'                p_session_status         => case when :P111_LIVE_YN = ''N'' then ''STAGED'' else ''OPEN'' end );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(49626520163313204256)
,p_internal_uid=>47736097573514806958
);
wwv_flow_imp.component_end;
end;
/
