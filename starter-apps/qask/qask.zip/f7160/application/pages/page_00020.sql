prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1843380062236545922
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>20
,p_name=>'Question'
,p_alias=>'QUESTION'
,p_step_title=>'Question'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
':root {',
'    --ut-pillbutton-checkbox-offset: 20px;',
'    --a-checkbox-label-spacing-x: 1rem;',
'}',
'.t-Button--large {',
'    --a-button-font-size: 1rem;',
'}',
'',
'.apex-item-group--rc .apex-item-option {',
'    width: 100% !important;',
'    --ut-pillbutton-padding-y: 1rem;',
'    font-weight: 700;',
'    --ut-pillbutton-font-size: 1.25rem;',
'    max-width: 320px;',
'    margin: 8px auto 8px auto;',
'}',
'',
'.t-Alert--horizontal {',
'    margin-inline-start: auto;',
'    margin-inline-end: auto;',
'    margin-bottom: 0;',
'    max-width: 47.5rem;',
'}',
'',
'#P20_ANSWER_CONTAINER .t-Form-inputContainer {',
'    display: flex;',
'    flex-direction: column-reverse;',
'}',
'',
'#P20_ANSWER_MANY_CONTAINER .t-Form-itemWrapper {',
'    display: block;',
'}',
'',
'.t-Form-fieldContainer--radioButtonGroup .apex-item-group--rc.apex-item-checkbox input+label {',
'    line-height: 24px;',
'}',
'',
'#P20_ANSWER_MANY_CONTAINER .apex-item-checkbox .apex-item-option input:checked+label {',
'    --a-checkbox-background-color: white;',
'    --a-checkbox-text-color: black;',
'}',
'',
'',
'#P20_ANSWER_MANY_CONTAINER .apex-item-checkbox .apex-item-option input+label:after,',
'#P20_ANSWER_MANY_CONTAINER .apex-item-checkbox .apex-item-option input+label:before {',
'    transform: scale(1.5)',
'}',
'',
'#P20_ANSWER_MANY_CONTAINER.t-Form-fieldContainer--radioButtonGroup .apex-item-group--rc.apex-item-checkbox input+label {',
'    padding-inline-start: 48px;',
'}',
'',
'span.t-Form-error {',
'    --ut-field-error-font-size: 1rem;',
'    margin-bottom: 8px;',
'    font-weight: 700;',
'}',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'16'
,p_last_updated_by=>'SBKENNED'
,p_last_upd_yyyymmddhh24miss=>'20240402212653'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54374118645250304252)
,p_plug_name=>'Session &SESSION_CODE.'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useRegionTitle'
,p_plug_template=>wwv_flow_imp.id(48272101477272978410)
,p_plug_display_sequence=>10
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'SESSION_CODE'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(124911995431428704712)
,p_plug_name=>'&P20_QUESTION.'
,p_region_css_classes=>'u-tC'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--warning'
,p_plug_template=>wwv_flow_imp.id(48271616986112978376)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'QUESTION_ID'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(126234813296133723038)
,p_plug_name=>'Answered!'
,p_parent_plug_id=>wwv_flow_imp.id(124911995431428704712)
,p_region_css_classes=>'u-tC'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48271623650022978379)
,p_plug_display_sequence=>10
,p_plug_source=>'<b>Answered!</b>'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.is_question_answered_yn (',
'    p_response_id => :RESPONSE_ID,',
'    p_question_id => :QUESTION_ID ) = ''Y'''))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(65588760166088655822)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_imp.id(124911995431428704712)
,p_button_name=>'submit_answer'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(48272162460548978436)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit Answer'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.is_question_answered_yn (',
'    p_response_id => :RESPONSE_ID,',
'    p_question_id => :QUESTION_ID ) = ''N'''))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_button_css_classes=>'margin-auto mxw320 w100p padding-md'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(65588761003928655823)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_imp.id(124911995431428704712)
,p_button_name=>'next_question'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(48272162491040978436)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Continue'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.is_question_answered_yn (',
'    p_response_id => :RESPONSE_ID,',
'    p_question_id => :QUESTION_ID ) = ''Y'''))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_button_css_classes=>'margin-auto mxw320 w100p padding-md'
,p_icon_css_classes=>'fa-chevron-right'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(65588770004211655829)
,p_branch_name=>'Show Confirmation'
,p_branch_action=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:RR,::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(63372481799047844470)
,p_branch_name=>'go home if no SESSION_ID'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>':SESSION_ID is null'
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(65588770804092655829)
,p_branch_name=>'Session Closed'
,p_branch_action=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:1,20::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>40
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>'qask_util.get_session_status (p_session_id => :SESSION_ID) = ''CLOSED'''
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(65588770390131655829)
,p_branch_name=>'session no longer open'
,p_branch_action=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:12:P12_SESSION_CODE:&SESSION_CODE.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>'qask_util.get_session_status(:SESSION_ID) = ''CLOSED'''
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(65588769638004655829)
,p_branch_name=>'question no longer open'
,p_branch_action=>'f?p=&APP_ID.:21:&SESSION.:QCLOSED:&DEBUG.:RR,21::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_VALIDATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
,p_branch_condition_type=>'FUNCTION_BODY'
,p_branch_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if qask_util.get_question_status (',
'       p_question_id => :QUESTION_ID) = ''OPEN'' then',
'   return false;',
'else',
'   return true;',
'end if;'))
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54374117252608304238)
,p_name=>'P20_QUESTION_FILE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(124911995431428704712)
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_session_questions',
' where id = :QUESTION_ID',
'   and question_filename is not null'))
,p_display_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(48272159645038978434)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'SQL'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select question_file',
'  from qask_session_questions',
' where id = :QUESTION_ID'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59106127841159729272)
,p_name=>'P20_ANSWER_TYPE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(124911995431428704712)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65723287596809051223)
,p_name=>'P20_ASK_FOR_COMMENTS_YN'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(124911995431428704712)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65723287924780051226)
,p_name=>'P20_QUESTION_EXPLANATION'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(124911995431428704712)
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P20_QUESTION_EXPLANATION'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(48272159645038978434)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65723288058291051227)
,p_name=>'P20_COMMENTS'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(124911995431428704712)
,p_prompt=>'Comments'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P20_ASK_FOR_COMMENTS_YN = ''Y'' and',
'qask_util.is_question_answered_yn (',
'    p_response_id => :RESPONSE_ID,',
'    p_question_id => :QUESTION_ID ) = ''N'''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(48272159924981978434)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65723288625515051233)
,p_name=>'P20_ANSWER_FREEFORM'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(124911995431428704712)
,p_prompt=>'Answer'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>4000
,p_grid_label_column_span=>0
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P20_ANSWER_TYPE = ''FREEFORM'' and',
'qask_util.is_question_answered_yn (',
'    p_response_id => :RESPONSE_ID,',
'    p_question_id => :QUESTION_ID ) = ''N'''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(48272159645038978434)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--xlarge'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(124911997317476704716)
,p_name=>'P20_ANSWER_ID'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(124911995431428704712)
,p_prompt=>'Answer (choose one)'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select answer_text d, id r',
'  from qask_sess_question_answers ',
' where question_id = :QUESTION_ID',
' order by answer_number'))
,p_grid_label_column_span=>0
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P20_ANSWER_TYPE = ''SINGLE'' and',
'qask_util.is_question_answered_yn (',
'    p_response_id => :RESPONSE_ID,',
'    p_question_id => :QUESTION_ID ) = ''N'''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(48272159645038978434)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--xlarge:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(124911997703283704720)
,p_name=>'P20_QUESTION_NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(124911995431428704712)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(130549505381512147352)
,p_name=>'P20_QUESTION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(124911995431428704712)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(130951461363051985159)
,p_name=>'P20_MULTI_ANSWER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(124911995431428704712)
,p_prompt=>'Answer (choose all that apply)'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select answer_text d, id r',
'  from qask_sess_question_answers ',
' where question_id = :QUESTION_ID',
' order by answer_number',
''))
,p_grid_label_column_span=>0
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P20_ANSWER_TYPE = ''MULTI'' and',
'qask_util.is_question_answered_yn (',
'    p_response_id => :RESPONSE_ID,',
'    p_question_id => :QUESTION_ID ) = ''N'''))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(48272159645038978434)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(65723287756645051224)
,p_computation_sequence=>10
,p_computation_item=>'QUESTION_ID'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return qask_util.get_next_question_id (',
'          p_session_id  => :SESSION_ID,',
'          p_question_id => :QUESTION_ID );'))
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(65588766403658655827)
,p_validation_name=>'must answer - SINGLE'
,p_validation_sequence=>10
,p_validation=>'P20_ANSWER_ID'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'You must select an answer!'
,p_validation_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P20_ANSWER_TYPE = ''SINGLE'' and',
'qask_util.is_question_answered_yn (',
'    p_response_id => :RESPONSE_ID,',
'    p_question_id => :QUESTION_ID ) = ''N'''))
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_associated_item=>wwv_flow_imp.id(124911997317476704716)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(73064919066629002227)
,p_validation_name=>'must answer - MULTI'
,p_validation_sequence=>20
,p_validation=>'P20_MULTI_ANSWER'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'You must select an answer!'
,p_validation_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P20_ANSWER_TYPE = ''MULTI'' and',
'qask_util.is_question_answered_yn (',
'    p_response_id => :RESPONSE_ID,',
'    p_question_id => :QUESTION_ID ) = ''N'''))
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_associated_item=>wwv_flow_imp.id(130951461363051985159)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(73064919208560002228)
,p_validation_name=>'must answer - FREEFORM'
,p_validation_sequence=>30
,p_validation=>'P20_ANSWER_FREEFORM'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'You must provide an answer!'
,p_validation_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P20_ANSWER_TYPE = ''FREEFORM'' and',
'qask_util.is_question_answered_yn (',
'    p_response_id => :RESPONSE_ID,',
'    p_question_id => :QUESTION_ID ) = ''N'''))
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_associated_item=>wwv_flow_imp.id(65723288625515051233)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(65723287858398051225)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'get question details'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_dont_need  varchar2(4000);',
'begin',
'',
':P20_QUESTION_NUMBER      := null;',
':P20_QUESTION             := null;',
':P20_ANSWER_TYPE          := null;',
':P20_ASK_FOR_COMMENTS_YN  := null;',
':P20_QUESTION_EXPLANATION := null;',
'',
'qask_util.get_question_details (',
'    p_question_id          => :QUESTION_ID,',
'    p_question_number      => :P20_QUESTION_NUMBER,',
'    p_question_status      => l_dont_need,',
'    p_question             => :P20_QUESTION,',
'    p_answer_type          => :P20_ANSWER_TYPE,',
'    p_ask_for_comments_yn  => :P20_ASK_FOR_COMMENTS_YN,',
'    p_question_explanation => :P20_QUESTION_EXPLANATION );',
'',
'    end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>63879907796161505303
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(65588766680417655827)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'submit_answer'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :SESSION_ID is null then',
'     raise_application_error(-20111,''Session ID is null, value is required'');',
'end if;',
'if :QUESTION_ID is null then',
'     raise_application_error(-20111,''Question ID is null, value is required'');',
'end if;',
'if :APP_SESSION is null then',
'    raise_application_error(-20111,''App session is null'');',
'end if;',
'',
':RESPONSE_ID := qask_util.answer_question (',
'    p_session_id       => :SESSION_ID,',
'    p_question_id      => :QUESTION_ID,',
'    p_apex_session_id  => :APP_SESSION,',
'    p_answer_id        => :P20_ANSWER_ID,',
'    p_answer_freeform  => :P20_ANSWER_FREEFORM,',
'    p_multi_answer     => :P20_MULTI_ANSWER,',
'    p_comment_text     => :P20_COMMENTS,',
'    p_response_id      => :RESPONSE_ID,',
'    p_respondent_name  => :P11_NAME,',
'    p_respondent_email => :P11_EMAIL );',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(65588760166088655822)
,p_internal_uid=>63745386618181109905
);
wwv_flow_imp.component_end;
end;
/
