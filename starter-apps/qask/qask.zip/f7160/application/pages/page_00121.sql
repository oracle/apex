prompt --application/pages/page_00121
begin
--   Manifest
--     PAGE: 00121
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1905173489740762914
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>121
,p_name=>'Question Summary'
,p_alias=>'QUESTION-SUMMARY'
,p_step_title=>'Question Summary'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'#APP_FILES#jquery.qrcode.min.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'	jQuery(''#qr_code'').qrcode({',
'        render	: "table",',
'		text	: ''&P121_QR_URL!RAW.''',
'	});'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
':root {',
'    --a-button-gap-x: 1rem;',
'}',
'',
'.qr-container {',
'    min-height: 348px;',
'    display: flex;',
'    align-items: center;',
'    justify-content: center;',
'    flex-direction: column;',
'}',
'#qr_code {',
'    padding: 8px;',
'    background-color: white;',
'}',
'.qr-container h2 {',
'    margin: 0 0 16px 0;',
'    font-weight: 700;',
'}',
'',
'.t-BadgeList + .t-Report-pagination {',
'    display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(50177448752025741407)
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_comment=>'Displays bar chart results of the previous question and provides a link to ask a new question'
,p_page_component_map=>'18'
,p_last_updated_by=>'SBKENNED'
,p_last_upd_yyyymmddhh24miss=>'20240404160424'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(141764462183430240701)
,p_plug_name=>'Pie chart'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--noUI:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(50176814689292741300)
,p_plug_display_sequence=>50
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_plug_display_when_condition=>'P121_ANSWER_TYPE'
,p_plug_display_when_cond2=>'FREEFORM'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(74416093627315404502)
,p_region_id=>wwv_flow_imp.id(141764462183430240701)
,p_chart_type=>'pie'
,p_height=>'500'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(74416094143614404505)
,p_chart_id=>wwv_flow_imp.id(74416093627315404502)
,p_seq=>10
,p_name=>'answers'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select qa.answer_text, ',
'       (select count(*) ',
'          from qask_response_answers a ',
'         where :P121_QUESTION_ID = a.question_id',
'           and a.answer_id = qa.id) answer_count',
'   from qask_session_questions q, ',
'        qask_sess_question_answers qa',
'  where q.session_id = :P121_SESSION_ID',
'    and q.id = qa.question_id',
'    and q.id = :P121_QUESTION_ID',
'order by qa.answer_number'))
,p_max_row_count=>100000
,p_items_value_column_name=>'ANSWER_COUNT'
,p_items_label_column_name=>'ANSWER_TEXT'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'ALL'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(142540616333389795778)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(50177274967013741324)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(50176759042163741276)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(50177337551343741350)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(168430413609864987782)
,p_plug_name=>'Results'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(50176795687290741293)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(174091445490247270885)
,p_plug_name=>'Answers by Participant'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:is-collapsed:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(50176814689292741300)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(171337366245811207353)
,p_plug_name=>'Answers by Participant'
,p_parent_plug_id=>wwv_flow_imp.id(174091445490247270885)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(50176852706173741315)
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.name,',
'       r.email,',
'       r.apex_session,',
'       r.user_agent,',
'       r.x_forwarded_for,',
'       r.remote_addr,',
'       a.answer_id,',
'       a.answer_text,',
'       a.comment_text,',
'       a.created_on created',
'  from qask_responses r,',
'       qask_response_answers a',
' where r.session_id = :P121_SESSION_ID',
'   and r.id = a.response_id (+)',
'   and :P121_QUESTION_ID = a.question_id (+)',
'order by r.id, a.answer_text'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Answers by Participant'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(171337366324550207354)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MICHAEL.HICHWA@ME.COM'
,p_internal_uid=>167588812772572898518
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142540603108574795758)
,p_db_column_name=>'ANSWER_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Answer Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(67628464058667814167)
,p_db_column_name=>'APEX_SESSION'
,p_display_order=>20
,p_column_identifier=>'U'
,p_column_label=>'Session ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142540607608849795764)
,p_db_column_name=>'NAME'
,p_display_order=>30
,p_column_identifier=>'R'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P121_RESP_NAME_REQUIRED_YN = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(67628463966616814166)
,p_db_column_name=>'EMAIL'
,p_display_order=>40
,p_column_identifier=>'T'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P121_RESP_EMAIL_REQUIRED_YN = ''Y'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142540607218452795764)
,p_db_column_name=>'CREATED'
,p_display_order=>50
,p_column_identifier=>'Q'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142540607987201795764)
,p_db_column_name=>'ANSWER_TEXT'
,p_display_order=>60
,p_column_identifier=>'S'
,p_column_label=>'Answer'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(67628464392968814170)
,p_db_column_name=>'COMMENT_TEXT'
,p_display_order=>70
,p_column_identifier=>'X'
,p_column_label=>'Comment Text'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P121_ASK_FOR_COMMENTS_YN = ''Y'''
,p_display_condition2=>'SQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142540606775930795763)
,p_db_column_name=>'USER_AGENT'
,p_display_order=>80
,p_column_identifier=>'K'
,p_column_label=>'User Agent'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(67628464226485814168)
,p_db_column_name=>'X_FORWARDED_FOR'
,p_display_order=>90
,p_column_identifier=>'V'
,p_column_label=>'X Forwarded For'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(67628464304783814169)
,p_db_column_name=>'REMOTE_ADDR'
,p_display_order=>100
,p_column_identifier=>'W'
,p_column_label=>'Remote Address'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(172588899820821228570)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'300483001'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'APEX_SESSION:NAME:EMAIL:ANSWER_TEXT:COMMENT_TEXT:CREATED:'
,p_sort_column_1=>'CREATED'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(174493396774537108646)
,p_plug_name=>'Bar chart'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--noUI:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(50176814689292741300)
,p_plug_display_sequence=>40
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_plug_display_when_condition=>'P121_ANSWER_TYPE'
,p_plug_display_when_cond2=>'FREEFORM'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(74416107717939404521)
,p_region_id=>wwv_flow_imp.id(174493396774537108646)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(74416109448875404522)
,p_chart_id=>wwv_flow_imp.id(74416107717939404521)
,p_seq=>10
,p_name=>'answers'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select qa.answer_text, ',
'       (select count(*) ',
'          from qask_response_answers a ',
'         where :P121_QUESTION_ID = a.question_id',
'           and a.answer_id = qa.id) answer_count',
'   from qask_session_questions q, ',
'        qask_sess_question_answers qa',
'  where q.session_id = :P121_SESSION_ID',
'    and q.id = qa.question_id',
'    and q.id = :P121_QUESTION_ID',
'order by qa.answer_number'))
,p_max_row_count=>100000
,p_items_value_column_name=>'ANSWER_COUNT'
,p_items_label_column_name=>'ANSWER_TEXT'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(74416108189519404521)
,p_chart_id=>wwv_flow_imp.id(74416107717939404521)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title_font_size=>'18'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_min_step=>1
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(74416108783444404522)
,p_chart_id=>wwv_flow_imp.id(74416107717939404521)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'off'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(197333802174130130249)
,p_plug_name=>'Button Container'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(50176798527465741294)
,p_plug_display_sequence=>30
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P121_SESSION_STATUS = ''OPEN'' and',
'qask_util.get_session_owner(p_session_id => :P121_SESSION_ID) = :APP_USER'))
,p_plug_display_when_cond2=>'SQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(197334813814535184480)
,p_name=>'&P121_QUESTION_NUMBER.. &P121_QUESTION.'
,p_template=>wwv_flow_imp.id(50176824482642741304)
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'js-refresh-region'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_component_template_options=>'#DEFAULT#:t-ContextualInfo-label--stacked'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select (select count(unique response_id) ',
'          from qask_responses r,',
'               qask_response_answers a',
'         where r.session_id = :P121_SESSION_ID',
'           and r.id = a.response_id',
'           and a.question_id = :P121_QUESTION_ID) respondents,',
'       ROUND(length_seconds/60) || '' minutes'' question_open',
'  from qask_session_questions',
' where session_id = :P121_SESSION_ID',
'   and id = :P121_QUESTION_ID'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P121_SESSION_CODE,P121_QUESTION_NUMBER'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(50177296727731741333)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74416091441343404492)
,p_query_column_id=>1
,p_column_alias=>'RESPONDENTS'
,p_column_display_sequence=>20
,p_column_heading=>'Responses'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74505428393375517570)
,p_query_column_id=>2
,p_column_alias=>'QUESTION_OPEN'
,p_column_display_sequence=>30
,p_column_heading=>'Question Open'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(202366272650288736423)
,p_plug_name=>'Session QR'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--noUI:t-Region--scrollBody:margin-bottom-none'
,p_plug_template=>wwv_flow_imp.id(50176862500453741319)
,p_plug_display_sequence=>11
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="qr-container">',
'    <h2 class="u-tC">Scan QR code to participate!</h2>',
'    <div id="qr_code"></div>',
'    <h2 class="u-tC">&P121_SESSION_CODE.</h2>',
'</div>'))
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P121_QUESTION_STATUS = ''OPEN'' and',
':P121_SESSION_STATUS = ''OPEN'''))
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74505428190446517568)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(197333802174130130249)
,p_button_name=>'close_session'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large'
,p_button_template_id=>wwv_flow_imp.id(50177335950289741350)
,p_button_image_alt=>'Close Session'
,p_button_position=>'CHANGE'
,p_button_css_classes=>'w260 padding-md'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74505428260979517569)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(197333802174130130249)
,p_button_name=>'ask_new_question'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large'
,p_button_template_id=>wwv_flow_imp.id(50177335950289741350)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Ask New Question'
,p_button_position=>'CHANGE'
,p_button_redirect_url=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:112:P112_SESSION_ID:&P121_SESSION_ID.'
,p_button_css_classes=>'w260 padding-md'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74416096562411404507)
,p_button_sequence=>1
,p_button_plug_id=>wwv_flow_imp.id(142540616333389795778)
,p_button_name=>'previous_question'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--mobileHideLabel:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(50177335980781741350)
,p_button_image_alt=>'Previous Question'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:121:&SESSION.::&DEBUG.:RR,121:P121_SESSION_ID,P121_QUESTION_ID:&P121_SESSION_ID.,&P121_PREV_QUESTION_ID.'
,p_button_condition=>'P121_PREV_QUESTION_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74416096961404404507)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(142540616333389795778)
,p_button_name=>'next_question'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--mobileHideLabel:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(50177335980781741350)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next Question'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:121:&SESSION.::&DEBUG.:121:P121_SESSION_ID,P121_QUESTION_ID:&P121_SESSION_ID.,&P121_NEXT_QUESTION_ID.'
,p_button_condition=>'P121_NEXT_QUESTION_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(74416114545297404529)
,p_branch_name=>'after close session'
,p_branch_action=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.:120:P120_SESSION_ID:&P121_SESSION_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(74505428190446517568)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(62848862584983027986)
,p_name=>'P121_QUESTION_FILE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(197334813814535184480)
,p_display_as=>'NATIVE_DISPLAY_IMAGE'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_session_questions',
' where id = :P121_QUESTION_ID',
'   and question_filename is not null'))
,p_display_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(50177333134779741348)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'SQL'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select question_file',
'  from qask_session_questions',
' where id = :P121_QUESTION_ID'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(67628463419178814160)
,p_name=>'P121_SESSION_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(168430413609864987782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(67628463520752814161)
,p_name=>'P121_QUESTION_ID'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(168430413609864987782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(67628463789259814164)
,p_name=>'P121_SESSION_NAME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(168430413609864987782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74970092356416765139)
,p_name=>'P121_ANSWER_TYPE'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(168430413609864987782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74970092544502765140)
,p_name=>'P121_ASK_FOR_COMMENTS_YN'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(168430413609864987782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74970092879807765144)
,p_name=>'P121_RESP_NAME_REQUIRED_YN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(168430413609864987782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74970093000121765145)
,p_name=>'P121_RESP_EMAIL_REQUIRED_YN'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(168430413609864987782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74970093283523765148)
,p_name=>'P121_SESSION_STATUS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(168430413609864987782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(89473267913518195152)
,p_name=>'P121_QUESTION_STATUS'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(168430413609864987782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(89473268043677195153)
,p_name=>'P121_QR_URL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(168430413609864987782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(141764468143539240710)
,p_name=>'P121_NEXT_QUESTION_ID'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(168430413609864987782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(141764468432095240713)
,p_name=>'P121_PREV_QUESTION_ID'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(168430413609864987782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(142540616286338795793)
,p_name=>'P121_SESSION_CODE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(168430413609864987782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(142540616701506795794)
,p_name=>'P121_QUESTION_NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(168430413609864987782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(142540617843769795794)
,p_name=>'P121_QUESTION'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(168430413609864987782)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(90229181011220625392)
,p_computation_sequence=>70
,p_computation_item=>'P121_QR_URL'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    x  varchar2(4000);',
'begin ',
'    x := apex_page.get_url (',
'           p_page => ''home'',',
'           p_session => 0,',
'           p_items => ''P1_CODE'',',
'           p_values => :P121_SESSION_CODE );',
'    x := substr(x,1,instr(x,''&'')-1);',
'',
'    return rtrim(owa_util.get_cgi_env(''HTTP_REFERER''),''/'') || x;',
'end;'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(74416112139095404527)
,p_computation_sequence=>30
,p_computation_item=>'P121_NEXT_QUESTION_ID'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return qask_util.get_next_question_id (',
'    p_session_id  => :P121_SESSION_ID,',
'    p_question_id => :P121_QUESTION_ID,',
'    p_status      => ''ANY'' );'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(74416112515961404527)
,p_computation_sequence=>40
,p_computation_item=>'P121_PREV_QUESTION_ID'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return qask_util.get_prev_question_id (',
'    p_session_id  => :P121_SESSION_ID,',
'    p_question_id => :P121_QUESTION_ID,',
'    p_status      => ''ANY'' );'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74416113644842404528)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Close Session'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.close_session (',
'    p_session_id => :P121_SESSION_ID );',
'',
'    '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(74505428190446517568)
,p_internal_uid=>70667560092865095692
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74970092816724765143)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'get session details'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_dont_need  varchar2(4000);',
'begin',
'qask_util.get_session_details (',
'    p_session_id             => :P121_SESSION_ID,',
'    p_session_name           => :P121_SESSION_NAME,',
'    p_session_code           => :P121_SESSION_CODE,',
'    p_purpose                => l_dont_need,',
'    p_resp_name_required_yn  => :P121_RESP_NAME_REQUIRED_YN,',
'    p_resp_email_required_yn => :P121_RESP_EMAIL_REQUIRED_YN,',
'    p_session_status         => :P121_SESSION_STATUS );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>71221539264747456307
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(67628463611527814162)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'get question details'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_dont_need  varchar2(4000);',
'begin',
'qask_util.get_question_details (',
'    p_question_id          => :P121_QUESTION_ID,',
'    p_question_number      => :P121_QUESTION_NUMBER,',
'    p_question_status      => :P121_QUESTION_STATUS,',
'    p_question             => :P121_QUESTION,',
'    p_answer_type          => :P121_ANSWER_TYPE,',
'    p_ask_for_comments_yn  => :P121_ASK_FOR_COMMENTS_YN,',
'    p_question_explanation => l_dont_need );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>63879910059550505326
);
wwv_flow_imp.component_end;
end;
/
