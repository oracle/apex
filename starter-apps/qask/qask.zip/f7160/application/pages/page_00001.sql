prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>26987669612026766
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'qAsk'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.apex-item-text {',
'    --a-field-input-font-size: 3rem;',
'    --a-field-input-line-height: 4rem;',
'}',
'.t-Form-itemWrapper {',
'    justify-content: center;',
'}',
'',
'.t-Alert--wizard .t-Alert-buttons {',
'    margin-block-start: 0.5rem;',
'}',
'',
'.t-Button--large {',
'    --a-button-font-size: 1rem;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(73625429600619576730)
,p_plug_name=>'Links2'
,p_region_css_classes=>'u-tC'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48298611319635005145)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(189466459430814452453)
,p_plug_name=>'Links'
,p_region_css_classes=>'u-tC'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48298611319635005145)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(198616816645759430824)
,p_plug_name=>'Welcome to qAsk'
,p_region_css_classes=>'u-tC'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--info:js-headingLevel-1:t-Form--noPadding'
,p_plug_template=>wwv_flow_imp.id(48298604655725005142)
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'Enter your session code to begin'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(65229798751486657676)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(73625429600619576730)
,p_button_name=>'SIGN_IN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_image_alt=>'Sign In'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:100::'
,p_button_condition_type=>'USER_IS_PUBLIC_USER'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(73625429498391576729)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(189466459430814452453)
,p_button_name=>'REQUEST_ACCESS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_image_alt=>'Host a Q&A Session'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:50:&SESSION.::&DEBUG.:50::'
,p_button_condition_type=>'USER_IS_PUBLIC_USER'
,p_security_scheme=>wwv_flow_imp.id(7579422517888996215)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(65229776327482652017)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(198616816645759430824)
,p_button_name=>'Join'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--large'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Join'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_button_css_classes=>'w260 margin-auto padding-md'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(59133115404764756037)
,p_branch_name=>'if session closed'
,p_branch_action=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:1::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(65229776327482652017)
,p_branch_sequence=>10
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.get_session_status (p_session_id => :SESSION_ID) = ''CLOSED'' and',
':SESSION_ID is not null'))
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(65635624746547990736)
,p_branch_name=>'name or email required'
,p_branch_action=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(65229776327482652017)
,p_branch_sequence=>20
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(qask_util.session_resp_name_req_yn(p_session_id => :SESSION_ID) = ''Y'' or',
'qask_util.session_resp_email_req_yn(p_session_id => :SESSION_ID) = ''Y'') and',
':SESSION_ID is not null'))
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(65635631704269991939)
,p_branch_name=>'go to question page, if question available'
,p_branch_action=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:RR,20::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(65229776327482652017)
,p_branch_sequence=>40
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.get_next_question_id (',
'    p_session_id  => :SESSION_ID) is not null and',
':SESSION_ID is not null'))
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(73625428324126576717)
,p_branch_name=>'go to answer page, if question not available'
,p_branch_action=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.:RR,20::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(65229776327482652017)
,p_branch_sequence=>50
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.get_next_question_id (',
'    p_session_id  => :SESSION_ID) is null and',
':SESSION_ID is not null'))
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(54401107863573331034)
,p_branch_name=>'send to Sessions when authenticated'
,p_branch_action=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(198616820092525430831)
,p_name=>'P1_CODE'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(198616816645759430824)
,p_use_cache_before_default=>'NO'
,p_placeholder=>'000000'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>10
,p_cMaxlength=>6
,p_tag_css_classes=>'u-tC w320'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(48299147314651005200)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge:margin-top-md'
,p_restricted_characters=>'US_ONLY'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(65229914263245903491)
,p_validation_name=>'code provided'
,p_validation_sequence=>10
,p_validation=>'P1_CODE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Session Code must be provided.'
,p_when_button_pressed=>wwv_flow_imp.id(65229776327482652017)
,p_associated_item=>wwv_flow_imp.id(198616820092525430831)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(65635707492788744779)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'get SESSION_ID (and RESPONSE_ID)'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_response_id     number;',
'    l_session_status  varchar2(30);',
'begin',
'',
':SESSION_CODE := null;',
':SESSION_NAME := null;',
':SESSION_ID   := null;',
':QUESTION_ID  := null;',
'',
':SESSION_ID   := qask_util.get_session_id(p_session_code => :P1_CODE);',
'',
'if :SESSION_ID is null then',
'    raise_application_error(-20111,''Session "''||:P1_CODE||''" is unknown. Please check your code and try again.'');',
'end if;',
'',
'l_session_status := qask_util.get_session_status (p_session_id => :SESSION_ID);',
'',
'if l_session_status = ''CLOSED'' then',
'    raise_application_error(-20111,''Session "''||:P1_CODE||''" is closed.'');',
'elsif l_session_status = ''STAGED'' then',
'    raise_application_error(-20111,''Session "''||:P1_CODE||''" has not started.'');',
'elsif l_session_status is null then',
'    raise_application_error(-20111,''Session "''||:P1_CODE||''" is not valid.'');',
'end if;',
'',
':SESSION_CODE := qask_util.get_session_code (p_session_id => :SESSION_ID);',
':SESSION_NAME := qask_util.get_session_name (p_session_id => :SESSION_ID);',
'',
'if :SESSION_ID is not null then',
'   l_response_id := qask_util.get_response_id (',
'                        p_session_id      => :SESSION_ID,',
'                        p_apex_session_id => :APP_SESSION );',
'   if nvl(l_response_id,-1) != nvl(:RESPONSE_ID,-1) then',
'       :RESPONSE_ID := l_response_id;',
'   end if;',
'end if;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(65229776327482652017)
,p_internal_uid=>63765339760940172091
);
wwv_flow_imp.component_end;
end;
/
