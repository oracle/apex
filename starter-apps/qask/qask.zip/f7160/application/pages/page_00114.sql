prompt --application/pages/page_00114
begin
--   Manifest
--     PAGE: 00114
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>114
,p_name=>'Start Session'
,p_alias=>'START-SESSION'
,p_page_mode=>'MODAL'
,p_step_title=>'Start Session'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(48319320446482829871)
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76118578922763724622)
,p_plug_name=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(178730055734637343102)
,p_name=>'&P114_SESSION_CODE. - &P114_SESSION_NAME.'
,p_template=>4072358936313175081
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--noBorder:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       OWNER,',
'       SESSION_CODE,',
'       initcap(session_status) status,',
'       closed_on DATE_CLOSED,',
'       CREATED_ON CREATED,',
'       started_on,',
'       CREATED_BY,',
'       PURPOSE,',
'       SESSION_NAME,',
'       (select count(*) from qask_session_questions ',
'         where session_id = s.id) question_count',
'  from QASK_SESSIONS s',
' where id = :P114_SESSION_ID'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P114_SESSION_ID'
,p_lazy_loading=>false
,p_query_row_template=>2100515439059797523
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55527033391733459484)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55527033844582459485)
,p_query_column_id=>2
,p_column_alias=>'OWNER'
,p_column_display_sequence=>20
,p_column_heading=>'Owner'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55527034337026459485)
,p_query_column_id=>3
,p_column_alias=>'SESSION_CODE'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55527038115236459487)
,p_query_column_id=>4
,p_column_alias=>'STATUS'
,p_column_display_sequence=>100
,p_column_heading=>'Status'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55527034851821459485)
,p_query_column_id=>5
,p_column_alias=>'DATE_CLOSED'
,p_column_display_sequence=>150
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55527035330516459486)
,p_query_column_id=>6
,p_column_alias=>'CREATED'
,p_column_display_sequence=>120
,p_column_heading=>'Created'
,p_column_format=>'fmMonth fmDD, YYYY'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions',
' where id = :P114_SESSION_ID',
'   and started_on is null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55527037692898459487)
,p_query_column_id=>7
,p_column_alias=>'STARTED_ON'
,p_column_display_sequence=>130
,p_column_heading=>'Started'
,p_column_format=>'fmMonth fmDD, YYYY'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions',
' where id = :P114_SESSION_ID',
'   and started_on is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55527035725045459486)
,p_query_column_id=>8
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>180
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55527036092488459486)
,p_query_column_id=>9
,p_column_alias=>'PURPOSE'
,p_column_display_sequence=>60
,p_column_heading=>'Purpose'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions',
' where id = :P114_SESSION_ID',
'   and purpose is not null'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55527036534534459486)
,p_query_column_id=>10
,p_column_alias=>'SESSION_NAME'
,p_column_display_sequence=>40
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(55527036932668459487)
,p_query_column_id=>11
,p_column_alias=>'QUESTION_COUNT'
,p_column_display_sequence=>210
,p_column_heading=>'Question Count'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(55527040230109459494)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(76118578922763724622)
,p_button_name=>'cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(55527039803442459494)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(76118578922763724622)
,p_button_name=>'start_session'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Start Session'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_security_scheme=>wwv_flow_imp.id(48319320446482829871)
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(55527666634111782867)
,p_branch_name=>'branch to question responses'
,p_branch_action=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:RR,113:P113_SESSION_ID,P113_QUESTION_ID:&P114_SESSION_ID.,&P114_FIRST_QUESTION_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(55527039803442459494)
,p_branch_sequence=>40
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54421162120047155613)
,p_name=>'P114_FIRST_QUESTION_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(178730055734637343102)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171853112360690639755)
,p_name=>'P114_SESSION_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(178730055734637343102)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171853112475217639756)
,p_name=>'P114_SESSION_CODE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(178730055734637343102)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171853112568712639757)
,p_name=>'P114_SESSION_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(178730055734637343102)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(55527040852599459495)
,p_computation_sequence=>10
,p_computation_item=>'P114_SESSION_CODE'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return qask_util.get_session_code (',
'    p_session_id => :P114_SESSION_ID );'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(55527041300346459495)
,p_computation_sequence=>20
,p_computation_item=>'P114_SESSION_NAME'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return qask_util.get_session_name (',
'    p_session_id => :P114_SESSION_ID );'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(54421162228804155614)
,p_computation_sequence=>30
,p_computation_item=>'P114_FIRST_QUESTION_ID'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return qask_util.get_next_question_id (',
'           p_session_id  => :P114_SESSION_ID,',
'           p_question_id => null,',
'           p_status      => ''ANY'' );'))
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(55527201528155467008)
,p_validation_name=>'check for max open sessions'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_max_open_sessions      number := qask_util.get_setting(''max_open_sessions'');',
'   l_open_session_for_user  number := qask_util.open_session_count_for_user(:APP_USER);',
'begin',
'',
'if l_open_session_for_user >= l_max_open_sessions then ',
'    return ''You have requested more sessions than permitted.  ''||',
'        ''Maximum permitted is ''||l_max_open_sessions||''.  ''||',
'        ''Please close some of your open sessions before starting a new one.'';',
'end if;',
'',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(55527039803442459494)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(55527042012513459496)
,p_name=>'Cancel'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(55527040230109459494)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(55527042528880459496)
,p_event_id=>wwv_flow_imp.id(55527042012513459496)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(55527208192099468125)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'start staged session'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.start_staged_session (',
'    p_session_id  => :P114_SESSION_ID,',
'    p_app_user    => :APP_USER,',
'    p_question_id => :P114_FIRST_QUESTION_ID );'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Session failed to be started.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(55527039803442459494)
,p_process_success_message=>'Session started.'
,p_internal_uid=>53636782945665070825
);
wwv_flow_imp.component_end;
end;
/
