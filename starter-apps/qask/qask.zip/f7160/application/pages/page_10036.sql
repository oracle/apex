prompt --application/pages/page_10036
begin
--   Manifest
--     PAGE: 10036
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>26987669612026766
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10036
,p_name=>'Account Request Details'
,p_alias=>'ACCOUNT-REQUEST-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Account Request Details'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(48299262763877005259)
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4827284274983108779)
,p_plug_name=>'Account Request Details'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48298609867162005145)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'QASK_ACCOUNT_REQUESTS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4827295429087108788)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48298612707337005146)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4827295799417108788)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4827295429087108788)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4827297159281108789)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(4827295429087108788)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P10036_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4827297999607108790)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(4827295429087108788)
,p_button_name=>'DECLINE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_image_alt=>'Decline'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P10036_REQUEST_STATUS'
,p_button_condition2=>'REQUESTED'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4827297584083108790)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(4827295429087108788)
,p_button_name=>'APPROVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(48299150130161005202)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Approve'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P10036_REQUEST_STATUS'
,p_button_condition2=>'APPROVED'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4827284578139108779)
,p_name=>'P10036_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_item_source_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(48299147594594005200)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4827284963231108780)
,p_name=>'P10036_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_item_source_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_prompt=>'Email'
,p_source=>'EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(48299147594594005200)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4827285395081108781)
,p_name=>'P10036_JUSTIFICATION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_item_source_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_prompt=>'Justification'
,p_source=>'JUSTIFICATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(48299147594594005200)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4827285798507108781)
,p_name=>'P10036_ACCEPTED_TERMS_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_item_source_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_source=>'ACCEPTED_TERMS_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4827286195908108781)
,p_name=>'P10036_USER_AGENT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_item_source_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_prompt=>'User Agent'
,p_source=>'USER_AGENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(48299147594594005200)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4827286564545108782)
,p_name=>'P10036_X_FORWARDED_FOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_item_source_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_prompt=>'X Forwarded For'
,p_source=>'X_FORWARDED_FOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(48299147594594005200)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4827287015327108782)
,p_name=>'P10036_REMOTE_ADDR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_item_source_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_prompt=>'Remote Addr'
,p_source=>'REMOTE_ADDR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(48299147594594005200)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4827287343942108782)
,p_name=>'P10036_REQUEST_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_item_source_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_prompt=>'Status'
,p_source=>'REQUEST_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'ACCESS REQUEST STATUSES'
,p_lov=>'.'||wwv_flow_imp.id(6352509286173357490)||'.'
,p_field_template=>wwv_flow_imp.id(48299147594594005200)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4827287775936108783)
,p_name=>'P10036_STATUS_REASON'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_item_source_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_prompt=>'Reason (mandatory if declining)'
,p_source=>'STATUS_REASON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(48299147594594005200)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4827288173545108783)
,p_name=>'P10036_ROW_VERSION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_item_source_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_source=>'ROW_VERSION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4827288612101108783)
,p_name=>'P10036_CREATED_ON'
,p_source_data_type=>'DATE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_item_source_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_source=>'CREATED_ON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4827289507573108784)
,p_name=>'P10036_CREATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_item_source_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_source=>'CREATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_help_text=>'The user who created the record.'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4827290407012108785)
,p_name=>'P10036_UPDATED_ON'
,p_source_data_type=>'DATE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_item_source_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_source=>'UPDATED_ON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4827290734789108785)
,p_name=>'P10036_UPDATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_item_source_plug_id=>wwv_flow_imp.id(4827284274983108779)
,p_source=>'UPDATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(6350337731733325989)
,p_validation_name=>'must have reason for declining'
,p_validation_sequence=>10
,p_validation=>'P10036_STATUS_REASON'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Must provide reason for declining.'
,p_when_button_pressed=>wwv_flow_imp.id(4827297999607108790)
,p_associated_item=>wwv_flow_imp.id(4827287775936108783)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4827295865777108788)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(4827295799417108788)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4827296729553108789)
,p_event_id=>wwv_flow_imp.id(4827295865777108788)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(73625430231820576736)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete Request'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.delete_access_request (',
'    p_access_request_id => :P10036_ID );'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Access Request failed to be deleted.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(4827297159281108789)
,p_process_success_message=>'Access Request deleted.'
,p_internal_uid=>71755062499972004048
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(73625430251208576737)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Approve'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_pwd_url  varchar2(4000);',
'begin',
'    l_pwd_url := apex_page.get_url(',
'                     p_application => :APP_ID,',
'                     p_page        => 9997,',
'                     p_session     => 0,',
'                     p_items       => ''P9997_EMAIL'',',
'                     p_values      => :P10036_EMAIL,',
'                     p_plain_url   => TRUE );',
'    l_pwd_url := rtrim(OWA_UTIL.get_cgi_env(''HTTP_REFERER''),''/'') || l_pwd_url;    ',
'',
'    qask_util.approve_access (',
'        p_access_request_id => :P10036_ID,',
'        p_reason            => :P10036_STATUS_REASON,',
'        p_send_email_yn     => ''Y'',',
'        p_app_id            => :APP_ID,',
'        p_app_url           => :APP_URL,',
'        p_pwd_url           => l_pwd_url ); ',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Access Request failed to be approved.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(4827297584083108790)
,p_process_success_message=>'Access Request approved.'
,p_internal_uid=>71755062519360004049
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(73625430354367576738)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Decline'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.decline_access (',
'    p_access_request_id => :P10036_ID,',
'    p_reason            => :P10036_STATUS_REASON,',
'    p_send_email_yn     => ''Y'',',
'    p_app_id            => :APP_ID,',
'    p_app_url           => :APP_URL ); '))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Access Request failed to be declined.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(4827297999607108790)
,p_process_success_message=>'Access Request declined.'
,p_internal_uid=>71755062622519004050
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(4827299207323108790)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2956931475474536102
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(4827298342125108790)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(4827284274983108779)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Account Request Details'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2956930610276536102
);
wwv_flow_imp.component_end;
end;
/
