prompt --application/pages/page_10036
begin
--   Manifest
--     PAGE: 10036
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10036
,p_name=>'Account Request Details'
,p_alias=>'ACCOUNT-REQUEST-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Account Request Details'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(48319320278462829871)
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4847341789568933391)
,p_plug_name=>'Account Request Details'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'QASK_ACCOUNT_REQUESTS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4847352943672933400)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2126429139436695430
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4847353314002933400)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(4847352943672933400)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4847354673866933401)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(4847352943672933400)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P10036_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4847355514192933402)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(4847352943672933400)
,p_button_name=>'DECLINE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Decline'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P10036_REQUEST_STATUS'
,p_button_condition2=>'REQUESTED'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(4847355098668933402)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(4847352943672933400)
,p_button_name=>'APPROVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Approve'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P10036_REQUEST_STATUS'
,p_button_condition2=>'APPROVED'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4847342092724933391)
,p_name=>'P10036_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_item_source_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4847342477816933392)
,p_name=>'P10036_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_item_source_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_prompt=>'Email'
,p_source=>'EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4847342909666933393)
,p_name=>'P10036_JUSTIFICATION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_item_source_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_prompt=>'Justification'
,p_source=>'JUSTIFICATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4847343313092933393)
,p_name=>'P10036_ACCEPTED_TERMS_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_item_source_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_source=>'ACCEPTED_TERMS_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4847343710493933393)
,p_name=>'P10036_USER_AGENT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_item_source_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_prompt=>'User Agent'
,p_source=>'USER_AGENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4847344079130933394)
,p_name=>'P10036_X_FORWARDED_FOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_item_source_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_prompt=>'X Forwarded For'
,p_source=>'X_FORWARDED_FOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4847344529912933394)
,p_name=>'P10036_REMOTE_ADDR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_item_source_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_prompt=>'Remote Addr'
,p_source=>'REMOTE_ADDR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4847344858527933394)
,p_name=>'P10036_REQUEST_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_item_source_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_prompt=>'Status'
,p_source=>'REQUEST_STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'ACCESS REQUEST STATUSES'
,p_lov=>'.'||wwv_flow_imp.id(6372566800759182102)||'.'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'LOV',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4847345290521933395)
,p_name=>'P10036_STATUS_REASON'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_item_source_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_prompt=>'Reason (mandatory if declining)'
,p_source=>'STATUS_REASON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4847345688130933395)
,p_name=>'P10036_ROW_VERSION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_item_source_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_source=>'ROW_VERSION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4847346126686933395)
,p_name=>'P10036_CREATED_ON'
,p_source_data_type=>'DATE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_item_source_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_source=>'CREATED_ON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4847347022158933396)
,p_name=>'P10036_CREATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_item_source_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_source=>'CREATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_help_text=>'The user who created the record.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4847347921597933397)
,p_name=>'P10036_UPDATED_ON'
,p_source_data_type=>'DATE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_item_source_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_source=>'UPDATED_ON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4847348249374933397)
,p_name=>'P10036_UPDATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_item_source_plug_id=>wwv_flow_imp.id(4847341789568933391)
,p_source=>'UPDATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(6370395246319150601)
,p_validation_name=>'must have reason for declining'
,p_validation_sequence=>10
,p_validation=>'P10036_STATUS_REASON'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Must provide reason for declining.'
,p_when_button_pressed=>wwv_flow_imp.id(4847355514192933402)
,p_associated_item=>wwv_flow_imp.id(4847345290521933395)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4847353380362933400)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(4847353314002933400)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4847354244138933401)
,p_event_id=>wwv_flow_imp.id(4847353380362933400)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(73645487746406401348)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete Request'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.delete_access_request (',
'    p_access_request_id => :P10036_ID );'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Access Request failed to be deleted.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(4847354673866933401)
,p_process_success_message=>'Access Request deleted.'
,p_internal_uid=>71755062499972004048
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(73645487765794401349)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Approve'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_pwd_url  varchar2(4000);',
'begin',
'    l_pwd_url := apex_page.get_url(',
'                     p_application => :APP_ID,',
'                     p_page        => 9997,',
'                     p_session     => 0,',
'                     p_items       => ''P9997_EMAIL'',',
'                     p_values      => :P10036_EMAIL,',
'                     p_plain_url   => TRUE );',
'    l_pwd_url := rtrim(OWA_UTIL.get_cgi_env(''HTTP_REFERER''),''/'') || l_pwd_url;    ',
'',
'    qask_util.approve_access (',
'        p_access_request_id => :P10036_ID,',
'        p_reason            => :P10036_STATUS_REASON,',
'        p_send_email_yn     => ''Y'',',
'        p_app_id            => :APP_ID,',
'        p_app_url           => :APP_URL,',
'        p_pwd_url           => l_pwd_url ); ',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Access Request failed to be approved.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(4847355098668933402)
,p_process_success_message=>'Access Request approved.'
,p_internal_uid=>71755062519360004049
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(73645487868953401350)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Decline'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.decline_access (',
'    p_access_request_id => :P10036_ID,',
'    p_reason            => :P10036_STATUS_REASON,',
'    p_send_email_yn     => ''Y'',',
'    p_app_id            => :APP_ID,',
'    p_app_url           => :APP_URL ); '))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Access Request failed to be declined.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(4847355514192933402)
,p_process_success_message=>'Access Request declined.'
,p_internal_uid=>71755062622519004050
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(4847356721908933402)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2956931475474536102
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(4847355856710933402)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(4847341789568933391)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Account Request Details'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>2956930610276536102
);
wwv_flow_imp.component_end;
end;
/
