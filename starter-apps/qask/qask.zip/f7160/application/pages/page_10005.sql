prompt --application/pages/page_10005
begin
--   Manifest
--     PAGE: 10005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1905173489740762914
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10005
,p_name=>'All Sessions'
,p_alias=>'ALL-SESSIONS'
,p_step_title=>'All Sessions'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(50177449946078741408)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(50177448584005741407)
,p_required_patch=>wwv_flow_imp.id(50184437864701860273)
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_help_text=>'<p>This report shows all email queued to be sent and those already sent.</p>'
,p_page_component_map=>'18'
,p_last_updated_by=>'SHARON.KENNEDY@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20240402210731'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(138058861791809721812)
,p_plug_name=>'All Sessions'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders'
,p_plug_template=>wwv_flow_imp.id(50176852706173741315)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       session_code,',
'       case session_status when ''OPEN'' then ''Active''',
'                           when ''CLOSED'' then ''Closed''',
'                           when ''STAGED'' then ''Draft''',
'            end session_status,',
'       session_name,',
'       purpose,',
'       owner,',
'       (select count(*) from qask_session_questions',
'         where session_id = s.id) question_cnt,',
'       (select count(*) from qask_responses',
'         where session_id = s.id) response_cnt,',
'       nvl(started_on,created_on) created_on',
'  from qask_sessions s'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Email Reporting'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(138058862406912721813)
,p_name=>'Email Reporting'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'SBKENNED'
,p_internal_uid=>134310308854935412977
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(138058863518022722055)
,p_db_column_name=>'ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(89473268364339195157)
,p_db_column_name=>'SESSION_CODE'
,p_display_order=>12
,p_column_identifier=>'V'
,p_column_label=>'Session Code'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(89473268507537195158)
,p_db_column_name=>'SESSION_STATUS'
,p_display_order=>22
,p_column_identifier=>'W'
,p_column_label=>'Status'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(89473268638125195159)
,p_db_column_name=>'SESSION_NAME'
,p_display_order=>32
,p_column_identifier=>'X'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(89473268726901195160)
,p_db_column_name=>'PURPOSE'
,p_display_order=>42
,p_column_identifier=>'Y'
,p_column_label=>'Purpose'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(89473268805170195161)
,p_db_column_name=>'OWNER'
,p_display_order=>52
,p_column_identifier=>'Z'
,p_column_label=>'Owner'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(89473268884018195162)
,p_db_column_name=>'QUESTION_CNT'
,p_display_order=>62
,p_column_identifier=>'AA'
,p_column_label=>'Questions'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(89473269016108195163)
,p_db_column_name=>'RESPONSE_CNT'
,p_display_order=>72
,p_column_identifier=>'AB'
,p_column_label=>'Responses'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(89473269056113195164)
,p_db_column_name=>'CREATED_ON'
,p_display_order=>82
,p_column_identifier=>'AC'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(138058878122430722066)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'464359010'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SESSION_CODE:SESSION_NAME:SESSION_STATUS:OWNER:QUESTION_CNT:RESPONSE_CNT:CREATED_ON:'
,p_sort_column_1=>'CREATED_ON'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(442925322688135842155)
,p_plug_name=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(50177274967013741324)
,p_plug_display_sequence=>5
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(50176759042163741276)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(50177337551343741350)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(91622985110121170400)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(138058861791809721812)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(50177335980781741350)
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&APP_SESSION.::&DEBUG.:&APP_PAGE_ID.,RR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(91622977685671170378)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(442925322688135842155)
,p_button_name=>'Up'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(50177335247771741349)
,p_button_image_alt=>'Up'
,p_button_position=>'UP'
,p_button_redirect_url=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-up'
);
wwv_flow_imp.component_end;
end;
/
