prompt --application/pages/page_00100
begin
--   Manifest
--     PAGE: 00100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1843380062236545922
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>100
,p_name=>'Q&A Sessions'
,p_alias=>'QANDA-SESSIONS'
,p_step_title=>'Q&A Sessions'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-ContentRow-misc {',
'    min-width: 100px;',
'}'))
,p_step_template=>wwv_flow_imp.id(48271589180497978365)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'22'
,p_last_updated_by=>'SBKENNED'
,p_last_upd_yyyymmddhh24miss=>'20240405154957'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(87556428701737654553)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48272101477272978410)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(48271585552422978362)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(48272164061602978436)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(87556429646410654556)
,p_plug_name=>'Search Results'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48271623650022978379)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       session_code,',
'       session_status,',
'       session_state,',
'       session_name,',
'       purpose,',
'       question_cnt,',
'       response_cnt,',
'       question_cnt || case when question_cnt = 1 then '' Question'' else '' Questions'' end questions,',
'       case when session_status != ''Draft'' then response_cnt ||',
'               case when response_cnt = 1 then '' Participant'' else '' Participants'' end',
'          end responses,',
'       created_on,',
'       created_comment,',
'       case when session_status = ''Closed''',
'            then ''Open ''|| length ||'', ''',
'            end length',
'from (',
'select id,',
'       session_code,',
'       case session_status when ''OPEN'' then ''Active''',
'                           when ''CLOSED'' then ''Closed''',
'                           when ''STAGED'' then ''Draft''',
'            end session_status,',
'       case session_status when ''OPEN'' then ''success''',
'                           when ''CLOSED'' then ''''',
'                           when ''STAGED'' then ''info''',
'            end session_state,',
'       session_name,',
'       purpose,',
'       (select count(*) from qask_session_questions',
'         where session_id = s.id) question_cnt,',
'       (select count(*) from qask_responses',
'         where session_id = s.id) response_cnt,',
'       nvl(started_on,created_on) created_on,',
'       case when session_status = ''OPEN'' then ''Started''',
'            when session_status = ''STAGED'' then ''Draft created''',
'            end created_comment,',
'       case when length_minutes is not null',
'            then case when LENGTH_MINUTES < 60',
'                 then round(LENGTH_MINUTES)||'' minutes''',
'                 else round(LENGTH_MINUTES/60,1)||'' hours'' end ',
'            end length,',
'       nvl(started_on,created_on) ob',
'  from qask_sessions s',
' where owner = lower(:APP_USER)',
')',
'order by ob desc'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_plug_display_when_condition=>'P100_SESSION_CNT'
,p_plug_display_when_cond2=>'0'
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_string.join_clob(wwv_flow_t_varchar2('{',
  '"OVERLINE": "\u0026SESSION_CODE.",',
  '"TITLE": "\u0026SESSION_NAME.",',
  '"DESCRIPTION": "{if PURPOSE\/}\u0026PURPOSE.\u003Cbr\/\u003E{endif\/}\u0026LENGTH. \u0026CREATED_COMMENT. \u0026CREATED_ON.",',
  '"MISC": "\u0026QUESTIONS.\u003Cbr\/\u003E\u0026RESPONSES.",',
  '"DISPLAY_AVATAR": "N",',
  '"DISPLAY_BADGE": "Y",',
  '"BADGE_LABEL": "Status",',
  '"BADGE_VALUE": "SESSION_STATUS",',
  '"BADGE_STATE": "SESSION_STATE",',
  '"BADGE_LABEL_DISPLAY": "N",',
  '"BADGE_COL_WIDTH": "t-ContentRow-badge--auto",',
  '"APPLY_THEME_COLORS": "Y",',
  '"HIDE_BORDERS": "N",',
  '"REMOVE_PADDING": "N"',
'}'))
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(54374120484118304271)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(54374120657359304272)
,p_name=>'SESSION_CODE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SESSION_CODE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(87568092960485432223)
,p_name=>'SESSION_STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SESSION_STATUS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(87568093030090432224)
,p_name=>'SESSION_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SESSION_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(87568093082792432225)
,p_name=>'PURPOSE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PURPOSE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(87568093539337432229)
,p_name=>'CREATED_ON'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_ON'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>90
,p_format_mask=>'SINCE'
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(87568094230701432236)
,p_name=>'CREATED_COMMENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CREATED_COMMENT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>140
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(87568096174144432256)
,p_name=>'QUESTION_CNT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QUESTION_CNT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>180
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(87568096312175432257)
,p_name=>'RESPONSE_CNT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RESPONSE_CNT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>190
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(90089908798899080442)
,p_name=>'SESSION_STATE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SESSION_STATE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>210
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(90089908949246080443)
,p_name=>'QUESTIONS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QUESTIONS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>220
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(90089908976298080444)
,p_name=>'RESPONSES'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RESPONSES'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>230
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(90089909189108080446)
,p_name=>'LENGTH'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LENGTH'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>240
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(87556429710881654556)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(48271689010712978405)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_source_type=>'NATIVE_FACETED_SEARCH'
,p_filtered_region_id=>wwv_flow_imp.id(87556429646410654556)
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_plug_display_when_condition=>'P100_SESSION_CNT'
,p_plug_display_when_cond2=>'0'
,p_landmark_label=>'Filters'
,p_attribute_01=>'N'
,p_attribute_06=>'E'
,p_attribute_08=>'#active_facets'
,p_attribute_09=>'Y'
,p_attribute_10=>'Matching Sessions'
,p_attribute_12=>'10000'
,p_attribute_13=>'Y'
,p_attribute_15=>'10'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(87556432718455654558)
,p_plug_name=>'Button Bar'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(48271625037724978380)
,p_plug_display_sequence=>10
,p_plug_source=>'<div id="active_facets"></div>'
,p_plug_query_num_rows=>15
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_plug_display_when_condition=>'P100_SESSION_CNT'
,p_plug_display_when_cond2=>'0'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(87568094621327432240)
,p_plug_name=>'no sessions yet'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>wwv_flow_imp.id(48271616986112978376)
,p_plug_display_sequence=>30
,p_plug_source=>'Create your first Q&A Session by clicking the New Session button.'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P100_SESSION_CNT'
,p_plug_display_when_cond2=>'0'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(87566714849600904115)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(87556428701737654553)
,p_button_name=>'new_session'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(48272162491040978436)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'New Session'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:111:&SESSION.::&DEBUG.:111::'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(87556433212275654558)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(87556432718455654558)
,p_button_name=>'RESET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(48272162491040978436)
,p_button_image_alt=>'Reset'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&APP_SESSION.::&DEBUG.:RR,100::'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(87556430246137654556)
,p_name=>'P100_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(87556429710881654556)
,p_prompt=>'Search'
,p_source=>'SESSION_CODE,SESSION_STATUS,SESSION_NAME,PURPOSE'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attribute_01=>'ROW'
,p_attribute_02=>'FACET'
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(87556431335599654557)
,p_name=>'P100_SESSION_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(87556429710881654556)
,p_prompt=>'Status'
,p_source=>'SESSION_STATUS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov_sort_direction=>'ASC'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(87556431748983654557)
,p_name=>'P100_QUESTION_COUNT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(87556429710881654556)
,p_prompt=>'Questions'
,p_source=>'QUESTION_CNT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov=>'STATIC2:0;|0,1-3;1|3,4-7;4|7,8+;8|'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(87556432105061654558)
,p_name=>'P100_RESPONSE_COUNT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(87556429710881654556)
,p_prompt=>'Participants'
,p_source=>'RESPONSE_CNT'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_RANGE'
,p_lov=>'STATIC2:0;|0,1-5;1|5,6-20;6|20,21-50;21|50,> 50;51|'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_fc_show_label=>true
,p_fc_collapsible=>false
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_show_more_count=>7
,p_fc_filter_values=>false
,p_fc_show_selected_first=>false
,p_fc_show_chart=>true
,p_fc_initial_chart=>false
,p_fc_actions_filter=>true
,p_fc_toggleable=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(90089909308906080447)
,p_name=>'P100_SESSION_CNT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(87556428701737654553)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(90089909437217080448)
,p_computation_sequence=>10
,p_computation_item=>'P100_SESSION_CNT'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select count(*) cnt',
'  from qask_sessions',
' where owner = lower(:APP_USER)'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(90089909476646080449)
,p_name=>'hide left facet region'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P100_SESSION_CNT'
,p_display_when_cond2=>'0'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(90089909622847080450)
,p_event_id=>wwv_flow_imp.id(90089909476646080449)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$(''#t_Body_side'').remove();'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(87568093946765432233)
,p_region_id=>wwv_flow_imp.id(87556429646410654556)
,p_position_id=>wwv_flow_imp.id(50067050091719465028)
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.:120:P120_SESSION_ID:&ID.'
);
wwv_flow_imp.component_end;
end;
/
