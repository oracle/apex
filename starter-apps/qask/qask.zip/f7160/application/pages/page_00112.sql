prompt --application/pages/page_00112
begin
--   Manifest
--     PAGE: 00112
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1905173489740762914
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>112
,p_name=>'Ask Question'
,p_alias=>'ASK-QUESTION'
,p_step_title=>'Ask Question'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(60909256445865390947)
,p_javascript_file_urls=>'#APP_FILES#jquery.qrcode.min.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'	jQuery(''#qr_code'').qrcode({',
'        render	: "table",',
'		text	: ''&P112_SESSION_URL!RAW.''',
'	});	',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
':root {',
'    --a-button-gap-x: 1rem;',
'    --ut-field-label-font-weight: 700;',
'    ',
'    /* autocomplete overrides */',
'    --a-menu-background-color: var(--a-button-background-color);',
'    --ut-cardlist-background-color: var(--a-button-background-color);',
'    --a-menu-padding-y:	0rem;',
'    --oj-collection-list-row-height: 0;',
'    --oj-collection-list-cell-padding-vertical: 0.5rem;',
'}',
'.qr-container {',
'    min-height: 348px;',
'    display: flex;',
'    align-items: center;',
'    justify-content: center;',
'    flex-direction: column;',
'}',
'#qr_code {',
'    padding: 8px;',
'    background-color: white;',
'}',
'.qr-container h2 {',
'    margin: 0 0 16px 0;',
'    font-weight: 700;',
'}',
'',
'.t-BadgeList + .t-Report-pagination {',
'    display: none;',
'}',
'',
'',
'',
'@media (max-width: 990px) {',
'    .region-question-details,',
'    .region-qr {',
'        max-width: 100%;',
'        padding-inline-end: 0;',
'        padding-inline-start: 0;',
'    }',
'}',
'',
'@media (max-width: 639px) {',
'    .t-ButtonRegion {',
'        background-color: white;',
'        margin-bottom: 0;',
'        border-top: 1px solid rgba(0,0,0,.1);',
'        padding: 16px !important;',
'    }',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(50177448752025741407)
,p_protection_level=>'C'
,p_deep_linking=>'N'
,p_page_component_map=>'16'
,p_last_updated_by=>'SBKENNED'
,p_last_upd_yyyymmddhh24miss=>'20240328200154'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(161434150849323139919)
,p_plug_name=>'Question &P112_QUESTION_NUMBER.'
,p_icon_css_classes=>'fa-clipboard-check'
,p_region_template_options=>'#DEFAULT#:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(50176862500453741319)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'region-question-details'
,p_query_type=>'TABLE'
,p_query_table=>'QASK_SESSION_QUESTIONS'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(67628462158313814148)
,p_plug_name=>'Comment Container'
,p_parent_plug_id=>wwv_flow_imp.id(161434150849323139919)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--scrollBody:margin-top-none'
,p_plug_template=>wwv_flow_imp.id(50176862500453741319)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(164188226060545203410)
,p_plug_name=>'Custom Answers Containers'
,p_parent_plug_id=>wwv_flow_imp.id(161434150849323139919)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--noUI:t-Region--scrollBody:margin-bottom-none'
,p_plug_template=>wwv_flow_imp.id(50176862500453741319)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(181511389281998040061)
,p_plug_name=>'Session QR'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:is-collapsed:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(50176814689292741300)
,p_plug_display_sequence=>35
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>4
,p_plug_grid_column_css_classes=>'region-qr'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="qr-container">',
'    <!--<h2 class="u-tC">Scan QR code to participate!</h2> -->',
'    <h3 class="u-tC">Scan QR code to participate</3>',
'    <div id="qr_code"></div>',
'</div>'))
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P112_SESSION_STATUS'
,p_plug_display_when_cond2=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(191428902659030344816)
,p_plug_name=>'&P112_SESSION_CODE. - &P112_SESSION_NAME.'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_plug_template=>wwv_flow_imp.id(50176829188621741306)
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_01'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(162124769978807480595)
,p_plug_name=>'Button Container'
,p_parent_plug_id=>wwv_flow_imp.id(191428902659030344816)
,p_region_css_classes=>'padding-none'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--stickToBottom:t-ButtonRegion--noPadding:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(50176798527465741294)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(51488048964666012207)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(162124769978807480595)
,p_button_name=>'close_session'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(50177335950289741350)
,p_button_image_alt=>'Close Session'
,p_button_position=>'CHANGE'
,p_confirm_message=>'Are you sure you want to close this session.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(51488049393713012207)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(162124769978807480595)
,p_button_name=>'ASK_QUESTION'
,p_button_static_id=>'ASK_QUESTION'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(50177335950289741350)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Ask Question'
,p_button_position=>'CHANGE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(24340097309616573944)
,p_branch_name=>'ask another (for staged'
,p_branch_action=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:112:P112_SESSION_ID:&P112_SESSION_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(51488049393713012207)
,p_branch_sequence=>10
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P112_SESSION_STATUS'
,p_branch_condition_text=>'STAGED'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(51488061423712012213)
,p_branch_name=>'branch to question'
,p_branch_action=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:113:P113_QUESTION_ID,P113_SESSION_ID:&P112_ID.,&P112_SESSION_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(51488049393713012207)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(51488062208222012214)
,p_branch_name=>'close session when staged'
,p_branch_action=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:RP,100,112:P100_SESSION_STATUS:Drafted&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(51488048964666012207)
,p_branch_sequence=>40
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P112_SESSION_STATUS'
,p_branch_condition_text=>'STAGED'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(24340099111963573962)
,p_branch_name=>'close session when open'
,p_branch_action=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:RP,100,112:P100_SESSION_STATUS:Closed&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(51488048964666012207)
,p_branch_sequence=>50
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24340096622499573937)
,p_name=>'P112_SESSION_STATUS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(161434150849323139919)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61011297373866492147)
,p_name=>'P112_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(161434150849323139919)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61011297519862492148)
,p_name=>'P112_SESSION_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(161434150849323139919)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61011297646779492149)
,p_name=>'P112_QUESTION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(161434150849323139919)
,p_item_source_plug_id=>wwv_flow_imp.id(161434150849323139919)
,p_prompt=>'Question'
,p_source=>'QUESTION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(50177334664429741349)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'The question that will be asked.  Remember to include a question mark at the end (if appropriate).'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61011297815203492151)
,p_name=>'P112_ANSWER_SET_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(161434150849323139919)
,p_item_source_plug_id=>wwv_flow_imp.id(161434150849323139919)
,p_prompt=>'Answer Set'
,p_source=>'ANSWER_SET_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with a as (select answer_set_id, ',
'                  listagg(answer_text, '', '') within group (order by display_order) answers',
'             from qask_aset_answers',
'            group by answer_set_id) ',
'select s.answer_set_name || ',
'          '' (''||substr(a.answers,1,100)||case when length(a.answers) > 100 then ''...'' end ||'')'' d, ',
'       s.id r',
'  from qask_answer_sets s, a',
' where s.id = a.answer_set_id',
' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Custom Answers'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(50177333414722741348)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_help_text=>'Select a standard set of answers for your question (or provide custom answers below).'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61011297961051492153)
,p_name=>'P112_ASK_FOR_COMMENTS_YN'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(67628462158313814148)
,p_item_source_plug_id=>wwv_flow_imp.id(161434150849323139919)
,p_prompt=>'Ask For Comments?'
,p_source=>'ASK_FOR_COMMENTS_YN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(50177333414722741348)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'If you Ask for Comments, a text field will be displayed to gather additional information from your participants.  Make sure you explain what you want filled in here in your question (or question explanation).'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61011298210608492155)
,p_name=>'P112_QUESTION_EXPLANATION'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(161434150849323139919)
,p_item_source_plug_id=>wwv_flow_imp.id(161434150849323139919)
,p_prompt=>'Question Explanation'
,p_source=>'QUESTION_EXPLANATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>2
,p_field_template=>wwv_flow_imp.id(50177333414722741348)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>'Additional details you may need to share to further explain the question.'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61011298321522492156)
,p_name=>'P112_QUESTION_FILENAME'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(161434150849323139919)
,p_prompt=>'Image'
,p_display_as=>'NATIVE_IMAGE_UPLOAD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(50177333414722741348)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Drag and drop a file containing an image to display below your question.  This can be used to ask things like "What animal is this?".'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'DROPZONE_ICON'
,p_attribute_16=>'600'
,p_attribute_17=>'600'
,p_attribute_18=>'Y'
,p_attribute_19=>'AUTO'
,p_attribute_23=>'AUTO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(67628461983533814146)
,p_name=>'P112_ANSWER_TYPE'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(161434150849323139919)
,p_item_default=>'SINGLE'
,p_prompt=>'Answer Type'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'ANSWER TYPE'
,p_lov=>'.'||wwv_flow_imp.id(75040565480674010959)||'.'
,p_field_template=>wwv_flow_imp.id(50177334664429741349)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_help_text=>'Indicate whether the participants will select just one answer, multiple answers of if you want the response to be free form text (in which case you do not need to supply answers to display).'
,p_attribute_01=>'3'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75503613852550312863)
,p_name=>'P112_SESSION_URL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(161434150849323139919)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(164184564332004092080)
,p_name=>'P112_SESSION_CODE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(161434150849323139919)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(164188230463802203419)
,p_name=>'P112_ANSWERS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(164188226060545203410)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Answer 1',
'Answer 2'))
,p_prompt=>'Custom Answers (enter one answer per line)'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cHeight=>7
,p_field_template=>wwv_flow_imp.id(50177333275716741348)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--xlarge'
,p_help_text=>'Enter your custom answers, one per line.'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(164193314151362348933)
,p_name=>'P112_SESSION_NAME'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(161434150849323139919)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(164193326710949353763)
,p_name=>'P112_QUESTION_NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(161434150849323139919)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(24340097412337573945)
,p_validation_name=>'Question required when adding question'
,p_validation_sequence=>10
,p_validation=>'P112_QUESTION'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Question must have some value.'
,p_when_button_pressed=>wwv_flow_imp.id(51488049393713012207)
,p_associated_item=>wwv_flow_imp.id(61011297646779492149)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(74505428511149517571)
,p_validation_name=>'check for FREEFORM, answer set or answer'
,p_validation_sequence=>20
,p_validation=>':P112_ANSWER_SET_ID is not null or :P112_ANSWERS is not null'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Answers must be provided'
,p_validation_condition=>'P112_ANSWER_TYPE'
,p_validation_condition2=>'FREEFORM'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(51488049393713012207)
,p_associated_item=>wwv_flow_imp.id(164188230463802203419)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(15777009483735929270)
,p_validation_name=>'P112_SESSION_ID is not null'
,p_validation_sequence=>30
,p_validation=>'P112_SESSION_ID'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Session is null, expecting a value'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(67628462324272814149)
,p_name=>'when change answer type'
,p_event_sequence=>5
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P112_ANSWER_TYPE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75503611933138312843)
,p_event_id=>wwv_flow_imp.id(67628462324272814149)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'show answers for SINGLE'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_ANSWERS'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P112_ANSWER_TYPE'
,p_client_condition_expression=>'SINGLE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75503611770476312842)
,p_event_id=>wwv_flow_imp.id(67628462324272814149)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'show answer set for SINGLE'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_ANSWER_SET_ID'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P112_ANSWER_TYPE'
,p_client_condition_expression=>'SINGLE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75503612119243312845)
,p_event_id=>wwv_flow_imp.id(67628462324272814149)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_name=>'show comments for SINGLE'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_ASK_FOR_COMMENTS_YN'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P112_ANSWER_TYPE'
,p_client_condition_expression=>'SINGLE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75503611996395312844)
,p_event_id=>wwv_flow_imp.id(67628462324272814149)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_name=>'show answers for MULTI'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_ANSWERS'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P112_ANSWER_TYPE'
,p_client_condition_expression=>'MULTI'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75503611432512312838)
,p_event_id=>wwv_flow_imp.id(67628462324272814149)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_name=>'hide answer set for MULTI'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_ANSWER_SET_ID'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P112_ANSWER_TYPE'
,p_client_condition_expression=>'MULTI'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(67628462388329814150)
,p_event_id=>wwv_flow_imp.id(67628462324272814149)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_name=>'hide comments for MULTI'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_ASK_FOR_COMMENTS_YN'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P112_ANSWER_TYPE'
,p_client_condition_expression=>'MULTI'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75503612220864312846)
,p_event_id=>wwv_flow_imp.id(67628462324272814149)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'Y'
,p_name=>'show comments for FREEFORM'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_ASK_FOR_COMMENTS_YN'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P112_ANSWER_TYPE'
,p_client_condition_expression=>'FREEFORM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75503611688772312841)
,p_event_id=>wwv_flow_imp.id(67628462324272814149)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'N'
,p_name=>'hide answers for FREEFORM'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_ANSWERS'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P112_ANSWER_TYPE'
,p_client_condition_expression=>'FREEFORM'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75503611638878312840)
,p_event_id=>wwv_flow_imp.id(67628462324272814149)
,p_event_result=>'TRUE'
,p_action_sequence=>100
,p_execute_on_page_init=>'N'
,p_name=>'hide answer set for FREEFORM'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_ANSWER_SET_ID'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P112_ANSWER_TYPE'
,p_client_condition_expression=>'FREEFORM'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(61011300150740492174)
,p_name=>'when select answer set'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P112_ANSWER_SET_ID'
,p_condition_element=>'P112_ANSWER_SET_ID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61011300201697492175)
,p_event_id=>wwv_flow_imp.id(61011300150740492174)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'hide answer'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_ANSWERS'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61011300310716492176)
,p_event_id=>wwv_flow_imp.id(61011300150740492174)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'show answer'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P112_ANSWERS'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(48063202643850590823)
,p_name=>'change button name'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'EXISTS'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions',
' where id = :P112_SESSION_ID',
'   and session_status = ''STAGED'''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48063202986583590825)
,p_event_id=>wwv_flow_imp.id(48063202643850590823)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.item("ASK_QUESTION").setValue("Add Question");'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(61011300417528492177)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'when freeform, clear answers and answerset'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P112_ANSWERS := null;',
':P112_ANSWER_SET_ID := null;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(51488049393713012207)
,p_process_when=>'P112_ANSWER_TYPE'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'FREEFORM'
,p_internal_uid=>57262746865551183341
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15777009421124929269)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'when answer set, clear answers'
,p_process_sql_clob=>':P112_ANSWERS := null;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(51488049393713012207)
,p_process_when=>'P112_ANSWER_SET_ID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>12028455869147620433
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(51488053101269012209)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'create question'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P112_ID := qask_util.add_question (',
'    p_session_id                 => :P112_SESSION_ID,',
'    p_question_number            => :P112_QUESTION_NUMBER,',
'    p_question                   => :P112_QUESTION,',
'    p_answer_set_id              => :P112_ANSWER_SET_ID,',
'    p_answers                    => :P112_ANSWERS,',
'    p_answer_type                => :P112_ANSWER_TYPE,',
'    p_ask_for_comments_yn        => case when :P112_ANSWER_TYPE != ''MULTI'' then :P112_ASK_FOR_COMMENTS_YN else ''N'' end,',
'    p_question_explanation       => :P112_QUESTION_EXPLANATION,',
'    p_question_filename          => :P112_QUESTION_FILENAME',
');'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'#SQLERRM#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(51488049393713012207)
,p_internal_uid=>47739499549291703373
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(51488053507525012210)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'close session'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P112_SESSION_ID is null then ',
'     raise_application_error(-20111,''Session is null, expecting a value'');',
'end if;',
'',
'qask_util.close_session (',
'    p_session_id => :P112_SESSION_ID);'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Unable to close session'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(51488048964666012207)
,p_process_when=>'P112_SESSION_STATUS'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'OPEN'
,p_process_success_message=>'Session &P112_SESSION_CODE. Closed'
,p_internal_uid=>47739499955547703374
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(24340096737014573938)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'load Details'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_dont_need  varchar2(4000);',
'    x            varchar2(4000);',
'begin ',
'',
'    qask_util.get_session_details (',
'        p_session_id             => :P112_SESSION_ID,',
'        p_session_name           => :P112_SESSION_NAME,',
'        p_session_code           => :P112_SESSION_CODE,',
'        p_purpose                => l_dont_need,',
'        p_resp_name_required_yn  => l_dont_need,',
'        p_resp_email_required_yn => l_dont_need,',
'        p_session_status         => :P112_SESSION_STATUS );',
'',
'    :P112_QUESTION_NUMBER := qask_util.get_next_question_number (p_session_id => :P112_SESSION_ID);',
'',
'    x := apex_page.get_url (',
'           p_page => ''home'',',
'           p_session => 0,',
'           p_items => ''P1_CODE'',',
'           p_values => :P112_SESSION_CODE );',
'    x := substr(x,1,instr(x,''&'')-1);',
'',
'    :P112_SESSION_URL := rtrim(owa_util.get_cgi_env(''HTTP_REFERER''),''/'') || x;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>20591543185037265102
);
wwv_flow_imp.component_end;
end;
/
