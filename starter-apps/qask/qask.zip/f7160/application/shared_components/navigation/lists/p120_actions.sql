prompt --application/shared_components/navigation/lists/p120_actions
begin
--   Manifest
--     LIST: p120_actions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>26987669612026766
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(55640771471003049182)
,p_name=>'p120_actions'
,p_list_status=>'PUBLIC'
,p_version_scn=>37167711609130
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(55640771700800049182)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Add Question'
,p_list_item_link_target=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.:112:P112_SESSION_ID:&P120_SESSION_ID.:'
,p_list_item_icon=>'fa-plus'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions',
' where id = :P120_SESSION_ID',
'   and session_status = ''STAGED''',
'   and owner = lower(:APP_USER)'))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(55640772091097049183)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Copy Session'
,p_list_item_link_target=>'f?p=&APP_ID.:115:&SESSION.::&DEBUG.:115:P115_ID:&P120_SESSION_ID.:'
,p_list_item_icon=>'fa-copy'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from qask_sessions',
' where id = :P120_SESSION_ID',
'   and session_status in (''STAGED'',''CLOSED'')',
'   and owner = lower(:APP_USER)'))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(55640772459777049183)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Delete Session'
,p_list_item_link_target=>'f?p=&APP_ID.:116:&SESSION.::&DEBUG.:116:P116_SESSION_ID:&P120_SESSION_ID.:'
,p_list_item_icon=>'fa-trash-o'
,p_list_item_disp_cond_type=>'EXPRESSION'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'qask_util.get_session_status(p_session_id => :P120_SESSION_ID) in (''STAGED'',''CLOSED'') and',
'qask_util.get_session_owner(p_session_id => :P120_SESSION_ID) = :APP_USER'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
