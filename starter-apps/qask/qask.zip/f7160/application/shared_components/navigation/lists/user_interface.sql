prompt --application/shared_components/navigation/lists/user_interface
begin
--   Manifest
--     LIST: User Interface
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(48319459158834830349)
,p_name=>'User Interface'
,p_list_status=>'PUBLIC'
,p_version_scn=>37167711609130
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(11316651348148517451)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Settings'
,p_list_item_link_target=>'f?p=&APP_ID.:10011:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gears'
,p_list_text_01=>'Manage the settings that govern this application'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(59247433511357872021)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Service Terms'
,p_list_item_link_target=>'f?p=&APP_ID.:10012:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-check'
,p_list_text_01=>'Terms that Hosts must accept in order to use this platform'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
