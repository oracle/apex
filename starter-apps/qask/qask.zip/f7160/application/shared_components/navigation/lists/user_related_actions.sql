prompt --application/shared_components/navigation/lists/user_related_actions
begin
--   Manifest
--     LIST: User Related Actions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(48319462587123830351)
,p_name=>'User Related Actions'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(48319318005731829870)
,p_version_scn=>37167711609130
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(48319462969353830351)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Users'
,p_list_item_link_target=>'f?p=&APP_ID.:10031:&APP_SESSION.::&DEBUG.:RP::'
,p_list_item_icon=>'fa-users'
,p_list_text_01=>'Set level of access for authenticated users of this application'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(48319463348301830351)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Account Requests'
,p_list_item_link_target=>'f?p=&APP_ID.:10035:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-key'
,p_list_text_01=>'Review requests for accounts (for creating sessions)'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14050839720630573131)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Restricted To Email Domains'
,p_list_item_link_target=>'f?p=&APP_ID.:10037:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-envelope-check'
,p_list_text_01=>'Control email domains that can be added as users'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(59241908852760794189)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Accepted Service Terms'
,p_list_item_link_target=>'f?p=&APP_ID.:10014:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-signature'
,p_list_text_01=>'All users that have accepted Service Terms'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
