prompt --application/shared_components/navigation/lists/user_related_actions
begin
--   Manifest
--     LIST: User Related Actions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>26987669612026766
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(48299405072538005739)
,p_name=>'User Related Actions'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(48299260491146005258)
,p_version_scn=>37167711609130
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(48299405454768005739)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Users'
,p_list_item_link_target=>'f?p=&APP_ID.:10031:&APP_SESSION.::&DEBUG.:RP::'
,p_list_item_icon=>'fa-users'
,p_list_text_01=>'Set level of access for authenticated users of this application'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(48299405833716005739)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Account Requests'
,p_list_item_link_target=>'f?p=&APP_ID.:10035:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-key'
,p_list_text_01=>'Review requests for accounts (for creating sessions)'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(14030782206044748519)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Restricted To Email Domains'
,p_list_item_link_target=>'f?p=&APP_ID.:10037:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-envelope-check'
,p_list_text_01=>'Control email domains that can be added as users'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(59221851338174969577)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Accepted Service Terms'
,p_list_item_link_target=>'f?p=&APP_ID.:10014:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-signature'
,p_list_text_01=>'All users that have accepted Service Terms'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
