prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>26987669612026766
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(48298573222035005128)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4826500343914104271)
,p_short_name=>'Account Requests'
,p_link=>'f?p=&APP_ID.:10035:&SESSION.::&DEBUG.:::'
,p_page_id=>10035
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48298573416467005129)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48299401505178005737)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:10000:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49110075808120670051)
,p_short_name=>'Activity Dashboard'
,p_link=>'f?p=&APP_ID.:10020:&SESSION.::&DEBUG.:::'
,p_page_id=>10020
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49111956203079057026)
,p_short_name=>'Settings'
,p_link=>'f?p=&APP_ID.:10011:&SESSION.::&DEBUG.:::'
,p_page_id=>10011
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49112690841201759651)
,p_short_name=>'Application Error Log'
,p_link=>'f?p=&APP_ID.:10022:&SESSION.::&DEBUG.:::'
,p_page_id=>10022
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49114134070514772854)
,p_short_name=>'Page Performance'
,p_link=>'f?p=&APP_ID.:10023:&SESSION.::&DEBUG.:::'
,p_page_id=>10023
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49114209976383784332)
,p_short_name=>'Page Views'
,p_link=>'f?p=&APP_ID.:10024:&SESSION.::&DEBUG.:::'
,p_page_id=>10024
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49116481208801112057)
,p_short_name=>'Logged Messages'
,p_link=>'f?p=&APP_ID.:10026:&SESSION.::&DEBUG.:::'
,p_page_id=>10026
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49116986770040119051)
,p_short_name=>'Manage User Access'
,p_link=>'f?p=&APP_ID.:10031:&SESSION.::&DEBUG.:::'
,p_page_id=>10031
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49118163526120831071)
,p_short_name=>'Restricted To Email Domains'
,p_link=>'f?p=&APP_ID.:10037:&SESSION.::&DEBUG.:::'
,p_page_id=>10037
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49118455827744156131)
,p_short_name=>'Email Reporting'
,p_link=>'f?p=&APP_ID.:10050:&SESSION.::&DEBUG.:::'
,p_page_id=>10050
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49118476336450162687)
,p_short_name=>'Job Reporting'
,p_link=>'f?p=&APP_ID.:10051:&SESSION.::&DEBUG.:::'
,p_page_id=>10051
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49606463796433379645)
,p_short_name=>'Create Session'
,p_link=>'f?p=&APP_ID.:111:&SESSION.::&DEBUG.:::'
,p_page_id=>111
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(53722952266256279460)
,p_parent_id=>wwv_flow_imp.id(72608302372305491869)
,p_short_name=>'Copy Session'
,p_link=>'f?p=&APP_ID.:115:&SESSION.::&DEBUG.:::'
,p_page_id=>115
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(59224541430601018232)
,p_short_name=>'Service Terms'
,p_link=>'f?p=&APP_ID.:10012:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10012
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(59225742822460030495)
,p_short_name=>'Accepted Service Terms'
,p_link=>'f?p=&APP_ID.:10014:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10014
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(63277350042200444165)
,p_short_name=>'Responses - &P113_SESSION_NAME.'
,p_link=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:::'
,p_page_id=>113
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(72537925916388668377)
,p_parent_id=>wwv_flow_imp.id(72608302372305491869)
,p_short_name=>'Question Summary'
,p_link=>'f?p=&APP_ID.:121:&SESSION.::&DEBUG.:::'
,p_page_id=>121
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(72608302372305491869)
,p_short_name=>'&P120_SESSION_CODE. Session Summary'
,p_link=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.:::'
,p_page_id=>120
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(87583416844488681320)
,p_short_name=>'Q&A Sessions'
,p_link=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_page_id=>100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(89744799980943434254)
,p_short_name=>'All Sessions'
,p_link=>'f?p=&APP_ID.:10005:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10005
);
wwv_flow_imp.component_end;
end;
/
