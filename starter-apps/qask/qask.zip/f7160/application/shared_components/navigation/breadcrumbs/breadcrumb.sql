prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(48318630736620829740)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4846557858499928883)
,p_short_name=>'Account Requests'
,p_link=>'f?p=&APP_ID.:10035:&SESSION.::&DEBUG.:::'
,p_page_id=>10035
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48318630931052829741)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48319459019763830349)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:10000:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49130133322706494663)
,p_short_name=>'Activity Dashboard'
,p_link=>'f?p=&APP_ID.:10020:&SESSION.::&DEBUG.:::'
,p_page_id=>10020
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49132013717664881638)
,p_short_name=>'Settings'
,p_link=>'f?p=&APP_ID.:10011:&SESSION.::&DEBUG.:::'
,p_page_id=>10011
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49132748355787584263)
,p_short_name=>'Application Error Log'
,p_link=>'f?p=&APP_ID.:10022:&SESSION.::&DEBUG.:::'
,p_page_id=>10022
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49134191585100597466)
,p_short_name=>'Page Performance'
,p_link=>'f?p=&APP_ID.:10023:&SESSION.::&DEBUG.:::'
,p_page_id=>10023
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49134267490969608944)
,p_short_name=>'Page Views'
,p_link=>'f?p=&APP_ID.:10024:&SESSION.::&DEBUG.:::'
,p_page_id=>10024
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49136538723386936669)
,p_short_name=>'Logged Messages'
,p_link=>'f?p=&APP_ID.:10026:&SESSION.::&DEBUG.:::'
,p_page_id=>10026
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49137044284625943663)
,p_short_name=>'Manage User Access'
,p_link=>'f?p=&APP_ID.:10031:&SESSION.::&DEBUG.:::'
,p_page_id=>10031
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49138221040706655683)
,p_short_name=>'Restricted To Email Domains'
,p_link=>'f?p=&APP_ID.:10037:&SESSION.::&DEBUG.:::'
,p_page_id=>10037
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49138513342329980743)
,p_short_name=>'Email Reporting'
,p_link=>'f?p=&APP_ID.:10050:&SESSION.::&DEBUG.:::'
,p_page_id=>10050
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49138533851035987299)
,p_short_name=>'Job Reporting'
,p_link=>'f?p=&APP_ID.:10051:&SESSION.::&DEBUG.:::'
,p_page_id=>10051
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49626521311019204257)
,p_short_name=>'Create Session'
,p_link=>'f?p=&APP_ID.:111:&SESSION.::&DEBUG.:::'
,p_page_id=>111
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(53743009780842104072)
,p_parent_id=>wwv_flow_imp.id(72628359886891316481)
,p_short_name=>'Copy Session'
,p_link=>'f?p=&APP_ID.:115:&SESSION.::&DEBUG.:::'
,p_page_id=>115
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(59244598945186842844)
,p_short_name=>'Service Terms'
,p_link=>'f?p=&APP_ID.:10012:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10012
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(59245800337045855107)
,p_short_name=>'Accepted Service Terms'
,p_link=>'f?p=&APP_ID.:10014:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10014
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(63297407556786268777)
,p_short_name=>'Responses - &P113_SESSION_NAME.'
,p_link=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:::'
,p_page_id=>113
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(72557983430974492989)
,p_parent_id=>wwv_flow_imp.id(72628359886891316481)
,p_short_name=>'Question Summary'
,p_link=>'f?p=&APP_ID.:121:&SESSION.::&DEBUG.:::'
,p_page_id=>121
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(72628359886891316481)
,p_short_name=>'&P120_SESSION_CODE. Session Summary'
,p_link=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.:::'
,p_page_id=>120
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(87603474359074505932)
,p_short_name=>'Q&A Sessions'
,p_link=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_page_id=>100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(89764857495529258866)
,p_short_name=>'All Sessions'
,p_link=>'f?p=&APP_ID.:10005:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10005
);
wwv_flow_imp.component_end;
end;
/
