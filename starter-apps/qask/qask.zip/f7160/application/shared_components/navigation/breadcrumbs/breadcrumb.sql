prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1843380062236545922
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(48271585552422978362)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(4799512674302077505)
,p_short_name=>'Account Requests'
,p_link=>'f?p=&APP_ID.:10035:&SESSION.::&DEBUG.:::'
,p_page_id=>10035
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48271585746854978363)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48272413835565978971)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:10000:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49083088138508643285)
,p_short_name=>'Activity Dashboard'
,p_link=>'f?p=&APP_ID.:10020:&SESSION.::&DEBUG.:::'
,p_page_id=>10020
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49084968533467030260)
,p_short_name=>'Settings'
,p_link=>'f?p=&APP_ID.:10011:&SESSION.::&DEBUG.:::'
,p_page_id=>10011
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49085703171589732885)
,p_short_name=>'Application Error Log'
,p_link=>'f?p=&APP_ID.:10022:&SESSION.::&DEBUG.:::'
,p_page_id=>10022
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49087146400902746088)
,p_short_name=>'Page Performance'
,p_link=>'f?p=&APP_ID.:10023:&SESSION.::&DEBUG.:::'
,p_page_id=>10023
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49087222306771757566)
,p_short_name=>'Page Views'
,p_link=>'f?p=&APP_ID.:10024:&SESSION.::&DEBUG.:::'
,p_page_id=>10024
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49089493539189085291)
,p_short_name=>'Logged Messages'
,p_link=>'f?p=&APP_ID.:10026:&SESSION.::&DEBUG.:::'
,p_page_id=>10026
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49089999100428092285)
,p_short_name=>'Manage User Access'
,p_link=>'f?p=&APP_ID.:10031:&SESSION.::&DEBUG.:::'
,p_page_id=>10031
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49091175856508804305)
,p_short_name=>'Restricted To Email Domains'
,p_link=>'f?p=&APP_ID.:10037:&SESSION.::&DEBUG.:::'
,p_page_id=>10037
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49091468158132129365)
,p_short_name=>'Email Reporting'
,p_link=>'f?p=&APP_ID.:10050:&SESSION.::&DEBUG.:::'
,p_page_id=>10050
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49091488666838135921)
,p_short_name=>'Job Reporting'
,p_link=>'f?p=&APP_ID.:10051:&SESSION.::&DEBUG.:::'
,p_page_id=>10051
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49579476126821352879)
,p_short_name=>'Create Session'
,p_link=>'f?p=&APP_ID.:111:&SESSION.::&DEBUG.:::'
,p_page_id=>111
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(53695964596644252694)
,p_parent_id=>wwv_flow_imp.id(72581314702693465103)
,p_short_name=>'Copy Session'
,p_link=>'f?p=&APP_ID.:115:&SESSION.::&DEBUG.:::'
,p_page_id=>115
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(59197553760988991466)
,p_short_name=>'Service Terms'
,p_link=>'f?p=&APP_ID.:10012:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10012
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(59198755152848003729)
,p_short_name=>'Accepted Service Terms'
,p_link=>'f?p=&APP_ID.:10014:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10014
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(63250362372588417399)
,p_short_name=>'Responses - &P113_SESSION_NAME.'
,p_link=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:::'
,p_page_id=>113
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(72510938246776641611)
,p_parent_id=>wwv_flow_imp.id(72581314702693465103)
,p_short_name=>'Question Summary'
,p_link=>'f?p=&APP_ID.:121:&SESSION.::&DEBUG.:::'
,p_page_id=>121
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(72581314702693465103)
,p_short_name=>'&P120_SESSION_CODE. Session Summary'
,p_link=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.:::'
,p_page_id=>120
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(87556429174876654554)
,p_short_name=>'Q&A Sessions'
,p_link=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_page_id=>100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(89717812311331407488)
,p_short_name=>'All Sessions'
,p_link=>'f?p=&APP_ID.:10005:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10005
);
wwv_flow_imp.component_end;
end;
/
