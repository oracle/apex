prompt --application/shared_components/files/app_icon_css
begin
--   Manifest
--     APP STATIC FILES: 7160
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1843380062236545922
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E6170702D69636F6E207B0A202020206261636B67726F756E642D696D6167653A2075726C2869636F6E732F6170702D69636F6E2D3139322E706E67293B0A202020206261636B67726F756E642D7265706561743A206E6F2D7265706561743B0A202020';
wwv_flow_imp.g_varchar2_table(2) := '206261636B67726F756E642D73697A653A20636F7665723B0A202020206261636B67726F756E642D706F736974696F6E3A203530253B0A202020206261636B67726F756E642D636F6C6F723A20233239353836363B0A7D0A0A2E742D416C6572742D6963';
wwv_flow_imp.g_varchar2_table(3) := '6F6E202E6170702D69636F6E207B0A2020202077696474683A2031323870783B0A202020206865696768743A2031323870783B0A7D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(63274502277613816199)
,p_file_name=>'app-icon.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
