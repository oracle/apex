prompt --application/shared_components/security/authentications/email_based_authentication
begin
--   Manifest
--     AUTHENTICATION: email-based authentication
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1905173489740762914
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(12790783328921267823)
,p_name=>'email-based authentication'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'local_auth'
,p_attribute_05=>'N'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function local_auth (',
'    p_username  in  varchar2,',
'    p_password  in  varchar2 )',
'    return boolean',
'is',
'begin',
'    return qask_util.token_is_valid (',
'               p_username => p_username,',
'               p_token    => p_password );',
'end local_auth;'))
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
