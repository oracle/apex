prompt --application/shared_components/security/authorizations/allow_user_requests
begin
--   Manifest
--     SECURITY SCHEME: ALLOW_USER_REQUESTS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1905173489740762914
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(9457608338017732363)
,p_name=>'ALLOW_USER_REQUESTS'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if qask_util.get_setting(''allow_account_requests_yn'') = ''Y'' then',
'   return TRUE;',
'else return FALSE;',
'end if;'))
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
