prompt --application/shared_components/security/authorizations/host
begin
--   Manifest
--     SECURITY SCHEME: Host
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>26987669612026766
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(48299262931897005259)
,p_name=>'Host'
,p_scheme_type=>'NATIVE_IS_IN_GROUP'
,p_attribute_01=>'Administrator,Host'
,p_attribute_02=>'A'
,p_error_message=>'Insufficient privileges, user is not a Host'
,p_version_scn=>37167711609130
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_imp.component_end;
end;
/
