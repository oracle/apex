prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 7160
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1905173489740762914
,p_default_owner=>'ORACLE'
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1905173489740762914
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(8661457414426643679)
,p_name=>'ACCESS_REQUESTS'
,p_message_text=>'Access Requests'
,p_version_scn=>15493767600927
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(20436434216540438146)
,p_name=>'ACCESS_REQUESTS_RESTRICTED_BY_EMAIL_DOMAIN'
,p_message_text=>'Access requests are restricted by email domain.'
,p_version_scn=>15495820361300
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1905173489740762914
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(21890606482580077194)
,p_name=>'APEX.AUTHENTICATION.LOGIN_THROTTLE.COUNTER'
,p_message_text=>'Please wait <span id="apex_login_throttle_sec">%0</span> seconds to verify again.'
,p_version_scn=>15496015297109
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(21891106333290391737)
,p_name=>'APEX.AUTHENTICATION.LOGIN_THROTTLE.ERROR'
,p_message_text=>'The verification attempt has been blocked.'
,p_version_scn=>15496015311829
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1905173489740762914
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(20422234916154265553)
,p_name=>'EMAIL_DOMAIN_NOT_ALLOWED'
,p_message_text=>'Email Domain not allowed.'
,p_version_scn=>15495818467593
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1905173489740762914
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(21888896242388359440)
,p_name=>'INVALID_CREDENTIALS'
,p_message_text=>'Invalid verification code'
,p_version_scn=>15496014953143
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1905173489740762914
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(20439773211543151784)
,p_name=>'UPDATE_SETTINGS_TO_RESTRICT_TO_THESE_DOMAINS'
,p_message_text=>'Update settings if you wish to restrict to these domains.'
,p_version_scn=>15495820576673
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1905173489740762914
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(20436603854641126519)
,p_name=>'USERS_AND_ACCESS_REQUESTS_RESTRICTED_BY_EMAIL_DOMAIN'
,p_message_text=>'Users and Access requests are restricted by email domain.'
,p_version_scn=>15495820367655
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(20435089744941109640)
,p_name=>'USERS_RESTRICTED_BY_EMAIL_DOMAIN'
,p_message_text=>'Users are restricted by email domain.'
,p_version_scn=>15495820199178
);
wwv_flow_imp.component_end;
end;
/
