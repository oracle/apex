prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 7160
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1843380062236545922
,p_default_owner=>'ORACLE'
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1843380062236545922
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(6756283924685880765)
,p_name=>'ACCESS_REQUESTS'
,p_message_text=>'Access Requests'
,p_version_scn=>15493767600927
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(18531260726799675232)
,p_name=>'ACCESS_REQUESTS_RESTRICTED_BY_EMAIL_DOMAIN'
,p_message_text=>'Access requests are restricted by email domain.'
,p_version_scn=>15495820361300
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1843380062236545922
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(19985432992839314280)
,p_name=>'APEX.AUTHENTICATION.LOGIN_THROTTLE.COUNTER'
,p_message_text=>'Please wait <span id="apex_login_throttle_sec">%0</span> seconds to verify again.'
,p_version_scn=>15496015297109
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(19985932843549628823)
,p_name=>'APEX.AUTHENTICATION.LOGIN_THROTTLE.ERROR'
,p_message_text=>'The verification attempt has been blocked.'
,p_version_scn=>15496015311829
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1843380062236545922
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(18517061426413502639)
,p_name=>'EMAIL_DOMAIN_NOT_ALLOWED'
,p_message_text=>'Email Domain not allowed.'
,p_version_scn=>15495818467593
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1843380062236545922
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(19983722752647596526)
,p_name=>'INVALID_CREDENTIALS'
,p_message_text=>'Invalid verification code'
,p_version_scn=>15496014953143
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1843380062236545922
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(18534599721802388870)
,p_name=>'UPDATE_SETTINGS_TO_RESTRICT_TO_THESE_DOMAINS'
,p_message_text=>'Update settings if you wish to restrict to these domains.'
,p_version_scn=>15495820576673
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1843380062236545922
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(18531430364900363605)
,p_name=>'USERS_AND_ACCESS_REQUESTS_RESTRICTED_BY_EMAIL_DOMAIN'
,p_message_text=>'Users and Access requests are restricted by email domain.'
,p_version_scn=>15495820367655
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(18529916255200346726)
,p_name=>'USERS_RESTRICTED_BY_EMAIL_DOMAIN'
,p_message_text=>'Users are restricted by email domain.'
,p_version_scn=>15495820199178
);
wwv_flow_imp.component_end;
end;
/
