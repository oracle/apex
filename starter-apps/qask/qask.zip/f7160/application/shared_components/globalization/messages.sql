prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 7160
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>26987669612026766
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(6783271594297907531)
,p_name=>'ACCESS_REQUESTS'
,p_message_text=>'Access Requests'
,p_version_scn=>15493767600927
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(18558248396411701998)
,p_name=>'ACCESS_REQUESTS_RESTRICTED_BY_EMAIL_DOMAIN'
,p_message_text=>'Access requests are restricted by email domain.'
,p_version_scn=>15495820361300
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(20012420662451341046)
,p_name=>'APEX.AUTHENTICATION.LOGIN_THROTTLE.COUNTER'
,p_message_text=>'Please wait <span id="apex_login_throttle_sec">%0</span> seconds to verify again.'
,p_version_scn=>15496015297109
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(20012920513161655589)
,p_name=>'APEX.AUTHENTICATION.LOGIN_THROTTLE.ERROR'
,p_message_text=>'The verification attempt has been blocked.'
,p_version_scn=>15496015311829
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(18544049096025529405)
,p_name=>'EMAIL_DOMAIN_NOT_ALLOWED'
,p_message_text=>'Email Domain not allowed.'
,p_version_scn=>15495818467593
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(20010710422259623292)
,p_name=>'INVALID_CREDENTIALS'
,p_message_text=>'Invalid verification code'
,p_version_scn=>15496014953143
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(18561587391414415636)
,p_name=>'UPDATE_SETTINGS_TO_RESTRICT_TO_THESE_DOMAINS'
,p_message_text=>'Update settings if you wish to restrict to these domains.'
,p_version_scn=>15495820576673
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(18558418034512390371)
,p_name=>'USERS_AND_ACCESS_REQUESTS_RESTRICTED_BY_EMAIL_DOMAIN'
,p_message_text=>'Users and Access requests are restricted by email domain.'
,p_version_scn=>15495820367655
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(18556903924812373492)
,p_name=>'USERS_RESTRICTED_BY_EMAIL_DOMAIN'
,p_message_text=>'Users are restricted by email domain.'
,p_version_scn=>15495820199178
);
wwv_flow_imp.component_end;
end;
/
