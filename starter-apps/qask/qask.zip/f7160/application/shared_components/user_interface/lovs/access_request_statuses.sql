prompt --application/shared_components/user_interface/lovs/access_request_statuses
begin
--   Manifest
--     ACCESS REQUEST STATUSES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(6372566800759182102)
,p_lov_name=>'ACCESS REQUEST STATUSES'
,p_lov_query=>'.'||wwv_flow_imp.id(6372566800759182102)||'.'
,p_location=>'STATIC'
,p_version_scn=>37167711609134
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(6372567048558182103)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Requested'
,p_lov_return_value=>'REQUESTED'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(6372567492202182103)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Approved'
,p_lov_return_value=>'APPROVED'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(6372567923610182103)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Declined'
,p_lov_return_value=>'DECLINED'
);
wwv_flow_imp.component_end;
end;
/
