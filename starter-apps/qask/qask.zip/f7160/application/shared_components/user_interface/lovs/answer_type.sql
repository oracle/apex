prompt --application/shared_components/user_interface/lovs/answer_type
begin
--   Manifest
--     ANSWER TYPE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1905173489740762914
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(75040565480674010959)
,p_lov_name=>'ANSWER TYPE'
,p_lov_query=>'.'||wwv_flow_imp.id(75040565480674010959)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(75040565770442010959)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Single Answer'
,p_lov_return_value=>'SINGLE'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(75040566249841010960)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Multiple Answers'
,p_lov_return_value=>'MULTI'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(75040566578328010960)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Free Form Answer'
,p_lov_return_value=>'FREEFORM'
);
wwv_flow_imp.component_end;
end;
/
