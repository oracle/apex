prompt --application/shared_components/logic/application_items/accepted_terms_yn
begin
--   Manifest
--     APPLICATION ITEM: ACCEPTED_TERMS_YN
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(56831687544262672113)
,p_name=>'ACCEPTED_TERMS_YN'
,p_protection_level=>'I'
,p_version_scn=>15503806003974
);
wwv_flow_imp.component_end;
end;
/
