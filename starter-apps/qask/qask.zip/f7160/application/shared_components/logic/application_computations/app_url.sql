prompt --application/shared_components/logic/application_computations/app_url
begin
--   Manifest
--     APPLICATION COMPUTATION: APP_URL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1843380062236545922
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(6292472198341771701)
,p_computation_sequence=>10
,p_computation_item=>'APP_URL'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    x  varchar2(4000);',
'begin ',
'    x := apex_page.get_url (',
'           p_page    => ''home'',',
'           p_session => 0 );',
'    x := substr(x,1,instr(x,''?'')-1);',
'',
'    return rtrim(owa_util.get_cgi_env(''HTTP_REFERER''),''/'') || x;',
'end;'))
,p_compute_when=>'APP_URL'
,p_compute_when_type=>'ITEM_IS_NULL'
,p_version_scn=>15514749905199
);
wwv_flow_imp.component_end;
end;
/
