prompt --application/shared_components/logic/application_processes/check_service_terms
begin
--   Manifest
--     APPLICATION PROCESS: Check Service Terms
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(56785106222727168934)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Check Service Terms'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if nvl(:ACCEPTED_TERMS_YN,''N'') = ''N'' then',
'   if qask_util.has_accepted_latest_terms_yn (p_email => :APP_USER) = ''Y'' then',
'       :ACCEPTED_TERMS_YN := ''Y'';',
'   else apex_util.redirect_url(apex_page.get_url(',
'                                   p_application => :APP_ID,',
'                                   p_page        => ''9995'',',
'                                   p_session     => :APP_SESSION ));',
'   end if;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'9995,9998,9999'
,p_process_when_type=>'CURRENT_PAGE_NOT_IN_CONDITION'
,p_security_scheme=>wwv_flow_imp.id(48319320446482829871)
,p_version_scn=>15504581679406
);
wwv_flow_imp.component_end;
end;
/
