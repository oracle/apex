prompt --application/shared_components/logic/application_processes/check_email_from
begin
--   Manifest
--     APPLICATION PROCESS: Check Email From
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1905173489740762914
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(62362586060524688409)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Check Email From'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if qask_util.get_setting (p_name => ''from_email'') is null then',
'   apex_util.redirect_url(apex_page.get_url(',
'                                   p_application => :APP_ID,',
'                                   p_page        => ''10010'',',
'                                   p_session     => :APP_SESSION ));',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'9995,9998,9999,10010'
,p_process_when_type=>'CURRENT_PAGE_NOT_IN_CONDITION'
,p_security_scheme=>wwv_flow_imp.id(50177448584005741407)
,p_version_scn=>15504956147600
);
wwv_flow_imp.component_end;
end;
/
