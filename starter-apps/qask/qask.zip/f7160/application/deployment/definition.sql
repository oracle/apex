prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7160
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>1843380062236545922
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(49535109080590213721)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop table qask_log cascade constraints;',
'drop table qask_service_terms cascade constraints;',
'drop table qask_service_term_accepts cascade constraints;',
'drop table qask_restricted_email_domains cascade constraints;',
'drop table qask_settings cascade constraints;',
'drop table qask_account_requests cascade constraints;',
'drop table qask_verify_tokens cascade constraints;',
'drop table qask_answer_sets cascade constraints;',
'drop table qask_aset_answers cascade constraints;',
'drop table qask_sessions cascade constraints;',
'drop table qask_session_questions cascade constraints;',
'drop table qask_sess_question_answers cascade constraints;',
'drop table qask_responses cascade constraints;',
'drop table qask_response_answers cascade constraints;',
'',
'drop package qask_util;',
'',
'begin',
'   dbms_scheduler.drop_job (job_name => ''QASK_CLOSE_OLD_SESSIONS'');',
'end;',
'/'))
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER'
,p_required_names_available=>'QASK_SERVICE_TERMS:QASK_SERVICE_TERM_ACCEPTS:QASK_RESTRICTED_EMAIL_DOMAINS:QASK_SETTINGS:QASK_ACCOUNT_REQUESTS:QASK_VERIFY_TOKENS:QASK_ANSWER_SETS:QASK_ASET_ANSWERS:QASK_SESSIONS:QASK_SESSION_QUESTIONS:QASK_SESS_QUESTION_ANSWERS:QASK_RESPONSES:QASK_R'
||'ESPONSE_ANSWERS:QASK_UTIL:QASK_CLOSE_OLD_SESSIONS:QASK_LOG'
);
wwv_flow_imp.component_end;
end;
/
