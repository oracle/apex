prompt --application/deployment/install/install_add_installing_user
begin
--   Manifest
--     INSTALL: INSTALL-add installing user
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(59296799819025678245)
,p_install_id=>wwv_flow_imp.id(49582154264788065099)
,p_name=>'add installing user'
,p_sequence=>70
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_app_user  varchar2(255) := apex_custom_auth.get_username;',
'begin',
'    for u in (',
'        select case when email is null and regexp_like(l_app_user,''[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}'')',
'                    then l_app_user',
'                    else email',
'                    end email',
'          from apex_workspace_apex_users',
'         where user_name = l_app_user',
'    ) loop',
'      if u.email is not null then',
'        for a in (',
'            select application_id',
'              from apex_applications',
'             where application_name = ''qAsk''',
'             order by last_updated_on desc',
'        ) loop',
'            for r in (',
'                select role_id',
'                  from apex_appl_acl_roles',
'                 where application_id = a.application_id ',
'                   and role_static_id = ''ADMINISTRATOR''',
'            ) loop',
'                qask_util.add_user (',
'                    p_username      => u.email,',
'                    p_role_id       => r.role_id,',
'                    p_send_email_yn => ''N'',',
'                    p_app_id        => a.application_id );',
'                exit;',
'            end loop;',
'            exit;',
'        end loop;',
'      end if;',
'    end loop;',
'end;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
