prompt --application/deployment/install/install_close_old_job
begin
--   Manifest
--     INSTALL: INSTALL-close_old job
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7160
,p_default_id_offset=>20057514585824612
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(59295070736819632563)
,p_install_id=>wwv_flow_imp.id(49582154264788065099)
,p_name=>'close_old job'
,p_sequence=>60
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'   dbms_scheduler.create_job (',
'      job_name        => ''QASK_CLOSE_OLD_SESSIONS'',',
'      job_type        => ''STORED_PROCEDURE'',',
'      job_action      => ''QASK_UTIL.CLOSE_OLD_SESSIONS'',',
'      auto_drop       => false,',
'      comments        => ''Closes any sessions idle for more than the allowed time'');',
'exception when others then',
'    -- ORA-00955: name is already used by an existing object',
'    if sqlcode not in (-955,-27477) then',
'        raise;',
'    end if;',
'end;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
