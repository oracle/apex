prompt --application/create_application
begin
--   Manifest
--     FLOW: 7090
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_imp_workspace.create_flow(
 p_id=>wwv_flow.g_flow_id
,p_owner=>nvl(wwv_flow_application_install.get_schema,'ORACLE')
,p_name=>nvl(wwv_flow_application_install.get_application_name,'Team Calendar')
,p_alias=>nvl(wwv_flow_application_install.get_application_alias,'TEAM-CALENDAR')
,p_application_group=>wwv_flow_imp.id(178129388996107318)
,p_application_group_name=>'Starter Apps'
,p_page_view_logging=>'YES'
,p_page_protection_enabled_y_n=>'Y'
,p_checksum_salt=>'B5CDC6F5068EB5D3291A15B06CECC9BAF767EF48F62733C466BFBC9C2C1A8583'
,p_checksum_salt_last_reset=>'19990804000000'
,p_bookmark_checksum_function=>'SH512'
,p_max_session_length_sec=>28800
,p_max_session_idle_sec=>28800
,p_compatibility_mode=>'24.2'
,p_flow_language=>'en'
,p_flow_language_derived_from=>'FLOW_PRIMARY_LANGUAGE'
,p_date_format=>'&APP_DATE_FORMAT.'
,p_timestamp_format=>'&APP_TIMESTAMP_FORMAT.'
,p_direction_right_to_left=>'N'
,p_flow_image_prefix => nvl(wwv_flow_application_install.get_image_prefix,'')
,p_documentation_banner=>wwv_flow_string.join(wwv_flow_t_varchar2(
'1.0.26 -> 1.0.27: Changed Notifications region(s) from plsql to report.',
'    Changed navigation region to APEX list.',
'1.0.27 -> 1.0.28: Changed Authentication scheme to use new "APEX_PACKAGED_APPLICATIONS" cookie',
'1.0.28 -> 1.0.29: Added confirm modal when enabling ACL',
'1.0.30 -> 1.0.31: Added "Rename Application" page and supporting application items, computations, substitution strings, item and region  changes on login pages, and UI Logo text replacement.',
'1.0.31 -> 1.0.32: Added Notifications to Mobile home page (400)',
'1.0.32 -> 1.0.33: Added "Bulk Add Users" functionality',
'1.0.34 -> 1.0.35: Error handling procedure updated to account for bug 17516350',
'1.0.35 -> 1.0.36: Implemented redesigned administrative ACL controls'))
,p_authentication_id=>wwv_flow_imp.id(8940447320923354813)
,p_application_tab_set=>0
,p_logo_type=>'T'
,p_logo_text=>'&APPLICATION_TITLE.'
,p_public_user=>'APEX_PUBLIC_USER'
,p_proxy_server=>nvl(wwv_flow_application_install.get_proxy,'')
,p_no_proxy_domains=>nvl(wwv_flow_application_install.get_no_proxy_domains,'')
,p_flow_version=>'24.2.1'
,p_flow_status=>'AVAILABLE_W_EDIT_LINK'
,p_flow_unavailable_text=>'This application is currently unavailable at this time.'
,p_exact_substitutions_only=>'Y'
,p_browser_cache=>'N'
,p_browser_frame=>'S'
,p_deep_linking=>'Y'
,p_runtime_api_usage=>'T'
,p_pass_ecid=>'N'
,p_security_scheme=>wwv_flow_imp.id(3255013754194135948)
,p_rejoin_existing_sessions=>'P'
,p_csv_encoding=>'Y'
,p_auto_time_zone=>'N'
,p_error_handling_function=>'eba_ca_fw.apex_error_handling'
,p_tokenize_row_search=>'N'
,p_substitution_string_01=>'APP_DATE_FORMAT'
,p_substitution_value_01=>'DD-Mon-RRRR'
,p_substitution_string_02=>'APP_TIME_FORMAT'
,p_substitution_value_02=>'HH:MIam'
,p_substitution_string_03=>'APP_TIMESTAMP_FORMAT'
,p_substitution_value_03=>'DSFM HH24:MI:SS'
,p_substitution_string_04=>'APP_DATETIME_FORMAT'
,p_substitution_value_04=>'DD-Mon-RRRR HH:MIam'
,p_substitution_string_05=>'APP_NAME'
,p_substitution_value_05=>'Team Calendar'
,p_file_prefix => nvl(wwv_flow_application_install.get_static_app_file_prefix,'')
,p_files_version=>9
,p_version_scn=>82521914
,p_print_server_type=>'INSTANCE'
,p_file_storage=>'DB'
,p_is_pwa=>'N'
,p_copyright_banner=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Name: #APP_NAME#',
'Copyright (c)2012, #YEAR# Oracle and/or its affiliates.',
'Licensed under the Universal Permissive License v 1.0 as shown ',
'at https://oss.oracle.com/licenses/upl/',
'',
'This script makes use of the FullCalendar product. Refer to',
'THIRD_PARTY_LICENSES.txt in the top directory of this project',
'or at https://github.com/oracle/apex for license information.'))
);
wwv_flow_imp.component_end;
end;
/
