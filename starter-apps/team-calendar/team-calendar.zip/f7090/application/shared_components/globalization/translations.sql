prompt --application/shared_components/globalization/translations
begin
--   Manifest
--     TRANSLATIONS: 7090
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
null;
wwv_flow_imp.component_end;
end;
/
