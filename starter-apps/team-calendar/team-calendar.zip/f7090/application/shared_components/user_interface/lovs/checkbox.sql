prompt --application/shared_components/user_interface/lovs/checkbox
begin
--   Manifest
--     CHECKBOX
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(9159222799173038036)
,p_lov_name=>'CHECKBOX'
,p_lov_query=>'.'||wwv_flow_imp.id(9159222799173038036)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089051329
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9159223098255038037)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>' '
,p_lov_return_value=>'Y'
);
wwv_flow_imp.component_end;
end;
/
