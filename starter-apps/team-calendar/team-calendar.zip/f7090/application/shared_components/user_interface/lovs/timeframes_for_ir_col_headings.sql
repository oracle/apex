prompt --application/shared_components/user_interface/lovs/timeframes_for_ir_col_headings
begin
--   Manifest
--     TIMEFRAMES (FOR IR COL HEADINGS)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>18526348527783382
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(8037869726861584676)
,p_lov_name=>'TIMEFRAMES (FOR IR COL HEADINGS)'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tf_name d, ',
'       tf_name r',
'  from EBA_ca_timeframes',
' where sysdate <= end_date',
' order by start_date',
''))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1089051329
);
wwv_flow_imp.component_end;
end;
/
