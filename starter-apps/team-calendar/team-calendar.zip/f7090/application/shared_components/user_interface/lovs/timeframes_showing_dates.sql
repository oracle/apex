prompt --application/shared_components/user_interface/lovs/timeframes_showing_dates
begin
--   Manifest
--     TIMEFRAMES (SHOWING DATES)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(8034894539064797560)
,p_lov_name=>'TIMEFRAMES (SHOWING DATES)'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tf_name || '' ('' || start_date || '' to '' ||',
'                          end_date || '')'' d, ',
'       tf_id r',
'  from EBA_ca_timeframes',
' order by start_date',
''))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1089051329
);
wwv_flow_imp.component_end;
end;
/
