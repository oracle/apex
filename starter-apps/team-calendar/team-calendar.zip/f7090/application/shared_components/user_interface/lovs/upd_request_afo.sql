prompt --application/shared_components/user_interface/lovs/upd_request_afo
begin
--   Manifest
--     UPD_REQUEST_AFO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(9166247300075296044)
,p_lov_name=>'UPD_REQUEST_AFO'
,p_lov_query=>'.'||wwv_flow_imp.id(9166247300075296044)||'.'
,p_location=>'STATIC'
,p_version_scn=>1089051329
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9166247606484296052)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'All Events'
,p_lov_return_value=>'A'
,p_lov_disp_cond_type=>'EXPRESSION'
,p_lov_disp_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:APP_PAGE_ID =  11 and (instr( :P11_REQUEST_TYPE,''A'') > 0 or  :P11_REQUEST_TYPE = ''D''))',
'or',
'(:APP_PAGE_ID = 411 and (instr(nvl(:P411_REQUEST_TYPE,''AFO''),''A'') > 0 or :P411_REQUEST_TYPE = ''D''))'))
,p_lov_disp_cond2=>'PLSQL'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9166247814103296059)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Future Events'
,p_lov_return_value=>'F'
,p_lov_disp_cond_type=>'EXPRESSION'
,p_lov_disp_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:APP_PAGE_ID =  11 and (instr( :P11_REQUEST_TYPE,''F'') > 0 or  :P11_REQUEST_TYPE = ''D''))',
'or',
'(:APP_PAGE_ID = 411 and (instr(nvl(:P411_REQUEST_TYPE,''AFO''),''F'') > 0 or :P411_REQUEST_TYPE = ''D''))'))
,p_lov_disp_cond2=>'PLSQL'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9166248017361296059)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Only this Event'
,p_lov_return_value=>'O'
,p_lov_disp_cond_type=>'EXPRESSION'
,p_lov_disp_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(:APP_PAGE_ID =  11 and (instr( :P11_REQUEST_TYPE,''O'') > 0 or  :P11_REQUEST_TYPE = ''D''))',
'or',
'(:APP_PAGE_ID = 411 and (instr(nvl(:P411_REQUEST_TYPE,''AFO''),''O'') > 0 or :P411_REQUEST_TYPE = ''D''))'))
,p_lov_disp_cond2=>'PLSQL'
);
wwv_flow_imp.component_end;
end;
/
