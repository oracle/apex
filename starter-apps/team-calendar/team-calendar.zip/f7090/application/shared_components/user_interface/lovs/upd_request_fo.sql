prompt --application/shared_components/user_interface/lovs/upd_request_fo
begin
--   Manifest
--     UPD_REQUEST_FO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(7993778785644479450)
,p_lov_name=>'UPD_REQUEST_FO'
,p_lov_query=>'.'||wwv_flow_imp.id(7993778785644479450)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(7993779277400479453)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Future Events'
,p_lov_return_value=>'F'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(7993779062896479451)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Only this Event'
,p_lov_return_value=>'O'
);
wwv_flow_imp.component_end;
end;
/
