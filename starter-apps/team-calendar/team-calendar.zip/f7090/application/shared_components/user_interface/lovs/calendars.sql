prompt --application/shared_components/user_interface/lovs/calendars
begin
--   Manifest
--     CALENDARS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(1857322079330514712)
,p_lov_name=>'CALENDARS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select short_name || '' - '' || calendar_name || decode(public_view_yn, ''Y'', null, '' (Private)'') d',
', calendar_id r',
'from eba_ca_calendars c',
'where public_view_yn = ''Y''',
'or    exists (select ''x''',
'              from eba_ca_users u',
'              where u.username = :APP_USER',
'              and   (   instr(u.restricted_to, c.calendar_id) > 0',
'                     or (access_level_id = 3 and restricted_to is null)',
'                    )',
'             ) ',
'order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1089051329
);
wwv_flow_imp.component_end;
end;
/
