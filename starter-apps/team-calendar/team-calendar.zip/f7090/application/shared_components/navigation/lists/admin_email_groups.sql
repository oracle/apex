prompt --application/shared_components/navigation/lists/admin_email_groups
begin
--   Manifest
--     LIST: Admin Email Groups
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(8005998771959837883)
,p_name=>'Admin Email Groups'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8005999791006843360)
,p_list_item_display_sequence=>5
,p_list_item_link_text=>'Send Email'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:15:::'
,p_list_item_icon=>'fa-envelope-o'
,p_list_text_01=>'Send email of events to a group or an individual.'
,p_security_scheme=>wwv_flow_imp.id(3234937006085175869)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8006629370425026620)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Groups'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-users'
,p_list_text_01=>'Groups are reusable lists of people that you can email a set of events to.'
,p_security_scheme=>wwv_flow_imp.id(3234937006085175869)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8006630681506029827)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Group Members'
,p_list_item_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-users'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from EBA_CA_EMAIL_GROUPS'))
,p_list_text_01=>'Report of all members of all groups.  Used for adding members and seeing which groups a person belongs to.'
,p_security_scheme=>wwv_flow_imp.id(3234937006085175869)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
);
wwv_flow_imp.component_end;
end;
/
