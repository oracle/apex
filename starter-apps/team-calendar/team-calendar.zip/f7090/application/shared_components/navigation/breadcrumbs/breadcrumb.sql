prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU:  Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>18526348527783382
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(8938898485436178194)
,p_name=>' Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1061429021041452311)
,p_parent_id=>wwv_flow_imp.id(3254629652671137550)
,p_short_name=>'Application Appearance'
,p_link=>'f?p=&APP_ID.:41:&SESSION.'
,p_page_id=>41
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1315645647463762863)
,p_parent_id=>wwv_flow_imp.id(3254629652671137550)
,p_short_name=>'Page Privileges'
,p_link=>'f?p=&APP_ID.:35:&SESSION.'
,p_page_id=>35
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1325437759756042982)
,p_parent_id=>wwv_flow_imp.id(3254629652671137550)
,p_short_name=>'Rename Application'
,p_link=>'f?p=&APP_ID.:37:&SESSION.'
,p_page_id=>37
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1337494739949734676)
,p_parent_id=>wwv_flow_imp.id(2469226754615508274)
,p_short_name=>'Time Zone'
,p_link=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_page_id=>100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1436291843116538135)
,p_parent_id=>wwv_flow_imp.id(3254629652671137550)
,p_short_name=>'Username Format'
,p_link=>'f?p=&APP_ID.:38:&SESSION.'
,p_page_id=>38
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1436313259839600312)
,p_short_name=>'Add Multiple Users'
,p_link=>'f?p=&APP_ID.:53:&SESSION.::&DEBUG.:::'
,p_page_id=>53
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1436327242683633782)
,p_short_name=>'Add Multiple Users'
,p_link=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.:::'
,p_page_id=>54
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1673278932352010751)
,p_parent_id=>wwv_flow_imp.id(3254629652671137550)
,p_short_name=>'Build Options'
,p_link=>'f?p=&APP_ID.:40:&SESSION.'
,p_page_id=>40
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1774625593589691682)
,p_short_name=>'Timeline of Future Events'
,p_link=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:::'
,p_page_id=>12
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1774948328151705395)
,p_short_name=>'Search'
,p_link=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_page_id=>2
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1774986628671729814)
,p_short_name=>'Tags'
,p_link=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:::'
,p_page_id=>36
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1855654669925451168)
,p_parent_id=>wwv_flow_imp.id(3254629652671137550)
,p_short_name=>'Calendars'
,p_link=>'f?p=&APP_ID.:42:&SESSION.'
,p_page_id=>42
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1855666407728458991)
,p_parent_id=>wwv_flow_imp.id(1855654669925451168)
,p_short_name=>'Calendar Details'
,p_link=>'f?p=&APP_ID.:44:&SESSION.'
,p_page_id=>44
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1980723866943457659)
,p_parent_id=>wwv_flow_imp.id(3254629652671137550)
,p_short_name=>'Manage Sample Data'
,p_link=>'f?p=&APP_ID.:43:&SESSION.'
,p_page_id=>43
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2469226754615508274)
,p_parent_id=>wwv_flow_imp.id(3254631241647173071)
,p_short_name=>'Preferences'
,p_link=>'f?p=&APP_ID.:28:&SESSION.'
,p_page_id=>28
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3222490451752287033)
,p_short_name=>'Help'
,p_link=>'f?p=&FLOW_ID.:14:&SESSION.'
,p_page_id=>14
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3254613946293078734)
,p_parent_id=>wwv_flow_imp.id(3254629652671137550)
,p_short_name=>'Notifications'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3254624648596089005)
,p_parent_id=>wwv_flow_imp.id(3254613946293078734)
,p_short_name=>'Notification'
,p_link=>'f?p=&FLOW_ID.:25:&SESSION.'
,p_page_id=>25
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3254629652671137550)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.:::'
,p_page_id=>26
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3254631241647173071)
,p_short_name=>'Home'
,p_link=>'f?p=&FLOW_ID.:1:&SESSION.'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3254810537625546089)
,p_parent_id=>wwv_flow_imp.id(3254821541008696333)
,p_short_name=>'User Details'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3254821541008696333)
,p_parent_id=>wwv_flow_imp.id(3254629652671137550)
,p_short_name=>'Access Control List'
,p_link=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:::'
,p_page_id=>29
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3254844847822331360)
,p_parent_id=>wwv_flow_imp.id(3254631241647173071)
,p_short_name=>'&P3_EVENT_NAME.'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3254851837433344239)
,p_parent_id=>wwv_flow_imp.id(3254844847822331360)
,p_short_name=>'Attachments'
,p_link=>'f?p=&FLOW_ID.:31:&SESSION.'
,p_page_id=>31
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3254860244648357876)
,p_parent_id=>wwv_flow_imp.id(3254851837433344239)
,p_short_name=>'Attachment'
,p_link=>'f?p=&FLOW_ID.:32:&SESSION.'
,p_page_id=>32
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3255542634063073887)
,p_parent_id=>wwv_flow_imp.id(3254844847822331360)
,p_short_name=>'Event Update'
,p_link=>'f?p=&FLOW_ID.:33:&SESSION.'
,p_page_id=>33
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3255549743012089726)
,p_parent_id=>wwv_flow_imp.id(3254844847822331360)
,p_short_name=>'Event Updates'
,p_link=>'f?p=&FLOW_ID.:34:&SESSION.'
,p_page_id=>34
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3304061549350254274)
,p_parent_id=>wwv_flow_imp.id(3254629652671137550)
,p_short_name=>'Application Error Log'
,p_link=>'f?p=&APP_ID.:175:&SESSION.::&DEBUG.:::'
,p_page_id=>175
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3332624651363735880)
,p_parent_id=>wwv_flow_imp.id(3254629652671137550)
,p_short_name=>'Activity Calendar'
,p_link=>'f?p=&FLOW_ID.:9:&SESSION.'
,p_page_id=>9
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(7433297793199741679)
,p_parent_id=>wwv_flow_imp.id(1774948328151705395)
,p_short_name=>'Delete Multiple'
,p_link=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::'
,p_page_id=>13
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8024522839210617182)
,p_parent_id=>wwv_flow_imp.id(3254629652671137550)
,p_short_name=>'Send Email'
,p_link=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:::'
,p_page_id=>15
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8024542117248720081)
,p_parent_id=>wwv_flow_imp.id(3254629652671137550)
,p_short_name=>'Groups'
,p_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:::'
,p_page_id=>16
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8024548231065724342)
,p_parent_id=>wwv_flow_imp.id(8024542117248720081)
,p_short_name=>'Details'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8025160615061820586)
,p_parent_id=>wwv_flow_imp.id(3254629652671137550)
,p_short_name=>'Group Members'
,p_link=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:::'
,p_page_id=>18
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8025186132512883571)
,p_parent_id=>wwv_flow_imp.id(8025160615061820586)
,p_short_name=>'Details'
,p_link=>'f?p=&FLOW_ID.:19:&SESSION.'
,p_page_id=>19
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8031795217979256357)
,p_parent_id=>wwv_flow_imp.id(8025160615061820586)
,p_short_name=>'Add Multiple Members'
,p_link=>'f?p=&FLOW_ID.:21:&SESSION.'
,p_page_id=>21
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8031875532785340668)
,p_parent_id=>wwv_flow_imp.id(8025160615061820586)
,p_short_name=>'Add Multiple Members'
,p_link=>'f?p=&FLOW_ID.:22:&SESSION.'
,p_page_id=>22
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8032960723706162845)
,p_parent_id=>wwv_flow_imp.id(3254629652671137550)
,p_short_name=>'Reporting Time Frames'
,p_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::'
,p_page_id=>23
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8032973730464187055)
,p_parent_id=>wwv_flow_imp.id(8032960723706162845)
,p_short_name=>'Details'
,p_link=>'f?p=&FLOW_ID.:24:&SESSION.'
,p_page_id=>24
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8519516245627248889)
,p_parent_id=>wwv_flow_imp.id(8938921689194178354)
,p_short_name=>'Update or Delete Affects'
,p_link=>'f?p=&FLOW_ID.:11:&SESSION.'
,p_page_id=>11
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8938912880421178325)
,p_parent_id=>wwv_flow_imp.id(3254629652671137550)
,p_option_sequence=>70
,p_short_name=>'Event Types'
,p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8938915504558178338)
,p_parent_id=>wwv_flow_imp.id(8938912880421178325)
,p_option_sequence=>80
,p_short_name=>'Details'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8938921689194178354)
,p_option_sequence=>100
,p_short_name=>'Event'
,p_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_imp.component_end;
end;
/
