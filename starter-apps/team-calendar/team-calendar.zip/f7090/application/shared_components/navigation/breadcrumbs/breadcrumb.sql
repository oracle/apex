prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU:  Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(8940448701738354891)
,p_name=>' Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1062979237343629008)
,p_parent_id=>wwv_flow_imp.id(3256179868973314247)
,p_short_name=>'Application Appearance'
,p_link=>'f?p=&APP_ID.:41:&SESSION.'
,p_page_id=>41
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1317195863765939560)
,p_parent_id=>wwv_flow_imp.id(3256179868973314247)
,p_short_name=>'Page Privileges'
,p_link=>'f?p=&APP_ID.:35:&SESSION.'
,p_page_id=>35
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1326987976058219679)
,p_parent_id=>wwv_flow_imp.id(3256179868973314247)
,p_short_name=>'Rename Application'
,p_link=>'f?p=&APP_ID.:37:&SESSION.'
,p_page_id=>37
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1339044956251911373)
,p_parent_id=>wwv_flow_imp.id(2470776970917684971)
,p_short_name=>'Time Zone'
,p_link=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_page_id=>100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1437842059418714832)
,p_parent_id=>wwv_flow_imp.id(3256179868973314247)
,p_short_name=>'Username Format'
,p_link=>'f?p=&APP_ID.:38:&SESSION.'
,p_page_id=>38
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1437863476141777009)
,p_short_name=>'Add Multiple Users'
,p_link=>'f?p=&APP_ID.:53:&SESSION.::&DEBUG.:::'
,p_page_id=>53
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1437877458985810479)
,p_short_name=>'Add Multiple Users'
,p_link=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.:::'
,p_page_id=>54
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1674829148654187448)
,p_parent_id=>wwv_flow_imp.id(3256179868973314247)
,p_short_name=>'Build Options'
,p_link=>'f?p=&APP_ID.:40:&SESSION.'
,p_page_id=>40
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1776175809891868379)
,p_short_name=>'Timeline of Future Events'
,p_link=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:::'
,p_page_id=>12
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1776498544453882092)
,p_short_name=>'Search'
,p_link=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_page_id=>2
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1776536844973906511)
,p_short_name=>'Tags'
,p_link=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:::'
,p_page_id=>36
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1857204886227627865)
,p_parent_id=>wwv_flow_imp.id(3256179868973314247)
,p_short_name=>'Calendars'
,p_link=>'f?p=&APP_ID.:42:&SESSION.'
,p_page_id=>42
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1857216624030635688)
,p_parent_id=>wwv_flow_imp.id(1857204886227627865)
,p_short_name=>'Calendar Details'
,p_link=>'f?p=&APP_ID.:44:&SESSION.'
,p_page_id=>44
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1982274083245634356)
,p_parent_id=>wwv_flow_imp.id(3256179868973314247)
,p_short_name=>'Manage Sample Data'
,p_link=>'f?p=&APP_ID.:43:&SESSION.'
,p_page_id=>43
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2470776970917684971)
,p_parent_id=>wwv_flow_imp.id(3256181457949349768)
,p_short_name=>'Preferences'
,p_link=>'f?p=&APP_ID.:28:&SESSION.'
,p_page_id=>28
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3224040668054463730)
,p_short_name=>'Help'
,p_link=>'f?p=&FLOW_ID.:14:&SESSION.'
,p_page_id=>14
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3256164162595255431)
,p_parent_id=>wwv_flow_imp.id(3256179868973314247)
,p_short_name=>'Notifications'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3256174864898265702)
,p_parent_id=>wwv_flow_imp.id(3256164162595255431)
,p_short_name=>'Notification'
,p_link=>'f?p=&FLOW_ID.:25:&SESSION.'
,p_page_id=>25
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3256179868973314247)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.:::'
,p_page_id=>26
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3256181457949349768)
,p_short_name=>'Home'
,p_link=>'f?p=&FLOW_ID.:1:&SESSION.'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3256360753927722786)
,p_parent_id=>wwv_flow_imp.id(3256371757310873030)
,p_short_name=>'User Details'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3256371757310873030)
,p_parent_id=>wwv_flow_imp.id(3256179868973314247)
,p_short_name=>'Access Control List'
,p_link=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:::'
,p_page_id=>29
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3256395064124508057)
,p_parent_id=>wwv_flow_imp.id(3256181457949349768)
,p_short_name=>'&P3_EVENT_NAME.'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3256402053735520936)
,p_parent_id=>wwv_flow_imp.id(3256395064124508057)
,p_short_name=>'Attachments'
,p_link=>'f?p=&FLOW_ID.:31:&SESSION.'
,p_page_id=>31
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3256410460950534573)
,p_parent_id=>wwv_flow_imp.id(3256402053735520936)
,p_short_name=>'Attachment'
,p_link=>'f?p=&FLOW_ID.:32:&SESSION.'
,p_page_id=>32
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3257092850365250584)
,p_parent_id=>wwv_flow_imp.id(3256395064124508057)
,p_short_name=>'Event Update'
,p_link=>'f?p=&FLOW_ID.:33:&SESSION.'
,p_page_id=>33
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3257099959314266423)
,p_parent_id=>wwv_flow_imp.id(3256395064124508057)
,p_short_name=>'Event Updates'
,p_link=>'f?p=&FLOW_ID.:34:&SESSION.'
,p_page_id=>34
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3305611765652430971)
,p_parent_id=>wwv_flow_imp.id(3256179868973314247)
,p_short_name=>'Application Error Log'
,p_link=>'f?p=&APP_ID.:175:&SESSION.::&DEBUG.:::'
,p_page_id=>175
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3334174867665912577)
,p_parent_id=>wwv_flow_imp.id(3256179868973314247)
,p_short_name=>'Activity Calendar'
,p_link=>'f?p=&FLOW_ID.:9:&SESSION.'
,p_page_id=>9
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(7434848009501918376)
,p_parent_id=>wwv_flow_imp.id(1776498544453882092)
,p_short_name=>'Delete Multiple'
,p_link=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::'
,p_page_id=>13
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8026073055512793879)
,p_parent_id=>wwv_flow_imp.id(3256179868973314247)
,p_short_name=>'Send Email'
,p_link=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:::'
,p_page_id=>15
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8026092333550896778)
,p_parent_id=>wwv_flow_imp.id(3256179868973314247)
,p_short_name=>'Groups'
,p_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:::'
,p_page_id=>16
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8026098447367901039)
,p_parent_id=>wwv_flow_imp.id(8026092333550896778)
,p_short_name=>'Details'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8026710831363997283)
,p_parent_id=>wwv_flow_imp.id(3256179868973314247)
,p_short_name=>'Group Members'
,p_link=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:::'
,p_page_id=>18
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8026736348815060268)
,p_parent_id=>wwv_flow_imp.id(8026710831363997283)
,p_short_name=>'Details'
,p_link=>'f?p=&FLOW_ID.:19:&SESSION.'
,p_page_id=>19
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8033345434281433054)
,p_parent_id=>wwv_flow_imp.id(8026710831363997283)
,p_short_name=>'Add Multiple Members'
,p_link=>'f?p=&FLOW_ID.:21:&SESSION.'
,p_page_id=>21
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8033425749087517365)
,p_parent_id=>wwv_flow_imp.id(8026710831363997283)
,p_short_name=>'Add Multiple Members'
,p_link=>'f?p=&FLOW_ID.:22:&SESSION.'
,p_page_id=>22
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8034510940008339542)
,p_parent_id=>wwv_flow_imp.id(3256179868973314247)
,p_short_name=>'Reporting Time Frames'
,p_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::'
,p_page_id=>23
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8034523946766363752)
,p_parent_id=>wwv_flow_imp.id(8034510940008339542)
,p_short_name=>'Details'
,p_link=>'f?p=&FLOW_ID.:24:&SESSION.'
,p_page_id=>24
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8521066461929425586)
,p_parent_id=>wwv_flow_imp.id(8940471905496355051)
,p_short_name=>'Update or Delete Affects'
,p_link=>'f?p=&FLOW_ID.:11:&SESSION.'
,p_page_id=>11
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8940463096723355022)
,p_parent_id=>wwv_flow_imp.id(3256179868973314247)
,p_option_sequence=>70
,p_short_name=>'Event Types'
,p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8940465720860355035)
,p_parent_id=>wwv_flow_imp.id(8940463096723355022)
,p_option_sequence=>80
,p_short_name=>'Details'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8940471905496355051)
,p_option_sequence=>100
,p_short_name=>'Event'
,p_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_imp.component_end;
end;
/
