prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU:  Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(8920372136908394812)
,p_name=>' Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1042902672513668929)
,p_parent_id=>wwv_flow_imp.id(3236103304143354168)
,p_short_name=>'Application Appearance'
,p_link=>'f?p=&APP_ID.:41:&SESSION.'
,p_page_id=>41
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1297119298935979481)
,p_parent_id=>wwv_flow_imp.id(3236103304143354168)
,p_short_name=>'Page Privileges'
,p_link=>'f?p=&APP_ID.:35:&SESSION.'
,p_page_id=>35
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1306911411228259600)
,p_parent_id=>wwv_flow_imp.id(3236103304143354168)
,p_short_name=>'Rename Application'
,p_link=>'f?p=&APP_ID.:37:&SESSION.'
,p_page_id=>37
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1318968391421951294)
,p_parent_id=>wwv_flow_imp.id(2450700406087724892)
,p_short_name=>'Time Zone'
,p_link=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_page_id=>100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1417765494588754753)
,p_parent_id=>wwv_flow_imp.id(3236103304143354168)
,p_short_name=>'Username Format'
,p_link=>'f?p=&APP_ID.:38:&SESSION.'
,p_page_id=>38
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1417786911311816930)
,p_short_name=>'Add Multiple Users'
,p_link=>'f?p=&APP_ID.:53:&SESSION.::&DEBUG.:::'
,p_page_id=>53
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1417800894155850400)
,p_short_name=>'Add Multiple Users'
,p_link=>'f?p=&APP_ID.:54:&SESSION.::&DEBUG.:::'
,p_page_id=>54
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1654752583824227369)
,p_parent_id=>wwv_flow_imp.id(3236103304143354168)
,p_short_name=>'Build Options'
,p_link=>'f?p=&APP_ID.:40:&SESSION.'
,p_page_id=>40
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1756099245061908300)
,p_short_name=>'Timeline of Future Events'
,p_link=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:::'
,p_page_id=>12
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1756421979623922013)
,p_short_name=>'Search'
,p_link=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_page_id=>2
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1756460280143946432)
,p_short_name=>'Tags'
,p_link=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:::'
,p_page_id=>36
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1837128321397667786)
,p_parent_id=>wwv_flow_imp.id(3236103304143354168)
,p_short_name=>'Calendars'
,p_link=>'f?p=&APP_ID.:42:&SESSION.'
,p_page_id=>42
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1837140059200675609)
,p_parent_id=>wwv_flow_imp.id(1837128321397667786)
,p_short_name=>'Calendar Details'
,p_link=>'f?p=&APP_ID.:44:&SESSION.'
,p_page_id=>44
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(1962197518415674277)
,p_parent_id=>wwv_flow_imp.id(3236103304143354168)
,p_short_name=>'Manage Sample Data'
,p_link=>'f?p=&APP_ID.:43:&SESSION.'
,p_page_id=>43
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(2450700406087724892)
,p_parent_id=>wwv_flow_imp.id(3236104893119389689)
,p_short_name=>'Preferences'
,p_link=>'f?p=&APP_ID.:28:&SESSION.'
,p_page_id=>28
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3203964103224503651)
,p_short_name=>'Help'
,p_link=>'f?p=&FLOW_ID.:14:&SESSION.'
,p_page_id=>14
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3236087597765295352)
,p_parent_id=>wwv_flow_imp.id(3236103304143354168)
,p_short_name=>'Notifications'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3236098300068305623)
,p_parent_id=>wwv_flow_imp.id(3236087597765295352)
,p_short_name=>'Notification'
,p_link=>'f?p=&FLOW_ID.:25:&SESSION.'
,p_page_id=>25
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3236103304143354168)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.:::'
,p_page_id=>26
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3236104893119389689)
,p_short_name=>'Home'
,p_link=>'f?p=&FLOW_ID.:1:&SESSION.'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3236284189097762707)
,p_parent_id=>wwv_flow_imp.id(3236295192480912951)
,p_short_name=>'User Details'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3236295192480912951)
,p_parent_id=>wwv_flow_imp.id(3236103304143354168)
,p_short_name=>'Access Control List'
,p_link=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.:::'
,p_page_id=>29
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3236318499294547978)
,p_parent_id=>wwv_flow_imp.id(3236104893119389689)
,p_short_name=>'&P3_EVENT_NAME.'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3236325488905560857)
,p_parent_id=>wwv_flow_imp.id(3236318499294547978)
,p_short_name=>'Attachments'
,p_link=>'f?p=&FLOW_ID.:31:&SESSION.'
,p_page_id=>31
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3236333896120574494)
,p_parent_id=>wwv_flow_imp.id(3236325488905560857)
,p_short_name=>'Attachment'
,p_link=>'f?p=&FLOW_ID.:32:&SESSION.'
,p_page_id=>32
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3237016285535290505)
,p_parent_id=>wwv_flow_imp.id(3236318499294547978)
,p_short_name=>'Event Update'
,p_link=>'f?p=&FLOW_ID.:33:&SESSION.'
,p_page_id=>33
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3237023394484306344)
,p_parent_id=>wwv_flow_imp.id(3236318499294547978)
,p_short_name=>'Event Updates'
,p_link=>'f?p=&FLOW_ID.:34:&SESSION.'
,p_page_id=>34
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3285535200822470892)
,p_parent_id=>wwv_flow_imp.id(3236103304143354168)
,p_short_name=>'Application Error Log'
,p_link=>'f?p=&APP_ID.:175:&SESSION.::&DEBUG.:::'
,p_page_id=>175
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(3314098302835952498)
,p_parent_id=>wwv_flow_imp.id(3236103304143354168)
,p_short_name=>'Activity Calendar'
,p_link=>'f?p=&FLOW_ID.:9:&SESSION.'
,p_page_id=>9
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(7414771444671958297)
,p_parent_id=>wwv_flow_imp.id(1756421979623922013)
,p_short_name=>'Delete Multiple'
,p_link=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::'
,p_page_id=>13
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8005996490682833800)
,p_parent_id=>wwv_flow_imp.id(3236103304143354168)
,p_short_name=>'Send Email'
,p_link=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:::'
,p_page_id=>15
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8006015768720936699)
,p_parent_id=>wwv_flow_imp.id(3236103304143354168)
,p_short_name=>'Groups'
,p_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:::'
,p_page_id=>16
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8006021882537940960)
,p_parent_id=>wwv_flow_imp.id(8006015768720936699)
,p_short_name=>'Details'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8006634266534037204)
,p_parent_id=>wwv_flow_imp.id(3236103304143354168)
,p_short_name=>'Group Members'
,p_link=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:::'
,p_page_id=>18
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8006659783985100189)
,p_parent_id=>wwv_flow_imp.id(8006634266534037204)
,p_short_name=>'Details'
,p_link=>'f?p=&FLOW_ID.:19:&SESSION.'
,p_page_id=>19
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8013268869451472975)
,p_parent_id=>wwv_flow_imp.id(8006634266534037204)
,p_short_name=>'Add Multiple Members'
,p_link=>'f?p=&FLOW_ID.:21:&SESSION.'
,p_page_id=>21
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8013349184257557286)
,p_parent_id=>wwv_flow_imp.id(8006634266534037204)
,p_short_name=>'Add Multiple Members'
,p_link=>'f?p=&FLOW_ID.:22:&SESSION.'
,p_page_id=>22
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8014434375178379463)
,p_parent_id=>wwv_flow_imp.id(3236103304143354168)
,p_short_name=>'Reporting Time Frames'
,p_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::'
,p_page_id=>23
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8014447381936403673)
,p_parent_id=>wwv_flow_imp.id(8014434375178379463)
,p_short_name=>'Details'
,p_link=>'f?p=&FLOW_ID.:24:&SESSION.'
,p_page_id=>24
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8500989897099465507)
,p_parent_id=>wwv_flow_imp.id(8920395340666394972)
,p_short_name=>'Update or Delete Affects'
,p_link=>'f?p=&FLOW_ID.:11:&SESSION.'
,p_page_id=>11
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8920386531893394943)
,p_parent_id=>wwv_flow_imp.id(3236103304143354168)
,p_option_sequence=>70
,p_short_name=>'Event Types'
,p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8920389156030394956)
,p_parent_id=>wwv_flow_imp.id(8920386531893394943)
,p_option_sequence=>80
,p_short_name=>'Details'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8920395340666394972)
,p_option_sequence=>100
,p_short_name=>'Event'
,p_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_imp.component_end;
end;
/
