prompt --application/shared_components/logic/application_processes/default_time_zone
begin
--   Manifest
--     APPLICATION PROCESS: Default Time Zone
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(7959896668918305821)
,p_process_sequence=>1
,p_process_point=>'AFTER_LOGIN'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Default Time Zone'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  c integer := 0;',
'begin',
'for c1 in (',
'   select TIMEZONE_PREFERENCE',
'   from   eba_ca_tz_pref',
'   where  USERID = upper(:APP_USER)) loop',
'   --',
'   if c1.TIMEZONE_PREFERENCE is not null then',
'       c := c + 1;',
'       APEX_UTIL.SET_SESSION_TIME_ZONE (P_TIME_ZONE => c1.TIMEZONE_PREFERENCE ); ',
'       :P100_TIMEZONE := c1.TIMEZONE_PREFERENCE;',
'       :F855_TIMEZONE := c1.TIMEZONE_PREFERENCE;',
'   end if;',
'   exit;',
'end loop;',
'if c = 0 then',
'        APEX_UTIL.SET_SESSION_TIME_ZONE (P_TIME_ZONE => ''US/Pacific''); ',
'       :P100_TIMEZONE := ''US/Pacific'';',
'       :F855_TIMEZONE := ''US/Pacific'';',
'end if;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Failed to default time zone'
);
wwv_flow_imp.component_end;
end;
/
