prompt --application/shared_components/logic/application_processes/clear_create_member_collections
begin
--   Manifest
--     APPLICATION PROCESS: Clear Create Member Collections
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_flow_process(
 p_id=>wwv_flow_api.id(7389040248104273544)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Clear Create Member Collections'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_collection.delete_collection (',
'   p_collection_name => ''BULK_MBRS_CREATE'' );',
'apex_collection.delete_collection (',
'   p_collection_name => ''BULK_MBRS_INVALID'' );'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>wwv_flow_api.id(3234937515255175869)
);
wwv_flow_api.component_end;
end;
/
