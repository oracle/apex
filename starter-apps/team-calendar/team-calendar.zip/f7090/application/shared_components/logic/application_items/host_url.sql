prompt --application/shared_components/logic/application_items/host_url
begin
--   Manifest
--     APPLICATION ITEM: HOST_URL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(8006858478884539870)
,p_name=>'HOST_URL'
,p_protection_level=>'S'
,p_escape_on_http_output=>'N'
,p_version_scn=>37166093807473
);
wwv_flow_imp.component_end;
end;
/
