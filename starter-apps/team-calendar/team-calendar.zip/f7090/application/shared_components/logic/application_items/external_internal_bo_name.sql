prompt --application/shared_components/logic/application_items/external_internal_bo_name
begin
--   Manifest
--     APPLICATION ITEM: EXTERNAL_INTERNAL_BO_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(1672142961962225902)
,p_name=>'EXTERNAL_INTERNAL_BO_NAME'
,p_protection_level=>'I'
,p_required_patch=>wwv_flow_imp.id(1611663373292043897)
,p_version_scn=>37166093807448
);
wwv_flow_imp.component_end;
end;
/
