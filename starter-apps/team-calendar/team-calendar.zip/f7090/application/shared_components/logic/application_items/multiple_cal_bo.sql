prompt --application/shared_components/logic/application_items/multiple_cal_bo
begin
--   Manifest
--     APPLICATION ITEM: MULTIPLE_CAL_BO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(1857191862426392734)
,p_name=>'MULTIPLE_CAL_BO'
,p_protection_level=>'I'
,p_version_scn=>37166093807492
);
wwv_flow_imp.component_end;
end;
/
