prompt --application/shared_components/logic/application_items/f855_timezone
begin
--   Manifest
--     APPLICATION ITEM: F855_TIMEZONE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(7980575938060553854)
,p_name=>'F855_TIMEZONE'
,p_protection_level=>'S'
,p_version_scn=>37166093807460
);
wwv_flow_imp.component_end;
end;
/
