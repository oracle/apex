prompt --application/shared_components/logic/application_items/external_internal_bo
begin
--   Manifest
--     APPLICATION ITEM: EXTERNAL_INTERNAL_BO
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_flow_item(
 p_id=>wwv_flow_api.id(1616130918802224123)
,p_name=>'EXTERNAL_INTERNAL_BO'
,p_protection_level=>'I'
,p_escape_on_http_output=>'N'
,p_required_patch=>wwv_flow_api.id(1611663373292043897)
);
wwv_flow_api.component_end;
end;
/
