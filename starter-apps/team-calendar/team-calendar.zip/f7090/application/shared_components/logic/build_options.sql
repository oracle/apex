prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 7090
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(1631739938122003976)
,p_build_option_name=>'Include External / Internal Event Types'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>37166093810572
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Differentiate between events that can be viewed by the public (external) and those that can only be viewed by those entered into the Access Control List (internal).',
'This option requires the Access Control Scope to be set to ''Reader access for any authenticated user''. By populating the Contact Email on events with the relevant addresses from users listed in the Access Control List, the Contact can be used to sear'
||'ch for events specifically for that person.'))
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(1678901496437878399)
,p_build_option_name=>'Show Updates'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>37166093810573
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Enable or disable the display of event updates.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(1693198998806964482)
,p_build_option_name=>'Show Time'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>37166093810573
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Select whether time will be displayed on calendar entries. If included, the calendar will also show Week and Day views.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(1857191596806388379)
,p_build_option_name=>'Include Multiple Calendars'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>37166093810573
,p_on_upgrade_keep_status=>true
,p_build_option_comment=>'Determine whether multiple calendars can be defined, and events can be entered against the different calendars. Administrators can optionally define which calendars a specific user can view and edit. '
);
wwv_flow_imp.component_end;
end;
/
