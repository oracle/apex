prompt --application/shared_components/logic/application_computations/cals_restricted_to
begin
--   Manifest
--     APPLICATION COMPUTATION: CALS_RESTRICTED_TO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(1857272458087527754)
,p_computation_sequence=>10
,p_computation_item=>'CALS_RESTRICTED_TO'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'QUERY'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(restricted_to, decode(access_level_id, 3, ''All'', null)) ',
'from eba_ca_users',
'where username = :APP_USER'))
,p_required_patch=>wwv_flow_imp.id(1837115031976428300)
,p_version_scn=>37166093807584
);
wwv_flow_imp.component_end;
end;
/
