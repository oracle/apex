prompt --application/shared_components/logic/application_computations/host_url
begin
--   Manifest
--     APPLICATION COMPUTATION: HOST_URL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(8026935952025502375)
,p_computation_sequence=>10
,p_computation_item=>'HOST_URL'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'wwv_flow_utilities.host_url(''SCRIPT'');'
,p_version_scn=>37166093807594
);
wwv_flow_imp.component_end;
end;
/
