prompt --application/shared_components/logic/application_computations/multiple_cal_bo_002
begin
--   Manifest
--     APPLICATION COMPUTATION: MULTIPLE_CAL_BO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(1837117066383451695)
,p_computation_sequence=>10
,p_computation_item=>'MULTIPLE_CAL_BO'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'Exclude'
,p_required_patch=>-wwv_flow_imp.id(1837115031976428300)
,p_version_scn=>37166093807569
);
wwv_flow_imp.component_end;
end;
/
