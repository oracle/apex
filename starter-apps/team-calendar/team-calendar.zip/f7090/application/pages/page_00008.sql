prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>8
,p_user_interface_id=>wwv_flow_imp.id(1120485210142475011)
,p_name=>'Event Type Details'
,p_alias=>'EVENT-TYPE-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Event Type Details'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(8920401851947419636)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(3234937006085175869)
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'02'
,p_last_upd_yyyymmddhh24miss=>'20200116130020'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1696196901292451784)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1696191373565075595)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3236135599327853794)
,p_plug_name=>'Recommended Colors'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(1696197797385075602)
,p_plug_display_sequence=>30
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br />Blue',
'<br />Border:     #C1CFE6',
'<br />Background: #E6ECF3',
'<br />',
'<br />Red',
'<br />Border:     #F1B8BA',
'<br />Background: #FAE1E2',
'<br />',
'<br />Yellow',
'<br />Border:     #E7EDB9',
'<br />Background: #F5F8E2',
'<br />',
'<br />Green',
'<br />Border:     #C2E1C8',
'<br />Background: #E5F3E8',
'<br />',
'<br />Teal',
'<br />Border:     #B1ECEB',
'<br />Background: #DEF7F7',
'<br />',
'<br />Purple',
'<br />Border:     #C0B7EC',
'<br />Background: #E4E1F7'))
,p_plug_query_headings_type=>'QUERY_COLUMNS'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_show_nulls_as=>' - '
,p_plug_display_condition_type=>'NEVER'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3274392595245018122)
,p_plug_name=>'hidden'
,p_plug_display_sequence=>10
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8920386941600394944)
,p_plug_name=>'Event Type Details'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1696191230793075593)
,p_plug_display_sequence=>20
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8920387045102394946)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1696196901292451784)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(1696225246979075678)
,p_button_image_alt=>'Cancel'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8920387140280394946)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1696196901292451784)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--danger'
,p_button_template_id=>wwv_flow_imp.id(1696225246979075678)
,p_button_image_alt=>'Delete'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_condition=>'P8_TYPE_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8920387248938394946)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1696196901292451784)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_imp.id(1696225246979075678)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P8_TYPE_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8920387357402394946)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(1696196901292451784)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_imp.id(1696225246979075678)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Event Type'
,p_button_position=>'NEXT'
,p_button_condition=>'P8_TYPE_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1538709513595392288)
,p_name=>'P8_INTERNAL_YN'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(8920386941600394944)
,p_use_cache_before_default=>'NO'
,p_prompt=>'External / Internal'
,p_source=>'INTERNAL_YN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:External;N,Internal Only;Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(262389464488723380)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_required_patch=>wwv_flow_imp.id(1611663373292043897)
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3236135203351845480)
,p_name=>'P8_BORDER_COLOR'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(3274392595245018122)
,p_use_cache_before_default=>'NO'
,p_source=>'BORDER_COLOR'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_help_text=>'Events are typically displayed in black.  You can override that color by assigning a display color by event type.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3237436411859113723)
,p_name=>'P8_COLOR_PREF_ID'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(8920386941600394944)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Color Preference'
,p_source=>'COLOR_PREF_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'COLOR PREFERENCE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select color_name, id ',
'from EBA_CA_color_prefs ',
'order by display_sequence, id'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Color Preference -'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(262389464488723380)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8920387542936394949)
,p_name=>'P8_TYPE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8920386941600394944)
,p_use_cache_before_default=>'NO'
,p_source=>'TYPE_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8920387637375394951)
,p_name=>'P8_TYPE_NAME'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(8920386941600394944)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Event Type'
,p_source=>'TYPE_NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>48
,p_cMaxlength=>60
,p_field_template=>wwv_flow_imp.id(262389464488723380)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8920512655166903070)
,p_name=>'P8_DISPLAY_COLOR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(3274392595245018122)
,p_use_cache_before_default=>'NO'
,p_source=>'DISPLAY_COLOR'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_help_text=>'Events are typically displayed in black.  You can override that color by assigning a display color by event type.'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8006931481720070510)
,p_validation_name=>'P8_EVENT_TYPE unique'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from EBA_ca_event_types',
' where lower(:P8_TYPE_NAME) = lower(type_name)',
'   and (:P8_TYPE_ID != type_id or :P8_TYPE_ID is null)'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Type already exists.'
,p_associated_item=>wwv_flow_imp.id(8920387637375394951)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8014407890448262237)
,p_validation_name=>'no related events before delete'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from EBA_ca_events',
' where :P8_TYPE_ID = type_id'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Cannot delete Event Type - it is related to Events.'
,p_when_button_pressed=>wwv_flow_imp.id(8920387140280394946)
,p_associated_item=>wwv_flow_imp.id(8920387637375394951)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1696196991984451785)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8920387045102394946)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1696197095345451786)
,p_event_id=>wwv_flow_imp.id(1696196991984451785)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8920388831892394953)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from EBA_CA_EVENT_TYPES'
,p_attribute_02=>'EBA_CA_EVENT_TYPES'
,p_attribute_03=>'P8_TYPE_ID'
,p_attribute_04=>'TYPE_ID'
,p_attribute_11=>'I:U:D'
,p_process_error_message=>'Unable to fetch row.'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3274394295685075025)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set colors'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'select ',
'   BG_COLOR,',
'   TEXT_COLOR',
'from EBA_CA_COLOR_PREFS',
'where id = :P8_COLOR_PREF_ID) loop',
':P8_DISPLAY_COLOR := c1.TEXT_COLOR;',
':P8_BORDER_COLOR := c1.BG_COLOR;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8920388933160394954)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of EBA_CA_EVENT_TYPES'
,p_attribute_02=>'EBA_CA_EVENT_TYPES'
,p_attribute_03=>'P8_TYPE_ID'
,p_attribute_04=>'TYPE_ID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_process_error_message=>'Unable to process row of table EBA_CA_EVENT_TYPES.'
,p_process_success_message=>'Action Processed.'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1696197230489451787)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
