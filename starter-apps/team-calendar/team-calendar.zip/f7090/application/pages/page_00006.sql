prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Event Links'
,p_alias=>'EVENT-LINKS'
,p_page_mode=>'MODAL'
,p_step_title=>'Event Links'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(1297121015765991139)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(3234937515255175869)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'16'
,p_last_updated_by=>'ALLAN'
,p_last_upd_yyyymmddhh24miss=>'20231012224530'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2491524635884162586)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1696191373565075595)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(4032344798347001322)
,p_plug_name=>'Event Links'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1696191230793075593)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(795331372948710838)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2491524635884162586)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(1696225246979075678)
,p_button_image_alt=>'Cancel'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(795332188427710840)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2491524635884162586)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>wwv_flow_imp.id(1696225246979075678)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(795338899321721669)
,p_name=>'P6_LINK_NAME_1'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(4032344798347001322)
,p_prompt=>'Name 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(1696224422244075672)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Name of 1st link.  If not provided, the URL will be displayed.'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(795339646168724387)
,p_name=>'P6_LINK_URL_1'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(4032344798347001322)
,p_prompt=>'URL 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(1696224422244075672)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'URL for 1st link.'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(795340432270727077)
,p_name=>'P6_LINK_NAME_2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(4032344798347001322)
,p_prompt=>'Name 2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(1696224223784075668)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Name of 2nd link.  If not provided, the URL will be displayed.'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(795341383199729698)
,p_name=>'P6_LINK_URL_2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(4032344798347001322)
,p_prompt=>'URL 2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(1696224223784075668)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'URL for 2nd link.'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(795342167638731622)
,p_name=>'P6_LINK_NAME_3'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(4032344798347001322)
,p_prompt=>'Name 3'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(1696224223784075668)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Name of 3rd link.  If not provided, the URL will be displayed.'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(795342954885734346)
,p_name=>'P6_LINK_URL_3'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(4032344798347001322)
,p_prompt=>'URL 3'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(1696224223784075668)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'URL for 3rd link.'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(4032348772483001342)
,p_name=>'P6_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(4032344798347001322)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(795346563933758291)
,p_validation_name=>'URL 1 Must start with http'
,p_validation_sequence=>10
,p_validation=>'substr(:P6_LINK_URL_1, 1, 4) = ''http'''
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'URL must start with http:// or https://'
,p_validation_condition=>'P6_LINK_URL_3'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_when_button_pressed=>wwv_flow_imp.id(795332188427710840)
,p_associated_item=>wwv_flow_imp.id(795339646168724387)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(112074800260221445)
,p_validation_name=>'URL2 Must not be null if link name was provided'
,p_validation_sequence=>20
,p_validation=>'P6_LINK_URL_2'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have some value.'
,p_validation_condition=>'P6_LINK_NAME_2'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_when_button_pressed=>wwv_flow_imp.id(795332188427710840)
,p_associated_item=>wwv_flow_imp.id(795341383199729698)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(795346824778759828)
,p_validation_name=>'URL2 Must start with http'
,p_validation_sequence=>30
,p_validation=>'substr(:P6_LINK_URL_2, 1, 4) = ''http'''
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'URL must start with http:// or https://'
,p_validation_condition=>'P6_LINK_URL_2'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_when_button_pressed=>wwv_flow_imp.id(795332188427710840)
,p_associated_item=>wwv_flow_imp.id(795341383199729698)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(112074964966221446)
,p_validation_name=>'URL3 Must not be null if link name was provided'
,p_validation_sequence=>50
,p_validation=>'P6_LINK_URL_3'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have some value.'
,p_validation_condition=>'P6_LINK_NAME_3'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_when_button_pressed=>wwv_flow_imp.id(795332188427710840)
,p_associated_item=>wwv_flow_imp.id(795342954885734346)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(795347118297761173)
,p_validation_name=>'URL 3 must start with http'
,p_validation_sequence=>60
,p_validation=>':P6_LINK_URL_3 is null or substr(:P6_LINK_URL_3, 1, 4) = ''http'''
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'URL must start with http:// or https://'
,p_validation_condition=>'P6_LINK_URL_3'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_when_button_pressed=>wwv_flow_imp.id(795332188427710840)
,p_associated_item=>wwv_flow_imp.id(795342954885734346)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(795335904426710857)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(795331372948710838)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(795336487484710859)
,p_event_id=>wwv_flow_imp.id(795335904426710857)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(795347594615769640)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'edit links'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update eba_ca_events',
'set LINK_NAME_1 = :P6_LINK_NAME_1,                   ',
'    LINK_URL_1 = :P6_LINK_URL_1,                ',
'    LINK_NAME_2 = :P6_LINK_NAME_2,                    ',
'    LINK_URL_2 = :P6_LINK_URL_2,                     ',
'    LINK_NAME_3 = :P6_LINK_NAME_3,                   ',
'    LINK_URL_3 = :P6_LINK_URL_3',
'where event_id = :P6_ID;',
'',
':P6_LINK_NAME_1 := null;',
':P6_LINK_URL_1 := null;',
':P6_LINK_NAME_2 := null;',
':P6_LINK_URL_2 := null;',
':P6_LINK_NAME_3 := null;',
':P6_LINK_URL_3 := null;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Unable to update the links'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(795332188427710840)
,p_process_success_message=>'Links updated'
,p_internal_uid=>795347594615769640
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(795335564387710857)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>795335564387710857
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(795334383389710855)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>795334383389710855
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(112074702522221444)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Populate Links'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    LINK_NAME_1,                   ',
'    LINK_URL_1,                ',
'    LINK_NAME_2,                    ',
'    LINK_URL_2,                     ',
'    LINK_NAME_3,                   ',
'    LINK_URL_3',
'into',
'    :P6_LINK_NAME_1,',
'    :P6_LINK_URL_1,',
'    :P6_LINK_NAME_2,',
'    :P6_LINK_URL_2,',
'    :P6_LINK_NAME_3,',
'    :P6_LINK_URL_3',
'from',
'    eba_ca_events',
'where',
'    event_id = :P6_ID;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P6_ID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>112074702522221444
);
wwv_flow_imp.component_end;
end;
/
