prompt --application/deployment/install/install_series
begin
--   Manifest
--     INSTALL: INSTALL-series
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3254470178702750242)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'series'
,p_sequence=>205
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table eba_ca_series (',
'   series_id        number        not null,',
'   --',
'   start_date       timestamp with time zone  not null,',
'   end_date         timestamp with time zone  not null,',
'   recur_freq       varchar2(10)  not null,',
'   --',
'   created_on       timestamp with time zone  not null,',
'   created_by       varchar2(255)  not null,',
'   last_updated_on  timestamp with time zone,',
'   last_updated_by  varchar2(255) )',
'/',
'alter table eba_ca_series ',
'   add constraint eba_ca_series_pk primary key (series_id)',
'/',
'create or replace trigger eba_ca_series_biu',
'  before insert or update on eba_ca_series               ',
'  for each row  ',
'begin   ',
'  if inserting then',
'     if :NEW.series_id is null ',
'        then :NEW.series_id := eba_ca_api.gen_id;',
'     end if;',
'     :NEW.CREATED_ON := CURRENT_TIMESTAMP;',
'     :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);',
'   end if;',
'',
'   if updating then',
'      :NEW.LAST_UPDATED_ON := CURRENT_TIMESTAMP;',
'      :NEW.LAST_UPDATED_BY := nvl(v(''APP_USER''),USER);',
'   end if; ',
'end; ',
'/',
'alter trigger eba_ca_series_biu enable',
'/',
'',
'',
'',
''))
);
wwv_flow_imp.component_end;
end;
/
