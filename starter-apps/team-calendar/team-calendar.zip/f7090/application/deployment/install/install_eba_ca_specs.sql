prompt --application/deployment/install/install_eba_ca_specs
begin
--   Manifest
--     INSTALL: INSTALL-eba_ca specs
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3234405910054063480)
,p_install_id=>wwv_flow_imp.id(7387283442825590819)
,p_name=>'eba_ca specs'
,p_sequence=>340
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package eba_ca is ',
'    -------------------------------------------------------------------------',
'    -- Generates a unique Identifier',
'    -------------------------------------------------------------------------',
'    function gen_id return number;',
'',
'    -------------------------------------------------------------------------',
'    -- Gets the current user''s authorization level. Can depend on the following:',
'    --  * If access control is currently disabled, returns highest level of 3.',
'    --  * If access control is enabled, but user is not in list, returns 0',
'    --  * If access control is enabled and user is in list, returns their',
'    --    access level.',
'    -------------------------------------------------------------------------',
'    function get_authorization_level (',
'        p_username             varchar2)',
'        return number;',
'    -------------------------------------------------------------------------',
'    -- Returns all of the restricted calendars for the given user          --',
'    -------------------------------------------------------------------------',
'    function decode_restrictions (',
'        p_user_id             number)',
'        return varchar2;',
'end eba_ca ;',
'/'))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(1662358162640665890)
,p_script_id=>wwv_flow_imp.id(3234405910054063480)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_CA'
);
wwv_flow_imp.component_end;
end;
/
