prompt --application/deployment/install/upgrade_update_event_types
begin
--   Manifest
--     INSTALL: UPGRADE-Update event types
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1631728847678874687)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'Update event types'
,p_sequence=>70
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select column_name',
'from user_tab_columns',
'where table_name = ''EBA_CA_EVENT_TYPES''',
'    and column_name = ''INTERNAL_YN'''))
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'alter table eba_ca_event_types',
'  add (INTERNAL_YN VARCHAR2(1));',
''))
);
wwv_flow_imp.component_end;
end;
/
