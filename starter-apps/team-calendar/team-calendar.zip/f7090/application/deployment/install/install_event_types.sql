prompt --application/deployment/install/install_event_types
begin
--   Manifest
--     INSTALL: INSTALL-event types
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(7387289345550598953)
,p_install_id=>wwv_flow_imp.id(7387283442825590819)
,p_name=>'event types'
,p_sequence=>200
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table eba_ca_event_types (',
'   type_id          number         not null,',
'   type_name        varchar2(60)   not null,',
'   display_color    varchar2(60),',
'   border_color     varchar2(30),',
'   text_color       varchar2(30),',
'   internal_yn      varchar2(1),',
'   is_active_yn     varchar2(1),',
'   color_pref_id    number',
'                    constraint eba_ca_et_cp_ck',
'                    references eba_ca_color_prefs (id),',
'   --',
'   created_on       timestamp with time zone  not null,',
'   created_by       varchar2(255)  not null,',
'   last_updated_on  timestamp with time zone,',
'   last_updated_by  varchar2(255) )',
'/',
'',
'-- Add index on foreign key columns',
'create index eba_ca_event_types_cp_idx on eba_ca_event_types(color_pref_id);',
'',
'alter table eba_ca_event_types',
'   add constraint eba_ca_event_types_pk primary key (type_id)',
'/',
'    ',
'alter table eba_ca_event_types',
'   add constraint eba_ca_event_types_uk unique (type_name)',
'/',
'    ',
'    ',
'create or replace trigger eba_ca_event_types_biu',
'  before insert or update on eba_ca_event_types               ',
'  for each row  ',
'begin   ',
'  if inserting then',
'     if :NEW.type_id is null ',
'        then :NEW.type_id := eba_ca_api.gen_id; ',
'     end if;',
'     :NEW.CREATED_ON := CURRENT_TIMESTAMP;',
'     :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);',
'   end if;',
'',
'   if updating then',
'      :NEW.LAST_UPDATED_ON := CURRENT_TIMESTAMP;',
'      :NEW.LAST_UPDATED_BY := nvl(v(''APP_USER''),USER);',
'   end if; ',
'   if :new.is_active_yn is null then',
'       if :new.type_name is null then',
'          :new.is_active_yn := ''N'';',
'       else',
'          :new.is_active_yn := ''Y'';',
'       end if;',
'   end if;',
'end; ',
'/',
'show errors',
'    ',
' ',
'alter trigger eba_ca_event_types_biu enable',
'/',
'',
'commit;',
'',
''))
);
wwv_flow_imp.component_end;
end;
/
