prompt --application/deployment/install/install_install_the_acl_seed_data
begin
--   Manifest
--     INSTALL: INSTALL-install the acl seed data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3254484979694072285)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'install the acl seed data'
,p_sequence=>630
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Bug tracker access levels */',
'insert into eba_ca_access_levels (id, access_level) values (1, ''Reader'');',
'insert into eba_ca_access_levels (id, access_level) values (2, ''Contributor'');',
'insert into eba_ca_access_levels (id, access_level) values (3, ''Administrator'');',
'',
'/* Bug Tracker preferences */',
'insert into eba_ca_preferences (id, preference_name, preference_value) values (1, ''ACCESS_CONTROL_ENABLED'', ''N'');',
'insert into eba_ca_preferences (id, preference_name, preference_value) values (2, ''ACCESS_CONTROL_SCOPE'', ''ACL_ONLY'');',
'insert into eba_ca_preferences (id, preference_name, preference_value) values (3, ''USERNAME_FORMAT'', ''EMAIL'');',
'',
'/* Constraint error lookups */',
'insert into eba_ca_error_lookup (constraint_name, message, language_code) values (''EBA_CA_USERS_UK'', ''Username must be unique.'', ''en'');',
'insert into eba_ca_error_lookup (constraint_name, message, language_code) values (''EBA_CA_CALENDAR_UK1'', ''Calendar Short Name must be unique.'', ''en'');',
'insert into eba_ca_error_lookup (constraint_name, message, language_code) values (''EBA_CA_CALENDAR_UK2'', ''Calendar Name must be unique.'', ''en'');',
'',
'commit;',
'/',
'show errors'))
);
wwv_flow_imp.component_end;
end;
/
