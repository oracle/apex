prompt --application/deployment/install/install_events_seq
begin
--   Manifest
--     INSTALL: INSTALL-events_seq
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3256459857462054443)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'events_seq'
,p_sequence=>202
,p_script_type=>'INSTALL'
,p_script_clob=>'create sequence eba_ca_seq;'
);
wwv_flow_imp.component_end;
end;
/
