prompt --application/deployment/install/install_group_members
begin
--   Manifest
--     INSTALL: INSTALL-group members
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3234394302921796501)
,p_install_id=>wwv_flow_imp.id(7387283442825590819)
,p_name=>'group members'
,p_sequence=>220
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table EBA_ca_email_group_mbrs (',
'   mbr_id         number         not null,',
'   group_id       number         not null,',
'   email_address  varchar2(255)  not null,',
'   --',
'   created_on       timestamp with time zone  not null,',
'   created_by       varchar2(255)  not null,',
'   last_updated_on  timestamp with time zone,',
'   last_updated_by  varchar2(255) )',
'/',
'alter table EBA_ca_email_group_mbrs',
'   add constraint EBA_ca_email_group_mbrs_pk primary key (mbr_id)',
'/',
'alter table EBA_ca_email_group_mbrs',
'   add constraint EBA_ca_email_group_mbrs_uk unique (group_id, email_address)',
'/',
'alter table EBA_ca_email_group_mbrs ',
'   add constraint EBA_ca_email_group_mbrs_fk1 ',
'   foreign key (group_id)',
'   references EBA_ca_email_groups (group_id)',
'   on delete cascade',
'/',
'create index EBA_ca_email_group_mbrs_i1',
'   on EBA_ca_email_group_mbrs (group_id)',
'/',
'create or replace trigger EBA_ca_email_group_mbrs_biu',
'  before insert or update on EBA_ca_email_group_mbrs              ',
'  for each row  ',
'begin   ',
'  if inserting then',
'     if :NEW.mbr_id is null ',
'        then :NEW.mbr_id := EBA_ca_api.gen_id; ',
'     end if;',
'     :NEW.CREATED_ON := CURRENT_TIMESTAMP;',
'     :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);',
'   end if;',
'',
'   if updating then',
'      :NEW.LAST_UPDATED_ON := CURRENT_TIMESTAMP;',
'      :NEW.LAST_UPDATED_BY := nvl(v(''APP_USER''),USER);',
'   end if; ',
'end; ',
'/',
'alter trigger EBA_ca_email_group_mbrs_biu enable',
'/',
'',
'',
'',
''))
);
wwv_flow_imp.component_end;
end;
/
