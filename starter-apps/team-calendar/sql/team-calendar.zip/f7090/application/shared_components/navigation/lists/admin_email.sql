prompt --application/shared_components/navigation/lists/admin_email
begin
--   Manifest
--     LIST: Admin Email
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(8026075336789797962)
,p_name=>'Admin Email'
,p_static_id=>'admin-email'
,p_version_scn=>'1089051329'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8026707246335989906)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Group Members'
,p_static_id=>'group-members'
,p_list_item_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-users'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_text_01=>'Report of all members of all groups.  Used for adding members and seeing which groups a person belongs to.'
,p_security_scheme=>wwv_flow_imp.id(3255013570915135948)
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8026705935254986699)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Groups'
,p_static_id=>'groups'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-users'
,p_list_item_disp_cond_type=>'NEVER'
,p_list_text_01=>'Groups are reusable lists of people that you can email a set of events to.'
,p_security_scheme=>wwv_flow_imp.id(3255013570915135948)
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(8026076355836803439)
,p_list_item_display_sequence=>5
,p_list_item_link_text=>'Send Email'
,p_static_id=>'send-email'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:15:::'
,p_list_item_icon=>'fa-envelope-o'
,p_list_item_disp_cond_type=>'FUNCTION_BODY'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_from_email varchar2(255);',
'begin',
'    -- If the end-user''s username is already an email address use it as the from address',
'    if regexp_like(:APP_USER, ''^[-!#$%&''''''''*+/0-9=?A-Z^_a-z{|}~](\.?[-!#$%&''''''''*+/0-9=?A-Z^_a-z{|}~])*@(-?[a-zA-Z0-9+])+(\.(-?[a-zA-Z0-9+])*)+$'') then',
'        l_from_email := lower(:APP_USER);',
'    else',
'        -- otherwise populate the from address by querying the apex_workspace_apex_users view (where email is a required value)',
'        select',
'            lower(a.email)',
'        into',
'            l_from_email',
'        from',
'            eba_ca_users u,',
'            apex_workspace_apex_users a',
'        where',
'            lower(u.username) = lower(a.user_name)',
'        and',
'            lower(:APP_USER) = lower(a.user_name);',
'    end if;',
'    return regexp_like(l_from_email, ''^[-!#$%&''''''''*+/0-9=?A-Z^_a-z{|}~](\.?[-!#$%&''''''''*+/0-9=?A-Z^_a-z{|}~])*@(-?[a-zA-Z0-9+])+(\.(-?[a-zA-Z0-9+])*)+$'');',
'end;'))
,p_list_item_disp_condition2=>'PLSQL'
,p_list_text_01=>'Send email of events to other app users.'
,p_security_scheme=>wwv_flow_imp.id(3255013570915135948)
,p_list_item_current_type=>'NEVER'
);
wwv_flow_imp.component_end;
end;
/
