prompt --application/shared_components/navigation/lists/activity_reporting
begin
--   Manifest
--     LIST: Activity Reporting
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(3334177763374933970)
,p_name=>'Activity Reporting'
,p_static_id=>'activity-reporting'
,p_version_scn=>'1089051329'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3334177980562933971)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Activity Calendar'
,p_static_id=>'activity-calendar'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar'
,p_list_text_01=>'Monthly calendar of page views with summary of page views by user by day.'
,p_security_scheme=>wwv_flow_imp.id(3255013570915135948)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
