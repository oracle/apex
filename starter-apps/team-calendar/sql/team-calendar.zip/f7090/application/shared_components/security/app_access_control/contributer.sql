prompt --application/shared_components/security/app_access_control/contributer
begin
--   Manifest
--     ACL ROLE: Contributer
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(601291328945779061)
,p_static_id=>'CONTRIBUTER'
,p_name=>'Contributer'
,p_version_scn=>'37166093807337'
);
wwv_flow_imp.component_end;
end;
/
