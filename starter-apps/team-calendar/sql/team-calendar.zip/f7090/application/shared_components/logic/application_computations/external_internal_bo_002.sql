prompt --application/shared_components/logic/application_computations/external_internal_bo_002
begin
--   Manifest
--     APPLICATION COMPUTATION: EXTERNAL_INTERNAL_BO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(1636224894490207717)
,p_computation_sequence=>10
,p_computation_item=>'EXTERNAL_INTERNAL_BO'
,p_static_id=>'external-internal-bo-2'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'Exclude'
,p_required_patch=>-wwv_flow_imp.id(1631739938122003976)
,p_version_scn=>'37166093807536'
);
wwv_flow_imp.component_end;
end;
/
