prompt --application/shared_components/logic/application_computations/multiple_cal_bo_name
begin
--   Manifest
--     APPLICATION COMPUTATION: MULTIPLE_CAL_BO_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(1857193218027407197)
,p_computation_sequence=>10
,p_computation_item=>'MULTIPLE_CAL_BO_NAME'
,p_static_id=>'multiple-cal-bo-name'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'Include Multiple Calendars'
,p_required_patch=>wwv_flow_imp.id(1857191596806388379)
,p_version_scn=>'37166093807552'
);
wwv_flow_imp.component_end;
end;
/
