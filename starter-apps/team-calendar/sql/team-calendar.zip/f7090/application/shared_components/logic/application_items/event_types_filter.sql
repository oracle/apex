prompt --application/shared_components/logic/application_items/event_types_filter
begin
--   Manifest
--     APPLICATION ITEM: EVENT_TYPES_FILTER
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(1857288456026996476)
,p_name=>'EVENT_TYPES_FILTER'
,p_protection_level=>'B'
,p_version_scn=>'37166093807431'
);
wwv_flow_imp.component_end;
end;
/
