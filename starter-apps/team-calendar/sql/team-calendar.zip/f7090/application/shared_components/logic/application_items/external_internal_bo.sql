prompt --application/shared_components/logic/application_items/external_internal_bo
begin
--   Manifest
--     APPLICATION ITEM: EXTERNAL_INTERNAL_BO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(1636207483632184202)
,p_name=>'EXTERNAL_INTERNAL_BO'
,p_protection_level=>'I'
,p_required_patch=>wwv_flow_imp.id(1631739938122003976)
,p_version_scn=>'37166093807439'
);
wwv_flow_imp.component_end;
end;
/
