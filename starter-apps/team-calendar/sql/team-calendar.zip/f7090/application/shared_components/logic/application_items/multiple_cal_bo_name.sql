prompt --application/shared_components/logic/application_items/multiple_cal_bo_name
begin
--   Manifest
--     APPLICATION ITEM: MULTIPLE_CAL_BO_NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(1857192596369401875)
,p_name=>'MULTIPLE_CAL_BO_NAME'
,p_protection_level=>'I'
,p_version_scn=>'37166093807500'
);
wwv_flow_imp.component_end;
end;
/
