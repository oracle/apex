prompt --application/shared_components/logic/application_computations/cals_restricted_to
begin
--   Manifest
--     APPLICATION COMPUTATION: CALS_RESTRICTED_TO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(1877349022917487833)
,p_computation_sequence=>10
,p_computation_item=>'CALS_RESTRICTED_TO'
,p_static_id=>'cals-restricted-to'
,p_computation_point=>'ON_NEW_INSTANCE'
,p_computation_type=>'QUERY'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(restricted_to, decode(access_level_id, 3, ''All'', null)) ',
'from eba_ca_users',
'where username = :APP_USER'))
,p_required_patch=>wwv_flow_imp.id(1857191596806388379)
,p_version_scn=>'37166093807584'
);
wwv_flow_imp.component_end;
end;
/
