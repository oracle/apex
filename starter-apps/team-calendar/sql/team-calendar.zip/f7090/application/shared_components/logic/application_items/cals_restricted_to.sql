prompt --application/shared_components/logic/application_items/cals_restricted_to
begin
--   Manifest
--     APPLICATION ITEM: CALS_RESTRICTED_TO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(1877348547787470302)
,p_name=>'CALS_RESTRICTED_TO'
,p_protection_level=>'I'
,p_version_scn=>'37166093807416'
);
wwv_flow_imp.component_end;
end;
/
