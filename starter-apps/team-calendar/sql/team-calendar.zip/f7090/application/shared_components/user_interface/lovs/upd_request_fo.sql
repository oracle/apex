prompt --application/shared_components/user_interface/lovs/upd_request_fo
begin
--   Manifest
--     UPD_REQUEST_FO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(8013855350474439529)
,p_lov_name=>'UPD_REQUEST_FO'
,p_static_id=>'upd-request-fo'
,p_lov_query=>'.'||wwv_flow_imp.id(8013855350474439529)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089051329'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8013855842230439532)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Future Events'
,p_lov_return_value=>'F'
,p_static_id=>'future-events'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8013855627726439530)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Only this Event'
,p_lov_return_value=>'O'
,p_static_id=>'only-this-event'
);
wwv_flow_imp.component_end;
end;
/
