prompt --application/shared_components/user_interface/lovs/upd_request_af
begin
--   Manifest
--     UPD_REQUEST_AF
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(8013806240713256999)
,p_lov_name=>'UPD_REQUEST_AF'
,p_static_id=>'upd-request-af'
,p_lov_query=>'.'||wwv_flow_imp.id(8013806240713256999)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089051329'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8013806528307257004)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'All Events'
,p_lov_return_value=>'A'
,p_static_id=>'all-events'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(8013806751351257007)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Future Events'
,p_lov_return_value=>'F'
,p_static_id=>'future-events'
);
wwv_flow_imp.component_end;
end;
/
