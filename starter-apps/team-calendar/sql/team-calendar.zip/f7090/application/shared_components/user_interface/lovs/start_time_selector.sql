prompt --application/shared_components/user_interface/lovs/start_time_selector
begin
--   Manifest
--     START TIME SELECTOR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(8940579525097807890)
,p_lov_name=>'START TIME SELECTOR'
,p_static_id=>'start-time-selector'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(trunc(sysdate)+((i-1)/48),v(''APP_TIME_FORMAT'')) d,',
'       to_char(trunc(sysdate)+((i-1)/48),v(''APP_TIME_FORMAT'')) r',
'  from wwv_flow_dual100',
' where i < 49',
'order by i',
''))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>'1089051329'
);
wwv_flow_imp.component_end;
end;
/
