prompt --application/shared_components/user_interface/lovs/std_time_zones
begin
--   Manifest
--     STD TIME ZONES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(3257177157360502937)
,p_lov_name=>'STD TIME ZONES'
,p_static_id=>'std-time-zones'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct tzname d, tzname r',
'  from V$TIMEZONE_NAMES',
' order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>'1089051329'
);
wwv_flow_imp.component_end;
end;
/
