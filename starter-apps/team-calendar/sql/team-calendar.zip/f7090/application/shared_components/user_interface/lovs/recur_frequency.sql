prompt --application/shared_components/user_interface/lovs/recur_frequency
begin
--   Manifest
--     RECUR FREQUENCY
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(9159195104956907243)
,p_lov_name=>'RECUR FREQUENCY'
,p_static_id=>'recur-frequency'
,p_lov_query=>'.'||wwv_flow_imp.id(9159195104956907243)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089051329'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9159195418193907255)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Daily'
,p_lov_return_value=>'D'
,p_static_id=>'daily'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9159196224191907266)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'each Month (same date)'
,p_lov_return_value=>'M'
,p_static_id=>'each-month-same-date'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9159196000042907266)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'every 2 Weeks (same day of week)'
,p_lov_return_value=>'2W'
,p_static_id=>'every-2-weeks-same-day-of-week'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(4093530390742968619)
,p_lov_disp_sequence=>6
,p_lov_disp_value=>'every 3 Months (same date)'
,p_lov_return_value=>'Q'
,p_static_id=>'every-3-months-same-date'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9159195811670907266)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'every Week (same day of week)'
,p_lov_return_value=>'W'
,p_static_id=>'every-week-same-day-of-week'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9159195620605907266)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'every Weekday (M-F)'
,p_lov_return_value=>'WD'
,p_static_id=>'every-weekday-m-f'
);
wwv_flow_imp.component_end;
end;
/
