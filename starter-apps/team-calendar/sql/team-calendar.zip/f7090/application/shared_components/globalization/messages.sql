prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 7090
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3261237476111555285)
,p_name=>'ABOUT_THIS_APPLICATION'
,p_message_text=>'About this Application'
,p_version_scn=>'37166093810590'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1382872964758907340)
,p_name=>'ABOUT_TO_CREATE'
,p_message_text=>'Please confirm adding the following %0 <strong>%1</strong> user(s) to your access control list.'
,p_version_scn=>'37166093810592'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1427460080536124431)
,p_name=>'ABOUT_TO_CREATE_WITH_INVALIDS'
,p_message_text=>'Please confirm adding the following %0 <strong>%1</strong> user(s) to your access control list. Note that %2 string(s) were invalid usernames.'
,p_version_scn=>'37166093810592'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3256352351754690253)
,p_name=>'ACCESS_CONTROL_INFO'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>When Access Control is enabled, Administrators have the ability to restrict access to certain application features, for authenticated users. Team Calendar supports the following 3 access levels; Reader, Contributor and Administrator.',
'  <b>Reader''s</b> have read-only access and can also view reports.',
'  <b>Contributor''s</b> can create, edit, delete and view reports.',
'  <b>Administrator''s</b>, in addition to Contributor''s capability, can also perform Team Calendar administration, including configuration of access control, exporting and installing or uninstalling sample data.</p> ',
''))
,p_version_scn=>'37166093810601'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1527299358534440675)
,p_name=>'ACL_DISABLED'
,p_message_text=>'<p>All users are currently <strong>Administrators</strong>. Please enable Access Control to restrict user access to this application.</p>'
,p_version_scn=>'37166093810613'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1527299162631438803)
,p_name=>'ACL_ENABLED'
,p_message_text=>'<p>Only users defined in the Access Control List have access to this application.</p>'
,p_version_scn=>'37166093810613'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1527298967376436590)
,p_name=>'ACL_PUBLIC_CONTRIBUTE'
,p_message_text=>'<p>All authenticated users have <strong>Reader</strong> and <strong>Contributor</strong> access.</p><p>Administrators are restricted by the Access Control List.</p>'
,p_version_scn=>'37166093810613'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1527298771905434419)
,p_name=>'ACL_PUBLIC_READONLY'
,p_message_text=>'<p>All authenticated users have <strong>Reader</strong> access.</p><p>Contributors and Administrators are restricted by the Access Control List.</p>'
,p_version_scn=>'37166093810613'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3255564555958301925)
,p_name=>'AC_CONFIGURATION_INFO'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p><strong>Enabling Access Control</strong> allows the application and its features to be controlled by the <strong>Access Control List</strong>, as defined by the application administrator. This application has 3 access levels available that can be '
||'granted to a user; Administrator, Contributor and Reader. Please see the Manage Access Control List page for further details on what each level provides.</p>',
'',
'<p>In addition, if you want to make every authenticated user a ''Reader'' of your application, you can select Reader access for any authenticated user from the Access Control Scope configuration option. Similarly, selecting Contributor access for any a'
||'uthenticated user will provide contributor access to any user who can authenticate into your application.</p>',
'',
'<br>',
'<p><b>Disabling Access Control</b> means that access to the application and all of its features including Administration are open to any user who can authenticate to the application.</p>',
'<br>',
'<p>Note: Irrespective of whether Access Control is enabled or disabled, a user still has to authenticate successfully into the application.</p>'))
,p_version_scn=>'37166093810626'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3261236767108552773)
,p_name=>'ADDITIONAL_INFORMATION'
,p_message_text=>'Additional Information'
,p_version_scn=>'37166093810638'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2974335775296699783)
,p_name=>'ADMINISTRATION'
,p_message_text=>'Administration'
,p_version_scn=>'37166093810647'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1382872570581904623)
,p_name=>'ALREADY_IN_ACL'
,p_message_text=>'User is already in Access Control List'
,p_version_scn=>'37166093810658'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1527298575355432832)
,p_name=>'ANY_AUTHENTICATED_USER'
,p_message_text=>'Any Authenticated User'
,p_version_scn=>'37166093810668'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1527751448995647250)
,p_name=>'AUTHENTICATION_REQUIRED_PAGES'
,p_message_text=>'Login Required Pages'
,p_version_scn=>'37166093810676'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1382871552478897827)
,p_name=>'BAU_EMAIL_INSTRUCTIONS'
,p_message_text=>'Enter or copy and paste email addresses separated by commas, semicolons, or new lines. Note that if you copy and paste email addresses from email messages, extraneous text will be filtered out. All email users provided will be added as the selected r'
||'ole. Existing or duplicate email addresses will be ignored.'
,p_version_scn=>'37166093810685'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1382871355713896402)
,p_name=>'BAU_STRING_INSTRUCTIONS'
,p_message_text=>'Enter or copy and paste usernames separated by commas, semicolons, or whitespace. All usernames provided will be added as the selected role. Existing or duplicate usernames will be ignored.'
,p_version_scn=>'37166093810686'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1382872373600903209)
,p_name=>'DUPLICATE_USER'
,p_message_text=>'Duplicate user in list'
,p_version_scn=>'37166093810694'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1508141578979070801)
,p_name=>'EMAIL_USERNAME_FORMAT_MSG'
,p_message_text=>'This application is currently using an <strong>email address</strong> username format (e.g. xyz@xyz.com). <a href="f?p=%0:%1:%2:">Change Username Format</a>'
,p_version_scn=>'37166093810704'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3261237070224553607)
,p_name=>'FEATURES'
,p_message_text=>'Features'
,p_version_scn=>'37166093810713'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3261237273341554545)
,p_name=>'GETTING_STARTED'
,p_message_text=>'Getting Started'
,p_version_scn=>'37166093810723'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2974315669409698072)
,p_name=>'HELP'
,p_message_text=>'Help'
,p_version_scn=>'37166093810753'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1449108063563771671)
,p_name=>'HELP_ABOUT'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="aboutApp">',
'<h2>About this Application</h2>',
'<p>The Team Calendar application gives you a way to list all your events on an easy to use, Web-accessible calendar. The Home page for the Team Calendar displays events in a monthly, weekly or daily format, with embedded links to detailed information'
||' about each event. You can also create customized reports on events.</p>',
'<p>',
'Each event is classified by event type and automatically displayed in an associated color. You can create your own event types or modify existing event type attributes.</p>',
'<p>',
'You can also send emails to other app users with information about upcoming meetings.</p>',
'</div>'))
,p_version_scn=>'37166160244049'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1449107673053767246)
,p_name=>'HELP_FEATURES'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="textRegion">',
'<h2>Features</h2><ul>',
'<li>Monthly/Weakly and Daily calendar Views</li>',
'<li>Flexible way to add and changes events</li>',
'<li>Nice Events views</li>',
'<li>Clear Timeline Display </li>',
'<li>Mobile Interface</li>',
'<li>Flexible Access Control (reader, contributor, administrator model)</li>',
'<li>Flexible Notifications</li>',
'</div>'))
,p_version_scn=>'37166093810754'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1449107867877769668)
,p_name=>'HELP_GETTING_STARTED'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="textRegion">',
'<h2>Getting Started</h2>',
'<br /><p>1. Set up Timeline</p>',
'<ul>',
'<li>Click the Timeline Tab</li>',
'<li>Click Create Event</li>',
'<li>Click the Create Button and add your events</li>',
'</ul>',
'<br /><p>2. Define Event Types:</p>',
'<ul>',
'<li>Click the Administration icon (gear icon)</li>',
'<li>Edit Event Types</li>',
'</ul>',
'</div>'))
,p_version_scn=>'37166093810755'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1449108258603773940)
,p_name=>'HELP_SIDEBAR'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h1 class="appNameHeader">',
'    <img src="%0f_spacer.gif" class="appIcon %1" alt="" />',
'    %2',
'</h1>',
'<ul class="vapList">',
'    <li>',
'        <span class="vLabel">App Version</span>',
'        <span class="vValue">%3</span>',
'    </li>',
'    <li>',
'        <span class="vLabel">Pages</span>',
'        <span class="vValue">%4</span>',
'    </li>',
'    <li>',
'        <span class="vLabel">Vendor</span>',
'        <span class="vValue">%5 </span>',
'    </li>',
'</ul>'))
,p_version_scn=>'37166093810755'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1449107450205762613)
,p_name=>'HELP_SUPPORT'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="textRegion">',
'<h2>Additional Information</h2>',
'<p>If you have questions, ask them on the <a href="%0" target="_blank">%1</a>.',
'</p>',
'</div>'))
,p_version_scn=>'37166093810757'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1382872767778905974)
,p_name=>'INVALID_USERS_NOT_CREATED'
,p_message_text=>'Note that %0 string(s) were invalid usernames.'
,p_version_scn=>'37166093810765'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2974319770794698470)
,p_name=>'LOGIN'
,p_message_text=>'Login'
,p_version_scn=>'37166093810783'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(2974331672872699052)
,p_name=>'LOGOUT'
,p_message_text=>'Logout'
,p_version_scn=>'37166093810793'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1382871979639900489)
,p_name=>'MISSING_AT_SIGN'
,p_message_text=>'Missing @ sign'
,p_version_scn=>'37166093810805'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1382871749028899432)
,p_name=>'MISSING_DOT'
,p_message_text=>'Missing dot'
,p_version_scn=>'37166093810806'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3208913879511663327)
,p_name=>'MOBILE'
,p_message_text=>'Mobile'
,p_version_scn=>'37166093810815'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1527751054171644835)
,p_name=>'PAGES_WITH_CUSTOM_AUTH'
,p_message_text=>'Authorization Protected'
,p_version_scn=>'37166093810825'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1527751251583646054)
,p_name=>'PUBLIC_PAGES'
,p_message_text=>'Public Pages'
,p_version_scn=>'37166093810830'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1508141774881072701)
,p_name=>'STRING_USERNAME_FORMAT_MSG'
,p_message_text=>'This application is currently using a <strong>non-email address</strong> username format (e.g. JOHNDOE). <a href="f?p=%0:%1:%2:">Change Username Format</a>'
,p_version_scn=>'37166093810839'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(1382872176620901848)
,p_name=>'USERNAME_TOO_LONG'
,p_message_text=>'Username too long'
,p_version_scn=>'37166093810846'
);
wwv_flow_imp.component_end;
end;
/
