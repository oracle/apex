prompt --application/pages/page_00015
begin
--   Manifest
--     PAGE: 00015
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>15
,p_name=>'Send Email'
,p_alias=>'SEND-EMAIL'
,p_step_title=>'Send Email'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(8940478416777379715)
,p_step_template=>2528119710305719084
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(3255013570915135948)
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ol>',
'  <li>Use the filter to select the set of events to be included.</li>',
'  <li>Select the group to send email to and/or enter email addresses separated by commas.</li>',
'  <li>Customize the from, subject and message body.</li>',
'  <li>Click [Send Email].</li>',
'</ol>',
'<p>Emails can be sent to other app users.  The set of events will be appended to the message body.  The ''From'' email address will be carbon-copied on the email.',
'</p>'))
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8026072755705793872)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(8940448701738354891)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8026929850809464207)
,p_plug_name=>'Email Details'
,p_static_id=>'email-details'
,p_region_template_options=>'#DEFAULT#:t-Region--hiddenOverflow:t-Region--hideHeader js-addHiddenHeadingRoleDesc'
,p_region_attributes=>'style="width: 99%; min-width: 99%"'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(132149191584181502)
,p_plug_name=>'Email Functionality Disabled'
,p_static_id=>'email-functionality-disabled'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--danger'
,p_plug_template=>2042159785845301134
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'This form uses the current end-user''s email address as the "From" email address for the emails it sends. We were unable to derive your email address, therefore this form cannot be used. Please ensure your APEX account has a valid email address define'
||'d or change the app''s authentication method to one that uses email addresses as usernames.'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'not regexp_like(:P15_FROM, ''^[-!#$%&''''''''*+/0-9=?A-Z^_a-z{|}~](\.?[-!#$%&''''''''*+/0-9=?A-Z^_a-z{|}~])*@(-?[a-zA-Z0-9+])+(\.(-?[a-zA-Z0-9+])*)+$'')'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(8014162132081286906)
,p_name=>'Events to be Included'
,p_static_id=>'events-to-be-included'
,p_template=>4073835273271169698
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.EVENT_ID,',
'       event_name,',
'       et.type_name || decode(:EXTERNAL_INTERNAL_BO, ''Include'', decode(internal_yn, ''Y'', '' (Internal Only)'', null), null) event_type,',
'       e.EVENT_DATE_TIME event_date,',
'       case when to_char(e.EVENT_DATE_TIME,''MI'') = ''00'' ',
'            then ltrim(to_char(e.EVENT_DATE_TIME,''HHam''),''0'')',
'            else ltrim(to_char(e.EVENT_DATE_TIME,''HH:MIam''),''0'')',
'            end start_time,',
'       case when to_char(to_date(to_char(EVENT_DATE_TIME,''DD-MON-RR''||''HH:MIam''),',
'                         ''DD-MON-RR''||''HH:MIam'')+(e.duration/24),''MI'') = ''00''',
'            then ltrim(to_char(to_date(to_char(EVENT_DATE_TIME,''DD-MON-RR''||''HH:MIam''),',
'                         ''DD-MON-RR''||''HH:MIam'')+(e.duration/24),''HHam''),''0'')',
'            else ltrim(to_char(to_date(to_char(EVENT_DATE_TIME,''DD-MON-RR''||''HH:MIam''),',
'                         ''DD-MON-RR''||''HH:MIam'')+(e.duration/24),''HH:MIam''),''0'')',
'            end end_time,',
'       case when e.duration = 0  then ''0 mins''',
'            when e.duration = .25 then ''15 mins''',
'            when e.duration = .5 then ''30 mins''',
'            when e.duration = .75 then ''45 mins''',
'            when e.duration = 1 then ''1 hr''',
'            when e.duration > 1 then to_char(trunc(e.duration)) || '' hrs''',
'              || case when e.duration - trunc(e.duration) = 0  then ''''',
'                      when e.duration - trunc(e.duration) = .25 then '' 15 mins''',
'                      when e.duration - trunc(e.duration) = .5 then '' 30 mins''',
'                      when e.duration - trunc(e.duration) = .75 then '' 45 mins''',
'                 end',
'            end duration,',
'       e.EVENT_DESC',
'  from EBA_CA_EVENTS e,',
'       EBA_CA_EVENT_TYPES et',
' where (:EXTERNAL_INTERNAL_BO = ''Exclude''',
'        or (   nvl(internal_yn, ''N'') = ''N''',
'            or upper(:APP_USER) in (select upper(username) from eba_ca_users)',
'           )',
'       )',
'   and e.type_id = et.type_id (+)',
'   and (:P15_EVENT_TYPE is null or e.type_id = :P15_EVENT_TYPE)',
'   and (:P15_START_DATE is null or ',
'        trunc(to_date(to_char(e.event_date_time,''&APP_DATE_FORMAT.''),',
'              ''&APP_DATE_FORMAT.'')) >= to_date(:P15_START_DATE,''&APP_DATE_FORMAT.'') )',
'   and (:P15_END_DATE is null or ',
'        trunc(to_date(to_char(e.event_date_time,''&APP_DATE_FORMAT.''),',
'              ''&APP_DATE_FORMAT.'')) <= to_date(:P15_END_DATE,''&APP_DATE_FORMAT.'') )',
'   and (:P15_TIMEFRAME is null or',
'        (trunc(to_date(to_char(e.event_date_time,''DD-MON-RRRR''),''DD-MON-RRRR''))',
'            >= (select start_date from EBA_ca_timeframes',
'                 where :P15_TIMEFRAME = tf_id) and',
'         trunc(to_date(to_char(e.event_date_time,''DD-MON-RRRR''),''DD-MON-RRRR''))',
'            <= (select end_date from EBA_ca_timeframes',
'                 where :P15_TIMEFRAME = tf_id)))',
' order by e.event_date_time'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No events found.'
,p_query_num_rows_type=>'SEARCH_ENGINE'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7409430516036813719)
,p_query_column_id=>7
,p_column_alias=>'DURATION'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7409430423803813719)
,p_query_column_id=>6
,p_column_alias=>'END_TIME'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8014162744328286910)
,p_query_column_id=>4
,p_column_alias=>'EVENT_DATE'
,p_column_display_sequence=>1
,p_column_heading=>'Event Date'
,p_column_format=>'&APP_DATE_FORMAT.'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8014163027086286910)
,p_query_column_id=>8
,p_column_alias=>'EVENT_DESC'
,p_column_display_sequence=>8
,p_column_heading=>'Description'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8014162440118286908)
,p_query_column_id=>1
,p_column_alias=>'EVENT_ID'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8014162555196286910)
,p_query_column_id=>2
,p_column_alias=>'EVENT_NAME'
,p_column_display_sequence=>6
,p_column_heading=>'Name'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(8014162643577286910)
,p_query_column_id=>3
,p_column_alias=>'EVENT_TYPE'
,p_column_display_sequence=>7
,p_column_heading=>'Type'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(7409430323350813718)
,p_query_column_id=>5
,p_column_alias=>'START_TIME'
,p_column_display_sequence=>3
,p_column_heading=>'Timing'
,p_column_html_expression=>'#START_TIME# - #END_TIME# (#DURATION#)'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8014171053394301307)
,p_plug_name=>'Filter'
,p_static_id=>'filter'
,p_region_template_options=>'#DEFAULT#:t-Region--hiddenOverflow:t-Region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_02'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1891552695078390070)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_imp.id(8026072755705793872)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:&LAST_VIEW.:&SESSION.::&DEBUG.:RP::'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(2435179722711421824)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(8026929850809464207)
,p_button_name=>'MEMBERS'
,p_static_id=>'members'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--primary:t-Button--simple'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'View Members'
,p_button_redirect_url=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:RP:P20_GROUP_ID:&P15_GROUP_ID.'
,p_button_condition_type=>'NEVER'
,p_button_cattributes=>'style="margin-top:8px;"'
,p_grid_new_row=>'N'
,p_grid_column_span=>5
,p_grid_column=>8
,p_button_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    1',
'from',
'    (',
'        select g.group_id,',
'               g.group_name name,',
'               count(*) cnt    ',
'          from EBA_ca_email_groups g, ',
'               EBA_ca_email_group_mbrs m',
'         where m.group_id = g.group_id',
'         group by g.group_id, g.group_name',
'    ) v1',
'where',
'    v1.cnt > 0'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7434980909737171132)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(8014171053394301307)
,p_button_name=>'P15_CLEAR'
,p_static_id=>'p15-clear'
,p_button_static_id=>'P15_CLEAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Clear'
,p_button_position=>'CLOSE'
,p_request_source=>'CLEAR'
,p_request_source_type=>'STATIC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8014215447600356349)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8014171053394301307)
,p_button_name=>'P15_GO'
,p_static_id=>'p15-go'
,p_button_static_id=>'P15_GO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Go'
,p_button_position=>'HELP'
,p_request_source=>'Go'
,p_request_source_type=>'STATIC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8026948728617580796)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8026072755705793872)
,p_button_name=>'SEND_EMAIL'
,p_static_id=>'send-email'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Send Email'
,p_button_position=>'CREATE'
,p_button_condition=>'regexp_like(:P15_FROM, ''^[-!#$%&''''''''*+/0-9=?A-Z^_a-z{|}~](\.?[-!#$%&''''''''*+/0-9=?A-Z^_a-z{|}~])*@(-?[a-zA-Z0-9+])+(\.(-?[a-zA-Z0-9+])*)+$'')'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(7434990928437176487)
,p_branch_action=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:15::'
,p_branch_point=>'BEFORE_COMPUTATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(7434980909737171132)
,p_branch_sequence=>20
,p_save_state_before_branch_yn=>'Y'
,p_branch_comment=>'Created 18-OCT-2010 12:47 by SBKENNED'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8014215648970356350)
,p_branch_action=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_save_state_before_branch_yn=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8014208837080343935)
,p_name=>'P15_END_DATE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(8014171053394301307)
,p_prompt=>'Until'
,p_format_mask=>'&APP_DATE_FORMAT.'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>16
,p_cMaxlength=>30
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'If entered, Events after this date will not be included.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8014211755780349292)
,p_name=>'P15_EVENT_TYPE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(8014171053394301307)
,p_prompt=>'Type'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'EVENT TYPES FOR MAIN CAL'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- All -'
,p_cHeight=>1
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_help_text=>'If selected, only events of this type will be included.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7420067199052402725)
,p_name=>'P15_FROM'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(8026929850809464207)
,p_prompt=>'From'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>4000
,p_display_when=>'regexp_like(:P15_FROM, ''^[-!#$%&''''''''*+/0-9=?A-Z^_a-z{|}~](\.?[-!#$%&''''''''*+/0-9=?A-Z^_a-z{|}~])*@(-?[a-zA-Z0-9+])+(\.(-?[a-zA-Z0-9+])*)+$'')'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Who the email will be sent from.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8026930742975471442)
,p_name=>'P15_GROUP_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8026929850809464207)
,p_prompt=>'To (group)'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'EMAIL GROUPS WITH CNT'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Group -'
,p_cHeight=>1
,p_colspan=>7
,p_display_when_type=>'NEVER'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_help_text=>'The email group that the email will be sent to.  The can be in addition to email addresses identified in the ''To'' or instead of.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    1',
'from',
'    (',
'        select g.group_id,',
'               g.group_name name,',
'               count(*) cnt    ',
'          from EBA_ca_email_groups g, ',
'               EBA_ca_email_group_mbrs m',
'         where m.group_id = g.group_id',
'         group by g.group_id, g.group_name',
'    ) v1',
'where',
'    v1.cnt > 0'))
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8026934439558498800)
,p_name=>'P15_MSG_BODY'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(8026929850809464207)
,p_item_default=>'Below is a set of events for your review.  If updates are necessary, please let me know.'
,p_prompt=>'Message'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>90
,p_cHeight=>4
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Enter the body of your email.  A table including the selected events will be included below the text.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'N',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8014167541620297911)
,p_name=>'P15_START_DATE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(8014171053394301307)
,p_prompt=>'From'
,p_format_mask=>'&APP_DATE_FORMAT.'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>16
,p_cMaxlength=>30
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'If entered, Events before this date will not be included.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8026931127522476379)
,p_name=>'P15_SUBJECT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(8026929850809464207)
,p_item_default=>'Please review the following events'
,p_prompt=>'Subject'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'The subject line for the email.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8063097849156515114)
,p_name=>'P15_TIMEFRAME'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(8014171053394301307)
,p_prompt=>'Timeframe'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TIMEFRAMES (SHOWING DATES)'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- None -'
,p_cHeight=>1
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from EBA_ca_timeframes'))
,p_display_when_type=>'EXISTS'
,p_field_template=>3033038003750078790
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_help_text=>'Select Reporting Timeframe to restrict the report.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7426010203981552179)
,p_name=>'P15_TO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(8026929850809464207)
,p_prompt=>'To (emails)'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    a.email as dv,',
'    a.email as rv',
'from',
'    eba_ca_users u,',
'    apex_workspace_apex_users a',
'where',
'    lower(u.username) = lower(a.user_name);'))
,p_cSize=>64
,p_cMaxlength=>4000
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    null',
'from',
'    eba_ca_users u,',
'    apex_workspace_apex_users a',
'where',
'    lower(u.username) = lower(a.user_name);'))
,p_display_when_type=>'EXISTS'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_help_text=>'Addresses to email.  Multiple addresses can be selected.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(132148668842181497)
,p_computation_sequence=>10
,p_computation_item=>'P15_FROM'
,p_static_id=>'p15-from'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_from_email varchar2(255);',
'begin',
'    -- If the end-user''s username is already an email address use it as the from address',
'    if regexp_like(:APP_USER, ''^[-!#$%&''''''''*+/0-9=?A-Z^_a-z{|}~](\.?[-!#$%&''''''''*+/0-9=?A-Z^_a-z{|}~])*@(-?[a-zA-Z0-9+])+(\.(-?[a-zA-Z0-9+])*)+$'') then',
'        l_from_email := lower(:APP_USER);',
'    else',
'        -- otherwise populate the from address by querying the apex_workspace_apex_users view (where email is a required value)',
'        select',
'            lower(a.email)',
'        into',
'            l_from_email',
'        from',
'            eba_ca_users u,',
'            apex_workspace_apex_users a',
'        where',
'            lower(u.username) = lower(a.user_name)',
'        and',
'            lower(:APP_USER) = lower(a.user_name);',
'    end if;',
'    return l_from_email;',
'end;'))
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(132149025907181500)
,p_validation_name=>'Defined "To" users are valid '
,p_static_id=>'defined-to-users-are-valid'
,p_validation_sequence=>60
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_email_array  apex_t_varchar2;',
'    l_valid_emails apex_t_varchar2;',
'    l_idx          varchar2(20);',
'    l_retval       boolean := true;',
'begin',
'   -- Populate submitted array',
'   l_email_array := apex_string.split(',
'                        p_str => :P15_TO,',
'                        p_sep => '':''',
'                    );',
'',
'    -- Populate Valid Emails string',
'    begin',
'        select',
'            lower(a.email)',
'        bulk collect into',
'            l_valid_emails',
'        from',
'            eba_ca_users u,',
'            apex_workspace_apex_users a',
'        where',
'            lower(u.username) = lower(a.user_name);',
'    exception',
'        when no_data_found then',
'            -- No users have been defined in the app and/or APEX workspace yet',
'            l_retval := false;',
'            return l_retval;',
'    end;',
'',
'    -- Start index at 1',
'    l_idx := l_email_array.first;',
'',
'    -- Loop through emails submitted in form',
'    while (l_idx is not null)',
'    loop',
'        -- Verify that the emails entered by end-user is in the list of emails assigned to APEX workspace users',
'        l_retval := lower(l_email_array(l_idx)) member of l_valid_emails; -- if this returns false it means the end-user somehow entered an invalid email',
'        ',
'        -- Bail from continued looping if last retval assignment was false',
'        if not l_retval then',
'            exit;',
'        end if;',
'',
'        -- If retval was true, move on to the next array value',
'        l_idx := l_email_array.next(l_idx);',
'    end loop;',
'    return l_retval;',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Please select only email addresses offered in the list.'
,p_validation_condition=>'P15_TO'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_imp.id(7426010203981552179)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(7426027209831601204)
,p_validation_name=>'From valid email'
,p_static_id=>'from-valid-email'
,p_validation_sequence=>50
,p_validation=>'P15_FROM'
,p_validation2=>'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>'Invalid Email format for From.'
,p_validation_condition=>'P15_FROM'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_when_button_pressed=>wwv_flow_imp.id(8026948728617580796)
,p_associated_item=>wwv_flow_imp.id(7420067199052402725)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(7420095727411458167)
,p_validation_name=>'P15_FROM not null'
,p_static_id=>'p15-from-not-null'
,p_validation_sequence=>20
,p_validation=>'P15_FROM'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'From must be specified.'
,p_when_button_pressed=>wwv_flow_imp.id(8026948728617580796)
,p_associated_item=>wwv_flow_imp.id(7420067199052402725)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8026947529525571553)
,p_validation_name=>'P15_GROUP_ID  or TO not null'
,p_static_id=>'p15-group-id-or-to-not-null'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P15_GROUP_ID is not null or ',
':P15_TO is not null'))
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Either a group must be selected or ''To'' must be specified.'
,p_when_button_pressed=>wwv_flow_imp.id(8026948728617580796)
,p_associated_item=>wwv_flow_imp.id(8026930742975471442)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8026948249957577482)
,p_validation_name=>'P15_MSG_BODY must be specified'
,p_static_id=>'p15-msg-body-must-be-specified'
,p_validation_sequence=>40
,p_validation=>'P15_MSG_BODY'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Message Body must be specified.'
,p_when_button_pressed=>wwv_flow_imp.id(8026948728617580796)
,p_associated_item=>wwv_flow_imp.id(8026934439558498800)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8026947938529574208)
,p_validation_name=>'P15_SUBJECT not null'
,p_static_id=>'p15-subject-not-null'
,p_validation_sequence=>30
,p_validation=>'P15_SUBJECT'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Subject must be specified.'
,p_when_button_pressed=>wwv_flow_imp.id(8026948728617580796)
,p_associated_item=>wwv_flow_imp.id(8026931127522476379)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(2435179734643421825)
,p_name=>'New'
,p_static_id=>'new'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P15_GROUP_ID'
,p_condition_element=>'P15_GROUP_ID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2435180027961421827)
,p_event_id=>wwv_flow_imp.id(2435179734643421825)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(2435179722711421824)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(2435179891350421826)
,p_event_id=>wwv_flow_imp.id(2435179734643421825)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(2435179722711421824)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8033467743748686447)
,p_name=>'save group id'
,p_static_id=>'save-group-id'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P15_GROUP_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8033468044853686491)
,p_event_id=>wwv_flow_imp.id(8033467743748686447)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-execute-plsql-code'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'items_to_submit', 'P15_GROUP_ID',
  'language', 'PLSQL',
  'plsql_code', 'null;',
  'show_processing', 'N')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7434994224066184695)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_RESET_PAGINATION'
,p_process_name=>'Reset Pagination'
,p_static_id=>'reset-pagination'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'target', 'THIS_PAGE')).to_clob
,p_process_when=>'Go,CLEAR'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>7414917659236224616
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8026952236760620921)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Send Email'
,p_static_id=>'send-email'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_app_name  varchar2(255)  default ''Team Calendar'';',
'   l_body      clob;',
'   l_email_to  varchar2(32000);',
'   crlf        varchar2(2) := chr(10) || chr(13); ',
'begin',
'',
'   for c1 in (',
'      select logo, logo_type',
'        from apex_applications',
'       where application_id = :APP_ID )',
'   loop',
'      if c1.logo_type = ''Text Logo'' then',
'         l_app_name := replace(substr(c1.logo,6),''&''||''APPLICATION_TITLE.'',:APPLICATION_TITLE);',
'         if lower(substr(l_app_name,1,4)) = ''<img'' then',
'            l_app_name := substr(l_app_name,instr(l_app_name,''>'')+1);',
'         end if;',
'      end if;',
'   end loop;',
'',
'   l_body := ''<div style="margin: 10px">',
'    <h1 style="margin: 0 0 5px 0; padding: 10px; font: bold 18px/32px Arial, sans-serif; color: #EA0000; background-color: #F0F0F0; border-bottom: 2px solid #E6E6E6">''||l_app_name||''</h1>',
'    <p style="margin: 15px 0; font: normal 13px/18px Arial, sans-serif;padding: 0 10px">''||crlf;',
'',
'   dbms_lob.append(l_body, apex_escape.html(:P15_MSG_BODY)||''</p>''||crlf);',
'',
'   dbms_lob.append(l_body,''<p style="margin: 15px 0; font: normal 13px/18px Arial, sans-serif;padding: 0 10px">''||crlf);',
'',
'   dbms_lob.append(l_body,''Please note that all dates and times are shown in ''||:F855_TIMEZONE||',
'                   '' time.  You can access these events in the <a href="''||:HOST_URL||''f?p=''||:APP_ID||'':1">''||l_app_name||''</a> application.</p>''||crlf);',
'',
'   dbms_lob.append(l_body,'' <table style="width: 100%;" cellspacing="0" cellpadding="0" border="0">',
'        <tr>',
'            <th style="background-color: #CCC; color: #333; font: bold 11px/18px Arial, sans-serif; text-align: left; width: 10%; padding: 5px 10px">Event Date</th>',
'            <th style="background-color: #CCC; color: #333; font: bold 11px/18px Arial, sans-serif; text-align: left; width: 17%; padding: 5px 10px">Time</th>',
'            <th style="background-color: #CCC; color: #333; font: bold 11px/18px Arial, sans-serif; text-align: left; width: 28%; padding: 5px 10px">Event Name</th>',
'            <th style="background-color: #CCC; color: #333; font: bold 11px/18px Arial, sans-serif; text-align: left; width: 10%; padding: 5px 10px">Type</th>',
'            <th style="background-color: #CCC; color: #333; font: bold 11px/18px Arial, sans-serif; text-align: left; width: 35%; padding: 5px 10px">Description</th>',
'        </tr>''||crlf);',
'',
'   for c1 in (',
'      select to_char(e.EVENT_DATE_TIME,:APP_DATE_FORMAT) event_date,',
'             case when to_char(e.EVENT_DATE_TIME,''MI'') = ''00'' ',
'                  then ltrim(to_char(e.EVENT_DATE_TIME,''HHam''),''0'')',
'                 else ltrim(to_char(e.EVENT_DATE_TIME,''HH:MIam''),''0'')',
'                 end || '' - '' ||',
'            case when to_char(to_date(to_char(EVENT_DATE_TIME,''DD-MON-RR''||''HH:MIam''),',
'                         ''DD-MON-RR''||''HH:MIam'')+(e.duration/24),''MI'') = ''00''',
'                 then ltrim(to_char(to_date(to_char(EVENT_DATE_TIME,''DD-MON-RR''||''HH:MIam''),',
'                         ''DD-MON-RR''||''HH:MIam'')+(e.duration/24),''HHam''),''0'')',
'                 else ltrim(to_char(to_date(to_char(EVENT_DATE_TIME,''DD-MON-RR''||''HH:MIam''),',
'                         ''DD-MON-RR''||''HH:MIam'')+(e.duration/24),''HH:MIam''),''0'')',
'                 end || '' ('' ||',
'            case when e.duration = 0  then ''0 mins''',
'                 when e.duration = .5 then ''30 mins''',
'                 when e.duration = 1 then ''1 hr''',
'                 when e.duration > 1 then to_char(e.duration) || '' hrs''',
'                 end || '')'' event_time,',
'             case when et.display_color is not null',
'                  then ''<span style="color:'' || apex_escape.html(et.display_color) || ''; white-space:nowrap; font-weight:bold;">'' || apex_escape.html(e.event_name) || ''</span>''',
'                  else ''<span style="white-space:nowrap; font-weight:bold;">'' || apex_escape.html(e.event_name) || ''</span>''',
'                  end event_name,',
'             nvl(apex_escape.html(et.type_name),''&nbsp;'') event_type,',
'             nvl(apex_escape.html(e.EVENT_DESC),''&nbsp;'') event_desc',
'        from EBA_CA_EVENTS e,',
'             EBA_CA_EVENT_TYPES et',
'       where e.type_id = et.type_id (+)',
'         and (:P15_EVENT_TYPE is null or e.type_id = :P15_EVENT_TYPE)',
'         and (:P15_START_DATE is null or ',
'              trunc(to_date(to_char(e.event_date_time,:APP_DATE_FORMAT),',
'                    ''&APP_DATE_FORMAT.'')) >= to_date(:P15_START_DATE,:APP_DATE_FORMAT) )',
'         and (:P15_END_DATE is null or ',
'              trunc(to_date(to_char(e.event_date_time,''&APP_DATE_FORMAT.''),',
'                    ''&APP_DATE_FORMAT.'')) <= to_date(:P15_END_DATE,:APP_DATE_FORMAT) )',
'         and (:P15_TIMEFRAME is null or',
'              (trunc(to_date(to_char(e.event_date_time,''DD-MON-RRRR''),''DD-MON-RRRR''))',
'                  >= (select start_date from EBA_ca_timeframes',
'                       where :P15_TIMEFRAME = tf_id) and',
'               trunc(to_date(to_char(e.event_date_time,''DD-MON-RRRR''),''DD-MON-RRRR''))',
'                  <= (select end_date from EBA_ca_timeframes',
'                       where :P15_TIMEFRAME = tf_id))) ',
'        order by e.event_date_time )',
'   loop',
'      dbms_lob.append(l_body,''<tr style="font: normal 12px/16px Arial, sans-serif; vertical-align: top;">'');',
'      dbms_lob.append(l_body,''<td style="padding: 5px 10px; background-color: #F4F4F4; border-bottom: 1px solid #E0E0E0">''||c1.event_date||''</td>'');',
'      dbms_lob.append(l_body,''<td style="padding: 5px 10px; background-color: #F4F4F4; border-bottom: 1px solid #E0E0E0">''||c1.event_time||''</td>'');',
'      dbms_lob.append(l_body,''<td style="padding: 5px 10px; background-color: #F4F4F4; border-bottom: 1px solid #E0E0E0">''||c1.event_name||''</td>'');',
'      dbms_lob.append(l_body,''<td style="padding: 5px 10px; background-color: #F4F4F4; border-bottom: 1px solid #E0E0E0">''||c1.event_type||''</td>'');',
'      dbms_lob.append(l_body,''<td style="padding: 5px 10px; background-color: #F4F4F4; border-bottom: 1px solid #E0E0E0">''||c1.event_desc||''</td>'');',
'      dbms_lob.append(l_body,''</tr>''||crlf);',
'   end loop;',
'',
'   dbms_lob.append(l_body,''</table></div>''||crlf);',
'',
'   for c1 in (',
'      select email_address',
'        from EBA_ca_email_group_mbrs',
'       where group_id = :P15_GROUP_ID )',
'   loop',
'      l_email_to := l_email_to || c1.email_address || '','';',
'   end loop;',
'',
'   if :P15_TO is not null then ',
'      l_email_to := l_email_to || :P15_TO || '','';',
'   end if;',
'',
'   l_email_to := substr(l_email_to,1,length(l_email_to)-1);',
'',
'   apex_mail.send (',
'      p_to        => l_email_to,',
'      p_from      => :P15_FROM,',
'      p_replyto   => nvl(replace(replace(eba_ca_fw.get_preference_value(''NOTIFICATION_EMAIL_REPLY_TO''),''N/A'',null),''Preference does not exist'',null), :P15_FROM),',
'      p_cc        => :P15_FROM,',
'      p_body      => to_clob('' ''),',
'      p_body_html => l_body,',
'      p_subj      => apex_escape.html(:P15_SUBJECT));',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Email(s) failed to be sent.'
,p_process_when_button_id=>wwv_flow_imp.id(8026948728617580796)
,p_process_success_message=>'Email(s) sent.'
,p_internal_uid=>8006875671930660842
);
wwv_flow_imp.component_end;
end;
/
