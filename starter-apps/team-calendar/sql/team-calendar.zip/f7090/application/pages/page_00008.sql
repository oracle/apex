prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>8
,p_name=>'Event Type Details'
,p_alias=>'EVENT-TYPE-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Event Type Details'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(8940478416777379715)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_step_template=>2101883943284197310
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(3255013570915135948)
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1716273466122411863)
,p_plug_name=>'Buttons'
,p_static_id=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2127905476394690047
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8940463506430355023)
,p_plug_name=>'Event Type Details'
,p_static_id=>'event-type-details'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3294469160074978201)
,p_plug_name=>'hidden'
,p_static_id=>'hidden'
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3256212164157813873)
,p_plug_name=>'Recommended Colors'
,p_static_id=>'recommended-colors'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>2665811232373458102
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br />Blue',
'<br />Border:     #C1CFE6',
'<br />Background: #E6ECF3',
'<br />',
'<br />Red',
'<br />Border:     #F1B8BA',
'<br />Background: #FAE1E2',
'<br />',
'<br />Yellow',
'<br />Border:     #E7EDB9',
'<br />Background: #F5F8E2',
'<br />',
'<br />Green',
'<br />Border:     #C2E1C8',
'<br />Background: #E5F3E8',
'<br />',
'<br />Teal',
'<br />Border:     #B1ECEB',
'<br />Background: #DEF7F7',
'<br />',
'<br />Purple',
'<br />Border:     #C0B7EC',
'<br />Background: #E4E1F7'))
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8940463609932355025)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1716273466122411863)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8940463922232355025)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(1716273466122411863)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Event Type'
,p_button_position=>'NEXT'
,p_button_condition=>'P8_TYPE_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8940463705110355025)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1716273466122411863)
,p_button_name=>'DELETE'
,p_static_id=>'delete'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--danger'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Delete'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_condition=>'P8_TYPE_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8940463813768355025)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1716273466122411863)
,p_button_name=>'SAVE'
,p_static_id=>'save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P8_TYPE_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3256211768181805559)
,p_name=>'P8_BORDER_COLOR'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(3294469160074978201)
,p_use_cache_before_default=>'NO'
,p_source=>'BORDER_COLOR'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_help_text=>'Events are typically displayed in black.  You can override that color by assigning a display color by event type.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3257512976689073802)
,p_name=>'P8_COLOR_PREF_ID'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(8940463506430355023)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Color Preference'
,p_source=>'COLOR_PREF_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'COLOR PREFERENCE'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Color Preference -'
,p_cHeight=>1
,p_field_template=>1610598484065263269
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8940589219996863149)
,p_name=>'P8_DISPLAY_COLOR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(3294469160074978201)
,p_use_cache_before_default=>'NO'
,p_source=>'DISPLAY_COLOR'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_help_text=>'Events are typically displayed in black.  You can override that color by assigning a display color by event type.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1558786078425352367)
,p_name=>'P8_INTERNAL_YN'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(8940463506430355023)
,p_use_cache_before_default=>'NO'
,p_prompt=>'External / Internal'
,p_source=>'INTERNAL_YN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:External;N,Internal Only;Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>1610598484065263269
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_required_patch=>wwv_flow_imp.id(1631739938122003976)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8940464107766355028)
,p_name=>'P8_TYPE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8940463506430355023)
,p_use_cache_before_default=>'NO'
,p_source=>'TYPE_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8940464202205355030)
,p_name=>'P8_TYPE_NAME'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(8940463506430355023)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Event Type'
,p_source=>'TYPE_NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>48
,p_cMaxlength=>60
,p_field_template=>1610598484065263269
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8034484455278222316)
,p_validation_name=>'no related events before delete'
,p_static_id=>'no-related-events-before-delete'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from EBA_ca_events',
' where :P8_TYPE_ID = type_id'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Cannot delete Event Type - it is related to Events.'
,p_when_button_pressed=>wwv_flow_imp.id(8940463705110355025)
,p_associated_item=>wwv_flow_imp.id(8940464202205355030)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8027008046550030589)
,p_validation_name=>'P8_EVENT_TYPE unique'
,p_static_id=>'p8-event-type-unique'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from EBA_ca_event_types',
' where lower(:P8_TYPE_NAME) = lower(type_name)',
'   and (:P8_TYPE_ID != type_id or :P8_TYPE_ID is null)'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Type already exists.'
,p_associated_item=>wwv_flow_imp.id(8940464202205355030)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1716273556814411864)
,p_name=>'Cancel Dialog'
,p_static_id=>'cancel-dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8940463609932355025)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1716273660175411865)
,p_event_id=>wwv_flow_imp.id(1716273556814411864)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-dialog-cancel'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1716273795319411866)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_static_id=>'close-dialog'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_success_messages', 'N')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>1696197230489451787
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8940465396722355032)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from EBA_CA_EVENT_TYPES'
,p_static_id=>'fetch-row-from-eba-ca-event-types'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'primary_key_column', 'TYPE_ID',
  'primary_key_item', 'P8_TYPE_ID',
  'table_name', 'EBA_CA_EVENT_TYPES')).to_clob
,p_process_error_message=>'Unable to fetch row.'
,p_internal_uid=>8920388831892394953
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8940465497990355033)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of EBA_CA_EVENT_TYPES'
,p_static_id=>'process-row-of-eba-ca-event-types'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'lock_row', 'Y',
  'primary_key_column', 'TYPE_ID',
  'primary_key_item', 'P8_TYPE_ID',
  'supported_operations', 'I:U:D',
  'table_name', 'EBA_CA_EVENT_TYPES')).to_clob
,p_process_error_message=>'Unable to process row of table EBA_CA_EVENT_TYPES.'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>8920388933160394954
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3294470860515035104)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set colors'
,p_static_id=>'set-colors'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'select ',
'   BG_COLOR,',
'   TEXT_COLOR',
'from EBA_CA_COLOR_PREFS',
'where id = :P8_COLOR_PREF_ID) loop',
':P8_DISPLAY_COLOR := c1.TEXT_COLOR;',
':P8_BORDER_COLOR := c1.BG_COLOR;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>3274394295685075025
);
wwv_flow_imp.component_end;
end;
/
