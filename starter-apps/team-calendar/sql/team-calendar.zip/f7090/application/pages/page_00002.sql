prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Search'
,p_alias=>'SEARCH'
,p_step_title=>'&APPLICATION_TITLE. - Search'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(8940477613660378872)
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'By default this page shows all upcoming events. From this page you can edit any existing event by clicking the <strong>Edit</strong> icon (pencil) next to the event. Click the <strong>Add Event</strong> button to add a new event. Click the <strong>De'
||'lete Multiple Events</strong> button to delete multiple events.'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1776493005023877121)
,p_plug_name=>'breadcrumbs'
,p_static_id=>'breadcrumbs'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--showBreadcrumb:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(8940448701738354891)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8412760768882197703)
,p_plug_name=>'Events'
,p_static_id=>'events'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton'
,p_plug_template=>2102002977963900996
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.EVENT_ID',
',      e.event_name',
',      case when et.display_color is not null then ',
'         ''<span style="white-space:nowrap;">'' ',
'         || apex_escape.html(et.type_name || decode(:EXTERNAL_INTERNAL_BO, ''Include'', decode(internal_yn, ''Y'', '' (Internal Only)'', null), null)) || ''</span>''',
'       else ',
'         ''<span style="white-space:nowrap;">'' ',
'         || apex_escape.html(et.type_name || decode(:EXTERNAL_INTERNAL_BO, ''Include'', decode(internal_yn, ''Y'', '' (Internal Only)'', null), null)) || ''</span>''',
'       end event_type',
',      e.EVENT_DATE_TIME event_date',
',      case when e.display_time = ''Y'' then ',
'          e.EVENT_DATE_TIME ',
'       else ',
'         null',
'       end event_start_time',
',      e.DURATION',
',      case when e.duration = 0  then ''0 mins''',
'            when e.duration = .25 then ''15 mins''',
'            when e.duration = .5 then ''30 mins''',
'            when e.duration = .75 then ''45 mins''',
'            when e.duration = 1 then ''1 hr''',
'            when e.duration > 1 then to_char(trunc(e.duration)) || '' hrs''',
'              || case when e.duration - trunc(e.duration) = 0  then ''''',
'                      when e.duration - trunc(e.duration) = .25 then '' 15 mins''',
'                      when e.duration - trunc(e.duration) = .5 then '' 30 mins''',
'                      when e.duration - trunc(e.duration) = .75 then '' 45 mins''',
'                 end',
'            end disp_duration',
',      e.EVENT_DESC',
',      e.CONTACT_PERSON',
',      e.location',
',      case when e.link_url_1 is not null or',
'                 e.link_url_2 is not null or',
'                 e.link_url_3 is not null ',
'            then ''Y''',
'            else null',
'            end links',
',      decode(decode(e.series_id, null, null, ''Y''),''Y'',''Yes'',''N'',''No'',decode(e.series_id, null, null, ''Y'')) recur_flag',
',      eba_ca_api.get_timeframes(e.event_id) timeframes',
',      e.CREATED_ON',
',      lower(e.CREATED_BY) created_by',
',      e.LAST_UPDATED_ON',
',      lower(e.LAST_UPDATED_BY) last_updated_by',
',      e.tags',
',      decode(e.calendar_id, null, ''Default''',
'              , c.short_name || '' - '' || c.calendar_name ',
'                || decode(c.public_view_yn, ''Y'', null, '' (Private)'')',
'             ) calendar',
'from eba_ca_events e',
',    eba_ca_event_types et',
',    eba_ca_calendars c',
'where e.type_id = et.type_id',
'and   e.calendar_id = c.calendar_id (+)',
'and   (   :MULTIPLE_CAL_BO = ''Exclude'' ',
'       or (   e.calendar_id is null',
'           or (   c.public_view_yn = ''Y''',
'               or exists (select ''x''',
'                          from eba_ca_users u',
'                          where u.username = :APP_USER',
'                          and   (   instr(u.restricted_to, c.calendar_id) > 0',
'                                 or (access_level_id = 3 and restricted_to is null)',
'                                )',
'                         )',
'              )',
'          )',
'      )',
'and   (   :EXTERNAL_INTERNAL_BO = ''Exclude''',
'       or (   nvl(et.internal_yn, ''N'') = ''N''',
'           or upper(:APP_USER) in (select upper(username) from eba_ca_users)',
'          )',
'      )',
'and   (   :P2_TIMEFRAME is null ',
'       or (    trunc(to_date(to_char(e.event_date_time,''DD-MON-RRRR''),''DD-MON-RRRR''))',
'                 >= (select start_date ',
'                     from EBA_ca_timeframes',
'                     where :P2_TIMEFRAME = tf_id',
'                    ) ',
'           and trunc(to_date(to_char(e.event_date_time,''DD-MON-RRRR''),''DD-MON-RRRR''))',
'                 <= (select end_date ',
'                     from EBA_ca_timeframes',
'                     where :P2_TIMEFRAME = tf_id',
'                    )',
'          )',
'      )'))
,p_plug_source_type=>'NATIVE_IR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(8412760967871197705)
,p_max_row_count=>'10000'
,p_max_row_count_message=>'This query returns more than 10,000 rows, please filter your data to ensure complete results.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:3:P3_EVENT_ID,P3_PREV_PAGE:#EVENT_ID#,2'
,p_detail_link_text=>'<span class="fa fa-edit" aria-hidden="true"></span>'
,p_detail_link_attr=>'aria-label="Edit #EVENT_NAME#"'
,p_internal_uid=>7750611519607594047
);
wwv_flow_imp_page.create_worksheet_col_group(
 p_id=>wwv_flow_imp.id(8412761069259197708)
,p_name=>'Audit Info'
,p_static_id=>'audit-info'
,p_display_sequence=>20
);
wwv_flow_imp_page.create_worksheet_col_group(
 p_id=>wwv_flow_imp.id(8412761162679197714)
,p_name=>'Details'
,p_static_id=>'details'
,p_display_sequence=>10
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1865442463362994137)
,p_db_column_name=>'CALENDAR'
,p_display_order=>41
,p_column_identifier=>'AL'
,p_column_label=>'Calendar'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_required_patch=>wwv_flow_imp.id(1857191596806388379)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8412761553558197720)
,p_db_column_name=>'CONTACT_PERSON'
,p_display_order=>9
,p_group_id=>wwv_flow_imp.id(8412761162679197714)
,p_column_identifier=>'I'
,p_column_label=>'Contact Person'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_help_text=>'Person to contact for more information.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8412761645356197720)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>11
,p_group_id=>wwv_flow_imp.id(8412761069259197708)
,p_column_identifier=>'K'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_help_text=>'The user who created the record.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8039414834924734903)
,p_db_column_name=>'CREATED_ON'
,p_display_order=>28
,p_group_id=>wwv_flow_imp.id(8412761069259197708)
,p_column_identifier=>'AH'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8034502351732300646)
,p_db_column_name=>'DISP_DURATION'
,p_display_order=>24
,p_group_id=>wwv_flow_imp.id(8412761162679197714)
,p_column_identifier=>'AD'
,p_column_label=>'Duration'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3303922468156327756)
,p_db_column_name=>'DURATION'
,p_display_order=>31
,p_column_identifier=>'AK'
,p_column_label=>'Duration'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8039414549696734902)
,p_db_column_name=>'EVENT_DATE'
,p_display_order=>25
,p_group_id=>wwv_flow_imp.id(8412761162679197714)
,p_column_identifier=>'AE'
,p_column_label=>'Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_DATE_FORMAT.'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8412761473123197720)
,p_db_column_name=>'EVENT_DESC'
,p_display_order=>8
,p_group_id=>wwv_flow_imp.id(8412761162679197714)
,p_column_identifier=>'H'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_help_text=>'Description of the event.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8412761275128197715)
,p_db_column_name=>'EVENT_ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Event ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8412761373616197719)
,p_db_column_name=>'EVENT_NAME'
,p_display_order=>3
,p_group_id=>wwv_flow_imp.id(8412761162679197714)
,p_column_identifier=>'B'
,p_column_label=>'Event Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_help_text=>'Name of the event.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8039414640484734902)
,p_db_column_name=>'EVENT_START_TIME'
,p_display_order=>26
,p_group_id=>wwv_flow_imp.id(8412761162679197714)
,p_column_identifier=>'AF'
,p_column_label=>'Start Time'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'&APP_TIME_FORMAT.'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8412761857443197720)
,p_db_column_name=>'EVENT_TYPE'
,p_display_order=>2
,p_group_id=>wwv_flow_imp.id(8412761162679197714)
,p_column_identifier=>'N'
,p_column_label=>'Event Type'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8412761773162197720)
,p_db_column_name=>'LAST_UPDATED_BY'
,p_display_order=>12
,p_group_id=>wwv_flow_imp.id(8412761069259197708)
,p_column_identifier=>'M'
,p_column_label=>'Last Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_help_text=>'The user who last updated the record.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8039414933679734903)
,p_db_column_name=>'LAST_UPDATED_ON'
,p_display_order=>29
,p_group_id=>wwv_flow_imp.id(8412761069259197708)
,p_column_identifier=>'AI'
,p_column_label=>'Last Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7969272223281520337)
,p_db_column_name=>'LINKS'
,p_display_order=>21
,p_group_id=>wwv_flow_imp.id(8412761162679197714)
,p_column_identifier=>'AA'
,p_column_label=>'Links'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8521049852852371547)
,p_db_column_name=>'LOCATION'
,p_display_order=>18
,p_group_id=>wwv_flow_imp.id(8412761162679197714)
,p_column_identifier=>'X'
,p_column_label=>'Location'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8412761965263197720)
,p_db_column_name=>'RECUR_FLAG'
,p_display_order=>10
,p_group_id=>wwv_flow_imp.id(8412761162679197714)
,p_column_identifier=>'R'
,p_column_label=>'Recurring'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3256434476293719278)
,p_db_column_name=>'TAGS'
,p_display_order=>30
,p_column_identifier=>'AJ'
,p_column_label=>'Tags'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8039414740022734902)
,p_db_column_name=>'TIMEFRAMES'
,p_display_order=>27
,p_group_id=>wwv_flow_imp.id(8412761162679197714)
,p_column_identifier=>'AG'
,p_column_label=>'Timeframes'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(8039419943163761373)
,p_rpt_show_filter_lov=>'2'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(8412762576191197721)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4487536'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'EVENT_NAME:EVENT_TYPE:CALENDAR:EVENT_DATE:EVENT_START_TIME:DISP_DURATION:CONTACT_PERSON:LOCATION:TAGS:RECUR_FLAG'
,p_sort_column_1=>'EVENT_DATE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'EVENT_START_TIME'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'EVENT_NAME'
,p_sort_direction_3=>'ASC'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(1877460710908707364)
,p_report_id=>wwv_flow_imp.id(8412762576191197721)
,p_static_id=>'ir-condition'
,p_name=>'Only future events'
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_expr_type=>'ROW'
,p_expr=>'  AE >= decode(AK,''All Day'', trunc(sysdate), sysdate - (AK/24))'
,p_condition_sql=>'  "EVENT_DATE" >= decode("DURATION",''All Day'', trunc(sysdate), sysdate - ("DURATION"/24))'
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3257766168468296651)
,p_plug_name=>'hidden Items'
,p_static_id=>'hidden-items'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1227693663653586864)
,p_name=>'Notifications'
,p_static_id=>'notifications'
,p_display_sequence=>10
,p_component_template_options=>'#DEFAULT#'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id, ',
'       nvl(lower(NOTIFICATION_TYPE),''yellow'') as ALERT_TYPE,',
'       NOTIFICATION_NAME alert_title,',
'       NOTIFICATION_DESCRIPTION alert_desc,',
'       '''' alert_action',
'  from EBA_CA_NOTIFICATIONS',
' where (DISPLAY_FROM is null or DISPLAY_FROM <= current_date) and',
'       (DISPLAY_UNTIL is null or DISPLAY_UNTIL >= current_date)',
' order by nvl(DISPLAY_SEQUENCE,0),NOTIFICATION_NAME'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>28842.25179278697457413
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1934417930912477329)
,p_query_column_id=>5
,p_column_alias=>'ALERT_ACTION'
,p_column_display_sequence=>5
,p_column_heading=>'Alert Action'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1934417475160477329)
,p_query_column_id=>4
,p_column_alias=>'ALERT_DESC'
,p_column_display_sequence=>4
,p_column_heading=>'Alert Desc'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1934417045477477328)
,p_query_column_id=>3
,p_column_alias=>'ALERT_TITLE'
,p_column_display_sequence=>3
,p_column_heading=>'Alert Title'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1934416666921477328)
,p_query_column_id=>2
,p_column_alias=>'ALERT_TYPE'
,p_column_display_sequence=>2
,p_column_heading=>'Alert Type'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1227693850015586940)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3257251361083872980)
,p_plug_name=>'Timezone'
,p_static_id=>'timezone'
,p_region_css_classes=>'infoTextRegion'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' "TIMEZONE"',
'',
' '))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'Y',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3256346375125659151)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1776493005023877121)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>2084305881903810008
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Event'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:10::'
,p_icon_css_classes=>'fa-chevron-right'
,p_security_scheme=>wwv_flow_imp.id(3255014080085135948)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3256346748590660953)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1776493005023877121)
,p_button_name=>'DELETE_MULTIPLE'
,p_static_id=>'delete-multiple'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--danger:t-Button--simple:t-Button--iconRight:t-Button--pillStart'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Delete Multiple Events'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:13::'
,p_button_cattributes=>'style="font-weight:bold"'
,p_security_scheme=>wwv_flow_imp.id(3255014080085135948)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(860140470208954424)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8412760768882197703)
,p_button_name=>'RESET'
,p_static_id=>'reset'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&SESSION.::&DEBUG.:RP,&APP_PAGE_ID.,RIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(3256351165690675321)
,p_computation_sequence=>10
,p_computation_item=>'LAST_VIEW'
,p_static_id=>'last-view'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'2'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1717272484378153743)
,p_name=>'Refresh Calendar'
,p_static_id=>'refresh-calendar'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1717272899034153749)
,p_event_id=>wwv_flow_imp.id(1717272484378153743)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', 'apex.message.showPageSuccess(''Action Processed.'');')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1717273409736153753)
,p_event_id=>wwv_flow_imp.id(1717272484378153743)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8412760768882197703)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
