prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Filter Options'
,p_alias=>'FILTER-OPTIONS'
,p_page_mode=>'MODAL'
,p_step_title=>'Filter Options'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2101883943284197310
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17783382028188088578)
,p_plug_name=>'Buttons'
,p_static_id=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2127905476394690047
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17438876147926777922)
,p_plug_name=>'Filter Options'
,p_static_id=>'filter-options'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader js-removeLandmark:t-Region--noBorder:t-Region--hiddenOverflow'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1857177299149373440)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(17783382028188088578)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1884136675908852327)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(17783382028188088578)
,p_button_name=>'RESET'
,p_static_id=>'reset'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Reset All'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1857177579256373442)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(17783382028188088578)
,p_button_name=>'SUBMIT'
,p_static_id=>'submit'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Set'
,p_button_position=>'CREATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1857178705900373463)
,p_name=>'P5_CALENDARS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(17438876147926777922)
,p_prompt=>'Calendars'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'CALENDARS WITH DEFAULT'
,p_grid_label_column_span=>0
,p_field_template=>2042262243893469891
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_required_patch=>wwv_flow_imp.id(1857191596806388379)
,p_help_text=>'Use to restrict to events from one or more calendars.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1857178274225373455)
,p_name=>'P5_CAL_ALL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(17438876147926777922)
,p_prompt=>'Calendars'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC2:All;0'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_required_patch=>wwv_flow_imp.id(1857191596806388379)
,p_help_text=>'Use to limit the results to events from the Calendars selected.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1857287413766981782)
,p_name=>'P5_CONTACT_EMAIL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(17438876147926777922)
,p_prompt=>'Contact Email'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'CONTACTS'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''x'' from',
'eba_ca_events where contact_email is not null;'))
,p_display_when_type=>'EXISTS'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_security_scheme=>wwv_flow_imp.id(3255014080085135948)
,p_required_patch=>wwv_flow_imp.id(1631739938122003976)
,p_help_text=>'Use to limit the results to events where the Contact Email matches the email listed in the Access Control List (under Administration).'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1857179079469373464)
,p_name=>'P5_ET_ALL'
,p_item_sequence=>7
,p_item_plug_id=>wwv_flow_imp.id(17438876147926777922)
,p_prompt=>'Event Types'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC2:All;0'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_help_text=>'Use to limit the results to events with the Event Types selected.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1857179466286373464)
,p_name=>'P5_EVENT_TYPES'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(17438876147926777922)
,p_prompt=>'Event Types'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'EVENT TYPES FOR MAIN CAL'
,p_grid_label_column_span=>0
,p_field_template=>2042262243893469891
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1857185503157373503)
,p_name=>'close'
,p_static_id=>'close'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1857177299149373440)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1857185936489373504)
,p_event_id=>wwv_flow_imp.id(1857185503157373503)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-dialog-cancel'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1857182776940373501)
,p_name=>'when cal other than all'
,p_static_id=>'when-cal-other-than-all'
,p_event_sequence=>7
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_CALENDARS'
,p_condition_element=>'P5_CALENDARS'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1857183236202373501)
,p_event_id=>wwv_flow_imp.id(1857182776940373501)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-set-value'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_CAL_ALL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'suppress_change_event', 'N',
  'type', 'STATIC_ASSIGNMENT')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1857181908265373497)
,p_name=>'when calendars All'
,p_static_id=>'when-calendars-all'
,p_event_sequence=>5
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_CAL_ALL'
,p_condition_element=>'P5_CAL_ALL'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1857182369033373500)
,p_event_id=>wwv_flow_imp.id(1857181908265373497)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-set-value'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_CALENDARS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'suppress_change_event', 'N',
  'type', 'STATIC_ASSIGNMENT')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1857184544602373502)
,p_name=>'when event type other than all'
,p_static_id=>'when-event-type-other-than-all'
,p_event_sequence=>12
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_EVENT_TYPES'
,p_condition_element=>'P5_EVENT_TYPES'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1857185115213373502)
,p_event_id=>wwv_flow_imp.id(1857184544602373502)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-set-value'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_ET_ALL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'suppress_change_event', 'N',
  'type', 'STATIC_ASSIGNMENT')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1857183638634373501)
,p_name=>'when event_types All'
,p_static_id=>'when-event-types-all'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_ET_ALL'
,p_condition_element=>'P5_ET_ALL'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1857184197434373502)
,p_event_id=>wwv_flow_imp.id(1857183638634373501)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-set-value'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_EVENT_TYPES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'suppress_change_event', 'N',
  'type', 'STATIC_ASSIGNMENT')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1857180671033373495)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_static_id=>'close-dialog'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_success_messages', 'N')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>1837104106203413416
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1857181039813373495)
,p_process_sequence=>22
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'load cals'
,p_static_id=>'load-cals'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_pref varchar2(4000);',
'begin',
'',
'l_pref := apex_util.get_preference (',
'              p_preference => ''CALENDARS_FILTER'',',
'              p_user       => :APP_USER );',
'',
'if l_pref is null or l_pref = ''0'' then',
'   :P5_CAL_ALL := ''0'';',
'else',
'   :P5_CALENDARS := l_pref;',
'end if;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>1837104474983413416
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(807016235260479450)
,p_process_sequence=>32
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'load contact_email'
,p_static_id=>'load-contact-email'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_pref varchar2(4000);',
'begin',
'',
'l_pref := apex_util.get_preference (',
'              p_preference => ''CONTACT_EMAIL'',',
'              p_user       => :APP_USER );',
'',
'if l_pref is null or l_pref = ''0'' then',
'   :P5_CONTACT_EMAIL := null;',
'else',
'   :P5_CONTACT_EMAIL := l_pref;',
'end if;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>786939670430519371
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1857181473695373496)
,p_process_sequence=>12
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'load event types'
,p_static_id=>'load-event-types'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_pref varchar2(4000);',
'begin',
'',
'l_pref := apex_util.get_preference (',
'              p_preference => ''EVENT_TYPES_FILTER'',',
'              p_user       => :APP_USER );',
'',
'if l_pref is null or l_pref = ''0'' then',
'   :P5_ET_ALL := ''0'';',
'else',
'   :P5_EVENT_TYPES := l_pref;',
'end if;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>1837104908865413417
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1884136821206852328)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Reset'
,p_static_id=>'reset'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P5_EVENT_TYPES := null;',
':P5_CALENDARS := null;',
':P5_CONTACT_EMAIL := null;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1884136675908852327)
,p_process_success_message=>'All filters reset'
,p_internal_uid=>1864060256376892249
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1857180239170373495)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set calendar pref'
,p_static_id=>'set-calendar-pref'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'APEX_UTIL.SET_PREFERENCE(        ',
'   p_preference => ''CALENDARS_FILTER'',',
'   p_value      => nvl(:P5_CALENDARS,''0''),      ',
'   p_user       => :APP_USER);',
'   ',
':CALENDARS_FILTER := nvl(:P5_CALENDARS,''0'');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>1837103674340413416
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1693193953546874166)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set contact email'
,p_static_id=>'set-contact-email'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'APEX_UTIL.SET_PREFERENCE(        ',
'   p_preference => ''CONTACT_EMAIL'',',
'   p_value      => nvl(:P5_CONTACT_EMAIL,''0''),      ',
'   p_user       => :APP_USER);',
'   ',
':CONTACT_EMAIL := :P5_CONTACT_EMAIL;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Filters failed to be set.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Filters set.'
,p_internal_uid=>1673117388716914087
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1857179864198373494)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'set event type pref'
,p_static_id=>'set-event-type-pref'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'APEX_UTIL.SET_PREFERENCE(        ',
'   p_preference => ''EVENT_TYPES_FILTER'',',
'   p_value      => nvl(:P5_EVENT_TYPES,''0''),      ',
'   p_user       => :APP_USER);',
'   ',
':EVENT_TYPES_FILTER := nvl(:P5_EVENT_TYPES,''0'');'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Filters failed to be set.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Filters set.'
,p_internal_uid=>1837103299368413415
);
wwv_flow_imp.component_end;
end;
/
