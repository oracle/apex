prompt --application/pages/page_00044
begin
--   Manifest
--     PAGE: 00044
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>44
,p_name=>'Calendar Details'
,p_alias=>'CALENDAR-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Calendar Details'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_step_template=>2101883943284197310
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(3255013570915135948)
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    This page allows app administrators to change attributes of a calendar. Click the <strong>Apply Changes</strong> button to save your changes. Click the <strong>Delete</strong> button to delete this calendar. Click the <strong>Cancel</strong> butt'
||'on to leave this page.',
'</p>'))
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17581170783487377642)
,p_plug_name=>'Buttons'
,p_static_id=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2127905476394690047
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17581168694623377640)
,p_plug_name=>'Calendar Details'
,p_static_id=>'calendar-details'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(17819121569764783703)
,p_name=>'Contributors'
,p_static_id=>'contributors'
,p_template=>4073835273271169698
,p_display_sequence=>50
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'t-Report--stretch:t-Report--altRowsDefault:t-Report--inline:t-Report--rowHighlightOff'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select username, ',
'       case when restricted_to is null then ''Unrestricted Contributor''',
'            else ''Restricted To set for this calendar'' end access_type,',
'       decode(access_level_id, 3, ''Administrator'', ''Contributor'') access_level',
'  from eba_ca_users',
' where access_level_id >= 2',
' and   (   instr('':''||restricted_to||'':'','':''||:P44_CALENDAR_ID||'':'') > 0',
'        or (    restricted_to is null ',
'            and access_level_id = 3',
'           )',
'       )',
' order by 1'))
,p_display_when_condition=>'P44_CALENDAR_ID'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'No users found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1865443333454994145)
,p_query_column_id=>3
,p_column_alias=>'ACCESS_LEVEL'
,p_column_display_sequence=>3
,p_column_heading=>'Access level'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1857215832859635687)
,p_query_column_id=>2
,p_column_alias=>'ACCESS_TYPE'
,p_column_display_sequence=>2
,p_column_heading=>'Access Type'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1857215394293635686)
,p_query_column_id=>1
,p_column_alias=>'USERNAME'
,p_column_display_sequence=>1
,p_column_heading=>'Username'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1865443391323994146)
,p_name=>'Readers (for this Private Calendar)'
,p_static_id=>'readers-for-this-private-calendar'
,p_template=>4073835273271169698
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'t-Report--stretch:t-Report--altRowsDefault:t-Report--inline:t-Report--rowHighlightOff'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select username, ',
'       ''Restricted To set for this calendar'' access_type',
'  from eba_ca_users',
' where access_level_id = 1',
' and   instr('':''||restricted_to||'':'','':''||:P44_CALENDAR_ID||'':'') > 0',
' order by 1'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P44_CALENDAR_ID is not null',
'and eba_ca_fw.get_preference_value(''ACCESS_CONTROL_ENABLED'') = ''Y'''))
,p_display_when_cond2=>'PLSQL'
,p_display_condition_type=>'EXPRESSION'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P44_PUBLIC_VIEW_YN'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_no_data_found=>'No users found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1865443555271994148)
,p_query_column_id=>2
,p_column_alias=>'ACCESS_TYPE'
,p_column_display_sequence=>2
,p_column_heading=>'Access Type'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1865443465148994147)
,p_query_column_id=>1
,p_column_alias=>'USERNAME'
,p_column_display_sequence=>1
,p_column_heading=>'Username'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1857213532063635683)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(17581170783487377642)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1857214311082635684)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(17581170783487377642)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Calendar'
,p_button_position=>'CREATE'
,p_button_condition=>'P44_CALENDAR_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1857214671254635684)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(17581170783487377642)
,p_button_name=>'DELETE'
,p_static_id=>'delete'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--danger'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Delete'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_condition=>'P44_CALENDAR_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1857213847960635683)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(17581170783487377642)
,p_button_name=>'SAVE'
,p_static_id=>'save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CREATE'
,p_button_condition=>'P44_CALENDAR_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1857209156641635678)
,p_name=>'P44_CALENDAR_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(17581168694623377640)
,p_use_cache_before_default=>'NO'
,p_source=>'CALENDAR_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1857210503797635681)
,p_name=>'P44_CALENDAR_NAME'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(17581168694623377640)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Name'
,p_source=>'CALENDAR_NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>48
,p_cMaxlength=>60
,p_field_template=>1610598484065263269
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Full name of Calendar.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1857212270284635682)
,p_name=>'P44_DESCRIPTION'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(17581168694623377640)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Description'
,p_source=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>1610598484065263269
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Description of the Calendar.  Only displayed on the Calendars report (to Adminstrators).'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1857211347470635681)
,p_name=>'P44_IS_ACTIVE_YN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(17581168694623377640)
,p_use_cache_before_default=>'NO'
,p_item_default=>'Y'
,p_prompt=>'Active?'
,p_source=>'IS_ACTIVE_YN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'If not active, events will still display but new events cannot be associated with the calendar.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1693193436724874161)
,p_name=>'P44_PUBLIC_VIEW_YN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(17581168694623377640)
,p_use_cache_before_default=>'NO'
,p_item_default=>'Y'
,p_prompt=>'Public Can View Events?'
,p_source=>'PUBLIC_VIEW_YN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_display_when=>'eba_ca_fw.get_preference_value(''ACCESS_CONTROL_ENABLED'') = ''Y'''
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>1610598304472262251
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Define whether all users can view the events on this calendar or only selected users.</p>',
'<p>If public can not view the events, you must update users who have rights to the calendar by going to Access Control List and selecting each users. On the User Details screen update Restricted To, selecting the calendars the user has access to.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1857209592697635678)
,p_name=>'P44_SHORT_NAME'
,p_is_required=>true
,p_item_sequence=>15
,p_item_plug_id=>wwv_flow_imp.id(17581168694623377640)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Short Name'
,p_source=>'SHORT_NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>10
,p_cMaxlength=>10
,p_field_template=>1610598484065263269
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Short name for Calendar.  Used as prefix when Events are displayed.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1857217266233635689)
,p_validation_name=>'no related events before delete'
,p_static_id=>'no-related-events-before-delete'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from EBA_ca_events',
' where :P44_CALENDAR_ID = calendar_id'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Cannot delete Calendar - it is related to Events.'
,p_when_button_pressed=>wwv_flow_imp.id(1857214671254635684)
,p_associated_item=>wwv_flow_imp.id(1857210503797635681)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1857216925904635689)
,p_validation_name=>'P44_CALENDAR_NAME unique'
,p_static_id=>'p44-calendar-name-unique'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_ca_calendars',
' where lower(:P44_CALENDAR_NAME) = lower(calendar_name)',
'   and (:P44_CALENDAR_ID != calendar_id or :P44_CALENDAR_ID is null)'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Calendar Name already exists.'
,p_associated_item=>wwv_flow_imp.id(1857210503797635681)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1857217656280635690)
,p_validation_name=>'P44_SHORT_NAME unique'
,p_static_id=>'p44-short-name-unique'
,p_validation_sequence=>15
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from eba_ca_calendars',
' where lower(:P44_SHORT_NAME) = lower(short_name)',
'   and (:P44_CALENDAR_ID != calendar_id or :P44_CALENDAR_ID is null)'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Short Name already exists.'
,p_associated_item=>wwv_flow_imp.id(1857209592697635678)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(128667756924925048)
,p_name=>'CNX'
,p_static_id=>'cnx'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1857213532063635683)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(128667908249925049)
,p_event_id=>wwv_flow_imp.id(128667756924925048)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-dialog-cancel'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1865443942898994152)
,p_name=>'Show Readers'
,p_static_id=>'show-readers'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P44_PUBLIC_VIEW_YN'
,p_condition_element=>'P44_PUBLIC_VIEW_YN'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'N'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1865444194726994154)
,p_event_id=>wwv_flow_imp.id(1865443942898994152)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1865443391323994146)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1865444072216994153)
,p_event_id=>wwv_flow_imp.id(1865443942898994152)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1865443391323994146)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(128668025927925050)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'close'
,p_static_id=>'close'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_success_messages', 'N')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>108591461097964971
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1857217962393635690)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from EBA_CA_CALENDARS'
,p_static_id=>'fetch-row-from-eba-ca-calendars'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'primary_key_column', 'CALENDAR_ID',
  'primary_key_item', 'P44_CALENDAR_ID',
  'table_name', 'EBA_CA_CALENDARS')).to_clob
,p_process_error_message=>'Unable to fetch row.'
,p_internal_uid=>1837141397563675611
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1857218393617635690)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of EBA_CA_CALENDARS'
,p_static_id=>'process-row-of-eba-ca-calendars'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'lock_row', 'Y',
  'primary_key_column', 'CALENDAR_ID',
  'primary_key_item', 'P44_CALENDAR_ID',
  'supported_operations', 'I:U:D',
  'table_name', 'EBA_CA_CALENDARS')).to_clob
,p_process_error_message=>'Unable to process row of table EBA_CA_CALENDARS.'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>1837141828787675611
);
wwv_flow_imp.component_end;
end;
/
