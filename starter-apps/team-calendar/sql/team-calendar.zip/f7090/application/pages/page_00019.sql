prompt --application/pages/page_00019
begin
--   Manifest
--     PAGE: 00019
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>19
,p_name=>'Group Member Details'
,p_alias=>'GROUP-MEMBER-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Group Member Details'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(8940478416777379715)
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_step_template=>2101883943284197310
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(3255013570915135948)
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1717309530299423927)
,p_plug_name=>'Buttons'
,p_static_id=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2127905476394690047
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8026731852473060256)
,p_plug_name=>'Group Member Details'
,p_static_id=>'group-member-details'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8026732040657060257)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1717309530299423927)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'EDIT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8026732428567060259)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1717309530299423927)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Member'
,p_button_position=>'NEXT'
,p_button_condition=>'P19_MBR_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8026732655910060259)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(1717309530299423927)
,p_button_name=>'DELETE'
,p_static_id=>'delete'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--danger'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Delete'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P19_MBR_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8026732225539060258)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1717309530299423927)
,p_button_name=>'SAVE'
,p_static_id=>'save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P19_MBR_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8026733024980060261)
,p_name=>'P19_EMAIL_ADDRESS'
,p_is_required=>true
,p_item_sequence=>2
,p_item_plug_id=>wwv_flow_imp.id(8026731852473060256)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Email Address'
,p_source=>'EMAIL_ADDRESS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'The email address of the member.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8026741153880086661)
,p_name=>'P19_GROUP_ID'
,p_is_required=>true
,p_item_sequence=>1.5
,p_item_plug_id=>wwv_flow_imp.id(8026731852473060256)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Email Group'
,p_source=>'GROUP_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'EMAIL GROUPS'
,p_cHeight=>1
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_help_text=>'The group you are adding the member to.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8026732833759060260)
,p_name=>'P19_MBR_ID'
,p_item_sequence=>1
,p_item_plug_id=>wwv_flow_imp.id(8026731852473060256)
,p_use_cache_before_default=>'NO'
,p_source=>'MBR_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(8026918655779399371)
,p_computation_sequence=>10
,p_computation_item=>'P19_EMAIL_ADDRESS'
,p_static_id=>'p19-email-address'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'SQL'
,p_computation=>'lower(:P19_EMAIL_ADDRESS)'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8027022324620166142)
,p_validation_name=>'P19_EMAIL_ADDRESS'
,p_static_id=>'p19-email-address'
,p_validation_sequence=>10
,p_validation=>'P19_EMAIL_ADDRESS'
,p_validation2=>'[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>'Invalid Email format.'
,p_associated_item=>wwv_flow_imp.id(8026733024980060261)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(8027009735993065382)
,p_validation_name=>'P19_GROUP_EMAIL_ADDRESS unique'
,p_static_id=>'p19-group-email-address-unique'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from EBA_ca_email_group_mbrs',
' where lower(:P19_EMAIL_ADDRESS) = lower(email_address)',
'   and :P19_GROUP_ID = group_id',
'   and (:P19_MBR_ID != mbr_id or :P19_MBR_ID is null)'))
,p_validation_type=>'NOT_EXISTS'
,p_error_message=>'Email Address already exists within selected Group.'
,p_associated_item=>wwv_flow_imp.id(8026733024980060261)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46949366580718422)
,p_name=>'CNX'
,p_static_id=>'cnx'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8026732040657060257)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46949478949718423)
,p_event_id=>wwv_flow_imp.id(46949366580718422)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-dialog-cancel'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(46950235947718431)
,p_process_sequence=>11
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_static_id=>'close-dialog'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_success_messages', 'N')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>26873671117758352
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8026736441363060269)
,p_process_sequence=>1
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from EBA_CA_EMAIL_GROUP_MBRS'
,p_static_id=>'fetch-row-from-eba-ca-email-group-mbrs'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'primary_key_column', 'MBR_ID',
  'primary_key_item', 'P19_MBR_ID',
  'table_name', 'EBA_CA_EMAIL_GROUP_MBRS')).to_clob
,p_process_error_message=>'Unable to fetch row.'
,p_internal_uid=>8006659876533100190
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8026736626367060271)
,p_process_sequence=>1
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of EBA_CA_EMAIL_GROUP_MBRS'
,p_static_id=>'process-row-of-eba-ca-email-group-mbrs'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'lock_row', 'Y',
  'primary_key_column', 'MBR_ID',
  'primary_key_item', 'P19_MBR_ID',
  'supported_operations', 'I:U:D',
  'table_name', 'EBA_CA_EMAIL_GROUP_MBRS')).to_clob
,p_process_error_message=>'Unable to process row of table EBA_CA_EMAIL_GROUP_MBRS.'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>8006660061537100192
);
wwv_flow_imp.component_end;
end;
/
