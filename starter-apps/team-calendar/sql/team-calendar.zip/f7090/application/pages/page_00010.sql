prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'Event Details'
,p_alias=>'EVENT-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Event Details'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(1317197580595951218)
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'var groupCal = groupCal || {};',
'',
'groupCal.defaultDuration = 1;'))
,p_step_template=>2103835248774687739
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(3255014080085135948)
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8941007515035353671)
,p_plug_name=>'Audit Information'
,p_static_id=>'audit-information'
,p_parent_plug_id=>wwv_flow_imp.id(8940468097198355042)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P10_EVENT_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1716272522204411853)
,p_plug_name=>'Buttons'
,p_static_id=>'buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2129856781885180476
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8940468097198355042)
,p_plug_name=>'Event'
,p_static_id=>'event'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7969204344932241829)
,p_plug_name=>'Links'
,p_static_id=>'links'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:is-expanded:t-Region--noBorder:t-Region--scrollBody'
,p_plug_template=>2667762537863948531
,p_plug_display_sequence=>50
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9159112497264649645)
,p_plug_name=>'Recurrence'
,p_static_id=>'recurrence'
,p_parent_plug_id=>wwv_flow_imp.id(8940468097198355042)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4504868307683981366
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8940468209591355043)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1716272522204411853)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4075790603270660137
,p_button_image_alt=>'Cancel'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'f?p=&APP_ID.:&LAST_VIEW.:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8940468517290355043)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1716272522204411853)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>4075790603270660137
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Event'
,p_button_position=>'NEXT'
,p_button_condition=>'P10_EVENT_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8523028667561673406)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(1716272522204411853)
,p_button_name=>'DELETE2'
,p_static_id=>'delete'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--danger'
,p_button_template_id=>4075790603270660137
,p_button_image_alt=>'Delete'
,p_button_position=>'CLOSE'
,p_button_execute_validations=>'N'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P10_EVENT_ID is not null and',
':P10_SERIES_ID is not null'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8940468304271355043)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(1716272522204411853)
,p_button_name=>'DELETE'
,p_static_id=>'delete-2'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--danger'
,p_button_template_id=>4075790603270660137
,p_button_image_alt=>'Delete'
,p_button_position=>'EDIT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P10_EVENT_ID is not null and',
':P10_SERIES_ID is null'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8940468406945355043)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1716272522204411853)
,p_button_name=>'SAVE'
,p_static_id=>'save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--gapLeft'
,p_button_template_id=>4075790603270660137
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P10_EVENT_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(608741874491284688)
,p_branch_name=>'Go To Home if setting event to recur'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(8940468406945355043)
,p_branch_sequence=>30
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>':P10_RECUR = ''N'' and :P10_RECUR_FLAG = ''Y'''
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8521084961235497979)
,p_branch_action=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>':P10_RECUR = ''Y'' and :REQUEST in (''SAVE'',''DELETE2'')'
,p_branch_condition_text=>'PLSQL'
,p_save_state_before_branch_yn=>'Y'
,p_branch_comment=>'Created 08-SEP-2010 20:10 by SBKENNED'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8521086952409533337)
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:1::'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(8940468304271355043)
,p_branch_sequence=>20
,p_save_state_before_branch_yn=>'Y'
,p_branch_comment=>'Created 08-SEP-2010 20:10 by SBKENNED'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(8940468625695355044)
,p_branch_name=>'Go To Page &LAST_VIEW.'
,p_branch_action=>'f?p=&APP_ID.:&LAST_VIEW.:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>40
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>':REQUEST not in (''DELETE'',''DELETE2'')'
,p_branch_condition_text=>'PLSQL'
,p_save_state_before_branch_yn=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1693193787478874164)
,p_name=>'P10_CALENDAR_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(8940468097198355042)
,p_prompt=>'Calendar'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'CALENDARS'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Default Calendar -'
,p_cHeight=>1
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_help_text=>'Name of the event.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3257350367240719910)
,p_name=>'P10_CONTACT_EMAIL'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(8940468097198355042)
,p_prompt=>'Contact Email'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'Person to contact for more information.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8940470404896355048)
,p_name=>'P10_CONTACT_PERSON'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(8940468097198355042)
,p_prompt=>'Contact Person'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'Person to contact for more information.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8940470919136355048)
,p_name=>'P10_CREATED_BY'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(8941007515035353671)
,p_prompt=>'Created By:'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'The user who created the record.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8940470620038355048)
,p_name=>'P10_CREATED_ON'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(8941007515035353671)
,p_prompt=>'Created:'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'The date on which the record was created.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9151832521066883043)
,p_name=>'P10_DURATION'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(8940468097198355042)
,p_prompt=>'End Time'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(to_date(to_char(trunc(sysdate),''&APP_DATE_FORMAT.'')||:P10_EVENT_START_TIME_D,',
'                       ''&APP_DATE_FORMAT.''||''&APP_TIME_FORMAT.'') + ((i-1)/(24*4)),',
'               ''&APP_TIME_FORMAT.'') ||',
'       '' ('' ||',
'      case when i = 1 then ''0 mins''',
'            when i = 2 then ''15 mins''',
'            when i = 3 then ''30 mins''',
'            when i = 4 then ''45 mins''',
'            when i = 5 then ''1 hr''',
'            when i > 5 then to_char(trunc((i-1)/4)) || '' hrs'' ||',
'              case when i - trunc((i-1)/4)*4 = 1 then ''''',
'                   when i - trunc((i-1)/4)*4 = 2 then '' 15 mins''',
'                   when i - trunc((i-1)/4)*4 = 3 then '' 30 mins''',
'                   when i - trunc((i-1)/4)*4 = 4 then '' 45 mins''',
'               end',
'             end',
'       || '')'' d,',
'       (i-1)/4 r',
'  from wwv_flow_dual100',
' where i < 50',
'order by i',
''))
,p_lov_cascade_parent_items=>'P10_EVENT_START_TIME_D'
,p_ajax_items_to_submit=>'P10_DURATION'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>2530188257487313616
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_help_text=>'End time of the event.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8782140601529096650)
,p_name=>'P10_EVENT_DATE_D'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(8940468097198355042)
,p_prompt=>'Date'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>15
,p_cMaxlength=>30
,p_field_template=>2530188257487313616
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'Select the event date.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8940469203507355046)
,p_name=>'P10_EVENT_DATE_TIME'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(8940468097198355042)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8940470208800355047)
,p_name=>'P10_EVENT_DESC'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(8940468097198355042)
,p_prompt=>'Description'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>64
,p_cMaxlength=>4000
,p_cHeight=>4
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'Description of the event.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'N',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8940468717517355045)
,p_name=>'P10_EVENT_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(8940468097198355042)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8940468808877355046)
,p_name=>'P10_EVENT_NAME'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(8940468097198355042)
,p_prompt=>'Name'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>2530188257487313616
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'Name of the event.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9151831812062880420)
,p_name=>'P10_EVENT_START_TIME_D'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(8940468097198355042)
,p_prompt=>'Start Time'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'START TIME SELECTOR'
,p_cHeight=>1
,p_field_template=>2530188257487313616
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_help_text=>'Start time of the event.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8940471427673355048)
,p_name=>'P10_LAST_UPDATED_BY'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(8941007515035353671)
,p_prompt=>'Last Updated By:'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'The user who last updated the record.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8940471114778355048)
,p_name=>'P10_LAST_UPDATED_ON'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(8941007515035353671)
,p_prompt=>'Last Updated:'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'The date on which the record was last updated.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7969169050894148918)
,p_name=>'P10_LINK_NAME_1'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(7969204344932241829)
,p_prompt=>'Name 1'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'Name of 1st link.  If not provided, the URL will be displayed.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7969179930509171410)
,p_name=>'P10_LINK_NAME_2'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(7969204344932241829)
,p_prompt=>'2'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'Name of 2nd link.  If not provided, the URL will be displayed.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7969188227093198811)
,p_name=>'P10_LINK_NAME_3'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(7969204344932241829)
,p_prompt=>'3'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'Name of 3rd link.  If not provided, the URL will be displayed.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7969170628515151881)
,p_name=>'P10_LINK_URL_1'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(7969204344932241829)
,p_prompt=>'URL'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_protection_level=>'S'
,p_help_text=>'URL for 1st link.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7969180439167173924)
,p_name=>'P10_LINK_URL_2'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(7969204344932241829)
,p_prompt=>'2'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>2044213549383960320
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_protection_level=>'S'
,p_help_text=>'URL for 2nd link.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7969188834365200849)
,p_name=>'P10_LINK_URL_3'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(7969204344932241829)
,p_prompt=>'3'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>2044213549383960320
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_protection_level=>'S'
,p_help_text=>'URL for 3rd link.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8521045967451348429)
,p_name=>'P10_LOCATION'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(8940468097198355042)
,p_prompt=>'Location'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>255
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'Location of the event.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1879261889421248409)
,p_name=>'P10_NEW_COLOR_PREF_ID'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(8940468097198355042)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Color Preference'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'COLOR PREFERENCE'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Color Preference -'
,p_cHeight=>1
,p_grid_label_column_span=>3
,p_field_template=>2530188257487313616
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8816220086173004611)
,p_name=>'P10_NEW_EVENT_TYPE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(8940468097198355042)
,p_prompt=>'New Type'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>48
,p_cMaxlength=>60
,p_grid_label_column_span=>3
,p_field_template=>2530188257487313616
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'If desired type is not in the select list, you can enter an event type here and it will be created.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1879262207000251402)
,p_name=>'P10_NEW_INTERNAL_YN'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(8940468097198355042)
,p_use_cache_before_default=>'NO'
,p_prompt=>'External / Internal'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:External;N,Internal Only;Y'
,p_cHeight=>1
,p_grid_label_column_span=>3
,p_field_template=>2530188257487313616
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_required_patch=>wwv_flow_imp.id(1631739938122003976)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8521086567169528123)
,p_name=>'P10_RECUR'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(9159112497264649645)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9159198712706918994)
,p_name=>'P10_RECUR_END_DATE'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(9159112497264649645)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'case when :P10_EVENT_ID is null',
'     then sysdate+7',
'     else to_date(:P10_EVENT_DATE_D,''&APP_DATE_FORMAT.'')+7',
'     end'))
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'End Date'
,p_format_mask=>'&APP_DATE_FORMAT.'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>15
,p_cMaxlength=>30
,p_field_template=>2530188257487313616
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_help_text=>'Date on which the recurrence will end.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9159214515832995556)
,p_name=>'P10_RECUR_FLAG'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(8940468097198355042)
,p_prompt=>'Recurs?'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'CHECKBOX'
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_help_text=>'Identifies if event recurs.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9159196920887911857)
,p_name=>'P10_RECUR_FREQ'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(9159112497264649645)
,p_prompt=>'Frequency'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'RECUR FREQUENCY'
,p_cHeight=>1
,p_field_template=>2530188257487313616
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_help_text=>'Select recurrence frequency.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8397428048098832141)
,p_name=>'P10_SERIES_ID'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(9159112497264649645)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7402714899757961629)
,p_name=>'P10_SUPPRESS_TIME'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(8940468097198355042)
,p_prompt=>'All day event?'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'CHECKBOX'
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_help_text=>'If you do not want the start time to display on the Monthly report, check Suppress Time.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3256260873470213936)
,p_name=>'P10_TAGS'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(8940468097198355042)
,p_prompt=>'Tags'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tag',
'  from eba_ca_tags_type_sum',
' where content_type = ''EVENT''',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>2322028657308407345
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'POPUP',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8940469002607355046)
,p_name=>'P10_TYPE_ID'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(8940468097198355042)
,p_item_default=>'nvl(:P1_EVENT_TYPE,:P12_EVENT_TYPE)'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Type'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'EVENT TYPES'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Type -'
,p_cHeight=>1
,p_field_template=>2530188257487313616
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_protection_level=>'S'
,p_help_text=>'Type of event.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(8412505174086574823)
,p_computation_sequence=>20
,p_computation_item=>'P10_DURATION'
,p_static_id=>'p10-duration'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'1'
,p_compute_when=>'P10_EVENT_ID'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(3792909205182581348)
,p_computation_sequence=>10
,p_computation_item=>'P10_EVENT_DATE_D'
,p_static_id=>'p10-event-date-d'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'to_char(to_date(:P10_EVENT_DATE_D,''&APP_DATE_TIME_FORMAT.''),''&APP_NLS_DATE_FORMAT.'')'
,p_compute_when=>'P10_EVENT_ID'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(8013694144354945853)
,p_computation_sequence=>10
,p_computation_item=>'P10_EVENT_START_TIME_D'
,p_static_id=>'p10-event-start-time-d'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(trunc(to_date(to_char(current_timestamp,''&APP_TIME_FORMAT.''),''&APP_TIME_FORMAT.''),''HH'')+1/24,''&APP_TIME_FORMAT.'') from dual',
''))
,p_compute_when=>'P10_EVENT_ID'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1865445251971994165)
,p_validation_name=>'P10_NEW_COLOR_PREF_ID Not Null'
,p_static_id=>'p10-new-color-pref-id-not-null'
,p_validation_sequence=>30
,p_validation=>'P10_NEW_COLOR_PREF_ID'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have some value.'
,p_validation_condition=>'P10_TYPE_ID'
,p_validation_condition2=>'-1'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_associated_item=>wwv_flow_imp.id(1879261889421248409)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1512454154292228099)
,p_validation_name=>'P10_NEW_EVENT_TYPE Not Null'
,p_static_id=>'p10-new-event-type-not-null'
,p_validation_sequence=>10
,p_validation=>'P10_NEW_EVENT_TYPE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have some value.'
,p_validation_condition=>'P10_TYPE_ID'
,p_validation_condition2=>'-1'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_associated_item=>wwv_flow_imp.id(8816220086173004611)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1865445426529994166)
,p_validation_name=>'P10_NEW_INTERNAL_YN Not Null'
,p_static_id=>'p10-new-internal-yn-not-null'
,p_validation_sequence=>40
,p_validation=>'P10_NEW_INTERNAL_YN'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# must have some value.'
,p_validation_condition=>'P10_TYPE_ID'
,p_validation_condition2=>'-1'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_associated_item=>wwv_flow_imp.id(1879262207000251402)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
,p_required_patch=>wwv_flow_imp.id(1631739938122003976)
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(9159262120532186090)
,p_validation_name=>'P10_RECUR_END_DATE not null'
,p_static_id=>'p10-recur-end-date-not-null'
,p_validation_sequence=>50
,p_validation=>'P10_RECUR_END_DATE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Recur End Date must be supplied.'
,p_validation_condition=>'P10_RECUR_FLAG'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_imp.id(9159198712706918994)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(9159260703432171713)
,p_validation_name=>'recur end date > event date'
,p_static_id=>'recur-end-date-event-date'
,p_validation_sequence=>60
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'to_date(:P10_RECUR_END_DATE,''&APP_DATE_FORMAT.'') >=',
'to_date(:P10_EVENT_DATE_D,''&APP_DATE_FORMAT.'')'))
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Recur End Date must be after Event Date'
,p_validation_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P10_RECUR_END_DATE is not null and ',
':P10_RECUR_FLAG is not null'))
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_associated_item=>wwv_flow_imp.id(9159198712706918994)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(485139225196592291)
,p_validation_name=>'URL 1 must start with http'
,p_static_id=>'url-1-must-start-with-http'
,p_validation_sequence=>80
,p_validation=>'substr(:P10_LINK_URL_1, 1, 4) = ''http'''
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'URL must start with http:// or https://'
,p_validation_condition=>'P10_LINK_URL_1'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_imp.id(7969170628515151881)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(485139299713592292)
,p_validation_name=>'URL 2 must start with http'
,p_static_id=>'url-2-must-start-with-http'
,p_validation_sequence=>90
,p_validation=>'substr(:P10_LINK_URL_2, 1, 4) = ''http'''
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'URL must start with http:// or https://'
,p_validation_condition=>'P10_LINK_URL_2'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_imp.id(7969180439167173924)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(485139444917592293)
,p_validation_name=>'URL 3 must start with http'
,p_static_id=>'url-3-must-start-with-http'
,p_validation_sequence=>100
,p_validation=>'substr(:P10_LINK_URL_3, 1, 4) = ''http'''
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'URL must start with http:// or https://'
,p_validation_condition=>'P10_LINK_URL_3'
,p_validation_condition_type=>'ITEM_IS_NOT_NULL'
,p_associated_item=>wwv_flow_imp.id(7969188834365200849)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(293897621188890183)
,p_validation_name=>'Valid Characters in Tag'
,p_static_id=>'valid-characters-in-tag'
,p_validation_sequence=>70
,p_validation=>'not regexp_like( :P10_TAGS, ''[:;#\/\\\?\&]'' )'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Tags may not contain the following characters: : ; \ / ? &'
,p_validation_condition=>'CREATE,SAVE'
,p_validation_condition_type=>'REQUEST_IN_CONDITION'
,p_associated_item=>wwv_flow_imp.id(3256260873470213936)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1716272565863411854)
,p_name=>'Cancel Dialog'
,p_static_id=>'cancel-dialog'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8940468209591355043)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1716272705551411855)
,p_event_id=>wwv_flow_imp.id(1716272565863411854)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-dialog-cancel'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(9159229508308050151)
,p_name=>'display recurrence region'
,p_static_id=>'display-recurrence-region'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P10_RECUR_FLAG'
,p_condition_element=>'P10_RECUR_FLAG'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Y'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9159229995901050154)
,p_event_id=>wwv_flow_imp.id(9159229508308050151)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9159112497264649645)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9159229804928050153)
,p_event_id=>wwv_flow_imp.id(9159229508308050151)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9159112497264649645)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3303912875626468888)
,p_name=>'Hide time if All Day event'
,p_static_id=>'hide-time-if-all-day-event'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P10_SUPPRESS_TIME'
,p_condition_element=>'P10_SUPPRESS_TIME'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Y'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3303913153726468890)
,p_event_id=>wwv_flow_imp.id(3303912875626468888)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P10_EVENT_START_TIME_D,P10_DURATION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3303913361018468891)
,p_event_id=>wwv_flow_imp.id(3303912875626468888)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P10_EVENT_START_TIME_D,P10_DURATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8013619833937715751)
,p_name=>'redefault recur end date'
,p_static_id=>'redefault-recur-end-date'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P10_EVENT_DATE_D'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>'(:P10_EVENT_ID is null or :P10_RECUR_FLAG is null) and regexp_like(:P10_EVENT_DATE_D,''^[:digit:]+\-[:alpha:]+\-[:digit:]+$'')'
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8013620148795715756)
,p_event_id=>wwv_flow_imp.id(8013619833937715751)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-set-value'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P10_RECUR_END_DATE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'escape_special_characters', 'Y',
  'items_to_submit', 'P10_EVENT_DATE_D',
  'plsql_expression', 'to_date(:P10_EVENT_DATE_D,''&APP_DATE_FORMAT.'')+7',
  'suppress_change_event', 'N',
  'type', 'PLSQL_EXPRESSION')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8412673245464850368)
,p_name=>'reset duration after refresh'
,p_static_id=>'reset-duration-after-refresh'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P10_DURATION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8412673563410850369)
,p_event_id=>wwv_flow_imp.id(8412673245464850368)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-set-value'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P10_DURATION'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_expression', 'groupCal.defaultDuration',
  'suppress_change_event', 'Y',
  'type', 'JAVASCRIPT_EXPRESSION')).to_clob
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8412515950369605770)
,p_name=>'save duration'
,p_static_id=>'save-duration'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P10_DURATION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8412516266627605775)
,p_event_id=>wwv_flow_imp.id(8412515950369605770)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'var duration = $v("P10_DURATION");',
    '',
    'if ( duration > 0 ) {',
    '   groupCal.defaultDuration = duration;',
    '}')))).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8816249591601148050)
,p_name=>'show/hide new event type'
,p_static_id=>'show-hide-new-event-type'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P10_TYPE_ID'
,p_condition_element=>'P10_TYPE_ID'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'-1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8816250087429148062)
,p_event_id=>wwv_flow_imp.id(8816249591601148050)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-hide'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P10_NEW_EVENT_TYPE,P10_NEW_COLOR_PREF_ID,P10_NEW_INTERNAL_YN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8816249885036148057)
,p_event_id=>wwv_flow_imp.id(8816249591601148050)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_static_id=>'native-show'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P10_NEW_EVENT_TYPE,P10_NEW_COLOR_PREF_ID,P10_NEW_INTERNAL_YN'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1716272794606411856)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_static_id=>'close-dialog'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'show_success_messages', 'N')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>1696196229776451777
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9163097821813754141)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create'
,p_static_id=>'create'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_type_id         number;',
'   l_new_event_type  varchar2(60);',
'   l_display_time    varchar2(1);',
'   l_duration        number := :P10_DURATION;',
'begin',
'',
'if :P10_TYPE_ID = ''-1'' then',
'   l_type_id        := null;',
'   l_new_event_type := :P10_NEW_EVENT_TYPE;',
'else',
'   l_type_id        := :P10_TYPE_ID;',
'   l_new_event_type := null;',
'end if;',
'',
'if :P10_SUPPRESS_TIME = ''Y'' then',
'   l_display_time := ''N'';',
'   l_duration := 24;',
'else',
'   l_display_time := ''Y'';',
'end if;',
'',
'EBA_ca_api.create_event (',
'   p_event_name      => :P10_EVENT_NAME,',
'   p_calendar_id     => :P10_CALENDAR_ID,',
'   p_type_id         => l_type_id,',
'   p_new_event_type  => l_new_event_type,',
'   p_new_color_pref_id => :P10_NEW_COLOR_PREF_ID,',
'   p_new_internal_yn   => :P10_NEW_INTERNAL_YN,',
'   p_event_date_time => to_date(:P10_EVENT_DATE_D||:P10_EVENT_START_TIME_D,',
'                               ''&APP_DATE_FORMAT.&APP_TIME_FORMAT.''),',
'   p_duration        => l_duration,',
'   p_event_desc      => :P10_EVENT_DESC,',
'   p_contact_person  => :P10_CONTACT_PERSON,',
'   p_contact_email   => :P10_CONTACT_EMAIL,',
'   p_display_time    => l_display_time,',
'   p_location        => :P10_LOCATION,',
'   p_link_name_1     => :P10_LINK_NAME_1,',
'   p_link_url_1      => :P10_LINK_URL_1,',
'   p_link_name_2     => :P10_LINK_NAME_2,',
'   p_link_url_2      => :P10_LINK_URL_2,',
'   p_link_name_3     => :P10_LINK_NAME_3,',
'   p_link_url_3      => :P10_LINK_URL_3,',
'   p_tags            => :P10_TAGS,',
'   --',
'   p_recur_flag      => :P10_RECUR_FLAG,',
'   p_recur_freq      => :P10_RECUR_FREQ,',
'   p_recur_end_date  => to_date(:P10_RECUR_END_DATE||:P10_EVENT_START_TIME_D,',
'                               ''&APP_DATE_FORMAT.&APP_TIME_FORMAT.'') );',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error creating event.'
,p_process_when_button_id=>wwv_flow_imp.id(8940468517290355043)
,p_process_success_message=>'Event created.'
,p_internal_uid=>9143021256983794062
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8782291172926523623)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Load Data'
,p_static_id=>'load-data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in (',
'   select event_name,',
'          calendar_id,',
'          type_id,',
'          event_date_time,',
'          duration,',
'          event_desc,',
'          contact_person,',
'          case when display_time = ''Y'' then null',
'               when display_time = ''N'' then ''Y''',
'               end suppress_time,',
'          location,',
'          link_name_1, link_url_1, link_name_2, link_url_2, link_name_3, link_url_3,',
'          series_id,',
'          created_on, ',
'          created_by, ',
'          last_updated_on, ',
'          last_updated_by, ',
'          tags,',
'          contact_email',
'     from EBA_ca_events',
'   where event_id = :P10_EVENT_ID )',
'loop',
'   :P10_EVENT_NAME         := c1.event_name;	',
'   :P10_CALENDAR_ID        := c1.calendar_id;',
'   :P10_TYPE_ID	           := c1.type_id;	',
'   :P10_EVENT_DATE_TIME	   := to_char(c1.event_date_time,''&APP_DATE_FORMAT.&APP_TIME_FORMAT.'');		',
'   :P10_EVENT_DATE_D	   := to_char(c1.event_date_time,''&APP_DATE_FORMAT.'');	',
'   :P10_EVENT_START_TIME_D := to_char(c1.event_date_time,''&APP_TIME_FORMAT.'');	',
'   :P10_DURATION           := c1.duration;	',
'   :P10_EVENT_DESC	   := c1.event_desc;	',
'   :P10_CONTACT_PERSON	   := c1.contact_person;',
'   if c1.contact_email is null and ',
'      instr(c1.contact_person,''@'') > 0 and ',
'      instr(c1.contact_person,''.'') > 0 then',
'      :P10_CONTACT_EMAIL      := c1.contact_person;',
'   else',
'      :P10_CONTACT_EMAIL      := c1.contact_email;',
'   end if;',
'   ',
'   :P10_SUPPRESS_TIME      := c1.suppress_time;',
'   :P10_LOCATION           := c1.location;',
'   :P10_LINK_NAME_1        := c1.link_name_1;',
'   :P10_LINK_URL_1         := c1.link_url_1;',
'   :P10_LINK_NAME_2        := c1.link_name_2;',
'   :P10_LINK_URL_2         := c1.link_url_2;',
'   :P10_LINK_NAME_3        := c1.link_name_3;',
'   :P10_LINK_URL_3         := c1.link_url_3;',
'   :P10_TAGS               := c1.tags;',
'   :P10_SERIES_ID          := c1.series_id;	',
'',
'   :P10_CREATED_ON	   := apex_util.get_since(c1.created_on);	',
'   :P10_CREATED_BY	   := c1.created_by;	',
'   :P10_LAST_UPDATED_ON	   := apex_util.get_since(c1.last_updated_on);	',
'   :P10_LAST_UPDATED_BY	   := c1.last_updated_by;	',
'',
'   if c1.series_id is not null then',
'      for c2 in (',
'         select recur_freq,',
'                end_date',
'           from EBA_ca_series',
'         where series_id = c1.series_id )',
'      loop',
'         :P10_RECUR_FLAG	:= ''Y'';',
'         :P10_RECUR_FREQ	:= c2.recur_freq;	',
'         :P10_RECUR_END_DATE	:= to_char(c2.end_date,''&APP_DATE_FORMAT.'');	',
'      end loop;',
'      :P10_RECUR := ''Y'';',
'   else',
'      :P10_RECUR := ''N'';',
'   end if;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'failed to load data'
,p_process_when=>'P10_EVENT_ID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>8762214608096563544
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8523029962497681432)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Recur Delete'
,p_static_id=>'recur-delete'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P10_RECUR        := ''Y'';',
':P11_REQUEST_TYPE := ''D'';'))
,p_process_clob_language=>'PLSQL'
,p_process_when_button_id=>wwv_flow_imp.id(8523028667561673406)
,p_internal_uid=>8502953397667721353
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8521087464530536827)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Simple Delete'
,p_static_id=>'simple-delete'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'EBA_ca_api.delete_event (',
'   p_event_id       => :P10_EVENT_ID );'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error deleting event.'
,p_process_when_button_id=>wwv_flow_imp.id(8940468304271355043)
,p_process_success_message=>'Event deleted.'
,p_internal_uid=>8501010899700576748
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8521085067469499831)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update'
,p_static_id=>'update'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'   l_type_id         number;',
'   l_new_event_type  varchar2(60);',
'   l_display_time    varchar2(1);',
'   l_duration        number := :P10_DURATION;',
'begin',
'',
'if :P10_SUPPRESS_TIME = ''Y'' then',
'   l_display_time := ''N'';',
'   l_duration := 24;',
'else',
'   l_display_time := ''Y'';',
'end if;',
'',
'for c1 in (',
'   select series_id, to_char(event_date_time,''&APP_DATE_FORMAT.'') event_date',
'     from EBA_ca_events',
'    where event_id = :P10_EVENT_ID )',
'loop',
'   -- simple update or adding recurrence',
'   if c1.series_id is null then',
'',
'      if :P10_TYPE_ID = ''-1'' then',
'         l_type_id        := null;',
'         l_new_event_type := :P10_NEW_EVENT_TYPE;',
'      else',
'         l_type_id        := :P10_TYPE_ID;',
'         l_new_event_type := null;',
'      end if;',
'',
'      EBA_ca_api.update_event (',
'         p_event_id        => :P10_EVENT_ID,',
'         p_event_name      => :P10_EVENT_NAME,',
'         p_calendar_id     => :P10_CALENDAR_ID,',
'         p_type_id         => l_type_id,',
'         p_new_event_type  => l_new_event_type,',
'         p_new_color_pref_id  => :P10_NEW_COLOR_PREF_ID,',
'         p_new_internal_yn    => :P10_NEW_INTERNAL_YN,',
'         p_event_date_time => to_date(:P10_EVENT_DATE_D||:P10_EVENT_START_TIME_D,',
'                                     ''&APP_DATE_FORMAT.&APP_TIME_FORMAT.''),',
'         p_duration        => l_duration,',
'         p_event_desc      => :P10_EVENT_DESC,',
'         p_contact_person  => :P10_CONTACT_PERSON,',
'         p_contact_email   => :P10_CONTACT_EMAIL,',
'         p_display_time    => l_display_time,',
'         p_location        => :P10_LOCATION,',
'         p_link_name_1     => :P10_LINK_NAME_1,',
'         p_link_url_1      => :P10_LINK_URL_1,',
'         p_link_name_2     => :P10_LINK_NAME_2,',
'         p_link_url_2      => :P10_LINK_URL_2,',
'         p_link_name_3     => :P10_LINK_NAME_3,',
'         p_link_url_3      => :P10_LINK_URL_3,',
'         p_tags            => :P10_TAGS,',
'         --',
'         p_recur_flag      => :P10_RECUR_FLAG,',
'         p_recur_freq      => :P10_RECUR_FREQ,',
'         p_recur_end_date  => to_date(:P10_RECUR_END_DATE||:P10_EVENT_START_TIME_D,',
'                                     ''&APP_DATE_FORMAT.&APP_TIME_FORMAT.''), ',
'         --',
'         p_update_request => ''S'' );',
'',
'   else',
'      -- removing recurrence',
'      if c1.series_id is not null and :P10_RECUR_FLAG is null then',
'         :P10_RECUR := ''Y'';',
'         :P11_REQUEST_TYPE := ''AFO'';',
'      else',
'         if :P10_EVENT_DATE_D != c1.event_date then ',
'            :P10_RECUR := ''Y'';',
'            :P11_REQUEST_TYPE := ''FO'';',
'         else',
'            for c2 in (',
'               select recur_freq, end_date',
'                 from EBA_ca_series',
'                where series_id = c1.series_id )',
'            loop',
'               if c2.recur_freq != :P10_RECUR_FREQ or',
'                  to_char(c2.end_date,''&APP_DATE_FORMAT.'') != :P10_RECUR_END_DATE then',
'                  :P10_RECUR := ''Y'';',
'                  :P11_REQUEST_TYPE := ''AF'';',
'               else',
'                  :P10_RECUR := ''Y'';',
'                  :P11_REQUEST_TYPE := ''AFO'';',
'               end if;',
'            end loop;',
'         end if;',
'      end if;',
'   end if;',
'end loop;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error updating event.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(8940468406945355043)
,p_process_success_message=>'Event updated.'
,p_internal_uid=>8501008502639539752
);
wwv_flow_imp.component_end;
end;
/
