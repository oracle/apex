prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Event Types'
,p_alias=>'EVENT-TYPES'
,p_page_mode=>'MODAL'
,p_step_title=>'Event Types'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(8940478416777379715)
,p_step_template=>2101883943284197310
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch:t-Dialog--noPadding'
,p_required_role=>wwv_flow_imp.id(3255013570915135948)
,p_protection_level=>'C'
,p_help_text=>'Event Types allow you to categorize events.  You can choose to associate a display color with an event type.'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8940462204198355020)
,p_plug_name=>'Event Types'
,p_static_id=>'event-types'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders'
,p_plug_template=>2102002977963900996
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select type_id,',
'       (select color_name from EBA_CA_color_prefs p where p.id = et.color_pref_id) color_preference,',
'       case when display_color is not null',
'            then ''<span style="white-space:nowrap;">'' || ',
'                 apex_escape.html(type_name) || ''</span>''',
'            else ''<span style="white-space:nowrap;">'' ||',
'                 apex_escape.html(type_name) || ''</span>''',
'            end type_name,',
'       type_name type_name_disp,',
'       display_color,',
'       border_color,',
'       (select count(*) from EBA_CA_EVENTS e',
'         where e.type_id = et.type_id) cnt_events,',
'       CREATED_ON,',
'       decode(nvl(internal_yn, ''N''), ''N'', ''External'', ''Internal Only'') internal_yn,',
'       LOWER(CREATED_BY) CREATED_BY,',
'       nvl(last_updated_on, created_on) LAST_UPDATED_ON,',
'       LOWER(LAST_UPDATED_BY) LAST_UPDATED_BY,',
'       type_name as type_name_raw',
'  from EBA_CA_EVENT_TYPES et'))
,p_plug_source_type=>'NATIVE_IR'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(8940462317738355020)
,p_max_row_count=>'10000'
,p_max_row_count_message=>'This query returns more than 10,000 rows, please filter your data to ensure complete results.'
,p_no_data_found_message=>'No event types found.'
,p_allow_save_rpt_public=>'Y'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::P8_TYPE_ID:#TYPE_ID#'
,p_detail_link_text=>'<span class="fa fa-edit" aria-hidden="true"></span>'
,p_detail_link_attr=>'title="Edit #TYPE_NAME_RAW#"'
,p_internal_uid=>8278312869474751362
);
wwv_flow_imp_page.create_worksheet_col_group(
 p_id=>wwv_flow_imp.id(9150247698034438343)
,p_name=>'Audit Info'
,p_static_id=>'audit-info'
,p_display_sequence=>20
);
wwv_flow_imp_page.create_worksheet_col_group(
 p_id=>wwv_flow_imp.id(9150247225953437006)
,p_name=>'Details'
,p_static_id=>'details'
,p_display_sequence=>10
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3256229180133846901)
,p_db_column_name=>'BORDER_COLOR'
,p_display_order=>83
,p_column_identifier=>'L'
,p_column_label=>'Border Color'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7434830706498886311)
,p_db_column_name=>'CNT_EVENTS'
,p_display_order=>53
,p_group_id=>wwv_flow_imp.id(9150247225953437006)
,p_column_identifier=>'I'
,p_column_label=>'Number of Events'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(3257512162360060186)
,p_db_column_name=>'COLOR_PREFERENCE'
,p_display_order=>93
,p_column_identifier=>'M'
,p_column_label=>'Color Preference'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8940462716673355021)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>23
,p_group_id=>wwv_flow_imp.id(9150247698034438343)
,p_column_identifier=>'D'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_help_text=>'The user who created the record.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7434830827454886313)
,p_db_column_name=>'CREATED_ON'
,p_display_order=>63
,p_group_id=>wwv_flow_imp.id(9150247698034438343)
,p_column_identifier=>'J'
,p_column_label=>'Created'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8940587599218857177)
,p_db_column_name=>'DISPLAY_COLOR'
,p_display_order=>3
,p_column_identifier=>'G'
,p_column_label=>'Display Color'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1558786025336352366)
,p_db_column_name=>'INTERNAL_YN'
,p_display_order=>13
,p_column_identifier=>'N'
,p_column_label=>'External / Internal '
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_required_patch=>wwv_flow_imp.id(1631739938122003976)
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8940462910367355022)
,p_db_column_name=>'LAST_UPDATED_BY'
,p_display_order=>33
,p_group_id=>wwv_flow_imp.id(9150247698034438343)
,p_column_identifier=>'F'
,p_column_label=>'Last Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_help_text=>'The user who last updated the record.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(7434830912416886313)
,p_db_column_name=>'LAST_UPDATED_ON'
,p_display_order=>73
,p_group_id=>wwv_flow_imp.id(9150247698034438343)
,p_column_identifier=>'K'
,p_column_label=>'Last Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'SINCE'
,p_tz_dependent=>'Y'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8940462424416355021)
,p_db_column_name=>'TYPE_ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Type Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8940462518574355021)
,p_db_column_name=>'TYPE_NAME'
,p_display_order=>2
,p_group_id=>wwv_flow_imp.id(9150247225953437006)
,p_column_identifier=>'B'
,p_column_label=>'Event Type'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
,p_help_text=>'Type of event.'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8034487424157241718)
,p_db_column_name=>'TYPE_NAME_DISP'
,p_display_order=>43
,p_group_id=>wwv_flow_imp.id(9150247225953437006)
,p_column_identifier=>'H'
,p_column_label=>'Event Type for Sorting'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(190256752635809710)
,p_db_column_name=>'TYPE_NAME_RAW'
,p_display_order=>103
,p_column_identifier=>'O'
,p_column_label=>'Type Name Raw'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(8940592317010871757)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1588307'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'TYPE_NAME:COLOR_PREFERENCE:INTERNAL_YN:CNT_EVENTS:LAST_UPDATED_ON:TYPE_NAME_RAW'
,p_sort_column_1=>'LAST_UPDATED_ON'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'TYPE_NAME_DISP'
,p_sort_direction_2=>'ASC'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(9159042122751221815)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'with Audit Info'
,p_report_seq=>10
,p_report_alias=>'3772805'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'TYPE_NAME:COLOR_PREFERENCE:INTERNAL_YN:CNT_EVENTS:CREATED_ON:CREATED_BY:LAST_UPDATED_ON:LAST_UPDATED_BY'
,p_sort_column_1=>'TYPE_NAME_DISP'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8940465616385355033)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(8940462204198355020)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Event Type'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:8::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3256229258447850047)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(8940462204198355020)
,p_button_name=>'RESET_REPORT'
,p_static_id=>'reset-report'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:7,RIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(128669813118925068)
,p_name=>'Refresh on Add'
,p_static_id=>'refresh-on-add'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8940465616385355033)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(128669847216925069)
,p_event_id=>wwv_flow_imp.id(128669813118925068)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8940462204198355020)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(128669998904925070)
,p_name=>'Refresh on Edit'
,p_static_id=>'refresh-on-edit'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(8940462204198355020)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129216763202094621)
,p_event_id=>wwv_flow_imp.id(128669998904925070)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8940462204198355020)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1717286164963308786)
,p_name=>'Refresh Report'
,p_static_id=>'refresh-report'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1717287070891308787)
,p_event_id=>wwv_flow_imp.id(1717286164963308786)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', 'apex.message.showPageSuccess(''Action Processed.'');')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1717286556803308787)
,p_event_id=>wwv_flow_imp.id(1717286164963308786)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(8940462204198355020)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
