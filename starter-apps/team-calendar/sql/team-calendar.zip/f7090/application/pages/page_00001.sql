prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'&APPLICATION_TITLE. - Home'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(8940477613660378872)
,p_javascript_file_urls=>'#APP_IMAGES#gc/apxColor.js'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Badge.apex-cal-default { background-color: #2578CF; border-color: #2578CF; color: #FFFFFF; }',
'.t-Badge.apex-cal-black { background-color: #303030; border-color: #303030; color: #FFFFFF; }',
'.t-Badge.apex-cal-blue { background-color: #4183D7; border-color: #4183D7; color: #FFFFFF; }',
'.t-Badge.apex-cal-bluesky { background-color: #6BB9F0; border-color: #6BB9F0; color: #404040; }',
'.t-Badge.apex-cal-brown { background-color: #D88935; border-color: #D88935; color: #404040; }',
'.t-Badge.apex-cal-cyan { background-color: #1ABC9C; border-color: #1ABC9C; color: #404040; }',
'.t-Badge.apex-cal-darkblue { background-color: #1F5F97; border-color: #1F5F97; color: #FFFFFF; }',
'.t-Badge.apex-cal-gray { background-color: #A0A0A0; border-color: #A0A0A0; color: #404040; }',
'.t-Badge.apex-cal-green { background-color: #2ECC71; border-color: #2ECC71; color: #404040; }',
'.t-Badge.apex-cal-lime { background-color: #28A346; border-color: #28A346; color: #FFFFFF; }',
'.t-Badge.apex-cal-orange { background-color: #F39C12; border-color: #F39C12; color: #404040; }',
'.t-Badge.apex-cal-red { background-color: #D91E18; border-color: #D91E18; color: #FFFFFF; }',
'.t-Badge.apex-cal-silver { background-color: #BDC3C7; border-color: #BDC3C7; color: #404040; }',
'.t-Badge.apex-cal-white { background-color: #F0F0F0; border-color: #F0F0F0; color: #404040; }',
'.t-Badge.apex-cal-yellow { background-color: #F1C40F; border-color: #F1C40F; color: #404040; }'))
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h2>About this Application</h2>',
'<p>The Team Calendar application gives you a way to list all your events on an easy to use, Web-accessible calendar. The Home page for the Team Calendar displays events in a monthly, weekly or daily format, with embedded links to detailed information'
||' about each event. You can also create customized reports on events.</p>',
'<p>',
'Each event is classified by event type and automatically displayed in an associated color. You can create your own event types or modify existing event type attributes.</p>',
'<p>',
'You can send emails to individuals or teams with information about upcoming meetings, and you have the ability to create your own teams to match your needs.</p>',
''))
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1733242383132955148)
,p_plug_name=>'ACL Warning'
,p_static_id=>'acl-warning'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--defaultIcons:t-Alert--warning:t-Alert--horizontal'
,p_plug_template=>2042159785845301134
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'PLUGIN_COM.ORACLE.APEX.ACL_WARNING'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'eba_ca_fw.get_preference_value(''ACCESS_CONTROL_ENABLED'') = ''N'''
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'f?p=&APP_ID.:SETTINGS:&SESSION.::&DEBUG.:RP::')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1716918900320296168)
,p_plug_name=>'&APPLICATION_TITLE.'
,p_static_id=>'application-title'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2675494171183407654
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for c1 in ( select preference_value',
'            from eba_ca_preferences',
'            where preference_name = ''APPLICATION_SUBTITLE''',
'            union all',
'            select ''Create, manage, and share calendar events.''',
'            from dual',
'            where not exists ( select null',
'                               from eba_ca_preferences',
'                               where preference_name = ''APPLICATION_SUBTITLE'')',
'          ) loop',
'    sys.htp.p(''<p>''||apex_escape.html(c1.preference_value)||''</p>'');',
'end loop;',
''))
,p_plug_source_type=>'NATIVE_PLSQL'
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1693194296036874169)
,p_name=>'Calendars'
,p_static_id=>'calendars'
,p_parent_plug_id=>wwv_flow_imp.id(1865442063424994133)
,p_template=>4073835273271169698
,p_display_sequence=>80
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d',
'  from',
'(',
'select ''Default'' d,',
'       1 ob',
'  from dual',
' where exists (select 1 from eba_ca_events',
'                where calendar_id is null)',
' and   (   nvl(:CALENDARS_FILTER,''0'') = ''0''',
'        or instr(:CALENDARS_FILTER, ''-1'') > 0',
'       )',
'union',
'select short_name ||'' - ''|| calendar_name || decode(public_view_yn, ''Y'', null, '' (Private)'') d,',
'       2 ob',
'  from eba_ca_calendars c',
'  where (   (     nvl(:CALENDARS_FILTER,''0'') = ''0'' ',
'              and  (   c.public_view_yn = ''Y''',
'                    or exists (select ''x''',
'                               from eba_ca_users u',
'                               where u.username = :APP_USER',
'                               and   (   instr(u.restricted_to, c.calendar_id) > 0',
'                                      or (access_level_id = 3 and restricted_to is null)',
'                                     )',
'                               )',
'                   ) ',
'              )',
'           or instr('':''||:CALENDARS_FILTER||'':'','':''||nvl(calendar_id,''-1'')||'':'') > 0',
'          )',
')',
' order by ob, d'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
,p_required_patch=>wwv_flow_imp.id(1857191596806388379)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1865440882890994121)
,p_query_column_id=>1
,p_column_alias=>'D'
,p_column_display_sequence=>1
,p_column_heading=>'Calendars'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(5566683884029312931)
,p_name=>'Contact Email'
,p_static_id=>'contact-email'
,p_parent_plug_id=>wwv_flow_imp.id(1865442063424994133)
,p_template=>4073835273271169698
,p_display_sequence=>90
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(:CONTACT_EMAIL, ''- All Contacts -'') contact_email',
'from dual'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''x'' from',
'eba_ca_events where contact_email is not null;'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
,p_required_patch=>wwv_flow_imp.id(1631739938122003976)
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1877429370019430029)
,p_query_column_id=>1
,p_column_alias=>'CONTACT_EMAIL'
,p_column_display_sequence=>1
,p_column_heading=>'Contact Email'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(7976333042534884922)
,p_name=>'Event Types'
,p_static_id=>'event-types'
,p_region_name=>'event-types-report'
,p_parent_plug_id=>wwv_flow_imp.id(1865442063424994133)
,p_template=>4073835273271169698
,p_display_sequence=>70
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--showIcon:t-Region--removeHeader js-removeLandmark:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select listagg(a.event_type, '' '') within group (order by a.type_name) event_types',
'from (select type_name,',
'       case when display_color is not null',
'            then ''<span class="a-luminance-color t-Badge t-Badge--basic t-Badge--small apex-cal-''||apex_escape.html(lower(cp.color_name))||''">''|| ',
'                 apex_escape.html(type_name || decode(:EXTERNAL_INTERNAL_BO, ''Include'', decode(internal_yn, ''Y'', '' (Internal Only)'', null), null) ) || ''</span>''',
'            else ''<span class="a-luminance-color t-Badge t-Badge--basic t-Badge--small" style="background-color:'' || apex_escape.html(cp.BG_COLOR) || '';">''||  ',
'                 apex_escape.html(type_name || decode(:EXTERNAL_INTERNAL_BO, ''Include'', decode(internal_yn, ''Y'', '' (Internal Only)'', null), null) ) || ''</span>''',
'            end event_type',
'from eba_ca_event_types et',
',    eba_ca_color_prefs cp',
'where et.color_pref_id = cp.id',
'and   (:EXTERNAL_INTERNAL_BO = ''Exclude''',
'       or (   nvl(internal_yn, ''N'') = ''N''',
'           or upper(:APP_USER) in (select upper(username) from eba_ca_users)',
'          )',
'      )',
'and   (   nvl(:EVENT_TYPES_FILTER,''0'') = ''0'' ',
'       or instr('':''||:EVENT_TYPES_FILTER||'':'','':''||nvl(type_id,''-1'')||'':'') > 0',
'      )',
') a',
''))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'  from EBA_CA_EVENT_TYPES'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1865444396079994156)
,p_query_column_id=>1
,p_column_alias=>'EVENT_TYPES'
,p_column_display_sequence=>1
,p_column_heading=>'Event Types'
,p_heading_alignment=>'LEFT'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1546735803295250850)
,p_plug_name=>'Events Calendar'
,p_static_id=>'events-calendar'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>50
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.event_id ',
', case when et.display_color is not null then',
'    ''apex-cal-''||',
'    (select lower(cp.color_name) from eba_ca_color_prefs cp where cp.bg_color = et.display_color)',
'  end css_class',
', e.event_name ',
', case when e.display_time = ''N'' then',
'    trunc(e.event_date_time)',
'  else ',
'    e.event_date_time',
'  end event_date_time',
', to_char(e.event_date_time,v(''APP_TIME_FORMAT'')) disp_time',
', substr (case when nvl(display_time,''Y'') = ''N'' then',
'            ''[All Day] ''',
'           else',
'             ''['' || ltrim(to_char(e.event_date_time,''HH:MIam''),''0'')',
'             || '' - '' || ltrim(to_char(e.event_date_time + duration/24,''HH:MIam''),''0'')',
'--             || '' ('' || case when e.duration = 0  then ''0 mins''',
'--                             when e.duration = .25 then ''15 mins''',
'--                             when e.duration = .5 then ''30 mins''',
'--                             when e.duration = .75 then ''45 mins''',
'--                             when e.duration = 1 then ''1 hr''',
'--                             when e.duration > 1 then to_char(trunc(e.duration)) || '' hrs''',
'--                               || case when e.duration - trunc(e.duration) = 0  then ''''',
'--                                       when e.duration - trunc(e.duration) = .25 then '' 15 mins''',
'--                                       when e.duration - trunc(e.duration) = .5 then '' 30 mins''',
'--                                       when e.duration - trunc(e.duration) = .75 then '' 45 mins''',
'--                                  end',
'--                        end',
'--             || '')] ''',
'             || ''] ''',
'           end ||',
'           case when :MULTIPLE_CAL_BO = ''Include'' then nvl(c.short_name, ''Default'') ||'': '' end || ',
'           e.event_name,1,255) ||',
'           case when exists (select 1 from EBA_CA_FILES',
'                             where event_id = e.event_id)',
'                then '' (a)''',
'           end disp_col',
'from eba_ca_events e',
',    eba_ca_event_types et',
',    eba_ca_calendars c',
'where e.type_id = et.type_id',
'and   e.calendar_id = c.calendar_id (+)',
'and   (   nvl(:EVENT_TYPES_FILTER,''0'') = ''0'' ',
'       or instr('':''||:EVENT_TYPES_FILTER||'':'', '':''||nvl(e.type_id,''-1'')||'':'') > 0',
'      )',
'and   (   :MULTIPLE_CAL_BO = ''Exclude'' ',
'       or (    nvl(:CALENDARS_FILTER,''0'') = ''0'' ',
'           and (   e.calendar_id is null',
'                or c.public_view_yn = ''Y''',
'                or exists (select ''x''',
'                           from eba_ca_users u',
'                           where u.username = :APP_USER',
'                           and   (   instr(u.restricted_to, c.calendar_id) > 0',
'                                  or (access_level_id = 3 and restricted_to is null)',
'                                 )',
'                          )',
'               ) ',
'          )',
'       or instr(:CALENDARS_FILTER,nvl(e.calendar_id,''-1'')) > 0',
'      )',
'and   (   :EXTERNAL_INTERNAL_BO = ''Exclude''',
'       or (:CONTACT_EMAIL is null',
'           or instr(upper(e.contact_email), :CONTACT_EMAIL) > 0',
'          )',
'      )',
'and   (   :EXTERNAL_INTERNAL_BO = ''Exclude''',
'       or (   nvl(et.internal_yn, ''N'') = ''N''',
'           or upper(:APP_USER) in (select upper(username) from eba_ca_users)',
'          )',
'      )',
'order by e.event_date_time'))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_required_patch=>wwv_flow_imp.id(1693198998806964482)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'calendar_views_and_navigation', 'month:list:navigation',
  'create_link', 'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:RP,10:P10_EVENT_DATE_D:&APEX$NEW_START_DATE.',
  'css_class', 'CSS_CLASS',
  'display_column', 'DISP_COL',
  'drag_and_drop', 'Y',
  'drag_and_drop_plsql_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'declare',
    '    l_recur_event boolean := false;',
    '    l_old_date    timestamp with time zone;',
    'begin',
    '	for c1 in (select s.series_id, start_date, end_date',
    '               from eba_ca_series s, eba_ca_events e',
    '               where s.series_id = e.series_id',
    '               and e.event_id = :APEX$PK_VALUE)',
    '    loop',
    '        l_recur_event := true;',
    '        exit;',
    '    end loop;',
    '',
    '    if not l_recur_event then',
    '        update eba_ca_events',
    '        set event_date_time = to_timestamp(:APEX$NEW_START_DATE,  ''YYYYMMDDHH24MISS'')',
    '        where event_id = :APEX$PK_VALUE;',
    '    end if;',
    'end;')),
  'event_sorting', 'AUTOMATIC',
  'first_hour', '9',
  'maximum_events_day', '10',
  'multiple_line_event', 'Y',
  'primary_key_column', 'EVENT_ID',
  'responsive_list_view', 'Y',
  'show_time', 'Y',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'EVENT_DATE_TIME',
  'time_format', '00',
  'view_edit_link', 'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:P3_EVENT_ID,P3_PREV_PAGE:&EVENT_ID.,1')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1693189581115874122)
,p_plug_name=>'Events Calendar'
,p_static_id=>'events-calendar-2'
,p_region_name=>'events-calendar'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.event_id ',
', case when et.display_color is not null then',
'    ''a-luminance-color apex-cal-''||',
'    (select lower(cp.color_name) from eba_ca_color_prefs cp where cp.bg_color = et.display_color)',
'  end css_class',
', e.event_name ',
', case when e.display_time = ''N'' then',
'    trunc(e.event_date_time)',
'  else e.event_date_time',
'  end event_date_time',
', to_char(e.event_date_time,v(''APP_TIME_FORMAT'')) disp_time',
', decode(nvl(display_time, ''Y''), ''Y'', e.event_date_time + (duration/24)',
'                                    , trunc(e.event_date_time) + 1',
'        ) end_time',
', substr (case when nvl(display_time,''Y'') = ''N'' then',
'             ''[All Day] ''',
'           else',
'             null',
'           end || ',
'           case when :MULTIPLE_CAL_BO = ''Include'' then nvl(c.short_name, ''Default'') ||'': '' end || ',
'           e.event_name,1,255) ||',
'           case when exists (select 1 from EBA_CA_FILES',
'                             where event_id = e.event_id)',
'                then '' (a)''',
'           end disp_col',
'from eba_ca_events e',
',    eba_ca_event_types et',
',    eba_ca_calendars c',
'where e.type_id = et.type_id',
'and   e.calendar_id = c.calendar_id (+)',
'and   (   nvl(:EVENT_TYPES_FILTER,''0'') = ''0'' ',
'       or instr('':''||:EVENT_TYPES_FILTER||'':'', '':''||nvl(e.type_id,''-1'')||'':'') > 0',
'      )',
'and   (   :MULTIPLE_CAL_BO = ''Exclude'' ',
'       or (    nvl(:CALENDARS_FILTER,''0'') = ''0'' ',
'           and (   e.calendar_id is null',
'                or c.public_view_yn = ''Y''',
'                or exists (select ''x''',
'                           from eba_ca_users u',
'                           where u.username = :APP_USER',
'                           and   (   instr(u.restricted_to, c.calendar_id) > 0',
'                                  or (access_level_id = 3 and restricted_to is null)',
'                                 )',
'                          )',
'               ) ',
'          )',
'       or instr(:CALENDARS_FILTER,nvl(e.calendar_id,''-1'')) > 0',
'      )',
'and   (   :EXTERNAL_INTERNAL_BO = ''Exclude''',
'       or (:CONTACT_EMAIL is null',
'           or instr(upper(e.contact_email), :CONTACT_EMAIL) > 0',
'          )',
'      )',
'and   (   :EXTERNAL_INTERNAL_BO = ''Exclude''',
'       or (   nvl(et.internal_yn, ''N'') = ''N''',
'           or upper(:APP_USER) in (select upper(username) from eba_ca_users)',
'          )',
'      )',
'order by e.event_date_time',
''))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_required_patch=>-wwv_flow_imp.id(1693198998806964482)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'calendar_export', 'ICAL',
  'calendar_views_and_navigation', 'month:week:day:list:navigation',
  'create_link', 'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:RP,10:P10_EVENT_DATE_D:&APEX$NEW_START_DATE.',
  'css_class', 'CSS_CLASS',
  'display_column', 'DISP_COL',
  'drag_and_drop', 'Y',
  'drag_and_drop_plsql_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'declare',
    '    l_recur_event boolean := false;',
    '    l_old_date    timestamp with time zone;',
    'begin',
    '	for c1 in (select s.series_id, start_date, end_date',
    '               from eba_ca_series s, eba_ca_events e',
    '               where s.series_id = e.series_id',
    '               and e.event_id = :APEX$PK_VALUE)',
    '    loop',
    '        l_recur_event := true;',
    '        exit;',
    '    end loop;',
    '',
    '    if not l_recur_event then',
    '        update eba_ca_events',
    '        set event_date_time = to_timestamp(:APEX$NEW_START_DATE,  ''YYYYMMDDHH24MISS'')',
    '        where event_id = :APEX$PK_VALUE;',
    '    end if;',
    'end;')),
  'end_date_column', 'END_TIME',
  'event_sorting', 'AUTOMATIC',
  'first_hour', '8',
  'maximum_events_day', '10',
  'multiple_line_event', 'Y',
  'primary_key_column', 'EVENT_ID',
  'responsive_list_view', 'Y',
  'show_time', 'Y',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'EVENT_DATE_TIME',
  'time_format', '12',
  'view_edit_link', 'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:P3_EVENT_ID,P3_PREV_PAGE:&EVENT_ID.,1')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1865442063424994133)
,p_plug_name=>'Filters'
,p_static_id=>'filters'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:js-useLocalStorage:is-expanded:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>2665811232373458102
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1216104272885839012)
,p_name=>'Notifications'
,p_static_id=>'notifications'
,p_display_sequence=>10
,p_component_template_options=>'#DEFAULT#'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id, ',
'       nvl(lower(NOTIFICATION_TYPE),''yellow'') as ALERT_TYPE, ',
'       NOTIFICATION_NAME as ALERT_TITLE, ',
'       NOTIFICATION_DESCRIPTION as ALERT_DESC,',
'       '''' alert_action',
'  from EBA_CA_NOTIFICATIONS',
' where (DISPLAY_FROM is null or DISPLAY_FROM <= current_date) and',
'       (DISPLAY_UNTIL is null or DISPLAY_UNTIL >= current_date)',
' order by nvl(DISPLAY_SEQUENCE,0),NOTIFICATION_NAME'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from EBA_CA_NOTIFICATIONS',
' where (DISPLAY_FROM is null or DISPLAY_FROM <= current_date) and',
'       (DISPLAY_UNTIL is null or DISPLAY_UNTIL >= current_date)'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>28842.25179278697457413
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1934399904205461241)
,p_query_column_id=>5
,p_column_alias=>'ALERT_ACTION'
,p_column_display_sequence=>5
,p_column_heading=>'Alert Action'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1934393976013456341)
,p_query_column_id=>4
,p_column_alias=>'ALERT_DESC'
,p_column_display_sequence=>4
,p_column_heading=>'Alert Desc'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1934393574439456341)
,p_query_column_id=>3
,p_column_alias=>'ALERT_TITLE'
,p_column_display_sequence=>3
,p_column_heading=>'Alert Title'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1934393170720456338)
,p_query_column_id=>2
,p_column_alias=>'ALERT_TYPE'
,p_column_display_sequence=>2
,p_column_heading=>'Alert Type'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1216104561687839013)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3257250560606863447)
,p_plug_name=>'Timezone'
,p_static_id=>'timezone'
,p_region_css_classes=>'infoTextRegion'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>60
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' "TIMEZONE"',
'',
' '))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'Y',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3256450257490931456)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1716918900320296168)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Event'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:10::'
,p_icon_css_classes=>'fa-chevron-right'
,p_security_scheme=>wwv_flow_imp.id(3255014080085135948)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1693193666918874163)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1865442063424994133)
,p_button_name=>'FILTER'
,p_static_id=>'filter'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconRight:t-Button--gapLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Update Filters'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-wrench'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(1168136702551611349)
,p_branch_action=>'f?p=&APP_ID.:1000:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>'eba_ca_fw.get_preference_value(''FIRST_RUN'') = ''YES'''
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(1884136564242852326)
,p_computation_sequence=>30
,p_computation_item=>'CONTACT_EMAIL'
,p_static_id=>'contact-email'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'null'
,p_compute_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''x''',
'from eba_ca_events',
'where contact_email is not null'))
,p_compute_when_type=>'NOT_EXISTS'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(23846147227392498)
,p_computation_sequence=>10
,p_computation_item=>'EVENT_TYPES_FILTER'
,p_static_id=>'event-types-filter'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'nvl(apex_util.get_preference ( ',
'              p_preference => ''EVENT_TYPES_FILTER'', ',
'              p_user       => :APP_USER ),0)'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(3256351369846676510)
,p_computation_sequence=>20
,p_computation_item=>'LAST_VIEW'
,p_static_id=>'last-view'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'1'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1716272896692411857)
,p_name=>'Refresh Calendar for Create'
,p_static_id=>'refresh-calendar-for-create'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(3256450257490931456)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1716273362742411862)
,p_event_id=>wwv_flow_imp.id(1716272896692411857)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', 'apex.message.showPageSuccess(''Event added.'');')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1716272934619411858)
,p_event_id=>wwv_flow_imp.id(1716272896692411857)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1693189581115874122)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1693193879480874165)
,p_event_id=>wwv_flow_imp.id(1716272896692411857)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh-2'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1546735803295250850)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1865441306907994125)
,p_name=>'Refresh Calendar for Filter'
,p_static_id=>'refresh-calendar-for-filter'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1693193666918874163)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1865441577846994128)
,p_event_id=>wwv_flow_imp.id(1865441306907994125)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'apex.message.showPageSuccess(''Filters applied.'');',
    '')))).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1865441404698994126)
,p_event_id=>wwv_flow_imp.id(1865441306907994125)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1546735803295250850)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1865441457395994127)
,p_event_id=>wwv_flow_imp.id(1865441306907994125)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh-2'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1693189581115874122)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1865441749097994130)
,p_event_id=>wwv_flow_imp.id(1865441306907994125)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh-3'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7976333042534884922)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1865441648949994129)
,p_event_id=>wwv_flow_imp.id(1865441306907994125)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh-4'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1693194296036874169)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1865444548375994158)
,p_event_id=>wwv_flow_imp.id(1865441306907994125)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh-5'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5566683884029312931)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
