prompt --application/deployment/install/install_events_history_trigger
begin
--   Manifest
--     INSTALL: INSTALL-events history trigger
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger ad_EBA_CA_EVENTS'||wwv_flow.LF||
'   after delete on EBA_CA_EVENTS'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(2) := ' insert into eba_ca_history ('||wwv_flow.LF||
'       table_name, component_rowkey, COMPONENT_ID, column_name, old_va';
wwv_flow_imp.g_varchar2_table(3) := 'lue, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :old.row_key, :old.event_id, ''DELETE'',null,''Removed event ''';
wwv_flow_imp.g_varchar2_table(4) := '||:old.EVENT_NAME);'||wwv_flow.LF||
'end ad_EBA_CA_EVENTS;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger ai_EBA_CA_EVENTS';
wwv_flow_imp.g_varchar2_table(5) := ''||wwv_flow.LF||
'   after insert on EBA_CA_EVENTS'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   insert into eba_ca_history ('||wwv_flow.LF||
'       table';
wwv_flow_imp.g_varchar2_table(6) := '_name, component_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'',:n';
wwv_flow_imp.g_varchar2_table(7) := 'ew.row_key, :new.event_id, ''Event Name '',null,:new.EVENT_NAME);'||wwv_flow.LF||
'end ai_EBA_CA_EVENTS;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(8) := ''||wwv_flow.LF||
'create or replace trigger au_EBA_CA_EVENTS'||wwv_flow.LF||
'   after update on EBA_CA_EVENTS'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'declare';
wwv_flow_imp.g_varchar2_table(9) := ''||wwv_flow.LF||
'   ov varchar2(4000) := null;'||wwv_flow.LF||
'   nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   -- FK'||wwv_flow.LF||
'   if updating and :old.';
wwv_flow_imp.g_varchar2_table(10) := 'TYPE_ID != :new.TYPE_ID then'||wwv_flow.LF||
'      ov := null; nv := null;'||wwv_flow.LF||
'      for c1 in (select type_name from eb';
wwv_flow_imp.g_varchar2_table(11) := 'a_ca_event_types t where t.type_id = :old.TYPE_ID) loop'||wwv_flow.LF||
'          ov := c1.type_name;'||wwv_flow.LF||
'      end loop';
wwv_flow_imp.g_varchar2_table(12) := ';'||wwv_flow.LF||
'      for c1 in (select type_name from eba_ca_event_types t where t.type_id = :new.TYPE_ID) loop'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(13) := '         nv := c1.type_name;'||wwv_flow.LF||
'      end loop;   '||wwv_flow.LF||
'      insert into eba_ca_history (table_name, compon';
wwv_flow_imp.g_varchar2_table(14) := 'ent_rowkey, component_id, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (''EVENTS'',:new.row_key';
wwv_flow_imp.g_varchar2_table(15) := ', :new.event_id, ''TYPE_ID'',ov,nv);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   if nvl(:old.SERIES_ID,''0'') != nvl(:new.SERIES';
wwv_flow_imp.g_varchar2_table(16) := '_ID,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_history (table_name, component_rowkey, COMPONENT_ID, column_';
wwv_flow_imp.g_varchar2_table(17) := 'name, old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'',:new.row_key, :new.event_id, ''SERIES_ID'',:old.SE';
wwv_flow_imp.g_varchar2_table(18) := 'RIES_ID,:new.SERIES_ID);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.EVENT_NAME,''0'') != nvl(:new.EVENT_NAME,''0'') then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(19) := '       insert into eba_ca_history (table_name, component_rowkey, COMPONENT_ID, column_name, old_valu';
wwv_flow_imp.g_varchar2_table(20) := 'e, new_value) values'||wwv_flow.LF||
'       (''EVENTS'',:new.row_key, :new.event_id, ''EVENT_NAME'',:old.EVENT_NAME,:new';
wwv_flow_imp.g_varchar2_table(21) := '.EVENT_NAME);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.DURATION,''0'') != nvl(:new.DURATION,''0'') then'||wwv_flow.LF||
'       insert i';
wwv_flow_imp.g_varchar2_table(22) := 'nto eba_ca_history (table_name, component_rowkey, COMPONENT_ID, column_name, old_value, new_value) v';
wwv_flow_imp.g_varchar2_table(23) := 'alues'||wwv_flow.LF||
'       (''EVENTS'', :new.row_key, :new.event_id, ''DURATION'',:old.DURATION,:new.DURATION);'||wwv_flow.LF||
'   end';
wwv_flow_imp.g_varchar2_table(24) := ' if;'||wwv_flow.LF||
'   if nvl(:old.EVENT_DESC,''0'') != nvl(:new.EVENT_DESC,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_histo';
wwv_flow_imp.g_varchar2_table(25) := 'ry (table_name, component_rowkey, COMPONENT_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
'       (''E';
wwv_flow_imp.g_varchar2_table(26) := 'VENTS'', :new.row_key, :new.event_id, ''EVENT_DESC'',:old.EVENT_DESC,:new.EVENT_DESC);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if';
wwv_flow_imp.g_varchar2_table(27) := ' nvl(:old.CONTACT_PERSON,''0'') != nvl(:new.CONTACT_PERSON,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_history';
wwv_flow_imp.g_varchar2_table(28) := ' (table_name, component_rowkey, COMPONENT_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
'       (''EVE';
wwv_flow_imp.g_varchar2_table(29) := 'NTS'', :new.row_key, :new.event_id, ''CONTACT_PERSON'',:old.CONTACT_PERSON,:new.CONTACT_PERSON);'||wwv_flow.LF||
'   end';
wwv_flow_imp.g_varchar2_table(30) := ' if;'||wwv_flow.LF||
'   if nvl(:old.CONTACT_EMAIL,''0'') != nvl(:new.CONTACT_EMAIL,''0'') then'||wwv_flow.LF||
'       insert into eba_ca';
wwv_flow_imp.g_varchar2_table(31) := '_history (table_name, component_rowkey, COMPONENT_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(32) := '   (''EVENTS'', :new.row_key, :new.event_id, ''CONTACT_EMAIL'',:old.CONTACT_EMAIL,:new.CONTACT_EMAIL);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(33) := '  end if;'||wwv_flow.LF||
'   if nvl(:old.DISPLAY_TIME,''0'') != nvl(:new.DISPLAY_TIME,''0'') then'||wwv_flow.LF||
'       insert into eba';
wwv_flow_imp.g_varchar2_table(34) := '_ca_history (table_name, component_rowkey, COMPONENT_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(35) := '      (''EVENTS'', :new.row_key, :new.event_id, ''DISPLAY_TIME'',:old.DISPLAY_TIME,:new.DISPLAY_TIME);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(36) := '  end if;'||wwv_flow.LF||
'   if nvl(:old.LOCATION,''0'') != nvl(:new.LOCATION,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_hist';
wwv_flow_imp.g_varchar2_table(37) := 'ory (table_name, component_rowkey, COMPONENT_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
'       (''';
wwv_flow_imp.g_varchar2_table(38) := 'EVENTS'', :new.row_key, :new.event_id, ''LOCATION'',:old.LOCATION,:new.LOCATION);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(';
wwv_flow_imp.g_varchar2_table(39) := ':old.LINK_NAME_1,''0'') != nvl(:new.LINK_NAME_1,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_history (table_nam';
wwv_flow_imp.g_varchar2_table(40) := 'e, component_rowkey, COMPONENT_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :new.';
wwv_flow_imp.g_varchar2_table(41) := 'row_key, :new.event_id, ''LINK_NAME_1'',:old.LINK_NAME_1,:new.LINK_NAME_1);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.';
wwv_flow_imp.g_varchar2_table(42) := 'LINK_URL_1,''0'') != nvl(:new.LINK_URL_1,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_history (table_name, comp';
wwv_flow_imp.g_varchar2_table(43) := 'onent_rowkey, COMPONENT_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :new.row_key';
wwv_flow_imp.g_varchar2_table(44) := ', :new.event_id, ''LINK_URL_1'',:old.LINK_URL_1,:new.LINK_URL_1);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.LINK_NAME_';
wwv_flow_imp.g_varchar2_table(45) := '2,''0'') != nvl(:new.LINK_NAME_2,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_history (table_name, component_ro';
wwv_flow_imp.g_varchar2_table(46) := 'wkey, COMPONENT_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :new.row_key, :new.e';
wwv_flow_imp.g_varchar2_table(47) := 'vent_id, ''LINK_NAME_2'',:old.LINK_NAME_2,:new.LINK_NAME_2);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.LINK_URL_2,''0'')';
wwv_flow_imp.g_varchar2_table(48) := ' != nvl(:new.LINK_URL_2,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_history (table_name, component_rowkey, C';
wwv_flow_imp.g_varchar2_table(49) := 'OMPONENT_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :new.row_key, :new.event_id';
wwv_flow_imp.g_varchar2_table(50) := ', ''LINK_URL_2'',:old.LINK_URL_2,:new.LINK_URL_2);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.LINK_NAME_3,''0'') != nvl(:';
wwv_flow_imp.g_varchar2_table(51) := 'new.LINK_NAME_3,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_history (table_name, component_rowkey, COMPONENT';
wwv_flow_imp.g_varchar2_table(52) := '_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :new.row_key, :new.event_id, ''LINK_';
wwv_flow_imp.g_varchar2_table(53) := 'NAME_3'',:old.LINK_NAME_3,:new.LINK_NAME_3);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.LINK_URL_3,''0'') != nvl(:new.LI';
wwv_flow_imp.g_varchar2_table(54) := 'NK_URL_3,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_history (table_name, component_rowkey, COMPONENT_ID, co';
wwv_flow_imp.g_varchar2_table(55) := 'lumn_name, old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :new.row_key, :new.event_id, ''LINK_URL_3'',';
wwv_flow_imp.g_varchar2_table(56) := ':old.LINK_URL_3,:new.LINK_URL_3);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.LINK_NAME_4,''0'') != nvl(:new.LINK_NAME_4';
wwv_flow_imp.g_varchar2_table(57) := ',''0'') then'||wwv_flow.LF||
'       insert into eba_ca_history (table_name, component_rowkey, COMPONENT_ID, column_nam';
wwv_flow_imp.g_varchar2_table(58) := 'e, old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :new.row_key, :new.event_id, ''LINK_NAME_4'',:old.LI';
wwv_flow_imp.g_varchar2_table(59) := 'NK_NAME_4,:new.LINK_NAME_4);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.LINK_URL_4,''0'') != nvl(:new.LINK_URL_4,''0'') t';
wwv_flow_imp.g_varchar2_table(60) := 'hen'||wwv_flow.LF||
'       insert into eba_ca_history (table_name, component_rowkey, COMPONENT_ID, column_name, old_';
wwv_flow_imp.g_varchar2_table(61) := 'value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :new.row_key, :new.event_id, ''LINK_URL_4'',:old.LINK_URL_4';
wwv_flow_imp.g_varchar2_table(62) := ',:new.LINK_URL_4);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.TAGS,''0'') != nvl(:new.TAGS,''0'') then'||wwv_flow.LF||
'       insert into';
wwv_flow_imp.g_varchar2_table(63) := ' eba_ca_history (table_name, component_rowkey, COMPONENT_ID, column_name, old_value, new_value) valu';
wwv_flow_imp.g_varchar2_table(64) := 'es'||wwv_flow.LF||
'       (''EVENTS'', :new.row_key, :new.event_id, ''TAGS'',:old.TAGS,:new.TAGS);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   -- time';
wwv_flow_imp.g_varchar2_table(65) := 'stamp columns'||wwv_flow.LF||
'   if (:old.EVENT_DATE_TIME is null and :new.EVENT_DATE_TIME is not null) or '||wwv_flow.LF||
'      (:';
wwv_flow_imp.g_varchar2_table(66) := 'old.EVENT_DATE_TIME is not null and :new.EVENT_DATE_TIME is null) or '||wwv_flow.LF||
'      (:old.EVENT_DATE_TIME !=';
wwv_flow_imp.g_varchar2_table(67) := ' :new.EVENT_DATE_TIME) then'||wwv_flow.LF||
'       insert into eba_ca_history (table_name, component_rowkey, COMPONE';
wwv_flow_imp.g_varchar2_table(68) := 'NT_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
'          (''EVENTS'', :new.row_key, :new.event_id, ''';
wwv_flow_imp.g_varchar2_table(69) := 'EVENT_DATE_TIME'',:old.EVENT_DATE_TIME,:new.EVENT_DATE_TIME);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end au_EBA_CA_EVENTS;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show';
wwv_flow_imp.g_varchar2_table(70) := ' errors';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3257086958997215777)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'events history trigger'
,p_sequence=>410
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
