prompt --application/deployment/install/upgrade_framework_package
begin
--   Manifest
--     INSTALL: UPGRADE-Framework Package
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace'||wwv_flow.LF||
'package eba_ca_fw as'||wwv_flow.LF||
''||wwv_flow.LF||
'    function conv_txt_html ('||wwv_flow.LF||
'        p_txt_message in varcha';
wwv_flow_imp.g_varchar2_table(2) := 'r2 )'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function conv_urls_links ('||wwv_flow.LF||
'        p_string in varchar2 )'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(3) := ' return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function tags_cleaner ('||wwv_flow.LF||
'        p_tags  in varchar2,'||wwv_flow.LF||
'        p_case  in varch';
wwv_flow_imp.g_varchar2_table(4) := 'ar2 default ''U'' )'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure tag_sync ('||wwv_flow.LF||
'        p_new_tags          in ';
wwv_flow_imp.g_varchar2_table(5) := 'varchar2,'||wwv_flow.LF||
'        p_old_tags          in varchar2,'||wwv_flow.LF||
'        p_content_type      in varchar2,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(6) := 'p_content_id        in number );'||wwv_flow.LF||
''||wwv_flow.LF||
'    function selective_escape ('||wwv_flow.LF||
'        p_text  in varchar2,'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(7) := '   p_tags  in varchar2 default ''<h2>,</h2>,<p>,</p>,<b>,</b>,<li>,</li>,<ul>,</ul>,<br />,<i>,</i>,<';
wwv_flow_imp.g_varchar2_table(8) := 'h3>,</h3>'' )'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function get_preference_value ('||wwv_flow.LF||
'        p_preference_name';
wwv_flow_imp.g_varchar2_table(9) := ' in varchar2 )'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure set_preference_value ('||wwv_flow.LF||
'        p_preference_n';
wwv_flow_imp.g_varchar2_table(10) := 'ame  in varchar2, '||wwv_flow.LF||
'        p_preference_value in varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'    function compress_int ('||wwv_flow.LF||
'        n ';
wwv_flow_imp.g_varchar2_table(11) := 'in integer )'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function apex_error_handling ('||wwv_flow.LF||
'        p_error in apex_er';
wwv_flow_imp.g_varchar2_table(12) := 'ror.t_error )'||wwv_flow.LF||
'        return apex_error.t_error_result;'||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_ca_fw;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1449117849657139110)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'Framework Package'
,p_sequence=>5
,p_script_type=>'UPGRADE'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
