prompt --application/deployment/install/upgrade_remove_eba_ca_admins_not_used
begin
--   Manifest
--     INSTALL: UPGRADE-remove eba_ca_admins (not used)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'drop table eba_ca_admins cascade constraints;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1856508651957641199)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'remove eba_ca_admins (not used)'
,p_sequence=>100
,p_script_type=>'UPGRADE'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
