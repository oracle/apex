prompt --application/deployment/install/upgrade_eba_ca_package
begin
--   Manifest
--     INSTALL: UPGRADE-eba_ca package
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_ca is '||wwv_flow.LF||
'    -----------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(2) := '--------------'||wwv_flow.LF||
'    -- Generates a unique Identifier'||wwv_flow.LF||
'    --------------------------------------------';
wwv_flow_imp.g_varchar2_table(3) := '-----------------------------'||wwv_flow.LF||
'    function gen_id return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ------------------------------';
wwv_flow_imp.g_varchar2_table(4) := '-------------------------------------------'||wwv_flow.LF||
'    -- Gets the current user''s authorization level. Can ';
wwv_flow_imp.g_varchar2_table(5) := 'depend on the following:'||wwv_flow.LF||
'    --  * If access control is currently disabled, returns highest level of';
wwv_flow_imp.g_varchar2_table(6) := ' 3.'||wwv_flow.LF||
'    --  * If access control is enabled, but user is not in list, returns 0'||wwv_flow.LF||
'    --  * If access c';
wwv_flow_imp.g_varchar2_table(7) := 'ontrol is enabled and user is in list, returns their'||wwv_flow.LF||
'    --    access level.'||wwv_flow.LF||
'    -------------------';
wwv_flow_imp.g_varchar2_table(8) := '------------------------------------------------------'||wwv_flow.LF||
'    function get_authorization_level ('||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(9) := '  p_username             varchar2)'||wwv_flow.LF||
'        return number;'||wwv_flow.LF||
'    --------------------------------------';
wwv_flow_imp.g_varchar2_table(10) := '-----------------------------------'||wwv_flow.LF||
'    -- Returns all of the restricted calendars for the given use';
wwv_flow_imp.g_varchar2_table(11) := 'r          --'||wwv_flow.LF||
'    -------------------------------------------------------------------------'||wwv_flow.LF||
'    func';
wwv_flow_imp.g_varchar2_table(12) := 'tion decode_restrictions ('||wwv_flow.LF||
'        p_user_id             number)'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
'end eba_ca';
wwv_flow_imp.g_varchar2_table(13) := ' ;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace package body eba_ca as '||wwv_flow.LF||
''||wwv_flow.LF||
'    -----------------------------------------------';
wwv_flow_imp.g_varchar2_table(14) := '--------------------------'||wwv_flow.LF||
'    -- Generates a unique Identifier'||wwv_flow.LF||
'    --------------------------------';
wwv_flow_imp.g_varchar2_table(15) := '-----------------------------------------'||wwv_flow.LF||
'    function gen_id'||wwv_flow.LF||
'        return number'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l';
wwv_flow_imp.g_varchar2_table(16) := '_id  number;'||wwv_flow.LF||
'    begin        '||wwv_flow.LF||
'        select to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(17) := 'X'')'||wwv_flow.LF||
'          into l_id'||wwv_flow.LF||
'          from dual;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'        return l_id;'||wwv_flow.LF||
'    end gen_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --------';
wwv_flow_imp.g_varchar2_table(18) := '-----------------------------------------------------------------'||wwv_flow.LF||
'    -- Gets the current user''s aut';
wwv_flow_imp.g_varchar2_table(19) := 'horization level. Depends on the following:'||wwv_flow.LF||
'    --  * If access control is currently disabled, retur';
wwv_flow_imp.g_varchar2_table(20) := 'ns highest level of 3.'||wwv_flow.LF||
'    --  * If access control is enabled, but user is not in list, returns 0'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(21) := '  --  * If access control is enabled and user is in list, returns their'||wwv_flow.LF||
'    --    access level.'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(22) := '-------------------------------------------------------------------------'||wwv_flow.LF||
'    function get_authoriza';
wwv_flow_imp.g_varchar2_table(23) := 'tion_level ('||wwv_flow.LF||
'        p_username             varchar2)'||wwv_flow.LF||
'        return number'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_access_';
wwv_flow_imp.g_varchar2_table(24) := 'level_id       eba_ca_users.access_level_id%type := 0;  -- default to lowest privilege.'||wwv_flow.LF||
'        l_ac';
wwv_flow_imp.g_varchar2_table(25) := 'count_locked        eba_ca_users.account_locked%type;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        -- If access control is disa';
wwv_flow_imp.g_varchar2_table(26) := 'bled, default to highest privilege'||wwv_flow.LF||
'        if eba_ca_fw.get_preference_value(''ACCESS_CONTROL_ENABLED';
wwv_flow_imp.g_varchar2_table(27) := ''') = ''N'' then'||wwv_flow.LF||
'            return 3;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            -- Query for user''s access level, throw';
wwv_flow_imp.g_varchar2_table(28) := 's no_data_found if no user'||wwv_flow.LF||
'            select access_level_id,'||wwv_flow.LF||
'                   account_locked'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(29) := '           into l_access_level_id,'||wwv_flow.LF||
'                   l_account_locked'||wwv_flow.LF||
'              from eba_ca_use';
wwv_flow_imp.g_varchar2_table(30) := 'rs'||wwv_flow.LF||
'             where username = p_username;'||wwv_flow.LF||
'            -- Check if user''s account is locked, retur';
wwv_flow_imp.g_varchar2_table(31) := 'n 0 (no privilege), otherwise stick'||wwv_flow.LF||
'            -- with their level.'||wwv_flow.LF||
'            if l_account_locked';
wwv_flow_imp.g_varchar2_table(32) := ' = ''Y'' then'||wwv_flow.LF||
'                return 0;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            -- Overwrite user access level';
wwv_flow_imp.g_varchar2_table(33) := ' 1 with access level 2 if access control scope is PUBLIC_CONTRIBUTE'||wwv_flow.LF||
'            if l_access_level_id';
wwv_flow_imp.g_varchar2_table(34) := ' = 1 and eba_ca_fw.get_preference_value(''ACCESS_CONTROL_SCOPE'') = ''PUBLIC_CONTRIBUTE'' then'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(35) := '       return 2;'||wwv_flow.LF||
'            end if;            '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        return l_access_level_id;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(36) := '   exception'||wwv_flow.LF||
'        when no_data_found then'||wwv_flow.LF||
'            -- If no user exists with passed username, ';
wwv_flow_imp.g_varchar2_table(37) := 'do a final check if reader access is set to any authenticated user'||wwv_flow.LF||
'            if eba_ca_fw.get_pref';
wwv_flow_imp.g_varchar2_table(38) := 'erence_value(''ACCESS_CONTROL_SCOPE'') = ''PUBLIC_CONTRIBUTE'' then'||wwv_flow.LF||
'                return 2;'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(39) := '  elsif eba_ca_fw.get_preference_value(''ACCESS_CONTROL_SCOPE'') = ''PUBLIC_READONLY'' then'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(40) := '    return 1;'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'                return 0;'||wwv_flow.LF||
'            end if;           '||wwv_flow.LF||
'    end get_';
wwv_flow_imp.g_varchar2_table(41) := 'authorization_level;'||wwv_flow.LF||
'    -------------------------------------------------------------------------'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(42) := '   -- Returns all of the restricted calendars for the given user          --'||wwv_flow.LF||
'    -------------------';
wwv_flow_imp.g_varchar2_table(43) := '------------------------------------------------------'||wwv_flow.LF||
'    function decode_restrictions ('||wwv_flow.LF||
'        p_';
wwv_flow_imp.g_varchar2_table(44) := 'user_id             number)'||wwv_flow.LF||
'        return varchar2 is'||wwv_flow.LF||
'      l_restricted_to varchar2(4000);'||wwv_flow.LF||
'      l';
wwv_flow_imp.g_varchar2_table(45) := '_calendar_id   number;'||wwv_flow.LF||
'      l_calendar_name varchar2(4000);'||wwv_flow.LF||
'      l_return        varchar2(4000);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(46) := '   begin'||wwv_flow.LF||
'null;'||wwv_flow.LF||
'/*'||wwv_flow.LF||
'      select restricted_to'||wwv_flow.LF||
'      into l_restricted_to'||wwv_flow.LF||
'      from eba_ca_users'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(47) := '  where id = p_user_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'      if l_restricted_to is null then'||wwv_flow.LF||
'        return null;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(48) := '    '||wwv_flow.LF||
'      while l_restricted_to is not null loop'||wwv_flow.LF||
'        l_calendar_id := decode(instr(l_restricted';
wwv_flow_imp.g_varchar2_table(49) := '_to, '':''), 0, l_restricted_to, substr(l_restricted_to, 1, instr(l_restricted_to, '':'') - 1));'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(50) := ' begin'||wwv_flow.LF||
'          select short_name || '' ('' || decode(public_view_yn, ''Y'', null, ''Private'') || '')'''||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(51) := '        into l_calendar_name'||wwv_flow.LF||
'          from eba_ca_calendars'||wwv_flow.LF||
'          where calendar_id = l_calenda';
wwv_flow_imp.g_varchar2_table(52) := 'r_id;'||wwv_flow.LF||
'        exception'||wwv_flow.LF||
'          when no_data_found then'||wwv_flow.LF||
'            l_calendar_name := l_calendar_';
wwv_flow_imp.g_varchar2_table(53) := 'id;'||wwv_flow.LF||
'        end;'||wwv_flow.LF||
'        '||wwv_flow.LF||
'        if l_return is null then'||wwv_flow.LF||
'          l_return := l_calendar_name;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(54) := '      elsif length(l_return) + length(l_calendar_name) + 2 > 3900 then'||wwv_flow.LF||
'          l_return := l_retur';
wwv_flow_imp.g_varchar2_table(55) := 'n || ''; ...'';'||wwv_flow.LF||
'          exit;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'          l_return := l_return || ''; '' || l_calendar_name';
wwv_flow_imp.g_varchar2_table(56) := ';'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        '||wwv_flow.LF||
'        l_restricted_to := substr(l_restricted_to, instr(l_restricted_to,';
wwv_flow_imp.g_varchar2_table(57) := ' '':'') + 1);'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'      '||wwv_flow.LF||
'      return l_return;'||wwv_flow.LF||
'    exception'||wwv_flow.LF||
'      when no_data_found the';
wwv_flow_imp.g_varchar2_table(58) := 'n'||wwv_flow.LF||
'        return null;'||wwv_flow.LF||
'*/'||wwv_flow.LF||
'    end decode_restrictions;'||wwv_flow.LF||
'end eba_ca;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1877304485343029439)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'eba_ca package'
,p_sequence=>110
,p_script_type=>'UPGRADE'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
