prompt --application/deployment/install/upgrade_more_event_colors
begin
--   Manifest
--     INSTALL: UPGRADE-More Event Colors
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'alter table EBA_CA_COLOR_PREFS add constraint'||wwv_flow.LF||
'   EBA_CA_COLOR_PREFS_UK unique (COLOR_NAME)'||wwv_flow.LF||
'/ '||wwv_flow.LF||
''||wwv_flow.LF||
'inser';
wwv_flow_imp.g_varchar2_table(2) := 't into EBA_CA_color_prefs (id, color_name, bg_color, text_color) values (6,''Black'',  ''#303030'', ''#30';
wwv_flow_imp.g_varchar2_table(3) := '3030'');'||wwv_flow.LF||
'insert into EBA_CA_color_prefs (id, color_name, bg_color, text_color) values (7,''Darkblue'', ';
wwv_flow_imp.g_varchar2_table(4) := ' ''#1F5F97'', ''#1F5F97'');'||wwv_flow.LF||
'insert into EBA_CA_color_prefs (id, color_name, bg_color, text_color) values';
wwv_flow_imp.g_varchar2_table(5) := ' (8,''Bluesky'',  ''#6BB9F0'', ''#6BB9F0'');'||wwv_flow.LF||
'insert into EBA_CA_color_prefs (id, color_name, bg_color, tex';
wwv_flow_imp.g_varchar2_table(6) := 't_color) values (9,''Brown'',  ''#D88935'', ''#D88935'');'||wwv_flow.LF||
'insert into EBA_CA_color_prefs (id, color_name, ';
wwv_flow_imp.g_varchar2_table(7) := 'bg_color, text_color) values (10,''Cyan'',  ''#1ABC9C'', ''#1ABC9C'');'||wwv_flow.LF||
'insert into EBA_CA_color_prefs (id,';
wwv_flow_imp.g_varchar2_table(8) := ' color_name, bg_color, text_color) values (11,''Lime'',  ''#28A346'', ''#28A346'');'||wwv_flow.LF||
'insert into EBA_CA_col';
wwv_flow_imp.g_varchar2_table(9) := 'or_prefs (id, color_name, bg_color, text_color) values (12,''Silver'',  ''#BDC3C7'', ''#BDC3C7'');'||wwv_flow.LF||
'insert ';
wwv_flow_imp.g_varchar2_table(10) := 'into EBA_CA_color_prefs (id, color_name, bg_color, text_color) values (13,''Yellow'',  ''#F1C40F'', ''#F1';
wwv_flow_imp.g_varchar2_table(11) := 'C40F'');'||wwv_flow.LF||
'commit;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2564607310498110518)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'More Event Colors'
,p_sequence=>50
,p_script_type=>'UPGRADE'
,p_condition_type=>'FUNCTION_BODY'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_cnt    pls_integer;',
'    l_retval boolean := true;',
'begin',
'    select count(*)',
'      into l_cnt',
'      from eba_ca_color_prefs',
'     where color_name in (''Black'', ''Darkblue'', ''Bluesky'', ''Brown'', ''Cyan'', ''Lime'', ''Silver'', ''Yellow'');',
'',
'    if l_cnt > 0 then',
'        l_retval := false;',
'    end if;',
'',
'    return l_retval;',
'end;'))
,p_condition2=>'PLSQL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
