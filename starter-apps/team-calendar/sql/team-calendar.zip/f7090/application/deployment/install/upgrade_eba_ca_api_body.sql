prompt --application/deployment/install/upgrade_eba_ca_api_body
begin
--   Manifest
--     INSTALL: UPGRADE-eba_ca_api body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body eba_ca_api '||wwv_flow.LF||
'as '||wwv_flow.LF||
'function create_series_l ( '||wwv_flow.LF||
'   p_start_date  timestam';
wwv_flow_imp.g_varchar2_table(2) := 'p with time zone, '||wwv_flow.LF||
'   p_end_date    timestamp with time zone, '||wwv_flow.LF||
'   p_recur_freq  varchar2 ) '||wwv_flow.LF||
'   retur';
wwv_flow_imp.g_varchar2_table(3) := 'n number '||wwv_flow.LF||
'is '||wwv_flow.LF||
'   l_series_id       number; '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'     '||wwv_flow.LF||
'   insert into EBA_ca_series '||wwv_flow.LF||
'      (start_';
wwv_flow_imp.g_varchar2_table(4) := 'date, end_date, recur_freq) '||wwv_flow.LF||
'   values '||wwv_flow.LF||
'      (p_start_date, p_end_date, p_recur_freq) '||wwv_flow.LF||
'   returning';
wwv_flow_imp.g_varchar2_table(5) := ' series_id into l_series_id; '||wwv_flow.LF||
'   return l_series_id; '||wwv_flow.LF||
'end create_series_l; '||wwv_flow.LF||
'procedure create_event_l';
wwv_flow_imp.g_varchar2_table(6) := ' ( '||wwv_flow.LF||
'   p_event_name       varchar2, '||wwv_flow.LF||
'   p_type_id          number, '||wwv_flow.LF||
'   p_calendar_id      number, '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(7) := '  p_event_date_time  timestamp with time zone, '||wwv_flow.LF||
'   p_duration         number, '||wwv_flow.LF||
'   p_event_desc      ';
wwv_flow_imp.g_varchar2_table(8) := ' varchar2, '||wwv_flow.LF||
'   p_contact_person   varchar2, '||wwv_flow.LF||
'   p_contact_email    varchar2, '||wwv_flow.LF||
'   p_display_time     ';
wwv_flow_imp.g_varchar2_table(9) := 'varchar2, '||wwv_flow.LF||
'   p_location         varchar2, '||wwv_flow.LF||
'   p_link_name_1      varchar2, '||wwv_flow.LF||
'   p_link_url_1       v';
wwv_flow_imp.g_varchar2_table(10) := 'archar2, '||wwv_flow.LF||
'   p_link_name_2      varchar2, '||wwv_flow.LF||
'   p_link_url_2       varchar2, '||wwv_flow.LF||
'   p_link_name_3      va';
wwv_flow_imp.g_varchar2_table(11) := 'rchar2, '||wwv_flow.LF||
'   p_link_url_3       varchar2, '||wwv_flow.LF||
'   p_series_id        number   default null, '||wwv_flow.LF||
'   p_tags   ';
wwv_flow_imp.g_varchar2_table(12) := '          varchar2 default null ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'   insert into EBA_ca_events '||wwv_flow.LF||
'      (event_name, type_';
wwv_flow_imp.g_varchar2_table(13) := 'id, calendar_id, '||wwv_flow.LF||
'       event_date_time, duration, '||wwv_flow.LF||
'       event_desc, contact_person,  '||wwv_flow.LF||
'       con';
wwv_flow_imp.g_varchar2_table(14) := 'tact_email, display_time, location, '||wwv_flow.LF||
'       link_name_1, link_url_1, '||wwv_flow.LF||
'       link_name_2, link_url_2';
wwv_flow_imp.g_varchar2_table(15) := ', '||wwv_flow.LF||
'       link_name_3, link_url_3, '||wwv_flow.LF||
'       series_id, tags) '||wwv_flow.LF||
'   values '||wwv_flow.LF||
'      (p_event_name, p_type_';
wwv_flow_imp.g_varchar2_table(16) := 'id, p_calendar_id, '||wwv_flow.LF||
'       p_event_date_time, p_duration, '||wwv_flow.LF||
'       p_event_desc, p_contact_person,  '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(17) := '       p_contact_email, p_display_time, p_location, '||wwv_flow.LF||
'       p_link_name_1, p_link_url_1, '||wwv_flow.LF||
'       p_l';
wwv_flow_imp.g_varchar2_table(18) := 'ink_name_2, p_link_url_2, '||wwv_flow.LF||
'       p_link_name_3, p_link_url_3, '||wwv_flow.LF||
'       p_series_id, p_tags ); '||wwv_flow.LF||
'end c';
wwv_flow_imp.g_varchar2_table(19) := 'reate_event_l; '||wwv_flow.LF||
'procedure create_recur_events_l ( '||wwv_flow.LF||
'   p_event_name       varchar2, '||wwv_flow.LF||
'   p_type_id    ';
wwv_flow_imp.g_varchar2_table(20) := '      number, '||wwv_flow.LF||
'   p_calendar_id      number, '||wwv_flow.LF||
'   p_event_date_time  timestamp with time zone, '||wwv_flow.LF||
'   p_';
wwv_flow_imp.g_varchar2_table(21) := 'duration         number, '||wwv_flow.LF||
'   p_event_desc       varchar2, '||wwv_flow.LF||
'   p_contact_person   varchar2, '||wwv_flow.LF||
'   p_con';
wwv_flow_imp.g_varchar2_table(22) := 'tact_email    varchar2, '||wwv_flow.LF||
'   p_display_time     varchar2, '||wwv_flow.LF||
'   p_location         varchar2, '||wwv_flow.LF||
'   p_link';
wwv_flow_imp.g_varchar2_table(23) := '_name_1      varchar2, '||wwv_flow.LF||
'   p_link_url_1       varchar2, '||wwv_flow.LF||
'   p_link_name_2      varchar2, '||wwv_flow.LF||
'   p_link_';
wwv_flow_imp.g_varchar2_table(24) := 'url_2       varchar2, '||wwv_flow.LF||
'   p_link_name_3      varchar2, '||wwv_flow.LF||
'   p_link_url_3       varchar2, '||wwv_flow.LF||
'   p_series';
wwv_flow_imp.g_varchar2_table(25) := '_id        number, '||wwv_flow.LF||
'   p_tags             varchar2 default null ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'   l_cnt              number;';
wwv_flow_imp.g_varchar2_table(26) := ' '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'   for c1 in ( '||wwv_flow.LF||
'      select start_date, end_date, recur_freq '||wwv_flow.LF||
'        from EBA_ca_series '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(27) := '       where series_id = p_series_id ) '||wwv_flow.LF||
'   loop '||wwv_flow.LF||
'      if c1.recur_freq = ''D'' then '||wwv_flow.LF||
'--         l_cnt';
wwv_flow_imp.g_varchar2_table(28) := ' := c1.end_date - c1.start_date; '||wwv_flow.LF||
'         l_cnt := trunc(to_number(substr((c1.end_date-c1.start_dat';
wwv_flow_imp.g_varchar2_table(29) := 'e),1,instr(c1.end_date-c1.start_date,'' '')))); '||wwv_flow.LF||
'         for i in 0..l_cnt loop '||wwv_flow.LF||
'            create_e';
wwv_flow_imp.g_varchar2_table(30) := 'vent_l ( '||wwv_flow.LF||
'               p_event_name      => p_event_name, '||wwv_flow.LF||
'               p_type_id         => p_t';
wwv_flow_imp.g_varchar2_table(31) := 'ype_id, '||wwv_flow.LF||
'               p_calendar_id     => p_calendar_id, '||wwv_flow.LF||
'               p_event_date_time => p_e';
wwv_flow_imp.g_varchar2_table(32) := 'vent_date_time + i, '||wwv_flow.LF||
'               p_duration        => p_duration, '||wwv_flow.LF||
'               p_event_desc   ';
wwv_flow_imp.g_varchar2_table(33) := '   => p_event_desc, '||wwv_flow.LF||
'               p_contact_person  => p_contact_person, '||wwv_flow.LF||
'               p_contact';
wwv_flow_imp.g_varchar2_table(34) := '_email   => p_contact_email, '||wwv_flow.LF||
'               p_display_time    => p_display_time, '||wwv_flow.LF||
'               p_';
wwv_flow_imp.g_varchar2_table(35) := 'location        => p_location, '||wwv_flow.LF||
'               p_link_name_1     => p_link_name_1, '||wwv_flow.LF||
'               p';
wwv_flow_imp.g_varchar2_table(36) := '_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'               p_link_name_2     => p_link_name_2, '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(37) := '  p_link_url_2      => p_link_url_2, '||wwv_flow.LF||
'               p_link_name_3     => p_link_name_3, '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(38) := '     p_link_url_3      => p_link_url_3, '||wwv_flow.LF||
'               p_series_id       => p_series_id, '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(39) := '      p_tags            => p_tags ); '||wwv_flow.LF||
'         end loop; '||wwv_flow.LF||
'      elsif c1.recur_freq = ''WD'' then '||wwv_flow.LF||
'-- ';
wwv_flow_imp.g_varchar2_table(40) := '        l_cnt := c1.end_date - c1.start_date; '||wwv_flow.LF||
'         l_cnt := trunc(to_number(substr((c1.end_date';
wwv_flow_imp.g_varchar2_table(41) := '-c1.start_date),1,instr(c1.end_date-c1.start_date,'' '')))); '||wwv_flow.LF||
'         for i in 0..l_cnt loop '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(42) := '     if to_char(p_event_date_time + i,''DY'') not in (''SAT'',''SUN'') then '||wwv_flow.LF||
'               create_event_l';
wwv_flow_imp.g_varchar2_table(43) := ' ( '||wwv_flow.LF||
'                  p_event_name      => p_event_name, '||wwv_flow.LF||
'                  p_type_id         => p_t';
wwv_flow_imp.g_varchar2_table(44) := 'ype_id, '||wwv_flow.LF||
'                  p_calendar_id     => p_calendar_id, '||wwv_flow.LF||
'                  p_event_date_time ';
wwv_flow_imp.g_varchar2_table(45) := '=> p_event_date_time + i, '||wwv_flow.LF||
'                  p_duration        => p_duration, '||wwv_flow.LF||
'                  p_e';
wwv_flow_imp.g_varchar2_table(46) := 'vent_desc      => p_event_desc, '||wwv_flow.LF||
'                  p_contact_person  => p_contact_person, '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(47) := '         p_contact_email   => p_contact_email, '||wwv_flow.LF||
'                  p_display_time    => p_display_tim';
wwv_flow_imp.g_varchar2_table(48) := 'e, '||wwv_flow.LF||
'                  p_location        => p_location, '||wwv_flow.LF||
'                  p_link_name_1     => p_lin';
wwv_flow_imp.g_varchar2_table(49) := 'k_name_1, '||wwv_flow.LF||
'                  p_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'                  p_link_name_2    ';
wwv_flow_imp.g_varchar2_table(50) := ' => p_link_name_2, '||wwv_flow.LF||
'                  p_link_url_2      => p_link_url_2, '||wwv_flow.LF||
'                  p_link_n';
wwv_flow_imp.g_varchar2_table(51) := 'ame_3     => p_link_name_3, '||wwv_flow.LF||
'                  p_link_url_3      => p_link_url_3, '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(52) := ' p_series_id       => p_series_id, '||wwv_flow.LF||
'                  p_tags            => p_tags ); '||wwv_flow.LF||
'            en';
wwv_flow_imp.g_varchar2_table(53) := 'd if; '||wwv_flow.LF||
'         end loop; '||wwv_flow.LF||
'      elsif c1.recur_freq = ''W'' then '||wwv_flow.LF||
'--         l_cnt := trunc((c1.end_d';
wwv_flow_imp.g_varchar2_table(54) := 'ate - c1.start_date)/7); '||wwv_flow.LF||
'         l_cnt := trunc(to_number(substr((c1.end_date-c1.start_date),1,ins';
wwv_flow_imp.g_varchar2_table(55) := 'tr(c1.end_date-c1.start_date,'' '')))/7); '||wwv_flow.LF||
'         for i in 0..l_cnt loop '||wwv_flow.LF||
'            create_event_l';
wwv_flow_imp.g_varchar2_table(56) := ' ( '||wwv_flow.LF||
'               p_event_name      => p_event_name, '||wwv_flow.LF||
'               p_type_id         => p_type_id';
wwv_flow_imp.g_varchar2_table(57) := ', '||wwv_flow.LF||
'               p_calendar_id     => p_calendar_id, '||wwv_flow.LF||
'               p_event_date_time => p_event_d';
wwv_flow_imp.g_varchar2_table(58) := 'ate_time + (i*7), '||wwv_flow.LF||
'               p_duration        => p_duration, '||wwv_flow.LF||
'               p_event_desc     ';
wwv_flow_imp.g_varchar2_table(59) := ' => p_event_desc, '||wwv_flow.LF||
'               p_contact_person  => p_contact_person, '||wwv_flow.LF||
'               p_contact_e';
wwv_flow_imp.g_varchar2_table(60) := 'mail   => p_contact_email, '||wwv_flow.LF||
'               p_display_time    => p_display_time, '||wwv_flow.LF||
'               p_lo';
wwv_flow_imp.g_varchar2_table(61) := 'cation        => p_location, '||wwv_flow.LF||
'               p_link_name_1     => p_link_name_1, '||wwv_flow.LF||
'               p_l';
wwv_flow_imp.g_varchar2_table(62) := 'ink_url_1      => p_link_url_1, '||wwv_flow.LF||
'               p_link_name_2     => p_link_name_2, '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(63) := 'p_link_url_2      => p_link_url_2, '||wwv_flow.LF||
'               p_link_name_3     => p_link_name_3, '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(64) := '   p_link_url_3      => p_link_url_3, '||wwv_flow.LF||
'               p_series_id       => p_series_id, '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(65) := '    p_tags            => p_tags ); '||wwv_flow.LF||
'         end loop; '||wwv_flow.LF||
'      elsif c1.recur_freq = ''2W'' then '||wwv_flow.LF||
'--   ';
wwv_flow_imp.g_varchar2_table(66) := '      l_cnt := trunc((c1.end_date - c1.start_date)/14); '||wwv_flow.LF||
'         l_cnt := trunc(to_number(substr((c';
wwv_flow_imp.g_varchar2_table(67) := '1.end_date-c1.start_date),1,instr(c1.end_date-c1.start_date,'' '')))/14); '||wwv_flow.LF||
'         for i in 0..l_cnt ';
wwv_flow_imp.g_varchar2_table(68) := 'loop '||wwv_flow.LF||
'            create_event_l ( '||wwv_flow.LF||
'               p_event_name      => p_event_name, '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(69) := '  p_type_id         => p_type_id, '||wwv_flow.LF||
'               p_calendar_id     => p_calendar_id, '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(70) := '  p_event_date_time => p_event_date_time + (i*14), '||wwv_flow.LF||
'               p_duration        => p_duration, ';
wwv_flow_imp.g_varchar2_table(71) := ''||wwv_flow.LF||
'               p_event_desc      => p_event_desc, '||wwv_flow.LF||
'               p_contact_person  => p_contact_pe';
wwv_flow_imp.g_varchar2_table(72) := 'rson, '||wwv_flow.LF||
'               p_contact_email   => p_contact_email, '||wwv_flow.LF||
'               p_display_time    => p_d';
wwv_flow_imp.g_varchar2_table(73) := 'isplay_time, '||wwv_flow.LF||
'               p_location        => p_location, '||wwv_flow.LF||
'               p_link_name_1     => p';
wwv_flow_imp.g_varchar2_table(74) := '_link_name_1, '||wwv_flow.LF||
'               p_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'               p_link_name_2     =';
wwv_flow_imp.g_varchar2_table(75) := '> p_link_name_2, '||wwv_flow.LF||
'               p_link_url_2      => p_link_url_2, '||wwv_flow.LF||
'               p_link_name_3   ';
wwv_flow_imp.g_varchar2_table(76) := '  => p_link_name_3, '||wwv_flow.LF||
'               p_link_url_3      => p_link_url_3, '||wwv_flow.LF||
'               p_series_id  ';
wwv_flow_imp.g_varchar2_table(77) := '     => p_series_id, '||wwv_flow.LF||
'               p_tags            => p_tags ); '||wwv_flow.LF||
'         end loop; '||wwv_flow.LF||
'      elsif';
wwv_flow_imp.g_varchar2_table(78) := ' c1.recur_freq = ''M'' then '||wwv_flow.LF||
'         l_cnt := trunc(months_between(to_date(to_char(c1.end_date,''DD-MO';
wwv_flow_imp.g_varchar2_table(79) := 'N-RRRR''),''DD-MON-RRRR''),  '||wwv_flow.LF||
'                                       to_date(to_char(c1.start_date,''DD-';
wwv_flow_imp.g_varchar2_table(80) := 'MON-RRRR''),''DD-MON-RRRR''))); '||wwv_flow.LF||
'         for i in 0..l_cnt loop '||wwv_flow.LF||
'            create_event_l ( '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(81) := '        p_event_name      => p_event_name, '||wwv_flow.LF||
'               p_type_id         => p_type_id, '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(82) := '       p_calendar_id     => p_calendar_id, '||wwv_flow.LF||
'               p_event_date_time => add_months(p_event_d';
wwv_flow_imp.g_varchar2_table(83) := 'ate_time,i), '||wwv_flow.LF||
'               p_duration        => p_duration, '||wwv_flow.LF||
'               p_event_desc      => p';
wwv_flow_imp.g_varchar2_table(84) := '_event_desc, '||wwv_flow.LF||
'               p_contact_person  => p_contact_person, '||wwv_flow.LF||
'               p_contact_email ';
wwv_flow_imp.g_varchar2_table(85) := '  => p_contact_email, '||wwv_flow.LF||
'               p_display_time    => p_display_time, '||wwv_flow.LF||
'               p_locatio';
wwv_flow_imp.g_varchar2_table(86) := 'n        => p_location, '||wwv_flow.LF||
'               p_link_name_1     => p_link_name_1, '||wwv_flow.LF||
'               p_link_u';
wwv_flow_imp.g_varchar2_table(87) := 'rl_1      => p_link_url_1, '||wwv_flow.LF||
'               p_link_name_2     => p_link_name_2, '||wwv_flow.LF||
'               p_lin';
wwv_flow_imp.g_varchar2_table(88) := 'k_url_2      => p_link_url_2, '||wwv_flow.LF||
'               p_link_name_3     => p_link_name_3, '||wwv_flow.LF||
'               p_';
wwv_flow_imp.g_varchar2_table(89) := 'link_url_3      => p_link_url_3, '||wwv_flow.LF||
'               p_series_id       => p_series_id, '||wwv_flow.LF||
'               p';
wwv_flow_imp.g_varchar2_table(90) := '_tags            => p_tags ); '||wwv_flow.LF||
'         end loop; '||wwv_flow.LF||
'      elsif c1.recur_freq = ''Q'' then '||wwv_flow.LF||
'         l_';
wwv_flow_imp.g_varchar2_table(91) := 'cnt := trunc(months_between(to_date(to_char(c1.end_date,''DD-MON-RRRR''),''DD-MON-RRRR''),  '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(92) := '                            to_date(to_char(c1.start_date,''DD-MON-RRRR''),''DD-MON-RRRR''))/3); '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(93) := '   for i in 0..l_cnt loop '||wwv_flow.LF||
'            create_event_l ( '||wwv_flow.LF||
'               p_event_name      => p_event';
wwv_flow_imp.g_varchar2_table(94) := '_name, '||wwv_flow.LF||
'               p_type_id         => p_type_id, '||wwv_flow.LF||
'               p_calendar_id     => p_calend';
wwv_flow_imp.g_varchar2_table(95) := 'ar_id, '||wwv_flow.LF||
'               p_event_date_time => add_months(p_event_date_time,i*3), '||wwv_flow.LF||
'               p_dur';
wwv_flow_imp.g_varchar2_table(96) := 'ation        => p_duration, '||wwv_flow.LF||
'               p_event_desc      => p_event_desc, '||wwv_flow.LF||
'               p_con';
wwv_flow_imp.g_varchar2_table(97) := 'tact_person  => p_contact_person, '||wwv_flow.LF||
'               p_contact_email   => p_contact_email, '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(98) := '    p_display_time    => p_display_time, '||wwv_flow.LF||
'               p_location        => p_location, '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(99) := '      p_link_name_1     => p_link_name_1, '||wwv_flow.LF||
'               p_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(100) := '         p_link_name_2     => p_link_name_2, '||wwv_flow.LF||
'               p_link_url_2      => p_link_url_2, '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(101) := '            p_link_name_3     => p_link_name_3, '||wwv_flow.LF||
'               p_link_url_3      => p_link_url_3, '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(102) := '               p_series_id       => p_series_id, '||wwv_flow.LF||
'               p_tags            => p_tags ); '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(103) := '      end loop; '||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'   end loop; '||wwv_flow.LF||
'end create_recur_events_l; '||wwv_flow.LF||
'procedure create_more_recu';
wwv_flow_imp.g_varchar2_table(104) := 'r_events_l ( '||wwv_flow.LF||
'   p_event_name            varchar2, '||wwv_flow.LF||
'   p_type_id               number, '||wwv_flow.LF||
'   p_calenda';
wwv_flow_imp.g_varchar2_table(105) := 'r_id           number, '||wwv_flow.LF||
'   p_last_event_date_time  timestamp with time zone, '||wwv_flow.LF||
'   p_duration         ';
wwv_flow_imp.g_varchar2_table(106) := '     number, '||wwv_flow.LF||
'   p_event_desc            varchar2, '||wwv_flow.LF||
'   p_contact_person        varchar2, '||wwv_flow.LF||
'   p_conta';
wwv_flow_imp.g_varchar2_table(107) := 'ct_email         varchar2, '||wwv_flow.LF||
'   p_display_time          varchar2, '||wwv_flow.LF||
'   p_location              varchar';
wwv_flow_imp.g_varchar2_table(108) := '2, '||wwv_flow.LF||
'   p_link_name_1           varchar2, '||wwv_flow.LF||
'   p_link_url_1            varchar2, '||wwv_flow.LF||
'   p_link_name_2    ';
wwv_flow_imp.g_varchar2_table(109) := '       varchar2, '||wwv_flow.LF||
'   p_link_url_2            varchar2, '||wwv_flow.LF||
'   p_link_name_3           varchar2, '||wwv_flow.LF||
'   p_l';
wwv_flow_imp.g_varchar2_table(110) := 'ink_url_3            varchar2, '||wwv_flow.LF||
'   p_series_id             number, '||wwv_flow.LF||
'   p_tags                  varch';
wwv_flow_imp.g_varchar2_table(111) := 'ar2 default null ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'   l_begin_date            timestamp with time zone; '||wwv_flow.LF||
'   l_cnt              ';
wwv_flow_imp.g_varchar2_table(112) := '     number; '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'   l_begin_date := to_date(to_char(p_last_event_date_time,''DD-MON-RRRR''),''DD-MO';
wwv_flow_imp.g_varchar2_table(113) := 'N-RRRR'')+1; '||wwv_flow.LF||
'   for c1 in ( '||wwv_flow.LF||
'      select end_date, recur_freq '||wwv_flow.LF||
'        from EBA_ca_series '||wwv_flow.LF||
'       w';
wwv_flow_imp.g_varchar2_table(114) := 'here series_id = p_series_id ) '||wwv_flow.LF||
'   loop '||wwv_flow.LF||
'      if c1.recur_freq = ''D'' then '||wwv_flow.LF||
'         l_cnt := trunc(';
wwv_flow_imp.g_varchar2_table(115) := 'to_number(substr((c1.end_date-l_begin_date),1,instr(c1.end_date-l_begin_date,'' '')))); '||wwv_flow.LF||
'         for ';
wwv_flow_imp.g_varchar2_table(116) := 'i in 1..l_cnt loop '||wwv_flow.LF||
'            create_event_l ( '||wwv_flow.LF||
'               p_event_name      => p_event_name, ';
wwv_flow_imp.g_varchar2_table(117) := ''||wwv_flow.LF||
'               p_type_id         => p_type_id, '||wwv_flow.LF||
'               p_calendar_id     => p_calendar_id, ';
wwv_flow_imp.g_varchar2_table(118) := ''||wwv_flow.LF||
'               p_event_date_time => p_last_event_date_time + i, '||wwv_flow.LF||
'               p_duration        =';
wwv_flow_imp.g_varchar2_table(119) := '> p_duration, '||wwv_flow.LF||
'               p_event_desc      => p_event_desc, '||wwv_flow.LF||
'               p_contact_person  =';
wwv_flow_imp.g_varchar2_table(120) := '> p_contact_person, '||wwv_flow.LF||
'               p_contact_email   => p_contact_email, '||wwv_flow.LF||
'               p_display_';
wwv_flow_imp.g_varchar2_table(121) := 'time    => p_display_time, '||wwv_flow.LF||
'               p_location        => p_location, '||wwv_flow.LF||
'               p_link_n';
wwv_flow_imp.g_varchar2_table(122) := 'ame_1     => p_link_name_1, '||wwv_flow.LF||
'               p_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'               p_lin';
wwv_flow_imp.g_varchar2_table(123) := 'k_name_2     => p_link_name_2, '||wwv_flow.LF||
'               p_link_url_2      => p_link_url_2, '||wwv_flow.LF||
'               p_';
wwv_flow_imp.g_varchar2_table(124) := 'link_name_3     => p_link_name_3, '||wwv_flow.LF||
'               p_link_url_3      => p_link_url_3, '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(125) := ' p_series_id       => p_series_id, '||wwv_flow.LF||
'               p_tags            => p_tags ); '||wwv_flow.LF||
'         end loop';
wwv_flow_imp.g_varchar2_table(126) := '; '||wwv_flow.LF||
'      elsif c1.recur_freq = ''WD'' then '||wwv_flow.LF||
'         l_cnt := trunc(to_number(substr((c1.end_date-l_be';
wwv_flow_imp.g_varchar2_table(127) := 'gin_date),1,instr(c1.end_date-l_begin_date,'' '')))); '||wwv_flow.LF||
'         for i in 1..l_cnt loop '||wwv_flow.LF||
'            if';
wwv_flow_imp.g_varchar2_table(128) := ' to_char(p_last_event_date_time + i,''DY'') not in (''SAT'',''SUN'') then '||wwv_flow.LF||
'               create_event_l (';
wwv_flow_imp.g_varchar2_table(129) := ' '||wwv_flow.LF||
'                  p_event_name      => p_event_name, '||wwv_flow.LF||
'                  p_type_id         => p_typ';
wwv_flow_imp.g_varchar2_table(130) := 'e_id, '||wwv_flow.LF||
'                  p_calendar_id     => p_calendar_id, '||wwv_flow.LF||
'                  p_event_date_time =>';
wwv_flow_imp.g_varchar2_table(131) := ' p_last_event_date_time + i, '||wwv_flow.LF||
'                  p_duration        => p_duration, '||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(132) := 'p_event_desc      => p_event_desc, '||wwv_flow.LF||
'                  p_contact_person  => p_contact_person, '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(133) := '            p_contact_email   => p_contact_email, '||wwv_flow.LF||
'                  p_display_time    => p_display_';
wwv_flow_imp.g_varchar2_table(134) := 'time, '||wwv_flow.LF||
'                  p_location        => p_location, '||wwv_flow.LF||
'                  p_link_name_1     => p_';
wwv_flow_imp.g_varchar2_table(135) := 'link_name_1, '||wwv_flow.LF||
'                  p_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'                  p_link_name_2 ';
wwv_flow_imp.g_varchar2_table(136) := '    => p_link_name_2, '||wwv_flow.LF||
'                  p_link_url_2      => p_link_url_2, '||wwv_flow.LF||
'                  p_lin';
wwv_flow_imp.g_varchar2_table(137) := 'k_name_3     => p_link_name_3, '||wwv_flow.LF||
'                  p_link_url_3      => p_link_url_3, '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(138) := '    p_series_id       => p_series_id, '||wwv_flow.LF||
'                  p_tags            => p_tags); '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(139) := 'end if; '||wwv_flow.LF||
'         end loop; '||wwv_flow.LF||
'      elsif c1.recur_freq = ''W'' then '||wwv_flow.LF||
'         l_cnt := trunc(to_number';
wwv_flow_imp.g_varchar2_table(140) := '(substr((c1.end_date-l_begin_date),1,instr(c1.end_date-l_begin_date,'' '')))/7); '||wwv_flow.LF||
'         for i in 1.';
wwv_flow_imp.g_varchar2_table(141) := '.l_cnt loop '||wwv_flow.LF||
'            create_event_l ( '||wwv_flow.LF||
'               p_event_name      => p_event_name, '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(142) := '         p_type_id         => p_type_id, '||wwv_flow.LF||
'               p_calendar_id     => p_calendar_id, '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(143) := '         p_event_date_time => p_last_event_date_time + (i*7), '||wwv_flow.LF||
'               p_duration        => p';
wwv_flow_imp.g_varchar2_table(144) := '_duration, '||wwv_flow.LF||
'               p_event_desc      => p_event_desc, '||wwv_flow.LF||
'               p_contact_person  => p';
wwv_flow_imp.g_varchar2_table(145) := '_contact_person, '||wwv_flow.LF||
'               p_contact_email   => p_contact_email, '||wwv_flow.LF||
'               p_display_tim';
wwv_flow_imp.g_varchar2_table(146) := 'e    => p_display_time, '||wwv_flow.LF||
'               p_location        => p_location, '||wwv_flow.LF||
'               p_link_name';
wwv_flow_imp.g_varchar2_table(147) := '_1     => p_link_name_1, '||wwv_flow.LF||
'               p_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'               p_link_n';
wwv_flow_imp.g_varchar2_table(148) := 'ame_2     => p_link_name_2, '||wwv_flow.LF||
'               p_link_url_2      => p_link_url_2, '||wwv_flow.LF||
'               p_lin';
wwv_flow_imp.g_varchar2_table(149) := 'k_name_3     => p_link_name_3, '||wwv_flow.LF||
'               p_link_url_3      => p_link_url_3, '||wwv_flow.LF||
'               p_';
wwv_flow_imp.g_varchar2_table(150) := 'series_id       => p_series_id, '||wwv_flow.LF||
'               p_tags            => p_tags ); '||wwv_flow.LF||
'         end loop; '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(151) := '      elsif c1.recur_freq = ''2W'' then '||wwv_flow.LF||
'         l_cnt := trunc(to_number(substr((c1.end_date-l_begin';
wwv_flow_imp.g_varchar2_table(152) := '_date),1,instr(c1.end_date-l_begin_date,'' '')))/14); '||wwv_flow.LF||
'         for i in 1..l_cnt loop '||wwv_flow.LF||
'            cr';
wwv_flow_imp.g_varchar2_table(153) := 'eate_event_l ( '||wwv_flow.LF||
'               p_event_name      => p_event_name, '||wwv_flow.LF||
'               p_type_id         ';
wwv_flow_imp.g_varchar2_table(154) := '=> p_type_id, '||wwv_flow.LF||
'               p_calendar_id     => p_calendar_id, '||wwv_flow.LF||
'               p_event_date_time ';
wwv_flow_imp.g_varchar2_table(155) := '=> p_last_event_date_time + (i*14), '||wwv_flow.LF||
'               p_duration        => p_duration, '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(156) := ' p_event_desc      => p_event_desc, '||wwv_flow.LF||
'               p_contact_person  => p_contact_person, '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(157) := '       p_contact_email   => p_contact_email, '||wwv_flow.LF||
'               p_display_time    => p_display_time, '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(158) := '              p_location        => p_location, '||wwv_flow.LF||
'               p_link_name_1     => p_link_name_1, '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(159) := '               p_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'               p_link_name_2     => p_link_name_2';
wwv_flow_imp.g_varchar2_table(160) := ', '||wwv_flow.LF||
'               p_link_url_2      => p_link_url_2, '||wwv_flow.LF||
'               p_link_name_3     => p_link_nam';
wwv_flow_imp.g_varchar2_table(161) := 'e_3, '||wwv_flow.LF||
'               p_link_url_3      => p_link_url_3, '||wwv_flow.LF||
'               p_series_id       => p_serie';
wwv_flow_imp.g_varchar2_table(162) := 's_id, '||wwv_flow.LF||
'               p_tags            => p_tags ); '||wwv_flow.LF||
'         end loop; '||wwv_flow.LF||
'      elsif c1.recur_freq ';
wwv_flow_imp.g_varchar2_table(163) := '= ''M'' then '||wwv_flow.LF||
'         l_cnt := trunc(months_between(to_date(to_char(c1.end_date,''DD-MON-RRRR''),''DD-MO';
wwv_flow_imp.g_varchar2_table(164) := 'N-RRRR''),  '||wwv_flow.LF||
'                                       to_date(to_char(l_begin_date,''DD-MON-RRRR''),''DD-M';
wwv_flow_imp.g_varchar2_table(165) := 'ON-RRRR''))); '||wwv_flow.LF||
'         for i in 1..l_cnt loop '||wwv_flow.LF||
'            create_event_l ( '||wwv_flow.LF||
'               p_event_';
wwv_flow_imp.g_varchar2_table(166) := 'name      => p_event_name, '||wwv_flow.LF||
'               p_type_id         => p_type_id, '||wwv_flow.LF||
'               p_calenda';
wwv_flow_imp.g_varchar2_table(167) := 'r_id     => p_calendar_id, '||wwv_flow.LF||
'               p_event_date_time => add_months(p_last_event_date_time,i)';
wwv_flow_imp.g_varchar2_table(168) := ', '||wwv_flow.LF||
'               p_duration        => p_duration, '||wwv_flow.LF||
'               p_event_desc      => p_event_desc';
wwv_flow_imp.g_varchar2_table(169) := ', '||wwv_flow.LF||
'               p_contact_person  => p_contact_person, '||wwv_flow.LF||
'               p_contact_email   => p_cont';
wwv_flow_imp.g_varchar2_table(170) := 'act_email, '||wwv_flow.LF||
'               p_display_time    => p_display_time, '||wwv_flow.LF||
'               p_location        =>';
wwv_flow_imp.g_varchar2_table(171) := ' p_location, '||wwv_flow.LF||
'               p_link_name_1     => p_link_name_1, '||wwv_flow.LF||
'               p_link_url_1      =';
wwv_flow_imp.g_varchar2_table(172) := '> p_link_url_1, '||wwv_flow.LF||
'               p_link_name_2     => p_link_name_2, '||wwv_flow.LF||
'               p_link_url_2    ';
wwv_flow_imp.g_varchar2_table(173) := '  => p_link_url_2, '||wwv_flow.LF||
'               p_link_name_3     => p_link_name_3, '||wwv_flow.LF||
'               p_link_url_3 ';
wwv_flow_imp.g_varchar2_table(174) := '     => p_link_url_3, '||wwv_flow.LF||
'               p_series_id       => p_series_id, '||wwv_flow.LF||
'               p_tags      ';
wwv_flow_imp.g_varchar2_table(175) := '      => p_tags ); '||wwv_flow.LF||
'         end loop; '||wwv_flow.LF||
'      elsif c1.recur_freq = ''Q'' then '||wwv_flow.LF||
'         l_cnt := trun';
wwv_flow_imp.g_varchar2_table(176) := 'c(months_between(to_date(to_char(c1.end_date,''DD-MON-RRRR''),''DD-MON-RRRR''),  '||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(177) := '                 to_date(to_char(l_begin_date,''DD-MON-RRRR''),''DD-MON-RRRR''))/3); '||wwv_flow.LF||
'         for i in ';
wwv_flow_imp.g_varchar2_table(178) := '1..l_cnt loop '||wwv_flow.LF||
'            create_event_l ( '||wwv_flow.LF||
'               p_event_name      => p_event_name, '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(179) := '           p_type_id         => p_type_id, '||wwv_flow.LF||
'               p_calendar_id     => p_calendar_id, '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(180) := '           p_event_date_time => add_months(p_last_event_date_time,i*3), '||wwv_flow.LF||
'               p_duration  ';
wwv_flow_imp.g_varchar2_table(181) := '      => p_duration, '||wwv_flow.LF||
'               p_event_desc      => p_event_desc, '||wwv_flow.LF||
'               p_contact_pe';
wwv_flow_imp.g_varchar2_table(182) := 'rson  => p_contact_person, '||wwv_flow.LF||
'               p_contact_email   => p_contact_email, '||wwv_flow.LF||
'               p_d';
wwv_flow_imp.g_varchar2_table(183) := 'isplay_time    => p_display_time, '||wwv_flow.LF||
'               p_location        => p_location, '||wwv_flow.LF||
'               p';
wwv_flow_imp.g_varchar2_table(184) := '_link_name_1     => p_link_name_1, '||wwv_flow.LF||
'               p_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(185) := '  p_link_name_2     => p_link_name_2, '||wwv_flow.LF||
'               p_link_url_2      => p_link_url_2, '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(186) := '     p_link_name_3     => p_link_name_3, '||wwv_flow.LF||
'               p_link_url_3      => p_link_url_3, '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(187) := '        p_series_id       => p_series_id, '||wwv_flow.LF||
'               p_tags            => p_tags ); '||wwv_flow.LF||
'         e';
wwv_flow_imp.g_varchar2_table(188) := 'nd loop; '||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'   end loop; '||wwv_flow.LF||
'end create_more_recur_events_l; '||wwv_flow.LF||
'procedure delete_event_l ( '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(189) := '   p_event_id  number ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'   delete from EBA_ca_events '||wwv_flow.LF||
'    where event_id = p_event_id; '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(190) := 'end delete_event_l; '||wwv_flow.LF||
'procedure delete_series_l ( '||wwv_flow.LF||
'   p_series_id  number ) '||wwv_flow.LF||
'is  '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'   delete fr';
wwv_flow_imp.g_varchar2_table(191) := 'om EBA_ca_series '||wwv_flow.LF||
'    where series_id = p_series_id; '||wwv_flow.LF||
'end delete_series_l; '||wwv_flow.LF||
'procedure clear_series_l';
wwv_flow_imp.g_varchar2_table(192) := ' ( '||wwv_flow.LF||
'   p_series_id  number ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'   update EBA_ca_events '||wwv_flow.LF||
'      set series_id = null '||wwv_flow.LF||
'    wh';
wwv_flow_imp.g_varchar2_table(193) := 'ere series_id = p_series_id; '||wwv_flow.LF||
'end clear_series_l; '||wwv_flow.LF||
'procedure update_series_end_date_l ( '||wwv_flow.LF||
'   p_series';
wwv_flow_imp.g_varchar2_table(194) := '_id  number, '||wwv_flow.LF||
'   p_end_date   timestamp with time zone ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'   update EBA_ca_series '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(195) := 'set end_date = p_end_date '||wwv_flow.LF||
'    where series_id = p_series_id; '||wwv_flow.LF||
'end update_series_end_date_l; '||wwv_flow.LF||
'proced';
wwv_flow_imp.g_varchar2_table(196) := 'ure update_event_l ( '||wwv_flow.LF||
'   p_event_id         number, '||wwv_flow.LF||
'   p_event_name       varchar2, '||wwv_flow.LF||
'   p_type_id  ';
wwv_flow_imp.g_varchar2_table(197) := '        number, '||wwv_flow.LF||
'   p_calendar_id      number, '||wwv_flow.LF||
'   p_event_date_time  timestamp with time zone, '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(198) := 'p_duration         number, '||wwv_flow.LF||
'   p_event_desc       varchar2, '||wwv_flow.LF||
'   p_contact_person   varchar2, '||wwv_flow.LF||
'   p_c';
wwv_flow_imp.g_varchar2_table(199) := 'ontact_email    varchar2, '||wwv_flow.LF||
'   p_display_time     varchar2, '||wwv_flow.LF||
'   p_location         varchar2, '||wwv_flow.LF||
'   p_li';
wwv_flow_imp.g_varchar2_table(200) := 'nk_name_1      varchar2, '||wwv_flow.LF||
'   p_link_url_1       varchar2, '||wwv_flow.LF||
'   p_link_name_2      varchar2, '||wwv_flow.LF||
'   p_lin';
wwv_flow_imp.g_varchar2_table(201) := 'k_url_2       varchar2, '||wwv_flow.LF||
'   p_link_name_3      varchar2, '||wwv_flow.LF||
'   p_link_url_3       varchar2, '||wwv_flow.LF||
'   p_seri';
wwv_flow_imp.g_varchar2_table(202) := 'es_id        number  default null, '||wwv_flow.LF||
'   p_tags             varchar2  default null  ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'   f';
wwv_flow_imp.g_varchar2_table(203) := 'or c1 in ( '||wwv_flow.LF||
'      select event_name, type_id, calendar_id, '||wwv_flow.LF||
'             event_date_time, duration, ';
wwv_flow_imp.g_varchar2_table(204) := ''||wwv_flow.LF||
'             event_desc, contact_person,  '||wwv_flow.LF||
'             contact_email, display_time, location, '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(205) := '          link_name_1, link_url_1, '||wwv_flow.LF||
'             link_name_2, link_url_2, '||wwv_flow.LF||
'             link_name_3,';
wwv_flow_imp.g_varchar2_table(206) := ' link_url_3, '||wwv_flow.LF||
'             series_id, '||wwv_flow.LF||
'             tags '||wwv_flow.LF||
'        from EBA_ca_events '||wwv_flow.LF||
'       where e';
wwv_flow_imp.g_varchar2_table(207) := 'vent_id = p_event_id ) '||wwv_flow.LF||
'   loop '||wwv_flow.LF||
'      if c1.event_name != p_event_name then '||wwv_flow.LF||
'         update EBA_ca';
wwv_flow_imp.g_varchar2_table(208) := '_events '||wwv_flow.LF||
'            set event_name = p_event_name '||wwv_flow.LF||
'          where event_id = p_event_id; '||wwv_flow.LF||
'      en';
wwv_flow_imp.g_varchar2_table(209) := 'd if; '||wwv_flow.LF||
'      if nvl(c1.type_id,0) != nvl(p_type_id,0) then '||wwv_flow.LF||
'         update eba_ca_events '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(210) := '   set type_id = p_type_id '||wwv_flow.LF||
'          where event_id = p_event_id; '||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'      if nvl(c1.c';
wwv_flow_imp.g_varchar2_table(211) := 'alendar_id,0) != nvl(p_calendar_id,0) then '||wwv_flow.LF||
'         update eba_ca_events '||wwv_flow.LF||
'            set calendar_';
wwv_flow_imp.g_varchar2_table(212) := 'id = p_calendar_id '||wwv_flow.LF||
'          where event_id = p_event_id; '||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'      -- only for non-rec';
wwv_flow_imp.g_varchar2_table(213) := 'urring events, recur pass in db value (update of recurring date/time handled elsewhere) '||wwv_flow.LF||
'      if to';
wwv_flow_imp.g_varchar2_table(214) := '_char(c1.event_date_time,''DD-MON-RRRR HH:MIam'') != to_char(p_event_date_time,''DD-MON-RRRR HH:MIam'') ';
wwv_flow_imp.g_varchar2_table(215) := 'then '||wwv_flow.LF||
'         update EBA_ca_events '||wwv_flow.LF||
'            set event_date_time = p_event_date_time '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(216) := 'where event_id = p_event_id; '||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'      if c1.duration != p_duration then '||wwv_flow.LF||
'         updat';
wwv_flow_imp.g_varchar2_table(217) := 'e EBA_ca_events '||wwv_flow.LF||
'            set duration = p_duration '||wwv_flow.LF||
'          where event_id = p_event_id; '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(218) := '  end if; '||wwv_flow.LF||
'      if nvl(c1.event_desc,''0'') != nvl(p_event_desc,''0'') then '||wwv_flow.LF||
'         update EBA_ca_eve';
wwv_flow_imp.g_varchar2_table(219) := 'nts '||wwv_flow.LF||
'            set event_desc = p_event_desc '||wwv_flow.LF||
'          where event_id = p_event_id; '||wwv_flow.LF||
'      end if';
wwv_flow_imp.g_varchar2_table(220) := '; '||wwv_flow.LF||
'      if nvl(c1.contact_person,''0'') != nvl(p_contact_person,''0'') then '||wwv_flow.LF||
'         update EBA_ca_eve';
wwv_flow_imp.g_varchar2_table(221) := 'nts '||wwv_flow.LF||
'            set contact_person = p_contact_person '||wwv_flow.LF||
'          where event_id = p_event_id; '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(222) := '  end if; '||wwv_flow.LF||
'      if nvl(c1.contact_email,''0'') != nvl(p_contact_email,''0'') then '||wwv_flow.LF||
'         update EBA_';
wwv_flow_imp.g_varchar2_table(223) := 'ca_events '||wwv_flow.LF||
'            set contact_email = p_contact_email '||wwv_flow.LF||
'          where event_id = p_event_id; '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(224) := '      end if; '||wwv_flow.LF||
'      if c1.display_time != p_display_time then '||wwv_flow.LF||
'         update EBA_ca_events '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(225) := '       set display_time = p_display_time '||wwv_flow.LF||
'          where event_id = p_event_id; '||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(226) := '   if nvl(c1.location,''0'') != nvl(p_location,''0'') then '||wwv_flow.LF||
'         update EBA_ca_events '||wwv_flow.LF||
'            s';
wwv_flow_imp.g_varchar2_table(227) := 'et location = p_location '||wwv_flow.LF||
'          where event_id = p_event_id; '||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'      if nvl(c1.lin';
wwv_flow_imp.g_varchar2_table(228) := 'k_name_1,''0'') != nvl(p_link_name_1,''0'') then '||wwv_flow.LF||
'         update EBA_ca_events '||wwv_flow.LF||
'            set link_na';
wwv_flow_imp.g_varchar2_table(229) := 'me_1 = p_link_name_1 '||wwv_flow.LF||
'          where event_id = p_event_id; '||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'      if nvl(c1.link_ur';
wwv_flow_imp.g_varchar2_table(230) := 'l_1,''0'') != nvl(p_link_url_1,''0'') then '||wwv_flow.LF||
'         update EBA_ca_events '||wwv_flow.LF||
'            set link_url_1 = ';
wwv_flow_imp.g_varchar2_table(231) := 'p_link_url_1 '||wwv_flow.LF||
'          where event_id = p_event_id; '||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'      if nvl(c1.link_name_2,''0''';
wwv_flow_imp.g_varchar2_table(232) := ') != nvl(p_link_name_2,''0'') then '||wwv_flow.LF||
'         update EBA_ca_events '||wwv_flow.LF||
'            set link_name_2 = p_lin';
wwv_flow_imp.g_varchar2_table(233) := 'k_name_2 '||wwv_flow.LF||
'          where event_id = p_event_id; '||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'      if nvl(c1.link_url_2,''0'') != ';
wwv_flow_imp.g_varchar2_table(234) := 'nvl(p_link_url_2,''0'') then '||wwv_flow.LF||
'         update EBA_ca_events '||wwv_flow.LF||
'            set link_url_2 = p_link_url_2';
wwv_flow_imp.g_varchar2_table(235) := ' '||wwv_flow.LF||
'          where event_id = p_event_id; '||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'      if nvl(c1.link_name_3,''0'') != nvl(p_l';
wwv_flow_imp.g_varchar2_table(236) := 'ink_name_3,''0'') then '||wwv_flow.LF||
'         update EBA_ca_events '||wwv_flow.LF||
'            set link_name_3 = p_link_name_3 '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(237) := '        where event_id = p_event_id; '||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'      if nvl(c1.link_url_3,''0'') != nvl(p_link_u';
wwv_flow_imp.g_varchar2_table(238) := 'rl_3,''0'') then '||wwv_flow.LF||
'         update EBA_ca_events '||wwv_flow.LF||
'            set link_url_3 = p_link_url_3 '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(239) := 'where event_id = p_event_id; '||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'      if nvl(c1.series_id,0) != nvl(p_series_id,0) then';
wwv_flow_imp.g_varchar2_table(240) := ' '||wwv_flow.LF||
'         update EBA_ca_events '||wwv_flow.LF||
'            set series_id = p_series_id '||wwv_flow.LF||
'          where event_id =';
wwv_flow_imp.g_varchar2_table(241) := ' p_event_id; '||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'      if nvl(c1.tags,''0m0'') != nvl(p_tags,''0m0'') then '||wwv_flow.LF||
'         update ';
wwv_flow_imp.g_varchar2_table(242) := 'EBA_ca_events '||wwv_flow.LF||
'            set tags = p_tags '||wwv_flow.LF||
'          where event_id = p_event_id; '||wwv_flow.LF||
'      end if; ';
wwv_flow_imp.g_varchar2_table(243) := ''||wwv_flow.LF||
'   end loop; '||wwv_flow.LF||
'end update_event_l; '||wwv_flow.LF||
'procedure update_start_time_l ( '||wwv_flow.LF||
'   p_event_id         number, '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(244) := '   p_event_date_time  timestamp with time zone ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'   update EBA_ca_events '||wwv_flow.LF||
'      set even';
wwv_flow_imp.g_varchar2_table(245) := 't_date_time = to_date(to_char(event_date_time,''DD-MON-RRRR'')||to_char(p_event_date_time,''HH:MIam''), ';
wwv_flow_imp.g_varchar2_table(246) := ''||wwv_flow.LF||
'                                    ''DD-MON-RRRRHH:MIam'') '||wwv_flow.LF||
'    where event_id = p_event_id; '||wwv_flow.LF||
'end up';
wwv_flow_imp.g_varchar2_table(247) := 'date_start_time_l; '||wwv_flow.LF||
'-- **************************** '||wwv_flow.LF||
'function gen_id  '||wwv_flow.LF||
'   return number '||wwv_flow.LF||
'is '||wwv_flow.LF||
'   l_id';
wwv_flow_imp.g_varchar2_table(248) := '  number; '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'   select to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'     into l_i';
wwv_flow_imp.g_varchar2_table(249) := 'd '||wwv_flow.LF||
'     from dual; '||wwv_flow.LF||
'   return l_id; '||wwv_flow.LF||
'end gen_id; '||wwv_flow.LF||
'function create_event_type ( '||wwv_flow.LF||
'   p_event_type    v';
wwv_flow_imp.g_varchar2_table(250) := 'archar2,'||wwv_flow.LF||
'   p_color_pref_id number,'||wwv_flow.LF||
'   p_internal_yn   varchar2'||wwv_flow.LF||
'  ) '||wwv_flow.LF||
'   return number '||wwv_flow.LF||
'is '||wwv_flow.LF||
'   l_type';
wwv_flow_imp.g_varchar2_table(251) := '_id  number  default null; '||wwv_flow.LF||
'   l_display_color varchar2(30);'||wwv_flow.LF||
'   l_border_color varchar2(30);'||wwv_flow.LF||
'begin '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(252) := '   for c1 in ( '||wwv_flow.LF||
'      select type_id '||wwv_flow.LF||
'        from EBA_ca_event_types '||wwv_flow.LF||
'       where upper(p_event_ty';
wwv_flow_imp.g_varchar2_table(253) := 'pe) = upper(type_name) ) '||wwv_flow.LF||
'   loop '||wwv_flow.LF||
'      l_type_id := c1.type_id; '||wwv_flow.LF||
'      return l_type_id; '||wwv_flow.LF||
'   end l';
wwv_flow_imp.g_varchar2_table(254) := 'oop; '||wwv_flow.LF||
'   if l_type_id is null then '||wwv_flow.LF||
'     for c1 in (select BG_COLOR'||wwv_flow.LF||
'                ,      TEXT_COLO';
wwv_flow_imp.g_varchar2_table(255) := 'R'||wwv_flow.LF||
'                from EBA_CA_COLOR_PREFS'||wwv_flow.LF||
'                where id = p_color_pref_id'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(256) := ') loop'||wwv_flow.LF||
'       l_display_color := c1.TEXT_COLOR;'||wwv_flow.LF||
'       l_border_color := c1.BG_COLOR;'||wwv_flow.LF||
'     end loop;';
wwv_flow_imp.g_varchar2_table(257) := ''||wwv_flow.LF||
'     '||wwv_flow.LF||
'     insert into EBA_ca_event_types (  type_name'||wwv_flow.LF||
'                                     , displ';
wwv_flow_imp.g_varchar2_table(258) := 'ay_color'||wwv_flow.LF||
'                                     , border_color'||wwv_flow.LF||
'                                     , ';
wwv_flow_imp.g_varchar2_table(259) := 'internal_yn'||wwv_flow.LF||
'                                     , color_pref_id'||wwv_flow.LF||
'                                   ';
wwv_flow_imp.g_varchar2_table(260) := ' ) '||wwv_flow.LF||
'      values (  p_event_type'||wwv_flow.LF||
'              , l_display_color'||wwv_flow.LF||
'              , l_border_color'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(261) := '          , p_internal_yn'||wwv_flow.LF||
'              , p_color_pref_id'||wwv_flow.LF||
'             ) '||wwv_flow.LF||
'      returning type_id in';
wwv_flow_imp.g_varchar2_table(262) := 'to l_type_id; '||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'   return l_type_id; '||wwv_flow.LF||
'end create_event_type; '||wwv_flow.LF||
'procedure create_event ( '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(263) := '  p_event_name       varchar2, '||wwv_flow.LF||
'   p_type_id          number, '||wwv_flow.LF||
'   p_calendar_id      number, '||wwv_flow.LF||
'   p_n';
wwv_flow_imp.g_varchar2_table(264) := 'ew_event_type   varchar2,'||wwv_flow.LF||
'   p_new_color_pref_id number,'||wwv_flow.LF||
'   p_new_internal_yn   varchar2,'||wwv_flow.LF||
'   p_event';
wwv_flow_imp.g_varchar2_table(265) := '_date_time  timestamp with time zone, '||wwv_flow.LF||
'   p_duration         number, '||wwv_flow.LF||
'   p_event_desc       varchar2';
wwv_flow_imp.g_varchar2_table(266) := ', '||wwv_flow.LF||
'   p_contact_person   varchar2, '||wwv_flow.LF||
'   p_contact_email    varchar2, '||wwv_flow.LF||
'   p_display_time     varchar2,';
wwv_flow_imp.g_varchar2_table(267) := ' '||wwv_flow.LF||
'   p_location         varchar2, '||wwv_flow.LF||
'   p_link_name_1      varchar2, '||wwv_flow.LF||
'   p_link_url_1       varchar2, ';
wwv_flow_imp.g_varchar2_table(268) := ''||wwv_flow.LF||
'   p_link_name_2      varchar2, '||wwv_flow.LF||
'   p_link_url_2       varchar2, '||wwv_flow.LF||
'   p_link_name_3      varchar2, '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(269) := '   p_link_url_3       varchar2, '||wwv_flow.LF||
'   p_tags             varchar2 default null, '||wwv_flow.LF||
'   -- '||wwv_flow.LF||
'   p_recur_fla';
wwv_flow_imp.g_varchar2_table(270) := 'g       varchar2, '||wwv_flow.LF||
'   p_recur_freq       varchar2, '||wwv_flow.LF||
'   p_recur_end_date   timestamp with time zone )';
wwv_flow_imp.g_varchar2_table(271) := ' '||wwv_flow.LF||
'is '||wwv_flow.LF||
'   l_event_type_id    number  default null; '||wwv_flow.LF||
'   l_series_id        number; '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'   if p_new';
wwv_flow_imp.g_varchar2_table(272) := '_event_type is not null then '||wwv_flow.LF||
'      l_event_type_id := create_event_type (  p_event_type => p_new_ev';
wwv_flow_imp.g_varchar2_table(273) := 'ent_type'||wwv_flow.LF||
'                                            , p_color_pref_id => p_new_color_pref_id'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(274) := '                                      , p_internal_yn => p_new_internal_yn'||wwv_flow.LF||
'                         ';
wwv_flow_imp.g_varchar2_table(275) := '                  ); '||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'        '||wwv_flow.LF||
'   if p_recur_flag = ''Y'' then '||wwv_flow.LF||
'      l_series_id := creat';
wwv_flow_imp.g_varchar2_table(276) := 'e_series_l ( '||wwv_flow.LF||
'                        p_start_date  => cast(trunc(to_date(to_char(p_event_date_time,';
wwv_flow_imp.g_varchar2_table(277) := '''DD-MON-RRRR''),''DD-MON-RRRR'')) as timestamp), '||wwv_flow.LF||
'                        p_end_date    => p_recur_end_';
wwv_flow_imp.g_varchar2_table(278) := 'date, '||wwv_flow.LF||
'                        p_recur_freq  => p_recur_freq ); '||wwv_flow.LF||
'      create_recur_events_l ( '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(279) := '     p_event_name      => p_event_name, '||wwv_flow.LF||
'         p_type_id         => nvl(p_type_id,l_event_type_id';
wwv_flow_imp.g_varchar2_table(280) := '), '||wwv_flow.LF||
'         p_calendar_id     => p_calendar_id, '||wwv_flow.LF||
'         p_event_date_time => p_event_date_time, '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(281) := '         p_duration        => p_duration, '||wwv_flow.LF||
'         p_event_desc      => p_event_desc, '||wwv_flow.LF||
'         p_c';
wwv_flow_imp.g_varchar2_table(282) := 'ontact_person  => p_contact_person, '||wwv_flow.LF||
'         p_contact_email   => p_contact_email, '||wwv_flow.LF||
'         p_disp';
wwv_flow_imp.g_varchar2_table(283) := 'lay_time    => p_display_time, '||wwv_flow.LF||
'         p_location        => p_location, '||wwv_flow.LF||
'         p_link_name_1   ';
wwv_flow_imp.g_varchar2_table(284) := '  => p_link_name_1, '||wwv_flow.LF||
'         p_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'         p_link_name_2     => p_li';
wwv_flow_imp.g_varchar2_table(285) := 'nk_name_2, '||wwv_flow.LF||
'         p_link_url_2      => p_link_url_2, '||wwv_flow.LF||
'         p_link_name_3     => p_link_name_3';
wwv_flow_imp.g_varchar2_table(286) := ', '||wwv_flow.LF||
'         p_link_url_3      => p_link_url_3, '||wwv_flow.LF||
'         p_series_id       => l_series_id, '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(287) := ' p_tags            => p_tags ); '||wwv_flow.LF||
'   else '||wwv_flow.LF||
'      create_event_l ( '||wwv_flow.LF||
'         p_event_name      => p_ev';
wwv_flow_imp.g_varchar2_table(288) := 'ent_name, '||wwv_flow.LF||
'         p_type_id         => nvl(p_type_id,l_event_type_id), '||wwv_flow.LF||
'         p_calendar_id    ';
wwv_flow_imp.g_varchar2_table(289) := ' => p_calendar_id, '||wwv_flow.LF||
'         p_event_date_time => p_event_date_time, '||wwv_flow.LF||
'         p_duration        => ';
wwv_flow_imp.g_varchar2_table(290) := 'p_duration, '||wwv_flow.LF||
'         p_event_desc      => p_event_desc, '||wwv_flow.LF||
'         p_contact_person  => p_contact_pe';
wwv_flow_imp.g_varchar2_table(291) := 'rson, '||wwv_flow.LF||
'         p_contact_email   => p_contact_email, '||wwv_flow.LF||
'         p_display_time    => p_display_time,';
wwv_flow_imp.g_varchar2_table(292) := ' '||wwv_flow.LF||
'         p_location        => p_location, '||wwv_flow.LF||
'         p_link_name_1     => p_link_name_1, '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(293) := 'p_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'         p_link_name_2     => p_link_name_2, '||wwv_flow.LF||
'         p_link_ur';
wwv_flow_imp.g_varchar2_table(294) := 'l_2      => p_link_url_2, '||wwv_flow.LF||
'         p_link_name_3     => p_link_name_3, '||wwv_flow.LF||
'         p_link_url_3      ';
wwv_flow_imp.g_varchar2_table(295) := '=> p_link_url_3, '||wwv_flow.LF||
'         p_tags            => p_tags ); '||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'   commit; '||wwv_flow.LF||
'end create_event;';
wwv_flow_imp.g_varchar2_table(296) := ' '||wwv_flow.LF||
'procedure delete_event ( '||wwv_flow.LF||
'   p_event_id           number, '||wwv_flow.LF||
'   -- '||wwv_flow.LF||
'   p_delete_request     varchar2';
wwv_flow_imp.g_varchar2_table(297) := '  default null) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'   l_event_cnt  number  default 0; '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'   for c1 in ( '||wwv_flow.LF||
'      select series_';
wwv_flow_imp.g_varchar2_table(298) := 'id, event_date_time '||wwv_flow.LF||
'        from EBA_ca_events '||wwv_flow.LF||
'       where event_id = p_event_id ) '||wwv_flow.LF||
'   loop '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(299) := '  -- simple delete '||wwv_flow.LF||
'      if c1.series_id is null then '||wwv_flow.LF||
'         delete_event_l ( '||wwv_flow.LF||
'            p_eve';
wwv_flow_imp.g_varchar2_table(300) := 'nt_id => p_event_id ); '||wwv_flow.LF||
'      -- recurring '||wwv_flow.LF||
'      else '||wwv_flow.LF||
'         if p_delete_request = ''O'' then '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(301) := '         delete_event_l ( '||wwv_flow.LF||
'               p_event_id => p_event_id ); '||wwv_flow.LF||
'            -- if no more eve';
wwv_flow_imp.g_varchar2_table(302) := 'nts in the series, delete the series '||wwv_flow.LF||
'            select count(*) '||wwv_flow.LF||
'              into l_event_cnt '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(303) := '             from EBA_ca_events '||wwv_flow.LF||
'             where series_id = c1.series_id; '||wwv_flow.LF||
'            if l_even';
wwv_flow_imp.g_varchar2_table(304) := 't_cnt = 0 then '||wwv_flow.LF||
'               delete_series_l ( '||wwv_flow.LF||
'                  p_series_id => c1.series_id ); '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(305) := '            elsif l_event_cnt = 1 then '||wwv_flow.LF||
'            -- only one event left, update event to remove s';
wwv_flow_imp.g_varchar2_table(306) := 'eries and delete series '||wwv_flow.LF||
'               clear_series_l ( '||wwv_flow.LF||
'                  p_series_id => c1.series';
wwv_flow_imp.g_varchar2_table(307) := '_id ); '||wwv_flow.LF||
'               delete_series_l ( '||wwv_flow.LF||
'                  p_series_id => c1.series_id ); '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(308) := '    else '||wwv_flow.LF||
'            -- update series end date, if last event was deleted '||wwv_flow.LF||
'               for c3 in';
wwv_flow_imp.g_varchar2_table(309) := ' ( '||wwv_flow.LF||
'                  select max(event_date_time) last_date '||wwv_flow.LF||
'                    from EBA_ca_events ';
wwv_flow_imp.g_varchar2_table(310) := ''||wwv_flow.LF||
'                   where series_id = c1.series_id ) '||wwv_flow.LF||
'               loop '||wwv_flow.LF||
'                  update_';
wwv_flow_imp.g_varchar2_table(311) := 'series_end_date_l ( '||wwv_flow.LF||
'                     p_series_id => c1.series_id, '||wwv_flow.LF||
'                     p_end_d';
wwv_flow_imp.g_varchar2_table(312) := 'ate  => cast(trunc(to_date(to_char(c3.last_date,''DD-MON-RRRR''),''DD-MON-RRRR'')) as timestamp)); '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(313) := '           end loop; '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'         else  '||wwv_flow.LF||
'            for c2 in ( '||wwv_flow.LF||
'               s';
wwv_flow_imp.g_varchar2_table(314) := 'elect event_id, event_date_time '||wwv_flow.LF||
'                 from EBA_ca_events '||wwv_flow.LF||
'                where series_i';
wwv_flow_imp.g_varchar2_table(315) := 'd = c1.series_id  ) '||wwv_flow.LF||
'            loop '||wwv_flow.LF||
'               if p_delete_request = ''A'' then '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(316) := '    delete_event_l ( '||wwv_flow.LF||
'                     p_event_id => c2.event_id ); '||wwv_flow.LF||
'               elsif p_dele';
wwv_flow_imp.g_varchar2_table(317) := 'te_request = ''F'' then '||wwv_flow.LF||
'                  -- delete future '||wwv_flow.LF||
'--                  if c2.event_date_time';
wwv_flow_imp.g_varchar2_table(318) := ' >= c1.event_date_time then '||wwv_flow.LF||
'                  if trunc(to_date(to_char(c2.event_date_time,''DD-MON-R';
wwv_flow_imp.g_varchar2_table(319) := 'RRR''),''DD-MON-RRRR'')) >=  '||wwv_flow.LF||
'                     trunc(to_date(to_char(c1.event_date_time,''DD-MON-RRR';
wwv_flow_imp.g_varchar2_table(320) := 'R''),''DD-MON-RRRR'')) then '||wwv_flow.LF||
'                     delete_event_l ( '||wwv_flow.LF||
'                        p_event_id ';
wwv_flow_imp.g_varchar2_table(321) := '=> c2.event_id ); '||wwv_flow.LF||
'                  end if; '||wwv_flow.LF||
'               end if; '||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(322) := '     -- if no more events in the series, delete the series '||wwv_flow.LF||
'            select count(*) '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(323) := '   into l_event_cnt '||wwv_flow.LF||
'              from EBA_ca_events '||wwv_flow.LF||
'             where series_id = c1.series_id; ';
wwv_flow_imp.g_varchar2_table(324) := ''||wwv_flow.LF||
'            if l_event_cnt = 0 then '||wwv_flow.LF||
'               delete_series_l ( '||wwv_flow.LF||
'                  p_series_i';
wwv_flow_imp.g_varchar2_table(325) := 'd => c1.series_id ); '||wwv_flow.LF||
'            else '||wwv_flow.LF||
'            -- update series end date '||wwv_flow.LF||
'               for c2';
wwv_flow_imp.g_varchar2_table(326) := ' in ( '||wwv_flow.LF||
'                  select max(event_date_time) last_date '||wwv_flow.LF||
'                    from EBA_ca_even';
wwv_flow_imp.g_varchar2_table(327) := 'ts '||wwv_flow.LF||
'                   where series_id = c1.series_id ) '||wwv_flow.LF||
'               loop '||wwv_flow.LF||
'                  upda';
wwv_flow_imp.g_varchar2_table(328) := 'te_series_end_date_l ( '||wwv_flow.LF||
'                     p_series_id => c1.series_id, '||wwv_flow.LF||
'                     p_en';
wwv_flow_imp.g_varchar2_table(329) := 'd_date  => cast(trunc(to_date(to_char(c2.last_date,''DD-MON-RRRR''),''DD-MON-RRRR'')) as timestamp)); '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(330) := '              end loop; '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'         end if; '||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'   end loop; '||wwv_flow.LF||
'end del';
wwv_flow_imp.g_varchar2_table(331) := 'ete_event; '||wwv_flow.LF||
'procedure update_event ( '||wwv_flow.LF||
'   p_event_id         number, '||wwv_flow.LF||
'   p_event_name       varchar2,';
wwv_flow_imp.g_varchar2_table(332) := ' '||wwv_flow.LF||
'   p_type_id          number, '||wwv_flow.LF||
'   p_calendar_id      number, '||wwv_flow.LF||
'   p_new_event_type   varchar2, '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(333) := 'p_new_color_pref_id number,'||wwv_flow.LF||
'   p_new_internal_yn   varchar2,'||wwv_flow.LF||
'   p_event_date_time  timestamp with ti';
wwv_flow_imp.g_varchar2_table(334) := 'me zone, '||wwv_flow.LF||
'   p_duration         number, '||wwv_flow.LF||
'   p_event_desc       varchar2, '||wwv_flow.LF||
'   p_contact_person   varc';
wwv_flow_imp.g_varchar2_table(335) := 'har2, '||wwv_flow.LF||
'   p_contact_email    varchar2, '||wwv_flow.LF||
'   p_display_time     varchar2, '||wwv_flow.LF||
'   p_location         varch';
wwv_flow_imp.g_varchar2_table(336) := 'ar2, '||wwv_flow.LF||
'   p_link_name_1      varchar2, '||wwv_flow.LF||
'   p_link_url_1       varchar2, '||wwv_flow.LF||
'   p_link_name_2      varcha';
wwv_flow_imp.g_varchar2_table(337) := 'r2, '||wwv_flow.LF||
'   p_link_url_2       varchar2, '||wwv_flow.LF||
'   p_link_name_3      varchar2, '||wwv_flow.LF||
'   p_link_url_3       varchar';
wwv_flow_imp.g_varchar2_table(338) := '2, '||wwv_flow.LF||
'   -- '||wwv_flow.LF||
'   p_recur_flag       varchar2, '||wwv_flow.LF||
'   p_recur_freq       varchar2, '||wwv_flow.LF||
'   p_recur_end_date   t';
wwv_flow_imp.g_varchar2_table(339) := 'imestamp with time zone, '||wwv_flow.LF||
'   -- '||wwv_flow.LF||
'   p_update_request   varchar2  default null, '||wwv_flow.LF||
'   p_tags           ';
wwv_flow_imp.g_varchar2_table(340) := '  varchar2  default null  ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'   l_event_type_id    number  default null; '||wwv_flow.LF||
'   l_series_id        ';
wwv_flow_imp.g_varchar2_table(341) := 'number; '||wwv_flow.LF||
'   l_event_cnt        number; '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'   if p_new_event_type is not null then '||wwv_flow.LF||
'      l_even';
wwv_flow_imp.g_varchar2_table(342) := 't_type_id := create_event_type (  p_event_type => p_new_event_type'||wwv_flow.LF||
'                                 ';
wwv_flow_imp.g_varchar2_table(343) := '           , p_color_pref_id => p_new_color_pref_id'||wwv_flow.LF||
'                                            , p_';
wwv_flow_imp.g_varchar2_table(344) := 'internal_yn => p_new_internal_yn'||wwv_flow.LF||
'                                           ); '||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'   for c';
wwv_flow_imp.g_varchar2_table(345) := '1 in ( '||wwv_flow.LF||
'      select event_name, type_id, calendar_id, '||wwv_flow.LF||
'             event_date_time, duration, '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(346) := '          event_desc, contact_person,  '||wwv_flow.LF||
'             contact_email, display_time, location, '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(347) := '      link_name_1, link_url_1, '||wwv_flow.LF||
'             link_name_2, link_url_2, '||wwv_flow.LF||
'             link_name_3, lin';
wwv_flow_imp.g_varchar2_table(348) := 'k_url_3, '||wwv_flow.LF||
'             series_id, '||wwv_flow.LF||
'             tags '||wwv_flow.LF||
'        from EBA_ca_events '||wwv_flow.LF||
'       where event';
wwv_flow_imp.g_varchar2_table(349) := '_id = p_event_id ) '||wwv_flow.LF||
'   loop '||wwv_flow.LF||
'      -- simple update '||wwv_flow.LF||
'      if nvl(p_recur_flag,''N'') != ''Y'' and c1.se';
wwv_flow_imp.g_varchar2_table(350) := 'ries_id is null then '||wwv_flow.LF||
'         update_event_l ( '||wwv_flow.LF||
'            p_event_id        => p_event_id, '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(351) := '       p_event_name      => p_event_name, '||wwv_flow.LF||
'            p_type_id         => nvl(p_type_id,l_event_ty';
wwv_flow_imp.g_varchar2_table(352) := 'pe_id), '||wwv_flow.LF||
'            p_calendar_id     => p_calendar_id, '||wwv_flow.LF||
'            p_event_date_time => p_event_d';
wwv_flow_imp.g_varchar2_table(353) := 'ate_time, '||wwv_flow.LF||
'            p_duration        => p_duration, '||wwv_flow.LF||
'            p_event_desc      => p_event_de';
wwv_flow_imp.g_varchar2_table(354) := 'sc, '||wwv_flow.LF||
'            p_contact_person  => p_contact_person, '||wwv_flow.LF||
'            p_contact_email   => p_contact_';
wwv_flow_imp.g_varchar2_table(355) := 'email, '||wwv_flow.LF||
'            p_display_time    => p_display_time, '||wwv_flow.LF||
'            p_location        => p_locatio';
wwv_flow_imp.g_varchar2_table(356) := 'n, '||wwv_flow.LF||
'            p_link_name_1     => p_link_name_1, '||wwv_flow.LF||
'            p_link_url_1      => p_link_url_1, ';
wwv_flow_imp.g_varchar2_table(357) := ''||wwv_flow.LF||
'            p_link_name_2     => p_link_name_2, '||wwv_flow.LF||
'            p_link_url_2      => p_link_url_2, '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(358) := '          p_link_name_3     => p_link_name_3, '||wwv_flow.LF||
'            p_link_url_3      => p_link_url_3, '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(359) := '       p_tags            => p_tags ); '||wwv_flow.LF||
'      -- adding recurrence (remove event and recreate as seri';
wwv_flow_imp.g_varchar2_table(360) := 'es) '||wwv_flow.LF||
'      elsif p_recur_flag = ''Y'' and c1.series_id is null then '||wwv_flow.LF||
'         delete_event_l ( '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(361) := '      p_event_id => p_event_id ); '||wwv_flow.LF||
'         l_series_id := create_series_l ( '||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(362) := '     p_start_date  => cast(trunc(to_date(to_char(p_event_date_time,''DD-MON-RRRR''),''DD-MON-RRRR'')) as';
wwv_flow_imp.g_varchar2_table(363) := ' timestamp), '||wwv_flow.LF||
'                           p_end_date    => p_recur_end_date, '||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(364) := '    p_recur_freq  => p_recur_freq ); '||wwv_flow.LF||
'         create_recur_events_l ( '||wwv_flow.LF||
'            p_event_name    ';
wwv_flow_imp.g_varchar2_table(365) := '  => p_event_name, '||wwv_flow.LF||
'            p_type_id         => nvl(p_type_id,l_event_type_id), '||wwv_flow.LF||
'            p_';
wwv_flow_imp.g_varchar2_table(366) := 'calendar_id     => p_calendar_id, '||wwv_flow.LF||
'            p_event_date_time => p_event_date_time, '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(367) := 'p_duration        => p_duration, '||wwv_flow.LF||
'            p_event_desc      => p_event_desc, '||wwv_flow.LF||
'            p_cont';
wwv_flow_imp.g_varchar2_table(368) := 'act_person  => p_contact_person, '||wwv_flow.LF||
'            p_contact_email   => p_contact_email, '||wwv_flow.LF||
'            p_d';
wwv_flow_imp.g_varchar2_table(369) := 'isplay_time    => p_display_time, '||wwv_flow.LF||
'            p_location        => p_location, '||wwv_flow.LF||
'            p_link_';
wwv_flow_imp.g_varchar2_table(370) := 'name_1     => p_link_name_1, '||wwv_flow.LF||
'            p_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'            p_link_nam';
wwv_flow_imp.g_varchar2_table(371) := 'e_2     => p_link_name_2, '||wwv_flow.LF||
'            p_link_url_2      => p_link_url_2, '||wwv_flow.LF||
'            p_link_name_3';
wwv_flow_imp.g_varchar2_table(372) := '     => p_link_name_3, '||wwv_flow.LF||
'            p_link_url_3      => p_link_url_3, '||wwv_flow.LF||
'            p_series_id     ';
wwv_flow_imp.g_varchar2_table(373) := '  => l_series_id, '||wwv_flow.LF||
'            p_tags            => p_tags ); '||wwv_flow.LF||
'      -- removing recurrence '||wwv_flow.LF||
'      e';
wwv_flow_imp.g_varchar2_table(374) := 'lsif p_recur_flag is null and c1.series_id is not null then '||wwv_flow.LF||
'         if p_update_request = ''A'' then';
wwv_flow_imp.g_varchar2_table(375) := ' '||wwv_flow.LF||
'            -- update event, delete rest of events and series '||wwv_flow.LF||
'            update_event_l ( '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(376) := '          p_event_id        => p_event_id, '||wwv_flow.LF||
'               p_event_name      => p_event_name, '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(377) := '          p_type_id         => nvl(p_type_id,l_event_type_id), '||wwv_flow.LF||
'               p_calendar_id     => ';
wwv_flow_imp.g_varchar2_table(378) := 'p_calendar_id, '||wwv_flow.LF||
'               p_event_date_time => p_event_date_time, '||wwv_flow.LF||
'               p_duration   ';
wwv_flow_imp.g_varchar2_table(379) := '     => p_duration, '||wwv_flow.LF||
'               p_event_desc      => p_event_desc, '||wwv_flow.LF||
'               p_contact_per';
wwv_flow_imp.g_varchar2_table(380) := 'son  => p_contact_person, '||wwv_flow.LF||
'               p_contact_email   => p_contact_email, '||wwv_flow.LF||
'               p_di';
wwv_flow_imp.g_varchar2_table(381) := 'splay_time    => p_display_time, '||wwv_flow.LF||
'               p_location        => p_location, '||wwv_flow.LF||
'               p_';
wwv_flow_imp.g_varchar2_table(382) := 'link_name_1     => p_link_name_1, '||wwv_flow.LF||
'               p_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(383) := ' p_link_name_2     => p_link_name_2, '||wwv_flow.LF||
'               p_link_url_2      => p_link_url_2, '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(384) := '    p_link_name_3     => p_link_name_3, '||wwv_flow.LF||
'               p_link_url_3      => p_link_url_3, '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(385) := '       p_series_id       => null, '||wwv_flow.LF||
'               p_tags            => p_tags ); '||wwv_flow.LF||
'            -- del';
wwv_flow_imp.g_varchar2_table(386) := 'ete rest by series_id and then delete series '||wwv_flow.LF||
'            for c2 in ( '||wwv_flow.LF||
'               select event_i';
wwv_flow_imp.g_varchar2_table(387) := 'd '||wwv_flow.LF||
'                 from EBA_ca_events '||wwv_flow.LF||
'                where series_id = c1.series_id) '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(388) := ' loop '||wwv_flow.LF||
'               delete_event_l ( '||wwv_flow.LF||
'                  p_event_id => c2.event_id ); '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(389) := 'end loop; '||wwv_flow.LF||
'            delete_series_l ( '||wwv_flow.LF||
'               p_series_id => c1.series_id ); '||wwv_flow.LF||
'         el';
wwv_flow_imp.g_varchar2_table(390) := 'sif p_update_request = ''F'' then '||wwv_flow.LF||
'            -- update event, delete future events, update series to';
wwv_flow_imp.g_varchar2_table(391) := ' show new end date '||wwv_flow.LF||
'            update_event_l ( '||wwv_flow.LF||
'               p_event_id        => p_event_id, '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(392) := '              p_event_name      => p_event_name, '||wwv_flow.LF||
'               p_type_id         => nvl(p_type_id,';
wwv_flow_imp.g_varchar2_table(393) := 'l_event_type_id), '||wwv_flow.LF||
'               p_calendar_id     => p_calendar_id, '||wwv_flow.LF||
'               p_event_date_t';
wwv_flow_imp.g_varchar2_table(394) := 'ime => p_event_date_time, '||wwv_flow.LF||
'               p_duration        => p_duration, '||wwv_flow.LF||
'               p_event_d';
wwv_flow_imp.g_varchar2_table(395) := 'esc      => p_event_desc, '||wwv_flow.LF||
'               p_contact_person  => p_contact_person, '||wwv_flow.LF||
'               p_c';
wwv_flow_imp.g_varchar2_table(396) := 'ontact_email   => p_contact_email, '||wwv_flow.LF||
'               p_display_time    => p_display_time, '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(397) := '    p_location        => p_location, '||wwv_flow.LF||
'               p_link_name_1     => p_link_name_1, '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(398) := '     p_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'               p_link_name_2     => p_link_name_2, '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(399) := '        p_link_url_2      => p_link_url_2, '||wwv_flow.LF||
'               p_link_name_3     => p_link_name_3, '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(400) := '           p_link_url_3      => p_link_url_3, '||wwv_flow.LF||
'               p_series_id       => null, '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(401) := '     p_tags            => p_tags ); '||wwv_flow.LF||
'            -- delete future events by series_id '||wwv_flow.LF||
'            f';
wwv_flow_imp.g_varchar2_table(402) := 'or c2 in ( '||wwv_flow.LF||
'               select event_id, event_date_time '||wwv_flow.LF||
'                 from EBA_ca_events '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(403) := '              where series_id = c1.series_id) '||wwv_flow.LF||
'            loop '||wwv_flow.LF||
'               if c2.event_date_tim';
wwv_flow_imp.g_varchar2_table(404) := 'e > c1.event_date_time then '||wwv_flow.LF||
'                  delete_event_l ( '||wwv_flow.LF||
'                     p_event_id => ';
wwv_flow_imp.g_varchar2_table(405) := 'c2.event_id ); '||wwv_flow.LF||
'               end if; '||wwv_flow.LF||
'            end loop; '||wwv_flow.LF||
'            select count(*) '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(406) := '      into l_event_cnt '||wwv_flow.LF||
'              from EBA_ca_events '||wwv_flow.LF||
'             where series_id = c1.series_i';
wwv_flow_imp.g_varchar2_table(407) := 'd; '||wwv_flow.LF||
'            -- if no more events in the series, delete the series '||wwv_flow.LF||
'            if l_event_cnt = ';
wwv_flow_imp.g_varchar2_table(408) := '0 then '||wwv_flow.LF||
'               delete_series_l ( '||wwv_flow.LF||
'                  p_series_id => c1.series_id ); '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(409) := '    else '||wwv_flow.LF||
'            -- update series end date '||wwv_flow.LF||
'               for c2 in ( '||wwv_flow.LF||
'                  selec';
wwv_flow_imp.g_varchar2_table(410) := 't max(event_date_time) last_date '||wwv_flow.LF||
'                    from EBA_ca_events '||wwv_flow.LF||
'                   where s';
wwv_flow_imp.g_varchar2_table(411) := 'eries_id = c1.series_id ) '||wwv_flow.LF||
'               loop '||wwv_flow.LF||
'                  update_series_end_date_l ( '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(412) := '               p_series_id => c1.series_id, '||wwv_flow.LF||
'                     p_end_date  => cast(trunc(to_date(';
wwv_flow_imp.g_varchar2_table(413) := 'to_char(c2.last_date,''DD-MON-RRRR''),''DD-MON-RRRR'')) as timestamp)); '||wwv_flow.LF||
'               end loop; '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(414) := '       end if; '||wwv_flow.LF||
'         elsif p_update_request = ''O'' then '||wwv_flow.LF||
'            -- update event, removing se';
wwv_flow_imp.g_varchar2_table(415) := 'ries '||wwv_flow.LF||
'            update_event_l ( '||wwv_flow.LF||
'               p_event_id        => p_event_id, '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(416) := 'p_event_name      => p_event_name, '||wwv_flow.LF||
'               p_type_id         => nvl(p_type_id,l_event_type_i';
wwv_flow_imp.g_varchar2_table(417) := 'd), '||wwv_flow.LF||
'               p_calendar_id     => p_calendar_id, '||wwv_flow.LF||
'               p_event_date_time => p_event';
wwv_flow_imp.g_varchar2_table(418) := '_date_time, '||wwv_flow.LF||
'               p_duration        => p_duration, '||wwv_flow.LF||
'               p_event_desc      => p_';
wwv_flow_imp.g_varchar2_table(419) := 'event_desc, '||wwv_flow.LF||
'               p_contact_person  => p_contact_person, '||wwv_flow.LF||
'               p_contact_email  ';
wwv_flow_imp.g_varchar2_table(420) := ' => p_contact_email, '||wwv_flow.LF||
'               p_display_time    => p_display_time, '||wwv_flow.LF||
'               p_location';
wwv_flow_imp.g_varchar2_table(421) := '        => p_location, '||wwv_flow.LF||
'               p_link_name_1     => p_link_name_1, '||wwv_flow.LF||
'               p_link_ur';
wwv_flow_imp.g_varchar2_table(422) := 'l_1      => p_link_url_1, '||wwv_flow.LF||
'               p_link_name_2     => p_link_name_2, '||wwv_flow.LF||
'               p_link';
wwv_flow_imp.g_varchar2_table(423) := '_url_2      => p_link_url_2, '||wwv_flow.LF||
'               p_link_name_3     => p_link_name_3, '||wwv_flow.LF||
'               p_l';
wwv_flow_imp.g_varchar2_table(424) := 'ink_url_3      => p_link_url_3, '||wwv_flow.LF||
'               p_series_id       => null, '||wwv_flow.LF||
'               p_tags   ';
wwv_flow_imp.g_varchar2_table(425) := '         => p_tags ); '||wwv_flow.LF||
'            select count(*) '||wwv_flow.LF||
'              into l_event_cnt '||wwv_flow.LF||
'              fr';
wwv_flow_imp.g_varchar2_table(426) := 'om EBA_ca_events '||wwv_flow.LF||
'             where series_id = c1.series_id; '||wwv_flow.LF||
'            -- if no more events in ';
wwv_flow_imp.g_varchar2_table(427) := 'the series, delete the series '||wwv_flow.LF||
'            if l_event_cnt = 0 then '||wwv_flow.LF||
'               delete_series_l (';
wwv_flow_imp.g_varchar2_table(428) := ' '||wwv_flow.LF||
'                  p_series_id => c1.series_id ); '||wwv_flow.LF||
'            else '||wwv_flow.LF||
'            -- update series e';
wwv_flow_imp.g_varchar2_table(429) := 'nd date '||wwv_flow.LF||
'               for c2 in ( '||wwv_flow.LF||
'                  select max(event_date_time) last_date '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(430) := '              from EBA_ca_events '||wwv_flow.LF||
'                   where series_id = c1.series_id ) '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(431) := '  loop '||wwv_flow.LF||
'                  update_series_end_date_l ( '||wwv_flow.LF||
'                     p_series_id => c1.series_';
wwv_flow_imp.g_varchar2_table(432) := 'id, '||wwv_flow.LF||
'                     p_end_date  => cast(trunc(to_date(to_char(c2.last_date,''DD-MON-RRRR''),''DD-';
wwv_flow_imp.g_varchar2_table(433) := 'MON-RRRR'')) as timestamp)); '||wwv_flow.LF||
'               end loop; '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'         end if; '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(434) := '-- updating recurring event '||wwv_flow.LF||
'      elsif p_recur_flag = ''Y'' and c1.series_id is not null then '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(435) := '    -- updating standard columns '||wwv_flow.LF||
'         if p_event_name              != c1.event_name or '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(436) := '     (nvl(p_type_id,0)         != nvl(c1.type_id,0) or p_new_event_type is not null) or '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(437) := ' nvl(p_calendar_id,0)      != nvl(c1.calendar_id,0) or '||wwv_flow.LF||
'            nvl(p_event_desc,''0'')     != nvl';
wwv_flow_imp.g_varchar2_table(438) := '(c1.event_desc,''0'') or '||wwv_flow.LF||
'            nvl(p_contact_person,''0'') != nvl(c1.contact_person,''0'') or '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(439) := '        nvl(p_contact_email,''0'')  != nvl(c1.contact_email,''0'') or '||wwv_flow.LF||
'            p_display_time       ';
wwv_flow_imp.g_varchar2_table(440) := '     != c1.display_time or '||wwv_flow.LF||
'            nvl(p_location,''0'')       != nvl(c1.location,''0'') or '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(441) := '      nvl(p_link_name_1,''0'')    != nvl(c1.link_name_1,''0'') or '||wwv_flow.LF||
'            nvl(p_link_url_1,''0'')    ';
wwv_flow_imp.g_varchar2_table(442) := ' != nvl(c1.link_url_1,''0'') or '||wwv_flow.LF||
'            nvl(p_link_name_2,''0'')    != nvl(c1.link_name_2,''0'') or '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(443) := '            nvl(p_link_url_2,''0'')     != nvl(c1.link_url_2,''0'') or '||wwv_flow.LF||
'            nvl(p_link_name_3,''0';
wwv_flow_imp.g_varchar2_table(444) := ''')    != nvl(c1.link_name_3,''0'') or '||wwv_flow.LF||
'            nvl(p_link_url_3,''0'')     != nvl(c1.link_url_3,''0'')';
wwv_flow_imp.g_varchar2_table(445) := ' or '||wwv_flow.LF||
'            nvl(p_tags,''0'')           != nvl(c1.tags,''0'') or '||wwv_flow.LF||
'            p_duration           ';
wwv_flow_imp.g_varchar2_table(446) := '     != c1.duration  '||wwv_flow.LF||
'         then '||wwv_flow.LF||
'            if p_update_request = ''O'' then '||wwv_flow.LF||
'               upda';
wwv_flow_imp.g_varchar2_table(447) := 'te_event_l ( '||wwv_flow.LF||
'                  p_event_id        => p_event_id, '||wwv_flow.LF||
'                  p_event_name    ';
wwv_flow_imp.g_varchar2_table(448) := '  => p_event_name, '||wwv_flow.LF||
'                  p_type_id         => nvl(p_type_id,l_event_type_id), '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(449) := '          p_calendar_id     => p_calendar_id, '||wwv_flow.LF||
'                  p_event_date_time => c1.event_date_';
wwv_flow_imp.g_varchar2_table(450) := 'time, -- passing base value so no update '||wwv_flow.LF||
'                  p_duration        => p_duration, '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(451) := '            p_event_desc      => p_event_desc, '||wwv_flow.LF||
'                  p_contact_person  => p_contact_per';
wwv_flow_imp.g_varchar2_table(452) := 'son, '||wwv_flow.LF||
'                  p_contact_email   => p_contact_email, '||wwv_flow.LF||
'                  p_display_time    =';
wwv_flow_imp.g_varchar2_table(453) := '> p_display_time, '||wwv_flow.LF||
'                  p_location        => p_location, '||wwv_flow.LF||
'                  p_link_name';
wwv_flow_imp.g_varchar2_table(454) := '_1     => p_link_name_1, '||wwv_flow.LF||
'                  p_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'                  p_';
wwv_flow_imp.g_varchar2_table(455) := 'link_name_2     => p_link_name_2, '||wwv_flow.LF||
'                  p_link_url_2      => p_link_url_2, '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(456) := '       p_link_name_3     => p_link_name_3, '||wwv_flow.LF||
'                  p_link_url_3      => p_link_url_3, '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(457) := '                p_series_id       => c1.series_id, '||wwv_flow.LF||
'                  p_tags            => p_tags );';
wwv_flow_imp.g_varchar2_table(458) := ' '||wwv_flow.LF||
'            else '||wwv_flow.LF||
'               for c2 in ( '||wwv_flow.LF||
'                  select event_id, event_date_time '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(459) := '                    from EBA_ca_events '||wwv_flow.LF||
'                   where series_id = c1.series_id ) '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(460) := '        loop '||wwv_flow.LF||
'                  if p_update_request = ''A'' then '||wwv_flow.LF||
'                     update_event_l ';
wwv_flow_imp.g_varchar2_table(461) := '( '||wwv_flow.LF||
'                        p_event_id        => c2.event_id, '||wwv_flow.LF||
'                        p_event_name  ';
wwv_flow_imp.g_varchar2_table(462) := '    => p_event_name, '||wwv_flow.LF||
'                        p_type_id         => nvl(p_type_id,l_event_type_id), '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(463) := '                        p_calendar_id     => p_calendar_id, '||wwv_flow.LF||
'                        p_event_date_ti';
wwv_flow_imp.g_varchar2_table(464) := 'me => c2.event_date_time, -- passing base value so no update '||wwv_flow.LF||
'                        p_duration    ';
wwv_flow_imp.g_varchar2_table(465) := '    => p_duration, '||wwv_flow.LF||
'                        p_event_desc      => p_event_desc, '||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(466) := '    p_contact_person  => p_contact_person, '||wwv_flow.LF||
'                        p_contact_email   => p_contact_e';
wwv_flow_imp.g_varchar2_table(467) := 'mail, '||wwv_flow.LF||
'                        p_display_time    => p_display_time, '||wwv_flow.LF||
'                        p_locat';
wwv_flow_imp.g_varchar2_table(468) := 'ion        => p_location, '||wwv_flow.LF||
'                        p_link_name_1     => p_link_name_1, '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(469) := '            p_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'                        p_link_name_2     => p_link_';
wwv_flow_imp.g_varchar2_table(470) := 'name_2, '||wwv_flow.LF||
'                        p_link_url_2      => p_link_url_2, '||wwv_flow.LF||
'                        p_link_';
wwv_flow_imp.g_varchar2_table(471) := 'name_3     => p_link_name_3, '||wwv_flow.LF||
'                        p_link_url_3      => p_link_url_3, '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(472) := '              p_series_id       => c1.series_id, '||wwv_flow.LF||
'                        p_tags            => p_tag';
wwv_flow_imp.g_varchar2_table(473) := 's ); '||wwv_flow.LF||
'                  elsif p_update_request = ''F'' then '||wwv_flow.LF||
'                     if c2.event_date_tim';
wwv_flow_imp.g_varchar2_table(474) := 'e >= c1.event_date_time then '||wwv_flow.LF||
'                        update_event_l ( '||wwv_flow.LF||
'                           p';
wwv_flow_imp.g_varchar2_table(475) := '_event_id        => c2.event_id, '||wwv_flow.LF||
'                           p_event_name      => p_event_name, '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(476) := '                        p_type_id         => nvl(p_type_id,l_event_type_id), '||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(477) := '     p_calendar_id     => p_calendar_id, '||wwv_flow.LF||
'                           p_event_date_time => c2.event_d';
wwv_flow_imp.g_varchar2_table(478) := 'ate_time, -- passing base value so no update '||wwv_flow.LF||
'                           p_duration        => p_dura';
wwv_flow_imp.g_varchar2_table(479) := 'tion, '||wwv_flow.LF||
'                           p_event_desc      => p_event_desc, '||wwv_flow.LF||
'                           p_c';
wwv_flow_imp.g_varchar2_table(480) := 'ontact_person  => p_contact_person, '||wwv_flow.LF||
'                           p_contact_email   => p_contact_email';
wwv_flow_imp.g_varchar2_table(481) := ', '||wwv_flow.LF||
'                           p_display_time    => p_display_time, '||wwv_flow.LF||
'                           p_loc';
wwv_flow_imp.g_varchar2_table(482) := 'ation        => p_location, '||wwv_flow.LF||
'                           p_link_name_1     => p_link_name_1, '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(483) := '                    p_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'                           p_link_name_2    ';
wwv_flow_imp.g_varchar2_table(484) := ' => p_link_name_2, '||wwv_flow.LF||
'                           p_link_url_2      => p_link_url_2, '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(485) := '          p_link_name_3     => p_link_name_3, '||wwv_flow.LF||
'                           p_link_url_3      => p_lin';
wwv_flow_imp.g_varchar2_table(486) := 'k_url_3, '||wwv_flow.LF||
'                           p_series_id       => c1.series_id, '||wwv_flow.LF||
'                           ';
wwv_flow_imp.g_varchar2_table(487) := 'p_tags            => p_tags ); '||wwv_flow.LF||
'                     end if; '||wwv_flow.LF||
'                  end if; '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(488) := '    end loop; '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'         end if; '||wwv_flow.LF||
'         -- update non-standard columns '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(489) := '    for c2 in ( '||wwv_flow.LF||
'            select recur_freq, end_date '||wwv_flow.LF||
'              from EBA_ca_series '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(490) := '     where series_id = c1.series_id ) '||wwv_flow.LF||
'         loop '||wwv_flow.LF||
'            if p_recur_freq != c2.recur_freq t';
wwv_flow_imp.g_varchar2_table(491) := 'hen '||wwv_flow.LF||
'               if p_update_request = ''A'' then '||wwv_flow.LF||
'                  for c3 in ( '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(492) := '    select event_id '||wwv_flow.LF||
'                       from EBA_ca_events '||wwv_flow.LF||
'                      where series_i';
wwv_flow_imp.g_varchar2_table(493) := 'd = c1.series_id  ) '||wwv_flow.LF||
'                  loop '||wwv_flow.LF||
'                     delete_event_l ( '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(494) := '        p_event_id => c3.event_id ); '||wwv_flow.LF||
'                  end loop; '||wwv_flow.LF||
'                  delete_series_l';
wwv_flow_imp.g_varchar2_table(495) := ' ( '||wwv_flow.LF||
'                     p_series_id => c1.series_id ); '||wwv_flow.LF||
'                  l_series_id := create_ser';
wwv_flow_imp.g_varchar2_table(496) := 'ies_l ( '||wwv_flow.LF||
'                     p_start_date  => cast(trunc(to_date(to_char(p_event_date_time,''DD-MON-';
wwv_flow_imp.g_varchar2_table(497) := 'RRRR''),''DD-MON-RRRR'')) as timestamp), '||wwv_flow.LF||
'                     p_end_date    => p_recur_end_date, '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(498) := '                 p_recur_freq  => p_recur_freq ); '||wwv_flow.LF||
'                  create_recur_events_l ( '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(499) := '               p_event_name      => p_event_name, '||wwv_flow.LF||
'                     p_type_id         => nvl(p_t';
wwv_flow_imp.g_varchar2_table(500) := 'ype_id,l_event_type_id), '||wwv_flow.LF||
'                     p_calendar_id     => p_calendar_id, '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(501) := '     p_event_date_time => p_event_date_time, '||wwv_flow.LF||
'                     p_duration        => p_duration, ';
wwv_flow_imp.g_varchar2_table(502) := ''||wwv_flow.LF||
'                     p_event_desc      => p_event_desc, '||wwv_flow.LF||
'                     p_contact_person  => ';
wwv_flow_imp.g_varchar2_table(503) := 'p_contact_person, '||wwv_flow.LF||
'                     p_contact_email   => p_contact_email, '||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(504) := 'p_display_time    => p_display_time, '||wwv_flow.LF||
'                     p_location        => p_location, '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(505) := '              p_link_name_1     => p_link_name_1, '||wwv_flow.LF||
'                     p_link_url_1      => p_link_';
wwv_flow_imp.g_varchar2_table(506) := 'url_1, '||wwv_flow.LF||
'                     p_link_name_2     => p_link_name_2, '||wwv_flow.LF||
'                     p_link_url_2 ';
wwv_flow_imp.g_varchar2_table(507) := '     => p_link_url_2, '||wwv_flow.LF||
'                     p_link_name_3     => p_link_name_3, '||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(508) := '  p_link_url_3      => p_link_url_3, '||wwv_flow.LF||
'                     p_series_id       => l_series_id, '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(509) := '               p_tags            => p_tags ); '||wwv_flow.LF||
'               elsif p_update_request = ''F'' then '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(510) := '               -- drop and recreate future only as new series '||wwv_flow.LF||
'                  for c3 in ( '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(511) := '               select event_id, event_date_time '||wwv_flow.LF||
'                       from EBA_ca_events '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(512) := '              where series_id = c1.series_id  ) '||wwv_flow.LF||
'                  loop '||wwv_flow.LF||
'                     if tru';
wwv_flow_imp.g_varchar2_table(513) := 'nc(to_date(to_char(c3.event_date_time,''DD-MON-RRRR''),''DD-MON-RRRR'')) >=  '||wwv_flow.LF||
'                        tr';
wwv_flow_imp.g_varchar2_table(514) := 'unc(to_date(to_char(c1.event_date_time,''DD-MON-RRRR''),''DD-MON-RRRR'')) then '||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(515) := 'delete_event_l ( '||wwv_flow.LF||
'                           p_event_id => c3.event_id ); '||wwv_flow.LF||
'                     end ';
wwv_flow_imp.g_varchar2_table(516) := 'if; '||wwv_flow.LF||
'                  end loop; '||wwv_flow.LF||
'                  select count(*) '||wwv_flow.LF||
'                    into l_even';
wwv_flow_imp.g_varchar2_table(517) := 't_cnt '||wwv_flow.LF||
'                    from EBA_ca_events '||wwv_flow.LF||
'                   where series_id = c1.series_id; '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(518) := '                 -- if no more events in the series, delete the series '||wwv_flow.LF||
'                  if l_event';
wwv_flow_imp.g_varchar2_table(519) := '_cnt = 0 then '||wwv_flow.LF||
'                     delete_series_l ( '||wwv_flow.LF||
'                        p_series_id => c1.ser';
wwv_flow_imp.g_varchar2_table(520) := 'ies_id ); '||wwv_flow.LF||
'                  else '||wwv_flow.LF||
'                  -- update series end date '||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(521) := ' for c3 in ( '||wwv_flow.LF||
'                        select max(event_date_time) last_date '||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(522) := '   from EBA_ca_events '||wwv_flow.LF||
'                         where series_id = c1.series_id ) '||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(523) := '   loop '||wwv_flow.LF||
'                        update_series_end_date_l ( '||wwv_flow.LF||
'                           p_series_id ';
wwv_flow_imp.g_varchar2_table(524) := '=> c1.series_id, '||wwv_flow.LF||
'                           p_end_date  => cast(trunc(to_date(to_char(c3.last_date,';
wwv_flow_imp.g_varchar2_table(525) := '''DD-MON-RRRR''),''DD-MON-RRRR'')) as timestamp)); '||wwv_flow.LF||
'                     end loop; '||wwv_flow.LF||
'                  en';
wwv_flow_imp.g_varchar2_table(526) := 'd if; '||wwv_flow.LF||
'                  l_series_id := create_series_l ( '||wwv_flow.LF||
'                     p_start_date  => cas';
wwv_flow_imp.g_varchar2_table(527) := 't(trunc(to_date(to_char(p_event_date_time,''DD-MON-RRRR''),''DD-MON-RRRR'')) as timestamp), '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(528) := '          p_end_date    => p_recur_end_date, '||wwv_flow.LF||
'                     p_recur_freq  => p_recur_freq ); ';
wwv_flow_imp.g_varchar2_table(529) := ''||wwv_flow.LF||
'                  create_recur_events_l ( '||wwv_flow.LF||
'                     p_event_name      => p_event_name, ';
wwv_flow_imp.g_varchar2_table(530) := ''||wwv_flow.LF||
'                     p_type_id         => nvl(p_type_id,l_event_type_id), '||wwv_flow.LF||
'                     p_c';
wwv_flow_imp.g_varchar2_table(531) := 'alendar_id     => p_calendar_id, '||wwv_flow.LF||
'                     p_event_date_time => p_event_date_time, '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(532) := '                 p_duration        => p_duration, '||wwv_flow.LF||
'                     p_event_desc      => p_event';
wwv_flow_imp.g_varchar2_table(533) := '_desc, '||wwv_flow.LF||
'                     p_contact_person  => p_contact_person, '||wwv_flow.LF||
'                     p_contact_';
wwv_flow_imp.g_varchar2_table(534) := 'email   => p_contact_email, '||wwv_flow.LF||
'                     p_display_time    => p_display_time, '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(535) := '         p_location        => p_location, '||wwv_flow.LF||
'                     p_link_name_1     => p_link_name_1, ';
wwv_flow_imp.g_varchar2_table(536) := ''||wwv_flow.LF||
'                     p_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'                     p_link_name_2     => ';
wwv_flow_imp.g_varchar2_table(537) := 'p_link_name_2, '||wwv_flow.LF||
'                     p_link_url_2      => p_link_url_2, '||wwv_flow.LF||
'                     p_link';
wwv_flow_imp.g_varchar2_table(538) := '_name_3     => p_link_name_3, '||wwv_flow.LF||
'                     p_link_url_3      => p_link_url_3, '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(539) := '         p_series_id       => l_series_id, '||wwv_flow.LF||
'                     p_tags            => p_tags ); '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(540) := '            end if; '||wwv_flow.LF||
'            else -- no freq change, date change '||wwv_flow.LF||
'               if to_char(p_ev';
wwv_flow_imp.g_varchar2_table(541) := 'ent_date_time,''DD-MON-RRRR'') != to_char(c1.event_date_time,''DD-MON-RRRR'') then '||wwv_flow.LF||
'                  if';
wwv_flow_imp.g_varchar2_table(542) := ' p_update_request = ''O'' then '||wwv_flow.LF||
'                     update_event_l ( '||wwv_flow.LF||
'                        p_event';
wwv_flow_imp.g_varchar2_table(543) := '_id        => p_event_id, '||wwv_flow.LF||
'                        p_event_name      => p_event_name, '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(544) := '           p_type_id         => nvl(p_type_id,l_event_type_id), '||wwv_flow.LF||
'                        p_calendar_';
wwv_flow_imp.g_varchar2_table(545) := 'id     => p_calendar_id, '||wwv_flow.LF||
'                        p_event_date_time => p_event_date_time, '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(546) := '               p_duration        => p_duration, '||wwv_flow.LF||
'                        p_event_desc      => p_even';
wwv_flow_imp.g_varchar2_table(547) := 't_desc, '||wwv_flow.LF||
'                        p_contact_person  => p_contact_person, '||wwv_flow.LF||
'                        p_c';
wwv_flow_imp.g_varchar2_table(548) := 'ontact_email   => p_contact_email, '||wwv_flow.LF||
'                        p_display_time    => p_display_time, '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(549) := '                      p_location        => p_location, '||wwv_flow.LF||
'                        p_link_name_1     =>';
wwv_flow_imp.g_varchar2_table(550) := ' p_link_name_1, '||wwv_flow.LF||
'                        p_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(551) := ' p_link_name_2     => p_link_name_2, '||wwv_flow.LF||
'                        p_link_url_2      => p_link_url_2, '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(552) := '                      p_link_name_3     => p_link_name_3, '||wwv_flow.LF||
'                        p_link_url_3     ';
wwv_flow_imp.g_varchar2_table(553) := ' => p_link_url_3, '||wwv_flow.LF||
'                        p_series_id       => c1.series_id, '||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(554) := '   p_tags            => p_tags ); '||wwv_flow.LF||
'                  elsif p_update_request = ''A'' then '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(555) := '      -- drop and recreate '||wwv_flow.LF||
'                     for c3 in ( '||wwv_flow.LF||
'                        select event_i';
wwv_flow_imp.g_varchar2_table(556) := 'd, event_date_time '||wwv_flow.LF||
'                          from EBA_ca_events '||wwv_flow.LF||
'                         where ser';
wwv_flow_imp.g_varchar2_table(557) := 'ies_id = c1.series_id ) '||wwv_flow.LF||
'                     loop '||wwv_flow.LF||
'                        delete_event_l ( '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(558) := '                     p_event_id => c3.event_id ); '||wwv_flow.LF||
'                     end loop; '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(559) := '    delete_series_l ( '||wwv_flow.LF||
'                        p_series_id => c1.series_id ); '||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(560) := 'l_series_id := create_series_l ( '||wwv_flow.LF||
'                        p_start_date  => cast(trunc(to_date(to_cha';
wwv_flow_imp.g_varchar2_table(561) := 'r(p_event_date_time,''DD-MON-RRRR''),''DD-MON-RRRR'')) as timestamp), '||wwv_flow.LF||
'                        p_end_dat';
wwv_flow_imp.g_varchar2_table(562) := 'e    => p_recur_end_date, '||wwv_flow.LF||
'                        p_recur_freq  => p_recur_freq ); '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(563) := '      create_recur_events_l ( '||wwv_flow.LF||
'                        p_event_name      => p_event_name, '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(564) := '               p_type_id         => nvl(p_type_id,l_event_type_id), '||wwv_flow.LF||
'                        p_calen';
wwv_flow_imp.g_varchar2_table(565) := 'dar_id     => p_calendar_id, '||wwv_flow.LF||
'                        p_event_date_time => p_event_date_time, '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(566) := '                   p_duration        => p_duration, '||wwv_flow.LF||
'                        p_event_desc      => p_';
wwv_flow_imp.g_varchar2_table(567) := 'event_desc, '||wwv_flow.LF||
'                        p_contact_person  => p_contact_person, '||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(568) := ' p_contact_email   => p_contact_email, '||wwv_flow.LF||
'                        p_display_time    => p_display_time,';
wwv_flow_imp.g_varchar2_table(569) := ' '||wwv_flow.LF||
'                        p_location        => p_location, '||wwv_flow.LF||
'                        p_link_name_1   ';
wwv_flow_imp.g_varchar2_table(570) := '  => p_link_name_1, '||wwv_flow.LF||
'                        p_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(571) := '     p_link_name_2     => p_link_name_2, '||wwv_flow.LF||
'                        p_link_url_2      => p_link_url_2,';
wwv_flow_imp.g_varchar2_table(572) := ' '||wwv_flow.LF||
'                        p_link_name_3     => p_link_name_3, '||wwv_flow.LF||
'                        p_link_url_3 ';
wwv_flow_imp.g_varchar2_table(573) := '     => p_link_url_3, '||wwv_flow.LF||
'                        p_series_id       => l_series_id, '||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(574) := '      p_tags            => p_tags ); '||wwv_flow.LF||
'                  elsif p_update_request = ''F'' then '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(575) := '         -- drop and recreate future only as new series '||wwv_flow.LF||
'                     for c3 in ( '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(576) := '               select event_id, event_date_time '||wwv_flow.LF||
'                          from EBA_ca_events '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(577) := '                    where series_id = c1.series_id  ) '||wwv_flow.LF||
'                     loop '||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(578) := '      if trunc(to_date(to_char(c3.event_date_time,''DD-MON-RRRR''),''DD-MON-RRRR'')) >=  '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(579) := '             trunc(to_date(to_char(c1.event_date_time,''DD-MON-RRRR''),''DD-MON-RRRR'')) then '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(580) := '                  delete_event_l ( '||wwv_flow.LF||
'                              p_event_id => c3.event_id ); '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(581) := '                    end if; '||wwv_flow.LF||
'                     end loop; '||wwv_flow.LF||
'                     select count(*) '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(582) := '                      into l_event_cnt '||wwv_flow.LF||
'                       from EBA_ca_events '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(583) := '     where series_id = c1.series_id; '||wwv_flow.LF||
'                     -- if no more events in the series, delet';
wwv_flow_imp.g_varchar2_table(584) := 'e the series '||wwv_flow.LF||
'                     if l_event_cnt = 0 then '||wwv_flow.LF||
'                        delete_series_l ';
wwv_flow_imp.g_varchar2_table(585) := '( '||wwv_flow.LF||
'                           p_series_id => c1.series_id ); '||wwv_flow.LF||
'                     else '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(586) := '          -- update series end date '||wwv_flow.LF||
'                        for c3 in ( '||wwv_flow.LF||
'                          ';
wwv_flow_imp.g_varchar2_table(587) := ' select max(event_date_time) last_date '||wwv_flow.LF||
'                             from EBA_ca_events '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(588) := '                 where series_id = c1.series_id ) '||wwv_flow.LF||
'                        loop '||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(589) := '        update_series_end_date_l ( '||wwv_flow.LF||
'                              p_series_id => c1.series_id, '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(590) := '                          p_end_date  => cast(trunc(to_date(to_char(c3.last_date,''DD-MON-RRRR''),''DD-';
wwv_flow_imp.g_varchar2_table(591) := 'MON-RRRR'')) as timestamp)); '||wwv_flow.LF||
'                        end loop; '||wwv_flow.LF||
'                     end if; '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(592) := '               l_series_id := create_series_l ( '||wwv_flow.LF||
'                        p_start_date  => cast(trunc';
wwv_flow_imp.g_varchar2_table(593) := '(to_date(to_char(p_event_date_time,''DD-MON-RRRR''),''DD-MON-RRRR'')) as timestamp), '||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(594) := '      p_end_date    => p_recur_end_date, '||wwv_flow.LF||
'                        p_recur_freq  => p_recur_freq ); '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(595) := '                     create_recur_events_l ( '||wwv_flow.LF||
'                        p_event_name      => p_event_n';
wwv_flow_imp.g_varchar2_table(596) := 'ame, '||wwv_flow.LF||
'                        p_type_id         => nvl(p_type_id,l_event_type_id), '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(597) := '        p_calendar_id     => p_calendar_id, '||wwv_flow.LF||
'                        p_event_date_time => p_event_da';
wwv_flow_imp.g_varchar2_table(598) := 'te_time, '||wwv_flow.LF||
'                        p_duration        => p_duration, '||wwv_flow.LF||
'                        p_event_';
wwv_flow_imp.g_varchar2_table(599) := 'desc      => p_event_desc, '||wwv_flow.LF||
'                        p_contact_person  => p_contact_person, '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(600) := '                p_contact_email   => p_contact_email, '||wwv_flow.LF||
'                        p_display_time    => ';
wwv_flow_imp.g_varchar2_table(601) := 'p_display_time, '||wwv_flow.LF||
'                        p_location        => p_location, '||wwv_flow.LF||
'                        p';
wwv_flow_imp.g_varchar2_table(602) := '_link_name_1     => p_link_name_1, '||wwv_flow.LF||
'                        p_link_url_1      => p_link_url_1, '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(603) := '                    p_link_name_2     => p_link_name_2, '||wwv_flow.LF||
'                        p_link_url_2      =';
wwv_flow_imp.g_varchar2_table(604) := '> p_link_url_2, '||wwv_flow.LF||
'                        p_link_name_3     => p_link_name_3, '||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(605) := '  p_link_url_3      => p_link_url_3, '||wwv_flow.LF||
'                        p_series_id       => l_series_id, '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(606) := '                     p_tags            => p_tags ); '||wwv_flow.LF||
'                  end if; '||wwv_flow.LF||
'               -- st';
wwv_flow_imp.g_varchar2_table(607) := 'art time change but no date change '||wwv_flow.LF||
'               elsif to_char(p_event_date_time,''HH:MIam'')    != ';
wwv_flow_imp.g_varchar2_table(608) := 'to_char(c1.event_date_time,''HH:MIam'') and '||wwv_flow.LF||
'                     to_char(p_event_date_time,''DD-MON-RR';
wwv_flow_imp.g_varchar2_table(609) := 'RR'') = to_char(c1.event_date_time,''DD-MON-RRRR'') then '||wwv_flow.LF||
'                     if p_update_request = ''O';
wwv_flow_imp.g_varchar2_table(610) := ''' then '||wwv_flow.LF||
'                        update_start_time_l ( '||wwv_flow.LF||
'                           p_event_id        ';
wwv_flow_imp.g_varchar2_table(611) := '=> p_event_id, '||wwv_flow.LF||
'                           p_event_date_time => p_event_date_time ); '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(612) := '       else '||wwv_flow.LF||
'                        for c3 in ( '||wwv_flow.LF||
'                           select event_id, event_';
wwv_flow_imp.g_varchar2_table(613) := 'date_time '||wwv_flow.LF||
'                             from EBA_ca_events '||wwv_flow.LF||
'                            where series';
wwv_flow_imp.g_varchar2_table(614) := '_id = c1.series_id ) '||wwv_flow.LF||
'                        loop '||wwv_flow.LF||
'                           if p_update_request =';
wwv_flow_imp.g_varchar2_table(615) := ' ''A'' then '||wwv_flow.LF||
'                              update_start_time_l ( '||wwv_flow.LF||
'                                 p_e';
wwv_flow_imp.g_varchar2_table(616) := 'vent_id        => c3.event_id, '||wwv_flow.LF||
'                                 p_event_date_time => p_event_date_t';
wwv_flow_imp.g_varchar2_table(617) := 'ime ); '||wwv_flow.LF||
'                           elsif p_update_request = ''F'' then '||wwv_flow.LF||
'                              ';
wwv_flow_imp.g_varchar2_table(618) := 'if c3.event_date_time >= c1.event_date_time then '||wwv_flow.LF||
'                                 update_start_time';
wwv_flow_imp.g_varchar2_table(619) := '_l ( '||wwv_flow.LF||
'                                    p_event_id        => c3.event_id, '||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(620) := '             p_event_date_time => p_event_date_time ); '||wwv_flow.LF||
'                              end if; '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(621) := '                      end if; '||wwv_flow.LF||
'                        end loop; '||wwv_flow.LF||
'                     end if; '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(622) := '           end if; '||wwv_flow.LF||
'               -- recur_end_date change, remove or add events '||wwv_flow.LF||
'               if';
wwv_flow_imp.g_varchar2_table(623) := ' p_recur_end_date != c2.end_date then '||wwv_flow.LF||
'                  -- when new end date earlier '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(624) := '     if p_recur_end_date < c2.end_date then '||wwv_flow.LF||
'                     -- remove future events '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(625) := '            for c3 in ( '||wwv_flow.LF||
'                        select event_id, event_date_time '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(626) := '         from EBA_ca_events '||wwv_flow.LF||
'                         where series_id = c1.series_id  ) '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(627) := '          loop '||wwv_flow.LF||
'                        if trunc(to_date(to_char(c3.event_date_time,''DD-MON-RRRR''),''';
wwv_flow_imp.g_varchar2_table(628) := 'DD-MON-RRRR'')) >  '||wwv_flow.LF||
'                           trunc(to_date(to_char(p_recur_end_date,''DD-MON-RRRR''),';
wwv_flow_imp.g_varchar2_table(629) := '''DD-MON-RRRR'')) then '||wwv_flow.LF||
'                           delete_event_l ( '||wwv_flow.LF||
'                              p_e';
wwv_flow_imp.g_varchar2_table(630) := 'vent_id => c3.event_id ); '||wwv_flow.LF||
'                        end if; '||wwv_flow.LF||
'                     end loop; '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(631) := '             -- update series end date '||wwv_flow.LF||
'                     for c3 in ( '||wwv_flow.LF||
'                        se';
wwv_flow_imp.g_varchar2_table(632) := 'lect max(event_date_time) last_date '||wwv_flow.LF||
'                          from EBA_ca_events '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(633) := '        where series_id = c1.series_id ) '||wwv_flow.LF||
'                     loop '||wwv_flow.LF||
'                        update_';
wwv_flow_imp.g_varchar2_table(634) := 'series_end_date_l ( '||wwv_flow.LF||
'                           p_series_id => c1.series_id, '||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(635) := '     p_end_date  => cast(trunc(to_date(to_char(c3.last_date,''DD-MON-RRRR''),''DD-MON-RRRR'')) as timest';
wwv_flow_imp.g_varchar2_table(636) := 'amp)); '||wwv_flow.LF||
'                     end loop; '||wwv_flow.LF||
'                  -- new end date after, update series and a';
wwv_flow_imp.g_varchar2_table(637) := 'dd events '||wwv_flow.LF||
'                  else '||wwv_flow.LF||
'                     update_series_end_date_l ( '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(638) := '        p_series_id => c1.series_id, '||wwv_flow.LF||
'                        p_end_date  => p_recur_end_date); '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(639) := '                  for c3 in ( '||wwv_flow.LF||
'                        select max(event_date_time) last_date '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(640) := '                    from EBA_ca_events '||wwv_flow.LF||
'                         where series_id = c1.series_id ) '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(641) := '                    loop '||wwv_flow.LF||
'                        create_more_recur_events_l ( '||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(642) := '       p_event_name           => p_event_name, '||wwv_flow.LF||
'                           p_type_id              =>';
wwv_flow_imp.g_varchar2_table(643) := ' nvl(p_type_id,l_event_type_id), '||wwv_flow.LF||
'                           p_calendar_id          => p_calendar_id';
wwv_flow_imp.g_varchar2_table(644) := ', '||wwv_flow.LF||
'                           p_last_event_date_time => c3.last_date, '||wwv_flow.LF||
'                           p_';
wwv_flow_imp.g_varchar2_table(645) := 'duration             => p_duration, '||wwv_flow.LF||
'                           p_event_desc           => p_event_de';
wwv_flow_imp.g_varchar2_table(646) := 'sc, '||wwv_flow.LF||
'                           p_contact_person       => p_contact_person, '||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(647) := '    p_contact_email        => p_contact_email, '||wwv_flow.LF||
'                           p_display_time         =>';
wwv_flow_imp.g_varchar2_table(648) := ' p_display_time, '||wwv_flow.LF||
'                           p_location             => p_location, '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(649) := '           p_link_name_1          => p_link_name_1, '||wwv_flow.LF||
'                           p_link_url_1        ';
wwv_flow_imp.g_varchar2_table(650) := '   => p_link_url_1, '||wwv_flow.LF||
'                           p_link_name_2          => p_link_name_2, '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(651) := '                 p_link_url_2           => p_link_url_2, '||wwv_flow.LF||
'                           p_link_name_3  ';
wwv_flow_imp.g_varchar2_table(652) := '        => p_link_name_3, '||wwv_flow.LF||
'                           p_link_url_3           => p_link_url_3, '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(653) := '                      p_series_id            => c1.series_id, '||wwv_flow.LF||
'                           p_tags    ';
wwv_flow_imp.g_varchar2_table(654) := '        => p_tags ); '||wwv_flow.LF||
'                     end loop; '||wwv_flow.LF||
'                  end if; '||wwv_flow.LF||
'               end ';
wwv_flow_imp.g_varchar2_table(655) := 'if; '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'         end loop; '||wwv_flow.LF||
'      end if; '||wwv_flow.LF||
'   end loop; '||wwv_flow.LF||
'end update_event; '||wwv_flow.LF||
'proced';
wwv_flow_imp.g_varchar2_table(656) := 'ure create_mbrs_collection ( '||wwv_flow.LF||
'    p_users     in varchar2, '||wwv_flow.LF||
'    p_group_id  in number ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_l';
wwv_flow_imp.g_varchar2_table(657) := 'ine      varchar2(32767); '||wwv_flow.LF||
'    l_emails    wwv_flow_global.vc_arr2; '||wwv_flow.LF||
'    l_email     varchar2(4000);';
wwv_flow_imp.g_varchar2_table(658) := ' '||wwv_flow.LF||
'    l_at        number; '||wwv_flow.LF||
'    l_dot       number; '||wwv_flow.LF||
'    l_user_id   number; '||wwv_flow.LF||
'    l_valid     boolean';
wwv_flow_imp.g_varchar2_table(659) := ' := true; '||wwv_flow.LF||
'    l_domain    varchar2(4000); '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    --------------------- '||wwv_flow.LF||
'    -- create collecti';
wwv_flow_imp.g_varchar2_table(660) := 'ons '||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    wwv_flow_collection.CREATE_OR_TRUNCATE_COLLECTION (''BULK_MBRS_INVALID''); '||wwv_flow.LF||
'    wwv_f';
wwv_flow_imp.g_varchar2_table(661) := 'low_collection.CREATE_OR_TRUNCATE_COLLECTION (''BULK_MBRS_CREATE''); '||wwv_flow.LF||
'     '||wwv_flow.LF||
'    ----------------------';
wwv_flow_imp.g_varchar2_table(662) := '---------------------- '||wwv_flow.LF||
'    -- replace delimiting characters with commas '||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    l_line := p_us';
wwv_flow_imp.g_varchar2_table(663) := 'ers; '||wwv_flow.LF||
'    l_line := replace(l_line,chr(10),'' ''); '||wwv_flow.LF||
'    l_line := replace(l_line,chr(13),'' ''); '||wwv_flow.LF||
'    l_';
wwv_flow_imp.g_varchar2_table(664) := 'line := replace(l_line,chr(9),'' ''); '||wwv_flow.LF||
'    l_line := replace(l_line,''<'','' ''); '||wwv_flow.LF||
'    l_line := replace(l';
wwv_flow_imp.g_varchar2_table(665) := '_line,''>'','' ''); '||wwv_flow.LF||
'    l_line := replace(l_line,'';'','' ''); '||wwv_flow.LF||
'    l_line := replace(l_line,'':'','' ''); '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(666) := ' l_line := replace(l_line,'' '','',''); '||wwv_flow.LF||
'     '||wwv_flow.LF||
'    ----------------------------------------- '||wwv_flow.LF||
'    -- get';
wwv_flow_imp.g_varchar2_table(667) := ' one comma separated line of emails '||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    for j in 1..1000 loop '||wwv_flow.LF||
'        if instr(l_line,'',,''';
wwv_flow_imp.g_varchar2_table(668) := ') > 0 then '||wwv_flow.LF||
'           l_line := replace(l_line,'',,'','',''); '||wwv_flow.LF||
'        else '||wwv_flow.LF||
'           exit; '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(669) := 'end if; '||wwv_flow.LF||
'    end loop; '||wwv_flow.LF||
'    ------------------------- '||wwv_flow.LF||
'    -- get an array of emails '||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    l_';
wwv_flow_imp.g_varchar2_table(670) := 'emails := wwv_flow_utilities.string_to_table(l_line,'',''); '||wwv_flow.LF||
'     '||wwv_flow.LF||
'    ----------------------------- '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(671) := '    -- add emails to a collection '||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    l_email := null; '||wwv_flow.LF||
'    l_domain := null; '||wwv_flow.LF||
'    l_at := ';
wwv_flow_imp.g_varchar2_table(672) := '0; '||wwv_flow.LF||
'    l_dot := 0; '||wwv_flow.LF||
'    for j in 1..l_emails.count loop '||wwv_flow.LF||
'        l_valid := true; '||wwv_flow.LF||
'        l_email ';
wwv_flow_imp.g_varchar2_table(673) := ':= trim(l_emails(j)); '||wwv_flow.LF||
'         '||wwv_flow.LF||
'        if l_email is not null then '||wwv_flow.LF||
'            ----------- '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(674) := '       -- Validate '||wwv_flow.LF||
'            -- '||wwv_flow.LF||
'            l_at := instr(nvl(l_email,''x''),''@''); '||wwv_flow.LF||
'            l_';
wwv_flow_imp.g_varchar2_table(675) := 'domain := substr(l_email,l_at+1); '||wwv_flow.LF||
'            l_dot := instr(l_domain,''.''); '||wwv_flow.LF||
'            if l_at < ';
wwv_flow_imp.g_varchar2_table(676) := '2 then '||wwv_flow.LF||
'                -- invalid email '||wwv_flow.LF||
'                wwv_flow_collection.add_member( '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(677) := '           p_collection_name => ''BULK_MBRS_INVALID'', '||wwv_flow.LF||
'                    p_c001            => l_ema';
wwv_flow_imp.g_varchar2_table(678) := 'il, '||wwv_flow.LF||
'                    p_c002            => ''missing @''); '||wwv_flow.LF||
'                commit; '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(679) := '  l_valid := false; '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'             '||wwv_flow.LF||
'            if l_dot = 0 and l_valid then '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(680) := '               wwv_flow_collection.add_member( '||wwv_flow.LF||
'                    p_collection_name => ''BULK_MBRS_';
wwv_flow_imp.g_varchar2_table(681) := 'INVALID'', '||wwv_flow.LF||
'                    p_c001            => l_email, '||wwv_flow.LF||
'                    p_c002            ';
wwv_flow_imp.g_varchar2_table(682) := '=> ''missing dot''); '||wwv_flow.LF||
'                commit; '||wwv_flow.LF||
'                l_valid := false; '||wwv_flow.LF||
'            end if; ';
wwv_flow_imp.g_varchar2_table(683) := ''||wwv_flow.LF||
'            if l_valid and length(l_email) > 255 then '||wwv_flow.LF||
'                wwv_flow_collection.add_memb';
wwv_flow_imp.g_varchar2_table(684) := 'er( '||wwv_flow.LF||
'                    p_collection_name => ''BULK_MBRS_INVALID'', '||wwv_flow.LF||
'                    p_c001      ';
wwv_flow_imp.g_varchar2_table(685) := '      => l_email, '||wwv_flow.LF||
'                    p_c002            => ''too long''); '||wwv_flow.LF||
'                commit; '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(686) := '               l_valid := false; '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'             '||wwv_flow.LF||
'            if l_valid then '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(687) := '              for c1 in ( '||wwv_flow.LF||
'                   select email_address  '||wwv_flow.LF||
'                     from EBA_c';
wwv_flow_imp.g_varchar2_table(688) := 'a_email_group_mbrs  '||wwv_flow.LF||
'                    where group_id = p_group_id  '||wwv_flow.LF||
'                     and uppe';
wwv_flow_imp.g_varchar2_table(689) := 'r(email_address) = upper(l_email) )  '||wwv_flow.LF||
'                loop '||wwv_flow.LF||
'                    wwv_flow_collection.';
wwv_flow_imp.g_varchar2_table(690) := 'add_member( '||wwv_flow.LF||
'                        p_collection_name => ''BULK_MBRS_INVALID'', '||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(691) := '    p_c001            => l_email, '||wwv_flow.LF||
'                        p_c002            => ''member exists''); '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(692) := '                   commit; '||wwv_flow.LF||
'                    l_valid := false; '||wwv_flow.LF||
'                    exit; '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(693) := '          end loop; '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'             '||wwv_flow.LF||
'            if l_valid then '||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(694) := ' for c1 in ( '||wwv_flow.LF||
'                   select c001  '||wwv_flow.LF||
'                     from wwv_flow_collections '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(695) := '               where collection_name = ''BULK_MBRS_CREATE'' '||wwv_flow.LF||
'                      and upper(c001) = t';
wwv_flow_imp.g_varchar2_table(696) := 'rim(upper(l_email)) )  '||wwv_flow.LF||
'                loop '||wwv_flow.LF||
'                    wwv_flow_collection.add_member( '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(697) := '                       p_collection_name => ''BULK_MBRS_INVALID'', '||wwv_flow.LF||
'                        p_c001    ';
wwv_flow_imp.g_varchar2_table(698) := '        => l_email, '||wwv_flow.LF||
'                        p_c002            => ''duplicate member''); '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(699) := '            commit; '||wwv_flow.LF||
'                    l_valid := false; '||wwv_flow.LF||
'                    exit; '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(700) := '   end loop; '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'             '||wwv_flow.LF||
'            if l_valid then '||wwv_flow.LF||
'               wwv_flo';
wwv_flow_imp.g_varchar2_table(701) := 'w_collection.add_member( '||wwv_flow.LF||
'                   p_collection_name => ''BULK_MBRS_CREATE'', '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(702) := '      p_c001            => lower(l_email)); '||wwv_flow.LF||
'               commit; '||wwv_flow.LF||
'            end if; '||wwv_flow.LF||
'        en';
wwv_flow_imp.g_varchar2_table(703) := 'd if; '||wwv_flow.LF||
'        l_email := null; '||wwv_flow.LF||
'    end loop; '||wwv_flow.LF||
'end create_mbrs_collection; '||wwv_flow.LF||
'procedure create_mbrs_f';
wwv_flow_imp.g_varchar2_table(704) := 'rom_collection ( '||wwv_flow.LF||
'    p_group_id  in number ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_email  varchar2(255); '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    for c1 in';
wwv_flow_imp.g_varchar2_table(705) := ' ( '||wwv_flow.LF||
'       select c001 '||wwv_flow.LF||
'         from wwv_flow_collections '||wwv_flow.LF||
'        where collection_name = ''BULK_MB';
wwv_flow_imp.g_varchar2_table(706) := 'RS_CREATE'' )  '||wwv_flow.LF||
'    loop '||wwv_flow.LF||
'        l_email := c1.c001; '||wwv_flow.LF||
'        insert into EBA_ca_email_group_mbrs '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(707) := '          (group_id, email_address) '||wwv_flow.LF||
'        values '||wwv_flow.LF||
'           (p_group_id, lower(l_email)); '||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(708) := 'nd loop; '||wwv_flow.LF||
'    commit; '||wwv_flow.LF||
'end create_mbrs_from_collection; '||wwv_flow.LF||
'function get_timeframes ( '||wwv_flow.LF||
'   p_event_id  i';
wwv_flow_imp.g_varchar2_table(709) := 'n  number ) '||wwv_flow.LF||
'   return varchar2 '||wwv_flow.LF||
'is '||wwv_flow.LF||
'   l_event_date  date; '||wwv_flow.LF||
'   l_timeframes  varchar2(4000); '||wwv_flow.LF||
'begin';
wwv_flow_imp.g_varchar2_table(710) := ' '||wwv_flow.LF||
'   for c1 in ( '||wwv_flow.LF||
'      select trunc(to_date(to_char(event_date_time,''DD-MON-RRRR''),''DD-MON-RRRR'')) ';
wwv_flow_imp.g_varchar2_table(711) := 'event_date '||wwv_flow.LF||
'        from EBA_ca_events '||wwv_flow.LF||
'       where event_id = p_event_id ) '||wwv_flow.LF||
'   loop '||wwv_flow.LF||
'      l_event';
wwv_flow_imp.g_varchar2_table(712) := '_date := c1.event_date; '||wwv_flow.LF||
'   end loop; '||wwv_flow.LF||
'   for c1 in ( '||wwv_flow.LF||
'      select tf_name '||wwv_flow.LF||
'        from EBA_ca_tim';
wwv_flow_imp.g_varchar2_table(713) := 'eframes '||wwv_flow.LF||
'       where l_event_date >= start_date '||wwv_flow.LF||
'         and l_event_date <= end_date  '||wwv_flow.LF||
'        or';
wwv_flow_imp.g_varchar2_table(714) := 'der by start_date asc) '||wwv_flow.LF||
'   loop '||wwv_flow.LF||
'      l_timeframes := l_timeframes ||'', ''|| c1.tf_name; '||wwv_flow.LF||
'   end loo';
wwv_flow_imp.g_varchar2_table(715) := 'p; '||wwv_flow.LF||
'   l_timeframes := ltrim(l_timeframes,'', ''); '||wwv_flow.LF||
'   return l_timeframes; '||wwv_flow.LF||
'end get_timeframes; '||wwv_flow.LF||
'end ';
wwv_flow_imp.g_varchar2_table(716) := 'eba_ca_api; '||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1856508020739628927)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'eba_ca_api body'
,p_sequence=>90
,p_script_type=>'UPGRADE'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
