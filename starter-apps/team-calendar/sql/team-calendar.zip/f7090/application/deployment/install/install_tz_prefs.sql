prompt --application/deployment/install/install_tz_prefs
begin
--   Manifest
--     INSTALL: INSTALL-tz prefs
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table EBA_CA_tz_pref ('||wwv_flow.LF||
'  id                        number not null'||wwv_flow.LF||
'                          ';
wwv_flow_imp.g_varchar2_table(2) := '  constraint EBA_CA_tz_pref_pk'||wwv_flow.LF||
'                            primary key,'||wwv_flow.LF||
'  row_version_number        ';
wwv_flow_imp.g_varchar2_table(3) := 'integer,'||wwv_flow.LF||
'  userid                    varchar2(255) not null,'||wwv_flow.LF||
'  TIMEZONE_PREFERENCE       varchar2(25';
wwv_flow_imp.g_varchar2_table(4) := '5) not null,'||wwv_flow.LF||
'  created                   timestamp with time zone,'||wwv_flow.LF||
'  created_by                varch';
wwv_flow_imp.g_varchar2_table(5) := 'ar2(255),'||wwv_flow.LF||
'  updated                   timestamp with time zone,'||wwv_flow.LF||
'  updated_by                varchar2';
wwv_flow_imp.g_varchar2_table(6) := '(255)'||wwv_flow.LF||
'  );'||wwv_flow.LF||
'  '||wwv_flow.LF||
'create or replace trigger biu_EBA_CA_tz_pref'||wwv_flow.LF||
'   before insert or update on EBA_CA_tz_p';
wwv_flow_imp.g_varchar2_table(7) := 'ref'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(8) := 'XXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created :=';
wwv_flow_imp.g_varchar2_table(9) := ' current_timestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := curr';
wwv_flow_imp.g_varchar2_table(10) := 'ent_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number :';
wwv_flow_imp.g_varchar2_table(11) := '= 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(12) := ' end if;'||wwv_flow.LF||
'   if inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.upda';
wwv_flow_imp.g_varchar2_table(13) := 'ted_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if :new.TIMEZONE_PREFERENCE is null then'||wwv_flow.LF||
'       :';
wwv_flow_imp.g_varchar2_table(14) := 'new.timezone_preference := ''UTC'';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger biu_EBA_CA_tz_pref enable;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3256158756893220074)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'tz prefs'
,p_sequence=>245
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
