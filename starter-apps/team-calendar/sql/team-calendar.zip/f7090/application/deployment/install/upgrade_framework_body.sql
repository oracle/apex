prompt --application/deployment/install/upgrade_framework_body
begin
--   Manifest
--     INSTALL: UPGRADE-Framework Body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE OR REPLACE PACKAGE BODY "EBA_CA_FW" as'||wwv_flow.LF||
'    function conv_txt_html ('||wwv_flow.LF||
'        p_txt_message in ';
wwv_flow_imp.g_varchar2_table(2) := 'varchar2 )'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_html_message   varchar2(32767) default p_txt_mes';
wwv_flow_imp.g_varchar2_table(3) := 'sage;'||wwv_flow.LF||
'        l_temp_url varchar2(32767) := null;'||wwv_flow.LF||
'        l_length number;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        l_html_';
wwv_flow_imp.g_varchar2_table(4) := 'message := replace(l_html_message, chr(10), ''<br />'');'||wwv_flow.LF||
'        l_html_message := replace(l_html_mess';
wwv_flow_imp.g_varchar2_table(5) := 'age, chr(13), null);'||wwv_flow.LF||
'        return l_html_message;'||wwv_flow.LF||
'    end conv_txt_html;'||wwv_flow.LF||
'    function conv_urls_li';
wwv_flow_imp.g_varchar2_table(6) := 'nks ('||wwv_flow.LF||
'        p_string in varchar2 )'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_string   varchar2(3276';
wwv_flow_imp.g_varchar2_table(7) := '7) default p_string;'||wwv_flow.LF||
'        l_endofUrl varchar2(4000) default chr(10) || chr(13) || chr(9) || '' )<>';
wwv_flow_imp.g_varchar2_table(8) := ''';'||wwv_flow.LF||
'        l_url         varchar2(4000);'||wwv_flow.LF||
'        l_current_pos number := 1;'||wwv_flow.LF||
'        n             nu';
wwv_flow_imp.g_varchar2_table(9) := 'mber := 1;'||wwv_flow.LF||
'        m             number := 1;'||wwv_flow.LF||
'        p             number := 1;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        l';
wwv_flow_imp.g_varchar2_table(10) := '_string := p_string || '' '';'||wwv_flow.LF||
'        for i in 1 .. 1000 loop'||wwv_flow.LF||
'            n := instr( lower(l_string),';
wwv_flow_imp.g_varchar2_table(11) := ' ''http://'', l_current_pos );'||wwv_flow.LF||
'            m := instr( lower(l_string), ''https://'', l_current_pos );'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(12) := '           p := instr( lower(l_string), ''ftp://'', l_current_pos   );'||wwv_flow.LF||
'            -- set n to positio';
wwv_flow_imp.g_varchar2_table(13) := 'n of first link'||wwv_flow.LF||
'            if m > 0 and (n = 0 or m < n) and (p = 0 or m < p) then'||wwv_flow.LF||
'               n';
wwv_flow_imp.g_varchar2_table(14) := ' := m;'||wwv_flow.LF||
'            elsif p > 0 and (n = 0 or p < n) then'||wwv_flow.LF||
'               n := p;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(15) := '            exit when n = 0 or length(l_string) > 32000;'||wwv_flow.LF||
'            for j in 0 .. length( l_string ';
wwv_flow_imp.g_varchar2_table(16) := ') - n loop'||wwv_flow.LF||
'                if ( instr( l_endofUrl, substr( l_string, n+j, 1 ) ) > 0 ) then'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(17) := '          l_url := rtrim( substr( l_string, n, j ), ''.''||chr(32)||chr(10) );'||wwv_flow.LF||
'                   l_ur';
wwv_flow_imp.g_varchar2_table(18) := 'l := ''<a href="'' || l_url || ''">'' || l_url || ''</a>'';'||wwv_flow.LF||
'                   l_string := substr( l_strin';
wwv_flow_imp.g_varchar2_table(19) := 'g, 1, n-1 ) || l_url || substr( l_string, n+j );'||wwv_flow.LF||
'                   l_current_pos := n + length(l_ur';
wwv_flow_imp.g_varchar2_table(20) := 'l);'||wwv_flow.LF||
'                   exit;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(21) := ' return l_string;'||wwv_flow.LF||
'    end conv_urls_links;'||wwv_flow.LF||
'    function tags_cleaner ('||wwv_flow.LF||
'        p_tags  in varchar2,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(22) := '        p_case  in varchar2 default ''U'' )'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        type tags is table ';
wwv_flow_imp.g_varchar2_table(23) := 'of varchar2(255) index by varchar2(255);'||wwv_flow.LF||
'        l_tags_a        tags;'||wwv_flow.LF||
'        l_tag           varch';
wwv_flow_imp.g_varchar2_table(24) := 'ar2(255);'||wwv_flow.LF||
'        l_tags          apex_application_global.vc_arr2;'||wwv_flow.LF||
'        l_tags_string   varchar2(';
wwv_flow_imp.g_varchar2_table(25) := '32767);'||wwv_flow.LF||
'        i               integer;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        l_tags := apex_util.string_to_table(p_tag';
wwv_flow_imp.g_varchar2_table(26) := 's,'','');'||wwv_flow.LF||
'        for i in 1..l_tags.count loop'||wwv_flow.LF||
'            --remove all whitespace, including tabs, s';
wwv_flow_imp.g_varchar2_table(27) := 'paces, line feeds and carraige returns with a single space'||wwv_flow.LF||
'            l_tag := substr(trim(regexp_r';
wwv_flow_imp.g_varchar2_table(28) := 'eplace(l_tags(i),''[[:space:]]{1,}'','' '')),1,255);'||wwv_flow.LF||
'            if l_tag is not null and l_tag != '' '' t';
wwv_flow_imp.g_varchar2_table(29) := 'hen'||wwv_flow.LF||
'                if p_case = ''U'' then'||wwv_flow.LF||
'                    l_tag := upper(l_tag);'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(30) := 'elsif p_case = ''L'' then'||wwv_flow.LF||
'                    l_tag := lower(l_tag);'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(31) := '       --add it to the associative array, if it is a duplicate, it will just be replaced'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(32) := '     l_tags_a(l_tag) := l_tag;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        l_tag := null;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(33) := 'l_tag := l_tags_a.first;'||wwv_flow.LF||
'        while l_tag is not null loop'||wwv_flow.LF||
'            l_tags_string := l_tags_st';
wwv_flow_imp.g_varchar2_table(34) := 'ring||l_tag;'||wwv_flow.LF||
'            if l_tag != l_tags_a.last then'||wwv_flow.LF||
'                l_tags_string := l_tags_stri';
wwv_flow_imp.g_varchar2_table(35) := 'ng || '', '';'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            l_tag := l_tags_a.next(l_tag);'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(36) := ' return substr(l_tags_string, 1, 4000);'||wwv_flow.LF||
'    end tags_cleaner;'||wwv_flow.LF||
'    procedure tag_sync ('||wwv_flow.LF||
'        p_new';
wwv_flow_imp.g_varchar2_table(37) := '_tags          in varchar2,'||wwv_flow.LF||
'        p_old_tags          in varchar2,'||wwv_flow.LF||
'        p_content_type      in ';
wwv_flow_imp.g_varchar2_table(38) := 'varchar2,'||wwv_flow.LF||
'        p_content_id        in number )'||wwv_flow.LF||
'    as'||wwv_flow.LF||
'        type tags is table of varchar2(255)';
wwv_flow_imp.g_varchar2_table(39) := ' index by varchar2(255);'||wwv_flow.LF||
'        l_new_tags_a    tags;'||wwv_flow.LF||
'        l_old_tags_a    tags;'||wwv_flow.LF||
'        l_new_t';
wwv_flow_imp.g_varchar2_table(40) := 'ags      apex_application_global.vc_arr2;'||wwv_flow.LF||
'        l_old_tags      apex_application_global.vc_arr2;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(41) := '       l_merge_tags    apex_application_global.vc_arr2;'||wwv_flow.LF||
'        l_dummy_tag     varchar2(255);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(42) := '   i               integer;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        l_old_tags := apex_util.string_to_table(p_old_tags,'', ';
wwv_flow_imp.g_varchar2_table(43) := ''');'||wwv_flow.LF||
'        l_new_tags := apex_util.string_to_table(p_new_tags,'', '');'||wwv_flow.LF||
'        if l_old_tags.count > ';
wwv_flow_imp.g_varchar2_table(44) := '0 then --do inserts and deletes'||wwv_flow.LF||
'            --build the associative arrays'||wwv_flow.LF||
'            for i in 1..l';
wwv_flow_imp.g_varchar2_table(45) := '_old_tags.count loop'||wwv_flow.LF||
'                l_old_tags_a(l_old_tags(i)) := l_old_tags(i);'||wwv_flow.LF||
'            end l';
wwv_flow_imp.g_varchar2_table(46) := 'oop;'||wwv_flow.LF||
'            for i in 1..l_new_tags.count loop'||wwv_flow.LF||
'                l_new_tags_a(l_new_tags(i)) := l_';
wwv_flow_imp.g_varchar2_table(47) := 'new_tags(i);'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'            --do the inserts'||wwv_flow.LF||
'            for i in 1..l_new_tags.c';
wwv_flow_imp.g_varchar2_table(48) := 'ount loop'||wwv_flow.LF||
'                begin'||wwv_flow.LF||
'                    l_dummy_tag := l_old_tags_a(l_new_tags(i));'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(49) := '            exception when no_data_found then'||wwv_flow.LF||
'                    insert into eba_ca_tags (tag, cont';
wwv_flow_imp.g_varchar2_table(50) := 'ent_id, content_type )'||wwv_flow.LF||
'                    values (l_new_tags(i), p_content_id, p_content_type );'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(51) := '                  l_merge_tags(l_merge_tags.count + 1) := l_new_tags(i);'||wwv_flow.LF||
'                end;'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(52) := '      end loop;'||wwv_flow.LF||
'            --do the deletes'||wwv_flow.LF||
'            for i in 1..l_old_tags.count loop'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(53) := '       begin'||wwv_flow.LF||
'                    l_dummy_tag := l_new_tags_a(l_old_tags(i));'||wwv_flow.LF||
'                excepti';
wwv_flow_imp.g_varchar2_table(54) := 'on when no_data_found then'||wwv_flow.LF||
'                    delete from eba_ca_tags where content_id = p_content_';
wwv_flow_imp.g_varchar2_table(55) := 'id and tag = l_old_tags(i);'||wwv_flow.LF||
'                    l_merge_tags(l_merge_tags.count + 1) := l_old_tags(i';
wwv_flow_imp.g_varchar2_table(56) := ');'||wwv_flow.LF||
'                end;'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'        else --just do inserts'||wwv_flow.LF||
'            for i in 1.';
wwv_flow_imp.g_varchar2_table(57) := '.l_new_tags.count loop'||wwv_flow.LF||
'                insert into eba_ca_tags (tag, content_id, content_type )'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(58) := '            values (l_new_tags(i), p_content_id, p_content_type );'||wwv_flow.LF||
'                l_merge_tags(l_me';
wwv_flow_imp.g_varchar2_table(59) := 'rge_tags.count + 1) := l_new_tags(i);'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        for i in 1..l_me';
wwv_flow_imp.g_varchar2_table(60) := 'rge_tags.count loop'||wwv_flow.LF||
'            merge into eba_ca_tags_type_sum s'||wwv_flow.LF||
'            using (select count(*)';
wwv_flow_imp.g_varchar2_table(61) := ' tag_count'||wwv_flow.LF||
'                     from eba_ca_tags'||wwv_flow.LF||
'                    where tag = l_merge_tags(i) and';
wwv_flow_imp.g_varchar2_table(62) := ' content_type = p_content_type ) t'||wwv_flow.LF||
'            on (s.tag = l_merge_tags(i) and s.content_type = p_co';
wwv_flow_imp.g_varchar2_table(63) := 'ntent_type )'||wwv_flow.LF||
'            when not matched then insert (tag, content_type, tag_count)'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(64) := '                   values (l_merge_tags(i), p_content_type, t.tag_count)'||wwv_flow.LF||
'            when matched th';
wwv_flow_imp.g_varchar2_table(65) := 'en update set s.tag_count = t.tag_count;'||wwv_flow.LF||
'            merge into eba_ca_tags_sum s'||wwv_flow.LF||
'            using ';
wwv_flow_imp.g_varchar2_table(66) := '(select sum(tag_count) tag_count'||wwv_flow.LF||
'                     from eba_ca_tags_type_sum'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(67) := 'where tag = l_merge_tags(i) ) t'||wwv_flow.LF||
'            on (s.tag = l_merge_tags(i) )'||wwv_flow.LF||
'            when not match';
wwv_flow_imp.g_varchar2_table(68) := 'ed then insert (tag, tag_count)'||wwv_flow.LF||
'                                  values (l_merge_tags(i), t.tag_cou';
wwv_flow_imp.g_varchar2_table(69) := 'nt)'||wwv_flow.LF||
'            when matched then update set s.tag_count = t.tag_count;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'    end ta';
wwv_flow_imp.g_varchar2_table(70) := 'g_sync;'||wwv_flow.LF||
'    function selective_escape ('||wwv_flow.LF||
'        p_text  in varchar2,'||wwv_flow.LF||
'        p_tags  in varchar2 def';
wwv_flow_imp.g_varchar2_table(71) := 'ault ''<h2>,</h2>,<p>,</p>,<b>,</b>,<li>,</li>,<ul>,</ul>,<br />,<i>,</i>,<h3>,</h3>'''||wwv_flow.LF||
'        ) retur';
wwv_flow_imp.g_varchar2_table(72) := 'n varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        t apex_application_global.vc_arr2;'||wwv_flow.LF||
'        x varchar2(32767) := p_text;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(73) := '  begin'||wwv_flow.LF||
'        t := apex_util.string_to_table(p_tags, '','');'||wwv_flow.LF||
'        for i in 1..t.count loop'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(74) := '      x := replace(x,t(i),''Aa''||i||''aA'');'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        x := apex_escape.html(x);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(75) := '  for i in 1..t.count loop'||wwv_flow.LF||
'            x := replace(x,''Aa''||i||''aA'',t(i));'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(76) := ' return x;'||wwv_flow.LF||
'    end selective_escape;'||wwv_flow.LF||
'    function get_preference_value ('||wwv_flow.LF||
'        p_preference_name v';
wwv_flow_imp.g_varchar2_table(77) := 'archar2 )'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_preference_value varchar2(255);'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(78) := ' select preference_value'||wwv_flow.LF||
'            into l_preference_value'||wwv_flow.LF||
'        from eba_ca_preferences'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(79) := ' where preference_name = p_preference_name;'||wwv_flow.LF||
'        return l_preference_value;'||wwv_flow.LF||
'    exception'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(80) := ' when no_data_found then'||wwv_flow.LF||
'            return ''Preference does not exist'';'||wwv_flow.LF||
'    end get_preference_valu';
wwv_flow_imp.g_varchar2_table(81) := 'e;'||wwv_flow.LF||
'    procedure set_preference_value ('||wwv_flow.LF||
'        p_preference_name  varchar2, '||wwv_flow.LF||
'        p_preference_v';
wwv_flow_imp.g_varchar2_table(82) := 'alue varchar2 )'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        merge into eba_ca_preferences dest'||wwv_flow.LF||
'        using ( select u';
wwv_flow_imp.g_varchar2_table(83) := 'pper(p_preference_name) preference_name,'||wwv_flow.LF||
'                    p_preference_value preference_value'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(84) := '             from dual ) src'||wwv_flow.LF||
'        on ( upper(dest.preference_name) = src.preference_name )'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(85) := '  when matched then'||wwv_flow.LF||
'            update set dest.preference_value = src.preference_value'||wwv_flow.LF||
'        when';
wwv_flow_imp.g_varchar2_table(86) := ' not matched then'||wwv_flow.LF||
'            insert (dest.preference_name, dest.preference_value)'||wwv_flow.LF||
'            value';
wwv_flow_imp.g_varchar2_table(87) := 's (src.preference_name, src.preference_value);'||wwv_flow.LF||
'    end set_preference_value;'||wwv_flow.LF||
'    function compress_i';
wwv_flow_imp.g_varchar2_table(88) := 'nt ('||wwv_flow.LF||
'        n in integer )'||wwv_flow.LF||
'        return varchar2'||wwv_flow.LF||
'    as'||wwv_flow.LF||
'        ret varchar2(30);'||wwv_flow.LF||
'        quotien';
wwv_flow_imp.g_varchar2_table(89) := 't integer;'||wwv_flow.LF||
'        remainder integer;'||wwv_flow.LF||
'        digit char(1);'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        ret := '''';'||wwv_flow.LF||
'        qu';
wwv_flow_imp.g_varchar2_table(90) := 'otient := n;'||wwv_flow.LF||
'        while quotient > 0'||wwv_flow.LF||
'        loop'||wwv_flow.LF||
'            remainder := mod(quotient, 10 + 26)';
wwv_flow_imp.g_varchar2_table(91) := ';'||wwv_flow.LF||
'            quotient := floor(quotient  / (10 + 26));'||wwv_flow.LF||
'            if remainder < 26 then'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(92) := '       digit := chr(ascii(''A'') + remainder);'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'                digit := chr(ascii(''0''';
wwv_flow_imp.g_varchar2_table(93) := ') + remainder - 26);'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            ret := digit || ret;'||wwv_flow.LF||
'        end loop ;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(94) := ' if length(ret) < 5 then'||wwv_flow.LF||
'            ret := lpad(ret, 4, ''A'');'||wwv_flow.LF||
'        end if ;'||wwv_flow.LF||
'        return upper';
wwv_flow_imp.g_varchar2_table(95) := '(ret);'||wwv_flow.LF||
'    end compress_int;'||wwv_flow.LF||
'    procedure add_error_log ( '||wwv_flow.LF||
'        p_error in apex_error.t_error )'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(96) := '    is'||wwv_flow.LF||
'    pragma autonomous_transaction;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        -- Remove old errors'||wwv_flow.LF||
'        delete from';
wwv_flow_imp.g_varchar2_table(97) := ' eba_ca_errors where err_time <= current_timestamp - 21;'||wwv_flow.LF||
'        -- Log the error.'||wwv_flow.LF||
'        insert in';
wwv_flow_imp.g_varchar2_table(98) := 'to eba_ca_errors ('||wwv_flow.LF||
'            app_id,'||wwv_flow.LF||
'            app_page_id,'||wwv_flow.LF||
'            app_user,'||wwv_flow.LF||
'            us';
wwv_flow_imp.g_varchar2_table(99) := 'er_agent,'||wwv_flow.LF||
'            ip_address,'||wwv_flow.LF||
'            ip_address2,'||wwv_flow.LF||
'            message,'||wwv_flow.LF||
'            page_ite';
wwv_flow_imp.g_varchar2_table(100) := 'm_name,'||wwv_flow.LF||
'            region_id,'||wwv_flow.LF||
'            column_alias,'||wwv_flow.LF||
'            row_num,'||wwv_flow.LF||
'            apex_error';
wwv_flow_imp.g_varchar2_table(101) := '_code,'||wwv_flow.LF||
'            ora_sqlcode,'||wwv_flow.LF||
'            ora_sqlerrm,'||wwv_flow.LF||
'            error_backtrace )'||wwv_flow.LF||
'        selec';
wwv_flow_imp.g_varchar2_table(102) := 't v(''APP_ID''),'||wwv_flow.LF||
'            v(''APP_PAGE_ID''),'||wwv_flow.LF||
'            v(''APP_USER''),'||wwv_flow.LF||
'            owa_util.get_cgi';
wwv_flow_imp.g_varchar2_table(103) := '_env(''HTTP_USER_AGENT''),'||wwv_flow.LF||
'            owa_util.get_cgi_env(''REMOTE_ADDR''),'||wwv_flow.LF||
'            sys_context(''U';
wwv_flow_imp.g_varchar2_table(104) := 'SERENV'', ''IP_ADDRESS''),'||wwv_flow.LF||
'            substr(p_error.message,0,4000),'||wwv_flow.LF||
'            p_error.page_item_na';
wwv_flow_imp.g_varchar2_table(105) := 'me,'||wwv_flow.LF||
'            p_error.region_id,'||wwv_flow.LF||
'            p_error.column_alias,'||wwv_flow.LF||
'            p_error.row_num,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(106) := '          p_error.apex_error_code,'||wwv_flow.LF||
'            p_error.ora_sqlcode,'||wwv_flow.LF||
'            substr(p_error.ora_s';
wwv_flow_imp.g_varchar2_table(107) := 'qlerrm,0,4000),'||wwv_flow.LF||
'            substr(p_error.error_backtrace,0,4000)'||wwv_flow.LF||
'        from dual;'||wwv_flow.LF||
'        commit';
wwv_flow_imp.g_varchar2_table(108) := ';'||wwv_flow.LF||
'    end add_error_log;'||wwv_flow.LF||
'    function apex_error_handling ('||wwv_flow.LF||
'        p_error in apex_error.t_error )'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(109) := '        return apex_error.t_error_result'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_result          apex_error.t_error_result;';
wwv_flow_imp.g_varchar2_table(110) := ''||wwv_flow.LF||
'        l_constraint_name varchar2(255);'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        l_result := apex_error.init_error_result';
wwv_flow_imp.g_varchar2_table(111) := ' ('||wwv_flow.LF||
'                        p_error => p_error );'||wwv_flow.LF||
'        -- If it is an internal error raised by APE';
wwv_flow_imp.g_varchar2_table(112) := 'X, like an invalid statement or'||wwv_flow.LF||
'        -- code which can not be executed, the error text might cont';
wwv_flow_imp.g_varchar2_table(113) := 'ain security sensitive'||wwv_flow.LF||
'        -- information. To avoid this security problem we can rewrite the err';
wwv_flow_imp.g_varchar2_table(114) := 'or to'||wwv_flow.LF||
'        -- a generic error message and log the original error message for further'||wwv_flow.LF||
'        -- i';
wwv_flow_imp.g_varchar2_table(115) := 'nvestigation by the help desk.'||wwv_flow.LF||
'        if p_error.is_internal_error then'||wwv_flow.LF||
'            -- mask all err';
wwv_flow_imp.g_varchar2_table(116) := 'ors that are not common runtime errors (Access Denied'||wwv_flow.LF||
'            -- errors raised by application / ';
wwv_flow_imp.g_varchar2_table(117) := 'page authorization and all errors'||wwv_flow.LF||
'            -- regarding session and session state)'||wwv_flow.LF||
'            if';
wwv_flow_imp.g_varchar2_table(118) := ' not p_error.is_common_runtime_error then'||wwv_flow.LF||
'                add_error_log( p_error );'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(119) := '-- Change the message to the generic error message which doesn''t expose'||wwv_flow.LF||
'                -- any sensi';
wwv_flow_imp.g_varchar2_table(120) := 'tive information.'||wwv_flow.LF||
'                l_result.message         := ''An unexpected internal application er';
wwv_flow_imp.g_varchar2_table(121) := 'ror has occurred.'';'||wwv_flow.LF||
'                l_result.additional_info := null;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'        el';
wwv_flow_imp.g_varchar2_table(122) := 'se'||wwv_flow.LF||
'            -- Always show the error as inline error'||wwv_flow.LF||
'            -- Note: If you have created man';
wwv_flow_imp.g_varchar2_table(123) := 'ual tabular forms (using the package'||wwv_flow.LF||
'            --       apex_item/htmldb_item in the SQL statement';
wwv_flow_imp.g_varchar2_table(124) := ') you should still'||wwv_flow.LF||
'            --       use "On error page" on that pages to avoid loosing entered d';
wwv_flow_imp.g_varchar2_table(125) := 'ata'||wwv_flow.LF||
'            l_result.display_location := case'||wwv_flow.LF||
'                                           when l_';
wwv_flow_imp.g_varchar2_table(126) := 'result.display_location = apex_error.c_on_error_page then apex_error.c_inline_in_notification'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(127) := '                                     else l_result.display_location'||wwv_flow.LF||
'                                ';
wwv_flow_imp.g_varchar2_table(128) := '         end;'||wwv_flow.LF||
'            -- If it''s a constraint violation like'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            --   -) ';
wwv_flow_imp.g_varchar2_table(129) := 'ORA-00001: unique constraint violated'||wwv_flow.LF||
'            --   -) ORA-02091: transaction rolled back (-> can';
wwv_flow_imp.g_varchar2_table(130) := ' hide a deferred constraint)'||wwv_flow.LF||
'            --   -) ORA-02290: check constraint violated'||wwv_flow.LF||
'            --';
wwv_flow_imp.g_varchar2_table(131) := '   -) ORA-02291: integrity constraint violated - parent key not found'||wwv_flow.LF||
'            --   -) ORA-02292:';
wwv_flow_imp.g_varchar2_table(132) := ' integrity constraint violated - child record found'||wwv_flow.LF||
'            --'||wwv_flow.LF||
'            -- we try to get a fr';
wwv_flow_imp.g_varchar2_table(133) := 'iendly error message from our constraint lookup configuration.'||wwv_flow.LF||
'            -- If we don''t find the c';
wwv_flow_imp.g_varchar2_table(134) := 'onstraint in our lookup table we fallback to'||wwv_flow.LF||
'            -- the original ORA error message.'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(135) := '    if p_error.ora_sqlcode in (-1, -2091, -2290, -2291, -2292) then'||wwv_flow.LF||
'                l_constraint_nam';
wwv_flow_imp.g_varchar2_table(136) := 'e := apex_error.extract_constraint_name ('||wwv_flow.LF||
'                                         p_error => p_erro';
wwv_flow_imp.g_varchar2_table(137) := 'r );'||wwv_flow.LF||
'                begin'||wwv_flow.LF||
'                    select message'||wwv_flow.LF||
'                      into l_result.me';
wwv_flow_imp.g_varchar2_table(138) := 'ssage'||wwv_flow.LF||
'                      from eba_ca_error_lookup'||wwv_flow.LF||
'                     where constraint_name = l_';
wwv_flow_imp.g_varchar2_table(139) := 'constraint_name;'||wwv_flow.LF||
'                exception when no_data_found then null; -- not every constraint has';
wwv_flow_imp.g_varchar2_table(140) := ' to be in our lookup table'||wwv_flow.LF||
'                end;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            -- If an ORA error h';
wwv_flow_imp.g_varchar2_table(141) := 'as been raised, for example a raise_application_error(-20xxx, ''...'')'||wwv_flow.LF||
'            -- in a table trigg';
wwv_flow_imp.g_varchar2_table(142) := 'er or in a PL/SQL package called by a process and we'||wwv_flow.LF||
'            -- haven''t found the error in our l';
wwv_flow_imp.g_varchar2_table(143) := 'ookup table, then we just want to see'||wwv_flow.LF||
'            -- the actual error text and not the full error st';
wwv_flow_imp.g_varchar2_table(144) := 'ack with all the ORA error numbers.'||wwv_flow.LF||
'            if p_error.ora_sqlcode is not null and l_result.mess';
wwv_flow_imp.g_varchar2_table(145) := 'age = p_error.message then'||wwv_flow.LF||
'                l_result.message := apex_error.get_first_ora_error_text (';
wwv_flow_imp.g_varchar2_table(146) := ''||wwv_flow.LF||
'                                        p_error => p_error );'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            -- If';
wwv_flow_imp.g_varchar2_table(147) := ' no associated page item/tabular form column has been set, we can use'||wwv_flow.LF||
'            -- apex_error.auto';
wwv_flow_imp.g_varchar2_table(148) := '_set_associated_item to automatically guess the affected'||wwv_flow.LF||
'            -- error field by examine the O';
wwv_flow_imp.g_varchar2_table(149) := 'RA error for constraint names or column names.'||wwv_flow.LF||
'            if l_result.page_item_name is null and l_';
wwv_flow_imp.g_varchar2_table(150) := 'result.column_alias is null then'||wwv_flow.LF||
'                apex_error.auto_set_associated_item ('||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(151) := '       p_error        => p_error,'||wwv_flow.LF||
'                    p_error_result => l_result );'||wwv_flow.LF||
'            end ';
wwv_flow_imp.g_varchar2_table(152) := 'if;'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        return l_result;'||wwv_flow.LF||
'    end apex_error_handling;'||wwv_flow.LF||
'end eba_ca_fw;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show erro';
wwv_flow_imp.g_varchar2_table(153) := 'rs';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1326986348855207156)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'Framework Body'
,p_sequence=>10
,p_script_type=>'UPGRADE'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
