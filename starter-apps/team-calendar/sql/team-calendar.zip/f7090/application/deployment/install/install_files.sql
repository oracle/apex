prompt --application/deployment/install/install_files
begin
--   Manifest
--     INSTALL: INSTALL-files
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE eba_ca_FILES '||wwv_flow.LF||
'   (   '||wwv_flow.LF||
'    ID                   NUMBER constraint eba_ca_FILES_PK primar';
wwv_flow_imp.g_varchar2_table(2) := 'y key, '||wwv_flow.LF||
'    ROW_VERSION_NUMBER   NUMBER, '||wwv_flow.LF||
'    EVENT_ID             NUMBER references eba_ca_events (';
wwv_flow_imp.g_varchar2_table(3) := 'event_id) on delete cascade, '||wwv_flow.LF||
'    FILENAME             VARCHAR2(4000 BYTE), '||wwv_flow.LF||
'    FILE_MIMETYPE      ';
wwv_flow_imp.g_varchar2_table(4) := '  VARCHAR2(512 BYTE), '||wwv_flow.LF||
'    FILE_CHARSET         VARCHAR2(512 BYTE), '||wwv_flow.LF||
'    FILE_BLOB            BLOB, ';
wwv_flow_imp.g_varchar2_table(5) := ''||wwv_flow.LF||
'    FILE_COMMENTS        VARCHAR2(4000 BYTE), '||wwv_flow.LF||
'    TAGS                 VARCHAR2(4000 BYTE), '||wwv_flow.LF||
'    C';
wwv_flow_imp.g_varchar2_table(6) := 'REATED              timestamp with time zone, '||wwv_flow.LF||
'    CREATED_BY           VARCHAR2(255 BYTE), '||wwv_flow.LF||
'    UPD';
wwv_flow_imp.g_varchar2_table(7) := 'ATED              timestamp with time zone, '||wwv_flow.LF||
'    UPDATED_BY           VARCHAR2(255 BYTE)'||wwv_flow.LF||
'   )  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'cr';
wwv_flow_imp.g_varchar2_table(8) := 'eate index eba_ca_FILES_i1 on eba_ca_FILES(event_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER BIU_eba_ca_FILES '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(9) := '  before insert or update on eba_ca_files'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  if :new.ID is null then'||wwv_flow.LF||
'    select';
wwv_flow_imp.g_varchar2_table(10) := ' to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
'  if ins';
wwv_flow_imp.g_varchar2_table(11) := 'erting then'||wwv_flow.LF||
'    :new.created := current_timestamp;'||wwv_flow.LF||
'    :new.created_by := nvl(wwv_flow.g_user,user);';
wwv_flow_imp.g_varchar2_table(12) := ''||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'    :new.r';
wwv_flow_imp.g_varchar2_table(13) := 'ow_version_number := 1;'||wwv_flow.LF||
'  elsif updating then'||wwv_flow.LF||
'    :new.row_version_number := nvl(:old.row_version_nu';
wwv_flow_imp.g_varchar2_table(14) := 'mber,1) + 1;'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
'  if (inserting or updating) and nvl(dbms_lob.getlength(:new.file_blob),0) > ';
wwv_flow_imp.g_varchar2_table(15) := '15728640 then'||wwv_flow.LF||
'    raise_application_error(-20000, ''The size of the uploaded file was over 15MB. Plea';
wwv_flow_imp.g_varchar2_table(16) := 'se upload a smaller file.'');'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
'  if inserting or updating then'||wwv_flow.LF||
'    :new.updated := current_t';
wwv_flow_imp.g_varchar2_table(17) := 'imestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'ALTER TRIG';
wwv_flow_imp.g_varchar2_table(18) := 'GER BIU_eba_ca_FILES ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3256259467405174322)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'files'
,p_sequence=>212
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
