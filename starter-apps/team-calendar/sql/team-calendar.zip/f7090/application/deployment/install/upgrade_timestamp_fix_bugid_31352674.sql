prompt --application/deployment/install/upgrade_timestamp_fix_bugid_31352674
begin
--   Manifest
--     INSTALL: UPGRADE-TIMESTAMP Fix (BUGID: 31352674)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- This script fixes BUG 31352674, replacing all columns of type TIMESTAMP(6) WITH LOCAL TIME ZONE t';
wwv_flow_imp.g_varchar2_table(2) := 'o TIMESTAMP WITH TIME ZONE'||wwv_flow.LF||
'-- it also updates all application triggers where columns where updated w';
wwv_flow_imp.g_varchar2_table(3) := 'ith LOCALTIMESTAMP to CURRENT_TIMESTAMP'||wwv_flow.LF||
'-- '||wwv_flow.LF||
'-- This upgrade script will only run if there are tables';
wwv_flow_imp.g_varchar2_table(4) := ' that start with ''EBA_CA%'' with columns of data type'||wwv_flow.LF||
'-- TIMESTAMP(6) WITH LOCAL TIME ZONE'||wwv_flow.LF||
''||wwv_flow.LF||
'-- 1 Disa';
wwv_flow_imp.g_varchar2_table(5) := 'ble all triggers.'||wwv_flow.LF||
'alter trigger "BI_EBA_CA_ERRORS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CA_COLOR_PREFS"';
wwv_flow_imp.g_varchar2_table(6) := ' DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CA_EVENT_TYPES_BIU" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CA_HISTORY" DIS';
wwv_flow_imp.g_varchar2_table(7) := 'ABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CA_SERIES_BIU" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CA_TAGS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alte';
wwv_flow_imp.g_varchar2_table(8) := 'r trigger "EBA_CA_CALENDARS_BIU" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "AD_EBA_CA_EVENTS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigge';
wwv_flow_imp.g_varchar2_table(9) := 'r "EBA_CA_EVENTS_BIU" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BD_EBA_CA_EVENTS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "AU_EBA_C';
wwv_flow_imp.g_varchar2_table(10) := 'A_EVENTS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "AI_EBA_CA_EVENTS" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CA_NOTES" DI';
wwv_flow_imp.g_varchar2_table(11) := 'SABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CA_FILES" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CA_EMAIL_GROUPS_BIU" DISABLE';
wwv_flow_imp.g_varchar2_table(12) := ';'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CA_EMAIL_GROUP_MBRS_BIU" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CA_TIMEFRAMES_BIU" DIS';
wwv_flow_imp.g_varchar2_table(13) := 'ABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'--TABLE and TRIGGER NO LONGER EXISTS AT THIS POINT.'||wwv_flow.LF||
'--alter trigger "EBA_CA_ADMINS_BIU" DISA';
wwv_flow_imp.g_varchar2_table(14) := 'BLE;'||wwv_flow.LF||
'--/'||wwv_flow.LF||
'alter trigger "EBA_CA_NOTE_BIU" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "BIU_EBA_CA_TZ_PREF" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'al';
wwv_flow_imp.g_varchar2_table(15) := 'ter trigger "EBA_CA_USERS_BD" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "EBA_CA_USERS_BIU" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger "';
wwv_flow_imp.g_varchar2_table(16) := 'EBA_CA_PREFERENCES_BIU" DISABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- 2 Add temporary timestamp columns'||wwv_flow.LF||
'alter table EBA_CA_ERRORS a';
wwv_flow_imp.g_varchar2_table(17) := 'dd (ERR_TIME1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_COLOR_PREFS add (CREATED1 timestamp wit';
wwv_flow_imp.g_varchar2_table(18) := 'h time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_EVENT_TYPES add (CREATED_ON1 tim';
wwv_flow_imp.g_varchar2_table(19) := 'estamp with time zone,LAST_UPDATED_ON1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_HISTORY add (C';
wwv_flow_imp.g_varchar2_table(20) := 'HANGE_DATE1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_SERIES add (START_DATE1 timestamp with ti';
wwv_flow_imp.g_varchar2_table(21) := 'me zone,END_DATE1 timestamp with time zone,CREATED_ON1 timestamp with time zone,LAST_UPDATED_ON1 tim';
wwv_flow_imp.g_varchar2_table(22) := 'estamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_TAGS add (CREATED1 timestamp with time zone,UPDATED1 tim';
wwv_flow_imp.g_varchar2_table(23) := 'estamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_CALENDARS add (CREATED_ON1 timestamp with time zone,LAST';
wwv_flow_imp.g_varchar2_table(24) := '_UPDATED_ON1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_EVENTS add (EVENT_DATE_TIME1 timestamp w';
wwv_flow_imp.g_varchar2_table(25) := 'ith time zone,CREATED_ON1 timestamp with time zone,LAST_UPDATED_ON1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alte';
wwv_flow_imp.g_varchar2_table(26) := 'r table EBA_CA_NOTES add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alt';
wwv_flow_imp.g_varchar2_table(27) := 'er table EBA_CA_FILES add (CREATED1 timestamp with time zone,UPDATED1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'al';
wwv_flow_imp.g_varchar2_table(28) := 'ter table EBA_CA_EMAIL_GROUPS add (CREATED_ON1 timestamp with time zone,LAST_UPDATED_ON1 timestamp w';
wwv_flow_imp.g_varchar2_table(29) := 'ith time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_EMAIL_GROUP_MBRS add (CREATED_ON1 timestamp with time zone,LAST_';
wwv_flow_imp.g_varchar2_table(30) := 'UPDATED_ON1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_TIMEFRAMES add (CREATED_ON1 timestamp wit';
wwv_flow_imp.g_varchar2_table(31) := 'h time zone,LAST_UPDATED_ON1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'--TABLE and TRIGGER NO LONGER EXISTS AT THI';
wwv_flow_imp.g_varchar2_table(32) := 'S POINT.'||wwv_flow.LF||
'--alter table EBA_CA_ADMINS add (CREATED_ON1 timestamp with time zone,LAST_UPDATED_ON1 time';
wwv_flow_imp.g_varchar2_table(33) := 'stamp with time zone)'||wwv_flow.LF||
'--/'||wwv_flow.LF||
'alter table EBA_CA_NOTIFICATIONS add (DISPLAY_FROM1 timestamp with time zo';
wwv_flow_imp.g_varchar2_table(34) := 'ne,DISPLAY_UNTIL1 timestamp with time zone,CREATED1 timestamp with time zone,UPDATED1 timestamp with';
wwv_flow_imp.g_varchar2_table(35) := ' time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_TZ_PREF add (CREATED1 timestamp with time zone,UPDATED1 timestamp w';
wwv_flow_imp.g_varchar2_table(36) := 'ith time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_USERS add (CREATED1 timestamp with time zone,UPDATED1 timestamp ';
wwv_flow_imp.g_varchar2_table(37) := 'with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_PREFERENCES add (CREATED_ON1 timestamp with time zone,UPDATED_O';
wwv_flow_imp.g_varchar2_table(38) := 'N1 timestamp with time zone)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Copy original column values into temporary column values'||wwv_flow.LF||
'update E';
wwv_flow_imp.g_varchar2_table(39) := 'BA_CA_ERRORS set ERR_TIME1 = ERR_TIME;'||wwv_flow.LF||
'update EBA_CA_COLOR_PREFS set CREATED1 = CREATED,UPDATED1 = U';
wwv_flow_imp.g_varchar2_table(40) := 'PDATED;'||wwv_flow.LF||
'update EBA_CA_EVENT_TYPES set CREATED_ON1 = CREATED_ON,LAST_UPDATED_ON1 = LAST_UPDATED_ON;'||wwv_flow.LF||
'u';
wwv_flow_imp.g_varchar2_table(41) := 'pdate EBA_CA_HISTORY set CHANGE_DATE1 = CHANGE_DATE;'||wwv_flow.LF||
'update EBA_CA_SERIES set START_DATE1 = START_DA';
wwv_flow_imp.g_varchar2_table(42) := 'TE,END_DATE1 = END_DATE,CREATED_ON1 = CREATED_ON,LAST_UPDATED_ON1 = LAST_UPDATED_ON;'||wwv_flow.LF||
'update EBA_CA_T';
wwv_flow_imp.g_varchar2_table(43) := 'AGS set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CA_CALENDARS set CREATED_ON1 = CREATED_ON,';
wwv_flow_imp.g_varchar2_table(44) := 'LAST_UPDATED_ON1 = LAST_UPDATED_ON;'||wwv_flow.LF||
'update EBA_CA_EVENTS set EVENT_DATE_TIME1 = EVENT_DATE_TIME,CREA';
wwv_flow_imp.g_varchar2_table(45) := 'TED_ON1 = CREATED_ON,LAST_UPDATED_ON1 = LAST_UPDATED_ON;'||wwv_flow.LF||
'update EBA_CA_NOTES set CREATED1 = CREATED,';
wwv_flow_imp.g_varchar2_table(46) := 'UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CA_FILES set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CA_EMA';
wwv_flow_imp.g_varchar2_table(47) := 'IL_GROUPS set CREATED_ON1 = CREATED_ON,LAST_UPDATED_ON1 = LAST_UPDATED_ON;'||wwv_flow.LF||
'update EBA_CA_EMAIL_GROUP';
wwv_flow_imp.g_varchar2_table(48) := '_MBRS set CREATED_ON1 = CREATED_ON,LAST_UPDATED_ON1 = LAST_UPDATED_ON;'||wwv_flow.LF||
'update EBA_CA_TIMEFRAMES set ';
wwv_flow_imp.g_varchar2_table(49) := 'CREATED_ON1 = CREATED_ON,LAST_UPDATED_ON1 = LAST_UPDATED_ON;'||wwv_flow.LF||
'--TABLE and TRIGGER NO LONGER EXISTS AT';
wwv_flow_imp.g_varchar2_table(50) := ' THIS POINT.'||wwv_flow.LF||
'--update EBA_CA_ADMINS set CREATED_ON1 = CREATED_ON,LAST_UPDATED_ON1 = LAST_UPDATED_ON;';
wwv_flow_imp.g_varchar2_table(51) := ''||wwv_flow.LF||
'update EBA_CA_NOTIFICATIONS set DISPLAY_FROM1 = DISPLAY_FROM,DISPLAY_UNTIL1 = DISPLAY_UNTIL,CREATED';
wwv_flow_imp.g_varchar2_table(52) := '1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CA_TZ_PREF set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'upd';
wwv_flow_imp.g_varchar2_table(53) := 'ate EBA_CA_USERS set CREATED1 = CREATED,UPDATED1 = UPDATED;'||wwv_flow.LF||
'update EBA_CA_PREFERENCES set CREATED_ON';
wwv_flow_imp.g_varchar2_table(54) := '1 = CREATED_ON,UPDATED_ON1 = UPDATED_ON;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- 3 Drop original timestamp with local time zone columns'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(55) := 'alter table EBA_CA_ERRORS drop (ERR_TIME)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_COLOR_PREFS drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(56) := 'alter table EBA_CA_EVENT_TYPES drop (CREATED_ON,LAST_UPDATED_ON)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_HISTORY drop (';
wwv_flow_imp.g_varchar2_table(57) := 'CHANGE_DATE)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_SERIES drop (START_DATE,END_DATE,CREATED_ON,LAST_UPDATED_ON)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alt';
wwv_flow_imp.g_varchar2_table(58) := 'er table EBA_CA_TAGS drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_CALENDARS drop (CREATED_ON,LAST_UPD';
wwv_flow_imp.g_varchar2_table(59) := 'ATED_ON)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_EVENTS drop (EVENT_DATE_TIME,CREATED_ON,LAST_UPDATED_ON)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table';
wwv_flow_imp.g_varchar2_table(60) := ' EBA_CA_NOTES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_FILES drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table';
wwv_flow_imp.g_varchar2_table(61) := ' EBA_CA_EMAIL_GROUPS drop (CREATED_ON,LAST_UPDATED_ON)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_EMAIL_GROUP_MBRS drop (C';
wwv_flow_imp.g_varchar2_table(62) := 'REATED_ON,LAST_UPDATED_ON)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_TIMEFRAMES drop (CREATED_ON,LAST_UPDATED_ON)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'--TAB';
wwv_flow_imp.g_varchar2_table(63) := 'LE and TRIGGER NO LONGER EXISTS AT THIS POINT.'||wwv_flow.LF||
'--alter table EBA_CA_ADMINS drop (CREATED_ON,LAST_UPD';
wwv_flow_imp.g_varchar2_table(64) := 'ATED_ON)'||wwv_flow.LF||
'--/'||wwv_flow.LF||
'alter table EBA_CA_NOTIFICATIONS drop (DISPLAY_FROM,DISPLAY_UNTIL,CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'al';
wwv_flow_imp.g_varchar2_table(65) := 'ter table EBA_CA_TZ_PREF drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_USERS drop (CREATED,UPDATED)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(66) := 'alter table EBA_CA_PREFERENCES drop (CREATED_ON,UPDATED_ON)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- 4 Rename temporary columns back to';
wwv_flow_imp.g_varchar2_table(67) := ' original column names'||wwv_flow.LF||
'alter table EBA_CA_ERRORS rename column ERR_TIME1 to ERR_TIME'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table E';
wwv_flow_imp.g_varchar2_table(68) := 'BA_CA_COLOR_PREFS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_COLOR_PREFS rename column U';
wwv_flow_imp.g_varchar2_table(69) := 'PDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_EVENT_TYPES rename column CREATED_ON1 to CREATED_ON'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter ';
wwv_flow_imp.g_varchar2_table(70) := 'table EBA_CA_EVENT_TYPES rename column LAST_UPDATED_ON1 to LAST_UPDATED_ON'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_HIST';
wwv_flow_imp.g_varchar2_table(71) := 'ORY rename column CHANGE_DATE1 to CHANGE_DATE'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_SERIES rename column START_DATE1 ';
wwv_flow_imp.g_varchar2_table(72) := 'to START_DATE'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_SERIES rename column END_DATE1 to END_DATE'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_S';
wwv_flow_imp.g_varchar2_table(73) := 'ERIES rename column CREATED_ON1 to CREATED_ON'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_SERIES rename column LAST_UPDATED';
wwv_flow_imp.g_varchar2_table(74) := '_ON1 to LAST_UPDATED_ON'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_TAGS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EB';
wwv_flow_imp.g_varchar2_table(75) := 'A_CA_TAGS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_CALENDARS rename column CREATED_ON1';
wwv_flow_imp.g_varchar2_table(76) := ' to CREATED_ON'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_CALENDARS rename column LAST_UPDATED_ON1 to LAST_UPDATED_ON'||wwv_flow.LF||
'/'||wwv_flow.LF||
'al';
wwv_flow_imp.g_varchar2_table(77) := 'ter table EBA_CA_EVENTS rename column EVENT_DATE_TIME1 to EVENT_DATE_TIME'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_EVENT';
wwv_flow_imp.g_varchar2_table(78) := 'S rename column CREATED_ON1 to CREATED_ON'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_EVENTS rename column LAST_UPDATED_ON1';
wwv_flow_imp.g_varchar2_table(79) := ' to LAST_UPDATED_ON'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_NOTES rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_C';
wwv_flow_imp.g_varchar2_table(80) := 'A_NOTES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_FILES rename column CREATED1 to CREAT';
wwv_flow_imp.g_varchar2_table(81) := 'ED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_FILES rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_EMAIL_GROUPS re';
wwv_flow_imp.g_varchar2_table(82) := 'name column CREATED_ON1 to CREATED_ON'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_EMAIL_GROUPS rename column LAST_UPDATED_O';
wwv_flow_imp.g_varchar2_table(83) := 'N1 to LAST_UPDATED_ON'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_EMAIL_GROUP_MBRS rename column CREATED_ON1 to CREATED_ON'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(84) := '/'||wwv_flow.LF||
'alter table EBA_CA_EMAIL_GROUP_MBRS rename column LAST_UPDATED_ON1 to LAST_UPDATED_ON'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter tabl';
wwv_flow_imp.g_varchar2_table(85) := 'e EBA_CA_TIMEFRAMES rename column CREATED_ON1 to CREATED_ON'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_TIMEFRAMES rename c';
wwv_flow_imp.g_varchar2_table(86) := 'olumn LAST_UPDATED_ON1 to LAST_UPDATED_ON'||wwv_flow.LF||
'/'||wwv_flow.LF||
'----TABLE and TRIGGER NO LONGER EXISTS AT THIS POINT.'||wwv_flow.LF||
'--';
wwv_flow_imp.g_varchar2_table(87) := 'alter table EBA_CA_ADMINS rename column CREATED_ON1 to CREATED_ON'||wwv_flow.LF||
'--/'||wwv_flow.LF||
'--alter table EBA_CA_ADMINS re';
wwv_flow_imp.g_varchar2_table(88) := 'name column LAST_UPDATED_ON1 to LAST_UPDATED_ON'||wwv_flow.LF||
'--/'||wwv_flow.LF||
'alter table EBA_CA_NOTIFICATIONS rename column D';
wwv_flow_imp.g_varchar2_table(89) := 'ISPLAY_FROM1 to DISPLAY_FROM'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_NOTIFICATIONS rename column DISPLAY_UNTIL1 to DISP';
wwv_flow_imp.g_varchar2_table(90) := 'LAY_UNTIL'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_NOTIFICATIONS rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_';
wwv_flow_imp.g_varchar2_table(91) := 'NOTIFICATIONS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_TZ_PREF rename column CREATED1 ';
wwv_flow_imp.g_varchar2_table(92) := 'to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_TZ_PREF rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_USERS';
wwv_flow_imp.g_varchar2_table(93) := ' rename column CREATED1 to CREATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_USERS rename column UPDATED1 to UPDATED'||wwv_flow.LF||
'/'||wwv_flow.LF||
'al';
wwv_flow_imp.g_varchar2_table(94) := 'ter table EBA_CA_PREFERENCES rename column CREATED_ON1 to CREATED_ON'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_CA_PREFERENCE';
wwv_flow_imp.g_varchar2_table(95) := 'S rename column UPDATED_ON1 to UPDATED_ON'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- 6 Re-create, enable Triggers and set columns with cu';
wwv_flow_imp.g_varchar2_table(96) := 'rrent_timestamp instead of localtimestamp'||wwv_flow.LF||
'create or replace TRIGGER BI_EBA_CA_ERRORS'||wwv_flow.LF||
'    before inse';
wwv_flow_imp.g_varchar2_table(97) := 'rt or update on EBA_CA_ERRORS'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        select to_n';
wwv_flow_imp.g_varchar2_table(98) := 'umber(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alt';
wwv_flow_imp.g_varchar2_table(99) := 'er trigger "BI_EBA_CA_ERRORS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER BIU_EBA_CA_COLOR_PREFS'||wwv_flow.LF||
'before ins';
wwv_flow_imp.g_varchar2_table(100) := 'ert or update on EBA_CA_COLOR_PREFS'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then';
wwv_flow_imp.g_varchar2_table(101) := ''||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'        into :new.id'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(102) := '  from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(103) := '       :new.created := current_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(104) := '  :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updati';
wwv_flow_imp.g_varchar2_table(105) := 'ng then'||wwv_flow.LF||
'        :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'        :new.updated_';
wwv_flow_imp.g_varchar2_table(106) := 'by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated    := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new';
wwv_flow_imp.g_varchar2_table(107) := '.display_sequence is null then'||wwv_flow.LF||
'       :new.display_sequence := 10;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger';
wwv_flow_imp.g_varchar2_table(108) := ' "BIU_EBA_CA_COLOR_PREFS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER EBA_CA_EVENT_TYPES_BIU'||wwv_flow.LF||
'  before inser';
wwv_flow_imp.g_varchar2_table(109) := 't or update on EBA_CA_EVENT_TYPES               '||wwv_flow.LF||
'  for each row  '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'  if inserting then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(110) := 'if :new.type_id is null '||wwv_flow.LF||
'        then :new.type_id := eba_ca_api.gen_id; '||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'     :new.cre';
wwv_flow_imp.g_varchar2_table(111) := 'ated_on := current_timestamp;'||wwv_flow.LF||
'     :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if upda';
wwv_flow_imp.g_varchar2_table(112) := 'ting then'||wwv_flow.LF||
'      :new.last_updated_on := current_timestamp;'||wwv_flow.LF||
'      :new.last_updated_by := nvl(v(''APP_';
wwv_flow_imp.g_varchar2_table(113) := 'USER''),USER);'||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'   if :new.is_active_yn is null then'||wwv_flow.LF||
'       if :new.type_name is null then';
wwv_flow_imp.g_varchar2_table(114) := ''||wwv_flow.LF||
'          :new.is_active_yn := ''N'';'||wwv_flow.LF||
'       else'||wwv_flow.LF||
'          :new.is_active_yn := ''Y'';'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(115) := '   end if;'||wwv_flow.LF||
'end; '||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger "EBA_CA_EVENT_TYPES_BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER BIU_';
wwv_flow_imp.g_varchar2_table(116) := 'EBA_CA_HISTORY '||wwv_flow.LF||
'   before insert or update on EBA_CA_HISTORY'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is ';
wwv_flow_imp.g_varchar2_table(117) := 'null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dua';
wwv_flow_imp.g_varchar2_table(118) := 'l;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.change_date := current_timestamp;'||wwv_flow.LF||
'       :new.changed';
wwv_flow_imp.g_varchar2_table(119) := '_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(120) := ' :new.row_version_number := :new.row_version_number + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger "BIU_EBA_C';
wwv_flow_imp.g_varchar2_table(121) := 'A_HISTORY" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER EBA_CA_SERIES_BIU'||wwv_flow.LF||
'  before insert or update on EBA_C';
wwv_flow_imp.g_varchar2_table(122) := 'A_SERIES               '||wwv_flow.LF||
'  for each row  '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'  if inserting then'||wwv_flow.LF||
'     if :new.series_id is null';
wwv_flow_imp.g_varchar2_table(123) := ' '||wwv_flow.LF||
'        then :new.series_id := eba_ca_api.gen_id;'||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'     :new.created_on := current_tim';
wwv_flow_imp.g_varchar2_table(124) := 'estamp;'||wwv_flow.LF||
'     :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if updating then'||wwv_flow.LF||
'      :new.l';
wwv_flow_imp.g_varchar2_table(125) := 'ast_updated_on := current_timestamp;'||wwv_flow.LF||
'      :new.last_updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end i';
wwv_flow_imp.g_varchar2_table(126) := 'f; '||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger "EBA_CA_SERIES_BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER BIU_EBA_CA_TAGS'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(127) := '  before insert or update on EBA_CA_TAGS'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         i';
wwv_flow_imp.g_varchar2_table(128) := 'f :new.id is null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(129) := '         into :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :new.created := current_timest';
wwv_flow_imp.g_varchar2_table(130) := 'amp;'||wwv_flow.LF||
'         :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(131) := '    :new.updated := current_timestamp;'||wwv_flow.LF||
'         :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'      en';
wwv_flow_imp.g_varchar2_table(132) := 'd if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger "BIU_EBA_CA_TAGS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER EBA_CA_CALENDARS_';
wwv_flow_imp.g_varchar2_table(133) := 'BIU'||wwv_flow.LF||
'  before insert or update on EBA_CA_CALENDARS               '||wwv_flow.LF||
'  for each row  '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'  if inse';
wwv_flow_imp.g_varchar2_table(134) := 'rting then'||wwv_flow.LF||
'     if :new.calendar_id is null '||wwv_flow.LF||
'        then :new.calendar_id := eba_ca_api.gen_id; '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(135) := '   end if;'||wwv_flow.LF||
'     :new.created_on := current_timestamp;'||wwv_flow.LF||
'     :new.created_by := nvl(v(''APP_USER''),USER';
wwv_flow_imp.g_varchar2_table(136) := ');'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if updating then'||wwv_flow.LF||
'      :new.last_updated_on := current_timestamp;'||wwv_flow.LF||
'      :new.last_u';
wwv_flow_imp.g_varchar2_table(137) := 'pdated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'end; '||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger "EBA_CA_CALENDARS_BIU" ENAB';
wwv_flow_imp.g_varchar2_table(138) := 'LE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER AD_EBA_CA_EVENTS'||wwv_flow.LF||
'   after delete on EBA_CA_EVENTS'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'b';
wwv_flow_imp.g_varchar2_table(139) := 'egin'||wwv_flow.LF||
'   insert into eba_ca_history ('||wwv_flow.LF||
'       table_name, component_rowkey, COMPONENT_ID, column_name,';
wwv_flow_imp.g_varchar2_table(140) := ' old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :old.row_key, :old.event_id, ''DELETE'',null,''Removed ';
wwv_flow_imp.g_varchar2_table(141) := 'event ''||:old.EVENT_NAME);'||wwv_flow.LF||
'end AD_EBA_CA_EVENTS;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger "AD_EBA_CA_EVENTS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'crea';
wwv_flow_imp.g_varchar2_table(142) := 'te or replace TRIGGER EBA_CA_EVENTS_BIU'||wwv_flow.LF||
'  before insert or update on EBA_CA_EVENTS               '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(143) := 'for each row  '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'  if inserting then'||wwv_flow.LF||
'     if :NEW.event_id is null '||wwv_flow.LF||
'        then :NEW.event_i';
wwv_flow_imp.g_varchar2_table(144) := 'd := EBA_ca_api.gen_id;'||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'     :NEW.CREATED_ON := current_timestamp;'||wwv_flow.LF||
'     :NEW.CREATED_BY';
wwv_flow_imp.g_varchar2_table(145) := ' := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'     :new.row_version_number := 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if updating then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(146) := ' :NEW.LAST_UPDATED_ON := current_timestamp;'||wwv_flow.LF||
'      :NEW.LAST_UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(147) := '     :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'   if :new.row_key i';
wwv_flow_imp.g_varchar2_table(148) := 's null then'||wwv_flow.LF||
'       select eba_ca_fw.compress_int(eba_ca_seq.nextval) into :new.row_key from dual;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(149) := ' end if;'||wwv_flow.LF||
'   eba_ca_fw.tag_sync('||wwv_flow.LF||
'         p_new_tags      => :new.tags,'||wwv_flow.LF||
'         p_old_tags      => :';
wwv_flow_imp.g_varchar2_table(150) := 'old.tags,'||wwv_flow.LF||
'         p_content_type  => ''EVENT'','||wwv_flow.LF||
'         p_content_id    => :new.event_id );'||wwv_flow.LF||
'end; '||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(151) := ''||wwv_flow.LF||
'alter trigger "EBA_CA_EVENTS_BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER BD_EBA_CA_EVENTS'||wwv_flow.LF||
'    before ';
wwv_flow_imp.g_varchar2_table(152) := 'delete on EBA_CA_EVENTS'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba_ca_fw.tag_sync('||wwv_flow.LF||
'        p_new_tags      => nu';
wwv_flow_imp.g_varchar2_table(153) := 'll,'||wwv_flow.LF||
'        p_old_tags      => :old.tags,'||wwv_flow.LF||
'        p_content_type  => ''EVENT'','||wwv_flow.LF||
'        p_content_id  ';
wwv_flow_imp.g_varchar2_table(154) := '  => :old.event_id );'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger "BD_EBA_CA_EVENTS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER ';
wwv_flow_imp.g_varchar2_table(155) := 'AU_EBA_CA_EVENTS'||wwv_flow.LF||
'   after update on EBA_CA_EVENTS'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'   ov varchar2(4000) := nu';
wwv_flow_imp.g_varchar2_table(156) := 'll;'||wwv_flow.LF||
'   nv varchar2(4000) := null;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   -- FK'||wwv_flow.LF||
'   if updating and :old.TYPE_ID != :new.TYPE_ID the';
wwv_flow_imp.g_varchar2_table(157) := 'n'||wwv_flow.LF||
'      ov := null; nv := null;'||wwv_flow.LF||
'      for c1 in (select type_name from eba_ca_event_types t where t.';
wwv_flow_imp.g_varchar2_table(158) := 'type_id = :old.TYPE_ID) loop'||wwv_flow.LF||
'          ov := c1.type_name;'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'      for c1 in (select t';
wwv_flow_imp.g_varchar2_table(159) := 'ype_name from eba_ca_event_types t where t.type_id = :new.TYPE_ID) loop'||wwv_flow.LF||
'          nv := c1.type_name';
wwv_flow_imp.g_varchar2_table(160) := ';'||wwv_flow.LF||
'      end loop;   '||wwv_flow.LF||
'      insert into eba_ca_history (table_name, component_rowkey, component_id, c';
wwv_flow_imp.g_varchar2_table(161) := 'olumn_name, old_value, new_value) values'||wwv_flow.LF||
'          (''EVENTS'',:new.row_key, :new.event_id, ''TYPE_ID'',';
wwv_flow_imp.g_varchar2_table(162) := 'ov,nv);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   if nvl(:old.SERIES_ID,''0'') != nvl(:new.SERIES_ID,''0'') then'||wwv_flow.LF||
'       insert';
wwv_flow_imp.g_varchar2_table(163) := ' into eba_ca_history (table_name, component_rowkey, COMPONENT_ID, column_name, old_value, new_value)';
wwv_flow_imp.g_varchar2_table(164) := ' values'||wwv_flow.LF||
'       (''EVENTS'',:new.row_key, :new.event_id, ''SERIES_ID'',:old.SERIES_ID,:new.SERIES_ID);'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(165) := ' end if;'||wwv_flow.LF||
'   if nvl(:old.EVENT_NAME,''0'') != nvl(:new.EVENT_NAME,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_h';
wwv_flow_imp.g_varchar2_table(166) := 'istory (table_name, component_rowkey, COMPONENT_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(167) := ' (''EVENTS'',:new.row_key, :new.event_id, ''EVENT_NAME'',:old.EVENT_NAME,:new.EVENT_NAME);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(168) := ' if nvl(:old.DURATION,''0'') != nvl(:new.DURATION,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_history (table_n';
wwv_flow_imp.g_varchar2_table(169) := 'ame, component_rowkey, COMPONENT_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :ne';
wwv_flow_imp.g_varchar2_table(170) := 'w.row_key, :new.event_id, ''DURATION'',:old.DURATION,:new.DURATION);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.EVENT_D';
wwv_flow_imp.g_varchar2_table(171) := 'ESC,''0'') != nvl(:new.EVENT_DESC,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_history (table_name, component_r';
wwv_flow_imp.g_varchar2_table(172) := 'owkey, COMPONENT_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :new.row_key, :new.';
wwv_flow_imp.g_varchar2_table(173) := 'event_id, ''EVENT_DESC'',:old.EVENT_DESC,:new.EVENT_DESC);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.CONTACT_PERSON,''0';
wwv_flow_imp.g_varchar2_table(174) := ''') != nvl(:new.CONTACT_PERSON,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_history (table_name, component_row';
wwv_flow_imp.g_varchar2_table(175) := 'key, COMPONENT_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :new.row_key, :new.ev';
wwv_flow_imp.g_varchar2_table(176) := 'ent_id, ''CONTACT_PERSON'',:old.CONTACT_PERSON,:new.CONTACT_PERSON);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.CONTACT';
wwv_flow_imp.g_varchar2_table(177) := '_EMAIL,''0'') != nvl(:new.CONTACT_EMAIL,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_history (table_name, compo';
wwv_flow_imp.g_varchar2_table(178) := 'nent_rowkey, COMPONENT_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :new.row_key,';
wwv_flow_imp.g_varchar2_table(179) := ' :new.event_id, ''CONTACT_EMAIL'',:old.CONTACT_EMAIL,:new.CONTACT_EMAIL);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.DI';
wwv_flow_imp.g_varchar2_table(180) := 'SPLAY_TIME,''0'') != nvl(:new.DISPLAY_TIME,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_history (table_name, co';
wwv_flow_imp.g_varchar2_table(181) := 'mponent_rowkey, COMPONENT_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :new.row_k';
wwv_flow_imp.g_varchar2_table(182) := 'ey, :new.event_id, ''DISPLAY_TIME'',:old.DISPLAY_TIME,:new.DISPLAY_TIME);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.LO';
wwv_flow_imp.g_varchar2_table(183) := 'CATION,''0'') != nvl(:new.LOCATION,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_history (table_name, component_';
wwv_flow_imp.g_varchar2_table(184) := 'rowkey, COMPONENT_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :new.row_key, :new';
wwv_flow_imp.g_varchar2_table(185) := '.event_id, ''LOCATION'',:old.LOCATION,:new.LOCATION);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.LINK_NAME_1,''0'') != nv';
wwv_flow_imp.g_varchar2_table(186) := 'l(:new.LINK_NAME_1,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_history (table_name, component_rowkey, COMPON';
wwv_flow_imp.g_varchar2_table(187) := 'ENT_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :new.row_key, :new.event_id, ''LI';
wwv_flow_imp.g_varchar2_table(188) := 'NK_NAME_1'',:old.LINK_NAME_1,:new.LINK_NAME_1);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.LINK_URL_1,''0'') != nvl(:new';
wwv_flow_imp.g_varchar2_table(189) := '.LINK_URL_1,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_history (table_name, component_rowkey, COMPONENT_ID,';
wwv_flow_imp.g_varchar2_table(190) := ' column_name, old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :new.row_key, :new.event_id, ''LINK_URL_';
wwv_flow_imp.g_varchar2_table(191) := '1'',:old.LINK_URL_1,:new.LINK_URL_1);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.LINK_NAME_2,''0'') != nvl(:new.LINK_NAM';
wwv_flow_imp.g_varchar2_table(192) := 'E_2,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_history (table_name, component_rowkey, COMPONENT_ID, column_';
wwv_flow_imp.g_varchar2_table(193) := 'name, old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :new.row_key, :new.event_id, ''LINK_NAME_2'',:old';
wwv_flow_imp.g_varchar2_table(194) := '.LINK_NAME_2,:new.LINK_NAME_2);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.LINK_URL_2,''0'') != nvl(:new.LINK_URL_2,''0''';
wwv_flow_imp.g_varchar2_table(195) := ') then'||wwv_flow.LF||
'       insert into eba_ca_history (table_name, component_rowkey, COMPONENT_ID, column_name, o';
wwv_flow_imp.g_varchar2_table(196) := 'ld_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :new.row_key, :new.event_id, ''LINK_URL_2'',:old.LINK_UR';
wwv_flow_imp.g_varchar2_table(197) := 'L_2,:new.LINK_URL_2);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.LINK_NAME_3,''0'') != nvl(:new.LINK_NAME_3,''0'') then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(198) := '      insert into eba_ca_history (table_name, component_rowkey, COMPONENT_ID, column_name, old_value';
wwv_flow_imp.g_varchar2_table(199) := ', new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :new.row_key, :new.event_id, ''LINK_NAME_3'',:old.LINK_NAME_3,:n';
wwv_flow_imp.g_varchar2_table(200) := 'ew.LINK_NAME_3);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.LINK_URL_3,''0'') != nvl(:new.LINK_URL_3,''0'') then'||wwv_flow.LF||
'       i';
wwv_flow_imp.g_varchar2_table(201) := 'nsert into eba_ca_history (table_name, component_rowkey, COMPONENT_ID, column_name, old_value, new_v';
wwv_flow_imp.g_varchar2_table(202) := 'alue) values'||wwv_flow.LF||
'       (''EVENTS'', :new.row_key, :new.event_id, ''LINK_URL_3'',:old.LINK_URL_3,:new.LINK_U';
wwv_flow_imp.g_varchar2_table(203) := 'RL_3);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.LINK_NAME_4,''0'') != nvl(:new.LINK_NAME_4,''0'') then'||wwv_flow.LF||
'       insert in';
wwv_flow_imp.g_varchar2_table(204) := 'to eba_ca_history (table_name, component_rowkey, COMPONENT_ID, column_name, old_value, new_value) va';
wwv_flow_imp.g_varchar2_table(205) := 'lues'||wwv_flow.LF||
'       (''EVENTS'', :new.row_key, :new.event_id, ''LINK_NAME_4'',:old.LINK_NAME_4,:new.LINK_NAME_4)';
wwv_flow_imp.g_varchar2_table(206) := ';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if nvl(:old.LINK_URL_4,''0'') != nvl(:new.LINK_URL_4,''0'') then'||wwv_flow.LF||
'       insert into eba_';
wwv_flow_imp.g_varchar2_table(207) := 'ca_history (table_name, component_rowkey, COMPONENT_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(208) := '     (''EVENTS'', :new.row_key, :new.event_id, ''LINK_URL_4'',:old.LINK_URL_4,:new.LINK_URL_4);'||wwv_flow.LF||
'   end i';
wwv_flow_imp.g_varchar2_table(209) := 'f;'||wwv_flow.LF||
'   if nvl(:old.TAGS,''0'') != nvl(:new.TAGS,''0'') then'||wwv_flow.LF||
'       insert into eba_ca_history (table_name';
wwv_flow_imp.g_varchar2_table(210) := ', component_rowkey, COMPONENT_ID, column_name, old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'', :new.r';
wwv_flow_imp.g_varchar2_table(211) := 'ow_key, :new.event_id, ''TAGS'',:old.TAGS,:new.TAGS);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   -- timestamp columns'||wwv_flow.LF||
'   if (:old.E';
wwv_flow_imp.g_varchar2_table(212) := 'VENT_DATE_TIME is null and :new.EVENT_DATE_TIME is not null) or '||wwv_flow.LF||
'      (:old.EVENT_DATE_TIME is not ';
wwv_flow_imp.g_varchar2_table(213) := 'null and :new.EVENT_DATE_TIME is null) or '||wwv_flow.LF||
'      (:old.EVENT_DATE_TIME != :new.EVENT_DATE_TIME) then';
wwv_flow_imp.g_varchar2_table(214) := ''||wwv_flow.LF||
'       insert into eba_ca_history (table_name, component_rowkey, COMPONENT_ID, column_name, old_val';
wwv_flow_imp.g_varchar2_table(215) := 'ue, new_value) values'||wwv_flow.LF||
'          (''EVENTS'', :new.row_key, :new.event_id, ''EVENT_DATE_TIME'',:old.EVENT';
wwv_flow_imp.g_varchar2_table(216) := '_DATE_TIME,:new.EVENT_DATE_TIME);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end AU_EBA_CA_EVENTS;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger "AU_EBA_CA_EVENT';
wwv_flow_imp.g_varchar2_table(217) := 'S" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER AI_EBA_CA_EVENTS'||wwv_flow.LF||
'   after insert on EBA_CA_EVENTS'||wwv_flow.LF||
'   for eac';
wwv_flow_imp.g_varchar2_table(218) := 'h row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   insert into eba_ca_history ('||wwv_flow.LF||
'       table_name, component_rowkey, component_id, colum';
wwv_flow_imp.g_varchar2_table(219) := 'n_name, old_value, new_value) values'||wwv_flow.LF||
'       (''EVENTS'',:new.row_key, :new.event_id, ''Event Name '',nul';
wwv_flow_imp.g_varchar2_table(220) := 'l,:new.EVENT_NAME);'||wwv_flow.LF||
'end AI_EBA_CA_EVENTS;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger "AI_EBA_CA_EVENTS" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or r';
wwv_flow_imp.g_varchar2_table(221) := 'eplace TRIGGER BIU_EBA_CA_NOTES '||wwv_flow.LF||
'   before insert or update on EBA_CA_NOTES'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(222) := ' if :new.ID is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :';
wwv_flow_imp.g_varchar2_table(223) := 'new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'       :';
wwv_flow_imp.g_varchar2_table(224) := 'new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.u';
wwv_flow_imp.g_varchar2_table(225) := 'pdated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(226) := '       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or ';
wwv_flow_imp.g_varchar2_table(227) := 'updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_use';
wwv_flow_imp.g_varchar2_table(228) := 'r,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger "BIU_EBA_CA_NOTES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER BI';
wwv_flow_imp.g_varchar2_table(229) := 'U_EBA_CA_FILES '||wwv_flow.LF||
'   before insert or update on EBA_CA_FILES'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  if :new.ID is nul';
wwv_flow_imp.g_varchar2_table(230) := 'l then'||wwv_flow.LF||
'    select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(231) := ' end if;'||wwv_flow.LF||
'  if inserting then'||wwv_flow.LF||
'    :new.created := current_timestamp;'||wwv_flow.LF||
'    :new.created_by := nvl(wwv_f';
wwv_flow_imp.g_varchar2_table(232) := 'low.g_user,user);'||wwv_flow.LF||
'    :new.updated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(wwv_flow.g_user,';
wwv_flow_imp.g_varchar2_table(233) := 'user);'||wwv_flow.LF||
'    :new.row_version_number := 1;'||wwv_flow.LF||
'  elsif updating then'||wwv_flow.LF||
'    :new.row_version_number := nvl(:o';
wwv_flow_imp.g_varchar2_table(234) := 'ld.row_version_number,1) + 1;'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
'  if (inserting or updating) and nvl(dbms_lob.getlength(:new';
wwv_flow_imp.g_varchar2_table(235) := '.file_blob),0) > 15728640 then'||wwv_flow.LF||
'    raise_application_error(-20000, ''The size of the uploaded file wa';
wwv_flow_imp.g_varchar2_table(236) := 's over 15MB. Please upload a smaller file.'');'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
'  if inserting or updating then'||wwv_flow.LF||
'    :new.upd';
wwv_flow_imp.g_varchar2_table(237) := 'ated := current_timestamp;'||wwv_flow.LF||
'    :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'  end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter';
wwv_flow_imp.g_varchar2_table(238) := ' trigger "BIU_EBA_CA_FILES" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER EBA_CA_EMAIL_GROUPS_BIU'||wwv_flow.LF||
'  before in';
wwv_flow_imp.g_varchar2_table(239) := 'sert or update on EBA_CA_EMAIL_GROUPS               '||wwv_flow.LF||
'  for each row  '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'  if inserting then'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(240) := '    if :NEW.group_id is null '||wwv_flow.LF||
'        then :NEW.group_id := EBA_ca_api.gen_id; '||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'     :N';
wwv_flow_imp.g_varchar2_table(241) := 'EW.CREATED_ON := current_timestamp;'||wwv_flow.LF||
'     :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   i';
wwv_flow_imp.g_varchar2_table(242) := 'f updating then'||wwv_flow.LF||
'      :NEW.LAST_UPDATED_ON := current_timestamp;'||wwv_flow.LF||
'      :NEW.LAST_UPDATED_BY := nvl(v';
wwv_flow_imp.g_varchar2_table(243) := '(''APP_USER''),USER);'||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'end; '||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger "EBA_CA_EMAIL_GROUPS_BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create o';
wwv_flow_imp.g_varchar2_table(244) := 'r replace TRIGGER EBA_CA_EMAIL_GROUP_MBRS_BIU'||wwv_flow.LF||
'  before insert or update on EBA_CA_EMAIL_GROUP_MBRS  ';
wwv_flow_imp.g_varchar2_table(245) := '            '||wwv_flow.LF||
'  for each row  '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'  if inserting then'||wwv_flow.LF||
'     if :NEW.mbr_id is null '||wwv_flow.LF||
'        then';
wwv_flow_imp.g_varchar2_table(246) := ' :NEW.mbr_id := EBA_ca_api.gen_id; '||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'     :NEW.CREATED_ON := current_timestamp;'||wwv_flow.LF||
'     :NE';
wwv_flow_imp.g_varchar2_table(247) := 'W.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if updating then'||wwv_flow.LF||
'      :NEW.LAST_UPDATED_ON :';
wwv_flow_imp.g_varchar2_table(248) := '= current_timestamp;'||wwv_flow.LF||
'      :NEW.LAST_UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'end; '||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alt';
wwv_flow_imp.g_varchar2_table(249) := 'er trigger "EBA_CA_EMAIL_GROUP_MBRS_BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER EBA_CA_TIMEFRAMES_BIU'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(250) := '  before insert or update on EBA_CA_TIMEFRAMES               '||wwv_flow.LF||
'  for each row  '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'  if inserti';
wwv_flow_imp.g_varchar2_table(251) := 'ng then'||wwv_flow.LF||
'     if :NEW.tf_id is null '||wwv_flow.LF||
'        then :NEW.tf_id := EBA_ca_api.gen_id; '||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(252) := ' :NEW.CREATED_ON := current_timestamp;'||wwv_flow.LF||
'     :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(253) := '  if updating then'||wwv_flow.LF||
'      :NEW.LAST_UPDATED_ON := current_timestamp;'||wwv_flow.LF||
'      :NEW.LAST_UPDATED_BY := nv';
wwv_flow_imp.g_varchar2_table(254) := 'l(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'end; '||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger "EBA_CA_TIMEFRAMES_BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'--TABLE';
wwv_flow_imp.g_varchar2_table(255) := ' and TRIGGER NO LONGER EXISTS AT THIS POINT.'||wwv_flow.LF||
'--create or replace TRIGGER EBA_CA_ADMINS_BIU'||wwv_flow.LF||
'--  befor';
wwv_flow_imp.g_varchar2_table(256) := 'e insert or update on EBA_CA_ADMINS               '||wwv_flow.LF||
'--  for each row  '||wwv_flow.LF||
'--begin   '||wwv_flow.LF||
'--  if inserting th';
wwv_flow_imp.g_varchar2_table(257) := 'en'||wwv_flow.LF||
'--     if :NEW.admin_id is null '||wwv_flow.LF||
'--        then :NEW.admin_id := EBA_ca_api.gen_id; '||wwv_flow.LF||
'--     end i';
wwv_flow_imp.g_varchar2_table(258) := 'f;'||wwv_flow.LF||
'--     :NEW.CREATED_ON := current_timestamp;'||wwv_flow.LF||
'--     :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'-';
wwv_flow_imp.g_varchar2_table(259) := '-   end if;'||wwv_flow.LF||
'--   if updating then'||wwv_flow.LF||
'--      :NEW.LAST_UPDATED_ON := current_timestamp;'||wwv_flow.LF||
'--      :NEW.LA';
wwv_flow_imp.g_varchar2_table(260) := 'ST_UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'--   end if; '||wwv_flow.LF||
'--end;'||wwv_flow.LF||
'--/'||wwv_flow.LF||
''||wwv_flow.LF||
'--alter trigger "EBA_CA_ADMINS_B';
wwv_flow_imp.g_varchar2_table(261) := 'IU" ENABLE;'||wwv_flow.LF||
'--/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER EBA_CA_NOTE_BIU'||wwv_flow.LF||
'before insert or update on EBA_CA_NOTIFIC';
wwv_flow_imp.g_varchar2_table(262) := 'ATIONS'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        select to_number(sys';
wwv_flow_imp.g_varchar2_table(263) := '_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'        into :new.id'||wwv_flow.LF||
'        from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(264) := 'if inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created := curren';
wwv_flow_imp.g_varchar2_table(265) := 't_timestamp;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_tim';
wwv_flow_imp.g_varchar2_table(266) := 'estamp;'||wwv_flow.LF||
'        :new.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.row_vers';
wwv_flow_imp.g_varchar2_table(267) := 'ion_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER)';
wwv_flow_imp.g_varchar2_table(268) := ';'||wwv_flow.LF||
'        :new.updated    := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.notification_type is null th';
wwv_flow_imp.g_varchar2_table(269) := 'en'||wwv_flow.LF||
'       :new.notification_type := ''MANUAL'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.display_sequence is null then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(270) := '       :new.display_sequence := 10;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger "EBA_CA_NOTE_BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'c';
wwv_flow_imp.g_varchar2_table(271) := 'reate or replace TRIGGER BIU_EBA_CA_TZ_PREF'||wwv_flow.LF||
'   before insert or update on EBA_CA_TZ_PREF'||wwv_flow.LF||
'   for each';
wwv_flow_imp.g_varchar2_table(272) := ' row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(273) := 'XXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_timest';
wwv_flow_imp.g_varchar2_table(274) := 'amp;'||wwv_flow.LF||
'       :new.created_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(275) := '       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif u';
wwv_flow_imp.g_varchar2_table(276) := 'pdating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if ';
wwv_flow_imp.g_varchar2_table(277) := 'inserting or updating then'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(w';
wwv_flow_imp.g_varchar2_table(278) := 'wv_flow.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if :new.TIMEZONE_PREFERENCE is null then'||wwv_flow.LF||
'       :new.timezone_pr';
wwv_flow_imp.g_varchar2_table(279) := 'eference := ''UTC'';'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger "BIU_EBA_CA_TZ_PREF" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replac';
wwv_flow_imp.g_varchar2_table(280) := 'e TRIGGER EBA_CA_USERS_BD'||wwv_flow.LF||
'    before delete on EBA_CA_USERS'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    pragma auto';
wwv_flow_imp.g_varchar2_table(281) := 'nomous_transaction;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    -- Disallow deletes to a user''s own record unless last one.'||wwv_flow.LF||
'    if v(''';
wwv_flow_imp.g_varchar2_table(282) := 'APP_USER'') = upper(:old.username) then'||wwv_flow.LF||
'       for c1 in ('||wwv_flow.LF||
'          select count(*) cnt'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(283) := 'from eba_ca_users'||wwv_flow.LF||
'           where id != :old.id )'||wwv_flow.LF||
'       loop'||wwv_flow.LF||
'          if c1.cnt > 0 then'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(284) := '     raise_application_error(-20002, ''Delete disallowed, you cannot delete your own access control d';
wwv_flow_imp.g_varchar2_table(285) := 'etails.'');'||wwv_flow.LF||
'          end if;'||wwv_flow.LF||
'       end loop;'||wwv_flow.LF||
'    end if;    '||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger "EBA_CA_USERS_BD';
wwv_flow_imp.g_varchar2_table(286) := '" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace TRIGGER EBA_CA_USERS_BIU'||wwv_flow.LF||
'    before insert or update on EBA_CA_USERS'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(287) := '    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            :new.id := ';
wwv_flow_imp.g_varchar2_table(288) := 'eba_ca.gen_id();'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        :new.created_by         := nvl(v(''APP_USER''), USER);'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(289) := '  :new.created            := current_timestamp;'||wwv_flow.LF||
'        :new.row_version        := 1;'||wwv_flow.LF||
'        if :ne';
wwv_flow_imp.g_varchar2_table(290) := 'w.account_locked is null then'||wwv_flow.LF||
'            :new.account_locked := ''N'';    '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if';
wwv_flow_imp.g_varchar2_table(291) := ';'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'            :new.updated_by         := nvl(v(''APP_USER''), USER);'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(292) := ':new.updated            := current_timestamp;'||wwv_flow.LF||
'            :new.row_version        := nvl(:old.row_ve';
wwv_flow_imp.g_varchar2_table(293) := 'rsion,1) + 1;                                '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- Always store username as upper case';
wwv_flow_imp.g_varchar2_table(294) := ''||wwv_flow.LF||
'    :new.username := upper(:new.username);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger "EBA_CA_USERS_BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'crea';
wwv_flow_imp.g_varchar2_table(295) := 'te or replace TRIGGER EBA_CA_PREFERENCES_BIU'||wwv_flow.LF||
'before insert or update on EBA_CA_PREFERENCES'||wwv_flow.LF||
'    for e';
wwv_flow_imp.g_varchar2_table(296) := 'ach row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        :new.id := eba_ca.gen_id();'||wwv_flow.LF||
'    end ';
wwv_flow_imp.g_varchar2_table(297) := 'if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created_o';
wwv_flow_imp.g_varchar2_table(298) := 'n := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''';
wwv_flow_imp.g_varchar2_table(299) := '),USER);'||wwv_flow.LF||
'        :new.updated_on := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.preference_name := upper';
wwv_flow_imp.g_varchar2_table(300) := '(:new.preference_name);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger "EBA_CA_PREFERENCES_BIU" ENABLE;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(409358566007575955)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'TIMESTAMP Fix (BUGID: 31352674)'
,p_sequence=>120
,p_script_type=>'UPGRADE'
,p_condition_type=>'EXISTS'
,p_condition=>'select null from all_tab_cols where table_name like ''EBA_CA_%'' and data_type = ''TIMESTAMP(6) WITH LOCAL TIME ZONE'''
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
