prompt --application/deployment/install/install_events_triggers
begin
--   Manifest
--     INSTALL: INSTALL-events triggers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace trigger EBA_ca_events_biu'||wwv_flow.LF||
'  before insert or update on EBA_ca_events              ';
wwv_flow_imp.g_varchar2_table(2) := ' '||wwv_flow.LF||
'  for each row  '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'  if inserting then'||wwv_flow.LF||
'     if :NEW.event_id is null '||wwv_flow.LF||
'        then :NEW.eve';
wwv_flow_imp.g_varchar2_table(3) := 'nt_id := EBA_ca_api.gen_id;'||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'     :NEW.CREATED_ON := CURRENT_TIMESTAMP;'||wwv_flow.LF||
'     :NEW.CREATE';
wwv_flow_imp.g_varchar2_table(4) := 'D_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'     :new.row_version_number := 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'   if updating then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(5) := '      :NEW.LAST_UPDATED_ON := CURRENT_TIMESTAMP;'||wwv_flow.LF||
'      :NEW.LAST_UPDATED_BY := nvl(v(''APP_USER''),USE';
wwv_flow_imp.g_varchar2_table(6) := 'R);'||wwv_flow.LF||
'      :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
''||wwv_flow.LF||
'   if :new.row';
wwv_flow_imp.g_varchar2_table(7) := '_key is null then'||wwv_flow.LF||
'       select eba_ca_fw.compress_int(eba_ca_seq.nextval) into :new.row_key from du';
wwv_flow_imp.g_varchar2_table(8) := 'al;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'   eba_ca_fw.tag_sync('||wwv_flow.LF||
'         p_new_tags      => :new.tags,'||wwv_flow.LF||
'         p_old_tags   ';
wwv_flow_imp.g_varchar2_table(9) := '   => :old.tags,'||wwv_flow.LF||
'         p_content_type  => ''EVENT'','||wwv_flow.LF||
'         p_content_id    => :new.event_id );'||wwv_flow.LF||
'e';
wwv_flow_imp.g_varchar2_table(10) := 'nd; '||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors    '||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger EBA_ca_events_biu enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    '||wwv_flow.LF||
'create or replace trigger';
wwv_flow_imp.g_varchar2_table(11) := ' BD_EBA_ca_events'||wwv_flow.LF||
'    before delete on EBA_ca_events'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba_ca_fw.tag_sync('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(12) := '        p_new_tags      => null,'||wwv_flow.LF||
'        p_old_tags      => :old.tags,'||wwv_flow.LF||
'        p_content_type  => ''E';
wwv_flow_imp.g_varchar2_table(13) := 'VENT'','||wwv_flow.LF||
'        p_content_id    => :old.event_id );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
'    '||wwv_flow.LF||
'alter trigger BD_EBA_ca_';
wwv_flow_imp.g_varchar2_table(14) := 'events enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3256461178157079401)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'events triggers'
,p_sequence=>400
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
