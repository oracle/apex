prompt --application/deployment/install/install_events
begin
--   Manifest
--     INSTALL: INSTALL-events
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_ca_events ('||wwv_flow.LF||
'   event_id            number         not null,'||wwv_flow.LF||
'   row_version_number  ';
wwv_flow_imp.g_varchar2_table(2) := 'integer,'||wwv_flow.LF||
'   row_key             varchar2(30),'||wwv_flow.LF||
'   event_name          varchar2(255)  not null,'||wwv_flow.LF||
'   typ';
wwv_flow_imp.g_varchar2_table(3) := 'e_id             number,'||wwv_flow.LF||
'   calendar_id         number,'||wwv_flow.LF||
'   event_date_time     timestamp with time z';
wwv_flow_imp.g_varchar2_table(4) := 'one  not null,'||wwv_flow.LF||
'   duration            number         not null,'||wwv_flow.LF||
'   event_desc          varchar2(4000)';
wwv_flow_imp.g_varchar2_table(5) := ','||wwv_flow.LF||
'   contact_person      varchar2(255),'||wwv_flow.LF||
'   contact_email       varchar2(255),'||wwv_flow.LF||
'   display_time       ';
wwv_flow_imp.g_varchar2_table(6) := ' varchar2(1)    not null,'||wwv_flow.LF||
'   location            varchar2(255),'||wwv_flow.LF||
'   link_name_1         varchar2(255)';
wwv_flow_imp.g_varchar2_table(7) := ','||wwv_flow.LF||
'   link_url_1          varchar2(4000),'||wwv_flow.LF||
'   link_name_2         varchar2(255),'||wwv_flow.LF||
'   link_url_2        ';
wwv_flow_imp.g_varchar2_table(8) := '  varchar2(4000),'||wwv_flow.LF||
'   link_name_3         varchar2(255),'||wwv_flow.LF||
'   link_url_3          varchar2(4000),'||wwv_flow.LF||
'   li';
wwv_flow_imp.g_varchar2_table(9) := 'nk_name_4         varchar2(255),'||wwv_flow.LF||
'   link_url_4          varchar2(4000),'||wwv_flow.LF||
'   tags                varch';
wwv_flow_imp.g_varchar2_table(10) := 'ar2(4000),'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   series_id        number,'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   created_on       timestamp with time zone  not';
wwv_flow_imp.g_varchar2_table(11) := ' null,'||wwv_flow.LF||
'   created_by       varchar2(255)  not null,'||wwv_flow.LF||
'   last_updated_on  timestamp with time zone,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(12) := ' last_updated_by  varchar2(255) )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_ca_events '||wwv_flow.LF||
'   add constraint eba_ca_events_pk pr';
wwv_flow_imp.g_varchar2_table(13) := 'imary key (event_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_ca_events '||wwv_flow.LF||
'   add constraint eba_ca_event_fk1 '||wwv_flow.LF||
'   foreign key';
wwv_flow_imp.g_varchar2_table(14) := ' (type_id)'||wwv_flow.LF||
'   references eba_ca_event_types (type_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create index eba_ca_events_i1 '||wwv_flow.LF||
'   on eba_ca_';
wwv_flow_imp.g_varchar2_table(15) := 'events (type_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_ca_events '||wwv_flow.LF||
'   add constraint eba_ca_event_fk2 '||wwv_flow.LF||
'   foreign key (se';
wwv_flow_imp.g_varchar2_table(16) := 'ries_id)'||wwv_flow.LF||
'   references eba_ca_series (series_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create index eba_ca_events_i2'||wwv_flow.LF||
'   on eba_ca_events';
wwv_flow_imp.g_varchar2_table(17) := ' (series_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_ca_events '||wwv_flow.LF||
'   add constraint eba_ca_event_fk3 '||wwv_flow.LF||
'   foreign key (calend';
wwv_flow_imp.g_varchar2_table(18) := 'ar_id)'||wwv_flow.LF||
'   references eba_ca_calendars (calendar_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create index eba_ca_events_i3'||wwv_flow.LF||
'   on eba_ca_eve';
wwv_flow_imp.g_varchar2_table(19) := 'nts (calendar_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_ca_events '||wwv_flow.LF||
'   add constraint eba_ca_event_cc1 '||wwv_flow.LF||
'   check ( displa';
wwv_flow_imp.g_varchar2_table(20) := 'y_time in (''Y'',''N'') )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3254470457362753502)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'events'
,p_sequence=>210
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
