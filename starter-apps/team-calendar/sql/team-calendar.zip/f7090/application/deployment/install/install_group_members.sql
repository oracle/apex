prompt --application/deployment/install/install_group_members
begin
--   Manifest
--     INSTALL: INSTALL-group members
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table EBA_ca_email_group_mbrs ('||wwv_flow.LF||
'   mbr_id         number         not null,'||wwv_flow.LF||
'   group_id       ';
wwv_flow_imp.g_varchar2_table(2) := 'number         not null,'||wwv_flow.LF||
'   email_address  varchar2(255)  not null,'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   created_on       timest';
wwv_flow_imp.g_varchar2_table(3) := 'amp with time zone  not null,'||wwv_flow.LF||
'   created_by       varchar2(255)  not null,'||wwv_flow.LF||
'   last_updated_on  times';
wwv_flow_imp.g_varchar2_table(4) := 'tamp with time zone,'||wwv_flow.LF||
'   last_updated_by  varchar2(255) )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_ca_email_group_mbrs'||wwv_flow.LF||
'   ad';
wwv_flow_imp.g_varchar2_table(5) := 'd constraint EBA_ca_email_group_mbrs_pk primary key (mbr_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_ca_email_group_mbrs'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(6) := '  add constraint EBA_ca_email_group_mbrs_uk unique (group_id, email_address)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_ca_em';
wwv_flow_imp.g_varchar2_table(7) := 'ail_group_mbrs '||wwv_flow.LF||
'   add constraint EBA_ca_email_group_mbrs_fk1 '||wwv_flow.LF||
'   foreign key (group_id)'||wwv_flow.LF||
'   referenc';
wwv_flow_imp.g_varchar2_table(8) := 'es EBA_ca_email_groups (group_id)'||wwv_flow.LF||
'   on delete cascade'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create index EBA_ca_email_group_mbrs_i1'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(9) := 'on EBA_ca_email_group_mbrs (group_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger EBA_ca_email_group_mbrs_biu'||wwv_flow.LF||
'  befo';
wwv_flow_imp.g_varchar2_table(10) := 're insert or update on EBA_ca_email_group_mbrs              '||wwv_flow.LF||
'  for each row  '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'  if insertin';
wwv_flow_imp.g_varchar2_table(11) := 'g then'||wwv_flow.LF||
'     if :NEW.mbr_id is null '||wwv_flow.LF||
'        then :NEW.mbr_id := EBA_ca_api.gen_id; '||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(12) := '  :NEW.CREATED_ON := CURRENT_TIMESTAMP;'||wwv_flow.LF||
'     :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(13) := ''||wwv_flow.LF||
'   if updating then'||wwv_flow.LF||
'      :NEW.LAST_UPDATED_ON := CURRENT_TIMESTAMP;'||wwv_flow.LF||
'      :NEW.LAST_UPDATED_BY := ';
wwv_flow_imp.g_varchar2_table(14) := 'nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'end; '||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger EBA_ca_email_group_mbrs_biu enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3254470867751756580)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'group members'
,p_sequence=>220
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
