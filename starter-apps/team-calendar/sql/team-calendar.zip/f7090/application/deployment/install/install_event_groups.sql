prompt --application/deployment/install/install_event_groups
begin
--   Manifest
--     INSTALL: INSTALL-event groups
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table EBA_ca_email_groups ('||wwv_flow.LF||
'   group_id    number         not null,'||wwv_flow.LF||
'   group_name  varchar2(2';
wwv_flow_imp.g_varchar2_table(2) := '55)  not null,'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   created_on       timestamp with time zone  not null,'||wwv_flow.LF||
'   created_by       var';
wwv_flow_imp.g_varchar2_table(3) := 'char2(255)  not null,'||wwv_flow.LF||
'   last_updated_on  timestamp with time zone,'||wwv_flow.LF||
'   last_updated_by  varchar2(255';
wwv_flow_imp.g_varchar2_table(4) := ') )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_ca_email_groups'||wwv_flow.LF||
'   add constraint EBA_ca_email_groups_pk primary key (group_id';
wwv_flow_imp.g_varchar2_table(5) := ')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_ca_email_groups'||wwv_flow.LF||
'   add constraint EBA_ca_email_groups_uk unique (group_name)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'c';
wwv_flow_imp.g_varchar2_table(6) := 'reate or replace trigger EBA_ca_email_groups_biu'||wwv_flow.LF||
'  before insert or update on EBA_ca_email_groups   ';
wwv_flow_imp.g_varchar2_table(7) := '            '||wwv_flow.LF||
'  for each row  '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'  if inserting then'||wwv_flow.LF||
'     if :NEW.group_id is null '||wwv_flow.LF||
'        th';
wwv_flow_imp.g_varchar2_table(8) := 'en :NEW.group_id := EBA_ca_api.gen_id; '||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'     :NEW.CREATED_ON := current_timestamp;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(9) := ' :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'   if updating then'||wwv_flow.LF||
'      :NEW.LAST_UPDATED';
wwv_flow_imp.g_varchar2_table(10) := '_ON := current_timestamp;'||wwv_flow.LF||
'      :NEW.LAST_UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'end; '||wwv_flow.LF||
'/';
wwv_flow_imp.g_varchar2_table(11) := ''||wwv_flow.LF||
'alter trigger EBA_ca_email_groups_biu enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3254470663595755329)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'event groups'
,p_sequence=>215
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
