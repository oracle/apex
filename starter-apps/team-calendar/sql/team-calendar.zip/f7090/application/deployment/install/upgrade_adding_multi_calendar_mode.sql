prompt --application/deployment/install/upgrade_adding_multi_calendar_mode
begin
--   Manifest
--     INSTALL: UPGRADE-Adding Multi-Calendar Mode
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_ca_calendars ('||wwv_flow.LF||
'   calendar_id      number         not null,'||wwv_flow.LF||
'   short_name       var';
wwv_flow_imp.g_varchar2_table(2) := 'char2(10)   not null,'||wwv_flow.LF||
'   calendar_name    varchar2(60)   not null,'||wwv_flow.LF||
'   public_view_yn   varchar2(1)  ';
wwv_flow_imp.g_varchar2_table(3) := '  default ''Y'','||wwv_flow.LF||
'   description      varchar2(4000),'||wwv_flow.LF||
'   is_active_yn     varchar2(1)    default ''Y'','||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(4) := '  --'||wwv_flow.LF||
'   created_on       timestamp with time zone  not null,'||wwv_flow.LF||
'   created_by       varchar2(255)  not ';
wwv_flow_imp.g_varchar2_table(5) := 'null,'||wwv_flow.LF||
'   last_updated_on  timestamp with time zone,'||wwv_flow.LF||
'   last_updated_by  varchar2(255) )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'alter tab';
wwv_flow_imp.g_varchar2_table(6) := 'le eba_ca_calendars'||wwv_flow.LF||
'   add constraint eba_ca_calendars_pk primary key (calendar_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'alter tab';
wwv_flow_imp.g_varchar2_table(7) := 'le eba_ca_calendars'||wwv_flow.LF||
'   add constraint eba_ca_calendars_uk1 unique (short_name)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_ca_';
wwv_flow_imp.g_varchar2_table(8) := 'calendars'||wwv_flow.LF||
'   add constraint eba_ca_calendars_uk2 unique (calendar_name)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_ca_calenda';
wwv_flow_imp.g_varchar2_table(9) := 'rs'||wwv_flow.LF||
'   add constraint eba_ca_calendar_cc1 '||wwv_flow.LF||
'   check ( public_view_yn in (''Y'',''N'') )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba';
wwv_flow_imp.g_varchar2_table(10) := '_ca_calendars'||wwv_flow.LF||
'   add constraint eba_ca_calendar_cc2 '||wwv_flow.LF||
'   check ( is_active_yn in (''Y'',''N'') )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(11) := '   '||wwv_flow.LF||
'create or replace trigger eba_ca_calendars_biu'||wwv_flow.LF||
'  before insert or update on eba_ca_calendars    ';
wwv_flow_imp.g_varchar2_table(12) := '           '||wwv_flow.LF||
'  for each row  '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'  if inserting then'||wwv_flow.LF||
'     if :new.calendar_id is null '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(13) := 'then :new.calendar_id := eba_ca_api.gen_id; '||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'     :NEW.CREATED_ON := CURRENT_TIMESTAMP;';
wwv_flow_imp.g_varchar2_table(14) := ''||wwv_flow.LF||
'     :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'   :NEW.LAST_UPDATED_ON := CURRENT_TIM';
wwv_flow_imp.g_varchar2_table(15) := 'ESTAMP;'||wwv_flow.LF||
'   :NEW.LAST_UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'end; '||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'alter trigger eba_ca_calend';
wwv_flow_imp.g_varchar2_table(16) := 'ars_biu enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Add constraint error messages'||wwv_flow.LF||
'insert into eba_ca_error_lookup (constraint_name,';
wwv_flow_imp.g_varchar2_table(17) := ' message, language_code) values (''EBA_CA_CALENDAR_UK1'', ''Calendar Short Name must be unique.'', ''en'')';
wwv_flow_imp.g_varchar2_table(18) := ';'||wwv_flow.LF||
'insert into eba_ca_error_lookup (constraint_name, message, language_code) values (''EBA_CA_CALENDAR';
wwv_flow_imp.g_varchar2_table(19) := '_UK2'', ''Calendar Name must be unique.'', ''en'');'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Update Events table'||wwv_flow.LF||
'alter table eba_ca_events add';
wwv_flow_imp.g_varchar2_table(20) := ' (calendar_id number)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_ca_events add constraint eba_ca_events_fk3'||wwv_flow.LF||
'   foreign key (c';
wwv_flow_imp.g_varchar2_table(21) := 'alendar_id)'||wwv_flow.LF||
'   references eba_ca_calendars (calendar_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create index eba_ca_events_i3'||wwv_flow.LF||
'   on eba_c';
wwv_flow_imp.g_varchar2_table(22) := 'a_events (calendar_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- comma separated list of calendar_ids, for contributor (access_level_id ';
wwv_flow_imp.g_varchar2_table(23) := '2)'||wwv_flow.LF||
'alter table eba_ca_users add (restricted_to varchar2(4000)); '||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1856500086473604486)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'Adding Multi-Calendar Mode'
,p_sequence=>35
,p_script_type=>'UPGRADE'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'from user_tables',
'where table_name = ''EBA_CA_CALENDARS'';'))
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
