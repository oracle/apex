prompt --application/deployment/install/install_notifications
begin
--   Manifest
--     INSTALL: INSTALL-notifications
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table EBA_CA_notifications ('||wwv_flow.LF||
'    id                        number            not null'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(2) := '                                         constraint EBA_CA_note_pk'||wwv_flow.LF||
'                                 ';
wwv_flow_imp.g_varchar2_table(3) := '               primary key,'||wwv_flow.LF||
'    row_version_number        number,'||wwv_flow.LF||
'    notification_name         varc';
wwv_flow_imp.g_varchar2_table(4) := 'har2(255)     not null,'||wwv_flow.LF||
'    notification_description  varchar2(4000)    null,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    notificatio';
wwv_flow_imp.g_varchar2_table(5) := 'n_type         varchar2(30)      not null'||wwv_flow.LF||
'                                                constraint';
wwv_flow_imp.g_varchar2_table(6) := ' EBA_CA_note_tp_cc'||wwv_flow.LF||
'                                                check (notification_type in (''RED';
wwv_flow_imp.g_varchar2_table(7) := ''',''YELLOW'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    display_sequence          number,'||wwv_flow.LF||
'    display_from              timestamp w';
wwv_flow_imp.g_varchar2_table(8) := 'ith time zone,'||wwv_flow.LF||
'    display_until             timestamp with time zone,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created_by        ';
wwv_flow_imp.g_varchar2_table(9) := '        varchar2(255)       not null,'||wwv_flow.LF||
'    created                   timestamp with time zone,'||wwv_flow.LF||
'    up';
wwv_flow_imp.g_varchar2_table(10) := 'dated_by                varchar2(255)       not null,'||wwv_flow.LF||
'    updated                   timestamp with t';
wwv_flow_imp.g_varchar2_table(11) := 'ime zone )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index EBA_CA_note_uk on EBA_CA_notifications (notification_name);'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'crea';
wwv_flow_imp.g_varchar2_table(12) := 'te or replace trigger EBA_CA_note_biu'||wwv_flow.LF||
'before insert or update on EBA_CA_notifications'||wwv_flow.LF||
'    for each r';
wwv_flow_imp.g_varchar2_table(13) := 'ow'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(14) := 'XXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'        into :new.id'||wwv_flow.LF||
'        from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(15) := '     :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(16) := ':new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :new.';
wwv_flow_imp.g_varchar2_table(17) := 'row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.row_version_number := nvl(:ol';
wwv_flow_imp.g_varchar2_table(18) := 'd.row_version_number,1) + 1;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.update';
wwv_flow_imp.g_varchar2_table(19) := 'd    := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.notification_type is null then'||wwv_flow.LF||
'       :new.notifi';
wwv_flow_imp.g_varchar2_table(20) := 'cation_type := ''MANUAL'';'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.display_sequence is null then'||wwv_flow.LF||
'       :new.display_s';
wwv_flow_imp.g_varchar2_table(21) := 'equence := 10;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger EBA_CA_note_biu enable;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3256158360094202056)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'notifications'
,p_sequence=>235
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
