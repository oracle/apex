prompt --application/deployment/install/install_eba_ca_specs
begin
--   Manifest
--     INSTALL: INSTALL-eba_ca specs
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_ca is '||wwv_flow.LF||
'    -----------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(2) := '--------------'||wwv_flow.LF||
'    -- Generates a unique Identifier'||wwv_flow.LF||
'    --------------------------------------------';
wwv_flow_imp.g_varchar2_table(3) := '-----------------------------'||wwv_flow.LF||
'    function gen_id return number;'||wwv_flow.LF||
''||wwv_flow.LF||
'    ------------------------------';
wwv_flow_imp.g_varchar2_table(4) := '-------------------------------------------'||wwv_flow.LF||
'    -- Gets the current user''s authorization level. Can ';
wwv_flow_imp.g_varchar2_table(5) := 'depend on the following:'||wwv_flow.LF||
'    --  * If access control is currently disabled, returns highest level of';
wwv_flow_imp.g_varchar2_table(6) := ' 3.'||wwv_flow.LF||
'    --  * If access control is enabled, but user is not in list, returns 0'||wwv_flow.LF||
'    --  * If access c';
wwv_flow_imp.g_varchar2_table(7) := 'ontrol is enabled and user is in list, returns their'||wwv_flow.LF||
'    --    access level.'||wwv_flow.LF||
'    -------------------';
wwv_flow_imp.g_varchar2_table(8) := '------------------------------------------------------'||wwv_flow.LF||
'    function get_authorization_level ('||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(9) := '  p_username             varchar2)'||wwv_flow.LF||
'        return number;'||wwv_flow.LF||
'    --------------------------------------';
wwv_flow_imp.g_varchar2_table(10) := '-----------------------------------'||wwv_flow.LF||
'    -- Returns all of the restricted calendars for the given use';
wwv_flow_imp.g_varchar2_table(11) := 'r          --'||wwv_flow.LF||
'    -------------------------------------------------------------------------'||wwv_flow.LF||
'    func';
wwv_flow_imp.g_varchar2_table(12) := 'tion decode_restrictions ('||wwv_flow.LF||
'        p_user_id             number)'||wwv_flow.LF||
'        return varchar2;'||wwv_flow.LF||
'end eba_ca';
wwv_flow_imp.g_varchar2_table(13) := ' ;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3254482474884023559)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'eba_ca specs'
,p_sequence=>340
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(1682434727470625969)
,p_script_id=>wwv_flow_imp.id(3254482474884023559)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_CA'
);
wwv_flow_imp.component_end;
end;
/
