prompt --application/deployment/install/install_tags
begin
--   Manifest
--     INSTALL: INSTALL-tags
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE eba_ca_tags ('||wwv_flow.LF||
'    id                      number primary key,'||wwv_flow.LF||
'    tag                  ';
wwv_flow_imp.g_varchar2_table(2) := '   varchar2(255) not null,'||wwv_flow.LF||
'    content_id              number,'||wwv_flow.LF||
'    content_type            varchar2(';
wwv_flow_imp.g_varchar2_table(3) := '30)'||wwv_flow.LF||
'                            constraint eba_ca_tags_ck check'||wwv_flow.LF||
'                            (content';
wwv_flow_imp.g_varchar2_table(4) := '_type in (''EVENT'',''NOTES'',''FILE'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created                 timestamp with time zone,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(5) := ' created_by              varchar2(255),'||wwv_flow.LF||
'    updated                 timestamp with time zone,'||wwv_flow.LF||
'    up';
wwv_flow_imp.g_varchar2_table(6) := 'dated_by              varchar2(255)'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger biu_eba_ca_tags'||wwv_flow.LF||
'   before ins';
wwv_flow_imp.g_varchar2_table(7) := 'ert or update on eba_ca_tags'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'   begin'||wwv_flow.LF||
'      if inserting then'||wwv_flow.LF||
'         if :NEW.ID is';
wwv_flow_imp.g_varchar2_table(8) := ' null then'||wwv_flow.LF||
'           select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'           int';
wwv_flow_imp.g_varchar2_table(9) := 'o :new.id'||wwv_flow.LF||
'           from dual;'||wwv_flow.LF||
'         end if;'||wwv_flow.LF||
'         :NEW.CREATED := current_timestamp;'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(10) := '  :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'      if updating then'||wwv_flow.LF||
'         :NEW.UP';
wwv_flow_imp.g_varchar2_table(11) := 'DATED := current_timestamp;'||wwv_flow.LF||
'         :NEW.UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(12) := '/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_ca_tags_type_sum ('||wwv_flow.LF||
'    tag                             varchar2(255)';
wwv_flow_imp.g_varchar2_table(13) := ','||wwv_flow.LF||
'    content_type                    varchar2(30),'||wwv_flow.LF||
'    tag_count                       number,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(14) := 'constraint eba_ca_tags_type_sum_pk primary key (tag,content_type)'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_ca_tags_';
wwv_flow_imp.g_varchar2_table(15) := 'sum ('||wwv_flow.LF||
'    tag                             varchar2(255),'||wwv_flow.LF||
'    tag_count                       number,';
wwv_flow_imp.g_varchar2_table(16) := ''||wwv_flow.LF||
'    constraint eba_ca_tags_sum_pk   primary key (tag)'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3256257167180108093)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'tags'
,p_sequence=>206
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
