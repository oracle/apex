prompt --application/deployment/install/install_eba_ca_body
begin
--   Manifest
--     INSTALL: INSTALL-eba_ca body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body eba_ca as '||wwv_flow.LF||
''||wwv_flow.LF||
'    -----------------------------------------------------';
wwv_flow_imp.g_varchar2_table(2) := '--------------------'||wwv_flow.LF||
'    -- Generates a unique Identifier'||wwv_flow.LF||
'    --------------------------------------';
wwv_flow_imp.g_varchar2_table(3) := '-----------------------------------'||wwv_flow.LF||
'    function gen_id'||wwv_flow.LF||
'        return number'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_id  n';
wwv_flow_imp.g_varchar2_table(4) := 'umber;'||wwv_flow.LF||
'    begin        '||wwv_flow.LF||
'        select to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(5) := '        into l_id'||wwv_flow.LF||
'          from dual;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'        return l_id;'||wwv_flow.LF||
'    end gen_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --------------';
wwv_flow_imp.g_varchar2_table(6) := '-----------------------------------------------------------'||wwv_flow.LF||
'    -- Gets the current user''s authoriza';
wwv_flow_imp.g_varchar2_table(7) := 'tion level. Depends on the following:'||wwv_flow.LF||
'    --  * If access control is currently disabled, returns hig';
wwv_flow_imp.g_varchar2_table(8) := 'hest level of 3.'||wwv_flow.LF||
'    --  * If access control is enabled, but user is not in list, returns 0'||wwv_flow.LF||
'    --  ';
wwv_flow_imp.g_varchar2_table(9) := '* If access control is enabled and user is in list, returns their'||wwv_flow.LF||
'    --    access level.'||wwv_flow.LF||
'    ------';
wwv_flow_imp.g_varchar2_table(10) := '-------------------------------------------------------------------'||wwv_flow.LF||
'    function get_authorization_l';
wwv_flow_imp.g_varchar2_table(11) := 'evel ('||wwv_flow.LF||
'        p_username             varchar2)'||wwv_flow.LF||
'        return number'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_access_level_';
wwv_flow_imp.g_varchar2_table(12) := 'id       eba_ca_users.access_level_id%type := 0;  -- default to lowest privilege.'||wwv_flow.LF||
'        l_account_';
wwv_flow_imp.g_varchar2_table(13) := 'locked        eba_ca_users.account_locked%type;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        -- If access control is disabled, ';
wwv_flow_imp.g_varchar2_table(14) := 'default to highest privilege'||wwv_flow.LF||
'        if eba_ca_fw.get_preference_value(''ACCESS_CONTROL_ENABLED'') = ''';
wwv_flow_imp.g_varchar2_table(15) := 'N'' then'||wwv_flow.LF||
'            return 3;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            -- Query for user''s access level, throws no_d';
wwv_flow_imp.g_varchar2_table(16) := 'ata_found if no user'||wwv_flow.LF||
'            select access_level_id,'||wwv_flow.LF||
'                   account_locked'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(17) := '     into l_access_level_id,'||wwv_flow.LF||
'                   l_account_locked'||wwv_flow.LF||
'              from eba_ca_users'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(18) := '          where username = p_username;'||wwv_flow.LF||
'            -- Check if user''s account is locked, return 0 (n';
wwv_flow_imp.g_varchar2_table(19) := 'o privilege), otherwise stick'||wwv_flow.LF||
'            -- with their level.'||wwv_flow.LF||
'            if l_account_locked = ''Y''';
wwv_flow_imp.g_varchar2_table(20) := ' then'||wwv_flow.LF||
'                return 0;'||wwv_flow.LF||
'            end if;'||wwv_flow.LF||
'            -- Overwrite user access level 1 wit';
wwv_flow_imp.g_varchar2_table(21) := 'h access level 2 if access control scope is PUBLIC_CONTRIBUTE'||wwv_flow.LF||
'            if l_access_level_id = 1 a';
wwv_flow_imp.g_varchar2_table(22) := 'nd eba_ca_fw.get_preference_value(''ACCESS_CONTROL_SCOPE'') = ''PUBLIC_CONTRIBUTE'' then'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(23) := ' return 2;'||wwv_flow.LF||
'            end if;            '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        return l_access_level_id;'||wwv_flow.LF||
'    exc';
wwv_flow_imp.g_varchar2_table(24) := 'eption'||wwv_flow.LF||
'        when no_data_found then'||wwv_flow.LF||
'            -- If no user exists with passed username, do a f';
wwv_flow_imp.g_varchar2_table(25) := 'inal check if reader access is set to any authenticated user'||wwv_flow.LF||
'            if eba_ca_fw.get_preference';
wwv_flow_imp.g_varchar2_table(26) := '_value(''ACCESS_CONTROL_SCOPE'') = ''PUBLIC_CONTRIBUTE'' then'||wwv_flow.LF||
'                return 2;'||wwv_flow.LF||
'            elsi';
wwv_flow_imp.g_varchar2_table(27) := 'f eba_ca_fw.get_preference_value(''ACCESS_CONTROL_SCOPE'') = ''PUBLIC_READONLY'' then'||wwv_flow.LF||
'                re';
wwv_flow_imp.g_varchar2_table(28) := 'turn 1;'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'                return 0;'||wwv_flow.LF||
'            end if;           '||wwv_flow.LF||
'    end get_author';
wwv_flow_imp.g_varchar2_table(29) := 'ization_level;'||wwv_flow.LF||
'    -------------------------------------------------------------------------'||wwv_flow.LF||
'    -- ';
wwv_flow_imp.g_varchar2_table(30) := 'Returns all of the restricted calendars for the given user          --'||wwv_flow.LF||
'    -------------------------';
wwv_flow_imp.g_varchar2_table(31) := '------------------------------------------------'||wwv_flow.LF||
'    function decode_restrictions ('||wwv_flow.LF||
'        p_user_i';
wwv_flow_imp.g_varchar2_table(32) := 'd             number)'||wwv_flow.LF||
'        return varchar2 is'||wwv_flow.LF||
'      l_restricted_to varchar2(4000);'||wwv_flow.LF||
'      l_calen';
wwv_flow_imp.g_varchar2_table(33) := 'dar_id   number;'||wwv_flow.LF||
'      l_calendar_name varchar2(4000);'||wwv_flow.LF||
'      l_return        varchar2(4000);'||wwv_flow.LF||
'    beg';
wwv_flow_imp.g_varchar2_table(34) := 'in'||wwv_flow.LF||
'null;'||wwv_flow.LF||
'/*'||wwv_flow.LF||
'      select restricted_to'||wwv_flow.LF||
'      into l_restricted_to'||wwv_flow.LF||
'      from eba_ca_users'||wwv_flow.LF||
'      wher';
wwv_flow_imp.g_varchar2_table(35) := 'e id = p_user_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'      if l_restricted_to is null then'||wwv_flow.LF||
'        return null;'||wwv_flow.LF||
'      end if;'||wwv_flow.LF||
'      '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(36) := '     while l_restricted_to is not null loop'||wwv_flow.LF||
'        l_calendar_id := decode(instr(l_restricted_to, ''';
wwv_flow_imp.g_varchar2_table(37) := ':''), 0, l_restricted_to, substr(l_restricted_to, 1, instr(l_restricted_to, '':'') - 1));'||wwv_flow.LF||
'        begin';
wwv_flow_imp.g_varchar2_table(38) := ''||wwv_flow.LF||
'          select short_name || '' ('' || decode(public_view_yn, ''Y'', null, ''Private'') || '')'''||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(39) := '  into l_calendar_name'||wwv_flow.LF||
'          from eba_ca_calendars'||wwv_flow.LF||
'          where calendar_id = l_calendar_id;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(40) := '        exception'||wwv_flow.LF||
'          when no_data_found then'||wwv_flow.LF||
'            l_calendar_name := l_calendar_id;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(41) := '      end;'||wwv_flow.LF||
'        '||wwv_flow.LF||
'        if l_return is null then'||wwv_flow.LF||
'          l_return := l_calendar_name;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(42) := 'elsif length(l_return) + length(l_calendar_name) + 2 > 3900 then'||wwv_flow.LF||
'          l_return := l_return || ''';
wwv_flow_imp.g_varchar2_table(43) := '; ...'';'||wwv_flow.LF||
'          exit;'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'          l_return := l_return || ''; '' || l_calendar_name;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(44) := '    end if;'||wwv_flow.LF||
'        '||wwv_flow.LF||
'        l_restricted_to := substr(l_restricted_to, instr(l_restricted_to, '':'') ';
wwv_flow_imp.g_varchar2_table(45) := '+ 1);'||wwv_flow.LF||
'      end loop;'||wwv_flow.LF||
'      '||wwv_flow.LF||
'      return l_return;'||wwv_flow.LF||
'    exception'||wwv_flow.LF||
'      when no_data_found then'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(46) := '    return null;'||wwv_flow.LF||
'*/'||wwv_flow.LF||
'    end decode_restrictions;'||wwv_flow.LF||
'end eba_ca;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3254484357054056270)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'eba_ca body'
,p_sequence=>380
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
