prompt --application/deployment/install/install_series
begin
--   Manifest
--     INSTALL: INSTALL-series
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_ca_series ('||wwv_flow.LF||
'   series_id        number        not null,'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   start_date       t';
wwv_flow_imp.g_varchar2_table(2) := 'imestamp with time zone  not null,'||wwv_flow.LF||
'   end_date         timestamp with time zone  not null,'||wwv_flow.LF||
'   recur_';
wwv_flow_imp.g_varchar2_table(3) := 'freq       varchar2(10)  not null,'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   created_on       timestamp with time zone  not null,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(4) := 'created_by       varchar2(255)  not null,'||wwv_flow.LF||
'   last_updated_on  timestamp with time zone,'||wwv_flow.LF||
'   last_upda';
wwv_flow_imp.g_varchar2_table(5) := 'ted_by  varchar2(255) )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table eba_ca_series '||wwv_flow.LF||
'   add constraint eba_ca_series_pk primary key ';
wwv_flow_imp.g_varchar2_table(6) := '(series_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger eba_ca_series_biu'||wwv_flow.LF||
'  before insert or update on eba_ca_series';
wwv_flow_imp.g_varchar2_table(7) := '               '||wwv_flow.LF||
'  for each row  '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'  if inserting then'||wwv_flow.LF||
'     if :NEW.series_id is null '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(8) := '  then :NEW.series_id := eba_ca_api.gen_id;'||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'     :NEW.CREATED_ON := CURRENT_TIMESTAMP;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(9) := '     :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'   if updating then'||wwv_flow.LF||
'      :NEW.LAST_UPD';
wwv_flow_imp.g_varchar2_table(10) := 'ATED_ON := CURRENT_TIMESTAMP;'||wwv_flow.LF||
'      :NEW.LAST_UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'end';
wwv_flow_imp.g_varchar2_table(11) := '; '||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_ca_series_biu enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3254470178702750242)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'series'
,p_sequence=>205
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
