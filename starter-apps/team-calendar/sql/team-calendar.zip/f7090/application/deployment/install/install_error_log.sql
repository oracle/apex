prompt --application/deployment/install/install_error_log
begin
--   Manifest
--     INSTALL: INSTALL-error log
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_ca_errors ('||wwv_flow.LF||
'    id                 number not null'||wwv_flow.LF||
'                       constrain';
wwv_flow_imp.g_varchar2_table(2) := 't eba_ca_errors_pk'||wwv_flow.LF||
'                       primary key,'||wwv_flow.LF||
'    err_time           timestamp with time zo';
wwv_flow_imp.g_varchar2_table(3) := 'ne'||wwv_flow.LF||
'                       default current_timestamp'||wwv_flow.LF||
'                       not null,'||wwv_flow.LF||
'    app_id     ';
wwv_flow_imp.g_varchar2_table(4) := '        number,'||wwv_flow.LF||
'    app_page_id        number,'||wwv_flow.LF||
'    app_user           varchar2(512),'||wwv_flow.LF||
'    user_agent ';
wwv_flow_imp.g_varchar2_table(5) := '        varchar2(4000),'||wwv_flow.LF||
'    ip_address         varchar2(512), -- As reported by owa_util.get_cgi_env';
wwv_flow_imp.g_varchar2_table(6) := ''||wwv_flow.LF||
'    ip_address2       varchar2(512), -- As reported by sys_context'||wwv_flow.LF||
'    -- From APEX_ERROR.T_ERROR:'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(7) := '    message           varchar2(4000), /* Displayed error message */'||wwv_flow.LF||
'    page_item_name    varchar2(2';
wwv_flow_imp.g_varchar2_table(8) := '55),  /* Associated page item name */'||wwv_flow.LF||
'    region_id         number,         /* Associated tabular fo';
wwv_flow_imp.g_varchar2_table(9) := 'rm region id of the primary application */'||wwv_flow.LF||
'    column_alias      varchar2(255),  /* Associated tabul';
wwv_flow_imp.g_varchar2_table(10) := 'ar form column alias */'||wwv_flow.LF||
'    row_num           number,         /* Associated tabular form row */'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(11) := 'apex_error_code   varchar2(255),  /* Contains the system message code if it''''s an error raised by AP';
wwv_flow_imp.g_varchar2_table(12) := 'EX */'||wwv_flow.LF||
'    ora_sqlcode       number,         /* SQLCODE on exception stack which triggered the error,';
wwv_flow_imp.g_varchar2_table(13) := ' NULL if the error was not raised by an ORA error */'||wwv_flow.LF||
'    ora_sqlerrm       varchar2(4000), /* SQLERR';
wwv_flow_imp.g_varchar2_table(14) := 'M which triggered the error, NULL if the error was not raised by an ORA error */'||wwv_flow.LF||
'    error_backtrace';
wwv_flow_imp.g_varchar2_table(15) := '   varchar2(4000)  /* Output of dbms_utility.format_error_backtrace or dbms_utility.format_call_stac';
wwv_flow_imp.g_varchar2_table(16) := 'k */'||wwv_flow.LF||
'    -- END APEX_ERROR.T_ERROR'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_ca_errors_i1 on eba_ca_errors( err_time );'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(17) := 'create or replace trigger bi_eba_ca_errors'||wwv_flow.LF||
'    before insert or update on eba_ca_errors'||wwv_flow.LF||
'    for each';
wwv_flow_imp.g_varchar2_table(18) := ' row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if :new.id is null then'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(19) := 'XXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3304017160028307576)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'error log'
,p_sequence=>5
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
