prompt --application/deployment/install/install_admins_to_be_replaced_with_new_std_code
begin
--   Manifest
--     INSTALL: INSTALL-admins (to be replaced with new std code)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table EBA_ca_admins ('||wwv_flow.LF||
'   admin_id        number         not null,'||wwv_flow.LF||
'   admin_username  varchar2';
wwv_flow_imp.g_varchar2_table(2) := '(255)  not null,'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   created_on       timestamp with time zone  not null,'||wwv_flow.LF||
'   created_by       v';
wwv_flow_imp.g_varchar2_table(3) := 'archar2(255)  not null,'||wwv_flow.LF||
'   last_updated_on  timestamp with time zone,'||wwv_flow.LF||
'   last_updated_by  varchar2(2';
wwv_flow_imp.g_varchar2_table(4) := '55) )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_ca_admins'||wwv_flow.LF||
'   add constraint EBA_ca_admins_pk primary key (admin_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter ';
wwv_flow_imp.g_varchar2_table(5) := 'table EBA_ca_admins'||wwv_flow.LF||
'   add constraint EBA_ca_admins_uk unique (admin_username)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace t';
wwv_flow_imp.g_varchar2_table(6) := 'rigger EBA_ca_admins_biu'||wwv_flow.LF||
'  before insert or update on EBA_ca_admins               '||wwv_flow.LF||
'  for each row  '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(7) := 'begin   '||wwv_flow.LF||
'  if inserting then'||wwv_flow.LF||
'     if :NEW.admin_id is null '||wwv_flow.LF||
'        then :NEW.admin_id := EBA_ca_api';
wwv_flow_imp.g_varchar2_table(8) := '.gen_id; '||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'     :NEW.CREATED_ON := CURRENT_TIMESTAMP;'||wwv_flow.LF||
'     :NEW.CREATED_BY := nvl(v(''APP';
wwv_flow_imp.g_varchar2_table(9) := '_USER''),USER);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'   if updating then'||wwv_flow.LF||
'      :NEW.LAST_UPDATED_ON := CURRENT_TIMESTAMP;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(10) := '  :NEW.LAST_UPDATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'end; '||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger EBA_ca_admins_b';
wwv_flow_imp.g_varchar2_table(11) := 'iu enable'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3254471560610763964)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'admins (to be replaced with new std code)'
,p_sequence=>230
,p_script_type=>'INSTALL'
,p_condition_type=>'NOT_EXISTS'
,p_condition=>'select null from all_tables where table_name = ''EBA_CA_ADMINS'';'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
