prompt --application/deployment/install/install_timeframes
begin
--   Manifest
--     INSTALL: INSTALL-timeframes
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table EBA_ca_timeframes ('||wwv_flow.LF||
'   tf_id       number         not null,'||wwv_flow.LF||
'   tf_name     varchar2(255';
wwv_flow_imp.g_varchar2_table(2) := ')  not null,'||wwv_flow.LF||
'   start_date  date           not null,'||wwv_flow.LF||
'   end_date    date           not null,'||wwv_flow.LF||
'   --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(3) := '  created_on       timestamp with time zone  not null,'||wwv_flow.LF||
'   created_by       varchar2(255)  not null,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(4) := '   last_updated_on  timestamp with time zone,'||wwv_flow.LF||
'   last_updated_by  varchar2(255) )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_';
wwv_flow_imp.g_varchar2_table(5) := 'ca_timeframes'||wwv_flow.LF||
'   add constraint EBA_ca_timeframes_pk primary key (tf_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter table EBA_ca_timefr';
wwv_flow_imp.g_varchar2_table(6) := 'ames'||wwv_flow.LF||
'   add constraint EBA_ca_timeframes_uk unique (tf_name)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace trigger EBA_ca_time';
wwv_flow_imp.g_varchar2_table(7) := 'frames_biu'||wwv_flow.LF||
'  before insert or update on EBA_ca_timeframes               '||wwv_flow.LF||
'  for each row  '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(8) := ' if inserting then'||wwv_flow.LF||
'     if :NEW.tf_id is null '||wwv_flow.LF||
'        then :NEW.tf_id := EBA_ca_api.gen_id; '||wwv_flow.LF||
'     e';
wwv_flow_imp.g_varchar2_table(9) := 'nd if;'||wwv_flow.LF||
'     :NEW.CREATED_ON := CURRENT_TIMESTAMP;'||wwv_flow.LF||
'     :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(10) := '  end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'   if updating then'||wwv_flow.LF||
'      :NEW.LAST_UPDATED_ON := CURRENT_TIMESTAMP;'||wwv_flow.LF||
'      :NEW.LAST_UPDA';
wwv_flow_imp.g_varchar2_table(11) := 'TED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'end; '||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger EBA_ca_timeframes_biu enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(12) := ''||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3254471150567761033)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'timeframes'
,p_sequence=>225
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
