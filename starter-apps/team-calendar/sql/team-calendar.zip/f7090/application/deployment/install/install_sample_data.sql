prompt --application/deployment/install/install_sample_data
begin
--   Manifest
--     INSTALL: INSTALL-Sample Data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_ca_sample_data as'||wwv_flow.LF||
'    procedure load;'||wwv_flow.LF||
'    procedure remove;'||wwv_flow.LF||
'    functi';
wwv_flow_imp.g_varchar2_table(2) := 'on is_loaded return boolean;'||wwv_flow.LF||
'end eba_ca_sample_data;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace package body eba_ca_sample';
wwv_flow_imp.g_varchar2_table(3) := '_data as'||wwv_flow.LF||
'    procedure load is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        merge into eba_ca_event_types dest using ('||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(4) := '    select 1 type_id, ''External Meeting'' type_name, ''#00FF00'' display_color, ''#00FF00'' border_color,';
wwv_flow_imp.g_varchar2_table(5) := ' ''Y'' is_active_yn, ''N'' internal_yn, 2 color_pref_id from dual'||wwv_flow.LF||
'            union all'||wwv_flow.LF||
'            sele';
wwv_flow_imp.g_varchar2_table(6) := 'ct 2 type_id, ''Team Meeting'' type_name, ''#FF0000'' display_color, ''#FF0000'' border_color,  ''Y'' is_act';
wwv_flow_imp.g_varchar2_table(7) := 'ive_yn, ''Y'' internal_yn, 1 color_pref_id from dual'||wwv_flow.LF||
'            union all'||wwv_flow.LF||
'            select 3 type_i';
wwv_flow_imp.g_varchar2_table(8) := 'd, ''Recurring Meeting'' type_name, ''#F1C40F'' display_color, ''#F1C40F'' border_color,  ''Y'' is_active_yn';
wwv_flow_imp.g_varchar2_table(9) := ', ''Y'' internal_yn, 13 color_pref_id from dual'||wwv_flow.LF||
'            ) src'||wwv_flow.LF||
'        on (dest.type_id = src.type_';
wwv_flow_imp.g_varchar2_table(10) := 'id)'||wwv_flow.LF||
'        when not matched then'||wwv_flow.LF||
'            insert ( type_id, type_name, display_color, border_col';
wwv_flow_imp.g_varchar2_table(11) := 'or, is_active_yn, internal_yn, color_pref_id )'||wwv_flow.LF||
'            values ( src.type_id, src.type_name, src.';
wwv_flow_imp.g_varchar2_table(12) := 'display_color, src.border_color, src.is_active_yn, src.internal_yn, src.color_pref_id );'||wwv_flow.LF||
''||wwv_flow.LF||
'        me';
wwv_flow_imp.g_varchar2_table(13) := 'rge into eba_ca_series dest using ('||wwv_flow.LF||
'            select 1 series_id, trunc(current_timestamp+1,''HH'') ';
wwv_flow_imp.g_varchar2_table(14) := 'start_date, trunc(current_timestamp+50,''HH'') end_date, 8 recur_freq from dual'||wwv_flow.LF||
'            ) src'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(15) := '    on (dest.series_id = src.series_id)'||wwv_flow.LF||
'        when not matched then'||wwv_flow.LF||
'            insert ( series_id';
wwv_flow_imp.g_varchar2_table(16) := ', start_date, end_date, recur_freq )'||wwv_flow.LF||
'            values ( src.series_id, src.start_date, src.end_dat';
wwv_flow_imp.g_varchar2_table(17) := 'e, src.recur_freq );'||wwv_flow.LF||
''||wwv_flow.LF||
'        merge into eba_ca_events dest using ('||wwv_flow.LF||
'            select 1 event_id,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(18) := '               ''All Hands Meeting'' event_name,'||wwv_flow.LF||
'                2 type_id,'||wwv_flow.LF||
'                trunc(curr';
wwv_flow_imp.g_varchar2_table(19) := 'ent_timestamp+5,''HH'') event_date_time,'||wwv_flow.LF||
'                2 duration,'||wwv_flow.LF||
'                ''Mandatory event''';
wwv_flow_imp.g_varchar2_table(20) := ' event_desc,'||wwv_flow.LF||
'                ''Larry'' contact_person,'||wwv_flow.LF||
'                ''Y'' display_time,'||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(21) := '   ''HQ Conference Room 1'' location,'||wwv_flow.LF||
'                ''Acme'' link_name_1,'||wwv_flow.LF||
'                ''http://acme';
wwv_flow_imp.g_varchar2_table(22) := '.com'' link_url_1,'||wwv_flow.LF||
'                null series_id'||wwv_flow.LF||
'            from dual'||wwv_flow.LF||
'            union all'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(23) := '     select 2,'||wwv_flow.LF||
'                ''Sales Event'','||wwv_flow.LF||
'                1,'||wwv_flow.LF||
'                trunc(current_times';
wwv_flow_imp.g_varchar2_table(24) := 'tamp+7,''DD''),'||wwv_flow.LF||
'                24,'||wwv_flow.LF||
'                ''An all-day event.'','||wwv_flow.LF||
'                ''Moe'','||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(25) := '          ''N'','||wwv_flow.LF||
'                ''Pasadena, CA'','||wwv_flow.LF||
'                null,'||wwv_flow.LF||
'                null,'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(26) := '       null'||wwv_flow.LF||
'            from dual'||wwv_flow.LF||
'            union all'||wwv_flow.LF||
'            select 3,'||wwv_flow.LF||
'                ''Weekl';
wwv_flow_imp.g_varchar2_table(27) := 'y Sales Update'','||wwv_flow.LF||
'                3,'||wwv_flow.LF||
'                trunc(current_timestamp+1,''HH''),'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(28) := ' 1,'||wwv_flow.LF||
'                ''Review pipeline and discuss wins/losses.'','||wwv_flow.LF||
'                ''Carolyn'','||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(29) := '       ''Y'','||wwv_flow.LF||
'                ''Denver, CO'','||wwv_flow.LF||
'                null,'||wwv_flow.LF||
'                null,'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(30) := '  1'||wwv_flow.LF||
'            from dual'||wwv_flow.LF||
'            union all'||wwv_flow.LF||
'            select 4,'||wwv_flow.LF||
'                ''Weekly Sales ';
wwv_flow_imp.g_varchar2_table(31) := 'Update'','||wwv_flow.LF||
'                3,'||wwv_flow.LF||
'                trunc(current_timestamp+8,''HH''),'||wwv_flow.LF||
'                1,'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(32) := '            ''Review pipeline and discuss wins/losses.'','||wwv_flow.LF||
'                ''Carolyn'','||wwv_flow.LF||
'                ''';
wwv_flow_imp.g_varchar2_table(33) := 'Y'','||wwv_flow.LF||
'                ''Denver, CO'','||wwv_flow.LF||
'                null,'||wwv_flow.LF||
'                null,'||wwv_flow.LF||
'                1'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(34) := '        from dual'||wwv_flow.LF||
'            union all'||wwv_flow.LF||
'            select 5,'||wwv_flow.LF||
'                ''Weekly Sales Update'',';
wwv_flow_imp.g_varchar2_table(35) := ''||wwv_flow.LF||
'                3,'||wwv_flow.LF||
'                trunc(current_timestamp+15,''HH''),'||wwv_flow.LF||
'                1,'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(36) := '     ''Review pipeline and discuss wins/losses.'','||wwv_flow.LF||
'                ''Carolyn'','||wwv_flow.LF||
'                ''Y'','||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(37) := '             ''Denver, CO'','||wwv_flow.LF||
'                null,'||wwv_flow.LF||
'                null,'||wwv_flow.LF||
'                1'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(38) := ' from dual'||wwv_flow.LF||
'            union all'||wwv_flow.LF||
'            select 6,'||wwv_flow.LF||
'                ''Weekly Sales Update'','||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(39) := '          3,'||wwv_flow.LF||
'                trunc(current_timestamp+22,''HH''),'||wwv_flow.LF||
'                1,'||wwv_flow.LF||
'                ''R';
wwv_flow_imp.g_varchar2_table(40) := 'eview pipeline and discuss wins/losses.'','||wwv_flow.LF||
'                ''Carolyn'','||wwv_flow.LF||
'                ''Y'','||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(41) := '      ''Denver, CO'','||wwv_flow.LF||
'                null,'||wwv_flow.LF||
'                null,'||wwv_flow.LF||
'                1'||wwv_flow.LF||
'            from d';
wwv_flow_imp.g_varchar2_table(42) := 'ual'||wwv_flow.LF||
'            union all'||wwv_flow.LF||
'            select 7,'||wwv_flow.LF||
'                ''Weekly Sales Update'','||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(43) := '   3,'||wwv_flow.LF||
'                trunc(current_timestamp+29,''HH''),'||wwv_flow.LF||
'                1,'||wwv_flow.LF||
'                ''Review p';
wwv_flow_imp.g_varchar2_table(44) := 'ipeline and discuss wins/losses.'','||wwv_flow.LF||
'                ''Carolyn'','||wwv_flow.LF||
'                ''Y'','||wwv_flow.LF||
'                ''';
wwv_flow_imp.g_varchar2_table(45) := 'Denver, CO'','||wwv_flow.LF||
'                null,'||wwv_flow.LF||
'                null,'||wwv_flow.LF||
'                1'||wwv_flow.LF||
'            from dual'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(46) := '         union all'||wwv_flow.LF||
'            select 8,'||wwv_flow.LF||
'                ''Weekly Sales Update'','||wwv_flow.LF||
'                3,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(47) := '               trunc(current_timestamp+36,''HH''),'||wwv_flow.LF||
'                1,'||wwv_flow.LF||
'                ''Review pipeline';
wwv_flow_imp.g_varchar2_table(48) := ' and discuss wins/losses.'','||wwv_flow.LF||
'                ''Carolyn'','||wwv_flow.LF||
'                ''Y'','||wwv_flow.LF||
'                ''Denver,';
wwv_flow_imp.g_varchar2_table(49) := ' CO'','||wwv_flow.LF||
'                null,'||wwv_flow.LF||
'                null,'||wwv_flow.LF||
'                1'||wwv_flow.LF||
'            from dual'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(50) := '  union all'||wwv_flow.LF||
'            select 9,'||wwv_flow.LF||
'                ''Weekly Sales Update'','||wwv_flow.LF||
'                3,'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(51) := '        trunc(current_timestamp+43,''HH''),'||wwv_flow.LF||
'                1,'||wwv_flow.LF||
'                ''Review pipeline and di';
wwv_flow_imp.g_varchar2_table(52) := 'scuss wins/losses.'','||wwv_flow.LF||
'                ''Carolyn'','||wwv_flow.LF||
'                ''Y'','||wwv_flow.LF||
'                ''Denver, CO'','||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(53) := '               null,'||wwv_flow.LF||
'                null,'||wwv_flow.LF||
'                1'||wwv_flow.LF||
'            from dual'||wwv_flow.LF||
'            union';
wwv_flow_imp.g_varchar2_table(54) := ' all'||wwv_flow.LF||
'            select 10,'||wwv_flow.LF||
'                ''Weekly Sales Update'','||wwv_flow.LF||
'                3,'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(55) := '  trunc(current_timestamp+50,''HH''),'||wwv_flow.LF||
'                1,'||wwv_flow.LF||
'                ''Review pipeline and discuss ';
wwv_flow_imp.g_varchar2_table(56) := 'wins/losses.'','||wwv_flow.LF||
'                ''Carolyn'','||wwv_flow.LF||
'                ''Y'','||wwv_flow.LF||
'                ''Denver, CO'','||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(57) := '         null,'||wwv_flow.LF||
'                null,'||wwv_flow.LF||
'                1'||wwv_flow.LF||
'            from dual'||wwv_flow.LF||
'            ) src'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(58) := '   on (dest.event_id = src.event_id)'||wwv_flow.LF||
'        when not matched then'||wwv_flow.LF||
'            insert (event_id, eve';
wwv_flow_imp.g_varchar2_table(59) := 'nt_name, type_id, event_date_time,'||wwv_flow.LF||
'                duration, event_desc, contact_person, display_tim';
wwv_flow_imp.g_varchar2_table(60) := 'e,'||wwv_flow.LF||
'                location, link_name_1, link_url_1, series_id )'||wwv_flow.LF||
'            values (src.event_id, ';
wwv_flow_imp.g_varchar2_table(61) := 'src.event_name, src.type_id, src.event_date_time,'||wwv_flow.LF||
'                src.duration, src.event_desc, src.';
wwv_flow_imp.g_varchar2_table(62) := 'contact_person, src.display_time,'||wwv_flow.LF||
'                src.location, src.link_name_1, src.link_url_1, src';
wwv_flow_imp.g_varchar2_table(63) := '.series_id );'||wwv_flow.LF||
'    end load;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure remove is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        delete from eba_ca_events whe';
wwv_flow_imp.g_varchar2_table(64) := 're event_id < 100;'||wwv_flow.LF||
'        delete from eba_ca_event_types where type_id < 100 and type_id not in (se';
wwv_flow_imp.g_varchar2_table(65) := 'lect distinct type_id from eba_ca_events);'||wwv_flow.LF||
'        delete from eba_ca_series where series_id < 100 a';
wwv_flow_imp.g_varchar2_table(66) := 'nd series_id not in (select distinct series_id from eba_ca_events);'||wwv_flow.LF||
'    end remove;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function is';
wwv_flow_imp.g_varchar2_table(67) := '_loaded return boolean is'||wwv_flow.LF||
'        l_cnt number := 0;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        select count(*) into l_cnt fr';
wwv_flow_imp.g_varchar2_table(68) := 'om eba_ca_events where event_id < 100;'||wwv_flow.LF||
'        if l_cnt > 0 then return true; end if;'||wwv_flow.LF||
'        select';
wwv_flow_imp.g_varchar2_table(69) := ' count(*) into l_cnt from eba_ca_event_types where type_id < 100 and type_id not in (select distinct';
wwv_flow_imp.g_varchar2_table(70) := ' type_id from eba_ca_events);'||wwv_flow.LF||
'        if l_cnt > 0 then return true; end if;'||wwv_flow.LF||
'        return false;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(71) := '   end is_loaded;'||wwv_flow.LF||
'end eba_ca_sample_data;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3263640764982249063)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'Sample Data'
,p_sequence=>660
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(1682435125811625999)
,p_script_id=>wwv_flow_imp.id(3263640764982249063)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_CA_SAMPLE_DATA'
);
wwv_flow_imp.component_end;
end;
/
