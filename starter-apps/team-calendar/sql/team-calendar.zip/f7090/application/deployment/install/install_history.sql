prompt --application/deployment/install/install_history
begin
--   Manifest
--     INSTALL: INSTALL-history
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE eba_ca_history '||wwv_flow.LF||
'   (   '||wwv_flow.LF||
'    ID                  NUMBER constraint eba_ca_history_pk pri';
wwv_flow_imp.g_varchar2_table(2) := 'mary key, '||wwv_flow.LF||
'    ROW_VERSION_NUMBER  NUMBER, '||wwv_flow.LF||
'    COMPONENT_ID        NUMBER, '||wwv_flow.LF||
'    COMPONENT_ROWKEY   ';
wwv_flow_imp.g_varchar2_table(3) := ' VARCHAR2(30 BYTE),'||wwv_flow.LF||
'    TABLE_NAME          VARCHAR2(60 BYTE) not null,'||wwv_flow.LF||
'    COLUMN_NAME         VARC';
wwv_flow_imp.g_varchar2_table(4) := 'HAR2(60 BYTE) not null, '||wwv_flow.LF||
'    OLD_VALUE           VARCHAR2(4000 BYTE), '||wwv_flow.LF||
'    NEW_VALUE           VARCH';
wwv_flow_imp.g_varchar2_table(5) := 'AR2(4000 BYTE), '||wwv_flow.LF||
'    CHANGE_DATE         TIMESTAMP WITH TIME ZONE, '||wwv_flow.LF||
'    CHANGED_BY          VARCHAR2';
wwv_flow_imp.g_varchar2_table(6) := '(255 BYTE)'||wwv_flow.LF||
'   )  ;'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_ca_history_i1 on eba_ca_history(component_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLA';
wwv_flow_imp.g_varchar2_table(7) := 'CE TRIGGER biu_eba_ca_history '||wwv_flow.LF||
'   before insert or update on eba_ca_history'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(8) := ' if :new.ID is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :';
wwv_flow_imp.g_varchar2_table(9) := 'new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.change_date := current_timestamp;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(10) := '   :new.changed_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updat';
wwv_flow_imp.g_varchar2_table(11) := 'ing then'||wwv_flow.LF||
'       :new.row_version_number := :new.row_version_number + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'ALTER TRIG';
wwv_flow_imp.g_varchar2_table(12) := 'GER biu_eba_ca_history ENABLE;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3256238759065944833)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'history'
,p_sequence=>203
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
