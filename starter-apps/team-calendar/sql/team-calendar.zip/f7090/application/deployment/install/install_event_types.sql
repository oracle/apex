prompt --application/deployment/install/install_event_types
begin
--   Manifest
--     INSTALL: INSTALL-event types
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_ca_event_types ('||wwv_flow.LF||
'   type_id          number         not null,'||wwv_flow.LF||
'   type_name        v';
wwv_flow_imp.g_varchar2_table(2) := 'archar2(60)   not null,'||wwv_flow.LF||
'   display_color    varchar2(60),'||wwv_flow.LF||
'   border_color     varchar2(30),'||wwv_flow.LF||
'   text_';
wwv_flow_imp.g_varchar2_table(3) := 'color       varchar2(30),'||wwv_flow.LF||
'   internal_yn      varchar2(1),'||wwv_flow.LF||
'   is_active_yn     varchar2(1),'||wwv_flow.LF||
'   color';
wwv_flow_imp.g_varchar2_table(4) := '_pref_id    number'||wwv_flow.LF||
'                    constraint eba_ca_et_cp_ck'||wwv_flow.LF||
'                    references eba';
wwv_flow_imp.g_varchar2_table(5) := '_ca_color_prefs (id),'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   created_on       timestamp with time zone  not null,'||wwv_flow.LF||
'   created_by   ';
wwv_flow_imp.g_varchar2_table(6) := '    varchar2(255)  not null,'||wwv_flow.LF||
'   last_updated_on  timestamp with time zone,'||wwv_flow.LF||
'   last_updated_by  varch';
wwv_flow_imp.g_varchar2_table(7) := 'ar2(255) )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'-- Add index on foreign key columns'||wwv_flow.LF||
'create index eba_ca_event_types_cp_idx on eba_ca_e';
wwv_flow_imp.g_varchar2_table(8) := 'vent_types(color_pref_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_ca_event_types'||wwv_flow.LF||
'   add constraint eba_ca_event_types_pk p';
wwv_flow_imp.g_varchar2_table(9) := 'rimary key (type_id)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'alter table eba_ca_event_types'||wwv_flow.LF||
'   add constraint eba_ca_event_types_uk u';
wwv_flow_imp.g_varchar2_table(10) := 'nique (type_name)'||wwv_flow.LF||
'/'||wwv_flow.LF||
'    '||wwv_flow.LF||
'    '||wwv_flow.LF||
'create or replace trigger eba_ca_event_types_biu'||wwv_flow.LF||
'  before insert or up';
wwv_flow_imp.g_varchar2_table(11) := 'date on eba_ca_event_types               '||wwv_flow.LF||
'  for each row  '||wwv_flow.LF||
'begin   '||wwv_flow.LF||
'  if inserting then'||wwv_flow.LF||
'     if :NEW';
wwv_flow_imp.g_varchar2_table(12) := '.type_id is null '||wwv_flow.LF||
'        then :NEW.type_id := eba_ca_api.gen_id; '||wwv_flow.LF||
'     end if;'||wwv_flow.LF||
'     :NEW.CREATED_ON';
wwv_flow_imp.g_varchar2_table(13) := ' := CURRENT_TIMESTAMP;'||wwv_flow.LF||
'     :NEW.CREATED_BY := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'   if updating t';
wwv_flow_imp.g_varchar2_table(14) := 'hen'||wwv_flow.LF||
'      :NEW.LAST_UPDATED_ON := CURRENT_TIMESTAMP;'||wwv_flow.LF||
'      :NEW.LAST_UPDATED_BY := nvl(v(''APP_USER'')';
wwv_flow_imp.g_varchar2_table(15) := ',USER);'||wwv_flow.LF||
'   end if; '||wwv_flow.LF||
'   if :new.is_active_yn is null then'||wwv_flow.LF||
'       if :new.type_name is null then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(16) := '     :new.is_active_yn := ''N'';'||wwv_flow.LF||
'       else'||wwv_flow.LF||
'          :new.is_active_yn := ''Y'';'||wwv_flow.LF||
'       end if;'||wwv_flow.LF||
'   end';
wwv_flow_imp.g_varchar2_table(17) := ' if;'||wwv_flow.LF||
'end; '||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
'    '||wwv_flow.LF||
' '||wwv_flow.LF||
'alter trigger eba_ca_event_types_biu enable'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'commit;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(7407365910380559032)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'event types'
,p_sequence=>200
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
