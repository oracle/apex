prompt --application/deployment/install/install_install_the_acl_seed_data
begin
--   Manifest
--     INSTALL: INSTALL-install the acl seed data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '/* Bug tracker access levels */'||wwv_flow.LF||
'insert into eba_ca_access_levels (id, access_level) values (1, ''Read';
wwv_flow_imp.g_varchar2_table(2) := 'er'');'||wwv_flow.LF||
'insert into eba_ca_access_levels (id, access_level) values (2, ''Contributor'');'||wwv_flow.LF||
'insert into eba';
wwv_flow_imp.g_varchar2_table(3) := '_ca_access_levels (id, access_level) values (3, ''Administrator'');'||wwv_flow.LF||
''||wwv_flow.LF||
'/* Bug Tracker preferences */'||wwv_flow.LF||
'ins';
wwv_flow_imp.g_varchar2_table(4) := 'ert into eba_ca_preferences (id, preference_name, preference_value) values (1, ''ACCESS_CONTROL_ENABL';
wwv_flow_imp.g_varchar2_table(5) := 'ED'', ''N'');'||wwv_flow.LF||
'insert into eba_ca_preferences (id, preference_name, preference_value) values (2, ''ACCESS';
wwv_flow_imp.g_varchar2_table(6) := '_CONTROL_SCOPE'', ''ACL_ONLY'');'||wwv_flow.LF||
'insert into eba_ca_preferences (id, preference_name, preference_value)';
wwv_flow_imp.g_varchar2_table(7) := ' values (3, ''USERNAME_FORMAT'', ''EMAIL'');'||wwv_flow.LF||
''||wwv_flow.LF||
'/* Constraint error lookups */'||wwv_flow.LF||
'insert into eba_ca_error_lo';
wwv_flow_imp.g_varchar2_table(8) := 'okup (constraint_name, message, language_code) values (''EBA_CA_USERS_UK'', ''Username must be unique.''';
wwv_flow_imp.g_varchar2_table(9) := ', ''en'');'||wwv_flow.LF||
'insert into eba_ca_error_lookup (constraint_name, message, language_code) values (''EBA_CA_C';
wwv_flow_imp.g_varchar2_table(10) := 'ALENDAR_UK1'', ''Calendar Short Name must be unique.'', ''en'');'||wwv_flow.LF||
'insert into eba_ca_error_lookup (constra';
wwv_flow_imp.g_varchar2_table(11) := 'int_name, message, language_code) values (''EBA_CA_CALENDAR_UK2'', ''Calendar Name must be unique.'', ''e';
wwv_flow_imp.g_varchar2_table(12) := 'n'');'||wwv_flow.LF||
''||wwv_flow.LF||
'commit;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3254484979694072285)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'install the acl seed data'
,p_sequence=>630
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
