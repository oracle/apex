prompt --application/deployment/install/install_event_notes
begin
--   Manifest
--     INSTALL: INSTALL-event notes
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE EBA_CA_NOTES '||wwv_flow.LF||
'   ( '||wwv_flow.LF||
'    ID                     NUMBER constraint EBA_CA_notes_pk primar';
wwv_flow_imp.g_varchar2_table(2) := 'y key, '||wwv_flow.LF||
'    ROW_VERSION_NUMBER     NUMBER not null, '||wwv_flow.LF||
'    EVENT_ID               NUMBER constraint eb';
wwv_flow_imp.g_varchar2_table(3) := 'a_ca_notes_fk'||wwv_flow.LF||
'                           references eba_ca_events (event_id)'||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(4) := '    on delete cascade, '||wwv_flow.LF||
'    NOTE                   CLOB, '||wwv_flow.LF||
'    tags                     VARCHAR2(4000';
wwv_flow_imp.g_varchar2_table(5) := ' BYTE), '||wwv_flow.LF||
'    CREATED                timestamp with time zone, '||wwv_flow.LF||
'    CREATED_BY             VARCHAR2(2';
wwv_flow_imp.g_varchar2_table(6) := '55 BYTE), '||wwv_flow.LF||
'    UPDATED                timestamp with time zone, '||wwv_flow.LF||
'    UPDATED_BY             VARCHAR2';
wwv_flow_imp.g_varchar2_table(7) := '(255 BYTE)'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'create index EBA_CA_NOTES_i1 on EBA_CA_NOTES(event_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGE';
wwv_flow_imp.g_varchar2_table(8) := 'R BIU_EBA_CA_NOTES '||wwv_flow.LF||
'   before insert or update on EBA_CA_NOTES'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID i';
wwv_flow_imp.g_varchar2_table(9) := 's null then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from d';
wwv_flow_imp.g_varchar2_table(10) := 'ual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := current_timestamp;'||wwv_flow.LF||
'       :new.created_b';
wwv_flow_imp.g_varchar2_table(11) := 'y := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := ';
wwv_flow_imp.g_varchar2_table(12) := 'nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.r';
wwv_flow_imp.g_varchar2_table(13) := 'ow_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inserting or updating then';
wwv_flow_imp.g_varchar2_table(14) := ''||wwv_flow.LF||
'       :new.updated := current_timestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow.g_user,user);'||wwv_flow.LF||
'   e';
wwv_flow_imp.g_varchar2_table(15) := 'nd if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'ALTER TRIGGER BIU_EBA_CA_NOTES ENABLE;';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3256239174218968160)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'event notes'
,p_sequence=>211
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
