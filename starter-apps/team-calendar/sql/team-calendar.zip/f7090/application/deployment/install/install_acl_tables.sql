prompt --application/deployment/install/install_acl_tables
begin
--   Manifest
--     INSTALL: INSTALL-acl tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_ca_access_levels ('||wwv_flow.LF||
'    id                      number              not null'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(2) := '                                         constraint eba_ca_access_levels_pk'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(3) := '                        primary key,'||wwv_flow.LF||
'    access_level            varchar2(30)        not null'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(4) := '                                          constraint eba_ca_acc_lvl_acc_lvl_ck'||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(5) := '                           check (access_level in ('||wwv_flow.LF||
'                                                ';
wwv_flow_imp.g_varchar2_table(6) := '    ''Administrator'','||wwv_flow.LF||
'                                                    ''Contributor'','||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(7) := '                                        ''Reader'' )),'||wwv_flow.LF||
'    row_version             number )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create u';
wwv_flow_imp.g_varchar2_table(8) := 'nique index eba_ca_access_levels_uk on eba_ca_access_levels(access_level);'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_ca_user';
wwv_flow_imp.g_varchar2_table(9) := 's ('||wwv_flow.LF||
'    id                      number              not null'||wwv_flow.LF||
'                                       ';
wwv_flow_imp.g_varchar2_table(10) := '         constraint eba_ca_users_pk'||wwv_flow.LF||
'                                                primary key,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(11) := ' username                varchar2(255)       not null'||wwv_flow.LF||
'                                              ';
wwv_flow_imp.g_varchar2_table(12) := '  constraint eba_ca_users_username_ck'||wwv_flow.LF||
'                                                check (upper(u';
wwv_flow_imp.g_varchar2_table(13) := 'sername)=username),'||wwv_flow.LF||
'    access_level_id         number              not null'||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(14) := '                         constraint eba_ca_users_acc_level_fk'||wwv_flow.LF||
'                                      ';
wwv_flow_imp.g_varchar2_table(15) := '          references eba_ca_access_levels,'||wwv_flow.LF||
'    account_locked          varchar2(1)         not null'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(16) := '                                                constraint eba_ca_users_acc_locked_ck'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(17) := '                                  check (account_locked in (''Y'',''N'')),'||wwv_flow.LF||
'    restricted_to           v';
wwv_flow_imp.g_varchar2_table(18) := 'archar2(4000), -- comma separated list of calendar_ids, for contributor (access_level_id 2)'||wwv_flow.LF||
'    row_';
wwv_flow_imp.g_varchar2_table(19) := 'version             number,'||wwv_flow.LF||
'    created_by              varchar2(255)       not null,'||wwv_flow.LF||
'    created   ';
wwv_flow_imp.g_varchar2_table(20) := '              timestamp with time zone,'||wwv_flow.LF||
'    updated_by              varchar2(255),'||wwv_flow.LF||
'    updated      ';
wwv_flow_imp.g_varchar2_table(21) := '           timestamp with time zone )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_ca_users_uk on eba_ca_users (usernam';
wwv_flow_imp.g_varchar2_table(22) := 'e);'||wwv_flow.LF||
'create index eba_ca_users_acc_lvl_idx on eba_ca_users (access_level_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trig';
wwv_flow_imp.g_varchar2_table(23) := 'ger eba_ca_users_biu'||wwv_flow.LF||
'    before insert or update on eba_ca_users'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inser';
wwv_flow_imp.g_varchar2_table(24) := 'ting then'||wwv_flow.LF||
'        if :new.id is null then'||wwv_flow.LF||
'            :new.id := eba_ca.gen_id();'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(25) := '      :new.created_by         := nvl(v(''APP_USER''), USER);'||wwv_flow.LF||
'        :new.created            := curren';
wwv_flow_imp.g_varchar2_table(26) := 't_timestamp;'||wwv_flow.LF||
'        :new.row_version        := 1;'||wwv_flow.LF||
'        if :new.account_locked is null then'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(27) := '       :new.account_locked := ''N'';    '||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(28) := ':new.updated_by         := nvl(v(''APP_USER''), USER);'||wwv_flow.LF||
'            :new.updated            := current_';
wwv_flow_imp.g_varchar2_table(29) := 'timestamp;'||wwv_flow.LF||
'            :new.row_version        := nvl(:old.row_version,1) + 1;                      ';
wwv_flow_imp.g_varchar2_table(30) := '          '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- Always store username as upper case'||wwv_flow.LF||
'    :new.username := upper(:new.us';
wwv_flow_imp.g_varchar2_table(31) := 'ername);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_ca_users_biu enable;'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_ca_users_bd'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(32) := '  before delete on eba_ca_users'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'declare'||wwv_flow.LF||
'    pragma autonomous_transaction;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(33) := '  -- Disallow deletes to a user''s own record unless last one.'||wwv_flow.LF||
'    if v(''APP_USER'') = upper(:old.user';
wwv_flow_imp.g_varchar2_table(34) := 'name) then'||wwv_flow.LF||
'       for c1 in ('||wwv_flow.LF||
'          select count(*) cnt'||wwv_flow.LF||
'            from eba_ca_users'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(35) := ' where id != :old.id )'||wwv_flow.LF||
'       loop'||wwv_flow.LF||
'          if c1.cnt > 0 then'||wwv_flow.LF||
'             raise_application_error';
wwv_flow_imp.g_varchar2_table(36) := '(-20002, ''Delete disallowed, you cannot delete your own access control details.'');'||wwv_flow.LF||
'          end if;';
wwv_flow_imp.g_varchar2_table(37) := ''||wwv_flow.LF||
'       end loop;'||wwv_flow.LF||
'    end if;    '||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alter trigger eba_ca_users_bd enable;'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_ca_';
wwv_flow_imp.g_varchar2_table(38) := 'error_lookup ('||wwv_flow.LF||
'    constraint_name         varchar2(30)        not null'||wwv_flow.LF||
'                            ';
wwv_flow_imp.g_varchar2_table(39) := '                    constraint eba_ca_error_lookup_pk'||wwv_flow.LF||
'                                              ';
wwv_flow_imp.g_varchar2_table(40) := '  primary key,'||wwv_flow.LF||
'    message                 varchar2(4000)      not null,'||wwv_flow.LF||
'    language_code          ';
wwv_flow_imp.g_varchar2_table(41) := ' varchar2(30)        not null'||wwv_flow.LF||
')'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_ca_error_lookup_uk on eba_ca_error_lookup ';
wwv_flow_imp.g_varchar2_table(42) := '(constraint_name,language_code);'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create table eba_ca_preferences ('||wwv_flow.LF||
'    id                      num';
wwv_flow_imp.g_varchar2_table(43) := 'ber              not null'||wwv_flow.LF||
'                                                constraint eba_ca_preferen';
wwv_flow_imp.g_varchar2_table(44) := 'ces_pk'||wwv_flow.LF||
'                                                primary key,'||wwv_flow.LF||
'    preference_name         varc';
wwv_flow_imp.g_varchar2_table(45) := 'har2(255)       not null'||wwv_flow.LF||
'                                                constraint eba_ca_prefs_pre';
wwv_flow_imp.g_varchar2_table(46) := 'fname_ck'||wwv_flow.LF||
'                                                check (upper(preference_name)=preference_na';
wwv_flow_imp.g_varchar2_table(47) := 'me),'||wwv_flow.LF||
'    preference_value        varchar2(255)       not null,'||wwv_flow.LF||
'    created_by              varchar2(';
wwv_flow_imp.g_varchar2_table(48) := '255)       not null,'||wwv_flow.LF||
'    created_on              timestamp with time zone,'||wwv_flow.LF||
'    updated_by           ';
wwv_flow_imp.g_varchar2_table(49) := '   varchar2(255),'||wwv_flow.LF||
'    updated_on              timestamp with time zone )'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create unique index eba_c';
wwv_flow_imp.g_varchar2_table(50) := 'a_preferences_uk on eba_ca_preferences (preference_name);'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_ca_prefer';
wwv_flow_imp.g_varchar2_table(51) := 'ences_biu'||wwv_flow.LF||
'before insert or update on eba_ca_preferences'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and ';
wwv_flow_imp.g_varchar2_table(52) := ':new.id is null then'||wwv_flow.LF||
'        :new.id := eba_ca.gen_id();'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :';
wwv_flow_imp.g_varchar2_table(53) := 'new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created_on := current_timestamp;'||wwv_flow.LF||
'    end if;';
wwv_flow_imp.g_varchar2_table(54) := ''||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated_on :=';
wwv_flow_imp.g_varchar2_table(55) := ' current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.preference_name := upper(:new.preference_name);'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'alte';
wwv_flow_imp.g_varchar2_table(56) := 'r trigger eba_ca_preferences_biu enable;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3254481078645996199)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'acl tables'
,p_sequence=>370
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
