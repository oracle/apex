prompt --application/deployment/install/install_color_prefs
begin
--   Manifest
--     INSTALL: INSTALL-color prefs
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_ca_color_prefs ('||wwv_flow.LF||
'    id                        number            not null'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(2) := '                                       constraint eba_ca_colorpref_pk'||wwv_flow.LF||
'                              ';
wwv_flow_imp.g_varchar2_table(3) := '                  primary key,'||wwv_flow.LF||
'    row_version_number        number,'||wwv_flow.LF||
'    color_name                v';
wwv_flow_imp.g_varchar2_table(4) := 'archar2(255)     not null,'||wwv_flow.LF||
'    bg_color                  varchar2(255),'||wwv_flow.LF||
'    text_color              ';
wwv_flow_imp.g_varchar2_table(5) := '  varchar2(255),'||wwv_flow.LF||
'    attr_01                   varchar2(255),'||wwv_flow.LF||
'    attr_02                   varchar2';
wwv_flow_imp.g_varchar2_table(6) := '(255),    '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    display_sequence          number,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    created_by                varchar';
wwv_flow_imp.g_varchar2_table(7) := '2(255)       not null,'||wwv_flow.LF||
'    created                   timestamp with time zone,'||wwv_flow.LF||
'    updated_by       ';
wwv_flow_imp.g_varchar2_table(8) := '         varchar2(255)       not null,'||wwv_flow.LF||
'    updated                   timestamp with time zone )'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'a';
wwv_flow_imp.g_varchar2_table(9) := 'lter table eba_ca_color_prefs add constraint'||wwv_flow.LF||
'   eba_ca_color_prefs_uk unique (COLOR_NAME)'||wwv_flow.LF||
'/ '||wwv_flow.LF||
''||wwv_flow.LF||
'create';
wwv_flow_imp.g_varchar2_table(10) := ' or replace trigger biu_eba_ca_color_prefs'||wwv_flow.LF||
'before insert or update on eba_ca_color_prefs'||wwv_flow.LF||
'    for eac';
wwv_flow_imp.g_varchar2_table(11) := 'h row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting and :new.id is null then'||wwv_flow.LF||
'        select to_number(sys_guid(),''XXXXXXXXX';
wwv_flow_imp.g_varchar2_table(12) := 'XXXXXXXXXXXXXXXXXXXXXXX'')'||wwv_flow.LF||
'        into :new.id'||wwv_flow.LF||
'        from dual;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(13) := '        :new.created_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.created := current_timestamp;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(14) := '   :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.updated := current_timestamp;'||wwv_flow.LF||
'        :n';
wwv_flow_imp.g_varchar2_table(15) := 'ew.row_version_number := 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if updating then'||wwv_flow.LF||
'        :new.row_version_number := nvl(';
wwv_flow_imp.g_varchar2_table(16) := ':old.row_version_number,1) + 1;'||wwv_flow.LF||
'        :new.updated_by := nvl(v(''APP_USER''),USER);'||wwv_flow.LF||
'        :new.upd';
wwv_flow_imp.g_varchar2_table(17) := 'ated    := current_timestamp;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if :new.display_sequence is null then'||wwv_flow.LF||
'       :new.disp';
wwv_flow_imp.g_varchar2_table(18) := 'lay_sequence := 10;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'alter trigger biu_eba_ca_color_prefs enable;'||wwv_flow.LF||
'/'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(19) := '   '||wwv_flow.LF||
'insert into eba_ca_color_prefs (id, color_name, bg_color, text_color) values (1,''Red'',  ''#FF0000';
wwv_flow_imp.g_varchar2_table(20) := ''', ''#FF0000'');'||wwv_flow.LF||
'insert into eba_ca_color_prefs (id, color_name, bg_color, text_color) values (2,''Gree';
wwv_flow_imp.g_varchar2_table(21) := 'n'',  ''#00FF00'', ''#00FF00'');'||wwv_flow.LF||
'insert into eba_ca_color_prefs (id, color_name, bg_color, text_color) va';
wwv_flow_imp.g_varchar2_table(22) := 'lues (3,''Orange'',  ''#FF9900'', ''#FF9900'');'||wwv_flow.LF||
'insert into eba_ca_color_prefs (id, color_name, bg_color, ';
wwv_flow_imp.g_varchar2_table(23) := 'text_color) values (4,''Gray'',  ''#CCCCCC'', ''#CCCCCC'');'||wwv_flow.LF||
'insert into eba_ca_color_prefs (id, color_name';
wwv_flow_imp.g_varchar2_table(24) := ', bg_color, text_color) values (5,''Blue'',  ''#0066FF'', ''#0066FF'');'||wwv_flow.LF||
''||wwv_flow.LF||
'insert into eba_ca_color_prefs (i';
wwv_flow_imp.g_varchar2_table(25) := 'd, color_name, bg_color, text_color) values (6,''Black'',  ''#303030'', ''#303030'');'||wwv_flow.LF||
'insert into eba_ca_c';
wwv_flow_imp.g_varchar2_table(26) := 'olor_prefs (id, color_name, bg_color, text_color) values (7,''Darkblue'',  ''#1F5F97'', ''#1F5F97'');'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(27) := 'rt into eba_ca_color_prefs (id, color_name, bg_color, text_color) values (8,''Bluesky'',  ''#6BB9F0'', ''';
wwv_flow_imp.g_varchar2_table(28) := '#6BB9F0'');'||wwv_flow.LF||
'insert into eba_ca_color_prefs (id, color_name, bg_color, text_color) values (9,''Brown'', ';
wwv_flow_imp.g_varchar2_table(29) := ' ''#D88935'', ''#D88935'');'||wwv_flow.LF||
'insert into eba_ca_color_prefs (id, color_name, bg_color, text_color) values';
wwv_flow_imp.g_varchar2_table(30) := ' (10,''Cyan'',  ''#1ABC9C'', ''#1ABC9C'');'||wwv_flow.LF||
'insert into eba_ca_color_prefs (id, color_name, bg_color, text_';
wwv_flow_imp.g_varchar2_table(31) := 'color) values (11,''Lime'',  ''#28A346'', ''#28A346'');'||wwv_flow.LF||
'insert into eba_ca_color_prefs (id, color_name, bg';
wwv_flow_imp.g_varchar2_table(32) := '_color, text_color) values (12,''Silver'',  ''#BDC3C7'', ''#BDC3C7'');'||wwv_flow.LF||
'insert into eba_ca_color_prefs (id,';
wwv_flow_imp.g_varchar2_table(33) := ' color_name, bg_color, text_color) values (13,''Yellow'',  ''#F1C40F'', ''#F1C40F'');'||wwv_flow.LF||
'commit;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3257437276420578689)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'color prefs'
,p_sequence=>190
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
