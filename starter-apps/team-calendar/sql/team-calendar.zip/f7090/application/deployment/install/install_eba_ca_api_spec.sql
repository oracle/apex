prompt --application/deployment/install/install_eba_ca_api_spec
begin
--   Manifest
--     INSTALL: INSTALL-eba_ca_api  spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_ca_api '||wwv_flow.LF||
'as '||wwv_flow.LF||
'function gen_id '||wwv_flow.LF||
'   return  number; '||wwv_flow.LF||
'function create_event';
wwv_flow_imp.g_varchar2_table(2) := '_type ( '||wwv_flow.LF||
'   p_event_type    varchar2, '||wwv_flow.LF||
'   p_color_pref_id number,'||wwv_flow.LF||
'   p_internal_yn   varchar2'||wwv_flow.LF||
'  ) '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(3) := '  return number; '||wwv_flow.LF||
'procedure create_event ( '||wwv_flow.LF||
'   p_event_name       varchar2, '||wwv_flow.LF||
'   p_type_id          n';
wwv_flow_imp.g_varchar2_table(4) := 'umber, '||wwv_flow.LF||
'   p_calendar_id      number, '||wwv_flow.LF||
'   p_new_event_type   varchar2, '||wwv_flow.LF||
'   p_new_color_pref_id numbe';
wwv_flow_imp.g_varchar2_table(5) := 'r,'||wwv_flow.LF||
'   p_new_internal_yn   varchar2,'||wwv_flow.LF||
'   p_event_date_time  timestamp with time zone, '||wwv_flow.LF||
'   p_duration  ';
wwv_flow_imp.g_varchar2_table(6) := '       number, '||wwv_flow.LF||
'   p_event_desc       varchar2, '||wwv_flow.LF||
'   p_contact_person   varchar2, '||wwv_flow.LF||
'   p_contact_email';
wwv_flow_imp.g_varchar2_table(7) := '    varchar2, '||wwv_flow.LF||
'   p_display_time     varchar2, '||wwv_flow.LF||
'   p_location         varchar2, '||wwv_flow.LF||
'   p_link_name_1   ';
wwv_flow_imp.g_varchar2_table(8) := '   varchar2, '||wwv_flow.LF||
'   p_link_url_1       varchar2, '||wwv_flow.LF||
'   p_link_name_2      varchar2, '||wwv_flow.LF||
'   p_link_url_2     ';
wwv_flow_imp.g_varchar2_table(9) := '  varchar2, '||wwv_flow.LF||
'   p_link_name_3      varchar2, '||wwv_flow.LF||
'   p_link_url_3       varchar2, '||wwv_flow.LF||
'   p_tags            ';
wwv_flow_imp.g_varchar2_table(10) := ' varchar2 default null, '||wwv_flow.LF||
'   -- '||wwv_flow.LF||
'   p_recur_flag       varchar2, '||wwv_flow.LF||
'   p_recur_freq       varchar2, '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(11) := ' p_recur_end_date   timestamp with time zone ); '||wwv_flow.LF||
'procedure delete_event ( '||wwv_flow.LF||
'   p_event_id         num';
wwv_flow_imp.g_varchar2_table(12) := 'ber, '||wwv_flow.LF||
'   -- '||wwv_flow.LF||
'   p_delete_request   varchar2  default null ); '||wwv_flow.LF||
'procedure update_event ( '||wwv_flow.LF||
'   p_event_i';
wwv_flow_imp.g_varchar2_table(13) := 'd         number, '||wwv_flow.LF||
'   p_event_name       varchar2, '||wwv_flow.LF||
'   p_type_id          number, '||wwv_flow.LF||
'   p_calendar_id ';
wwv_flow_imp.g_varchar2_table(14) := '     number, '||wwv_flow.LF||
'   p_new_event_type   varchar2, '||wwv_flow.LF||
'   p_new_color_pref_id number,'||wwv_flow.LF||
'   p_new_internal_yn  ';
wwv_flow_imp.g_varchar2_table(15) := ' varchar2,'||wwv_flow.LF||
'   p_event_date_time  timestamp with time zone, '||wwv_flow.LF||
'   p_duration         number, '||wwv_flow.LF||
'   p_even';
wwv_flow_imp.g_varchar2_table(16) := 't_desc       varchar2, '||wwv_flow.LF||
'   p_contact_person   varchar2, '||wwv_flow.LF||
'   p_contact_email    varchar2, '||wwv_flow.LF||
'   p_displ';
wwv_flow_imp.g_varchar2_table(17) := 'ay_time     varchar2, '||wwv_flow.LF||
'   p_location         varchar2, '||wwv_flow.LF||
'   p_link_name_1      varchar2, '||wwv_flow.LF||
'   p_link_u';
wwv_flow_imp.g_varchar2_table(18) := 'rl_1       varchar2, '||wwv_flow.LF||
'   p_link_name_2      varchar2, '||wwv_flow.LF||
'   p_link_url_2       varchar2, '||wwv_flow.LF||
'   p_link_na';
wwv_flow_imp.g_varchar2_table(19) := 'me_3      varchar2, '||wwv_flow.LF||
'   p_link_url_3       varchar2, '||wwv_flow.LF||
'   -- '||wwv_flow.LF||
'   p_recur_flag       varchar2, '||wwv_flow.LF||
'   p_r';
wwv_flow_imp.g_varchar2_table(20) := 'ecur_freq       varchar2, '||wwv_flow.LF||
'   p_recur_end_date   timestamp with time zone, '||wwv_flow.LF||
'   -- '||wwv_flow.LF||
'   p_update_reque';
wwv_flow_imp.g_varchar2_table(21) := 'st   varchar2  default null, '||wwv_flow.LF||
'   p_tags             varchar2  default null ); '||wwv_flow.LF||
'procedure create_mbrs';
wwv_flow_imp.g_varchar2_table(22) := '_collection ( '||wwv_flow.LF||
'    p_users     in varchar2, '||wwv_flow.LF||
'    p_group_id  in number ); '||wwv_flow.LF||
'procedure create_mbrs_fro';
wwv_flow_imp.g_varchar2_table(23) := 'm_collection ( '||wwv_flow.LF||
'    p_group_id  in number ); '||wwv_flow.LF||
'function get_timeframes ( '||wwv_flow.LF||
'   p_event_id  in  number )';
wwv_flow_imp.g_varchar2_table(24) := ' '||wwv_flow.LF||
'   return varchar2; '||wwv_flow.LF||
'end eba_ca_api; '||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(7407362518790555192)
,p_install_id=>wwv_flow_imp.id(7407360007655550898)
,p_name=>'eba_ca_api  spec'
,p_sequence=>100
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(1682422156265625277)
,p_script_id=>wwv_flow_imp.id(7407362518790555192)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_CA_API'
);
wwv_flow_imp.component_end;
end;
/
