prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7090
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7090
,p_default_id_offset=>1550216302176697
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'drop table eba_ca_event_types      cascade constraints;'||wwv_flow.LF||
'drop table eba_ca_series           cascade c';
wwv_flow_imp.g_varchar2_table(2) := 'onstraints;'||wwv_flow.LF||
'drop table eba_ca_events           cascade constraints;'||wwv_flow.LF||
'drop table eba_ca_email_groups  ';
wwv_flow_imp.g_varchar2_table(3) := '   cascade constraints;'||wwv_flow.LF||
'drop table eba_ca_email_group_mbrs cascade constraints;'||wwv_flow.LF||
'drop table eba_ca_ti';
wwv_flow_imp.g_varchar2_table(4) := 'meframes       cascade constraints;'||wwv_flow.LF||
'drop table eba_ca_admins           cascade constraints;'||wwv_flow.LF||
'drop tab';
wwv_flow_imp.g_varchar2_table(5) := 'le eba_ca_access_levels    cascade constraints purge;'||wwv_flow.LF||
'drop table eba_ca_error_lookup     cascade con';
wwv_flow_imp.g_varchar2_table(6) := 'straints purge;'||wwv_flow.LF||
'drop table eba_ca_preferences      cascade constraints;'||wwv_flow.LF||
'drop table eba_ca_users     ';
wwv_flow_imp.g_varchar2_table(7) := '       cascade constraints purge;'||wwv_flow.LF||
'drop table eba_ca_notifications    cascade constraints purge;'||wwv_flow.LF||
'drop';
wwv_flow_imp.g_varchar2_table(8) := ' table eba_ca_tz_pref          cascade constraints purge;'||wwv_flow.LF||
'drop table eba_ca_HISTORY          cascade';
wwv_flow_imp.g_varchar2_table(9) := ' constraints purge;'||wwv_flow.LF||
'drop table eba_ca_tags             cascade constraints;'||wwv_flow.LF||
'drop table eba_ca_tags_t';
wwv_flow_imp.g_varchar2_table(10) := 'ype_sum    cascade constraints;'||wwv_flow.LF||
'drop table eba_ca_tags_sum         cascade constraints;'||wwv_flow.LF||
'drop table e';
wwv_flow_imp.g_varchar2_table(11) := 'ba_ca_FILES            cascade constraints;'||wwv_flow.LF||
'drop table eba_ca_NOTES            cascade constraints;'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(12) := 'drop table eba_ca_color_prefs      cascade constraints;'||wwv_flow.LF||
'drop table eba_ca_errors           cascade c';
wwv_flow_imp.g_varchar2_table(13) := 'onstraints;'||wwv_flow.LF||
'drop table eba_ca_calendars        cascade constraints;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop package eba_ca_api;'||wwv_flow.LF||
'drop p';
wwv_flow_imp.g_varchar2_table(14) := 'ackage eba_ca;'||wwv_flow.LF||
'drop package eba_ca_fw;'||wwv_flow.LF||
'drop package eba_ca_sample_data;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop sequence eba_ca_seq;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(15) := 'begin'||wwv_flow.LF||
'    wwv_flow_api.create_or_remove_file( '||wwv_flow.LF||
'        p_location => ''APPLICATION'','||wwv_flow.LF||
'        p_name  ';
wwv_flow_imp.g_varchar2_table(16) := '   => ''group-cal-logo2.png'','||wwv_flow.LF||
'        p_mode     => ''REMOVE'','||wwv_flow.LF||
'        p_type     => ''IMAGE'');'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(17) := ''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(7407360007655550898)
,p_welcome_message=>'This application installer will guide you through the process of creating your database objects and seed data.'
,p_configuration_message=>'You can configure the following attributes of your application.'
,p_build_options_message=>'You can choose to include the following build options.'
,p_validation_message=>'The following validations will be performed to ensure your system is compatible with this application.'
,p_install_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_message=>'The application installer has detected that this application''s supporting objects were previously installed.  This wizard will guide you through the process of upgrading these supporting objects.'
,p_upgrade_confirm_message=>'Please confirm that you would like to install this application''s supporting objects.'
,p_upgrade_success_message=>'Your application''s supporting objects have been installed.'
,p_upgrade_failure_message=>'Installation of database objects and seed data has failed.'
,p_get_version_sql_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null',
'  from user_tables',
' where table_name like ''EBA_CA_%'''))
,p_deinstall_success_message=>'Deinstallation complete.'
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_free_kb=>1408
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE SEQUENCE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
,p_required_names_available=>'EBA_CA_ACCESS_LEVELS:EBA_CA_ADMINS:EBA_CA_COLOR_PREFS:EBA_CA_EMAIL_GROUP_MBRS:EBA_CA_EMAIL_GROUPS:EBA_CA_ERROR_LOOKUP:EBA_CA_EVENT_TYPES:EBA_CA_EVENTS:EBA_CA_FILES:EBA_CA_HISTORY:EBA_CA_NOTES:EBA_CA_NOTIFICATIONS:EBA_CA_PREFERENCES:EBA_CA_SERIES:EBA_'
||'CA_TAGS:EBA_CA_TAGS_TYPE_SUM:EBA_CA_TAGS_SUM:EBA_CA_TIMEFRAMES:EBA_CA_TZ_PREF:EBA_CA_USERS:EBA_CA_API:EBA_CA:EBA_CA_SEQ:EBA_CA_FW'
,p_deinstall_message=>'This operation will completely remove this application from your workspace.'
);
wwv_flow_imp.component_end;
end;
/
