prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 6000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>6000
,p_default_id_offset=>21004945808237727
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(1043802702227324815)
,p_build_option_name=>'Commented Out'
,p_static_id=>'commented-out'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>'273493669'
);
wwv_flow_imp.component_end;
end;
/
