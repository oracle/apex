prompt --application/shared_components/files/app_min_css
begin
--   Manifest
--     APP STATIC FILES: 6000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>6000
,p_default_id_offset=>21004945808237727
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E696E666F7B666F6E742D73697A653A766172282D2D75742D626173652D666F6E742D73697A652C203172656D297D2E6E6F777261707B77686974652D73706163653A6E6F777261707D3A726F6F747B2D2D75742D626F64792D636F6E74656E742D7061';
wwv_flow_imp.g_varchar2_table(2) := '6464696E672D783A313070783B2D2D75742D626F64792D636F6E74656E742D70616464696E672D793A3570787D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(1686266509031675805)
,p_file_name=>'app.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
