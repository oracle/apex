prompt --application/deployment/install/install_package
begin
--   Manifest
--     INSTALL: INSTALL-Package
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>6000
,p_default_id_offset=>36423738932107368
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_util_farest_explorer as  '||wwv_flow.LF||
'    procedure ingest_json_describe(  '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(2) := '  p_application_id in number,  '||wwv_flow.LF||
'        p_module_static_id in varchar2  '||wwv_flow.LF||
'    );  '||wwv_flow.LF||
'    procedure inge';
wwv_flow_imp.g_varchar2_table(3) := 'st_json_for_data_sources;  '||wwv_flow.LF||
'    procedure refresh_catalog; '||wwv_flow.LF||
'end eba_util_farest_explorer; '||wwv_flow.LF||
'/'||wwv_flow.LF||
'create ';
wwv_flow_imp.g_varchar2_table(4) := 'or replace package body eba_util_farest_explorer as '||wwv_flow.LF||
'    c_native_adfbc constant varchar2(12) := ''NA';
wwv_flow_imp.g_varchar2_table(5) := 'TIVE_ADFBC''; '||wwv_flow.LF||
'    c_web_src_type constant varchar2(15)  := ''WEB SOURCE TYPE''; '||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    function ';
wwv_flow_imp.g_varchar2_table(6) := 'replace_url_params( '||wwv_flow.LF||
'        p_url            in varchar2, '||wwv_flow.LF||
'        p_module_id      in number, '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(7) := '     p_application_id in number) '||wwv_flow.LF||
'        return              varchar2 '||wwv_flow.LF||
'    is '||wwv_flow.LF||
'        l_ret varcha';
wwv_flow_imp.g_varchar2_table(8) := 'r2(32767) := p_url; '||wwv_flow.LF||
'    begin '||wwv_flow.LF||
'        for p in (select name, value '||wwv_flow.LF||
'                    from apex_';
wwv_flow_imp.g_varchar2_table(9) := 'appl_web_src_parameters '||wwv_flow.LF||
'                   where module_id = p_module_id '||wwv_flow.LF||
'                     and ';
wwv_flow_imp.g_varchar2_table(10) := 'application_id = p_application_id) loop '||wwv_flow.LF||
'            l_ret := replace(l_ret, '':'' || p.name, p.value)';
wwv_flow_imp.g_varchar2_table(11) := '; '||wwv_flow.LF||
'            l_ret := replace(l_ret, ''{'' || p.name|| ''}'', p.value); '||wwv_flow.LF||
'        end loop; '||wwv_flow.LF||
'        re';
wwv_flow_imp.g_varchar2_table(12) := 'turn l_ret; '||wwv_flow.LF||
'    end; '||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    function sandbox_header_value( '||wwv_flow.LF||
'        p_app_id in number) '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(13) := '    return      varchar2 '||wwv_flow.LF||
'    is '||wwv_flow.LF||
'        l_ret apex_appl_plugin_settings.attribute_01%type; '||wwv_flow.LF||
'    be';
wwv_flow_imp.g_varchar2_table(14) := 'gin '||wwv_flow.LF||
'        select attribute_01 '||wwv_flow.LF||
'          into l_ret '||wwv_flow.LF||
'          from apex_appl_plugin_settings '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(15) := '       where application_id = p_app_id '||wwv_flow.LF||
'           and plugin_code = c_native_adfbc '||wwv_flow.LF||
'           and ';
wwv_flow_imp.g_varchar2_table(16) := 'plugin_type = c_web_src_type; '||wwv_flow.LF||
'        return case when l_ret is not null then apex_string.format(''s';
wwv_flow_imp.g_varchar2_table(17) := 'andbox="%s"'',l_ret) end; '||wwv_flow.LF||
'    exception '||wwv_flow.LF||
'        when no_data_found then '||wwv_flow.LF||
'            return null; '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(18) := '    end sandbox_header_value; '||wwv_flow.LF||
'    procedure ensure_app_proxy( '||wwv_flow.LF||
'        p_app_id number) '||wwv_flow.LF||
'    is '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(19) := '  begin '||wwv_flow.LF||
'        apex_debug.info(''### ensure_app_proxy''); '||wwv_flow.LF||
'        select proxy_server, '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(20) := '    no_proxy_domains '||wwv_flow.LF||
'          into apex_application.g_proxy_server, '||wwv_flow.LF||
'               apex_applicati';
wwv_flow_imp.g_varchar2_table(21) := 'on.g_no_proxy_domains '||wwv_flow.LF||
'         from apex_applications '||wwv_flow.LF||
'        where application_id = p_app_id; '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(22) := '      apex_debug.info(''### Set proxy = (%s), no_proxy = (%s)'',apex_application.g_proxy_server,apex_a';
wwv_flow_imp.g_varchar2_table(23) := 'pplication.g_no_proxy_domains);     '||wwv_flow.LF||
'    exception '||wwv_flow.LF||
'        when no_data_found then '||wwv_flow.LF||
'            nul';
wwv_flow_imp.g_varchar2_table(24) := 'l; '||wwv_flow.LF||
'    end ensure_app_proxy; '||wwv_flow.LF||
'     '||wwv_flow.LF||
'    -----------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(25) := '- '||wwv_flow.LF||
'    -- Download, parse, and locally store key information '||wwv_flow.LF||
'    -- about the FA REST data source u';
wwv_flow_imp.g_varchar2_table(26) := 'sed by the web source '||wwv_flow.LF||
'    -- module whose (app_id,module_id) is passed in  '||wwv_flow.LF||
'    -------------------';
wwv_flow_imp.g_varchar2_table(27) := '----------------------------------------- '||wwv_flow.LF||
'    procedure ingest_json_describe(  '||wwv_flow.LF||
'        p_applicati';
wwv_flow_imp.g_varchar2_table(28) := 'on_id   in number,  '||wwv_flow.LF||
'        p_module_static_id in varchar2 '||wwv_flow.LF||
'    )  '||wwv_flow.LF||
'    is  '||wwv_flow.LF||
'        l_describe_jso';
wwv_flow_imp.g_varchar2_table(29) := 'n               clob;  '||wwv_flow.LF||
'        l_fa_rest_endpoint_id         number;  '||wwv_flow.LF||
'  '||wwv_flow.LF||
'        -----------------';
wwv_flow_imp.g_varchar2_table(30) := '------------------------------------------- '||wwv_flow.LF||
'        -- Return the ADF REST describe JSON for a web ';
wwv_flow_imp.g_varchar2_table(31) := 'source module '||wwv_flow.LF||
'        ------------------------------------------------------------ '||wwv_flow.LF||
'        functio';
wwv_flow_imp.g_varchar2_table(32) := 'n describe_json  '||wwv_flow.LF||
'        return clob  '||wwv_flow.LF||
'        is '||wwv_flow.LF||
'            c_sandbox_header_value constant varc';
wwv_flow_imp.g_varchar2_table(33) := 'har2(4000) := sandbox_header_value(p_application_id); '||wwv_flow.LF||
'        begin  '||wwv_flow.LF||
'            ensure_app_proxy(';
wwv_flow_imp.g_varchar2_table(34) := 'p_application_id); '||wwv_flow.LF||
'            for l_web_source_module in (select wsm.url_endpoint,   '||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(35) := '                                   wsm.credential_static_id, '||wwv_flow.LF||
'                                      ';
wwv_flow_imp.g_varchar2_table(36) := '         wsm.module_id '||wwv_flow.LF||
'                                          from apex_appl_web_src_modules wsm';
wwv_flow_imp.g_varchar2_table(37) := '  '||wwv_flow.LF||
'                                          where wsm.web_source_type_code = c_native_adfbc '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(38) := '                                    and wsm.application_id = p_application_id  '||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(39) := '                      and wsm.module_static_id = p_module_static_id) loop  '||wwv_flow.LF||
'            apex_web_ser';
wwv_flow_imp.g_varchar2_table(40) := 'vice.set_request_headers(  '||wwv_flow.LF||
'                p_name_01  => ''REST-Framework-Version'',  '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(41) := '  p_value_01 => ''6'', '||wwv_flow.LF||
'                p_name_02  => case when c_sandbox_header_value is not null the';
wwv_flow_imp.g_varchar2_table(42) := 'n ''Metadata-Context'' end, '||wwv_flow.LF||
'                p_value_02 => c_sandbox_header_value ); '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(43) := 'return apex_web_service.make_rest_request(  '||wwv_flow.LF||
'                            p_url                  => r';
wwv_flow_imp.g_varchar2_table(44) := 'eplace_url_params( '||wwv_flow.LF||
'                                                        p_url            => l_we';
wwv_flow_imp.g_varchar2_table(45) := 'b_source_module.url_endpoint, '||wwv_flow.LF||
'                                                        p_module_id  ';
wwv_flow_imp.g_varchar2_table(46) := '    => l_web_source_module.module_id, '||wwv_flow.LF||
'                                                        p_app';
wwv_flow_imp.g_varchar2_table(47) := 'lication_id => p_application_id)||''/describe'',  '||wwv_flow.LF||
'                            p_http_method          ';
wwv_flow_imp.g_varchar2_table(48) := '=> ''GET'', '||wwv_flow.LF||
'                            p_credential_static_id => l_web_source_module.credential_stat';
wwv_flow_imp.g_varchar2_table(49) := 'ic_id);  '||wwv_flow.LF||
'            end loop;  '||wwv_flow.LF||
'        end describe_json;  '||wwv_flow.LF||
'    begin '||wwv_flow.LF||
'        l_describe_json :=';
wwv_flow_imp.g_varchar2_table(50) := ' describe_json;  '||wwv_flow.LF||
'        delete from eba_util_farest_endpoints   '||wwv_flow.LF||
'         where application_id = p';
wwv_flow_imp.g_varchar2_table(51) := '_application_id  '||wwv_flow.LF||
'           and module_static_id = p_module_static_id;  '||wwv_flow.LF||
'        insert into eba_ut';
wwv_flow_imp.g_varchar2_table(52) := 'il_farest_endpoints(  '||wwv_flow.LF||
'            module_static_id,  '||wwv_flow.LF||
'            application_id  '||wwv_flow.LF||
'        )  '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(53) := '    values (  '||wwv_flow.LF||
'            p_module_static_id,  '||wwv_flow.LF||
'            p_application_id  '||wwv_flow.LF||
'        )  '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(54) := 'returning id into l_fa_rest_endpoint_id;  '||wwv_flow.LF||
'        insert into eba_util_farest_endpoint_attrs(  '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(55) := '         endpoint_id,  '||wwv_flow.LF||
'            attr_name,  '||wwv_flow.LF||
'            attr_type,  '||wwv_flow.LF||
'            attr_len,  '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(56) := '          attr_title,  '||wwv_flow.LF||
'            attr_description,  '||wwv_flow.LF||
'            attr_lov,  '||wwv_flow.LF||
'            lov_href';
wwv_flow_imp.g_varchar2_table(57) := ',  '||wwv_flow.LF||
'            attr_control_type,  '||wwv_flow.LF||
'            attr_is_queryable,  '||wwv_flow.LF||
'            attr_is_required, ';
wwv_flow_imp.g_varchar2_table(58) := ' '||wwv_flow.LF||
'            attr_has_def_expr,  '||wwv_flow.LF||
'            attr_allow_changes,  '||wwv_flow.LF||
'            attr_is_primary_key';
wwv_flow_imp.g_varchar2_table(59) := ',  '||wwv_flow.LF||
'            attr_is_custom,  '||wwv_flow.LF||
'            allowed_operators,  '||wwv_flow.LF||
'            position      '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(60) := '  )  '||wwv_flow.LF||
'        select  l_fa_rest_endpoint_id,  '||wwv_flow.LF||
'                a.attr_name,  '||wwv_flow.LF||
'                a.attr';
wwv_flow_imp.g_varchar2_table(61) := '_type,  '||wwv_flow.LF||
'                a.attr_len,  '||wwv_flow.LF||
'                a.attr_title,  '||wwv_flow.LF||
'                a.attr_descri';
wwv_flow_imp.g_varchar2_table(62) := 'ption, '||wwv_flow.LF||
'                a.attr_lov,  '||wwv_flow.LF||
'                replace(replace(REGEXP_REPLACE(c.lov_href,''\{(';
wwv_flow_imp.g_varchar2_table(63) := '\w+)\}'','':\1'',1,0,''i''),'':443/'',''/''),'':80/'',''/'') lov_href, '||wwv_flow.LF||
'                a.attr_control_type,  '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(64) := '              case a.attr_queryable    when ''true'' then ''Y'' else ''N'' end            attr_is_queryabl';
wwv_flow_imp.g_varchar2_table(65) := 'e,  '||wwv_flow.LF||
'                case a.attr_required     when ''true'' then ''Y'' else ''N'' end            attr_is_r';
wwv_flow_imp.g_varchar2_table(66) := 'equired,  '||wwv_flow.LF||
'                case a.attr_has_def_expr when ''true'' then ''Y'' else ''N'' end            att';
wwv_flow_imp.g_varchar2_table(67) := 'r_has_def_expr,  '||wwv_flow.LF||
'                case a.attr_allow_changes  '||wwv_flow.LF||
'                    when ''never''    th';
wwv_flow_imp.g_varchar2_table(68) := 'en ''ReadOnly''  '||wwv_flow.LF||
'                    when ''inCreate'' then ''CreateOnly''  '||wwv_flow.LF||
'                    when ''al';
wwv_flow_imp.g_varchar2_table(69) := 'ways''   then ''Always''  '||wwv_flow.LF||
'                end                                                         ';
wwv_flow_imp.g_varchar2_table(70) := '          attr_allow_changes,  '||wwv_flow.LF||
'                case when b.attr_name is not null then ''Y'' else ''N'' ';
wwv_flow_imp.g_varchar2_table(71) := 'end               attr_is_primary_key,  '||wwv_flow.LF||
'                case   '||wwv_flow.LF||
'                    when upper(a.at';
wwv_flow_imp.g_varchar2_table(72) := 'tr_name) like ''%\_C'' escape ''\''   '||wwv_flow.LF||
'                    then ''Y''   '||wwv_flow.LF||
'                    else ''N'' end ';
wwv_flow_imp.g_varchar2_table(73) := 'attr_is_custom,  '||wwv_flow.LF||
'                (select listagg(y.operator,'', '')  '||wwv_flow.LF||
'                   from json_ta';
wwv_flow_imp.g_varchar2_table(74) := 'ble(a.attr_operators,''$[*]''   '||wwv_flow.LF||
'                            columns (  '||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(75) := '   operator path ''$''  '||wwv_flow.LF||
'                            )  '||wwv_flow.LF||
'                        ) y) as supported_ope';
wwv_flow_imp.g_varchar2_table(76) := 'rators,  '||wwv_flow.LF||
'                a.position  '||wwv_flow.LF||
'            from json_table( l_describe_json,  '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(77) := '       ''$.Resources.*.attributes[*]''  '||wwv_flow.LF||
'                    columns (  '||wwv_flow.LF||
'                        posit';
wwv_flow_imp.g_varchar2_table(78) := 'ion                          for ordinality,  '||wwv_flow.LF||
'                        attr_name          varchar2(4';
wwv_flow_imp.g_varchar2_table(79) := '000) path ''$.name'',  '||wwv_flow.LF||
'                        attr_title         varchar2(4000) path ''$.title'',  '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(80) := '                      attr_control_type  varchar2(4000) path ''$.controlType'',  '||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(81) := '    attr_description   varchar2(4000) path ''$.annotations.description'',  '||wwv_flow.LF||
'                        at';
wwv_flow_imp.g_varchar2_table(82) := 'tr_lov           varchar2(4000) path ''$.lov.childRefForCreate'',  '||wwv_flow.LF||
'                        attr_type ';
wwv_flow_imp.g_varchar2_table(83) := '         varchar2(4000) path ''$.type'',  '||wwv_flow.LF||
'                        attr_len           varchar2(4000) p';
wwv_flow_imp.g_varchar2_table(84) := 'ath ''$.precision'',  '||wwv_flow.LF||
'                        attr_queryable     varchar2(4000) path ''$.queryable'',  ';
wwv_flow_imp.g_varchar2_table(85) := ''||wwv_flow.LF||
'                        attr_required      varchar2(4000) path ''$.mandatory'',  '||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(86) := '     attr_allow_changes varchar2(4000) path ''$.allowChanges'',  '||wwv_flow.LF||
'                        attr_operato';
wwv_flow_imp.g_varchar2_table(87) := 'rs     varchar2(4000) path ''$.operators'',  '||wwv_flow.LF||
'                        attr_has_def_expr  varchar2(4000';
wwv_flow_imp.g_varchar2_table(88) := ') path ''$.hasDefaultValueExpression'')) a,  '||wwv_flow.LF||
'                json_table(l_describe_json,  '||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(89) := '          ''$.Resources.*.collection.finders[*]?(@.name=="PrimaryKey").attributes[*]''  '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(90) := '       columns (  '||wwv_flow.LF||
'                        attr_name varchar2(4000) path ''$.name'')) b,  '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(91) := '     (  '||wwv_flow.LF||
'                    select  '||wwv_flow.LF||
'                        a.lov_name,  '||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(92) := 'a.lov_href  '||wwv_flow.LF||
'                    from  '||wwv_flow.LF||
'                        json_table( l_describe_json,  '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(93) := '                       ''$.Resources.*.item.links[*]?(@.rel=="lov")''  '||wwv_flow.LF||
'                            co';
wwv_flow_imp.g_varchar2_table(94) := 'lumns (  '||wwv_flow.LF||
'                                lov_name varchar2(4000) path ''$.name'',  '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(95) := '               lov_href varchar2(4000) path ''$.href'')) a  '||wwv_flow.LF||
'                ) c  '||wwv_flow.LF||
'            where a';
wwv_flow_imp.g_varchar2_table(96) := '.attr_name = b.attr_name (+)  '||wwv_flow.LF||
'              and a.attr_lov  = c.lov_name  (+);  '||wwv_flow.LF||
'    insert into eb';
wwv_flow_imp.g_varchar2_table(97) := 'a_util_farest_endpoint_chobj(  '||wwv_flow.LF||
'        endpoint_id,  '||wwv_flow.LF||
'        obj_name,  '||wwv_flow.LF||
'        cardinality,  '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(98) := '      obj_href  '||wwv_flow.LF||
'    )  '||wwv_flow.LF||
'     select l_fa_rest_endpoint_id,  '||wwv_flow.LF||
'            x.name,  '||wwv_flow.LF||
'            x.ca';
wwv_flow_imp.g_varchar2_table(99) := 'rdinality,  '||wwv_flow.LF||
'            replace(replace(REGEXP_REPLACE(x.href,''\{(\w+)\}'','':\1'',1,0,''i''),'':443/'',''/';
wwv_flow_imp.g_varchar2_table(100) := '''),'':80/'',''/'') href  '||wwv_flow.LF||
'       from json_table(l_describe_json,''$.Resources.*.item.links[*]?(@.rel=="c';
wwv_flow_imp.g_varchar2_table(101) := 'hild")''  '||wwv_flow.LF||
'       columns (  '||wwv_flow.LF||
'            href varchar2(4000) path ''$.href'',  '||wwv_flow.LF||
'            name varch';
wwv_flow_imp.g_varchar2_table(102) := 'ar2(4000) path ''$.name'',  '||wwv_flow.LF||
'            cardinality varchar2(100) path ''$.cardinality.value''  '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(103) := ' )) x;  '||wwv_flow.LF||
'    end ingest_json_describe;  '||wwv_flow.LF||
'    -------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(104) := '----- '||wwv_flow.LF||
'    -- Download, parse, and locally store key information '||wwv_flow.LF||
'    -- about the FA REST data sour';
wwv_flow_imp.g_varchar2_table(105) := 'ces used by all the apps in '||wwv_flow.LF||
'    -- the workspace that haven''t yet been downloaded '||wwv_flow.LF||
'    ------------';
wwv_flow_imp.g_varchar2_table(106) := '------------------------------------------------ '||wwv_flow.LF||
'    procedure ingest_json_for_data_sources  '||wwv_flow.LF||
'    i';
wwv_flow_imp.g_varchar2_table(107) := 's '||wwv_flow.LF||
'        l_total_services_to_describe  number; '||wwv_flow.LF||
'        l_cur_service_being_described number := 0;';
wwv_flow_imp.g_varchar2_table(108) := '      '||wwv_flow.LF||
'    begin '||wwv_flow.LF||
'        select count(*)  '||wwv_flow.LF||
'        into l_total_services_to_describe '||wwv_flow.LF||
'        from ';
wwv_flow_imp.g_varchar2_table(109) := '( '||wwv_flow.LF||
'            select application_id, module_static_id  '||wwv_flow.LF||
'                                           ';
wwv_flow_imp.g_varchar2_table(110) := ' from apex_appl_web_src_modules  '||wwv_flow.LF||
'                                           where web_source_type_c';
wwv_flow_imp.g_varchar2_table(111) := 'ode = c_native_adfbc '||wwv_flow.LF||
'                                           minus  '||wwv_flow.LF||
'                           ';
wwv_flow_imp.g_varchar2_table(112) := '               select application_id, module_static_id  '||wwv_flow.LF||
'                                           ';
wwv_flow_imp.g_varchar2_table(113) := ' from eba_util_farest_endpoints '||wwv_flow.LF||
'        ); '||wwv_flow.LF||
'        for l_data_source in (select application_id, mo';
wwv_flow_imp.g_varchar2_table(114) := 'dule_static_id  '||wwv_flow.LF||
'                                from apex_appl_web_src_modules  '||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(115) := '             where web_source_type_code = c_native_adfbc '||wwv_flow.LF||
'                               minus  '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(116) := '                           select application_id, module_static_id  '||wwv_flow.LF||
'                               ';
wwv_flow_imp.g_varchar2_table(117) := ' from eba_util_farest_endpoints) loop  '||wwv_flow.LF||
'            begin  '||wwv_flow.LF||
'                l_cur_service_being_desc';
wwv_flow_imp.g_varchar2_table(118) := 'ribed := l_cur_service_being_described + 1; '||wwv_flow.LF||
'                apex_background_process.set_progress( '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(119) := '                    p_totalwork => l_total_services_to_describe, '||wwv_flow.LF||
'                    p_sofar     =>';
wwv_flow_imp.g_varchar2_table(120) := ' l_cur_service_being_described); '||wwv_flow.LF||
'                apex_background_process.set_status(''Retrieving RES';
wwv_flow_imp.g_varchar2_table(121) := 'T endpoint description for '' '||wwv_flow.LF||
'                                                    ||l_data_source.mo';
wwv_flow_imp.g_varchar2_table(122) := 'dule_static_id '||wwv_flow.LF||
'                                                    ||'' in app '' '||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(123) := '                                  ||l_data_source.application_id);                                  ';
wwv_flow_imp.g_varchar2_table(124) := ' '||wwv_flow.LF||
'                ingest_json_describe(  '||wwv_flow.LF||
'                    p_application_id   => l_data_source.ap';
wwv_flow_imp.g_varchar2_table(125) := 'plication_id,  '||wwv_flow.LF||
'                    p_module_static_id => l_data_source.module_static_id);  '||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(126) := '         commit;  '||wwv_flow.LF||
'            exception  '||wwv_flow.LF||
'                when others then  '||wwv_flow.LF||
'                    ap';
wwv_flow_imp.g_varchar2_table(127) := 'ex_debug.info(''Error while describing app %s, datasource %s'',  '||wwv_flow.LF||
'                        l_data_sourc';
wwv_flow_imp.g_varchar2_table(128) := 'e.application_id,  '||wwv_flow.LF||
'                        l_data_source.module_static_id);  '||wwv_flow.LF||
'                    a';
wwv_flow_imp.g_varchar2_table(129) := 'pex_debug.info(sqlerrm);  '||wwv_flow.LF||
'            end;  '||wwv_flow.LF||
'        end loop;  '||wwv_flow.LF||
'    end ingest_json_for_data_sourc';
wwv_flow_imp.g_varchar2_table(130) := 'es; '||wwv_flow.LF||
'    ------------------------------------------------------------ '||wwv_flow.LF||
'    -- Refresh the catalog of';
wwv_flow_imp.g_varchar2_table(131) := ' available top-level REST endpoints '||wwv_flow.LF||
'    -- for the distinct list of base URLs among all FA REST dat';
wwv_flow_imp.g_varchar2_table(132) := 'a '||wwv_flow.LF||
'    -- sources defined in the workspace. '||wwv_flow.LF||
'    ---------------------------------------------------';
wwv_flow_imp.g_varchar2_table(133) := '--------- '||wwv_flow.LF||
'    procedure refresh_catalog is '||wwv_flow.LF||
'        l_total_baseurls_to_describe  number; '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(134) := 'l_cur_baseurl_being_described number := 0;      '||wwv_flow.LF||
'        l_xml_of_json_describe xmltype; '||wwv_flow.LF||
'        --';
wwv_flow_imp.g_varchar2_table(135) := '---------------------------------------------------------- '||wwv_flow.LF||
'        -- Return the minimal REST descr';
wwv_flow_imp.g_varchar2_table(136) := 'ibe payload for the endpoint '||wwv_flow.LF||
'        -- URL passed in. '||wwv_flow.LF||
'        -----------------------------------';
wwv_flow_imp.g_varchar2_table(137) := '------------------------- '||wwv_flow.LF||
'        function describe_json( '||wwv_flow.LF||
'            p_endpoint_url         in va';
wwv_flow_imp.g_varchar2_table(138) := 'rchar2, '||wwv_flow.LF||
'            p_credential_static_id in varchar2, '||wwv_flow.LF||
'            p_application_id       in numb';
wwv_flow_imp.g_varchar2_table(139) := 'er)  '||wwv_flow.LF||
'        return clob  '||wwv_flow.LF||
'        is '||wwv_flow.LF||
'            c_sandbox_header_value constant varchar2(4000) :';
wwv_flow_imp.g_varchar2_table(140) := '= sandbox_header_value(p_application_id);  '||wwv_flow.LF||
'        begin  '||wwv_flow.LF||
'            apex_web_service.set_request';
wwv_flow_imp.g_varchar2_table(141) := '_headers(  '||wwv_flow.LF||
'                p_name_01  => ''REST-Framework-Version'',  '||wwv_flow.LF||
'                p_value_01 => ';
wwv_flow_imp.g_varchar2_table(142) := '''6'', '||wwv_flow.LF||
'                p_name_02  => case when c_sandbox_header_value is not null then ''Metadata-Cont';
wwv_flow_imp.g_varchar2_table(143) := 'ext'' end, '||wwv_flow.LF||
'                p_value_02 => c_sandbox_header_value );  '||wwv_flow.LF||
'            return apex_web_ser';
wwv_flow_imp.g_varchar2_table(144) := 'vice.make_rest_request(  '||wwv_flow.LF||
'                        p_url                  => p_endpoint_url||''/descri';
wwv_flow_imp.g_varchar2_table(145) := 'be?metadataMode=minimal'',  '||wwv_flow.LF||
'                        p_http_method          => ''GET'',  '||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(146) := '           p_credential_static_id => p_credential_static_id);  '||wwv_flow.LF||
'        end describe_json;      '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(147) := ' begin '||wwv_flow.LF||
'        -- Remove existing base URLs for catalog describe '||wwv_flow.LF||
'        delete from eba_util_fare';
wwv_flow_imp.g_varchar2_table(148) := 'st_cat_baseurl; '||wwv_flow.LF||
'        -- Populate distinct list of base URLs for catalog describe '||wwv_flow.LF||
'        insert';
wwv_flow_imp.g_varchar2_table(149) := ' into eba_util_farest_cat_baseurl(endpoint_url,credential_static_id,application_id) '||wwv_flow.LF||
'        select ';
wwv_flow_imp.g_varchar2_table(150) := 'base_url_endpoint, '||wwv_flow.LF||
'               credential_static_id, '||wwv_flow.LF||
'               min(application_id) '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(151) := '    from ( '||wwv_flow.LF||
'            select distinct  '||wwv_flow.LF||
'                       case when instr(url_endpoint,''/''||a';
wwv_flow_imp.g_varchar2_table(152) := 'ttribute_02||''/'') > 0 '||wwv_flow.LF||
'                            then substr(url_endpoint, 1, instr(url_endpoint,''';
wwv_flow_imp.g_varchar2_table(153) := '/''||attribute_02||''/'') - 1) '||wwv_flow.LF||
'                            else case when regexp_instr(url_endpoint,''/';
wwv_flow_imp.g_varchar2_table(154) := '''||apex_escape.regexp(attribute_02)||''$'') > 0  '||wwv_flow.LF||
'                                      then substr(ur';
wwv_flow_imp.g_varchar2_table(155) := 'l_endpoint, 1, regexp_instr(url_endpoint,''/''||apex_escape.regexp(attribute_02)||''$'') - 1) '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(156) := '                             else url_endpoint '||wwv_flow.LF||
'                                 end '||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(157) := '          end as base_url_endpoint,  '||wwv_flow.LF||
'                       credential_static_id, '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(158) := '       application_id '||wwv_flow.LF||
'                  from apex_appl_web_src_modules '||wwv_flow.LF||
'                 where web_';
wwv_flow_imp.g_varchar2_table(159) := 'source_type_code = c_native_adfbc) '||wwv_flow.LF||
'          group by base_url_endpoint, credential_static_id; '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(160) := '     commit; '||wwv_flow.LF||
'        select count(*)  '||wwv_flow.LF||
'          into l_total_baseurls_to_describe '||wwv_flow.LF||
'          from ';
wwv_flow_imp.g_varchar2_table(161) := 'eba_util_farest_cat_baseurl; '||wwv_flow.LF||
'        -- Describe and shred each base URL '||wwv_flow.LF||
'         for j in (select';
wwv_flow_imp.g_varchar2_table(162) := ' id, endpoint_url, credential_static_id, application_id '||wwv_flow.LF||
'                     from eba_util_farest_c';
wwv_flow_imp.g_varchar2_table(163) := 'at_baseurl) loop '||wwv_flow.LF||
'            begin '||wwv_flow.LF||
'                l_cur_baseurl_being_described := l_cur_baseurl_';
wwv_flow_imp.g_varchar2_table(164) := 'being_described + 1; '||wwv_flow.LF||
'                apex_background_process.set_progress( '||wwv_flow.LF||
'                    p_t';
wwv_flow_imp.g_varchar2_table(165) := 'otalwork => l_total_baseurls_to_describe, '||wwv_flow.LF||
'                    p_sofar     => l_cur_baseurl_being_de';
wwv_flow_imp.g_varchar2_table(166) := 'scribed);    '||wwv_flow.LF||
'                apex_background_process.set_status(''Retrieving REST endpoints at ''||j.';
wwv_flow_imp.g_varchar2_table(167) := 'endpoint_url);  '||wwv_flow.LF||
'                ensure_app_proxy(j.application_id); '||wwv_flow.LF||
'                l_xml_of_json_';
wwv_flow_imp.g_varchar2_table(168) := 'describe := apex_json.to_xmltype(describe_json(j.endpoint_url,j.credential_static_id,j.application_i';
wwv_flow_imp.g_varchar2_table(169) := 'd)); '||wwv_flow.LF||
'                insert into eba_util_farest_catalog(resource_name,title,endpoint_url,baseurl_i';
wwv_flow_imp.g_varchar2_table(170) := 'd) '||wwv_flow.LF||
'                select x.resource_name,  '||wwv_flow.LF||
'                       coalesce(x.title_plural,x.title';
wwv_flow_imp.g_varchar2_table(171) := ') as title,  '||wwv_flow.LF||
'                       regexp_replace(x.href,''/describe$'') as href, '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(172) := '      j.id as baseurl_id '||wwv_flow.LF||
'                from xmltable( ''/json/Resources/*''  '||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(173) := '   passing l_xml_of_json_describe '||wwv_flow.LF||
'                        columns '||wwv_flow.LF||
'                           resou';
wwv_flow_imp.g_varchar2_table(174) := 'rce_name varchar2(200) path ''local-name()'', '||wwv_flow.LF||
'                           href          varchar2(4000)';
wwv_flow_imp.g_varchar2_table(175) := ' path ''links/row[1]/href'', '||wwv_flow.LF||
'                           title         varchar2(200) path ''title'',    ';
wwv_flow_imp.g_varchar2_table(176) := '    '||wwv_flow.LF||
'                           title_plural  varchar2(200) path ''titlePlural''     '||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(177) := '     ) x '||wwv_flow.LF||
'                    order by upper(resource_name); '||wwv_flow.LF||
'                    commit; '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(178) := '   exception '||wwv_flow.LF||
'                when others then null; '||wwv_flow.LF||
'            end; '||wwv_flow.LF||
'         end loop; '||wwv_flow.LF||
'    end ';
wwv_flow_imp.g_varchar2_table(179) := 'refresh_catalog; '||wwv_flow.LF||
'end eba_util_farest_explorer;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(985758011018015339)
,p_install_id=>wwv_flow_imp.id(1023097412459087773)
,p_name=>'Package'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(985758124551015339)
,p_script_id=>wwv_flow_imp.id(985758011018015339)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_UTIL_FAREST_EXPLORER'
);
wwv_flow_imp.component_end;
end;
/
