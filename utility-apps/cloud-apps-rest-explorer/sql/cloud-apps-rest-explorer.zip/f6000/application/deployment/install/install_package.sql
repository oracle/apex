prompt --application/deployment/install/install_package
begin
--   Manifest
--     INSTALL: INSTALL-Package
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>6000
,p_default_id_offset=>21004945808237727
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_util_farest_explorer as  '||wwv_flow.LF||
'    procedure ingest_json_describe(  '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(2) := '  p_application_id   in number,  '||wwv_flow.LF||
'        p_module_static_id in varchar2  '||wwv_flow.LF||
'    );  '||wwv_flow.LF||
'    procedure in';
wwv_flow_imp.g_varchar2_table(3) := 'gest_json_for_data_sources;  '||wwv_flow.LF||
'    procedure refresh_catalog;'||wwv_flow.LF||
'    function manage_catalogs('||wwv_flow.LF||
'        p';
wwv_flow_imp.g_varchar2_table(4) := '_release           in varchar2,'||wwv_flow.LF||
'        p_pillar            in varchar2,'||wwv_flow.LF||
'        p_operation        ';
wwv_flow_imp.g_varchar2_table(5) := ' in varchar2)'||wwv_flow.LF||
'        return                 varchar2;'||wwv_flow.LF||
'    function tokenized_row_search_predicate('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(6) := '        p_search_facet_value in varchar2,'||wwv_flow.LF||
'        p_search_column_name in varchar2,'||wwv_flow.LF||
'        p_search';
wwv_flow_imp.g_varchar2_table(7) := '_facet_name  in varchar2)'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
'    procedure ensure_available_catalogs;'||wwv_flow.LF||
'end eba_util';
wwv_flow_imp.g_varchar2_table(8) := '_farest_explorer;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'create or replace package body eba_util_farest_explorer as'||wwv_flow.LF||
'    c_catalog_baseurl';
wwv_flow_imp.g_varchar2_table(9) := '     constant varchar2(255) := ''http://phoenix225302.dev3sub3phx.databasede3phx.oraclevcn.com:9988'';';
wwv_flow_imp.g_varchar2_table(10) := ''||wwv_flow.LF||
'    c_catalog_filename    constant varchar2(255) := ''fa_catalog_manifest.json'';'||wwv_flow.LF||
'    c_native_adfbc ';
wwv_flow_imp.g_varchar2_table(11) := '       constant varchar2(12)  := ''NATIVE_ADFBC'';'||wwv_flow.LF||
'    c_web_src_type        constant varchar2(15)  :=';
wwv_flow_imp.g_varchar2_table(12) := ' ''WEB SOURCE TYPE'';'||wwv_flow.LF||
'    c_manifest_collection constant varchar2(23)  := ''EBA_UTIL_FACAT_MANIFEST'';'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(13) := '   c_manifest_url        constant varchar2(255) := c_catalog_baseurl||''/''||c_catalog_filename;'||wwv_flow.LF||
'    g';
wwv_flow_imp.g_varchar2_table(14) := '_server_prefixes  apex_application.num_assoc_arr;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    function replace_url_params('||wwv_flow.LF||
'        p_';
wwv_flow_imp.g_varchar2_table(15) := 'url            in varchar2,'||wwv_flow.LF||
'        p_module_id      in number,'||wwv_flow.LF||
'        p_application_id in number)'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(16) := '        return              varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_ret varchar2(32767) := p_url;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(17) := '  for p in (select name, value'||wwv_flow.LF||
'                    from apex_appl_web_src_parameters'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(18) := '    where module_id = p_module_id'||wwv_flow.LF||
'                     and application_id = p_application_id) loop'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(19) := '           l_ret := replace(l_ret, '':'' || p.name, p.value);'||wwv_flow.LF||
'            l_ret := replace(l_ret, ''{'' ';
wwv_flow_imp.g_varchar2_table(20) := '|| p.name|| ''}'', p.value);'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        return l_ret;'||wwv_flow.LF||
'    end;'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    function sand';
wwv_flow_imp.g_varchar2_table(21) := 'box_header_value('||wwv_flow.LF||
'        p_app_id in number)'||wwv_flow.LF||
'        return      varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_ret apex';
wwv_flow_imp.g_varchar2_table(22) := '_appl_plugin_settings.attribute_01%type;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        select attribute_01'||wwv_flow.LF||
'          into l_ret'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(23) := '          from apex_appl_plugin_settings'||wwv_flow.LF||
'         where application_id = p_app_id'||wwv_flow.LF||
'           and plu';
wwv_flow_imp.g_varchar2_table(24) := 'gin_code = c_native_adfbc'||wwv_flow.LF||
'           and plugin_type = c_web_src_type;'||wwv_flow.LF||
'        return case when l_re';
wwv_flow_imp.g_varchar2_table(25) := 't is not null then apex_string.format(''sandbox="%s"'',l_ret) end;'||wwv_flow.LF||
'    exception'||wwv_flow.LF||
'        when no_data_';
wwv_flow_imp.g_varchar2_table(26) := 'found then'||wwv_flow.LF||
'            return null;'||wwv_flow.LF||
'    end sandbox_header_value;'||wwv_flow.LF||
'    procedure ensure_app_proxy('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(27) := '      p_app_id number)'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        select proxy_server,'||wwv_flow.LF||
'               no_proxy_domains';
wwv_flow_imp.g_varchar2_table(28) := ''||wwv_flow.LF||
'          into apex_application.g_proxy_server,'||wwv_flow.LF||
'               apex_application.g_no_proxy_domains'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(29) := '         from apex_applications'||wwv_flow.LF||
'        where application_id = p_app_id;'||wwv_flow.LF||
'    exception'||wwv_flow.LF||
'        when ';
wwv_flow_imp.g_varchar2_table(30) := 'no_data_found then'||wwv_flow.LF||
'            null;'||wwv_flow.LF||
'    end ensure_app_proxy;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --------------------------------';
wwv_flow_imp.g_varchar2_table(31) := '----------------------------'||wwv_flow.LF||
'    -- Download, parse, and locally store key information'||wwv_flow.LF||
'    -- about ';
wwv_flow_imp.g_varchar2_table(32) := 'the FA REST data source used by the web source'||wwv_flow.LF||
'    -- module whose (app_id,module_id) is passed in'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(33) := '   ------------------------------------------------------------'||wwv_flow.LF||
'    procedure ingest_json_describe('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(34) := '        p_application_id   in number,'||wwv_flow.LF||
'        p_module_static_id in varchar2'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_';
wwv_flow_imp.g_varchar2_table(35) := 'describe_json               clob;'||wwv_flow.LF||
'        l_fa_rest_endpoint_id         number;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -----------';
wwv_flow_imp.g_varchar2_table(36) := '-------------------------------------------------'||wwv_flow.LF||
'        -- Return the ADF REST describe JSON for a';
wwv_flow_imp.g_varchar2_table(37) := ' web source module'||wwv_flow.LF||
'        ------------------------------------------------------------'||wwv_flow.LF||
'        func';
wwv_flow_imp.g_varchar2_table(38) := 'tion describe_json'||wwv_flow.LF||
'        return clob'||wwv_flow.LF||
'        is'||wwv_flow.LF||
'            c_sandbox_header_value constant varcha';
wwv_flow_imp.g_varchar2_table(39) := 'r2(4000) := sandbox_header_value(p_application_id);'||wwv_flow.LF||
'        begin'||wwv_flow.LF||
'            ensure_app_proxy(p_app';
wwv_flow_imp.g_varchar2_table(40) := 'lication_id);'||wwv_flow.LF||
'            for l_web_source_module in (select wsm.url_endpoint,'||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(41) := '                          wsm.credential_static_id,'||wwv_flow.LF||
'                                               w';
wwv_flow_imp.g_varchar2_table(42) := 'sm.module_id,'||wwv_flow.LF||
'                                               wsm.auth_url_endpoint'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(43) := '                         from apex_appl_web_src_modules wsm'||wwv_flow.LF||
'                                        ';
wwv_flow_imp.g_varchar2_table(44) := '  where wsm.web_source_type_code = c_native_adfbc'||wwv_flow.LF||
'                                          and wsm.';
wwv_flow_imp.g_varchar2_table(45) := 'application_id = p_application_id'||wwv_flow.LF||
'                                          and wsm.module_static_id';
wwv_flow_imp.g_varchar2_table(46) := ' = p_module_static_id) loop'||wwv_flow.LF||
'            apex_web_service.set_request_headers('||wwv_flow.LF||
'                p_name';
wwv_flow_imp.g_varchar2_table(47) := '_01  => ''REST-Framework-Version'','||wwv_flow.LF||
'                p_value_01 => ''6'','||wwv_flow.LF||
'                p_name_02  => c';
wwv_flow_imp.g_varchar2_table(48) := 'ase when c_sandbox_header_value is not null then ''Metadata-Context'' end,'||wwv_flow.LF||
'                p_value_02 ';
wwv_flow_imp.g_varchar2_table(49) := '=> c_sandbox_header_value );'||wwv_flow.LF||
'                return apex_web_service.make_rest_request('||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(50) := '                p_url                  => replace_url_params('||wwv_flow.LF||
'                                      ';
wwv_flow_imp.g_varchar2_table(51) := '                  p_url            => l_web_source_module.url_endpoint,'||wwv_flow.LF||
'                            ';
wwv_flow_imp.g_varchar2_table(52) := '                            p_module_id      => l_web_source_module.module_id,'||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(53) := '                                   p_application_id => p_application_id)||''/describe'','||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(54) := '               p_http_method          => ''GET'','||wwv_flow.LF||
'                            p_credential_static_id =';
wwv_flow_imp.g_varchar2_table(55) := '> l_web_source_module.credential_static_id,'||wwv_flow.LF||
'                            p_token_url            => l_';
wwv_flow_imp.g_varchar2_table(56) := 'web_source_module.auth_url_endpoint);'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'        end describe_json;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(57) := '     l_describe_json := describe_json;'||wwv_flow.LF||
'        delete from eba_util_farest_endpoints'||wwv_flow.LF||
'         where ';
wwv_flow_imp.g_varchar2_table(58) := 'application_id = p_application_id'||wwv_flow.LF||
'           and module_static_id = p_module_static_id;'||wwv_flow.LF||
'        inse';
wwv_flow_imp.g_varchar2_table(59) := 'rt into eba_util_farest_endpoints('||wwv_flow.LF||
'            module_static_id,'||wwv_flow.LF||
'            application_id'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(60) := ')'||wwv_flow.LF||
'        values ('||wwv_flow.LF||
'            p_module_static_id,'||wwv_flow.LF||
'            p_application_id'||wwv_flow.LF||
'        )'||wwv_flow.LF||
'        re';
wwv_flow_imp.g_varchar2_table(61) := 'turning id into l_fa_rest_endpoint_id;'||wwv_flow.LF||
'        insert into eba_util_farest_endpoint_attrs('||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(62) := '   endpoint_id,'||wwv_flow.LF||
'            attr_name,'||wwv_flow.LF||
'            attr_type,'||wwv_flow.LF||
'            attr_len,'||wwv_flow.LF||
'            attr';
wwv_flow_imp.g_varchar2_table(63) := '_title,'||wwv_flow.LF||
'            attr_description,'||wwv_flow.LF||
'            attr_lov,'||wwv_flow.LF||
'            lov_href,'||wwv_flow.LF||
'            attr_c';
wwv_flow_imp.g_varchar2_table(64) := 'ontrol_type,'||wwv_flow.LF||
'            attr_is_queryable, '||wwv_flow.LF||
'            attr_is_required,'||wwv_flow.LF||
'            attr_has_def_';
wwv_flow_imp.g_varchar2_table(65) := 'expr,'||wwv_flow.LF||
'            attr_allow_changes,'||wwv_flow.LF||
'            attr_is_primary_key,'||wwv_flow.LF||
'            attr_is_custom,'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(66) := '           allowed_operators,'||wwv_flow.LF||
'            position'||wwv_flow.LF||
'        )'||wwv_flow.LF||
'        select  l_fa_rest_endpoint_id,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(67) := '                a.attr_name,'||wwv_flow.LF||
'                a.attr_type,'||wwv_flow.LF||
'                a.attr_len,'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(68) := '  a.attr_title,'||wwv_flow.LF||
'                a.attr_description,'||wwv_flow.LF||
'                a.attr_lov,'||wwv_flow.LF||
'                repl';
wwv_flow_imp.g_varchar2_table(69) := 'ace(replace(REGEXP_REPLACE(c.lov_href,''\{(\w+)\}'','':\1'',1,0,''i''),'':443/'',''/''),'':80/'',''/'') lov_href,'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(70) := '                a.attr_control_type,'||wwv_flow.LF||
'                case a.attr_queryable    when ''true'' then ''Y'' e';
wwv_flow_imp.g_varchar2_table(71) := 'lse ''N'' end            attr_is_queryable,'||wwv_flow.LF||
'                case a.attr_required     when ''true'' then ';
wwv_flow_imp.g_varchar2_table(72) := '''Y'' else ''N'' end            attr_is_required,'||wwv_flow.LF||
'                case a.attr_has_def_expr when ''true'' t';
wwv_flow_imp.g_varchar2_table(73) := 'hen ''Y'' else ''N'' end            attr_has_def_expr,'||wwv_flow.LF||
'                case a.attr_allow_changes'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(74) := '             when ''never''    then ''ReadOnly'''||wwv_flow.LF||
'                    when ''inCreate'' then ''CreateOnly'''||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(75) := '                   when ''always''   then ''Always'''||wwv_flow.LF||
'                end                                ';
wwv_flow_imp.g_varchar2_table(76) := '                                   attr_allow_changes,'||wwv_flow.LF||
'                case when b.attr_name is not ';
wwv_flow_imp.g_varchar2_table(77) := 'null then ''Y'' else ''N'' end               attr_is_primary_key,'||wwv_flow.LF||
'                case'||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(78) := '   when upper(a.attr_name) like ''%\_C'' escape ''\'''||wwv_flow.LF||
'                    then ''Y'''||wwv_flow.LF||
'                    e';
wwv_flow_imp.g_varchar2_table(79) := 'lse ''N'' end attr_is_custom,'||wwv_flow.LF||
'                (select listagg(y.operator,'', '')'||wwv_flow.LF||
'                   from';
wwv_flow_imp.g_varchar2_table(80) := ' json_table(a.attr_operators,''$[*]'''||wwv_flow.LF||
'                            columns ('||wwv_flow.LF||
'                          ';
wwv_flow_imp.g_varchar2_table(81) := '      operator path ''$'''||wwv_flow.LF||
'                            )'||wwv_flow.LF||
'                        ) y) as supported_oper';
wwv_flow_imp.g_varchar2_table(82) := 'ators,'||wwv_flow.LF||
'                a.position'||wwv_flow.LF||
'            from json_table( l_describe_json,'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(83) := '''$.Resources.*.attributes[*]'''||wwv_flow.LF||
'                    columns ('||wwv_flow.LF||
'                        position        ';
wwv_flow_imp.g_varchar2_table(84) := '                  for ordinality,'||wwv_flow.LF||
'                        attr_name          varchar2(4000) path ''$.';
wwv_flow_imp.g_varchar2_table(85) := 'name'','||wwv_flow.LF||
'                        attr_title         varchar2(4000) path ''$.title'','||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(86) := '     attr_control_type  varchar2(4000) path ''$.controlType'','||wwv_flow.LF||
'                        attr_descriptio';
wwv_flow_imp.g_varchar2_table(87) := 'n   varchar2(4000) path ''$.annotations.description'','||wwv_flow.LF||
'                        attr_lov           varc';
wwv_flow_imp.g_varchar2_table(88) := 'har2(4000) path ''$.lov.childRefForCreate'','||wwv_flow.LF||
'                        attr_type          varchar2(4000)';
wwv_flow_imp.g_varchar2_table(89) := ' path ''$.type'','||wwv_flow.LF||
'                        attr_len           varchar2(4000) path ''$.precision'','||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(90) := '                  attr_queryable     varchar2(4000) path ''$.queryable'','||wwv_flow.LF||
'                        attr';
wwv_flow_imp.g_varchar2_table(91) := '_required      varchar2(4000) path ''$.mandatory'','||wwv_flow.LF||
'                        attr_allow_changes varchar';
wwv_flow_imp.g_varchar2_table(92) := '2(4000) path ''$.allowChanges'','||wwv_flow.LF||
'                        attr_operators     varchar2(4000) path ''$.ope';
wwv_flow_imp.g_varchar2_table(93) := 'rators'','||wwv_flow.LF||
'                        attr_has_def_expr  varchar2(4000) path ''$.hasDefaultValueExpression';
wwv_flow_imp.g_varchar2_table(94) := ''')) a,'||wwv_flow.LF||
'                json_table(l_describe_json,'||wwv_flow.LF||
'                    ''$.Resources.*.collection.fin';
wwv_flow_imp.g_varchar2_table(95) := 'ders[*]?(@.name=="PrimaryKey").attributes[*]'''||wwv_flow.LF||
'                    columns ('||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(96) := 'attr_name varchar2(4000) path ''$.name'')) b,'||wwv_flow.LF||
'                ('||wwv_flow.LF||
'                    select'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(97) := '             a.lov_name,'||wwv_flow.LF||
'                        a.lov_href'||wwv_flow.LF||
'                    from'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(98) := '         json_table( l_describe_json,'||wwv_flow.LF||
'                            ''$.Resources.*.item.links[*]?(@.re';
wwv_flow_imp.g_varchar2_table(99) := 'l=="lov")'''||wwv_flow.LF||
'                            columns ('||wwv_flow.LF||
'                                lov_name varchar2(4';
wwv_flow_imp.g_varchar2_table(100) := '000) path ''$.name'','||wwv_flow.LF||
'                                lov_href varchar2(4000) path ''$.href'')) a'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(101) := '          ) c'||wwv_flow.LF||
'            where a.attr_name = b.attr_name (+)'||wwv_flow.LF||
'              and a.attr_lov  = c.lov_';
wwv_flow_imp.g_varchar2_table(102) := 'name  (+);'||wwv_flow.LF||
'    insert into eba_util_farest_endpoint_chobj('||wwv_flow.LF||
'        endpoint_id,'||wwv_flow.LF||
'        obj_name,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(103) := '      cardinality,'||wwv_flow.LF||
'        obj_href'||wwv_flow.LF||
'    )'||wwv_flow.LF||
'     select l_fa_rest_endpoint_id,'||wwv_flow.LF||
'            x.name,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(104) := '         x.cardinality,'||wwv_flow.LF||
'            replace(replace(REGEXP_REPLACE(x.href,''\{(\w+)\}'','':\1'',1,0,''i'')';
wwv_flow_imp.g_varchar2_table(105) := ','':443/'',''/''),'':80/'',''/'') href'||wwv_flow.LF||
'       from json_table(l_describe_json,''$.Resources.*.item.links[*]?(';
wwv_flow_imp.g_varchar2_table(106) := '@.rel=="child")'''||wwv_flow.LF||
'       columns ('||wwv_flow.LF||
'            href varchar2(4000) path ''$.href'','||wwv_flow.LF||
'            name va';
wwv_flow_imp.g_varchar2_table(107) := 'rchar2(4000) path ''$.name'','||wwv_flow.LF||
'            cardinality varchar2(100) path ''$.cardinality.value'''||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(108) := ')) x;'||wwv_flow.LF||
'    end ingest_json_describe;'||wwv_flow.LF||
'    ------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(109) := ''||wwv_flow.LF||
'    -- Download, parse, and locally store key information'||wwv_flow.LF||
'    -- about the FA REST data sources use';
wwv_flow_imp.g_varchar2_table(110) := 'd by all the apps in'||wwv_flow.LF||
'    -- the workspace that haven''t yet been downloaded'||wwv_flow.LF||
'    ---------------------';
wwv_flow_imp.g_varchar2_table(111) := '---------------------------------------'||wwv_flow.LF||
'    procedure ingest_json_for_data_sources'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_';
wwv_flow_imp.g_varchar2_table(112) := 'total_services_to_describe  number;'||wwv_flow.LF||
'        l_cur_service_being_described number := 0;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(113) := '     select count(*)'||wwv_flow.LF||
'        into l_total_services_to_describe'||wwv_flow.LF||
'        from ('||wwv_flow.LF||
'            select app';
wwv_flow_imp.g_varchar2_table(114) := 'lication_id, module_static_id'||wwv_flow.LF||
'                                            from apex_appl_web_src_mod';
wwv_flow_imp.g_varchar2_table(115) := 'ules'||wwv_flow.LF||
'                                           where web_source_type_code = c_native_adfbc'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(116) := '                                   minus'||wwv_flow.LF||
'                                          select applicatio';
wwv_flow_imp.g_varchar2_table(117) := 'n_id, module_static_id'||wwv_flow.LF||
'                                            from eba_util_farest_endpoints'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(118) := '      );'||wwv_flow.LF||
'        for l_data_source in (select application_id, module_static_id'||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(119) := '           from apex_appl_web_src_modules'||wwv_flow.LF||
'                               where web_source_type_code ';
wwv_flow_imp.g_varchar2_table(120) := '= c_native_adfbc'||wwv_flow.LF||
'                               minus'||wwv_flow.LF||
'                              select applicati';
wwv_flow_imp.g_varchar2_table(121) := 'on_id, module_static_id'||wwv_flow.LF||
'                                from eba_util_farest_endpoints) loop'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(122) := '     begin'||wwv_flow.LF||
'                l_cur_service_being_described := l_cur_service_being_described + 1;'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(123) := '           apex_background_process.set_progress('||wwv_flow.LF||
'                    p_totalwork => l_total_services';
wwv_flow_imp.g_varchar2_table(124) := '_to_describe,'||wwv_flow.LF||
'                    p_sofar     => l_cur_service_being_described);'||wwv_flow.LF||
'                ape';
wwv_flow_imp.g_varchar2_table(125) := 'x_background_process.set_status(''Retrieving REST endpoint description for '''||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(126) := '                            ||l_data_source.module_static_id'||wwv_flow.LF||
'                                       ';
wwv_flow_imp.g_varchar2_table(127) := '             ||'' in app '''||wwv_flow.LF||
'                                                    ||l_data_source.applic';
wwv_flow_imp.g_varchar2_table(128) := 'ation_id);'||wwv_flow.LF||
'                ingest_json_describe('||wwv_flow.LF||
'                    p_application_id   => l_data_so';
wwv_flow_imp.g_varchar2_table(129) := 'urce.application_id,'||wwv_flow.LF||
'                    p_module_static_id => l_data_source.module_static_id);'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(130) := '            commit;'||wwv_flow.LF||
'            exception'||wwv_flow.LF||
'                when others then'||wwv_flow.LF||
'                    apex_';
wwv_flow_imp.g_varchar2_table(131) := 'debug.info(''Error while describing app %s, datasource %s'','||wwv_flow.LF||
'                        l_data_source.app';
wwv_flow_imp.g_varchar2_table(132) := 'lication_id,'||wwv_flow.LF||
'                        l_data_source.module_static_id);'||wwv_flow.LF||
'                    apex_debug';
wwv_flow_imp.g_varchar2_table(133) := '.info(sqlerrm);'||wwv_flow.LF||
'            end;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'    end ingest_json_for_data_sources;'||wwv_flow.LF||
'    -------';
wwv_flow_imp.g_varchar2_table(134) := '-----------------------------------------------------'||wwv_flow.LF||
'    -- Refresh the catalog of available top-le';
wwv_flow_imp.g_varchar2_table(135) := 'vel REST endpoints'||wwv_flow.LF||
'    -- for the distinct list of base URLs among all FA REST data'||wwv_flow.LF||
'    -- sources d';
wwv_flow_imp.g_varchar2_table(136) := 'efined in the workspace.'||wwv_flow.LF||
'    ------------------------------------------------------------'||wwv_flow.LF||
'    proced';
wwv_flow_imp.g_varchar2_table(137) := 'ure refresh_catalog is'||wwv_flow.LF||
'        l_total_baseurls_to_describe  number;'||wwv_flow.LF||
'        l_cur_baseurl_being_des';
wwv_flow_imp.g_varchar2_table(138) := 'cribed number := 0;'||wwv_flow.LF||
'        l_xml_of_json_describe xmltype;'||wwv_flow.LF||
'        --------------------------------';
wwv_flow_imp.g_varchar2_table(139) := '----------------------------'||wwv_flow.LF||
'        -- Return the minimal REST describe payload for the endpoint'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(140) := '      -- URL passed in.'||wwv_flow.LF||
'        ------------------------------------------------------------'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(141) := ' function describe_json('||wwv_flow.LF||
'            p_endpoint_url         in varchar2,'||wwv_flow.LF||
'            p_credential_st';
wwv_flow_imp.g_varchar2_table(142) := 'atic_id in varchar2,'||wwv_flow.LF||
'            p_application_id       in number,'||wwv_flow.LF||
'            p_token_url          ';
wwv_flow_imp.g_varchar2_table(143) := '  in varchar2)'||wwv_flow.LF||
'        return clob'||wwv_flow.LF||
'        is'||wwv_flow.LF||
'            c_sandbox_header_value constant varchar2(4';
wwv_flow_imp.g_varchar2_table(144) := '000) := sandbox_header_value(p_application_id);'||wwv_flow.LF||
'            l_resp clob;'||wwv_flow.LF||
'            l_param varchar';
wwv_flow_imp.g_varchar2_table(145) := '2(100) := ''?metadataMode=minimal'';'||wwv_flow.LF||
'        begin'||wwv_flow.LF||
'            while true loop'||wwv_flow.LF||
''||wwv_flow.LF||
'                apex_d';
wwv_flow_imp.g_varchar2_table(146) := 'ebug.trace( ''## Trying to describe with parameter %0'',p0=>coalesce(l_param,''NULL''));'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(147) := ' apex_web_service.set_request_headers('||wwv_flow.LF||
'                    p_name_01  => ''REST-Framework-Version'','||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(148) := '                   p_value_01 => ''6'','||wwv_flow.LF||
'                    p_name_02  => case when c_sandbox_header_v';
wwv_flow_imp.g_varchar2_table(149) := 'alue is not null then ''Metadata-Context'' end,'||wwv_flow.LF||
'                    p_value_02 => c_sandbox_header_val';
wwv_flow_imp.g_varchar2_table(150) := 'ue );'||wwv_flow.LF||
'                l_resp := apex_web_service.make_rest_request('||wwv_flow.LF||
'                        p_url   ';
wwv_flow_imp.g_varchar2_table(151) := '               => p_endpoint_url||''/describe'' || l_param,'||wwv_flow.LF||
'                        p_http_method     ';
wwv_flow_imp.g_varchar2_table(152) := '     => ''GET'','||wwv_flow.LF||
'                        p_credential_static_id => p_credential_static_id,'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(153) := '             p_token_url            => p_token_url );'||wwv_flow.LF||
''||wwv_flow.LF||
'                exit when apex_web_service.g_';
wwv_flow_imp.g_varchar2_table(154) := 'status_code = utl_http.http_ok or l_param is null;'||wwv_flow.LF||
'                l_param := null;'||wwv_flow.LF||
''||wwv_flow.LF||
'            end';
wwv_flow_imp.g_varchar2_table(155) := ' loop;'||wwv_flow.LF||
''||wwv_flow.LF||
'            return l_resp;'||wwv_flow.LF||
''||wwv_flow.LF||
'        end describe_json;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        -- Remove existing ';
wwv_flow_imp.g_varchar2_table(156) := 'base URLs for catalog describe'||wwv_flow.LF||
'        delete from eba_util_farest_cat_baseurl;'||wwv_flow.LF||
'        -- Populate ';
wwv_flow_imp.g_varchar2_table(157) := 'distinct list of base URLs for catalog describe'||wwv_flow.LF||
'        insert into eba_util_farest_cat_baseurl(endp';
wwv_flow_imp.g_varchar2_table(158) := 'oint_url,credential_static_id,application_id,auth_url_endpoint)'||wwv_flow.LF||
'        select base_url_endpoint,'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(159) := '             credential_static_id,'||wwv_flow.LF||
'               min(application_id),'||wwv_flow.LF||
'               auth_url_endpo';
wwv_flow_imp.g_varchar2_table(160) := 'int'||wwv_flow.LF||
'          from ('||wwv_flow.LF||
'            select distinct'||wwv_flow.LF||
'                       case when instr(url_endpoint';
wwv_flow_imp.g_varchar2_table(161) := ',''/''||attribute_02||''/'') > 0'||wwv_flow.LF||
'                            then substr(url_endpoint, 1, instr(url_endp';
wwv_flow_imp.g_varchar2_table(162) := 'oint,''/''||attribute_02||''/'') - 1)'||wwv_flow.LF||
'                            else case when regexp_instr(url_endpoi';
wwv_flow_imp.g_varchar2_table(163) := 'nt,''/''||apex_escape.regexp(attribute_02)||''$'') > 0'||wwv_flow.LF||
'                                      then substr';
wwv_flow_imp.g_varchar2_table(164) := '(url_endpoint, 1, regexp_instr(url_endpoint,''/''||apex_escape.regexp(attribute_02)||''$'') - 1)'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(165) := '                               else url_endpoint'||wwv_flow.LF||
'                                 end'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(166) := '          end as base_url_endpoint,'||wwv_flow.LF||
'                       credential_static_id,'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(167) := '    application_id,'||wwv_flow.LF||
'                       auth_url_endpoint'||wwv_flow.LF||
'                  from apex_appl_web_sr';
wwv_flow_imp.g_varchar2_table(168) := 'c_modules'||wwv_flow.LF||
'                 where web_source_type_code = c_native_adfbc)'||wwv_flow.LF||
'          group by base_url_';
wwv_flow_imp.g_varchar2_table(169) := 'endpoint, credential_static_id, auth_url_endpoint;'||wwv_flow.LF||
'        commit;'||wwv_flow.LF||
'        select count(*)'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(170) := ' into l_total_baseurls_to_describe'||wwv_flow.LF||
'          from eba_util_farest_cat_baseurl;'||wwv_flow.LF||
'        -- Describe a';
wwv_flow_imp.g_varchar2_table(171) := 'nd shred each base URL'||wwv_flow.LF||
'         for j in (select id, endpoint_url, credential_static_id, application';
wwv_flow_imp.g_varchar2_table(172) := '_id, auth_url_endpoint'||wwv_flow.LF||
'                     from eba_util_farest_cat_baseurl) loop'||wwv_flow.LF||
'            begin';
wwv_flow_imp.g_varchar2_table(173) := ''||wwv_flow.LF||
'                l_cur_baseurl_being_described := l_cur_baseurl_being_described + 1;'||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(174) := ' apex_background_process.set_progress('||wwv_flow.LF||
'                    p_totalwork => l_total_baseurls_to_descri';
wwv_flow_imp.g_varchar2_table(175) := 'be,'||wwv_flow.LF||
'                    p_sofar     => l_cur_baseurl_being_described);'||wwv_flow.LF||
'                apex_backgrou';
wwv_flow_imp.g_varchar2_table(176) := 'nd_process.set_status(''Retrieving REST endpoints at ''||j.endpoint_url);'||wwv_flow.LF||
'                ensure_app_p';
wwv_flow_imp.g_varchar2_table(177) := 'roxy(j.application_id);'||wwv_flow.LF||
'                l_xml_of_json_describe := apex_json.to_xmltype(describe_json';
wwv_flow_imp.g_varchar2_table(178) := '(j.endpoint_url,j.credential_static_id,j.application_id,j.auth_url_endpoint));'||wwv_flow.LF||
'                inser';
wwv_flow_imp.g_varchar2_table(179) := 't into eba_util_farest_catalog(resource_name,title,endpoint_url,baseurl_id)'||wwv_flow.LF||
'                select x';
wwv_flow_imp.g_varchar2_table(180) := '.resource_name,'||wwv_flow.LF||
'                       coalesce(x.title_plural,x.title) as title,'||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(181) := '     regexp_replace(x.href,''/describe$'') as href,'||wwv_flow.LF||
'                       j.id as baseurl_id'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(182) := '        from xmltable( ''/json/Resources/*'''||wwv_flow.LF||
'                        passing l_xml_of_json_describe'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(183) := '                      columns'||wwv_flow.LF||
'                           resource_name varchar2(200) path ''local-nam';
wwv_flow_imp.g_varchar2_table(184) := 'e()'','||wwv_flow.LF||
'                           href          varchar2(4000) path ''links/row[1]/href'','||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(185) := '               title         varchar2(200) path ''title'','||wwv_flow.LF||
'                           title_plural  va';
wwv_flow_imp.g_varchar2_table(186) := 'rchar2(200) path ''titlePlural'''||wwv_flow.LF||
'                     ) x'||wwv_flow.LF||
'                    order by upper(resource_';
wwv_flow_imp.g_varchar2_table(187) := 'name);'||wwv_flow.LF||
'                    commit;'||wwv_flow.LF||
'            exception'||wwv_flow.LF||
'                when others then'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(188) := '      apex_debug.info(apex_string.format(''Exception fetching catalog from %s: %s'',j.endpoint_url,sql';
wwv_flow_imp.g_varchar2_table(189) := 'errm));'||wwv_flow.LF||
'            end;'||wwv_flow.LF||
'         end loop;'||wwv_flow.LF||
'    end refresh_catalog;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function install_catalog_z';
wwv_flow_imp.g_varchar2_table(190) := 'ip('||wwv_flow.LF||
'        p_release           in varchar2,'||wwv_flow.LF||
'        p_pillar            in varchar2)'||wwv_flow.LF||
'        return';
wwv_flow_imp.g_varchar2_table(191) := '       varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        c_file_name constant varchar2(1000) := p_release'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(192) := '                           ||''_'''||wwv_flow.LF||
'                                               ||p_pillar'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(193) := '                                      ||''.zip'';'||wwv_flow.LF||
'        l_catalog_zip         blob;'||wwv_flow.LF||
'        l_files ';
wwv_flow_imp.g_varchar2_table(194) := '              apex_zip.t_files;'||wwv_flow.LF||
'        l_ret                 varchar2(255);'||wwv_flow.LF||
'        l_details_json ';
wwv_flow_imp.g_varchar2_table(195) := '       blob;'||wwv_flow.LF||
'        l_pillar_id           number;'||wwv_flow.LF||
'        l_release_id          number;'||wwv_flow.LF||
'        l_c';
wwv_flow_imp.g_varchar2_table(196) := 'atalog_id          number;'||wwv_flow.LF||
''||wwv_flow.LF||
'        ----------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(197) := '---------------'||wwv_flow.LF||
'        procedure get_pillar_id'||wwv_flow.LF||
'        is'||wwv_flow.LF||
'        begin'||wwv_flow.LF||
'            select id'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(198) := '         into l_pillar_id'||wwv_flow.LF||
'              from eba_util_facat_pillars'||wwv_flow.LF||
'             where name = p_pill';
wwv_flow_imp.g_varchar2_table(199) := 'ar;'||wwv_flow.LF||
'        exception'||wwv_flow.LF||
'            when no_data_found then'||wwv_flow.LF||
'                insert into eba_util_facat';
wwv_flow_imp.g_varchar2_table(200) := '_pillars(name)'||wwv_flow.LF||
'                values (p_pillar)'||wwv_flow.LF||
'                returning id into l_pillar_id;'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(201) := '    end get_pillar_id;'||wwv_flow.LF||
'        ---------------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(202) := '----------'||wwv_flow.LF||
'        procedure get_release_id'||wwv_flow.LF||
'        is'||wwv_flow.LF||
'        begin'||wwv_flow.LF||
'            select id'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(203) := '     into l_release_id'||wwv_flow.LF||
'              from eba_util_facat_releases'||wwv_flow.LF||
'             where name = p_releas';
wwv_flow_imp.g_varchar2_table(204) := 'e;'||wwv_flow.LF||
'        exception'||wwv_flow.LF||
'            when no_data_found then'||wwv_flow.LF||
'                insert into eba_util_facat_';
wwv_flow_imp.g_varchar2_table(205) := 'releases(name)'||wwv_flow.LF||
'                values (p_release)'||wwv_flow.LF||
'                returning id into l_release_id;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(206) := '      end get_release_id;'||wwv_flow.LF||
''||wwv_flow.LF||
'        -----------------------------------------------------------------';
wwv_flow_imp.g_varchar2_table(207) := '--------------'||wwv_flow.LF||
'        procedure install_catalog_service('||wwv_flow.LF||
'            p_details_json in blob)'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(208) := '  is'||wwv_flow.LF||
'            l_service_id eba_util_facat_endpoints.id%type;'||wwv_flow.LF||
'            cursor c is select l_cat';
wwv_flow_imp.g_varchar2_table(209) := 'alog_id,'||wwv_flow.LF||
'                               name,'||wwv_flow.LF||
'                               description,'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(210) := '                     path,'||wwv_flow.LF||
'                               server_prefix'||wwv_flow.LF||
'                          fr';
wwv_flow_imp.g_varchar2_table(211) := 'om json_table(p_details_json, ''$."data_profile"'' columns ('||wwv_flow.LF||
'                            name         ';
wwv_flow_imp.g_varchar2_table(212) := ' varchar2(4000)  path ''$."name"'','||wwv_flow.LF||
'                            path          varchar2(4000)  path ''$.';
wwv_flow_imp.g_varchar2_table(213) := '"path"'','||wwv_flow.LF||
'                            server_prefix varchar2(4000)  path ''$."server_prefix"'','||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(214) := '                     description   varchar2(4000) path ''$."description"'''||wwv_flow.LF||
'                          )';
wwv_flow_imp.g_varchar2_table(215) := ');'||wwv_flow.LF||
'            l_service_info c%rowtype;'||wwv_flow.LF||
'            l_server_prefix_id number;'||wwv_flow.LF||
''||wwv_flow.LF||
'            procedu';
wwv_flow_imp.g_varchar2_table(216) := 're get_server_prefix_id('||wwv_flow.LF||
'                p_server_url_prefix in varchar2)'||wwv_flow.LF||
'            is'||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(217) := ' begin'||wwv_flow.LF||
'                if g_server_prefixes.exists(p_server_url_prefix) then'||wwv_flow.LF||
'                    l_s';
wwv_flow_imp.g_varchar2_table(218) := 'erver_prefix_id := g_server_prefixes(p_server_url_prefix);'||wwv_flow.LF||
'                else'||wwv_flow.LF||
'                    ';
wwv_flow_imp.g_varchar2_table(219) := 'begin'||wwv_flow.LF||
'                        select id'||wwv_flow.LF||
'                          into l_server_prefix_id'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(220) := '                from eba_util_facat_server_prefixes'||wwv_flow.LF||
'                         where server_url_prefix';
wwv_flow_imp.g_varchar2_table(221) := ' = p_server_url_prefix;'||wwv_flow.LF||
'                    exception'||wwv_flow.LF||
'                        when no_data_found the';
wwv_flow_imp.g_varchar2_table(222) := 'n'||wwv_flow.LF||
'                            insert into eba_util_facat_server_prefixes(server_url_prefix)'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(223) := '                    values (p_server_url_prefix)'||wwv_flow.LF||
'                            returning id into l_ser';
wwv_flow_imp.g_varchar2_table(224) := 'ver_prefix_id;'||wwv_flow.LF||
'                    end;'||wwv_flow.LF||
'                    -- Cache server prefix id lookup'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(225) := '             g_server_prefixes(p_server_url_prefix) := l_server_prefix_id;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(226) := '           end get_server_prefix_id;'||wwv_flow.LF||
'        begin'||wwv_flow.LF||
'            open c;'||wwv_flow.LF||
'            fetch c into l_se';
wwv_flow_imp.g_varchar2_table(227) := 'rvice_info;'||wwv_flow.LF||
'            close c;'||wwv_flow.LF||
'            get_server_prefix_id(l_service_info.server_prefix);'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(228) := '         insert into eba_util_facat_endpoints('||wwv_flow.LF||
'                catalog_id,'||wwv_flow.LF||
'                name,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(229) := '             description,'||wwv_flow.LF||
'                path,'||wwv_flow.LF||
'                server_prefix_id'||wwv_flow.LF||
'            )'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(230) := '       values ('||wwv_flow.LF||
'                l_catalog_id,'||wwv_flow.LF||
'                l_service_info.name,'||wwv_flow.LF||
'                l';
wwv_flow_imp.g_varchar2_table(231) := '_service_info.description,'||wwv_flow.LF||
'                l_service_info.path,'||wwv_flow.LF||
'                l_server_prefix_id'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(232) := '           )'||wwv_flow.LF||
'            returning id into l_service_id;'||wwv_flow.LF||
'            insert into eba_util_facat_endp';
wwv_flow_imp.g_varchar2_table(233) := 'oint_attrs('||wwv_flow.LF||
'                bo_endpoint_id,'||wwv_flow.LF||
'                data_profile_column_name,'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(234) := '  attr_name,'||wwv_flow.LF||
'                attr_type,'||wwv_flow.LF||
'                attr_len,'||wwv_flow.LF||
'                attr_title,'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(235) := '          attr_description,'||wwv_flow.LF||
'                attr_is_queryable,'||wwv_flow.LF||
'                attr_is_required,'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(236) := '             attr_allow_changes,'||wwv_flow.LF||
'                position'||wwv_flow.LF||
'            )'||wwv_flow.LF||
'            select l_service';
wwv_flow_imp.g_varchar2_table(237) := '_id,'||wwv_flow.LF||
'                   col_name,'||wwv_flow.LF||
'                   coalesce(remote_attr_name,selector),'||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(238) := '         attr_type,'||wwv_flow.LF||
'                   attr_len,'||wwv_flow.LF||
'                   attr_title,'||wwv_flow.LF||
'                   a';
wwv_flow_imp.g_varchar2_table(239) := 'ttr_description,'||wwv_flow.LF||
'                   attr_filterable,'||wwv_flow.LF||
'                   case '||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(240) := '  when '',''||additional_info||'','' like ''%,Required,%'''||wwv_flow.LF||
'                        then ''Y'''||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(241) := '          else ''N'''||wwv_flow.LF||
'                   end,'||wwv_flow.LF||
'                   case '||wwv_flow.LF||
'                        when '',''';
wwv_flow_imp.g_varchar2_table(242) := '||additional_info||'','' like ''%,ReadOnly,%'''||wwv_flow.LF||
'                        then ''N'''||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(243) := 'when '',''||additional_info||'','' like ''%,CreateOnly,%'''||wwv_flow.LF||
'                        then ''On Create'''||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(244) := '                  else ''Y'''||wwv_flow.LF||
'                   end,'||wwv_flow.LF||
'                   seq'||wwv_flow.LF||
'              from json_ta';
wwv_flow_imp.g_varchar2_table(245) := 'ble(p_details_json, ''$."data_profile"."columns"[*]'' columns ('||wwv_flow.LF||
'                   col_name         va';
wwv_flow_imp.g_varchar2_table(246) := 'rchar2(4000) path ''$."name"'','||wwv_flow.LF||
'                   selector         varchar2(4000) path ''$."selector"''';
wwv_flow_imp.g_varchar2_table(247) := ','||wwv_flow.LF||
'                   remote_attr_name varchar2(4000) path ''$."remote_attribute_name"'','||wwv_flow.LF||
'             ';
wwv_flow_imp.g_varchar2_table(248) := '      attr_type        varchar2(4000) path ''$."data_type"'','||wwv_flow.LF||
'                   attr_len         numb';
wwv_flow_imp.g_varchar2_table(249) := 'er         path ''$."max_length"'','||wwv_flow.LF||
'                   attr_title       varchar2(4000) path ''$."label"';
wwv_flow_imp.g_varchar2_table(250) := ''','||wwv_flow.LF||
'                   attr_description varchar2(4000) path ''$."description"'','||wwv_flow.LF||
'                   att';
wwv_flow_imp.g_varchar2_table(251) := 'r_filterable  varchar2(4000) path ''$."is_filterable"'','||wwv_flow.LF||
'                   seq              number   ';
wwv_flow_imp.g_varchar2_table(252) := '      path ''$."sequence"'','||wwv_flow.LF||
'                   additional_info  varchar2(4000) path ''$."additional_in';
wwv_flow_imp.g_varchar2_table(253) := 'fo"'''||wwv_flow.LF||
'              ));'||wwv_flow.LF||
'        end install_catalog_service;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        -- Clear server prefix';
wwv_flow_imp.g_varchar2_table(254) := ' url cache'||wwv_flow.LF||
'        g_server_prefixes.delete;'||wwv_flow.LF||
'        l_catalog_zip := apex_web_service.make_rest_req';
wwv_flow_imp.g_varchar2_table(255) := 'uest_b('||wwv_flow.LF||
'                            p_http_method => ''GET'','||wwv_flow.LF||
'                            p_url       ';
wwv_flow_imp.g_varchar2_table(256) := '  => rtrim(c_catalog_baseurl,''/'')'||wwv_flow.LF||
'                                             ||''/'''||wwv_flow.LF||
'               ';
wwv_flow_imp.g_varchar2_table(257) := '                              ||c_file_name);'||wwv_flow.LF||
'        if apex_web_service.g_status_code != 200 then'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(258) := '            l_ret := apex_string.format('||wwv_flow.LF||
'                                ''Error downloading %s pilla';
wwv_flow_imp.g_varchar2_table(259) := 'r catalog for %s release'','||wwv_flow.LF||
'                                p_pillar,'||wwv_flow.LF||
'                               ';
wwv_flow_imp.g_varchar2_table(260) := ' p_release);'||wwv_flow.LF||
'        end if;'||wwv_flow.LF||
'        get_pillar_id;'||wwv_flow.LF||
'        get_release_id;'||wwv_flow.LF||
'        -- delete existi';
wwv_flow_imp.g_varchar2_table(261) := 'ng catalog for this (release,pillar) combination'||wwv_flow.LF||
'        delete from eba_util_facat_catalogs'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(262) := ' where pillar_id = l_pillar_id'||wwv_flow.LF||
'          and release_id = l_release_id;'||wwv_flow.LF||
'        -- insert new catalo';
wwv_flow_imp.g_varchar2_table(263) := 'g entry to prepare for installing'||wwv_flow.LF||
'        -- all the services in the downloaded release/pillar catal';
wwv_flow_imp.g_varchar2_table(264) := 'og zip'||wwv_flow.LF||
'        insert into eba_util_facat_catalogs(release_id,pillar_id)'||wwv_flow.LF||
'        values (l_release_i';
wwv_flow_imp.g_varchar2_table(265) := 'd,l_pillar_id)'||wwv_flow.LF||
'        returning id into l_catalog_id;'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        -- Get list of files from ';
wwv_flow_imp.g_varchar2_table(266) := 'the zip'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        l_files := apex_zip.get_files(l_catalog_zip);'||wwv_flow.LF||
''||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        -- Set ';
wwv_flow_imp.g_varchar2_table(267) := 'initial background progress'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        apex_background_process.set_progress(p_totalwork=>l_f';
wwv_flow_imp.g_varchar2_table(268) := 'iles.count,p_sofar=>0);'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        -- Process the individual files inside the zip'||wwv_flow.LF||
'        --';
wwv_flow_imp.g_varchar2_table(269) := ''||wwv_flow.LF||
'        for j in 1..l_files.count loop'||wwv_flow.LF||
'            l_details_json := apex_zip.get_file_content(l_ca';
wwv_flow_imp.g_varchar2_table(270) := 'talog_zip,l_files(j));'||wwv_flow.LF||
'            apex_background_process.set_progress(p_totalwork=>l_files.count,p';
wwv_flow_imp.g_varchar2_table(271) := '_sofar=>j);'||wwv_flow.LF||
'            install_catalog_service('||wwv_flow.LF||
'                p_details_json => l_details_json);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(272) := '        end loop;'||wwv_flow.LF||
'        -- Wire up the path parentage for hiearchy'||wwv_flow.LF||
'        update eba_util_facat_e';
wwv_flow_imp.g_varchar2_table(273) := 'ndpoints e'||wwv_flow.LF||
'        set e.parent_bo_endpoint_id ='||wwv_flow.LF||
'           (select p.id'||wwv_flow.LF||
'              from eba_util';
wwv_flow_imp.g_varchar2_table(274) := '_facat_endpoints p'||wwv_flow.LF||
'             where p.catalog_id = e.catalog_id'||wwv_flow.LF||
'               and p.server_prefix';
wwv_flow_imp.g_varchar2_table(275) := '_id = e.server_prefix_id'||wwv_flow.LF||
'               and p.path = case'||wwv_flow.LF||
'                                regexp_cou';
wwv_flow_imp.g_varchar2_table(276) := 'nt(e.path,''/\{[^}]+\}/child/[^/]+$'')'||wwv_flow.LF||
'                                when 1'||wwv_flow.LF||
'                        ';
wwv_flow_imp.g_varchar2_table(277) := '        then regexp_replace(e.path,''/\{[^}]+\}/child/[^/]+$'')'||wwv_flow.LF||
'                            end);     ';
wwv_flow_imp.g_varchar2_table(278) := '   '||wwv_flow.LF||
'        return l_ret;'||wwv_flow.LF||
'    end;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function uninstall_catalog_zip('||wwv_flow.LF||
'        p_release in varchar';
wwv_flow_imp.g_varchar2_table(279) := '2,'||wwv_flow.LF||
'        p_pillar  in varchar2)'||wwv_flow.LF||
'        return       varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_ret varchar2(255);'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(280) := '    begin'||wwv_flow.LF||
'        delete'||wwv_flow.LF||
'        from eba_util_facat_catalogs c'||wwv_flow.LF||
'        where c.release_id = (select';
wwv_flow_imp.g_varchar2_table(281) := ' id'||wwv_flow.LF||
'                                from eba_util_facat_releases'||wwv_flow.LF||
'                               wher';
wwv_flow_imp.g_varchar2_table(282) := 'e name = p_release)'||wwv_flow.LF||
'          and c.pillar_id = (select id'||wwv_flow.LF||
'                               from eba_u';
wwv_flow_imp.g_varchar2_table(283) := 'til_facat_pillars'||wwv_flow.LF||
'                              where name = p_pillar);'||wwv_flow.LF||
'        return l_ret;'||wwv_flow.LF||
'    en';
wwv_flow_imp.g_varchar2_table(284) := 'd;'||wwv_flow.LF||
'    function manage_catalogs('||wwv_flow.LF||
'        p_release           in varchar2,'||wwv_flow.LF||
'        p_pillar          ';
wwv_flow_imp.g_varchar2_table(285) := '  in varchar2,'||wwv_flow.LF||
'        p_operation         in varchar2)'||wwv_flow.LF||
'        return         varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(286) := '   l_ret varchar2(255);'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        apex_debug.enter(''manage_catalogs'','||wwv_flow.LF||
'            ''p_release';
wwv_flow_imp.g_varchar2_table(287) := ''',p_release,'||wwv_flow.LF||
'            ''p_pillar'',p_pillar,'||wwv_flow.LF||
'            ''p_operation'',p_operation);'||wwv_flow.LF||
'        case u';
wwv_flow_imp.g_varchar2_table(288) := 'pper(p_operation)'||wwv_flow.LF||
'            when ''INSTALL'' then'||wwv_flow.LF||
'                l_ret := install_catalog_zip('||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(289) := '                        p_release           => p_release,'||wwv_flow.LF||
'                            p_pillar      ';
wwv_flow_imp.g_varchar2_table(290) := '      => p_pillar);'||wwv_flow.LF||
'            when ''UNINSTALL'' then'||wwv_flow.LF||
'                l_ret := uninstall_catalog_zip';
wwv_flow_imp.g_varchar2_table(291) := '('||wwv_flow.LF||
'                            p_release => p_release,'||wwv_flow.LF||
'                            p_pillar  => p_pil';
wwv_flow_imp.g_varchar2_table(292) := 'lar);'||wwv_flow.LF||
'            else'||wwv_flow.LF||
'                l_ret := ''Unrecognized operation ''||upper(p_operation);'||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(293) := '   end case;'||wwv_flow.LF||
'        return l_ret;'||wwv_flow.LF||
'    end manage_catalogs;'||wwv_flow.LF||
''||wwv_flow.LF||
'    function tokenized_row_search_predi';
wwv_flow_imp.g_varchar2_table(294) := 'cate('||wwv_flow.LF||
'        p_search_facet_value in varchar2,'||wwv_flow.LF||
'        p_search_column_name in varchar2,'||wwv_flow.LF||
'        p_';
wwv_flow_imp.g_varchar2_table(295) := 'search_facet_name  in varchar2)'||wwv_flow.LF||
'        return                  varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        c_row_search';
wwv_flow_imp.g_varchar2_table(296) := '_predicate constant varchar2(255) :='||wwv_flow.LF||
'            q''~upper(%s) like chr(37)||upper(trim(regexp_substr';
wwv_flow_imp.g_varchar2_table(297) := '(:%s,''[^''||chr(13)||chr(10)||'']+'',1,%s)))||chr(37)~'';'||wwv_flow.LF||
'        l_predicates apex_t_varchar2;'||wwv_flow.LF||
'    begi';
wwv_flow_imp.g_varchar2_table(298) := 'n'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        -- Return a valid predicate so that the Function Returning SQL will be legal'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(299) := '      -- SQL even at design time when p_search_facet_value is null'||wwv_flow.LF||
'        --'||wwv_flow.LF||
'        if p_search_fa';
wwv_flow_imp.g_varchar2_table(300) := 'cet_value is null then'||wwv_flow.LF||
'            return ''1=1'';'||wwv_flow.LF||
'        else'||wwv_flow.LF||
'            for j in 1..regexp_count(p';
wwv_flow_imp.g_varchar2_table(301) := '_search_facet_value,''[^''||chr(13)||chr(10)||'']+'') loop'||wwv_flow.LF||
'                -- chr(37) is the percent sig';
wwv_flow_imp.g_varchar2_table(302) := 'n'||wwv_flow.LF||
'                apex_string.push(l_predicates,'||wwv_flow.LF||
'                                 apex_string.format';
wwv_flow_imp.g_varchar2_table(303) := '('||wwv_flow.LF||
'                                    c_row_search_predicate,'||wwv_flow.LF||
'                                    p_';
wwv_flow_imp.g_varchar2_table(304) := 'search_column_name,'||wwv_flow.LF||
'                                    p_search_facet_name,'||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(305) := '             j));'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'            return apex_string.join(l_predicates,'' and '');'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(306) := '       end if;'||wwv_flow.LF||
'    end tokenized_row_search_predicate;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure ensure_available_catalogs'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(307) := 'is'||wwv_flow.LF||
'        l_manifest_clob   clob;'||wwv_flow.LF||
'        l_manifest_json   json_object_t;'||wwv_flow.LF||
'        json_syntax_erro';
wwv_flow_imp.g_varchar2_table(308) := 'r exception;'||wwv_flow.LF||
'        json_invalid      exception;'||wwv_flow.LF||
'        pragma            exception_init(json_synt';
wwv_flow_imp.g_varchar2_table(309) := 'ax_error,-40441);'||wwv_flow.LF||
'        pragma            exception_init(json_invalid,-40834);        '||wwv_flow.LF||
'    begin'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(310) := '       for j in (select null'||wwv_flow.LF||
'                    from apex_collections'||wwv_flow.LF||
'                   where coll';
wwv_flow_imp.g_varchar2_table(311) := 'ection_name = c_manifest_collection'||wwv_flow.LF||
'                     and clob001 is not null'||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(312) := '  and sys.dbms_lob.getlength(clob001) > 0) '||wwv_flow.LF||
'        loop'||wwv_flow.LF||
'            -- Manifest is already cached.'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(313) := '            return;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        apex_collection.create_or_truncate_collection(c_manife';
wwv_flow_imp.g_varchar2_table(314) := 'st_collection);'||wwv_flow.LF||
'        l_manifest_clob := apex_web_service.make_rest_request('||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(315) := '           p_http_method => ''GET'','||wwv_flow.LF||
'                                p_url         => c_manifest_url);';
wwv_flow_imp.g_varchar2_table(316) := ''||wwv_flow.LF||
'        -- Make sure it''s valid JSON before caching it                        '||wwv_flow.LF||
'        l_manifest_j';
wwv_flow_imp.g_varchar2_table(317) := 'son := json_object_t(l_manifest_clob);'||wwv_flow.LF||
'        apex_collection.add_member('||wwv_flow.LF||
'            p_collection_';
wwv_flow_imp.g_varchar2_table(318) := 'name => c_manifest_collection,'||wwv_flow.LF||
'            p_clob001         => l_manifest_clob);'||wwv_flow.LF||
'    exception'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(319) := '    -- if some temporary issue causes the return to be invalid JSON'||wwv_flow.LF||
'        -- then don''t cache anyt';
wwv_flow_imp.g_varchar2_table(320) := 'hing and we''ll try again next time'||wwv_flow.LF||
'        when json_syntax_error then'||wwv_flow.LF||
'            null;'||wwv_flow.LF||
'        whe';
wwv_flow_imp.g_varchar2_table(321) := 'n json_invalid THEN'||wwv_flow.LF||
'            null;        '||wwv_flow.LF||
'    end ensure_available_catalogs;'||wwv_flow.LF||
'end eba_util_farest';
wwv_flow_imp.g_varchar2_table(322) := '_explorer;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1006762956826253066)
,p_install_id=>wwv_flow_imp.id(1044102358267325500)
,p_name=>'Package'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(1006763070359253066)
,p_script_id=>wwv_flow_imp.id(1006762956826253066)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_UTIL_FAREST_EXPLORER'
);
wwv_flow_imp.component_end;
end;
/
