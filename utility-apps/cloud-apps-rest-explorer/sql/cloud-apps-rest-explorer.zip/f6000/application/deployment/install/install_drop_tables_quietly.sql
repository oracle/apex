prompt --application/deployment/install/install_drop_tables_quietly
begin
--   Manifest
--     INSTALL: INSTALL-Drop Tables Quietly
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>6000
,p_default_id_offset=>36423738932107368
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'declare'||wwv_flow.LF||
'    l_tables apex_t_varchar2 := apex_t_varchar2(''eba_util_farest_catalog'','||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(2) := '                               ''eba_util_farest_cat_baseurl'','||wwv_flow.LF||
'                                      ';
wwv_flow_imp.g_varchar2_table(3) := '          ''eba_util_farest_endpoint_attrs'','||wwv_flow.LF||
'                                                ''eba_uti';
wwv_flow_imp.g_varchar2_table(4) := 'l_farest_endpoint_chobj'','||wwv_flow.LF||
'                                                ''eba_util_farest_endpoints';
wwv_flow_imp.g_varchar2_table(5) := ''');'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- Quietly drop all tables in the list'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    for j in 1..l_tables.count lo';
wwv_flow_imp.g_varchar2_table(6) := 'op'||wwv_flow.LF||
'        begin'||wwv_flow.LF||
'            execute immediate ''drop table ''||l_tables(j)||'' cascade constraints'';'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(7) := '       exception'||wwv_flow.LF||
'            when others then'||wwv_flow.LF||
'                if sqlcode != -942 then'||wwv_flow.LF||
'              ';
wwv_flow_imp.g_varchar2_table(8) := '      raise;'||wwv_flow.LF||
'                end if;'||wwv_flow.LF||
'        end;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(997232930102720901)
,p_install_id=>wwv_flow_imp.id(1023097412459087773)
,p_name=>'Drop Tables Quietly'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
