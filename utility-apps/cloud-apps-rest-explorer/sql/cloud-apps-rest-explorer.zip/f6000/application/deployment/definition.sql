prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 6000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>6000
,p_default_id_offset=>36423738932107368
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'drop table eba_util_farest_catalog cascade constraints;'||wwv_flow.LF||
'drop table eba_util_farest_cat_baseurl casca';
wwv_flow_imp.g_varchar2_table(2) := 'de constraints;'||wwv_flow.LF||
'drop table eba_util_farest_endpoint_attrs cascade constraints;'||wwv_flow.LF||
'drop table eba_util_f';
wwv_flow_imp.g_varchar2_table(3) := 'arest_endpoint_chobj cascade constraints;'||wwv_flow.LF||
'drop table eba_util_farest_endpoints cascade constraints;';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(1023097412459087773)
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
