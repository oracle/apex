prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>6000
,p_default_id_offset=>21004945808237727
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Service Details'
,p_alias=>'SERVICE-DETAILS'
,p_step_title=>'Service Details'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'app.setupCopyHandlersForInteractiveReport("attributes-tab");',
'app.setupCopyHandlersForInteractiveReport("child-objects-tab");'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'th#action,',
'td[headers=action]',
'{',
'  width:60px;',
'  text-align: center !important;',
'}',
'',
'th#action,',
'td[headers=cardinality]',
'{',
'  width:60px;',
'  text-align: center !important;',
'}',
''))
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1025937922672231370)
,p_plug_name=>'Attributes'
,p_static_id=>'attributes'
,p_region_name=>'attributes-tab'
,p_parent_plug_id=>wwv_flow_imp.id(1026939968568550234)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2102002977963900996
,p_plug_display_sequence=>5
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.ID,',
'       a.ENDPOINT_ID,',
'       a.ATTR_NAME,',
'       a.ATTR_TYPE,',
'       apex_escape.html(a.ATTR_LEN) attr_len,',
'       a.ATTR_TITLE,',
'       a.ATTR_DESCRIPTION,',
'       a.ATTR_LOV,',
'       a.LOV_HREF,',
'       case a.ATTR_CONTROL_TYPE',
'         when ''combo_lov'' then ''Popup LOV''',
'         when ''choice'' then ''Select List''',
'         when ''delimited_ids_choice'' then ''Multiselect''',
'         when ''check_box'' then ''Switch''',
'         when ''date''      then ''Date Picker''',
'         else attr_control_type',
'       end as attr_control_type,',
'       a.ATTR_IS_QUERYABLE,',
'       a.ATTR_IS_REQUIRED,',
'       a.ATTR_HAS_DEF_EXPR,',
'       case a.ATTR_ALLOW_CHANGES',
'         when ''ReadOnly'' then ''N''',
'         when ''Always'' then ''Y''',
'         when ''CreateOnly'' then ''On Create''',
'       end as attr_allow_changes,',
'       a.ATTR_IS_PRIMARY_KEY,',
'       a.ATTR_IS_CUSTOM,',
'       a.ALLOWED_OPERATORS,',
'       a.POSITION',
'  from eba_util_farest_endpoint_attrs a',
' where endpoint_id = :P3_ID',
'   and (:P3_SHOW_HIDDEN_ATTRS = ''Y'' ',
'        or ',
'        a.attr_name in (    select column_selector',
'                              from apex_appl_data_profile_cols c',
'                             where (c.application_id,c.data_profile_name) = ',
'                                   (select m.application_id, m.data_profile_name',
'                                      from eba_util_farest_endpoints e',
'                                      left join apex_appl_web_src_modules m ',
'                                             on m.application_id   = e.application_id',
'                                            and m.module_static_id = e.module_static_id',
'                                      where e.id = a.endpoint_id)',
'                             and c.is_hidden = ''No''',
'                        )',
'        )'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P3_ID,P3_SHOW_HIDDEN_ATTRS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Attributes'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1026940766981550242)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_internal_uid=>9107133043978633
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1026942495672550259)
,p_db_column_name=>'ALLOWED_OPERATORS'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Only Operators?'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1026942220549550256)
,p_db_column_name=>'ATTR_ALLOW_CHANGES'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Editable?'
,p_column_html_expression=>'<span style="white-space:nowrap">#ATTR_ALLOW_CHANGES#</span>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1026941785174550252)
,p_db_column_name=>'ATTR_CONTROL_TYPE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Preferred UI'
,p_column_html_expression=>'<span style="white-space:nowrap">#ATTR_CONTROL_TYPE#</span>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1026941467542550249)
,p_db_column_name=>'ATTR_DESCRIPTION'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1026942120222550255)
,p_db_column_name=>'ATTR_HAS_DEF_EXPR'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Defaulted?'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1026942386139550258)
,p_db_column_name=>'ATTR_IS_CUSTOM'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Custom?'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1026942308032550257)
,p_db_column_name=>'ATTR_IS_PRIMARY_KEY'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Remote PK?'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1026941928857550253)
,p_db_column_name=>'ATTR_IS_QUERYABLE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Queryable?'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1026941950751550254)
,p_db_column_name=>'ATTR_IS_REQUIRED'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Required?'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1020780887994578196)
,p_db_column_name=>'ATTR_LEN'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Attr Len'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1032236375191887713)
,p_db_column_name=>'ATTR_LOV'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Attr Lov'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1026941070667550245)
,p_db_column_name=>'ATTR_NAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Attribute Name'
,p_column_html_expression=>'<tt>#ATTR_NAME#</tt>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1026941398686550248)
,p_db_column_name=>'ATTR_TITLE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Label'
,p_column_html_expression=>'<span style="white-space:nowrap">#ATTR_TITLE#</span>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1026941185550550246)
,p_db_column_name=>'ATTR_TYPE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Type'
,p_column_html_expression=>'#ATTR_TYPE#{if ATTR_LEN/}(#ATTR_LEN#){endif/}'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1032236332786887712)
,p_db_column_name=>'ENDPOINT_ID'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Endpoint Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1032236202285887711)
,p_db_column_name=>'ID'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1026941662248550251)
,p_db_column_name=>'LOV_HREF'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'LOV Endpoint'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if LOV_HREF/}<button type="button" title="Copy #ATTR_NAME# LOV endpoint URL to clipboard" aria-label="Copy #ATTR_NAME# LOV endpoint URL to clipboard" data-text="#LOV_HREF#"',
'class="t-Button t-Button--noLabel t-Button--icon">',
'    <span aria-hidden="true" class="t-Icon fa fa-clone"></span>',
'</button>{endif/}'))
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1032236092268887710)
,p_db_column_name=>'POSITION'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Position'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1032261219364915395)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'144276'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'ATTR_NAME:ATTR_TYPE:ATTR_TITLE:ATTR_DESCRIPTION:LOV_HREF:ATTR_CONTROL_TYPE:ATTR_IS_QUERYABLE:ATTR_IS_REQUIRED:ATTR_HAS_DEF_EXPR:ATTR_ALLOW_CHANGES:ATTR_IS_PRIMARY_KEY:ATTR_IS_CUSTOM:ALLOWED_OPERATORS'
,p_sort_column_1=>'POSITION'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1771089799217177442)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'All'
,p_report_seq=>10
,p_report_alias=>'ALL'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'ATTR_NAME:ATTR_TYPE:ATTR_TITLE:ATTR_DESCRIPTION:LOV_HREF:ATTR_CONTROL_TYPE:ATTR_IS_QUERYABLE:ATTR_IS_REQUIRED:ATTR_HAS_DEF_EXPR:ATTR_ALLOW_CHANGES:ATTR_IS_PRIMARY_KEY:ATTR_IS_CUSTOM:ALLOWED_OPERATORS'
,p_sort_column_1=>'POSITION'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1771094140019193361)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'Editable'
,p_report_seq=>10
,p_report_alias=>'EDITABLE'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'ATTR_NAME:ATTR_TYPE:ATTR_TITLE:ATTR_DESCRIPTION:LOV_HREF:ATTR_CONTROL_TYPE:ATTR_IS_QUERYABLE:ATTR_IS_REQUIRED:ATTR_HAS_DEF_EXPR:ATTR_ALLOW_CHANGES:ATTR_IS_PRIMARY_KEY:ATTR_IS_CUSTOM:ALLOWED_OPERATORS'
,p_sort_column_1=>'POSITION'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(1812980322951084529)
,p_report_id=>wwv_flow_imp.id(1771094140019193361)
,p_static_id=>'ir-condition'
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ATTR_ALLOW_CHANGES'
,p_operator=>'!='
,p_expr=>'N'
,p_condition_sql=>'"ATTR_ALLOW_CHANGES" != #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# != ''N''  '
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1771090734405185793)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'Queryable'
,p_report_seq=>10
,p_report_alias=>'QUERYABLE'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'ATTR_NAME:ATTR_TYPE:ATTR_TITLE:ATTR_DESCRIPTION:LOV_HREF:ATTR_CONTROL_TYPE:ATTR_IS_QUERYABLE:ATTR_IS_REQUIRED:ATTR_HAS_DEF_EXPR:ATTR_ALLOW_CHANGES:ATTR_IS_PRIMARY_KEY:ATTR_IS_CUSTOM:ALLOWED_OPERATORS'
,p_sort_column_1=>'POSITION'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(1812982970194088637)
,p_report_id=>wwv_flow_imp.id(1771090734405185793)
,p_static_id=>'ir-condition'
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ATTR_IS_QUERYABLE'
,p_operator=>'='
,p_expr=>'Y'
,p_condition_sql=>'"ATTR_IS_QUERYABLE" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''Y''  '
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1771095271593197768)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'Read-Only'
,p_report_seq=>10
,p_report_alias=>'READONLY'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'ATTR_NAME:ATTR_TYPE:ATTR_TITLE:ATTR_DESCRIPTION:LOV_HREF:ATTR_CONTROL_TYPE:ATTR_IS_QUERYABLE:ATTR_IS_REQUIRED:ATTR_HAS_DEF_EXPR:ATTR_ALLOW_CHANGES:ATTR_IS_PRIMARY_KEY:ATTR_IS_CUSTOM:ALLOWED_OPERATORS'
,p_sort_column_1=>'POSITION'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(1812983794512090414)
,p_report_id=>wwv_flow_imp.id(1771095271593197768)
,p_static_id=>'ir-condition'
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ATTR_ALLOW_CHANGES'
,p_operator=>'='
,p_expr=>'N'
,p_condition_sql=>'"ATTR_ALLOW_CHANGES" = #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# = ''N''  '
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1771096361512202309)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'With LOV'
,p_report_seq=>10
,p_report_alias=>'WITHLOV'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'ATTR_NAME:ATTR_TYPE:ATTR_TITLE:ATTR_DESCRIPTION:LOV_HREF:ATTR_CONTROL_TYPE:ATTR_IS_QUERYABLE:ATTR_IS_REQUIRED:ATTR_HAS_DEF_EXPR:ATTR_ALLOW_CHANGES:ATTR_IS_PRIMARY_KEY:ATTR_IS_CUSTOM:ALLOWED_OPERATORS'
,p_sort_column_1=>'POSITION'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(1812984609729092579)
,p_report_id=>wwv_flow_imp.id(1771096361512202309)
,p_static_id=>'ir-condition'
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'LOV_HREF'
,p_operator=>'is not null'
,p_condition_sql=>'"LOV_HREF" is not null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1026940040061550235)
,p_plug_name=>'Child Objects'
,p_static_id=>'child-objects'
,p_region_name=>'child-objects-tab'
,p_parent_plug_id=>wwv_flow_imp.id(1026939968568550234)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2102002977963900996
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'TABLE'
,p_query_table=>'EBA_UTIL_FAREST_ENDPOINT_CHOBJ'
,p_query_where=>'endpoint_id = :P3_ID'
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'obj_name'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P3_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Child Objects'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1026940167661550236)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_internal_uid=>9106533723978627
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1026940564582550240)
,p_db_column_name=>'CARDINALITY'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Cardinality'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_static_id=>'cardinality'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1026940398086550238)
,p_db_column_name=>'ENDPOINT_ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Endpoint Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1026940313562550237)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1026940673095550241)
,p_db_column_name=>'OBJ_HREF'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Endpoint&nbsp;URL'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<button type="button" title="Copy #OBJ_NAME# child object endpoint URL to clipboard" aria-label="Copy #OBJ_NAME# child object endpoint URL to clipboard" data-text="#OBJ_HREF#"',
'class="t-Button t-Button--noLabel t-Button--icon">',
'    <span aria-hidden="true" class="t-Icon fa fa-clone"></span>',
'</button>'))
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_static_id=>'action'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1026940452440550239)
,p_db_column_name=>'OBJ_NAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Object Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1032234568602847981)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'144010'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'OBJ_HREF:CARDINALITY:OBJ_NAME'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1684003543976035632)
,p_plug_name=>'Help'
,p_static_id=>'help'
,p_region_template_options=>'#DEFAULT#:js-dialog-size480x320'
,p_plug_template=>2674150083631647148
,p_plug_display_sequence=>50
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="info"><p>Use this page to explore the <code>&P3_NAME.</code> data source''s attributes and child objects.</p><p>Click the application icon to return to the data source list...</p></span>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1026939968568550234)
,p_plug_name=>'Tabs'
,p_static_id=>'tabs'
,p_region_name=>'tabs'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>3224648155363603145
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1017839575712581059)
,p_plug_name=>'Title Bar'
,p_static_id=>'title-bar'
,p_plug_display_sequence=>40
,p_plug_display_point=>'AFTER_LOGO'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<span class="apex-logo-text"> -&nbsp; Service Details:  &P3_NAME.</span>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1684003717741035633)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1684003543976035632)
,p_button_name=>'Close'
,p_static_id=>'close'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1684003782956035634)
,p_button_sequence=>60
,p_button_name=>'Help'
,p_static_id=>'help'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--primary'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Help'
,p_button_position=>'BEFORE_NAVIGATION_BAR'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-info-circle-o'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1025939010637231381)
,p_name=>'P3_ID'
,p_item_sequence=>30
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1017839640898581060)
,p_name=>'P3_NAME'
,p_item_sequence=>40
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1766598790210046457)
,p_name=>'P3_SHOW_HIDDEN_ATTRS'
,p_item_sequence=>10
,p_item_display_point=>'BEFORE_NAVIGATION_BAR'
,p_item_default=>'N'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Show Only Visible Attributes;N,Show All Attributes;Y'
,p_cHeight=>1
,p_field_template=>2042262243893469891
,p_item_css_classes=>'u-nowrap'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(1017839843180581062)
,p_computation_sequence=>10
,p_computation_item=>'P3_NAME'
,p_static_id=>'p3-name'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select wsm.module_name',
'from eba_util_farest_endpoints e',
'left join apex_appl_web_src_modules wsm on wsm.module_static_id = e.module_static_id',
'                                        and wsm.application_id  = e.application_id',
'where e.id = :P3_ID',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1684004036755035637)
,p_name=>'On Close Clicked'
,p_static_id=>'on-close-clicked'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1684003717741035633)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1684004217562035638)
,p_event_id=>wwv_flow_imp.id(1684004036755035637)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-close-region'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1684003543976035632)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1684003867556035635)
,p_name=>'On Help Clicked'
,p_static_id=>'on-help-clicked'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1684003782956035634)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1684003959467035636)
,p_event_id=>wwv_flow_imp.id(1684003867556035635)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-open-region'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1684003543976035632)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1766598841637046458)
,p_name=>'When Change Hidden Switch'
,p_static_id=>'when-change-hidden-switch'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_SHOW_HIDDEN_ATTRS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1766599001741046459)
,p_event_id=>wwv_flow_imp.id(1766598841637046458)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1025937922672231370)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1766599310594046462)
,p_name=>'When Tab Changed'
,p_static_id=>'when-tab-changed'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#tabs'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'atabsactivate'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1766599402724046463)
,p_event_id=>wwv_flow_imp.id(1766599310594046462)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    '// Find the active tab and its associated region',
    'let active_tab = apex.region(this.triggeringElement.id).widget().aTabs("getActive");',
    'let active_region = $(''[id$=-tab]'',$(active_tab.panel$));',
    '',
    '// If we have region, find its ID and record that for use in the regions',
    'if(active_region){',
    '    let active_id = $(active_region).attr(''id'');',
    '    if ( active_id == "attributes-tab" ) {',
    '        apex.items.P3_SHOW_HIDDEN_ATTRS.show();',
    '    }',
    '    else {',
    '        apex.items.P3_SHOW_HIDDEN_ATTRS.hide();',
    '    }',
    '}')))).to_clob
);
wwv_flow_imp.component_end;
end;
/
