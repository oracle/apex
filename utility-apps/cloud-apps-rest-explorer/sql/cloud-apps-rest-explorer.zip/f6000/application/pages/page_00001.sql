prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>6000
,p_default_id_offset=>21004945808237727
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Oracle Cloud Apps REST Endpoints'
,p_alias=>'ORACLE-CLOUD-APPS-REST-ENDPOINTS'
,p_step_title=>'Oracle Cloud Apps REST Endpoints'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'app.setupCopyHandlersForInteractiveReport("fa-rest-endpoints-tab");',
'app.setupCopyHandlersForInteractiveReport("all-endpoints-tab");',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'th#action,',
'td[headers=action]',
'{',
'  width:80px;',
'  text-align: center !important;',
'}',
'',
'th#service-endpoint,',
'td[headers=service-endpoint]',
'{',
'  width:50px;',
'  text-align: center !important;',
'}',
'',
'th#all-endpoint-url,',
'td[headers=all-endpoint-url]',
'{',
'  width:50px;',
'  text-align: center !important;',
'}',
'',
'.hidden {',
'   display : none;',
'}'))
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6882918368574508)
,p_plug_name=>'All Endpoints'
,p_static_id=>'all-endpoints'
,p_parent_plug_id=>wwv_flow_imp.id(1526529964808325433)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1526531920231325452)
,p_plug_name=>'Background Progress'
,p_static_id=>'background-progress'
,p_parent_plug_id=>wwv_flow_imp.id(1526529964808325433)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6883460869574513)
,p_plug_name=>'Business Object Attributes'
,p_static_id=>'business-object-attributes'
,p_region_name=>'all-endpoints-tab'
,p_parent_plug_id=>wwv_flow_imp.id(6885708357574536)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'TABLE'
,p_query_table=>'EBA_UTIL_FACAT_ENDPOINT_ATTRS'
,p_query_where=>'BO_ENDPOINT_ID = :P1_SELECTED_BO_ID'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P1_SELECTED_BO_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(6883534377574514)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_internal_uid=>6883534377574514
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6884989970574528)
,p_db_column_name=>'ATTR_ALLOW_CHANGES'
,p_display_order=>150
,p_column_identifier=>'N'
,p_column_label=>'Editable'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6884285043574521)
,p_db_column_name=>'ATTR_DESCRIPTION'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6884668015574525)
,p_db_column_name=>'ATTR_IS_QUERYABLE'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Queryable?'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6884709833574526)
,p_db_column_name=>'ATTR_IS_REQUIRED'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Required?'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6884008782574519)
,p_db_column_name=>'ATTR_LEN'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Length'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6883891760574517)
,p_db_column_name=>'ATTR_NAME'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Name'
,p_column_html_expression=>'<tt>#ATTR_NAME#</tt>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6884178272574520)
,p_db_column_name=>'ATTR_TITLE'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Label'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6883966123574518)
,p_db_column_name=>'ATTR_TYPE'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Type'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6883776390574516)
,p_db_column_name=>'BO_ENDPOINT_ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Bo Endpoint Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(8659833849613903)
,p_db_column_name=>'DATA_PROFILE_COLUMN_NAME'
,p_display_order=>30
,p_column_identifier=>'S'
,p_column_label=>'Data Profile Column Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6883693339574515)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6885386673574532)
,p_db_column_name=>'POSITION'
,p_display_order=>190
,p_column_identifier=>'R'
,p_column_label=>'Position'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(8641600654305263)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'86417'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>10
,p_report_columns=>'ATTR_NAME:ATTR_TYPE:ATTR_LEN:ATTR_TITLE:ATTR_DESCRIPTION:ATTR_IS_QUERYABLE:ATTR_IS_REQUIRED:ATTR_ALLOW_CHANGES'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6885827049574537)
,p_plug_name=>'Business Object Details'
,p_static_id=>'business-object-details'
,p_parent_plug_id=>wwv_flow_imp.id(6885708357574536)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'TABLE'
,p_query_table=>'EBA_UTIL_FACAT_ENDPOINTS'
,p_query_where=>'ID = :P1_SELECTED_BO_ID'
,p_include_rowid_column=>false
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_ajax_items_to_submit=>'P1_SELECTED_BO_ID'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_plug_query_no_data_found=>'Select a Business Object in the List or Tree'
,p_no_data_found_icon_classes=>'fa-building-o'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'OVERLINE', '&PATH.',
  'REMOVE_PADDING', 'N',
  'TITLE', '&NAME.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8661339166613918)
,p_name=>'CATALOG_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CATALOG_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8661603489613921)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8661210494613917)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8661515112613920)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8661460105613919)
,p_name=>'PARENT_BO_ENDPOINT_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PARENT_BO_ENDPOINT_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8661717249613922)
,p_name=>'PATH'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PATH'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6885708357574536)
,p_plug_name=>'Business Object Details Container'
,p_static_id=>'business-object-details-container'
,p_parent_plug_id=>wwv_flow_imp.id(6882918368574508)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6886561958574544)
,p_plug_name=>'Business Object Search'
,p_static_id=>'business-object-search'
,p_parent_plug_id=>wwv_flow_imp.id(6886331738574542)
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>2127905476394690047
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(6886771551574546)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'compact_numbers_threshold', '10000',
  'more_filters_suggestion_chip', 'N',
  'show_total_row_count', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6886681558574545)
,p_name=>'P1_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6886561958574544)
,p_prompt=>'Search'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'collapsed_search_field', 'N',
  'search_type', 'ROW')).to_clob
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6886771551574546)
,p_plug_name=>'Business Objects List'
,p_static_id=>'business-objects-list'
,p_parent_plug_id=>wwv_flow_imp.id(8660363708613908)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3372714138756020509
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.id,',
'       e.catalog_id,',
'       e.parent_bo_endpoint_id,',
'       e.name,',
'       e.description,',
'       e.path',
'  from eba_util_facat_endpoints e',
'  join eba_util_facat_catalogs c on e.catalog_id = c.id',
' where c.release_id = :P1_RELEASE_ID'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'NAME'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_ajax_items_to_submit=>'P1_RELEASE_ID'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_plug_query_no_data_found=>'No business objects match your search'
,p_no_data_found_icon_classes=>'fa-building-o'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_row_selection_type=>'SINGLE'
,p_current_selection_page_item=>'P1_SELECTED_BO_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'DESCRIPTION', '&DESCRIPTION.',
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N',
  'TITLE', '&NAME.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8660522139613910)
,p_name=>'CATALOG_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CATALOG_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8660847957613913)
,p_name=>'DESCRIPTION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPTION'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>50
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8660440213613909)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8660702665613912)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>40
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8660607751613911)
,p_name=>'PARENT_BO_ENDPOINT_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PARENT_BO_ENDPOINT_ID'
,p_data_type=>'NUMBER'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(8660907266613914)
,p_name=>'PATH'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PATH'
,p_data_type=>'VARCHAR2'
,p_display_sequence=>60
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_available_clientside=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8660363708613908)
,p_plug_name=>'Business Objects Results'
,p_static_id=>'business-objects-results'
,p_parent_plug_id=>wwv_flow_imp.id(6886331738574542)
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>3224648155363603145
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6886331738574542)
,p_plug_name=>'Business Objects Tab'
,p_static_id=>'business-objects-tab'
,p_parent_plug_id=>wwv_flow_imp.id(6882918368574508)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>4
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6883046042574509)
,p_plug_name=>'Business Objects Tree'
,p_static_id=>'business-objects-tree'
,p_region_name=>'bo-tree'
,p_parent_plug_id=>wwv_flow_imp.id(8660363708613908)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return apex_string.format(q''~',
'with x as (select e.id, nvl(e.parent_bo_endpoint_id, -1 * p.id) as parent_id, e.path',
'            from eba_util_facat_endpoints e',
'            join eba_util_facat_catalogs c on c.id = e.catalog_id',
'            join eba_util_facat_pillars  p on p.id = c.pillar_id',
'            where c.release_id = :P1_RELEASE_ID',
'            union all',
'            select -1 * id, null, name',
'            from eba_util_facat_pillars',
'            where name in (select distinct p.name',
'                            from eba_util_facat_endpoints e',
'                            join eba_util_facat_catalogs c on c.id = e.catalog_id',
'                            join eba_util_facat_pillars  p on p.id = c.pillar_id',
'                            where c.release_id = :P1_RELEASE_ID)',
')',
'select  distinct id, ',
'        parent_id,',
'        case ',
'                when path like ''/''||chr(37)',
'                then rtrim(regexp_substr(regexp_replace(path,''/\{[^}]+\}/child''), ''/[^/]+/?$''),''/'')',
'                else path',
'        end',
'        as business_object,',
'        upper(',
'            case ',
'                    when path like ''/''||chr(37)',
'                    then rtrim(regexp_substr(regexp_replace(path,''/\{[^}]+\}/child''), ''/[^/]+/?$''),''/'')',
'                    else path',
'            end) as upper_business_object',
'from x',
'connect by prior parent_id = id',
'start with ( ',
'         parent_id is not null',
'    and  (',
'            :P1_SEARCH is null',
'            or (%s)',
'    )       ',
')',
'~'',',
'eba_util_farest_explorer.tokenized_row_search_predicate(',
'    p_search_facet_value => :P1_SEARCH,',
'    p_search_column_name => ''PATH'',',
'    p_search_facet_name  => ''P1_SEARCH''));'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_JSTREE'
,p_ajax_items_to_submit=>'P1_SEARCH,P1_RELEASE_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'activate_node_link_with', 'S',
  'default_icon_css_class', 'icon-tree-folder',
  'icon_type_css_class', 'a-Icon',
  'node_id_column', 'ID',
  'node_label_column', 'BUSINESS_OBJECT',
  'node_value_column', 'ID',
  'order_siblings_by', 'UPPER_BUSINESS_OBJECT',
  'parent_key_column', 'PARENT_ID',
  'selected_node_page_item', 'P1_SELECTED_BO_ID',
  'start_tree_with', 'NULL',
  'tree_hierarchy', 'SQL',
  'tree_tooltip', 'N')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1022785648555589932)
,p_plug_name=>'Endpoints In Use'
,p_static_id=>'endpoints-in-use'
,p_region_name=>'fa-rest-endpoints-tab'
,p_parent_plug_id=>wwv_flow_imp.id(1526529964808325433)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2102002977963900996
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'ABOVE'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case ',
'            when e.id is not null ',
'            then ',
'                apex_page.get_url(',
'                   p_page => 3,',
'                   p_items => ''P3_ID'',',
'                   p_values => e.id,',
'                   p_request => ''IR[attributes]_ALL'')',
'        end as details_url,',
'        apex_page.get_url(',
'           p_page    => 1,',
'           p_items   => ''P1_INGEST_APPLICATION_ID,P1_INGEST_MODULE_STATIC_ID'',',
'           p_values  => wsm.application_id||'',''||wsm.module_static_id,',
'           p_request => ''INGEST'') as refresh_url,',
'           wsm.application_name, ',
'       wsm.application_id, ',
'       wsm.module_static_id, ',
'       wsm.url_endpoint,',
'       case when e.id is null then ''Install'' else ''Refresh'' end available_action',
'from apex_appl_web_src_modules wsm',
'left outer join eba_util_farest_endpoints e on e.module_static_id = wsm.module_static_id',
'                                           and e.application_id  = wsm.application_id',
'where wsm.web_source_type_code = ''NATIVE_ADFBC'''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Endpoints In Use'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1022785824339589933)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'No Oracle Cloud Apps REST data sources defined in any app in the workspace. Add at least one REST data source of type "Oracle Cloud Applications (SaaS) REST Service" to get started...'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_internal_uid=>14403799720316114
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1017838313268581046)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>30
,p_column_identifier=>'M'
,p_column_label=>'Application Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1017838206338581045)
,p_db_column_name=>'APPLICATION_NAME'
,p_display_order=>20
,p_column_identifier=>'L'
,p_column_label=>'Application'
,p_column_html_expression=>'#APPLICATION_NAME# (#APPLICATION_ID#)'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1017840578910581069)
,p_db_column_name=>'AVAILABLE_ACTION'
,p_display_order=>80
,p_column_identifier=>'R'
,p_column_label=>'Action'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span>',
'{case AVAILABLE_ACTION/}',
'   {when Install/}<a class="fa fa-download" ',
'                     title="Download the service definition info for this data source" ',
'                      href="#REFRESH_URL#"></a>',
'   {when Refresh/}<a class="fa fa-repeat" ',
'                     title="Refresh the service definition info for this data source"',
'                     href="#REFRESH_URL#"></a>',
'{endcase/}',
'</span>'))
,p_column_type=>'STRING'
,p_static_id=>'action'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1017839452065581058)
,p_db_column_name=>'DETAILS_URL'
,p_display_order=>10
,p_column_identifier=>'P'
,p_column_label=>'Details Url'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1022786760181589943)
,p_db_column_name=>'MODULE_STATIC_ID'
,p_display_order=>40
,p_column_identifier=>'G'
,p_column_label=>'REST Data Source Static Id'
,p_column_html_expression=>'<div>{if DETAILS_URL/}<b><a href="#DETAILS_URL#" rel="noopener noreferrer">{endif/}#MODULE_STATIC_ID#{if DETAILS_URL/}</a></b>{endif/}</div>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1017840480080581068)
,p_db_column_name=>'REFRESH_URL'
,p_display_order=>70
,p_column_identifier=>'Q'
,p_column_label=>'Refresh Url'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1022787093394589946)
,p_db_column_name=>'URL_ENDPOINT'
,p_display_order=>50
,p_column_identifier=>'J'
,p_column_label=>'Endpoint&nbsp;URL'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<button type="button" title="Copy #MODULE_STATIC_ID# endpoint URL to clipboard" aria-label="Copy #MODULE_STATIC_ID# endpoint URL to clipboard" data-text="#URL_ENDPOINT#"',
'class="t-Button t-Button--noLabel t-Button--icon">',
'    <span aria-hidden="true" class="t-Icon fa fa-clone"></span>',
'</button>'))
,p_column_type=>'STRING'
,p_static_id=>'service-endpoint'
,p_use_as_row_header=>'N'
,p_available_clientside=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1771102284131274579)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'For All Apps'
,p_report_seq=>10
,p_report_alias=>'9043154'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'AVAILABLE_ACTION:URL_ENDPOINT:MODULE_STATIC_ID:APPLICATION_NAME'
,p_sort_column_1=>'MODULE_STATIC_ID'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1771103197146280938)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'By App'
,p_report_seq=>10
,p_report_alias=>'9043163'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'AVAILABLE_ACTION:URL_ENDPOINT:MODULE_STATIC_ID:APPLICATION_NAME'
,p_sort_column_1=>'MODULE_STATIC_ID'
,p_sort_direction_1=>'ASC'
,p_break_on=>'APPLICATION_NAME'
,p_break_enabled_on=>'APPLICATION_NAME'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1017858250079582129)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'94763'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'AVAILABLE_ACTION:URL_ENDPOINT:MODULE_STATIC_ID:APPLICATION_NAME'
,p_sort_column_1=>'MODULE_STATIC_ID'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1021048483245254020)
,p_plug_name=>'Help'
,p_static_id=>'help'
,p_region_template_options=>'#DEFAULT#:js-dialog-size480x320'
,p_plug_template=>2674150083631647148
,p_plug_display_sequence=>80
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="info">',
'    <p>All the <em>Oracle Cloud Application (SaaS) REST Service </em> data sources in your workspace appear on the <em>Endpoints In Use</em> tab.</p>',
'    <p>All endpoints available from the Fusion Apps pillars in use show on the <em>All Endpoints</em> tab.</p>',
'    <p>After downloading the description of an in-use data source, click its name to explore its attributes and child objects...</p>',
'</span>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1044099831873325012)
,p_plug_name=>'Oracle Cloud Apps REST Describe Explorer'
,p_static_id=>'oracle-cloud-apps-rest-describe-explorer'
,p_plug_display_sequence=>10
,p_plug_display_point=>'AFTER_LOGO'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<span class="apex-logo-text"> -&nbsp; REST Data Sources</span>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(2977568824305392277)
,p_name=>'Show Progress'
,p_static_id=>'show-progress'
,p_region_name=>'background-progress-tab'
,p_parent_plug_id=>wwv_flow_imp.id(1526531920231325452)
,p_template=>4502917002193490937
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'        case bgp.process_name',
'             when ''On Download Services'' ',
'             then ''Remaining in-use service descriptions''',
'             when ''Install Catalog in Background''',
'             then ''Installing catalog for release ''',
'                  ||regexp_substr(bgp.context_value,''^[^:]+'')',
'                  ||'' ''',
'                  ||regexp_substr(bgp.context_value,''[^:]+$'',1,1)',
'                  ||'' pillar''',
'        end as refresh_task,',
'        bgp.status_message,  ',
'        case when bgp.sofar is not null and bgp.totalwork is not null',
'             then round(bgp.sofar/bgp.totalwork*100)||''%''',
'        end progress,',
'        round(bgp.sofar/bgp.totalwork*100) progress_bar',
'from apex_appl_page_bg_proc_status bgp',
'where bgp.process_name in (''Install Catalog in Background'', ''On Download Services'')',
'and bgp.status_code   in ( ''ENQUEUED'',''SCHEDULED'', ''EXECUTING'', ''FAILED'')',
'and bgp.application_id = :APP_ID',
'and bgp.page_id in (1,2)'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2540130677583398057
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No background activity happening at the moment'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1550608805566411260)
,p_query_column_id=>3
,p_column_alias=>'PROGRESS'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1550609201496411261)
,p_query_column_id=>4
,p_column_alias=>'PROGRESS_BAR'
,p_column_display_sequence=>30
,p_column_heading=>'Progress'
,p_column_format=>'PCT_GRAPH::#fb0b0b:100'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_report_column_width=>100
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1526532332217325457)
,p_query_column_id=>1
,p_column_alias=>'REFRESH_TASK'
,p_column_display_sequence=>10
,p_column_heading=>'Download Task'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_report_column_width=>400
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1526532434019325458)
,p_query_column_id=>2
,p_column_alias=>'STATUS_MESSAGE'
,p_column_display_sequence=>50
,p_column_heading=>'Status Message'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1526529964808325433)
,p_plug_name=>'Tabs'
,p_static_id=>'tabs'
,p_region_name=>'tabs'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-TabsRegion-mod--simple'
,p_plug_template=>3224648155363603145
,p_plug_display_sequence=>50
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1684004529187035642)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1021048483245254020)
,p_button_name=>'Close'
,p_static_id=>'close'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1526534248404325476)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1022785648555589932)
,p_button_name=>'Download_Remaining_Service_Descriptions_in_Background'
,p_static_id=>'download-remaining-service-descriptions-in-background'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Download Remaining Service Descriptions In Background'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * ',
'from(select application_id, module_static_id',
'       from apex_appl_web_src_modules',
'      where web_source_type_code = ''NATIVE_ADFBC''',
'      minus',
'     select application_id, module_static_id',
'       from eba_util_farest_endpoints)',
'fetch first row only'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-cloud-download'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1684004276766035639)
,p_button_sequence=>40
,p_button_name=>'Help'
,p_static_id=>'help'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--primary'
,p_button_template_id=>2350584059425431644
,p_button_image_alt=>'Help'
,p_button_position=>'BEFORE_NAVIGATION_BAR'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-info-circle-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7237229516587805)
,p_button_sequence=>20
,p_button_name=>'MANAGE_CATALOGS'
,p_static_id=>'manage-catalogs'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Manage Catalogs'
,p_button_position=>'BEFORE_NAVIGATION_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-file-cabinet'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1526531413311325447)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1022785648555589932)
,p_button_name=>'Refresh_Endpoints_in_Use'
,p_static_id=>'refresh-endpoints-in-use'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Refresh List'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1526532029324325454)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2977568824305392277)
,p_button_name=>'Refresh_Progress_Display'
,p_static_id=>'refresh-progress-display'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2084305881903810008
,p_button_image_alt=>'Refresh Progress Display'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'margin-top-md  margin-bottom-md '
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1017838727401581051)
,p_name=>'P1_INGEST_APPLICATION_ID'
,p_item_sequence=>20
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1017838887696581052)
,p_name=>'P1_INGEST_MODULE_STATIC_ID'
,p_item_sequence=>40
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8662050168613925)
,p_name=>'P1_RELEASE_ID'
,p_item_sequence=>10
,p_item_display_point=>'BEFORE_NAVIGATION_BAR'
,p_prompt=>'Release Id'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Release ''||name as name, id',
'from eba_util_facat_releases',
'union all',
'select ''< No Catalog >'', -1',
'from dual',
'where not exists (',
'    select null',
'      from eba_util_facat_endpoints',
'      fetch first row only)',
'order by name'))
,p_cHeight=>1
,p_field_template=>2042262243893469891
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'U'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6883129737574510)
,p_name=>'P1_SELECTED_BO_ID'
,p_item_sequence=>70
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1526534166845325475)
,p_name=>'P1_TAB_ACTIVATED'
,p_item_sequence=>60
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(8662190799613926)
,p_computation_sequence=>10
,p_computation_item=>'P1_RELEASE_ID'
,p_static_id=>'p1-release-id'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id',
'from (',
'    select id, name',
'    from eba_util_facat_releases',
'    union all',
'    select -1, null',
'    from dual',
'    where not exists (',
'        select null',
'          from eba_util_facat_endpoints',
'          fetch first row only)',
')',
'order by name',
'fetch first row only'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1526532126853325455)
,p_name=>'On Refresh Progress'
,p_static_id=>'on-refresh-progress'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1526532029324325454)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1526532233359325456)
,p_event_id=>wwv_flow_imp.id(1526532126853325455)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2977568824305392277)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(6883249839574511)
,p_name=>'On Tree Selection Changed'
,p_static_id=>'on-tree-selection-changed'
,p_event_sequence=>70
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(6883046042574509)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_JSTREE|REGION TYPE|treeviewselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6883316448574512)
,p_event_id=>wwv_flow_imp.id(6883249839574511)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Assign Selected BO ID'
,p_static_id=>'assign-selected-bo-id'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_SELECTED_BO_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_expression', 'apex.region("bo-tree").call("getSelectedNodes")[0]?.id',
  'suppress_change_event', 'N',
  'type', 'JAVASCRIPT_EXPRESSION')).to_clob
,p_stop_execution_on_error=>'N'
,p_wait_for_result=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(6885410208574533)
,p_event_id=>wwv_flow_imp.id(6883249839574511)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_name=>'Refresh Business Object Attributes'
,p_static_id=>'refresh-business-object-attributes'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6883460869574513)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8661903722613924)
,p_event_id=>wwv_flow_imp.id(6883249839574511)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'Refresh Business Object Details'
,p_static_id=>'refresh-business-object-details'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6885827049574537)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1684004720879035643)
,p_name=>'When Close Clicked'
,p_static_id=>'when-close-clicked'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1684004529187035642)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1684004785107035644)
,p_event_id=>wwv_flow_imp.id(1684004720879035643)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-close-region'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1021048483245254020)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1684004418166035640)
,p_name=>'When Help Clicked'
,p_static_id=>'when-help-clicked'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1684004276766035639)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1684004426818035641)
,p_event_id=>wwv_flow_imp.id(1684004418166035640)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-open-region'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1021048483245254020)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8661044592613915)
,p_name=>'When List Selection Changed'
,p_static_id=>'when-list-selection-changed'
,p_event_sequence=>100
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(6886771551574546)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8661102197613916)
,p_event_id=>wwv_flow_imp.id(8661044592613915)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Refresh Business Object Attributes'
,p_static_id=>'refresh-business-object-attributes'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6883460869574513)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8661896942613923)
,p_event_id=>wwv_flow_imp.id(8661044592613915)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Refresh Business Object Details'
,p_static_id=>'refresh-business-object-details'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6885827049574537)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8659929214613904)
,p_name=>'When Manage Catalogs Dialog Closed'
,p_static_id=>'when-manage-catalogs-dialog-closed'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(7237229516587805)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8660082976613905)
,p_event_id=>wwv_flow_imp.id(8659929214613904)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Refresh Hidden Classic Report'
,p_static_id=>'refresh-hidden-classic-report'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6883046042574509)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1684003041376035627)
,p_name=>'When Refresh Endpoints in Use Clicked'
,p_static_id=>'when-refresh-endpoints-in-use-clicked'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1526531413311325447)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1684003180093035628)
,p_event_id=>wwv_flow_imp.id(1684003041376035627)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-refresh'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1022785648555589932)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8662267130613927)
,p_name=>'When Release Changed'
,p_static_id=>'when-release-changed'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_RELEASE_ID'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8662358374613928)
,p_event_id=>wwv_flow_imp.id(8662267130613927)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Refresh List'
,p_static_id=>'refresh-list'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6886771551574546)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8662416678613929)
,p_event_id=>wwv_flow_imp.id(8662267130613927)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Refresh Tree'
,p_static_id=>'refresh-tree'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6883046042574509)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8660183853613906)
,p_name=>'When Results Refreshed'
,p_static_id=>'when-results-refreshed'
,p_event_sequence=>90
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(6886561958574544)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_FACETED_SEARCH|REGION TYPE|facetschange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8660206767613907)
,p_event_id=>wwv_flow_imp.id(8660183853613906)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Refresh Tree'
,p_static_id=>'refresh-tree'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(6883046042574509)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'maintain_pagination', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1526533943991325473)
,p_name=>'When Tab Changed'
,p_static_id=>'when-tab-changed'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#tabs'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'atabsactivate'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1526534093927325474)
,p_event_id=>wwv_flow_imp.id(1526533943991325473)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_static_id=>'native-javascript-code'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'js_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    '// Find the active tab and its associated region',
    'let active_tab = apex.region(this.triggeringElement.id).widget().aTabs("getActive");',
    'let active_region = $(''[id$=-tab]'',$(active_tab.panel$));',
    '',
    '// If we have region, find its ID and record that for use in the regions',
    'if(active_region){',
    '    let active_id = $(active_region).attr(''id'');',
    '    apex.items.P1_TAB_ACTIVATED.setValue(active_id);',
    '',
    '    // If we want to auto refresh...',
    '    if( active_id == "background-progress-tab" ){',
    '        // If we can refresh the current region;',
    '        if( active_id && apex.regions[active_id] && apex.regions[active_id].refresh ){        ',
    '            apex.regions[active_id].refresh();',
    '        }',
    '    }',
    '}')))).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1526531295670325446)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(1526531148306325445)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Call Refresh Catalog'
,p_static_id=>'call-refresh-catalog'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'package', 'EBA_UTIL_FAREST_EXPLORER',
  'package_method', 'REFRESH_CATALOG',
  'type', 'PLSQL_PACKAGE')).to_clob
,p_internal_uid=>659744374017019520
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1017839035784581054)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(1017838969035581053)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Describe and Ingest JSON'
,p_static_id=>'describe-and-ingest-json'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'package', 'EBA_UTIL_FAREST_EXPLORER',
  'package_method', 'INGEST_JSON_DESCRIBE',
  'type', 'PLSQL_PACKAGE')).to_clob
,p_internal_uid=>9457011165307235
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(1017839135362581055)
,p_page_process_id=>wwv_flow_imp.id(1017839035784581054)
,p_page_id=>1
,p_name=>'p_application_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P1_INGEST_APPLICATION_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(1017839293120581056)
,p_page_process_id=>wwv_flow_imp.id(1017839035784581054)
,p_page_id=>1
,p_name=>'p_module_static_id'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P1_INGEST_MODULE_STATIC_ID'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1526531733483325451)
,p_process_sequence=>30
,p_parent_process_id=>wwv_flow_imp.id(1526531538955325449)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Download Missing Descriptions'
,p_static_id=>'download-missing-descriptions'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'package', 'EBA_UTIL_FAREST_EXPLORER',
  'package_method', 'INGEST_JSON_FOR_DATA_SOURCES',
  'type', 'PLSQL_PACKAGE')).to_clob
,p_internal_uid=>659744811830019525
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1017838969035581053)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'If Ingest Link Clicked...'
,p_static_id=>'if-ingest-link-clicked'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'run_in_background', 'N')).to_clob
,p_process_when=>'INGEST'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>9456944416307234
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1526531538955325449)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'On Download Services'
,p_static_id=>'on-download-services'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'executions_limit', '1',
  'run_in_background', 'Y',
  'serialize', 'N',
  'submit_immediately', 'N',
  'temporary_file_handling', 'IGNORE')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1526534248404325476)
,p_internal_uid=>659744617302019523
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1526531148306325445)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'On Refresh Catalog'
,p_static_id=>'on-refresh-catalog'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'executions_limit', '1',
  'run_in_background', 'Y',
  'serialize', 'N',
  'submit_immediately', 'N',
  'temporary_file_handling', 'IGNORE')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>659744226653019519
);
wwv_flow_imp.component_end;
end;
/
