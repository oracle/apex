prompt --application/shared_components/files/app_css
begin
--   Manifest
--     APP STATIC FILES: 6000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>6000
,p_default_id_offset=>21004945808237727
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E696E666F207B0A202020666F6E742D73697A653A20766172282D2D75742D626173652D666F6E742D73697A652C203172656D293B0A7D0A0A2E6E6F77726170207B0A20202077686974652D73706163653A206E6F777261703B0A7D0A0A3A726F6F7420';
wwv_flow_imp.g_varchar2_table(2) := '7B0A202020202D2D75742D626F64792D636F6E74656E742D70616464696E672D783A20313070783B0A202020202D2D75742D626F64792D636F6E74656E742D70616464696E672D793A203570783B0A7D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(1686260990448653073)
,p_file_name=>'app.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
