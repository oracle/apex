prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>6000
,p_default_id_offset=>21004945808237727
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(1043803803168324819)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
,p_version_scn=>37167715867415
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(1044098927428325009)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Oracle Cloud Apps REST Endpoints'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
