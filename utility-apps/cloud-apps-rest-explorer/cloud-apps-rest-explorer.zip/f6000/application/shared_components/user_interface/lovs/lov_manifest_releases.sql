prompt --application/shared_components/user_interface/lovs/lov_manifest_releases
begin
--   Manifest
--     LOV_MANIFEST_RELEASES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>6000
,p_default_id_offset=>21004945808237727
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(3389174268180448)
,p_lov_name=>'LOV_MANIFEST_RELEASES'
,p_location=>'JSON_COLLECTION'
,p_array_column_id=>wwv_flow_imp.id(3367354751899470)
,p_document_source_id=>wwv_flow_imp.id(3366049961899458)
,p_return_column_name=>'NAME'
,p_display_column_name=>'NAME'
,p_default_sort_column_name=>'NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>83424757
);
wwv_flow_imp.component_end;
end;
/
