prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 6000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>6000
,p_default_id_offset=>1802454858096775
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_theme_style(
 p_id=>wwv_flow_imp.id(1008577344343401067)
,p_theme_id=>42
,p_name=>'Vita REST Explorer'
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_FILES#less/theme/Vita.less'
,p_theme_roller_config=>'{"classes":[],"vars":{"@g_Accent-BG":"#403c39","@g_Button-BG":"#ece9e7","@g_Button-Text":"#000000","@l_Button-Primary-BG":"#403c39","@l_Button-Primary-Text":"#ffffff"},"customCSS":"","useCustomLess":"N"}'
,p_theme_roller_output_file_url=>'#THEME_DB_FILES#1006774889485304292.css'
,p_theme_roller_read_only=>false
);
wwv_flow_imp.component_end;
end;
/
