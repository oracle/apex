prompt --application/shared_components/json_source/available_catalogs_by_release
begin
--   Manifest
--     DOCUMENT SOURCE: Available Catalogs by Release
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>6000
,p_default_id_offset=>21004945808237727
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_document_source(
 p_id=>wwv_flow_imp.id(3366049961899458)
,p_name=>'Available Catalogs by Release'
,p_static_id=>'available_catalogs_by_release'
,p_document_source_type=>'JSON_TABLE'
,p_location=>'LOCAL'
,p_object_name=>'EBA_UTIL_FACAT_MANIFEST'
,p_data_profile_id=>wwv_flow_imp.id(3366168094899458)
,p_version_scn=>83390063
);
wwv_flow_imp.component_end;
end;
/
