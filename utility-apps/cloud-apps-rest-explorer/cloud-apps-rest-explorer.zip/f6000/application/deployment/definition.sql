prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 6000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>6000
,p_default_id_offset=>21004945808237727
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(1044102358267325500)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop table eba_util_farest_catalog cascade constraints;',
'drop table eba_util_farest_cat_baseurl cascade constraints;',
'drop table eba_util_farest_endpoint_attrs cascade constraints;',
'drop table eba_util_farest_endpoint_chobj cascade constraints;',
'drop table eba_util_farest_endpoints cascade constraints;'))
);
wwv_flow_imp.component_end;
end;
/
