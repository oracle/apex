prompt --application/deployment/install/install_views
begin
--   Manifest
--     INSTALL: INSTALL-Views
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>6000
,p_default_id_offset=>21004945808237727
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3374910208936683)
,p_install_id=>wwv_flow_imp.id(1044102358267325500)
,p_name=>'Views'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'  CREATE OR REPLACE FORCE EDITIONABLE VIEW "EBA_UTIL_FACAT_MANIFEST" ("MANIFEST_JSON") AS ',
'  select nvl(c.clob001,''{"releases":[]}'') as manifest_json',
'from dual',
'left join apex_collections c ',
'       on c.collection_name = ''EBA_UTIL_FACAT_MANIFEST''',
'fetch first row only;'))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(3375013424936685)
,p_script_id=>wwv_flow_imp.id(3374910208936683)
,p_object_owner=>'#OWNER#'
,p_object_type=>'VIEW'
,p_object_name=>'EBA_UTIL_FACAT_MANIFEST'
);
wwv_flow_imp.component_end;
end;
/
