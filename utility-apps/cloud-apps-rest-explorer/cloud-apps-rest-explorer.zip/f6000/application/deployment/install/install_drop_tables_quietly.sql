prompt --application/deployment/install/install_drop_tables_quietly
begin
--   Manifest
--     INSTALL: INSTALL-Drop Tables Quietly
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>6000
,p_default_id_offset=>21004945808237727
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1018237875910958628)
,p_install_id=>wwv_flow_imp.id(1044102358267325500)
,p_name=>'Drop Tables Quietly'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_tables apex_t_varchar2 := apex_t_varchar2(''eba_util_farest_catalog'',',
'                                                ''eba_util_farest_cat_baseurl'',',
'                                                ''eba_util_farest_endpoint_attrs'',',
'                                                ''eba_util_farest_endpoint_chobj'',',
'                                                ''eba_util_farest_endpoints'');',
'begin',
'    --',
'    -- Quietly drop all tables in the list',
'    --',
'    for j in 1..l_tables.count loop',
'        begin',
'            execute immediate ''drop table ''||l_tables(j)||'' cascade constraints'';',
'        exception',
'            when others then',
'                if sqlcode != -942 then',
'                    raise;',
'                end if;',
'        end;',
'    end loop;',
'end;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
