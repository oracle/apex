prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>6000
,p_default_id_offset=>21004945808237727
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Manage Catalogs'
,p_alias=>'MANAGE-CATALOGS'
,p_page_mode=>'MODAL'
,p_step_title=>'Manage Catalogs'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(function () {',
'    apex.actions.add([',
'    {',
'        name: "catalog-install",',
'        label: "Install",',
'        iconType: "fa",',
'        icon: "fa-file-cabinet",',
'        action: function( event, element, args)',
'        {',
'            apex.items.P2_SELECTED_RELEASE.value = args.release;',
'            apex.items.P2_SELECTED_PILLAR.value  = args.pillar;',
'            apex.items.P2_SELECTED_ACTION.value  = ''INSTALL'';',
'            $("body").trigger("manage-catalog-event");',
'        }',
'    },',
'    {',
'        name: "catalog-uninstall",',
'        label: "Uninstall",',
'        iconType: "fa",',
'        icon: "fa-file-cabinet",',
'        action: function( event, element, args)',
'        {',
'            apex.items.P2_SELECTED_RELEASE.value = args.release;',
'            apex.items.P2_SELECTED_PILLAR.value  = args.pillar;',
'            apex.items.P2_SELECTED_ACTION.value  = ''UNINSTALL'';',
'            $("body").trigger("manage-catalog-event");',
'        }',
'    }',
'    ]);',
'});'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7236888496587801)
,p_plug_name=>'Pillars'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_location=>'JSON_COLLECTION'
,p_array_column_id=>wwv_flow_imp.id(3367979528899470)
,p_document_source_id=>wwv_flow_imp.id(3366049961899458)
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d.NAME,',
'       d.PILLAR_NAME,',
'       case',
'            when c.id             is not null then ''INSTALLED''',
'            when bgp.execution_id is not null then ''INSTALLING''',
'            else                                   ''AVAILABLE''',
'       end as status',
'  from #APEX$SOURCE_DATA# d',
'  left join eba_util_facat_releases r  on r.name = d.name',
'  left join eba_util_facat_pillars  p  on p.name = d.pillar_name',
'  left join apex_appl_page_bg_proc_status bgp on bgp.process_name = ''Install Catalog in Background''',
'                                              and regexp_substr(bgp.context_value,''^[^:]+'') = d.name',
'                                              and regexp_substr(bgp.context_value,''[^:]+$'',1,1) = d.pillar_name',
'                                              and bgp.status_code   in ( ''ENQUEUED'',''SCHEDULED'', ''EXECUTING'')',
'                                              and bgp.application_id = :APP_ID',
'                                              and bgp.page_id        = 2',
'  left join eba_util_facat_catalogs c  on r.id   = c.release_id',
'                                      and p.id   = c.pillar_id',
'where d.name = :P2_RELEASE'))
,p_source_post_processing=>'SQL'
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_ajax_items_to_submit=>'P2_RELEASE'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'BADGE_COL_WIDTH', 't-ContentRow-badge--md',
  'BADGE_LABEL', 'Status',
  'BADGE_LABEL_DISPLAY', 'N',
  'BADGE_VALUE', 'STATUS',
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'Y',
  'HIDE_BORDERS', 'N',
  'REMOVE_PADDING', 'N',
  'TITLE', '&PILLAR_NAME.')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3184812306459122)
,p_name=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3184903601459123)
,p_name=>'PILLAR_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PILLAR_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(3185014612459124)
,p_name=>'STATUS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'STATUS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>30
,p_is_group=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7237370233587806)
,p_name=>'P2_RELEASE'
,p_item_sequence=>10
,p_prompt=>'Release'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MANIFEST_RELEASES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7238494628587817)
,p_name=>'P2_SELECTED_RELEASE'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7238594074587818)
,p_name=>'P2_SELECTED_PILLAR'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7238643166587819)
,p_name=>'P2_SELECTED_ACTION'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7239073974587823)
,p_name=>'P2_ERROR_MESSAGE'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9704890650832724)
,p_name=>'P2_BACKGROUND_CONTEXT'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(3184614758459120)
,p_computation_sequence=>10
,p_computation_item=>'P2_RELEASE'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_context   apex_exec.t_context;',
'    l_columns   apex_exec.t_columns;',
'    l_order_bys apex_exec.t_order_bys;',
'begin',
'    apex_exec.add_column(p_columns     => l_columns,',
'                         p_column_name => ''NAME'');',
'    apex_exec.add_order_by(p_order_bys => l_order_bys,',
'                           p_column_name => ''NAME'');',
'    l_context := apex_exec.open_query_context(',
'                    p_location              => apex_exec.c_location_json_source,',
'                    p_json_source_static_id => ''available_catalogs_by_release'',',
'                    p_array_column_name     => ''RELEASES'',',
'                    p_columns               => l_columns,',
'                    p_order_bys             => l_order_bys);',
'    while apex_exec.next_row(l_context) loop',
'        return apex_exec.get_varchar2(l_context,''NAME'');',
'    end loop;',
'end;'))
,p_compute_when=>'P2_RELEASE'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7237447973587807)
,p_name=>'On Change Release'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2_RELEASE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7237566136587808)
,p_event_id=>wwv_flow_imp.id(7237447973587807)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7236888496587801)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7238732164587820)
,p_name=>'On Catalog Action'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'body'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'manage-catalog-event'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7239140699587824)
,p_event_id=>wwv_flow_imp.id(7238732164587820)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Prepare for Catalog Action'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P2_ERROR_MESSAGE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7238874960587821)
,p_event_id=>wwv_flow_imp.id(7238732164587820)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Perform Catalog Action'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'CATALOG_ACTION'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9703357218832709)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Handle Catalog Action'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CATALOG_ACTION'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>9703357218832709
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3185170980459125)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Ensure Available Catalogs'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'EBA_UTIL_FAREST_EXPLORER'
,p_attribute_04=>'ENSURE_AVAILABLE_CATALOGS'
,p_internal_uid=>3185170980459125
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9703491380832710)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(9703357218832709)
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'If Installing...'
,p_attribute_01=>'N'
,p_process_when=>'P2_SELECTED_ACTION'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'INSTALL'
,p_internal_uid=>9703491380832710
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9704902409832725)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(9703491380832710)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Compute Background Context'
,p_process_sql_clob=>':P2_BACKGROUND_CONTEXT := :P2_SELECTED_RELEASE||'':''||:P2_SELECTED_PILLAR;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>9704902409832725
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9703579444832711)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(9703357218832709)
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Else If Uninstalling...'
,p_attribute_01=>'N'
,p_process_when=>'P2_SELECTED_ACTION'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'UNINSTALL'
,p_internal_uid=>9703579444832711
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9703636835832712)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(9703491380832710)
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Install Catalog in Background'
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_04=>'IGNORE'
,p_attribute_07=>'P2_BACKGROUND_CONTEXT'
,p_attribute_08=>'ERROR'
,p_attribute_09=>'N'
,p_process_success_message=>'Release &P2_SELECTED_RELEASE. &P2_SELECTED_PILLAR. pillar installing in background'
,p_internal_uid=>9703636835832712
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9703735388832713)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(9703636835832712)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Install Using Manage Catalogs'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'EBA_UTIL_FAREST_EXPLORER'
,p_attribute_04=>'MANAGE_CATALOGS'
,p_internal_uid=>9703735388832713
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(9703973456832715)
,p_page_process_id=>wwv_flow_imp.id(9703735388832713)
,p_page_id=>2
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P2_ERROR_MESSAGE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(9704029696832716)
,p_page_process_id=>wwv_flow_imp.id(9703735388832713)
,p_page_id=>2
,p_name=>'p_release'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P2_SELECTED_RELEASE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(9704113633832717)
,p_page_process_id=>wwv_flow_imp.id(9703735388832713)
,p_page_id=>2
,p_name=>'p_pillar'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P2_SELECTED_PILLAR'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(9704286763832718)
,p_page_process_id=>wwv_flow_imp.id(9703735388832713)
,p_page_id=>2
,p_name=>'p_operation'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'P2_SELECTED_ACTION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9704365339832719)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(9703579444832711)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Uninstall Using Manage Catalogs'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'EBA_UTIL_FAREST_EXPLORER'
,p_attribute_04=>'MANAGE_CATALOGS'
,p_process_error_message=>'&P2_ERROR_MESSAGE.'
,p_process_success_message=>'Release &P2_SELECTED_RELEASE. &P2_SELECTED_PILLAR. pillar uninstalled'
,p_internal_uid=>9704365339832719
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(9704477578832720)
,p_page_process_id=>wwv_flow_imp.id(9704365339832719)
,p_page_id=>2
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P2_ERROR_MESSAGE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(9704560880832721)
,p_page_process_id=>wwv_flow_imp.id(9704365339832719)
,p_page_id=>2
,p_name=>'p_release'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P2_SELECTED_RELEASE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(9704687150832722)
,p_page_process_id=>wwv_flow_imp.id(9704365339832719)
,p_page_id=>2
,p_name=>'p_pillar'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P2_SELECTED_PILLAR'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(9704746115832723)
,p_page_process_id=>wwv_flow_imp.id(9704365339832719)
,p_page_id=>2
,p_name=>'p_operation'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'P2_SELECTED_ACTION'
);
wwv_flow_imp_page.create_component_action(
 p_id=>wwv_flow_imp.id(7238183861587814)
,p_region_id=>wwv_flow_imp.id(7236888496587801)
,p_position_id=>362316004162771045
,p_display_sequence=>10
,p_template_id=>362317865359806322
,p_label=>unistr('\22EE')
,p_button_display_type=>'TEXT'
,p_is_hot=>false
,p_show_as_disabled=>false
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(7238243431587815)
,p_component_action_id=>wwv_flow_imp.id(7238183861587814)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Install'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$catalog-install?release=&NAME.&pillar=&PILLAR_NAME.'
,p_icon_css_classes=>'fa-file-cabinet'
,p_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_condition_expr1=>'STATUS'
,p_condition_expr2=>'AVAILABLE'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp_page.create_comp_menu_entry(
 p_id=>wwv_flow_imp.id(7238349927587816)
,p_component_action_id=>wwv_flow_imp.id(7238183861587814)
,p_menu_entry_type=>'ENTRY'
,p_label=>'Uninstall'
,p_display_sequence=>20
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#action$catalog-uninstall?release=&NAME.&pillar=&PILLAR_NAME.'
,p_icon_css_classes=>'fa-file-cabinet'
,p_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_condition_expr1=>'STATUS'
,p_condition_expr2=>'INSTALLED'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp.component_end;
end;
/
