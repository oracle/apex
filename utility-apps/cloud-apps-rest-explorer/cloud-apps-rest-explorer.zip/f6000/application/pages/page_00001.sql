prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>6000
,p_default_id_offset=>36423738932107368
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Oracle Cloud Apps REST Endpoints'
,p_alias=>'ORACLE-CLOUD-APPS-REST-ENDPOINTS'
,p_step_title=>'Oracle Cloud Apps REST Endpoints'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'app.setupCopyHandlersForInteractiveReport("fa-rest-endpoints-tab");',
'app.setupCopyHandlersForInteractiveReport("all-endpoints-tab");',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'th#action,',
'td[headers=action]',
'{',
'  width:80px;',
'  text-align: center !important;',
'}',
'',
'th#service-endpoint,',
'td[headers=service-endpoint]',
'{',
'  width:50px;',
'  text-align: center !important;',
'}',
'',
'th#all-endpoint-url,',
'td[headers=all-endpoint-url]',
'{',
'  width:50px;',
'  text-align: center !important;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1000043537437016293)
,p_plug_name=>'Help'
,p_region_template_options=>'#DEFAULT#:js-dialog-size480x320'
,p_plug_template=>wwv_flow_imp.id(1022877251975087138)
,p_plug_display_sequence=>100
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span class="info">',
'    <p>All the <em>Oracle Cloud Application (SaaS) REST Service </em> data sources in your workspace appear on the <em>Endpoints In Use</em> tab.</p>',
'    <p>All endpoints available from the Fusion Apps pillars in use show on the <em>All Endpoints</em> tab.</p>',
'    <p>After downloading the description of an in-use data source, click its name to explore its attributes and child objects...</p>',
'</span>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1023094886065087285)
,p_plug_name=>'Oracle Cloud Apps REST Describe Explorer'
,p_plug_display_sequence=>10
,p_plug_display_point=>'AFTER_LOGO'
,p_plug_source=>'<span class="apex-logo-text"> -&nbsp; REST Data Sources</span>'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1505525019000087706)
,p_plug_name=>'Tabs'
,p_region_name=>'tabs'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(1022911469157087148)
,p_plug_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1001780702747352205)
,p_plug_name=>'Endpoints In Use'
,p_region_name=>'fa-rest-endpoints-tab'
,p_parent_plug_id=>wwv_flow_imp.id(1505525019000087706)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1022891918187087143)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case ',
'            when e.id is not null ',
'            then ',
'                apex_page.get_url(',
'                   p_page => 3,',
'                   p_items => ''P3_ID'',',
'                   p_values => e.id,',
'                   p_request => ''IR[attributes]_ALL'')',
'        end as details_url,',
'        apex_page.get_url(',
'           p_page    => 1,',
'           p_items   => ''P1_INGEST_APPLICATION_ID,P1_INGEST_MODULE_STATIC_ID'',',
'           p_values  => wsm.application_id||'',''||wsm.module_static_id,',
'           p_request => ''INGEST'') as refresh_url,',
'           wsm.application_name, ',
'       wsm.application_id, ',
'       wsm.module_static_id, ',
'       wsm.url_endpoint,',
'       case when e.id is null then ''Install'' else ''Refresh'' end available_action',
'from apex_appl_web_src_modules wsm',
'left outer join eba_util_farest_endpoints e on e.module_static_id = wsm.module_static_id',
'                                           and e.application_id  = wsm.application_id',
'where wsm.web_source_type_code = ''NATIVE_ADFBC'''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Endpoints In Use'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1001780878531352206)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'No Oracle Cloud Apps REST data sources defined in any app in the workspace. Add at least one REST data source of type "Oracle Cloud Applications (SaaS) REST Service" to get started...'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'SMUENCH'
,p_internal_uid=>14403799720316114
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(996834506257343331)
,p_db_column_name=>'DETAILS_URL'
,p_display_order=>10
,p_column_identifier=>'P'
,p_column_label=>'Details Url'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(996833260530343318)
,p_db_column_name=>'APPLICATION_NAME'
,p_display_order=>20
,p_column_identifier=>'L'
,p_column_label=>'Application'
,p_column_html_expression=>'#APPLICATION_NAME# (#APPLICATION_ID#)'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(996833367460343319)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>30
,p_column_identifier=>'M'
,p_column_label=>'Application Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1001781814373352216)
,p_db_column_name=>'MODULE_STATIC_ID'
,p_display_order=>40
,p_column_identifier=>'G'
,p_column_label=>'REST Data Source Static Id'
,p_column_html_expression=>'<div>{if DETAILS_URL/}<b><a href="#DETAILS_URL#" rel="noopener noreferrer">{endif/}#MODULE_STATIC_ID#{if DETAILS_URL/}</a></b>{endif/}</div>'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1001782147586352219)
,p_db_column_name=>'URL_ENDPOINT'
,p_display_order=>50
,p_column_identifier=>'J'
,p_column_label=>'Endpoint&nbsp;URL'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<button type="button" title="Copy #MODULE_STATIC_ID# endpoint URL to clipboard" aria-label="Copy #MODULE_STATIC_ID# endpoint URL to clipboard" data-text="#URL_ENDPOINT#"',
'class="t-Button t-Button--noLabel t-Button--icon">',
'    <span aria-hidden="true" class="t-Icon fa fa-clone"></span>',
'</button>'))
,p_column_type=>'STRING'
,p_static_id=>'service-endpoint'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(996835534272343341)
,p_db_column_name=>'REFRESH_URL'
,p_display_order=>70
,p_column_identifier=>'Q'
,p_column_label=>'Refresh Url'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(996835633102343342)
,p_db_column_name=>'AVAILABLE_ACTION'
,p_display_order=>80
,p_column_identifier=>'R'
,p_column_label=>'Action'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span>',
'{case AVAILABLE_ACTION/}',
'   {when Install/}<a class="fa fa-download" ',
'                     title="Download the service definition info for this data source" ',
'                      href="#REFRESH_URL#"></a>',
'   {when Refresh/}<a class="fa fa-repeat" ',
'                     title="Refresh the service definition info for this data source"',
'                     href="#REFRESH_URL#"></a>',
'{endcase/}',
'</span>'))
,p_column_type=>'STRING'
,p_static_id=>'action'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(996853304271344402)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'94763'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'AVAILABLE_ACTION:URL_ENDPOINT:MODULE_STATIC_ID:APPLICATION_NAME:'
,p_sort_column_1=>'MODULE_STATIC_ID'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1750097338323036852)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'For All Apps'
,p_report_seq=>10
,p_report_alias=>'9043154'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'AVAILABLE_ACTION:URL_ENDPOINT:MODULE_STATIC_ID:APPLICATION_NAME:'
,p_sort_column_1=>'MODULE_STATIC_ID'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1750098251338043211)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'By App'
,p_report_seq=>10
,p_report_alias=>'9043163'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'AVAILABLE_ACTION:URL_ENDPOINT:MODULE_STATIC_ID:APPLICATION_NAME:'
,p_sort_column_1=>'MODULE_STATIC_ID'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'APPLICATION_NAME:0:0:0:0:0'
,p_break_enabled_on=>'APPLICATION_NAME:0:0:0:0:0'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1505525167463087707)
,p_plug_name=>'All Endpoints'
,p_region_name=>'all-endpoints-tab'
,p_parent_plug_id=>wwv_flow_imp.id(1505525019000087706)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1022891918187087143)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c.ID,',
'       c.TITLE,',
'       c.ENDPOINT_URL,',
'       b.ENDPOINT_URL BASE_URL,',
'       c.RESOURCE_NAME',
'  from eba_util_farest_catalog c',
'  left outer join eba_util_farest_cat_baseurl b on b.id = c.baseurl_id'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'All Endpoints'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1505525257108087708)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'SMUENCH'
,p_internal_uid=>659743281263019509
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1505525348647087709)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1505525544873087711)
,p_db_column_name=>'ENDPOINT_URL'
,p_display_order=>20
,p_column_identifier=>'C'
,p_column_label=>'Endpoint&nbsp;URL'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<button type="button" title="Copy #RESOURCE_NAME# endpoint URL to clipboard" aria-label="Copy #RESOURCE_NAME# endpoint URL to clipboard" data-text="#ENDPOINT_URL#"',
'class="t-Button t-Button--noLabel t-Button--icon">',
'    <span aria-hidden="true" class="t-Icon fa fa-clone"></span>',
'</button>'))
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_static_id=>'all-endpoint-url'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1505525722425087713)
,p_db_column_name=>'RESOURCE_NAME'
,p_display_order=>30
,p_column_identifier=>'E'
,p_column_label=>'Resource Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1505525424548087710)
,p_db_column_name=>'TITLE'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Title'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(1505527577363087732)
,p_db_column_name=>'BASE_URL'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>'Base Url'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1513186189853883886)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'6674043'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'ENDPOINT_URL:RESOURCE_NAME:TITLE:BASE_URL:'
,p_sort_column_1=>'RESOURCE_NAME'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'BASE_URL:0:0:0:0:0'
,p_break_enabled_on=>'BASE_URL:0:0:0:0:0'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1505526974423087725)
,p_plug_name=>'Background Progress'
,p_parent_plug_id=>wwv_flow_imp.id(1505525019000087706)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1022835102818087124)
,p_plug_display_sequence=>70
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(2956563878497154550)
,p_name=>'Show Progress'
,p_region_name=>'background-progress-tab'
,p_parent_plug_id=>wwv_flow_imp.id(1505526974423087725)
,p_template=>wwv_flow_imp.id(1022835102818087124)
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--staticRowColors:t-Report--rowHighlight:t-Report--inline:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'        case bgp.process_name',
'             when ''On Refresh Catalog''   ',
'             then ''All catalog endpoints''',
'             when ''On Download Services'' ',
'             then ''Remaining in-use service descriptions''',
'        end as refresh_task,',
'        bgp.status_message,  ',
'        case when bgp.sofar is not null and bgp.totalwork is not null',
'             then round(bgp.sofar/bgp.totalwork*100)||''%''',
'        end progress,',
'        round(bgp.sofar/bgp.totalwork*100) progress_bar',
'from apex_appl_page_bg_proc_status bgp',
'left join apex_application_page_proc pp on bgp.process_id = pp.process_id',
'where      pp.process_name   in (''On Download Services'',''On Refresh Catalog'')',
'       and bgp.status_code   in ( ''ENQUEUED'',''SCHEDULED'', ''EXECUTING'')',
'       and pp.application_id = :APP_ID',
'       and pp.page_id        = 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(1022939898596087158)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No background service description retrieval happening at the moment'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1505527386409087730)
,p_query_column_id=>1
,p_column_alias=>'REFRESH_TASK'
,p_column_display_sequence=>10
,p_column_heading=>'Download Task'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_report_column_width=>150
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1505527488211087731)
,p_query_column_id=>2
,p_column_alias=>'STATUS_MESSAGE'
,p_column_display_sequence=>50
,p_column_heading=>'Status Message'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1529603859758173533)
,p_query_column_id=>3
,p_column_alias=>'PROGRESS'
,p_column_display_sequence=>20
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(1529604255688173534)
,p_query_column_id=>4
,p_column_alias=>'PROGRESS_BAR'
,p_column_display_sequence=>30
,p_column_heading=>'Progress'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH::#fb0b0b:100'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_report_column_width=>100
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1662999330957797912)
,p_button_sequence=>70
,p_button_name=>'Help'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--primary'
,p_button_template_id=>wwv_flow_imp.id(1022974172668087173)
,p_button_image_alt=>'Help'
,p_button_position=>'BEFORE_NAVIGATION_BAR'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-info-circle-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1662999583378797915)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1000043537437016293)
,p_button_name=>'Close'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(1022974916444087173)
,p_button_image_alt=>'Close'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1505527083516087727)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2956563878497154550)
,p_button_name=>'Refresh_Progress_Display'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(1022974963311087173)
,p_button_image_alt=>'Refresh Progress Display'
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'margin-top-md  margin-bottom-md '
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1505526467503087720)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1001780702747352205)
,p_button_name=>'Refresh_Endpoints_in_Use'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(1022974963311087173)
,p_button_image_alt=>'Refresh List'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1662998286232797902)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1505525167463087707)
,p_button_name=>'Refresh_Catalog_Endpoints'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(1022974963311087173)
,p_button_image_alt=>'Refresh List'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1505525840361087714)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1505525167463087707)
,p_button_name=>'Refresh_Catalog_in_Background'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(1022974963311087173)
,p_button_image_alt=>'Refresh Catalog In Background'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-repeat'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1505529302596087749)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1001780702747352205)
,p_button_name=>'Download_Remaining_Service_Descriptions_in_Background'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(1022974963311087173)
,p_button_image_alt=>'Download Remaining Service Descriptions In Background'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * ',
'from(select application_id, module_static_id',
'       from apex_appl_web_src_modules',
'      where web_source_type_code = ''NATIVE_ADFBC''',
'      minus',
'     select application_id, module_static_id',
'       from eba_util_farest_endpoints)',
'fetch first row only'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-cloud-download'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(996833781593343324)
,p_name=>'P1_INGEST_APPLICATION_ID'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(996833941888343325)
,p_name=>'P1_INGEST_MODULE_STATIC_ID'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1505529221037087748)
,p_name=>'P1_TAB_ACTIVATED'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1505527181045087728)
,p_name=>'On Refresh Progress'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1505527083516087727)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1505527287551087729)
,p_event_id=>wwv_flow_imp.id(1505527181045087728)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(2956563878497154550)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1505528998183087746)
,p_name=>'When Tab Changed'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#tabs'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'atabsactivate'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1505529148119087747)
,p_event_id=>wwv_flow_imp.id(1505528998183087746)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Find the active tab and its associated region',
'let active_tab = apex.region(this.triggeringElement.id).widget().aTabs("getActive");',
'let active_region = $(''[id$=-tab]'',$(active_tab.panel$));',
'',
'// If we have region, find its ID and record that for use in the regions',
'if(active_region){',
'    let active_id = $(active_region).attr(''id'');',
'    apex.items.P1_TAB_ACTIVATED.setValue(active_id);',
'',
'    // If we want to auto refresh...',
'    if( active_id == "background-progress-tab" ){',
'        // If we can refresh the current region;',
'        if( active_id && apex.regions[active_id] && apex.regions[active_id].refresh ){        ',
'            apex.regions[active_id].refresh();',
'        }',
'    }',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1662998095567797900)
,p_name=>'When Refresh Endpoints in Use Clicked'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1505526467503087720)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1662998234284797901)
,p_event_id=>wwv_flow_imp.id(1662998095567797900)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1001780702747352205)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1662998384467797903)
,p_name=>'When Refresh Catalog Endpoints Clicked'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1662998286232797902)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1662998489469797904)
,p_event_id=>wwv_flow_imp.id(1662998384467797903)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1505525167463087707)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1662999472357797913)
,p_name=>'When Help Clicked'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1662999330957797912)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1662999481009797914)
,p_event_id=>wwv_flow_imp.id(1662999472357797913)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1000043537437016293)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1662999775070797916)
,p_name=>'When Close Clicked'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1662999583378797915)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1662999839298797917)
,p_event_id=>wwv_flow_imp.id(1662999775070797916)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1000043537437016293)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1505526202498087718)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'On Refresh Catalog'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'IGNORE'
,p_attribute_06=>'1'
,p_attribute_09=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1505525840361087714)
,p_internal_uid=>659744226653019519
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1505526593147087722)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'On Download Services'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'IGNORE'
,p_attribute_06=>'1'
,p_attribute_09=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(1505529302596087749)
,p_internal_uid=>659744617302019523
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(996834023227343326)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'If Ingest Link Clicked...'
,p_attribute_01=>'N'
,p_process_when=>'INGEST'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>9456944416307234
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(996834089976343327)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(996834023227343326)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Describe and Ingest JSON'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'EBA_UTIL_FAREST_EXPLORER'
,p_attribute_04=>'INGEST_JSON_DESCRIBE'
,p_internal_uid=>9457011165307235
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(996834189554343328)
,p_page_process_id=>wwv_flow_imp.id(996834089976343327)
,p_page_id=>1
,p_name=>'p_application_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P1_INGEST_APPLICATION_ID'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(996834347312343329)
,p_page_process_id=>wwv_flow_imp.id(996834089976343327)
,p_page_id=>1
,p_name=>'p_module_static_id'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P1_INGEST_MODULE_STATIC_ID'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1505526349862087719)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(1505526202498087718)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Call Refresh Catalog'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'EBA_UTIL_FAREST_EXPLORER'
,p_attribute_04=>'REFRESH_CATALOG'
,p_internal_uid=>659744374017019520
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1505526787675087724)
,p_process_sequence=>30
,p_parent_process_id=>wwv_flow_imp.id(1505526593147087722)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Download Missing Descriptions'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'EBA_UTIL_FAREST_EXPLORER'
,p_attribute_04=>'INGEST_JSON_FOR_DATA_SOURCES'
,p_internal_uid=>659744811830019525
);
wwv_flow_imp.component_end;
end;
/
