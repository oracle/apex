prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 7920
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7920
,p_default_id_offset=>2053840036990350
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'drop table eba_demo_card_emp;'||wwv_flow.LF||
'drop table eba_demo_card_dept;'||wwv_flow.LF||
'drop table eba_demo_card_vehicle_speed;';
wwv_flow_imp.g_varchar2_table(2) := ''||wwv_flow.LF||
'drop table eba_demo_card_random_image;'||wwv_flow.LF||
''||wwv_flow.LF||
'drop package eba_demo_card_pkg;';
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(10744201903091577351)
,p_deinstall_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
,p_required_free_kb=>100
,p_required_sys_privs=>'CREATE PROCEDURE:CREATE TABLE:CREATE TRIGGER:CREATE VIEW'
,p_required_names_available=>'EBA_DEMO_CARD_DEPT:EBA_DEMO_CARD_EMP:EBA_DEMO_CARD_VEHICLE_SPEED:EBA_DEMO_CARD_RANDOM_IMAGE'
);
wwv_flow_imp.component_end;
end;
/
