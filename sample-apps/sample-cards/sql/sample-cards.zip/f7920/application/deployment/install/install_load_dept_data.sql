prompt --application/deployment/install/install_load_dept_data
begin
--   Manifest
--     INSTALL: INSTALL-load dept data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7920
,p_default_id_offset=>2053840036990350
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'insert into eba_demo_card_dept (DEPTNO,DNAME,LOC) values (10,''ACCOUNTING'',''NEW YORK'');'||wwv_flow.LF||
'insert into e';
wwv_flow_imp.g_varchar2_table(2) := 'ba_demo_card_dept (DEPTNO,DNAME,LOC) values (20,''RESEARCH'',''DALLAS'');'||wwv_flow.LF||
'insert into eba_demo_card_dept';
wwv_flow_imp.g_varchar2_table(3) := ' (DEPTNO,DNAME,LOC) values (30,''SALES'',''CHICAGO'');'||wwv_flow.LF||
'insert into eba_demo_card_dept (DEPTNO,DNAME,LOC)';
wwv_flow_imp.g_varchar2_table(4) := ' values (40,''OPERATIONS'',''BOSTON'');';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(9822251866754869555)
,p_install_id=>wwv_flow_imp.id(10744201903091577351)
,p_name=>'load dept data'
,p_sequence=>50
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
