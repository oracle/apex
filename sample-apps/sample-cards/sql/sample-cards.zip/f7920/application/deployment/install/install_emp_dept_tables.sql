prompt --application/deployment/install/install_emp_dept_tables
begin
--   Manifest
--     INSTALL: INSTALL-emp dept tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7920
,p_default_id_offset=>2053840036990350
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_demo_card_dept ('||wwv_flow.LF||
'    deptno    number not null constraint eba_demo_card_dept_pk pri';
wwv_flow_imp.g_varchar2_table(2) := 'mary key,'||wwv_flow.LF||
'    dname     varchar2(50),'||wwv_flow.LF||
'    loc       varchar2(255) );'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_demo_card_emp';
wwv_flow_imp.g_varchar2_table(3) := ' ('||wwv_flow.LF||
'    empno            number not null constraint eba_demo_card_emp_pk  primary key,'||wwv_flow.LF||
'    ename     ';
wwv_flow_imp.g_varchar2_table(4) := '       varchar2(255),'||wwv_flow.LF||
'    job              varchar2(255),'||wwv_flow.LF||
'    mgr              number,'||wwv_flow.LF||
'    hiredate ';
wwv_flow_imp.g_varchar2_table(5) := '        date,'||wwv_flow.LF||
'    sal              number,'||wwv_flow.LF||
'    comm             number,'||wwv_flow.LF||
'    deptno           number,';
wwv_flow_imp.g_varchar2_table(6) := ''||wwv_flow.LF||
'    profile_image    blob,'||wwv_flow.LF||
'    mimetype         varchar2(255),'||wwv_flow.LF||
'    filename         varchar2(400),'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(7) := '    image_last_update date,'||wwv_flow.LF||
'    tags             varchar2(4000) );'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_card_emp ad';
wwv_flow_imp.g_varchar2_table(8) := 'd constraint eba_demo_card_emp_mgr_fk foreign key (mgr)'||wwv_flow.LF||
'      references eba_demo_card_emp (empno) e';
wwv_flow_imp.g_varchar2_table(9) := 'nable;'||wwv_flow.LF||
''||wwv_flow.LF||
'alter table eba_demo_card_emp add constraint eba_demo_card_emp_dept_fk foreign key (deptno)'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(10) := '      references eba_demo_card_dept (deptno) enable;'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(9822251760791865786)
,p_install_id=>wwv_flow_imp.id(10744201903091577351)
,p_name=>'emp dept tables'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
