prompt --application/deployment/install/install_eba_demo_card_pkg
begin
--   Manifest
--     INSTALL: INSTALL-eba_demo_card_pkg
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7920
,p_default_id_offset=>2053840036990350
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_demo_card_pkg as'||wwv_flow.LF||
''||wwv_flow.LF||
'    function get_video_duration ('||wwv_flow.LF||
'        p_video_id';
wwv_flow_imp.g_varchar2_table(2) := ' in varchar2 ) return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'    procedure get_profile_image ('||wwv_flow.LF||
'        p_empno in number);'||wwv_flow.LF||
''||wwv_flow.LF||
'end ';
wwv_flow_imp.g_varchar2_table(3) := 'eba_demo_card_pkg;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace package body eba_demo_card_pkg as'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- Get YouTube';
wwv_flow_imp.g_varchar2_table(4) := ' video duration using REST Data Source'||wwv_flow.LF||
'    -- '||wwv_flow.LF||
'    function get_video_duration ('||wwv_flow.LF||
'            p_video';
wwv_flow_imp.g_varchar2_table(5) := '_id in varchar2 ) return varchar2'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_columns    apex_exec.t_columns;'||wwv_flow.LF||
'        l_paramet';
wwv_flow_imp.g_varchar2_table(6) := 'ers apex_exec.t_parameters;'||wwv_flow.LF||
'        l_context    apex_exec.t_context;'||wwv_flow.LF||
'    '||wwv_flow.LF||
'        type t_column_pos';
wwv_flow_imp.g_varchar2_table(7) := 'ition is table of pls_integer index by varchar2(32767);'||wwv_flow.LF||
'        l_column_position t_column_position;';
wwv_flow_imp.g_varchar2_table(8) := ''||wwv_flow.LF||
'        l_hour     number;'||wwv_flow.LF||
'        l_duration varchar2(255);'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'    '||wwv_flow.LF||
'        -- specify colu';
wwv_flow_imp.g_varchar2_table(9) := 'mns to select from the REST Data Source'||wwv_flow.LF||
'        apex_exec.add_column( '||wwv_flow.LF||
'            p_columns       =';
wwv_flow_imp.g_varchar2_table(10) := '> l_columns,'||wwv_flow.LF||
'            p_column_name   => ''DURATION'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'        apex_exec.add_parameter ('||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(11) := '     p_parameters => l_parameters,'||wwv_flow.LF||
'            p_name       => ''id'','||wwv_flow.LF||
'            p_value      => p_v';
wwv_flow_imp.g_varchar2_table(12) := 'ideo_id );'||wwv_flow.LF||
'    '||wwv_flow.LF||
'        -- invoke REST Data Source and select data'||wwv_flow.LF||
'        l_context := apex_exec.op';
wwv_flow_imp.g_varchar2_table(13) := 'en_rest_source_query('||wwv_flow.LF||
'            p_static_id  => ''APEX_Youtube_Videos'','||wwv_flow.LF||
'            p_parameters =>';
wwv_flow_imp.g_varchar2_table(14) := ' l_parameters,'||wwv_flow.LF||
'            p_columns    => l_columns );'||wwv_flow.LF||
'    '||wwv_flow.LF||
'        -- now get result set positions';
wwv_flow_imp.g_varchar2_table(15) := ' for the selected columns'||wwv_flow.LF||
'        l_column_position( ''DURATION'' ) := apex_exec.get_column_position( ';
wwv_flow_imp.g_varchar2_table(16) := 'l_context, ''DURATION'' );'||wwv_flow.LF||
'       '||wwv_flow.LF||
'        -- loop through result set and print out contents'||wwv_flow.LF||
'        w';
wwv_flow_imp.g_varchar2_table(17) := 'hile apex_exec.next_row( l_context ) loop'||wwv_flow.LF||
'            l_duration := apex_exec.get_varchar2( l_contex';
wwv_flow_imp.g_varchar2_table(18) := 't, l_column_position( ''DURATION'' ) );'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'        '||wwv_flow.LF||
'        -- finally: release all res';
wwv_flow_imp.g_varchar2_table(19) := 'ources'||wwv_flow.LF||
'        apex_exec.close( l_context );'||wwv_flow.LF||
'        '||wwv_flow.LF||
'        -- convert iso-8601 time format to rea';
wwv_flow_imp.g_varchar2_table(20) := 'dable format'||wwv_flow.LF||
'        l_hour := extract (hour from to_dsinterval( l_duration ));'||wwv_flow.LF||
'        l_duration :';
wwv_flow_imp.g_varchar2_table(21) := '= case when l_hour > 0 then to_char( l_hour, ''09'' )||'':'' end ||'||wwv_flow.LF||
'                      to_char( extra';
wwv_flow_imp.g_varchar2_table(22) := 'ct (minute from to_dsinterval( l_duration )), ''09'' )||'':''||'||wwv_flow.LF||
'                      to_char( extract (';
wwv_flow_imp.g_varchar2_table(23) := 'second from to_dsinterval( l_duration )), ''09'' );'||wwv_flow.LF||
'    '||wwv_flow.LF||
'        return l_duration;'||wwv_flow.LF||
'    exception'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(24) := '    when others then'||wwv_flow.LF||
'            -- IMPORTANT: also release all resources, when an exception occcurs';
wwv_flow_imp.g_varchar2_table(25) := '!'||wwv_flow.LF||
'            apex_exec.close( l_context );'||wwv_flow.LF||
'            raise;'||wwv_flow.LF||
'    end get_video_duration;'||wwv_flow.LF||
''||wwv_flow.LF||
'    --'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(26) := '   -- Get employee profile BLOB image and display inline'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    procedure get_profile_image ('||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(27) := '      p_empno in number)'||wwv_flow.LF||
'    is'||wwv_flow.LF||
'        l_export  apex_data_export.t_export;'||wwv_flow.LF||
'    begin'||wwv_flow.LF||
'        selec';
wwv_flow_imp.g_varchar2_table(28) := 't profile_image, filename, mimetype'||wwv_flow.LF||
'          into l_export.content_blob, l_export.file_name, l_expo';
wwv_flow_imp.g_varchar2_table(29) := 'rt.mime_type'||wwv_flow.LF||
'          from eba_demo_card_emp'||wwv_flow.LF||
'         where empno = p_empno;'||wwv_flow.LF||
''||wwv_flow.LF||
'        apex_data_exp';
wwv_flow_imp.g_varchar2_table(30) := 'ort.download('||wwv_flow.LF||
'            p_export              => l_export,'||wwv_flow.LF||
'            p_content_disposition => ap';
wwv_flow_imp.g_varchar2_table(31) := 'ex_data_export.c_inline );'||wwv_flow.LF||
'    end get_profile_image;'||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_demo_card_pkg;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6061325474875251481)
,p_install_id=>wwv_flow_imp.id(10744201903091577351)
,p_name=>'eba_demo_card_pkg'
,p_sequence=>200
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
