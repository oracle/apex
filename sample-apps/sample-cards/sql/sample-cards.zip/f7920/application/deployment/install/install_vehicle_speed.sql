prompt --application/deployment/install/install_vehicle_speed
begin
--   Manifest
--     INSTALL: INSTALL-vehicle speed
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7920
,p_default_id_offset=>2053840036990350
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- create table'||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_demo_card_vehicle_speed('||wwv_flow.LF||
'    id                   number default t';
wwv_flow_imp.g_varchar2_table(2) := 'o_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                         constraint eba_de';
wwv_flow_imp.g_varchar2_table(3) := 'mo_card_vspeed_pk primary key,'||wwv_flow.LF||
'    posted_speed         number, '||wwv_flow.LF||
'    vehicle_speed        number, '||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(4) := '   date_of_incedent     date, '||wwv_flow.LF||
'    license_plate        varchar2(50), '||wwv_flow.LF||
'    location             varc';
wwv_flow_imp.g_varchar2_table(5) := 'har2(50), '||wwv_flow.LF||
'    state                varchar2(50) );'||wwv_flow.LF||
''||wwv_flow.LF||
'-- load data'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_';
wwv_flow_imp.g_varchar2_table(6) := 'SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (1,25,37,';
wwv_flow_imp.g_varchar2_table(7) := 'to_date(''09/28/2020'',''MM/DD/YYYY''),''1A510EE3'',''School Road'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE';
wwv_flow_imp.g_varchar2_table(8) := '_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (2,45,70';
wwv_flow_imp.g_varchar2_table(9) := ',to_date(''10/17/2020'',''MM/DD/YYYY''),''EE05301'',''River Road'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_';
wwv_flow_imp.g_varchar2_table(10) := 'SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (3,55,64,';
wwv_flow_imp.g_varchar2_table(11) := 'to_date(''10/09/2020'',''MM/DD/YYYY''),''31C5101'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SP';
wwv_flow_imp.g_varchar2_table(12) := 'EED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (4,45,38,to';
wwv_flow_imp.g_varchar2_table(13) := '_date(''10/18/2020'',''MM/DD/YYYY''),''544331D53'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_S';
wwv_flow_imp.g_varchar2_table(14) := 'PEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (5,55,62,t';
wwv_flow_imp.g_varchar2_table(15) := 'o_date(''10/14/2020'',''MM/DD/YYYY''),''4331E57'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPE';
wwv_flow_imp.g_varchar2_table(16) := 'ED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (6,45,54,to_';
wwv_flow_imp.g_varchar2_table(17) := 'date(''10/15/2020'',''MM/DD/YYYY''),''EF5443313'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SP';
wwv_flow_imp.g_varchar2_table(18) := 'EED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (7,55,55,to';
wwv_flow_imp.g_varchar2_table(19) := '_date(''10/05/2020'',''MM/DD/YYYY''),''20EF54431'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SP';
wwv_flow_imp.g_varchar2_table(20) := 'EED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (8,45,50,to';
wwv_flow_imp.g_varchar2_table(21) := '_date(''09/23/2020'',''MM/DD/YYYY''),''54433211'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SP';
wwv_flow_imp.g_varchar2_table(22) := 'EED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (9,35,32,to';
wwv_flow_imp.g_varchar2_table(23) := '_date(''10/13/2020'',''MM/DD/YYYY''),''3322510E2'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_';
wwv_flow_imp.g_varchar2_table(24) := 'SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (10,45,55';
wwv_flow_imp.g_varchar2_table(25) := ',to_date(''09/28/2020'',''MM/DD/YYYY''),''E0530102'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE';
wwv_flow_imp.g_varchar2_table(26) := '_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (11,35,3';
wwv_flow_imp.g_varchar2_table(27) := '5,to_date(''10/08/2020'',''MM/DD/YYYY''),''05301006'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHIC';
wwv_flow_imp.g_varchar2_table(28) := 'LE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (12,55';
wwv_flow_imp.g_varchar2_table(29) := ',48,to_date(''09/28/2020'',''MM/DD/YYYY''),''10EE05307'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHI';
wwv_flow_imp.g_varchar2_table(30) := 'CLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (13,5';
wwv_flow_imp.g_varchar2_table(31) := '5,54,to_date(''10/01/2020'',''MM/DD/YYYY''),''10EE0534'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHI';
wwv_flow_imp.g_varchar2_table(32) := 'CLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (14,4';
wwv_flow_imp.g_varchar2_table(33) := '5,40,to_date(''09/20/2020'',''MM/DD/YYYY''),''4332757'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHI';
wwv_flow_imp.g_varchar2_table(34) := 'CLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (15,5';
wwv_flow_imp.g_varchar2_table(35) := '5,52,to_date(''10/12/2020'',''MM/DD/YYYY''),''053010004'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEH';
wwv_flow_imp.g_varchar2_table(36) := 'ICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (16,';
wwv_flow_imp.g_varchar2_table(37) := '45,52,to_date(''10/15/2020'',''MM/DD/YYYY''),''EE0530106'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_V';
wwv_flow_imp.g_varchar2_table(38) := 'EHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (1';
wwv_flow_imp.g_varchar2_table(39) := '7,45,46,to_date(''10/03/2020'',''MM/DD/YYYY''),''05301006'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_';
wwv_flow_imp.g_varchar2_table(40) := 'VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (';
wwv_flow_imp.g_varchar2_table(41) := '18,45,43,to_date(''10/09/2020'',''MM/DD/YYYY''),''510EE053'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD';
wwv_flow_imp.g_varchar2_table(42) := '_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values ';
wwv_flow_imp.g_varchar2_table(43) := '(19,55,63,to_date(''09/30/2020'',''MM/DD/YYYY''),''0EE0531'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_';
wwv_flow_imp.g_varchar2_table(44) := 'VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (';
wwv_flow_imp.g_varchar2_table(45) := '20,25,30,to_date(''10/04/2020'',''MM/DD/YYYY''),''4332D55'',''School Road'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD';
wwv_flow_imp.g_varchar2_table(46) := '_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values ';
wwv_flow_imp.g_varchar2_table(47) := '(21,55,55,to_date(''10/10/2020'',''MM/DD/YYYY''),''E0530102'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD';
wwv_flow_imp.g_varchar2_table(48) := '_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values ';
wwv_flow_imp.g_varchar2_table(49) := '(22,55,57,to_date(''10/02/2020'',''MM/DD/YYYY''),''544332F53'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CAR';
wwv_flow_imp.g_varchar2_table(50) := 'D_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values';
wwv_flow_imp.g_varchar2_table(51) := ' (23,25,48,to_date(''10/02/2020'',''MM/DD/YYYY''),''0EF544336'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_';
wwv_flow_imp.g_varchar2_table(52) := 'CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) val';
wwv_flow_imp.g_varchar2_table(53) := 'ues (24,55,49,to_date(''10/10/2020'',''MM/DD/YYYY''),''510EE07'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_C';
wwv_flow_imp.g_varchar2_table(54) := 'ARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) valu';
wwv_flow_imp.g_varchar2_table(55) := 'es (25,45,64,to_date(''10/03/2020'',''MM/DD/YYYY''),''05301002'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_';
wwv_flow_imp.g_varchar2_table(56) := 'CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) val';
wwv_flow_imp.g_varchar2_table(57) := 'ues (26,55,50,to_date(''10/19/2020'',''MM/DD/YYYY''),''53010008'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_';
wwv_flow_imp.g_varchar2_table(58) := 'CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) val';
wwv_flow_imp.g_varchar2_table(59) := 'ues (27,55,49,to_date(''10/03/2020'',''MM/DD/YYYY''),''EE05308'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_C';
wwv_flow_imp.g_varchar2_table(60) := 'ARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) valu';
wwv_flow_imp.g_varchar2_table(61) := 'es (28,25,28,to_date(''10/03/2020'',''MM/DD/YYYY''),''510EE0533'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEM';
wwv_flow_imp.g_varchar2_table(62) := 'O_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) v';
wwv_flow_imp.g_varchar2_table(63) := 'alues (29,45,39,to_date(''10/14/2020'',''MM/DD/YYYY''),''F5443336'',''River Road'',''PA'');'||wwv_flow.LF||
'insert into EBA_DE';
wwv_flow_imp.g_varchar2_table(64) := 'MO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) ';
wwv_flow_imp.g_varchar2_table(65) := 'values (30,45,60,to_date(''10/16/2020'',''MM/DD/YYYY''),''EF544336'',''River Road'',''MD'');'||wwv_flow.LF||
'insert into EBA_D';
wwv_flow_imp.g_varchar2_table(66) := 'EMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE)';
wwv_flow_imp.g_varchar2_table(67) := ' values (31,55,62,to_date(''10/05/2020'',''MM/DD/YYYY''),''38510EE06'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_';
wwv_flow_imp.g_varchar2_table(68) := 'DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE';
wwv_flow_imp.g_varchar2_table(69) := ') values (32,45,39,to_date(''10/02/2020'',''MM/DD/YYYY''),''43339515'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA';
wwv_flow_imp.g_varchar2_table(70) := '_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STAT';
wwv_flow_imp.g_varchar2_table(71) := 'E) values (33,55,51,to_date(''10/13/2020'',''MM/DD/YYYY''),''53010004'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA';
wwv_flow_imp.g_varchar2_table(72) := '_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STAT';
wwv_flow_imp.g_varchar2_table(73) := 'E) values (34,35,38,to_date(''10/19/2020'',''MM/DD/YYYY''),''05301007'',''Main Street'',''MD'');'||wwv_flow.LF||
'insert into E';
wwv_flow_imp.g_varchar2_table(74) := 'BA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,ST';
wwv_flow_imp.g_varchar2_table(75) := 'ATE) values (35,55,48,to_date(''10/13/2020'',''MM/DD/YYYY''),''510EE05'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EB';
wwv_flow_imp.g_varchar2_table(76) := 'A_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STA';
wwv_flow_imp.g_varchar2_table(77) := 'TE) values (36,25,30,to_date(''10/01/2020'',''MM/DD/YYYY''),''B20EF55'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into E';
wwv_flow_imp.g_varchar2_table(78) := 'BA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,ST';
wwv_flow_imp.g_varchar2_table(79) := 'ATE) values (37,45,48,to_date(''10/14/2020'',''MM/DD/YYYY''),''F544333'',''River Road'',''MD'');'||wwv_flow.LF||
'insert into E';
wwv_flow_imp.g_varchar2_table(80) := 'BA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,ST';
wwv_flow_imp.g_varchar2_table(81) := 'ATE) values (38,55,55,to_date(''10/05/2020'',''MM/DD/YYYY''),''4333F516'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into E';
wwv_flow_imp.g_varchar2_table(82) := 'BA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,ST';
wwv_flow_imp.g_varchar2_table(83) := 'ATE) values (39,55,60,to_date(''10/18/2020'',''MM/DD/YYYY''),''40510E7'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EB';
wwv_flow_imp.g_varchar2_table(84) := 'A_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STA';
wwv_flow_imp.g_varchar2_table(85) := 'TE) values (40,35,61,to_date(''10/19/2020'',''MM/DD/YYYY''),''E05301003'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(86) := ' EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,';
wwv_flow_imp.g_varchar2_table(87) := 'STATE) values (41,35,32,to_date(''10/14/2020'',''MM/DD/YYYY''),''E053012'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert int';
wwv_flow_imp.g_varchar2_table(88) := 'o EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION';
wwv_flow_imp.g_varchar2_table(89) := ',STATE) values (42,55,58,to_date(''10/18/2020'',''MM/DD/YYYY''),''43510E6'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(90) := ' EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,';
wwv_flow_imp.g_varchar2_table(91) := 'STATE) values (43,45,48,to_date(''10/01/2020'',''MM/DD/YYYY''),''4334453'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(92) := ' EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,';
wwv_flow_imp.g_varchar2_table(93) := 'STATE) values (44,55,51,to_date(''10/15/2020'',''MM/DD/YYYY''),''EF544336'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(94) := ' EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,';
wwv_flow_imp.g_varchar2_table(95) := 'STATE) values (45,25,28,to_date(''10/12/2020'',''MM/DD/YYYY''),''46510EE05'',''School Road'',''VA'');'||wwv_flow.LF||
'insert i';
wwv_flow_imp.g_varchar2_table(96) := 'nto EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATI';
wwv_flow_imp.g_varchar2_table(97) := 'ON,STATE) values (46,55,49,to_date(''10/16/2020'',''MM/DD/YYYY''),''54433475'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert i';
wwv_flow_imp.g_varchar2_table(98) := 'nto EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATI';
wwv_flow_imp.g_varchar2_table(99) := 'ON,STATE) values (47,25,28,to_date(''10/10/2020'',''MM/DD/YYYY''),''F5443342'',''School Road'',''DC'');'||wwv_flow.LF||
'insert';
wwv_flow_imp.g_varchar2_table(100) := ' into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCA';
wwv_flow_imp.g_varchar2_table(101) := 'TION,STATE) values (48,45,43,to_date(''10/19/2020'',''MM/DD/YYYY''),''9510EE057'',''River Road'',''VA'');'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(102) := 'rt into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LO';
wwv_flow_imp.g_varchar2_table(103) := 'CATION,STATE) values (49,45,42,to_date(''10/16/2020'',''MM/DD/YYYY''),''5301001'',''River Road'',''VA'');'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(104) := 'rt into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LO';
wwv_flow_imp.g_varchar2_table(105) := 'CATION,STATE) values (50,55,59,to_date(''09/28/2020'',''MM/DD/YYYY''),''10EE05302'',''Highway 5'',''DC'');'||wwv_flow.LF||
'ins';
wwv_flow_imp.g_varchar2_table(106) := 'ert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,L';
wwv_flow_imp.g_varchar2_table(107) := 'OCATION,STATE) values (51,55,62,to_date(''10/07/2020'',''MM/DD/YYYY''),''20EF54435'',''Highway 5'',''VA'');'||wwv_flow.LF||
'in';
wwv_flow_imp.g_varchar2_table(108) := 'sert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,';
wwv_flow_imp.g_varchar2_table(109) := 'LOCATION,STATE) values (52,55,55,to_date(''10/14/2020'',''MM/DD/YYYY''),''D510EE3'',''Highway 5'',''VA'');'||wwv_flow.LF||
'ins';
wwv_flow_imp.g_varchar2_table(110) := 'ert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,L';
wwv_flow_imp.g_varchar2_table(111) := 'OCATION,STATE) values (53,55,51,to_date(''10/11/2020'',''MM/DD/YYYY''),''4E510EE04'',''Highway 5'',''VA'');'||wwv_flow.LF||
'in';
wwv_flow_imp.g_varchar2_table(112) := 'sert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,';
wwv_flow_imp.g_varchar2_table(113) := 'LOCATION,STATE) values (54,45,54,to_date(''09/21/2020'',''MM/DD/YYYY''),''44334F55'',''River Road'',''VA'');'||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(114) := 'nsert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE';
wwv_flow_imp.g_varchar2_table(115) := ',LOCATION,STATE) values (55,45,45,to_date(''09/28/2020'',''MM/DD/YYYY''),''510EE02'',''River Road'',''DC'');'||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(116) := 'nsert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE';
wwv_flow_imp.g_varchar2_table(117) := ',LOCATION,STATE) values (56,45,42,to_date(''10/02/2020'',''MM/DD/YYYY''),''33515106'',''River Road'',''VA'');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(118) := 'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLAT';
wwv_flow_imp.g_varchar2_table(119) := 'E,LOCATION,STATE) values (57,45,79,to_date(''10/12/2020'',''MM/DD/YYYY''),''52510EE06'',''River Road'',''VA'')';
wwv_flow_imp.g_varchar2_table(120) := ';'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PL';
wwv_flow_imp.g_varchar2_table(121) := 'ATE,LOCATION,STATE) values (58,45,44,to_date(''10/06/2020'',''MM/DD/YYYY''),''F544334'',''River Road'',''DC'')';
wwv_flow_imp.g_varchar2_table(122) := ';'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PL';
wwv_flow_imp.g_varchar2_table(123) := 'ATE,LOCATION,STATE) values (59,55,62,to_date(''10/12/2020'',''MM/DD/YYYY''),''4510EE01'',''Highway 5'',''VA'')';
wwv_flow_imp.g_varchar2_table(124) := ';'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PL';
wwv_flow_imp.g_varchar2_table(125) := 'ATE,LOCATION,STATE) values (60,55,62,to_date(''09/19/2020'',''MM/DD/YYYY''),''0EF5441'',''Highway 5'',''DC'');';
wwv_flow_imp.g_varchar2_table(126) := ''||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLA';
wwv_flow_imp.g_varchar2_table(127) := 'TE,LOCATION,STATE) values (61,45,42,to_date(''09/21/2020'',''MM/DD/YYYY''),''20EF545'',''River Road'',''PA'');';
wwv_flow_imp.g_varchar2_table(128) := ''||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLA';
wwv_flow_imp.g_varchar2_table(129) := 'TE,LOCATION,STATE) values (62,45,40,to_date(''09/22/2020'',''MM/DD/YYYY''),''43357514'',''River Road'',''VA'')';
wwv_flow_imp.g_varchar2_table(130) := ';'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PL';
wwv_flow_imp.g_varchar2_table(131) := 'ATE,LOCATION,STATE) values (63,45,51,to_date(''10/18/2020'',''MM/DD/YYYY''),''530100005'',''River Road'',''VA';
wwv_flow_imp.g_varchar2_table(132) := ''');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_';
wwv_flow_imp.g_varchar2_table(133) := 'PLATE,LOCATION,STATE) values (64,35,34,to_date(''09/28/2020'',''MM/DD/YYYY''),''EE0530102'',''Main Street'',';
wwv_flow_imp.g_varchar2_table(134) := '''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICEN';
wwv_flow_imp.g_varchar2_table(135) := 'SE_PLATE,LOCATION,STATE) values (65,35,34,to_date(''10/09/2020'',''MM/DD/YYYY''),''5443355'',''Main Street''';
wwv_flow_imp.g_varchar2_table(136) := ',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICE';
wwv_flow_imp.g_varchar2_table(137) := 'NSE_PLATE,LOCATION,STATE) values (66,35,30,to_date(''09/19/2020'',''MM/DD/YYYY''),''EF544336'',''Main Stree';
wwv_flow_imp.g_varchar2_table(138) := 't'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LI';
wwv_flow_imp.g_varchar2_table(139) := 'CENSE_PLATE,LOCATION,STATE) values (67,55,48,to_date(''10/15/2020'',''MM/DD/YYYY''),''EE053013'',''Highway ';
wwv_flow_imp.g_varchar2_table(140) := '5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LI';
wwv_flow_imp.g_varchar2_table(141) := 'CENSE_PLATE,LOCATION,STATE) values (68,55,57,to_date(''09/21/2020'',''MM/DD/YYYY''),''20EF54437'',''Highway';
wwv_flow_imp.g_varchar2_table(142) := ' 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,L';
wwv_flow_imp.g_varchar2_table(143) := 'ICENSE_PLATE,LOCATION,STATE) values (69,45,42,to_date(''09/28/2020'',''MM/DD/YYYY''),''510EE05'',''River Ro';
wwv_flow_imp.g_varchar2_table(144) := 'ad'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,L';
wwv_flow_imp.g_varchar2_table(145) := 'ICENSE_PLATE,LOCATION,STATE) values (70,45,35,to_date(''10/15/2020'',''MM/DD/YYYY''),''F544331'',''River Ro';
wwv_flow_imp.g_varchar2_table(146) := 'ad'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,L';
wwv_flow_imp.g_varchar2_table(147) := 'ICENSE_PLATE,LOCATION,STATE) values (71,25,31,to_date(''09/30/2020'',''MM/DD/YYYY''),''360510E2'',''School ';
wwv_flow_imp.g_varchar2_table(148) := 'Road'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT';
wwv_flow_imp.g_varchar2_table(149) := ',LICENSE_PLATE,LOCATION,STATE) values (72,55,55,to_date(''10/07/2020'',''MM/DD/YYYY''),''EE053013'',''Highw';
wwv_flow_imp.g_varchar2_table(150) := 'ay 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT';
wwv_flow_imp.g_varchar2_table(151) := ',LICENSE_PLATE,LOCATION,STATE) values (73,35,38,to_date(''09/23/2020'',''MM/DD/YYYY''),''510EE06'',''Main S';
wwv_flow_imp.g_varchar2_table(152) := 'treet'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDEN';
wwv_flow_imp.g_varchar2_table(153) := 'T,LICENSE_PLATE,LOCATION,STATE) values (74,55,52,to_date(''10/19/2020'',''MM/DD/YYYY''),''EE053016'',''High';
wwv_flow_imp.g_varchar2_table(154) := 'way 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDEN';
wwv_flow_imp.g_varchar2_table(155) := 'T,LICENSE_PLATE,LOCATION,STATE) values (75,55,56,to_date(''10/02/2020'',''MM/DD/YYYY''),''544336457'',''Hig';
wwv_flow_imp.g_varchar2_table(156) := 'hway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDE';
wwv_flow_imp.g_varchar2_table(157) := 'NT,LICENSE_PLATE,LOCATION,STATE) values (76,35,29,to_date(''10/03/2020'',''MM/DD/YYYY''),''365510EE3'',''Ma';
wwv_flow_imp.g_varchar2_table(158) := 'in Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INC';
wwv_flow_imp.g_varchar2_table(159) := 'EDENT,LICENSE_PLATE,LOCATION,STATE) values (77,45,54,to_date(''09/23/2020'',''MM/DD/YYYY''),''3366510E7'',';
wwv_flow_imp.g_varchar2_table(160) := '''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_I';
wwv_flow_imp.g_varchar2_table(161) := 'NCEDENT,LICENSE_PLATE,LOCATION,STATE) values (78,45,48,to_date(''10/10/2020'',''MM/DD/YYYY''),''E05301005';
wwv_flow_imp.g_varchar2_table(162) := ''',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF';
wwv_flow_imp.g_varchar2_table(163) := '_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (79,35,44,to_date(''10/16/2020'',''MM/DD/YYYY''),''5443368';
wwv_flow_imp.g_varchar2_table(164) := ''',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_O';
wwv_flow_imp.g_varchar2_table(165) := 'F_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (80,55,54,to_date(''10/15/2020'',''MM/DD/YYYY''),''20EF54';
wwv_flow_imp.g_varchar2_table(166) := '3'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF';
wwv_flow_imp.g_varchar2_table(167) := '_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (81,55,62,to_date(''10/11/2020'',''MM/DD/YYYY''),''EF54433';
wwv_flow_imp.g_varchar2_table(168) := '4'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF';
wwv_flow_imp.g_varchar2_table(169) := '_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (82,25,32,to_date(''10/15/2020'',''MM/DD/YYYY''),''0EE0530';
wwv_flow_imp.g_varchar2_table(170) := '7'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_';
wwv_flow_imp.g_varchar2_table(171) := 'OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (83,45,48,to_date(''09/25/2020'',''MM/DD/YYYY''),''05301';
wwv_flow_imp.g_varchar2_table(172) := '05'',''River Road'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_';
wwv_flow_imp.g_varchar2_table(173) := 'OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (84,35,44,to_date(''10/04/2020'',''MM/DD/YYYY''),''EE053';
wwv_flow_imp.g_varchar2_table(174) := '01'',''Main Street'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE';
wwv_flow_imp.g_varchar2_table(175) := '_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (85,35,37,to_date(''10/18/2020'',''MM/DD/YYYY''),''4433';
wwv_flow_imp.g_varchar2_table(176) := '6E5'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DAT';
wwv_flow_imp.g_varchar2_table(177) := 'E_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (86,55,55,to_date(''10/17/2020'',''MM/DD/YYYY''),''336';
wwv_flow_imp.g_varchar2_table(178) := 'F5107'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DAT';
wwv_flow_imp.g_varchar2_table(179) := 'E_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (87,55,63,to_date(''10/19/2020'',''MM/DD/YYYY''),''544';
wwv_flow_imp.g_varchar2_table(180) := '337051'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DA';
wwv_flow_imp.g_varchar2_table(181) := 'TE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (88,55,79,to_date(''10/19/2020'',''MM/DD/YYYY''),''71';
wwv_flow_imp.g_varchar2_table(182) := '510EE1'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DA';
wwv_flow_imp.g_varchar2_table(183) := 'TE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (89,55,51,to_date(''10/16/2020'',''MM/DD/YYYY''),''33';
wwv_flow_imp.g_varchar2_table(184) := '72517'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DAT';
wwv_flow_imp.g_varchar2_table(185) := 'E_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (90,55,82,to_date(''10/08/2020'',''MM/DD/YYYY''),''E05';
wwv_flow_imp.g_varchar2_table(186) := '3012'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE';
wwv_flow_imp.g_varchar2_table(187) := '_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (91,35,47,to_date(''10/16/2020'',''MM/DD/YYYY''),''E053';
wwv_flow_imp.g_varchar2_table(188) := '012'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DAT';
wwv_flow_imp.g_varchar2_table(189) := 'E_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (92,35,28,to_date(''09/22/2020'',''MM/DD/YYYY''),''510';
wwv_flow_imp.g_varchar2_table(190) := 'EE057'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,D';
wwv_flow_imp.g_varchar2_table(191) := 'ATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (93,45,40,to_date(''09/21/2020'',''MM/DD/YYYY''),''0';
wwv_flow_imp.g_varchar2_table(192) := '5301002'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,';
wwv_flow_imp.g_varchar2_table(193) := 'DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (94,55,55,to_date(''10/16/2020'',''MM/DD/YYYY''),''';
wwv_flow_imp.g_varchar2_table(194) := '0EF5443'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,D';
wwv_flow_imp.g_varchar2_table(195) := 'ATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (95,55,50,to_date(''10/06/2020'',''MM/DD/YYYY''),''8';
wwv_flow_imp.g_varchar2_table(196) := '510EE8'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DA';
wwv_flow_imp.g_varchar2_table(197) := 'TE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (96,55,64,to_date(''10/17/2020'',''MM/DD/YYYY''),''05';
wwv_flow_imp.g_varchar2_table(198) := '301006'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DA';
wwv_flow_imp.g_varchar2_table(199) := 'TE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (97,35,33,to_date(''09/25/2020'',''MM/DD/YYYY''),''05';
wwv_flow_imp.g_varchar2_table(200) := '30107'',''Main Street'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,D';
wwv_flow_imp.g_varchar2_table(201) := 'ATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (98,55,55,to_date(''10/18/2020'',''MM/DD/YYYY''),''F';
wwv_flow_imp.g_varchar2_table(202) := '5443378'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,D';
wwv_flow_imp.g_varchar2_table(203) := 'ATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (99,55,53,to_date(''10/11/2020'',''MM/DD/YYYY''),''0';
wwv_flow_imp.g_varchar2_table(204) := '53010006'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,';
wwv_flow_imp.g_varchar2_table(205) := 'DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (100,55,64,to_date(''09/22/2020'',''MM/DD/YYYY''),';
wwv_flow_imp.g_varchar2_table(206) := '''EF5443377'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEE';
wwv_flow_imp.g_varchar2_table(207) := 'D,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (101,55,63,to_date(''10/18/2020'',''MM/DD/YYYY''';
wwv_flow_imp.g_varchar2_table(208) := '),''337E513'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEE';
wwv_flow_imp.g_varchar2_table(209) := 'D,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (102,45,45,to_date(''09/23/2020'',''MM/DD/YYYY''';
wwv_flow_imp.g_varchar2_table(210) := '),''053010002'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_S';
wwv_flow_imp.g_varchar2_table(211) := 'PEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (103,35,34,to_date(''09/23/2020'',''MM/DD/YY';
wwv_flow_imp.g_varchar2_table(212) := 'YY''),''54433803'',''Main Street'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICL';
wwv_flow_imp.g_varchar2_table(213) := 'E_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (104,45,49,to_date(''10/17/2020'',''MM/DD';
wwv_flow_imp.g_varchar2_table(214) := '/YYYY''),''EF5443385'',''River Road'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEH';
wwv_flow_imp.g_varchar2_table(215) := 'ICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (105,55,49,to_date(''09/28/2020'',''MM';
wwv_flow_imp.g_varchar2_table(216) := '/DD/YYYY''),''EE05305'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEH';
wwv_flow_imp.g_varchar2_table(217) := 'ICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (106,25,20,to_date(''09/24/2020'',''MM';
wwv_flow_imp.g_varchar2_table(218) := '/DD/YYYY''),''83510EE05'',''School Road'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED';
wwv_flow_imp.g_varchar2_table(219) := ',VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (107,35,40,to_date(''10/05/2020''';
wwv_flow_imp.g_varchar2_table(220) := ',''MM/DD/YYYY''),''F544333'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPE';
wwv_flow_imp.g_varchar2_table(221) := 'ED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (108,55,50,to_date(''09/29/202';
wwv_flow_imp.g_varchar2_table(222) := '0'',''MM/DD/YYYY''),''E05301007'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_S';
wwv_flow_imp.g_varchar2_table(223) := 'PEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (109,35,37,to_date(''09/27/2';
wwv_flow_imp.g_varchar2_table(224) := '020'',''MM/DD/YYYY''),''0EF544333'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POST';
wwv_flow_imp.g_varchar2_table(225) := 'ED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (110,45,49,to_date(''09/';
wwv_flow_imp.g_varchar2_table(226) := '23/2020'',''MM/DD/YYYY''),''544338752'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,P';
wwv_flow_imp.g_varchar2_table(227) := 'OSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (111,55,56,to_date(''';
wwv_flow_imp.g_varchar2_table(228) := '10/06/2020'',''MM/DD/YYYY''),''EE0530103'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID';
wwv_flow_imp.g_varchar2_table(229) := ',POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (112,55,54,to_date';
wwv_flow_imp.g_varchar2_table(230) := '(''09/28/2020'',''MM/DD/YYYY''),''EF544336'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (I';
wwv_flow_imp.g_varchar2_table(231) := 'D,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (113,35,36,to_dat';
wwv_flow_imp.g_varchar2_table(232) := 'e(''09/27/2020'',''MM/DD/YYYY''),''0EE053018'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEE';
wwv_flow_imp.g_varchar2_table(233) := 'D (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (114,55,53,to';
wwv_flow_imp.g_varchar2_table(234) := '_date(''10/03/2020'',''MM/DD/YYYY''),''53010004'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPE';
wwv_flow_imp.g_varchar2_table(235) := 'ED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (115,55,49,t';
wwv_flow_imp.g_varchar2_table(236) := 'o_date(''09/28/2020'',''MM/DD/YYYY''),''EE05304'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPE';
wwv_flow_imp.g_varchar2_table(237) := 'ED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (116,55,62,t';
wwv_flow_imp.g_varchar2_table(238) := 'o_date(''10/10/2020'',''MM/DD/YYYY''),''44338D8'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPE';
wwv_flow_imp.g_varchar2_table(239) := 'ED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (117,45,47,t';
wwv_flow_imp.g_varchar2_table(240) := 'o_date(''10/19/2020'',''MM/DD/YYYY''),''0EE0531'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SP';
wwv_flow_imp.g_varchar2_table(241) := 'EED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (118,55,89,';
wwv_flow_imp.g_varchar2_table(242) := 'to_date(''09/24/2020'',''MM/DD/YYYY''),''338F510E2'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_';
wwv_flow_imp.g_varchar2_table(243) := 'SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (119,55,5';
wwv_flow_imp.g_varchar2_table(244) := '5,to_date(''09/19/2020'',''MM/DD/YYYY''),''510EE02'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_';
wwv_flow_imp.g_varchar2_table(245) := 'SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (120,55,4';
wwv_flow_imp.g_varchar2_table(246) := '5,to_date(''10/17/2020'',''MM/DD/YYYY''),''053010008'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICL';
wwv_flow_imp.g_varchar2_table(247) := 'E_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (121,55';
wwv_flow_imp.g_varchar2_table(248) := ',69,to_date(''09/26/2020'',''MM/DD/YYYY''),''510EE051'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHIC';
wwv_flow_imp.g_varchar2_table(249) := 'LE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (122,3';
wwv_flow_imp.g_varchar2_table(250) := '5,36,to_date(''10/10/2020'',''MM/DD/YYYY''),''B20EF548'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VE';
wwv_flow_imp.g_varchar2_table(251) := 'HICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (12';
wwv_flow_imp.g_varchar2_table(252) := '3,35,37,to_date(''09/19/2020'',''MM/DD/YYYY''),''20EF545'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_';
wwv_flow_imp.g_varchar2_table(253) := 'VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (';
wwv_flow_imp.g_varchar2_table(254) := '124,45,39,to_date(''09/28/2020'',''MM/DD/YYYY''),''530100005'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CA';
wwv_flow_imp.g_varchar2_table(255) := 'RD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) value';
wwv_flow_imp.g_varchar2_table(256) := 's (125,55,57,to_date(''10/16/2020'',''MM/DD/YYYY''),''4433965'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CA';
wwv_flow_imp.g_varchar2_table(257) := 'RD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) value';
wwv_flow_imp.g_varchar2_table(258) := 's (126,25,26,to_date(''09/28/2020'',''MM/DD/YYYY''),''7510EE7'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_';
wwv_flow_imp.g_varchar2_table(259) := 'CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) val';
wwv_flow_imp.g_varchar2_table(260) := 'ues (127,55,49,to_date(''10/19/2020'',''MM/DD/YYYY''),''53010008'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO';
wwv_flow_imp.g_varchar2_table(261) := '_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) va';
wwv_flow_imp.g_varchar2_table(262) := 'lues (128,35,35,to_date(''09/30/2020'',''MM/DD/YYYY''),''399510EE4'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_';
wwv_flow_imp.g_varchar2_table(263) := 'DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE';
wwv_flow_imp.g_varchar2_table(264) := ') values (129,55,55,to_date(''10/08/2020'',''MM/DD/YYYY''),''0EE05308'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA';
wwv_flow_imp.g_varchar2_table(265) := '_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STAT';
wwv_flow_imp.g_varchar2_table(266) := 'E) values (130,55,59,to_date(''09/28/2020'',''MM/DD/YYYY''),''544339B7'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EB';
wwv_flow_imp.g_varchar2_table(267) := 'A_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STA';
wwv_flow_imp.g_varchar2_table(268) := 'TE) values (131,55,59,to_date(''09/19/2020'',''MM/DD/YYYY''),''39C510E4'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into E';
wwv_flow_imp.g_varchar2_table(269) := 'BA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,ST';
wwv_flow_imp.g_varchar2_table(270) := 'ATE) values (132,45,67,to_date(''09/23/2020'',''MM/DD/YYYY''),''053010004'',''River Road'',''VA'');'||wwv_flow.LF||
'insert int';
wwv_flow_imp.g_varchar2_table(271) := 'o EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION';
wwv_flow_imp.g_varchar2_table(272) := ',STATE) values (133,55,48,to_date(''10/08/2020'',''MM/DD/YYYY''),''510EE0538'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert i';
wwv_flow_imp.g_varchar2_table(273) := 'nto EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATI';
wwv_flow_imp.g_varchar2_table(274) := 'ON,STATE) values (134,55,59,to_date(''10/11/2020'',''MM/DD/YYYY''),''053010007'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert';
wwv_flow_imp.g_varchar2_table(275) := ' into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCA';
wwv_flow_imp.g_varchar2_table(276) := 'TION,STATE) values (135,55,57,to_date(''10/19/2020'',''MM/DD/YYYY''),''0EF544333'',''Highway 5'',''VA'');'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(277) := 'rt into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LO';
wwv_flow_imp.g_varchar2_table(278) := 'CATION,STATE) values (136,55,51,to_date(''09/27/2020'',''MM/DD/YYYY''),''3A1510E1'',''Highway 5'',''VA'');'||wwv_flow.LF||
'ins';
wwv_flow_imp.g_varchar2_table(279) := 'ert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,L';
wwv_flow_imp.g_varchar2_table(280) := 'OCATION,STATE) values (137,45,39,to_date(''09/20/2020'',''MM/DD/YYYY''),''EF54433A5'',''River Road'',''VA'');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(281) := 'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLAT';
wwv_flow_imp.g_varchar2_table(282) := 'E,LOCATION,STATE) values (138,55,52,to_date(''10/06/2020'',''MM/DD/YYYY''),''EF54435'',''Highway 5'',''MD'');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(283) := 'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLAT';
wwv_flow_imp.g_varchar2_table(284) := 'E,LOCATION,STATE) values (139,45,53,to_date(''10/17/2020'',''MM/DD/YYYY''),''0EE053018'',''River Road'',''MD''';
wwv_flow_imp.g_varchar2_table(285) := ');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_P';
wwv_flow_imp.g_varchar2_table(286) := 'LATE,LOCATION,STATE) values (140,55,49,to_date(''10/14/2020'',''MM/DD/YYYY''),''F54433A53'',''Highway 5'',''V';
wwv_flow_imp.g_varchar2_table(287) := 'A'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE';
wwv_flow_imp.g_varchar2_table(288) := '_PLATE,LOCATION,STATE) values (141,35,34,to_date(''10/17/2020'',''MM/DD/YYYY''),''33A65103'',''Main Street''';
wwv_flow_imp.g_varchar2_table(289) := ',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICE';
wwv_flow_imp.g_varchar2_table(290) := 'NSE_PLATE,LOCATION,STATE) values (142,25,33,to_date(''10/10/2020'',''MM/DD/YYYY''),''530100007'',''School R';
wwv_flow_imp.g_varchar2_table(291) := 'oad'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,';
wwv_flow_imp.g_varchar2_table(292) := 'LICENSE_PLATE,LOCATION,STATE) values (143,35,41,to_date(''10/12/2020'',''MM/DD/YYYY''),''F544337'',''Main S';
wwv_flow_imp.g_varchar2_table(293) := 'treet'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDEN';
wwv_flow_imp.g_varchar2_table(294) := 'T,LICENSE_PLATE,LOCATION,STATE) values (144,55,50,to_date(''10/08/2020'',''MM/DD/YYYY''),''510EE0531'',''Hi';
wwv_flow_imp.g_varchar2_table(295) := 'ghway 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCED';
wwv_flow_imp.g_varchar2_table(296) := 'ENT,LICENSE_PLATE,LOCATION,STATE) values (145,45,45,to_date(''10/01/2020'',''MM/DD/YYYY''),''AA510EE07'',''';
wwv_flow_imp.g_varchar2_table(297) := 'River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_IN';
wwv_flow_imp.g_varchar2_table(298) := 'CEDENT,LICENSE_PLATE,LOCATION,STATE) values (146,45,44,to_date(''09/27/2020'',''MM/DD/YYYY''),''10EE05303';
wwv_flow_imp.g_varchar2_table(299) := ''',''River Road'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF';
wwv_flow_imp.g_varchar2_table(300) := '_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (147,35,41,to_date(''10/05/2020'',''MM/DD/YYYY''),''B20EF5';
wwv_flow_imp.g_varchar2_table(301) := '3'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_';
wwv_flow_imp.g_varchar2_table(302) := 'OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (148,55,55,to_date(''10/17/2020'',''MM/DD/YYYY''),''EF54';
wwv_flow_imp.g_varchar2_table(303) := '4332'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE';
wwv_flow_imp.g_varchar2_table(304) := '_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (149,45,76,to_date(''10/02/2020'',''MM/DD/YYYY''),''EE0';
wwv_flow_imp.g_varchar2_table(305) := '53018'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DA';
wwv_flow_imp.g_varchar2_table(306) := 'TE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (150,35,44,to_date(''09/19/2020'',''MM/DD/YYYY''),''E';
wwv_flow_imp.g_varchar2_table(307) := '053013'',''Main Street'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,';
wwv_flow_imp.g_varchar2_table(308) := 'DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (151,55,62,to_date(''09/28/2020'',''MM/DD/YYYY''),';
wwv_flow_imp.g_varchar2_table(309) := '''05301007'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED';
wwv_flow_imp.g_varchar2_table(310) := ',DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (152,55,75,to_date(''09/26/2020'',''MM/DD/YYYY'')';
wwv_flow_imp.g_varchar2_table(311) := ',''54433B154'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPE';
wwv_flow_imp.g_varchar2_table(312) := 'ED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (153,45,43,to_date(''10/02/2020'',''MM/DD/YYYY';
wwv_flow_imp.g_varchar2_table(313) := '''),''33B2518'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SP';
wwv_flow_imp.g_varchar2_table(314) := 'EED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (154,55,55,to_date(''09/22/2020'',''MM/DD/YYY';
wwv_flow_imp.g_varchar2_table(315) := 'Y''),''0EF54437'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_S';
wwv_flow_imp.g_varchar2_table(316) := 'PEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (155,55,60,to_date(''10/17/2020'',''MM/DD/YY';
wwv_flow_imp.g_varchar2_table(317) := 'YY''),''0EE0538'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_S';
wwv_flow_imp.g_varchar2_table(318) := 'PEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (156,55,53,to_date(''10/16/2020'',''MM/DD/YY';
wwv_flow_imp.g_varchar2_table(319) := 'YY''),''B5510EE2'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_';
wwv_flow_imp.g_varchar2_table(320) := 'SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (157,35,36,to_date(''10/08/2020'',''MM/DD/Y';
wwv_flow_imp.g_varchar2_table(321) := 'YYY''),''F544332'',''Main Street'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICL';
wwv_flow_imp.g_varchar2_table(322) := 'E_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (158,55,57,to_date(''10/18/2020'',''MM/DD';
wwv_flow_imp.g_varchar2_table(323) := '/YYYY''),''B20EF5442'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHI';
wwv_flow_imp.g_varchar2_table(324) := 'CLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (159,45,51,to_date(''10/17/2020'',''MM/';
wwv_flow_imp.g_varchar2_table(325) := 'DD/YYYY''),''05301006'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VE';
wwv_flow_imp.g_varchar2_table(326) := 'HICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (160,55,59,to_date(''10/19/2020'',''M';
wwv_flow_imp.g_varchar2_table(327) := 'M/DD/YYYY''),''B9510E5'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VE';
wwv_flow_imp.g_varchar2_table(328) := 'HICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (161,55,55,to_date(''10/08/2020'',''M';
wwv_flow_imp.g_varchar2_table(329) := 'M/DD/YYYY''),''053010001'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,';
wwv_flow_imp.g_varchar2_table(330) := 'VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (162,55,50,to_date(''09/24/2020'',';
wwv_flow_imp.g_varchar2_table(331) := '''MM/DD/YYYY''),''10EE057'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,';
wwv_flow_imp.g_varchar2_table(332) := 'VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (163,45,41,to_date(''10/04/2020'',';
wwv_flow_imp.g_varchar2_table(333) := '''MM/DD/YYYY''),''EE0530108'',''River Road'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPE';
wwv_flow_imp.g_varchar2_table(334) := 'ED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (164,55,54,to_date(''09/26/202';
wwv_flow_imp.g_varchar2_table(335) := '0'',''MM/DD/YYYY''),''433BD5106'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_S';
wwv_flow_imp.g_varchar2_table(336) := 'PEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (165,45,52,to_date(''09/19/2';
wwv_flow_imp.g_varchar2_table(337) := '020'',''MM/DD/YYYY''),''510EE03'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_';
wwv_flow_imp.g_varchar2_table(338) := 'SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (166,55,86,to_date(''09/30/';
wwv_flow_imp.g_varchar2_table(339) := '2020'',''MM/DD/YYYY''),''BF510EE3'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED';
wwv_flow_imp.g_varchar2_table(340) := '_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (167,55,67,to_date(''10/09';
wwv_flow_imp.g_varchar2_table(341) := '/2020'',''MM/DD/YYYY''),''05301008'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTE';
wwv_flow_imp.g_varchar2_table(342) := 'D_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (168,45,39,to_date(''10/1';
wwv_flow_imp.g_varchar2_table(343) := '0/2020'',''MM/DD/YYYY''),''510EE0532'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,PO';
wwv_flow_imp.g_varchar2_table(344) := 'STED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (169,45,51,to_date(''1';
wwv_flow_imp.g_varchar2_table(345) := '0/09/2020'',''MM/DD/YYYY''),''433C251'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,P';
wwv_flow_imp.g_varchar2_table(346) := 'OSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (170,45,40,to_date(''';
wwv_flow_imp.g_varchar2_table(347) := '10/09/2020'',''MM/DD/YYYY''),''F544334'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,';
wwv_flow_imp.g_varchar2_table(348) := 'POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (171,45,38,to_date(';
wwv_flow_imp.g_varchar2_table(349) := '''10/10/2020'',''MM/DD/YYYY''),''20EF5448'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (I';
wwv_flow_imp.g_varchar2_table(350) := 'D,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (172,35,33,to_dat';
wwv_flow_imp.g_varchar2_table(351) := 'e(''10/10/2020'',''MM/DD/YYYY''),''53010007'',''Main Street'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED';
wwv_flow_imp.g_varchar2_table(352) := ' (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (173,25,34,to_';
wwv_flow_imp.g_varchar2_table(353) := 'date(''09/21/2020'',''MM/DD/YYYY''),''C6510EE8'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SP';
wwv_flow_imp.g_varchar2_table(354) := 'EED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (174,55,59,';
wwv_flow_imp.g_varchar2_table(355) := 'to_date(''10/14/2020'',''MM/DD/YYYY''),''7510EE1'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SP';
wwv_flow_imp.g_varchar2_table(356) := 'EED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (175,25,28,';
wwv_flow_imp.g_varchar2_table(357) := 'to_date(''09/26/2020'',''MM/DD/YYYY''),''54433C4'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_';
wwv_flow_imp.g_varchar2_table(358) := 'SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (176,45,4';
wwv_flow_imp.g_varchar2_table(359) := '8,to_date(''10/08/2020'',''MM/DD/YYYY''),''9510EE058'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHIC';
wwv_flow_imp.g_varchar2_table(360) := 'LE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (177,5';
wwv_flow_imp.g_varchar2_table(361) := '5,52,to_date(''09/24/2020'',''MM/DD/YYYY''),''A510EE4'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHIC';
wwv_flow_imp.g_varchar2_table(362) := 'LE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (178,2';
wwv_flow_imp.g_varchar2_table(363) := '5,25,to_date(''09/27/2020'',''MM/DD/YYYY''),''E053017'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEH';
wwv_flow_imp.g_varchar2_table(364) := 'ICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (179';
wwv_flow_imp.g_varchar2_table(365) := ',55,48,to_date(''10/11/2020'',''MM/DD/YYYY''),''510EE06'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEH';
wwv_flow_imp.g_varchar2_table(366) := 'ICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (180';
wwv_flow_imp.g_varchar2_table(367) := ',55,53,to_date(''10/14/2020'',''MM/DD/YYYY''),''4433CD514'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_V';
wwv_flow_imp.g_varchar2_table(368) := 'EHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (1';
wwv_flow_imp.g_varchar2_table(369) := '81,55,89,to_date(''10/12/2020'',''MM/DD/YYYY''),''510EE054'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_';
wwv_flow_imp.g_varchar2_table(370) := 'VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (';
wwv_flow_imp.g_varchar2_table(371) := '182,55,55,to_date(''10/15/2020'',''MM/DD/YYYY''),''F544336'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_';
wwv_flow_imp.g_varchar2_table(372) := 'VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (';
wwv_flow_imp.g_varchar2_table(373) := '183,55,58,to_date(''10/10/2020'',''MM/DD/YYYY''),''F54433D2'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD';
wwv_flow_imp.g_varchar2_table(374) := '_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values ';
wwv_flow_imp.g_varchar2_table(375) := '(184,55,64,to_date(''09/20/2020'',''MM/DD/YYYY''),''0EF544331'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CA';
wwv_flow_imp.g_varchar2_table(376) := 'RD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) value';
wwv_flow_imp.g_varchar2_table(377) := 's (185,55,63,to_date(''10/03/2020'',''MM/DD/YYYY''),''2510EE1'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CA';
wwv_flow_imp.g_varchar2_table(378) := 'RD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) value';
wwv_flow_imp.g_varchar2_table(379) := 's (186,55,55,to_date(''09/22/2020'',''MM/DD/YYYY''),''D3510E4'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CA';
wwv_flow_imp.g_varchar2_table(380) := 'RD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) value';
wwv_flow_imp.g_varchar2_table(381) := 's (187,35,45,to_date(''10/02/2020'',''MM/DD/YYYY''),''433D4516'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO';
wwv_flow_imp.g_varchar2_table(382) := '_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) va';
wwv_flow_imp.g_varchar2_table(383) := 'lues (188,35,31,to_date(''09/25/2020'',''MM/DD/YYYY''),''33D55104'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_D';
wwv_flow_imp.g_varchar2_table(384) := 'EMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE)';
wwv_flow_imp.g_varchar2_table(385) := ' values (189,55,59,to_date(''09/24/2020'',''MM/DD/YYYY''),''33D6510E4'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA';
wwv_flow_imp.g_varchar2_table(386) := '_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STAT';
wwv_flow_imp.g_varchar2_table(387) := 'E) values (190,45,41,to_date(''09/26/2020'',''MM/DD/YYYY''),''E0530106'',''River Road'',''MD'');'||wwv_flow.LF||
'insert into E';
wwv_flow_imp.g_varchar2_table(388) := 'BA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,ST';
wwv_flow_imp.g_varchar2_table(389) := 'ATE) values (191,35,36,to_date(''10/02/2020'',''MM/DD/YYYY''),''D8510EE07'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert in';
wwv_flow_imp.g_varchar2_table(390) := 'to EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATIO';
wwv_flow_imp.g_varchar2_table(391) := 'N,STATE) values (192,35,33,to_date(''10/17/2020'',''MM/DD/YYYY''),''510EE053'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert';
wwv_flow_imp.g_varchar2_table(392) := ' into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCA';
wwv_flow_imp.g_varchar2_table(393) := 'TION,STATE) values (193,55,59,to_date(''09/20/2020'',''MM/DD/YYYY''),''530100008'',''Highway 5'',''VA'');'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(394) := 'rt into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LO';
wwv_flow_imp.g_varchar2_table(395) := 'CATION,STATE) values (194,55,53,to_date(''10/11/2020'',''MM/DD/YYYY''),''54433DB5'',''Highway 5'',''VA'');'||wwv_flow.LF||
'ins';
wwv_flow_imp.g_varchar2_table(396) := 'ert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,L';
wwv_flow_imp.g_varchar2_table(397) := 'OCATION,STATE) values (195,35,34,to_date(''10/18/2020'',''MM/DD/YYYY''),''0EF5447'',''Main Street'',''MD'');'||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(398) := 'nsert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE';
wwv_flow_imp.g_varchar2_table(399) := ',LOCATION,STATE) values (196,25,56,to_date(''10/18/2020'',''MM/DD/YYYY''),''0EF544336'',''School Road'',''DC''';
wwv_flow_imp.g_varchar2_table(400) := ');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_P';
wwv_flow_imp.g_varchar2_table(401) := 'LATE,LOCATION,STATE) values (197,45,66,to_date(''09/24/2020'',''MM/DD/YYYY''),''3DE510E7'',''River Road'',''V';
wwv_flow_imp.g_varchar2_table(402) := 'A'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE';
wwv_flow_imp.g_varchar2_table(403) := '_PLATE,LOCATION,STATE) values (198,45,71,to_date(''09/23/2020'',''MM/DD/YYYY''),''B20EF51'',''River Road'',''';
wwv_flow_imp.g_varchar2_table(404) := 'VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENS';
wwv_flow_imp.g_varchar2_table(405) := 'E_PLATE,LOCATION,STATE) values (199,55,50,to_date(''09/25/2020'',''MM/DD/YYYY''),''0510EE6'',''Highway 5'',''';
wwv_flow_imp.g_varchar2_table(406) := 'VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENS';
wwv_flow_imp.g_varchar2_table(407) := 'E_PLATE,LOCATION,STATE) values (200,45,38,to_date(''10/16/2020'',''MM/DD/YYYY''),''10EE0531'',''River Road''';
wwv_flow_imp.g_varchar2_table(408) := ',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICE';
wwv_flow_imp.g_varchar2_table(409) := 'NSE_PLATE,LOCATION,STATE) values (201,25,19,to_date(''09/26/2020'',''MM/DD/YYYY''),''5301003'',''School Roa';
wwv_flow_imp.g_varchar2_table(410) := 'd'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LI';
wwv_flow_imp.g_varchar2_table(411) := 'CENSE_PLATE,LOCATION,STATE) values (202,35,42,to_date(''10/13/2020'',''MM/DD/YYYY''),''3E3510EE8'',''Main S';
wwv_flow_imp.g_varchar2_table(412) := 'treet'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDEN';
wwv_flow_imp.g_varchar2_table(413) := 'T,LICENSE_PLATE,LOCATION,STATE) values (203,55,62,to_date(''09/26/2020'',''MM/DD/YYYY''),''05301007'',''Hig';
wwv_flow_imp.g_varchar2_table(414) := 'hway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDE';
wwv_flow_imp.g_varchar2_table(415) := 'NT,LICENSE_PLATE,LOCATION,STATE) values (204,25,33,to_date(''10/13/2020'',''MM/DD/YYYY''),''F54433E56'',''S';
wwv_flow_imp.g_varchar2_table(416) := 'chool Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_IN';
wwv_flow_imp.g_varchar2_table(417) := 'CEDENT,LICENSE_PLATE,LOCATION,STATE) values (205,55,71,to_date(''10/19/2020'',''MM/DD/YYYY''),''510EE054''';
wwv_flow_imp.g_varchar2_table(418) := ',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_I';
wwv_flow_imp.g_varchar2_table(419) := 'NCEDENT,LICENSE_PLATE,LOCATION,STATE) values (206,55,64,to_date(''10/17/2020'',''MM/DD/YYYY''),''E0530107';
wwv_flow_imp.g_varchar2_table(420) := ''',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_';
wwv_flow_imp.g_varchar2_table(421) := 'INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (207,55,84,to_date(''09/30/2020'',''MM/DD/YYYY''),''5301000';
wwv_flow_imp.g_varchar2_table(422) := '04'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_O';
wwv_flow_imp.g_varchar2_table(423) := 'F_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (208,55,64,to_date(''10/13/2020'',''MM/DD/YYYY''),''20EF5';
wwv_flow_imp.g_varchar2_table(424) := '42'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_O';
wwv_flow_imp.g_varchar2_table(425) := 'F_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (209,55,51,to_date(''10/16/2020'',''MM/DD/YYYY''),''EF544';
wwv_flow_imp.g_varchar2_table(426) := '335'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_';
wwv_flow_imp.g_varchar2_table(427) := 'OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (210,55,82,to_date(''09/26/2020'',''MM/DD/YYYY''),''5301';
wwv_flow_imp.g_varchar2_table(428) := '00001'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DAT';
wwv_flow_imp.g_varchar2_table(429) := 'E_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (211,55,82,to_date(''10/13/2020'',''MM/DD/YYYY''),''C5';
wwv_flow_imp.g_varchar2_table(430) := '10EE6'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DAT';
wwv_flow_imp.g_varchar2_table(431) := 'E_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (212,55,51,to_date(''09/27/2020'',''MM/DD/YYYY''),''43';
wwv_flow_imp.g_varchar2_table(432) := '3ED516'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DA';
wwv_flow_imp.g_varchar2_table(433) := 'TE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (213,25,21,to_date(''10/19/2020'',''MM/DD/YYYY''),''B';
wwv_flow_imp.g_varchar2_table(434) := '20EF542'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED';
wwv_flow_imp.g_varchar2_table(435) := ',DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (214,55,54,to_date(''09/21/2020'',''MM/DD/YYYY'')';
wwv_flow_imp.g_varchar2_table(436) := ',''EF510EE2'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEE';
wwv_flow_imp.g_varchar2_table(437) := 'D,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (215,55,62,to_date(''09/27/2020'',''MM/DD/YYYY''';
wwv_flow_imp.g_varchar2_table(438) := '),''0EF544331'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SP';
wwv_flow_imp.g_varchar2_table(439) := 'EED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (216,45,52,to_date(''10/01/2020'',''MM/DD/YYY';
wwv_flow_imp.g_varchar2_table(440) := 'Y''),''5301003'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_S';
wwv_flow_imp.g_varchar2_table(441) := 'PEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (217,55,60,to_date(''09/20/2020'',''MM/DD/YY';
wwv_flow_imp.g_varchar2_table(442) := 'YY''),''0EF5448'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_S';
wwv_flow_imp.g_varchar2_table(443) := 'PEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (218,25,20,to_date(''10/13/2020'',''MM/DD/YY';
wwv_flow_imp.g_varchar2_table(444) := 'YY''),''3510EE051'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHIC';
wwv_flow_imp.g_varchar2_table(445) := 'LE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (219,35,35,to_date(''10/02/2020'',''MM/D';
wwv_flow_imp.g_varchar2_table(446) := 'D/YYYY''),''33F45107'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VE';
wwv_flow_imp.g_varchar2_table(447) := 'HICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (220,55,57,to_date(''09/19/2020'',''M';
wwv_flow_imp.g_varchar2_table(448) := 'M/DD/YYYY''),''510EE053'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,V';
wwv_flow_imp.g_varchar2_table(449) := 'EHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (221,55,62,to_date(''09/27/2020'',''';
wwv_flow_imp.g_varchar2_table(450) := 'MM/DD/YYYY''),''0EE0536'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,V';
wwv_flow_imp.g_varchar2_table(451) := 'EHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (222,55,63,to_date(''09/27/2020'',''';
wwv_flow_imp.g_varchar2_table(452) := 'MM/DD/YYYY''),''0EE0536'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,V';
wwv_flow_imp.g_varchar2_table(453) := 'EHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (223,45,40,to_date(''10/07/2020'',''';
wwv_flow_imp.g_varchar2_table(454) := 'MM/DD/YYYY''),''E053012'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,';
wwv_flow_imp.g_varchar2_table(455) := 'VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (224,45,53,to_date(''09/24/2020'',';
wwv_flow_imp.g_varchar2_table(456) := '''MM/DD/YYYY''),''E053011'',''River Road'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED';
wwv_flow_imp.g_varchar2_table(457) := ',VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (225,45,53,to_date(''10/09/2020''';
wwv_flow_imp.g_varchar2_table(458) := ',''MM/DD/YYYY''),''B20EF5441'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SP';
wwv_flow_imp.g_varchar2_table(459) := 'EED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (226,45,43,to_date(''10/14/20';
wwv_flow_imp.g_varchar2_table(460) := '20'',''MM/DD/YYYY''),''10EE0532'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_';
wwv_flow_imp.g_varchar2_table(461) := 'SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (227,45,44,to_date(''10/02/';
wwv_flow_imp.g_varchar2_table(462) := '2020'',''MM/DD/YYYY''),''EE053015'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTE';
wwv_flow_imp.g_varchar2_table(463) := 'D_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (228,25,38,to_date(''10/0';
wwv_flow_imp.g_varchar2_table(464) := '1/2020'',''MM/DD/YYYY''),''4433FD516'',''School Road'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,P';
wwv_flow_imp.g_varchar2_table(465) := 'OSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (229,25,16,to_date(''';
wwv_flow_imp.g_varchar2_table(466) := '09/25/2020'',''MM/DD/YYYY''),''0EE053011'',''School Road'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (';
wwv_flow_imp.g_varchar2_table(467) := 'ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (230,55,57,to_da';
wwv_flow_imp.g_varchar2_table(468) := 'te(''10/01/2020'',''MM/DD/YYYY''),''0EE05304'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED ';
wwv_flow_imp.g_varchar2_table(469) := '(ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (231,45,45,to_d';
wwv_flow_imp.g_varchar2_table(470) := 'ate(''09/29/2020'',''MM/DD/YYYY''),''10EE0532'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEE';
wwv_flow_imp.g_varchar2_table(471) := 'D (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (232,55,63,to';
wwv_flow_imp.g_varchar2_table(472) := '_date(''10/07/2020'',''MM/DD/YYYY''),''01510EE07'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SP';
wwv_flow_imp.g_varchar2_table(473) := 'EED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (233,45,54,';
wwv_flow_imp.g_varchar2_table(474) := 'to_date(''10/04/2020'',''MM/DD/YYYY''),''4340251'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_S';
wwv_flow_imp.g_varchar2_table(475) := 'PEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (234,45,42';
wwv_flow_imp.g_varchar2_table(476) := ',to_date(''10/02/2020'',''MM/DD/YYYY''),''EE0530103'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICL';
wwv_flow_imp.g_varchar2_table(477) := 'E_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (235,45';
wwv_flow_imp.g_varchar2_table(478) := ',44,to_date(''10/18/2020'',''MM/DD/YYYY''),''434045103'',''River Road'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEH';
wwv_flow_imp.g_varchar2_table(479) := 'ICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (236';
wwv_flow_imp.g_varchar2_table(480) := ',45,43,to_date(''10/09/2020'',''MM/DD/YYYY''),''510EE0531'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_';
wwv_flow_imp.g_varchar2_table(481) := 'VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (';
wwv_flow_imp.g_varchar2_table(482) := '237,55,49,to_date(''10/14/2020'',''MM/DD/YYYY''),''406510E4'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD';
wwv_flow_imp.g_varchar2_table(483) := '_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values ';
wwv_flow_imp.g_varchar2_table(484) := '(238,45,41,to_date(''10/03/2020'',''MM/DD/YYYY''),''7510EE05'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CA';
wwv_flow_imp.g_varchar2_table(485) := 'RD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) value';
wwv_flow_imp.g_varchar2_table(486) := 's (239,35,35,to_date(''09/20/2020'',''MM/DD/YYYY''),''10EE052'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_';
wwv_flow_imp.g_varchar2_table(487) := 'CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) val';
wwv_flow_imp.g_varchar2_table(488) := 'ues (240,45,51,to_date(''10/19/2020'',''MM/DD/YYYY''),''B20EF57'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO';
wwv_flow_imp.g_varchar2_table(489) := '_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) va';
wwv_flow_imp.g_varchar2_table(490) := 'lues (241,35,40,to_date(''10/08/2020'',''MM/DD/YYYY''),''40A510EE8'',''Main Street'',''PA'');'||wwv_flow.LF||
'insert into EBA_';
wwv_flow_imp.g_varchar2_table(491) := 'DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE';
wwv_flow_imp.g_varchar2_table(492) := ') values (242,25,27,to_date(''10/19/2020'',''MM/DD/YYYY''),''40B510EE3'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into ';
wwv_flow_imp.g_varchar2_table(493) := 'EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,S';
wwv_flow_imp.g_varchar2_table(494) := 'TATE) values (243,45,42,to_date(''10/08/2020'',''MM/DD/YYYY''),''5301003'',''River Road'',''MD'');'||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(495) := ' EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,';
wwv_flow_imp.g_varchar2_table(496) := 'STATE) values (244,55,52,to_date(''10/02/2020'',''MM/DD/YYYY''),''0D510E2'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(497) := ' EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,';
wwv_flow_imp.g_varchar2_table(498) := 'STATE) values (245,55,85,to_date(''10/17/2020'',''MM/DD/YYYY''),''4340E512'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert int';
wwv_flow_imp.g_varchar2_table(499) := 'o EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION';
wwv_flow_imp.g_varchar2_table(500) := ',STATE) values (246,55,64,to_date(''10/13/2020'',''MM/DD/YYYY''),''E0530102'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert in';
wwv_flow_imp.g_varchar2_table(501) := 'to EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATIO';
wwv_flow_imp.g_varchar2_table(502) := 'N,STATE) values (247,55,54,to_date(''10/19/2020'',''MM/DD/YYYY''),''F544348'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert in';
wwv_flow_imp.g_varchar2_table(503) := 'to EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATIO';
wwv_flow_imp.g_varchar2_table(504) := 'N,STATE) values (248,45,75,to_date(''10/18/2020'',''MM/DD/YYYY''),''20EF541'',''River Road'',''PA'');'||wwv_flow.LF||
'insert i';
wwv_flow_imp.g_varchar2_table(505) := 'nto EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATI';
wwv_flow_imp.g_varchar2_table(506) := 'ON,STATE) values (249,35,29,to_date(''09/21/2020'',''MM/DD/YYYY''),''EF544345'',''Main Street'',''VA'');'||wwv_flow.LF||
'inser';
wwv_flow_imp.g_varchar2_table(507) := 't into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOC';
wwv_flow_imp.g_varchar2_table(508) := 'ATION,STATE) values (250,55,57,to_date(''09/23/2020'',''MM/DD/YYYY''),''13510EE4'',''Highway 5'',''VA'');'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(509) := 'rt into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LO';
wwv_flow_imp.g_varchar2_table(510) := 'CATION,STATE) values (251,55,57,to_date(''09/25/2020'',''MM/DD/YYYY''),''4434147'',''Highway 5'',''MD'');'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(511) := 'rt into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LO';
wwv_flow_imp.g_varchar2_table(512) := 'CATION,STATE) values (252,55,49,to_date(''10/05/2020'',''MM/DD/YYYY''),''4155103'',''Highway 5'',''MD'');'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(513) := 'rt into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LO';
wwv_flow_imp.g_varchar2_table(514) := 'CATION,STATE) values (253,25,20,to_date(''10/18/2020'',''MM/DD/YYYY''),''053010002'',''School Road'',''VA'');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(515) := 'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLAT';
wwv_flow_imp.g_varchar2_table(516) := 'E,LOCATION,STATE) values (254,45,73,to_date(''09/25/2020'',''MM/DD/YYYY''),''417510E5'',''River Road'',''VA'')';
wwv_flow_imp.g_varchar2_table(517) := ';'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PL';
wwv_flow_imp.g_varchar2_table(518) := 'ATE,LOCATION,STATE) values (255,35,42,to_date(''10/07/2020'',''MM/DD/YYYY''),''544341854'',''Main Street'',''';
wwv_flow_imp.g_varchar2_table(519) := 'DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENS';
wwv_flow_imp.g_varchar2_table(520) := 'E_PLATE,LOCATION,STATE) values (256,45,44,to_date(''09/29/2020'',''MM/DD/YYYY''),''EE0530106'',''River Road';
wwv_flow_imp.g_varchar2_table(521) := ''',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LIC';
wwv_flow_imp.g_varchar2_table(522) := 'ENSE_PLATE,LOCATION,STATE) values (257,45,53,to_date(''10/04/2020'',''MM/DD/YYYY''),''EF544341'',''River Ro';
wwv_flow_imp.g_varchar2_table(523) := 'ad'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,L';
wwv_flow_imp.g_varchar2_table(524) := 'ICENSE_PLATE,LOCATION,STATE) values (258,25,27,to_date(''09/24/2020'',''MM/DD/YYYY''),''510EE052'',''School';
wwv_flow_imp.g_varchar2_table(525) := ' Road'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDEN';
wwv_flow_imp.g_varchar2_table(526) := 'T,LICENSE_PLATE,LOCATION,STATE) values (259,45,73,to_date(''09/26/2020'',''MM/DD/YYYY''),''0EF54433'',''Riv';
wwv_flow_imp.g_varchar2_table(527) := 'er Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCED';
wwv_flow_imp.g_varchar2_table(528) := 'ENT,LICENSE_PLATE,LOCATION,STATE) values (260,45,49,to_date(''09/27/2020'',''MM/DD/YYYY''),''D510EE057'',''';
wwv_flow_imp.g_varchar2_table(529) := 'River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_IN';
wwv_flow_imp.g_varchar2_table(530) := 'CEDENT,LICENSE_PLATE,LOCATION,STATE) values (261,55,53,to_date(''09/29/2020'',''MM/DD/YYYY''),''0EF54435''';
wwv_flow_imp.g_varchar2_table(531) := ',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_I';
wwv_flow_imp.g_varchar2_table(532) := 'NCEDENT,LICENSE_PLATE,LOCATION,STATE) values (262,55,51,to_date(''09/21/2020'',''MM/DD/YYYY''),''544341F6';
wwv_flow_imp.g_varchar2_table(533) := ''',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_';
wwv_flow_imp.g_varchar2_table(534) := 'INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (263,45,45,to_date(''09/20/2020'',''MM/DD/YYYY''),''4205102';
wwv_flow_imp.g_varchar2_table(535) := ''',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF';
wwv_flow_imp.g_varchar2_table(536) := '_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (264,45,42,to_date(''09/25/2020'',''MM/DD/YYYY''),''421510';
wwv_flow_imp.g_varchar2_table(537) := 'EE8'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE';
wwv_flow_imp.g_varchar2_table(538) := '_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (265,45,56,to_date(''09/25/2020'',''MM/DD/YYYY''),''20E';
wwv_flow_imp.g_varchar2_table(539) := 'F54434'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,D';
wwv_flow_imp.g_varchar2_table(540) := 'ATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (266,35,39,to_date(''10/06/2020'',''MM/DD/YYYY''),''';
wwv_flow_imp.g_varchar2_table(541) := '544342355'',''Main Street'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPE';
wwv_flow_imp.g_varchar2_table(542) := 'ED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (267,55,59,to_date(''10/15/2020'',''MM/DD/YYYY';
wwv_flow_imp.g_varchar2_table(543) := '''),''E053011'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPE';
wwv_flow_imp.g_varchar2_table(544) := 'ED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (268,35,35,to_date(''09/30/2020'',''MM/DD/YYYY';
wwv_flow_imp.g_varchar2_table(545) := '''),''425510E2'',''Main Street'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_';
wwv_flow_imp.g_varchar2_table(546) := 'SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (269,45,49,to_date(''10/08/2020'',''MM/DD/Y';
wwv_flow_imp.g_varchar2_table(547) := 'YYY''),''4342657'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE';
wwv_flow_imp.g_varchar2_table(548) := '_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (270,45,44,to_date(''09/25/2020'',''MM/DD/';
wwv_flow_imp.g_varchar2_table(549) := 'YYYY''),''530100007'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHI';
wwv_flow_imp.g_varchar2_table(550) := 'CLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (271,55,86,to_date(''10/07/2020'',''MM/';
wwv_flow_imp.g_varchar2_table(551) := 'DD/YYYY''),''053010001'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VE';
wwv_flow_imp.g_varchar2_table(552) := 'HICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (272,35,43,to_date(''10/01/2020'',''M';
wwv_flow_imp.g_varchar2_table(553) := 'M/DD/YYYY''),''EF544342'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED';
wwv_flow_imp.g_varchar2_table(554) := ',VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (273,55,61,to_date(''09/29/2020''';
wwv_flow_imp.g_varchar2_table(555) := ',''MM/DD/YYYY''),''B20EF58'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED';
wwv_flow_imp.g_varchar2_table(556) := ',VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (274,45,53,to_date(''09/23/2020''';
wwv_flow_imp.g_varchar2_table(557) := ',''MM/DD/YYYY''),''0EE053017'',''River Road'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SP';
wwv_flow_imp.g_varchar2_table(558) := 'EED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (275,35,28,to_date(''10/06/20';
wwv_flow_imp.g_varchar2_table(559) := '20'',''MM/DD/YYYY''),''4342C55'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_';
wwv_flow_imp.g_varchar2_table(560) := 'SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (276,55,64,to_date(''10/02/';
wwv_flow_imp.g_varchar2_table(561) := '2020'',''MM/DD/YYYY''),''510EE03'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_';
wwv_flow_imp.g_varchar2_table(562) := 'SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (277,25,25,to_date(''09/20/';
wwv_flow_imp.g_varchar2_table(563) := '2020'',''MM/DD/YYYY''),''B20EF5441'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POS';
wwv_flow_imp.g_varchar2_table(564) := 'TED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (278,55,55,to_date(''09';
wwv_flow_imp.g_varchar2_table(565) := '/29/2020'',''MM/DD/YYYY''),''EE0530106'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,P';
wwv_flow_imp.g_varchar2_table(566) := 'OSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (279,45,38,to_date(''';
wwv_flow_imp.g_varchar2_table(567) := '10/02/2020'',''MM/DD/YYYY''),''E05301005'',''River Road'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (I';
wwv_flow_imp.g_varchar2_table(568) := 'D,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (280,25,23,to_dat';
wwv_flow_imp.g_varchar2_table(569) := 'e(''09/29/2020'',''MM/DD/YYYY''),''4434312'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED ';
wwv_flow_imp.g_varchar2_table(570) := '(ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (281,45,51,to_d';
wwv_flow_imp.g_varchar2_table(571) := 'ate(''09/26/2020'',''MM/DD/YYYY''),''32510EE01'',''River Road'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPE';
wwv_flow_imp.g_varchar2_table(572) := 'ED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (282,45,39,t';
wwv_flow_imp.g_varchar2_table(573) := 'o_date(''10/13/2020'',''MM/DD/YYYY''),''0EF5445'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SP';
wwv_flow_imp.g_varchar2_table(574) := 'EED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (283,55,50,';
wwv_flow_imp.g_varchar2_table(575) := 'to_date(''10/03/2020'',''MM/DD/YYYY''),''E05301005'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_';
wwv_flow_imp.g_varchar2_table(576) := 'SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (284,55,5';
wwv_flow_imp.g_varchar2_table(577) := '8,to_date(''10/09/2020'',''MM/DD/YYYY''),''E053016'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_';
wwv_flow_imp.g_varchar2_table(578) := 'SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (285,45,4';
wwv_flow_imp.g_varchar2_table(579) := '5,to_date(''10/08/2020'',''MM/DD/YYYY''),''10EE05302'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHIC';
wwv_flow_imp.g_varchar2_table(580) := 'LE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (286,5';
wwv_flow_imp.g_varchar2_table(581) := '5,60,to_date(''09/19/2020'',''MM/DD/YYYY''),''20EF544'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHIC';
wwv_flow_imp.g_varchar2_table(582) := 'LE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (287,5';
wwv_flow_imp.g_varchar2_table(583) := '5,51,to_date(''10/12/2020'',''MM/DD/YYYY''),''53010007'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHI';
wwv_flow_imp.g_varchar2_table(584) := 'CLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (288,';
wwv_flow_imp.g_varchar2_table(585) := '55,49,to_date(''10/07/2020'',''MM/DD/YYYY''),''20EF54436'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VE';
wwv_flow_imp.g_varchar2_table(586) := 'HICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (28';
wwv_flow_imp.g_varchar2_table(587) := '9,35,37,to_date(''09/23/2020'',''MM/DD/YYYY''),''053010005'',''Main Street'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CAR';
wwv_flow_imp.g_varchar2_table(588) := 'D_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values';
wwv_flow_imp.g_varchar2_table(589) := ' (290,45,56,to_date(''09/20/2020'',''MM/DD/YYYY''),''053010002'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_';
wwv_flow_imp.g_varchar2_table(590) := 'CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) val';
wwv_flow_imp.g_varchar2_table(591) := 'ues (291,55,70,to_date(''09/24/2020'',''MM/DD/YYYY''),''E0530105'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO';
wwv_flow_imp.g_varchar2_table(592) := '_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) va';
wwv_flow_imp.g_varchar2_table(593) := 'lues (292,25,30,to_date(''09/25/2020'',''MM/DD/YYYY''),''4343D5101'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_';
wwv_flow_imp.g_varchar2_table(594) := 'DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE';
wwv_flow_imp.g_varchar2_table(595) := ') values (293,55,62,to_date(''09/19/2020'',''MM/DD/YYYY''),''530100005'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EB';
wwv_flow_imp.g_varchar2_table(596) := 'A_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STA';
wwv_flow_imp.g_varchar2_table(597) := 'TE) values (294,45,41,to_date(''09/22/2020'',''MM/DD/YYYY''),''3F510EE01'',''River Road'',''MD'');'||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(598) := ' EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,';
wwv_flow_imp.g_varchar2_table(599) := 'STATE) values (295,45,41,to_date(''09/21/2020'',''MM/DD/YYYY''),''EF54437'',''River Road'',''VA'');'||wwv_flow.LF||
'insert int';
wwv_flow_imp.g_varchar2_table(600) := 'o EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION';
wwv_flow_imp.g_varchar2_table(601) := ',STATE) values (296,55,58,to_date(''10/09/2020'',''MM/DD/YYYY''),''0EE05305'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert in';
wwv_flow_imp.g_varchar2_table(602) := 'to EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATIO';
wwv_flow_imp.g_varchar2_table(603) := 'N,STATE) values (297,45,54,to_date(''09/22/2020'',''MM/DD/YYYY''),''EE0530106'',''River Road'',''DC'');'||wwv_flow.LF||
'insert';
wwv_flow_imp.g_varchar2_table(604) := ' into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCA';
wwv_flow_imp.g_varchar2_table(605) := 'TION,STATE) values (298,35,39,to_date(''10/07/2020'',''MM/DD/YYYY''),''43443513'',''Main Street'',''VA'');'||wwv_flow.LF||
'ins';
wwv_flow_imp.g_varchar2_table(606) := 'ert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,L';
wwv_flow_imp.g_varchar2_table(607) := 'OCATION,STATE) values (299,45,66,to_date(''09/30/2020'',''MM/DD/YYYY''),''B20EF5441'',''River Road'',''VA'');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(608) := 'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLAT';
wwv_flow_imp.g_varchar2_table(609) := 'E,LOCATION,STATE) values (300,55,53,to_date(''09/28/2020'',''MM/DD/YYYY''),''45510E6'',''Highway 5'',''VA'');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(610) := 'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLAT';
wwv_flow_imp.g_varchar2_table(611) := 'E,LOCATION,STATE) values (301,55,60,to_date(''10/08/2020'',''MM/DD/YYYY''),''10EE05303'',''Highway 5'',''VA'')';
wwv_flow_imp.g_varchar2_table(612) := ';'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PL';
wwv_flow_imp.g_varchar2_table(613) := 'ATE,LOCATION,STATE) values (302,35,38,to_date(''09/30/2020'',''MM/DD/YYYY''),''10EE055'',''Main Street'',''VA';
wwv_flow_imp.g_varchar2_table(614) := ''');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_';
wwv_flow_imp.g_varchar2_table(615) := 'PLATE,LOCATION,STATE) values (303,45,54,to_date(''09/25/2020'',''MM/DD/YYYY''),''448510E3'',''River Road'',''';
wwv_flow_imp.g_varchar2_table(616) := 'VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENS';
wwv_flow_imp.g_varchar2_table(617) := 'E_PLATE,LOCATION,STATE) values (304,55,57,to_date(''10/08/2020'',''MM/DD/YYYY''),''EE053016'',''Highway 5'',';
wwv_flow_imp.g_varchar2_table(618) := '''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICEN';
wwv_flow_imp.g_varchar2_table(619) := 'SE_PLATE,LOCATION,STATE) values (305,55,61,to_date(''10/16/2020'',''MM/DD/YYYY''),''44344A54'',''Highway 5''';
wwv_flow_imp.g_varchar2_table(620) := ',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICE';
wwv_flow_imp.g_varchar2_table(621) := 'NSE_PLATE,LOCATION,STATE) values (306,55,52,to_date(''09/26/2020'',''MM/DD/YYYY''),''B20EF546'',''Highway 5';
wwv_flow_imp.g_varchar2_table(622) := ''',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LIC';
wwv_flow_imp.g_varchar2_table(623) := 'ENSE_PLATE,LOCATION,STATE) values (307,55,55,to_date(''10/18/2020'',''MM/DD/YYYY''),''C510EE053'',''Highway';
wwv_flow_imp.g_varchar2_table(624) := ' 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,L';
wwv_flow_imp.g_varchar2_table(625) := 'ICENSE_PLATE,LOCATION,STATE) values (308,35,40,to_date(''10/04/2020'',''MM/DD/YYYY''),''0EF5442'',''Main St';
wwv_flow_imp.g_varchar2_table(626) := 'reet'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT';
wwv_flow_imp.g_varchar2_table(627) := ',LICENSE_PLATE,LOCATION,STATE) values (309,45,49,to_date(''10/18/2020'',''MM/DD/YYYY''),''EE05306'',''River';
wwv_flow_imp.g_varchar2_table(628) := ' Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDEN';
wwv_flow_imp.g_varchar2_table(629) := 'T,LICENSE_PLATE,LOCATION,STATE) values (310,35,36,to_date(''10/03/2020'',''MM/DD/YYYY''),''0EF544347'',''Ma';
wwv_flow_imp.g_varchar2_table(630) := 'in Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INC';
wwv_flow_imp.g_varchar2_table(631) := 'EDENT,LICENSE_PLATE,LOCATION,STATE) values (311,25,25,to_date(''10/07/2020'',''MM/DD/YYYY''),''5443453'',''';
wwv_flow_imp.g_varchar2_table(632) := 'School Road'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_I';
wwv_flow_imp.g_varchar2_table(633) := 'NCEDENT,LICENSE_PLATE,LOCATION,STATE) values (312,55,57,to_date(''10/05/2020'',''MM/DD/YYYY''),''510EE058';
wwv_flow_imp.g_varchar2_table(634) := ''',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_';
wwv_flow_imp.g_varchar2_table(635) := 'INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (313,45,71,to_date(''09/24/2020'',''MM/DD/YYYY''),''510EE05';
wwv_flow_imp.g_varchar2_table(636) := '1'',''River Road'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_O';
wwv_flow_imp.g_varchar2_table(637) := 'F_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (314,35,37,to_date(''09/27/2020'',''MM/DD/YYYY''),''E0530';
wwv_flow_imp.g_varchar2_table(638) := '15'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE';
wwv_flow_imp.g_varchar2_table(639) := '_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (315,35,42,to_date(''10/07/2020'',''MM/DD/YYYY''),''0EF';
wwv_flow_imp.g_varchar2_table(640) := '54436'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,D';
wwv_flow_imp.g_varchar2_table(641) := 'ATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (316,55,56,to_date(''10/05/2020'',''MM/DD/YYYY''),''';
wwv_flow_imp.g_varchar2_table(642) := '10EE05303'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED';
wwv_flow_imp.g_varchar2_table(643) := ',DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (317,45,44,to_date(''09/25/2020'',''MM/DD/YYYY'')';
wwv_flow_imp.g_varchar2_table(644) := ',''434565108'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SP';
wwv_flow_imp.g_varchar2_table(645) := 'EED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (318,45,40,to_date(''10/16/2020'',''MM/DD/YYY';
wwv_flow_imp.g_varchar2_table(646) := 'Y''),''F54434572'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE';
wwv_flow_imp.g_varchar2_table(647) := '_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (319,55,62,to_date(''09/24/2020'',''MM/DD/';
wwv_flow_imp.g_varchar2_table(648) := 'YYYY''),''EF544343'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICL';
wwv_flow_imp.g_varchar2_table(649) := 'E_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (320,45,43,to_date(''10/08/2020'',''MM/DD';
wwv_flow_imp.g_varchar2_table(650) := '/YYYY''),''0EF54437'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHI';
wwv_flow_imp.g_varchar2_table(651) := 'CLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (321,35,47,to_date(''10/13/2020'',''MM/';
wwv_flow_imp.g_varchar2_table(652) := 'DD/YYYY''),''20EF5448'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,V';
wwv_flow_imp.g_varchar2_table(653) := 'EHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (322,45,46,to_date(''10/07/2020'',''';
wwv_flow_imp.g_varchar2_table(654) := 'MM/DD/YYYY''),''4345B5103'',''River Road'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEE';
wwv_flow_imp.g_varchar2_table(655) := 'D,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (323,55,53,to_date(''09/22/2020';
wwv_flow_imp.g_varchar2_table(656) := ''',''MM/DD/YYYY''),''44345C53'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPE';
wwv_flow_imp.g_varchar2_table(657) := 'ED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (324,55,50,to_date(''10/04/202';
wwv_flow_imp.g_varchar2_table(658) := '0'',''MM/DD/YYYY''),''44345D515'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_S';
wwv_flow_imp.g_varchar2_table(659) := 'PEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (325,55,54,to_date(''10/09/2';
wwv_flow_imp.g_varchar2_table(660) := '020'',''MM/DD/YYYY''),''44345E6'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_S';
wwv_flow_imp.g_varchar2_table(661) := 'PEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (326,35,31,to_date(''10/01/2';
wwv_flow_imp.g_varchar2_table(662) := '020'',''MM/DD/YYYY''),''5F510EE2'',''Main Street'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTE';
wwv_flow_imp.g_varchar2_table(663) := 'D_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (327,55,52,to_date(''10/0';
wwv_flow_imp.g_varchar2_table(664) := '6/2020'',''MM/DD/YYYY''),''20EF548'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTE';
wwv_flow_imp.g_varchar2_table(665) := 'D_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (328,25,29,to_date(''10/0';
wwv_flow_imp.g_varchar2_table(666) := '8/2020'',''MM/DD/YYYY''),''EF544341'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,PO';
wwv_flow_imp.g_varchar2_table(667) := 'STED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (329,55,76,to_date(''0';
wwv_flow_imp.g_varchar2_table(668) := '9/27/2020'',''MM/DD/YYYY''),''20EF54434'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,';
wwv_flow_imp.g_varchar2_table(669) := 'POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (330,55,55,to_date(';
wwv_flow_imp.g_varchar2_table(670) := '''09/23/2020'',''MM/DD/YYYY''),''54434634'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID';
wwv_flow_imp.g_varchar2_table(671) := ',POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (331,45,53,to_date';
wwv_flow_imp.g_varchar2_table(672) := '(''10/07/2020'',''MM/DD/YYYY''),''0EE05306'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (';
wwv_flow_imp.g_varchar2_table(673) := 'ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (332,45,49,to_da';
wwv_flow_imp.g_varchar2_table(674) := 'te(''10/04/2020'',''MM/DD/YYYY''),''5510EE052'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEE';
wwv_flow_imp.g_varchar2_table(675) := 'D (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (333,45,48,to';
wwv_flow_imp.g_varchar2_table(676) := '_date(''10/01/2020'',''MM/DD/YYYY''),''6510EE03'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SP';
wwv_flow_imp.g_varchar2_table(677) := 'EED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (334,55,53,';
wwv_flow_imp.g_varchar2_table(678) := 'to_date(''10/08/2020'',''MM/DD/YYYY''),''67510EE6'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_S';
wwv_flow_imp.g_varchar2_table(679) := 'PEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (335,55,61';
wwv_flow_imp.g_varchar2_table(680) := ',to_date(''09/20/2020'',''MM/DD/YYYY''),''B20EF546'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_';
wwv_flow_imp.g_varchar2_table(681) := 'SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (336,55,5';
wwv_flow_imp.g_varchar2_table(682) := '2,to_date(''09/28/2020'',''MM/DD/YYYY''),''10EE0534'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE';
wwv_flow_imp.g_varchar2_table(683) := '_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (337,35,';
wwv_flow_imp.g_varchar2_table(684) := '43,to_date(''09/23/2020'',''MM/DD/YYYY''),''B20EF5441'',''Main Street'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEH';
wwv_flow_imp.g_varchar2_table(685) := 'ICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (338';
wwv_flow_imp.g_varchar2_table(686) := ',45,50,to_date(''10/08/2020'',''MM/DD/YYYY''),''5301003'',''River Road'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VE';
wwv_flow_imp.g_varchar2_table(687) := 'HICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (33';
wwv_flow_imp.g_varchar2_table(688) := '9,55,55,to_date(''09/30/2020'',''MM/DD/YYYY''),''4346C5102'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_';
wwv_flow_imp.g_varchar2_table(689) := 'VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (';
wwv_flow_imp.g_varchar2_table(690) := '340,45,43,to_date(''10/11/2020'',''MM/DD/YYYY''),''0EF544346'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CA';
wwv_flow_imp.g_varchar2_table(691) := 'RD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) value';
wwv_flow_imp.g_varchar2_table(692) := 's (341,35,31,to_date(''09/30/2020'',''MM/DD/YYYY''),''F544346E1'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEM';
wwv_flow_imp.g_varchar2_table(693) := 'O_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) v';
wwv_flow_imp.g_varchar2_table(694) := 'alues (342,55,53,to_date(''10/19/2020'',''MM/DD/YYYY''),''5301004'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEM';
wwv_flow_imp.g_varchar2_table(695) := 'O_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) v';
wwv_flow_imp.g_varchar2_table(696) := 'alues (343,55,53,to_date(''10/18/2020'',''MM/DD/YYYY''),''470510E2'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DE';
wwv_flow_imp.g_varchar2_table(697) := 'MO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) ';
wwv_flow_imp.g_varchar2_table(698) := 'values (344,45,40,to_date(''10/14/2020'',''MM/DD/YYYY''),''71510EE06'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA';
wwv_flow_imp.g_varchar2_table(699) := '_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STAT';
wwv_flow_imp.g_varchar2_table(700) := 'E) values (345,55,89,to_date(''10/12/2020'',''MM/DD/YYYY''),''B20EF545'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EB';
wwv_flow_imp.g_varchar2_table(701) := 'A_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STA';
wwv_flow_imp.g_varchar2_table(702) := 'TE) values (346,55,58,to_date(''10/10/2020'',''MM/DD/YYYY''),''B20EF547'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into E';
wwv_flow_imp.g_varchar2_table(703) := 'BA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,ST';
wwv_flow_imp.g_varchar2_table(704) := 'ATE) values (347,45,44,to_date(''09/29/2020'',''MM/DD/YYYY''),''443474512'',''River Road'',''VA'');'||wwv_flow.LF||
'insert int';
wwv_flow_imp.g_varchar2_table(705) := 'o EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION';
wwv_flow_imp.g_varchar2_table(706) := ',STATE) values (348,35,41,to_date(''09/24/2020'',''MM/DD/YYYY''),''475510EE7'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert';
wwv_flow_imp.g_varchar2_table(707) := ' into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCA';
wwv_flow_imp.g_varchar2_table(708) := 'TION,STATE) values (349,25,22,to_date(''09/20/2020'',''MM/DD/YYYY''),''3476510E2'',''School Road'',''VA'');'||wwv_flow.LF||
'in';
wwv_flow_imp.g_varchar2_table(709) := 'sert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,';
wwv_flow_imp.g_varchar2_table(710) := 'LOCATION,STATE) values (350,35,40,to_date(''10/04/2020'',''MM/DD/YYYY''),''0EF544348'',''Main Street'',''VA'')';
wwv_flow_imp.g_varchar2_table(711) := ';'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PL';
wwv_flow_imp.g_varchar2_table(712) := 'ATE,LOCATION,STATE) values (351,45,51,to_date(''09/22/2020'',''MM/DD/YYYY''),''510EE0534'',''River Road'',''P';
wwv_flow_imp.g_varchar2_table(713) := 'A'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE';
wwv_flow_imp.g_varchar2_table(714) := '_PLATE,LOCATION,STATE) values (352,45,36,to_date(''10/04/2020'',''MM/DD/YYYY''),''EF54433'',''River Road'',''';
wwv_flow_imp.g_varchar2_table(715) := 'VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENS';
wwv_flow_imp.g_varchar2_table(716) := 'E_PLATE,LOCATION,STATE) values (353,55,56,to_date(''10/05/2020'',''MM/DD/YYYY''),''7A510EE02'',''Highway 5''';
wwv_flow_imp.g_varchar2_table(717) := ',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICE';
wwv_flow_imp.g_varchar2_table(718) := 'NSE_PLATE,LOCATION,STATE) values (354,55,50,to_date(''10/05/2020'',''MM/DD/YYYY''),''E053014'',''Highway 5''';
wwv_flow_imp.g_varchar2_table(719) := ',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICE';
wwv_flow_imp.g_varchar2_table(720) := 'NSE_PLATE,LOCATION,STATE) values (355,55,59,to_date(''10/16/2020'',''MM/DD/YYYY''),''510EE02'',''Highway 5''';
wwv_flow_imp.g_varchar2_table(721) := ',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICE';
wwv_flow_imp.g_varchar2_table(722) := 'NSE_PLATE,LOCATION,STATE) values (356,45,45,to_date(''09/30/2020'',''MM/DD/YYYY''),''544347D4'',''River Roa';
wwv_flow_imp.g_varchar2_table(723) := 'd'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LI';
wwv_flow_imp.g_varchar2_table(724) := 'CENSE_PLATE,LOCATION,STATE) values (357,55,64,to_date(''09/28/2020'',''MM/DD/YYYY''),''E053012'',''Highway ';
wwv_flow_imp.g_varchar2_table(725) := '5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LI';
wwv_flow_imp.g_varchar2_table(726) := 'CENSE_PLATE,LOCATION,STATE) values (358,45,50,to_date(''10/03/2020'',''MM/DD/YYYY''),''530100002'',''River ';
wwv_flow_imp.g_varchar2_table(727) := 'Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT';
wwv_flow_imp.g_varchar2_table(728) := ',LICENSE_PLATE,LOCATION,STATE) values (359,35,38,to_date(''09/23/2020'',''MM/DD/YYYY''),''480510E4'',''Main';
wwv_flow_imp.g_varchar2_table(729) := ' Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCED';
wwv_flow_imp.g_varchar2_table(730) := 'ENT,LICENSE_PLATE,LOCATION,STATE) values (360,45,39,to_date(''09/22/2020'',''MM/DD/YYYY''),''43481511'',''R';
wwv_flow_imp.g_varchar2_table(731) := 'iver Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INC';
wwv_flow_imp.g_varchar2_table(732) := 'EDENT,LICENSE_PLATE,LOCATION,STATE) values (361,35,31,to_date(''09/26/2020'',''MM/DD/YYYY''),''0EF54437'',';
wwv_flow_imp.g_varchar2_table(733) := '''Main Street'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_';
wwv_flow_imp.g_varchar2_table(734) := 'INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (362,55,58,to_date(''09/30/2020'',''MM/DD/YYYY''),''5301000';
wwv_flow_imp.g_varchar2_table(735) := '1'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF';
wwv_flow_imp.g_varchar2_table(736) := '_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (363,55,55,to_date(''09/24/2020'',''MM/DD/YYYY''),''0EF544';
wwv_flow_imp.g_varchar2_table(737) := '345'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_';
wwv_flow_imp.g_varchar2_table(738) := 'OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (364,35,37,to_date(''10/10/2020'',''MM/DD/YYYY''),''510E';
wwv_flow_imp.g_varchar2_table(739) := 'E04'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DAT';
wwv_flow_imp.g_varchar2_table(740) := 'E_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (365,45,43,to_date(''10/17/2020'',''MM/DD/YYYY''),''44';
wwv_flow_imp.g_varchar2_table(741) := '3486513'',''River Road'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,';
wwv_flow_imp.g_varchar2_table(742) := 'DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (366,55,55,to_date(''10/05/2020'',''MM/DD/YYYY''),';
wwv_flow_imp.g_varchar2_table(743) := '''0EF54436'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED';
wwv_flow_imp.g_varchar2_table(744) := ',DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (367,55,59,to_date(''10/02/2020'',''MM/DD/YYYY'')';
wwv_flow_imp.g_varchar2_table(745) := ',''8510EE05'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEE';
wwv_flow_imp.g_varchar2_table(746) := 'D,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (368,45,38,to_date(''09/25/2020'',''MM/DD/YYYY''';
wwv_flow_imp.g_varchar2_table(747) := '),''0EE0536'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPE';
wwv_flow_imp.g_varchar2_table(748) := 'ED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (369,55,75,to_date(''10/09/2020'',''MM/DD/YYYY';
wwv_flow_imp.g_varchar2_table(749) := '''),''48A510E5'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SP';
wwv_flow_imp.g_varchar2_table(750) := 'EED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (370,45,45,to_date(''10/12/2020'',''MM/DD/YYY';
wwv_flow_imp.g_varchar2_table(751) := 'Y''),''8B510E3'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_S';
wwv_flow_imp.g_varchar2_table(752) := 'PEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (371,55,62,to_date(''10/12/2020'',''MM/DD/YY';
wwv_flow_imp.g_varchar2_table(753) := 'YY''),''E05301004'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE';
wwv_flow_imp.g_varchar2_table(754) := '_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (372,45,52,to_date(''10/15/2020'',''MM/DD/';
wwv_flow_imp.g_varchar2_table(755) := 'YYYY''),''EF54437'',''River Road'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICL';
wwv_flow_imp.g_varchar2_table(756) := 'E_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (373,45,51,to_date(''10/01/2020'',''MM/DD';
wwv_flow_imp.g_varchar2_table(757) := '/YYYY''),''5301002'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHIC';
wwv_flow_imp.g_varchar2_table(758) := 'LE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (374,25,50,to_date(''10/16/2020'',''MM/D';
wwv_flow_imp.g_varchar2_table(759) := 'D/YYYY''),''E05301008'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,V';
wwv_flow_imp.g_varchar2_table(760) := 'EHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (375,55,45,to_date(''09/29/2020'',''';
wwv_flow_imp.g_varchar2_table(761) := 'MM/DD/YYYY''),''0EF5441'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,V';
wwv_flow_imp.g_varchar2_table(762) := 'EHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (376,45,45,to_date(''09/29/2020'',''';
wwv_flow_imp.g_varchar2_table(763) := 'MM/DD/YYYY''),''4349153'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,';
wwv_flow_imp.g_varchar2_table(764) := 'VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (377,45,52,to_date(''10/03/2020'',';
wwv_flow_imp.g_varchar2_table(765) := '''MM/DD/YYYY''),''43492513'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEE';
wwv_flow_imp.g_varchar2_table(766) := 'D,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (378,45,44,to_date(''09/27/2020';
wwv_flow_imp.g_varchar2_table(767) := ''',''MM/DD/YYYY''),''E0530101'',''River Road'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SP';
wwv_flow_imp.g_varchar2_table(768) := 'EED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (379,45,69,to_date(''10/11/20';
wwv_flow_imp.g_varchar2_table(769) := '20'',''MM/DD/YYYY''),''20EF54433'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED';
wwv_flow_imp.g_varchar2_table(770) := '_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (380,55,52,to_date(''10/07';
wwv_flow_imp.g_varchar2_table(771) := '/2020'',''MM/DD/YYYY''),''495510E5'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTE';
wwv_flow_imp.g_varchar2_table(772) := 'D_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (381,55,58,to_date(''10/1';
wwv_flow_imp.g_varchar2_table(773) := '2/2020'',''MM/DD/YYYY''),''4349658'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTE';
wwv_flow_imp.g_varchar2_table(774) := 'D_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (382,25,24,to_date(''09/2';
wwv_flow_imp.g_varchar2_table(775) := '0/2020'',''MM/DD/YYYY''),''3497512'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POS';
wwv_flow_imp.g_varchar2_table(776) := 'TED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (383,35,43,to_date(''10';
wwv_flow_imp.g_varchar2_table(777) := '/04/2020'',''MM/DD/YYYY''),''20EF5448'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,';
wwv_flow_imp.g_varchar2_table(778) := 'POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (384,45,53,to_date(';
wwv_flow_imp.g_varchar2_table(779) := '''09/21/2020'',''MM/DD/YYYY''),''053010007'',''River Road'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (';
wwv_flow_imp.g_varchar2_table(780) := 'ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (385,45,78,to_da';
wwv_flow_imp.g_varchar2_table(781) := 'te(''10/12/2020'',''MM/DD/YYYY''),''510EE05'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED ';
wwv_flow_imp.g_varchar2_table(782) := '(ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (386,45,42,to_d';
wwv_flow_imp.g_varchar2_table(783) := 'ate(''10/02/2020'',''MM/DD/YYYY''),''E0530108'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEE';
wwv_flow_imp.g_varchar2_table(784) := 'D (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (387,25,33,to';
wwv_flow_imp.g_varchar2_table(785) := '_date(''10/01/2020'',''MM/DD/YYYY''),''20EF5445'',''School Road'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_S';
wwv_flow_imp.g_varchar2_table(786) := 'PEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (388,55,50';
wwv_flow_imp.g_varchar2_table(787) := ',to_date(''10/10/2020'',''MM/DD/YYYY''),''EF5443494'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE';
wwv_flow_imp.g_varchar2_table(788) := '_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (389,35,';
wwv_flow_imp.g_varchar2_table(789) := '31,to_date(''10/16/2020'',''MM/DD/YYYY''),''EF5443493'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEH';
wwv_flow_imp.g_varchar2_table(790) := 'ICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (390';
wwv_flow_imp.g_varchar2_table(791) := ',35,29,to_date(''09/19/2020'',''MM/DD/YYYY''),''EF5443491'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD';
wwv_flow_imp.g_varchar2_table(792) := '_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values ';
wwv_flow_imp.g_varchar2_table(793) := '(391,45,57,to_date(''09/19/2020'',''MM/DD/YYYY''),''4A0510E5'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CA';
wwv_flow_imp.g_varchar2_table(794) := 'RD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) value';
wwv_flow_imp.g_varchar2_table(795) := 's (392,25,26,to_date(''09/24/2020'',''MM/DD/YYYY''),''530100005'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEM';
wwv_flow_imp.g_varchar2_table(796) := 'O_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) v';
wwv_flow_imp.g_varchar2_table(797) := 'alues (393,35,38,to_date(''10/17/2020'',''MM/DD/YYYY''),''54434A8'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_D';
wwv_flow_imp.g_varchar2_table(798) := 'EMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE)';
wwv_flow_imp.g_varchar2_table(799) := ' values (394,45,60,to_date(''10/11/2020'',''MM/DD/YYYY''),''4A3510E2'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA';
wwv_flow_imp.g_varchar2_table(800) := '_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STAT';
wwv_flow_imp.g_varchar2_table(801) := 'E) values (395,35,33,to_date(''09/28/2020'',''MM/DD/YYYY''),''54434A7'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into E';
wwv_flow_imp.g_varchar2_table(802) := 'BA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,ST';
wwv_flow_imp.g_varchar2_table(803) := 'ATE) values (396,35,43,to_date(''10/15/2020'',''MM/DD/YYYY''),''510EE0534'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert in';
wwv_flow_imp.g_varchar2_table(804) := 'to EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATIO';
wwv_flow_imp.g_varchar2_table(805) := 'N,STATE) values (397,25,18,to_date(''10/04/2020'',''MM/DD/YYYY''),''EF54434A6'',''School Road'',''VA'');'||wwv_flow.LF||
'inser';
wwv_flow_imp.g_varchar2_table(806) := 't into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOC';
wwv_flow_imp.g_varchar2_table(807) := 'ATION,STATE) values (398,55,52,to_date(''09/19/2020'',''MM/DD/YYYY''),''20EF54438'',''Highway 5'',''VA'');'||wwv_flow.LF||
'ins';
wwv_flow_imp.g_varchar2_table(808) := 'ert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,L';
wwv_flow_imp.g_varchar2_table(809) := 'OCATION,STATE) values (399,55,66,to_date(''10/11/2020'',''MM/DD/YYYY''),''05301005'',''Highway 5'',''VA'');'||wwv_flow.LF||
'in';
wwv_flow_imp.g_varchar2_table(810) := 'sert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,';
wwv_flow_imp.g_varchar2_table(811) := 'LOCATION,STATE) values (400,45,42,to_date(''09/19/2020'',''MM/DD/YYYY''),''EF54437'',''River Road'',''VA'');'||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(812) := 'nsert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE';
wwv_flow_imp.g_varchar2_table(813) := ',LOCATION,STATE) values (401,55,61,to_date(''09/29/2020'',''MM/DD/YYYY''),''A510EE054'',''Highway 5'',''DC'');';
wwv_flow_imp.g_varchar2_table(814) := ''||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLA';
wwv_flow_imp.g_varchar2_table(815) := 'TE,LOCATION,STATE) values (402,55,58,to_date(''10/07/2020'',''MM/DD/YYYY''),''0EE053018'',''Highway 5'',''DC''';
wwv_flow_imp.g_varchar2_table(816) := ');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_P';
wwv_flow_imp.g_varchar2_table(817) := 'LATE,LOCATION,STATE) values (403,25,25,to_date(''09/30/2020'',''MM/DD/YYYY''),''4434AC7'',''School Road'',''V';
wwv_flow_imp.g_varchar2_table(818) := 'A'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE';
wwv_flow_imp.g_varchar2_table(819) := '_PLATE,LOCATION,STATE) values (404,45,45,to_date(''10/09/2020'',''MM/DD/YYYY''),''F54434A4'',''River Road'',';
wwv_flow_imp.g_varchar2_table(820) := '''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICEN';
wwv_flow_imp.g_varchar2_table(821) := 'SE_PLATE,LOCATION,STATE) values (405,55,58,to_date(''09/29/2020'',''MM/DD/YYYY''),''510EE052'',''Highway 5''';
wwv_flow_imp.g_varchar2_table(822) := ',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICE';
wwv_flow_imp.g_varchar2_table(823) := 'NSE_PLATE,LOCATION,STATE) values (406,35,38,to_date(''09/28/2020'',''MM/DD/YYYY''),''0EF54432'',''Main Stre';
wwv_flow_imp.g_varchar2_table(824) := 'et'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,L';
wwv_flow_imp.g_varchar2_table(825) := 'ICENSE_PLATE,LOCATION,STATE) values (407,55,57,to_date(''10/03/2020'',''MM/DD/YYYY''),''54434B05'',''Highwa';
wwv_flow_imp.g_varchar2_table(826) := 'y 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,';
wwv_flow_imp.g_varchar2_table(827) := 'LICENSE_PLATE,LOCATION,STATE) values (408,55,64,to_date(''09/24/2020'',''MM/DD/YYYY''),''434B15107'',''High';
wwv_flow_imp.g_varchar2_table(828) := 'way 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDEN';
wwv_flow_imp.g_varchar2_table(829) := 'T,LICENSE_PLATE,LOCATION,STATE) values (409,55,49,to_date(''10/06/2020'',''MM/DD/YYYY''),''20EF547'',''High';
wwv_flow_imp.g_varchar2_table(830) := 'way 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDEN';
wwv_flow_imp.g_varchar2_table(831) := 'T,LICENSE_PLATE,LOCATION,STATE) values (410,55,53,to_date(''10/04/2020'',''MM/DD/YYYY''),''B3510EE04'',''Hi';
wwv_flow_imp.g_varchar2_table(832) := 'ghway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCED';
wwv_flow_imp.g_varchar2_table(833) := 'ENT,LICENSE_PLATE,LOCATION,STATE) values (411,55,62,to_date(''10/02/2020'',''MM/DD/YYYY''),''20EF54435'',''';
wwv_flow_imp.g_varchar2_table(834) := 'Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INC';
wwv_flow_imp.g_varchar2_table(835) := 'EDENT,LICENSE_PLATE,LOCATION,STATE) values (412,45,46,to_date(''10/17/2020'',''MM/DD/YYYY''),''EF54434B1''';
wwv_flow_imp.g_varchar2_table(836) := ',''River Road'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_';
wwv_flow_imp.g_varchar2_table(837) := 'INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (413,35,30,to_date(''10/13/2020'',''MM/DD/YYYY''),''6510EE0';
wwv_flow_imp.g_varchar2_table(838) := '56'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE';
wwv_flow_imp.g_varchar2_table(839) := '_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (414,55,44,to_date(''09/23/2020'',''MM/DD/YYYY''),''4B7';
wwv_flow_imp.g_varchar2_table(840) := '510EE3'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DA';
wwv_flow_imp.g_varchar2_table(841) := 'TE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (415,45,51,to_date(''10/05/2020'',''MM/DD/YYYY''),''0';
wwv_flow_imp.g_varchar2_table(842) := 'EE05301'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,';
wwv_flow_imp.g_varchar2_table(843) := 'DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (416,55,55,to_date(''10/12/2020'',''MM/DD/YYYY''),';
wwv_flow_imp.g_varchar2_table(844) := '''B20EF5448'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEE';
wwv_flow_imp.g_varchar2_table(845) := 'D,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (417,55,59,to_date(''10/16/2020'',''MM/DD/YYYY''';
wwv_flow_imp.g_varchar2_table(846) := '),''E053018'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEE';
wwv_flow_imp.g_varchar2_table(847) := 'D,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (418,55,61,to_date(''10/02/2020'',''MM/DD/YYYY''';
wwv_flow_imp.g_varchar2_table(848) := '),''E05301004'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SP';
wwv_flow_imp.g_varchar2_table(849) := 'EED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (419,35,48,to_date(''09/21/2020'',''MM/DD/YYY';
wwv_flow_imp.g_varchar2_table(850) := 'Y''),''4434BC1'',''Main Street'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_';
wwv_flow_imp.g_varchar2_table(851) := 'SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (420,45,45,to_date(''09/29/2020'',''MM/DD/Y';
wwv_flow_imp.g_varchar2_table(852) := 'YYY''),''0EE05306'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICL';
wwv_flow_imp.g_varchar2_table(853) := 'E_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (421,35,44,to_date(''10/08/2020'',''MM/DD';
wwv_flow_imp.g_varchar2_table(854) := '/YYYY''),''5301004'',''Main Street'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHI';
wwv_flow_imp.g_varchar2_table(855) := 'CLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (422,55,45,to_date(''09/30/2020'',''MM/';
wwv_flow_imp.g_varchar2_table(856) := 'DD/YYYY''),''54434BF6'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEH';
wwv_flow_imp.g_varchar2_table(857) := 'ICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (423,35,30,to_date(''10/08/2020'',''MM';
wwv_flow_imp.g_varchar2_table(858) := '/DD/YYYY''),''5301004'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,V';
wwv_flow_imp.g_varchar2_table(859) := 'EHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (424,55,60,to_date(''09/30/2020'',''';
wwv_flow_imp.g_varchar2_table(860) := 'MM/DD/YYYY''),''510EE052'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,';
wwv_flow_imp.g_varchar2_table(861) := 'VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (425,55,63,to_date(''09/23/2020'',';
wwv_flow_imp.g_varchar2_table(862) := '''MM/DD/YYYY''),''EF54434C1'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEE';
wwv_flow_imp.g_varchar2_table(863) := 'D,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (426,55,56,to_date(''10/01/2020';
wwv_flow_imp.g_varchar2_table(864) := ''',''MM/DD/YYYY''),''10EE05306'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SP';
wwv_flow_imp.g_varchar2_table(865) := 'EED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (427,55,48,to_date(''09/27/20';
wwv_flow_imp.g_varchar2_table(866) := '20'',''MM/DD/YYYY''),''510EE06'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SP';
wwv_flow_imp.g_varchar2_table(867) := 'EED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (428,55,64,to_date(''09/30/20';
wwv_flow_imp.g_varchar2_table(868) := '20'',''MM/DD/YYYY''),''05301006'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_S';
wwv_flow_imp.g_varchar2_table(869) := 'PEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (429,45,56,to_date(''10/05/2';
wwv_flow_imp.g_varchar2_table(870) := '020'',''MM/DD/YYYY''),''4C6510EE5'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTE';
wwv_flow_imp.g_varchar2_table(871) := 'D_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (430,55,64,to_date(''09/2';
wwv_flow_imp.g_varchar2_table(872) := '8/2020'',''MM/DD/YYYY''),''10EE058'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTE';
wwv_flow_imp.g_varchar2_table(873) := 'D_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (431,55,59,to_date(''10/0';
wwv_flow_imp.g_varchar2_table(874) := '9/2020'',''MM/DD/YYYY''),''510EE0537'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POS';
wwv_flow_imp.g_varchar2_table(875) := 'TED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (432,45,56,to_date(''10';
wwv_flow_imp.g_varchar2_table(876) := '/16/2020'',''MM/DD/YYYY''),''4C9510EE5'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,';
wwv_flow_imp.g_varchar2_table(877) := 'POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (433,25,19,to_date(';
wwv_flow_imp.g_varchar2_table(878) := '''10/13/2020'',''MM/DD/YYYY''),''434CA58'',''School Road'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (I';
wwv_flow_imp.g_varchar2_table(879) := 'D,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (434,45,52,to_dat';
wwv_flow_imp.g_varchar2_table(880) := 'e(''10/08/2020'',''MM/DD/YYYY''),''0EF54432'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED ';
wwv_flow_imp.g_varchar2_table(881) := '(ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (435,25,34,to_d';
wwv_flow_imp.g_varchar2_table(882) := 'ate(''10/02/2020'',''MM/DD/YYYY''),''34CC5107'',''School Road'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPE';
wwv_flow_imp.g_varchar2_table(883) := 'ED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (436,55,70,t';
wwv_flow_imp.g_varchar2_table(884) := 'o_date(''10/19/2020'',''MM/DD/YYYY''),''4434CD1'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPE';
wwv_flow_imp.g_varchar2_table(885) := 'ED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (437,55,62,t';
wwv_flow_imp.g_varchar2_table(886) := 'o_date(''10/17/2020'',''MM/DD/YYYY''),''4434CE511'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_S';
wwv_flow_imp.g_varchar2_table(887) := 'PEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (438,55,59';
wwv_flow_imp.g_varchar2_table(888) := ',to_date(''09/25/2020'',''MM/DD/YYYY''),''434CF5101'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE';
wwv_flow_imp.g_varchar2_table(889) := '_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (439,45,';
wwv_flow_imp.g_varchar2_table(890) := '48,to_date(''09/20/2020'',''MM/DD/YYYY''),''20EF541'',''River Road'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICL';
wwv_flow_imp.g_varchar2_table(891) := 'E_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (440,55';
wwv_flow_imp.g_varchar2_table(892) := ',51,to_date(''09/27/2020'',''MM/DD/YYYY''),''54434D154'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHI';
wwv_flow_imp.g_varchar2_table(893) := 'CLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (441,';
wwv_flow_imp.g_varchar2_table(894) := '55,55,to_date(''10/06/2020'',''MM/DD/YYYY''),''34D2515'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHI';
wwv_flow_imp.g_varchar2_table(895) := 'CLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (442,';
wwv_flow_imp.g_varchar2_table(896) := '45,44,to_date(''09/24/2020'',''MM/DD/YYYY''),''4434D3518'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_V';
wwv_flow_imp.g_varchar2_table(897) := 'EHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (4';
wwv_flow_imp.g_varchar2_table(898) := '43,35,44,to_date(''10/05/2020'',''MM/DD/YYYY''),''54434D5'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD';
wwv_flow_imp.g_varchar2_table(899) := '_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values ';
wwv_flow_imp.g_varchar2_table(900) := '(444,55,61,to_date(''09/30/2020'',''MM/DD/YYYY''),''EE053011'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CAR';
wwv_flow_imp.g_varchar2_table(901) := 'D_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values';
wwv_flow_imp.g_varchar2_table(902) := ' (445,55,52,to_date(''09/24/2020'',''MM/DD/YYYY''),''20EF5448'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CA';
wwv_flow_imp.g_varchar2_table(903) := 'RD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) value';
wwv_flow_imp.g_varchar2_table(904) := 's (446,45,50,to_date(''10/06/2020'',''MM/DD/YYYY''),''B20EF55'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_C';
wwv_flow_imp.g_varchar2_table(905) := 'ARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) valu';
wwv_flow_imp.g_varchar2_table(906) := 'es (447,55,51,to_date(''10/01/2020'',''MM/DD/YYYY''),''20EF547'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_C';
wwv_flow_imp.g_varchar2_table(907) := 'ARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) valu';
wwv_flow_imp.g_varchar2_table(908) := 'es (448,35,29,to_date(''10/12/2020'',''MM/DD/YYYY''),''510EE0531'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DE';
wwv_flow_imp.g_varchar2_table(909) := 'MO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) ';
wwv_flow_imp.g_varchar2_table(910) := 'values (449,55,58,to_date(''10/06/2020'',''MM/DD/YYYY''),''34DA510E4'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_';
wwv_flow_imp.g_varchar2_table(911) := 'DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE';
wwv_flow_imp.g_varchar2_table(912) := ') values (450,45,53,to_date(''10/09/2020'',''MM/DD/YYYY''),''0EF5443'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA';
wwv_flow_imp.g_varchar2_table(913) := '_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STAT';
wwv_flow_imp.g_varchar2_table(914) := 'E) values (451,45,44,to_date(''09/22/2020'',''MM/DD/YYYY''),''DC510EE03'',''River Road'',''PA'');'||wwv_flow.LF||
'insert into ';
wwv_flow_imp.g_varchar2_table(915) := 'EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,S';
wwv_flow_imp.g_varchar2_table(916) := 'TATE) values (452,35,29,to_date(''09/26/2020'',''MM/DD/YYYY''),''4434DD515'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert i';
wwv_flow_imp.g_varchar2_table(917) := 'nto EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATI';
wwv_flow_imp.g_varchar2_table(918) := 'ON,STATE) values (453,55,62,to_date(''10/05/2020'',''MM/DD/YYYY''),''EE0530101'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert';
wwv_flow_imp.g_varchar2_table(919) := ' into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCA';
wwv_flow_imp.g_varchar2_table(920) := 'TION,STATE) values (454,55,64,to_date(''10/13/2020'',''MM/DD/YYYY''),''0EF5442'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert';
wwv_flow_imp.g_varchar2_table(921) := ' into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCA';
wwv_flow_imp.g_varchar2_table(922) := 'TION,STATE) values (455,45,40,to_date(''10/13/2020'',''MM/DD/YYYY''),''510EE055'',''River Road'',''DC'');'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(923) := 'rt into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LO';
wwv_flow_imp.g_varchar2_table(924) := 'CATION,STATE) values (456,55,51,to_date(''09/25/2020'',''MM/DD/YYYY''),''10EE055'',''Highway 5'',''VA'');'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(925) := 'rt into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LO';
wwv_flow_imp.g_varchar2_table(926) := 'CATION,STATE) values (457,45,51,to_date(''09/20/2020'',''MM/DD/YYYY''),''20EF5446'',''River Road'',''VA'');'||wwv_flow.LF||
'in';
wwv_flow_imp.g_varchar2_table(927) := 'sert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,';
wwv_flow_imp.g_varchar2_table(928) := 'LOCATION,STATE) values (458,55,49,to_date(''09/29/2020'',''MM/DD/YYYY''),''20EF5441'',''Highway 5'',''VA'');'||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(929) := 'nsert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE';
wwv_flow_imp.g_varchar2_table(930) := ',LOCATION,STATE) values (459,25,34,to_date(''10/19/2020'',''MM/DD/YYYY''),''54434E3'',''School Road'',''PA'');';
wwv_flow_imp.g_varchar2_table(931) := ''||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLA';
wwv_flow_imp.g_varchar2_table(932) := 'TE,LOCATION,STATE) values (460,45,42,to_date(''10/03/2020'',''MM/DD/YYYY''),''B20EF5448'',''River Road'',''MD';
wwv_flow_imp.g_varchar2_table(933) := ''');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_';
wwv_flow_imp.g_varchar2_table(934) := 'PLATE,LOCATION,STATE) values (461,55,50,to_date(''10/14/2020'',''MM/DD/YYYY''),''4E6510EE6'',''Highway 5'',''';
wwv_flow_imp.g_varchar2_table(935) := 'DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENS';
wwv_flow_imp.g_varchar2_table(936) := 'E_PLATE,LOCATION,STATE) values (462,35,42,to_date(''09/27/2020'',''MM/DD/YYYY''),''053010001'',''Main Stree';
wwv_flow_imp.g_varchar2_table(937) := 't'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LI';
wwv_flow_imp.g_varchar2_table(938) := 'CENSE_PLATE,LOCATION,STATE) values (463,55,61,to_date(''10/19/2020'',''MM/DD/YYYY''),''EF54434E3'',''Highwa';
wwv_flow_imp.g_varchar2_table(939) := 'y 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,';
wwv_flow_imp.g_varchar2_table(940) := 'LICENSE_PLATE,LOCATION,STATE) values (464,55,55,to_date(''10/16/2020'',''MM/DD/YYYY''),''20EF5442'',''Highw';
wwv_flow_imp.g_varchar2_table(941) := 'ay 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT';
wwv_flow_imp.g_varchar2_table(942) := ',LICENSE_PLATE,LOCATION,STATE) values (465,55,62,to_date(''10/01/2020'',''MM/DD/YYYY''),''434EA5101'',''Hig';
wwv_flow_imp.g_varchar2_table(943) := 'hway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDE';
wwv_flow_imp.g_varchar2_table(944) := 'NT,LICENSE_PLATE,LOCATION,STATE) values (466,35,57,to_date(''10/13/2020'',''MM/DD/YYYY''),''EE053017'',''Ma';
wwv_flow_imp.g_varchar2_table(945) := 'in Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INC';
wwv_flow_imp.g_varchar2_table(946) := 'EDENT,LICENSE_PLATE,LOCATION,STATE) values (467,45,47,to_date(''10/13/2020'',''MM/DD/YYYY''),''C510EE3'',''';
wwv_flow_imp.g_varchar2_table(947) := 'River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_IN';
wwv_flow_imp.g_varchar2_table(948) := 'CEDENT,LICENSE_PLATE,LOCATION,STATE) values (468,55,53,to_date(''10/01/2020'',''MM/DD/YYYY''),''34ED510E2';
wwv_flow_imp.g_varchar2_table(949) := ''',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_';
wwv_flow_imp.g_varchar2_table(950) := 'INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (469,35,33,to_date(''10/10/2020'',''MM/DD/YYYY''),''34EE514';
wwv_flow_imp.g_varchar2_table(951) := ''',''Main Street'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_O';
wwv_flow_imp.g_varchar2_table(952) := 'F_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (470,55,52,to_date(''10/19/2020'',''MM/DD/YYYY''),''F5443';
wwv_flow_imp.g_varchar2_table(953) := '42'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_O';
wwv_flow_imp.g_varchar2_table(954) := 'F_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (471,45,43,to_date(''09/30/2020'',''MM/DD/YYYY''),''0EE05';
wwv_flow_imp.g_varchar2_table(955) := '305'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE';
wwv_flow_imp.g_varchar2_table(956) := '_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (472,55,51,to_date(''09/24/2020'',''MM/DD/YYYY''),''510';
wwv_flow_imp.g_varchar2_table(957) := 'EE04'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE';
wwv_flow_imp.g_varchar2_table(958) := '_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (473,25,26,to_date(''10/10/2020'',''MM/DD/YYYY''),''434';
wwv_flow_imp.g_varchar2_table(959) := 'F252'',''School Road'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DA';
wwv_flow_imp.g_varchar2_table(960) := 'TE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (474,25,25,to_date(''09/24/2020'',''MM/DD/YYYY''),''5';
wwv_flow_imp.g_varchar2_table(961) := '4434F36'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED';
wwv_flow_imp.g_varchar2_table(962) := ',DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (475,55,51,to_date(''10/13/2020'',''MM/DD/YYYY'')';
wwv_flow_imp.g_varchar2_table(963) := ',''F54434F42'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPE';
wwv_flow_imp.g_varchar2_table(964) := 'ED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (476,55,50,to_date(''10/16/2020'',''MM/DD/YYYY';
wwv_flow_imp.g_varchar2_table(965) := '''),''F54434F51'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_S';
wwv_flow_imp.g_varchar2_table(966) := 'PEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (477,55,58,to_date(''09/29/2020'',''MM/DD/YY';
wwv_flow_imp.g_varchar2_table(967) := 'YY''),''34F65103'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_';
wwv_flow_imp.g_varchar2_table(968) := 'SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (478,55,55,to_date(''10/17/2020'',''MM/DD/Y';
wwv_flow_imp.g_varchar2_table(969) := 'YYY''),''E053016'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_';
wwv_flow_imp.g_varchar2_table(970) := 'SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (479,55,48,to_date(''09/21/2020'',''MM/DD/Y';
wwv_flow_imp.g_varchar2_table(971) := 'YYY''),''E0530108'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE';
wwv_flow_imp.g_varchar2_table(972) := '_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (480,55,55,to_date(''09/30/2020'',''MM/DD/';
wwv_flow_imp.g_varchar2_table(973) := 'YYYY''),''F544347'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE';
wwv_flow_imp.g_varchar2_table(974) := '_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (481,55,55,to_date(''09/26/2020'',''MM/DD/';
wwv_flow_imp.g_varchar2_table(975) := 'YYYY''),''0530105'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE';
wwv_flow_imp.g_varchar2_table(976) := '_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (482,45,43,to_date(''10/15/2020'',''MM/DD/';
wwv_flow_imp.g_varchar2_table(977) := 'YYYY''),''053010006'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHI';
wwv_flow_imp.g_varchar2_table(978) := 'CLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (483,55,48,to_date(''10/18/2020'',''MM/';
wwv_flow_imp.g_varchar2_table(979) := 'DD/YYYY''),''4FC510EE8'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VE';
wwv_flow_imp.g_varchar2_table(980) := 'HICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (484,35,32,to_date(''09/29/2020'',''M';
wwv_flow_imp.g_varchar2_table(981) := 'M/DD/YYYY''),''510EE07'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,';
wwv_flow_imp.g_varchar2_table(982) := 'VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (485,45,72,to_date(''09/24/2020'',';
wwv_flow_imp.g_varchar2_table(983) := '''MM/DD/YYYY''),''4434FE8'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED';
wwv_flow_imp.g_varchar2_table(984) := ',VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (486,45,39,to_date(''09/25/2020''';
wwv_flow_imp.g_varchar2_table(985) := ',''MM/DD/YYYY''),''34FF510E8'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SP';
wwv_flow_imp.g_varchar2_table(986) := 'EED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (487,55,59,to_date(''09/27/20';
wwv_flow_imp.g_varchar2_table(987) := '20'',''MM/DD/YYYY''),''EF5443503'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_';
wwv_flow_imp.g_varchar2_table(988) := 'SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (488,45,45,to_date(''10/01/';
wwv_flow_imp.g_varchar2_table(989) := '2020'',''MM/DD/YYYY''),''F544358'',''River Road'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED';
wwv_flow_imp.g_varchar2_table(990) := '_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (489,55,64,to_date(''10/11';
wwv_flow_imp.g_varchar2_table(991) := '/2020'',''MM/DD/YYYY''),''B20EF5444'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POST';
wwv_flow_imp.g_varchar2_table(992) := 'ED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (490,35,42,to_date(''09/';
wwv_flow_imp.g_varchar2_table(993) := '21/2020'',''MM/DD/YYYY''),''510EE0536'',''Main Street'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,';
wwv_flow_imp.g_varchar2_table(994) := 'POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (491,45,50,to_date(';
wwv_flow_imp.g_varchar2_table(995) := '''09/22/2020'',''MM/DD/YYYY''),''EE05304'',''River Road'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID';
wwv_flow_imp.g_varchar2_table(996) := ',POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (492,55,55,to_date';
wwv_flow_imp.g_varchar2_table(997) := '(''10/02/2020'',''MM/DD/YYYY''),''505510EE2'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (';
wwv_flow_imp.g_varchar2_table(998) := 'ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (493,35,29,to_da';
wwv_flow_imp.g_varchar2_table(999) := 'te(''10/05/2020'',''MM/DD/YYYY''),''44350655'',''Main Street'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEE';
wwv_flow_imp.g_varchar2_table(1000) := 'D (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (494,25,28,to';
wwv_flow_imp.g_varchar2_table(1001) := '_date(''09/23/2020'',''MM/DD/YYYY''),''507510EE2'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_';
wwv_flow_imp.g_varchar2_table(1002) := 'SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (495,55,6';
wwv_flow_imp.g_varchar2_table(1003) := '6,to_date(''10/17/2020'',''MM/DD/YYYY''),''44350856'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE';
wwv_flow_imp.g_varchar2_table(1004) := '_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (496,35,';
wwv_flow_imp.g_varchar2_table(1005) := '42,to_date(''10/04/2020'',''MM/DD/YYYY''),''510EE057'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHI';
wwv_flow_imp.g_varchar2_table(1006) := 'CLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (497,';
wwv_flow_imp.g_varchar2_table(1007) := '45,50,to_date(''09/18/2020'',''MM/DD/YYYY''),''0EF5445'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEH';
wwv_flow_imp.g_varchar2_table(1008) := 'ICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (498';
wwv_flow_imp.g_varchar2_table(1009) := ',35,40,to_date(''10/09/2020'',''MM/DD/YYYY''),''530100007'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD';
wwv_flow_imp.g_varchar2_table(1010) := '_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values ';
wwv_flow_imp.g_varchar2_table(1011) := '(499,55,72,to_date(''09/25/2020'',''MM/DD/YYYY''),''4350C5102'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CA';
wwv_flow_imp.g_varchar2_table(1012) := 'RD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) value';
wwv_flow_imp.g_varchar2_table(1013) := 's (500,35,67,to_date(''10/19/2020'',''MM/DD/YYYY''),''0530103'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_';
wwv_flow_imp.g_varchar2_table(1014) := 'CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) val';
wwv_flow_imp.g_varchar2_table(1015) := 'ues (501,35,42,to_date(''09/30/2020'',''MM/DD/YYYY''),''20EF54432'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_D';
wwv_flow_imp.g_varchar2_table(1016) := 'EMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE)';
wwv_flow_imp.g_varchar2_table(1017) := ' values (502,55,55,to_date(''10/11/2020'',''MM/DD/YYYY''),''0EF54437'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_';
wwv_flow_imp.g_varchar2_table(1018) := 'DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE';
wwv_flow_imp.g_varchar2_table(1019) := ') values (503,45,43,to_date(''10/19/2020'',''MM/DD/YYYY''),''443510518'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into E';
wwv_flow_imp.g_varchar2_table(1020) := 'BA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,ST';
wwv_flow_imp.g_varchar2_table(1021) := 'ATE) values (504,55,64,to_date(''10/18/2020'',''MM/DD/YYYY''),''435115103'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(1022) := ' EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,';
wwv_flow_imp.g_varchar2_table(1023) := 'STATE) values (505,55,64,to_date(''10/19/2020'',''MM/DD/YYYY''),''3512516'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(1024) := ' EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,';
wwv_flow_imp.g_varchar2_table(1025) := 'STATE) values (506,45,39,to_date(''10/04/2020'',''MM/DD/YYYY''),''544351353'',''River Road'',''VA'');'||wwv_flow.LF||
'insert i';
wwv_flow_imp.g_varchar2_table(1026) := 'nto EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATI';
wwv_flow_imp.g_varchar2_table(1027) := 'ON,STATE) values (507,35,28,to_date(''10/12/2020'',''MM/DD/YYYY''),''EF54431'',''Main Street'',''DC'');'||wwv_flow.LF||
'insert';
wwv_flow_imp.g_varchar2_table(1028) := ' into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCA';
wwv_flow_imp.g_varchar2_table(1029) := 'TION,STATE) values (508,45,64,to_date(''10/05/2020'',''MM/DD/YYYY''),''15510EE2'',''River Road'',''VA'');'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(1030) := 'rt into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LO';
wwv_flow_imp.g_varchar2_table(1031) := 'CATION,STATE) values (509,55,53,to_date(''10/01/2020'',''MM/DD/YYYY''),''16510EE3'',''Highway 5'',''PA'');'||wwv_flow.LF||
'ins';
wwv_flow_imp.g_varchar2_table(1032) := 'ert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,L';
wwv_flow_imp.g_varchar2_table(1033) := 'OCATION,STATE) values (510,25,26,to_date(''09/30/2020'',''MM/DD/YYYY''),''E053011'',''School Road'',''DC'');'||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(1034) := 'nsert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE';
wwv_flow_imp.g_varchar2_table(1035) := ',LOCATION,STATE) values (511,55,52,to_date(''10/01/2020'',''MM/DD/YYYY''),''53010002'',''Highway 5'',''PA'');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1036) := 'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLAT';
wwv_flow_imp.g_varchar2_table(1037) := 'E,LOCATION,STATE) values (512,35,36,to_date(''10/19/2020'',''MM/DD/YYYY''),''9510EE056'',''Main Street'',''VA';
wwv_flow_imp.g_varchar2_table(1038) := ''');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_';
wwv_flow_imp.g_varchar2_table(1039) := 'PLATE,LOCATION,STATE) values (513,35,29,to_date(''09/24/2020'',''MM/DD/YYYY''),''51A510EE1'',''Main Street''';
wwv_flow_imp.g_varchar2_table(1040) := ',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICE';
wwv_flow_imp.g_varchar2_table(1041) := 'NSE_PLATE,LOCATION,STATE) values (514,55,62,to_date(''10/17/2020'',''MM/DD/YYYY''),''351B515'',''Highway 5''';
wwv_flow_imp.g_varchar2_table(1042) := ',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICE';
wwv_flow_imp.g_varchar2_table(1043) := 'NSE_PLATE,LOCATION,STATE) values (515,55,48,to_date(''10/03/2020'',''MM/DD/YYYY''),''B20EF542'',''Highway 5';
wwv_flow_imp.g_varchar2_table(1044) := ''',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LIC';
wwv_flow_imp.g_varchar2_table(1045) := 'ENSE_PLATE,LOCATION,STATE) values (516,55,70,to_date(''10/15/2020'',''MM/DD/YYYY''),''5443513'',''Highway 5';
wwv_flow_imp.g_varchar2_table(1046) := ''',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LIC';
wwv_flow_imp.g_varchar2_table(1047) := 'ENSE_PLATE,LOCATION,STATE) values (517,55,55,to_date(''10/08/2020'',''MM/DD/YYYY''),''5301002'',''Highway 5';
wwv_flow_imp.g_varchar2_table(1048) := ''',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LIC';
wwv_flow_imp.g_varchar2_table(1049) := 'ENSE_PLATE,LOCATION,STATE) values (518,55,59,to_date(''10/07/2020'',''MM/DD/YYYY''),''510EE0533'',''Highway';
wwv_flow_imp.g_varchar2_table(1050) := ' 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,L';
wwv_flow_imp.g_varchar2_table(1051) := 'ICENSE_PLATE,LOCATION,STATE) values (519,55,56,to_date(''10/01/2020'',''MM/DD/YYYY''),''EF5443522'',''Highw';
wwv_flow_imp.g_varchar2_table(1052) := 'ay 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT';
wwv_flow_imp.g_varchar2_table(1053) := ',LICENSE_PLATE,LOCATION,STATE) values (520,45,54,to_date(''09/25/2020'',''MM/DD/YYYY''),''10EE0538'',''Rive';
wwv_flow_imp.g_varchar2_table(1054) := 'r Road'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDE';
wwv_flow_imp.g_varchar2_table(1055) := 'NT,LICENSE_PLATE,LOCATION,STATE) values (521,45,45,to_date(''10/07/2020'',''MM/DD/YYYY''),''544352252'',''R';
wwv_flow_imp.g_varchar2_table(1056) := 'iver Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INC';
wwv_flow_imp.g_varchar2_table(1057) := 'EDENT,LICENSE_PLATE,LOCATION,STATE) values (522,45,53,to_date(''09/30/2020'',''MM/DD/YYYY''),''0EF54435'',';
wwv_flow_imp.g_varchar2_table(1058) := '''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_I';
wwv_flow_imp.g_varchar2_table(1059) := 'NCEDENT,LICENSE_PLATE,LOCATION,STATE) values (523,35,40,to_date(''10/04/2020'',''MM/DD/YYYY''),''05301004';
wwv_flow_imp.g_varchar2_table(1060) := ''',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_O';
wwv_flow_imp.g_varchar2_table(1061) := 'F_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (524,45,40,to_date(''09/29/2020'',''MM/DD/YYYY''),''35255';
wwv_flow_imp.g_varchar2_table(1062) := '16'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_';
wwv_flow_imp.g_varchar2_table(1063) := 'OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (525,35,41,to_date(''09/21/2020'',''MM/DD/YYYY''),''2651';
wwv_flow_imp.g_varchar2_table(1064) := '0EE7'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DA';
wwv_flow_imp.g_varchar2_table(1065) := 'TE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (526,35,32,to_date(''10/09/2020'',''MM/DD/YYYY''),''3';
wwv_flow_imp.g_varchar2_table(1066) := '527510E1'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEE';
wwv_flow_imp.g_varchar2_table(1067) := 'D,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (527,55,53,to_date(''09/30/2020'',''MM/DD/YYYY''';
wwv_flow_imp.g_varchar2_table(1068) := '),''E053013'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEE';
wwv_flow_imp.g_varchar2_table(1069) := 'D,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (528,55,49,to_date(''09/28/2020'',''MM/DD/YYYY''';
wwv_flow_imp.g_varchar2_table(1070) := '),''E05301003'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SP';
wwv_flow_imp.g_varchar2_table(1071) := 'EED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (529,55,56,to_date(''09/28/2020'',''MM/DD/YYY';
wwv_flow_imp.g_varchar2_table(1072) := 'Y''),''B20EF543'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_S';
wwv_flow_imp.g_varchar2_table(1073) := 'PEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (530,55,81,to_date(''10/09/2020'',''MM/DD/YY';
wwv_flow_imp.g_varchar2_table(1074) := 'YY''),''544352B5'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_';
wwv_flow_imp.g_varchar2_table(1075) := 'SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (531,45,43,to_date(''10/10/2020'',''MM/DD/Y';
wwv_flow_imp.g_varchar2_table(1076) := 'YYY''),''4352C53'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE';
wwv_flow_imp.g_varchar2_table(1077) := '_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (532,55,71,to_date(''10/08/2020'',''MM/DD/';
wwv_flow_imp.g_varchar2_table(1078) := 'YYYY''),''44352D2'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE';
wwv_flow_imp.g_varchar2_table(1079) := '_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (533,45,38,to_date(''10/06/2020'',''MM/DD/';
wwv_flow_imp.g_varchar2_table(1080) := 'YYYY''),''0EF54433'',''River Road'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHIC';
wwv_flow_imp.g_varchar2_table(1081) := 'LE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (534,55,64,to_date(''10/14/2020'',''MM/D';
wwv_flow_imp.g_varchar2_table(1082) := 'D/YYYY''),''0EE053015'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEH';
wwv_flow_imp.g_varchar2_table(1083) := 'ICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (535,55,64,to_date(''10/12/2020'',''MM';
wwv_flow_imp.g_varchar2_table(1084) := '/DD/YYYY''),''05301006'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VE';
wwv_flow_imp.g_varchar2_table(1085) := 'HICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (536,55,49,to_date(''10/07/2020'',''M';
wwv_flow_imp.g_varchar2_table(1086) := 'M/DD/YYYY''),''35315101'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,V';
wwv_flow_imp.g_varchar2_table(1087) := 'EHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (537,55,79,to_date(''10/05/2020'',''';
wwv_flow_imp.g_varchar2_table(1088) := 'MM/DD/YYYY''),''EE0530104'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED';
wwv_flow_imp.g_varchar2_table(1089) := ',VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (538,25,25,to_date(''10/16/2020''';
wwv_flow_imp.g_varchar2_table(1090) := ',''MM/DD/YYYY''),''053010001'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_S';
wwv_flow_imp.g_varchar2_table(1091) := 'PEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (539,45,48,to_date(''10/12/2';
wwv_flow_imp.g_varchar2_table(1092) := '020'',''MM/DD/YYYY''),''510EE0538'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTE';
wwv_flow_imp.g_varchar2_table(1093) := 'D_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (540,55,62,to_date(''10/0';
wwv_flow_imp.g_varchar2_table(1094) := '1/2020'',''MM/DD/YYYY''),''EE05302'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTE';
wwv_flow_imp.g_varchar2_table(1095) := 'D_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (541,55,58,to_date(''10/0';
wwv_flow_imp.g_varchar2_table(1096) := '3/2020'',''MM/DD/YYYY''),''10EE056'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTE';
wwv_flow_imp.g_varchar2_table(1097) := 'D_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (542,55,54,to_date(''09/2';
wwv_flow_imp.g_varchar2_table(1098) := '4/2020'',''MM/DD/YYYY''),''537510EE4'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POS';
wwv_flow_imp.g_varchar2_table(1099) := 'TED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (543,55,58,to_date(''10';
wwv_flow_imp.g_varchar2_table(1100) := '/17/2020'',''MM/DD/YYYY''),''443538516'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,P';
wwv_flow_imp.g_varchar2_table(1101) := 'OSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (544,55,49,to_date(''';
wwv_flow_imp.g_varchar2_table(1102) := '10/01/2020'',''MM/DD/YYYY''),''0EF54432'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,';
wwv_flow_imp.g_varchar2_table(1103) := 'POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (545,55,58,to_date(';
wwv_flow_imp.g_varchar2_table(1104) := '''09/30/2020'',''MM/DD/YYYY''),''B20EF5444'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (I';
wwv_flow_imp.g_varchar2_table(1105) := 'D,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (546,55,47,to_dat';
wwv_flow_imp.g_varchar2_table(1106) := 'e(''10/15/2020'',''MM/DD/YYYY''),''B510EE07'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (';
wwv_flow_imp.g_varchar2_table(1107) := 'ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (547,55,59,to_da';
wwv_flow_imp.g_varchar2_table(1108) := 'te(''10/15/2020'',''MM/DD/YYYY''),''F544353C1'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED';
wwv_flow_imp.g_varchar2_table(1109) := ' (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (548,35,30,to_';
wwv_flow_imp.g_varchar2_table(1110) := 'date(''09/23/2020'',''MM/DD/YYYY''),''10EE05302'',''Main Street'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_S';
wwv_flow_imp.g_varchar2_table(1111) := 'PEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (549,55,55';
wwv_flow_imp.g_varchar2_table(1112) := ',to_date(''10/04/2020'',''MM/DD/YYYY''),''53E510EE7'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE';
wwv_flow_imp.g_varchar2_table(1113) := '_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (550,55,';
wwv_flow_imp.g_varchar2_table(1114) := '52,to_date(''09/21/2020'',''MM/DD/YYYY''),''544353F3'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICL';
wwv_flow_imp.g_varchar2_table(1115) := 'E_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (551,45';
wwv_flow_imp.g_varchar2_table(1116) := ',50,to_date(''10/07/2020'',''MM/DD/YYYY''),''3540514'',''River Road'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHIC';
wwv_flow_imp.g_varchar2_table(1117) := 'LE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (552,5';
wwv_flow_imp.g_varchar2_table(1118) := '5,64,to_date(''09/27/2020'',''MM/DD/YYYY''),''10EE0535'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHI';
wwv_flow_imp.g_varchar2_table(1119) := 'CLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (553,';
wwv_flow_imp.g_varchar2_table(1120) := '55,58,to_date(''10/17/2020'',''MM/DD/YYYY''),''54435424'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEH';
wwv_flow_imp.g_varchar2_table(1121) := 'ICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (554';
wwv_flow_imp.g_varchar2_table(1122) := ',45,36,to_date(''10/02/2020'',''MM/DD/YYYY''),''54435435'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_V';
wwv_flow_imp.g_varchar2_table(1123) := 'EHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (5';
wwv_flow_imp.g_varchar2_table(1124) := '55,35,34,to_date(''10/14/2020'',''MM/DD/YYYY''),''54435448'',''Main Street'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CAR';
wwv_flow_imp.g_varchar2_table(1125) := 'D_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values';
wwv_flow_imp.g_varchar2_table(1126) := ' (556,55,55,to_date(''10/13/2020'',''MM/DD/YYYY''),''3545514'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CAR';
wwv_flow_imp.g_varchar2_table(1127) := 'D_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values';
wwv_flow_imp.g_varchar2_table(1128) := ' (557,45,34,to_date(''10/02/2020'',''MM/DD/YYYY''),''20EF54431'',''River Road'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_';
wwv_flow_imp.g_varchar2_table(1129) := 'CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) val';
wwv_flow_imp.g_varchar2_table(1130) := 'ues (558,55,87,to_date(''09/26/2020'',''MM/DD/YYYY''),''10EE05307'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEM';
wwv_flow_imp.g_varchar2_table(1131) := 'O_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) v';
wwv_flow_imp.g_varchar2_table(1132) := 'alues (559,55,63,to_date(''09/19/2020'',''MM/DD/YYYY''),''20EF5441'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DE';
wwv_flow_imp.g_varchar2_table(1133) := 'MO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) ';
wwv_flow_imp.g_varchar2_table(1134) := 'values (560,35,37,to_date(''09/27/2020'',''MM/DD/YYYY''),''530100001'',''Main Street'',''PA'');'||wwv_flow.LF||
'insert into EB';
wwv_flow_imp.g_varchar2_table(1135) := 'A_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STA';
wwv_flow_imp.g_varchar2_table(1136) := 'TE) values (561,55,50,to_date(''10/07/2020'',''MM/DD/YYYY''),''0EF54436'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into E';
wwv_flow_imp.g_varchar2_table(1137) := 'BA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,ST';
wwv_flow_imp.g_varchar2_table(1138) := 'ATE) values (562,55,63,to_date(''09/19/2020'',''MM/DD/YYYY''),''54B510EE6'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into';
wwv_flow_imp.g_varchar2_table(1139) := ' EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,';
wwv_flow_imp.g_varchar2_table(1140) := 'STATE) values (563,25,21,to_date(''10/03/2020'',''MM/DD/YYYY''),''EE053014'',''School Road'',''VA'');'||wwv_flow.LF||
'insert i';
wwv_flow_imp.g_varchar2_table(1141) := 'nto EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATI';
wwv_flow_imp.g_varchar2_table(1142) := 'ON,STATE) values (564,55,53,to_date(''10/17/2020'',''MM/DD/YYYY''),''510EE06'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert i';
wwv_flow_imp.g_varchar2_table(1143) := 'nto EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATI';
wwv_flow_imp.g_varchar2_table(1144) := 'ON,STATE) values (565,55,50,to_date(''09/24/2020'',''MM/DD/YYYY''),''E510EE04'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert ';
wwv_flow_imp.g_varchar2_table(1145) := 'into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCAT';
wwv_flow_imp.g_varchar2_table(1146) := 'ION,STATE) values (566,55,88,to_date(''10/02/2020'',''MM/DD/YYYY''),''44354F513'',''Highway 5'',''VA'');'||wwv_flow.LF||
'inser';
wwv_flow_imp.g_varchar2_table(1147) := 't into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOC';
wwv_flow_imp.g_varchar2_table(1148) := 'ATION,STATE) values (567,55,52,to_date(''09/25/2020'',''MM/DD/YYYY''),''35505108'',''Highway 5'',''VA'');'||wwv_flow.LF||
'inse';
wwv_flow_imp.g_varchar2_table(1149) := 'rt into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LO';
wwv_flow_imp.g_varchar2_table(1150) := 'CATION,STATE) values (568,35,35,to_date(''09/25/2020'',''MM/DD/YYYY''),''0EE05305'',''Main Street'',''VA'');'||wwv_flow.LF||
'i';
wwv_flow_imp.g_varchar2_table(1151) := 'nsert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE';
wwv_flow_imp.g_varchar2_table(1152) := ',LOCATION,STATE) values (569,45,51,to_date(''10/17/2020'',''MM/DD/YYYY''),''4355257'',''River Road'',''PA'');'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(1153) := 'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLAT';
wwv_flow_imp.g_varchar2_table(1154) := 'E,LOCATION,STATE) values (570,55,49,to_date(''10/15/2020'',''MM/DD/YYYY''),''443553515'',''Highway 5'',''VA'')';
wwv_flow_imp.g_varchar2_table(1155) := ';'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PL';
wwv_flow_imp.g_varchar2_table(1156) := 'ATE,LOCATION,STATE) values (571,55,62,to_date(''10/16/2020'',''MM/DD/YYYY''),''54510EE8'',''Highway 5'',''VA''';
wwv_flow_imp.g_varchar2_table(1157) := ');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_P';
wwv_flow_imp.g_varchar2_table(1158) := 'LATE,LOCATION,STATE) values (572,25,28,to_date(''10/08/2020'',''MM/DD/YYYY''),''5301007'',''School Road'',''V';
wwv_flow_imp.g_varchar2_table(1159) := 'A'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE';
wwv_flow_imp.g_varchar2_table(1160) := '_PLATE,LOCATION,STATE) values (573,55,72,to_date(''09/27/2020'',''MM/DD/YYYY''),''5301003'',''Highway 5'',''M';
wwv_flow_imp.g_varchar2_table(1161) := 'D'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE';
wwv_flow_imp.g_varchar2_table(1162) := '_PLATE,LOCATION,STATE) values (574,55,64,to_date(''09/25/2020'',''MM/DD/YYYY''),''20EF5443'',''Highway 5'',''';
wwv_flow_imp.g_varchar2_table(1163) := 'VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENS';
wwv_flow_imp.g_varchar2_table(1164) := 'E_PLATE,LOCATION,STATE) values (575,55,63,to_date(''10/10/2020'',''MM/DD/YYYY''),''B20EF546'',''Highway 5'',';
wwv_flow_imp.g_varchar2_table(1165) := '''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICEN';
wwv_flow_imp.g_varchar2_table(1166) := 'SE_PLATE,LOCATION,STATE) values (576,55,55,to_date(''10/07/2020'',''MM/DD/YYYY''),''F54435595'',''Highway 5';
wwv_flow_imp.g_varchar2_table(1167) := ''',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LIC';
wwv_flow_imp.g_varchar2_table(1168) := 'ENSE_PLATE,LOCATION,STATE) values (577,55,62,to_date(''10/09/2020'',''MM/DD/YYYY''),''0EE053017'',''Highway';
wwv_flow_imp.g_varchar2_table(1169) := ' 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,L';
wwv_flow_imp.g_varchar2_table(1170) := 'ICENSE_PLATE,LOCATION,STATE) values (578,55,84,to_date(''09/30/2020'',''MM/DD/YYYY''),''20EF544'',''Highway';
wwv_flow_imp.g_varchar2_table(1171) := ' 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,L';
wwv_flow_imp.g_varchar2_table(1172) := 'ICENSE_PLATE,LOCATION,STATE) values (579,55,58,to_date(''10/19/2020'',''MM/DD/YYYY''),''510EE058'',''Highwa';
wwv_flow_imp.g_varchar2_table(1173) := 'y 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,';
wwv_flow_imp.g_varchar2_table(1174) := 'LICENSE_PLATE,LOCATION,STATE) values (580,45,40,to_date(''10/12/2020'',''MM/DD/YYYY''),''EE0530108'',''Rive';
wwv_flow_imp.g_varchar2_table(1175) := 'r Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDE';
wwv_flow_imp.g_varchar2_table(1176) := 'NT,LICENSE_PLATE,LOCATION,STATE) values (581,55,49,to_date(''09/23/2020'',''MM/DD/YYYY''),''44355E6'',''Hig';
wwv_flow_imp.g_varchar2_table(1177) := 'hway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDE';
wwv_flow_imp.g_varchar2_table(1178) := 'NT,LICENSE_PLATE,LOCATION,STATE) values (582,45,76,to_date(''10/16/2020'',''MM/DD/YYYY''),''E053013'',''Riv';
wwv_flow_imp.g_varchar2_table(1179) := 'er Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCED';
wwv_flow_imp.g_varchar2_table(1180) := 'ENT,LICENSE_PLATE,LOCATION,STATE) values (583,55,55,to_date(''09/22/2020'',''MM/DD/YYYY''),''54435605'',''H';
wwv_flow_imp.g_varchar2_table(1181) := 'ighway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCE';
wwv_flow_imp.g_varchar2_table(1182) := 'DENT,LICENSE_PLATE,LOCATION,STATE) values (584,55,69,to_date(''10/02/2020'',''MM/DD/YYYY''),''EE0530102'',';
wwv_flow_imp.g_varchar2_table(1183) := '''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_IN';
wwv_flow_imp.g_varchar2_table(1184) := 'CEDENT,LICENSE_PLATE,LOCATION,STATE) values (585,55,55,to_date(''10/07/2020'',''MM/DD/YYYY''),''4435623'',';
wwv_flow_imp.g_varchar2_table(1185) := '''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_IN';
wwv_flow_imp.g_varchar2_table(1186) := 'CEDENT,LICENSE_PLATE,LOCATION,STATE) values (586,45,40,to_date(''10/04/2020'',''MM/DD/YYYY''),''10EE053'',';
wwv_flow_imp.g_varchar2_table(1187) := '''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF_I';
wwv_flow_imp.g_varchar2_table(1188) := 'NCEDENT,LICENSE_PLATE,LOCATION,STATE) values (587,45,40,to_date(''10/17/2020'',''MM/DD/YYYY''),''564510E7';
wwv_flow_imp.g_varchar2_table(1189) := ''',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_OF';
wwv_flow_imp.g_varchar2_table(1190) := '_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (588,55,55,to_date(''10/15/2020'',''MM/DD/YYYY''),''0EE053';
wwv_flow_imp.g_varchar2_table(1191) := '016'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE_';
wwv_flow_imp.g_varchar2_table(1192) := 'OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (589,55,55,to_date(''10/14/2020'',''MM/DD/YYYY''),''5443';
wwv_flow_imp.g_varchar2_table(1193) := '5667'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DATE';
wwv_flow_imp.g_varchar2_table(1194) := '_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (590,55,54,to_date(''09/19/2020'',''MM/DD/YYYY''),''0EE';
wwv_flow_imp.g_varchar2_table(1195) := '053013'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEED,DA';
wwv_flow_imp.g_varchar2_table(1196) := 'TE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (591,25,28,to_date(''10/10/2020'',''MM/DD/YYYY''),''E';
wwv_flow_imp.g_varchar2_table(1197) := 'F5443566'',''School Road'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SPEE';
wwv_flow_imp.g_varchar2_table(1198) := 'D,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (592,55,67,to_date(''10/17/2020'',''MM/DD/YYYY''';
wwv_flow_imp.g_varchar2_table(1199) := '),''530100008'',''Highway 5'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SP';
wwv_flow_imp.g_varchar2_table(1200) := 'EED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (593,55,58,to_date(''09/19/2020'',''MM/DD/YYY';
wwv_flow_imp.g_varchar2_table(1201) := 'Y''),''0EE0534'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_SP';
wwv_flow_imp.g_varchar2_table(1202) := 'EED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (594,45,39,to_date(''10/11/2020'',''MM/DD/YYY';
wwv_flow_imp.g_varchar2_table(1203) := 'Y''),''4356B56'',''River Road'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE_S';
wwv_flow_imp.g_varchar2_table(1204) := 'PEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (595,45,45,to_date(''09/20/2020'',''MM/DD/YY';
wwv_flow_imp.g_varchar2_table(1205) := 'YY''),''E0530102'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHICLE';
wwv_flow_imp.g_varchar2_table(1206) := '_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (596,45,42,to_date(''10/11/2020'',''MM/DD/';
wwv_flow_imp.g_varchar2_table(1207) := 'YYYY''),''56D510EE3'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,VEHI';
wwv_flow_imp.g_varchar2_table(1208) := 'CLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (597,45,54,to_date(''10/03/2020'',''MM/';
wwv_flow_imp.g_varchar2_table(1209) := 'DD/YYYY''),''20EF54436'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED,V';
wwv_flow_imp.g_varchar2_table(1210) := 'EHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (598,45,47,to_date(''10/01/2020'',''';
wwv_flow_imp.g_varchar2_table(1211) := 'MM/DD/YYYY''),''0EF54437'',''River Road'',''MD'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED';
wwv_flow_imp.g_varchar2_table(1212) := ',VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (599,55,45,to_date(''09/23/2020''';
wwv_flow_imp.g_varchar2_table(1213) := ',''MM/DD/YYYY''),''4435705'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPEED';
wwv_flow_imp.g_varchar2_table(1214) := ',VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (600,55,55,to_date(''10/11/2020''';
wwv_flow_imp.g_varchar2_table(1215) := ',''MM/DD/YYYY''),''EE0530104'',''Highway 5'',''DC'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_SPE';
wwv_flow_imp.g_varchar2_table(1216) := 'ED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (601,25,31,to_date(''10/04/202';
wwv_flow_imp.g_varchar2_table(1217) := '0'',''MM/DD/YYYY''),''E0530108'',''School Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTED_';
wwv_flow_imp.g_varchar2_table(1218) := 'SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (602,55,68,to_date(''09/19/';
wwv_flow_imp.g_varchar2_table(1219) := '2020'',''MM/DD/YYYY''),''0EE053014'',''Highway 5'',''PA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POSTE';
wwv_flow_imp.g_varchar2_table(1220) := 'D_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (603,55,50,to_date(''09/2';
wwv_flow_imp.g_varchar2_table(1221) := '4/2020'',''MM/DD/YYYY''),''0EE053011'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POS';
wwv_flow_imp.g_varchar2_table(1222) := 'TED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (604,55,61,to_date(''09';
wwv_flow_imp.g_varchar2_table(1223) := '/21/2020'',''MM/DD/YYYY''),''5755107'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,POS';
wwv_flow_imp.g_varchar2_table(1224) := 'TED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (605,55,49,to_date(''10';
wwv_flow_imp.g_varchar2_table(1225) := '/19/2020'',''MM/DD/YYYY''),''EE0530105'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,P';
wwv_flow_imp.g_varchar2_table(1226) := 'OSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (606,55,62,to_date(''';
wwv_flow_imp.g_varchar2_table(1227) := '10/17/2020'',''MM/DD/YYYY''),''20EF546'',''Highway 5'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID,P';
wwv_flow_imp.g_varchar2_table(1228) := 'OSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (607,45,39,to_date(''';
wwv_flow_imp.g_varchar2_table(1229) := '09/30/2020'',''MM/DD/YYYY''),''10EE0531'',''River Road'',''VA'');'||wwv_flow.LF||
'insert into EBA_DEMO_CARD_VEHICLE_SPEED (ID';
wwv_flow_imp.g_varchar2_table(1230) := ',POSTED_SPEED,VEHICLE_SPEED,DATE_OF_INCEDENT,LICENSE_PLATE,LOCATION,STATE) values (608,45,45,to_date';
wwv_flow_imp.g_varchar2_table(1231) := '(''10/06/2020'',''MM/DD/YYYY''),''9510EE052'',''River Road'',''VA'');'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(9822257512902228407)
,p_install_id=>wwv_flow_imp.id(10744201903091577351)
,p_name=>'vehicle speed'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
