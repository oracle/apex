prompt --application/shared_components/user_interface/lovs/login_remember_username
begin
--   Manifest
--     LOGIN_REMEMBER_USERNAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7920
,p_default_id_offset=>2053840036990350
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(11335825896463572460)
,p_lov_name=>'LOGIN_REMEMBER_USERNAME'
,p_static_id=>'login-remember-username'
,p_lov_query=>'.'||wwv_flow_imp.id(11335825896463572460)||'.'
,p_location=>'STATIC'
,p_version_scn=>'1089080073'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(11335826220078572461)
,p_lov_disp_sequence=>10
,p_lov_disp_value=>'Remember username'
,p_lov_return_value=>'Y'
,p_static_id=>'remember-username'
);
wwv_flow_imp.component_end;
end;
/
