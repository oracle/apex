prompt --application/shared_components/navigation/lists/home
begin
--   Manifest
--     LIST: Home
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.04.07'
,p_release=>'26.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7920
,p_default_id_offset=>2053840036990350
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(6163012060017804775)
,p_name=>'Home'
,p_static_id=>'home'
,p_version_scn=>'1089080073'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6163013432928804777)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Advanced'
,p_static_id=>'advanced'
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-ellipsis-h'
,p_list_text_01=>'Learn how to create a Cards region of charts, define a Cards region''s No Data Found message, and use template directives to dynamically display information'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6163012312647804776)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Basics'
,p_static_id=>'basics'
,p_list_item_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-address-card-o'
,p_list_text_01=>'Learn how to create color coded cards, a Cards region with a Faceted Search, and several other Cards regions using various styles'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6163013038863804776)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Card Actions'
,p_static_id=>'card-actions'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-link'
,p_list_text_01=>'Learn how to make an each card link to a given URL or how to define different elements on each card that link to different URLs'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(6163012635883804776)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Images and Media'
,p_static_id=>'images-and-media'
,p_list_item_link_target=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-image'
,p_list_text_01=>'Learn how to display images and embedded videos in Cards regions'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
