prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7920
,p_default_id_offset=>2053840036990350
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(11335680389548572237)
,p_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6162855805990060978)
,p_short_name=>'Advanced'
,p_static_id=>'advanced'
,p_link=>'f?p=&APP_ID.:19:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>19
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6162902000707200520)
,p_parent_id=>wwv_flow_imp.id(6162882002564969308)
,p_short_name=>'Application Static Files'
,p_static_id=>'application-static-files'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6162901105886192356)
,p_parent_id=>wwv_flow_imp.id(6162882002564969308)
,p_short_name=>'Background Image'
,p_static_id=>'background-image'
,p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6162866196340159416)
,p_short_name=>'Basics'
,p_static_id=>'basics'
,p_link=>'f?p=&APP_ID.:20:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>20
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11335834228698572488)
,p_parent_id=>wwv_flow_imp.id(6162882002564969308)
,p_short_name=>'BLOB Column'
,p_static_id=>'blob-column'
,p_link=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_page_id=>2
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6162896985390152517)
,p_parent_id=>wwv_flow_imp.id(6162882002564969308)
,p_short_name=>'BLOB Column as URL'
,p_static_id=>'blob-column-as-url'
,p_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
,p_page_id=>5
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6162888512323064919)
,p_short_name=>'Card Actions'
,p_static_id=>'card-actions'
,p_link=>'f?p=&APP_ID.:22:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>22
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6162956732999015750)
,p_parent_id=>wwv_flow_imp.id(6162855805990060978)
,p_short_name=>'Charts'
,p_static_id=>'charts'
,p_link=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::'
,p_page_id=>11
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6162892319848096828)
,p_parent_id=>wwv_flow_imp.id(6162866196340159416)
,p_short_name=>'Color Coded Cards'
,p_static_id=>'color-coded-cards'
,p_link=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:::'
,p_page_id=>18
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6162950184488971947)
,p_parent_id=>wwv_flow_imp.id(6162888512323064919)
,p_short_name=>'Conditional Actions'
,p_static_id=>'conditional-actions'
,p_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:::'
,p_page_id=>16
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6162899259847172900)
,p_parent_id=>wwv_flow_imp.id(6162882002564969308)
,p_short_name=>'Embedded Video'
,p_static_id=>'embedded-video'
,p_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_page_id=>6
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6162892989955104864)
,p_parent_id=>wwv_flow_imp.id(6162866196340159416)
,p_short_name=>'Faceted Search'
,p_static_id=>'faceted-search'
,p_link=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:::'
,p_page_id=>12
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6162951518084998126)
,p_parent_id=>wwv_flow_imp.id(6162888512323064919)
,p_short_name=>'Full Card Action'
,p_static_id=>'full-card-action'
,p_link=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:::'
,p_page_id=>15
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(11335680574032572237)
,p_short_name=>'Home'
,p_static_id=>'home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6162897906840159070)
,p_parent_id=>wwv_flow_imp.id(6162882002564969308)
,p_short_name=>'Image URL'
,p_static_id=>'image-url'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6162882002564969308)
,p_short_name=>'Images and Media'
,p_static_id=>'images-and-media'
,p_link=>'f?p=&APP_ID.:21:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>21
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6162958109874025905)
,p_parent_id=>wwv_flow_imp.id(6162855805990060978)
,p_short_name=>'No Data Found'
,p_static_id=>'no-data-found'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6162893782652111804)
,p_parent_id=>wwv_flow_imp.id(6162866196340159416)
,p_short_name=>'Star Icons'
,p_static_id=>'star-icons'
,p_link=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::'
,p_page_id=>13
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6162894495763118842)
,p_parent_id=>wwv_flow_imp.id(6162866196340159416)
,p_short_name=>'Styles'
,p_static_id=>'styles'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6162958734133032355)
,p_parent_id=>wwv_flow_imp.id(6162855805990060978)
,p_short_name=>'Template Directives'
,p_static_id=>'template-directives'
,p_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::'
,p_page_id=>9
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(6163334674336249941)
,p_parent_id=>wwv_flow_imp.id(6162882002564969308)
,p_short_name=>'Video Images with Durations'
,p_static_id=>'video-images-with-durations'
,p_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_imp.component_end;
end;
/
