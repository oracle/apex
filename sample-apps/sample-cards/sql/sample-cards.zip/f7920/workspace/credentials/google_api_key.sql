prompt --workspace/credentials/google_api_key
begin
--   Manifest
--     CREDENTIAL: Google API Key
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7920
,p_default_id_offset=>2053840036990350
,p_default_owner=>'ORACLE'
);
wwv_imp_workspace.create_credential(
 p_id=>4425201999827780147
,p_name=>'Google API Key'
,p_static_id=>'google_api_key'
,p_authentication_type=>'HTTP_QUERY_STRING'
,p_prompt_on_install=>true
);
wwv_flow_imp.component_end;
end;
/
