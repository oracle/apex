prompt --application/shared_components/user_interface/template_options
begin
--   Manifest
--     THEME OPTIONS: 7920
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7920
,p_default_id_offset=>2053840036990350
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_template_option(
 p_id=>wwv_flow_imp.id(11336103204277255704)
,p_theme_id=>42
,p_name=>'STICKY_HEADER_ON_MOBILE'
,p_display_name=>'Sticky Header on Mobile'
,p_display_sequence=>100
,p_page_template_id=>wwv_flow_imp.id(11336099281267255690)
,p_css_classes=>'js-pageStickyMobileHeader'
,p_template_types=>'PAGE'
,p_help_text=>'This will position the contents of the Breadcrumb Bar region position so it sticks to the top of the screen for small screens.'
);
wwv_flow_imp.component_end;
end;
/
