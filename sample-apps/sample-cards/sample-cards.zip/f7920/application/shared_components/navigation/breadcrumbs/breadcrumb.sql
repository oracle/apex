prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.0-14'
,p_default_workspace_id=>20
,p_default_application_id=>7920
,p_default_id_offset=>5368331085050014364
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_menu(
 p_id=>wwv_flow_api.id(5965295464461567523)
,p_name=>'Breadcrumb'
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(792470880903056264)
,p_short_name=>'Advanced'
,p_link=>'f?p=&APP_ID.:19:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>19
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(792481271253154702)
,p_short_name=>'Basics'
,p_link=>'f?p=&APP_ID.:20:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>20
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(792497077477964594)
,p_short_name=>'Images and Media'
,p_link=>'f?p=&APP_ID.:21:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>21
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(792503587236060205)
,p_short_name=>'Card Actions'
,p_link=>'f?p=&APP_ID.:22:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>22
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(792507394761092114)
,p_parent_id=>wwv_flow_api.id(792481271253154702)
,p_short_name=>'Color Coded Cards'
,p_link=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.:::'
,p_page_id=>18
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(792508064868100150)
,p_parent_id=>wwv_flow_api.id(792481271253154702)
,p_short_name=>'Faceted Search'
,p_link=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:::'
,p_page_id=>12
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(792508857565107090)
,p_parent_id=>wwv_flow_api.id(792481271253154702)
,p_short_name=>'Star Icons'
,p_link=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.:::'
,p_page_id=>13
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(792509570676114128)
,p_parent_id=>wwv_flow_api.id(792481271253154702)
,p_short_name=>'Styles'
,p_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(792512060303147803)
,p_parent_id=>wwv_flow_api.id(792497077477964594)
,p_short_name=>'BLOB Column as URL'
,p_link=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::'
,p_page_id=>5
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(792512981753154356)
,p_parent_id=>wwv_flow_api.id(792497077477964594)
,p_short_name=>'Image URL'
,p_link=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(792514334760168186)
,p_parent_id=>wwv_flow_api.id(792497077477964594)
,p_short_name=>'Embedded Video'
,p_link=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:::'
,p_page_id=>6
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(792516180799187642)
,p_parent_id=>wwv_flow_api.id(792497077477964594)
,p_short_name=>'Background Image'
,p_link=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(792517075620195806)
,p_parent_id=>wwv_flow_api.id(792497077477964594)
,p_short_name=>'Application Static Files'
,p_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(792565259401967233)
,p_parent_id=>wwv_flow_api.id(792503587236060205)
,p_short_name=>'Conditional Actions'
,p_link=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.:::'
,p_page_id=>16
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(792566592997993412)
,p_parent_id=>wwv_flow_api.id(792503587236060205)
,p_short_name=>'Full Card Action'
,p_link=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:::'
,p_page_id=>15
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(792571807912011036)
,p_parent_id=>wwv_flow_api.id(792470880903056264)
,p_short_name=>'Charts'
,p_link=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::'
,p_page_id=>11
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(792573184787021191)
,p_parent_id=>wwv_flow_api.id(792470880903056264)
,p_short_name=>'No Data Found'
,p_link=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.:::'
,p_page_id=>17
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(792573809046027641)
,p_parent_id=>wwv_flow_api.id(792470880903056264)
,p_short_name=>'Template Directives'
,p_link=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::'
,p_page_id=>9
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(792949749249245227)
,p_parent_id=>wwv_flow_api.id(792497077477964594)
,p_short_name=>'Video Images with Durations'
,p_link=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(5965295648945567523)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.'
,p_page_id=>1
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(5965449303611567774)
,p_parent_id=>wwv_flow_api.id(792497077477964594)
,p_short_name=>'BLOB Column'
,p_link=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
,p_page_id=>2
);
wwv_flow_api.component_end;
end;
/
