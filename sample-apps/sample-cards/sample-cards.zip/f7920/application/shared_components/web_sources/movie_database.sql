prompt --application/shared_components/web_sources/movie_database
begin
--   Manifest
--     WEB SOURCE: Movie Database
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7920
,p_default_id_offset=>5368331085050014364
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_web_source_module(
 p_id=>wwv_flow_api.id(5973170277566283292)
,p_name=>'Movie Database'
,p_static_id=>'Movie_Database'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_api.id(5973165785890283288)
,p_remote_server_id=>wwv_flow_api.id(1955948284379183812)
,p_url_path_prefix=>'/10'
,p_credential_id=>wwv_flow_api.id(4423150213920829700)
);
wwv_flow_api.create_web_source_param(
 p_id=>wwv_flow_api.id(5973171266447283293)
,p_web_src_module_id=>wwv_flow_api.id(5973170277566283292)
,p_name=>'language'
,p_param_type=>'QUERY_STRING'
,p_is_required=>false
,p_value=>'en-US'
);
wwv_flow_api.create_web_source_operation(
 p_id=>wwv_flow_api.id(5973170385610283293)
,p_web_src_module_id=>wwv_flow_api.id(5973170277566283292)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
,p_caching=>'ALL_USERS'
,p_invalidate_when=>'3600'
);
wwv_flow_api.component_end;
end;
/
