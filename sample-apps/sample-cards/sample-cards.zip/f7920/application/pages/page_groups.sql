prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7920
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7920
,p_default_id_offset=>2053840036990350
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(11335822791519572431)
,p_group_name=>'Administration'
);
wwv_flow_imp.component_end;
end;
/
