prompt --workspace/remote_servers/www_googleapis_com_youtube_v3
begin
--   Manifest
--     REMOTE SERVER: www-googleapis-com-youtube-v3
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.04.12'
,p_release=>'22.1.0-15'
,p_default_workspace_id=>20
,p_default_application_id=>7920
,p_default_id_offset=>5368331085050014364
,p_default_owner=>'ORACLE'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(1352489740377360882)
,p_name=>'www-googleapis-com-youtube-v3'
,p_static_id=>'www_googleapis_com_youtube_v3'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('www_googleapis_com_youtube_v3'),'https://www.googleapis.com/youtube/v3/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('www_googleapis_com_youtube_v3'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('www_googleapis_com_youtube_v3'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('www_googleapis_com_youtube_v3'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('www_googleapis_com_youtube_v3'),'')
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
