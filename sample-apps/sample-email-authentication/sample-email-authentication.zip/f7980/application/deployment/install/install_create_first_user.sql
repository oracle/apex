prompt --application/deployment/install/install_create_first_user
begin
--   Manifest
--     INSTALL: INSTALL-create first user
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>26977940949803488
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16174078969951620424)
,p_install_id=>wwv_flow_imp.id(1872877062818401196)
,p_name=>'create first user'
,p_sequence=>50
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_app_user  varchar2(255) := apex_custom_auth.get_username;',
'begin',
'    for u in (',
'        select email',
'          from apex_workspace_apex_users',
'         where user_name = l_app_user',
'    ) loop',
'        for a in (',
'            select application_id',
'              from apex_applications',
'             where application_name = ''Sample Email Authentication''',
'             order by last_updated_on desc',
'        ) loop',
'            for r in (',
'                select role_id',
'                  from apex_appl_acl_roles',
'                 where application_id = a.application_id ',
'                   and role_static_id = ''ADMINISTRATOR''',
'            ) loop',
'                eba_ema_util.add_user (',
'                    p_username      => u.email,',
'                    p_role_id       => r.role_id,',
'                    p_send_email_yn => ''N'',',
'                    p_app_id        => a.application_id );',
'                exit;',
'            end loop;',
'            exit;',
'        end loop;',
'    end loop;',
'end;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
