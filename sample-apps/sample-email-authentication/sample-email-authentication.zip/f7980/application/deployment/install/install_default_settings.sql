prompt --application/deployment/install/install_default_settings
begin
--   Manifest
--     INSTALL: INSTALL-default settings
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>1843403949831885631
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1846119642228920276)
,p_install_id=>wwv_flow_imp.id(1845899121868597708)
,p_name=>'default settings'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- load settings',
'',
'begin',
'    eba_ema_util.add_setting (',
'        p_name          => ''from_email'',',
'        p_display_order => 30,',
'        p_description   => ''used as the from address for the emails sent (for tokens, account requests)'',',
'        p_value         => '''',',
'        p_is_numeric_yn => ''N'',',
'        p_is_yn         => ''N'' );',
'',
'    eba_ema_util.add_setting (',
'        p_name          => ''max_tokens'',',
'        p_display_order => 50,',
'        p_description   => ''how many tokens can be generated during the reset window'',',
'        p_value         => ''3'',',
'        p_is_numeric_yn => ''Y'',',
'        p_is_yn         => ''N'' );',
'',
'    eba_ema_util.add_setting (',
'        p_name          => ''max_verify_attempts_per_token'',',
'        p_display_order => 55,',
'        p_description   => ''how many verification attempts before a token is no longer valid'',',
'        p_value         => ''3'',',
'        p_is_numeric_yn => ''Y'',',
'        p_is_yn         => ''N'' );',
'',
'    eba_ema_util.add_setting (',
'        p_name          => ''reset_verify_after_x_hours'',',
'        p_display_order => 60,',
'        p_description   => ''how many hours a user will be locked out after exceeding max tokens/max attempts'',',
'        p_value         => ''1'',',
'        p_is_numeric_yn => ''Y'',',
'        p_is_yn         => ''N'' );',
'',
'end;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
