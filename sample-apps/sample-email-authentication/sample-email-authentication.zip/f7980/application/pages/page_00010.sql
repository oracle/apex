prompt --application/pages/page_00010
begin
--   Manifest
--     PAGE: 00010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>26977940949803488
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10
,p_name=>'About'
,p_alias=>'ABOUT-PRE'
,p_step_title=>'About'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(48299275315166121689)
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_help_text=>'All application help text can be accessed from this page. The links in the "Documentation" region give a much more in-depth explanation of the application''s features and functionality.'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(98127794443043450143)
,p_plug_name=>'About'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h1:t-ContentBlock--lightBG'
,p_plug_template=>wwv_flow_imp.id(48298652821447121587)
,p_plug_display_sequence=>20
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This application illustrates the use of email authentication.  Usernames must be email addresses and tokens are emailed to users at login time to verify their identities, instead of using passwords.</p>',
'',
'<p>It utilizes the APEX Application Control List (ACL) for user management along with custom tables for managing tokens.</p>',
'',
'<p>The tables used by this application are:',
'    <ul>',
'        <li>EBA_EMA_LOG</li>',
'        <li>EBA_EMA_SETTINGS</li>',
'        <li>EBA_EMA_VERIFY_TOKENS</li>',
'    </ul>',
'and the associated package is EBA_EMA_UTIL.</p>',
'',
'<p>The EBA_EMA_SETTINGS table contains the following:',
'    <ul>',
'        <li>from_email - used as the from address for the emails sent (for tokens)</li>',
'        <li>max_tokens - how many tokens can be generated during the reset window</li>',
'        <li>max_verify_attempts_per_token - how many verification attempts before a token is no longer valid</li>',
'        <li>reset_verify_after_x_hours - how many hours a user will be locked out after exceeding max tokens/max attempts</li>',
'    </ul>',
'</p>',
'',
'<p>The following settings are currently hardcoded into EBA_EMA_UTIL.GENERATE_TOKEN:',
'    <ul>',
'        <li>l_grace_minutes   number := 5;</li>',
'        <li>l_token_length    number := 6;</li>',
'        <li>l_expire_minutes  number := 15;</li>',
'    </ul>',
'If you wish to make these dynamic, they should be added as settings.</p>',
'',
'<p>To authenticate, a user must be in the application''s ACL.  They provide their email address and request a verification code and then provide the resulting verification code that was sent to thier email.</p>',
'',
'<p>The first Administrator is created during the installation process using the email of the user that installed the application.  The user is able to authenticate because the email with their verification code will be sent from their email.  Once th'
||'ey are authenticated, they will be prompted to set the from_email that will then be used for all other verification emails sent from this application.</p>'))
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
