prompt --application/pages/page_10010
begin
--   Manifest
--     PAGE: 10010
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>1843403949831885631
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>10010
,p_name=>'Emails From'
,p_alias=>'EMAILS-FROM'
,p_step_title=>'Emails From'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(48271620769649318077)
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(48272298981860318202)
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_last_updated_by=>'SBKENNED'
,p_last_upd_yyyymmddhh24miss=>'20240410195816'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79255314867000107829)
,p_plug_name=>'Emails From Setting'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48271707745079318112)
,p_plug_display_sequence=>20
,p_plug_header=>'This is the email address that the verification codes will be sent from.  The application cannot be used without providing a setting.'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(16149489983200837749)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(79255314867000107829)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(48272186348144318145)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(16149491712333837751)
,p_branch_name=>'Go To Protected Page'
,p_branch_action=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:10010::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(68680228753756596079)
,p_name=>'P10010_FROM_EMAIL'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(79255314867000107829)
,p_item_default=>'return eba_ema_util.get_setting(p_name => ''from_email'');'
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'From Email'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(48272185062284318144)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(16149490928336837751)
,p_validation_name=>'email valid'
,p_validation_sequence=>10
,p_validation=>'P10010_FROM_EMAIL'
,p_validation2=>'[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>'Email is not valid'
,p_associated_item=>wwv_flow_imp.id(68680228753756596079)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(16149491253587837751)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update settings'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'eba_ema_util.set_setting (',
'    p_name  => ''from_email'',',
'    p_value => :P10010_FROM_EMAIL );'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Settings failed to be saved.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Settings saved.'
,p_internal_uid=>61558014860179645525
);
wwv_flow_imp.component_end;
end;
/
