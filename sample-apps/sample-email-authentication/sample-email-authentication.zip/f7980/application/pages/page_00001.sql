prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>1843403949831885631
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Home'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.apex-item-text {',
'    --a-field-input-font-size: 3rem;',
'    --a-field-input-line-height: 4rem;',
'}',
'.t-Form-itemWrapper {',
'    justify-content: center;',
'}',
'',
'.t-Alert--wizard .t-Alert-buttons {',
'    margin-block-start: 0.5rem;',
'}',
'',
'.t-Button--large {',
'    --a-button-font-size: 1rem;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'13'
,p_last_updated_by=>'SBKENNED'
,p_last_upd_yyyymmddhh24miss=>'20240405190524'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(28503785645581313907)
,p_plug_name=>'Welcome to Sample Email Authentication'
,p_region_css_classes=>'u-tC'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--info:js-headingLevel-1:t-Form--noPadding'
,p_plug_template=>wwv_flow_imp.id(48271640873708318085)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'This is where your home page content would be - displayed only once verified.'
,p_plug_display_condition_type=>'USER_IS_NOT_PUBLIC_USER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(73598465818602889673)
,p_plug_name=>'Links'
,p_region_css_classes=>'u-tC'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(48271647537618318088)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(198589852863742743767)
,p_plug_name=>'Welcome to Sample Email Authentication'
,p_region_css_classes=>'u-tC'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--info:js-headingLevel-1:t-Form--noPadding'
,p_plug_template=>wwv_flow_imp.id(48271640873708318085)
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>If you are a valid user in the application''s ACL, click <b>User Login</b> below</p>'
,p_plug_display_condition_type=>'USER_IS_PUBLIC_USER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(65202834629760970619)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(73598465818602889673)
,p_button_name=>'ADMIN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(48272186348144318145)
,p_button_image_alt=>'Administration'
,p_button_redirect_url=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.:::'
,p_button_condition_type=>'USER_IS_NOT_PUBLIC_USER'
,p_security_scheme=>wwv_flow_imp.id(48272298981860318202)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(65202834969469970619)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(73598465818602889673)
,p_button_name=>'SIGN_IN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(48272186348144318145)
,p_button_image_alt=>'User Login'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_button_condition_type=>'USER_IS_PUBLIC_USER'
);
wwv_flow_imp.component_end;
end;
/
