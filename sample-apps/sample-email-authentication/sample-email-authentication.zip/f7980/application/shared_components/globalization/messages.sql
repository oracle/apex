prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 7980
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>13699378009317950
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(20026134199393775427)
,p_name=>'APEX.AUTHENTICATION.LOGIN_THROTTLE.COUNTER'
,p_message_text=>'Please wait <span id="apex_login_throttle_sec">%0</span> seconds to verify again.'
,p_version_scn=>15496015297109
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(20026634050104089970)
,p_name=>'APEX.AUTHENTICATION.LOGIN_THROTTLE.ERROR'
,p_message_text=>'The verification attempt has been blocked.'
,p_version_scn=>15496015311829
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(20024423959202057673)
,p_name=>'INVALID_CREDENTIALS'
,p_message_text=>'Invalid verification code'
,p_version_scn=>15496014953143
);
wwv_flow_imp.component_end;
end;
/
