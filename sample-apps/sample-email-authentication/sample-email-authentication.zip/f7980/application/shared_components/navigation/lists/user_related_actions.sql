prompt --application/shared_components/navigation/lists/user_related_actions
begin
--   Manifest
--     LIST: User Related Actions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>26977940949803488
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(48299419231471122170)
,p_name=>'User Related Actions'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(48299274650079121689)
,p_version_scn=>37167711506897
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(48299419613701122170)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Users'
,p_list_item_link_target=>'f?p=&APP_ID.:10031:&APP_SESSION.::&DEBUG.:RP::'
,p_list_item_icon=>'fa-users'
,p_list_text_01=>'Set level of access for authenticated users of this application'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
