prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>1843403949831885631
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(48271609440018318071)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48271609634450318072)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48272437723161318680)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:10000:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49084992421062369969)
,p_short_name=>'Settings'
,p_link=>'f?p=&APP_ID.:10011:&SESSION.::&DEBUG.:::'
,p_page_id=>10011
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49085727059185072594)
,p_short_name=>'Application Error Log'
,p_link=>'f?p=&APP_ID.:10022:&SESSION.::&DEBUG.:::'
,p_page_id=>10022
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49089517426784425000)
,p_short_name=>'Logged Messages'
,p_link=>'f?p=&APP_ID.:10026:&SESSION.::&DEBUG.:::'
,p_page_id=>10026
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49090022988023431994)
,p_short_name=>'Manage User Access'
,p_link=>'f?p=&APP_ID.:10031:&SESSION.::&DEBUG.:::'
,p_page_id=>10031
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49091492045727469074)
,p_short_name=>'Email Reporting'
,p_link=>'f?p=&APP_ID.:10050:&SESSION.::&DEBUG.:::'
,p_page_id=>10050
);
wwv_flow_imp.component_end;
end;
/
