prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>13699378009317950
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(48312286758977439509)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48312286953409439510)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(48313115042120440118)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:10000:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49125669740021491407)
,p_short_name=>'Settings'
,p_link=>'f?p=&APP_ID.:10011:&SESSION.::&DEBUG.:::'
,p_page_id=>10011
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49126404378144194032)
,p_short_name=>'Application Error Log'
,p_link=>'f?p=&APP_ID.:10022:&SESSION.::&DEBUG.:::'
,p_page_id=>10022
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49130194745743546438)
,p_short_name=>'Logged Messages'
,p_link=>'f?p=&APP_ID.:10026:&SESSION.::&DEBUG.:::'
,p_page_id=>10026
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49130700306982553432)
,p_short_name=>'Manage User Access'
,p_link=>'f?p=&APP_ID.:10031:&SESSION.::&DEBUG.:::'
,p_page_id=>10031
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(49132169364686590512)
,p_short_name=>'Email Reporting'
,p_link=>'f?p=&APP_ID.:10050:&SESSION.::&DEBUG.:::'
,p_page_id=>10050
);
wwv_flow_imp.component_end;
end;
/
