prompt --application/shared_components/logic/application_items/app_url
begin
--   Manifest
--     APPLICATION ITEM: APP_URL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>13699378009317950
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(6332996496435472995)
,p_name=>'APP_URL'
,p_protection_level=>'I'
,p_version_scn=>15493657060440
);
wwv_flow_imp.component_end;
end;
/
