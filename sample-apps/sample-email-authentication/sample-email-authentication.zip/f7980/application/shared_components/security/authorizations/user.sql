prompt --application/shared_components/security/authorizations/user
begin
--   Manifest
--     SECURITY SCHEME: User
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>26977940949803488
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(48299277090830121690)
,p_name=>'User'
,p_scheme_type=>'NATIVE_IS_IN_GROUP'
,p_attribute_01=>'Administrator,User'
,p_attribute_02=>'A'
,p_error_message=>'Insufficient privileges, not a valid user'
,p_version_scn=>37167711507299
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_imp.component_end;
end;
/
