prompt --application/shared_components/security/app_access_control/user
begin
--   Manifest
--     ACL ROLE: User
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>1843403949831885631
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(48272298811468318202)
,p_static_id=>'USER'
,p_name=>'User'
,p_description=>'Can access the applications protected pages, but not perform Administrative functions.'
,p_version_scn=>15506201038870
);
wwv_flow_imp.component_end;
end;
/
