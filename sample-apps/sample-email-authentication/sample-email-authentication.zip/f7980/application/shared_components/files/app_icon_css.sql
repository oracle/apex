prompt --application/shared_components/files/app_icon_css
begin
--   Manifest
--     APP STATIC FILES: 7980
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>13699378009317950
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E6170702D69636F6E207B0D0A202020206261636B67726F756E642D696D6167653A2075726C2869636F6E732F6170702D69636F6E2D3139322E706E67293B0D0A202020206261636B67726F756E642D7265706561743A206E6F2D7265706561743B0D0A';
wwv_flow_imp.g_varchar2_table(2) := '202020206261636B67726F756E642D73697A653A20636F7665723B0D0A202020206261636B67726F756E642D706F736974696F6E3A203530253B0D0A202020206261636B67726F756E642D636F6C6F723A20233239353836363B0D0A7D0D0A0D0A2E742D';
wwv_flow_imp.g_varchar2_table(3) := '416C6572742D69636F6E202E6170702D69636F6E207B0D0A2020202077696474683A2031323870783B0D0A202020206865696768743A2031323870783B0D0A7D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(43913235522564046920)
,p_file_name=>'app-icon.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
