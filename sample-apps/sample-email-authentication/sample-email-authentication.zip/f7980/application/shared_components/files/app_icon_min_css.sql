prompt --application/shared_components/files/app_icon_min_css
begin
--   Manifest
--     APP STATIC FILES: 7980
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>26977940949803488
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E6170702D69636F6E7B6261636B67726F756E642D696D6167653A75726C2869636F6E732F6170702D69636F6E2D3139322E706E67293B6261636B67726F756E642D7265706561743A6E6F2D7265706561743B6261636B67726F756E642D73697A653A63';
wwv_flow_imp.g_varchar2_table(2) := '6F7665723B6261636B67726F756E642D706F736974696F6E3A3530253B6261636B67726F756E642D636F6C6F723A233239353836367D2E742D416C6572742D69636F6E202E6170702D69636F6E7B77696474683A31323870783B6865696768743A313238';
wwv_flow_imp.g_varchar2_table(3) := '70787D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(43900074130077228971)
,p_file_name=>'app-icon.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
