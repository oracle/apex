prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 7980
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>13699378009317950
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(48312977662892439641)
,p_group_name=>'Administration'
,p_static_id=>'administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(59044784162679089180)
,p_group_name=>'Session Management'
,p_static_id=>'session-management'
);
wwv_flow_imp.component_end;
end;
/
