prompt --application/pages/page_09999
begin
--   Manifest
--     PAGE: 09999
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>13699378009317950
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>9999
,p_name=>'Login Page'
,p_alias=>'LOGIN'
,p_step_title=>'Sample Email Authentication Log In'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_step_template=>2102634289808461002
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'12'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(48312978189880439642)
,p_plug_name=>'Sample Email Authentication Login'
,p_static_id=>'sample-email-authentication-login'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#:js-headingLevel-1'
,p_plug_template=>2675634334296186762
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6364051791143760376)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(48312978189880439642)
,p_button_name=>'Cancel'
,p_static_id=>'cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:9999::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(48312979938610439644)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(48312978189880439642)
,p_button_name=>'SEND_CODE'
,p_static_id=>'send-code'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Send Verification Code'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(6364055974156760418)
,p_branch_name=>'Go To Verification'
,p_branch_action=>'f?p=&APP_ID.:9998:&SESSION.::&DEBUG.:9999::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P9999_VALID_USER_YN'
,p_branch_condition_text=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(13912533905871627470)
,p_branch_name=>'stay if user not found'
,p_branch_action=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:9999:P9999_USERNAME:&P9999_USERNAME.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P9999_VALID_USER_YN'
,p_branch_condition_text=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48312978728761439643)
,p_name=>'P9999_USERNAME'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(48312978189880439642)
,p_prompt=>'Email Address'
,p_placeholder=>'Email Address'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>2042262243893469891
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'Y',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_item_comment=>'advanced - custom attributes - autocomplete="username"'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10920803144013615819)
,p_name=>'P9999_VALID_USER_YN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(48312978189880439642)
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(1887754937452270207)
,p_validation_name=>'email valid'
,p_static_id=>'email-valid'
,p_validation_sequence=>20
,p_validation=>'P9999_USER_NAME'
,p_validation2=>'[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>'Not a valid email format'
,p_associated_item=>wwv_flow_imp.id(48312978728761439643)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(6364055633777760414)
,p_validation_name=>'is user locked'
,p_static_id=>'is-user-locked'
,p_validation_sequence=>10
,p_validation=>'eba_ema_util.is_account_locked_yn (p_username => :P9999_USERNAME) = ''N'''
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Maximum verification attempts exceeded, this account is temporarily locked.'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(13912538492157627516)
,p_name=>'msg when verification attempts maxed'
,p_static_id=>'msg-when-verification-attempts-maxed'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'REQUEST_EQUALS_CONDITION'
,p_display_when_cond=>'NEWCODE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13912538594934627517)
,p_event_id=>wwv_flow_imp.id(13912538492157627516)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_static_id=>'native-alert'
,p_action=>'NATIVE_ALERT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'message', '<p>No more verification attempts left, request a new code.</p>')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10920803030493615818)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'check if valid user'
,p_static_id=>'check-if-valid-user'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9999_VALID_USER_YN := ''N'';',
'',
'if apex_acl.has_user_any_roles (',
'               p_application_id => :APP_ID, ',
'               p_user_name => :P9999_USERNAME ) then',
'    :P9999_VALID_USER_YN := ''Y'';',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>9036721761702608749
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6364056152402760419)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'generate_token'
,p_static_id=>'generate-token'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_token varchar2(30);',
'begin',
'',
'    l_token := eba_ema_util.generate_token (',
'        p_username   => :P9999_USERNAME );',
'',
'',
'    eba_ema_util.send_verification_email (',
'        p_username => :P9999_USERNAME,',
'        p_token    => l_token,',
'        p_app_id   => :APP_ID );',
'',
'    :P9998_USERNAME := :P9999_USERNAME;',
'    ',
'exception',
'when eba_ema_util.e_account_locked then',
'    raise_application_error(-20111,''Maximum verification attempts exceeded.  Account will reset in ''||eba_ema_util.get_setting(''reset_verify_after_x_hours'')||'' hours.'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P9999_VALID_USER_YN'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'Y'
,p_process_success_message=>'Check your email for your verification code.'
,p_internal_uid=>4479974883611753350
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(48312983639022439646)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Username Cookie'
,p_static_id=>'get-username-cookie'
,p_process_sql_clob=>':P9999_USERNAME := apex_authentication.get_login_username_cookie;'
,p_process_clob_language=>'PLSQL'
,p_process_when=>'apex_authentication.get_login_username_cookie is not null'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>46428902370231432577
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13912534949142627480)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'show different message if not a valid user'
,p_static_id=>'show-different-message-if-not-a-valid-user'
,p_process_sql_clob=>'null;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P9999_VALID_USER_YN'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'N'
,p_process_success_message=>'A verification code will be emailed, if this user is found.'
,p_internal_uid=>12028453680351620411
);
wwv_flow_imp.component_end;
end;
/
