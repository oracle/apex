prompt --application/deployment/install/install_package_body
begin
--   Manifest
--     INSTALL: INSTALL-package body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>13699378009317950
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body eba_ema_util  '||wwv_flow.LF||
'as '||wwv_flow.LF||
' '||wwv_flow.LF||
'-- To catch PL/SQL error, error log procedure ne';
wwv_flow_imp.g_varchar2_table(2) := 'eds to be autonomous transactions and do commit at the end.  '||wwv_flow.LF||
'procedure add_log (  '||wwv_flow.LF||
'    p_procedure_';
wwv_flow_imp.g_varchar2_table(3) := 'name  in varchar2,  '||wwv_flow.LF||
'    p_log_type        in varchar2 default ''error'', '||wwv_flow.LF||
'    p_error           in va';
wwv_flow_imp.g_varchar2_table(4) := 'rchar2,  '||wwv_flow.LF||
'    p_arg1_name       in varchar2 default null,  '||wwv_flow.LF||
'    p_arg1_val        in varchar2 defaul';
wwv_flow_imp.g_varchar2_table(5) := 't null,  '||wwv_flow.LF||
'    p_arg2_name       in varchar2 default null,  '||wwv_flow.LF||
'    p_arg2_val        in varchar2 defaul';
wwv_flow_imp.g_varchar2_table(6) := 't null,  '||wwv_flow.LF||
'    p_arg3_name       in varchar2 default null,  '||wwv_flow.LF||
'    p_arg3_val        in varchar2 defaul';
wwv_flow_imp.g_varchar2_table(7) := 't null,  '||wwv_flow.LF||
'    p_arg4_name       in varchar2 default null,  '||wwv_flow.LF||
'    p_arg4_val        in varchar2 defaul';
wwv_flow_imp.g_varchar2_table(8) := 't null,  '||wwv_flow.LF||
'    p_arg5_name       in varchar2 default null,  '||wwv_flow.LF||
'    p_arg5_val        in varchar2 defaul';
wwv_flow_imp.g_varchar2_table(9) := 't null )  '||wwv_flow.LF||
'is  '||wwv_flow.LF||
'    pragma autonomous_transaction;  '||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'    insert into eba_ema_log  '||wwv_flow.LF||
'       (p';
wwv_flow_imp.g_varchar2_table(10) := 'age_id, procedure_name, log_type, error,  '||wwv_flow.LF||
'        arg1_name, arg1_val, arg2_name, arg2_val, arg3_na';
wwv_flow_imp.g_varchar2_table(11) := 'me, arg3_val,  '||wwv_flow.LF||
'        arg4_name, arg4_val, arg5_name, arg5_val )  '||wwv_flow.LF||
'    values  '||wwv_flow.LF||
'       (apex_appli';
wwv_flow_imp.g_varchar2_table(12) := 'cation.g_flow_step_id, p_procedure_name, p_log_type, p_error,  '||wwv_flow.LF||
'        p_arg1_name, p_arg1_val, p_a';
wwv_flow_imp.g_varchar2_table(13) := 'rg2_name, p_arg2_val, p_arg3_name, p_arg3_val,  '||wwv_flow.LF||
'        p_arg4_name, p_arg4_val, p_arg5_name, p_arg';
wwv_flow_imp.g_varchar2_table(14) := '5_val );  '||wwv_flow.LF||
'    commit;  '||wwv_flow.LF||
'end add_log;  '||wwv_flow.LF||
' '||wwv_flow.LF||
' '||wwv_flow.LF||
'procedure add_setting (  '||wwv_flow.LF||
'    p_name           in  varch';
wwv_flow_imp.g_varchar2_table(15) := 'ar2,   '||wwv_flow.LF||
'    p_display_order  in  number, '||wwv_flow.LF||
'    p_description    in  varchar2, '||wwv_flow.LF||
'    p_value          i';
wwv_flow_imp.g_varchar2_table(16) := 'n  varchar2, '||wwv_flow.LF||
'    p_is_numeric_yn  in  varchar2, '||wwv_flow.LF||
'    p_is_yn          in  varchar2 ) '||wwv_flow.LF||
'is  '||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(17) := '  '||wwv_flow.LF||
'    if p_is_numeric_yn = ''Y'' and p_is_yn = ''Y'' then '||wwv_flow.LF||
'        add_log (  '||wwv_flow.LF||
'            p_procedure_';
wwv_flow_imp.g_varchar2_table(18) := 'name => ''add_setting'',  '||wwv_flow.LF||
'            p_error          => ''Setting cannot be both numeric and YN'',  '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(19) := '            p_arg1_name      => ''p_name'', p_arg1_val => p_name );  '||wwv_flow.LF||
'        raise_application_error(';
wwv_flow_imp.g_varchar2_table(20) := '-20111,''Setting cannot be both numeric and YN.''); '||wwv_flow.LF||
'    end if; '||wwv_flow.LF||
' '||wwv_flow.LF||
'    insert into eba_ema_settings  ';
wwv_flow_imp.g_varchar2_table(21) := ''||wwv_flow.LF||
'        (name, display_order, description, is_numeric_yn, is_yn) '||wwv_flow.LF||
'    values '||wwv_flow.LF||
'        (p_name, p_di';
wwv_flow_imp.g_varchar2_table(22) := 'splay_order, p_description, p_is_numeric_yn, p_is_yn); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    set_setting(p_name => p_name, p_value ';
wwv_flow_imp.g_varchar2_table(23) := '=> p_value); '||wwv_flow.LF||
'  '||wwv_flow.LF||
'exception when others then  '||wwv_flow.LF||
'    add_log (  '||wwv_flow.LF||
'        p_procedure_name => ''add_setti';
wwv_flow_imp.g_varchar2_table(24) := 'ng'',  '||wwv_flow.LF||
'        p_error          =>  sqlerrm,  '||wwv_flow.LF||
'        p_arg1_name      => ''p_name'', p_arg1_val => p';
wwv_flow_imp.g_varchar2_table(25) := '_name );  '||wwv_flow.LF||
'    raise;  '||wwv_flow.LF||
'end add_setting; '||wwv_flow.LF||
' '||wwv_flow.LF||
' '||wwv_flow.LF||
'procedure set_setting (  '||wwv_flow.LF||
'    p_name       in  varchar';
wwv_flow_imp.g_varchar2_table(26) := '2,   '||wwv_flow.LF||
'    p_value      in  varchar2 ) '||wwv_flow.LF||
'is  '||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'  '||wwv_flow.LF||
'    for c1 in ( '||wwv_flow.LF||
'        select id, '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(27) := '       is_numeric_yn, '||wwv_flow.LF||
'               is_yn '||wwv_flow.LF||
'          from eba_ema_settings  '||wwv_flow.LF||
'         where name =';
wwv_flow_imp.g_varchar2_table(28) := ' lower(p_name) '||wwv_flow.LF||
'    ) loop '||wwv_flow.LF||
'        if c1.is_numeric_yn = ''Y'' and validate_conversion(p_value as NUM';
wwv_flow_imp.g_varchar2_table(29) := 'BER) = 0 then '||wwv_flow.LF||
'            add_log (  '||wwv_flow.LF||
'                   p_procedure_name => ''set_setting'',  '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(30) := '              p_log_type       => ''info'', '||wwv_flow.LF||
'                   p_error          => ''Value must be num';
wwv_flow_imp.g_varchar2_table(31) := 'eric'',  '||wwv_flow.LF||
'                   p_arg1_name      => ''p_name'', p_arg1_val => p_name,  '||wwv_flow.LF||
'                  ';
wwv_flow_imp.g_varchar2_table(32) := ' p_arg2_name      => ''p_value'', p_arg2_val => p_value );  '||wwv_flow.LF||
'                raise_application_error(-';
wwv_flow_imp.g_varchar2_table(33) := '20111,''Value must be numeric.''); '||wwv_flow.LF||
'        elsif c1.is_yn = ''Y'' and p_value not in (''Y'',''N'') then '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(34) := '          add_log (  '||wwv_flow.LF||
'                p_procedure_name => ''set_setting'',  '||wwv_flow.LF||
'                p_log_typ';
wwv_flow_imp.g_varchar2_table(35) := 'e       => ''info'', '||wwv_flow.LF||
'                p_error          => ''Value must be Y or N'',  '||wwv_flow.LF||
'                p_';
wwv_flow_imp.g_varchar2_table(36) := 'arg1_name      => ''p_name'', p_arg1_val => p_name,  '||wwv_flow.LF||
'                p_arg2_name      => ''p_value'', p';
wwv_flow_imp.g_varchar2_table(37) := '_arg2_val => p_value );  '||wwv_flow.LF||
'            raise_application_error(-20111,''Value must be Y or N.''); '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(38) := '    end if; '||wwv_flow.LF||
'        update eba_ema_settings  '||wwv_flow.LF||
'           set value = p_value  '||wwv_flow.LF||
'         where id = ';
wwv_flow_imp.g_varchar2_table(39) := 'c1.id;  '||wwv_flow.LF||
'    end loop; '||wwv_flow.LF||
'  '||wwv_flow.LF||
'exception when others then  '||wwv_flow.LF||
'    add_log (  '||wwv_flow.LF||
'        p_procedure_name => ';
wwv_flow_imp.g_varchar2_table(40) := '''set_setting'',  '||wwv_flow.LF||
'        p_error          =>  sqlerrm,  '||wwv_flow.LF||
'        p_arg1_name      => ''p_name'', p_arg';
wwv_flow_imp.g_varchar2_table(41) := '1_val => p_name );  '||wwv_flow.LF||
'    raise;  '||wwv_flow.LF||
'end set_setting; '||wwv_flow.LF||
' '||wwv_flow.LF||
' '||wwv_flow.LF||
'function get_setting (  '||wwv_flow.LF||
'    p_name       in';
wwv_flow_imp.g_varchar2_table(42) := '  varchar2 ) '||wwv_flow.LF||
'    return varchar2  '||wwv_flow.LF||
'is  '||wwv_flow.LF||
'begin  '||wwv_flow.LF||
'    for c1 in (  '||wwv_flow.LF||
'       select value  '||wwv_flow.LF||
'         fr';
wwv_flow_imp.g_varchar2_table(43) := 'om eba_ema_settings   '||wwv_flow.LF||
'        where name = lower(p_name)   '||wwv_flow.LF||
'    ) loop  '||wwv_flow.LF||
'        return c1.value; '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(44) := '    end loop;  '||wwv_flow.LF||
'  '||wwv_flow.LF||
'    return null;  '||wwv_flow.LF||
'end get_setting;  '||wwv_flow.LF||
' '||wwv_flow.LF||
'-----------------------------------------';
wwv_flow_imp.g_varchar2_table(45) := '------ '||wwv_flow.LF||
' '||wwv_flow.LF||
'procedure add_user ( '||wwv_flow.LF||
'    p_username           in  varchar2, '||wwv_flow.LF||
'    p_role_id            in ';
wwv_flow_imp.g_varchar2_table(46) := ' number, '||wwv_flow.LF||
'    p_send_email_yn      in  varchar2 default ''Y'', '||wwv_flow.LF||
'    p_app_id             in  number, '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(47) := '    p_app_url            in  varchar2 default null ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_from_email  varchar2(255)  := get_se';
wwv_flow_imp.g_varchar2_table(48) := 'tting(''from_email''); '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    if p_send_email_yn = ''Y'' and (p_app_url is null or l_from_email is ';
wwv_flow_imp.g_varchar2_table(49) := 'null) then '||wwv_flow.LF||
'        add_log (  '||wwv_flow.LF||
'            p_procedure_name => ''add_user'',  '||wwv_flow.LF||
'            p_log_type';
wwv_flow_imp.g_varchar2_table(50) := '       => ''info'', '||wwv_flow.LF||
'            p_error          => ''Must have app_url and from_email to send email.''';
wwv_flow_imp.g_varchar2_table(51) := ',  '||wwv_flow.LF||
'            p_arg1_name      => ''p_username'', p_arg1_val => p_username,  '||wwv_flow.LF||
'            p_arg2_nam';
wwv_flow_imp.g_varchar2_table(52) := 'e      => ''p_role_id'',  p_arg2_val => p_role_id );  '||wwv_flow.LF||
'        raise_application_error(-20111,''Cannot ';
wwv_flow_imp.g_varchar2_table(53) := 'send email.''); '||wwv_flow.LF||
'    end if; '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- user may already have access '||wwv_flow.LF||
'    if not apex_acl.has_user_any';
wwv_flow_imp.g_varchar2_table(54) := '_roles ( '||wwv_flow.LF||
'               p_application_id => p_app_id,  '||wwv_flow.LF||
'               p_user_name      => p_userna';
wwv_flow_imp.g_varchar2_table(55) := 'me )  '||wwv_flow.LF||
'    then '||wwv_flow.LF||
'        apex_acl.add_user_role ( '||wwv_flow.LF||
'            p_application_id => p_app_id, '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(56) := '      p_user_name      => p_username, '||wwv_flow.LF||
'            p_role_id        => p_role_id ); '||wwv_flow.LF||
'    end if; '||wwv_flow.LF||
' '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(57) := '    if p_send_email_yn = ''Y'' then '||wwv_flow.LF||
'        apex_mail.send ( '||wwv_flow.LF||
'                p_to                 =>';
wwv_flow_imp.g_varchar2_table(58) := ' p_username,   '||wwv_flow.LF||
'                p_from               => l_from_email,  '||wwv_flow.LF||
'                p_applicatio';
wwv_flow_imp.g_varchar2_table(59) := 'n_id     => p_app_id,  '||wwv_flow.LF||
'                p_template_static_id => ''USER_CREATED'',  '||wwv_flow.LF||
'                p_';
wwv_flow_imp.g_varchar2_table(60) := 'placeholders       => ''{'' || ''"APPLICATION_LINK": "'' || p_app_url ||''", ''|| '||wwv_flow.LF||
'                       ';
wwv_flow_imp.g_varchar2_table(61) := '                        ''"USERNAME":'' || apex_json.stringify( p_username ) || '||wwv_flow.LF||
'                     ';
wwv_flow_imp.g_varchar2_table(62) := '                    ''}'' );  '||wwv_flow.LF||
'    end if; '||wwv_flow.LF||
'    '||wwv_flow.LF||
'exception when others then  '||wwv_flow.LF||
'    add_log (  '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(63) := 'p_procedure_name => ''add_user'',  '||wwv_flow.LF||
'        p_error          =>  sqlerrm,  '||wwv_flow.LF||
'        p_arg1_name      =';
wwv_flow_imp.g_varchar2_table(64) := '> ''p_username'', p_arg1_val => p_username,  '||wwv_flow.LF||
'        p_arg2_name      => ''p_role_id'',  p_arg2_val => ';
wwv_flow_imp.g_varchar2_table(65) := 'p_role_id );  '||wwv_flow.LF||
'    raise_application_error(-20111,''Error adding user.''); '||wwv_flow.LF||
'end add_user; '||wwv_flow.LF||
' '||wwv_flow.LF||
' '||wwv_flow.LF||
'procedu';
wwv_flow_imp.g_varchar2_table(66) := 're update_user ( '||wwv_flow.LF||
'    p_username           in  varchar2, '||wwv_flow.LF||
'    p_role_id            in  number, '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(67) := 'p_app_id             in  number ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
' '||wwv_flow.LF||
'    apex_acl.replace_user_roles ( '||wwv_flow.LF||
'        p_applica';
wwv_flow_imp.g_varchar2_table(68) := 'tion_id => p_app_id, '||wwv_flow.LF||
'        p_user_name      => p_username, '||wwv_flow.LF||
'        p_role_ids       => wwv_flow_';
wwv_flow_imp.g_varchar2_table(69) := 't_number(p_role_id) ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'exception when others then  '||wwv_flow.LF||
'    add_log (  '||wwv_flow.LF||
'        p_procedure_name => ''';
wwv_flow_imp.g_varchar2_table(70) := 'update_user'',  '||wwv_flow.LF||
'        p_error          =>  sqlerrm,  '||wwv_flow.LF||
'        p_arg1_name      => ''p_username'', p_';
wwv_flow_imp.g_varchar2_table(71) := 'arg1_val => p_username,  '||wwv_flow.LF||
'        p_arg2_name      => ''p_role_id'',  p_arg2_val => p_role_id );  '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(72) := ' raise_application_error(-20111,''Error updating user.''); '||wwv_flow.LF||
'end update_user; '||wwv_flow.LF||
' '||wwv_flow.LF||
' '||wwv_flow.LF||
'procedure delete_use';
wwv_flow_imp.g_varchar2_table(73) := 'r ( '||wwv_flow.LF||
'    p_username           in  varchar2, '||wwv_flow.LF||
'    p_app_id             in  number ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
' '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(74) := ' apex_acl.remove_all_user_roles ( '||wwv_flow.LF||
'        p_application_id => p_app_id, '||wwv_flow.LF||
'        p_user_name      =';
wwv_flow_imp.g_varchar2_table(75) := '> p_username ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'exception when others then  '||wwv_flow.LF||
'    add_log (  '||wwv_flow.LF||
'        p_procedure_name => ''delete_';
wwv_flow_imp.g_varchar2_table(76) := 'user'',  '||wwv_flow.LF||
'        p_error          =>  sqlerrm,  '||wwv_flow.LF||
'        p_arg1_name      => ''p_username'', p_arg1_va';
wwv_flow_imp.g_varchar2_table(77) := 'l => p_username );  '||wwv_flow.LF||
'    raise_application_error(-20111,''Error deleting user.''); '||wwv_flow.LF||
'end delete_user; '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(78) := ' '||wwv_flow.LF||
' '||wwv_flow.LF||
'procedure send_verification_email ( '||wwv_flow.LF||
'    p_username          in  varchar2, '||wwv_flow.LF||
'    p_token         ';
wwv_flow_imp.g_varchar2_table(79) := '    in  varchar2, '||wwv_flow.LF||
'    p_app_id            in  number ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_from_email  varchar2(255)  := get';
wwv_flow_imp.g_varchar2_table(80) := '_setting(''from_email''); '||wwv_flow.LF||
'begin '||wwv_flow.LF||
' '||wwv_flow.LF||
'    if not apex_acl.has_user_any_roles ( '||wwv_flow.LF||
'               p_applica';
wwv_flow_imp.g_varchar2_table(81) := 'tion_id => p_app_id,  '||wwv_flow.LF||
'               p_user_name      => p_username ) then '||wwv_flow.LF||
'        raise_applicati';
wwv_flow_imp.g_varchar2_table(82) := 'on_error(-20111,''Not a Sample Email Authentication user.''); '||wwv_flow.LF||
'    end if; '||wwv_flow.LF||
' '||wwv_flow.LF||
'    apex_mail.send ( '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(83) := '      p_to                 => p_username,   '||wwv_flow.LF||
'        p_from               => nvl(l_from_email,p_user';
wwv_flow_imp.g_varchar2_table(84) := 'name), -- allows first user to login'||wwv_flow.LF||
'        p_application_id     => p_app_id,  '||wwv_flow.LF||
'        p_template_';
wwv_flow_imp.g_varchar2_table(85) := 'static_id => ''VERIFICATION'',  '||wwv_flow.LF||
'        p_placeholders       => ''{'' || ''"TOKEN": "'' || p_token ||''"'' ';
wwv_flow_imp.g_varchar2_table(86) := '|| '||wwv_flow.LF||
'                                         ''}'' );  '||wwv_flow.LF||
' '||wwv_flow.LF||
'    -- must push to get token out immediatel';
wwv_flow_imp.g_varchar2_table(87) := 'y '||wwv_flow.LF||
'    apex_mail.push_queue; '||wwv_flow.LF||
' '||wwv_flow.LF||
'exception when others then  '||wwv_flow.LF||
'    add_log (  '||wwv_flow.LF||
'        p_procedure_nam';
wwv_flow_imp.g_varchar2_table(88) := 'e => ''send_verification_email'',  '||wwv_flow.LF||
'        p_error          =>  sqlerrm,  '||wwv_flow.LF||
'        p_arg1_name      =';
wwv_flow_imp.g_varchar2_table(89) := '> ''p_username'', p_arg1_val => p_username ); '||wwv_flow.LF||
'    raise_application_error(-20111,''Error sending verif';
wwv_flow_imp.g_varchar2_table(90) := 'ication email.''); '||wwv_flow.LF||
'end send_verification_email; '||wwv_flow.LF||
' '||wwv_flow.LF||
' '||wwv_flow.LF||
'procedure log_access ( '||wwv_flow.LF||
'    p_username     in  ';
wwv_flow_imp.g_varchar2_table(91) := 'varchar2, '||wwv_flow.LF||
'    p_verified_yn  in  varchar2 ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'    pragma autonomous_transaction; '||wwv_flow.LF||
'    l_max_veri';
wwv_flow_imp.g_varchar2_table(92) := 'fy_attempts  number:= get_setting(''max_verify_attempts_per_token''); '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    update eba_ema_verif';
wwv_flow_imp.g_varchar2_table(93) := 'y_tokens '||wwv_flow.LF||
'       set verified_yn     = p_verified_yn, '||wwv_flow.LF||
'           accessed_on     = sysdate, '||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(94) := '     access_attempts = access_attempts + 1, '||wwv_flow.LF||
'           expired_yn      = case when p_verified_yn = ';
wwv_flow_imp.g_varchar2_table(95) := '''N'' and access_attempts + 1 >= l_max_verify_attempts then ''Y''  '||wwv_flow.LF||
'                                  el';
wwv_flow_imp.g_varchar2_table(96) := 'se expired_yn end '||wwv_flow.LF||
'     where expired_yn = ''N'' '||wwv_flow.LF||
'       and username = lower(p_username); '||wwv_flow.LF||
'    commit';
wwv_flow_imp.g_varchar2_table(97) := '; '||wwv_flow.LF||
'end log_access; '||wwv_flow.LF||
' '||wwv_flow.LF||
' '||wwv_flow.LF||
'function is_account_locked_yn (  '||wwv_flow.LF||
'    p_username     in  varchar2 ) '||wwv_flow.LF||
'    ret';
wwv_flow_imp.g_varchar2_table(98) := 'urn varchar2  '||wwv_flow.LF||
'is                                    '||wwv_flow.LF||
'    l_tokens                      number; '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(99) := ' l_reset_verify_after_x_hours  number;      '||wwv_flow.LF||
'    l_max_tokens                  number:= get_setting(';
wwv_flow_imp.g_varchar2_table(100) := '''max_tokens'');  '||wwv_flow.LF||
'    l_max_verify_attempts         number:= get_setting(''max_verify_attempts_per_tok';
wwv_flow_imp.g_varchar2_table(101) := 'en'');                                                                                '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    if ';
wwv_flow_imp.g_varchar2_table(102) := 'p_username is null then '||wwv_flow.LF||
'        return ''Y''; '||wwv_flow.LF||
'    end if; '||wwv_flow.LF||
' '||wwv_flow.LF||
'    l_reset_verify_after_x_hours := coa';
wwv_flow_imp.g_varchar2_table(103) := 'lesce(get_setting(''reset_verify_after_x_hours''),0); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    if l_reset_verify_after_x_hours = 0 then ';
wwv_flow_imp.g_varchar2_table(104) := ''||wwv_flow.LF||
'       return ''N''; '||wwv_flow.LF||
'    end if; '||wwv_flow.LF||
' '||wwv_flow.LF||
'    select count(*) '||wwv_flow.LF||
'      into l_tokens '||wwv_flow.LF||
'      from eba_ema_ver';
wwv_flow_imp.g_varchar2_table(105) := 'ify_tokens '||wwv_flow.LF||
'     where username = lower(p_username) '||wwv_flow.LF||
'       and created_on > sysdate - l_reset_verif';
wwv_flow_imp.g_varchar2_table(106) := 'y_after_x_hours/24 '||wwv_flow.LF||
'       and verified_yn = ''N'' '||wwv_flow.LF||
'       and (expired_yn = ''Y'' or access_attempts >=';
wwv_flow_imp.g_varchar2_table(107) := ' l_max_verify_attempts) '||wwv_flow.LF||
'       and reset_on is null; '||wwv_flow.LF||
' '||wwv_flow.LF||
'    if l_tokens >= l_max_tokens then '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(108) := '   return ''Y''; '||wwv_flow.LF||
'    else '||wwv_flow.LF||
'        return ''N''; '||wwv_flow.LF||
'    end if; '||wwv_flow.LF||
'end is_account_locked_yn; '||wwv_flow.LF||
' '||wwv_flow.LF||
' '||wwv_flow.LF||
'function ';
wwv_flow_imp.g_varchar2_table(109) := 'is_token_maxed_yn ( '||wwv_flow.LF||
'    p_username     in  varchar2 ) '||wwv_flow.LF||
'    return varchar2  '||wwv_flow.LF||
'is '||wwv_flow.LF||
'    l_reset_verify';
wwv_flow_imp.g_varchar2_table(110) := '_after_x_hours  number; '||wwv_flow.LF||
'    l_max_verify_attempts         number:= get_setting(''max_verify_attempts';
wwv_flow_imp.g_varchar2_table(111) := '_per_token''); '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    l_reset_verify_after_x_hours := coalesce(get_setting(''reset_verify_after_x';
wwv_flow_imp.g_varchar2_table(112) := '_hours''),0); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    for c1 in ( '||wwv_flow.LF||
'        select coalesce ( '||wwv_flow.LF||
'                   (select access_attemp';
wwv_flow_imp.g_varchar2_table(113) := 'ts '||wwv_flow.LF||
'                      from eba_ema_verify_tokens '||wwv_flow.LF||
'                     where username = lower(p_';
wwv_flow_imp.g_varchar2_table(114) := 'username) '||wwv_flow.LF||
'                       and (l_reset_verify_after_x_hours = 0 or created_on > sysdate - l_';
wwv_flow_imp.g_varchar2_table(115) := 'reset_verify_after_x_hours/24) '||wwv_flow.LF||
'                       and verified_yn = ''N'' '||wwv_flow.LF||
'                      ';
wwv_flow_imp.g_varchar2_table(116) := ' and expired_yn = ''N'' '||wwv_flow.LF||
'                       and reset_on is null ),  '||wwv_flow.LF||
'                   (select a';
wwv_flow_imp.g_varchar2_table(117) := 'ccess_attempts '||wwv_flow.LF||
'                      from eba_ema_verify_tokens '||wwv_flow.LF||
'                     where usernam';
wwv_flow_imp.g_varchar2_table(118) := 'e = lower(p_username) '||wwv_flow.LF||
'                       and (l_reset_verify_after_x_hours = 0 or created_on > ';
wwv_flow_imp.g_varchar2_table(119) := 'sysdate - l_reset_verify_after_x_hours/24) '||wwv_flow.LF||
'                       and updated_on = (select max (upd';
wwv_flow_imp.g_varchar2_table(120) := 'ated_on) '||wwv_flow.LF||
'                                           from eba_ema_verify_tokens '||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(121) := '                       where username = lower(p_username)) ) '||wwv_flow.LF||
'                   ,0) verification_at';
wwv_flow_imp.g_varchar2_table(122) := 'tempts '||wwv_flow.LF||
'          from dual '||wwv_flow.LF||
'    ) loop '||wwv_flow.LF||
'        if c1.verification_attempts < l_max_verify_attempts';
wwv_flow_imp.g_varchar2_table(123) := ' then '||wwv_flow.LF||
'           return ''N''; '||wwv_flow.LF||
'        end if; '||wwv_flow.LF||
'    end loop; '||wwv_flow.LF||
' '||wwv_flow.LF||
'    return ''Y''; '||wwv_flow.LF||
'end is_token_maxed';
wwv_flow_imp.g_varchar2_table(124) := '_yn;  '||wwv_flow.LF||
' '||wwv_flow.LF||
' '||wwv_flow.LF||
'function generate_token ( '||wwv_flow.LF||
'    p_username       in  varchar2 ) '||wwv_flow.LF||
'    return varchar2  '||wwv_flow.LF||
'is ';
wwv_flow_imp.g_varchar2_table(125) := ''||wwv_flow.LF||
'    l_max_verify_attempts         number := get_setting(''max_verify_attempts'');  '||wwv_flow.LF||
'    l_grace_minut';
wwv_flow_imp.g_varchar2_table(126) := 'es               number := 5; '||wwv_flow.LF||
'    l_token_length                number := 6; '||wwv_flow.LF||
'    l_expire_minutes ';
wwv_flow_imp.g_varchar2_table(127) := '             number := 15; -- if change to setting, need to update verification email template '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(128) := '-- '||wwv_flow.LF||
'    l_token                       varchar2(255); '||wwv_flow.LF||
'begin '||wwv_flow.LF||
' '||wwv_flow.LF||
'    if l_max_verify_attempts > 0 then';
wwv_flow_imp.g_varchar2_table(129) := ' '||wwv_flow.LF||
' '||wwv_flow.LF||
'        if is_account_locked_yn(p_username => p_username) = ''Y'' then '||wwv_flow.LF||
'            add_log (p_pro';
wwv_flow_imp.g_varchar2_table(130) := 'cedure_name => ''generate_token'',  '||wwv_flow.LF||
'                           p_log_type       => ''info'', '||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(131) := '                  p_error          => ''Maximum verification attempts exceeded'', '||wwv_flow.LF||
'                   ';
wwv_flow_imp.g_varchar2_table(132) := '        p_arg1_name      => ''p_username'', p_arg1_val => p_username ); '||wwv_flow.LF||
'            raise e_account_l';
wwv_flow_imp.g_varchar2_table(133) := 'ocked; '||wwv_flow.LF||
'--            raise_application_error(-20111,''Maximum verification attempts exceeded.  Accou';
wwv_flow_imp.g_varchar2_table(134) := 'nt will reset in ''||get_setting(''reset_verify_after_x_hours'')||'' hours.''); '||wwv_flow.LF||
'        end if; '||wwv_flow.LF||
' '||wwv_flow.LF||
'    e';
wwv_flow_imp.g_varchar2_table(135) := 'nd if; '||wwv_flow.LF||
' '||wwv_flow.LF||
'    begin '||wwv_flow.LF||
'        select token '||wwv_flow.LF||
'          into l_token '||wwv_flow.LF||
'          from eba_ema_verify_tok';
wwv_flow_imp.g_varchar2_table(136) := 'ens '||wwv_flow.LF||
'        where username = lower(p_username) '||wwv_flow.LF||
'          and expire_on > sysdate - l_grace_minutes';
wwv_flow_imp.g_varchar2_table(137) := '/(24*60) '||wwv_flow.LF||
'          and verified_yn = ''N'' '||wwv_flow.LF||
'          and expired_yn = ''N''; '||wwv_flow.LF||
'    exception '||wwv_flow.LF||
'        w';
wwv_flow_imp.g_varchar2_table(138) := 'hen too_many_rows or no_data_found then '||wwv_flow.LF||
'            null; '||wwv_flow.LF||
'    end; '||wwv_flow.LF||
' '||wwv_flow.LF||
'    if l_token is null then ';
wwv_flow_imp.g_varchar2_table(139) := ''||wwv_flow.LF||
' '||wwv_flow.LF||
'        update eba_ema_verify_tokens '||wwv_flow.LF||
'           set expired_yn = ''Y'' '||wwv_flow.LF||
'         where username = ';
wwv_flow_imp.g_varchar2_table(140) := 'lower(p_username) '||wwv_flow.LF||
'           and expired_yn = ''N''; '||wwv_flow.LF||
' '||wwv_flow.LF||
'        l_token := lpad(to_char(round(dbms_ra';
wwv_flow_imp.g_varchar2_table(141) := 'ndom.value(1,999999))),l_token_length,''0''); '||wwv_flow.LF||
' '||wwv_flow.LF||
'        insert into eba_ema_verify_tokens ( '||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(142) := '    username, '||wwv_flow.LF||
'            token, '||wwv_flow.LF||
'            expire_on ) '||wwv_flow.LF||
'        values ( '||wwv_flow.LF||
'            lower(p_us';
wwv_flow_imp.g_varchar2_table(143) := 'ername), '||wwv_flow.LF||
'            l_token, '||wwv_flow.LF||
'            sysdate + l_expire_minutes/(24*60) ); '||wwv_flow.LF||
' '||wwv_flow.LF||
'    end if; '||wwv_flow.LF||
' '||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(144) := '    return l_token; '||wwv_flow.LF||
'exception  '||wwv_flow.LF||
'    when others then '||wwv_flow.LF||
'        add_log (p_procedure_name => ''generat';
wwv_flow_imp.g_varchar2_table(145) := 'e_token'',  '||wwv_flow.LF||
'                       p_error => sqlerrm, '||wwv_flow.LF||
'                       p_arg1_name => ''p_use';
wwv_flow_imp.g_varchar2_table(146) := 'rname'', p_arg1_val => p_username ); '||wwv_flow.LF||
'        raise; '||wwv_flow.LF||
'end generate_token; '||wwv_flow.LF||
' '||wwv_flow.LF||
' '||wwv_flow.LF||
'function token_is_vali';
wwv_flow_imp.g_varchar2_table(147) := 'd ( '||wwv_flow.LF||
'    p_username    in  varchar2, '||wwv_flow.LF||
'    p_token       in  varchar2 ) '||wwv_flow.LF||
'    return boolean  '||wwv_flow.LF||
'is '||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(148) := ' l_verified_yn  varchar2(1); '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'    begin '||wwv_flow.LF||
'        select ''Y'' '||wwv_flow.LF||
'          into l_verified_yn '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(149) := '        from eba_ema_verify_tokens  '||wwv_flow.LF||
'         where username = lower(p_username) '||wwv_flow.LF||
'           and tok';
wwv_flow_imp.g_varchar2_table(150) := 'en = trim(p_token) '||wwv_flow.LF||
'           and expire_on > sysdate '||wwv_flow.LF||
'           and expired_yn = ''N'' '||wwv_flow.LF||
'           ';
wwv_flow_imp.g_varchar2_table(151) := 'and rownum = 1; '||wwv_flow.LF||
'    exception when no_data_found then '||wwv_flow.LF||
'        l_verified_yn := ''N''; '||wwv_flow.LF||
'        add_l';
wwv_flow_imp.g_varchar2_table(152) := 'og (p_procedure_name => ''token_is_valid'',  '||wwv_flow.LF||
'                       p_log_type       => ''info'', '||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(153) := '                   p_error          => ''invalid token used'', '||wwv_flow.LF||
'                       p_arg1_name => ';
wwv_flow_imp.g_varchar2_table(154) := '''p_username'', p_arg1_val => p_username, '||wwv_flow.LF||
'                       p_arg2_name => ''p_token'', p_arg2_val';
wwv_flow_imp.g_varchar2_table(155) := ' => p_token ); '||wwv_flow.LF||
'    end; '||wwv_flow.LF||
'    log_access ( '||wwv_flow.LF||
'        p_username    => p_username, '||wwv_flow.LF||
'        p_verified';
wwv_flow_imp.g_varchar2_table(156) := '_yn => l_verified_yn ); '||wwv_flow.LF||
'    return l_verified_yn = ''Y''; '||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'    add_log (p';
wwv_flow_imp.g_varchar2_table(157) := '_procedure_name => ''token_is_valid'',  '||wwv_flow.LF||
'                   p_error => sqlerrm, '||wwv_flow.LF||
'                   p_';
wwv_flow_imp.g_varchar2_table(158) := 'arg1_name => ''p_username'', p_arg1_val => p_username, '||wwv_flow.LF||
'                   p_arg2_name => ''p_token'', p';
wwv_flow_imp.g_varchar2_table(159) := '_arg2_val => p_token ); '||wwv_flow.LF||
'    raise_application_error(-20111,''Error validating token.''); '||wwv_flow.LF||
'end token_i';
wwv_flow_imp.g_varchar2_table(160) := 's_valid; '||wwv_flow.LF||
' '||wwv_flow.LF||
' '||wwv_flow.LF||
'procedure reset_verification_tokens ( '||wwv_flow.LF||
'    p_username    in  varchar2 ) '||wwv_flow.LF||
'is '||wwv_flow.LF||
'begin '||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(161) := '  update eba_ema_verify_tokens  '||wwv_flow.LF||
'       set reset_on = sysdate, '||wwv_flow.LF||
'           reset_by = lower(nvl(sys';
wwv_flow_imp.g_varchar2_table(162) := '_context(''APEX$SESSION'',''APP_USER''),user)) '||wwv_flow.LF||
'     where username = lower(p_username) '||wwv_flow.LF||
'       and rese';
wwv_flow_imp.g_varchar2_table(163) := 't_on is null '||wwv_flow.LF||
'       and verified_yn = ''N''; '||wwv_flow.LF||
'exception when others then '||wwv_flow.LF||
'    add_log (p_procedure_na';
wwv_flow_imp.g_varchar2_table(164) := 'me => ''reset_verification_tokens'',  '||wwv_flow.LF||
'                   p_error => sqlerrm, '||wwv_flow.LF||
'                   p_ar';
wwv_flow_imp.g_varchar2_table(165) := 'g1_name => ''p_username'', p_arg1_val => p_username); '||wwv_flow.LF||
'    raise_application_error(-20111,''Error reset';
wwv_flow_imp.g_varchar2_table(166) := 'ting verification token.''); '||wwv_flow.LF||
'end reset_verification_tokens; '||wwv_flow.LF||
' '||wwv_flow.LF||
'end eba_ema_util; '||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1886791373408039970)
,p_install_id=>wwv_flow_imp.id(1886576440827719146)
,p_name=>'package body'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
