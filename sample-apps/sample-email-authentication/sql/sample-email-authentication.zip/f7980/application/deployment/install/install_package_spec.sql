prompt --application/deployment/install/install_package_spec
begin
--   Manifest
--     INSTALL: INSTALL-package spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>13699378009317950
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package eba_ema_util '||wwv_flow.LF||
'as'||wwv_flow.LF||
''||wwv_flow.LF||
'-- if user exceeds max verification attempts, this is ra';
wwv_flow_imp.g_varchar2_table(2) := 'ised for the app to read from'||wwv_flow.LF||
'e_account_locked  exception;'||wwv_flow.LF||
''||wwv_flow.LF||
'-- To catch PL/SQL error, error log proc';
wwv_flow_imp.g_varchar2_table(3) := 'edure needs to be autonomous transactions and do commit at the end. '||wwv_flow.LF||
'procedure add_log ( '||wwv_flow.LF||
'    p_proc';
wwv_flow_imp.g_varchar2_table(4) := 'edure_name  in varchar2, '||wwv_flow.LF||
'    p_log_type        in varchar2 default ''error'','||wwv_flow.LF||
'    p_error           i';
wwv_flow_imp.g_varchar2_table(5) := 'n varchar2, '||wwv_flow.LF||
'    p_arg1_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg1_val        in varchar2 defa';
wwv_flow_imp.g_varchar2_table(6) := 'ult null, '||wwv_flow.LF||
'    p_arg2_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg2_val        in varchar2 defaul';
wwv_flow_imp.g_varchar2_table(7) := 't null, '||wwv_flow.LF||
'    p_arg3_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg3_val        in varchar2 default ';
wwv_flow_imp.g_varchar2_table(8) := 'null, '||wwv_flow.LF||
'    p_arg4_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg4_val        in varchar2 default nu';
wwv_flow_imp.g_varchar2_table(9) := 'll, '||wwv_flow.LF||
'    p_arg5_name       in varchar2 default null, '||wwv_flow.LF||
'    p_arg5_val        in varchar2 default null';
wwv_flow_imp.g_varchar2_table(10) := ' ); '||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_setting ( '||wwv_flow.LF||
'    p_name           in  varchar2,  '||wwv_flow.LF||
'    p_display_order  in  number,';
wwv_flow_imp.g_varchar2_table(11) := ''||wwv_flow.LF||
'    p_description    in  varchar2,'||wwv_flow.LF||
'    p_value          in  varchar2,'||wwv_flow.LF||
'    p_is_numeric_yn  in  varc';
wwv_flow_imp.g_varchar2_table(12) := 'har2,'||wwv_flow.LF||
'    p_is_yn          in  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure set_setting ( '||wwv_flow.LF||
'    p_name       in  varchar2, ';
wwv_flow_imp.g_varchar2_table(13) := ' '||wwv_flow.LF||
'    p_value      in  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'function get_setting ( '||wwv_flow.LF||
'    p_name       in  varchar2 )'||wwv_flow.LF||
'    retu';
wwv_flow_imp.g_varchar2_table(14) := 'rn varchar2; '||wwv_flow.LF||
''||wwv_flow.LF||
'-----------------------------------------------'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure add_user ('||wwv_flow.LF||
'    p_username ';
wwv_flow_imp.g_varchar2_table(15) := '          in  varchar2,'||wwv_flow.LF||
'    p_role_id            in  number,'||wwv_flow.LF||
'    p_send_email_yn      in  varchar2 d';
wwv_flow_imp.g_varchar2_table(16) := 'efault ''Y'','||wwv_flow.LF||
'    p_app_id             in  number,'||wwv_flow.LF||
'    p_app_url            in  varchar2 default null ';
wwv_flow_imp.g_varchar2_table(17) := ');'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure update_user ('||wwv_flow.LF||
'    p_username           in  varchar2,'||wwv_flow.LF||
'    p_role_id            in  numb';
wwv_flow_imp.g_varchar2_table(18) := 'er,'||wwv_flow.LF||
'    p_app_id             in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure delete_user ('||wwv_flow.LF||
'    p_username           in  var';
wwv_flow_imp.g_varchar2_table(19) := 'char2,'||wwv_flow.LF||
'    p_app_id             in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure send_verification_email ('||wwv_flow.LF||
'    p_username   ';
wwv_flow_imp.g_varchar2_table(20) := '       in  varchar2,'||wwv_flow.LF||
'    p_token             in  varchar2,'||wwv_flow.LF||
'    p_app_id            in  number );'||wwv_flow.LF||
''||wwv_flow.LF||
'pr';
wwv_flow_imp.g_varchar2_table(21) := 'ocedure log_access ('||wwv_flow.LF||
'    p_username     in  varchar2,'||wwv_flow.LF||
'    p_verified_yn  in  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'function ';
wwv_flow_imp.g_varchar2_table(22) := 'is_account_locked_yn ( '||wwv_flow.LF||
'    p_username     in  varchar2 )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function is_token_ma';
wwv_flow_imp.g_varchar2_table(23) := 'xed_yn ('||wwv_flow.LF||
'    p_username     in  varchar2 )'||wwv_flow.LF||
'    return varchar2; '||wwv_flow.LF||
''||wwv_flow.LF||
'function generate_token ('||wwv_flow.LF||
'    p_us';
wwv_flow_imp.g_varchar2_table(24) := 'ername       in  varchar2 )'||wwv_flow.LF||
'    return varchar2;'||wwv_flow.LF||
''||wwv_flow.LF||
'function token_is_valid ('||wwv_flow.LF||
'    p_username    in  va';
wwv_flow_imp.g_varchar2_table(25) := 'rchar2,'||wwv_flow.LF||
'    p_token       in  varchar2 )'||wwv_flow.LF||
'    return boolean;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure reset_verification_tokens ('||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(26) := '    p_username    in  varchar2 );'||wwv_flow.LF||
''||wwv_flow.LF||
'end eba_ema_util;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1886780963701037830)
,p_install_id=>wwv_flow_imp.id(1886576440827719146)
,p_name=>'package spec'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
