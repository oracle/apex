prompt --application/deployment/install/install_create_first_user
begin
--   Manifest
--     INSTALL: INSTALL-create first user
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>13699378009317950
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'declare'||wwv_flow.LF||
'    l_app_user  varchar2(255) := apex_custom_auth.get_username;'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    for u in ('||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(2) := ' select email'||wwv_flow.LF||
'          from apex_workspace_apex_users'||wwv_flow.LF||
'         where user_name = l_app_user'||wwv_flow.LF||
'    ) l';
wwv_flow_imp.g_varchar2_table(3) := 'oop'||wwv_flow.LF||
'        for a in ('||wwv_flow.LF||
'            select application_id'||wwv_flow.LF||
'              from apex_applications'||wwv_flow.LF||
'      ';
wwv_flow_imp.g_varchar2_table(4) := '       where application_name = ''Sample Email Authentication'''||wwv_flow.LF||
'             order by last_updated_on ';
wwv_flow_imp.g_varchar2_table(5) := 'desc'||wwv_flow.LF||
'        ) loop'||wwv_flow.LF||
'            for r in ('||wwv_flow.LF||
'                select role_id'||wwv_flow.LF||
'                  from ape';
wwv_flow_imp.g_varchar2_table(6) := 'x_appl_acl_roles'||wwv_flow.LF||
'                 where application_id = a.application_id '||wwv_flow.LF||
'                   and ro';
wwv_flow_imp.g_varchar2_table(7) := 'le_static_id = ''ADMINISTRATOR'''||wwv_flow.LF||
'            ) loop'||wwv_flow.LF||
'                eba_ema_util.add_user ('||wwv_flow.LF||
'          ';
wwv_flow_imp.g_varchar2_table(8) := '          p_username      => u.email,'||wwv_flow.LF||
'                    p_role_id       => r.role_id,'||wwv_flow.LF||
'            ';
wwv_flow_imp.g_varchar2_table(9) := '        p_send_email_yn => ''N'','||wwv_flow.LF||
'                    p_app_id        => a.application_id );'||wwv_flow.LF||
'         ';
wwv_flow_imp.g_varchar2_table(10) := '       exit;'||wwv_flow.LF||
'            end loop;'||wwv_flow.LF||
'            exit;'||wwv_flow.LF||
'        end loop;'||wwv_flow.LF||
'    end loop;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(16187778347960938374)
,p_install_id=>wwv_flow_imp.id(1886576440827719146)
,p_name=>'create first user'
,p_sequence=>50
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
