prompt --application/deployment/install/install_create_tables
begin
--   Manifest
--     INSTALL: INSTALL-create tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>13699378009317950
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create table eba_ema_log ('||wwv_flow.LF||
'    id                             number '||wwv_flow.LF||
'                              ';
wwv_flow_imp.g_varchar2_table(2) := '        default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                 ';
wwv_flow_imp.g_varchar2_table(3) := '                     constraint eba_ema_log_pk primary key,'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   page_id                        ';
wwv_flow_imp.g_varchar2_table(4) := ' number,'||wwv_flow.LF||
'   procedure_name                  varchar2(1000),'||wwv_flow.LF||
'   log_type                        varch';
wwv_flow_imp.g_varchar2_table(5) := 'ar2(30)    not null'||wwv_flow.LF||
'                                       constraint eba_ema_log_type check (log_ty';
wwv_flow_imp.g_varchar2_table(6) := 'pe in (''error'',''info'')),'||wwv_flow.LF||
'   error                           varchar2(4000)  not null,'||wwv_flow.LF||
'   --'||wwv_flow.LF||
'   arg1_';
wwv_flow_imp.g_varchar2_table(7) := 'name                       varchar2(255),'||wwv_flow.LF||
'   arg1_val                        varchar2(4000),'||wwv_flow.LF||
'   arg2';
wwv_flow_imp.g_varchar2_table(8) := '_name                       varchar2(255),'||wwv_flow.LF||
'   arg2_val                        varchar2(4000),'||wwv_flow.LF||
'   arg';
wwv_flow_imp.g_varchar2_table(9) := '3_name                       varchar2(255),'||wwv_flow.LF||
'   arg3_val                        varchar2(4000),'||wwv_flow.LF||
'   ar';
wwv_flow_imp.g_varchar2_table(10) := 'g4_name                       varchar2(255),'||wwv_flow.LF||
'   arg4_val                        varchar2(4000),'||wwv_flow.LF||
'   a';
wwv_flow_imp.g_varchar2_table(11) := 'rg5_name                       varchar2(255),'||wwv_flow.LF||
'   arg5_val                        varchar2(4000),'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(12) := '--'||wwv_flow.LF||
'   created_on                      date  not null,'||wwv_flow.LF||
'   created_trunc                   date  not n';
wwv_flow_imp.g_varchar2_table(13) := 'ull,'||wwv_flow.LF||
'   created_by                      varchar2(255)  not null'||wwv_flow.LF||
');'||wwv_flow.LF||
'create index eba_ema_error_log_i1';
wwv_flow_imp.g_varchar2_table(14) := ' on eba_ema_log (created_trunc);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_ema_log_bi'||wwv_flow.LF||
'    before insert'||wwv_flow.LF||
'    on ';
wwv_flow_imp.g_varchar2_table(15) := 'eba_ema_log'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    :new.created_on    := sysdate;'||wwv_flow.LF||
'    :new.created_trunc := trun';
wwv_flow_imp.g_varchar2_table(16) := 'c(sysdate);'||wwv_flow.LF||
'    :new.created_by    := lower(nvl(sys_context(''APEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'end ';
wwv_flow_imp.g_varchar2_table(17) := 'eba_ema_log_bi;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_ema_settings ('||wwv_flow.LF||
'    id                             number '||wwv_flow.LF||
'     ';
wwv_flow_imp.g_varchar2_table(18) := '                                 default on null to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(19) := 'XXXX'') '||wwv_flow.LF||
'                                      constraint eba_ema_settings_pk primary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(20) := ' display_order                  number,'||wwv_flow.LF||
'    name                           varchar2(255)  not null'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(21) := '                                     constraint eba_ema_settings_uk unique,'||wwv_flow.LF||
'    description         ';
wwv_flow_imp.g_varchar2_table(22) := '           varchar2(4000) not null,'||wwv_flow.LF||
'    value                          varchar2(4000),'||wwv_flow.LF||
'    is_numeri';
wwv_flow_imp.g_varchar2_table(23) := 'c_yn                  varchar2(1)    not null    -- used in validation'||wwv_flow.LF||
'                             ';
wwv_flow_imp.g_varchar2_table(24) := '         constraint eba_ema_settings_is_numeric_cc'||wwv_flow.LF||
'                                      check (is_n';
wwv_flow_imp.g_varchar2_table(25) := 'umeric_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    is_yn                          varchar2(1)    not null    -- used in va';
wwv_flow_imp.g_varchar2_table(26) := 'lidation'||wwv_flow.LF||
'                                      constraint eba_ema_settings_is_yn_cc'||wwv_flow.LF||
'                ';
wwv_flow_imp.g_varchar2_table(27) := '                      check (is_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    row_version                    integer ';
wwv_flow_imp.g_varchar2_table(28) := '        not null,'||wwv_flow.LF||
'    created_on                     date            not null,'||wwv_flow.LF||
'    created_by       ';
wwv_flow_imp.g_varchar2_table(29) := '              varchar2(255)   not null,'||wwv_flow.LF||
'    updated_on                     date            not null,';
wwv_flow_imp.g_varchar2_table(30) := ''||wwv_flow.LF||
'    updated_by                     varchar2(255)   not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_ema_s';
wwv_flow_imp.g_varchar2_table(31) := 'ettings_biu'||wwv_flow.LF||
'    before insert or update '||wwv_flow.LF||
'    on eba_ema_settings'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inser';
wwv_flow_imp.g_varchar2_table(32) := 'ting then'||wwv_flow.LF||
'        :new.row_version := 1;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.row_version := nvl(:ol';
wwv_flow_imp.g_varchar2_table(33) := 'd.row_version,0) + 1;'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_on := sysdate;'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(34) := ':new.created_by := lower(nvl(sys_context(''APEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.up';
wwv_flow_imp.g_varchar2_table(35) := 'dated_on := sysdate;'||wwv_flow.LF||
'    :new.updated_by := lower(nvl(sys_context(''APEX$SESSION'',''APP_USER''),user));';
wwv_flow_imp.g_varchar2_table(36) := ' '||wwv_flow.LF||
'end eba_ema_settings_biu;'||wwv_flow.LF||
'/'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'create table eba_ema_verify_tokens ('||wwv_flow.LF||
'    id                         ';
wwv_flow_imp.g_varchar2_table(37) := '    number '||wwv_flow.LF||
'                                      default on null to_number(sys_guid(), ''XXXXXXXXXXX';
wwv_flow_imp.g_varchar2_table(38) := 'XXXXXXXXXXXXXXXXXXXXX'') '||wwv_flow.LF||
'                                      constraint eba_ema_verify_tokens_pk p';
wwv_flow_imp.g_varchar2_table(39) := 'rimary key,'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    username                       varchar2(255) not null,'||wwv_flow.LF||
'    token             ';
wwv_flow_imp.g_varchar2_table(40) := '             varchar2(30)  not null,'||wwv_flow.LF||
'    verified_yn                    varchar2(1)   default ''N'' no';
wwv_flow_imp.g_varchar2_table(41) := 't null  '||wwv_flow.LF||
'                                      constraint eba_ema_verify_tokens_verified_cc'||wwv_flow.LF||
'        ';
wwv_flow_imp.g_varchar2_table(42) := '                              check (verified_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    expired_yn                     v';
wwv_flow_imp.g_varchar2_table(43) := 'archar2(1)   default ''N'' not null  '||wwv_flow.LF||
'                                      constraint eba_ema_verify_';
wwv_flow_imp.g_varchar2_table(44) := 'tokens_expired_cc'||wwv_flow.LF||
'                                      check (expired_yn in (''Y'',''N'')),'||wwv_flow.LF||
'    expire_';
wwv_flow_imp.g_varchar2_table(45) := 'on                      date  not null,'||wwv_flow.LF||
'    accessed_on                    date,'||wwv_flow.LF||
'    access_attempts';
wwv_flow_imp.g_varchar2_table(46) := '                number  default 0  not null,'||wwv_flow.LF||
'    reset_on                       date,'||wwv_flow.LF||
'    reset_by  ';
wwv_flow_imp.g_varchar2_table(47) := '                     varchar2(255),'||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    row_version                    integer       not null';
wwv_flow_imp.g_varchar2_table(48) := ','||wwv_flow.LF||
'    created_on                     date          not null,'||wwv_flow.LF||
'    created_by                     varc';
wwv_flow_imp.g_varchar2_table(49) := 'har2(255) not null,'||wwv_flow.LF||
'    updated_on                     date          not null,'||wwv_flow.LF||
'    updated_by       ';
wwv_flow_imp.g_varchar2_table(50) := '              varchar2(255) not null'||wwv_flow.LF||
');'||wwv_flow.LF||
''||wwv_flow.LF||
'create index eba_ema_verify_tokens_i1 on eba_ema_verify_tok';
wwv_flow_imp.g_varchar2_table(51) := 'ens (username, token);'||wwv_flow.LF||
''||wwv_flow.LF||
'create or replace trigger eba_ema_verify_tokens_biu'||wwv_flow.LF||
'    before insert or upd';
wwv_flow_imp.g_varchar2_table(52) := 'ate '||wwv_flow.LF||
'    on eba_ema_verify_tokens'||wwv_flow.LF||
'    for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.row_vers';
wwv_flow_imp.g_varchar2_table(53) := 'ion := 1;'||wwv_flow.LF||
'    elsif updating then'||wwv_flow.LF||
'        :new.row_version := nvl(:old.row_version,0) + 1;'||wwv_flow.LF||
'    end i';
wwv_flow_imp.g_varchar2_table(54) := 'f;'||wwv_flow.LF||
'    if inserting then'||wwv_flow.LF||
'        :new.created_on := sysdate;'||wwv_flow.LF||
'        :new.created_by := lower(nvl(sy';
wwv_flow_imp.g_varchar2_table(55) := 's_context(''APEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    :new.updated_on := sysdate;'||wwv_flow.LF||
'    :new.u';
wwv_flow_imp.g_varchar2_table(56) := 'pdated_by := lower(nvl(sys_context(''APEX$SESSION'',''APP_USER''),user)); '||wwv_flow.LF||
'end eba_ema_verify_tokens_biu';
wwv_flow_imp.g_varchar2_table(57) := ';'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1886594609087722911)
,p_install_id=>wwv_flow_imp.id(1886576440827719146)
,p_name=>'create tables'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
