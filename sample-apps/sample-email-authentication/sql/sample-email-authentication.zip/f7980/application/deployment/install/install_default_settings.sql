prompt --application/deployment/install/install_default_settings
begin
--   Manifest
--     INSTALL: INSTALL-default settings
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>13699378009317950
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '-- load settings'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'    eba_ema_util.add_setting ('||wwv_flow.LF||
'        p_name          => ''from_email'','||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(2) := '    p_display_order => 30,'||wwv_flow.LF||
'        p_description   => ''used as the from address for the emails sent ';
wwv_flow_imp.g_varchar2_table(3) := '(for tokens, account requests)'','||wwv_flow.LF||
'        p_value         => '''','||wwv_flow.LF||
'        p_is_numeric_yn => ''N'','||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(4) := '    p_is_yn         => ''N'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'    eba_ema_util.add_setting ('||wwv_flow.LF||
'        p_name          => ''max_tokens';
wwv_flow_imp.g_varchar2_table(5) := ''','||wwv_flow.LF||
'        p_display_order => 50,'||wwv_flow.LF||
'        p_description   => ''how many tokens can be generated durin';
wwv_flow_imp.g_varchar2_table(6) := 'g the reset window'','||wwv_flow.LF||
'        p_value         => ''3'','||wwv_flow.LF||
'        p_is_numeric_yn => ''Y'','||wwv_flow.LF||
'        p_is_yn';
wwv_flow_imp.g_varchar2_table(7) := '         => ''N'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'    eba_ema_util.add_setting ('||wwv_flow.LF||
'        p_name          => ''max_verify_attempts_p';
wwv_flow_imp.g_varchar2_table(8) := 'er_token'','||wwv_flow.LF||
'        p_display_order => 55,'||wwv_flow.LF||
'        p_description   => ''how many verification attempts';
wwv_flow_imp.g_varchar2_table(9) := ' before a token is no longer valid'','||wwv_flow.LF||
'        p_value         => ''3'','||wwv_flow.LF||
'        p_is_numeric_yn => ''Y'',';
wwv_flow_imp.g_varchar2_table(10) := ''||wwv_flow.LF||
'        p_is_yn         => ''N'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'    eba_ema_util.add_setting ('||wwv_flow.LF||
'        p_name          => ''reset';
wwv_flow_imp.g_varchar2_table(11) := '_verify_after_x_hours'','||wwv_flow.LF||
'        p_display_order => 60,'||wwv_flow.LF||
'        p_description   => ''how many hours a ';
wwv_flow_imp.g_varchar2_table(12) := 'user will be locked out after exceeding max tokens/max attempts'','||wwv_flow.LF||
'        p_value         => ''1'','||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(13) := '      p_is_numeric_yn => ''Y'','||wwv_flow.LF||
'        p_is_yn         => ''N'' );'||wwv_flow.LF||
''||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1886796961188041714)
,p_install_id=>wwv_flow_imp.id(1886576440827719146)
,p_name=>'default settings'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
