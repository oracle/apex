prompt --application/shared_components/logic/application_processes/check_for_email_from
begin
--   Manifest
--     APPLICATION PROCESS: check for email_from
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>13699378009317950
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(16190821113220476406)
,p_process_sequence=>1
,p_process_point=>'BEFORE_HEADER'
,p_process_name=>'check for email_from'
,p_static_id=>'check-for-email-from'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if eba_ema_util.get_setting (p_name => ''from_email'') is null then',
'   apex_util.redirect_url(apex_page.get_url(',
'                                   p_application => :APP_ID,',
'                                   p_page        => ''10010'',',
'                                   p_session     => :APP_SESSION ));',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'9998,9999,10010'
,p_process_when_type=>'CURRENT_PAGE_NOT_IN_CONDITION'
,p_security_scheme=>wwv_flow_imp.id(48312976300819439640)
,p_version_scn=>'15506383683779'
);
wwv_flow_imp.component_end;
end;
/
