prompt --application/shared_components/navigation/lists/user_related_actions
begin
--   Manifest
--     LIST: User Related Actions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>13699378009317950
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(48313118609480440120)
,p_name=>'User Related Actions'
,p_static_id=>'user-related-actions'
,p_required_patch=>wwv_flow_imp.id(48312974028088439639)
,p_version_scn=>'37167711506897'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(48313118991710440120)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Users'
,p_static_id=>'users'
,p_list_item_link_target=>'f?p=&APP_ID.:10031:&APP_SESSION.::&DEBUG.:RP::'
,p_list_item_icon=>'fa-users'
,p_list_text_01=>'Set level of access for authenticated users of this application'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
