prompt --application/shared_components/security/authentications/email_based_authentication
begin
--   Manifest
--     AUTHENTICATION: email-based authentication
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>13699378009317950
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(10926311045734966056)
,p_name=>'email-based authentication'
,p_static_id=>'email-based-authentication'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'authentication_function', 'local_auth',
  'enable_legacy_attributes', 'N')).to_clob
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function local_auth (',
'    p_username  in  varchar2,',
'    p_password  in  varchar2 )',
'    return boolean',
'is',
'begin',
'    return eba_ema_util.token_is_valid (',
'               p_username => p_username,',
'               p_token    => p_password );',
'end local_auth;'))
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_version_scn=>'37167711508752'
);
wwv_flow_imp.component_end;
end;
/
