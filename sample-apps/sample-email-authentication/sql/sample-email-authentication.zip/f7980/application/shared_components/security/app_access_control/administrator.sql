prompt --application/shared_components/security/app_access_control/administrator
begin
--   Manifest
--     ACL ROLE: Administrator
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7980
,p_default_id_offset=>13699378009317950
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(48312975905135439640)
,p_static_id=>'ADMINISTRATOR'
,p_name=>'Administrator'
,p_description=>'Can monitor the application and add users.'
,p_version_scn=>'15506200941160'
);
wwv_flow_imp.component_end;
end;
/
