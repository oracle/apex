prompt --application/deployment/install/install_projects
begin
--   Manifest
--     INSTALL: INSTALL-projects
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7960
,p_default_id_offset=>9401511585985709
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE EBA_DEMO_FILE_PROJECTS'||wwv_flow.LF||
'   ('||wwv_flow.LF||
'    ID NUMBER, '||wwv_flow.LF||
'    row_version_number number,'||wwv_flow.LF||
'    PROJECT ';
wwv_flow_imp.g_varchar2_table(2) := '           VARCHAR2(30) not null, '||wwv_flow.LF||
'    TASK_NAME          VARCHAR2(255) not null, '||wwv_flow.LF||
'    START_DATE   ';
wwv_flow_imp.g_varchar2_table(3) := '      date not null, '||wwv_flow.LF||
'    END_DATE           date not null, '||wwv_flow.LF||
'    STATUS             VARCHAR2(30) not';
wwv_flow_imp.g_varchar2_table(4) := ' null, '||wwv_flow.LF||
'    ASSIGNED_TO        VARCHAR2(30), '||wwv_flow.LF||
'    COST               NUMBER, '||wwv_flow.LF||
'    BUDGET            ';
wwv_flow_imp.g_varchar2_table(5) := ' NUMBER, '||wwv_flow.LF||
'    created_on         timestamp,'||wwv_flow.LF||
'    created_by         varchar2(255),'||wwv_flow.LF||
'    browser_env   ';
wwv_flow_imp.g_varchar2_table(6) := '     varchar2(4000),'||wwv_flow.LF||
'    icon_name          varchar2(4000),'||wwv_flow.LF||
'    icon_comments      varchar2(4000),'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(7) := '   icon_blob          blob,'||wwv_flow.LF||
'    icon_mimetype      varchar2(512),'||wwv_flow.LF||
'    icon_charset       varchar2(51';
wwv_flow_imp.g_varchar2_table(8) := '2),'||wwv_flow.LF||
'    icon_last_updated  timestamp,'||wwv_flow.LF||
'    CONSTRAINT EBA_DEMO_FILE_PROJECTS_PK PRIMARY KEY (ID) ENAB';
wwv_flow_imp.g_varchar2_table(9) := 'LE'||wwv_flow.LF||
'   ) ;'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER  BIU_EBA_DEMO_FILE_PROJECTS'||wwv_flow.LF||
'   before insert or update on EBA_D';
wwv_flow_imp.g_varchar2_table(10) := 'EMO_FILE_PROJECTS'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is null then'||wwv_flow.LF||
'     select to_number(sys_guid(),';
wwv_flow_imp.g_varchar2_table(11) := '''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'    -- Icon Validations'||wwv_flow.LF||
'    ';
wwv_flow_imp.g_varchar2_table(12) := '-- Size (200KB limit)'||wwv_flow.LF||
'    if updating and :NEW.ICON_NAME is not null and nvl(dbms_lob.getlength(:NEW';
wwv_flow_imp.g_varchar2_table(13) := '.ICON_BLOB),0) > 204800 then'||wwv_flow.LF||
'        raise_application_error(-20000, ''The size of the uploaded icon ';
wwv_flow_imp.g_varchar2_table(14) := 'image was over 200kb. Please upload a smaller sized image.'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
'    -- Mimetype (must be i';
wwv_flow_imp.g_varchar2_table(15) := 'mage)'||wwv_flow.LF||
'    if (inserting or updating) and :NEW.ICON_NAME is not null and nvl(:NEW.ICON_MIMETYPE,''NULL';
wwv_flow_imp.g_varchar2_table(16) := ''') not like ''image%'' then'||wwv_flow.LF||
'       raise_application_error(-20000, ''The uploaded file was not an image';
wwv_flow_imp.g_varchar2_table(17) := '. Please upload an image file.'');'||wwv_flow.LF||
'    end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.row_version_number :';
wwv_flow_imp.g_varchar2_table(18) := '= 1;'||wwv_flow.LF||
'   elsif updating then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(19) := ' end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors    '||wwv_flow.LF||
'    '||wwv_flow.LF||
' '||wwv_flow.LF||
'ALTER TRIGGER BIU_EBA_DEMO_FILE_PROJECTS ENABLE'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3250590914748500457)
,p_install_id=>wwv_flow_imp.id(3201659695352375700)
,p_name=>'projects'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
