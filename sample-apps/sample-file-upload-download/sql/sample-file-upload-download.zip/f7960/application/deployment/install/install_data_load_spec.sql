prompt --application/deployment/install/install_data_load_spec
begin
--   Manifest
--     INSTALL: INSTALL-data load spec
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7960
,p_default_id_offset=>9401511585985709
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package  EBA_DEMO_FILE_DATA'||wwv_flow.LF||
'as'||wwv_flow.LF||
'procedure remove_data;'||wwv_flow.LF||
'procedure load_data;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'';
wwv_flow_imp.g_varchar2_table(2) := 'show errors';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3250597392461910396)
,p_install_id=>wwv_flow_imp.id(3201659695352375700)
,p_name=>'data load spec'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(1671767176041652158)
,p_script_id=>wwv_flow_imp.id(3250597392461910396)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_DEMO_FILE_DATA'
);
wwv_flow_imp.component_end;
end;
/
