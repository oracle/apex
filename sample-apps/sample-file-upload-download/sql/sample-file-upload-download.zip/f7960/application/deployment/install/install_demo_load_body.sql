prompt --application/deployment/install/install_demo_load_body
begin
--   Manifest
--     INSTALL: INSTALL-demo load body
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7960
,p_default_id_offset=>9401511585985709
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'create or replace package body EBA_DEMO_FILE_DATA'||wwv_flow.LF||
'as'||wwv_flow.LF||
'procedure remove_data'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'delete from EBA_';
wwv_flow_imp.g_varchar2_table(2) := 'DEMO_FILE_PROJECTS;'||wwv_flow.LF||
'end remove_data;'||wwv_flow.LF||
''||wwv_flow.LF||
'procedure load_data'||wwv_flow.LF||
'is'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  insert into eba_demo_file_proje';
wwv_flow_imp.g_varchar2_table(3) := 'cts (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''ACME Web Express';
wwv_flow_imp.g_varchar2_table(4) := ' Configuration'',''Identify server requirements'',to_date(''12/20/2015'',''MM/DD/YYYY''),to_date(''12/21/201';
wwv_flow_imp.g_varchar2_table(5) := '5'',''MM/DD/YYYY''),''Closed'',''John Watson'',''200'',''500'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,';
wwv_flow_imp.g_varchar2_table(6) := 'task_name,start_date,end_date,status,assigned_to,cost,budget) values (''ACME Web Express Configuratio';
wwv_flow_imp.g_varchar2_table(7) := 'n'',''Determine Web listener configuration(s)'',to_date(''12/22/2015'',''MM/DD/YYYY''),to_date(''12/22/2015''';
wwv_flow_imp.g_varchar2_table(8) := ',''MM/DD/YYYY''),''Closed'',''James Cassidy'',''600'',''500'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,';
wwv_flow_imp.g_varchar2_table(9) := 'task_name,start_date,end_date,status,assigned_to,cost,budget) values (''ACME Web Express Configuratio';
wwv_flow_imp.g_varchar2_table(10) := 'n'',''Run installation'',to_date(''12/25/2015'',''MM/DD/YYYY''),to_date(''12/25/2015'',''MM/DD/YYYY''),''Closed''';
wwv_flow_imp.g_varchar2_table(11) := ',''James Cassidy'',''200'',''200'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,en';
wwv_flow_imp.g_varchar2_table(12) := 'd_date,status,assigned_to,cost,budget) values (''ACME Web Express Configuration'',''Create pilot worksp';
wwv_flow_imp.g_varchar2_table(13) := 'ace'',to_date(''12/27/2015'',''MM/DD/YYYY''),to_date(''12/27/2015'',''MM/DD/YYYY''),''Closed'',''John Watson'',''1';
wwv_flow_imp.g_varchar2_table(14) := '00'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,end_date,status,assig';
wwv_flow_imp.g_varchar2_table(15) := 'ned_to,cost,budget) values (''ACME Web Express Configuration'',''Specify security authentication scheme';
wwv_flow_imp.g_varchar2_table(16) := '(s)'',to_date(''01/01/2015'',''MM/DD/YYYY''),to_date(''01/01/2015'',''MM/DD/YYYY''),''Open'',''John Watson'',''200';
wwv_flow_imp.g_varchar2_table(17) := ''',''300'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,end_date,status,assigne';
wwv_flow_imp.g_varchar2_table(18) := 'd_to,cost,budget) values (''ACME Web Express Configuration'',''Configure Workspace provisioning'',to_dat';
wwv_flow_imp.g_varchar2_table(19) := 'e(''01/02/2015'',''MM/DD/YYYY''),to_date(''01/02/2015'',''MM/DD/YYYY''),''Open'',''John Watson'',''200'',''100'');'||wwv_flow.LF||
' ';
wwv_flow_imp.g_varchar2_table(20) := ' insert into eba_demo_file_projects (project,task_name,start_date,end_date,status,assigned_to,cost,b';
wwv_flow_imp.g_varchar2_table(21) := 'udget) values (''ACME Web Express Configuration'',''Select servers for Development, Test, Production'',t';
wwv_flow_imp.g_varchar2_table(22) := 'o_date(''01/05/2015'',''MM/DD/YYYY''),to_date(''01/07/2015'',''MM/DD/YYYY''),''Open'',''James Cassidy'',''200'',''6';
wwv_flow_imp.g_varchar2_table(23) := '00'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,end_date,status,assigned_to';
wwv_flow_imp.g_varchar2_table(24) := ',cost,budget) values (''Bug Tracker'',''Document quality assurance procedures'',to_date(''11/05/2015'',''MM';
wwv_flow_imp.g_varchar2_table(25) := '/DD/YYYY''),to_date(''11/08/2015'',''MM/DD/YYYY''),''Closed'',''Myra Sutcliff'',''3000'',''2000'');'||wwv_flow.LF||
'  insert into';
wwv_flow_imp.g_varchar2_table(26) := ' eba_demo_file_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) value';
wwv_flow_imp.g_varchar2_table(27) := 's (''Bug Tracker'',''Review automated testing tools'',to_date(''11/09/2015'',''MM/DD/YYYY''),to_date(''11/11/';
wwv_flow_imp.g_varchar2_table(28) := '2015'',''MM/DD/YYYY''),''Closed'',''Myra Sutcliff'',''750'',''1500'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (pr';
wwv_flow_imp.g_varchar2_table(29) := 'oject,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Bug Tracker'',''Implement';
wwv_flow_imp.g_varchar2_table(30) := ' bug tracking software'',to_date(''11/24/2015'',''MM/DD/YYYY''),to_date(''11/24/2015'',''MM/DD/YYYY''),''Close';
wwv_flow_imp.g_varchar2_table(31) := 'd'',''Myra Sutcliff'',''100'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,';
wwv_flow_imp.g_varchar2_table(32) := 'end_date,status,assigned_to,cost,budget) values (''Bug Tracker'',''Train developers on tracking bugs'',t';
wwv_flow_imp.g_varchar2_table(33) := 'o_date(''12/01/2015'',''MM/DD/YYYY''),to_date(''12/06/2015'',''MM/DD/YYYY''),''On-Hold'',''Myra Sutcliff'',''1000';
wwv_flow_imp.g_varchar2_table(34) := ''',''2000'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,end_date,status,assign';
wwv_flow_imp.g_varchar2_table(35) := 'ed_to,cost,budget) values (''Bug Tracker'',''Measure effectiveness of improved QA'',to_date(''12/13/2015''';
wwv_flow_imp.g_varchar2_table(36) := ',''MM/DD/YYYY''),to_date(''12/13/2015'',''MM/DD/YYYY''),''Pending'',''Myra Sutcliff'',''0'',''500'');'||wwv_flow.LF||
'  insert int';
wwv_flow_imp.g_varchar2_table(37) := 'o eba_demo_file_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) valu';
wwv_flow_imp.g_varchar2_table(38) := 'es (''Convert Spreadsheets'',''Collect mission-critical spreadsheets'',to_date(''12/19/2015'',''MM/DD/YYYY''';
wwv_flow_imp.g_varchar2_table(39) := '),to_date(''12/20/2015'',''MM/DD/YYYY''),''Closed'',''Pam King'',''2500'',''4000'');'||wwv_flow.LF||
'  insert into eba_demo_file';
wwv_flow_imp.g_varchar2_table(40) := '_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Convert Sp';
wwv_flow_imp.g_varchar2_table(41) := 'readsheets'',''Lock spreadsheets'',to_date(''12/22/2015'',''MM/DD/YYYY''),to_date(''12/22/2015'',''MM/DD/YYYY''';
wwv_flow_imp.g_varchar2_table(42) := '),''Closed'',''Pam King'',''300'',''800'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_da';
wwv_flow_imp.g_varchar2_table(43) := 'te,end_date,status,assigned_to,cost,budget) values (''Convert Spreadsheets'',''Create ACME Web Express ';
wwv_flow_imp.g_varchar2_table(44) := 'applications from spreadsheets'',to_date(''12/30/2015'',''MM/DD/YYYY''),to_date(''01/03/2016'',''MM/DD/YYYY''';
wwv_flow_imp.g_varchar2_table(45) := '),''Open'',''Pam King'',''6000'',''10000'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_d';
wwv_flow_imp.g_varchar2_table(46) := 'ate,end_date,status,assigned_to,cost,budget) values (''Convert Spreadsheets'',''Send links to previous ';
wwv_flow_imp.g_varchar2_table(47) := 'spreadsheet owners'',to_date(''01/05/2016'',''MM/DD/YYYY''),to_date(''01/05/2016'',''MM/DD/YYYY''),''Pending'',';
wwv_flow_imp.g_varchar2_table(48) := '''Pam King'',''0'',''500'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,end_date,s';
wwv_flow_imp.g_varchar2_table(49) := 'tatus,assigned_to,cost,budget) values (''Discussion Forum'',''Identify owners'',to_date(''11/25/2015'',''MM';
wwv_flow_imp.g_varchar2_table(50) := '/DD/YYYY''),to_date(''11/25/2015'',''MM/DD/YYYY''),''Closed'',''Hank Davis'',''250'',''300'');'||wwv_flow.LF||
'  insert into eba_';
wwv_flow_imp.g_varchar2_table(51) := 'demo_file_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''D';
wwv_flow_imp.g_varchar2_table(52) := 'iscussion Forum'',''Install ACME Web Express application on internet server'',to_date(''12/01/2015'',''MM/';
wwv_flow_imp.g_varchar2_table(53) := 'DD/YYYY''),to_date(''12/01/2015'',''MM/DD/YYYY''),''Closed'',''Hank Davis'',''100'',''100'');'||wwv_flow.LF||
'  insert into eba_d';
wwv_flow_imp.g_varchar2_table(54) := 'emo_file_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Di';
wwv_flow_imp.g_varchar2_table(55) := 'scussion Forum'',''Monitor participation'',to_date(''12/31/2015'',''MM/DD/YYYY''),to_date(''01/01/2016'',''MM/';
wwv_flow_imp.g_varchar2_table(56) := 'DD/YYYY''),''Open'',''Hank Davis'',''450'',''500'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,';
wwv_flow_imp.g_varchar2_table(57) := 'start_date,end_date,status,assigned_to,cost,budget) values (''Email Integration'',''Complete plan'',to_d';
wwv_flow_imp.g_varchar2_table(58) := 'ate(''12/12/2015'',''MM/DD/YYYY''),to_date(''12/13/2015'',''MM/DD/YYYY''),''Closed'',''Bob Nile'',''3000'',''1500'')';
wwv_flow_imp.g_varchar2_table(59) := ';'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,end_date,status,assigned_to,cos';
wwv_flow_imp.g_varchar2_table(60) := 't,budget) values (''Email Integration'',''Check software licenses'',to_date(''12/15/2015'',''MM/DD/YYYY''),t';
wwv_flow_imp.g_varchar2_table(61) := 'o_date(''12/15/2015'',''MM/DD/YYYY''),''Closed'',''Bob Nile'',''200'',''200'');'||wwv_flow.LF||
'  insert into eba_demo_file_proj';
wwv_flow_imp.g_varchar2_table(62) := 'ects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Email Integrati';
wwv_flow_imp.g_varchar2_table(63) := 'on'',''Get RFPs for new server'',to_date(''12/29/2015'',''MM/DD/YYYY''),to_date(''12/30/2015'',''MM/DD/YYYY''),';
wwv_flow_imp.g_varchar2_table(64) := '''Closed'',''Bob Nile'',''2000'',''1000'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_da';
wwv_flow_imp.g_varchar2_table(65) := 'te,end_date,status,assigned_to,cost,budget) values (''Email Integration'',''Purchase backup server'',to_';
wwv_flow_imp.g_varchar2_table(66) := 'date(''01/15/2016'',''MM/DD/YYYY''),to_date(''01/17/2016'',''MM/DD/YYYY''),''Pending'',''Bob Nile'',''0'',''3000'');';
wwv_flow_imp.g_varchar2_table(67) := ''||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,end_date,status,assigned_to,cost';
wwv_flow_imp.g_varchar2_table(68) := ',budget) values (''Employee Satisfaction Survey'',''Complete questionnaire'',to_date(''12/05/2015'',''MM/DD';
wwv_flow_imp.g_varchar2_table(69) := '/YYYY''),to_date(''12/06/2015'',''MM/DD/YYYY''),''Closed'',''Irene Jones'',''1200'',''800'');'||wwv_flow.LF||
'  insert into eba_d';
wwv_flow_imp.g_varchar2_table(70) := 'emo_file_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Em';
wwv_flow_imp.g_varchar2_table(71) := 'ployee Satisfaction Survey'',''Review with legal'',to_date(''12/07/2015'',''MM/DD/YYYY''),to_date(''12/07/20';
wwv_flow_imp.g_varchar2_table(72) := '15'',''MM/DD/YYYY''),''On-Hold'',''Irene Jones'',''200'',''400'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (projec';
wwv_flow_imp.g_varchar2_table(73) := 't,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Employee Satisfaction Surve';
wwv_flow_imp.g_varchar2_table(74) := 'y'',''Plan rollout schedule'',to_date(''12/08/2015'',''MM/DD/YYYY''),to_date(''12/08/2015'',''MM/DD/YYYY''),''On';
wwv_flow_imp.g_varchar2_table(75) := '-Hold'',''Irene Jones'',''0'',''750'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,';
wwv_flow_imp.g_varchar2_table(76) := 'end_date,status,assigned_to,cost,budget) values (''Client Server Conversion'',''Identify pilot Client S';
wwv_flow_imp.g_varchar2_table(77) := 'erver applications'',to_date(''12/17/2015'',''MM/DD/YYYY''),to_date(''12/17/2015'',''MM/DD/YYYY''),''Closed'',''';
wwv_flow_imp.g_varchar2_table(78) := 'Scott Spencer'',''200'',''200'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,end_';
wwv_flow_imp.g_varchar2_table(79) := 'date,status,assigned_to,cost,budget) values (''Client Server Conversion'',''Migrate pilot Client Server';
wwv_flow_imp.g_varchar2_table(80) := ' to ACME Web Express'',to_date(''12/19/2015'',''MM/DD/YYYY''),to_date(''12/22/2015'',''MM/DD/YYYY''),''Closed''';
wwv_flow_imp.g_varchar2_table(81) := ',''Scott Spencer'',''4500'',''5000'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,';
wwv_flow_imp.g_varchar2_table(82) := 'end_date,status,assigned_to,cost,budget) values (''Client Server Conversion'',''Post-migration review'',';
wwv_flow_imp.g_varchar2_table(83) := 'to_date(''12/23/2015'',''MM/DD/YYYY''),to_date(''12/23/2015'',''MM/DD/YYYY''),''Closed'',''Pam King'',''500'',''300';
wwv_flow_imp.g_varchar2_table(84) := ''');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,end_date,status,assigned_to,c';
wwv_flow_imp.g_varchar2_table(85) := 'ost,budget) values (''Client Server Conversion'',''Plan migration schedule'',to_date(''12/26/2015'',''MM/DD';
wwv_flow_imp.g_varchar2_table(86) := '/YYYY''),to_date(''12/26/2015'',''MM/DD/YYYY''),''Closed'',''Pam King'',''1000'',''1000'');'||wwv_flow.LF||
'  insert into eba_dem';
wwv_flow_imp.g_varchar2_table(87) := 'o_file_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Clie';
wwv_flow_imp.g_varchar2_table(88) := 'nt Server Conversion'',''Migrate Client Server applications'',to_date(''12/31/2015'',''MM/DD/YYYY''),to_dat';
wwv_flow_imp.g_varchar2_table(89) := 'e(''01/03/2016'',''MM/DD/YYYY''),''Open'',''Pam King'',''300'',''12000'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects ';
wwv_flow_imp.g_varchar2_table(90) := '(project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Client Server Conver';
wwv_flow_imp.g_varchar2_table(91) := 'sion'',''Test migrated applications'',to_date(''01/05/2016'',''MM/DD/YYYY''),to_date(''01/06/2016'',''MM/DD/YY';
wwv_flow_imp.g_varchar2_table(92) := 'YY''),''Pending'',''Russ Saunders'',''0'',''6000'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,';
wwv_flow_imp.g_varchar2_table(93) := 'start_date,end_date,status,assigned_to,cost,budget) values (''Client Server Conversion'',''User accepta';
wwv_flow_imp.g_varchar2_table(94) := 'nce testing'',to_date(''01/09/2016'',''MM/DD/YYYY''),to_date(''01/11/2016'',''MM/DD/YYYY''),''Pending'',''Russ S';
wwv_flow_imp.g_varchar2_table(95) := 'aunders'',''0'',''2500'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,end_date,st';
wwv_flow_imp.g_varchar2_table(96) := 'atus,assigned_to,cost,budget) values (''Client Server Conversion'',''End-user Training'',to_date(''01/15/';
wwv_flow_imp.g_varchar2_table(97) := '2016'',''MM/DD/YYYY''),to_date(''01/15/2016'',''MM/DD/YYYY''),''Pending'',''Myra Sutcliff'',''0'',''2500'');'||wwv_flow.LF||
'  inse';
wwv_flow_imp.g_varchar2_table(98) := 'rt into eba_demo_file_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget';
wwv_flow_imp.g_varchar2_table(99) := ') values (''Client Server Conversion'',''Rollout migrated Client Server in ACME Web Express'',to_date(''0';
wwv_flow_imp.g_varchar2_table(100) := '1/16/2016'',''MM/DD/YYYY''),to_date(''01/16/2016'',''MM/DD/YYYY''),''Pending'',''Pam King'',''0'',''200'');'||wwv_flow.LF||
'  inser';
wwv_flow_imp.g_varchar2_table(101) := 't into eba_demo_file_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget)';
wwv_flow_imp.g_varchar2_table(102) := ' values (''Load Packaged Apps'',''Identify point solutions required'',to_date(''12/19/2015'',''MM/DD/YYYY'')';
wwv_flow_imp.g_varchar2_table(103) := ',to_date(''12/19/2015'',''MM/DD/YYYY''),''Closed'',''John Watson'',''200'',''300'');'||wwv_flow.LF||
'  insert into eba_demo_file';
wwv_flow_imp.g_varchar2_table(104) := '_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Load Packa';
wwv_flow_imp.g_varchar2_table(105) := 'ged Apps'',''Install in development'',to_date(''12/20/2015'',''MM/DD/YYYY''),to_date(''12/20/2015'',''MM/DD/YY';
wwv_flow_imp.g_varchar2_table(106) := 'YY''),''Closed'',''John Watson'',''100'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,st';
wwv_flow_imp.g_varchar2_table(107) := 'art_date,end_date,status,assigned_to,cost,budget) values (''Load Packaged Apps'',''Customize solutions''';
wwv_flow_imp.g_varchar2_table(108) := ',to_date(''12/23/2015'',''MM/DD/YYYY''),to_date(''12/25/2015'',''MM/DD/YYYY''),''Open'',''John Watson'',''1500'',''';
wwv_flow_imp.g_varchar2_table(109) := '4000'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,end_date,status,assigned_';
wwv_flow_imp.g_varchar2_table(110) := 'to,cost,budget) values (''Load Packaged Apps'',''Implement in Production'',to_date(''12/26/2015'',''MM/DD/Y';
wwv_flow_imp.g_varchar2_table(111) := 'YYY''),to_date(''12/26/2015'',''MM/DD/YYYY''),''On-Hold'',''John Watson'',''200'',''1500'');'||wwv_flow.LF||
'  insert into eba_de';
wwv_flow_imp.g_varchar2_table(112) := 'mo_file_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Loa';
wwv_flow_imp.g_varchar2_table(113) := 'd Packaged Apps'',''Train Administrators of Packaged Apps'',to_date(''12/28/2015'',''MM/DD/YYYY''),to_date(';
wwv_flow_imp.g_varchar2_table(114) := '''12/28/2015'',''MM/DD/YYYY''),''Pending'',''John Watson'',''0'',''1000'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects';
wwv_flow_imp.g_varchar2_table(115) := ' (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Maintain Support Sy';
wwv_flow_imp.g_varchar2_table(116) := 'stems'',''HR software upgrades'',to_date(''11/28/2015'',''MM/DD/YYYY''),to_date(''12/01/2015'',''MM/DD/YYYY''),';
wwv_flow_imp.g_varchar2_table(117) := '''Closed'',''Pam King'',''8000'',''7000'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_da';
wwv_flow_imp.g_varchar2_table(118) := 'te,end_date,status,assigned_to,cost,budget) values (''Maintain Support Systems'',''Apply Billing System';
wwv_flow_imp.g_varchar2_table(119) := ' updates'',to_date(''12/02/2015'',''MM/DD/YYYY''),to_date(''12/04/2015'',''MM/DD/YYYY''),''Closed'',''Russ Saund';
wwv_flow_imp.g_varchar2_table(120) := 'ers'',''9500'',''7000'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,end_date,sta';
wwv_flow_imp.g_varchar2_table(121) := 'tus,assigned_to,cost,budget) values (''Maintain Support Systems'',''Arrange for vacation coverage'',to_d';
wwv_flow_imp.g_varchar2_table(122) := 'ate(''12/06/2015'',''MM/DD/YYYY''),to_date(''12/06/2015'',''MM/DD/YYYY''),''Open'',''Al Bines'',''300'',''500'');'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(123) := 'insert into eba_demo_file_projects (project,task_name,start_date,end_date,status,assigned_to,cost,bu';
wwv_flow_imp.g_varchar2_table(124) := 'dget) values (''Maintain Support Systems'',''Investigate new Virus Protection software'',to_date(''01/15/';
wwv_flow_imp.g_varchar2_table(125) := '2016'',''MM/DD/YYYY''),to_date(''01/16/2016'',''MM/DD/YYYY''),''Open'',''Pam King'',''1700'',''1500'');'||wwv_flow.LF||
'  insert in';
wwv_flow_imp.g_varchar2_table(126) := 'to eba_demo_file_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) val';
wwv_flow_imp.g_varchar2_table(127) := 'ues (''Migrate Desktop Application'',''Identify pilot desktop applications'',to_date(''12/10/2015'',''MM/DD';
wwv_flow_imp.g_varchar2_table(128) := '/YYYY''),to_date(''12/10/2015'',''MM/DD/YYYY''),''Closed'',''Bob Nile'',''300'',''500'');'||wwv_flow.LF||
'  insert into eba_demo_';
wwv_flow_imp.g_varchar2_table(129) := 'file_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Migrat';
wwv_flow_imp.g_varchar2_table(130) := 'e Desktop Application'',''Migrate pilot applications to ACME Web Express'',to_date(''12/12/2015'',''MM/DD/';
wwv_flow_imp.g_varchar2_table(131) := 'YYYY''),to_date(''12/13/2015'',''MM/DD/YYYY''),''Closed'',''Bob Nile'',''1250'',''1500'');'||wwv_flow.LF||
'  insert into eba_demo';
wwv_flow_imp.g_varchar2_table(132) := '_file_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Migra';
wwv_flow_imp.g_varchar2_table(133) := 'te Desktop Application'',''Plan migration schedule'',to_date(''12/16/2015'',''MM/DD/YYYY''),to_date(''12/16/';
wwv_flow_imp.g_varchar2_table(134) := '2015'',''MM/DD/YYYY''),''Closed'',''Bob Nile'',''600'',''200'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,';
wwv_flow_imp.g_varchar2_table(135) := 'task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Migrate Desktop Application'',';
wwv_flow_imp.g_varchar2_table(136) := '''Migrate desktop applications'',to_date(''01/08/2016'',''MM/DD/YYYY''),to_date(''01/12/2016'',''MM/DD/YYYY'')';
wwv_flow_imp.g_varchar2_table(137) := ',''Open'',''Bob Nile'',''1000'',''8000'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_dat';
wwv_flow_imp.g_varchar2_table(138) := 'e,end_date,status,assigned_to,cost,budget) values (''Migrate Desktop Application'',''User acceptance te';
wwv_flow_imp.g_varchar2_table(139) := 'sting'',to_date(''01/14/2016'',''MM/DD/YYYY''),to_date(''01/15/2016'',''MM/DD/YYYY''),''Open'',''Bob Nile'',''1500';
wwv_flow_imp.g_varchar2_table(140) := ''',''6000'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,end_date,status,assign';
wwv_flow_imp.g_varchar2_table(141) := 'ed_to,cost,budget) values (''Migrate Desktop Application'',''End-user Training'',to_date(''01/18/2016'',''M';
wwv_flow_imp.g_varchar2_table(142) := 'M/DD/YYYY''),to_date(''01/19/2016'',''MM/DD/YYYY''),''Open'',''John Watson'',''0'',''2000'');'||wwv_flow.LF||
'  insert into eba_d';
wwv_flow_imp.g_varchar2_table(143) := 'emo_file_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Mi';
wwv_flow_imp.g_varchar2_table(144) := 'grate Desktop Application'',''Post-migration review'',to_date(''02/01/2016'',''MM/DD/YYYY''),to_date(''02/02';
wwv_flow_imp.g_varchar2_table(145) := '/2016'',''MM/DD/YYYY''),''Pending'',''Bob Nile'',''100'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (projec';
wwv_flow_imp.g_varchar2_table(146) := 't,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Migrate from Legacy Server''';
wwv_flow_imp.g_varchar2_table(147) := ',''Obtain Legacy Server credentials'',to_date(''01/20/2016'',''MM/DD/YYYY''),to_date(''01/20/2016'',''MM/DD/Y';
wwv_flow_imp.g_varchar2_table(148) := 'YYY''),''Pending'',''James Cassidy'',''0'',''500'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,';
wwv_flow_imp.g_varchar2_table(149) := 'start_date,end_date,status,assigned_to,cost,budget) values (''Migrate from Legacy Server'',''Map data u';
wwv_flow_imp.g_varchar2_table(150) := 'sage'',to_date(''01/22/2016'',''MM/DD/YYYY''),to_date(''01/24/2016'',''MM/DD/YYYY''),''Pending'',''Bob Nile'',''0''';
wwv_flow_imp.g_varchar2_table(151) := ',''8000'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,end_date,status,assigne';
wwv_flow_imp.g_varchar2_table(152) := 'd_to,cost,budget) values (''Migrate from Legacy Server'',''Identify integration points'',to_date(''01/25/';
wwv_flow_imp.g_varchar2_table(153) := '2016'',''MM/DD/YYYY''),to_date(''01/26/2016'',''MM/DD/YYYY''),''Pending'',''Bob Nile'',''0'',''2000'');'||wwv_flow.LF||
'  insert in';
wwv_flow_imp.g_varchar2_table(154) := 'to eba_demo_file_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) val';
wwv_flow_imp.g_varchar2_table(155) := 'ues (''Migrate from Legacy Server'',''Create DB Connection to new server'',to_date(''01/25/2016'',''MM/DD/Y';
wwv_flow_imp.g_varchar2_table(156) := 'YYY''),to_date(''01/25/2016'',''MM/DD/YYYY''),''Pending'',''Scott Spencer'',''0'',''100'');'||wwv_flow.LF||
'  insert into eba_dem';
wwv_flow_imp.g_varchar2_table(157) := 'o_file_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Migr';
wwv_flow_imp.g_varchar2_table(158) := 'ate from Legacy Server'',''Migrate table structures'',to_date(''01/19/2016'',''MM/DD/YYYY''),to_date(''01/20';
wwv_flow_imp.g_varchar2_table(159) := '/2016'',''MM/DD/YYYY''),''Pending'',''John Watson'',''0'',''2500'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (proj';
wwv_flow_imp.g_varchar2_table(160) := 'ect,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Migrate from Legacy Serve';
wwv_flow_imp.g_varchar2_table(161) := 'r'',''Import data'',to_date(''01/31/2016'',''MM/DD/YYYY''),to_date(''02/01/2016'',''MM/DD/YYYY''),''Pending'',''Jo';
wwv_flow_imp.g_varchar2_table(162) := 'hn Watson'',''0'',''1000'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,end_date,';
wwv_flow_imp.g_varchar2_table(163) := 'status,assigned_to,cost,budget) values (''Migrate from Legacy Server'',''Convert processes'',to_date(''01';
wwv_flow_imp.g_varchar2_table(164) := '/31/2016'',''MM/DD/YYYY''),to_date(''02/02/2016'',''MM/DD/YYYY''),''Pending'',''Pam King'',''0'',''3000'');'||wwv_flow.LF||
'  inser';
wwv_flow_imp.g_varchar2_table(165) := 't into eba_demo_file_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget)';
wwv_flow_imp.g_varchar2_table(166) := ' values (''Migrate from Legacy Server'',''Notify users'',to_date(''02/05/2016'',''MM/DD/YYYY''),to_date(''02/';
wwv_flow_imp.g_varchar2_table(167) := '05/2016'',''MM/DD/YYYY''),''Pending'',''Bob Nile'',''0'',''200'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (projec';
wwv_flow_imp.g_varchar2_table(168) := 't,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Migrate from Legacy Server''';
wwv_flow_imp.g_varchar2_table(169) := ',''Cut over to new database'',to_date(''02/06/2016'',''MM/DD/YYYY''),to_date(''02/06/2016'',''MM/DD/YYYY''),''P';
wwv_flow_imp.g_varchar2_table(170) := 'ending'',''Bob Nile'',''0'',''1500'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,e';
wwv_flow_imp.g_varchar2_table(171) := 'nd_date,status,assigned_to,cost,budget) values (''Migrate from Legacy Server'',''Decommission Legacy Se';
wwv_flow_imp.g_varchar2_table(172) := 'rver'',to_date(''02/20/2016'',''MM/DD/YYYY''),to_date(''02/20/2016'',''MM/DD/YYYY''),''Pending'',''Al Bines'',''0''';
wwv_flow_imp.g_varchar2_table(173) := ',''500'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,end_date,status,assigned';
wwv_flow_imp.g_varchar2_table(174) := '_to,cost,budget) values (''Public Website'',''Determine host server'',to_date(''12/05/2015'',''MM/DD/YYYY'')';
wwv_flow_imp.g_varchar2_table(175) := ',to_date(''12/05/2015'',''MM/DD/YYYY''),''Closed'',''Tiger Scott'',''200'',''200'');'||wwv_flow.LF||
'  insert into eba_demo_file';
wwv_flow_imp.g_varchar2_table(176) := '_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Public Web';
wwv_flow_imp.g_varchar2_table(177) := 'site'',''Check software licenses'',to_date(''12/05/2015'',''MM/DD/YYYY''),to_date(''12/05/2015'',''MM/DD/YYYY''';
wwv_flow_imp.g_varchar2_table(178) := '),''Closed'',''Tom Suess'',''100'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_d';
wwv_flow_imp.g_varchar2_table(179) := 'ate,end_date,status,assigned_to,cost,budget) values (''Public Website'',''Purchase additional software ';
wwv_flow_imp.g_varchar2_table(180) := 'licenses, if needed'',to_date(''12/06/2015'',''MM/DD/YYYY''),to_date(''12/07/2015'',''MM/DD/YYYY''),''On-Hold''';
wwv_flow_imp.g_varchar2_table(181) := ',''Al Bines'',''300'',''1000'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,end_da';
wwv_flow_imp.g_varchar2_table(182) := 'te,status,assigned_to,cost,budget) values (''Public Website'',''Develop web pages'',to_date(''01/01/2016''';
wwv_flow_imp.g_varchar2_table(183) := ',''MM/DD/YYYY''),to_date(''01/02/2016'',''MM/DD/YYYY''),''Open'',''Tiger Scott'',''0'',''2000'');'||wwv_flow.LF||
'  insert into eb';
wwv_flow_imp.g_varchar2_table(184) := 'a_demo_file_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (';
wwv_flow_imp.g_varchar2_table(185) := '''Public Website'',''Plan rollout schedule'',to_date(''01/03/2016'',''MM/DD/YYYY''),to_date(''01/03/2016'',''MM';
wwv_flow_imp.g_varchar2_table(186) := '/DD/YYYY''),''Open'',''Tom Suess'',''0'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,st';
wwv_flow_imp.g_varchar2_table(187) := 'art_date,end_date,status,assigned_to,cost,budget) values (''Software Project Tracking'',''Conduct proje';
wwv_flow_imp.g_varchar2_table(188) := 'ct kickoff meeting'',to_date(''12/28/2015'',''MM/DD/YYYY''),to_date(''12/28/2015'',''MM/DD/YYYY''),''Closed'',''';
wwv_flow_imp.g_varchar2_table(189) := 'Pam King'',''100'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,end_date,';
wwv_flow_imp.g_varchar2_table(190) := 'status,assigned_to,cost,budget) values (''Software Project Tracking'',''Customize Software Projects sof';
wwv_flow_imp.g_varchar2_table(191) := 'tware'',to_date(''12/31/2015'',''MM/DD/YYYY''),to_date(''01/01/2016'',''MM/DD/YYYY''),''Open'',''Tom Suess'',''600';
wwv_flow_imp.g_varchar2_table(192) := ''',''1000'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,end_date,status,assign';
wwv_flow_imp.g_varchar2_table(193) := 'ed_to,cost,budget) values (''Software Project Tracking'',''Enter base data (Projects, Milestones, etc.)';
wwv_flow_imp.g_varchar2_table(194) := ''',to_date(''01/02/2016'',''MM/DD/YYYY''),to_date(''01/02/2016'',''MM/DD/YYYY''),''Open'',''Tom Suess'',''200'',''20';
wwv_flow_imp.g_varchar2_table(195) := '0'');'||wwv_flow.LF||
'  insert into eba_demo_file_projects (project,task_name,start_date,end_date,status,assigned_to,';
wwv_flow_imp.g_varchar2_table(196) := 'cost,budget) values (''Software Project Tracking'',''Load current tasks and enhancements'',to_date(''01/0';
wwv_flow_imp.g_varchar2_table(197) := '4/2016'',''MM/DD/YYYY''),to_date(''01/04/2016'',''MM/DD/YYYY''),''Open'',''Tom Suess'',''400'',''500'');'||wwv_flow.LF||
'  insert i';
wwv_flow_imp.g_varchar2_table(198) := 'nto eba_demo_file_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) va';
wwv_flow_imp.g_varchar2_table(199) := 'lues (''Training for ACME Web Express'',''Create training workspace'',to_date(''12/17/2015'',''MM/DD/YYYY'')';
wwv_flow_imp.g_varchar2_table(200) := ',to_date(''12/18/2015'',''MM/DD/YYYY''),''Closed'',''James Cassidy'',''500'',''700'');'||wwv_flow.LF||
'  insert into eba_demo_fi';
wwv_flow_imp.g_varchar2_table(201) := 'le_projects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Training';
wwv_flow_imp.g_varchar2_table(202) := ' for ACME Web Express'',''Publish links to self-study courses'',to_date(''12/19/2015'',''MM/DD/YYYY''),to_d';
wwv_flow_imp.g_varchar2_table(203) := 'ate(''12/19/2015'',''MM/DD/YYYY''),''Closed'',''John Watson'',''100'',''100'');'||wwv_flow.LF||
'  insert into eba_demo_file_proj';
wwv_flow_imp.g_varchar2_table(204) := 'ects (project,task_name,start_date,end_date,status,assigned_to,cost,budget) values (''Training for AC';
wwv_flow_imp.g_varchar2_table(205) := 'ME Web Express'',''Publish development standards'',to_date(''12/19/2015'',''MM/DD/YYYY''),to_date(''12/20/20';
wwv_flow_imp.g_varchar2_table(206) := '15'',''MM/DD/YYYY''),''On-Hold'',''John Watson'',''1000'',''2000'');'||wwv_flow.LF||
''||wwv_flow.LF||
'update EBA_DEMO_FILE_projects'||wwv_flow.LF||
'set start_d';
wwv_flow_imp.g_varchar2_table(207) := 'ate = start_date + (SYSDATE - TO_DATE(''01012016'',''MMDDYYYY''))'||wwv_flow.LF||
',   end_date = end_date + (SYSDATE - T';
wwv_flow_imp.g_varchar2_table(208) := 'O_DATE(''01012016'',''MMDDYYYY''));'||wwv_flow.LF||
'end load_data;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'show errors'||wwv_flow.LF||
''||wwv_flow.LF||
'begin'||wwv_flow.LF||
'  EBA_DEMO_FILE_DATA.load_d';
wwv_flow_imp.g_varchar2_table(209) := 'ata;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
''||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3250597993631920116)
,p_install_id=>wwv_flow_imp.id(3201659695352375700)
,p_name=>'demo load body'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
