prompt --application/deployment/install/install_files
begin
--   Manifest
--     INSTALL: INSTALL-files
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7960
,p_default_id_offset=>9401511585985709
,p_default_owner=>'ORACLE'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := 'CREATE TABLE EBA_DEMO_FILES '||wwv_flow.LF||
'   (   '||wwv_flow.LF||
'    -- primary key and row number for lost update detection'||wwv_flow.LF||
'   ';
wwv_flow_imp.g_varchar2_table(2) := ' ID                   NUMBER constraint EBA_DEMO_FILES_PK primary key, '||wwv_flow.LF||
'    ROW_VERSION_NUMBER   NUM';
wwv_flow_imp.g_varchar2_table(3) := 'BER, '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- foreign key'||wwv_flow.LF||
'    PROJECT_ID           NUMBER constraint eba_demo_files_fk'||wwv_flow.LF||
'       ';
wwv_flow_imp.g_varchar2_table(4) := '                  references EBA_DEMO_FILE_PROJECTS (id)'||wwv_flow.LF||
'                         on delete cascade,';
wwv_flow_imp.g_varchar2_table(5) := ' '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- standard columns'||wwv_flow.LF||
'    FILENAME             VARCHAR2(4000 BYTE), '||wwv_flow.LF||
'    FILE_MIMETYPE   ';
wwv_flow_imp.g_varchar2_table(6) := '     VARCHAR2(512 BYTE), '||wwv_flow.LF||
'    FILE_CHARSET         VARCHAR2(512 BYTE), '||wwv_flow.LF||
'    FILE_BLOB            BLO';
wwv_flow_imp.g_varchar2_table(7) := 'B, '||wwv_flow.LF||
'    --'||wwv_flow.LF||
'    -- optional columns'||wwv_flow.LF||
'    FILE_COMMENTS        VARCHAR2(4000 BYTE), '||wwv_flow.LF||
'    TAGS          ';
wwv_flow_imp.g_varchar2_table(8) := '       VARCHAR2(4000 BYTE), '||wwv_flow.LF||
'    CREATED              timestamp, '||wwv_flow.LF||
'    CREATED_BY           VARCHAR2(';
wwv_flow_imp.g_varchar2_table(9) := '255 BYTE), '||wwv_flow.LF||
'    UPDATED              timestamp, '||wwv_flow.LF||
'    UPDATED_BY           VARCHAR2(255 BYTE)'||wwv_flow.LF||
'   )  ;';
wwv_flow_imp.g_varchar2_table(10) := ''||wwv_flow.LF||
''||wwv_flow.LF||
'create index EBA_DEMO_FILES_i2 on EBA_DEMO_FILES(project_id);'||wwv_flow.LF||
''||wwv_flow.LF||
'CREATE OR REPLACE TRIGGER BIU_EBA_D';
wwv_flow_imp.g_varchar2_table(11) := 'EMO_FILES '||wwv_flow.LF||
'   before insert or update on EBA_DEMO_FILES'||wwv_flow.LF||
'   for each row'||wwv_flow.LF||
'begin'||wwv_flow.LF||
'   if :new.ID is null ';
wwv_flow_imp.g_varchar2_table(12) := 'then'||wwv_flow.LF||
'     select to_number(sys_guid(),''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') into :new.id from dual;'||wwv_flow.LF||
'  ';
wwv_flow_imp.g_varchar2_table(13) := ' end if;'||wwv_flow.LF||
''||wwv_flow.LF||
'   if inserting then'||wwv_flow.LF||
'       :new.created := localtimestamp;'||wwv_flow.LF||
'       :new.created_by := nvl(';
wwv_flow_imp.g_varchar2_table(14) := 'wwv_flow.g_user,user);'||wwv_flow.LF||
'       :new.updated := localtimestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow';
wwv_flow_imp.g_varchar2_table(15) := '.g_user,user);'||wwv_flow.LF||
'       :new.row_version_number := 1;'||wwv_flow.LF||
'   elsif updating and :new.filename is not null ';
wwv_flow_imp.g_varchar2_table(16) := 'and nvl(dbms_lob.getlength(:new.file_blob),0) > 15728640 then'||wwv_flow.LF||
'       raise_application_error(-20000,';
wwv_flow_imp.g_varchar2_table(17) := ' ''The size of the uploaded file was over 15MB. Please upload a smaller sized file.'');'||wwv_flow.LF||
'   elsif updat';
wwv_flow_imp.g_varchar2_table(18) := 'ing then'||wwv_flow.LF||
'       :new.row_version_number := nvl(:old.row_version_number,1) + 1;'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'   if inse';
wwv_flow_imp.g_varchar2_table(19) := 'rting or updating then'||wwv_flow.LF||
'       :new.updated := localtimestamp;'||wwv_flow.LF||
'       :new.updated_by := nvl(wwv_flow';
wwv_flow_imp.g_varchar2_table(20) := '.g_user,user);'||wwv_flow.LF||
'   end if;'||wwv_flow.LF||
'end;'||wwv_flow.LF||
'/'||wwv_flow.LF||
'ALTER TRIGGER BIU_EBA_DEMO_FILES ENABLE;'||wwv_flow.LF||
''||wwv_flow.LF||
'';
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3250591297694514422)
,p_install_id=>wwv_flow_imp.id(3201659695352375700)
,p_name=>'files'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_imp.varchar2_to_clob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
