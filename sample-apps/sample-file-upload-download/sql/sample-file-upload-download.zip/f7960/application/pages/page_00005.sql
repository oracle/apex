prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7960
,p_default_id_offset=>9401511585985709
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'SQL Syntax'
,p_alias=>'SQL-SYNTAX'
,p_step_title=>'SQL Syntax'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'U'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1327972398549367034)
,p_plug_name=>'About this page'
,p_static_id=>'about-this-page'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>This page shows the recommended SQL syntax to build file upload and download into your Oracle Application Express (APEX) application.  You need more than just a <strong>BLOB</strong> column as the browser will need to know the filename, mime type '
||'and character sets when downloading files.</p>',
'<p>Recommended column details</p>',
'<ul>',
'<li><strong>FILENAME</strong>: ICON_NAME in the example below.  Tracks the actual filename so that downloads of the file are given an appropriate name.  Without this attribute a download link would not know what filename to download a file as.</li>',
'<li><strong>BLOB</strong>: ICON_BLOB in the example below.  The Binary Large Object (BLOB) database column used to store uploaded files into database tables.  The Oracle BLOB datatype is virtually unlimited in size.</li>',
'<li><strong>MIMETYPE</strong>: ICON_MIMETYPE in the example below.  The mimetype is used by the bowser to identify which application should be used to display the content of a downloaded BLOB data.  The BLOB datatype does not maintain this informatio'
||'n so it is important to manage this data in its own column.</li>',
'<li><strong>CHARACTER SET</strong>: ICON_CHARSET in the example below.  Identifies the character set used to download the file.  The character set of a BLOB column is not automatically tracked so it will need to be maintained in a separate column.</l'
||'i>',
'<li><strong>LAST_UPDATED</strong>: ICON_LAST_UPDATED in the example below.  Tracks the timestamp of when the file was last updated and can be used for browser caching.  It is not required but can dramatically improve performance of some applications.'
||'</li>',
'',
'</ul>',
'<p>Reference Oracle Application Express documentation for additional information.</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1328031913842475596)
,p_plug_name=>'About this page2'
,p_static_id=>'about-this-page-2'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>'<p>The <strong>sys.dbms_lob.getlength</strong> function is a high performance database package used to get the length of a BLOB column.</p>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1327933804039351856)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(14803839704771485623)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1328017389376402309)
,p_plug_name=>'Example SQL Queries used in this application'
,p_static_id=>'example-sql-queries-used-in-this-application'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>',
'select',
'    ID,',
'    ROW_VERSION_NUMBER,',
'    PROJECT_ID,',
'    FILENAME,',
'    FILE_MIMETYPE,',
'    FILE_CHARSET,',
'    FILE_BLOB,',
'    FILE_COMMENTS,',
'    TAGS,',
'    CREATED,',
'    CREATED_BY,',
'    UPDATED,',
'    UPDATED_BY,',
'    sys.dbms_lob.getlength(file_blob) file_size,',
'    sys.dbms_lob.getlength(file_blob) download',
'from EBA_DEMO_FILES',
'',
'</pre>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1327952892877355968)
,p_plug_name=>'SQL create table syntax used in this sample application'
,p_static_id=>'sql-create-table-syntax-used-in-this-sample-application'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<pre>',
'CREATE TABLE EBA_DEMO_FILE_PROJECTS',
'   (',
'    ID                 NUMBER, ',
'    row_version_number NUMBER,',
'    project            VARCHAR2(30) not null, ',
'    task_name          VARCHAR2(255) not null, ',
'    start_date         DATE not null, ',
'    end_date           DATE not null, ',
'    status             VARCHAR2(30) not null, ',
'    assigned_to        VARCHAR2(30), ',
'    cost               NUMBER, ',
'    budget             NUMBER, ',
'    created_on         TIMESTAMP,',
'    created_by         VARCHAR2(255),',
'    browser_env        VARCHAR2(4000),',
'    <strong>icon_name          VARCHAR2(4000)</strong>,',
'    <strong>icon_blob          BLOB</strong>,',
'    <strong>icon_mimetype      VARCHAR2(512)</strong>,',
'    <strong>icon_charset       VARCHAR2(512)</strong>,',
'    <strong>icon_last_updated  TIMESTAMP</strong>,',
'    icon_comments      VARCHAR2(4000),',
'    CONSTRAINT EBA_DEMO_FILE_PROJECTS_PK PRIMARY KEY (ID) ENABLE',
'   ) ;',
'',
'</pre>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
