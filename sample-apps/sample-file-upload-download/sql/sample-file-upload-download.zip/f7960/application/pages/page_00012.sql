prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7960
,p_default_id_offset=>9401511585985709
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>12
,p_name=>'File'
,p_alias=>'FILE'
,p_step_title=>'File'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_step_template=>4073832297226169690
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3251034402743212865)
,p_plug_name=>'Application features demonstrated on this page'
,p_static_id=>'application-features-demonstrated-on-this-page'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4502917002193490937
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span style="infoTextRegion">',
'<p>',
'This page shows how to:',
'<ol style="margin: 8px 24px;">',
'  <li>Upload a file to an application table''s BLOB column</li>',
'  <li>Download from a PL/SQL Generated Link</li>',
'</ol>',
'<a name="upload_file"></a><br />',
'<p><strong>Upload a file to an application table''s BLOB column</strong></p>',
'<ul style="margin: 8px 24px;">',
'  <li>Add an unconditional page rendering page process</li>',
'  <li>Choose "Data Manipulation" and click "Next"</li>',
'  <li>Select the default, "Automated Row Fetch", then click "Next"</li>',
'  <li>Give the process a name, "Fetch Row from EBA_DEMO_FILES" (for example), change the processing point to "On load - After Header" and click "Next"</li>',
'  <li>Enter the table name of the application''s "files" table, the APEX page item id of the page item that references the file being uploaded, and the column name of the blob column in the afore assigned application "files" table and click "Next"</li'
||'>',
'  <li>Optionally add a success and/or error message, click "Create Process"</li>',
'  <li>Create an "HTML" region (for holding your file upload form element)</li>',
'  <li>Create a hidden page item that will hold the primary key id value of the row that holds the file (e.g, P12_ID)<span style="font-weight:bold;font-size:13px;color:red;">*</span></li>',
'  <li>Now create a "File Browse" page item in the same region as the above page items, ensure the "Storage Type" value is set to "BLOB column specified in Item Source attribute"</li>',
'  <li>Define the application tables'' column names for holding, MIME Type, Filename, Character Set, and BLOB Last Updated, and then click, "Next"</li>',
'  <li>Then click, "Create Item"<span style="font-weight:bold;font-size:13px;color:red;">*</span></li>',
'  <li>Create the other hidden page items that will store the filename, mimetype, and character set meta data<span style="font-weight:bold;font-size:13px;color:red;">*</span></li>',
'  <li>If your application''s files table has a description (or comments) column, add a textarea page item for capturing this information<span style="font-weight:bold;font-size:13px;color:red;">*</span></li>',
'  <li>Now create an unconditional page processing process</li>',
'  <li>Choose "Data Manipulation" and click "Next"</li>',
'  <li>Give the process a name, "Process Row from EBA_DEMO_FILES" (for example), change the processing point to "On Submit - After Computations and Validations" and click "Next"</li>',
'  <li>Enter the table name of the application''s "files" table, the APEX page item id of the page item that references the file being uploaded, and the column name of the blob column in the application''s "files" table and then click "Create Item"</li>',
'  <li>Create the Cancel, Delete, Apply Changes, and Create buttons (see implementation of buttons on this page)</li>',
'  <li>Now create a conditional page processing process</li>',
'  <li>Choose "Session State" and click "Next"</li>',
'  <li>Select "Clear Cache for all Items on Pages (PageID,PageID,PageID)" and click "Next"</li>',
'  <li>Give it a name of "reset page", leave the other defaulted values, click "Next"</li>',
'  <li>Enter the current page id and then click "Next"</li>',
'  <li>Optionally add Success and/or Error Messages and then click "Next"</li>',
'  <li>Change the "When Button Pressed" condition to use the "Delete" button, leave all other options set to their default values and click "Create Process"</li>',
'</ul>',
'<span style="font-weight:bold;font-size:13px;color:red;">*</span> Be sure to set the identified page item''s "Source Type" as "Database Column" and assign their "Source value or expression" as the corresponding column name in the application''s "files"'
||' table.',
'<br /><a name="download_link"></a><br />',
'<p><strong>Download from a PL/SQL Generated Link</strong></p>',
'<ul style="margin: 8px 24px;">',
'  <li>If you are editing an existing file, you will see a link to download the file you are editing. This is generated from P12_DOWNLOAD_LINK (Display-Only) page item.</li>',
'  <li>This item uses PL/SQL and the apex_util.get_blob_file_src() function to generate the link for the end-user to download the file</li>',
'</ul>',
'</p>',
'</span>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3250643092910232253)
,p_plug_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2532939663579242476
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(14803839704771485623)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4073839682315169711
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3250639020376232214)
,p_plug_name=>'File'
,p_static_id=>'file'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:t-Region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>4073835273271169698
,p_plug_display_sequence=>10
,p_plug_item_display_point=>'ABOVE'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3250639598699232216)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3250643092910232253)
,p_button_name=>'CANCEL'
,p_static_id=>'cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3250639212923232216)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(3250643092910232253)
,p_button_name=>'CREATE'
,p_static_id=>'create'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add File'
,p_button_position=>'CREATE'
,p_button_condition=>'P12_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3250639409361232216)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(3250643092910232253)
,p_button_name=>'DELETE'
,p_static_id=>'delete'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--simple:t-Button--danger'
,p_button_template_id=>4073839297780169708
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P12_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3250639317106232216)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(3250643092910232253)
,p_button_name=>'SAVE'
,p_static_id=>'save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4073839297780169708
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CHANGE'
,p_button_condition=>'P12_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(3250640201989232218)
,p_branch_action=>'f?p=&APP_ID.:3:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3251007216080904488)
,p_name=>'P12_DOWNLOAD_LINK'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(3250639020376232214)
,p_prompt=>'Download'
,p_source_type=>'ALWAYS_NULL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P12_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'PLSQL',
  'format', 'PLAIN',
  'pl_sql_code', wwv_flow_string.join(wwv_flow_t_varchar2(
    'begin',
    '  sys.htp.p(''<a href="'' || apex_util.get_blob_file_src(''P12_FILE_BLOB'',:P12_ID,:P12_PROJECT_ID) || ''">''||apex_escape.html(:P12_FILENAME)||''</a>'');',
    'end;')),
  'send_on_page_submit', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3250640814078232242)
,p_name=>'P12_FILENAME'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(3250639020376232214)
,p_use_cache_before_default=>'NO'
,p_source=>'FILENAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3250641415590232246)
,p_name=>'P12_FILE_BLOB'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(3250639020376232214)
,p_use_cache_before_default=>'NO'
,p_prompt=>'File Blob'
,p_post_element_text=>'<p><em>Files must be under 15M in size.</em></p>'
,p_source=>'FILE_BLOB'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>64
,p_cMaxlength=>255
,p_display_when=>'P12_ID'
,p_display_when_type=>'ITEM_IS_NULL'
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_copy_paste', 'N',
  'blob_last_updated_column', 'UPDATED',
  'character_set_column', 'FILE_CHARSET',
  'content_disposition', 'attachment',
  'display_as', 'INLINE',
  'display_download_link', 'Y',
  'download_link_text', 'Download',
  'filename_column', 'FILENAME',
  'mime_type_column', 'FILE_MIMETYPE',
  'storage_type', 'DB_COLUMN')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3250641199225232242)
,p_name=>'P12_FILE_CHARSET'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(3250639020376232214)
,p_use_cache_before_default=>'NO'
,p_source=>'FILE_CHARSET'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3250641611520232246)
,p_name=>'P12_FILE_COMMENTS'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(3250639020376232214)
,p_use_cache_before_default=>'NO'
,p_prompt=>'File Comments'
,p_source=>'FILE_COMMENTS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>64
,p_cMaxlength=>4000
,p_field_template=>2320077351817916916
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3250640994181232242)
,p_name=>'P12_FILE_MIMETYPE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(3250639020376232214)
,p_use_cache_before_default=>'NO'
,p_source=>'FILE_MIMETYPE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3250640404202232223)
,p_name=>'P12_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(3250639020376232214)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3250640597756232240)
,p_name=>'P12_PROJECT_ID'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(3250639020376232214)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Project'
,p_source=>'PROJECT_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select project||'' ''||task_name d, id from eba_demo_file_projects order by 1'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Select Project -'
,p_cHeight=>1
,p_field_template=>2528236951996823187
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(3250999211307808529)
,p_validation_name=>'P12_FILE_BLOB'
,p_static_id=>'p12-file-blob'
,p_validation_sequence=>10
,p_validation=>'P12_FILE_BLOB'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Please select a file to upload.'
,p_validation_condition=>'P12_ID'
,p_validation_condition_type=>'ITEM_IS_NULL'
,p_when_button_pressed=>wwv_flow_imp.id(3250639212923232216)
,p_associated_item=>wwv_flow_imp.id(3250641415590232246)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3250642589715232248)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from EBA_DEMO_FILES'
,p_static_id=>'fetch-row-from-eba-demo-files'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'primary_key_column', 'ID',
  'primary_key_item', 'P12_ID',
  'table_name', 'EBA_DEMO_FILES')).to_clob
,p_internal_uid=>3241241078129246539
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3250642812171232249)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of EBA_DEMO_FILES'
,p_static_id=>'process-row-of-eba-demo-files'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'lock_row', 'Y',
  'primary_key_column', 'ID',
  'primary_key_item', 'P12_ID',
  'supported_operations', 'I:U:D',
  'table_name', 'EBA_DEMO_FILES')).to_clob
,p_process_error_message=>'#SQLERRM_TEXT#'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>3241241300585246540
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3250643019467232249)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_static_id=>'reset-page'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'type', 'CLEAR_CACHE_CURRENT_PAGE')).to_clob
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(3250639409361232216)
,p_internal_uid=>3241241507881246540
);
wwv_flow_imp.component_end;
end;
/
