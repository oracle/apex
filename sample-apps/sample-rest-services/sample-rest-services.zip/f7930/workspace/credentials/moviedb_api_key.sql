prompt --workspace/credentials/moviedb_api_key
begin
--   Manifest
--     CREDENTIAL: MovieDb API Key
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_imp_workspace.create_credential(
 p_id=>15655119485874726
,p_name=>'MovieDb API Key'
,p_static_id=>'moviedb_api_key'
,p_authentication_type=>'HTTP_QUERY_STRING'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
