prompt --workspace/remote_servers/sample_application_github_repositories
begin
--   Manifest
--     REMOTE SERVER: Sample Application - Github Repositories
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(721750674432746101)
,p_name=>'Sample Application - Github Repositories'
,p_static_id=>'Sample_Application___Github_Repositories'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('Sample_Application___Github_Repositories'),'https://api.github.com/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('Sample_Application___Github_Repositories'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('Sample_Application___Github_Repositories'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('Sample_Application___Github_Repositories'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('Sample_Application___Github_Repositories'),'')
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
