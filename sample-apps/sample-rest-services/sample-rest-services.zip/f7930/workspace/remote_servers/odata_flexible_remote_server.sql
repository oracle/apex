prompt --workspace/remote_servers/odata_flexible_remote_server
begin
--   Manifest
--     REMOTE SERVER: OData Flexible Remote Server
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_imp_workspace.create_remote_server(
 p_id=>17028453717544882
,p_name=>'OData Flexible Remote Server'
,p_static_id=>'OData_Flexible_Remote_Server'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('OData_Flexible_Remote_Server'),'#host#')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('OData_Flexible_Remote_Server'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('OData_Flexible_Remote_Server'),'')
,p_configuration_procedure=>'configure_odata_remote_server'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'procedure configure_odata_remote_server(',
'   p_info   in apex_plugin.t_remote_server_info,',
'   p_config in out apex_plugin.t_remote_server_config',
')',
'is',
'begin',
'',
'   p_config.base_url := apex_app_setting.get_value(p_name => ''ODATA_URL'');',
'',
'exception',
'   when no_data_found then',
'      p_config.base_url := null;',
'end;',
''))
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
