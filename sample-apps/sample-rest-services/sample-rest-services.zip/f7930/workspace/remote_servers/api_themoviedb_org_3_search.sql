prompt --workspace/remote_servers/api_themoviedb_org_3_search
begin
--   Manifest
--     REMOTE SERVER: api-themoviedb-org-3-search
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_imp_workspace.create_remote_server(
 p_id=>19597746759082809
,p_name=>'api-themoviedb-org-3-search'
,p_static_id=>'api_themoviedb_org_3_search'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('api_themoviedb_org_3_search'),'https://api.themoviedb.org/3/search/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('api_themoviedb_org_3_search'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('api_themoviedb_org_3_search'),'')
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
