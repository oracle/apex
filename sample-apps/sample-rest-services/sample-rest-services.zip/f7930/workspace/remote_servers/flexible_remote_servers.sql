prompt --workspace/remote_servers/flexible_remote_servers
begin
--   Manifest
--     REMOTE SERVER: flexible remote servers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_imp_workspace.create_remote_server(
 p_id=>18529060167393527
,p_name=>'flexible remote servers'
,p_static_id=>'flexible_remote_servers'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('flexible_remote_servers'),'#host#')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('flexible_remote_servers'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('flexible_remote_servers'),'')
,p_configuration_procedure=>'configure_remote_server'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'procedure configure_remote_server(',
'   p_info   in apex_plugin.t_remote_server_info,',
'   p_config in out apex_plugin.t_remote_server_config',
')',
'is',
'begin',
'   p_config.base_url := apex_app_setting.get_value(p_name => ''REMOTE_SERVER_BASE_URL'') ',
'                        || apex_app_setting.get_value(p_name => ''REMOTE_SERVER_SCHEMA_ALIAS'');',
'',
'exception',
'   when others then',
'      p_config.base_url := null;',
'',
'end;',
''))
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
