prompt --application/shared_components/navigation/lists/interactivity
begin
--   Manifest
--     LIST: Interactivity
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(94320694233969499)
,p_name=>'Interactivity'
,p_list_status=>'PUBLIC'
,p_version_scn=>3887138
);
wwv_flow_imp.component_end;
end;
/
