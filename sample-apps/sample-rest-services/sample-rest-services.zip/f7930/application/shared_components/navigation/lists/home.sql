prompt --application/shared_components/navigation/lists/home
begin
--   Manifest
--     LIST: Home
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(94302958188495697)
,p_name=>'Home'
,p_list_status=>'PUBLIC'
,p_version_scn=>50269995
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94679820729953826)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'REST Data Sources'
,p_list_item_link_target=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-search'
,p_list_text_01=>'This section explores various methods for integrating RESTful services within Oracle APEX. It covers basic HTTP requests and...'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94680178202979949)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Combine with Relational Data',
''))
,p_list_item_link_target=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database-arrow-up'
,p_list_text_01=>'Showcase how to merge and enriche external REST data with local Oracle Tables using ...'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94680467246998245)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Data Display Options'
,p_list_item_link_target=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_text_01=>'This section showcases various techniques for presenting REST data in Oracle APEX, including reports ...'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94680741160012016)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Advanced Features'
,p_list_item_link_target=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-ellipsis-h-o'
,p_list_text_01=>'This section highlights advanced functionalities such as dynamic actions for triggering REST calls and robust error handling ...'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
