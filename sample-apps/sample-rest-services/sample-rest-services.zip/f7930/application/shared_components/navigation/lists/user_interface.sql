prompt --application/shared_components/navigation/lists/user_interface
begin
--   Manifest
--     LIST: User Interface
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(94300678338483549)
,p_name=>'User Interface'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(94279434483483503)
,p_version_scn=>4594966
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94301032192483549)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Theme Style Selection'
,p_list_item_link_target=>'f?p=&APP_ID.:501:&SESSION.::&DEBUG.:10010:::'
,p_list_item_icon=>'fa-paint-brush'
,p_list_text_01=>'Set the default application look and feel.'
,p_required_patch=>wwv_flow_imp.id(94279434483483503)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(95284208551247718)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Reset Data'
,p_list_item_link_target=>'f?p=&APP_ID.:502:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-refresh'
,p_list_text_01=>'This application ships with sample data. You can reset the sample data using this administrative page.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(95724173663797890)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Web Credentials'
,p_list_item_link_target=>'f?p=&APP_ID.:503:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-lock-new'
,p_list_text_01=>'The REST Data Source Plugins & Cards Layout pages rely on TMDb API. Use this page to provide your own TMDb API key.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(97695150653772278)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Network Setup'
,p_list_item_link_target=>'f?p=&APP_ID.:504:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-window-search'
,p_list_text_01=>'This page helps you to setup connection with ORDS and ODATA.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
