prompt --application/shared_components/navigation/lists/advanced_features
begin
--   Manifest
--     LIST: Advanced Features
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(94322544283999405)
,p_name=>'Advanced Features'
,p_list_status=>'PUBLIC'
,p_version_scn=>20808695
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(99565370497197267)
,p_list_item_display_sequence=>1
,p_list_item_link_text=>'REST Synchronization'
,p_list_item_link_target=>'f?p=&APP_ID.:401:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-refresh'
,p_list_text_01=>'Leverage REST Synchronization for improved performance and availability.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(95973161006318377)
,p_list_item_display_sequence=>19
,p_list_item_link_text=>'Invoke API Process'
,p_list_item_link_target=>'f?p=&APP_ID.:402:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-compass'
,p_list_text_01=>'Shows how to declaratively invoke a REST API using the Invoke API Page Process type.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94868803416083046)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'REST Data and PL/SQL'
,p_list_item_link_target=>'f?p=&APP_ID.:404:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-window-pointer'
,p_list_text_01=>'Illustrates how to invoke REST endpoints with PL/SQL and the APEX_EXEC package.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94635605028852496)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Nested JSON and Dynamic Actions'
,p_list_item_link_target=>'f?p=&APP_ID.:405:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-ai-sparkle-generate-text'
,p_list_text_01=>'Use Dynamic Actions to visualize nested JSON from a REST Data Source in two regions.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94871360183157127)
,p_list_item_display_sequence=>41
,p_list_item_link_text=>'REST Data Source Plugins'
,p_list_item_link_target=>'f?p=&APP_ID.:406:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plug'
,p_list_text_01=>'Use a REST Data Source Plug-In to support special functionality of an external REST API.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(99781549479088977)
,p_list_item_display_sequence=>51
,p_list_item_link_text=>'REST and Workflow'
,p_list_item_link_target=>'f?p=&APP_ID.:407:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-workflow'
,p_list_text_01=>'Explains how to orchestrate REST calls using Workflows.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
