prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(94274941999483477)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
,p_version_scn=>50269255
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94287125440483520)
,p_list_item_display_sequence=>9
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94309439979681128)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'REST Data Source'
,p_list_item_link_target=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-window-search'
,p_list_item_current_type=>'TARGET_PAGE'
,p_sub_list_id=>wwv_flow_imp.id(94308748506666992)
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94309929674699451)
,p_list_item_display_sequence=>11
,p_list_item_link_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Combine with Relational Data',
''))
,p_list_item_link_target=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database-arrow-up'
,p_list_item_current_type=>'TARGET_PAGE'
,p_sub_list_id=>wwv_flow_imp.id(94317290780924273)
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94626406420559813)
,p_list_item_display_sequence=>13
,p_list_item_link_text=>'Data Display Options'
,p_list_item_link_target=>'f?p=&APP_ID.:300:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_item_current_type=>'TARGET_PAGE'
,p_sub_list_id=>wwv_flow_imp.id(94619572120533775)
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94310786885721737)
,p_list_item_display_sequence=>14
,p_list_item_link_text=>'Advanced Features'
,p_list_item_link_target=>'f?p=&APP_ID.:400:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-ellipsis-h-o'
,p_list_item_current_type=>'TARGET_PAGE'
,p_sub_list_id=>wwv_flow_imp.id(94322544283999405)
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94299612521483547)
,p_list_item_display_sequence=>10000
,p_list_item_link_text=>'Administration'
,p_list_item_link_target=>'f?p=&APP_ID.:500:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user-wrench'
,p_security_scheme=>wwv_flow_imp.id(94280170220483504)
,p_list_item_current_type=>'TARGET_PAGE'
,p_sub_list_id=>wwv_flow_imp.id(94300678338483549)
);
wwv_flow_imp.component_end;
end;
/
