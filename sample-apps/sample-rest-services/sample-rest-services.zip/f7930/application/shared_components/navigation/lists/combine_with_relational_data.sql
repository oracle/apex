prompt --application/shared_components/navigation/lists/combine_with_relational_data
begin
--   Manifest
--     LIST: Combine with Relational Data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(94317290780924273)
,p_name=>'Combine with Relational Data'
,p_static_id=>'combine-with-relational-data'
,p_version_scn=>'50269019'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(95681596473689234)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Derived Columns'
,p_static_id=>'derived-columns'
,p_list_item_link_target=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-circle-arrow-in-east'
,p_list_text_01=>'Showcases how to use additional <em>derived columns</em> in the <strong>Data Profile</strong> to enrich results coming from the REST service.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94317474959924274)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Post Processing SQL'
,p_static_id=>'post-processing-sql'
,p_list_item_link_target=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-arrow-up'
,p_list_text_01=>'Showcases how to combine external REST data with data from local tables using <strong>Post Processing SQL</strong>.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
