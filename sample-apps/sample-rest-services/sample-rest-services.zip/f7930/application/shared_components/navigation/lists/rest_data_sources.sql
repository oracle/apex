prompt --application/shared_components/navigation/lists/rest_data_sources
begin
--   Manifest
--     LIST: REST Data Sources
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(94308748506666992)
,p_name=>'REST Data Sources'
,p_list_status=>'PUBLIC'
,p_version_scn=>16565667
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94309005886666992)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Simple HTTP'
,p_list_item_link_target=>'f?p=&APP_ID.:101:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table-search'
,p_list_text_01=>unistr('One\2011shot HTTP endpoint delivering your complete dataset instantly.')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94313160137741628)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'ORDS'
,p_list_item_link_target=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database-application'
,p_list_text_01=>'Enable insert, update and delete on ORDS compliant endpoints.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94316932905895904)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'OData'
,p_list_item_link_target=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database-check'
,p_list_text_01=>'Seamlessly integrate and consume external OData REST services.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
