prompt --application/shared_components/navigation/lists/data_display_options
begin
--   Manifest
--     LIST: Data Display Options
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(94619572120533775)
,p_name=>'Data Display Options'
,p_list_status=>'PUBLIC'
,p_version_scn=>23634224
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94633099177690758)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Simple Report'
,p_list_item_link_target=>'f?p=&APP_ID.:301:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table'
,p_list_text_01=>'Shows how to consume a REST endpoint with automatic JSON conversion to present data without advanced features.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94633413665693847)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Report with Pagination'
,p_list_item_link_target=>'f?p=&APP_ID.:302:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table-clock'
,p_list_text_01=>'Highlights how to dynamically fetch and display subsets of data from a REST service using offset/limit parameters, making it suitable for large datasets.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94633899712699876)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Report with Query'
,p_list_item_link_target=>'f?p=&APP_ID.:303:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database-search'
,p_list_text_01=>'Illustrates how to create a report that handles larger REST service responses and offers built-in query capabilities.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94634131248701839)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Cards Layout'
,p_list_item_link_target=>'f?p=&APP_ID.:304:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-address-card'
,p_list_text_01=>'Showcases how to use visual card regions to display REST data in a mobile-friendly format, offering an alternative presentation to traditional reports.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94634781844707759)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Oracle JET Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:305:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-combo-chart'
,p_list_text_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Demonstrates how to build interactive, dynamic visualizations using Oracle JET.',
'',
''))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94699600207927404)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Faceted Search'
,p_list_item_link_target=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-table-search'
,p_list_text_01=>'Demonstrates how to consume and display REST-sourced data using Faceted Search, with filtering by Job and Salary ranges.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94702429091956815)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Map'
,p_list_item_link_target=>'f?p=&APP_ID.:307:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-map-marker'
,p_list_text_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Displays REST data on a map using the built-in APEX Map component.',
'',
''))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(94704085147998295)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Calendar'
,p_list_item_link_target=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar'
,p_list_text_01=>'Presents REST data in the APEX Calendar component for date-based visualization.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
