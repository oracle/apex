prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(94274508379483476)
,p_name=>'Breadcrumb'
,p_static_id=>'breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99515872798924010)
,p_short_name=>'Administration'
,p_static_id=>'administration'
,p_link=>'f?p=&APP_ID.:500:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>500
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99374730706812417)
,p_short_name=>'Advanced Features'
,p_static_id=>'advanced-features'
,p_link=>'f?p=&APP_ID.:400:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>400
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99521379343941921)
,p_parent_id=>wwv_flow_imp.id(99515872798924010)
,p_short_name=>'Application Appearance'
,p_static_id=>'application-appearance'
,p_link=>'f?p=&APP_ID.:501:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>501
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99356594651744653)
,p_parent_id=>wwv_flow_imp.id(99282093413574858)
,p_short_name=>'Calendar'
,p_static_id=>'calendar'
,p_link=>'f?p=&APP_ID.:308:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>308
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99314572783674626)
,p_parent_id=>wwv_flow_imp.id(99282093413574858)
,p_short_name=>'Cards Layout'
,p_static_id=>'cards-layout'
,p_link=>'f?p=&APP_ID.:304:&SESSION.::&DEBUG.:::'
,p_page_id=>304
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99246960689753650)
,p_short_name=>'Combine with Relational Data'
,p_static_id=>'combine-with-relational-data'
,p_link=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:::'
,p_page_id=>200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99282093413574858)
,p_short_name=>'Data Display Options'
,p_static_id=>'data-display-options'
,p_link=>'f?p=&APP_ID.:300:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>300
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99263254363974812)
,p_parent_id=>wwv_flow_imp.id(99246960689753650)
,p_short_name=>'Derived Columns'
,p_static_id=>'derived-columns'
,p_link=>'f?p=&APP_ID.:202:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>202
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99339883964692131)
,p_parent_id=>wwv_flow_imp.id(99282093413574858)
,p_short_name=>'Faceted Search on REST'
,p_static_id=>'faceted-search-on-rest'
,p_link=>'f?p=&APP_ID.:306:&SESSION.::&DEBUG.:::'
,p_page_id=>306
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(94274711691483476)
,p_short_name=>'Home'
,p_static_id=>'home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99399533682485072)
,p_parent_id=>wwv_flow_imp.id(99374730706812417)
,p_short_name=>'Invoke API Process'
,p_static_id=>'invoke-api-process'
,p_link=>'f?p=&APP_ID.:402:&SESSION.::&DEBUG.:::'
,p_page_id=>402
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99352372688715665)
,p_parent_id=>wwv_flow_imp.id(99282093413574858)
,p_short_name=>'Map'
,p_static_id=>'map'
,p_link=>'f?p=&APP_ID.:307:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>307
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99493451054808236)
,p_parent_id=>wwv_flow_imp.id(99374730706812417)
,p_short_name=>'Nested JSON and Dynamic Actions'
,p_static_id=>'nested-json-and-dynamic-actions'
,p_link=>'f?p=&APP_ID.:405:&SESSION.::&DEBUG.:::'
,p_page_id=>405
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99540426257010096)
,p_parent_id=>wwv_flow_imp.id(99515872798924010)
,p_short_name=>'Network Setup'
,p_static_id=>'network-setup'
,p_link=>'f?p=&APP_ID.:504:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>504
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99210809370976285)
,p_parent_id=>wwv_flow_imp.id(99223375373168752)
,p_option_sequence=>12
,p_short_name=>'OData'
,p_static_id=>'odata'
,p_link=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.:::'
,p_page_id=>103
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99322776181682205)
,p_parent_id=>wwv_flow_imp.id(99282093413574858)
,p_short_name=>'Oracle JET Charts'
,p_static_id=>'oracle-jet-charts'
,p_link=>'f?p=&APP_ID.:305:&SESSION.::&DEBUG.:::'
,p_page_id=>305
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99201612077956751)
,p_parent_id=>wwv_flow_imp.id(99223375373168752)
,p_option_sequence=>11
,p_short_name=>'Oracle REST Data Services (ORDS)'
,p_static_id=>'oracle-rest-data-services-ords'
,p_link=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:::'
,p_page_id=>102
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99254258889915499)
,p_parent_id=>wwv_flow_imp.id(99246960689753650)
,p_short_name=>'Post Processing SQL'
,p_static_id=>'post-processing-sql'
,p_link=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.:::'
,p_page_id=>201
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99298053526656475)
,p_parent_id=>wwv_flow_imp.id(99282093413574858)
,p_short_name=>'Report with Pagination'
,p_static_id=>'report-with-pagination'
,p_link=>'f?p=&APP_ID.:302:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>302
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99307136641665844)
,p_parent_id=>wwv_flow_imp.id(99282093413574858)
,p_short_name=>'Report with Query'
,p_static_id=>'report-with-query'
,p_link=>'f?p=&APP_ID.:303:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>303
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99527409956960384)
,p_parent_id=>wwv_flow_imp.id(99515872798924010)
,p_short_name=>'Reset Data'
,p_static_id=>'reset-data'
,p_link=>'f?p=&APP_ID.:502:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>502
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99779449966901397)
,p_parent_id=>wwv_flow_imp.id(99374730706812417)
,p_short_name=>'REST and Workflow'
,p_static_id=>'rest-and-workflow'
,p_link=>'f?p=&APP_ID.:407:&SESSION.::&DEBUG.:::'
,p_page_id=>407
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99419029910706668)
,p_parent_id=>wwv_flow_imp.id(99374730706812417)
,p_short_name=>'REST Data and PL/SQL'
,p_static_id=>'rest-data-and-pl-sql'
,p_link=>'f?p=&APP_ID.:404:&SESSION.::&DEBUG.:::'
,p_page_id=>404
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99506416023825086)
,p_parent_id=>wwv_flow_imp.id(99374730706812417)
,p_short_name=>'REST Data Source Plugins'
,p_static_id=>'rest-data-source-plugins'
,p_link=>'f?p=&APP_ID.:406:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>406
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99223375373168752)
,p_short_name=>'REST Data Sources'
,p_static_id=>'rest-data-sources'
,p_link=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_page_id=>100
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99393247651460890)
,p_parent_id=>wwv_flow_imp.id(99374730706812417)
,p_short_name=>'REST  Synchronization'
,p_static_id=>'rest-synchronization'
,p_link=>'f?p=&APP_ID.:401:&SESSION.::&DEBUG.:::'
,p_page_id=>401
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99193552569940316)
,p_parent_id=>wwv_flow_imp.id(99223375373168752)
,p_short_name=>'Simple HTTP'
,p_static_id=>'simple-http'
,p_link=>'f?p=&APP_ID.:101:&SESSION.::&DEBUG.:::'
,p_page_id=>101
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99291947858608144)
,p_parent_id=>wwv_flow_imp.id(99282093413574858)
,p_short_name=>'Simple Report'
,p_static_id=>'simple-report'
,p_link=>'f?p=&APP_ID.:301:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>301
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99534121465989346)
,p_parent_id=>wwv_flow_imp.id(99515872798924010)
,p_short_name=>'Web Credentials'
,p_static_id=>'web-credentials'
,p_link=>'f?p=&APP_ID.:503:&SESSION.::&DEBUG.:::'
,p_page_id=>503
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(99814185767496368)
,p_parent_id=>wwv_flow_imp.id(99779449966901397)
,p_short_name=>'Workflow Console'
,p_static_id=>'workflow-console'
,p_link=>'f?p=&APP_ID.:408:&SESSION.::&DEBUG.:::'
,p_page_id=>408
);
wwv_flow_imp.component_end;
end;
/
