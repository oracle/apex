prompt --application/shared_components/user_interface/lovs/employee_popup_lov
begin
--   Manifest
--     EMPLOYEE_POPUP_LOV
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(16523375231754759)
,p_lov_name=>'EMPLOYEE_POPUP_LOV'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ename as employee,',
'       empno as return_value,',
'       sal   as old_salary',
'  from eba_demo_rest_employee',
' order by ename',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'RETURN_VALUE'
,p_display_column_name=>'EMPLOYEE'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>21437050
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(16524410162758781)
,p_query_column_name=>'EMPLOYEE'
,p_heading=>'Employee'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(16523997436758781)
,p_query_column_name=>'OLD_SALARY'
,p_heading=>'Old Salary'
,p_display_sequence=>20
,p_data_type=>'NUMBER'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(16524846251758781)
,p_query_column_name=>'RETURN_VALUE'
,p_display_sequence=>30
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp.component_end;
end;
/
