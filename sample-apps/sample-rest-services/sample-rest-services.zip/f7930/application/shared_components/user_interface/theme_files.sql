prompt --application/shared_components/user_interface/theme_files
begin
--   Manifest
--     THEME FILES: 42
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2026.03.30'
,p_release=>'26.1.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
null;
wwv_flow_imp.component_end;
end;
/
