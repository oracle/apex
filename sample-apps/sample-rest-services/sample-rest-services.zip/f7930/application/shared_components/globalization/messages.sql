prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 7930
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(15720191198008927)
,p_name=>'P303.PROCESS.SUCCESS'
,p_message_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Debug enabled. On the Developer Toolbar, click the Debug Button to see more details.',
''))
,p_is_js_message=>true
,p_version_scn=>20416583
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(15718695122879636)
,p_name=>'P402.DA.ERROR.MSG'
,p_message_text=>'Error parsing JSON: %0'
,p_is_js_message=>true
,p_version_scn=>19579011
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(15732786332283577)
,p_name=>'P402.DA.FORBIDDEN.MSG'
,p_message_text=>'Forbidden: You don''t have permission to access this resource.'
,p_is_js_message=>true
,p_version_scn=>20164254
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(15732957025288884)
,p_name=>'P402.DA.NOTFOUND.MSG'
,p_message_text=>'Resource not found.'
,p_is_js_message=>true
,p_version_scn=>20164321
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(15738724256078812)
,p_name=>'P402.DA.ORDS.RESPONSE'
,p_message_text=>'Response from REST API: %0'
,p_is_js_message=>true
,p_version_scn=>20281844
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(15733132883304261)
,p_name=>'P402.DA.SERVEREERR.MSG'
,p_message_text=>'Internal server error. Please try again later.'
,p_is_js_message=>true
,p_version_scn=>20169624
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(15732428967275858)
,p_name=>'P402.DA.UNAUTHORIZED.MSG'
,p_message_text=>'Unauthorized access. Please log in.'
,p_is_js_message=>true
,p_version_scn=>20164153
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(15733379387308625)
,p_name=>'P402.DA.UNEXPECTEDERR.MSG'
,p_message_text=>'An unexpected error occurred.'
,p_is_js_message=>true
,p_version_scn=>20169704
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(15719212456932368)
,p_name=>'P404.PROCESS.SUCCESS'
,p_message_text=>'Store and Orders data processed, summary report email sent successfully.'
,p_is_js_message=>true
,p_version_scn=>19579611
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(15730542314205839)
,p_name=>'P405.DA.REFRESH.MSG'
,p_message_text=>'Chart refreshed'
,p_is_js_message=>true
,p_version_scn=>20157551
);
wwv_flow_imp.component_end;
end;
/
