prompt --application/shared_components/data_profiles/eba_rest_department
begin
--   Manifest
--     DATA PROFILE: EBA_REST_DEPARTMENT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_data_profile(
 p_id=>wwv_flow_imp.id(96329498526973668)
,p_name=>'EBA_REST_DEPARTMENT'
,p_format=>'JSON'
,p_row_selector=>'items'
,p_use_raw_json_selectors=>false
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(96329651893973674)
,p_data_profile_id=>wwv_flow_imp.id(96329498526973668)
,p_name=>'DEPTNO'
,p_sequence=>1
,p_is_primary_key=>true
,p_column_type=>'DATA'
,p_data_type=>'NUMBER'
,p_has_time_zone=>false
,p_selector=>'deptno'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(96329999656973674)
,p_data_profile_id=>wwv_flow_imp.id(96329498526973668)
,p_name=>'DNAME'
,p_sequence=>2
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4000
,p_has_time_zone=>false
,p_selector=>'dname'
);
wwv_flow_imp_shared.create_data_profile_col(
 p_id=>wwv_flow_imp.id(96330314901973674)
,p_data_profile_id=>wwv_flow_imp.id(96329498526973668)
,p_name=>'LOC'
,p_sequence=>3
,p_column_type=>'DATA'
,p_data_type=>'VARCHAR2'
,p_max_length=>4000
,p_has_time_zone=>false
,p_selector=>'loc'
);
wwv_flow_imp.component_end;
end;
/
