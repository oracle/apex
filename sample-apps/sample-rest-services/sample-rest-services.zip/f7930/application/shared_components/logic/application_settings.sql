prompt --application/shared_components/logic/application_settings
begin
--   Manifest
--     APPLICATION SETTINGS: 7930
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(16056156358774255)
,p_name=>'TMDB_APIKEY'
,p_value=>'NO'
,p_is_required=>'N'
,p_valid_values=>'YES,NO'
,p_version_scn=>51369826
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(97765075833099294)
,p_name=>'REMOTE_SERVER_INITIALIZED'
,p_value=>'NO'
,p_is_required=>'N'
,p_valid_values=>'YES,NO'
,p_version_scn=>75158722
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(100923862693099487)
,p_name=>'ODATA_URL'
,p_is_required=>'N'
,p_on_upgrade_keep_value=>true
,p_version_scn=>75144753
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(100924061009101832)
,p_name=>'REMOTE_SERVER_BASE_URL'
,p_is_required=>'N'
,p_on_upgrade_keep_value=>true
,p_version_scn=>75158687
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(100924261443103367)
,p_name=>'REMOTE_SERVER_SCHEMA_ALIAS'
,p_is_required=>'N'
,p_version_scn=>75158655
);
wwv_flow_imp.component_end;
end;
/
