prompt --application/shared_components/logic/application_items/remote_server
begin
--   Manifest
--     APPLICATION ITEM: REMOTE_SERVER
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(97788196434683801)
,p_name=>'REMOTE_SERVER'
,p_protection_level=>'S'
,p_version_scn=>26329235
);
wwv_flow_imp.component_end;
end;
/
