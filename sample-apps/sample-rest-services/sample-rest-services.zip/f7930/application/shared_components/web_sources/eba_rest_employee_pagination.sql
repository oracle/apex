prompt --application/shared_components/web_sources/eba_rest_employee_pagination
begin
--   Manifest
--     WEB SOURCE: EBA_REST_EMPLOYEE_PAGINATION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(97134193668595595)
,p_name=>'EBA_REST_EMPLOYEE_PAGINATION'
,p_static_id=>'eba_rest_pagination'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(97132180668595591)
,p_remote_server_id=>wwv_flow_imp.id(18529060167393527)
,p_url_path_prefix=>'/data/Pagination'
,p_attribute_01=>'FLEXIBLE'
,p_attribute_02=>'limit'
,p_attribute_07=>'offset'
,p_attribute_08=>'OFFSET'
,p_attribute_09=>'hasMore'
,p_attribute_10=>'EQUALS'
,p_attribute_11=>'true'
,p_version_scn=>16940986
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(97134344128595596)
,p_web_src_module_id=>wwv_flow_imp.id(97134193668595595)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
