prompt --application/shared_components/web_sources/sample_application_github_repository_issues
begin
--   Manifest
--     WEB SOURCE: Sample Application - Github Repository Issues
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>0
,p_default_owner=>'ORACLE'
);
wwv_flow_api.create_web_source_module(
 p_id=>wwv_flow_api.id(721811242113776315)
,p_name=>'Sample Application - Github Repository Issues'
,p_static_id=>'Sample_Application_Github_Repository_Issues'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_api.id(721788179794776285)
,p_remote_server_id=>wwv_flow_api.id(721750674432746101)
,p_url_path_prefix=>'repos/oracle/:repo/issues'
);
wwv_flow_api.create_web_source_param(
 p_id=>wwv_flow_api.id(721811963116776315)
,p_web_src_module_id=>wwv_flow_api.id(721811242113776315)
,p_name=>'repo'
,p_param_type=>'URL_PATTERN'
,p_is_required=>false
,p_value=>'docker-images'
);
wwv_flow_api.create_web_source_operation(
 p_id=>wwv_flow_api.id(721811500584776315)
,p_web_src_module_id=>wwv_flow_api.id(721811242113776315)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_caching=>'ALL_USERS'
,p_invalidate_when=>'FREQ=DAILY;BYHOUR=0;BYMINUTE=0;BYSECOND=0'
);
wwv_flow_api.component_end;
end;
/
