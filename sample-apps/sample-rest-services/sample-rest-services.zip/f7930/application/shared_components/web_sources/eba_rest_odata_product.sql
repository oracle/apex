prompt --application/shared_components/web_sources/eba_rest_odata_product
begin
--   Manifest
--     WEB SOURCE: EBA_REST_ODATA_PRODUCT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(95470832101104479)
,p_name=>'EBA_REST_ODATA_PRODUCT'
,p_static_id=>'prod_odata'
,p_web_source_type=>'NATIVE_ODATA'
,p_data_profile_id=>wwv_flow_imp.id(95467700418104477)
,p_remote_server_id=>wwv_flow_imp.id(17028453717544882)
,p_url_path_prefix=>'Northwind.svc/'
,p_attribute_01=>'Products'
,p_attribute_03=>'option_orderby:option_select:option_search:option_client_driven_paging'
,p_attribute_04=>'none'
,p_attribute_05=>'N'
,p_attribute_06=>'count_none'
,p_attribute_07=>'filter_contains:filter_startswith:filter_in:filter_endswith'
,p_version_scn=>37743998
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(95471042835104479)
,p_web_src_module_id=>wwv_flow_imp.id(95470832101104479)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
