prompt --application/shared_components/web_sources/eba_rest_product_workflows
begin
--   Manifest
--     WEB SOURCE: EBA_REST_PRODUCT_WORKFLOWS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(100824169162377522)
,p_name=>'EBA_REST_PRODUCT_WORKFLOWS'
,p_static_id=>'eba_rest_product_workflows'
,p_web_source_type=>'NATIVE_ORDS'
,p_data_profile_id=>wwv_flow_imp.id(100821317945377521)
,p_remote_server_id=>wwv_flow_imp.id(18529060167393527)
,p_url_path_prefix=>'/orders/product/:id'
,p_attribute_01=>'N'
,p_attribute_02=>'HIGHEST'
,p_version_scn=>16754260
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(100824721830377522)
,p_web_src_module_id=>wwv_flow_imp.id(100824169162377522)
,p_name=>'id'
,p_param_type=>'URL_PATTERN'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'1'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(100824338908377522)
,p_web_src_module_id=>wwv_flow_imp.id(100824169162377522)
,p_name=>'fetch single product'
,p_operation=>'GET'
,p_database_operation=>'FETCH_SINGLE_ROW'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(100826557525382766)
,p_web_src_module_id=>wwv_flow_imp.id(100824169162377522)
,p_web_src_operation_id=>wwv_flow_imp.id(100824338908377522)
,p_name=>'PRODUCT_NAME'
,p_param_type=>'DATA_PROFILE'
,p_is_required=>false
,p_direction=>'OUT'
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(100827521586383639)
,p_web_src_module_id=>wwv_flow_imp.id(100824169162377522)
,p_web_src_operation_id=>wwv_flow_imp.id(100824338908377522)
,p_name=>'PRODUCT_DETAILS'
,p_param_type=>'DATA_PROFILE'
,p_is_required=>false
,p_direction=>'OUT'
);
wwv_flow_imp.component_end;
end;
/
