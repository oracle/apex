prompt --application/shared_components/web_sources/sample_application_github_repository_commits
begin
--   Manifest
--     WEB SOURCE: Sample Application - Github Repository Commits
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>12319406322640193
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(74820889094403144)
,p_name=>'Sample Application - Github Repository Commits'
,p_static_id=>'Sample_Application___Github_Repository_Commits'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(74799449853403135)
,p_remote_server_id=>wwv_flow_imp.id(733666003810366051)
,p_url_path_prefix=>'repos/oracle/:repo/commits'
,p_pass_ecid=>true
,p_version_scn=>1089080203
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(74821560689403146)
,p_web_src_module_id=>wwv_flow_imp.id(74820889094403144)
,p_name=>'repo'
,p_param_type=>'URL_PATTERN'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'docker-images'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(74821156659403145)
,p_web_src_module_id=>wwv_flow_imp.id(74820889094403144)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_caching=>'ALL_USERS'
,p_invalidate_when=>'FREQ=DAILY;BYHOUR=0;BYMINUTE=0;BYSECOND=0'
);
wwv_flow_imp.component_end;
end;
/
