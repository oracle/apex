prompt --application/shared_components/web_sources/eba_movie_plug
begin
--   Manifest
--     WEB SOURCE: EBA_MOVIE_PLUG
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(96609545478449030)
,p_name=>'EBA_MOVIE_PLUG'
,p_static_id=>'eba_movie_plug'
,p_web_source_type=>'PLUGIN_COM.ORACLE.APEX.RESTSOURCE.FIXEDPAGESIZE'
,p_data_profile_id=>wwv_flow_imp.id(96604717442449025)
,p_remote_server_id=>wwv_flow_imp.id(19597746759082809)
,p_url_path_prefix=>'/movie'
,p_credential_id=>wwv_flow_imp.id(15655119485874726)
,p_version_scn=>21055822
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(96610132248449032)
,p_web_src_module_id=>wwv_flow_imp.id(96609545478449030)
,p_name=>'query'
,p_param_type=>'QUERY_STRING'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_is_query_param=>true
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(96609812963449031)
,p_web_src_module_id=>wwv_flow_imp.id(96609545478449030)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_legacy_ords_fixed_page_size=>20
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
