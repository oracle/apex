prompt --application/shared_components/web_sources/eba_rest_product_workflows_post
begin
--   Manifest
--     WEB SOURCE: EBA_REST_PRODUCT_WORKFLOWS_POST
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(100978729707109722)
,p_name=>'EBA_REST_PRODUCT_WORKFLOWS_POST'
,p_static_id=>'post'
,p_web_source_type=>'NATIVE_ORDS'
,p_data_profile_id=>wwv_flow_imp.id(100978003251109721)
,p_remote_server_id=>wwv_flow_imp.id(18529060167393527)
,p_url_path_prefix=>'/orders/product_post'
,p_attribute_01=>'N'
,p_attribute_02=>'HIGHEST'
,p_version_scn=>16762132
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(100979787989109722)
,p_web_src_module_id=>wwv_flow_imp.id(100978729707109722)
,p_name=>'id'
,p_param_type=>'URL_PATTERN'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'1'
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(100978958068109722)
,p_web_src_module_id=>wwv_flow_imp.id(100978729707109722)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(100979324000109722)
,p_web_src_module_id=>wwv_flow_imp.id(100978729707109722)
,p_operation=>'POST'
,p_database_operation=>'INSERT'
,p_url_pattern=>'.'
,p_request_body_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'    ',
'   "USER_ID":"#USER_ID#"',
'   ,"PRODUCT_NAME":"#PRODUCT_NAME#"',
'   ,"PRODUCT_DETAILS":"#PRODUCT_DETAILS#"',
'   ',
'}'))
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(100986558119126113)
,p_web_src_module_id=>wwv_flow_imp.id(100978729707109722)
,p_web_src_operation_id=>wwv_flow_imp.id(100979324000109722)
,p_name=>'USER_ID'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(100987012170127850)
,p_web_src_module_id=>wwv_flow_imp.id(100978729707109722)
,p_web_src_operation_id=>wwv_flow_imp.id(100979324000109722)
,p_name=>'PRODUCT_NAME'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(100987385589131133)
,p_web_src_module_id=>wwv_flow_imp.id(100978729707109722)
,p_web_src_operation_id=>wwv_flow_imp.id(100979324000109722)
,p_name=>'PRODUCT_DETAILS'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(101006743241237039)
,p_web_src_module_id=>wwv_flow_imp.id(100978729707109722)
,p_web_src_operation_id=>wwv_flow_imp.id(100979324000109722)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'application/json'
);
wwv_flow_imp.component_end;
end;
/
