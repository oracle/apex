prompt --application/shared_components/web_sources/eba_rest_movies
begin
--   Manifest
--     WEB SOURCE: EBA_REST_MOVIES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(96297614377875508)
,p_name=>'EBA_REST_MOVIES'
,p_static_id=>'eba_rest_movies'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(96292647239875502)
,p_remote_server_id=>wwv_flow_imp.id(20780987798122564)
,p_url_path_prefix=>'/movie/popular'
,p_credential_id=>wwv_flow_imp.id(15655119485874726)
,p_version_scn=>23648570
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(96297772513875510)
,p_web_src_module_id=>wwv_flow_imp.id(96297614377875508)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
