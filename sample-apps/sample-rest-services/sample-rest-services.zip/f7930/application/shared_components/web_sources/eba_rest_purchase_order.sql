prompt --application/shared_components/web_sources/eba_rest_purchase_order
begin
--   Manifest
--     WEB SOURCE: EBA_REST_PURCHASE_ORDER
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(97228724484071495)
,p_name=>'EBA_REST_PURCHASE_ORDER'
,p_static_id=>'eba_rest_purchase_order'
,p_web_source_type=>'NATIVE_HTTP'
,p_data_profile_id=>wwv_flow_imp.id(97220260886071489)
,p_remote_server_id=>wwv_flow_imp.id(18529060167393527)
,p_url_path_prefix=>'/orders/purchaseorders/'
,p_sync_max_http_requests=>1000
,p_version_scn=>19717119
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(97228975513071496)
,p_web_src_module_id=>wwv_flow_imp.id(97228724484071495)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
