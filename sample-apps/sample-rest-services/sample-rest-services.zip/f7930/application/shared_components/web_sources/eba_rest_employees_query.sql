prompt --application/shared_components/web_sources/eba_rest_employees_query
begin
--   Manifest
--     WEB SOURCE: EBA_REST_EMPLOYEES_QUERY
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(96716525393489468)
,p_name=>'EBA_REST_EMPLOYEES_QUERY'
,p_static_id=>'eba_rest_employees'
,p_web_source_type=>'NATIVE_ORDS'
,p_data_profile_id=>wwv_flow_imp.id(96712392525489461)
,p_remote_server_id=>wwv_flow_imp.id(18529060167393527)
,p_url_path_prefix=>'data/emp'
,p_attribute_01=>'N'
,p_attribute_02=>'HIGHEST'
,p_version_scn=>16940912
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(96716782362489468)
,p_web_src_module_id=>wwv_flow_imp.id(96716525393489468)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
