prompt --application/shared_components/email/templates/store_order_summary
begin
--   Manifest
--     EMAIL TEMPLATE: STORE ORDER SUMMARY
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_shared.create_email_template(
 p_id=>wwv_flow_imp.id(16530337508010610)
,p_name=>'STORE ORDER SUMMARY'
,p_static_id=>'STORE_ORDER_SUMMARY'
,p_version_number=>2
,p_subject=>'Store Order Summary Report'
,p_html_body=>wwv_flow_string.join(wwv_flow_t_varchar2(
' <body>',
'    <h2>Store Order Summary Report</h2>',
'    <p>Dear User,</p>',
'    <p>The ETL process has completed successfully. Below is the summary of orders per store:</p>',
'        #ORDER_SUMMARY_TABLE!RAW#',
'    <p>Thank you</p>',
'  </body>'))
,p_html_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<html>',
'  <head>',
'    <style>',
'      body { font-family: arial, sans-serif; font-size: 14px; }',
'      table { border-collapse: collapse; width: 100%; }',
'      th, td { border: 1px solid #dddddd; padding: 8px; text-align: left; }',
'      th { background-color: #f2f2f2; }',
'    </style>',
'  </head>'))
,p_html_footer=>'</html>'
,p_version_scn=>75083861
);
wwv_flow_imp.component_end;
end;
/
