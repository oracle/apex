prompt --application/pages/page_00406
begin
--   Manifest
--     PAGE: 00406
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>406
,p_name=>'REST Data Source Plugins'
,p_alias=>'REST-DATA-SOURCE-PLUGINS1'
,p_step_title=>'REST Data Source Plugins'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(102078941990942903)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  <p>',
'    This page integrates a custom <strong>REST Data Source Plugin</strong> the invoke',
'    REST APIs of <strong>The Movie Database (TMDb) API</strong>. To start searching,',
'    type keywords into the Interactive Report search bar.',
'',
'    This approach highlights how a <strong>REST Source Plugin</strong> can provide ',
'    an implementation for specific behavior of a REST API, like pagination,',
'    filtering or behavior for specific parameter values.',
'  </p>',
''))
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'apex_app_setting.get_value(''TMDB_APIKEY'') = ''YES'''
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(102300415572769474)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(94274508379483476)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(103027066189139213)
,p_plug_name=>'Rest Data Source Plugins Results'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>40
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(96609545478449030)
,p_query_type=>'SQL'
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'apex_app_setting.get_value(''TMDB_APIKEY'') = ''YES'''
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(103027168461139214)
,p_no_data_found_message=>'Please enter keywords to search for movies.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'AHMAMED'
,p_internal_uid=>10959547933966107
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103027239650139215)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103027385480139216)
,p_db_column_name=>'ADULT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Adult'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103027508472139217)
,p_db_column_name=>'TITLE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Title'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'Y'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103027596167139218)
,p_db_column_name=>'VIDEO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Video'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103027665970139219)
,p_db_column_name=>'OVERVIEW'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Overview'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103027930085139221)
,p_db_column_name=>'POPULARITY'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Popularity'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103027991373139222)
,p_db_column_name=>'VOTE_COUNT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Vote Count'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103028078798139223)
,p_db_column_name=>'POSTER_PATH'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Poster Path'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<img src="https://image.tmdb.org/t/p/w45#POSTER_PATH#" alt="Movie Poster" onerror="this.outerHTML=''No image available'';" />',
''))
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103028169919139224)
,p_db_column_name=>'RELEASE_DATE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Release Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103028302213139225)
,p_db_column_name=>'VOTE_AVERAGE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Vote Average'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if #VOTE_AVERAGE# >= 4/}',
unistr('  \2605\2605\2605\2605\2605'),
'{else/}',
unistr('  \2605\2605\2605\2606\2606'),
'{endif/}',
''))
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103028363203139226)
,p_db_column_name=>'BACKDROP_PATH'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Backdrop Path'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div>',
'  {if BACKDROP_PATH  /}',
'      <img src="https://image.tmdb.org/t/p/w45#BACKDROP_PATH#" alt="Movie Backdrop" />',
'  {else/}',
'      <p>No Backdrop</p>',
'  {endif/}',
'</div>',
'',
'',
'',
''))
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103055862964351877)
,p_db_column_name=>'ORIGINAL_TITLE'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Original Title'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103055984635351878)
,p_db_column_name=>'ORIGINAL_LANGUAGE'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Original Language'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(16434086302414714)
,p_db_column_name=>'GENRE_IDS'
,p_display_order=>150
,p_column_identifier=>'Q'
,p_column_label=>'Genre Ids'
,p_column_type=>'CLOB'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(103071467241352237)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'35729'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:ADULT:TITLE:VIDEO:OVERVIEW:POPULARITY:VOTE_COUNT:POSTER_PATH:RELEASE_DATE:VOTE_AVERAGE:BACKDROP_PATH:ORIGINAL_TITLE:ORIGINAL_LANGUAGE'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(99500994680825082)
,p_page_id=>406
,p_web_src_param_id=>wwv_flow_imp.id(96610132248449032)
,p_page_plug_id=>wwv_flow_imp.id(103027066189139213)
,p_value_type=>'NULL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105069100299100612)
,p_plug_name=>'Web Credentials Not provided'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_source=>'This page relies on a REST Data Source. You need to provide your own API key for <strong>themoviedb.org</strong>. Go to administration and set your own api key in the Manage web credentials page'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'apex_app_setting.get_value(''TMDB_APIKEY'') = ''NO'''
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99499291449825079)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(105069100299100612)
,p_button_name=>'Set_API_Key'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Set API Key'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:503:&SESSION.::&DEBUG.::P304_SOURCE:406'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98354246018089849)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(102300415572769474)
,p_button_name=>'NEXT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:407:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98354162723089848)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(102300415572769474)
,p_button_name=>'PREVIOUS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:405:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(103068011526351929)
,p_name=>'P406_MOVIE'
,p_item_sequence=>20
,p_item_default=>'batman'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp.component_end;
end;
/
