prompt --application/pages/page_00504
begin
--   Manifest
--     PAGE: 00504
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>504
,p_name=>'Network Setup'
,p_alias=>'NETWORK-SETUP1'
,p_step_title=>'Network Setup'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(94280170220483504)
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(100799418520345243)
,p_plug_name=>'Update OData Base URL'
,p_icon_css_classes=>'fa-number-2'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--noIcon:t-Alert--info:t-Alert--accessibleHeading'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br/>',
'<p>Enter the URL of a working OData endpoint returning "Northwind" data</p>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(100799432348345244)
,p_plug_name=>'Update Or Set Proxy Server'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--noIcon:t-Alert--info:t-Alert--accessibleHeading'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br/>',
'<p>',
'    Use this field to specify a proxy server to be used by the application.',
'    Using a proxy server may be required for REST requests done by the application, for instance when REST Data Sources or the APEX_WEB_SERVICE package is used.',
'</p>',
'',
'<br/>',
'<p>',
'    Example: http://www-proxy.example.com',
'</p>',
''))
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'not apex_application_global.g_cloud'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105104955293285599)
,p_plug_name=>'Update Remote Server'
,p_icon_css_classes=>'fa-number-1'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--noIcon:t-Alert--info:t-Alert--accessibleHeading'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<br/>',
'<p>Enter the remote server Base URL and Schema Alias (follow the guide above to ensure remote server is properly set up)</p>'))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105150503538623895)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(94274508379483476)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(105819974020926794)
,p_plug_name=>'General Guide'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div style="margin-bottom: 1em; padding: 10px;">',
'  <strong>Remote Server Update Guide:</strong>',
'  <p style="margin: 5px 0;">',
'    1. Enter the base portion of your ORDS URL  into the first field.  ',
'    <em>Example:</em> https://apex.oracle.com/pls/apex/',
'  </p>',
'  <p style="margin: 5px 0;">',
'    2. In the second field, enter the  schema name that appears in the URL path.  ',
'    <em>Example:</em> trainingworkspace or whatever',
'  </p>',
'  <p style="margin: 5px 0;">',
'    3. Click <strong>Save</strong> to save the changes. The application will use this configuration to construct REST endpoints for data retrieval and updates.',
'  </p>',
'</div>',
''))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99539844423010096)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(105150503538623895)
,p_button_name=>'Save'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Save'
,p_button_position=>'NEXT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(99541661480010097)
,p_branch_name=>'Go To Page 500'
,p_branch_action=>'f?p=&APP_ID.:500:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_COMPUTATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(100799546219345245)
,p_name=>'P504_ODATA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(100799418520345243)
,p_item_default=>'apex_app_setting.get_value(p_name =>''ODATA_URL'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'OData Endpoint URL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_protection_level=>'S'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Please enter the URL of a valid OData endpoint that provides "Northwind" data</p> </br>',
'Example: <em>https://ODataBaseUrl/version/Northwind/</em>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(100799713647345246)
,p_name=>'P504_PROXY_SERVER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(100799432348345244)
,p_prompt=>'Proxy Server'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>2318601014859922299
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105105558000285601)
,p_name=>'P504_BASE_URL'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(105104955293285599)
,p_prompt=>'Base URL'
,p_source=>'apex_util.host_url(''APEX_PATH'');'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--indicatorAsterisk:t-Form-fieldContainer--xlarge:t-Form-fieldContainer--boldDisplay'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(105108918455285634)
,p_name=>'P504_SCHEMA'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(105104955293285599)
,p_prompt=>'Schema Alias'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select lower(path_prefix)',
'    from apex_workspaces',
'   where workspace_id = v(''workspace_id'');'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>2526760615038828570
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--indicatorAsterisk:t-Form-fieldContainer--xlarge:t-Form-fieldContainer--boldDisplay'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(99540720962010097)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Remote Server'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    ',
'begin ',
'    apex_app_setting.set_value(''REMOTE_SERVER_BASE_URL'', :P504_BASE_URL);',
'    apex_app_setting.set_value(''REMOTE_SERVER_SCHEMA_ALIAS'', :P504_SCHEMA);',
'    apex_app_setting.set_value(''ODATA_URL'', :P504_ODATA);',
'    if :P504_PROXY_SERVER is not null and not apex_application_global.g_cloud then',
'      apex_application_admin.set_proxy_server(',
'         p_application_id => v(''APP_ID''),',
'         p_proxy_server   => :P504_PROXY_SERVER',
'      );',
'    end if;',
'    :REMOTE_SERVER := ''YES'';',
'    apex_app_setting.set_value(''REMOTE_SERVER_INITIALIZED'', ''YES'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'error while setting remote server'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(99539844423010096)
,p_process_success_message=>'Remote Server set successfully'
,p_internal_uid=>7473100434836990
);
wwv_flow_imp.component_end;
end;
/
