prompt --application/pages/page_00405
begin
--   Manifest
--     PAGE: 00405
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.0'
,p_default_workspace_id=>20
,p_default_application_id=>7930
,p_default_id_offset=>15349786538206521
,p_default_owner=>'ORACLE'
);
wwv_flow_imp_page.create_page(
 p_id=>405
,p_name=>'Nested JSON & Dynamic Actions'
,p_alias=>'NESTED-JSON-DYNAMIC-ACTIONS'
,p_step_title=>'Nested JSON & Dynamic Actions'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>'MUST_NOT_BE_PUBLIC_USER'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(104553307121232662)
,p_plug_name=>'Parent Nested JSON'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>20
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(97228724484071495)
,p_query_type=>'SQL'
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(104553396880232663)
,p_max_rows_per_page=>'10'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'AHMAMED'
,p_internal_uid=>12485776353059556
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104553502970232664)
,p_db_column_name=>'PO_USER'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Ordered By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'Y'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104553613495232665)
,p_db_column_name=>'PO_PONUMBER'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Purchase Order Number'
,p_column_link=>'#'
,p_column_linktext=>'<span class="t-Button-label">PO - #PO_PONUMBER#</span>'
,p_column_link_attr=>'class="po-link t-Button t-Button--hot t-Button--small t-Button--primary t-Button--simple t-Button--gapLeft" data-po-number="#PO_PONUMBER#"'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104553817009232667)
,p_db_column_name=>'PO_REFERENCE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Order Reference'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104553956673232668)
,p_db_column_name=>'PO_REQUESTOR'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Requestor Full Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(104650581533717023)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'51674'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PO_USER:PO_PONUMBER:PO_REFERENCE:PO_REQUESTOR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(104627477254638190)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(94274508379483476)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(104703870940446431)
,p_plug_name=>'Number of Line Items per Product in Selected Purchase Order'
,p_region_name=>'chart-region'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(97228724484071495)
,p_array_column_id=>wwv_flow_imp.id(97221072508071491)
,p_query_type=>'SQL'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_ajax_items_to_submit=>'PO_P_NUMBER'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(99484143515808232)
,p_region_id=>wwv_flow_imp.id(104703870940446431)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(99486466940808233)
,p_chart_id=>wwv_flow_imp.id(99484143515808232)
,p_static_id=>'chart-region'
,p_seq=>10
,p_name=>'Series'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select part_description as label,',
'       quantity         as value,',
'       ''Product: '' || part_description || ''<br/>Quantity: '' || quantity as custom_tooltip',
'  from #APEX$SOURCE_DATA#',
' where po_ponumber = :PO_P_NUMBER'))
,p_ajax_items_to_submit=>'PO_P_NUMBER'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(97228724484071495)
,p_array_column_id=>wwv_flow_imp.id(97221072508071491)
,p_source_post_processing=>'SQL'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'LABEL'
,p_items_short_desc_column_name=>'CUSTOM_TOOLTIP'
,p_custom_column_name=>'VALUE'
,p_color=>'#34aadc'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(99484673207808232)
,p_chart_id=>wwv_flow_imp.id(99484143515808232)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'Product'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(99485317179808232)
,p_chart_id=>wwv_flow_imp.id(99484143515808232)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Quantity'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(99485889437808232)
,p_chart_id=>wwv_flow_imp.id(99484143515808232)
,p_axis=>'y2'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'off'
,p_split_dual_y=>'auto'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(104704346773446436)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div>',
'  <p>',
'    This page demonstrates how to consume nested data from the ',
'    <strong>EBA_REST_PURCHASE_ORDER</strong> REST Data Source. ',
'    By configuring a Data Profile that maps the parent purchase order details ',
'    and nested line items, we can display a two-tier layout:',
'  </p>',
'  <ul>',
'    <li>',
'      <strong>Parent Region</strong>: Shows general purchase order information ',
'      (PO number, shipping instructions).',
'    </li>',
'    <li>',
'      <strong>Child Region</strong>: Displays the associated line items ',
'      (part details, quantity, etc.) for the selected PO.',
'    </li>',
'  </ul>',
'  <p>',
'    A dynamic action triggers when you click a PO number in the parent region, ',
'    updating the child region to show only the nested data (line items) for ',
'    that specific purchase order. This highlights the power of Oracle APEX in ',
'    handling nested JSON responses and binding them to interactive reports or ',
'    charts through Data Profiles.',
'  </p>',
'</div>',
''))
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98354074307089847)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(104627477254638190)
,p_button_name=>'NEXT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Next'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:406:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98354006823089846)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(104627477254638190)
,p_button_name=>'PREVIOUS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_button_redirect_url=>'f?p=&APP_ID.:404:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-angle-left'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(104665104889724973)
,p_name=>'PO_P_NUMBER'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(99494103287808237)
,p_name=>'Set Page Item'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.po-link'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99494561514808237)
,p_event_id=>wwv_flow_imp.id(99494103287808237)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var poNumber = $(this.triggeringElement).attr("data-po-number");',
'apex.item(''PO_P_NUMBER'').setValue(poNumber);',
'apex.region(''chart-region'').refresh();',
'apex.message.ariaMessage(apex.lang.formatMessage(''P303.PROCESS.SUCCESS''));',
'',
'',
''))
);
wwv_flow_imp.component_end;
end;
/
